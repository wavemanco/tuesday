I'll read the reference files before building the pack.
Dara, your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-canned-a4b39ec3/ashgrove_member-experience-lead_interview_pack.md`.

I built it in loop mode, one section per round on 20 November, with 25 questions across the three rounds. I didn't search the web, because your pasted values, the recruiter's email, the July strategy brief and the JD already covered everything I'd have looked up. Persona weights follow each round's role, since the interviewers aren't named yet.

- **Your biggest gap is the contact centre.** You said you've never worked in one, and the role owns complaints there end to end. D1 is the question to rehearse first: concede it plainly, hold only what you've said about the branch complaints log and training tellers, and have a spoken plan for learning the contact-centre side.
- **Your second gap is presenting to senior leaders.** You said you've never presented above regional level. The pack has you say that in your own words and follow it with a preparation plan. B1 and D3 cover it.
- **The panel round is where the values and the strategy meet.** "Own the Fix" says whoever finds the problem keeps hold of it. The escalation case (H1) works best if your answer says who keeps hold after a complaint moves up. "Neighbours, Not Numbers" sits right next to the plan to consolidate eight branches into five hubs, so expect H3 or something like it.
- **The four value questions are scaffolds, not stories.** None of your sentences yet carries a story for any value, so G1 to G4 show what a good story needs and then your nearest material. The slowest prep item is finding real stories for them.
- **Several fit rows depend on details only you have.** Whether the spreadsheet was built in Excel, what it showed, what made the complaints log "formal", and any contact with digital teams are all answer slots in the pack. Your true answers would firm up those rows, and the pack should be re-run once you have them.

I can run a live drill as the Head of Member Services on D1, or as the panel on H1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you want the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview pack for Dara

Loop mode, built 11 November 2026 for three rounds on 20 November 2026 (nine days out).

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Nothing further about format |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; the panel is also the values round and scores against the four values |

Interviewer names are not assigned yet, so persona weights follow each round's role, not a person.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each round has its own persona weights, bank and reverse questions. The fit snapshot, prohibited claims, sources and upgrade menu are shared.
- **Type key.** VAL: whether past behaviour shows the company's published values. EXP: whether your own account of your work survives follow-ups. JD: a stated responsibility or requirement of this job. CO: whether you can think at the company's altitude, from its strategy. CASE: a live problem from the role, scored on structure.
- **Guidance is scaffolding, not a script.** Say it in your own words. Each question's Provenance cell shows the sentences of yours that its guidance rests on; anything beyond them is an answer slot.
- **An answer slot is an instruction for the interview.** Answer whichever branch is true. Saying plainly that you did not do something, or that it was not yours, is a complete answer and never a confession.
- **IDs.** Fit rows are F1 to F9. Questions run A and B (round 1), C, D, E (round 2), G, H, J (round 3).

## Prep triage

Nine days. The few things to do well, in order:

1. **D1, the highest-ROI prep in the pack.** Rehearse it aloud until it is boring, with all four levels. Start today.
2. **The answer slots on F1, F3, F4, F6, F7 and F9.** Write your true answers in your own words (A4, A5, C3, D2, E1 use them). Anything you write that you can say outside a drill upgrades those rows.
3. **Four real stories for the four values and one for C1.** G1 to G4 and C1 are selection scaffolds because none of your sentences carries a story yet. Start looking now; this is the slowest item.
4. **H1 aloud, timed to 20 minutes,** naming which value each step serves.
5. **A1, A3, B1 and B3 as spoken openings.** These are round 1, and they set what round 2 starts from.
6. **Day before:** the reverse questions for each round, one read.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log, with nothing inspected behind it, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any stage beyond the log was yours to handle, say which and what you did, in your own words; if none was, or there was no such stage, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says you built the monthly complaints spreadsheet, and the words stay there. It does not show what the spreadsheet showed. Answer slot: say what it showed and who used it, in your own words; if there is a part of it you did not build or cannot explain, say so plainly and stay with what you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Derivation: a built monthly spreadsheet read against Excel reporting. The sentence says spreadsheet, and nothing shows what it was built in. Answer slot: the JD names Excel, so expect a probe on what it was built in. Say the tool in your own words; if it was not Excel, say so plainly and say what you built in it |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on the face of it, and a CV-style line with nothing inspected behind it, so expect a probe on what the work consisted of. Lead in the sentence's own terms: "6 years in retail banking, the last 3 as a branch supervisor." |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Derivation: a formal complaints log read against the JD's regulated-complaints line. The sentence says formal and does not show what made it so. Answer slot: expect a probe on what made the log formal. Say what made it formal, in your own words; if you do not know what rules sat behind it, or none did, say so plainly and stay with the log you handled |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | transferability | Derivation: training new tellers on an escalation script read against coaching supervisors on escalations. Your material says tellers, not supervisors, and the words stay at that scope: "I trained new tellers on our escalation script." Answer slot: expect a probe on who beyond new tellers you took through escalations. If you showed supervisors or peers anything, say what and how; if not, say so plainly and stay with the tellers |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Nothing added to suggest a senior audience you have not had |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not mention digital work. Answer slot: the JD names digital teams and self-service journeys, so expect a probe on any contact with digital channels. If any of your branch work touched them, say what and which part was yours; if none did, say so plainly and answer as a plan |

## Grounding brief

From the 2026 strategy brief Ashgrove published in July 2026, which the recruiter sent you. It is about four months old on 11 November, so treat it as current unless an interviewer describes the plan differently.

| Item | What the brief says | Source | Provenance | What it means for you |
|---|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | Your pasted brief | [grounded] | Complaints will increasingly start in channels with no counter; E1 and E2 rehearse it |
| Branch consolidation | Consolidate eight branches into five hubs over 2027 | Your pasted brief | [grounded] | Sits next to the value "Neighbours, Not Numbers", so expect it to come up in round 3; H3 and G3 rehearse it |
| New product | Launch a small-business lending product in Q1 2027 | Your pasted brief | [grounded] | A new product means complaint types nobody at Ashgrove has handled yet; a follow-up in E1 |
| Competition | The main competitive pressure is app-only banks | Your pasted brief | [grounded] | Use as context for why complaints handling matters, not as a thesis you must defend |
| Read across | Digital shift, hub consolidation and a new product all land inside the first two years of this role | Derived from the three rows above | [inferred] | The monthly report and the escalation process are likely to be asked about as things that must hold up through change |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | A3, A4, C1, D1, D2, H1 |
| Report monthly on complaint volumes and resolution times | A5, D3, H3 |
| Coach branch supervisors on escalations | C3, H2, J1 |
| Work with digital teams on self-service journeys | E1, E2 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | A4, C1 |
| Confident presenting to senior leaders | B1, C2, D3 |
| Comfortable with Excel reporting | A5 |

The four published values are covered by G1 to G4 (and Own the Fix again by C1).

---

# Round 1: the recruiter (30 minutes)

## Persona table, round 1

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | A friendly half hour: your journey, why Ashgrove, why now. Casual questions are still scored | High. A recruiter screen starts from Conversational plus a light Skeptic, and the email gives this slot no stated focus beyond the chat | A ninety-second arc built from sentences you have said; treat casual questions about JD topics as scored; give a reason of your own for Ashgrove |
| Skeptic, light | Knockout checks in a friendly register: the contact centre, presenting to senior leaders | Medium. Same starting prior; the JD's contact-centre and senior-leader lines meet the two limits you stated (F2, F8), so a check on both is plausible | Say each stated limit plainly in the words F2 and F8 give, then the plan; no apology and no stretching |

## Bank, round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role asks for four-plus years in financial-services customer operations. Walk me through your experience against that." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | A ninety-second arc in the beats these sentences state. First "6 years in retail banking, the last 3 as a branch supervisor", in those terms. Then the formal complaints log you handled and the new tellers you trained on the escalation script. Then the monthly complaints spreadsheet you built. Say "I" for what the sentences say you did, and place nothing in a particular year unless you can. Answer slot: your material does not say what the years before the supervisor role held; say it in your own words, or say you would rather start with the supervisor years. End on one reason of your own for this role | F5 is the evidence for the years line, and F1 and F3 are the sentences it leans on; JD because it restates the JD's own requirement, delivered as an EXP-style arc |
| A2 | "What draws you to Ashgrove?" | CO | [grounded] | No claim about your past is needed. Name one of the four published values you can speak to and say why it matters to you in a sentence of your own. Add one fact from the July 2026 strategy brief, such as the move of 40% of member service to digital by 2028, and say what you would want to understand about it. If your honest reason is mostly the scope of the role, say that plainly rather than reaching for the values | A recruiter screen scores motivation consistency; the JD calls Ashgrove member-owned, the values are published, and the brief is current. CO because it tests homework depth at the company's altitude |
| A3 | "The role covers the contact centre as well as branches. Where does your experience sit against that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say the stated limit first and plainly: "I've never worked in a contact centre." Then what your material does carry, at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Then a plan, said as a plan: two or three first-month steps of your own choosing for learning how complaints reach and leave the contact centre. Do not describe branch work as contact-centre work, and do not apologise. Stop after the plan | F2 is the stated gap and the likeliest knockout in a first round; JD because it scores the headline responsibility |
| A4 | "Tell me about the formal complaints you've handled." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F6 and F1: tell the two things the sentence states, in your own words. You handled the branch's formal complaints log, and you trained new tellers on the escalation script. Answer slot: the JD's complaints requirement makes a probe on what made the log formal likely. Say what made it formal, in your own words; if you do not know what rules sat behind it, or none did, say so plainly and stay with the log you handled | F6 is the thinnest evidence for the JD's complaints requirement and the likeliest place to be probed; JD because it scores a stated requirement, EXP in delivery |
| A5 | "Tell me about the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 and F4: "I built the monthly complaints spreadsheet our regional manager uses." Say it at that scope. Answer slot: the JD asks for monthly reporting and for Excel, so expect a probe on what the spreadsheet showed and what it was built in. Say both in your own words; if part of it is something you did not build or cannot explain, or it was not built in Excel, say so plainly and stay with what you did build | F3 and F4 are the rows carrying the JD's reporting and Excel lines, and both rest on this one sentence; JD because both are listed requirements |
| B1 | "Tell me about the most senior audience you've presented to." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold the stated limit exactly: "I've never presented to anyone above regional level." Answer slot: your material does not say what you presented at regional level, or whether the spreadsheet was presented rather than sent. If you presented anything at that level, say what and how it went, in your own words; if you did not present, say so plainly. Then a plan, said as a plan: one or two steps of your own for preparing to present to senior leaders | F8 is a stated gap against the JD's senior-leaders line, and an open prompt makes you choose the audience before you are asked; JD because it scores that line |
| B2 | "Why this move, and why now?" | EXP | [generic] | No claim about your past is needed beyond the facts you choose to tell. Give the true reason in a sentence of your own, and one reason that points at this role rather than away from the current one. If part of the honest reason is simply that it is the next step, say that plainly | A Skeptic's motivation stem; EXP because it tests whether your own career story holds together under follow-up |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Choose the one you will name before you are asked, using the stated words: "I've never worked in a contact centre" or "I've never presented to anyone above regional level". Then the plan, said as a plan. Then what you can start on day one at the scope of "I handled the branch's formal complaints log and trained new tellers on our escalation script." Do not name a weakness you do not have in order to look candid | F2 and F8 are the two limits you stated; picking one in advance means it is chosen, not found live. JD because it asks you to score yourself against the JD |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "How will the second and third rounds be scored, and does the Head of Member Services see the panel's marks?" | Shows you understand the loop is scored, and gets the one process fact only the recruiter holds |
| 2 | "Can you tell me the roles, or the branches, of the two people on the panel?" | Costs the recruiter nothing and lets you retune round 3; the upgrade menu says what a name or role unlocks |
| 3 | "Is the 20-minute case written or spoken, and do I see any material beforehand?" | Lets you rehearse the right format for H1 rather than a guess |
| 4 | "What happens after 20 November, and when should I expect to hear?" | Practical, and signals you are weighing the role seriously |
| 5 | "What do you hear most often from the team about what this role most needs to fix?" | Invites the recruiter's own account, which a screen rarely gets, and shapes how you open in round 2 |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes)

## Persona table, round 2

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" prompts, STAR-shaped | High. The email says the round is mostly behavioural, which moves this above the hiring-manager starting prior of Case plus Skeptic | Pick the story first; "we" for context, "I" for what you did; where no story comes to mind, say so plainly and give the nearest thing your material carries |
| Skeptic | The contact-centre gap and the senior-audience gap, asked by the person who would carry the risk of hiring you | High. A hiring manager starts from Case plus Skeptic, and F2 and F8 are the two largest gaps in the snapshot | Rehearse D1 until it is boring: concede specifically, hold what the quotes carry, plan out loud |
| Case / Strategist | A short live problem on the role's own agenda: digital shift, self-service | Medium-low. The hiring-manager prior includes Case, but the email's "mostly behavioural" lowers it to two questions | Clarify before structuring; use the strategy brief's own figures; ask rather than assert |

## Bank, round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a complaint that had to be escalated, and what you did." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one real complaint that moved up from you or the branch. It needs a named stake for the member, one thing you did yourself ("I" for that, "we" for the rest), and where the member stood at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries at its own scope, "I handled the branch's formal complaints log and trained new tellers on our escalation script.", or how you would handle an escalation. Answer slot: if you stayed with it after it moved up, say how; if it left your hands, say so plainly | The JD's escalation and complaints lines make this the most direct behavioural prompt for F1 and F6; EXP because it tests what was actually yours |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | No claim about your past is supplied. Selection criteria: a named truth someone did not want, the audience's real level (say it plainly), what you said, and whether anything changed. Choose a story where the truth was acted on; where your material shows none, say so rather than supplying an ending. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would deliver one | The role reports complaint data upward, and F8 limits the audience you can claim; VAL because it scores behaviour under a hard message, and the persona stem is the source |
| C3 | "Tell me about a time you coached someone on handling escalations." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7: "I trained new tellers on our escalation script." That is the beat the sentence carries; tell it in your own words. Answer slot: the JD asks about coaching branch supervisors, so expect a probe on who beyond the tellers you took through escalations. If you showed supervisors or peers anything, say what and how; if not, say so plainly and stay with the tellers | F7 is the evidence for the JD's coaching line and is at tellers' scope; JD because it scores a stated responsibility, with behavioural delivery |
| D1 | "You haven't worked in a contact centre, and this role owns complaints there too. Why should I believe you can lead it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI rehearsal in this pack.** It will be asked in some form, and it is aimed where F2 is thinnest. Hold only what the quotes carry. Level 1: concede first and specifically, "I've never worked in a contact centre." Then hold: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Level 2, pushed on what phone complaints need that you have not seen: say what you would not know yet rather than guessing at it, then the plan, said as a plan, for what you would learn first and from whom. Level 3, asked whether the contact-centre team would follow a lead without that background: do not claim they would; say how you would earn it by listening first and asking what they want from the role. Level 4, "and if you are wrong?": say what you would check and who you would ask. Never fold the core claim, and never stretch the branch work into contact-centre work. Answer slot: if any of your branch work touched contact-centre colleagues or calls, say what and which part was yours; if nothing did, say so plainly | Deepest rehearsal because this is the most predictable objection to this candidate: the role's headline duty meets F2. JD because it scores that duty; the Skeptic's delivery is why it is rehearsed with four follow-up levels |
| D2 | "How much of the branch's complaints process was actually yours?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold what the sentence carries and nothing more: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Hold it through two follow-ups by returning to those two things, never by adding to them. Answer slot: if you also set or changed any step in how complaints moved through the branch, say which; if the process was set by others, or you set no step, say so plainly. Name one part you did not own, if there was one, before you are asked | F1 is where the JD's end-to-end duty presses against a branch-level log; EXP because the question tests attribution, in a pressure register |
| D3 | "Walk me through how you would present complaint volumes and resolution times to our senior leaders." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | No past is needed. Structure it aloud: ask what the leaders decide with it; lead with the answer in plain words, one headline, then what sits behind it, then what you recommend; show a trend before a single month. Say how you would explain a figure if someone asked how it was counted. If asked about your experience, the stated limit holds: "I've never presented to anyone above regional level." Then how you would rehearse with the Head of Member Services before the first one, as a plan | F8 against the JD's reporting and senior-leaders lines (F3 for the reporting); JD because it scores both, delivered as a live problem |
| E1 | "Ashgrove wants 40% of member service on digital channels by 2028. What happens to complaints along the way, and what would you want to know first?" | CO | [grounded] | Clarify before structuring: which complaint types move first; where a member would raise a complaint in an app and who sees it; what stays with a person. Then objective, segments (simple against complex), approach, what you would measure, risks (a complaint that bounces between channels). If there is time, ask who would own complaints on the small-business lending product due in Q1 2027, rather than asserting an answer. Answer slot: if any of your branch work touched digital or self-service channels, say what and which part was yours; if none did, say so plainly and answer as a set of questions | The brief's first strategic target, and the one place F9 has nothing to quote; CO because it tests strategy fluency, with CASE structure |
| E2 | "What would you want a member to be able to resolve without asking anyone, and what must always reach a person?" | JD | [grounded] | Think from the member's side of the counter, the first published value. Sort complaints by how simple they are and how upset the member is likely to be. Self-service suits status checks and simple fixes; a person should see anything involving harm to the member or a repeat contact. Say how a member would learn where their complaint stands, in plain words. Concede that you would test this with the digital teams rather than decide it alone. Answer slot: if you have worked with a digital or online team, say what; if not, say so plainly and answer as principles | F9 is the row for the JD's digital-teams line; JD because it scores that line and uses two of the published values |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "Where does a complaint enter today, and where does it leave the contact centre or a branch's hands?" | Shows you think in ownership from start to finish, the way the JD frames the role |
| 2 | "Which part of the complaints process do you most want improved in the first year, and how would you know it had been?" | Makes you a partner in the manager's own priority, with a measure attached |
| 3 | "How do you see this role working with the digital teams as 40% of service moves to digital by 2028?" | Uses the brief's own target and invites the manager to say how it is meant to work |
| 4 | "What should the monthly report change in how leaders decide things?" | Shows you see reporting as a tool for decisions, not a spreadsheet to circulate |
| 5 | "What support would a new lead get in learning the contact-centre side?" | Turns your stated limit into a practical ramp conversation, and shows you plan to close it |

---

# Round 3: the panel of two branch managers (60 minutes; includes the 20-minute case; the values round)

## Persona table, round 3

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Prompts mapped to the four published values, scored against them | Very high. The recruiter's email says the panel scores against the four values | A real story per value where you have one; where none comes to mind, say so plainly and use the nearest material; never recite a slogan |
| Case / Strategist | The 20-minute complaint-escalation case | Certain for 20 of the 60 minutes: the email names the case. Its content is not yet known | Clarify first, say the structure aloud, name which value each step serves, ask before asserting |
| Peer Evaluator | The seam between this role and the branches; what you would need from them | Medium. Reading from the JD (coaching branch supervisors, working across branches), the managers run the branches this role touches. That is the pack's inference, not something the email says | Offer seam principles instead of pretending to know the seam; say what you bring the branches, not only what you need |

## Bank, round 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Members First, Always: pick a time when what was easiest for the branch and what was right for the member differed. It needs a decision you made, what it risked, and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material carries at its own scope, "I handled the branch's formal complaints log and trained new tellers on our escalation script.", or say how you would decide | The first published value; VAL because it scores whether behaviour, not slogan familiarity, matches the value. F1 is the nearest material |
| G2 | "Tell me about a time you made something complicated clear to a member or a colleague." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Plain Words: pick a time when the explanation had to land the first time. It needs what you changed in the words you used and what showed it had landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries at its own scope, "I trained new tellers on our escalation script.", or how you would make a complaint reply plain | The value says that if a member needs it explained twice, the writer got it wrong; F7 is the nearest material; VAL |
| G3 | "Tell me about a time a number and a neighbour pulled in different directions." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold for Neighbours, Not Numbers: pick a time when a figure said one thing and what you knew of the member or the town said another. It needs what you did, what you said, and to whom. If no such time comes to mind, say so plainly, then give the nearest thing your material carries at its own scope, "I built the monthly complaints spreadsheet our regional manager uses.", or how you would weigh it. The 2027 plan to consolidate eight branches into five hubs makes this value live; do not take a position on the plan itself | F3 is the nearest material; VAL, and the brief's hub plan is why this value is likely to be pressed |
| G4 | "Tell me about a time you found a problem and stayed with it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Own the Fix: pick a time you found the problem, with a named owner (you), what you did, and how you knew it was solved. Use a different story from C1 if you can. If no such time comes to mind, say so plainly, then give the nearest thing your material carries at its own scope, "I handled the branch's formal complaints log and trained new tellers on our escalation script.", or how you would hold a problem to the end | The value's own wording ("whoever finds the problem keeps hold of it") is the bar; VAL, and F1 is the nearest material |
| H1 | "A member's complaint has gone from the branch to the contact centre and back, and they have now written in. You have twenty minutes: what do you do?" | CASE | [inferred] | The real case is not yet known; this is a pattern. Say the structure aloud first. Clarify: what the member asked for, where the complaint is now and who last touched it, how long it has run, any deadline attached, and anything about the member's circumstances. Then the member today: one named person keeps hold and the member hears from them in plain words. Then why it bounced, which is the hand-off, not the people. Then what changes: the value's wording, "whoever finds the problem keeps hold of it until it is solved", suggests an escalation answer should say who keeps hold after it moves, so say that. Then how you would coach the supervisor, and what you would report monthly. Name which value each step serves. Concede that you do not know Ashgrove's actual process and say what you would ask first | The panel scores against the values and the case is 20 of the 60 minutes. Inferred because the reading of Own the Fix is the pack's derivation from the value's wording; CASE because it scores structure on a live problem |
| H2 | "A supervisor sends you every complaint the moment it arrives, even small ones. How do you coach them?" | CASE | [generic] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Structure: find out why they escalate before telling them anything; agree together what a supervisor keeps and what moves up; practise it with a real example; follow up, and keep the complaint with them rather than taking it. Coaching a supervisor is not the same as training new tellers on a script ("I trained new tellers on our escalation script."); say so rather than blurring them. Answer slot: if you have coached peers or supervisors, say how; if not, say so plainly and answer as a plan | The JD's coaching line (F7); CASE because it is a live problem about no past of yours |
| H3 | "Over 2027 Ashgrove is consolidating eight branches into five hubs. What does that mean for how members complain, and what would you watch?" | CO | [grounded] | It is the company's plan; do not take a side on it. Ask first: which towns change, what members used their branch for, and how complaints reach a person today. Then what you would watch: complaints from affected towns, and how long they take to resolve, compared with before, monthly, by branch and by hub. Ask what a quiet town's low complaint count would and would not tell you. Concede that you would not know the plan's detail | The brief's second target and the most plausible pressure point with branch managers; CO, with the monthly reporting line (F3) behind it |
| J1 | "Our supervisors are busy, and you would be coaching them from outside the branch. Where is the seam between you and us, and what happens when we disagree?" | CASE | [generic] | Offer seam principles, not facts: the branch keeps the member relationship and the day-to-day call; the lead owns the standard and the monthly picture. When you disagree, evidence first (real cases and the numbers), then take it to the Head of Member Services together. Say what you bring them: clearer reporting, fewer repeat escalations, a coach and not an inspector. Say you would ask each manager how they want to work | The Peer Evaluator's seam stem against the JD's coaching line; CASE because it is a live collaboration problem, and it presupposes nothing about your past |
| J2 | "Tell me about a time you disagreed with someone at your level about how a complaint should be handled." | VAL | [generic] | Selection criteria: a real disagreement with an equal, what you said, how the disagreement ended, and the working relationship afterwards. It should show spine and tact together. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle one | A Peer Evaluator's collegial form of the Skeptic's probes; VAL because it scores how you behave with equals |

## Values cheat sheet

The panel scores against these four, which you pasted from ashgrovecu.org/about/values on 11 November. None of your sentences yet carries a story for any of them, so each row is a scaffold with the nearest material named.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | G1 scaffold. Nearest material, at its own scope (F1): "I handled the branch's formal complaints log and trained new tellers on our escalation script." |
| Plain Words | If a member needed it explained twice, the writer failed | G2 scaffold. Nearest material, at its own scope (F7): "I handled the branch's formal complaints log and trained new tellers on our escalation script." |
| Neighbours, Not Numbers | Every branch is part of its town | G3 scaffold. Nearest material, at its own scope (F3): "I built the monthly complaints spreadsheet our regional manager uses." |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | G4 scaffold. Nearest material, at its own scope (F1): "I handled the branch's formal complaints log and trained new tellers on our escalation script." |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would help your supervisors most from this role in its first month?" | The reciprocity question for a peer panel: it asks what you can do for them first |
| 2 | "As eight branches become five hubs over 2027, how do you want complaint feedback to reach you and your supervisors?" | Takes the brief's plan seriously without taking a side, and asks for their working need |
| 3 | "How do your supervisors decide today when a complaint should move up and when to keep it?" | Engages directly with the escalation case and tells you what H1 and H2 should address |
| 4 | "Which of the four values is hardest to keep hold of on a busy day in a branch?" | Invites them to be candid about the values they will score you against |
| 5 | "What is one complaint your branch received that you would like never to see again?" | Opens the story they care about most, and signals you would rather hear it than present |

---

## Prohibited claims

Claims this pack will not coach, because the material does not support them, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in a contact centre, or work that amounts to it | Negative you stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." No answer slot beyond whether anything touched contact-centre colleagues, which D1 asks neutrally |
| Has presented to senior leaders, or to any audience above regional level | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." The plan for preparing is a future, never a past |
| Owned the member complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's formal complaints log, not the process end to end. A4 and D2 stay inside the log |
| Reported monthly to leaders on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. Your material says you built the spreadsheet, not what it showed. A5 asks only what it showed and what it was built in |
| Handled regulated complaints | Inflated form of F6 | F6's quote at its own scope. Your material says a formal complaints log, not what made it formal. A4's slot stays with the log |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: "I trained new tellers on our escalation script." Your material says tellers, not supervisors. C3 and H2 stay at that scope |

## Sources

Provided documents: the JD you pasted; the four values you copied on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the three rounds; the 2026 strategy brief Ashgrove published in July 2026, sent by the recruiter; your own background in your message. No dossier was consumed. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet or the G bank: the pasted values text already supplies all four values by name |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email already gives three sessions, who runs each, and what each holds |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO bank: the July 2026 brief already supplies the digital target, the hub plan, the Q1 2027 product and the competitive frame |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No names were given and interviewers beyond their roles have not been assigned, so there was no query to form; the interviewer read is absent and the upgrade menu says what a name unlocks |
| 5. representative `Member Experience Lead` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Your true answers to the answer slots** on F1, F3, F4, F6, F7 and F9 (what the spreadsheet showed and what it was built in, what made the log formal, whether anyone beyond tellers was coached, any digital contact) → those rows move from slots to quoted evidence and A4, A5, C3 and E1 regenerate. Say them outside a drill so they count.
- **One sentence for each real story you can find** for the four values and C1 → G1 to G4 and C1 move from selection scaffolds to story-mapped rows, and the values cheat sheet fills in.
- **A description of the monthly complaints spreadsheet's layout, with member details removed** (what each tab or column shows) → F3 and F4 can rise from medium and low, because a layout is an inspectable artifact for reporting work.
- **The interviewers' roles or names once assigned** → an interviewer read, persona weights per person on the panel, and a reverse question tied to someone's own career path. The recruiter can send these in one email.
- **What the 20-minute case looks like (written or spoken, any material beforehand)** → H1 retuned to the real format; a one-line question for the recruiter.
- **A deeper research pass, offered once** (up to 6 further searches and 2 further fetches, several more minutes): interviewer public footprint once names exist, role-family loop reports, and recent Ashgrove organisation context. Say the word and I will run it.
- **A tuesday-dossier.md from an earlier evaluation of this role** → verified evidence and an underwriter-named top objection in place of the one this pack inferred from the fit snapshot.
