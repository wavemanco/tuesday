I'll read the skill's reference files before building the pack.
Web search was refused for all four research calls, so I'll build the pack from your inputs only and label it that way.
Bash was blocked, so I'll make the same renames with Edit.
Femi, your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-denied-9eb84eb7/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 22 questions across six interviewer styles, a fit snapshot against each JD line, and six reverse questions for Tobias.

- **No company research:** web search was refused on all four attempts, so nothing in the pack is sourced from Saltmarsh. Their values, loop and strategy, and Tobias's public footprint, are all absent. The strategy cases are generic.
- **Assumed round:** I assumed Tobias is your future hiring manager, since you didn't say. That puts the case-style and skeptical interviewers first.
- **Highest-ROI prep:** B1, "I don't see any in-app purchase work in your background. How would you handle that in this role?" Open with "I haven't worked on a game with in-app purchases," hold what your own sentences carry, then give a plan. B2 (never led a team) and B5 (owning the post-event review) come next.
- **Strongest ground:** the weekly content-drop calendar, the release checklist, and the retention numbers you presented.
- **Where the pack stops:** it does not coach you to claim live events across two titles, owning the review's KPIs, managing releases with QA, leading a team, or in-app-purchase experience.

Where your material was silent, the pack gives answer slots rather than invented detail. Examples are which teams you worked with on drops, who prepared the retention numbers, and whether your title was live-service.

I can play the skeptical interviewer on B1 with live follow-ups, then give feedback against that question's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias the person you'd report to, or a skip-level or peer? The answer reweights every bank.
2. Did the recruiter say anything about the format, such as a case, a presentation or a take-home? That would add a build section for it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi. **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Round:** 60 minutes, Friday. **Relationship:** not stated, so this pack assumes a hiring-manager round. If that is wrong, the persona weights in the table below are the part that changes. **Research:** no company research ran (see Sources), so nothing here asserts anything about Saltmarsh beyond what the JD and your message say.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script: where a cell says answer slot, it asks you to say what is true for you, and the second branch is always allowed to be "that wasn't mine" or "that didn't exist".

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows what the company says it values (no values round is detected here, so VAL appears only through standard behavioral stems) |
| EXP | Whether the claims on your background survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none included: no research established anything about Saltmarsh) |
| CASE | A live problem from the role, scored on structure and reasoning |

## Prep triage

The interview is Friday, so this covers Wednesday and Thursday.

1. Rehearse B1 aloud until it is boring. It is the highest-ROI prep in this pack: the objection most likely to be put to you, in some form.
2. Rehearse B2 and B5 next, since they cover the other two stated or visible gaps (leading a team, owning the post-event review).
3. Build a 90-second arc for D1 from the four quoted sentences in the fit snapshot, and nothing beyond them.
4. Run A2 and A3 once each, thinking aloud, so the clarify-then-structure habit is warm.
5. Choose three reverse questions and say them out loud once.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not events and not two titles, with nothing inspected behind it, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on what changes with a second title likely. If you worked on the calendar of any other title, say which and how, in your own words; if you did not, say so plainly and stay with the main title's calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | Your material says you ran the calendar and is silent on whom you worked with on each drop. Answer slot: the JD names design, art, engineering and community, so expect a probe on which of them you worked with on a drop. If you worked with any, say which and what your part was, in your own words; if none, or it was not yours, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the numbers, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on who prepared the numbers, and whether a review of any event came with them, likely. If the numbers were yours to prepare, say how, in your own words; if you presented numbers someone else prepared, or no such review existed, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on what the checklist holds. Lead with the quote's own terms: you wrote it, and your QA team still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | discovery | The years are stated and the pack sets them beside the JD's 3+ as a statement of years only. Whether the title was live-service is not shown. Answer slot: if you would call your studio's title live-service, say why in your own words; if you would not, or you are unsure, say so plainly and stay with the weekly calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: weekly, content drops, your main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but nothing inspected behind it, so expect a probe on how the monthly numbers were put together. Lead with the quote's own terms. What you know about how they were counted is yours to say; where you do not know, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | Your material says you wrote a checklist and does not show who relied on your other writing. Answer slot: the JD asks for clear written communication, so expect a request for an example. If you have written other documents that others relied on, say which, in your own words; if the checklist is the main one, say so plainly and offer to walk through it |
| F9 | Leading a team — not a JD line; the JD's verbs are "Plan and run", "coordinate", "own" and "manage" (the pack's reading of the JD) | "Never led a team" — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I haven't led a team." Then how you would get four disciplines to agree without authority over them, said as a plan and never as a past |
| F10 | [generic] Revenue and in-app-purchase measures — a role-family pattern, not a JD line | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |

No requirement in the JD is a gate: "3+ years" is a length-of-experience line, graded in F5 like any other.

## Persona table

No loop source establishes Saltmarsh's loop, so these weights rest on the hiring-manager prior and a generic loop pattern, not on a documented Saltmarsh process. Treat them as a starting point.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems on a calendar, a release crunch, a metric dip | High (5 questions): the hiring-manager prior favors it, and the JD's own lines (two-title calendar, update coordination, release checklist, post-event review) are all case-shaped | Clarify first, then objective, approach, metrics, risks; think aloud; challenge one premise politely |
| B. Skeptic | Quiet probing of the gaps | High (5 questions): the hiring-manager prior favors it, and your own message states two absences (F9, F10) and the material is thin on F2 and F3 | Rehearse B1 until boring; plain acknowledgment, then a plan; never bluff a competency the interviewer owns |
| C. Data-Driven Prober | Retention and KPI questions taken two levels deep | Medium (3 questions): the JD names retention metrics and KPIs, and you present retention numbers (F3, F7) | Say what you know about how the numbers were counted and say plainly what you do not |
| D. Conversational | The opener and warm-up questions | Medium (3 questions): a 60-minute interview usually starts here, and casual questions are still scored | Pre-script a 90-second arc from your own quoted sentences; treat casual questions about live events as scored |
| E. Pressure | Interruptions, attribution probes | Low (2 questions): nothing in the inputs signals a stress style | Pause, restate, hold through two follow-ups, concede specifically |
| G. Values/Behavioral | Standard behavioral stems | Low (2 questions): no values-style round is detected, because no loop source documents one and the generic pattern does not assume one | Choose instances only from what happened; the honest branch is allowed |

A Peer Evaluator bank is not included because nothing signals a peer round. If Tobias turns out to be a peer, say so and that bank gets added.

## Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're handed the live-events calendar for two mobile titles and the next eight weeks are blank. What do you need to know first, and how do you build it?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify before structuring: each title's goals and audience, fixed dates, which teams are already booked, how earlier events performed. Then objective, how you would sequence two titles against shared teams, risks, how you would report. Think aloud. Your own experience may enter in its own words: you ran a weekly content-drop calendar for your main title for two years. Two titles is wider, so say what you would ask rather than saying you have done it | F1 and F6 are the evidence. The JD's calendar line is the one most likely to be turned into a live problem. CASE because it scores structure, not past |
| A2 | "An event is two days from launch and QA has found a blocking bug. Design wants to ship, and community has already announced the date. Walk me through the next hour." | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Clarify: how severe, who is affected, whether there is a workaround, who makes the call. Lay out options (ship, ship with a mitigation, move the date), what each costs, and what you would tell community and when. Close by saying what goes in the post-event review. You may say you wrote the release checklist your QA team still uses; what a go or no-go rests on is for you to say in your own words | F4 is the evidence. The JD pairs coordination across four teams with the QA checklist, and this is where they collide. CASE with JD content |
| A3 | "An event's retention came in below the one before it. How do you diagnose it?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head" | Clarify which retention, over what cohort, against which comparison. Then segment (new versus returning, platform), list the other things that changed that week, say what you would check first, and name the assumption you would defend least before they do. You may say you presented the monthly retention numbers to the studio head, and then separate what you can say about how they were counted from what you cannot | F3 and F7 are the evidence. The JD's retention line makes a diagnostic case likely. CASE because it scores reasoning |
| A4 | "An event has just closed on one of our titles. What goes into the post-event review, and who needs to read it?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Structure: the goal agreed before the event, what happened against it, what you would change, the next actions and owners, written so a busy reader gets the answer in the first lines. Ask which KPIs the title already tracks, including any revenue measures. If the conversation moves to in-app purchases, the plain line is "I haven't worked on a game with in-app purchases", followed by how you would learn them. Answer slot: the JD asks for clear written communication, so expect a request for an example of your writing. If you have written other documents others relied on, say which; if the checklist is the main one, say so plainly | F3, F8 and F10 are the evidence. JD content because the post-event review is the JD's own line, with CASE delivery |
| A5 | "Two titles, one shared art team and one shared community team. Both want their event in the same week. How do you decide, and who do you talk to?" | CASE | [generic] | Clarify the goals and deadlines of each event, what each team can actually deliver that week, and what the cost of moving either one is. Then propose principles for the decision (goals, dates, team capacity) rather than a verdict, name who you would talk to first, and say how you would record the decision so the same clash is easier next time. The question needs no claim about your past, so the guidance makes none | F1 and F2 are the requirements it tests. CASE because the JD's two-title and four-team lines sit on exactly this seam |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see any in-app purchase work in your background. How would you handle that in this role?" | JD | [grounded] "never worked on a game with in-app purchases" | **Highest-ROI prep in this pack.** Hold-then-concede. Open with the plain line: "I haven't worked on a game with in-app purchases." Then hold only what your own sentences carry: you ran a weekly content-drop calendar for your main title for two years, and you presented the monthly retention numbers to the studio head. Then a plan, said as a plan: what you would ask for in the first weeks (the existing reports, which numbers the team treats as the ones that matter) and who you would learn it from. Follow-up levels to rehearse: first, "retention isn't revenue, so why should we think your numbers work carries over?" — return to what you did and did not do, never to what it proves; second, "so what is week one?" — the plan; third, "what if you're wrong about how much you need to learn?" — say what you would check and when you would tell Tobias. Do not describe spend metrics you have not worked with | F10 is the likeliest place to be probed, and the objection is aimed exactly where the material is thin. JD because it scores a stated gap against the role |
| B2 | "I don't see team leadership in your background, and this role coordinates design, art, engineering and community on each update. How would that work for you?" | JD | [grounded] "Never led a team" and "I ran the weekly content-drop calendar for our main title for the last two years" | Plain line first: "I haven't led a team." Then the JD's own verb: the role coordinates. Answer slot: if you worked with any of the four teams on a drop, say which and what your part was, in your own words; if none, or it was not yours, say so plainly and stay with the calendar you ran. Then how you would get agreement without authority, as a method: what each team needs from the calendar, who decides what, where disagreements go. Hold through two follow-ups by returning to the calendar, never by adding to it | F2 and F9 are the evidence. The JD's coordination line meets your stated absence, which makes this the second most likely objection. JD because it scores a stated requirement |
| B3 | "Why this role, and why now?" | JD | [generic] | A selection scaffold, not a story. Pick two lines in the JD you actually want to do, and quote them. Then one thing from your own work that you actually enjoyed, in your own words. Anything about Saltmarsh itself comes only from what you have verified; this pack has no research on it. If a clear reason does not come to mind, say so plainly and give the nearest true thing | Motivation consistency is the Skeptic's core test. JD because the answer is anchored in the posting; no claim about the candidate's past is asserted |
| B4 | "You ran the calendar for your studio's main title. This role covers two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold on the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Concede that two titles is wider and say what changes in your own method (how you would see both calendars at once, how clashes get raised). Answer slot: if you worked on the calendar of any other title, say which and how; if you did not, say so plainly and stay with the main title | F1 and F6 are the evidence; F5 sits behind it. JD because it scores the two-title requirement |
| B5 | "This role owns the post-event review and its KPIs. What part of that have you owned yourself?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Hold: "I presented the monthly retention numbers to the studio head." Answer slot: if the numbers were yours to prepare, say how, in your own words; if someone else prepared them, or no event review existed, say so plainly and stay with presenting them. Concede what you do not know, and say what you would put in a review first. Hold through two follow-ups by returning to the sentence | F3 is the evidence and a place where the material is thin. JD because it scores the own-the-review requirement |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention numbers did you present to the studio head each month, and what were they showing?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say which numbers and what they showed, in your own words and only what you remember. The probe goes two levels down on these four, each asked in your own words: how the figure was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. Where you do not know, say so plainly | F7 is the evidence. EXP because it tests what was actually yours |
| C2 | "How would you tell whether a live event moved retention, rather than it just being a busy week?" | JD | [generic] | A method, said as a method: a comparison you would trust, what else changed that week, which players you would look at separately, how long you would wait before calling it. Name your weakest assumption aloud. The question needs no claim about your past, so the guidance makes none | The JD's retention line, taken to its assumptions. JD with CASE delivery |
| C3 | "How did you know whether a weekly drop had worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: the JD's post-event line makes a probe on how results were checked likely. If you looked at drop-level results, say what, in your own words; if you did not, say so plainly, and say what you would look at first | F6 and F3 are the requirements. EXP because the premise is that you ran the calendar, and the probe is on what it showed |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc with exactly these beats, in your own words: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title, the last two years; the release checklist QA still uses; the monthly retention numbers to the studio head. Close on one or two JD lines you actually want. Nothing between the beats beyond what you remember | F5 is the evidence. EXP because it tests whether the story hangs together and sounds like you |
| D2 | "What are you playing on mobile right now, and what do you make of how its live events work?" | JD | [generic] | Pick a game you actually play and say one specific thing you noticed about its events. If you do not play live-service mobile games, say so plainly and name one you looked at while preparing. Do not guess at Saltmarsh's own games | Casual questions about hot JD topics are scored. JD because it tests live-events awareness; no claim about the candidate's past |
| D3 | "Tell me about the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Say you wrote it and your QA team still uses it. Answer slot: if you can say what is on it and how a release uses it, say so in your own words; if you do not remember the detail, or others shaped it, say so plainly. Never describe a section you do not remember | F4 and F8 are the evidence. EXP because it tests what was actually yours, and it is the nearest thing to the JD's QA line |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Pause, restate, then hold: "I wrote the release checklist our QA team still uses." Answer slot: if QA or others added to it, say so; if you drafted it alone, say so. Concede specifically if you are unsure of a detail. Hold through two follow-ups, and never fold on the core sentence just to restore harmony | F4 is the evidence. EXP because attribution is what is scored; the pressure delivery tests composure |
| E2 | "Sixty seconds: why should we hire you for this role?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | Three beats, one sentence each, from the quotes: the weekly calendar, the checklist, the retention numbers. Then concede in one line: "I haven't worked on a game with in-app purchases, and I haven't led a team." Then one line on how you would ramp. Pause before starting | F6, F4, F7, F9 and F10 are the rows it draws on. JD because it scores fit to the role, with pressure delivery |

### G. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold. Pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. Your material has a setting for it (you presented the monthly retention numbers to the studio head) but no event, so the pack supplies none. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem; no values round is detected, so VAL here is generic practice. F7 is the setting |
| G2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Pick a time with a named choice, what it cost, and what you did about the metric. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Supply no event you cannot stand behind | A standard behavioral stem for a live-ops role. VAL; no claim about the past is asserted |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A5, B4 |
| "coordinate design, art, engineering and community teams on each update" | A2, A5, B2 |
| "own the post-event review and the KPIs it reports" | A3, A4, B5, C1, C2, C3 |
| "manage the release checklist with QA" | A2, D3, E1 |
| "3+ years producing live-service games or apps" | B4, D1, E2 |
| "experience running a content calendar" | A1, B4, C3 |
| "comfortable with player-retention metrics" | A3, C1, C2 |
| "clear written communication" | A4, D3 |

## Reverse questions

No interviewer profile exists, so none of these is tied to Tobias's own path. None is a peer-reciprocity question, since the round is assumed to be hiring-manager.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first event look like for someone in this role on each title?" | It shows you think in outcomes and gives you the success criteria in the interviewer's words |
| R2 | "How are the two titles' calendars coordinated today, and where do they collide?" | It goes straight at the two-title requirement (F1) and tells you where the real difficulty is |
| R3 | "Which KPIs does the post-event review report today, and who reads it?" | It uses the JD's own line and shows whether revenue measures are in scope without claiming anything about them |
| R4 | "What does the release checklist with QA look like today, and what would you change about it?" | It invites a conversation about the thing you wrote (F4) |
| R5 | "What tends to be hardest about getting design, art, engineering and community aligned on an update?" | It shows you expect friction and gives you the seam to ask about in the next round |
| R6 | "Where would you want someone new to be strongest in the first 90 days, and where would they get support to learn what they haven't done before?" | It is candor with a plan attached, and it lets the monetization gap (F10) be discussed on your terms |

## Prohibited claims

Not coached: wording that outruns your own sentences, and claims you stated are not true.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title. B4's slot stays inside that |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. B5's slot asks only who prepared the numbers you presented |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist your QA team still uses |
| Led or managed a team | Negative you stated, F9 | The plain acknowledgment: "I haven't led a team." No slot |
| Has in-app-purchase or monetization experience | Negative you stated, F10 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot; only a plan |

## Sources

Provided: the JD text you pasted; your background, as stated in your message. No dossier, no assessment, no ID.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Every search sent was refused, so no result came back from any of them: "Saltmarsh Games values" (refused); "Saltmarsh Games interview process live operations producer" (refused); "Saltmarsh Games mobile studio strategy news" (refused); "Tobias Wrenfield Saltmarsh Games Head of Live Operations" (refused).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | A values cheat sheet, if a values round is documented; the call was refused |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Loop structure and persona weights; the call was refused, so the weights rest on the hiring-manager prior and a generic pattern |
| 3. `Saltmarsh Games mobile studio strategy news` | unavailable | CO questions and strategy-grounded cases; the call was refused, so the cases are generic |
| 4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` | unavailable | An interviewer read and a reverse question tied to his path; the call was refused, so the interviewer read is absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, or pasted text of Saltmarsh's values, careers or press pages → a values cheat sheet if a values round is documented, strategy-grounded CO and CASE questions, and a documented loop in place of the generic pattern. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and the interviewer's talks
- Tobias's public footprint, or anything he has said or written about live operations → an interviewer read, persona weights adjusted to him, and a reverse question tied to his own path
- The recruiter's note on format (a case, an exercise, a presentation) → graded-deliverable sections and sharper persona weights
- Confirmation that Tobias is your future manager, or a different relationship → persona weights recomputed
- Your answers to the slots in F1, F2, F3, F5 and F8 (other titles, which teams you worked with, who prepared the numbers, whether the title was live-service, other writing others relied on) → those rows move from discovery to grounded and the matching guidance becomes story-mapped
- A redacted copy of the release checklist, a content-calendar export, or a monthly retention deck → F4, F6 and F7 can rise from medium toward high
- A tuesday-dossier.md from a prior opportunity-evaluation pass → verified evidence and a named top objection in place of the inferred one
