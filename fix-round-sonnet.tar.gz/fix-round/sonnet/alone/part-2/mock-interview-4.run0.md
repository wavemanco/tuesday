I'll read the reference files the skill points to before writing anything.
The pack is saved, and I'm writing up the hand-off message now.

Your prep pack is saved as `Quartzline_product-manager-platform-apis_interview_pack.md`, next to your other files. I built it for a 45-minute hiring-manager conversation on Thursday, as you described. Your dossier supplied the requirements and your confirmed evidence, so I asked you for nothing.

- **No company research:** The three web searches I tried (values, interview process, strategy) were all refused, so the pack has no Quartzline values, loop or strategy. I left out the values cheat sheet and company-knowledge questions rather than fill them from memory. The upgrade menu says what a rerun with search access would add.
- **Highest-ROI prep:** A1 is the objection the dossier named: no PM title, no roadmap. It is built as concede first, hold only what your three confirmed quotes carry, then a ramp plan.
- **Roadmap gap:** A2 coaches a plain acknowledgment plus a ramp plan and no bridge, since the dossier found nothing to bridge it with.
- **R2, R3 and R4:** The dossier gave no strategy for these, so I derived those rows myself and labeled them `[inferred]`. Each carries an answer slot you can answer either way from your own experience.

I can play the Skeptic on A1 whenever you want to rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Round:** one 45-minute conversation with the hiring manager, on Thursday (your words). Interviewer name not given.
- **Built on:** your `tuesday-dossier.md` (v1.1, dated 2026-08-14) plus your message. No company research could be run (see Sources).
- **Highest-ROI prep in this pack:** A1. The dossier's author named that objection from evidence you confirmed, so it is theirs and not an inference of this pack.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether a claim on your record survives scrutiny and attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

- **Quotes.** V1, V2 and V3 are the first, second and third entries of the dossier's `verified_candidate_evidence`, quoted exactly. Every sentence about your past in this pack rests on one of them.
- **Answer slot.** An instruction addressed to your answer in the room, not a question for me. It names a probe the role's wording makes likely and gives two honest branches: you did it and say how, or you did not, or it was not yours, and you say so plainly and return to what the quotes carry. Either branch is a good answer.
- **Fit-row IDs.** F1 to F9 refer to the fit snapshot below.

## Fit snapshot

Requirement text is quoted from the dossier's `role_profile`, which stands as the posting's lines.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [grounded] | transferability | The dossier's strategy is `bridge`, and the condition is that it is positioned as adjacent and never as product management. Your material shows integration leadership, not a product management role, and the words stay at that scope, in your own words. The limit is the pack's observation: the three years are not in your material. The plain acknowledgment "I haven't held a product manager title or role" is sourced to the dossier's `prohibited_claims` field. A1 rehearses it |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities, with R1 sub-claim "Owning a roadmap and prioritization authority (R1 sub-claim)" | none given | none | [grounded] | capability | The dossier records this as `acknowledge_gap`, and the underwriter found no adjacent evidence, so no bridge is coached. The words are sourced to the `acknowledge_gap` area and the `prohibited_claims` field: "I haven't owned a product roadmap" and "I haven't set prioritization for an engineering squad". Then a ramp plan, said as a plan and never as a past: what you would learn first about which decisions sit with the PM and which with the squad leads. No answer slot |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] | transferability | The dossier gives no strategy for R2, so the gap type is this pack's own reading: client integrations of the vendor's APIs sit next to the requirement and do not reach it. The words are V1 at its own scope. Answer slot: the requirement's wording makes a probe on which product you shipped likely. Which of the integrations you led sits closest, and which part of it was yours; if none sits close, say so plainly and stay with the integrations as you led them |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Wrote the internal integration playbook her team uses" — dossier V2 | medium | [inferred] | discovery | The dossier gives no strategy for R3. V1 says architecture on REST API integrations and V2 says a playbook; neither says whether API docs or schemas were part of it. Answer slot: the requirement's wording makes a probe on docs and schemas likely. If you worked with API docs or schemas in those integrations, say which and what you did with them, in your own words; if you did not, say so plainly and stay with the architecture and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [inferred] | discovery | The dossier gives no strategy for R4. The quotes show clients and product; neither names engineering or sales. V3 is confirmed with limited inspectable proof, so expect a probe on it and volunteer what you can show and what you can only describe. Answer slot: which of engineering, sales and customers you worked with directly, and what part was yours; if one of them was not a group you worked with, say so plainly and stay with what the quotes carry |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy is `clarify`, and no confirmed entry speaks to agile delivery itself, so nothing about your past goes in the answer. Answer slot: the requirement's wording is the interviewer's probe. If you have worked in an agile delivery model, say how it ran and what part was yours, in your own words; if you have never worked that way, say so plainly, and say what you would want to confirm about how this team defines it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [inferred] | discovery | V3 shows sessions that carried client evidence to product; it does not show whether they were discovery conversations with integration partners. Confirmed, limited inspectable proof: volunteer the limit before it is extracted. Answer slot: say what the sessions gathered and from whom, in your own words; if they were not conversations with partners, or you did not run them that way, say so plainly and stay with what the quote says |
| F8 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Your material does not show this either way, and silence is not an absence. Answer slot: if you defined or tracked any measure of how clients used the APIs, say what was counted, in your own words; if you did not, say so plainly, and say what you would want to know first about how adoption is measured here, which the role leaves open |
| F9 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] | discovery | V1 lists requirements and go-live on client integrations; it does not show specs or work with engineering squads. Answer slot: if you wrote requirements that engineers built from, say what they were and who built from them; if none were, or the engineers worked from someone else's, say so plainly and stay with the integrations as V1 states them |

No requirement in the dossier is a gate: `hard_gates` is empty and none is a term such as authorization or location.

## Persona table

The loop is one 45-minute conversation with the hiring manager, from your words, so no archetype fallback applies. Weights start from the hiring-manager prior and are adjusted by the dossier. No interviewer profile exists to adjust further.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the title and roadmap gap | High. The hiring-manager prior is Case plus Skeptic, and the dossier names one objection and three weak areas | Rehearse A1 until it is boring. Concede first, then hold at the quotes' scope, and name the limit before it is asked for |
| B. Case / Strategist | Live problems from the role: adoption, two squads, discovery, a partner outage | High. The hiring-manager prior, and each responsibility in the role is a ready-made problem | Clarify, then objective, segmentation, approach, metrics, risks. Where the role leaves a fact open, ask it first |
| C. Conversational | The opening journey question and casual questions about APIs | Medium. A 45-minute conversation usually opens this way, and casual questions are still scored | A 90-second arc built only from your quotes, positioned as adjacent to product work |
| D. Data-Driven Prober | Reads the record line by line: the number, the playbook, the sessions | Medium. Three confirmed claims exist, one with a figure and one flagged medium confidence | Know what you can and cannot say about how the figure was counted, and volunteer limits |
| E. Pressure | Time-boxed challenges, attribution and authority | Low. No signal for it, and A1 may arrive in this register | Pause, restate, hold through two follow-ups, concede specifically |

Not banked: Peer Evaluator, because the round is with the hiring manager and not a peer; Values/Behavioral, because no values-style round is detected. Your words establish a single hiring-manager conversation, and no source documenting a values round was read.

## Question banks

### A. Skeptic (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | The deepest rehearsal here, and the underwriter's own wording of the objection. Move 1, concede first and plainly, before they press: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Both are sourced to the dossier's `prohibited_claims` and `acknowledge_gap` fields. Move 2, hold only what the quotes carry: you led 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live, and you wrote the internal integration playbook your team uses. Position it as adjacent to product work, in your own words, never as product management. Move 3, name the limit yourself: the playbook can be inspected, so offer to walk through it. Move 4, a ramp plan said as a plan: what you would learn first, namely which roadmap decisions sit with the PM and which with the squad leads, and how adoption is measured today. Follow-up 1, "That is delivery, not product tradeoffs — where did you make a tradeoff?": hold at the integrations, and concede "I haven't set prioritization for an engineering squad" (`prohibited_claims`). Follow-up 2, "So you are asking us to take a risk": agree specifically that roadmap ownership is new for you, then restate the hold and the plan. Never fold on the core claim to restore harmony | F1 and F2 together are the biggest gap, so this question arrives in some form. JD because it scores the stated requirement, with Pressure delivery possible |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] `acknowledge_gap`: "Owning a roadmap and prioritization authority (R1 sub-claim)" | The dossier's strategy here is `acknowledge_gap`, so no bridge. Name it plainly: "I haven't owned a product roadmap." Then the ramp plan in your own words: the first two things you would learn, taken from what the role leaves open, which are where decision rights sit between the PM and the squad leads, and how partner adoption is measured today. Say what you would not decide alone until you knew | F2 is a capability gap the underwriter found nothing to bridge. JD because it asks for honest self-assessment against the listed role |
| A3 | "Where in your background does shipping an API or platform product sit closest?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote states, at its own scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live. Answer slot: which of those integrations sits closest to the API or platform work this role owns, and which part of it was yours; if none sits close, or the part was not yours, say so plainly and return to the integrations as you led them. Do not let the answer grow past the quote | F3 is a must-have with only adjacent evidence and no underwriter strategy, so it is probed. JD because it scores a stated must-have |
| A4 | "How have you worked in an agile delivery model inside a product team?" | JD | [grounded] | Makes no claim about your past. Answer slot: the requirement's own wording, "Agile delivery experience", is the probe. If you have worked in an agile delivery model, say how it ran and what part was yours, in your own words; if you have never worked that way, say so plainly, and say what you would want to confirm about how this team defines it, for instance which delivery rhythm the two squads run | F6 is a `clarify` area: the evidence may exist and was not established. JD because it scores a preferred requirement |
| A5 | "Why move into product management, and why this platform?" | JD | [generic] | A selection scaffold, with no claim about your past. Choose one real reason you can say in a sentence and that your later answers would support; say what you want to do and not what you are leaving. Tie it to the role's own responsibilities, partner discovery, adoption, the roadmap, only where that is true for you. If no single reason comes to mind, say so plainly, then give the nearest thing your material carries, or how you would decide | The motivation probe is the standard second step after a background mismatch, and F1 is that mismatch. JD because it tests fit with the role |

### B. Case / Strategist (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner adoption of one of our APIs has been flat for two quarters. How would you diagnose it?" | CASE | [generic] | Clarify first: what counts as adoption here, and what the baseline is, which the role leaves open. Then objective, segmentation (partner types, stage reached), approach, metrics, risks. Challenge one premise respectfully, for instance whether flat is the problem. Think aloud. Claims no past | Live version of the adoption-metrics responsibility (F8). CASE because it scores structure, not a record |
| B2 | "Two squads want opposite things from the same API change this quarter. How do you decide, and who decides?" | CASE | [generic] | Ask who holds the decision and what the tie-break path is, since decision authority against the squad leads is an open item in the role. Then give criteria and not a pick: partner impact, cost, reversibility. Propose seam principles and say what you would escalate with a recommendation. Claims no authority and no past | Tests the unresolved authority question without asserting any (F2). CASE because it is a live problem |
| B3 | "Sketch how you would run discovery with integration partners in your first sixty days." | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure: which partners first and why, what you need to learn, how you would pull it together, what decision it feeds. If you draw on your own work, stay with V3's scope: quarterly sessions that fed client evidence to product. It is confirmed with limited inspectable proof, so volunteer what you can show and what you can only describe | F7 is the evidence for the discovery responsibility and the likeliest place to be probed. CASE delivery, JD content |
| B4 | "A partner tells you a schema change broke their integration. Walk me through the first hour and what changes afterwards." | CASE | [generic] | Contain: what changed, who is affected. Communicate. Decide fix or roll back with engineering. Afterwards: how the change was announced, versioning, the docs. Uses the docs and schemas vocabulary the role names. Claims no past | Covers the technical-fluency requirement (F4) as a decision and not a recital. CASE because it is a live problem |
| B5 | "This role writes specs and drives delivery with two engineering squads. What have you done that sits closest to that?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote states: client integrations led from scoping and requirements to UAT and go-live. Answer slot: if you wrote requirements that engineers built from, say what they were and who built from them; if none were, or the engineers worked from someone else's, say so plainly and stay with the integrations as the quote states them | F9 is the responsibility with the thinnest evidence. JD because it scores a stated responsibility, in a case-style delivery |

### C. Conversational (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc, in your own words, in this order: you led 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live; you wrote the internal integration playbook your team uses; you ran quarterly roadmap-input sessions that fed client evidence to product. The last beat is confirmed with limited inspectable proof: say what you can show and what you can only describe. Position the whole arc as adjacent to product work. Finish with your A5 answer | The opening question is asked of every candidate, and this arc sets the frame for F1. EXP because it is your record, told in order |
| C2 | "What makes an API easy or painful for a partner to adopt?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Lead with a principle, then draw on the integrations you led, at the quote's scope. Answer slot: the requirement's wording "API docs, schemas" makes a probe likely. If you worked with docs or schemas in those integrations, say which and what you did with them; if you did not, say so plainly and stay with the architecture and the playbook | Casual questions on the requirement's topic are scored, and F4 is where the material is silent. JD because it scores a stated requirement |
| C3 | "Tell me about a time you had to keep engineering, sales and a customer moving in the same direction." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | A selection scaffold. No quoted sentence carries engineering and sales, so choose an instance you can tell end to end: it needs a named stake, what each group wanted, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the client integrations you led, at the quote's scope, or how you would handle it | F5 is the stakeholder requirement and the quotes carry only part of it. JD because the stem is the requirement's own list |

### D. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 30-plus was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure counts integrations, and the number stays on that noun. Answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If there is a part you cannot vouch for, say so plainly. Do not offer a counting method you could not repeat under a second question | The one figure in the confirmed record is where probers go first (F1, F3). EXP because it tests attribution |
| D2 | "What is in the integration playbook, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Beats the quote states: you wrote it, it is internal, your team uses it. The playbook can be inspected, so be ready to walk through it. Answer slot: if others contributed to it, say what part was yours; if it was entirely yours, say so | The playbook is the best-evidenced claim and so the safest ground to be specific on (F4). EXP because it checks what was yours |
| D3 | "Walk me through how the roadmap-input sessions worked." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Beats the quote states: you ran them, quarterly, feeding client evidence to product. Confirmed with limited inspectable proof, so say what you can show and what you can only describe before they ask. Answer slot: which part of the sessions was yours to run, and what you know of what came of the evidence afterwards; if you do not know, or nothing did, say so plainly and stay with what the sessions fed to product | The medium-confidence claim is the one a prober finds a seam in (F5, F7). EXP because it tests what was actually yours |

### E. Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Of those 30-plus integrations, how much was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the verb and scope the quote carries: you led them, from scoping to go-live. Hold through two follow-ups, such as "Who did the architecture?" Concede specifically through the slot: which parts or phases others carried; if others carried some, say which plainly. Concede that, never the core claim | The standard attribution probe on the headline claim (F1). EXP because it tests attribution under pressure |
| E2 | "Sixty seconds: two squad leads disagree with your call. Why does yours stand?" | JD | [generic] | Pause and restate. Your position: the first thing you would want to know is where the decision sits. Hold that through two follow-ups. Concede specifically: if the decision is not yours, you take a recommendation and the evidence to whoever owns it. Claims no authority and no past | Decision authority against the squad leads is unresolved in the role, so this tests composure on exactly that (F2). JD because it scores the stated responsibility |

### Requirement coverage

| Requirement or responsibility | Questions | Note |
|---|---|---|
| R1 3+ years product management experience | A1, A5, C1, E1 | |
| R1 sub-claim: roadmap and prioritization authority; "Own the roadmap" | A1, A2, B2, E2 | |
| R2 Shipped API or platform products | A3 | |
| R3 Technical fluency: API docs, schemas | B4, C2, D2 | |
| R4 Stakeholder management across engineering, sales, customers | C3, B2, D3 | |
| R5 Agile delivery experience | A4 | |
| Run discovery with integration partners | B3, D3 | |
| Write specs and drive delivery with two engineering squads | B5 | |
| Define and track adoption metrics | B1 | |
| Company and strategy (CO) | — none, and why | No company research ran, so a CO question would be `[generic]` and unsupported |
| Published values (VAL) | — none, and why | No values-style round is detected and no values page was read |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's risk register has decision authority against the squad leads as asserted and not evidenced. The answer is what you would be accepting, and it lets the hiring manager answer A2 on their own terms |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a named responsibility with no baseline stated. The answer tells you what you would be judged on, and it is the fact B1 asks you to clarify first |
| 3 | "Which parts of this role do you expect someone coming from integration delivery, and not from a PM track, to need to learn first?" | It turns the A1 objection into a shared plan and gives you the content of your ramp plan from the person who will judge it |
| 4 | "How does discovery with integration partners work today, and who holds those relationships?" | Discovery is a stated responsibility (F7). The answer tells you whether you would inherit relationships or build them |
| 5 | "What would you want to see from me in the first ninety days to feel this hire was the right call?" | It asks the hiring manager to define success in their own terms, and it invites them to say what they would need beyond the title |

## Prohibited claims

Built from the dossier's `prohibited_claims` and from the fit snapshot. No guidance cell, slot or reverse question asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims`; limit on F1 | V1 at its own scope, positioned as adjacent. The plain acknowledgment, sourced to the `prohibited_claims` field: "I haven't held a product manager title or role." |
| Having owned a product roadmap | Dossier `prohibited_claims` and the `acknowledge_gap` area on F2 | The plain acknowledgment, sourced to those fields: "I haven't owned a product roadmap." Then a ramp plan. No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | The plain acknowledgment, sourced to that field: "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | Inflated form of F3 | V1 at its own scope. The limit is the pack's observation: your material says client integrations of the vendor's REST APIs, not an API or platform product. A3's slot stays inside the integrations |

## Sources

- **Provided:** `tuesday-dossier.md`, version 1.1, dated 2026-08-14. It supplied `role_profile` (the requirement and responsibility lines), `handoff_to_mock_interview` (verified evidence V1 to V3, weak areas with their allowed strategies, the named objection, risks, employer questions, prohibited claims) and `decision` (context only). It carries no `evidence_map`, `evidence_state` or `risk_register`, so rows F3, F4, F5, F7 and F9 are graded by this pack and labeled `[inferred]`. Your message supplied the round type and day.
- **Searches sent:** "Quartzline company values", "Quartzline interview process product manager" and "Quartzline partner API platform strategy news". All three were refused, so they returned nothing. No pages were fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Search refused. It would have moved a values cheat sheet and VAL questions. The pack has neither |
| 2. Quartzline interview process, product manager | unavailable | Search refused. It would have moved persona weights beyond your own description of the round. Weights rest on that description and the hiring-manager prior |
| 3. Quartzline strategy and recent news | unavailable | Search refused. It would have moved a CO question and the grounding brief. The pack has none |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative product manager JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access for this session, then a rerun → Quartzline's published values, documented interview loop and current strategy: a values cheat sheet if a values round turns up, a CO question, and persona weights read from the loop. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and recent org context
- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep email → any pre-declared focus areas or deliverable, which gets its own build section
- Your answers to the answer slots in F3, F4, F5, F6, F7, F8 and F9 → those rows become story-mapped and `[grounded]`, and the matching bank guidance is regenerated
- An agenda, notes or deck from the quarterly roadmap-input sessions → the V3 evidence moves from medium toward high, and D3 and B3 get firmer ground
- A dossier update grading R2, R3 and R4 with strategies → rows F3, F4 and F5 move from this pack's derivation to the underwriter's grading
