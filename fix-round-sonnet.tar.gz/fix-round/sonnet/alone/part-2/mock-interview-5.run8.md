Search was refused, so I'm building the pack from your message alone. Writing the file now.
Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md`. Two things limited it:

- **The market report didn't arrive.** It wasn't in my working directory or your message, so nothing in the pack comes from it. The POV build tells you to bring one point from it, argue one thesis of your own, and name one thing you'd say no to. The report's content is yours to fill in.
- **Search was refused.** All five searches were denied and I didn't retry. Nothing about Kelverton comes from research, only from you and the recruiter's email as you quoted it. The pack has no interviewer read, no values section and no JD-based rows.

I built it for a panel of two: Deepa leaning Strategist and Skeptic, Ross leaning commercial Prober and Pressure.

Your highest-ROI prep is B1: "You've never carried a direct quota. Why would we trust you with a number here?" Ross will push on commercials, and you've stated that gap yourself. B1 starts with a plain acknowledgment of the quota gap, then the "roughly £4M of influenced revenue" figure held at that wording. C1 covers how that figure was counted and which part was yours. If you don't know how it was counted, the pack says to say so.

The triage section sets out the four hours in order, starting with 90 minutes on the POV.

Say the word and I'll play Ross on B1 with live follow-ups, or Deepa on the POV.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the JD text, or a CV, or both? The requirement rows currently rest only on the recruiter's words and your message, and either would let me quote the posting directly.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday. Panel of two, 60 minutes: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: you talk through a POV on where you would take operator partnerships over the next 18 months, no slides, landing on what it means for the operators. Rest is Q&A, and Ross will push on commercials.

**Built from:** your message only. No JD, no CV file, no market report text, no research (every search was refused, see Sources). Everything about you below is quoted from your message; everything about Kelverton is what you or the recruiter said.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Past behaviour against the company's published values (no bank here: no values-style round is detected) |
| EXP | Whether your CV claims survive scrutiny; what was actually you |
| JD | Stated responsibilities and requirements, including your gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, reasoned aloud |

Sections left out, and why: interviewer read (only first names and titles are known), grounding brief (no report text or research in hand), values cheat sheet (no values-style round detected), delivery coaching (no assessment given).

## Prep triage (about four hours)

| Order | Time | Do | Tied to |
|---|---|---|---|
| 1 | 90 min | Build the POV: pick one consensus item, one thesis, one anti-pick, then say it aloud three times against a timer. Aim for 12 to 13 minutes so follow-ups have room. Re-read the report once with that single job | Graded deliverable below; A1, A3, A4 |
| 2 | 60 min | The commercial objection: write your slot answers to B1, C1 and C3 in your own words, then say them aloud | B1 (highest-ROI), C1, C3 |
| 3 | 30 min | Plain acknowledgments, then D1 and D2 as 60-second answers | F4, F5, D1, D2 |
| 4 | 30 min | Think-aloud structure on live problems | A2, A5, D3 |
| 5 | 30 min | Your 90-second journey and the reverse questions | E1, Reverse questions |

Everything else is insurance.

## Fit snapshot

Requirements come from the recruiter's email as you quoted it, or from your own description of Kelverton. There is no JD, so F6's requirement is a role-family pattern, written as plain prose.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, as you quoted it | "running the ISV channel" — your message | medium | [grounded] | transferability | Your material says you ran an ISV channel, with nothing inspected behind it, and says nothing about which of its decisions were yours. The words stay at "running the ISV channel". Answer slot: the recruiter's ask makes a probe on how the channel ran likely. If any part of it was yours to decide, say which part and how you decided, in your own words; if it was set by others, or there was no such decision, say so plainly and stay with running the channel |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email, as you quoted it | "bus and light rail network planning, so I know the operator world from the other side" — your message | medium | [grounded] | discovery | The quote says bus and light rail network planning; it does not show which operators' work it was or what they said they needed. Answer slot: if any of that work showed you what an operator needed from a supplier or partner, say what, in your own words; if it did not, or it was not rail, say so plainly and stay with the network planning you did |
| F3 | "Ross will push on commercials" — recruiter's email, as you quoted it | "roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | A figure with nothing inspected behind it, carrying "roughly" and "influenced"; the words stay exactly there. Answer slots, the four a figure raises: how it was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly |
| F4 | "Ross will push on commercials" — recruiter's email, as you quoted it | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota." Then how you would approach carrying a number, said as a plan and never as a past. Never a claim to quota, bookings or closed revenue |
| F5 | "they sell scheduling software to train operating companies" — your message | "Never sold into rail specifically" — your message | none | [grounded] | capability | You have said it. Words: "I haven't sold into rail specifically." Then who you would learn from and in what order, said as a plan. This is experience, not a gate |
| F6 | Build and scale a partner programme (role-family pattern, no source supplied) | "took it from 6 partners to 40" — your message | medium | [generic] | none | The quote already reaches the requirement in role terms, with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you took it from 6 partners to 40. Answer slots for the figure: what counted as a partner, what the count is sensitive to, the assumption you would defend least, and which part was yours |

## Graded deliverable: the 15-minute POV

Facts to build on:

| Fact | Source | Provenance |
|---|---|---|
| 15 minutes, no slides, "just talk us through it" | Recruiter's email, as you quoted it | [grounded] |
| Topic: "where you'd take our operator partnerships over the next 18 months" | Recruiter's email, as you quoted it | [grounded] |
| Required close: "Please land on what it means for the operators themselves" | Recruiter's email, as you quoted it | [grounded] |
| Ross "will push on commercials" | Recruiter's email, as you quoted it | [grounded] |
| A market report from Kelverton's strategy team, which you have read; this pack has not seen its text | Your message | [grounded] |

Three theses to choose from, each with its mandatory concession. Pick one, and treat all three as positions to test with operators, not findings.

| # | Thesis you could argue | What it means for operators | Mandatory concession | Draws on | Provenance |
|---|---|---|---|---|---|
| T1 | Treat operators as members of a small partner programme, not only as customers: a few structured joint efforts they opt into | A defined joint outcome they can see and choose, with a named counterpart at Kelverton | You ran an ISV channel and have not sold into rail, so this is a hypothesis to test with operators, not a playbook that carried over | F6 "took it from 6 partners to 40"; F5 "Never sold into rail specifically" | [generic] |
| T2 | Define each partnership by one outcome the operator can see and would measure itself, and let Kelverton's commercial case follow from it | The partnership is judged on the operator's own measure | Attribution gets harder: your own figure is influenced revenue, not direct, so Ross will ask how the commercial case is counted. Say you would agree the counting before committing to a number | F2 "bus and light rail network planning, so I know the operator world from the other side"; F4 "never carried a direct quota, only influenced revenue" | [generic] |
| T3 | Go deep with a few operators before widening | More joint attention for fewer operators | Slower reach, and it runs against the breadth your own record shows. Present it as a different bet, not as a lesson you learned, because your material does not say you learned it | F6 "took it from 6 partners to 40" | [generic] |

Differentiating from the report, which the interviewers' own strategy team wrote:

| Move | What to do | Why | Provenance |
|---|---|---|---|
| Consensus item | Bring exactly one point from the report you agree with, in your words, to show you did the reading | A shortlist anyone prepared can assemble scores as homework; one item is enough to prove it | [generic] |
| Divergence | Argue one thesis from T1 to T3 and say where and why it departs from the report | Departing with reasons is the judgment signal | [generic] |
| Anti-pick | Name one thing you would decline in the first year, with its cost. If you pick refusing a partner-count target, expect B3 and C2 follow-ups, since your own figure is a partner count | A senior role includes saying no; a real anti-pick is rehearsed against the follow-up it invites | [generic] |

Draft running order (scaffolding, about 12 to 13 minutes):

| Minutes | Beat | Notes |
|---|---|---|
| 0:00 to 1:00 | Frame: what you know, what you do not | Say once, plainly, "I haven't sold into rail specifically" (F5), then say the rest is stated as hypotheses to test |
| 1:00 to 3:00 | One consensus item from the report | Your words, from your reading; no recital |
| 3:00 to 9:00 | Your thesis, then the anti-pick | One thesis well beats three briefly |
| 9:00 to 12:00 | What it means for the operators themselves | The requested close. Fill in, in your own words: for an operator in 18 months this means ___, ___ and ___ |
| 12:00 to 13:00 | What you would test first, and your concession | End on the concession, then stop |

## Persona table

Panel, so the top two personas of each member's relationship are blended. The loop is established by the recruiter's email as you quoted it: one session, a panel of two, 60 minutes, a POV then Q&A. No round is named as values-style.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Case/Strategist | Deepa follows up the POV with live problems on operator partnerships | High: a future manager prior is Case/Strategist plus Skeptic, and 15 of 60 minutes is a strategy talk | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | A |
| Skeptic | Quiet probing of what your message states you lack: rail selling and a direct quota | High: same prior, and the gaps are stated | Rehearse the single most predictable objection (B1) until it is boring; plain acknowledgment, then a plan | B |
| Data-Driven Prober | Ross takes the figures apart | High: the recruiter says he will push on commercials, and your two headline figures are an influenced-revenue number and a partner count | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know | C |
| Pressure/Stress | Ross time-boxes or challenges attribution | Medium: an executive prior adds Pressure, but "push" may mean hard questions, not stress | Pause, restate, hold the stated facts through two follow-ups, concede specifics | D |
| Conversational | Deepa opens warmly with your journey | Low to medium: an opener, but still scored | A 90-second arc built from the beats you stated | E |
| Values/Behavioral | Not expected | Low: no values-style round is documented by any source in hand | None needed | No bank |
| Peer Evaluator | Not expected | Low: neither panellist is a peer | None needed | No bank |

## Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Pick an operator you'd want as a partner. What should the partnership look like in 18 months, and how would that operator know it was working?" | CASE | [generic] | Clarify first: which kind of operator, what they are trying to improve, what Kelverton already does with them. Then the objective in the operator's terms, two or three moves, and how the operator, not Kelverton, would see it working. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The POV muscle again, as a live problem; the operator-side close is the scored part |
| A2 | "What would you say no to in your first year?" | CASE | [generic] | Name the one thing you would decline, why, and what declining costs. Your anti-pick from the POV build is the answer. Hold it through two follow-ups and concede the specific cost; never withdraw the position just to restore harmony. No claim about your past | The natural push on a POV; tests whether the anti-pick is a real position |
| A3 | "What does this change for the operators themselves?" | JD | [grounded] "bus and light rail network planning, so I know the operator world from the other side" | Answer in the operator's terms: what they gain, what they stop having to do, how they would know, each as a position you would test rather than a fact about operators. If you cite your planning background, say it at its scope: bus and light rail network planning. Answer slot: if any of that work showed you what an operator needed from a supplier or partner, say what, in your own words; if it did not, or it was not rail, say so plainly and say what you would ask operators first | F2; the recruiter asked the POV to land here, so it is scored twice. JD because it scores the stated close, though the delivery is CASE |
| A4 | "What in the market report would you push back on?" | CO | [grounded] "which I've read" | This pack has not seen the report, so it names nothing from it. Use your own reading: one point you agree with, one you would test, and what evidence would change your mind. Frame it as where you would look first, not as a correction. If you have no first-hand evidence for a challenge, say it is your reading, plainly | The report is the interviewers' own strategy document, so differentiate from it and never recite it; CO because it tests homework depth |
| A5 | "An operator you want to partner with says a joint pilot would add work for their team with no clear benefit to them. What do you do?" | CASE | [generic] | Clarify what work and benefit mean to them and who decides. Separate real cost from perceived. Reshape the pilot to cut their cost or bring their benefit forward. Decide what you would concede and what you would walk away from, and say how you would know it is working. Think aloud. No claim about your past | Tests the operator-side lens the recruiter asked for, under a realistic objection |

### B. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota. Why would we trust you with a number here?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I've never carried a direct quota; my number was influenced revenue." Then the figure at its scope: "roughly £4M of influenced revenue", never booked, closed or quota. Follow-up 1, "so someone else closed it?": answer slot: say how the figure was counted and which part was yours; if you do not know how it was counted, say so plainly. Follow-up 2, "what would you commit to here?": give no number. Say what you would need before accepting one, as a plan: a baseline, what is already committed, and how attribution is counted. Hold those facts through both follow-ups and concede the quota gap explicitly. The limit, said before it is asked: your material shows influenced revenue, not direct | F3 and F4; this is the single most predictable objection, because Ross will push on commercials and the gap is stated. JD because it scores the stated commercial requirement |
| B2 | "You haven't sold into rail. What won't you know on day one?" | JD | [grounded] "Never sold into rail specifically"; "bus and light rail network planning, so I know the operator world from the other side" | Say it plainly first: "I haven't sold into rail specifically." Then name one or two things you would not yet know, as questions you would ask operators rather than guesses about rail. What your material carries is bus and light rail network planning, at that scope. Answer slot: if that work gave you a first-hand view of how operators decide, say what; if it did not, say so and return to the planning work. Close with a plan: who you would talk to in the first weeks, in what order | F5 and F2; the stated gap, asked directly |
| B3 | "Your partners were ISVs; ours are operators. What actually carries over?" | EXP | [grounded] "running the ISV channel"; "took it from 6 partners to 40" | Start from what you did, at its scope: running the ISV channel, taking it from 6 partners to 40. Then say what you would test rather than assert what carries over: which parts of running a channel you would expect to differ with operators, and how you would find out. Answer slot: if any of your channel partners resembled an operator, say how; if none did, say so plainly and stay with the ISV channel. Concede that you cannot yet say what carries over | F1 and F6; the transfer question underneath the whole application |
| B4 | "Why rail-tech, and why now?" | EXP | [grounded] "9 years in partnerships"; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | The reason is yours and this pack does not have it. Answer slot: say in your own words what moved you toward rail-tech now; if part of the honest answer is the transport work you did earlier, say so; if there was no single reason, say so plainly. Keep to the path your message states and do not offer a reason you would not repeat under a second question | Motivation consistency; EXP because it tests whether the career story holds together |
| B5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "Never sold into rail specifically" | Choose the weakness that is real and say it first; the two your message states are the likeliest. Pair it with a concrete ramp plan for the first weeks: who you would learn from, what you would read, what you would ask Deepa and Ross, said as a plan. Calibrated candor beats bluffing a competency Ross owns | F4 and F5; a stock Skeptic stem that your stated gaps make near-certain |

### C. Data-Driven Prober (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slots, each in your own words: how the figure was counted; what it is most sensitive to; the assumption behind it you would defend least; which part of it was yours. If you do not know how it was counted, say so plainly: that is a better answer than a method you cannot repeat under a second question. The pack supplies no method, baseline or attribution model | F3; a headline figure is a magnet for a commercial director |
| C2 | "What counted as a partner when you went from 6 to 40?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slots, in your own words: what counted as a partner; what the count is sensitive to; the assumption you would defend least; which part of the growth was yours. If you do not know, say so plainly. Never describe a count or a definition you cannot repeat | F6; the second headline figure, and a count can be defined many ways |
| C3 | "If we asked you to commit to a number for operator partnerships in year one, how would you set it?" | CASE | [grounded] "never carried a direct quota, only influenced revenue" | Acknowledge the gap in one sentence, then reason aloud: what you would need before giving a figure (a baseline, what is already committed, how attribution is counted), the range you would agree before a point, and what would make you revise. Give no invented number. The question is about a future decision, so the answer is a method, said as one | F4; Ross pushing on commercials makes this the forward-looking version of B1 |
| C4 | "How would you structure commercial terms with an operator partner, and where would you give ground?" | CASE | [generic] | Reason aloud from principles: what each side is paying for, what is variable, what you would protect. Say what you do not know about this company's pricing and about rail contracting rather than guessing. Answer slot: if you have shaped commercial terms with a partner, say what was yours; if terms were set by others or you have not, say so plainly and stay with the principles. Do not present a structure as one you have run | Ross's commercial push as a live problem; CASE because it is reasoned on the spot |

### D. Pressure/Stress (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "took it from 6 partners to 40"; "bus and light rail network planning, so I know the operator world from the other side" | Hold-then-concede. Pause and restate. Concede first, plainly: "I haven't sold into rail specifically." Then the facts at their scope, in your own words: you took the ISV channel from 6 partners to 40, and you did bus and light rail network planning. Do not claim to be better; let them draw the inference. Hold through two follow-ups by returning to those facts, never by adding to them | F5, F6 and F2; the Pressure stem aimed at the stated gap |
| D2 | "How much of that growth was actually you?" | EXP | [grounded] "took it from 6 partners to 40"; "running the ISV channel" | Hold-then-concede. Answer slot: say which parts were yours and which were others', in your own words; if you cannot separate them, say so plainly. "I" for what you did, "we" for context, never "single-handedly". Hold the quote at its scope through two follow-ups and concede the specific parts that were not yours | F6 and F1; the attribution probe every partnerships candidate gets |
| D3 | "You've got eighteen months and one operator wants you to drop everything for them. Go." | CASE | [generic] | Pause and restate. Clarify what dropping everything costs and what they are offering, weigh it against the plan, decide, and say what you would concede. Time-box yourself to about two minutes. No claim about your past | Tests composure on the same trade-off the anti-pick raises |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey from transport consulting to the payments channel." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."; "last 4 at a payments company running the ISV channel" | A 90-second arc using only the beats your message states: the transport consulting years (bus and light rail network planning), nine years in partnerships, the last four running the ISV channel. Why you moved between them is an answer slot: say in your own words what drew you from one to the next; if a move was not a choice, say so plainly. End on why this conversation, not on a summary | A warm opener is still scored; the arc is the one place to land the transport background early |
| E2 | "What do you most want to find out about our operators in your first month?" | JD | [generic] | Three questions you would ask operators, ordered, each tied to the POV you gave. Casual register, still scored. Make them questions, not assertions about what operators want. No claim about your past | A reverse-flavoured question that tests whether the POV was a position or a performance |

### Requirement coverage

| Requirement | Source | Questions |
|---|---|---|
| POV on operator partnerships over 18 months | Recruiter's email | A1, A2, A4, A5, D3, B3 |
| Land on what it means for operators | Recruiter's email | A1, A3, A5, E2 |
| Commercials | Recruiter's email | B1, C1, C2, C3, C4, D2 |
| Sells into train operating companies | Your message | B2, B5, D1, A4 |
| Build and scale a partner programme (role-family pattern) | None supplied | B3, C2, D2, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which operator partnership today would you point to as what good looks like, and what makes it work?" | It tests whether a working model exists and gives you something concrete to build the POV against |
| R2 | "How is the partnerships number set today, and how much of it is direct versus influenced?" | It raises the quota gap (F4) on your terms and shows you understand attribution before Ross raises it |
| R3 | "Where do operators say no to us today, and what do they say?" | The operator-side view the recruiter asked you to land on, from the people who hear it |
| R4 | "What would you need to see from me by month six for the 18-month plan to be on track?" | Deepa is your future manager; this turns the interview into a working agreement |
| R5 | "What is the biggest thing I would not know on day one that someone should tell me?" | It owns the rail gap (F5) openly and invites coaching instead of testing |
| R6 | "What has moved since the strategy report went round last quarter?" | It signals you read the report and care about what is current; ask it only if you have read the report closely |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a quota or closed revenue directly | Negative you stated, F4 | "never carried a direct quota, only influenced revenue". Plain acknowledgment: "I've never carried a direct quota." No slot |
| Has sold into rail | Negative you stated, F5 | "Never sold into rail specifically". Plain acknowledgment: "I haven't sold into rail specifically." No slot |
| Booked, closed or owned the £4M | Inflated form of F3 | "roughly £4M of influenced revenue" at its own scope. The limit is the pack's observation: your material says influenced, not booked, closed or quota-carrying. C1's slots stay inside the figure |
| Set the strategy for the ISV channel | Inflated form of F1 | "running the ISV channel" at its own scope. The limit is the pack's observation: your material says running it, not which decisions were yours. B3 and D2 slots stay inside that |
| Knows train operating companies, or heavy rail, from the inside | Inflated form of F2 | "bus and light rail network planning, so I know the operator world from the other side" at its own scope. The limit is the pack's observation: your material says bus and light rail |
| Grew the channel single-handedly | Inflated form of F6 | "took it from 6 partners to 40" at its own scope. The limit is the pack's observation: your material does not say what share was yours. C2 and D2 slots stay inside the count |

## Sources

Provided documents: your message (including the recruiter's email as you quoted it). Not received: the market report, which you say was attached; no copy was in the working directory or message, so nothing in this pack comes from it. No JD, CV file or dossier was provided; no dossier was consumed.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

Searches sent, all refused (permission not granted), so nothing came back and nothing was retried:

- `Kelverton Rail values` — refused
- `Kelverton Rail interview process partnerships manager` — refused
- `Kelverton Rail strategy news train operating companies scheduling software` — refused
- `Deepa VP Partnerships Kelverton Rail` — refused
- `Senior Partnerships Manager job description rail technology software train operating companies` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have named published values for VAL themes; no values-style round is detected, so the cheat sheet stays out either way |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | Would have checked loop structure; the recruiter's email already fixes this session (panel, 60 minutes, POV then Q&A), so persona weights rest on that |
| 3. `Kelverton Rail strategy news` | unavailable | Would have grounded CO and CASE questions and a grounding brief; no strategy text is in hand because the report did not arrive, so these are labelled generic |
| 4. `Deepa VP Partnerships Kelverton Rail` | unavailable | One query sent, for Deepa only; Ross was not searched. Would have moved the interviewer read and a tailored reverse question |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have turned generic requirement rows into quoted, inferred JD rows |

## Upgrade menu

- The market report text (paste it) → a grounding brief, CO and CASE questions rebuilt on its vocabulary, and a concrete consensus item, divergence and anti-pick for the POV
- The JD text → generic requirement rows become quoted `[grounded]` rows and the coverage table maps the posting's own list
- Your CV → more quoted evidence per row; F1, F2, F3 and F6 sit at medium until something inspectable sits behind them, such as the partner programme's reporting or a revenue-attribution summary you can describe
- Your answers to the slots in F1, F2, F3 and F6 (how the £4M was counted, what counted as a partner, which parts were yours) → those rows and B1, C1, C2 move from slots to quoted guidance
- Search access, or pasted pages (values page, recent news, careers page) → loop confirmation, a values-style round check, and grounded CO questions
- Deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes; it needs search access, which was refused in this session
- Deepa's and Ross's full names or public profile text → an interviewer read and a reverse question tied to each one's own path
- One email to the recruiter: whether the report went to every candidate, and what "operator partnerships" covers (existing customers, new operators, or both) → sharper POV theses and A1
- A `tuesday-dossier.md` from an earlier evaluation of this role, if you have one → verified evidence and absolute prohibited claims in place of the ones built here
