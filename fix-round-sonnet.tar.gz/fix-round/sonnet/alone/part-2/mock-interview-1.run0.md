I'll read the reference files the skill requires before writing anything.
Both searches were refused, so this pack runs on your inputs only. I'm writing it now.
The pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-1-denied-b24cf0d6/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

I built it for a single 60-minute peer conversation with Dan, using only what you gave me. Both web searches (company values, Dan's public footprint) were refused, so none of it is verified. That includes the interviewer read, which rests on your summary of Dan's profile, and C2 and C3, which rest on your research note. It has 20 questions across six personas, ordered by weight. The highest-ROI prep is D1, the sales-ops and quota-setting gap, because you stated it and Dan's function is Sales Strategy.

Say the word and I'll play Dan on D1 and push with the follow-ups the pack lays out.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter name any focus areas or ask Priya to prepare something, such as a POV or a case? A pre-declared deliverable would add a build section.
Can you paste the full JD and Priya's CV text? That would turn the JD highlights and the summary into exact quotes and may add questions the highlights missed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind Data
**Relationship and round:** peer (both report to the same VP); a single 60-minute conversation
**Built on:** your message only (JD highlights, a candidate summary, an interviewer summary, your research note). Both web searches were refused, so nothing here has been checked against public sources.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. No VAL questions appear here: no values-style round is detected and no published values are in hand |
| EXP | Whether a CV claim survives scrutiny, including what was actually yours |
| JD | A stated responsibility or requirement in the JD: can you do the listed job, gaps included |
| CO | Company and strategy knowledge, thought through at the company's altitude |
| CASE | Structure and reasoning on a live problem set in the role |

Question IDs are letters by persona. The letter F is left out of the banks because F1 to F7 are fit-snapshot rows, so the Pressure bank is G.

The question named as the highest-ROI prep in this pack is **D1**.

## 2. Fit snapshot

Requirements are quoted from the JD highlights you supplied. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market for a new line, and the words stay at that scope: "I spent nine years at a large consumer-tech company in product strategy and ops." Answer slot: the JD's line makes a probe on your range likely. If any part of that work was yours to decide, say which part and how you decided, in your own words; if none was, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | discovery | The quote says a proposal and a credit. It does not show which stage of a customer lifecycle the change touched, or how whitespace was identified. Answer slot: the JD's land/adopt/expand/renew line makes a probe on stages likely. If the change addressed a particular stage, say which, in your own words; if it was not framed that way, say so plainly and stay with the proposal and the credit. The figure itself raises the counting slots in A1 and A2 |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | presentation | Say it in the quote's own terms: "I'm skilled in SQL and Tableau." The pack's observation is that the quote says skilled in, not that analyses were run independently, so the words stop there. The probe is rehearsed in A4 |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not the design of a partner motion, and the words stay at that scope: "I built a partner-level revenue model that was used in carrier negotiations." The JD says required, so expect this to be probed. Answer slot: if any part of how the model was used in the negotiations was yours to decide, say which and how you decided; if none was, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | none | No gap, but a coach's-notes line with nothing inspected behind it, so expect a probe on how the consensus formed. Lead with the quote's own terms: "I set annual volume targets with cross-org consensus." Do not let the word "quota" replace "volume targets" (see F6) |
| F6 | No JD highlight asks for sales-ops or quota-setting; the interviewer's function is Sales Strategy, so the topic can arise — your message | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap wording cannot close, and it has been stated. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller, and F5's targets are not relabeled as quotas |
| F7 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | presentation | Say it in the quote's own terms: "I use AI tools daily." The pack's observation is that the quote says use, not building or launching AI products, so the words stop there. Which tools and what for is rehearsed in E2 |

## 3. Reading the interviewer

Public footprint was not searched; this read rests on the profile summary you gave.

| Signal | What the material says | Provenance | Reading (this pack's inference from the left column) |
|---|---|---|---|
| Self-description | "relentlessly data-driven" — your message | [grounded] | Expect every number to be probed to its inputs and assumptions: A1 to A5, G2 |
| Career spine | "pricing and monetization roles" — your message | [grounded] | Case questions tilt to pricing, packaging and unit economics, his native vocabulary: C2, C3 |
| Startup chapter | "one early-stage-startup chapter" — your message | [grounded] | Builder framing may land, and a scrappiness probe is possible. None of your quoted sentences carries a startup chapter, so no shared jump is offered |
| Function and relationship | "Director of Sales Strategy"; a peer reporting to the same VP — your message | [grounded] | Sales-ops and quota topics can arise (D1, G1), and the seam question is likely (B1) |
| Mirror opportunity | His pricing and monetization path beside F2's quote: "proposed a store-surface change credited with a ~$400M ARR uplift" | [inferred] | Shared vocabulary only (revenue, ARR), not a shared job. Use F2's sentence exactly as written and do not stretch it toward pricing work |

Delivery implications for this interviewer: state your assumptions aloud before a number, and say plainly when you do not know how something was counted.

## 4. Persona table

| Persona | Weight and questions | How it shows up with Dan | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|---|
| A. Data-Driven Prober | Highest, 5 | Walks the CV line by line and asks for inputs, counting and assumptions | High. Peer-round prior puts the Prober near the top, and the self-description in section 3 raises it further | Know what you can and cannot say about how each figure was counted; say plainly when you do not know; name the weakest assumption first (A1, A2) |
| B. Peer Evaluator | High, 4 | Seam-splitting, "what would you need from me", credit and disagreement | High. The peer relationship is the other dominant prior, and the JD asks for cross-functional influence | Reciprocity: offer what you bring his team, and propose seam principles rather than pretending to know the seam (B1, B4) |
| C. Case/Strategist | Mid, 4 | Live problems on pricing, packaging, partners, GTM structure | Medium-high. The pricing and monetization spine tilts cases his way, and the role is strategy | Clarify, objective, segmentation, approach, metrics, risks, aloud; challenge one premise respectfully per case |
| D. Skeptic | Mid, 3 | Quiet probing of the sales-ops gap, the consumer-to-this-role jump, and why now | Medium-high. You stated the sales-ops absence, and a Sales Strategy peer is positioned to press it | Rehearse D1 until it is boring; bridges only from adjacent quotes; plain candor, then a plan |
| E. Conversational | Low, 2 | The "walk me through the journey" opener and a casual question on AI | Medium. A 60-minute peer conversation usually opens loosely, and the JD flags AI as a plus | A 90-second arc; treat the AI question as scored |
| G. Pressure | Low, 2 | Time-boxed "why you" and "how much was you" | Low-medium. A peer is less likely than a senior interviewer to stress-test, but the figure invites it | Pause, restate, hold the quoted position through two follow-ups, concede specifically |

Loop basis: your own words establish one 60-minute session with Dan, so persona weights rest on the peer prior plus his signals, not on a company archetype. No values-style round is detected, so there is no VAL bank and no values cheat sheet.

## 5. Question banks

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start at the sentence's own scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Then three answer slots, each in your own words: how the figure was counted, what it is most sensitive to, and which part was yours. For each, if you know, say it; if you do not know how it was counted, or a step was not yours, say so plainly and return to "proposed" and "credited with". Hold through two follow-ups by returning to those words, never by adding to them | F2 holds the headline number, and a self-described data-driven peer is likely to start there. EXP because it tests how the figure survives, not the role |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name the assumption you would defend least before the follow-up ("what happens to the figure if that is wrong?") arrives. Answer slot: if you know of one, say it and what it would change; if you do not know the counting well enough to name one, say so plainly and return to the sentence as written. Never invent an assumption to sound rigorous | The second level of F2's probe, kept separate because the concession wording is the thing to rehearse. EXP because it scores candor about the figure |
| A3 | "Walk me through the revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Tell the beats the sentence states, in your own words: you built it, it was at partner level, it was used in carrier negotiations. Answer slot: the JD asks for independent analysis in SQL and Tableau, so a probe on the tooling is likely. If you did the model's data work in SQL or Tableau, say so; if it was other tools or other people, say so plainly and stay with the model | F4 is the nearest partner evidence and F3's tooling probe attaches to it. EXP because it verifies what was built; the JD requirement is why it is likely |
| A4 | "Tell me about an analysis you ran in SQL or Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | The quote carries no story, so this is a selection scaffold. Pick one analysis where you wrote the queries or built the view yourself, and where you can state the question, the conclusion and the assumption you would defend least. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, "I'm skilled in SQL and Tableau", or how you would approach one | The JD names the tooling and the Prober counter-strategy is an end-to-end walkthrough. F3 is the evidence. JD because the line is the JD's own |
| A5 | "Suppose we have a few months of usage data on a new product and a small set of early accounts. What can you responsibly conclude about expansion whitespace, and what would you refuse to conclude?" | CASE | [generic] | No claim about your past is needed. Clarify first: what counts as usage, how the early accounts were chosen, what decision the answer feeds. Then segment, then say what is solid and what is directional, name the assumption you would defend least, and say what would change your mind | Tests data judgment on a problem shaped like the role, in the register a data-driven peer prefers. `[generic]` because it is a pattern for the problem, not a fact about this employer. CASE with Prober delivery |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We report to the same VP. Where is the seam between your work and mine, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a map, and say you do not yet know where the boundary sits. Offer principles such as who owns the question versus who owns the number, agreeing before the VP sees it, and escalating with options. Then ask where he would draw it. Makes no claim about your past | The Peer Evaluator's core stem; the JD asks for strong cross-functional influence. `[generic]` because it is a pattern for the problem. JD because it scores that requirement |
| B2 | "How did you get cross-org consensus on those annual volume targets?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Tell the beats the sentence states: you set annual volume targets, and the consensus was cross-org. Answer slot: the JD's cross-functional influence line makes a probe on how consensus formed likely. If the orgs differed and you worked through it, say what differed and what part was yours; if consensus came without disagreement, or you were not the one who resolved it, say so plainly and stay with the targets and the consensus. If he calls them quotas, keep "volume targets" and see D1 | F5 is the evidence and the likeliest place a peer tests disagreement style. EXP because it verifies the claim; the peer persona is why it comes collegially |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The Peer stem scores credit-sharing. Use "we" for context and "I" for what was yours. The sentence's own verbs are "proposed" and "credited with", so keep them. Answer slot: if others built, shipped or measured it, say so by role, plainly; if the work did not span teams, say so plainly and describe how you would handle credit | F2's figure invites a credit probe from a peer. EXP because the answer must come from a real instance; the Peer stem supplies the delivery |
| B4 | "What would you need from me in your first thirty days, and what could you give my team?" | JD | [grounded] "skilled in SQL/Tableau" "uses AI tools daily" | Two halves. Needs, phrased as questions you would ask: how targets and whitespace are tracked today, and which numbers are contested. Gives: "I'm skilled in SQL and Tableau, and I use AI tools daily." Answer slot: if you can name one concrete thing you would offer his team with those, say it; if you would rather learn first, say so plainly | The reciprocity move the Peer persona scores. F3 and F7 supply the offer. JD because it scores fit with the listed analysis and AI lines |

### C. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Suppose you are handed GTM for a brand-new product line. What do you need to know first, and how do you structure the first ninety days?" | CASE | [grounded] | Think aloud: clarify, objective, segmentation, approach, metrics, risks. Use the JD's own spine, land, adopt, expand, renew, to segment. State your hypothesis early and challenge one premise (for example, whether the objective is revenue, adoption or profitability). A hypothetical, so it makes no claim about your past | The JD's first responsibility, asked as a live problem. F1 is why it is likely. CASE because it scores structure, with the JD's vocabulary |
| C2 | "Say a much larger platform vendor bundles a comparable capability into its own suite at no extra charge. What does that do to how we price and package for expand and renew?" | CO | [grounded] your research note: bundling as the main competitive threat | Rely on no facts about that vendor. Clarify whether the bundle matches what customers use most, and whether bundling is mainly a price threat or a distribution threat. Segment accounts by exposure, then levers (packaging, terms, proof of value), then the metric and the unit-economics assumption you would test first | Your note names bundling as the main threat, and his pricing spine makes this his native ground. CO because it tests strategy fluency; CASE is the delivery |
| C3 | "We are launching an AI copilot, Compass, and aiming at profitability. How would GTM for a copilot differ between landing and adopting it?" | CO | [grounded] your research note: the Compass launch and profitability as stated priorities | Ask whether Compass is one of the two lines this role owns rather than assuming it. Frame land versus adopt as hypotheses: what proves value, and who adopts. Treat profitability as a constraint: which motions are cost-efficient. Use "Compass" as the company does, and do not describe yourself as having launched AI products | Two of the three stated priorities in one question, with the JD's AI plus. CO because it tests current strategy; the note's age is unknown, so this is carried as unverified |
| C4 | "Design a partner motion for a new line from scratch. Who are the partners, what does each side get, and how do we know it is working?" | CASE | [grounded] "built a partner-level revenue model used in carrier negotiations" | Structure: objective, partner types, value to each side, economics, enablement, metrics, risks. Offer the quote once, at its own scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of how the model was used in the negotiations was yours to decide, say which and how you decided; if none was, say so plainly and stay with the model | The JD says partner-motion design experience is required, and F4 is the only adjacent evidence. CASE because it is a live design problem; JD content is why it is likely |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The role is GTM strategy across land, adopt, expand and renew, and you have not done classic sales-ops or quota-setting work. Where would you be weakest on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" | The deepest rehearsal in the pack. Level 0: the plain acknowledgment, "I don't have classic sales-ops or quota-setting experience." Then the adjacent quote at its own scope, "I set annual volume targets with cross-org consensus", then a plan said as a plan: before proposing anything on targets or sales capacity, ask how they are set today and test any design against that. Follow-up 1, "isn't that the same thing?": keep the quote's words and concede the difference; the classic work is the part you have not done. Follow-up 2, "what breaks first?": answer as a plan, naming what you would check first. Follow-up 3, "why should I believe the ramp is fast?": answer with what the quotes carry and offer to pair with him. Answer slot: if you have evidence of a fast ramp, say it; if you do not, say so plainly. Never relabel the targets as quotas | F6 is a gap you stated, aimed at the interviewer's own function, so a version of this question is near-certain. JD because it scores the role's requirement; Skeptic because it probes the gap |
| D2 | "You have spent nine years in consumer tech. What carries over to land, adopt, expand and renew here, and what doesn't?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The quote carries no customer-lifecycle story, so this is a selection scaffold. Pick one piece of your work you can describe plainly and tie it to one stage; then name one thing that does not carry, plainly. If nothing comes to mind, say so plainly, then give the nearest thing your material carries, the sentence as written, or how you would approach it | F1 is the evidence, and the background mismatch is the Skeptic's standard probe. JD because the JD's lifecycle line is the target |
| D3 | "Why leave nine years in consumer tech for this role, and why now?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The reason is yours to give; the pack supplies none. Structure it as a pull toward something the JD says rather than a push away. Answer slot: name one reason tied to the role in your own words; if the honest reason is about timing and not content, say so plainly, and say what you hope to learn | Motivation consistency is what the Skeptic scores. JD because it scores fit with this role; F1 is the background it presses on |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the two beats the sentence states: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Answer slot: why you moved at each point and what you want next, in your own words; if a move was not planned, say so plainly. Close on what draws you to this role | The biography opener is scored even when it feels casual. F1 is the evidence. EXP because it tests whether the career story holds together |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Start at the sentence's scope: "I use AI tools daily." Answer slot: which tools and what for, in your own words; if it is mainly light or personal use, say so plainly. Do not extend it to building or launching AI products. A data-driven interviewer may ask how you check the output; the pack supplies no method, so say only what you actually do | The JD flags AI as a plus, asked here in a casual register. F7 is the evidence. JD because it scores that line |

### G. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has run sales strategy or sales ops?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "skilled in SQL/Tableau" "No classic sales-ops or quota-setting experience." | Pause and restate. Hold: one sentence in the quotes' terms, covering the model used in carrier negotiations, the annual volume targets set with cross-org consensus, and being skilled in SQL and Tableau. Concede specifically: "I don't have classic sales-ops or quota-setting experience." If he pushes ("that is the core of the job"), return to the quotes and add nothing. Second push: say what you would do in the first weeks, as a plan | F6 is the gap this challenge is built on. JD because it scores fit; the Pressure persona scores composure |
| G2 | "That ~$400M result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause. Hold: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Add nothing. Answer slot: if you know which pieces others did, name them by role; if you do not know how the credit was determined, say so plainly. Never "drove", "led" or "delivered". Hold through two follow-ups by returning to the sentence | The attribution probe stated in its blunt form. F2 is the evidence. EXP because it scores honest attribution; this is A1's figure under pressure |

### Requirement coverage

| JD requirement (JD highlights) | Questions |
|---|---|
| "own GTM strategy for two new product lines" | C1, C3, D1 |
| "identify whitespace across land/adopt/expand/renew" | A5, C1, C2, D2 |
| "run independent analysis in SQL and Tableau" | A3, A4, A5 |
| "partner-motion design experience required" | C4, A3 |
| "strong cross-functional influence" | B1, B2, B4 |
| "AI experience a plus" | E2, C3 |

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You have spent most of your career in pricing and monetization, with one early-stage startup chapter. What from that chapter do you still use?" | Ties to his own path, which turns the interview into a peer conversation, and shows you listened to his background |
| R2 | "What is the one thing a new peer could do in the first month that would genuinely help your team?" | The reciprocity question for a peer: it asks how you reduce his load, not just what you need |
| R3 | "Which two product lines does this role own, and where is each in land, adopt, expand and renew today?" | You cannot tell from your material whether Compass is one of them, and the answer sharpens every case you rehearsed |
| R4 | "Where do you draw the line between your team's numbers and the whitespace analysis this role would own?" | Tests the seam before it becomes a disagreement, and shows you treat the boundary as something to agree on |
| R5 | "How is bundling by larger platform vendors showing up in the pricing and packaging conversations you are in?" | Uses the competitive threat from your note in his native area, so the answer teaches you something current |
| R6 | "Where would you expect someone with my background to need the most help from you?" | Candor about the gap invites him to name it, so you hear D1's real version early |

## 7. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led GTM for a new product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not GTM for a new line. F1's slot stays inside the work you did decide |
| Drove, delivered or generated the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: "proposed" and "credited with". The limit is the pack's observation: the material does not say who built or shipped it. A1 and A2 ask only how it was counted and which part was yours |
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope: a revenue model used in negotiations. The limit is the pack's observation: the material says the model, not the design of a motion. C4's slot stays inside how the model was used |
| Has sales-ops or quota-setting experience, including calling the annual volume targets quotas | Negative stated, F6, and contradicted by F6's own words | The plain acknowledgment F6 gives: "I don't have classic sales-ops or quota-setting experience." F5's quote stands at its own scope. No slot |
| Built or launched AI products such as a copilot | Inflated form of F7 | F7's quote at its own scope: "I use AI tools daily." The limit is the pack's observation: the material says use, not building |

## 8. Sources

Provided documents: your message (JD highlights, a candidate summary, an interviewer summary, and your research note on Northwind's priorities and competitive threat). None was verified against a public source, and the note's date was not stated.

Searches sent, both refused:

| Query | Outcome |
|---|---|
| Northwind Data company values principles | refused |
| Dan Kovac Director of Sales Strategy Northwind Data | refused |

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Search refused. It would have given published value names for VAL questions as raising sources, and a cheat sheet only if a values-style round were detected |
| 2. `Northwind Data interview process` for the role family | skipped | Your own words establish the loop: one 60-minute session with Dan. That fixes the persona weights |
| 3. `Northwind Data strategy` or recent news | skipped | Your research note already supplies the three priorities and the bundling threat that feed C2 and C3. Its age is unstated, so those questions are carried as unverified |
| 4. `Dan Kovac Northwind Data` | unavailable | Search refused. It would have given talks and writing for section 3 and a sharper R1; the read rests on your summary alone |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## 9. Upgrade menu

- Full JD text → the six JD rows become quotes from the whole posting, and any mid-list requirement the highlights omit gets a question
- Recruiter's note on focus areas or any pre-declared deliverable → coverage beyond round-type priors, and a build section for any assignment
- Search permission granted → targets 1 and 4 rerun: published values, and Dan's public talks and writing for a sharper interviewer read
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes, needing the same search permission → a grounding brief on strategy, competitors and recent leadership context, in place of the unverified note
- A dated strategy source or a current Northwind priorities page → C2 and C3 move from unverified to verified
- The document behind the ~$400M credit (a decision memo or the dashboard that showed it) → F2 can move from medium toward high, and A1 and A2's slots may be answered from it
- The partner revenue model file or deck used in the carrier negotiations → F4 can move from medium toward high
- A Tableau workbook or SQL query you authored → F3 can move from medium toward high, and A4 becomes a story map
- Your own answers to the answer slots in F1, F2, F4, A1, A2, B2 and C4 → the rows they draw on regenerate with your words in the evidence column
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and any prohibited claims it records would override and sharpen what is built locally here
