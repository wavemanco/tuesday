I'll read the reference files the skill requires before writing the pack.
Dara, your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-canned-96b6d19b/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it for the three rounds on 20 November, with each round's questions, interviewer styles and reverse questions kept separate. Round 3 also has a values cheat sheet for the four values and a set of questions for the 20-minute escalation case. I used only what you pasted, with no web research, because the recruiter's email, the values and the strategy brief already covered those. There is no interviewer section, because the interviewers haven't been named.

The prep worth the most time is question C1: "You've never worked in a contact centre, so how would you own it?" It comes back in all three rounds, and your own message states the gap. The pack coaches you to concede it plainly in your own words, hold what you did do (the branch's formal complaints log), and give a plan for learning the contact-centre side.

Other things the pack flags:

- **Your three stated gaps:** the contact centre, presenting above regional level, and digital teams. The first two are things you told me. For digital, your message says nothing either way.
- **Slots to fill in:** where the pack can't tell what you did, it leaves a slot for you to answer in your own words. It doesn't fill in details for you. These cover what your monthly spreadsheet counted, whether it was Excel, which outside rules your complaints log followed, and whether you ever trained anyone other than new tellers.
- **A clash in the values round:** the role coaches people on escalation, but "Own the Fix" says whoever finds a problem keeps hold of it. Question F5 prepares you for a panel pointing that out.

Say the word and I'll play the Head of Member Services on C1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead — Ashgrove Credit Union — interview pack for Dara

Loop mode: three rounds on 20 November 2026. Round 1 is 30 minutes with the recruiter. Round 2 is 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural. Round 3 is 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation, and it is also the values round. Interviewer names beyond their roles are not yet assigned, so there is no interviewer read in this pack.

The one piece of prep worth the most time: **C1**, the contact-centre objection. It comes back in every round (B1, C1, C3), and your own message already states the gap.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. IDs run by round and persona (A and B are round 1, C to E round 2, F to H round 3). Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether your background survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company, its strategy and its pressures |
| CASE | A live problem from the role: structure and reasoning |

An answer slot is an instruction for the interview, not a question for you now. Each one has two honest branches: say what you did, or say plainly that you did not, and return to what your own words already carry.

## Fit snapshot

Your evidence is quoted from your message. No row is a gate: none of the JD's lines is a licence, location or schedule term, so the experience lines are graded as ordinary rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD (the branches part) | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process around it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's scope makes a probe on what sat around the log likely. If anything before a complaint reached the log, or after it left, was yours, say what, in your own words; if none was, say so plainly and stay with the log |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (the contact centre part) | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your sentence says a monthly spreadsheet you built and your regional manager uses; it does not say what it counted. Answer slot: the JD's reporting line makes a probe on what the spreadsheet counted likely. Say what it counted, in your own words; if you do not know how something in it was counted, say so plainly and stay with the spreadsheet as you described it |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Your sentence says new tellers and a script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: if the people you trained included anyone other than new tellers, say who; if they were all new tellers, say so plainly |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have worked with a digital or app team on anything members use, say what and which part was yours; if you have not, say so plainly and say what you would ask a digital team first from the complaints side |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it. Lead with the years and the last three as supervisor in the quote's own terms |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your sentence says formal complaints and a log, and does not say what rules the log was kept to. Answer slot: if the log was kept to any rules or deadlines from outside the branch, say which and who set them; if it was not, or you do not know, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for a first presentation, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your sentence says spreadsheet, not which tool. Answer slot: if it was built in Excel, say so and what you did in it; if it was another tool, say that plainly |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process across branches and the contact centre | B1, C1, E1, G1 |
| Report monthly on complaint volumes and resolution times | B4, D2, E2, H2 |
| Coach branch supervisors on escalations | C2, G2, H1 |
| Work with digital teams on self-service journeys | B3, G3 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | A4, D1, G1 |
| Confident presenting to senior leaders | B2, C3, D2 |
| Comfortable with Excel reporting | B4 |

No question covers a CV headline metric because your message gives no figures.

## Grounding brief

From the July 2026 strategy brief the recruiter sent you, as you relayed it. Four facts are in hand; the full text is not.

| Fact | Source | Provenance | Where it shows up |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief, July 2026 | [grounded] | A2, B3, E2, G3 |
| Consolidate eight branches into five hubs over 2027 | 2026 strategy brief, July 2026 | [grounded] | A2, E2, F3 |
| Launch a small-business lending product in Q1 2027 | 2026 strategy brief, July 2026 | [grounded] | A2 |
| Main competitive pressure is app-only banks | 2026 strategy brief, July 2026 | [grounded] | G3 |

Use the brief's own terms. Do not offer opinions on whether the strategy is right.

---

# Round 1 — recruiter, 30 minutes

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Conversational | Friendly, unstructured: the journey, the motivation | High. The relationship prior for a recruiter screen is Conversational plus a light Skeptic, and 30 minutes leaves room for little else | A pre-scripted 90-second arc; treat casual questions as scored |
| B Skeptic, light | Knockout checks framed as checking a box | Medium. The JD's contact-centre, senior-leader and digital lines meet F2, F8 and F5, and a screen is where those are checked first | Concede plainly, move to a plan, do not stretch |

## Bank A — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc of the beats those sentences state, in your own words: six years in retail banking, the last three as a branch supervisor, the branch's formal complaints log, the escalation script you trained new tellers on, the monthly complaints spreadsheet your regional manager uses. Close on why this role. Answer slot: say what drew you to complaints work and to a member-owned organisation; if the reason is mostly that the role fits your next step, say so plainly and name the published value that appeals most. Stop at 90 seconds | F6 is the first requirement a recruiter checks, and F1, F3 and F4 are the rows the arc has to carry at the quotes' own scope. EXP because it tests whether the story matches the material; the conversational register is why it is easy to under-prepare |
| A2 | "What do you know about Ashgrove?" | CO | [grounded] | Bring two facts from the strategy brief in its own terms: 40% of member service to digital by 2028, and eight branches into five hubs over 2027. The small-business lending launch in Q1 2027 is a third if you want one. Then one published value by name, and what it means in complaints work in your words. Say where each came from and stop | A screen scores homework, and the brief was sent to you, so not knowing it costs more than knowing it earns. CO because it tests knowledge at screening altitude |
| A3 | "Why a credit union, and why Ashgrove?" | CO | [grounded] | Anchor in what is published: the JD says member-owned, and the first value is "Members First, Always — we decide from the member's side of the counter." Your own reason is an answer slot: say what in your work made you want complaints at the centre of a role; if you have no reason beyond the role fitting, say so plainly and name the value you would most want to work under. Keep it consistent, because rounds 2 and 3 will hear it again | Motivation consistency is scored across a three-round loop, so this answer has to be one you can repeat. CO because it tests what you know and chose about this employer |
| A4 | "Tell me about the formal complaints log you handled." | EXP | [grounded] "I handled the branch's formal complaints log" | Hold to the quote: "I handled the branch's formal complaints log." Say in your own words what the log held and what handling it involved. Answer slot: the JD's complaints line makes a probe on outside rules likely; if the log was kept to any rules or deadlines from outside the branch, say which and who set them; if it was not, or you do not know, say so plainly and stay with the log. Do not describe it as covering more than your branch | F7 and F1 are where a recruiter's knockout check lands. EXP because it tests what was yours, with JD content |

## Bank B — Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role spans branches and the contact centre. What contact-centre experience do you have?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment first, in the quote's terms: "I haven't worked in a contact centre." Then stop describing the gap and say, as a plan and not a past, what you would do to learn it. Do not stretch anything else into contact-centre experience. Under 30 seconds | F2 is a stated gap, and a recruiter checks it first. The same question comes back harder in round 2 (C1). JD because it scores a stated requirement |
| B2 | "The role presents to senior leaders. How comfortable are you there?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then, as a plan, how you would prepare for a first presentation to senior leaders. Answer slot: if you have presented to your regional manager, say what and how it went; if you have not presented formally at all, say so plainly. Do not claim confidence you cannot back | F8 is a stated gap against a stated requirement. JD because it scores the role's presenting line |
| B3 | "The role works with digital teams on self-service journeys. What have you done with digital teams?" | JD | [grounded] | Your material carries no sentence on this, so it is an answer slot: if you have worked with a digital or app team on anything members use, say what and which part was yours; if you have not, say so plainly and say what you would ask a digital team first from the complaints side. The brief's 40% digital target by 2028 is why the question matters | F5 is silent in your material, so the honest answer is not yet known to this pack. JD because it scores a stated responsibility |
| B4 | "Tell me about the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold to the quote: you built it, it is monthly, your regional manager uses it. Answer slot: the JD's reporting and Excel lines make probes on what it counted and what tool it was in likely; say both in your own words, and if you do not know how something in it was counted, say so plainly. Name the assumption in it you would defend least before they ask, if you know one | F3 and F9 both rest on this one sentence, so it takes the first probe. EXP because it tests what was yours, with JD content |

## Reverse questions, round 1

| Question | Why it lands |
|---|---|
| "Who will I meet in rounds 2 and 3, and can you share names once they are assigned?" | The names are not yet assigned, and the recruiter is the one person who gets them first |
| "Is the 20-minute case on the panel built on a real complaint or a made-up one, and is there anything I should read beforehand?" | Tells you the format of the heaviest-weighted exercise in the loop |
| "How does the contact centre sit against member services, and who does it report to?" | Shows you read the JD's contact-centre line, and positions F2 as a question about scope |
| "Is this a new post or a replacement, and who owns complaints today?" | Context the JD does not give, and it frames the first 90 days (E1) |
| "Which of the four values do candidates find hardest to show?" | The panel scores against them, and the recruiter may have seen the pattern |

---

# Round 2 — Head of Member Services, 45 minutes

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| C Skeptic | Quiet, persistent probing of the gaps | High. The hiring-manager prior is Case plus Skeptic, and this person would own your development, so F2, F8 and F5 are theirs to price | Rehearse the contact-centre objection until it is boring; concede in your quotes' terms; plan, not past |
| D Values / Behavioral | "Tell me about a time" probes | High. The recruiter says this round is mostly behavioural, which lifts it above the hiring-manager prior | Stories where the quotes carry the setting; selection criteria where they do not; honest branch ready |
| E Case / Strategist | A live problem from the role's own roadmap | Medium. A hiring-manager prior, lowered because the recruiter said mostly behavioural | Clarify, then structure, then answer; challenge one premise |

## Bank C — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role owns complaints across the branches and the contact centre, and you've said you haven't worked in a contact centre. How would you own something you haven't worked in?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Highest-ROI prep in this pack. Level 1, 60 seconds: concede first, in the quote's terms, "I haven't worked in a contact centre"; hold only what your quote carries, "I handled the branch's formal complaints log", which is the branch side; say the limit before they ask. Then a plan, said as a plan: what you would want to see and listen to in the contact centre in your first weeks, and who you would ask. Level 2, they push that the JD puts it in scope: agree, do not add experience, restate the plan with one first step of your choosing. Level 3, what would worry you most: name one real worry in your own words. Answer slot: if contact-centre colleagues ever worked a complaint with you, say what happened and your part; if none did, say so plainly and stay with the log | F2 is a stated gap and F1 is the nearest evidence, which stops at the branch. The objection arrives in some form in all three rounds, so a rehearsed non-defensive answer changes the interview. JD content with Skeptic delivery |
| C2 | "You trained new tellers on an escalation script. How is coaching branch supervisors on escalations different?" | JD | [grounded] "trained new tellers on our escalation script"; "6 years in retail banking, the last 3 as a branch supervisor" | Hold to the quotes: you trained new tellers on the escalation script, and you spent the last three years as a branch supervisor. Say what the training involved in your own words. Answer slot: if the people you trained included anyone other than new tellers, say who; if they were all new tellers, say so plainly. Then, as a plan, how you would approach coaching supervisors, who are a different audience from new tellers. Do not call the training coaching of supervisors | F4 stops at tellers, which is the exact distance the question tests. JD content; the branch managers on the panel may return to it (H1) |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose from what you have already said plainly: the contact centre or presenting above regional level. A third candidate is digital-team work, where your material is silent: answer slot, say whether you have any, and if not, say so plainly. Name one, concede it in the quote's terms, then give the plan in two sentences. Do not choose a weakness that is really a strength in disguise | F2, F8 and F5 are the rows with the least behind them. JD because it scores the whole list; delivery is Skeptic |

## Bank D — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you had to escalate a complaint." | EXP | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | The quotes carry the log and the script, not an escalation story, so this is a selection scaffold: pick a time where you can name the stake, the decision to escalate, how you kept the member informed, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the log you handled, or how you would handle it. "I" for what you did, "we" for context | F1, F4 and F7 are the rows an escalation story would support. EXP because it tests what you actually did; the open prompt's theme comes from the JD's escalation line |
| D2 | "Tell me about a time a report you produced said something uncomfortable." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The quote carries the spreadsheet and its reader, not an uncomfortable finding. Selection criteria: a named finding, who needed to hear it, what you said, how the relationship stood after, and whether the hard truth landed. If none comes to mind, say so plainly, then describe the spreadsheet as the quote has it and say how you would raise a bad finding with a senior reader | F3 and F8 meet here: a report, and a senior audience. VAL because it tests whether the hard truth lands; the open prompt's theme comes from the JD's reporting line |
| D3 | "Tell me about a time you coached someone through something difficult." | EXP | [grounded] "trained new tellers on our escalation script" | The quote carries training new tellers on the script, not a difficult moment. Selection criteria: who it was, what was hard for them, what you did, what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the training as the quote has it, or how you would handle it | F4 is the coaching row, and the JD raises it. EXP because it tests what was actually yours |

## Bank E — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "It's your first 90 days. What do you need to know first, and what would you do?" | CASE | [generic] | Clarify first: where complaints enter, how they are recorded, who holds them at each handoff, what outside deadlines apply. Then objective, then split by branches, contact centre and digital, then approach, measures and risks. Make the contact-centre part of the plan concrete, since it is C1 turned into a schedule. Think aloud and challenge one premise | The role is about owning a process across three areas, so a manager buys a plan. CASE; the structure carries no claim about your past |
| E2 | "As branches consolidate into hubs over 2027, complaint numbers at the hubs rise. What would you look at?" | CASE | [grounded] | Clarify: rise against what, which hubs, over what period. Hypotheses: merged workloads, handoff gaps, members shifting channel. Challenge one premise: more complaints can mean more members are reaching the process, not more failure. Say what you would look at in the monthly figures; make no claim about what your own spreadsheet did | Built on the brief's eight-to-five plan and the JD's reporting line (F3). CASE because it is a diagnosis; CO because it speaks at the company's altitude |

## Reverse questions, round 2

| Question | Why it lands |
|---|---|
| "What would a good first 90 days look like to you, between branches, contact centre and digital?" | Invites the manager to set the plan you rehearsed in E1 |
| "How are complaints reported to senior leaders today, and what do you wish the reporting showed?" | Ties to the JD's monthly reporting and to F3 |
| "How do you see my work with branch supervisors changing as eight branches become five hubs?" | Uses the brief's hub plan, and a manager can only answer it from their own view |
| "Which of branches, contact centre and digital is furthest from where you want it?" | Tells you where to aim the first month |
| "Where would you expect my background to be thinnest, and how would you want me to build that in the first month?" | Turns C1 from an objection into a joint plan, which only works if you have rehearsed C1 |

---

# Round 3 — panel of two branch managers, 60 minutes (20-minute case, scored against the four values)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| F Values / Behavioral | Scenario probes against Ashgrove's four named values | High. The recruiter says the panel is the values round and scores against the four | A story or scaffold per value, with the honest branch ready |
| G Case / Strategist | The 20-minute escalation case | High. The recruiter names it, and it is a third of the round | Clarify, own one named owner, plain words to the member |
| H Peer Evaluator | Where branch and role meet, and what you need from them | Medium. An inference: the panel are branch managers and the role works across branches and coaches branch supervisors, but their exact relationship to the role is not stated | Propose seam principles, not a seam you do not know; bring something to them, not only what you need |

The Conversational persona is low here: the cross-functional prior includes it, but a scored values round leaves less room for it, so it is folded into bank F.

## Bank F — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Members First, Always. The quote carries the setting, not a decision. Selection criteria: a named stake, the decision you made from the member's side, what it cost in the branch, how the member heard it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the log you handled, or how you would handle it | Value 1 of 4. F1 supplies the setting only, so the story's middle has to be yours |
| F2 | "Tell me about a time something you wrote or said had to be explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words. The quote carries the script and the training, not an occasion. Answer slot: if a trainee or a member ever needed something explained twice, say what it was and what you changed; if not, say so plainly and describe how you taught the script as the quote has it | Value 2 of 4. F4 is the nearest row; whether anything needed explaining twice is not in it |
| F3 | "The strategy consolidates eight branches into five hubs over 2027. How do you hold 'every branch is part of its town' through that, in a complaints role?" | VAL | [grounded] | Neighbours, Not Numbers. Make no claim about your past. Answer as a plan: ask which towns and what members use the branch for; keep complaints reachable and answered in plain words through the change; do not pretend to know the hub plan's detail. Answer slot: if members ever told you what their branch meant to them, say what they said and what you did; if not, say so plainly and use the plan | Value 3 of 4. The brief's hub plan sits against this value, and two branch managers will hear it from inside their branches. VAL with CO content |
| F4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix. The quote carries the log, not a problem kept to the end. Selection criteria: whose problem it was to begin with, what you did, how you knew it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Value 4 of 4. F1 is the nearest row and stops at the log |
| F5 | "You trained people on an escalation script. How does passing a complaint up fit with 'whoever finds the problem keeps hold of it'?" | VAL | [grounded] "trained new tellers on our escalation script" | Hold to the quote: you trained new tellers on the escalation script. Answer slot: if the script kept the person who found the problem involved after escalation, say how; if it handed the complaint over entirely, or you do not know, say so plainly and say how you would build ownership into escalation in this role. Do not say the script already worked that way unless it did | The role coaches escalations and the value says the finder keeps hold, so the two collide. F4 is the row at stake. VAL with JD content |

## Values cheat sheet

| Value (official name) | Working meaning, paraphrased | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | F1: "I handled the branch's formal complaints log" carries the setting only, so use the F1 scaffold above, ending in its honest branch |
| Plain Words | If a member has to be told twice, the writer failed | F4: "trained new tellers on our escalation script" carries the script only, so use the F2 slot above, ending in its honest branch |
| Neighbours, Not Numbers | Each branch is part of its town, not a line in a table | F3: "I built the monthly complaints spreadsheet our regional manager uses" carries the numbers side only, so use the F3 plan and slot above, ending in its honest branch |
| Own the Fix | Whoever finds a problem stays with it until it is solved | F1: "I handled the branch's formal complaints log" carries the setting only, so use the F4 scaffold above, ending in its honest branch |

## Bank G — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member has complained at the branch twice about the same unresolved issue and says they will go elsewhere. The supervisor wants to escalate; the contact centre says it is the branch's to fix. You have twenty minutes: what do you do?" | CASE | [generic] | Clarify first: what the complaint is, what was promised, what outside deadlines apply, what the member wants. Objective: the issue solved, with one named owner said aloud, which is Own the Fix at work. Then what to tell the member now in plain words, what to record, what to review afterwards about why it bounced. Challenge the premise that it is either the branch's or the contact centre's. Roughly: 3 minutes clarify, 5 structure, 8 approach, 4 risks | The recruiter named a 20-minute escalation case, and this is its likely shape. CASE; the structure makes no claim about your past, and F1, F2 and F7 are the limits behind it |
| G2 | "A supervisor escalates almost every complaint to you. How do you coach them?" | CASE | [generic] | Clarify: since when, which types, whether they are right to. Hypotheses: fear, unclear thresholds, the script. Approach: understand before coaching, agree thresholds, keep the supervisor holding the member relationship, say what you will measure. Risk: taking ownership away from them. Make no claim that you have coached supervisors | The JD's coaching line and F4's gap meet here, so this is where a panel can test the role directly. CASE |
| G3 | "40% of member service moves to digital by 2028. Which complaints should never end up in a self-service journey, and how should the rest be written?" | CASE | [grounded] | Clarify what self-service covers. Principles: the member chooses the channel; a complaint about the self-service itself needs a human; anything with outside deadlines or an upset member needs a person; the rest in Plain Words, said once. The app-only banks in the brief are the reason the journey must work. Your material is silent on digital-team work (F5), so answer as a design principle, not as experience | Built on the brief's 40% target and the JD's digital line. CASE with CO content, and the nearest this loop gets to F5 |

## Bank H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our supervisors will be coached by you. Where is the seam between what we manage in branch and what you own, and what happens when we disagree?" | JD | [generic] | Propose principles, not a seam you do not know: one named owner for every complaint; the branch keeps the member relationship; the JD gives you the process, the reporting and the coaching, so ask where they see the edges. On disagreement: raise it early, bring the facts from the monthly figures, agree who decides before a case arises. Reciprocity: what you bring them is a clear read of their branch's complaints in plain words, and what you need is their supervisors' time | Peers price what a hire costs their own branch. JD content, Peer delivery |
| H2 | "Your monthly report may show our branch worse than another's. How do you bring me that before it goes up?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The quote states a monthly spreadsheet you built and your regional manager uses. As a plan: tell the branch manager first, in plain words, what a figure shows and what it does not, ask what they know about the town's context, then agree what goes up. Answer slot: if you ever took a branch-level finding to someone before it went further, say what happened; if not, say so plainly and describe the plan | F3 is the reporting row, and this sets Neighbours, Not Numbers against it. JD with VAL content |

## Reverse questions, round 3

| Question | Why it lands |
|---|---|
| "What would help your supervisors most from me in my first month?" | The reciprocity question: it asks what you can do for them |
| "What does a complaint handled well look like from your side of the counter?" | Uses their first value in their own words |
| "Which of the four values is hardest to live in a branch day to day?" | A panel scoring on the values will have an honest view |
| "How would you want to hear about your branch's complaints before they go up?" | Connects H2 to a real preference |
| "Where do complaints get stuck today between branch and contact centre?" | Connects G1 to their experience and tests F2's scope |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log, not the process around it. The slots in A4 and C1 stay inside the log |
| Has contact-centre experience | Negative you stated, F2 | "Never worked in a contact centre", and the plain acknowledgment F2 gives. No slot beyond C1's |
| Has presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level", and the plain acknowledgment F8 gives |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says new tellers and a script. C2's slot asks only who was trained |
| Reported complaint volumes and resolution times each month | Inflated form of F3 | F3's quote at its own scope. B4's slot asks only what the spreadsheet counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says a formal complaints log, not what rules it was kept to. A4's slot asks only which rules, if any |

## Sources

Provided documents: the JD; the values text you copied on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; the four facts you relayed from the July 2026 strategy brief; your background, in your message. No tuesday-dossier.md was present.

No searches were sent and no pages were fetched. The values URL names where your pasted text came from; it was not read as a link.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the cheat sheet and the VAL bank, with the four values by official name |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email fixes the loop: three rounds, who runs each, the 20-minute case and the values scoring |
| 3. Ashgrove strategy or recent news | skipped | The July 2026 brief you relayed is under six months old and supplies four facts for the CO and CASE questions |
| 4. Interviewer name and Ashgrove | n/a | No names are assigned, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names for rounds 2 and 3 → a reading of each person's public professional footprint, persona weights adjusted from it, and a reverse question tied to their own path
- The full strategy brief, not just four facts → a fuller grounding brief and sharper CO and CASE questions
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → recent organisational context and loop reports for this kind of role, and the interviewer footprints once names exist
- Your own answers to the slots in F1, F3, F4, F5, F7 and F9 → those rows move from discovery toward grounded, and the VAL scaffolds become story-mapped answers
- An anonymised sample of the monthly complaints spreadsheet → the inspectable artifact for F3 and F9, which would move their confidence bands
- Your CV text → more quotable evidence for the fit snapshot beyond what your message states
- The recruiter, by one email: which outside rules apply to Ashgrove's complaints, and whether the contact centre sits under Member Services → settles F7 and the scope of F2
- How many hours you have before the 20th → a prioritised prep schedule
- A tuesday-dossier.md from job-underwriter → verified evidence and a prohibited-claims list from a separate assessment, which would replace this pack's locally built one
