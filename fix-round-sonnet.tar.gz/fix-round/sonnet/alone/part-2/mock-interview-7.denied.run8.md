I'll read the reference files first.
Saving the pack is done. I'm fixing one naming clash: the values-bank question IDs F1 and F2 collide with fit-snapshot rows F1 and F2. Then I'll present it.
Femi, your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-denied-c6285feb/saltmarsh-games_live-operations-producer_interview_pack.md`.

I built it for a hiring-manager round, since your note gave Tobias's title but not how he relates to the role. It has 19 questions across six interviewer styles, plus a fit snapshot and six reverse questions. It also has a list of claims I won't coach, and a coverage table mapping each JD line to the questions that cover it.

My web searches were refused, so nothing in the pack comes from research on Saltmarsh, its products, its interview process or Tobias. The strategy and company questions are generic and there's no interviewer read. The Sources section lists the four refused searches, and the upgrade menu says what research would add.

The highest-ROI prep is question B1. Your evidence is thinnest where the JD is widest: the live-events calendar across two titles, and owning the post-event review. You've told me about one title's weekly content drops and presenting retention numbers. B1 rehearses saying that plainly, then conceding only the limits you can actually name. Questions B3 and B4 do the same for never having led a team and never having worked on in-app purchases.

Say the word and I'll play Tobias as the Skeptic on B1, then give feedback against that question's guidance.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, a peer, or a skip-level, and did the recruiter mention a format, take-home or focus areas for the 60 minutes? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Session:** one 60-minute interview, Friday
**Relationship (assumed, not confirmed):** hiring manager. Your note gave his title and not how the role relates to him, so the persona weights below rest on the hiring-manager prior. If he is a peer or a skip-level, the weights change (see the upgrade menu).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your background claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you did your homework on the company and its products |
| CASE | Structure and reasoning on a live problem from the role |

Answer slots in the guidance are instructions for the interview, not questions for you now. Each has two honest branches: say how it went, or say plainly that the step was not yours or did not exist. Both are good answers.

**Highest-ROI prep: B1.** Your material is thinnest exactly where the JD is widest, which is the live-events calendar across two titles and ownership of the post-event review. That question will arrive in some form. Rehearse B1 until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title, with nothing inspected behind it, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD says live-events calendar and two titles, so a probe on whether the calendar held events and spanned more than one title is likely. If it did, say how, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team, and never worked on a game with in-app purchases" — your message | low | [inferred] | discovery | Your material touches the calendar and says nothing about whom you worked with on it. The JD's word is coordinate, which is not the leading you said you have not done, and the pack does not treat them as the same. Answer slot: if you worked with any of the four disciplines the JD lists on those drops, say which and what your part was, in your own words; if none, or it was not your part, say so plainly and stay with the calendar you ran. Plain acknowledgment, sourced to your message: "I haven't led a team." |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presenting the monthly retention numbers, which is presenting, not producing or owning, and it is not a review of an event. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD says post-event review and KPIs, so a probe on whether any drop or event was reviewed afterwards, and which measures were looked at, is likely. If one was, say what was looked at and what part was yours; if none was, or it was someone else's, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in what the quote says, but a line with nothing inspected behind it, and "wrote" is not "managed each release", so expect a probe on how releases ran against it. Lead with it in the quote's own terms: you wrote it, and QA still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | The quote carries four years and the associate producer title at a puzzle-game studio. It does not say whether the title was run as a live service, and the pack does not supply that. A years requirement is not a gate: it is graded like any other row. Answer slot: if the title was run as a live service, say how, in your own words; if it was not, or you are unsure, say so plainly and stay with the four years |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Lead with it as stated: "I ran the weekly content-drop calendar for our main title for the last two years." Expect a probe on how the calendar worked, rehearsed as A4 |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms: "I presented the monthly retention numbers to the studio head." It says presented, not how the numbers were counted, so expect a probe on that, rehearsed as C1 |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A written document in ongoing use touches the requirement without showing whether the writing was clear. Answer slot: if there is another piece of writing others relied on, say what it was; if the checklist is the one, say so plainly and stay with it |
| F9 | Mobile live-operations roles in general can involve in-app purchases; the JD does not mention them | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The JD does not raise this, so the pack does not know whether Tobias will; it is here because your own statement makes it a likely self-assessed weak spot |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: prioritize two titles, diagnose a dip, handle a slipping feature | High. The hiring-manager prior puts it first, and the JD is a planning-and-coordination job that invites live cases | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the gaps: one title versus two, events versus drops, no team led, no in-app purchases | High. The hiring-manager prior puts it second, and F1, F3 and F9 are the thinnest rows against the widest JD lines | Rehearse B1 until boring; bridge only from what you stated; say the limit plainly before it is asked |
| Data-Driven Prober | Reads the background line by line and asks how the retention numbers were counted | Medium. The JD names retention metrics and you named monthly retention numbers, so the probe has a target; no figures are on your background, so there is no number to defend | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know |
| Conversational/Rapport | Opening "walk me through your journey" and a casual question about what you play | Medium. Most interviews open this way, and casual questions here are still scored | A 90-second arc built only from your four stated facts; treat the casual question about games as scored |
| Pressure | Time-boxes you and asks how much was actually yours | Low to medium. Nothing in the material says this loop is stress-style; the attribution probe appears in most loops | Pause, restate, hold the position through two follow-ups, concede only specifics |
| Values/Behavioral | Scenario prompts about leadership communication and putting players first | Low. No loop source establishes a dedicated values round, so the Generic archetype applies with no values round assumed | Scaffolds ending in the honest branch; stories only where a sentence of yours carries one |
| Peer Evaluator | Seam-splitting between adjacent teams | Low, with no questions in the bank. Under the assumed hiring-manager relationship it is unlikely; it would rise if Tobias turns out to be a peer | Reciprocity framing: what you bring his team, and seam principles rather than pretending to know the seam |

Loop note: no loop source was available (the searches were refused, see Sources), so the weights rest on the hiring-manager prior and the Generic archetype, not on documented Saltmarsh rounds.

## Question banks

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Both our titles want the big event slot this month. How do you decide, and what do you need to know first?" | CASE | [generic] | Clarify before structuring: what each event is meant to move, what each team has capacity for, what the last comparable event did, where the QA window falls. State the decision criteria aloud, pick, name the main risk, and challenge one premise politely, for example whether both really need the same slot. The question needs no claim about your past, so the guidance makes none | The JD's two-titles calendar is the role's core planning problem (F1's requirement); CASE because it scores structure, not content |
| A2 | "An event shipped on Saturday and Monday's numbers are 20 percent under plan. Walk me through your post-event review." | CASE | [generic] | Clarify what the plan was built on and what the comparison is; segment before diagnosing; list hypotheses; say what you would report, to whom, and what you would change for the next event. Say aloud what you would not conclude from one weekend. No claim about your past is made here | The JD's post-event review and KPI line (F3's requirement) as a live problem; CASE because the answer is reasoning, and it also rehearses F3's thin evidence without claiming it |
| A3 | "Two days before an update ships, engineering says one feature will slip. Art and community have already scheduled around it. What do you do?" | CASE | [generic] | Structure it: what you ask engineering first, what each team now needs to know and by when, the options (ship without it, move the date, ship it later as a patch), who decides and what you bring to that decision, and what you would record afterwards. No claim about your past is made | The JD's coordination line (F2's requirement) as a decision under pressure; CASE because there is no single right answer, only visible reasoning |
| A4 | "Walk me through the weekly content-drop calendar you ran." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F6: the calendar, the weekly rhythm, the main title and the two years are the beats the quote states; tell them in your own words. Answer slot: the JD says plan and run, so expect a probe on how items got into the calendar; if you chose or sequenced them, say how and why; if they were set by someone else, or there was no set process, say so plainly and describe how you ran the calendar. Answer slot: the JD says live events across two titles; if your calendar held events or covered more than one title, say so; if not, say so plainly | F6 is the evidence for the calendar requirement and F1 is where it is stretched; JD because it scores the stated requirement, with EXP delivery |
| A5 | "Have you played either of our titles? What did you notice about how they run events?" | CO | [generic] | Play both before Friday and say only what you actually saw: one specific observation per title, framed as an observation, not a verdict. If you have not played them, say so plainly and ask what Tobias sees as the standout in how they run events and why. The pack cannot name the titles because the research was refused | Homework depth is scored in a casual register; CO because it tests current product knowledge, and generic because no research could be run |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You ran the weekly content-drop calendar for your main title. This role plans live events across two titles and owns the post-event review. What carries over, and what doesn't?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" "Wrote the release checklist our QA team still uses" "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. Level 1, the hold, only what the quotes carry: "For the last two years I ran the weekly content-drop calendar for our main title. I wrote the release checklist our QA team still uses. I presented the monthly retention numbers to the studio head." Say the limit before they do. The pack's observation is that your material shows drops for the main title, not events across two titles and not a post-event review; the words for it are an answer slot: if any drop was run as an event, any calendar of yours covered more than one title, or any drop was reviewed afterwards, say which and what part was yours; if none, say so plainly. Level 2, "How much of the calendar was your call?": answer slot: if you chose or sequenced items, say how; if others set it, or there was no set process, say so plainly and return to the calendar you ran. Level 3, "So why you?": return to the three sentences above, then say what you would learn first as a plan, never as a past. Hold through each level and concede only the specific limits your slot answers establish | F1 and F3 are where the role's wider mandate presses hardest, with F5 beside them, so this objection arrives in some form; JD because it scores the stated requirements, Skeptic because it goes straight at the gap |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Choose the answer that is true for you; pick from the rows the pack marks thin (F1, F2, F3, F5), or from what you stated yourself. If you choose what you stated, the plain acknowledgment is "I haven't led a team" or "I haven't worked on a game with in-app purchases", whichever you mean. The JD names neither, so your call whether either is your weakest. Then give a first-30-days plan, said as a plan. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry | Candor under a standard Skeptic stem; JD because it scores honest self-assessment against the listed requirements |
| B3 | "You haven't led a team. You'd be working across several disciplines on every update. How would that go?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Open with the plain acknowledgment: "I haven't led a team." The pack makes no claim that you coordinated anyone. Answer slot: the JD lists the disciplines you would work across; if you worked with any of them on the weekly drops, say which and what your part was; if none, or it was not your part, say so plainly and return to the calendar you ran. Then a plan, said as a plan: how you would run your first update with each discipline | The stated negative in F2's evidence is the premise; EXP because it tests what was actually yours, and the JD's coordination line (F2) is why it matters |
| B4 | "You haven't worked on a game with in-app purchases. What would you want to learn first?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the plan, said as a plan and not a past: play both titles, read the last few post-event reviews, and ask the team how purchases figure in each title's events, what they measure, and who owns those numbers. Do not describe any purchase-related work you did not do | F9 records the stated negative; EXP because the interviewer is checking your self-assessment, and the whole answer is candor plus a learning plan |
| B5 | "The JD asks for 3+ years producing live-service games. Was your puzzle title run as a live service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: if it was run as a live service, say how in your own words; if it was not, or you are unsure, say so plainly and stay with the four years and the weekly drops you ran. Do not adopt the interviewer's phrase unless it is true of that title | F5 is the requirement the quotes do not settle, so the premise is the JD's and the guidance does not adopt it; JD because it scores the first listed requirement |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start from what the quote says: "I presented the monthly retention numbers to the studio head." Answer slots, each in your own words: how the numbers were counted; what they were sensitive to; the assumption behind them you would defend least; which part was yours, whether you produced them or presented figures others produced. "I don't know how it was counted" is an honest branch. Do not name a method or a metric definition you cannot repeat under a second question | F7 and F3 rest on this one sentence, so a prober starts here; EXP because the probe is attribution and assumptions |
| C2 | "Tell me about a time a retention number changed something you did." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | An open prompt, so you choose the instance. Criteria: the number, what you did because of it, what happened next, and what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I presented the monthly retention numbers to the studio head", and say how you would use those numbers in this role. Do not invent a decision | The JD's retention requirement (F7) in behavioral form; EXP because it tests a real instance, and the open-prompt form avoids presupposing one |
| C3 | "You wrote the release checklist QA uses. Walk me through it." | JD | [grounded] "Wrote the release checklist our QA team still uses" | Beats the quote states: you wrote it, and QA still uses it. Answer slot: the JD says manage the release checklist with QA, so expect a probe on how releases ran against it; if you ran it with QA on releases, say how and what your part was; if QA ran it, or it was used without you, say so plainly and stay with having written it | F4 is your strongest row and the likeliest to be probed for depth; JD because it scores the stated checklist requirement |

### D. Conversational/Rapport (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years" "Wrote the release checklist our QA team still uses" "Presented the monthly retention numbers to the studio head" | A 90-second arc that holds only these four facts: the four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the main title, the checklist QA still uses, the monthly retention presentation. Answer slot: why live operations and why this studio, in your words; if you have no specific reason yet, say so plainly and say what drew you to the posting. Do not fill the arc with detail beyond these four | The biography question is scored, and the arc is where a candidate drifts from the facts; EXP because it tests whether the story matches the background |
| D2 | "What are you playing right now, and how do you think it runs live events?" | CO | [generic] | Say what you actually play and pick one real observation about how it runs events. If you are not playing anything live-service at the moment, say so plainly and name the last one you spent real time in. No claim about your past is made here | A casual question on a hot JD topic that is still scored; CO because it tests genuine interest in the space, generic because it needs no research |

### E. Pressure (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over someone who has run live events across several titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" "Wrote the release checklist our QA team still uses" "Presented the monthly retention numbers to the studio head" | Pause, restate, then hold on what the quotes carry: the calendar, the checklist, the retention presentation, one sentence each. Hold through two follow-ups. Concede only specifically: answer slot: if you have not run events or more than one title, say so plainly rather than arguing past it, then say what you would learn first as a plan. Never fold on the three facts to restore harmony | F1 is the thin row this question presses; JD because it scores fit against the listed role, with Pressure delivery |
| E2 | "How much of that checklist was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: "I wrote the release checklist our QA team still uses." Answer slot: if anyone else contributed or QA shaped it, say who and what part was whose; if you wrote it alone, say so plainly. Add nothing to the quote. A held position you cannot back is the one the second follow-up breaks | F4's attribution is the likeliest place a time-boxed interviewer tests; EXP because the question is about what was actually yours |

### G. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "Presented the monthly retention numbers to the studio head" | An open prompt: choose an instance. Criteria: a named stake, the moment you did not soften it, and the relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I presented the monthly retention numbers to the studio head", without claiming any number was unwelcome unless it was | A standard behavioral stem; VAL, with generic provenance because no published Saltmarsh values were available to theme it, and the quote appears only as the nearest-thing fallback |
| G2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | An open prompt: choose an instance. Criteria: the metric, the player-facing consequence you weighed, what you chose, and how it landed. If no such time comes to mind, say so plainly, then say how you would decide when the two conflict. No claim about your past is made here | A standard behavioral stem adapted to a games context; VAL, generic because it rests on the persona stem and no published values |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A4, B1, E1 |
| Coordinate design, art, engineering and community on each update | A3, B3 |
| Own the post-event review and the KPIs it reports | A2, B1, C2 |
| Manage the release checklist with QA | C3, E2 |
| 3+ years producing live-service games or apps | B5, D1 |
| Experience running a content calendar | A4, B1 |
| Comfortable with player-retention metrics | C1, C2 |
| Clear written communication | none, and why: no question scores it directly; it is judged by how you answer and by any written follow-up, and C3 and E2 touch the one written artifact you named (F8) |

Strategy-grounded CO and CASE questions were not possible: the research was refused, so A1 to A3, A5 and D2 are generic. That is the honest cost, and the upgrade menu says what would change it.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like in this role across the two titles?" | It asks for the success bar in the role's own terms and signals you are planning to be measured |
| R2 | "What does the post-event review report today, and who reads it?" | The JD makes the review and its KPIs yours, so asking what exists shows you will build on it, not replace it blindly |
| R3 | "How do design, art, engineering and community hand work to the producer on an update today, and where does it tend to snag?" | It asks about the real seams in the coordination line and invites a candid answer |
| R4 | "How do the two titles' calendars relate today: separate, shared, or somewhere between?" | It goes at the planning problem behind A1 and tells you what you would inherit |
| R5 | "How do in-app purchases figure in the events calendar and the review today?" | It turns your stated gap into a learning question and gets you the information you need |
| R6 | "Where does the release checklist live now, and who maintains it?" | It ties to the QA line and shows you think about the checklist as an ongoing artifact |

No interviewer profile was available, so none is tied to Tobias's own path (see the upgrade menu).

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't led a team." No slot |
| Worked on, or owned, in-app purchase or monetization work | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot; then a plan |
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the weekly content-drop calendar for the main title. B1's slots stay inside that calendar |
| Coordinated design, art, engineering and community on each update | Inflated form of F2 | F2's quote at its own scope. B3's slot asks only whom you worked with on the weekly drops |
| Owned the post-event review and its KPIs, or produced the retention numbers | Inflated form of F3 | F3's quote at its own scope: your material says presenting. C1's slot asks only how the numbers were counted and which part was yours |
| Four years producing a live-service game | Inflated form of F5 | F5's quote at its own scope: four years as an associate producer at a puzzle-game studio. B5's slot asks only whether the title was run as a live service |

## Sources

Provided documents: the job description text and your background summary, both in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, every one refused because search permission was not granted in this session:

- "Saltmarsh Games company values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games mobile studio strategy news" — refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Every call was refused. It would have fed a values cheat sheet and values-themed VAL questions; none is built, and G1 and G2 rest on persona stems |
| 2. Saltmarsh Games interview process, producer roles | unavailable | Every call was refused. It would have fed the loop structure and persona weights; they rest on the hiring-manager prior and the Generic archetype |
| 3. Saltmarsh Games strategy and recent news | unavailable | Every call was refused. It would have fed strategy-grounded CO and CASE questions and a grounding brief; A1 to A3, A5 and D2 are generic |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Every call was refused. It would have fed an interviewer read and a reverse question tied to his path; both are absent |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is your future manager, a peer or a skip-level, and the format the recruiter described (any presentation, take-home or stated focus areas) → persona weights recomputed, and a build section if a deliverable was announced
- Search permission → rerun the four refused targets: published values (a values cheat sheet if a values round is documented), loop structure, a strategy-grounded CO and CASE bank, and Tobias's public professional footprint for an interviewer read and a tailored reverse question
- A deeper research pass (offered once): up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on the studio's strategy and recent moves, and role-family loop reports
- Your answers to the slots in F1, F2, F3, F5 and F8, in your own words, stated outside any drill → those discovery and transferability rows gain quoted evidence and their bridges and guidance regenerate
- The content calendar itself and the release checklist document (an export or a screenshot) → F1, F4 and F6 can move from medium to high
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence, an underwriter-chosen objection to rehearse, and sourced prohibited claims in place of the ones built here
