I'll read the reference files the skill points to before writing anything.
Web searches were refused here, so I'm building the pack from what you gave me. I'll write it now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-1-denied-c1f63cd5/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

I built it for a single peer conversation with Dan. It has 19 questions across six personas (Prober, Peer, Case, Skeptic, Pressure, Conversational), each tagged by type and with answer guidance and rationale. The Skeptic bank's D1 is the highest-ROI rehearsal. It is the "no classic sales-ops or quota-setting experience" objection, sitting in the function Dan leads.

Web searches were refused in this session, so none of the three I tried returned anything. Everything about Northwind and Dan comes from your note and profile description, which I couldn't check or date. No values-based questions are banked, since no values text was in hand.

Say the word and I'll play Dan on D1, with live follow-ups and feedback against the pack's guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document.

1. Did the recruiter give any focus areas or a pre-declared deliverable (a POV, a presentation) for this conversation? A named deliverable would add a graded build section, and stated focus areas would reweight the banks.
2. Can you paste the full JD text and Priya's CV, or say skip? The pack stands without them, but the thin fit rows would become quoted evidence and the guidance more specific.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy — a peer; both report to the same VP (your message)
**Round:** one 60-minute conversation with Dan (your message)

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on. Every question carries both, so you can see the style you will face and the thing being tested.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the CV claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the actual role |

- Guidance is scaffolding, not a script. Say things in your own words, and only what you actually did.
- An answer slot is an instruction for the interview, not a question for you now. It names what Dan is likely to probe, then gives two honest branches: say how you did it, or say plainly it was not yours or never existed.
- Highest-ROI rehearsal in this pack: D1. It is the objection most likely to be asked in some form, so rehearse it until it is boring.
- No VAL questions are banked: no published values were in hand and no values-style round is documented for this loop (see Sources).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message; "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | Your material says targets and a proposal, not a GTM strategy for a new line, and the words stay there: "I set annual volume targets with cross-org consensus" and "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD's two-new-product-lines line makes a probe on your closest comparable likely. Name the nearest piece of work you carry and what part of it was yours, in your own words; if nothing was close, say so plainly and stay with the targets and the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | The quote at its own scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Your material does not say how the opportunity was found or which lifecycle stage it sat in. Answer slot: the whitespace line makes a probe on how it was found likely. If the finding came from analysis you did, say what you looked at, in your own words; if it did not, or the analysis was someone else's, say so plainly and stay with the proposal. A headline figure also raises four slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | low | [inferred] | discovery | A skill line with nothing inspected behind it, so it is a lead and not a story. Answer slot: if there is an analysis you ran yourself in either tool, say what the question was, what you pulled and what came of it; if there is none that was yours end to end, say so plainly and say how you would approach one |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | The quote at its own scope: "I built a partner-level revenue model that was used in carrier negotiations." Your material says a model used in negotiations, not how a partnership was run or designed. Answer slot: if any part of how the model was used in the negotiations was yours to set, say which part and how you decided; if none was, or it was not yours, say so plainly and describe the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | Reword only the quote: "I set annual volume targets with cross-org consensus." Your material does not name the orgs or say how consensus formed, and the words add neither. Expect a probe; the answer is what you did, in your own words |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | low | [inferred] | discovery | The quote at its own scope: "I use AI tools daily." Your material does not show whether that reaches work on an AI product or a go-to-market. Answer slot: name the tools and one specific thing you did with them; if it is everyday use and not a piece of work, say so plainly |
| F7 | Sales-ops and quota-setting fluency, as a Director of Sales Strategy would test it — plain prose, not a JD line | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to sales-ops work, and nothing added to make the gap feel smaller |
| F8 | "Senior GTM Strategy Lead, Emerging Products" at a "B2B data-infrastructure SaaS" — your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | The quote at its own scope: "I spent two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops." Answer slot: expect a probe on the move to business buyers. If any of the nine years touched enterprise customers or business buyers, say what and your part; if none did, say so plainly and stay with the product strategy and ops work |

## Reading the interviewer

Public footprint was not researched (search refused); this reads only the profile description you supplied.

| Signal | Source | Practical implication | Provenance |
|---|---|---|---|
| "relentlessly data-driven" | Dan's profile self-description, your message | Persona rule: this tilts toward the Prober, so expect any number you give to be probed to its assumptions. Pre-name the weakest assumption you know of before he does. Drilled in A1, A2, E1 | [inferred] |
| "pricing and monetization roles" | your message | Persona rule: pricing, packaging and unit economics are his native language, so expect case questions to tilt that way (C3). Your material in F1 to F8 shows no pricing work; if asked about pricing you have done, answer from what you did or say plainly it was not yours | [inferred] |
| "one early-stage-startup chapter" | your message | Persona rule: builder stories land well with this signal, and a probe on scrappiness is plausible (E2). Do not coach a claim of startup-style work your material does not carry | [inferred] |
| "both reporting to the same VP" | your message | He is pricing what you cost and add to his own work: seams, credit, disagreement with an equal (B1 to B4). Offer seam principles and a reciprocity frame; do not pretend to know where the line sits | [inferred] |
| Shared vocabulary: monetization and ARR | his "pricing and monetization roles", your message, beside F2's "proposed a store-surface change credited with a ~$400M ARR uplift" | Speak ARR and revenue naturally with him, and no further than that quote reaches. No shared career jump is offered: no row's evidence carries the candidate's side of one | [inferred] |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance | Bank |
|---|---|---|---|---|---|
| Data-Driven Prober | Every figure walked to its inputs and assumptions; follow-ups go two levels deep | High: the peer prior pairs Peer Evaluator with Prober, and "relentlessly data-driven" raises it. Weight: 5 questions | Know what you can and cannot say about how each number was counted and say plainly when you do not know; name the weakest assumption before he does | [inferred] | A |
| Peer Evaluator | Seams between his team and this role, "what would you need from me", credit across teams | High: the relationship prior, since you would sit beside him under one VP. Weight: 4 questions | Reciprocity framing; propose seam principles, not a map; show spine and tact together | [inferred] | B |
| Case / Strategist | Live problems from the role: Compass, expansion, pricing a new product | Medium: no hiring-manager prior here, but the JD asks for whitespace and strategy work and his pricing spine tilts cases toward monetization. Weight: 3 questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | [inferred] | C |
| Skeptic | Quiet probing of the gaps: sales-ops and quota, partner-motion design, the consumer-to-B2B move | Medium: F7 is a stated gap in the function he leads, and F4 and F8 are adjacent not direct. Weight: 3 questions | Rehearse the likeliest objection (D1) until it is boring; bridge only from what your quotes carry; plain limits plus a ramp plan | [inferred] | D |
| Pressure / Stress | Time-boxed challenges to attribution and motive | Low: a peer conversation is rarely adversarial, but one attribution challenge on the headline figure is cheap to rehearse. Weight: 2 questions | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real | [inferred] | E |
| Conversational / Rapport | Open "walk me through the journey" and casual probes on hot JD topics such as AI | Medium for the opener, low for the rest: it is a single peer chat. Weight: 2 questions | A pre-scripted 90-second arc; treat casual questions about AI as scored | [inferred] | G |
| Values / Behavioral | Scenario probes mapped to published values | Low: no published values were in hand and no values-style round is documented for a single peer conversation. Not banked; influence stories live in B | Revisit if values text or a recruiter note arrives (upgrade menu) | [inferred] | not banked |

## Grounding brief

From your research note, which is undated and could not be checked (search refused). Use it to sound current, not to recite.

| Fact (verbatim) | Source | How it feeds the pack | Provenance |
|---|---|---|---|
| "three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | your message | C1 to C3, R4, R6 | [grounded] |
| "main competitive threat is bundling by a much larger platform vendor" | your message | C1, R5 | [grounded] |
| "B2B data-infrastructure SaaS, ~3,000 employees" | your message | D2, F8's slot | [grounded] |

## Question banks

### A. Data-Driven Prober (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the sentence and nothing added: "I proposed a store-surface change credited with a ~$400M ARR uplift." Then the four figure slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least (name it before Dan does), and which part was yours. If you do not know how it was counted, say so plainly and do not estimate. Never describe a sizing method, baseline or attribution model you cannot repeat under a second question | F2 holds the pack's headline figure, and a data-driven peer will go straight to it; EXP because it tests what was actually the candidate's, and the weakest-assumption move is the type's bar |
| A2 | "Walk me through the partner-level revenue model you built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: you built it, it was partner-level, it was used in carrier negotiations. Answer slot: the JD's independent-analysis and partner lines make a probe on what the model took in and what it was most sensitive to likely. If you built it, say the main drivers and the one you would defend least, in your own words; if some inputs came from others or you do not know how they were set, say so plainly and stay with the three beats | F4 is the only evidence for the partner requirement and F3 asks for independent analysis; EXP because the probe is on what was theirs, with JD content behind it |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau, from question to finding." | JD | [inferred] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | Selection scaffold. Pick one piece of analysis you wrote or built yourself. It needs a named question, the data you pulled, the finding, what happened because of it, and the number you would defend least. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the revenue model, at its own scope, or say how you would approach one | F3 is thin and the JD names the tools, so Dan will ask for an instance; JD because it scores the stated requirement, and open because no sentence carries the story |
| A4 | "How did the cross-org consensus on your annual volume targets come together?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote states: annual volume targets, cross-org consensus. Answer slot: the JD's cross-functional-influence line makes a probe on how consensus formed likely. If you drove it, say how and what part was yours, in your own words; if the orgs reached it themselves or someone else led it, say so plainly and stay with the quote. Name the orgs and the metric where you have them; do not supply them from this page | F5 is where the influence requirement is carried; EXP because it tests what was the candidate's part, and it is the seam a sales-strategy peer cares most about |
| A5 | "How would you tell whether a new-product GTM motion is working: which three numbers, and where does each one mislead?" | JD | [grounded] | A live problem, so the guidance makes no claim about your past. Choose three measures you could defend, say what each one hides, and name the assumption you would defend least. Think aloud and ask what the product's buyer and sales cycle look like before choosing. Tie one measure to the profitability priority if it fits | The JD's two-new-product-lines line is the raising source, and a Prober tests the measurement habit behind it; JD because it scores the stated responsibility, CASE in delivery |

### B. Peer Evaluator (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between sales strategy and GTM strategy for new products, and what happens when we disagree?" | JD | [grounded] | Do not pretend to know the seam. Offer principles: shared definitions of land, adopt, expand and renew; one agreed data source; decision rights stated before a disagreement; and the shared VP as the last resort, not the first. Ask Dan where it chafes today before proposing anything. The guidance makes no claim about your past | The relationship and the shared VP come from your message; JD because it scores the cross-functional-influence line, and this is the persona's signature stem |
| B2 | "How do you handle credit when work spans teams?" | JD | [generic] | Say the principle first: name who did what, early and in writing. Then a selection scaffold for the story: pick a time work spanned teams and you were the one to name another team's part; it needs a named stake and an intact relationship. If no such time comes to mind, say so plainly, then say how you would handle it | Credit probes are the peer's way of asking whether you add to or take from his load; JD because F5's requirement is the raising source, and the story is open because no sentence carries it |
| B3 | "What would you need from me, and my team, in your first month?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Reciprocity first: what you would bring his team, then what you need. Offer a shared definition of the funnel stages and data access as asks. For what you bring, stay with the quote: "I set annual volume targets with cross-org consensus," offered as how you work with other orgs, not as a deliverable you will ship. Do not promise analysis you have not shown | A peer prices what the hire costs him; JD because it scores partnership fit against F5, and the reciprocity frame is the counter-strategy the persona asks for |
| B4 | "When your analysis and the sales team's numbers disagree, whose number wins?" | CASE | [generic] | A live problem, no claim about your past. Reconcile before debating: agree the definitions and the source of the number first, then isolate where they diverge, then decide with the owner of the decision. Say which assumption in your own number you would test first. Challenge the premise respectfully: neither number wins until the definitions match | Tests disagreement style with an equal and a data-driven habit at once; CASE because it is a live scenario, and generic because it is a pattern for the problem |

### C. Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is a stated priority. How would you think about land and adopt for a copilot when a much larger platform vendor can bundle a rival into a suite customers already own?" | CO | [grounded] | Clarify first: who the first buyers are, what the competing bundle includes and how it is priced, what success means, what adoption data exists for adjacent products. Then: objective; segment by existing accounts against new logos; approach for each stage; metrics (adoption, attach, expansion revenue, margin); risks (price pressure from the bundle, cannibalization). Challenge one premise, such as that the bundling threat bites every segment equally. Do not claim knowledge of Compass beyond what is public | The launch and the threat are the two strategy facts in your research note, undated and unchecked; CO because it tests altitude, with CASE delivery |
| C2 | "Enterprise expansion is a priority. Say a segment shows high adoption but flat expansion. How do you size the whitespace and decide where to place a bet?" | CASE | [grounded] | Clarify what whitespace means here: accounts, products or seats, and what data exists. Segment by lifecycle stage using the JD's terms: land, adopt, expand, renew. Size with a count times a plausible attach times a realistic price, and name the assumption you would defend least. Say what you would test and how you would check it against the sales team. A live problem; no claim about your past | The JD's whitespace line and the expansion priority are both raising sources; CASE because it is a live problem, and F2 is the only evidence behind it |
| C3 | "Profitability is a stated priority. For a new AI product, how do you decide between selling it as an add-on, bundling it into an existing plan, or pricing on usage, and what data do you want first?" | CASE | [generic] | A live problem, pricing in Dan's native language. Clarify the buyer and the cost to serve; consider willingness to pay, attach and cannibalization, the competing bundle, and margin against the profitability priority. State the trade-off you would make and the assumption you would defend least. If you have not priced a product, say how you would learn what the data would show; do not borrow vocabulary you cannot defend | His pricing spine makes this the likeliest place for him to push; CASE because it is live, and generic because the structure is a pattern, with the priority only echoing your research note |

### D. Skeptic (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You don't have classic sales-ops or quota-setting experience, and this role sits next to mine. Where does that hurt you first?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | The highest-ROI rehearsal in the pack. Open with the plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Stop; do not soften it. Then the two sentences your material carries, each at its own scope: "I set annual volume targets with cross-org consensus" and "I built a partner-level revenue model used in carrier negotiations." Let Dan decide how far they reach; do not call them equivalent to quota work. Limit, named before he asks: your material does not show renewal or quota mechanics, so do not reach for them. Follow-up 1 ("volume targets are not quotas"): agree they are different, and ask what he would want you to learn first. Follow-up 2 ("what would you get wrong first"): answer as a plan, not a past: what you would ask for in the first weeks, such as how quotas are set today and the data behind them. Follow-up 3 ("why should I trust your judgment on expand and renew"): hold by saying what you would do, not by arguing credentials; concede plainly that it is a gap you would close with his team | The gap sits in the function he leads, so this is the most predictable objection in the loop; F7 is the stated negative and F1 and F4 are the only adjacent quotes. JD because it scores the stated lifecycle work, and deepest because it needs three follow-up levels and exact concession wording |
| D2 | "You've spent nine years in consumer tech. Why move to B2B data infrastructure, and why now?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Your reasons are yours; the pack cannot supply them. Give one reason that pulls you toward this role and one on why now, each specific enough to survive "tell me more". If part of the honest reason is a push away from the last role, say that plainly. Answer slot: if any of the nine years touched enterprise customers or business buyers, say what and your part; if none did, say so plainly and stay with the product strategy and ops work. Do not claim domain knowledge of data infrastructure you have not shown | F8 is the background probe every skeptic opens with; JD because it scores fit with the role, and the guidance is a scaffold because no quote carries the motive |
| D3 | "Partner-motion design is a required part of this role. What part of a partner motion have you designed yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The hold is only what the quote carries: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of how the model was used in the negotiations was yours to set, say which part and how you decided, in your own words; if none was, or it was not yours, say so plainly and describe the model. The honest branch is a limit, not a confession. Hold through two follow-ups by returning to the model, never by adding to it | F4 is where the JD's required line presses hardest; JD because it scores a stated requirement, and the slot lets the premise be false |

### E. Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold-then-concede. Pause, restate, then hold: "I proposed a store-surface change credited with a ~$400M ARR uplift." Return to that sentence through two follow-ups; never add to it. Concede specifically, as an answer slot: if you know how credit was divided, say it in your own words; if you do not know how the credit was assigned or by whom, say so plainly. Never fold on the core claim to restore harmony | The classic attribution probe on F2, in the persona's own stem; EXP because it tests precise attribution, and the hold is only what the quote carries |
| E2 | "Why should I believe nine years at a large consumer-tech company carries over here?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Hold-then-concede. Restate, then say what the nine years were in the quote's words: product strategy and ops at a large consumer-tech company. Say which parts you would expect to carry over and which you would expect to relearn, in your own words, and name them. Hold through two follow-ups; concede the relearning plainly, not the whole transfer. The pack does not supply which parts carry | His startup chapter makes a probe on scrappiness plausible; JD because it scores fit, and F8 is the evidence it presses on |

### G. Conversational / Rapport (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "proposed a store-surface change credited with a ~$400M ARR uplift"; "set annual volume targets with cross-org consensus" | A 90-second arc with four beats. One: two years in strategy consulting at a top firm. Two: nine years at a large consumer-tech company in product strategy and ops. Three: the three things your material carries, in the quotes' own words and no more. Four: why this role, in your reasons, not this page's. Rehearse it out loud and stop at ninety seconds | The opener is almost certain in a peer chat and is still scored; EXP because it sets the story every later probe returns to, and F8, F4, F2 and F1 are the rows it draws on |
| G2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Name the tools you use and one specific thing you did with them that you can describe end to end. If it is everyday use and not a piece of work, say so plainly. Do not imply you have built or launched an AI product, and do not claim knowledge of how Compass works. Tie to the role only if you can do it truthfully | The JD's AI line is the raising source and a casual question on it is still scored; JD because it scores a stated plus, and the guidance is a scaffold because F6's quote carries no story |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | A5, C1, C3 |
| identify whitespace across land/adopt/expand/renew | A1, C2 |
| run independent analysis in SQL and Tableau | A2, A3 |
| partner-motion design experience required | A2, D3 |
| strong cross-functional influence | A4, B1, B2, B3, B4 |
| AI experience a plus | G2 |
| background fit (not a JD line): consumer-tech to B2B | D2, E2, G1 |
| sales-ops and quota fluency (not a JD line) | D1 |

Type coverage: EXP A1, A2, A4, E1, G1; JD A3, A5, B1, B2, B3, D1, D2, D3, E2, G2; CO C1; CASE B4, C2, C3; VAL none, for the reason given under How to use this pack.

## Reverse questions

| # | Question to ask Dan | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Your background includes pricing and monetization roles and an early-stage startup. What from those shows up in how you approach sales strategy here?" | Ties to his own path, and turns an interrogation into a peer conversation | [grounded] |
| R2 | "What could a new person on my side do in the first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are pricing his load, not only yours | [generic] |
| R3 | "Where do you see the line between your team and this role today, and what is the first decision you would want me to check with you before making it?" | Proposes a seam without pretending to know it, and lets him describe where it chafes | [generic] |
| R4 | "Which numbers across land, adopt, expand and renew do you trust most today, and which do you wish were better?" | A data-driven peer will care most about the data you would be working from | [inferred] |
| R5 | "When a larger platform vendor bundles into the suite, where does it show up first in the pipeline data?" | Uses the competitive threat in your research note and asks about the data, his language | [grounded] |
| R6 | "How is the profitability priority changing where sales strategy decides to invest in the new product lines?" | Shows you read the priorities as a tension, not a slogan | [grounded] |
| R7 | "What does the VP want from the two of us together in the next two quarters?" | Surfaces the shared boss's expectations for the peer pair | [grounded] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Designed or owned a partner motion | Inflated form of F4 | F4's quote at its own scope: "built a partner-level revenue model used in carrier negotiations". The limit is the pack's observation: the material says a model used in negotiations, not how a partnership was designed. D3's slot stays inside the model |
| Owned or led GTM strategy for a new product line | Inflated form of F1 | F1's quote at its own scope: "set annual volume targets with cross-org consensus". The limit is the pack's observation: the material says targets and a proposal, not a GTM strategy for a new line |
| Presented the annual volume targets as quota-setting or sales-ops work | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." The targets stay at the scope of F1's quote. No slot |
| Took sole or full credit for the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". The limit is the pack's observation: the material says proposed and credited, not who else contributed or how credit was assigned. E1's slot asks only about the split |
| Has launched or taken an AI product to market | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily". The limit is the pack's observation: the material says daily use, not work on a product. G2's slot asks only what was done with the tools |

## Sources

Provided documents: your message — the JD highlights, the candidate summary, the interviewer profile description and the research note. No dossier was present.

Searches sent, all refused (the session did not grant web search):

- `Northwind Data company values principles` — refused
- `Northwind Data Compass AI copilot launch enterprise expansion` — refused
- `Dan Kovac Director of Sales Strategy Northwind Data` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Every call refused. Would have supplied the company's published values, enabling VAL questions with mapped stories; no values-style round is documented either way, so a cheat sheet was not warranted |
| 2. `Northwind Data interview process` | skipped | Your words fix the loop: one 60-minute conversation with Dan, a peer. That settles persona priors and the session count, so a search could not have changed them |
| 3. `Northwind Data strategy` and recent news | unavailable | Every call refused. Would have checked your research note's freshness and fed the grounding brief and C1 to C3 and R4 to R6 |
| 4. `Dan Kovac Northwind Data` | unavailable | Every call refused. Would have fed the interviewer read and R1 with his public path beyond your description |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | A JD was supplied, as highlights; the fit snapshot and JD-tagged questions rest on it. Full text is in the upgrade menu |

## Upgrade menu

- The full JD text → mid-list requirements that the highlights omit become rows, and every JD-tagged question gains a raising source it may quote
- The recruiter's prep note (focus areas, process, any pre-declared deliverable) → a graded-deliverable build section if one was announced, and persona weights read from stated focus areas, not priors
- Priya's CV, or her answers to the answer slots in F1 to F4, F6 and F8 → thin rows become quoted material and the matching guidance cells become story maps; answers to the figure slots on the ~$400M give A1 and E1 their real content
- An inspectable artifact behind the claims, if she can share one: an analysis, query or dashboard sample for F3, and the record that credited the ~$400M uplift for F2 → medium and low bands can rise where the artifact shows what was hers
- Northwind's published values or principles text, or a recruiter statement that a values round exists → VAL questions with mapped stories or selection scaffolds
- Dan's own talks, posts or profile text beyond your description → a fuller interviewer read and a sharper R1
- Deeper research: up to 6 more searches and 2 more fetches, several more minutes, needing web search to be allowed in this session → strategy brief, interviewer footprint, role-family loop reports and recent org context; offered once
- A `tuesday-dossier.md`, if one exists → verified evidence and a named top objection in place of the inferred one; the pack does not need it
