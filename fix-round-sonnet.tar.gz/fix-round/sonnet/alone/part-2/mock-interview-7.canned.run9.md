I'll read the reference files before building the pack.
Research is finding real Saltmarsh material, which is rare for this kind of search. I'm reading their official values and interviewing pages in full now, then I'll build the pack.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-canned-5aaf170b/saltmarsh_live-operations-producer_interview_pack.md`. It has 21 questions, a values cheat sheet, six reverse questions and a prep plan sized to the time before Friday.

Saltmarsh publishes its loop. Your 60 minutes is the "Outage Hour": a live-incident tabletop on a simulated outage, then a values conversation, with no take-home. I built the pack assuming Tobias is the hiring manager running it, so the tabletop and values questions carry the most weight.

The question to rehearse first is C1. Saltmarsh's September 2026 news moves its titles to a season pass, and you've said you haven't worked on a game with in-app purchases. Three of the other four Skeptic questions test the gaps you stated: C2, C4 and E1. I picked C1 myself because no dossier named an objection. The pack drills it with three follow-ups. Your retention numbers, your release checklist and your calendar are the sentences the pack builds your answers on. It keeps them at the scope you gave them, and it leaves answer slots wherever your material doesn't say.

I can run a live drill on C1 with me playing Tobias. I can also save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to Word.

Beyond the pack: I can add a one-page "first ten minutes of an outage" card, since half your hour is the tabletop.

Two questions:
1. Has your recruiter said anything about the tabletop, such as the scenario, which title, or whether it's timed? Anything you have would replace my generic scenarios in A1 to A3.
2. Do you want a deeper research pass, up to 6 more searches and 2 more fetches over several more minutes? It would add a company grounding section and more on Tobias's published talks. My research so far saw only snippets of the Project Larkspur news post and his GDC talk listing.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Built on the assumption that he is the hiring manager who runs your session, which is the "Outage Hour" in Saltmarsh's published loop: one 60-minute interview, a live-incident tabletop on a simulated outage during a live event, then a values conversation (Sources, row 2).
**When:** Friday. Built for about two days of prep.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for your own words, not a script, and where it says "answer slot" it is an instruction for the interview, not a question for you now.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Saltmarsh's published values, not generic virtue |
| EXP | Whether what you said about your own work survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you understand the company's current direction |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

| Order | When | Do this | Where |
|---|---|---|---|
| 1 | Tonight | Rehearse the objection most likely to be asked, aloud, three times, including its three follow-ups. This is the highest-ROI prep in the pack: it is inferred from the fit snapshot because no underwriting dossier was supplied | C1, then C4 and E1 |
| 2 | Thursday morning | Run the tabletop half against a timer: clarify first, then structure, then recommend | A1, A2, A3 |
| 3 | Thursday midday | Choose real stories for the three published values, or take the honest branch where none comes to mind | B1, B2, B3, section 10 |
| 4 | Thursday evening | Defend your own sentences: how the retention numbers were counted, what the checklist is, what was you | D1, D3, E2, F1 |
| 5 | Friday morning | Read the reverse questions once and pick three | Section 11 |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your message says weekly content drops for the main title, not live events and not two titles, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events line makes a probe on whether any drops were time-limited events likely. If any were, say which and how they were run; if none were, say so plainly and stay with the weekly calendar. The JD's two-titles line makes a probe on more than one title likely. If you ran a calendar for another title, say how; if only the main title, say so plainly |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | low | [grounded] | discovery | The quote states no team lead and says nothing about coordinating, so the pack does not read it as an absence of coordination. Answer slot: the JD names four disciplines, so expect a probe on which you worked with on an update. If you coordinated any of them, say which and how you got agreement, in your own words; if you did not, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | The quote is monthly numbers presented, not a post-event review and not KPI ownership, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on what happened to the numbers after you presented them. If you can say what the studio head did with them, say it in your own words; if nothing followed, or it was not yours to know, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead with the quote's own terms: "I wrote the release checklist our QA team still uses." The quote says wrote, and that QA uses it; the pack's observation is that it does not say who maintains it. Nothing inspected sits behind the line, so expect a probe on it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The quotes give the years and the calendar; they do not say whether the main title was a live-service game. Answer slot: the JD's live-service line makes that probe likely. If the title was live-service, say how in your own words; if not, say so plainly and say what the calendar did involve. The role asks for "producing" and your title is "associate producer", so expect that to be noticed |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Word it at the quote's scope: "I presented the monthly retention numbers to the studio head." The quote does not say how the numbers were counted, so D1 rehearses that before it is asked |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | A written document that is still in use is the nearest named thing: "I wrote the release checklist our QA team still uses." Nothing else written is quoted, so nothing wider is claimed |
| F8 | Not in the JD: event work on a title with in-app purchases, a role-family expectation written as plain prose; Saltmarsh's September 2026 season-pass announcement makes it likely to come up (Sources, row 3) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work, and nothing added to make the gap feel smaller |

No requirement in the JD is a gate: "3+ years" is a length-of-experience requirement, graded like any other row.

## Reading the interviewer

Public professional footprint only. It is one talk listing seen as a search snippet; the talk itself was not read.

| Public fact | Source | What it means for your prep |
|---|---|---|
| Head of Live Operations at Saltmarsh Games; previously a QA lead at a console studio | GDC 2026 talk listing for "Patch Notes Are a Promise" (Sources, row 4) | Expect depth on the release checklist and on how you work with QA: D3, B5, A2 |
| His argument, as the listing gives it: a live team is judged by how often its patch notes describe what actually shipped | Same listing | He listens for the gap between said and shipped. Keep every answer at the scope of what you did; this is also what C1, E1 and E2 rehearse |
| Shared professional ground | F4: "Wrote the release checklist our QA team still uses." — your message | A QA-facing document you wrote sits next to his QA background. Say the sentence at its scope and let him ask; it is shared ground, not a shared career jump |
| Footprint depth | One listing only | Nothing else about his style is established, so none is assumed. The upgrade menu names what would deepen this |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist (4 to 5 questions) | The tabletop: a simulated outage during a live event, run live | Highest. Hiring-manager rounds lean Case and Skeptic by relationship prior, and Saltmarsh's interviewing page documents the tabletop as the first half of the Outage Hour | Clarify, then objective, then structure, then recommend; think aloud; challenge one premise respectfully |
| B. Values / Behavioral (5 questions) | The values conversation that closes the hour | Guaranteed in this session: the same page documents a values conversation as the second half, and the values page names three principles | Choose real stories, or take the honest branch; say "we" for context and "I" for what was yours |
| C. Skeptic (4 questions) | Quiet probing of in-app purchases, team leadership and the jump from an associate role | High. Hiring-manager prior, plus gaps you have stated (F2, F8) and a title step (F5) | Rehearse C1 until boring; bridge only from your own sentences; concede what is true |
| D. Data-Driven Prober (3 questions) | Line-by-line on retention numbers and the checklist | Medium. Inference: his QA background (Reading the interviewer) and the JD's KPI line point toward depth on checklists and numbers | Say how things were counted, or say plainly you do not know |
| E. Pressure (2 questions) | Time-boxed challenge, "how much was you" | Low to medium. Inference only: a live tabletop may be time-boxed, but no source says the hour is a stress format | Pause, restate, hold two follow-ups, concede specifically |
| F. Conversational (2 questions) | The opener and casual questions about live games | Medium. Openers are near-universal; casual questions are still scored | A 90-second arc, built from your own sentences |

Peer Evaluator is left out: Tobias is the head of the function, not a peer.

## Question banks

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, B1, E2, F1 |
| Coordinate design, art, engineering and community teams on each update | A1, A3, C2 |
| Own the post-event review and the KPIs it reports | D2, D1, B4 |
| Manage the release checklist with QA | A2, A5, B5, D3 |
| 3+ years producing live-service games or apps | C3, F1, F2 |
| Comfortable with player-retention metrics | D1, D2, B4 |
| Clear written communication | A3, D3 |

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Players report they can't claim their rewards on day two of a limited-time event, and the community team is already seeing it on social. Engineering joins in ten minutes. What do you do first?" | CASE | [generic] | Clarify before you structure: what exactly is failing (claiming, display, or data), who is affected and how many, since when. Objective: stop players being harmed and keep them informed. Then sequence: who must be on the call, what community hears in the first minutes, a decision point on pausing or extending the event, what you would measure to know it is fixed. Challenge one premise aloud, such as whether the cause is known yet. The published value says that when the calendar and the players disagree, the players win; use it only if it is how you would actually decide. The question needs no claim about your past, so the guidance makes none | The live-incident half of the Outage Hour (persona table, row A); `[generic]` because the scenario is a pattern for the problem, not Saltmarsh's actual one; CASE because it scores structure on a live problem |
| A2 | "The fix is built, QA hasn't finished the release checklist, and the event ends in two hours. Ship or hold?" | CASE | [generic] | Do not answer ship or hold first. Ask what is untested, what a bad ship could do to players against what a missed window does to them, and who decides. Lay out the options (ship now, ship part, hold and extend or compensate the event) and what players would be told under each, announcing only what is built. Then commit to a recommendation, name the assumption it rests on, and name the fact that would change it. The guidance makes no claim about your past | Tests the schedule-versus-QA seam behind F4 as a decision; the published value on announcing only what is built is the likely listening frame; CASE |
| A3 | "Write the first player-facing message about the outage. What goes in, what stays out?" | CASE | [generic] | Structure: what is known now, what players should do, when the next update comes. Out: causes you cannot confirm, fix times nobody has agreed, compensation not yet decided. Say it aloud in plain, short sentences. The guidance makes no claim about your past | The JD's written-communication line (F7) tested live rather than asked about; CASE |
| A4 | "From February 2027 two titles share one events calendar and one live-ops group. You are planning the first shared calendar. What do you need to know before you place a single event?" | CO | [grounded] | Clarify first: what is already fixed, how the two audiences overlap, which events cannot collide, who owns each slot, how a review would compare events across titles. Then objective, sequencing rules, metrics, risks. Use the company's own vocabulary (shared events calendar, single live-ops group, season pass) and ask how the pass works rather than stating it, since the pack saw only a news snippet. Do not correct the interviewer if a detail differs | The pack's strategy-grounded question (Sources, row 3); it presses on F1 and F8 together; CO delivered as CASE |
| A5 | "Sketch the release checklist for a limited-time event that touches art, engineering, community and QA. What is on it, and who signs off?" | CASE | [generic] | Structure by phase: before build lock, before release, at release, after release. One owner per line, one explicit sign-off, and a decision rule for what happens when a line fails. Close with how the checklist would change after each release. The guidance makes no claim about your past; D3 is where your own checklist comes in | Covers the JD's checklist line (F4) as design; the closing beat follows the published value on leaving the checklist better; CASE |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What happened?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time a scheduled drop and what players needed pulled apart, with a named stake, a decision you made or influenced, and what happened for the players. Say what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, that you ran the weekly content-drop calendar for your main title for two years, or how you would decide | Maps to "Players Before Plans"; F1 holds the nearest sentence; VAL |
| B2 | "Tell me about a time you were asked to announce something before it was built, or before you knew it would ship." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick a time with a named announcement, the pressure to make it, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing: you wrote the release checklist QA still uses, at that scope. Answer slot: the value says Saltmarsh announces what is built, not what is hoped, so expect a probe on whether the checklist ever changed what was released or announced. If it did, say what happened and what part was yours; if not, say so plainly and stay with having written it | Maps to "Ship the Patch Not the Promise" and to his talk's theme; F4 holds the nearest sentence; VAL |
| B3 | "Tell me about a time you left a process or a checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. Beats the sentence states: you wrote the checklist, and QA still uses it. Tell them in your own words. Answer slot: the value says every release leaves the checklist better than it found it, so expect a probe on whether it changed after releases. If it did, say what prompted a change, what changed, and whose change it was; if it did not change, or the changes were not yours, say so plainly and stay with having written it | Maps to "Leave the Build Greener"; the one value your material carries a story for, at its own scope; VAL |
| B4 | "Tell me about a time you had to deliver a number leadership did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a month the numbers fell short of hopes, with a named stake, how you said it, and where the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, that you presented the monthly retention numbers to the studio head, or how you would do it | Persona stem for the values interviewer, applied to F3 and F6; VAL |
| B5 | "Tell me about a time QA said a release was not ready and the schedule said otherwise." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick a time with a named release, who held which position, what was decided and by whom, and how you worked with QA afterwards. If no such time comes to mind, say so plainly, then give the nearest thing, the checklist you wrote that QA still uses, or how you would handle it. The JD's manage-with-QA line makes this probe likely | JD line on working with QA (F4) as a behavioural prompt, aimed at the interviewer's own QA background; VAL |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our titles are moving to a season-pass model, and you have not worked on a game with in-app purchases. How would you run an events calendar with revenue attached to it?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "Presented the monthly retention numbers to the studio head."; "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack, inferred from the fit snapshot because no dossier named an objection. Hold: say the limit first, in your words: "I haven't worked on a game with in-app purchases." Then what your material carries, at its own scope: you presented the monthly retention numbers to the studio head, and you ran the weekly content-drop calendar for your main title for two years. Then a plan, said as a plan and never as a past: what you would ask in the first weeks, such as who owns the trade-offs between events and revenue, and which event numbers are tied to the pass. Follow-up one, "What would you do in week one?": three questions you would ask, not answers you would give. Follow-up two, "Why would retention work carry over?": concede, since retention numbers and revenue are different things, and say what you would read and whom you would ask. Follow-up three, "A stakeholder wants a paid event over player complaints": answer as a decision, and use the published value only if it is your view. Never invent a revenue event or a figure | F8 is the largest gap and the likeliest opening for a hiring manager; the limit is named before it is asked for; JD because it scores whether you can do the role as it is changing |
| C2 | "You have never led a team, and this role coordinates design, art, engineering and community on every update. Why would they follow your calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first: "I've never led a team." Then the calendar, at its scope: you ran the weekly content-drop calendar for your main title for two years. Answer slot: the JD names four disciplines, so expect a probe on which you worked with. If you coordinated any, say which and how you got agreement; if you did not, say so plainly and stay with the calendar. Close with how you would work, said as a plan | F2 is the row this probes; the acknowledgment has the source the pack requires; JD |
| C3 | "You are coming from a puzzle-game studio as an associate producer. Why Saltmarsh, and why this role now?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Three beats. What you have done: the four years, at that scope. What you want next. Why this team. Answer slot: your material does not carry why you want this or why now, so the words must be yours; if you have read Saltmarsh's published values or Tobias's talk, name what struck you only if it is true, and if you have not, say what you would want to learn | The motivation probe, aimed at the title step (F5); the pack supplies no reason because none was given; JD |
| C4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Calibrated candor: choose the one that is true. The pack's observation is that your material is thinnest on coordinating the four disciplines (F2) and on in-app purchases (F8). If you choose in-app purchases: "I haven't worked on a game with in-app purchases," then your plan. If you choose coordination, use C2's slot | Persona stem for the Skeptic; honest self-assessment scores higher than bluffing; JD |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The monthly retention numbers you presented to the studio head: walk me through how they were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold the sentence at its scope. Answer slot: say how the numbers were counted, what they were most sensitive to, the assumption behind them you would defend least, and which part was yours, each in your own words. If you do not know how a figure was counted, say so plainly and say what you would check. Never state a method you cannot repeat under a second question | F6 is the row; every quantified claim gets a defend-the-number rehearsal; EXP |
| D2 | "What would you want a post-event review to report, and which one number would you hold an event to?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | A hypothetical, so it claims nothing about your past: the event's objective, one primary number with a guardrail, a comparison point you can name, and the decision it feeds. If you reach for experience, the nearest sentence is that you presented the monthly retention numbers to the studio head; do not call that a post-event review | The JD's post-event-review line (F3) asked as a design question so the answer cannot outrun the quote; JD |
| D3 | "Tell me about the release checklist you wrote: how did it come about, and how does QA use it now?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. Beats the sentence states: you wrote it, and QA still uses it. Answer slot: how it came about and what QA does with it are not in your material. Say who asked for it and what QA does with it today, in your own words; if you cannot say, or it was handed over, say so plainly and stay with having written it. The JD's manage-with-QA line makes a probe on the working relationship likely | F4 is the strongest quote and sits closest to the interviewer's own background; EXP |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run a monetized live-ops title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head."; "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold: the calendar, the checklist and the retention numbers, each at its own scope. Concede specifically: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to those sentences, never by adding to them or by claiming anything about the other candidate | F8 and F2 are what this tests; hold-then-concede on a position your quotes carry; JD |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Anchor in your sentence: "I ran the weekly content-drop calendar." Answer slot: say which parts you decided and which came from design, art, engineering or community, in your own words; if you cannot separate them, or others decided most of it, say so plainly and return to what you ran. Do not fold on "ran" and do not stretch it | F1 is the row; the attribution probe in its pressure form; EXP |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats, one sentence each, in your own words: the four years, the calendar, the checklist, the retention numbers, each at its quoted scope. Close with why Saltmarsh, using C3's slot. Rehearse it so it ends by itself | The biography question is scored even when it feels casual; F5 and F1 carry the beats; EXP |
| F2 | "Which live games do you actually follow, and what do you notice about how they run their events?" | JD | [generic] | Selection scaffold: pick one game you really follow, one thing about its event calendar or patch notes you notice, and what you would copy or avoid. Mention his theme of patch notes matching what shipped only if you would have noticed it anyway. If no game comes to mind, say so plainly and say what you would look at first | The JD's live-service line asked casually; `[generic]` because it needs no claim about your past; JD |

## Values / principles cheat sheet

The names are Saltmarsh's own, from the values page (Sources, row 1). A values conversation is the second half of the Outage Hour (Sources, row 2).

| Value | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | If the schedule and what players need conflict, players decide | No quoted sentence carries such a conflict. Selection scaffold in B1 and its honest branch; nearest sentence, F1: "I ran the weekly content-drop calendar for our main title for the last two years." |
| Ship the Patch Not the Promise | Announce what exists, not what is hoped for | No quoted sentence carries it. Selection scaffold in B2 and its honest branch; nearest sentence, F4: "Wrote the release checklist our QA team still uses." |
| Leave the Build Greener | Each release should leave the code and the checklist in better shape | F4: "Wrote the release checklist our QA team still uses." Story at that scope, with the slot on later changes in B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live operations from QA. What did QA teach you about running a live calendar that you would want a new producer to learn first?" | Ties to his own path as the listing gives it, and invites the QA conversation your checklist sentence sits in |
| R2 | "A summary of your GDC talk says a live team is judged by how often its patch notes describe what actually shipped. How does the team measure that today?" | Shows you looked at his published work and asks about the measure, not the slogan. Say you saw the listing, not the talk, if asked |
| R3 | "Project Larkspur brings the two titles under one live-ops group. Where does this role sit in that, and are the two titles I would plan for the two on the shared calendar?" | Uses the strategy news and settles a real ambiguity between the JD's per-title wording and a shared calendar |
| R4 | "After the first shared-calendar event in February 2027, what would the post-event review need to show for you to call it a good one?" | Pulls out the KPIs the role owns, and shows you think in reviews |
| R5 | "With the move to a season pass, who owns the trade-offs between events and revenue, and what should a new producer without in-app-purchase experience learn first?" | Raises the gap yourself and asks for the ramp, which also tells you whether onboarding exists |
| R6 | "What would make the first ninety days a clear success?" | A standard diligence question that gets the interviewer's scoring criteria stated aloud |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed design, art, engineering or community teams | Negative you stated, F2 | The plain acknowledgment F2's quote gives: "I've never led a team." C2's slot asks only about coordinating |
| Has worked on a game with in-app purchases, or owned monetization | Negative you stated, F8 | "I haven't worked on a game with in-app purchases." A plan, never a past. No slot |
| Owned the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says the weekly content-drop calendar for the main title. E2's slot stays inside the calendar you ran |
| Owned post-event reviews and the KPIs they report | Inflated form of F3 | F3's quote at its own scope: the material says monthly retention numbers presented. F3's slot asks only what followed those numbers |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope. D3's slot asks how it came about and how QA uses it |
| Owned or analysed player retention | Inflated form of F6 | F6's quote at its own scope. D1's slot asks only how the presented numbers were counted |

## Sources

Provided documents: the JD text and your background, both in your message.

| Query or fetch | Returned |
|---|---|
| Search: Saltmarsh Games values | https://saltmarshgames.com/values |
| Search: Saltmarsh Games interview process Live Operations Producer | https://saltmarshgames.com/careers/interviewing |
| Search: Saltmarsh Games mobile studio news strategy | https://saltmarshgames.com/news/project-larkspur (snippet only; page not fetched) |
| Search: Tobias Wrenfield Saltmarsh Games Head of Live Operations | https://talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only; page not fetched) |
| Fetch: https://saltmarshgames.com/values | Page text: three values by name with their one-line definitions |
| Fetch: https://saltmarshgames.com/careers/interviewing | Page text: the loop is a recruiter call, then the Outage Hour |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Section 10 and B1 to B3: the three principles by name |
| 2. Saltmarsh Games interview process, live operations | yes | Loop structure: one 60-minute session, a tabletop then a values conversation; persona weights and banks A and B follow it |
| 3. Saltmarsh Games strategy and recent news | yes | A4, C1, F8 and R3 to R5: the September 2026 move to a season pass, one shared calendar from February 2027, and per-title event teams replaced by one group. Snippet only, so nothing beyond it is stated |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Reading the interviewer, R1 and R2: a GDC 2026 talk listing, with his prior QA lead role and the talk's argument. Snippet only; the talk itself was not read |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Not established: how the season pass works, the tabletop's actual scenario, and anything about the interviewer beyond the one listing.

## Upgrade menu

- The recruiter's note on the Outage Hour (the scenario, which title, whether the tabletop is time-boxed) → turns the generic scenarios in A1 to A3 into the real format and resets persona E
- Confirmation that Tobias is the hiring manager running your session → confirms every persona weight, which currently rests on that assumption
- Your own answers to the slots in F1, F2, F3 and F5 (any time-limited events, any coordination with the four disciplines, what followed the retention numbers, whether the main title was live-service), said outside a practice drill → those rows and the banks that draw on them move from answer slots to story maps
- A redacted copy of the release checklist and one redacted monthly retention slide → F3, F4, F6 and F7 move from `medium` to `high`
- The text or slides of the GDC talk → the interviewer read comes from the talk itself rather than a listing
- A pasted strategy brief on Project Larkspur and the season pass → A4, C1 and R3 to R5 get more than a snippet, and a grounding section can be added
- A tuesday-dossier.md from a job-underwriter pass → the objection to rehearse comes from confirmed evidence rather than inference, and weak areas carry their own allowed strategy
