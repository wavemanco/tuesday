I'm running the research for your prep pack now, five searches on Kelverton Rail's values, interview process, strategy, the interviewers and a typical JD. After that I'll write the pack.
Web search was refused, so every research target went unanswered. The pack rests only on your message and the recruiter's email as you quoted it. I'm writing it now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-5-denied-281ce30d/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

I built it for a single 60-minute panel with a 15-minute POV, using only what you told me. Web search was refused, so all five research queries failed. The market report didn't reach me, so every Kelverton-specific fact is left for you to fill from it.

- **Prep schedule:** a four-hour weekend plan with the POV first.
- **POV build:** three thesis options, each with the concession you must say aloud, the operator close the recruiter asked for, and an anti-pick.
- **Questions and reverse questions:** 19 questions across six panel personas, plus six reverse questions.
- **Highest-ROI prep:** C1, the "never sold into rail, never carried a direct quota" challenge. It is the one Ross is most likely to press.

Say the word and I'll play Ross on C1, or run you through the POV with a timer. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word.

1. Can you paste the JD, or should I carry on without it?
2. If you grant web search, do you want me to redo the research with a deeper pass? That's up to 6 more searches and 2 more fetches, and several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your POV on where you would take operator partnerships over the next 18 months, no slides. Rest is Q&A, and Ross will push on commercials. All of this is from the recruiter's email as you quoted it.

**Built on:** your message only. No JD text, and the market report was not in what reached me. Web research was refused, so nothing here is drawn from outside research.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Types: VAL is behaviour against published values. EXP is a deep-dive on your own work. JD is the role's stated requirements. CO is company and strategy knowledge. CASE is a live problem.
- No VAL questions are included. Nothing in your material or the recruiter's email describes a values round.
- Guidance is scaffolding, not a script. Anything marked "answer slot" is for you to fill truthfully in the interview, in your own words. Either branch of a slot is a good answer.
- Provenance: grounded means traceable to your message or the recruiter's email. Inferred means derived from a typical source. Generic means a role-family pattern that makes no claim about you or Kelverton.

## Prep triage (four hours)

1. **Hour 1 to 1.5 — the 15-minute POV.** Section 5 is the one graded deliverable. Pick one thesis, write the skeleton, then say it aloud against a timer. Record it once.
2. **One hour — C1, then D1.** C1 is the highest-ROI prep in this pack. Rehearse it aloud until the opening admission sounds boring.
3. **45 minutes — B1 and B2, with D2.** Write your own answer to each of the four number slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Then say them aloud.
4. **45 minutes — full run-through with a friend as Ross.** POV, then A4, C1, B1 and one reverse question.

Everything else in this pack is insurance.

## The fit snapshot

No row is a gate. Nothing in your material or the recruiter's email states a term such as location, pay or right to work.

Requirement quotes are the recruiter's email as you quoted it. Rows F4 and F5 have no JD behind them, so their requirements are plain role-family prose and carry no slot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "the market report their strategy team circulated internally last quarter, which I've read" — your message | medium | [grounded] | transferability | Your material carries an ISV channel's growth and an influenced figure, with nothing inspected behind either. It does not show that the same shape fits rail operators, and the words stay at the quote's scope: "I took it from 6 partners to 40." Keep "influenced" attached to the £4M. Answer slot: the figure raises four probes, namely how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer each in your own words; if you do not know how a piece was counted, say so plainly |
| F2 | "Please land on what it means for the operators themselves." — recruiter email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, and does not say which operators or what the work involved. The words stay there: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: expect a probe on how directly you worked with operators. If you worked with their staff, say how, in your own words; if you did not, or only indirectly, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials." — recruiter email | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" — your message | low | [grounded] | transferability | You stated both negatives, so the plain words are yours: "I've never carried a direct quota, and my revenue figure is influenced revenue." The influenced figure is adjacent to commercial accountability and does not reach it, and the pack adds nothing to close that distance |
| F4 | Senior-level ownership of a partner programme and its relationships — role-family expectation, no source text | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [generic] | none | No gap in the quote's own terms, but nothing is inspected behind it, so expect a probe. Lead with it as written: nine years in partnerships, the last four running the ISV channel |
| F5 | Direct experience selling into rail — role-family expectation, no source text | "Never sold into rail specifically" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then say how you would learn it, as a plan in your own words, never as a past |

## 5. POV build (graded deliverable)

**The brief, quoted:** "no slides needed, just talk us through it", over "the next 18 months", and "land on what it means for the operators themselves."

**Facts to build on, at their own scope:**
- F1: "took it from 6 partners to 40, roughly £4M of influenced revenue"
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F4: "9 years in partnerships, last 4 at a payments company running the ISV channel"

Use at most two of these in 15 minutes, and say each as written.

**Differentiation from the market report.** The report came from their own strategy team, so the panel knows its shortlist. Reciting it scores as homework. In the opening minutes, bring one report item you agree with to show grounding. Then spend the body of the talk on one thesis where you diverge, with your reason, and say what you would not do (the anti-pick). The pack has not seen the report, so the thesis frames below carry blanks to fill from it.

**Three defensible theses.** Pick one. Each has a concession that you must say aloud.

| Thesis | The claim, in the shape you would say it | Mandatory concession | What it means for operators (your close) |
|---|---|---|---|
| T1 Depth over breadth | Concentrate 18 months on a few operator partnerships co-designed around ___ (an outcome the report names), rather than counting partners | Slower headline growth, and more risk concentrated in few relationships | One concrete change an operator's team would see in ___ (name it from the report) |
| T2 A partner network around the product | Extend what operators get through third parties they already work with, using the channel shape from F1 as a starting hypothesis | The 6-to-40 growth came from a different market, so treat it as a hypothesis to test, and more partners add support load | Fewer separate integrations for an operator to manage, stated as a claim you would test with Deepa |
| T3 Measure partnerships by operator outcomes | Hold partnerships to an operator-outcome measure first and a commercial measure second | Outcomes are slower to show and harder to attribute, which is exactly what Ross will press | What the operator can point to at 6, 12 and 18 months |

**The anti-pick.** Choose one thing to say no to in the 18 months and give the reason. A fitting example is "I would not chase partner count as the headline measure." Use it only if it is true to your thesis.

**15-minute shape:**

| Minutes | Content |
|---|---|
| 0 to 2 | Frame, and the one report item you agree with |
| 2 to 8 | Your thesis, and why you diverge |
| 8 to 10 | The anti-pick |
| 10 to 11 | The concession |
| 11 to 14 | What it means for the operators themselves |
| 14 to 15 | Invite the push |

## 8. Persona table

Deepa is a hiring-manager relationship and Ross is a commercial push by the recruiter's own words. A panel blends the top two personas of each member.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A) | Live problems on the POV and the operator close | Highest. The recruiter's email makes the POV a graded 15 minutes, and a future manager buys capability | Clarify, structure, then land the operator close. Challenge one premise politely |
| Data-Driven Prober (bank B) | Pulls the £4M apart | High. "Ross will push on commercials" and F1 is your one figure | Know what you can and cannot say about how it was counted, and say plainly when you do not know |
| Skeptic (bank C) | Rail and quota gaps | Medium to high. F3 and F5 are your stated gaps, and a hiring manager is derisking them | Rehearse C1 until it is boring. Bridge only from what you stated |
| Pressure (bank D) | Time-boxes and tests ownership | Medium. Commercial pushes from a director often arrive this way, but this is my reading, not a stated fact | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator (bank E) | The seam between partnerships and commercial | Lower. Ross sits on the adjacent side of the same deals | Reciprocity framing, and propose seam principles rather than pretending to know the seam |
| Conversational (bank F) | Opener and motivation | Lower weight, but still scored | A 90-second arc built from your own sentences |

The loop is one session as the recruiter described it, so no archetype fallback applies. No values-style round is detected, so there is no values cheat sheet.

## 9. Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Build from section 5, not from this cell. The only claim about your past it needs is at the quote's scope: "I took it from 6 partners to 40." Keep "influenced" attached to the £4M. End on the operator close | The recruiter pre-declared this deliverable (F1), so it is graded. CASE because it scores a thesis, JD because the recruiter's words set the topic |
| A2 | "Before you commit to a plan, what do you need to know about our operators first?" | CASE | [generic] | Clarify aloud before you structure: two or three things whose answers would change your plan, then objective, how you would segment operators, approach, how you would know it is working, main risk. Needs no claim about your past, so the guidance makes none | A Strategist scores clarify-then-structure on a problem from the recruiter's own brief (F1) |
| A3 | "Which operators do you start with, and which do you leave alone for now?" | CASE | [generic] | State your selection criteria first, then apply them. Say what you would deliberately not do yet, which is where the anti-pick in section 5 earns its place. Concede what you cannot judge without data you do not have | A role that owns partnerships has to say no. The anti-pick differentiates from the consensus answer (F1) |
| A4 | "Make it concrete: what does your plan change for an operator?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer from the operator's side of the table with one operator-level change you would defend. Your quote's scope is bus and light rail network planning, so keep to it. Answer slot: expect a probe on how directly you worked with operators. If you worked with their staff, say how, in your own words; if you did not, or only indirectly, say so plainly and stay with the network planning | The recruiter asked for this close (F2), and the Strategist scores whether the answer is in the operator's terms |
| A5 | "Where do you disagree with the market report?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Differentiate, never recite: one item you agree with to show you read it, then one you would weight differently, with your reason. The pack has not seen the report and cannot name items. Answer slot: if you disagree with nothing, say so plainly and name the item you would test first | Their own strategy team wrote it, and F1 shows you hold it. CO because it tests whether you think at their altitude |

### B. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the roughly £4M was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say how it was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words and before they ask. Keep "influenced" in the sentence. If you do not know how a piece was counted, say so plainly and do not reconstruct a method | The headline figure in F1, so it is the likeliest target. EXP because it tests attribution honesty |
| B2 | "Influenced is not closed. How much of it would have happened without you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Start from your own words: it is "roughly £4M of influenced revenue", and "I've never carried a direct quota." Answer slot: say which part was yours and how you know, in your own words; if you cannot separate it, say so plainly and name the weakest assumption you know of. Offer no share | One level deeper on F1, and it presses on F3 |
| B3 | "What did partner number 41 cost to bring on, and when does adding one stop paying?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: expect this probe because Ross will push on commercials. If you tracked what a partner cost to bring on or what each returned, say how you measured it, in your own words; if you did not, or it was not yours, say so plainly and return to the 6-to-40 growth as you said it | The recruiter's commercial warning (F3) makes unit economics likely. The question premises a practice, so the guidance holds a slot that lets it be false |
| B4 | "In 18 months, what number should we hold partnerships to?" | CASE | [generic] | Propose one operator-outcome measure and one commercial measure, say which leads and which lags, concede that attribution is hard, and say what you would need to see before committing to a figure. Needs no claim about your past | Ross's push on commercials meets your thesis here. F3 is why the concession matters |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail and never carried a direct quota. Why should we trust you with commercial conversations with operators?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **Highest-ROI prep in this pack.** Level 1: say the limits first, before they do: "I've never sold into rail specifically, and I've never carried a direct quota." Level 2: say what you bring, at its own scope: nine years in partnerships, the last four running the ISV channel, "took it from 6 partners to 40", and five years of bus and light rail network planning. Describe it and let them draw the inference. Level 3, if they say "that is not rail": answer slot: if the network planning touched rail operators, say where; if it did not, say so plainly and stay with bus and light rail. Level 4, if they ask for your commercial record: concede exactly, "my figure is influenced revenue." Close with how you would learn the commercials as a plan in your own words, never as a past. Hold the quoted facts; do not add to them | This is the objection the whole pack points at (F3, F5). JD because it scores the role's commercial requirement; deepest rehearsal because it will arrive in some form |
| C2 | "Which part of this role will you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Choose from the limits you have stated, name one in your own words, then give the ramp as a plan. Do not pick a weakness that is not yours; if neither of these is the honest choice, say what is | The Skeptic's standard stem; F3 and F5 are where the answer lives |
| C3 | "Why leave payments for rail-tech, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | State your own reason in one sentence, one you would still say after a follow-up. If there is more than one, name the main one first. If no single reason comes to mind, say so plainly, then give the nearest true thing | The Skeptic scores motivation consistency (F4) |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you rather than someone who has already sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause and restate. Concede first: "I've never sold into rail specifically." Then hold on what the quotes carry: nine years in partnerships, the last four running the ISV channel, "took it from 6 partners to 40". Hold through two follow-ups by returning to those facts, never by adding to them | A time-boxed form of the F5 objection, and the pressure bar is hold-then-concede |
| D2 | "That growth from 6 to 40 partners — how much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | Pause, restate, hold the quote's scope: "I took it from 6 partners to 40." Answer slot: say which part was yours and what the rest depended on, in your own words; if others made decisions you did not, say so plainly and stay with what you ran | The attribution probe on F1; the pressure stem "how much of that was actually you" |
| D3 | "Our operators are stretched. Why would they spend time on partnerships rather than running trains?" | CASE | [generic] | Answer in the operator's terms: name what they would stop worrying about, tie it to the close from section 5, and concede that some partnerships will cost operators time and say how you would limit that. Needs no claim about your past | Tests the operator close the recruiter asked for (F2) under pressure |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and commercial sit side by side. Where's the seam, and what happens when we disagree about a deal?" | JD | [generic] | Propose seam principles rather than claiming to know the seam. Show what you bring Ross's team as well as what you need. Needs no claim about your past | Ross is on the adjacent side of the same deals (F3) |
| E2 | "How do you handle credit when a deal spans partnerships and sales?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: if you have shared credit with sales colleagues, say how, in your own words; if the arrangement was different, or none existed, say so plainly and return to "roughly £4M of influenced revenue" as you said it | An influenced figure invites a credit question (F1); the peer stem on credit |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey from transport consulting into partnerships." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc with the beats your quotes state: five years in transport consulting on bus and light rail network planning, then nine years in partnerships, the last four running the ISV channel. Answer slot: why you moved, in your own words | The opener is still scored (F2, F4) |
| F2 | "What drew you to Kelverton?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Anchor your reason to one thing you read in the report, in your own words. The pack has not seen the report and supplies no fact about Kelverton. Answer slot: if nothing in it drew you, say so plainly and say what did | A chatty question that scores homework (F1) |

### Requirement coverage

| Requirement | Questions |
|---|---|
| POV on operator partnerships over 18 months | A1, A2, A3, A5, B4 |
| What it means for the operators | A4, D3 |
| Commercials | B1, B2, B3, B4, C1, C2, D1, E1, E2 |
| Senior partnerships ownership (role-family) | C3, D2, F1 |
| Rail selling (role-family) | C1, C2, D1 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would you want operators to say about Kelverton's partnerships 18 months from now?" | Hands you the operator close and shows you think in the operator's terms |
| 2 | "How are partnerships measured today, and who decides when a relationship is working?" | The commercial angle Ross will care about, asked as a collaborator |
| 3 | "Ross, what could I do in my first month that would genuinely help your team?" | The reciprocity question; it moves the seam conversation from threat to help |
| 4 | "What would a strong first 90 days look like to each of you, and would you describe it the same way?" | Surfaces any gap between the future manager and the commercial view |
| 5 | "Which operator partnership do you consider the strongest today, and what made it work?" | Invites a real story and gives you material for the next round |
| 6 | "Deepa, what would make you say in a year that hiring me was right?" | Closes on the manager's own scoring sheet |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota, or owned a commercial number | Negative you stated, F3 | "I've never carried a direct quota." No slot |
| Has sold into rail | Negative you stated, F5 | "I've never sold into rail specifically." No slot |
| Knows train operating companies from the inside | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says bus and light rail network planning. A4's slot stays inside that |
| Generated or closed £4M of revenue | Inflated form of F1 | "Roughly £4M of influenced revenue", with the word kept |
| Designed the channel, or personally brought on the new partners | Inflated form of F1 | "Took it from 6 partners to 40", at its own scope. D2's slot asks only which part was yours |

## 14. Sources

Provided documents: your message, which quotes the recruiter's email. The market report was not in what reached me, so nothing here draws on it.

Searches sent, all refused (web search permission was not granted):
- "Kelverton Rail values" — refused
- "Kelverton Rail interview process partnerships manager" — refused
- "Kelverton Rail strategy news train operating companies scheduling software" — refused
- "Deepa VP Partnerships Kelverton Rail" — refused
- "Senior Partnerships Manager rail technology job description train operating companies" — refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values cheat sheet, but none is built because no values round is detected |
| 2. `Kelverton Rail interview process` | unavailable | Would have checked the loop; the recruiter's email already fixes the session, so persona weights rest on it |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have fed the CO questions and a grounding brief; A5 and F2 are built around the report instead |
| 4. `Deepa Kelverton Rail` and Ross | unavailable | One query for Deepa was refused; I sent none for Ross after that. The interviewer read is absent |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have turned F4 and F5 into inferred rows quoting a JD; they stay plain role-family prose |

## 15. Upgrade menu

- The market report's text, pasted → a grounding brief in the report's own vocabulary, a sharper section 5 differentiation, and named items for A5 and F2
- The JD text → F4 and F5 become grounded rows quoting the JD, and any requirement not yet covered gets a question
- Your own answers to the slots in F1, F2 and B1 to B3 (how the £4M was counted, whether you worked directly with operators, which part of the 6-to-40 growth was yours) → those rows upgrade from slots to story-mapped answers
- Web search permission → targets 1 to 5 above can be re-run
- Deepa's and Ross's public profiles, or text you paste from them → an interviewer read and a reverse question tied to each one's path
- A `tuesday-dossier.md` from earlier work → verified evidence and a sourced prohibited-claims list in place of the locally built one
