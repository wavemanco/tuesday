I'll read the reference files the skill requires before writing anything.
The pack is written and saved. Here it is.

Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-6-denied-d5be448a/larkfield-systems_engineering-manager_interview_pack.md`. It covers all three rounds in one file. It has a shared fit snapshot, per-round persona weights, 10, 11 and 9 questions per round, reverse questions for each round, and a prohibited-claims list.

- **Research didn't run.** The host refused all three web searches, so nothing about Larkfield's values, strategy or interview process is researched. Monday's values questions are themed from the recruiter's description, there's no values cheat sheet, and the company and strategy questions are labeled generic.
- **The question to rehearse most:** TS1, the jump from "a team lead of 6" to two squads and eleven engineers. It comes back in all three rounds: as a skeptic probe on Tuesday, from the staff engineers' side on Thursday, and as a time-boxed "why you" on Monday.
- **Your own words only:** The pack quotes only your four sentences about yourself. Where it needs more, such as how the 60% was counted or whether you've partnered with hardware, it leaves an answer slot for you to fill.

I can run a live drill on TS1 with me as the Director of Engineering, or on any other question. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

Has the recruiter sent any per-round details, such as focus areas, a take-home, or the interviewers' names? And can you paste the full JD and your CV, or tell me to go without them?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack (loop mode): Engineering Manager, Larkfield Systems

Candidate: Yusuf. Three scheduled rounds, in order:

| Round | When | Who | Relationship |
|---|---|---|---|
| 1 | Tuesday, 45 min | Director of Engineering (would-be boss) | Hiring manager |
| 2 | The Thursday after, 60 min | Two staff engineers and a product manager | Panel |
| 3 | The following Monday, 30 min | VP Engineering, described by the recruiter as "values and leadership philosophy" | Skip-level, values-style |

Built on this assumption: no CV, no full JD text and no interviewer names were supplied, and web research was refused (see Sources), so the pack rests on what you wrote in your message. Everything about Larkfield beyond your message is labeled `[generic]` or absent.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and leadership philosophy, not generic virtue |
| EXP | Whether the claims about your work survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude (generic here: no company research ran) |
| CASE | Structure and reasoning on a live problem from the role |

Question IDs read round, persona, number: T is Tuesday, H is Thursday, M is Monday. Persona letters: S Skeptic, C Case/Strategist, R Conversational, E Peer Evaluator, D Data-Driven Prober, V Values/Behavioral, P Pressure. Answer slots are instructions for the interview, not questions for this chat.

## Prep triage

You gave a two-week window and three dates, not hours, so this is an order of work, not an hour count.

1. Before Tuesday: TS1 (the pack's highest-ROI rehearsal, see below), then TS4 and TS2.
2. Before Tuesday, in parallel: your two figures. TS4 and TR2 rehearse the 60% and the 40 interviews, and the same answers return in HD1, HD2 and MV3.
3. Before Thursday: HE1 and HV1, because the panel will arrive at your scale jump from the peer side.
4. Before Monday: MV1 and MP1. They are TS1 in a different register.
5. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

The JD is the role description you pasted; the evidence is four sentences from your message. The JD as given states no term such as location, travel or a credential, so no row is a hard gate; the upgrade menu asks for the full text in case it holds one.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — JD as you pasted it | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material says a team lead of six, with nothing inspected behind it, and says nothing about two squads or device-management. The words stay at that scope: "I was a team lead of six." Answer slot: the JD's two squads make a probe on leading more than one group likely. If you led more than one group at once, or worked through other leads, say how, in your own words; if not, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" — JD as you pasted it, the delivery element | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The sentence carries a reliability quarter, roadmap pressure and a drop that came after, with nothing inspected behind it. It does not say who set the roadmap, what the quarter displaced, or how the 60% was counted. Answer slot: if you know how the 60% was counted, say it; if you do not, say so plainly. Name the assumption behind it you would defend least, and which part was yours, in your own words |
| F3 | "own delivery, hiring and growth for 11 engineers" — JD as you pasted it, the hiring element | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on the 40. Lead with the loop in the quote's own terms: you run it, for backend roles |
| F4 | "own delivery, hiring and growth for 11 engineers" — JD as you pasted it, the growth element | none given | none | [grounded] | discovery | Your material is silent on growing engineers, so the pack writes nothing about it. Answer slot: if any part of leading six involved helping engineers grow, say what was yours and what happened, in your own words; if none did, or it sat with someone else, say so plainly and stay with the team of six |
| F5 | "partner with hardware and product on roadmap" — JD as you pasted it | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | discovery | You stated you never owned a hardware-adjacent roadmap, so those words are yours: "I've never owned a hardware-adjacent roadmap." The requirement is partnering, and your material does not say whether you have partnered with hardware or product. Answer slot: if you worked with either on roadmap items, say what part was yours; if not, say so plainly |
| F6 | "industrial IoT" — role title line as you pasted it, the domain element | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [grounded] | discovery | The sentence names your current domain and says nothing about device, fleet or embedded-adjacent work. Answer slot: if you have worked on systems that manage devices in the field, say what and how close; if not, say so plainly and say how you would learn the domain |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Lead two squads building device-management services | TS1, TC1, TC2, HD3, MC1, MC3 |
| Own delivery | TS4, TC3, HV1, HD1, MV2, MP2, MC2 |
| Own hiring | TR2, HD2, MV3 |
| Own growth for 11 engineers | TS5, HE4, MV1, MV4 |
| Partner with hardware and product on roadmap | TS2, TC2, HV2, HV3, HV4, MC3 |
| Industrial IoT domain | TS3, HD3, MC1 |

## Persona weights by round

### Round 1: Tuesday, Director of Engineering

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the jump from a team of six to two squads, the domain switch, and why now | Highest. Hiring-manager prior is Case/Strategist plus Skeptic, and your fit snapshot has its widest gaps at F1, F5 and F6, which is where a would-be boss derisks | Rehearse the scale-jump objection until it is boring: the sentence at its own scope, the limit said plainly, a ramp plan stated as a plan |
| Case/Strategist | A live problem on their roadmap: first 30 days, a date that slips | Second, from the hiring-manager prior. Your two rounds that follow are less case-led, so this is where case practice pays | Clarify, then objective, then approach, then risks; think aloud; challenge one premise |
| Conversational | The biography and "what do you do on hiring today" | Lowest but scored: a 45-minute round opens with it | A 90-second arc built only from the quoted sentences |

### Round 2: Thursday panel

Assumption: the staff engineers are senior ICs in the org you would support, and the PM is a cross-functional partner. If a staff engineer would report into you, tell me and the weights shift.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between an EM and staff engineers; credit; disagreement | Highest. Panel rule blends each member's top personas, and two of three members are engineers who will price what you cost their work | Reciprocity framing; propose seam principles instead of claiming to know the seam |
| Data-Driven Prober | Staff engineers pulling on your two figures and on how you judge a design | Second. Technical specialists prior is Prober plus Pressure, and your message gives two figures a prober can grab | Say what you know of how each number was counted, and say plainly where you do not |
| Values/Behavioral | The PM asks for stories about product and delivery tension | Third. Cross-functional prior is Values/Behavioral plus Conversational, and the JD names product partnership | A story from your quoted sentences where one carries it, a selection scaffold where none does |

### Round 3: Monday, VP Engineering

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Leadership philosophy; stories that show how you lead | Highest. The recruiter's own description of this round is "values and leadership philosophy" | Stories where the hard truth landed, "we" for context and "I" for contribution; where your material shows no ending, say so |
| Case/Strategist | Altitude questions: what to build, what not to | Second. Skip-level prior is strategy-heavy, but 30 minutes caps it | Think aloud; use the company's vocabulary only where you have read it |
| Pressure | Time-boxed "why you" and a challenge to the reliability quarter | Third. Skip-level prior includes Pressure, and the scale jump is the natural target | Pause, restate, hold through two follow-ups, concede one specific thing |

## Question banks

Round 1 bank assumes the Director asks about your fit first and your thinking second.

### Round 1, Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| TS1 | "You've been a team lead of six. This role is two squads and eleven engineers. What's different, and how would you handle it?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | The pack's highest-ROI rehearsal. Hold only what the sentence carries: "I was a team lead of six." Concede one thing from the numbers: the team you led was six and this role is eleven across two squads. Then a ramp plan stated as a plan, never a past: what you would ask each squad first and whom you would meet in the first weeks. Answer slot: if you led more than one group at once or worked through other leads, say how; if not, say so plainly and return to the team of six. Follow-ups are listed below the table | F1 is the widest gap against the JD's first clause, so this arrives in some form in all three rounds; JD because it scores the stated requirement |
| TS2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick the weakness your own sentence supports and say it plainly: "I've never owned a hardware-adjacent roadmap." Then how you would close it, as a plan: who you would ask and what you would read first. Do not volunteer a second weakness the question did not ask for. Answer slot: if you have worked alongside hardware or product teams on roadmap items, say what part was yours; if not, say so plainly | F5 holds the stated negative and the JD names hardware partnership; JD because it scores a listed responsibility |
| TS3 | "Why leave payments for industrial IoT?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Selection scaffold: your reason has to be a true one that points at the JD's own words, device-management services or partnering with hardware, and not at the role being a step up. If your honest reason is mostly about the management step, say so plainly, then give what draws you to this domain, or how you would find out | F6 shows nothing carrying the domain switch; JD because motive is scored against the role |
| TS4 | "Your on-call burden came down. How much of that was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold: "I pushed a reliability quarter through against roadmap pressure, and the on-call burden dropped 60% after." The sentence says after, so do not say the quarter caused it. Answer slot: say how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, in your own words; if you do not know how it was counted, say so plainly | F2 holds the one figure of your impact; EXP because it tests attribution |
| TS5 | "Tell me about a time you helped an engineer grow." | EXP | [generic] | Open prompt, theme from the JD's growth clause. Selection scaffold: pick someone where you can name what they could not do before and what you did, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the team of six, or how you would approach growth with eleven engineers | F4 is silent on growth and the JD owns it; EXP because it asks for an instance |

Deepest rehearsal, TS1, three follow-up levels:

- Level 1, "What changes at two squads?" Give the numbers, then the plan.
- Level 2, "Who do you lean on?" Slot: if you worked through other leads, say how; if not, say so plainly and name who you would ask here, as a plan.
- Level 3, "What if it isn't working in ninety days?" Say what you would look at and who you would tell, as a plan. Do not claim a past.

### Round 1, Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| TC1 | "You inherit two squads building device-management services. What do you need to know first, and what do you do in the first thirty days?" | CASE | [generic] | Clarify before structuring: what each squad owns, how delivery is tracked today, how hardware dates constrain the software, who the hardware and product counterparts are, whether any of the eleven roles are open. Then objective, approach, risks, how you would know it was working. Challenge one premise, for example whether the two squads should keep their current split. The question needs no claim about your past, so the guidance makes none | Live problem built from the JD's first two clauses; `[generic]` because it is a pattern, not a fact about this team |
| TC2 | "Hardware has a fixed ship date, your squad's service is behind, and product wants scope held. What do you do?" | CASE | [generic] | Name the decision first, which is what gets cut or moved. Ask what is fixed and what is negotiable, who can authorize a trade, what the failure cost is on each side. Close with how you would tell hardware and product, and when. Say you would want to learn how this team already handles it | The JD pairs hardware and product on the roadmap, and F5 is the gap this probes; CASE because it is a live trade-off |
| TC3 | "A reliability problem is hurting customers but the roadmap is committed. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure the decision first: severity, cost of delay, what the commitment protects, who can release it. You may point at the sentence at its own scope, "I pushed a reliability quarter through against roadmap pressure", and stop there. Answer slot: expect a probe on what the roadmap gave up; if you know, say what, in your own words; if nothing was traded, say so plainly and stay with the quarter | The question mirrors F2's story, so the interviewer can test the story as a method; CASE with EXP content |

### Round 1, Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| TR1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc with three beats the sentence states: nine years in engineering, three as a team lead of six, now at a payments company. A fourth beat, why this role, is your own reason: see TS3, and keep it to one sentence | F1 and F6 hold the biography; EXP because it checks the story against the record |
| TR2 | "What do you do around hiring today?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | "I run our hiring loop for backend roles." Answer slot for the figure: say how the 40 was counted, whether it is interviews you gave or interviews the loop held, what it is sensitive to, and the assumption you would defend least, in your own words; if you do not know, say so plainly | F3 is the cleanest evidence for the hiring clause, and a figure draws the defend-the-number probe; EXP because it tests the figure |

### Round 2, Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| HE1 | "Where's the seam between an engineering manager and a staff engineer on technical decisions, and what happens when we disagree?" | JD | [generic] | Propose principles, not a claim to know this team's seam: who decides what is built and when, who decides how, how a disagreement gets escalated and when it is not worth escalating. Ask how they work today and say you would start by following that. No claim about your past | Panel prior and F1: they will price what a new manager costs their work; JD because it scores the people-leadership clause |
| HE2 | "Tell me about a time you disagreed with an engineer about technical direction." | VAL | [generic] | Open prompt, theme from the peer-disagreement stem. Selection scaffold: pick a time with a named stake, where you did not fold and the working relationship was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The pack's counter-strategy for this persona is spine and tact together; VAL because it scores behavior, not content |
| HE3 | "Our work spans software and hardware. How do you handle credit when work spans teams?" | VAL | [generic] | Principle first: credit goes where the work was, named specifically, and said in the room, not only to the manager. "We" for context and "I" for your own contribution. No claim about your past | A credit probe is a stock Peer Evaluator stem; VAL because it scores partnership behavior |
| HE4 | "On-call load is real for our engineers. How do you think about it?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The sentence at its own scope: you pushed a reliability quarter through against roadmap pressure and the on-call burden dropped after. Then how you think about it going forward, as a view. Answer slot for the figure: how it was counted and which part was yours, in your own words; if you do not know how it was counted, say so plainly | F2 is your strongest story with engineers; EXP because it asks the candidate to tie a view to a record |

### Round 2, Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| HD1 | "Walk me through how the 60% was counted. Which assumption behind it would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say the sentence, then the slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words. If you do not know how it was counted, say so plainly: naming your weakest assumption before they do converts a gotcha into credibility. Do not say the quarter caused the drop | F2's figure is the one a staff engineer will pull; EXP because it is defend-the-number |
| HD2 | "How do you know your hiring loop is any good?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Return to the sentence: "I run our hiring loop for backend roles." Answer slot: the JD makes hiring a probe, so expect a question on how the loop's quality is judged. If you use any measure of it, say what, in your own words; if you use none, say so plainly and describe how you run the loop | F3 holds a figure and an unmeasured process; EXP because it tests whether the claim has evidence |
| HD3 | "How do you evaluate a design in a domain that's new to you?" | CASE | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Method first: ask for the failure modes, the rollout and rollback plan, what happens when a device is offline or half-updated, who is on call. Say you would lean on the staff engineers in the room for domain depth. Answer slot: if you have worked on systems that manage devices in the field, say what and how close; if not, say so plainly | F6 is the domain gap and staff engineers test it; CASE because it asks for a method |

### Round 2, Values/Behavioral (product manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| HV1 | "Tell me about a time you held a line on engineering quality when the roadmap pushed the other way." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the sentence: a reliability quarter, roadmap pressure, pushed through, and the on-call burden dropped after. Answer slot: the JD pairs product with the roadmap, so expect a probe on who pushed the other way and how that relationship ended up; if you know, say it in your own words; if there was no one specific, say so plainly and stay with the quarter | The PM will test whether you can say no and keep the relationship; F2 carries the story; VAL |
| HV2 | "Tell me about a time you and a product partner disagreed about priorities." | VAL | [generic] | Open prompt, theme from the JD's product partnership clause. Selection scaffold: a named disagreement, what each side wanted, how it got settled and the relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F5 does not show product partnership; VAL because it scores behavior |
| HV3 | "How do you tell a product manager something won't make the date?" | VAL | [generic] | Open prompt, theme from the unpopular-truth stem. Selection scaffold: pick a time the news landed and the plan changed. If none comes to mind, say so plainly, then say how you would do it: early, with the options, with what you need decided and by when | A date slipping against a hardware date is the main source of friction the JD implies; VAL |
| HV4 | "How do you want to work with product and hardware on the roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Answer as how you would work, not as a past. If hardware comes up, say plainly: "I've never owned a hardware-adjacent roadmap." Then how you would start: a standing conversation on dates and dependencies. Answer slot: if you have partnered with either on roadmap items, say what part was yours; if not, say so plainly | The JD's last clause is a listed responsibility, and F5 is its row |

### Round 3, Values/Behavioral

No published Larkfield values were in hand, so these are themed from the recruiter's words ("values and leadership philosophy") and the JD, not from value names.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| MV1 | "What's your leadership philosophy?" | VAL | [generic] | Selection scaffold: two or three principles you actually hold, each tied to one real episode in your own words. If the reliability quarter reflects one of them, you may say so. If no principle comes to mind with an episode behind it, say so plainly, then give the nearest thing your material carries, or how you would lead | The recruiter named leadership philosophy as this round's subject; VAL |
| MV2 | "Tell me about a time you made an unpopular call for the long term." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The beats the sentence states: a reliability quarter, roadmap pressure, pushed through, the on-call burden dropped after. Answer slot: if you know whose pressure it was and what they said, say it, in your own words; if you do not, say so plainly and stay with the quarter. The hard truth is the part that landed, so say what changed | The unpopular-truth stem fits F2 exactly; VAL |
| MV3 | "Tell me about a time a hiring decision didn't go as you expected." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Open prompt, theme from the JD's hiring clause. Selection scaffold: one decision, what you expected, what happened, what you changed. If no such time comes to mind, say so plainly, then return to the sentence: "I run our hiring loop for backend roles" | F3 holds hiring; a VP checks judgment about people, not the count |
| MV4 | "What will you do differently as an engineering manager than you did as a team lead?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Start from the sentence: you were a team lead of six. Then what you would do differently, as an intention. Answer slot: the JD makes growth part of the job, so expect a probe on what the people side of leading six involved. If you ran growth conversations or reviews, say what; if that sat with someone else, say so plainly | F1 and F4: the lead-to-manager step is where leadership philosophy becomes concrete |

### Round 3, Case/Strategist

Without company research these stay generic: do not assert Larkfield facts you have not read.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| MC1 | "What makes device management hard, and what should engineering be great at here?" | CO | [generic] | Think aloud from first principles: devices are offline, long-lived and updated in the field, so rollout safety and observability matter. Then ask the VP what they see as the hardest part for Larkfield. Make no claim about Larkfield's strategy | CO that goes generic without research, which is the honest cost; the question tests altitude |
| MC2 | "You'd run two squads in a company of about 600. How do you decide what not to build?" | CASE | [generic] | Criteria first: customer impact, hardware dependency, reliability cost, team capacity. Then who you would involve in the call. Say you would want the VP's priorities before applying any of it | Roadmap ownership is in the JD; CASE |
| MC3 | "Hardware and software ship on different cadences. How does that change how you run a squad?" | CASE | [generic] | Clarify the cadences first, then dependencies, buffers, what you would track weekly, and how you would communicate a slip. Ask the VP how the two cadences are managed today | The role sits between hardware and product; CASE |

### Round 3, Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| MP1 | "Sixty seconds: why you rather than someone who has already run two squads?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." and "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause, restate, then hold on what your sentences carry: you run the hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Concede one specific thing in your own sentence: "I've never managed managers and I've never owned a hardware-adjacent roadmap." Then stop. Do not claim equivalence with someone who has done it | This is TS1 in a pressure register; F1, F3 and F5 hold the two strengths and the concession |
| MP2 | "You pushed a reliability quarter through against roadmap pressure. Isn't that just a team lead ignoring the business?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold through two follow-ups at the sentence's own scope: you pushed a reliability quarter through against roadmap pressure and the on-call burden dropped after. Concede only what is true: the quarter had a cost to the roadmap. Answer slot: if you know what the roadmap gave up, say what, in your own words; if you do not, say so plainly | The devil's-advocate version of F2; VAL because it scores composure and judgment together |

## Reverse questions

### Round 1, Director of Engineering

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does success look like for these two squads at six and twelve months, and what do you want from me in the first ninety days?" | It asks your future boss to define the bar, which they will measure you against anyway |
| 2 | "Where is delivery most fragile today, between hardware dates and software, or inside the squads?" | It shows you already see the seam the JD names |
| 3 | "How is the roadmap decided today between you, product and hardware, and where would you want me to push?" | It positions you as a partner, not a taker of orders |
| 4 | "What support does a new manager get on hiring and growth for eleven engineers?" | It signals you take the people side seriously |
| 5 | "What would make you hesitate to hire me, and is there anything I could address now?" | It surfaces the scale-jump objection in the room, where you can answer it |

### Round 2, panel

| # | Question | Why it lands |
|---|---|---|
| 1 | "Where do you want an engineering manager to stay out of technical decisions, and where to step in?" | Staff engineers hear it as respect for their lane |
| 2 | "What is the on-call experience like today, and what would you fix first?" | It ties to your strongest story without claiming it |
| 3 | "How do you and engineering handle it when a hardware date moves?" | The PM answers from where they sit, and you learn the real friction |
| 4 | "What could a new manager do in their first month that would genuinely help your work?" | Reciprocity question: it turns an evaluation into a collaboration |
| 5 | "How do you want to hear bad news about a date?" | It tells the panel you plan to deliver it early |

### Round 3, VP Engineering

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does good engineering leadership look like here in practice, and what is a recent example?" | It asks for the philosophy in action, in a round about philosophy |
| 2 | "Where do engineering managers at Larkfield tend to struggle, and what helps?" | It invites candor and tells you what the VP watches for |
| 3 | "How do you decide when a manager is ready to take on more?" | It shows interest in the next step without claiming you have taken it |
| 4 | "What would need to be true of my first six months for you to feel this was the right hire?" | It gets the VP's bar in their own words |
| 5 | "What has changed in how Larkfield thinks about engineering in the last year?" | It shows curiosity at the company's altitude without reciting facts you have not read |

## Prohibited claims

Built locally from the fit snapshot before the banks were written. No dossier was present.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers | Negative you stated, F5 | The plain acknowledgment from your sentence: "I've never managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment from your sentence: "I've never owned a hardware-adjacent roadmap." The partnering slot in F5 asks only what, if anything, you did alongside hardware or product |
| Led two squads, or eleven engineers | Inflated form of F1 | F1's quote at its own scope: a team lead of six. The limit is the pack's observation: your material says six, not two squads |
| The reliability quarter caused the 60% drop | Inflated form of F2 | F2's quote at its own scope: the drop came after the quarter. The limit is the pack's observation: the sentence says after, not because |
| Owned hiring end to end | Inflated form of F3 | F3's quote at its own scope: you run the hiring loop for backend roles. TR2 and HD2 slots stay inside the loop |

## Sources

Provided documents: your message (the role description, the three rounds and your background). No CV, no full JD text, no dossier.

Searches sent, all refused by the host:

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have moved the values cheat sheet (section 10) and value-named VAL questions; both are absent, and Monday's VAL bank is themed from the recruiter's words instead |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have checked the loop and case formats; the loop itself is established by your own words, which name three rounds with who runs each, so persona weights stand |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have grounded the CO and CASE questions in current strategy; they are labeled `[generic]` for that reason |
| 4. `interviewer name Larkfield Systems` | n/a | No names were given, so no query could be formed; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | The role description you pasted fixes the fit snapshot's requirement rows and the JD-tagged questions |

## Upgrade menu

- Interviewer names, or the recruiter's note on each round → an interviewer read, persona weights adjusted from their public footprint, a tailored reverse question per round, and a build section for any take-home or presentation the recruiter has announced
- The full JD text → the requirement rows quote the JD instead of your summary, the coverage table tightens, and any term it holds (location, travel, a credential) is checked as a gate
- Your CV → F1 to F6 evidence can quote it, and rows with `none given` such as F4 may upgrade
- Your answers to the answer slots on F1, F2, F4, F5 and F6, said outside a drill → those rows gain your own sentences, and the guidance on TS1, TS5, HD3 and HV4 turns from slots into story maps
- Permission for web search, or the pasted values page and a strategy brief → the values cheat sheet, value-named VAL questions, and CO and CASE questions grounded in Larkfield's current strategy; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can follow if you want it
- A tuesday-dossier.md from an earlier evidence review, if you have one → verified evidence and allowed strategies for your weak areas, replacing the locally built prohibited list
