I'll read the reference files the skill requires before writing anything.
I've read the spec. Your inputs fix everything a search could change: the loop and its three rounds, the values, the strategy and the JD. So I'll build the pack from them and send no searches.
I'll make these renames with targeted edits, because a blanket replace would also hit the case-bank question IDs.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-canned-e61a1deb/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a loop pack for your three rounds on 20 November, with a shared fit snapshot and a mini-pack per round. Your evidence is the sentences in your message, since there's no CV file, and I ran no searches because your JD, values, recruiter email and strategy summary already covered what a search would have.

The pack names D1 as the highest-ROI prep. D1 is the manager-round question "you've never worked in a contact centre, and this role owns the process across it." D4 (presenting above regional level) is the runner-up.

Say the word and I'll play the Head of Member Services on D1, with live follow-ups, then give you feedback against that question's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack — Member Experience Lead, Ashgrove Credit Union

**For:** Dara
**Loop day:** 20 November 2026, nine days from 11 November 2026. Three rounds, so this is a loop pack: one shared fit snapshot and grounding brief, then a mini-pack per round.
**Interviewers:** only their roles are known. Round 1 is the recruiter. Round 2 is the Head of Member Services, who would be your manager. Round 3 is a panel of two branch managers. No names are assigned yet, so there is no interviewer read.
**Highest-ROI prep in the pack:** D1, the contact-centre question in the manager round. Your own message names that gap and the JD's first requirement ends with the contact centre. Runner-up: D4, presenting above regional level.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Every question carries one type tag.

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values, not general virtue |
| EXP | Whether a claim about your own work survives follow-up, and what was actually yours |
| JD | A stated responsibility or requirement in the posting |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | A live problem from the role, scored on structure |

- Guidance is scaffolding for a spoken answer, not a script. Say it in your own words.
- An **answer slot** is an instruction for the interview. It marks where the interviewer is likely to probe and where only you know the answer. Each slot has two honest branches. Either branch is a good answer. The second always allows that the thing never happened or was not yours.
- Anything about your past rests on a sentence from your message, quoted in the Provenance column. Where no sentence carries a story, you get selection criteria and an honest fallback, not a story.
- Provenance labels: `[grounded]` is traceable to what you gave me. `[inferred]` is this pack's derivation, with the basis named. `[generic]` is a pattern with no claim about Ashgrove or about you.

## Fit snapshot (shared by all three rounds)

No requirement in the JD is a gate, as the suite defines one. A length-of-experience line is graded like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's line makes a probe on how far your part went likely. Say which parts of handling the log were yours, in your own words; if the log was a record and the handling sat elsewhere, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your sentence says a monthly complaints spreadsheet your regional manager uses; it does not show what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet showed. Say what it counted, in your own words; if volumes or resolution times were not in it, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Your words stay at the tellers: "I trained new tellers on our escalation script." Answer slot: the JD says supervisors, so expect a probe on whether you have coached anyone at supervisor level or alongside you. If you have, say who and what part was yours; if all of it was teller training, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not establish any work with digital teams or self-service journeys; that is the pack's observation, not words for you. Answer slot: if you have worked with a digital or app team, or on any self-service flow, say what and what part was yours, in your own words; if you have not, say so plainly and say what you would want to learn from the digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on the stated requirement, though it is a line with nothing inspected behind it, so expect a probe. Lead with the sentence in its own terms: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your sentence says formal complaints log; it does not show which rules governed it. Answer slot: the JD says regulated, so expect a probe on what the log had to meet. If you know which rules applied and what they asked of you, say so in your own words; if you do not know, or none applied to your log, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. The sentence is about level only, so nothing is claimed about presenting at regional level |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your sentence says spreadsheet, not Excel, and the words stay "spreadsheet" unless it was. Answer slot: the JD says Excel, so expect a probe on the tool and on what the spreadsheet did. If it was Excel, say so and describe what you built, in your own words; if it was another tool, say so plainly and stay with what you built |

## Grounding brief (shared)

From the 2026 strategy brief Ashgrove published in July 2026, as you summarised it. It is about four months old. The Q1 2027 launch is close to your interview date, so listen for whether people describe it as launched or still coming.

| # | From the brief | Provenance | Reading for this role | Provenance of the reading |
|---|---|---|---|---|
| S1 | "move 40% of member service to digital channels by 2028" | [grounded] | Complaints will arrive through more channels, and the JD's self-service line sits on this. Used in A2, A4, E1 | [inferred] |
| S2 | "consolidate eight branches into five hubs over 2027" | [grounded] | Changes where complaints arise and who handles them. It sits beside the value Neighbours, Not Numbers, and question G3 rehearses that. Whether the panel raises it is unknown | [inferred] |
| S3 | "launch a small-business lending product in Q1 2027" | [grounded] | A new product is a new place for complaints to arise. Low weight, a reverse-question topic at most | [inferred] |
| S4 | "the main competitive pressure is app-only banks" | [grounded] | App-only banks are the benchmark members may hold Ashgrove's self-service against. Used in A4 and E1 | [inferred] |

The brief is published, so other candidates may have read it. Bring one item to show you read it, then your own view with a concession. Do not recite it.

## Persona table (shared; weights per round)

| Persona | How it shows up in this loop | Likelihood by round, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly first screen that is still scored | R1 high: the recruiter's "30 minutes with me" is a recruiter-screen prior. R2 and R3 low | A 90-second arc for the journey question (A1); treat casual JD questions as scored (A3, A4); use the reverse-question slot |
| Skeptic | Quiet probing of the contact-centre and senior-leader gaps | R2 high: the manager prior is derisking gaps, and the recruiter says this is "the Head of Member Services, who would be your manager". Your message names two gaps they can go to. R1 light, a knockout check. R3 low | Rehearse D1 until it is boring; concede specifically; never borrow experience you have not stated |
| Values / Behavioral | Open prompts scored against Ashgrove's four values | R3 highest: "The panel is also the values round — they score against the four values." R2 medium-high: the recruiter says it is "mostly behavioural". R1 low | One selection scaffold per value, with the honest fallback ready. Use "we" for context, "I" for your contribution |
| Case / Strategist | The 20-minute complaint-escalation case, plus strategy questions | R3 medium: "including a 20-minute case on a complaint escalation". R2 low-medium: the manager prior is case-led, but "mostly behavioural" pulls it down | Clarify, objective, segments, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Peer Evaluator | Seam, collaboration and credit probes from branch managers | R3 medium: the JD has you coaching "branch supervisors on escalations", so branch managers sit next to the people you would coach. That is an inference about what the panel will care about | Offer seam principles, not a claim to know the seam. Lead with what you would give them |
| Pressure | Interruptions and "how much was you" | Low in every round: nothing in the recruiter's email points to a stress format. D3 and D4 carry the stems in case the manager goes there | Hold-then-concede: hold the sentence you can back, concede the specific gap |
| Data-Driven Prober | Inputs and denominators behind a figure | Low: your message gives no headline figure. The nearest artifact is the spreadsheet (A3, D3) | Say what it counted and what you do not know about how any figure was counted |

---

# Round 1 — Recruiter, 30 minutes

Weights: Conversational high, light Skeptic. The risk is treating it as unscored.

### A — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey. How did you get here, and why this role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Story-mapped on F6 in three beats. The first two are the sentence's: six years in retail banking, the last three as a branch supervisor. Tell them in your own words in about 60 seconds. The third beat, why this role, is yours and the pack does not write it. Anchor it on a JD line you actually want, only if that is true for you. Stop at 90 seconds | The opener in a friendly screen, and scored. F6 is the row it rests on. EXP because it tests the one line the whole loop leans on |
| A2 | "What do you know about us, and what made you apply?" | CO | [grounded] "Never worked in a contact centre" | Bring one item from the brief, for instance the 40% digital target by 2028 (S1). Then give one view of your own on what it means for complaints. Attach the limit you would concede: the contact-centre side is new to you. Say that in your words, since your sentence is the only source for it. Do not list the brief | CO from a published brief that other candidates may also have read, so a recitation scores as homework. F2 is the limit to name before they do |
| A3 | "Tell me about the complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3 and F9. The beats the sentence states: monthly, complaints, your regional manager uses it, you built it. Say it in those terms. Answer slot: the JD asks for monthly reporting on volumes and resolution times and for Excel reporting, so expect a probe on what it counted and in what tool. Say what it counted and the tool, in your own words; if volumes or resolution times were not in it, or it was not in Excel, say so plainly and stay with the spreadsheet you built | F3 and F9 both rest on this one sentence, so it is the likeliest place to be probed. EXP because it tests what was actually yours |
| A4 | "How do you think about self-service for complaints? What should a member be able to do without ringing us?" | JD | [grounded] | Give a view, not a past. State one principle of your own, then where self-service should not replace a person. Connect it to S1 and S4 in one sentence. Answer slot: if you have worked with a digital or app team, or on a self-service flow, say what and what part was yours; if you have not, say so plainly and say what you would ask the digital team first | The JD's self-service line (F5) raised casually. JD because it scores that requirement even in a chatty register. The guidance asks for a view because your material shows no digital work |

### B — Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre, and you haven't worked in one. Is that a concern?" | JD | [grounded] "Never worked in a contact centre" | The 30-second version of D1; the full rehearsal is there. Say it plainly first: "I haven't worked in a contact centre." Then one sentence on how you would learn it, as a plan. Add no experience your sentence does not state | A knockout check in a friendly register, and the first time the gap is said aloud. F2 is the row. JD because it scores the posting's own wording |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick the one you can speak about most honestly and say it in a sentence. Both are gaps you have stated. Do not invent a third. Then the first thing you would do about it, as a plan | The standard Skeptic stem. F2 and F8 are the two stated gaps. Calibrated candor scores better than a disguised strength |
| B3 | "How comfortable are you presenting to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | Say the plain sentence first: "I've never presented to anyone above regional level." Then the plan. A generic structure: find out who reads the report and what decision they need, then keep to that. Do not suggest you have presented at any level | F8 is a stated gap and a JD requirement, so the recruiter will check it. JD because it scores the posting's line |
| B4 | "Tell me what 'formal' meant in the complaints log you handled." | EXP | [grounded] "I handled the branch's formal complaints log" | The beats the sentence states: the log, the branch's, formal. Answer slot: the JD asks for experience handling regulated complaints, so expect a probe on what made a complaint formal and what rules it had to meet. If you know, say so in your own words; if you do not know the rules, or none applied to your log, say so plainly and stay with the log | F7's row, asked as a premised question the sentence supports. EXP because it tests what the word "formal" actually covered |

### Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Once the two panel members are assigned, could you tell me who they are? And does the case come with any material in advance?" | Interviewer names are the one input the pack lacks, and the answer decides what the case prep can be |
| R1.2 | "Who holds the complaints process today across branches and the contact centre?" | The JD asks you to "Own the member complaints process end to end"; the answer shows how much already exists |
| R1.3 | "What is the Head of Member Services most hoping this role changes in its first six months?" | It gives you the manager's priority before round 2 |

---

# Round 2 — Head of Member Services (your would-be manager), 45 minutes

Weights: Skeptic high, Values/Behavioral medium-high ("mostly behavioural"), Case low-medium.

### C — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a complaint was escalated and you had to deal with it." | EXP | [grounded] "I handled the branch's formal complaints log" | This is an open prompt, so you choose the instance, and your sentence carries the log but no case. Selection criteria: a case that reached the formal log, a stake you can name, what was yours to do, how the member was left. "I" for your contribution, "we" for context. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log", or how you would handle it | The JD's escalation and complaints lines, in the behavioural register this round uses. F1 is the nearest evidence. EXP because it asks for your own instance |
| C2 | "Tell me about a time you coached someone through an escalation." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4. The beats the sentence states: new tellers, the escalation script, you trained them. Tell it in your own words. Answer slot: the JD's coaching line is about supervisors, so expect a probe on who you coached and how you knew it worked. If you coached a supervisor or peer, or saw what came of the training, say so and what part was yours; if all of it was teller training, say so plainly and stay with the tellers | F4 is the closest evidence for the coaching line and is thin at supervisor level. EXP because it tests what you did, not what you would do |
| C3 | "Tell me about a time you worked with another team to make something easier for members." | JD | [grounded] | An open prompt from the JD's digital-teams line, and nothing in your material carries it. Selection criteria: a named team, one thing that changed for members, what was yours. If no such time comes to mind, say so plainly, then say how you would work with a digital team: what you would ask first and what you would bring | F5 has no evidence, so the honest fallback is the main branch of the answer. JD because it scores that requirement |
| C4 | "Tell me about a time you told someone senior something they did not want to hear." | VAL | [generic] | Selection criteria: a stake you can name, a moment you did not fold, and a working relationship still intact afterwards. Your material shows no such story, so the pack writes none. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would raise a hard point with a manager | A standard behavioural stem for a manager round, and a view of how you would work with the person you report to. The label is `[generic]` because it is a pattern, not a claim about Ashgrove |

### D — Skeptic (deepest rehearsal here)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never worked in a contact centre, and this role owns the process across it. How do you see that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "the last 3 as a branch supervisor" | **The highest-ROI rehearsal in the pack. Rehearse four levels.** Level 1: say it plainly, "I haven't worked in a contact centre." Then what your material does carry, at its scope: "I handled the branch's formal complaints log." Then a plan, said as learning: what you would find out first and from whom, in your own words. Level 2, "so that is a gap on day one": concede day one and hold the branch-side sentence without extending it. Level 3, "branch managers will say you do not understand the phone side": name the limit before they do. Your material shows no call-handling, so do not borrow any. Level 4, "what would your first 30 days be": the plan again, in your own words. Hold the sentence you can back through two follow-ups, then concede the specific gap | The JD's first requirement ends with the contact centre, F2 is a stated gap, and the manager owns the cross-channel remit. JD because it scores the posting's wording. This is the objection that will be asked in some form |
| D2 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log" | The beats the sentence states: the log, the branch's, formal complaints. Tell them in your own words. Answer slot: the JD says end to end and names resolution times, so expect a probe on what happened to a complaint once it was logged. Say what you did with it and what was yours; if the log was a record and the handling sat elsewhere, or there was no step after logging that you saw, say so plainly and stay with the log | F1 and F7 both rest on this sentence. EXP because it is the CV-style probe a manager runs on the line that sounds most relevant |
| D3 | "How much of that spreadsheet was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold-then-concede. Hold the sentence as written, "I built the monthly complaints spreadsheet our regional manager uses", through two follow-ups by returning to it, never by adding to it. Concession slot: if someone else set what it should show, or you do not know how a figure in it was counted, say so plainly; if you chose what it showed, say what in your own words. Name the assumption behind any figure that you would defend least before they do | The pressure stem on F3's artifact. EXP because it is an attribution probe, and the sentence is the only thing it can be held against |
| D4 | "The JD wants someone confident presenting to senior leaders, and you've never presented above regional level. Why should we expect that to work?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Concede first, in your own words: "I've never presented to anyone above regional level." Then hold what you can back at its scope: "I built the monthly complaints spreadsheet our regional manager uses." The sentence says the regional manager uses it, not that you presented it, so do not say you did. Then the plan, for example: ask who reads each report and what they need to decide. If pushed with "that is not the same", concede that the audience is new and keep the plan | F8 is a stated gap and the JD's own requirement. JD because it scores that line. The runner-up for deepest rehearsal |

### E — Case / Strategist (lighter)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that mean for complaints, and what would you want to know first?" | CASE | [grounded] | Clarify first: what counts as a digital channel, which kinds of complaint, which members need a person. Then the objective, the segments, an approach, the metrics (the JD's own pair, volumes and resolution times, by channel) and the risks, with app-only banks as the benchmark (S1, S4). Challenge one premise respectfully, for example whether complaints should sit inside the 40% at all. Think aloud. Your material shows no digital work, so make no claim about it | The strategy-grounded question the pack needs, in the manager's own territory. CASE because it scores structure; CO overlaps |

### Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "The brief aims for 40% of member service to be digital by 2028. Where do complaints sit in that, and who in the digital team would I work with?" | It turns the JD's self-service line and S1 into a working question, and shows the brief was read |
| R2.2 | "How does the contact-centre team see this role? What would they need from the Member Experience Lead?" | It treats the contact-centre gap (F2) as something to learn from, not hide |
| R2.3 | "What would a good monthly complaints report look like to you, and who reads it?" | It ties to the JD's reporting line and gives you the audience before you present to it (F8) |

---

# Round 3 — Panel of two branch managers, 60 minutes (includes a 20-minute case; scored against the four values)

Weights: Values/Behavioral highest, Case medium, Peer Evaluator medium. Roughly 20 minutes go to the case, leaving about 40 for values and peer questions.

### Values / principles cheat sheet

Ashgrove's four values, as copied on 11 November 2026 from ashgrovecu.org/about/values. No sentence in your material carries a story for any value, so each row is a selection scaffold. That is the pack's observation, not a gap in you. Choose real instances from your own six years.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide with the member's position in front of you, not the institution's convenience | Selection scaffold: a decision where the member's side and the easier side differed, what it cost, what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, F1's "I handled the branch's formal complaints log", or how you would handle it |
| Plain Words | Write and say it so a member does not need it explained twice | Selection scaffold: something complicated you made plain, what was unclear, how you knew it landed. Nearest material, F4: "trained new tellers on our escalation script" — it does not show whether you wrote or reworded the script, so claim nothing there. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | A branch belongs to its town, so local context counts alongside the figures | Selection scaffold: a time you weighed what the numbers said against what a branch's community needed. Nearest material, F6: "the last 3 as a branch supervisor" — it shows the role, not a community story. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem stays with it until it is solved | Selection scaffold: a problem you found and kept hold of through handoffs until it was fixed. Nearest material, F1: "I handled the branch's formal complaints log" — it carries the log, not a case. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

### F — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | An open prompt from the value Members First, Always. Selection criteria: a decision where the member's side and the easier side differed, what it cost, how it ended, what was yours. Your sentence carries the log, not a decision, so the pack writes none. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first of the four scored values. VAL because it scores a published value; F1 is the nearest evidence |
| F2 | "Tell me about a time you had to make something complicated plain for a member." | VAL | [grounded] "trained new tellers on our escalation script" | An open prompt from Plain Words. Selection criteria: what was unclear, what you said differently, how you knew it landed. Your sentence shows tellers trained on a script, not who wrote it or whether the words changed, so claim nothing there. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second scored value, and the one a script-based escalation process is most exposed to. F4 is the nearest evidence |
| F3 | "Tell me about a time you weighed what the numbers said against what a branch's own community needed." | VAL | [grounded] "the last 3 as a branch supervisor" | An open prompt from Neighbours, Not Numbers. Selection criteria: the numbers in play, what the community needed, what you did, how it came out. Your sentence shows your role, not a community story, so the pack writes none. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The third scored value, in front of two branch managers. F6 is the nearest evidence, and S2 makes the topic live |
| F4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | An open prompt from Own the Fix. Selection criteria: you found it yourself, you stayed with it through any handoff, what the fix was, what was yours. Your sentence carries the log, not a case. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The fourth scored value, and it echoes the JD's "Own the member complaints process end to end". F1 is the nearest evidence |

### G — Case / Strategist

The case content is not known. These are practice shapes for a complaint escalation. Ask the recruiter whether case material comes in advance (R1.1).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member has complained at their branch and by phone to the contact centre, and nobody has told them where it stands. Walk us through what you do." | CASE | [generic] | Clarify first: what the complaint is, how long it has been open, what has already been said to the member, and which rules apply to it. Then the objective: the member knows where it stands and it gets fixed. Then who holds it now, the first update to the member in plain words, the cause, and what gets recorded and reported. Say the structure aloud. The two values this case tests are Own the Fix and Plain Words. No claim about your past is needed | The live problem the recruiter described, "a complaint escalation", at the seam of branch and contact centre. CASE because it scores structure; `[generic]` because the real scenario is unknown |
| G2 | "A branch supervisor comes to you unsure how to handle an escalation that has already upset a member. What do you do in the next hour?" | CASE | [generic] | Clarify first: what has been promised, what the member needs today, what the supervisor already knows. Then what you do for the member now and what you do for the supervisor: coach through it rather than take it over, and set what you will check afterwards. The case is about the JD's coaching line. It asks nothing about your past, so the guidance makes no claim about it | The JD's "coach branch supervisors on escalations", as a live decision. CASE because it scores reasoning; F4 is the thin evidence behind it, which is why the case may be pointed there |
| G3 | "Eight branches are becoming five hubs over 2027. What changes for complaints, and what would you want to protect?" | CASE | [grounded] | Clarify first: which branches, what happens to the people and counters, how members will reach someone. Then the objective, the segments, an approach, the metrics (volumes and resolution times by site) and the risks. Tie in Neighbours, Not Numbers: members in a town that loses its branch. Give a view and a concession; do not criticise the strategy. Make no claim about your past | S2 is in the brief and the panel are branch managers. The pack cannot say whether it will be asked. CO because it scores strategy fluency; CASE overlaps |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Where is the seam between a branch manager and you when a complaint is escalated? What happens when we disagree?" | JD | [generic] | Offer seam principles, not a claim that you know the seam: who decides, who speaks to the member, who learns from it. Say you would ask them where it sits today. For a disagreement, say how you would raise it: privately, with the member's position first. No claim about your past | Branch managers sit next to the supervisors the JD has you coach (F4). JD because it scores the coaching and cross-branch lines |
| H2 | "What would you need from us, and what would we get from you?" | JD | [generic] | Lead with what they would get, in the job's own terms: monthly reporting on complaint volumes and resolution times and coaching for supervisors on escalations. Those are the JD's duties, not past claims. Then what you need: how they currently handle escalations and where they feel unsupported | Reciprocity framing for a peer-style panel. JD because the answer is drawn from the posting's duties |
| H3 | "Tell me about a time you disagreed with someone at your own level and how it was resolved." | VAL | [generic] | An open prompt from the peer stem. Selection criteria: the disagreement, the member or branch stake, what you did, the relationship afterwards. Your material shows no such story, so the pack writes none. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A collegial disagreement probe from two people you would work alongside. VAL because it scores behaviour under friction |

### Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-style panel; it shows you are thinking about their load |
| R3.2 | "With eight branches becoming five hubs, what do you most want the complaints process to protect?" | S2 and Neighbours, Not Numbers together; it asks them to set the priorities your case answers will be heard against |
| R3.3 | "When an escalation has gone badly in your branch, what did you most wish had been done differently?" | It surfaces the real failure modes the coaching line is meant to fix |

---

## Requirement coverage

| JD requirement | Fit row | Questions that cover it |
|---|---|---|
| "Own the member complaints process end to end" | F1 | C1, D2, G1, F4 |
| "across branches and the contact centre" | F2 | B1, B2, D1, G1 |
| "report monthly on complaint volumes and resolution times" | F3 | A3, D3, E1 |
| "coach branch supervisors on escalations" | F4 | C2, G2, H1, H2 |
| "work with digital teams on self-service journeys" | F5 | A4, C3, E1 |
| "4+ years in financial-services customer operations" | F6 | A1 |
| "experience handling regulated complaints" | F7 | B4, D2 |
| "confident presenting to senior leaders" | F8 | B2, B3, D4 |
| "comfortable with Excel reporting" | F9 | A3, D3 |

Defend-the-number: none. Your message gives no headline figure, so there is nothing to count.

## Prohibited claims (not coached, and why)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's sentence at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation: your material says the branch log, not the process |
| Has contact-centre experience | A negative you stated, F2: "Never worked in a contact centre" | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's sentence at its own scope: "trained new tellers on our escalation script". The limit is the pack's observation: your material says tellers |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's sentence at its own scope: "I built the monthly complaints spreadsheet our regional manager uses". The limit is the pack's observation: your material does not show what it counted |
| Has presented to senior leaders | A negative you stated, F8: "I've never presented to anyone above regional level" | The plain acknowledgment, in your own words: "I've never presented to anyone above regional level." No slot |
| Handled complaints under a named regulatory regime | Inflated form of F7 | F7's sentence at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation: your material says formal, not which rules |
| Advanced Excel skills | Inflated form of F9 | F9's sentence at its own scope: "I built the monthly complaints spreadsheet our regional manager uses". The limit is the pack's observation: your material says spreadsheet, not Excel |

## Sources

Provided documents:
- The JD for Member Experience Lead at Ashgrove Credit Union, as you pasted it.
- Ashgrove's four values, as you pasted them on 11 November 2026 and noted as copied from ashgrovecu.org/about/values. The URL is where the text came from, so it was not fetched.
- The recruiter's email on the three rounds on 20 November.
- The 2026 strategy brief published in July 2026, through your four-point summary of it, not the brief itself.
- Your background, in your message.
- No `tuesday-dossier.md` was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the cheat sheet and F1 to F4 |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the three rounds, their lengths and who runs each, so the persona weights follow it |
| 3. `Ashgrove Credit Union strategy` | skipped | The July 2026 brief, about four months old, fixes the grounding brief, A2, E1 and G3 |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names are assigned, so no query could be formed; there is no interviewer read |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewers' names, once assigned → an interviewer read for each, persona weights per person, and a reverse question tied to their own path
- The full text of the July 2026 strategy brief → the grounding brief rows S1 to S4 are built from your four-point summary, so more of its current vocabulary and numbers would sharpen A2, E1 and G3
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → recent leadership and organisation context, loop reports, and a stronger CO and CASE bank
- The recruiter's answer on whether the 20-minute case comes with material in advance, and what it covers → the G bank becomes specific to the real scenario; this is usually one email
- Your own written answers to the slots in F1, F3, F4, F5, F7 and F9, sent outside a drill → each row becomes quoted evidence, and the banks that rest on it can map a story where they now give a scaffold
- A fuller CV or any complaints-handling or reporting artifact you can describe → rows F1, F3 and F9 move from medium or low toward high
- A `tuesday-dossier.md` from an earlier evaluation of this role, if you have one → verified-evidence grading and an underwriter's prohibited-claims list in place of the locally built one
