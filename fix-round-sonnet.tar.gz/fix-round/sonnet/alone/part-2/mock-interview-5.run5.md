Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md`. It is built for a two-person panel (Deepa as future manager, Ross on commercials) with a 15-minute spoken POV and then Q&A. It runs to 19 questions and includes a four-hour prep schedule. I built it from your message alone: web search wasn't permitted, so there's no company or interviewer research. I also don't have the text of the market report or a JD, so the company-specific questions are labelled generic.

Say the word and I'll play the Skeptic on C1, the pack's highest-ROI question: "you haven't sold into rail and haven't carried a direct number". I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the JD, your CV, and the report's headline findings, or say to carry on without them? The report would let me pick your "agree with one item, diverge on one" pair and sharpen the POV build.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Second-round panel, Tuesday, 60 minutes. Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Format per the recruiter: first 15 minutes a spoken POV with no slides, then Q&A, with Ross pushing on commercials.

Built from your message alone: no JD, no CV document, and the text of the market report was not in hand. Company research was attempted and not permitted, so nothing here is company-specific beyond what you and the recruiter said.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (not used here: no values round was documented) |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | The stated role and the stated ask, including your gaps |
| CO | Whether you can think at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

Where a cell says answer slot, it is an instruction for the interview: answer from your own experience, or say plainly it was not yours or did not exist, and return to what you did say.

## Prep triage (four hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 35 min | Re-read the report with a pencil: mark one item you agree with and one you would do differently, and note where it conflicts with your thesis. Send the recruiter a one-line email asking what "operator partnerships" covers at Kelverton | Graded deliverable, A3 |
| 2 | 55 min | Build the 15-minute POV and say it aloud twice, timed to about 12 minutes | Graded deliverable, A1, A2 |
| 3 | 45 min | Rehearse the objection that will arrive in some form: you have not sold into rail and have not carried a direct number. Say it aloud through both follow-ups | C1, C2, D1 |
| 4 | 45 min | Defend the £4M to its assumptions, then rehearse the "what number would you sign up to" interruption | B1, B3, B4, D2, D3 |
| 5 | 30 min | The 90-second journey arc and the reverse questions | E1, Reverse questions |
| 6 | 30 min | One full run: POV, then C1, then B1, back to back, out loud | All of the above |

Everything else in this pack is insurance.

## Fit snapshot

Requirements are quoted from the recruiter's email or your message, because no JD was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter email, quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message; "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning and a payments ISV channel, not rail operator partnerships, and the words stay at that scope: "I spent five years in transport consulting, in bus and light rail network planning, and I've run an ISV channel." Answer slot: the POV ask makes a probe on what from those years bears on train operating companies likely. If something carried across, say what, in your own words; if nothing did, say so plainly and stay with what you did |
| F2 | "Please land on what it means for the operators themselves." — recruiter email, quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The quote speaks to bus and light rail, and it does not speak to train operating companies. Words: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: the ask is operator impact, so expect a probe on what operators would see differently. If any of that planning work put you close to operators' decisions, say what you saw, in your own words; if it did not, say so plainly and say how you would find out |
| F3 | "Ross will push on commercials" — recruiter email, quoted in your message | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Influenced revenue is adjacent to commercials and does not reach deal economics. Words at the quote's scope: "I took the ISV channel from 6 partners to 40, with roughly £4M of influenced revenue." Answer slots, each in your own words: how the figure was counted, what it is most sensitive to, the assumption in it you would defend least, and which part was yours. If you do not know how a part was counted, say so plainly |
| F4 | "Ross will push on commercials" — recruiter email, quoted in your message | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota; what I've had is influenced revenue." Then how you would get accountable for a number, said as a plan in the future tense and never as a past |
| F5 | "they sell scheduling software to train operating companies" — your message | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | Words: "I've never sold into rail specifically." Then what you would learn first and how, said as a plan. Nothing added to make the gap feel smaller |
| F6 | "Senior Partnerships Manager" — your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | No gap on the role's core, but two lines with nothing inspected behind them, so expect a probe. Lead with them in their own terms: nine years in partnerships, the last four running an ISV channel |

No requirement in the material is a gate (a term such as location or right to work), so the snapshot has no gate row. A JD would settle that.

## Graded deliverable: the 15-minute spoken POV

The recruiter named this deliverable and its close: "present a short POV on where you'd take our operator partnerships over the next 18 months", and "land on what it means for the operators themselves".

Grounded facts to build on, each from a fit-snapshot row:

- F6: "took it from 6 partners to 40, roughly £4M of influenced revenue". Use it as the one piece of your own experience that speaks to partner channels, at its own scope.
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". Use it for the operator's side of the table, and say bus and light rail when you say it.
- F4 and F5: you have never carried a direct quota and never sold into rail specifically. Say both yourself, early and plainly, inside the concession of whichever thesis you pick.

Three theses to choose between. Each is a pattern to test against the report, not a claim about Kelverton:

| Thesis | Draws on | Mandatory concession | What it means for the operators |
|---|---|---|---|
| T1: Go deep before wide. Spend the 18 months on a small number of operator relationships, each built around one outcome the operator already tracks | [generic] pattern, no claim about your past | Depth costs reach and concentrates risk, and you have not tested it in rail (F5) | The operator gets a partner working against its own measure rather than Kelverton's product list |
| T2: Use partners so the operator does not integrate the surrounding pieces alone | F6: "took it from 6 partners to 40, roughly £4M of influenced revenue", at its own scope | A payments ISV channel is not rail, and who holds budget and how integration cycles run may differ; you have not sold into rail (F5) | The operator gets a coherent set of tools instead of a list of vendors to stitch together |
| T3: Measure operator outcomes, not partner activity | F3, the influenced-revenue figure, as the live example of attribution being the weak spot | Operator outcomes will be harder to attribute than revenue, and you have only carried influenced revenue (F4) | The operator sees a number it can check for itself |

Differentiation. The report is shared ground, so reciting its shortlist scores as homework. Bring one item from it to show you read it (slot: choose which, from the report), then one thesis above that departs from it, with your reason. Where the report points one way, say what you would not do: the anti-pick. A candidate anti-pick, if the report supports it: do not set a partner-count target as the 18-month goal. Test that against the report before using it, and note it sits awkwardly with T2, so choose between them.

Timing for about 14 minutes: 1 minute on the scope you are assuming, 2 on where the report sits and your one divergence, 6 on your thesis and its concession, 3 on the operators, 1 to 2 on the limits you have named and what you would learn first.

The requested close, three sentences you complete from the report and your thesis: what an operator would see at month 6, at month 12, and at month 18. The pack supplies no figures or facts for them.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Questions on the POV itself: what you would do, what you would drop, what you need to know first | High. The recruiter set a 15-minute POV and named Q&A after it, and Deepa is your future manager (hiring-manager prior: Case/Strategist plus Skeptic) | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Ross working your £4M and your commercial thinking line by line | High. The recruiter wrote "Ross will push on commercials", and your own metric is influenced revenue, which is the figure that gets probed | Know what you can and cannot say about how it was counted; say plainly where you do not know |
| Skeptic | Your gaps: rail, direct number, why now | Medium to high. You stated both gaps yourself (F4, F5), and a future manager is buying capability and derisking gaps | Rehearse C1 until it is boring; concede the limits first and in your own words |
| Pressure | Ross interrupting or time-boxing, asking for a number | Medium. This rests on the relationship prior for an executive questioner, not on anything documented about Ross | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational | Opening journey question and motivation | Low to medium. A 60-minute panel usually opens softly, but this is the prior, not a documented fact | Pre-script a 90-second arc and treat casual questions as scored |

No interviewer profile exists, so there is no interviewer read and persona weights follow the priors above.

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through where you'd take our operator partnerships over the next 18 months, and what that means for the operators." | JD | [grounded] | The graded-deliverable section is the guidance: say the scope you are assuming, name the objective, pick one thesis, state its concession, close on the operator in three sentences. Aim for about 12 minutes and leave room. The question needs no claim about your past, so this cell makes none | The recruiter's own words set this task, so it is JD, delivered as a CASE. F1 and F2 are the rows it presses on |
| A2 | "Which operators would you deliberately not prioritise in the first 18 months?" | CASE | [generic] | Give the criteria before any names: what makes an operator ready, what makes one a distraction. Then apply them to the categories the report uses (slot: take them from the report) and say what you give up by saying no | The anti-pick: a partnerships role has to say no, and the report's shortlist is shared ground. F1 sits behind it |
| A3 | "Which part of the strategy team's report do you agree with least, and why?" | CO | [grounded] | The pack has not seen the report. Choose one item you agree with and one you would do differently, from the report itself, and give the reason for each. If the report is silent on your point, say so plainly rather than inventing what it says | The report is shared ground, so this tests judgement rather than recall. CO because it tests altitude; `[grounded]` rests on the recruiter attaching the report, not on its content |
| A4 | "An operator's planning team says a new partner integration lands in the same quarter as a timetable change they are already stretched on. Do you push on, pause, or reshape it?" | CASE | [generic] | Clarify first: whose deadline it is, what can move, who at the operator decides. Then choose, give the reason, say what the operator keeps either way, and name what you would be wrong about. No claim about your past | A live problem from the operator's side, which F2 predicts will be probed. `[generic]` because it is a pattern, not a fact about Kelverton |
| A5 | "What would you need to know in your first 30 days before committing to a plan?" | CASE | [generic] | Three buckets, asked rather than assumed: the operators and who buys versus who uses; the partners already in place; how the commercial model works today. Finish by saying what would change your plan | Tests clarifying before structuring, the Case/Strategist bar. F5 is why the first bucket matters |

### B. Data-Driven Prober and commercials (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | Say it at its scope: "I took the ISV channel from 6 partners to 40, with roughly £4M of influenced revenue." Answer slots, in your own words: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. If you do not know how a part was counted, say so plainly. Do not call it sold, closed or generated | The headline figure is the magnet; F3 and F6 are the rows. EXP because it tests attribution honesty |
| B2 | "How would you structure the economics of an operator partnership: who pays whom, for what?" | CASE | [generic] | Ask what exists today first (you have not seen it). Then lay out the options you would test, say which you would test first and why, and what would prove you wrong. The pack supplies no figures and no claim about Kelverton's model | Ross is documented as pushing on commercials. CASE because it is a live structuring problem rather than a CV probe |
| B3 | "Eighteen months in, how would we know the partnerships were commercially working?" | JD | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Offer two or three measures, split into leading and lagging, and name the attribution assumption you would defend least. Answer slot: if you know how your own influenced-revenue figure was attributed, say how; if you do not, say so plainly | Converts the commercials push into a measurement answer. F3 and F4 sit behind it; JD because it scores the stated ask |
| B4 | "How sensitive was that £4M to your largest few partners?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: if you know the spread across partners, say how concentrated it was, in your own words; if you do not know or it was not tracked, say so plainly and say what you would check. Keep 40 attached to partners and £4M attached to influenced revenue | The sensitivity probe a prober uses on any figure. F3 |
| B5 | "What do I tell an operator is in it for them, commercially?" | CO | [generic] | Answer in the operator's terms, not Kelverton's: its costs, its risk, its time. Concede that you would test the answer with operators before relying on it. No claim about your past | Closes the loop between Ross's commercials and the recruiter's "what it means for the operators themselves". F2 |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't sold into rail and you haven't carried a direct number. Why should we trust you with operator partnerships here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The highest-ROI prep in this pack: this objection will arrive in some form. Name both limits yourself in the first 20 seconds: "I've never sold into rail specifically, and I've never carried a direct quota." Then hold only what the quotes carry: nine years in partnerships, the last four running an ISV channel, and five years in bus and light rail network planning. Follow-up 1, "bus and light rail isn't a train operator": concede exactly, since the quote says bus and light rail, then answer slot: if something carried across, say what; if nothing did, say so plainly. Follow-up 2, "so what don't you know?": name the one thing you would learn first and how, as a plan. Hold through both; never add to what you did | F4 and F5 are your own stated limits, so the panel will find them whether or not you name them. JD because it scores the role's fit, with the Skeptic's delivery |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Answer slot: choose the one you would honestly name. If it is one of your two stated gaps, say it plainly and say what you would do in month one, as a plan. If your honest answer is something else, say that instead; never name a weakness that is not real | The standard weakness probe; F4 and F5 give the honest candidates. JD because it scores the requirement |
| C3 | "Why leave payments for rail-tech, and why now?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Selection scaffold: the reason must be the real one, specific to this company or this sector, and consistent with your arc. If the pull back toward transport is real, say that your five years in transport consulting came before your partnerships years. If the real reason is different, say that. If nothing beyond "a good role" comes to mind, say so plainly, then say what about this company you actually looked at | Motivation consistency is what a Skeptic scores. EXP because the answer must fit your history; F2 is the row |
| C4 | "After six months, what should we be judging you on?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Offer two or three markers: learning and relationship markers, and one commercial marker you would want agreed. Say plainly that you have not carried a direct quota, and that you would ask how the number is set here (see Reverse questions). No figures supplied | A future manager's version of C1, framed forward. F4 |

### D. Pressure (likely from Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause and restate the question. Concede first: "I've never sold into rail specifically." Then hold only what the quotes carry: "I took the ISV channel from 6 partners to 40, with roughly £4M of influenced revenue." Stop at sixty seconds; do not add claims about how fast you would learn | Hold-then-concede on the core gap. F4, F5 and F6 |
| D2 | "How much of the 6 to 40 was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: if others contributed, say what part was theirs and what part was yours; if you did it alone, say so. Use "we" for context and "I" for contribution. Hold the sentence you can back, and concede the rest specifically | The attribution probe, the Pressure stem for this candidate. F6 |
| D3 | Ross cuts in: "I'm not hearing a number. What number would you sign up to?" | CASE | [generic] | Do not produce a figure you cannot defend. Say what you would need first, such as a baseline, the operator list and how a number is set here. Answer slot: if you have a view, give a range with the assumption you would defend least, in your own words; if you do not, say so plainly and say when you would. The pack supplies no figure | The commercials push at its sharpest, aimed at a candidate who has carried only influenced revenue (F4) |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc with the beats the quotes state: five years in transport consulting, in bus and light rail network planning; then nine years in partnerships, the last four at a payments company running the ISV channel. Answer slot: why this role, in your own words; if the move was not a plan, say so plainly. Add no further beats | The opener is scored. F1 and F6 supply the beats |
| E2 | "What drew you to a scheduling-software company in particular?" | CO | [generic] | Selection scaffold: name one specific thing you actually read or looked at, from the report or elsewhere. If nothing specific comes to mind beyond the role, say so plainly, then say what you did look at. No claim about your past | A casual question on the company's core product is still scored. `[generic]` because the pack has no company research |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, A5 and the graded-deliverable section |
| "Please land on what it means for the operators themselves." | A1, A4, B5 |
| "Ross will push on commercials" | B1, B2, B3, B4, D3 |
| "Senior Partnerships Manager" | E1, B1, D2 |
| "they sell scheduling software to train operating companies" | C1, C2, D1, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would success look like for this role at six months and at eighteen, and which operator outcomes would you point to?" | Shows you think in operator outcomes, the exact close they asked for, and gives you the marker to aim at |
| R2 | "Where do operator partnerships sit relative to direct sales, and who owns the operator relationship day to day?" | Seam question; it shows you are thinking about the work rather than the title |
| R3 | "What did the strategy team's report underweight, in your view?" | Invites them to disagree with their own document, which signals you read it critically rather than recited it |
| R4 | "How is a partnerships number set here: direct, shared, or influenced?" | Faces your gap openly and gets the one fact C4 and D3 depend on |
| R5 | "What is one thing an operator has asked for that you have not been able to deliver?" | Surfaces the real friction and shows you want the hard version of the job |
| R6 | "Deepa, what would you want me to have understood by the end of month one?" | A future manager hearing a new hire ask for the brief is hearing how you will work with them |

## Prohibited claims

Claims this pack will not coach, built from the fit snapshot before the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or has rail partnership experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never sold into rail specifically." No slot |
| Carried a quota, or owned a revenue number | Negative you stated, F4 | The plain acknowledgment F4 gives: "I've never carried a direct quota; what I've had is influenced revenue." No slot |
| Knows the train operating company world from the other side | Inflated form of F2 | F2's quote at its own scope: five years in bus and light rail network planning. The limit is the pack's observation: your material says bus and light rail, not train operating companies |
| Generated, closed or sold £4M | Inflated form of F3 | F3's quote at its own scope: roughly £4M of influenced revenue. The limit is the pack's observation: your material says influenced, not generated or closed |
| Built the partner programme single-handedly | Inflated form of F6 | F6's quote at its own scope: "took it from 6 partners to 40". B-bank and D2 slots ask only which part was yours |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report was attached to that email; its text was not in hand, so nothing in this pack states what it says.

No dossier was supplied.

Searches sent, all refused (no result returned):

- "Kelverton Rail values": refused
- "Kelverton Rail interview process partnerships manager": refused
- "Kelverton Rail strategy news train operating companies scheduling software": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused
- "Senior Partnerships Manager rail technology job description": refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have fed published-value themes for VAL questions; nothing moved, no values round is documented |
| 2. Kelverton Rail interview process | unavailable | Would have checked loop structure; the recruiter's email already gives this session's format, so persona weights follow it plus the priors |
| 3. Kelverton Rail strategy and recent news | unavailable | Would have grounded the CO questions and a grounding brief; A3, B5 and E2 are therefore generic or rest on the report you hold |
| 4. Interviewer names with company | unavailable | Would have produced an interviewer read and a reverse question tied to a path; both are absent |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have supplied inferred requirement rows; the fit snapshot uses the recruiter's and your words instead |

## Upgrade menu

- The JD text → requirement rows in the fit snapshot become quoted from the posting, any gate terms (such as location or right to work) get checked, and the JD-tagged questions are rewritten against its list
- Your CV → the fit snapshot's evidence column is checked against it, and rows F1, F2, F3 and F6 may gain further quoted sentences
- The report's headline findings, pasted → a grounding brief, a named consensus item for you to differentiate from, and A3 and A2 rewritten against it
- Your answers to the answer slots in F1, F2, F3, B1, B4 and D2 → those rows become story-mapped in your own words
- The interviewers' public footprint, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, run only on your consent) → an interviewer read, a reverse question tied to each path, and company-specific CO questions
- The recruiter's reply on what "operator partnerships" covers → the POV's scope line and thesis choice are fixed rather than assumed
- A `tuesday-dossier.md`, if you have one → the objection to rehearse would come from verified evidence rather than inference
