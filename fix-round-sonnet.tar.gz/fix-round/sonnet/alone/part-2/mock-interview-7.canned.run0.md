I'll read the reference files before building the pack.
Checking is done, so I'm writing the pack to a file now.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-canned-c35beae7/saltmarsh-games_live-operations-producer_interview_pack.md`.

I built it for the round Saltmarsh's interviewing page describes: "a live-incident tabletop on a simulated outage during a live event, then a values conversation," with no take-home. I assumed Tobias is the hiring manager running it.

It has 19 questions. The tabletop bank (A1 to A5) has the most weight. It's followed by the values bank, which uses Saltmarsh's three published values by name. The fit snapshot, interviewer read, reverse questions and prohibited-claims list are in the file.

The question to rehearse most is C2, the in-app-purchases gap. The posting doesn't list it, but Saltmarsh's news page describes a move to a season-pass model. The pack coaches a plain acknowledgment, then a plan, and nothing that implies purchase experience you didn't describe.

I only read the search summaries for the Larkspur news and for Tobias's GDC talk, not the full pages. The upgrade menu offers a deeper research pass that would read both.

Say the word and I'll play the hiring manager on the tabletop (A1), or the Skeptic on C2.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Has your recruiter said anything about the Outage Hour, such as a type of outage or anything to prepare? The answer would replace the generic tabletop in A1 to A5 with the real one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Treated as the hiring manager running the Outage Hour (the loop is documented in Sources); that relationship is an assumption, and the persona weights below follow from it.
**Round:** one 60-minute session. Saltmarsh's interviewing page describes it as "a live-incident tabletop on a simulated outage during a live event, then a values conversation," with no take-home.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Every question carries one type tag:

| Tag | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Whether your own lines survive scrutiny: what was actually you |
| JD | A stated responsibility or requirement in the posting |
| CO | Whether you can think at the company's altitude: strategy, recent moves |
| CASE | A live problem from the role, scored on structure and reasoning aloud |

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for you now: say what is true in your own words, and if the practice was not yours or never existed, say so plainly and return to the sentence you can stand behind.

**The highest-ROI rehearsal is C2**, the in-app-purchases question. Nothing in the posting lists purchases. It is the largest gap you stated yourself, and Saltmarsh's own news page describes a move to a season-pass model (see Sources), so it is the objection most likely to arrive. No underwriting dossier was present, so this objection is inferred rather than evidence-derived. The A bank is the next priority, because the tabletop is the documented core of the session.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material gives the four years and the role, and does not show whether the title was live-service. The words stay at "4 years as an associate producer at a puzzle-game studio." Answer slot: the JD's live-service line makes a probe on how the title's updates reached players likely. If it was live-service, say in your own words how updates reached players; if it was not, or you cannot call it that, say so plainly and return to the weekly content-drop calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: you ran it, weekly, for your main title, for two years. A named cadence beats an adjective |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events line makes a probe on what the weekly drops contained likely. If any of the drops were time-limited events, say which and how you ran them, in your own words; if none were, say so plainly and stay with the calendar you ran |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team" — your message | low | [inferred] | discovery | Coordinating is not leading, and your material shows neither which teams the drops involved nor how you worked with them. The sourced words are your own negative: "I've never led a team." Answer slot: if the drops involved design, art, engineering or community, say who and what you asked of each, in your own words; if some of those groups were not part of it, or you were not the one coordinating, say so plainly and stay with the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting numbers is adjacent to this line, and the words stay at "I presented the monthly retention numbers to the studio head." Answer slot: the JD's KPI line makes a probe on who set the numbers' definitions likely. If you chose or shaped any definition behind those numbers, say which and how you decided, in your own words; if they were set by someone else, or definitions were not something you decided, say so plainly and return to presenting them |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on how the numbers were counted (D2). Lead with it in its own terms: you presented the retention numbers to the studio head, monthly |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on it. Lead with the checklist in the quote's own terms: you wrote it, and your QA team still uses it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Your material has no line about writing as such, and the checklist is the one written thing it names. The words stay at "Wrote the release checklist our QA team still uses"; let the interviewer draw any inference about clarity. A5 tests this live |
| F9 | Not a JD line: an unquoted role-family expectation, familiarity with in-app purchases in a live mobile title | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Grounded on your own stated negative; the requirement itself is a role-family expectation, not a JD line. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to purchase-economy work, and nothing added to make the gap feel smaller |

No row is a hard gate: the posting's "3+ years" is a length-of-experience line, not a credential or legal bar.

## Reading the interviewer

Public professional footprint only. One search returned one source on Tobias, a talk page; it was not fetched, so everything below stands on that page's summary.

| # | Public signal | Source | Provenance | What it means for your prep |
|---|---|---|---|---|
| R1 | Head of Live Operations at Saltmarsh Games; GDC 2026 talk "Patch Notes Are a Promise," arguing that a live team is judged by how often its patch notes describe what actually shipped | talks.gdconf.example/2026/patch-notes-are-a-promise | [grounded] | Commitments you voice in A1 and A5 are likely to be heard against this argument. Say what is known and what is built, and leave out what is hoped. Do not quote the talk back unless asked |
| R2 | Previously a QA lead at a console studio | Same page | [grounded] | Release and QA questions (A4, D1, E1) may be followed up in specific terms. Concede specifics and never pad. Mirror opportunity: your side of the shared QA and release ground is F7, "Wrote the release checklist our QA team still uses" — your message. This is shared professional ground, not a shared identity, so offer it plainly and do not build on it |
| R3 | Saltmarsh's published value "Ship the Patch Not the Promise" and the talk's title share the patch and promise vocabulary | values page and talk page | [inferred] | Expect B2 and A5 to be heard through the same lens: what you announce should match what is built |

## Persona table

The weights show their reasoning so you can recalibrate if you know something this pack does not. Pass 1 is the relationship prior (hiring manager: Case/Strategist and Skeptic). Pass 2 is the interviewer signals (R1 and R2). Pass 3 is the loop source: a tabletop, then a values conversation.

| Persona | Weight | How it shows up here | Reasoning | Provenance | Counter-strategy |
|---|---|---|---|---|---|
| Case / Strategist | Highest (5 questions) | The outage tabletop and follow-on decisions, A1 to A5 | The documented session opens with the tabletop, and the hiring-manager prior points the same way | [grounded] | Clarify, then objective, then approach, then risks, thinking aloud; state what is known and what is not; challenge one premise respectfully |
| Values / Behavioral | High (4) | The values conversation, B1 to B4, keyed to the three published values | The loop source documents a values conversation as the second half, so it is guaranteed in this session | [grounded] | Map a story to each value where one of your quoted lines carries it, and use the selection scaffold with its honest branch where none does; "we" for context, "I" for your own part |
| Skeptic | Medium (3) | Quiet probing of the gaps: live-service, coordination without leading, purchases (C1 to C3) | The hiring-manager prior; the gap rows F1, F4 and F9 give it material | [inferred] | Rehearse C2 until it is boring: acknowledge plainly, give the plan, concede specifics, and hold through two follow-ups without adding to your past |
| Data-Driven Prober | Medium (3) | Line-by-line probes on the calendar, the retention numbers and the review (D1 to D3) | You listed retention reporting and a calendar; R2 suggests release and process detail will be followed up | [inferred] | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| Pressure | Low (2) | Time-boxed or interrupting follow-ups inside the tabletop; "how much was actually you" (E1, E2) | A simulated outage may carry a clock, and the hiring-manager prior includes derisking | [inferred] | Pause, restate, anchor in what you said, hold through two follow-ups before conceding anything real |
| Conversational | Low (2) | The opening "walk me through" and a casual question on events (G1, G2) | A 60-minute session usually opens with a biography question; casual questions are still scored | [generic] | A pre-scripted 90-second arc; treat casual questions about live events as scored |

The Peer Evaluator is left out: Tobias is the hiring manager, not a peer. If that assumption is wrong, say so and the banks get reweighted.

## Question banks

Question IDs run by persona. Fit-snapshot rows keep the F prefix, so the Conversational bank is G.

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a live event. Reward claims are failing for a share of players, the community channel is filling with reports, and engineering is still finding the cause. You're the producer in the room: what are your first ten minutes?" | CASE | [generic] | Think aloud in order. Clarify first: who is affected, since when, what is confirmed versus reported, and what engineering needs from you. Objective: players first, then the event, then the calendar. Approach: one named owner per thread (fix, players, comms), an early message that says only what is known and when the next update comes, and a decision on whether the event keeps running. Risk: a fix time nobody has agreed. Close with what goes in the review afterward. The question asks for no claim about your past, so the guidance makes none | The tabletop is the documented core of the session; its actual scenario is unpublished, so this is a representative shape and not a prediction. CASE because it scores structure aloud |
| A2 | "Engineering says the fix lands tomorrow evening. The event ends tonight, and the calendar has the next event going live Thursday. What do you do with the calendar?" | CASE | [generic] | Say the trade-off out loud: extend the event, compensate, or let it end, and then the knock-on to Thursday. Name what you would need to know: how many players are affected, what compensation is feasible, and whether Thursday's build depends on the fix. Use the published value as the lens: when the calendar and the players disagree, the players win. Then say what you would tell the team about Thursday and by when you would decide. This is a decision, not an anecdote, so use no precedent from your past | Tests calendar judgment under a live failure; Players Before Plans is the likely lens (see the values sheet). CASE because it asks for a decision |
| A3 | "From February 2027 two of our titles share one events calendar run by a single live-ops group. You've run the weekly content-drop calendar for your main title. What changes with two titles on one calendar, and what would you want to know first?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify before structuring: who owns each title's slots, how the two player bases differ, and how a season-pass rhythm shapes events. Ask and do not assume. Then structure: collisions between the titles' events, shared engineering and art capacity, and one review format so both titles' results can be compared. Your own ground is the sentence as quoted: "I ran the weekly content-drop calendar for our main title for the last two years." Stop the past there and say what you would do next as a plan | F3 is where the JD's two-titles line presses hardest. The Larkspur news makes the shared-calendar framing likely (inferred from one search result). JD because it scores that line, CO in content, and the strategy facts come from Sources |
| A4 | "Design wants to add a mechanic to Thursday's event after QA has signed off the build. How do you decide?" | JD | [generic] | Structure: what exactly changed, what it touches, and what the release checklist says about re-testing versus shipping. Then the options (ship as signed, delay, ship the change later), who decides, and by when. Ask QA what they would need before you decide. If the checklist does not cover the change, say so and say the checklist gets fixed afterward, which is the published Leave the Build Greener value. No claim about your past | Covers the JD's release-checklist-with-QA line (F7) as a decision. JD content, CASE delivery |
| A5 | "I'm your community manager. It's ten minutes into the outage. Give me the message we post to players, out loud or on the page." | JD | [generic] | Three sentences: what players are seeing, what we are doing, and when the next update comes. Say only what is known and no fix time that has not been agreed; that is the published Ship the Patch Not the Promise value in practice. Read it back and cut one word. No claim about your past | Tests the JD's clear-written-communication line (F8) live; R1 makes wording of commitments likely to be heard closely. JD content, CASE delivery |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players pulled in different directions." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: your material does not carry a story of that kind. Pick an occasion that has a named stake (what the calendar said), what players were telling you, the call made, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the calendar you ran as quoted, or say how you would handle it | The first published value is nearly this sentence, so a question on it is close to certain. F2 is the only row touching the calendar. VAL because it scores past behavior against a published value |
| B2 | "Tell me about a time you told people something less exciting than they were hoping to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: your material does not show a time the hard truth landed, so the pack supplies no ending. Pick an occasion with a named audience, what they hoped for, what you said, and what happened afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I presented the monthly retention numbers to the studio head," or say how you would handle it | Maps to Ship the Patch Not the Promise. F5 is the nearest row and carries no story of an unwelcome message. VAL because it scores behavior against that value |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F7. Beats the sentence states: you wrote the release checklist, and your QA team still uses it. Tell those in your own words. Answer slot: the value's wording is about leaving the checklist better after each release, so expect a probe on what changed in it over time. If you revised it after a release, say what and why; if you did not, or it was not yours to revise, say so plainly and stay with the checklist you wrote and that QA still uses. Do not say the sentence shows improvement; it shows the checklist exists and is in use | Maps to Leave the Build Greener, the one value whose wording names a checklist. VAL because it scores a published value |
| B4 | "Which of our three values would be hardest for you to live by here?" | VAL | [grounded] | Choose honestly. Pick the one your own habits cut against and say what you would do about it, and do not pick the one you can map fastest. No claim about your past | A common closer in a values conversation; the values page is the raising source. VAL because it scores self-knowledge against the published values |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The posting asks for three-plus years producing live-service games or apps. Tell me what the live-service side of your four years looked like." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Hold what the quotes carry, in those words: "4 years as an associate producer at a puzzle-game studio," and the weekly content-drop calendar for your main title for two years. Answer slot: the JD's live-service line makes a probe on how the title's updates reached players likely. If it was live-service, say in your own words how updates reached players; if it was not, or you cannot call it that, say so plainly and return to the calendar you ran | F1 is the first requirement a skeptic checks, and the material is silent on it. JD because it scores a stated requirement |
| C2 | "We're moving to a season-pass model. You've never worked on a game with in-app purchases. What would you be blind to on day one?" | CO | [grounded] "never worked on a game with in-app purchases" | **The highest-ROI rehearsal in this pack.** Hold-then-concede. Acknowledge first and plainly: "I've never worked on a game with in-app purchases." Do not soften it, and do not bridge to a past that is not in your material. Then the plan, not the past: how a season pass changes what each event is for, who you would ask to walk you through how offers and events fit together, and what you would read first, such as past post-event reviews. Hold through two follow-ups by returning to the acknowledgment and the plan, and never by adding to your past. If pressed on how long, answer slot: name the time you would want, in your own words. Concede the specific thing you expect to be slowest at | F9 is the largest gap you stated. The Larkspur news says the two titles move to a season pass, so the gap is likely to be pressed even though the JD does not list it (inferred). CO because it needs Saltmarsh's strategy to answer well |
| C3 | "Getting design, art, engineering and community onto the same update means moving people who don't report to you. You've never led a team. How do you do that?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years" | Acknowledge plainly: "I've never led a team." Answer slot: the JD's coordinate-on-each-update line makes a probe on how likely. If the drops involved design, art, engineering or community, say who and what you asked of each, in your own words; if some of those groups were not part of it, or you were not the one coordinating, say so plainly and stay with the calendar you ran. Then the plan, said as what you would do: one calendar everyone can see, and agreeing with each group what ready means before an update locks | F4 is the JD line your material touches least, and the missing leadership is one you stated. JD because it scores a stated responsibility |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F2. Beats the sentence states: weekly, content drops, your main title, two years. Tell those in your own words. Answer slot: the JD's content-calendar line makes a probe on how slots were decided and what happened when one slipped likely. If you set the slots or handled a slip, say how, in your own words; if the slots were set elsewhere, or no slip arose, say so plainly and describe how you ran the calendar week to week | F2 is the strongest line and the one every follow-up starts from. EXP because it tests what was actually yours |
| D2 | "Pick one of the monthly retention numbers you presented to the studio head. How was it counted?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Name the number you would pick, in your own words. Answer slot: if you know how it was counted, say so; then what it was sensitive to, the assumption behind it you would defend least, and which part of producing it was yours. If you do not know how it was counted, say so plainly and say what you did own, which is presenting it. The pack supplies no method, baseline or metric name, so use only what you actually know | F6 is the JD's metrics line and the figure probers go after. JD content, EXP delivery. The weakest-assumption move is the credibility gain |
| D3 | "The role owns the post-event review and the KPIs in it. Where in your own work were the numbers' definitions decided, and by whom?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Hold: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose or shaped any definition behind them, say which and how you decided; if they were set by someone else, or definitions were not something you decided, say so plainly and return to presenting them. Then say as a plan what you would put first in a post-event review: what the event set out to do, what happened, and what you would change | F5 is where presenting and owning are most likely to be separated. The guidance does not contest the distinction. JD because it scores the stated line |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold-then-concede. Hold the sentence through two follow-ups: "I wrote the release checklist our QA team still uses." Add nothing to it. Answer slot: if QA or others shaped parts of it, say which parts and how; if it was yours alone, say so plainly. Concede in specifics. R2 means a vague concession will be followed up | The stock attribution probe, aimed at F7. EXP because it tests attribution honesty |
| E2 | "Sixty seconds: why you, rather than someone who has already run a monetised live game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "never worked on a game with in-app purchases" | Pause and restate. Then three sentences, each as you said it: "I ran the weekly content-drop calendar for our main title for the last two years." "I wrote the release checklist our QA team still uses." "I presented the monthly retention numbers to the studio head." Then concede in one sentence, "I've never worked on a game with in-app purchases," and give the C2 plan. Let the interviewer draw the inference; do not say these make you the better fit | Pulls F2, F6, F7 and F9 into one answer. JD content, with the Pressure delivery of a time box |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc in that order, each in its quoted terms: the 4 years as an associate producer at a puzzle-game studio, the calendar, the checklist, the retention presentations. Close on why live operations and why Saltmarsh, in your own words; the pack supplies no reasons. Answer slot: if your honest reason is partly about the role's next step, say that plainly | The biography question opens most sessions and is scored. EXP because it checks that the story matches the lines you will be asked about |
| G2 | "What's a live event in someone else's game that you'd steal from, and why?" | JD | [generic] | Selection scaffold: pick one you actually played or watched. Say what players were asked to do, why it worked in terms of calendar and rhythm, and one thing you would change. If none comes to mind, say so plainly and say what you would look at first. The pack names no game | A casual question on the JD's central topic, the live-events calendar. JD content, Conversational delivery |

### Requirement coverage

| Requirement (source) | Questions |
|---|---|
| "3+ years producing live-service games or apps" — JD | C1, G1 |
| "experience running a content calendar" — JD | D1, G1 |
| "Plan and run the live-events calendar for two of our mobile titles" — JD | A2, A3, G2 |
| "coordinate design, art, engineering and community teams on each update" — JD | C3 |
| "own the post-event review and the KPIs it reports" — JD | D3 |
| "comfortable with player-retention metrics" — JD | D2 |
| "manage the release checklist with QA" — JD | A4, E1 |
| "clear written communication" — JD | A5 |
| Not a JD line: in-app purchases | C2, E2 |

## Values cheat sheet

A values-style round is detected: the loop source describes a values conversation. The value names below are the official ones from Saltmarsh's values page.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players' experience conflict, the players' experience decides | Selection scaffold, B1. F2's sentence, "I ran the weekly content-drop calendar for our main title for the last two years," carries the calendar and no conflict between it and players. If no such time comes to mind, say so plainly and answer how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold, B2. F5's sentence, "Presented the monthly retention numbers to the studio head," carries no unwelcome message. If no such time comes to mind, say so plainly and answer how you would handle it |
| Leave the Build Greener | Each release should leave the codebase and the checklist better than it found them | B3, from F7: "Wrote the release checklist our QA team still uses." The sentence carries the checklist and its continued use, with nothing about improvement; any revision since is an answer slot in B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Your GDC talk argued a live team is judged by how often its patch notes describe what actually shipped. Inside the team here, who checks that, and where does it show up in the post-event review?" | Ties to Tobias's own public work (R1), so it reads as listening, not flattery. It also shows you understand the post-event review as an accountability tool |
| 2 | "What does a strong first ten minutes of an outage look like on your team, and where do people most often lose time?" | Treats the tabletop as a real competency and lets you calibrate what A1 is scored against |
| 3 | "With Project Larkspur folding the per-title event teams into one live-ops group, who owns each title's calendar, and who decides when two titles' events collide?" | Shows you read the September 2026 announcement and asks the real scope question about the role |
| 4 | "Purchases and the season-pass model are where I'd be new. What would you want someone in this seat to have learned by the end of their first quarter, and who would walk them through it?" | Names the C2 gap before it is pressed and turns it into a ramp conversation |
| 5 | "Could you point me to a post-event review you'd hold up as the standard here, and say what makes it good?" | Shows how the team defines owning the KPIs in the review, which F5's JD line leaves open |
| 6 | "What does the release checklist look like today, and where does it hurt most?" | Connects to F7 and to the Leave the Build Greener value, and invites a specific answer from someone with a QA background (R2) |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live-event calendars for two titles | Inflated form of F3 | F3's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: your material says a weekly content-drop calendar for your main title. Slots stay inside the drops |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope: "I presented the monthly retention numbers to the studio head." The limit is the pack's observation: your material says presenting, not owning |
| Led or managed a team | Negative you stated, F4 | The plain acknowledgment: "I've never led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment: "I've never worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the job description text and your background, both in your message. No `tuesday-dossier.md` was present, so none was consumed.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches sent:

- `Saltmarsh Games values` returned https://saltmarshgames.com/values
- `Saltmarsh Games interview process live operations producer` returned https://saltmarshgames.com/careers/interviewing
- `Saltmarsh Games mobile studio strategy news` returned https://saltmarshgames.com/news/project-larkspur
- `Tobias Wrenfield Saltmarsh Games` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise

Fetches sent: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both read in full.

What the news and talk results established is limited to what each result showed. Project Larkspur (September 2026) moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and retires per-title event teams in favour of a single live-ops group. The posting does not name its two titles, so tying them to Larkspur is an inference. Neither page was fetched past its search summary.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet: three values by official name; B1 to B4 themes |
| 2. `Saltmarsh Games interview process` | yes | Loop: recruiter call, then one 60-minute Outage Hour with the hiring manager (tabletop, then values conversation), no take-home. Persona weights; no graded-deliverable section |
| 3. `Saltmarsh Games strategy` / recent news | yes | A3, C2 rationale and reverse question 3, from the Larkspur summary; its full text was not read |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read R1 to R3 and reverse question 1, from one talk summary; the talk page was not fetched |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whatever your recruiter said about the Outage Hour (a type of outage, any materials, who else is in the room) → replaces the representative tabletop shape in A1 to A5 with the real one; usually one email
- Confirmation of Tobias's relationship to the role → persona weights re-derived if he is not the hiring manager
- Your CV text → F1 to F8 currently rest on five sentences from your message, and fuller lines would turn several `medium` rows into richer evidence
- The artifacts behind the lines: a monthly retention deck you presented, an export of the weekly content-drop calendar, the release checklist itself → F2, F5, F6 and F7 could move from `medium` toward `high`
- Your answers to the slots (was the puzzle title live-service, which teams the drops involved, did you set any number's definition) → quoted into the snapshot, with the rows they touch regenerated
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → reads the full Larkspur announcement and Tobias's talk, and adds a grounding brief. Offered once
- An underwriting dossier (tuesday-dossier.md), if you have one → the objection named from confirmed evidence, and a strategy binding each weak area; never a prerequisite
