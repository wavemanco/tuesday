I'll read the reference files the skill requires before writing anything.
Loading is done; now running three targeted searches (values, interview process, the interviewer's public footprint) before I write the pack.
Applying the pack fixes directly with the edit tool: neutral wording for Dan, plus renaming the pressure bank so its IDs don't collide with the fit-snapshot rows.
Next batch: remaining pronouns in the question banks and reverse questions, the Pressure-bank rename, and the unsourced concession line.
Your prep pack for Priya is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-1-denied-d1825b92/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

I built it for a peer conversation with Dan Kovac. It has 24 questions in tables with answer guidance and a rationale for each. They are grouped by persona, weighted Prober and Peer Evaluator highest, and each is tagged as VAL, EXP, JD, CO or CASE. The pack also has a fit snapshot, a reading of Dan, reverse questions and a requirement-coverage table. Section 13 lists the claims it won't coach.

- **Highest-ROI prep: D1.** A peer who owns sales strategy will probably press on Priya's own statement that she has "no classic sales-ops or quota-setting experience." The pack rehearses a plain acknowledgment, her adjacent evidence at its real scope, and a ramp plan.
- **Second priority: the ~$400M ARR figure.** A1, A2 and P1 cover how it was counted, the assumption she'd defend least, and how much of it was hers.
- **Quota-setting:** the pack never lets her relabel "annual volume targets" as quota-setting, since she said she has none.
- **Answer slots:** where your material was silent, the pack leaves a slot for Priya to answer from her real experience instead of supplying specifics.
- **Research was blocked.** My three searches (Northwind values, interview process, Dan's public footprint) were refused, so everything rests on what you gave me. The values bank is generic, and the interviewer read uses only your description of Dan. The upgrade menu says what a granted search or a deeper pass would add.
- **Left out as not applicable:** prep triage, graded deliverables, a grounding brief, a values cheat sheet and delivery coaching.

Say the word and I'll play Dan as the Skeptic on D1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind Data. **Round:** one 60-minute conversation with Dan, who would be Priya's peer, both reporting to the same VP (all from your message). Built at research tier L1; the three searches sent were refused, so the pack rests on what you provided (see Sources).

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in Priya's own words, and where a cell holds an answer slot, answer it from her real experience or say plainly that the practice was not hers.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and collaboration style, not generic virtue |
| EXP | Whether claims about her own work survive scrutiny, and what was actually hers |
| JD | The stated responsibilities and requirements, including the gaps |
| CO | Company and strategy fluency, at the altitude of Northwind's stated priorities |
| CASE | Structure and reasoning on a live problem from the role |

Left out, because their conditions were not met: prep triage (no prep time given), graded deliverables (none announced), grounding brief (your research note is three priorities and one threat, not a full strategy brief), values cheat sheet (no values round is documented and no values page was read), delivery coaching (no assessment provided).

## Fit snapshot

Requirements are the JD highlights as you gave them. Evidence cells hold only sentences from your message. No requirement in the highlights is a gate (a term such as location, schedule or authorization), so no gate row appears.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | low | [inferred] | transferability | Your material says product strategy and ops at a consumer-tech company, not the go-to-market side of a product line, and the words stay at that scope: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two-new-product-lines line makes a probe on how products reached customers likely. If any of your product work involved how a product was taken to customers, say which part and what was yours, in your own words; if none did, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [inferred] | discovery | The sentence touches growth; the material does not show whether it reached any of the four stages. Words stay at the sentence: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: if that change affected one of land, adopt, expand or renew, say which and how you know, in your own words; if it did not, or you cannot tell, say so plainly and stay with what you proposed. The figure itself raises the defend-the-number slots in A1 and A2 |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | No gap in the terms, but a self-described skill with nothing inspected behind it, and Dan's own profile words are "relentlessly data-driven", so expect a request for an example. Lead in the sentence's own terms: "I'm skilled in SQL and Tableau." Choose an example of analysis you ran yourself |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a revenue model used in carrier negotiations, not the design of a partner motion; the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's "required" makes a probe on partner-motion design likely. If any part of that work shaped how partners were worked with, say which part and what was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | The sentence already reaches the requirement in other terms. Use it whole and add nothing: "I set annual volume targets with cross-org consensus." Expect a probe on how consensus was reached; the slot for that is in B2 |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | presentation | The sentence reaches the requirement as use: "I use AI tools daily." The pack's observation is that the material says use, not building. Which tools and for what is an answer slot, in E2 |
| F7 | Fluency with sales-ops and quota-setting, as a role-family expectation for a GTM role beside a sales-strategy team [generic] | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to shrink the gap, and the annual volume targets in F5 are not offered as quota-setting |

## Reading the interviewer

Everything here is the profile as you relayed it; the search for Dan's public footprint was refused, so nothing beyond your description is used.

| Signal | What it implies for this conversation |
|---|---|
| Self-described "relentlessly data-driven" | Every number gets probed to its assumptions: the ~$400M figure (A1, A2, F1) and the revenue model (A3). Say plainly where you do not know how something was counted |
| Career spine in pricing and monetization | Pricing, packaging and unit-economics angles are Dan's native language, so expect C2 in some form. Ask for Dan's view rather than performing expertise you have not claimed |
| One early-stage-startup chapter | Builder stories can land with Dan, but no sentence of Priya's carries a zero-to-one story, so none is offered here |
| Peer, same VP | Expect seam and collaboration questions (bank B) and the question of what you add to Dan's team's work, not only what you need from it |

**Mirror opportunity (shared vocabulary, not a shared jump):** Dan's path runs through pricing and monetization; the fit snapshot's F4 row carries "built a partner-level revenue model used in carrier negotiations". Revenue modelling is common ground to name, at that scope. No career jump of Dan's is known, so none is offered.

## Persona table

Weights start from the peer relationship prior (Peer Evaluator and Data-Driven Prober), adjusted by Dan's signals, and are capped by the loop: your own words establish one 60-minute conversation with Dan, so no archetype fallback is used and no values-style round is detected.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Data-Driven Prober | Line-by-line on numbers and models; follow-ups two levels deeper | High. Peer prior, raised by Dan's "relentlessly data-driven" self-description | Know what you can and cannot say about how each figure was counted; name the weakest assumption you know of before Dan does; say plainly when you do not know | A (5) |
| Peer Evaluator | Seam between Dan's team and the new product lines; what you need from Dan; credit across teams | High. Peer prior; same VP | Reciprocity framing; propose seam principles rather than pretending to know the seam | B (5) |
| Case / Strategist | Live problems on GTM, packaging, partner motion | Medium. Not a hiring manager, but Dan's pricing spine tilts cases to packaging and economics | Clarify, objective, segmentation, approach, metrics, risks; say the structure aloud; challenge one premise respectfully | C (4) |
| Skeptic | The background mismatch, collegially | Medium. You have stated the absence yourself, so a peer is likely to test it | Rehearse D1 until it is boring: plain acknowledgment, adjacent evidence at its scope, a ramp plan | D (4) |
| Conversational / Rapport | Biography opener; AI "what are you playing with" | Low-medium. Any 60-minute conversation opens this way, and AI is a stated plus | A 90-second arc built from your own sentences; treat casual questions as scored | E (2) |
| Pressure | "How much of that was actually you?" | Low. No signal of a stress style | Pause, restate, hold through two follow-ups, concede specifically | P (2) |
| Values / Behavioral | Unpopular-truth and customer-first prompts | Low. No values round is documented and no values page was read | Selection scaffolds ending in the honest branch | G (2) |

## Question banks

**Highest-ROI prep in this pack: D1.** It is the single most predictable objection (a peer who owns sales strategy meeting a candidate who has said she has no classic sales-ops or quota-setting experience), so it gets the most follow-up levels and the exact concession wording. The second priority is the cluster around the ~$400M figure (A1, A2, P1).

Requirement coverage:

| JD requirement | Covered by |
|---|---|
| "own GTM strategy for two new product lines" | C1, C2, C3, D2, D4 |
| "identify whitespace across land/adopt/expand/renew" | A4, C3 |
| "run independent analysis in SQL and Tableau" | A4, A5, B4 |
| "partner-motion design experience required" | A3, C4, D3 |
| "strong cross-functional influence" | B1, B2, B3, B5, G1 |
| "AI experience a plus" | C3, E2 |

### A. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "That ~$400M ARR figure: walk me through how it was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the sentence says and no more: you proposed a store-surface change, and it was credited with the uplift. Answer slot: how the figure was counted, what it is sensitive to, and which part was yours, each in your own words; if you do not know how it was counted, or the credit was not yours alone, say so plainly and return to the proposal you made. Nothing in this pack supplies a method or baseline | F2 holds the pack's only headline figure, which a prober goes to first. EXP because it tests what was actually hers and how well she knows her own number |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name, in your own words, the assumption you would defend least before Dan does; it turns a gotcha into a credibility gain. Answer slot: if you know of one, say it; if you do not know how the figure was built, say that plainly and return to the proposal | Second level of the same figure (F2), asked the way probers ask it. EXP because it scores self-knowledge of one's own claim |
| A3 | "Walk me through the revenue model: what question was it built to answer?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story beats are only the sentence's: you built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: Dan's profile words raise a probe two levels deeper on what went into the model. If you can say what it took in and how it was handled, say so in your own words; if you do not know, or that part was not yours, say so plainly and return to the model you built | F4 is the evidence for partner work and the likeliest place a data-driven peer goes beyond the headline. EXP because the question is about what she built |
| A4 | "Show me how you'd use SQL and Tableau to find whitespace across land, adopt, expand and renew." | JD | [grounded] "skilled in SQL/Tableau" | Open with the sentence in its own terms, then think aloud: the question you are answering, what data you would ask whether exists, the cut by stage and segment, the view you would hand a peer, and what would change your mind. Ask Dan what is available instead of inventing tables. The pack names no dataset and claims no past analysis | F3 and F2's requirement meet here, and "independent analysis" is a JD line a data-driven peer will test live. JD with CASE delivery |
| A5 | "How do you decide a metric is trustworthy enough to build a GTM plan on?" | JD | [generic] | Structure it: what it is defined to measure, where it comes from, how fresh it is, who else relies on it, and what result would make you distrust it. The question needs no claim about your past, so the guidance makes none | A data-driven peer scores method as much as results (F3's requirement). `[generic]` because it is a pattern for the problem, not a fact about this employer |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claiming to know the seam: who owns the customer relationship, who owns the number, who decides when views conflict, and how a disagreement is surfaced early. Then ask Dan where the seam sits today. The question needs no claim about your past | The peer prior puts seam-splitting first, and F5's requirement is about influence without authority. JD because it scores the cross-functional line; `[generic]` because the actual seam is unknown |
| B2 | "You set annual volume targets with cross-org consensus. How did you get there?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats are the sentence's: you set annual volume targets, with consensus across orgs. Answer slot: the JD's cross-functional line makes a probe on disagreement likely. If orgs disagreed, say what about and what part of resolving it was yours; if consensus came without disagreement, or the resolving was not yours, say so plainly and stay with the targets. Do not call them quotas | F5 is the evidence for influence. EXP because Dan will test attribution, not the adjective |
| B3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams and credit was shared; it needs a named piece of work, what was yours, and what was another team's. Use "we" for context and "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A standard peer probe, relevant because the ~$400M figure is "credited" (F2). `[generic]` because no quoted sentence carries a credit-sharing story |
| B4 | "Compass is launching into the enterprise base. What do you need from my team, and what do I get from yours?" | CO | [grounded] "skilled in SQL/Tableau" | The company facts (enterprise expansion, the Compass launch) come from your research note. Needs: the field's view of where customers are stuck, access to the data, a shared definition of stages. Gives: analysis in SQL and Tableau in the sentence's own terms, offered as a question about what Dan would find useful. State the exchange both ways | The reciprocity question the peer prior predicts; F3 is the only quoted skill that translates into something Dan could use. CO because it needs the stated priorities |
| B5 | "Where would you disagree with how Sales Strategy runs today?" | VAL | [generic] | A trap for a candidate with no inside view. Do not pretend to one: say what you would want to understand first, and what evidence would change your mind, then offer a disagreement style that is specific and tactful. The question needs no claim about your past | Peers test disagreement style with equals (F5's requirement). `[generic]` because the answer depends on a team she has not seen |

### C. Case / Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have two new product lines. What do you need to know first, and what is your first deliverable?" | CASE | [generic] | Clarify (what each product is, who buys, what exists), set the objective, segment, state the approach, name metrics and risks, and challenge one premise respectfully. Say the structure aloud before using it. No claim about your past | The role's headline requirement (F1's) turned into a live problem. `[generic]` because the products are unnamed |
| C2 | "A much larger platform vendor bundles a competing capability into its suite. How do you position and package a Northwind product against that while profitability is a stated priority?" | CASE | [grounded] | The bundling threat and the profitability priority come from your research note. Clarify which product and segment, then frame where a standalone offer wins and where it does not, the packaging choices that follow, and the metrics. Invite Dan's pricing view; pricing is Dan's native ground. No claim about your past | Dan's pricing and monetization spine makes this the likeliest case. CO and CASE: the strategy supplies the problem, the delivery is live |
| C3 | "Compass is launching. Where's the whitespace across land, adopt, expand and renew in the enterprise base, and what would you pull first?" | CASE | [grounded] | Compass and the enterprise-expansion priority come from your research note. Structure by stage and segment, state the first pull, and say what you would do with an AI copilot's usage data as a question to ask, not a claim. No claim about your past | Covers the whitespace and AI lines (F2's and F6's requirements) against a current priority. CASE, with CO content |
| C4 | "Design a partner motion for a new product line: which partners, what do they get, how do we know it is working?" | CASE | [grounded] "built a partner-level revenue model used in carrier negotiations" | Structure first: partner types, what each side gives and gets, how you would test it, what you would measure. You may say once that you built a partner-level revenue model used in carrier negotiations, at that scope. Answer slot: if that work shaped how partners were worked with, say how; if it did not, say so plainly and stay with the model | F4 is a required line and the thinnest row; a live design problem lets her show structure without claiming a past she has not stated |

### D. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This sits next to a sales-strategy team, and you haven't done classic sales-ops or quota-setting. Which part would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | **Deepest rehearsal.** Level 1: say it plainly, "I don't have classic sales-ops or quota-setting experience." Then what you bring, each at its own scope: "I set annual volume targets with cross-org consensus"; "I'm skilled in SQL and Tableau"; "I built a partner-level revenue model that was used in carrier negotiations". Do not call the targets quotas. Level 2, "why not hire someone who has done it?": hold that the listed role spans more than that one skill, and concede the specific: on day one your team would know more about it. Level 3, "how do you close it?": a plan, not a past: what you would ask Dan's team to teach first and how you would check you had learned it. Answer slot: name a first step and timing only if you have decided them; if you have not, say what you would find out first. The limit, as the pack's observation: your material shows adjacent work, not sales-ops itself | F7 is the stated gap, and a peer who owns that function is the likeliest person to press it. JD because it scores a stated gap; Skeptic because it is asked collegially and persistently |
| D2 | "You've spent nine years at a consumer-tech company. What makes you think B2B land, adopt, expand and renew will translate?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Do not claim B2B experience; the sentence does not say it. Answer slot: if any of your work involved business customers, say which part and what was yours; if none did, say so plainly and stay with the product strategy and ops work. Then name the first thing you would learn about enterprise customers, as a plan | F1's transferability gap, said aloud by a peer. JD because it tests whether the background reaches the requirement |
| D3 | "The JD says partner-motion design experience is required. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the sentence carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of that work shaped how partners were worked with, say which part and what was yours; if none did, or it was not yours, say so plainly and return to the model. Hold through two follow-ups by returning to the model, never by adding to it | F4 is where a "required" line presses hardest. JD, hold-then-concede in the Skeptic's register |
| D4 | "Why this role, and why now?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Selection criteria: a reason that is yours, specific to the stated priorities in your research note (enterprise expansion, Compass, profitability), forward-looking rather than an exit from the last job. Arc beats from the sentence: consulting, then nine years in consumer tech. Answer slot: the reason itself, in your own words; if you have not settled one, say so plainly and say what you are trying to find out | The motivation probe every Skeptic runs; JD because it scores fit with the role as stated |

### E. Conversational / Rapport Builder (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with three beats: consulting, then nine years in product strategy and ops at a consumer-tech company, then why this role. For a proof point, pick one sentence: "I built a partner-level revenue model used in carrier negotiations" or "I set annual volume targets with cross-org consensus". Answer slot: the why-this-role beat, in your own words | The opener is scored for economy and coherence (F1's quote is the arc). EXP because it is the CV told aloud |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Start with the sentence: "I use AI tools daily." Answer slot: which tools, for what, and what changed in your work; if it is use and not building, say that plainly. Add a question about how Compass is meant to be used by customers, not a claim | AI is a stated plus (F6), asked casually and scored. JD because it tests the plus |

### P. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "That ARR result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate. Hold, through two follow-ups, the position the sentence carries: you proposed the change. Concede specifically what the sentence does not say: how the credit was assigned, and how much beyond the proposal was yours. Answer slot: which parts, if any, beyond the proposal were yours, in your own words; if none, say so plainly | The attribution probe behind F2's figure. EXP in a pressure register |
| P2 | "Sixty seconds: why you over someone who has carried a quota?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus" | Pause, restate, then three beats in sixty seconds: concede the quota point in your own words, then the revenue model and the volume targets at their own scope. Hold the rest; never reframe the targets as quotas | F7 is the premise and F4 and F5 are the counterweights. JD in a pressure register |

### G. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact afterward; "we" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | F5's requirement is about influence. `[generic]` because no quoted sentence carries this story |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a named customer need, the metric it cost, and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Values-style probes can arrive anywhere in a 60-minute conversation. `[generic]` because no values page was read |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent much of your career in pricing and monetization. What from that lens do you want the two new product lines to settle before they commit to a motion?" | Tied to Dan's own path; it asks for Dan's view and turns the interview into a peer conversation |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are asking what you add, not only what you get |
| R3 | "Where do you see the seam between Sales Strategy and emerging-products GTM, and what is the best way for us to surface a disagreement early?" | Shows seam-principle thinking and a collaborative disagreement style |
| R4 | "How much does the bundling pressure from a larger platform vendor show up in the deals you see?" | Built from your research note; asks Dan for ground truth rather than asserting it |
| R5 | "What does success for the two product lines look like at the end of the first year, given the profitability priority?" | Connects to a stated priority and asks for a measure, not a slogan |
| R6 | "Where does land, adopt, expand and renew data live today, and what could I query on day one?" | Practical and signals independent analysis (F3) without a claim |

## Prohibited claims

Built before the banks and binding on every cell above.

| Not coached | Basis | Honest form |
|---|---|---|
| Has quota-setting or classic sales-ops experience, or that the annual volume targets were quotas | A negative you stated, F7 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." No slot |
| Drove or generated the ~$400M ARR | Inflated form of F2 | F2's quote at its own scope: you proposed a change that was credited with the uplift. The limit is the pack's observation: the material says credited, not generated |
| Led the carrier negotiations, or designed or ran partner motions | Inflated form of F4 | F4's quote at its own scope: a model that was used in negotiations. The material says the model, not the negotiating or the motion |
| Owned go-to-market strategy for a product line | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. The material does not show the go-to-market side |
| Built or shipped AI products, or has Compass-style copilot experience | Inflated form of F6 | F6's quote at its own scope: daily use of AI tools |

## Sources

Provided documents: your message (JD highlights, candidate summary, interviewer profile as relayed, research note on Northwind's three stated priorities and the bundling threat).

Searches sent: "Northwind Data company values principles" (refused); "Northwind Data interview process strategy GTM role" (refused); "Dan Kovac Northwind Data Director of Sales Strategy" (refused). No fetches. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | All calls refused. Would have supplied official value names for VAL questions; bank G is `[generic]` instead |
| 2. Northwind Data interview process, GTM role | unavailable | All calls refused. Would have checked for a documented loop; persona weights rest on your description of one conversation with a peer |
| 3. Northwind Data strategy and recent news | skipped | Your research note already supplies the priorities and the bundling threat that feed the CO and CASE questions (B4, C2, C3) |
| 4. Dan Kovac, Northwind Data | unavailable | All calls refused. Would have added public talks and writing to the interviewer read and a tailored reverse question; both rest on your description only |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → any requirement beyond the six highlights gets a row and a question, and any term such as location, travel or authorization would be checked as a gate
- Priya's CV → evidence cells now quote your summary; CV lines would add detail and could upgrade F2 and F4 and replace answer slots
- Priya's answers to the slots in F1, F2, F4, A1, A3 and B2 → those rows regenerate from her own words
- Search permission, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → Northwind's published values, any documented loop, Dan's public talks and writing, and a fuller strategy brief for the CO and CASE banks
- The recruiter's prep email → focus areas and any pre-declared deliverable
- Prep time available → a prioritized prep schedule
- A tuesday-dossier.md from an earlier evidence review → verified evidence and absolute prohibited claims in place of the list built here
