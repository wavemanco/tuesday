I've read the skill's rules and I'm now running the research step: six searches on Kelverton Rail, the two panellists and a comparable job description.
Research was blocked, so I'm building the pack from your message and the recruiter's email only. Everything about Kelverton stays generic, and the sources section records each refused search.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-5-denied-c6016dfe/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

I built it for a hiring-manager plus commercial-director panel with a 15-minute spoken POV, exactly as the recruiter's email describes. I could not run any research. All six of my searches were refused, and I haven't seen the market report. So the pack contains nothing about Kelverton beyond what you and the recruiter's email told me, and the report-dependent parts (the POV's consensus item, A2, R4) give method only. The sources section lists each refused search.

- **POV:** the pack has a build section with a timing table, three theses with mandatory concessions, and a close on what it means for the operators. The plan is to bring one item from the report as the consensus, then diverge from it with a reasoned "no".
- **Highest-ROI question (B1):** "You haven't sold into rail and you haven't carried a quota. Why is this a safe hire?" Rehearse naming both limits yourself before they're pressed, then holding on what you actually said and conceding the rest plainly.
- **Most likely commercial probe:** your message doesn't say whether the £4M is one year or four. C1 to C3 and D2 prepare you for Ross's questions on it.
- **Unspoken objection:** ISV partners and train operators are different kinds of partner (B4). R3 asks them what "operator partnerships" covers.
- **Triage:** the four hours are split into four one-hour blocks, and the pack lists what to drop if you run short.

Say the word and I'll play Deepa as the Skeptic on B1, the question the pack names as highest-ROI.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description text and your CV, if you have them? They would turn the role-family rows F4 to F6 into sourced requirements and let me check F1 to F3 against your CV. I'm happy to proceed without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Second-round panel, Tuesday, 60 minutes. Panel as given in the recruiter's email: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Shape as given in the same email: a 15-minute spoken POV with no slides, then Q&A, with Ross expected to push on commercials.

Built on two assumptions. The round is a hiring-manager-plus-executive panel, because the recruiter's email says so. And no research ran: all six searches were refused, so nothing in this pack is a fact about Kelverton beyond what you and the recruiter's email supplied, and the market report was not in my hands. Sections left out for that reason: interviewer read, grounding brief, values cheat sheet, delivery coaching. Each is named in the upgrade menu.

## How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows values, not generic virtue |
| EXP | Whether the claims about your past survive scrutiny, and what was actually yours |
| JD | Whether you can do the stated job, gaps included |
| CO | Whether you can think at the company's altitude and have done the homework |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` rests on something you or the recruiter wrote, quoted beside it; `[inferred]` is derived from an adjacent source, with the derivation named; `[generic]` is a role-family pattern with no claim about you or Kelverton. An answer slot is an instruction for the interview: it names what an interviewer is likely to probe and gives you two honest branches, and it asks nothing of you here. Question IDs skip the letter F so they cannot be confused with the fit-snapshot rows F1 to F6.

## Prep triage (about four hours)

| Block | Do | Tied to |
|---|---|---|
| 1. 60 min | Re-read the report once with three marks: one item to bring as the consensus, one finding you would challenge, one you would leave out of the 18 months. Draft the POV in note form from the build section, not as a script | Graded deliverable, A2, A5 |
| 2. 60 min | Say the POV aloud against a timer, twice, and cut it to 13 minutes so interruptions do not push you over. Write the operator close last | Graded deliverable, A1, A4 |
| 3. 60 min | Write out your own answers to the slots in C1 (period, how counted, sensitivity, weakest assumption, your part), then say B1 aloud four times in the hold-then-concede order. Send the answers back and rows F1 to F3 regrade | B1 (highest-ROI), D1, D2, C1, C2, C3 |
| 4. 60 min | Commercial push: C4 and D3 aloud. Then the 90-second arc in E1, and choose three reverse questions | C4, D3, E1, Reverse questions |

Everything else is insurance: A3, B3, B5, E2, G1, G2.

## Fit snapshot

No JD was supplied, so requirements F1 to F3 are the recruiter's own words, quoted. F4 to F6 are role-family expectations with no source supplied, written as plain prose and labelled `[generic]`; they raise no answer slot. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, as quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships, with nothing inspected behind it, so the words stay at that scope: "Four of my nine years in partnerships were at a payments company running the ISV channel; I took it from 6 partners to 40." Answer slot: the recruiter's POV line makes a probe on what that work taught you about operator-facing partnerships likely. If any of it did, say what and how, in your own words; if it did not, say so plainly and stay with the count |
| F2 | "land on what it means for the operators themselves" — recruiter's email, as quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies, and the words stay there: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: the line about the operators themselves makes a probe on how close you were to operators' own people likely. If any of that work put you in front of them, say who and what you took from it; if it did not, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter's email, as quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message, "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | Influenced revenue is adjacent to commercial accountability and does not reach it, and you have said so: "I've never carried a direct quota; what I've had is influenced revenue." Keep "roughly" and "influenced". Answer slot: expect the defend-the-number probes: whether the £4M is one year or four, how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. Answer each in your own words; if you do not know how it was counted, say so plainly |
| F4 | Selling into the rail operator market — role-family expectation, no source supplied | "Never sold into rail specifically" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Never a claim to rail selling, and nothing added to make the gap feel smaller |
| F5 | Growing a portfolio of partners — role-family expectation, no source supplied | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [generic] | none | No gap in the requirement as written here, but a count with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you took it from 6 partners to 40 |
| F6 | Structuring commercial terms for a partnership — role-family expectation, no source supplied | none given | none | [generic] | discovery | Strong evidence would be one partner arrangement where you had a view on the terms and can say what it was. Selection scaffold: pick one such arrangement, say what the terms were and what part of them you held a view on; if no such arrangement comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would structure one |

## Graded deliverable: the 15-minute POV

The recruiter's brief, as quoted in F1 and F2: "present a short POV on where you'd take our operator partnerships over the next 18 months" and "land on what it means for the operators themselves". It must also survive F3, where Ross will push on commercials.

**Facts about you you may build on, each exactly as the row carries it**

| Row | Sentence from the row's evidence cell | Use in the POV |
|---|---|---|
| F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | The count and the figure are the only numbers you may use about your past, said as stated |
| F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The one operator-side credential your material carries; say it at its scope |
| F3 | "never carried a direct quota, only influenced revenue" | The limit to name yourself, in the plain words F3 gives |

Nothing about Kelverton's products, customers or numbers is in this pack. Whatever the report says, you bring from your own reading and attribute to it.

**Three theses, each with a mandatory concession**

| Thesis | One line to say aloud | 18-month shape | Mandatory concession | Leans on | Label |
|---|---|---|---|---|---|
| T1. Start from the operator's outcome | "I'd define each partnership by what changes for the operator, and work back from there." | Months 0 to 6: choose two or three operator outcomes from your reading of the report and test them against what operators say they need. Months 6 to 12: one pilot per outcome. Months 12 to 18: keep, scale or stop each | Outcomes are slower to attribute than a partner count, and eighteen months may show only leading indicators | F2, said at its scope | [generic] |
| T2. Deeper before wider | "I'd rather have a few partnerships that clearly work than many that merely exist." | Months 0 to 6: choose the few. Months 6 to 12: make them work and measure them. Months 12 to 18: widen only on evidence | It cuts against the 6-to-40 story in F1, and fewer partnerships mean more concentration risk and slower breadth. Say this before Ross does | F1, by contrast | [generic] |
| T3. Build the partner layer around the operator | "Where operators already depend on third parties, I'd make Kelverton the easy place to connect them." | Only if your reading of the report supports it; otherwise hold it for Q&A | The partners in F1 were ISV partners, not operators, and whether Kelverton wants third parties in the picture is not something your material shows. Use only conditionally | F1's ISV-channel quote, as a shape not a claim | [inferred] |

Recommended: lead with T1, use T2 for the sequencing, hold T3 for A1 and B4.

**Differentiation.** The report is the one source the panel's own strategy team wrote and every prepared candidate will have, so it is the consensus answer. Bring exactly one consensus item from it to prove you read it, then T1 as your divergence, then the anti-pick: one item the report puts forward that you would deliberately leave out of the 18 months, with the reason (A5). Choosing it is yours; the pack has not seen the report.

**Requested close: what it means for the operators themselves.** Three sentences, in this order. First, what an operator can do at month 18 that it cannot do today. Second, what the operator has to give or change to get it, named plainly. Third, when it first sees something: the month-6 and month-12 markers. For each move, have one line ready on what it costs, what it earns and how you would know, with no figure you cannot source.

**Timing**

| Minutes | Content |
|---|---|
| 0:00 to 1:30 | What you mean by operator partnerships, offered for them to correct; optionally the two limits from F3 and F4 in one sentence, which takes the sting out of B1 |
| 1:30 to 4:00 | Where things stand: your one consensus item |
| 4:00 to 9:30 | T1 with T2 as the sequencing, in three six-month windows |
| 9:30 to 11:30 | The anti-pick and the main risk |
| 11:30 to 14:00 | What it means for the operators themselves |
| 14:00 to 15:00 | What you would need to learn in the first 90 days, then hand over |

## Persona table

The shape of this session is the recruiter's: one 60-minute panel of two, a 15-minute POV and then Q&A. Weights rest on that plus the relationship priors, and no interviewer footprint was available to adjust them.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Deepa taking the POV forward into live problems on the roadmap | High: Deepa is the future manager, the hiring-manager prior is Case/Strategist plus Skeptic, and the POV is itself a strategy exercise | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| Skeptic | Deepa probing the gaps F3 and F4 state, and the step from payments to rail | High: the same prior, and your own message states both negatives | Rehearse B1 until it is boring: name the limits first, hold on what the quotes carry, concede plainly, end on a plan |
| Data-Driven Prober | Ross on the £4M and the 6-to-40 | Medium-high: the recruiter's words are "Ross will push on commercials", and your headline figures are the natural target | Know what you can say about how each figure was counted and say plainly what you do not know |
| Pressure | Ross interrupting and time-boxing on the commercials | Medium: the executive prior adds Pressure to the Prober, and "push" suggests it | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational | A warm opener or a casual question inside the Q&A | Low-medium: 15 of the 60 minutes are a prepared talk, leaving little room for rapport | A 90-second arc; treat casual questions as scored |
| Values/Behavioral | A behavioural question from either panellist | Low: no source in hand documents a values round and the recruiter's description has none | Selection scaffolds only, since no published values are in hand |
| Peer Evaluator | Not on this panel | No peer is named, so no questions are written for it | None needed |

## Question banks

### A. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're in the seat on day one. Which operator partnership do you start, and what do you need to know first?" | CASE | [generic] | Think aloud in order: what you need to know first (what the partnership is for, who at the operator it touches), the objective, a segmentation of operators you can defend, the one you would start with and why that one, the metric, the main risk. Challenge one premise politely, such as what partnership means here. The question needs no claim about your past, so the guidance makes none | Deepa is the future manager and the Q&A follows a strategy POV (F1), so a live roadmap problem is the natural next step. CASE because it scores structure |
| A2 | "Which finding in the strategy team's report would you challenge, and which would you leave out of the next 18 months?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Choose the finding before Tuesday from your own reading; the pack has not seen the report. Say it in the report's own terms, then your disagreement or your reason to deprioritise it, then what would change your mind. Answer slot: if no finding comes to mind that you would challenge, say so plainly and name the one you would sequence last, with the reason | The report is the shared source every prepared candidate holds, so departing from it with reasons scores as judgment (F1). CO because it tests homework and altitude; only the method is coached since the report text is not in hand |
| A3 | "Two operators want different things from us and we can only resource one. How do you decide, and what do you say to the other?" | CASE | [generic] | State your criteria before applying them, ask what each operator wants and would give, make the decision, then give the words for the one not resourced: a no with a reason and a next step. State any assumption about how Kelverton earns from operators as an assumption and invite correction. No claim about your past | A senior partnerships role includes saying no, and a commercial director is on the panel (F3, F6). CASE because it is a live trade-off |
| A4 | "How will we know in month six, twelve and eighteen that your plan is working?" | CASE | [generic] | A leading and a lagging indicator per window, with how each could mislead; separate what the operator would see from what Kelverton would see. Name the metric and what you would need to baseline it; give no target figure you cannot source. No claim about your past | Ross's commercial push (F3) lands first on measurement. CASE because the metrics come from the plan you just presented |
| A5 | "What would you stop, or say no to, in your first year?" | JD | [generic] | The anti-pick from the build section: one partnership type or activity you would deliberately not pursue, the cost of not pursuing it, and what would make you reverse. Chosen from your own reading of the report | Differentiating from the consensus answer needs a stated no (F1). JD because direction-setting is a stated part of the POV brief |

### B. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail and you haven't carried a quota. Why is this a safe hire?" | JD | [grounded] "Never sold into rail specifically", "never carried a direct quota, only influenced revenue", "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | The highest-ROI rehearsal in this pack. Name the limits first, in the plain words of the quotes: "I've never sold into rail specifically, and I've never carried a direct quota; what I've had is influenced revenue." Then hold on what the quotes carry and nothing more: five years in transport consulting on bus and light rail network planning, and nine years in partnerships, the last four running an ISV channel that went from 6 partners to 40. Do not say these amount to the experience the role asks for; let them draw that. Follow-up one, influenced is not owned: concede it in those words and return to the count. Follow-up two, bus and light rail is not a train operator: return to the consulting quote at its own scope (B2). Follow-up three, the first 90 days: a plan said as a plan, three things you would learn first and from whom, each yours to choose | The objection F3 and F4 state and F2 only partly answers, so it arrives in some form. JD because it scores the stated requirement including its gaps; deepest rehearsal because it is aimed where the material is thinnest |
| B2 | "Your consulting was bus and light rail network planning. How does that get you into a train operator's world?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say the quote at its own scope, and in your own words what you mean by the operator world from the other side. Answer slot: the recruiter's line about the operators themselves makes a probe on how close you were to operators' own people likely. If any of that work put you in front of them, say who and what you took from it; if it did not, say so plainly and stay with the network planning | F2 is adjacent work, and the gap between bus and light rail and train operating companies is the first place a Skeptic goes. EXP because it tests what the claim actually covers |
| B3 | "Why leave payments for rail-tech, and why now?" | EXP | [grounded] "last 4 at a payments company running the ISV channel" | Selection scaffold: a reason that names one specific thing you have seen or want, a separate reason for why now, and nothing you could not repeat under a second question. If no specific reason comes to mind, say so plainly, then give the nearest true reason your material does carry | Motivation consistency is the Skeptic's standard probe (F1). EXP because it tests whether the move is coherent with the history, not the company's values |
| B4 | "You ran an ISV channel. Operators are a different kind of partner. What carries over, and what doesn't?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer with two short lists. Answer slot: the recruiter's phrase operator partnerships raises what operators are to Kelverton as partners, so say which parts of the channel work you think carry over and which do not, in your own words; if none come to mind, say so plainly and return to the count: you took it from 6 partners to 40. Describe no mechanics your material does not carry | The side-of-the-table difference between ISV partners and operators is the unspoken objection to F1 and F5. JD because it scores whether the background fits the stated partnerships role |
| B5 | "Would you be comfortable carrying a number here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Answer yes or no first, then what you would want to understand: which number, over what period, with what authority over the levers. The plain acknowledgment, in your own words: "I haven't carried a direct quota." If you would welcome it, say so and what you would want agreed; if you have reservations, name them. Do not present influenced revenue as the same thing | F3 states the negative, so the question is likely from either panellist. JD because it scores the commercial accountability the role may carry |

### C. Data-Driven Prober (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue", "never carried a direct quota, only influenced revenue" | Say the figure as you gave it: roughly £4M of influenced revenue, keeping both words. Answer slot, in your own words: whether the £4M is one year or all four; how it was counted and by whom; what it is most sensitive to; the assumption you would defend least; which part was yours. If you do not know how it was counted, say so plainly: an honest gap beats a method you cannot repeat under the next question. Name no attribution model you did not use | A headline figure is the first thing a Prober tests, and the period is not stated in the quote (F3). EXP because it tests what survives scrutiny |
| C2 | "What counted as a partner in the six, and in the forty?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: what counted as a partner is yours to say in your own words; if the definition was set by someone else, changed between six and forty, or was never formal, say so plainly. Name the assumption in the count you would defend least before they do. Keep the count as the quote states it and add no detail your material does not carry | F5 is a count with nothing inspected behind it, and a denominator question follows any growth figure. EXP |
| C3 | "If we took your best partner out of that figure, what's left?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | A sensitivity probe. Answer slot: what the figure is sensitive to, in your own words; if you do not know how concentrated it was, say so plainly and say what you would look at to find out. Offer no concentration figure you cannot source | F3's figure is influenced revenue, which is where a sensitivity question presses. EXP |
| C4 | "How would you structure the commercials of an operator partnership: what do we give, what do we get, and how do we know it is worth it?" | CASE | [generic] | State your assumptions about how Kelverton earns from operators as assumptions, then structure it: what each side contributes, what each side risks, the terms you would test first, the point at which you would walk away, and how payback would show inside 18 months. Name what you would need to see; give no number you cannot source. Frame it as how you would structure it, not as a history | F6 has no evidence behind it, and Ross is expected to push here (F3). CASE because it is a live problem with commercial content |

### D. Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail and carried a quota?" | JD | [grounded] "Never sold into rail specifically", "never carried a direct quota, only influenced revenue", "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause and restate the question in one sentence. Concede only what you stated: "I haven't sold into rail and I haven't carried a direct quota." Hold on what the quotes carry: the consulting years on bus and light rail network planning, and the ISV channel that went from 6 partners to 40. Do not claim to be better on their terms; let the comparison stand. If pushed that it is still not rail, repeat the consulting quote at its own scope rather than adding to it, then concede plainly what you would have to learn | B1 arriving with a clock on it from the commercial director (F3, F4). JD, with Pressure delivery |
| D2 | "That £4M — how much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue", "never carried a direct quota, only influenced revenue" | Hold the word you used: influenced. Answer slot: which part of the influence was yours, in your own words; if it was shared or you cannot separate it, say so plainly. After the second push, concede in your own sentence: "I've never carried a direct quota, only influenced revenue." Do not turn influence into ownership under pressure | The Pressure stem aimed at F3's figure. EXP because it tests attribution under stress |
| D3 | "You haven't mentioned payback. Convince me this pays back inside eighteen months." | CASE | [generic] | Pause, restate, answer in ninety seconds. Hold the thesis, and concede what the plan cannot yet know: whatever Kelverton's own figures say. Name the one assumption you would test first and the result that would make you change the plan | An interruption of the POV on its weakest flank, which is the commercial one (F1, F3). CASE with Pressure delivery |

### E. Conversational (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc whose beats are the quotes: five years in transport consulting on bus and light rail network planning; nine years in partnerships; the last four at a payments company running the ISV channel, from 6 partners to 40. Your message does not say whether the consulting years sit before or inside the nine, so say the order as it happened. End on why Kelverton, in your own sentence, since no quote carries it. Add no roles or titles | The casual opener is scored too (F1, F2). EXP because it tests whether the story is coherent and economical |
| E2 | "What draws you to scheduling software in particular?" | CO | [generic] | Selection scaffold: one specific thing about scheduling you have seen or read, tied to what operators do, not a general interest. If no such thing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would find out | A casual question that tests homework (F2). CO because the product category is the company's own |

### G. Values/Behavioral (weight: low)

No published values are in hand and no values-style round is documented, so these two are persona stems rather than values coverage.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to a partner or to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you said it plainly, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem, ranked low because nothing documents a values round (F1). VAL |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold: a named stake, the moment you chose, and what it cost. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The same stem family; relevant to a role whose close is what it means for operators (F2). VAL |

### Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1 POV over the next 18 months | A1, A2, A3, A4, A5, D3, graded deliverable | |
| F2 What it means for the operators | A1, B2, E1, E2, graded deliverable close | |
| F3 Ross will push on commercials | B5, C1, C2, C3, C4, D1, D2, D3 | |
| F4 Selling into rail | B1, B2, D1 | |
| F5 Growing a partner portfolio | B4, C1, C2, C3, E1 | |
| F6 Commercial terms | A3, C4 | |
| Published company values | — none, and why | Research was refused and no values page is in hand; G1 and G2 are generic stems |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To Deepa: "At the six-month mark, what would have to be true for you to say this hire has worked?" | Turns the 18-month POV into a checkable test, and the answer shows whether the role carries a number (F3) without you asserting anything |
| R2 | To Ross: "Which commercial arrangement with operators is working best today, and which are you least sure of?" | Invites him to talk commercials in his own terms and shows you are pricing the role into real commercials (F6) |
| R3 | "When you say operator partnerships, which kinds of arrangement sit under that, and where does a partnership stop and an account relationship start?" | Defines the central term, which the ISV-versus-operator difference in B4 makes the real ambiguity (F1) |
| R4 | "What has moved since the strategy team circulated that report last quarter that I would not see from the document?" | Shows you read it and are thinking about how current it is, without reciting it |
| R5 | "What do your strongest operator relationships have in common, and what would someone from outside rail most likely misread?" | Asks for their candid read on exactly the outsider gap in F4, and turns an objection into coaching |
| R6 | "What would my first 90 days look like, and who at the operators would I spend time with?" | Ties to the ramp plan in B1 and to what it means for the operators themselves (F2) |

No interviewer profile was available, so none of these is tied to a panellist's own path. R1 and R2 are tied to their stated roles only.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I've never sold into rail specifically." Then a plan said as a plan. No slot |
| Has carried a direct quota, or owned the £4M as revenue | Negative the candidate stated, F3 | "I've never carried a direct quota; what I've had is influenced revenue." C1 asks only how the figure was counted |
| Knows train operating companies from the inside | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says bus and light rail network planning, not train operating companies. B2's slot stays inside the consulting work |
| Credit for how the ISV partners were recruited, tiered or paid, or for building the programme | Inflated form of F1 and F5 | F1's quote at its own scope. The limit is the pack's observation: your material states the count and the influenced figure, not the method. C2's slot asks only what counted as a partner |
| Facts about Kelverton, or findings of the report, supplied by this pack | No source in hand: research was refused and the report text was not supplied | Use only what you read in the report yourself, attributed to it |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report is named in your message but was not supplied to me and was not used. No dossier was present.

Searches sent, every one refused; no fetches were sent:

| # | Query | Outcome |
|---|---|---|
| 1 | Kelverton Rail company values | refused |
| 2 | Kelverton Rail interview process partnerships manager | refused |
| 3 | Kelverton Rail strategy news train operating companies scheduling software | refused |
| 4 | Deepa VP Partnerships Kelverton Rail | refused |
| 5 | Ross Commercial Director Kelverton Rail | refused |
| 6 | Senior Partnerships Manager rail technology train operating companies job description | refused |

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Call refused. Would have fixed the value names for VAL raising sources and the values cheat sheet if a values-style round were documented; G1 and G2 stay generic |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | Call refused. Would have shown rounds beyond this one; this session's shape comes from the recruiter's email, so persona weights are unchanged |
| 3. `Kelverton Rail strategy` and recent news | unavailable | Call refused. Would have grounded a CO question in current strategy and supplied the grounding brief; A2 and R4 are method only |
| 4. `Deepa` and `Ross` with the company | unavailable | Both calls refused. Would have supplied an interviewer read, adjusted persona weights and tied a reverse question to a panellist's path |
| 5. Representative `Senior Partnerships Manager` JD | unavailable | Call refused. Would have turned the role-family rows F4 to F6 from `[generic]` to `[inferred]` and sharpened the JD-tagged questions |

## Upgrade menu

- Search access, then a rerun: values, loop beyond this round, current strategy, each panellist's public footprint and a comparable JD would come back, adding the interviewer read and grounding brief and regrading F4 to F6
- The report's text, or its headline findings pasted in: the consensus item in the POV build, A2 and R4 become `[grounded]`, and a grounding brief can be added
- The JD text: F4 to F6 become `[grounded]` requirements and B1, B4 and C4 are re-aimed at its own lines
- Your CV: rows F1 to F3 are checked against it, and an inspectable artifact behind the £4M, such as an export showing how the influenced figure was counted, would raise their confidence above medium
- Your answers to the slots in B2, C1, C2 and D2, said or written outside a drill: they enter the fit snapshot as quoted material and the rows regenerate
- Deepa's and Ross's full names, or their public profiles pasted in: an interviewer read, adjusted persona weights and a reverse question tied to each path
- The recruiter, in one email: what operator partnerships covers at Kelverton, whether there was a JD, and what the Q&A will focus on
- A tuesday-dossier.md from earlier evidence work: confirmed evidence would replace the inferred highest-ROI objection and add strategy limits per weak area
