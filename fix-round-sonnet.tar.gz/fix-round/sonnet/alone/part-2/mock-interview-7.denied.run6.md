I'll read the reference files the skill points to before building the pack.
The pack is written and saved. I'm sending it over now.

Your prep pack for the Live Operations Producer interview is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-denied-f9ffce4d/saltmarsh-games_live-operations-producer_interview_pack.md`.

- **Assumption:** you didn't say how Tobias relates to the role, so I built it for a hiring-manager round, a single 60-minute session. That puts Case and Skeptic questions first.
- **No company research:** web search wasn't granted, so I tried four searches (values, interview process, strategy, Tobias) and all were refused. The pack rests only on your JD and your message. Nothing in it claims anything about Saltmarsh itself, and the case questions are generic. The Sources section lists each refused search. The upgrade menu says what research would add if you grant search.
- **Highest-ROI prep (B1):** the in-app purchase gap. It is the one gap you stated that wording can't close. The guidance is to say the limit plainly and early, then give a credible ramp plan.
- **Other likely probes:** whether you "presented" or "owned" the retention numbers, one title versus two, and coordinating four disciplines without having led a team.
- **Answer slots:** where your material is silent, the pack gives instructions for you to answer in your own words, not scripted lines. Fill those in before Friday.
- **Coverage:** 22 questions across seven personas, a coverage table against each JD requirement, six reverse questions and a short prep triage.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did the recruiter say anything about the format or a task to prepare?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Role:** Live Operations Producer, Saltmarsh Games (mobile game studio, about 350 people, per your message)
- **Interviewer:** Tobias Wrenfield, Head of Live Operations
- **Relationship and round:** assumed hiring manager, a single 60-minute session on Friday. You did not say how Tobias relates to the role, so the persona weights below rest on the hiring-manager prior and will move if that is wrong.
- **Candidate:** Femi
- **Research:** none ran. Search permission was not granted, so everything below comes from your JD and your message. See Sources.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Every question carries both, so you can rehearse the delivery and the content.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows what the role needs. No published values were obtained, so VAL here means behavioral and is not mapped to company values |
| EXP | Work-experience deep-dive: whether the claims about your past survive a probe |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge. None in this pack, because no company research was available |
| CASE | A live problem set in the role, scored on structure and reasoning |

Guidance is scaffolding, not a script. Question IDs run by persona: A Case/Strategist, B Skeptic, C Data-Driven Prober, D Conversational, E Pressure, V Values/Behavioral, P Peer Evaluator. Fit-snapshot rows are F1 to F9.

An answer slot is an instruction for the interview, not a question for you now. Meet it with either honest branch: say what you did in your own words, or say plainly that the step was not yours or did not exist.

## Prep triage

Sized to the time before Friday. Do these in order and do them well.

1. **B1, out loud, three times.** It is the highest-ROI prep in this pack.
2. **B3 and C1, together.** Settle what you can and cannot say about how the monthly retention numbers were counted, including "I don't know" where that is true.
3. **D1, timed to 90 seconds.** It is the opening arc.
4. **A1 and A3.** Practice saying the structure aloud before filling it.
5. **Reverse questions.** Choose three and say them once.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title, not events and not two titles, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's "plan and run" makes a probe on how the calendar's contents were decided likely. If any of those decisions were yours, say which and how you decided, in your own words; if the contents were set elsewhere, or there was no such step, say so plainly and stay with running the weekly calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [inferred] | discovery | Your material says you have not led a team and is silent on working with these four disciplines, so the plain words are "I haven't led a team." Answer slot: the JD's coordination line makes a probe on how you worked with design, art, engineering and community likely. If you worked with any of them on the content drops, say which and what you needed from them, in your own words; if you did not, or it was not yours, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers, not reviews and not the measures behind them, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's review-and-KPIs line makes a probe on the numbers likely. Say which part of those monthly numbers was yours, including how they were counted and what they are sensitive to, if you know; if the counting was done elsewhere, or you do not know how, say so plainly and stay with presenting them to the studio head |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it, not how releases ran against it, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's "manage ... with QA" makes a probe on how releases ran against the checklist likely. If you ran releases against it with QA, say how, in your own words; if QA ran it, or there was no such step, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and a two-year calendar, and does not show how many of the four years the title was a live-service one. The words: "I have four years as an associate producer at a puzzle-game studio." Answer slot: the JD's 3+ years makes a probe on how many of those years were on a live-service title likely. Say how many, in your own words; if only some were, or you do not know how to count it, say so plainly and stay with the four years and the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a statement with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: you ran it, weekly, for the main title, for two years, because a named record beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap on the requirement as worded, but nothing inspected stands behind it, so expect a probe on how the numbers were counted (C1). Lead with it as quoted: monthly, retention, to the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | The checklist is one written document that others still use; the material shows no other writing and nothing on how clear it is. Answer slot: the JD's line makes a request for a writing sample or a written exercise likely. If the checklist or another document you wrote can be shared, say which; if none can, say so plainly and say how you would write the first one for them |
| F9 | Monetization of live events through in-app purchases (role-family requirement, not in the JD) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work, and nothing added to make the gap feel smaller |

## Persona table

Weights start from the hiring-manager prior (Case/Strategist and Skeptic dominant) and are adjusted by what your material shows. Depth follows weight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A, 5 questions) | Live problems from the actual role: planning a month of events, diagnosing a retention drop, a release-day conflict | High. The hiring-manager prior puts it first, and the JD's duties (calendar, coordination, review, checklist) each convert directly into a live problem | Clarify, objective, segmentation, approach, metrics, risks, said aloud. Challenge one premise respectfully per case |
| Skeptic (B, 5 questions) | Quiet, persistent probing of the gaps: in-app purchases, leading no team, one title versus two, presented versus owned | High. The same prior puts it second, and your own message names two gaps (F2, F9) and the snapshot shows three transferability rows (F1, F3, F4) | Rehearse B1 until it is boring: the plain acknowledgment first, the ramp as a plan, the concession stated specifically. Candor over bluffing a competency the interviewer owns |
| Data-Driven Prober (C, 3 questions) | Walks the retention numbers line by line: counted how, what assumption is weakest | Medium. Retention is the one metric your material names (F3, F7), so it is where a prober would start | Know what you can and cannot say about how the numbers were counted and say plainly when you do not know. Name the weakest assumption before they do |
| Conversational/Rapport Builder (D, 3 questions) | An unstructured opener, "walk me through the journey," then casual questions that are still scored | Medium. A 60-minute session with a department head very likely has an opening of this kind, and the risk is treating it as unscored | A pre-scripted 90-second arc (D1). Treat casual questions on the JD's hot topics as scored. Never close the reverse-question slot with "you've covered everything" |
| Pressure/Stress (E, 2 questions) | Time-boxed challenges on title, years and attribution | Low to medium. Nothing you gave points to a stress format, but the thin rows (F1, F5) are where one would press | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |
| Values/Behavioral (V, 2 questions) | Scenario probes on disagreement and hard truths | Low. No loop source documents a values round and no company values were obtained, so these are behavioral only | Selection scaffolds ending in the honest branch; "we" for context, "I" for contribution |
| Peer Evaluator (P, 2 questions) | Seam-splitting between live ops and neighbouring teams; collaboration in writing | Low. Tobias is the Head of Live Operations by your account, so a peer posture is unlikely from him, though the role works across four teams | Reciprocity framing; propose seam principles rather than pretending to know the seam |

## Question banks

B1 is the single most likely objection to this candidate, the one this pack names as its highest-ROI prep.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would plan the next month of live events across two titles. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what each title is trying to achieve this month, what is already committed, what each team can deliver, how success will be judged. Then objective, segmentation (the two titles, the kinds of event, the player groups), approach (cadence, dependencies, buffers), metrics, risks. Think aloud and challenge one premise, for example whether both titles should share a cadence. The question needs no claim about your past, so the guidance makes none | The JD's calendar duty (F1's requirement) as a live problem. CASE because it scores structure and clarifying, not recall |
| A2 | "After an update ships, a retention measure you report falls against the previous update. Diagnose it." | CASE | [generic] | Clarify the measure's definition and the cohorts first. Compare like with like. List what changed in the update and which of the four teams (design, art, engineering, community) would know about each change. Order your checks from cheapest to dearest. Name the weakest assumption in your diagnosis before they do, and say what you would report before the cause is known. No claim about your past | F7 and F3's requirements as a live problem. CASE because it asks for a diagnosis in the moment |
| A3 | "The day before an update ships, QA still has an open item on the release checklist. Walk me through what you do." | CASE | [generic] | Ask first what the item is, what it could break, and who decides to ship. Lay out the options (ship as is, fix, cut the item, move the date), what each costs each team, what you would tell community and when, and what you would record on the checklist afterwards. No claim about your past | F4's requirement as a decision rather than a document. CASE because the answer is a decision under time pressure |
| A4 | "Design wants Friday, engineering says the build lands the following week, and community has already announced the date. What do you do?" | CASE | [generic] | Facts first: is the build date firm, and what moved. Then the options (partial release, slip with a message, cut scope) and what each costs each team. Say who decides and who advises, and ask rather than assume; bring the decision owner in. Say what you would tell community and when. No claim about your past | F2's requirement, which is where a producer with no team to lead is probed hardest. CASE with JD content |
| A5 | "A live event has just ended. What goes into the post-event review, and what do you report?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head" | Structure it: what the event was meant to achieve, what you compare it against, which measures, what went wrong in delivery as well as in the numbers, what you change next time. Name the weakest assumption in the measures you pick. If you want an anchor for the reporting side, the sentence you can stand on is "I presented the monthly retention numbers to the studio head." Go no further than that sentence | F3's requirement as a live problem, with F3's own sentence as the only anchor. CASE because it asks you to design the review rather than recall one |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Say a live event you are scheduling is paired with an in-app purchase offer. You haven't worked on a game with in-app purchases. What do you need to know first, and who do you ask?" | JD | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | **Highest-ROI rehearsal.** Say the limit early, unasked, in plain words: "I haven't worked on a game with in-app purchases." Then give the plan as a plan: what you would ask first, and which two of the JD's four teams (design, art, engineering, community) you would ask. Expect three follow-ups. First, how you would learn it: say how you would, concretely, in your own words. Second, what you would do before you understood it: say what you would not decide alone and who you would bring in. Third, what happens when the offer underperforms and you are asked why: concede specifically, that at first you could not judge it on your own, and say what you would need to be shown and by whom. If asked what you do bring, say what your material carries, "I ran the weekly content-drop calendar for our main title for the last two years" or "I presented the monthly retention numbers to the studio head", and stop. Do not stretch either sentence to cover purchases or revenue. Hold the plan through all three follow-ups; the only thing you concede is the limit | F9 is the one row you stated as a gap, and it cannot be closed with wording, so the answer is a plain limit plus a credible ramp. JD because it tests whether you can do the listed job with a gap in it; the hypothetical keeps the question from presupposing anything about your past |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick the weakness your material actually states rather than a modest-sounding one that is really a strength. Your material states two: "I haven't worked on a game with in-app purchases" and "I haven't led a team." Choose the one you would honestly pick, say it in one sentence, then give the ramp as a plan. If neither is what you would honestly pick, say so plainly and choose from your own judgment, not from this pack | F9 and F2 are the stated gaps, so this stem lands on them. JD because it scores honest self-assessment against the listed requirements |
| B3 | "You presented the monthly retention numbers to the studio head. How much of those numbers was actually yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start from the sentence and hold it: "I presented the monthly retention numbers to the studio head." Answer slot: say which part of those numbers was yours, including how they were counted and what they are sensitive to, if you know; if the counting was done elsewhere, or you do not know how, say so plainly and stay with presenting them. Hold through two follow-ups by returning to the sentence, never by adding to it | F3 is where the JD's ownership language presses hardest on your material. EXP because it tests what was yours |
| B4 | "You ran the weekly content-drop calendar for your main title. This role covers two titles and a live-events calendar. What carries over and what doesn't?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold what the sentence carries: "I ran the weekly content-drop calendar for our main title for the last two years." Your material shows one title and content drops. Answer slot: if you ever ran a calendar for a second title, or any of what you scheduled was an event, say what and how, in your own words; if not, say so plainly and stay with the main title. What you would need to learn first is a plan, so say it as one | F1 and F6. JD because it tests the step from your calendar to the one the role describes |
| B5 | "The JD asks you to coordinate design, art, engineering and community on each update, and you haven't led a team. How do you get four disciplines to follow a calendar?" | JD | [grounded] "Never led a team" | Open with the plain words: "I haven't led a team." Then the plan: ask each discipline what it needs and by when, keep the calendar where all four can see it, agree up front who decides. Answer slot: if you worked with any of the four on the drops, say which and what you needed from them; if you did not, say so plainly and say how you would start. Do not claim authority you did not have | F2's gap, with the plain acknowledgment sourced to your own sentence. JD because coordination is the stated duty |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you know about how they were counted, in your own words; where you do not know, say so plainly and stay with "I presented the monthly retention numbers to the studio head." Before they ask, name the assumption behind the numbers you would defend least, if you know one; if you do not, say that. Never supply a method you cannot repeat under a second question | F7 and F3 together: the one metric your material names gets probed to its definition. EXP because it tests the claim |
| C2 | "Which retention measures would you put in a post-event review, and what would each one miss?" | JD | [generic] | Choose two or three measures you can define aloud. For each, give its blind spot in a clause. End with the one you would trust least and why, which is your weakest-assumption move. No claim about your past | F3's KPIs line and F7's metrics line. Generic because nothing obtained says what this studio measures |
| C3 | "Two teams quote different figures for the same event. How do you decide which number goes in the review?" | CASE | [generic] | Ask for each figure's definition and source first. Reconcile where you can. Where you cannot, report both with the difference stated. Say who should own the definition so it does not recur, and say what you would not report. No claim about your past | F3's "KPIs it reports" as a live problem. CASE because it tests process under disagreement |

### D. Conversational/Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get to where you are, and why this role?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc with only the beats those four sentences state, in this order: the four years, the weekly calendar, the checklist, the monthly numbers. Tell each in your own words at its own scope. Answer slot: the "why this role" beat is yours; say what pulls you to live operations and to this studio. If you cannot yet say, say so plainly and say what you want to find out. End on what you want to do next, not on a claim about what you have proven | F5, F1, F4 and F3 are the arc's beats. EXP because it asks for your path; the casual register is the risk, since the answer is scored |
| D2 | "Which live-service game's event calendar do you follow closely, and what do you notice about how they run it?" | JD | [generic] | Pick one you actually follow and say one observation you can defend, for example how it paces its events or how it announces them. If none comes to mind, say so plainly, then say what you would look at first when studying one | F6's calendar requirement in a casual register. Generic because the question asks for your current habits, which this pack cannot know |
| D3 | "Tell me about the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Stand on the sentence: "I wrote the release checklist our QA team still uses." Answer slot: the JD says "manage ... with QA", so expect a probe on how releases ran against it. If you ran releases against it with QA, say how; if QA ran it, or there was no such step, say so plainly and stay with the checklist you wrote | F4. EXP because it tests the claim; asked casually, it is still scored |

### E. Pressure/Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we put you on two titles when your title so far is associate producer?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Pause and restate. Hold what the sentences carry: "four years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years." Then concede specifically that the JD asks for 3+ years producing live-service games and that your material does not show how many of the four years were live-service. Answer slot: say how many, in your own words; if you do not know how to count it, say so plainly. Do not fold on the core: the four years and the calendar stand | F5 and F1. JD because it scores the stated years requirement; the time-box is the pressure |
| E2 | "That calendar. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you set parts of the calendar, say which and how you decided; if the contents were set elsewhere, or by a team, say so plainly and stay with running it weekly. Hold through two follow-ups and concede only what you can name. Do not drop the verb you can stand behind | F1 and F6. EXP because it is the attribution probe in its sharpest form |

### V. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time design, art, engineering or community disagreed about an update's date." | VAL | [generic] | Selection scaffold: pick a time two teams wanted different dates. It needs a named stake, what you did, and a relationship intact at the end; use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's four-team coordination line (F2's requirement) as a behavioral prompt. VAL here means behavioral, because no company values were obtained |
| V2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: choose a time the hard message actually landed, with a named stake, a moment you did not soften it, and the relationship intact after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not supply an ending the story did not have | A standard values-round stem, included because Tobias may use one. Generic because no source ties it to this loop |

### P. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where is the seam between live operations and design, and what happens when we disagree about an update?" | CASE | [generic] | Offer seam principles rather than claiming to know the seam: who decides what, who must be told, and where disagreements go. Use reciprocity: what you bring to the teams, not only what you need. Say how you would disagree with tact and with spine. No claim about your past | F2's requirement from the other side of the table. Generic because nothing obtained describes how the teams divide the work |
| P2 | "Four teams will read the same update note. How do you keep them aligned in writing?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Structure of the note: what changes, when, who needs to act, what is still open; one place for the current version; how corrections are flagged. The one written document your material carries is the checklist: "I wrote the release checklist our QA team still uses." Answer slot: if you can share it or another document you wrote, say which; if none can be shared, say so plainly and say how you would write the first one for them | F8's requirement. JD because written communication is a stated requirement |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A4, B4, D2, E2 |
| "coordinate design, art, engineering and community teams on each update" | A4, B5, V1, P1 |
| "own the post-event review and the KPIs it reports" | A2, A5, B3, C1, C2, C3 |
| "manage the release checklist with QA" | A3, D3 |
| "3+ years producing live-service games or apps" | D1, E1 |
| "experience running a content calendar" | B4, D2, E2 |
| "comfortable with player-retention metrics" | A2, B3, C1, C2 |
| "clear written communication" | P2, D3 |
| In-app purchases (role-family, not in the JD) | B1, B2 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "For the two titles, what would a good first 90 days look like in this seat, and what would make you say it went well?" | It shows you are planning for outcomes and gives you the success bar in his words |
| "How are the live-events calendars planned today, and where does the producer's call begin and end?" | It surfaces the scope behind "plan and run" (F1), which your material only partly covers |
| "Which KPIs does the post-event review report today, and who reads it?" | It clarifies what "own the KPIs" means in practice (F3) and shows interest in the review's use, not only its production |
| "How does the release checklist work between producers and QA at the moment, and what would you change?" | It ties to the one document you wrote (F4) and invites his view of it |
| "Which teams does the producer lean on most for each update, and where does coordination tend to strain?" | It addresses the coordination duty (F2) as a working problem and tells you where to put your early effort |
| "My background hasn't included in-app purchases. Where would you want me ramped first, and who would be my guide?" | Use it only after B1 has been raised. It turns the stated gap into a joint plan and shows you have already thought about the ramp |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Four years producing live-service games, or 3+ years of live-service production | Inflated form of F5 | F5's quotes at their own scope. The limit is the pack's observation: your material says four years as an associate producer and a two-year calendar, and does not show how many years were live-service. E1's slot stays inside the four years and the calendar |
| Planned or owned the live-events calendar | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." B4's and E2's slots stay inside the weekly calendar |
| Owned the retention KPIs or the post-event review | Inflated form of F3 | F3's quote at its own scope: "I presented the monthly retention numbers to the studio head." B3's slot asks only which part of the numbers was yours |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope: "I wrote the release checklist our QA team still uses." D3's slot stays with the checklist |
| Led a team or led cross-functional teams | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't led a team." No slot |
| Has monetization or in-app purchase experience | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |

## Sources

**Provided documents:** the job description text you pasted; your background message. No dossier was present.

**Searches sent, all refused (search permission was not granted):**

- `Saltmarsh Games values`: refused
- `Saltmarsh Games interview process live operations producer`: refused
- `Saltmarsh Games strategy news mobile`: refused
- `Tobias Wrenfield Saltmarsh Games`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The call was refused. It would have supplied value names for VAL questions, and a values cheat sheet only if a loop source also documented a values round. VAL questions here are generic behavioral prompts |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | The call was refused. It would have established the loop and moved the persona weights. They rest on the hiring-manager prior and your own account of a single 60-minute session |
| 3. `Saltmarsh Games strategy news mobile` | unavailable | The call was refused. It would have grounded CO questions and the CASE bank in the studio's current priorities. There are no CO questions and the CASE items are labeled generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The call was refused. It would have supplied an interviewer read and a reverse question tied to his path. Both are absent |
| 5. representative Live Operations Producer JD | skipped | You supplied the JD, which fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, if you grant it: company values, loop structure and recent strategy would replace the generic CASE and VAL prompts with grounded ones, add CO questions, and add a values cheat sheet if a values round turns up. A deeper pass is also available, up to 6 more searches and 2 more fetches, several more minutes
- Whether Tobias is the person you would report to, and anything the recruiter said about format or a task to prepare: reweights every bank, and any announced deliverable gets its own build section
- Tobias's public talks or writing, if you have them: an interviewer read and a reverse question tied to his own path
- Your own words on the answer slots in F1, F3, F4 and F5: each becomes quoted evidence and the guidance rows that draw on those rows become story maps instead of slots
- A sample of the content-drop calendar, the release checklist itself, or a monthly retention report, whatever you are allowed to share: these are the inspectable artifacts that would raise F1, F4 and F7 from medium and give F8 something to stand on
- A `tuesday-dossier.md` from an earlier role evaluation would add verified evidence and any claims already ruled out
