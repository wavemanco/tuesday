I'll read the reference files the skill requires before building the pack.
Bash was declined, so I'll make the ID renames with Edit instead.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-denied-c52d7010/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as three mini-packs, one per round on 20 November: the recruiter, the Head of Member Services, and the branch-manager panel with its values scoring and escalation case. The pack uses only what you sent. I ran no searches, since your pasted values, the recruiter's email, the strategy brief and the JD already cover what research would have.

The most important prep is D1 in round 2. It is the likely objection: you handled the branch's formal complaints log, you've never worked in a contact centre, and the role owns complaints across all branches and the contact centre. The pack rehearses holding what your sentences say, conceding the rest plainly, and giving a plan for the contact centre, said as a plan.

Several JD requirements rest on thin evidence: reporting on volumes and resolution times, Excel, regulated complaints, coaching supervisors and digital teams. For those the pack gives you answer slots instead of stories. You fill each slot with what actually happened, or say plainly that it wasn't yours.

Say the word and I'll play the panel on the escalation case (G1), or any other question, with live follow-ups and feedback against the pack's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Built 11 November 2026 for three rounds on 20 November 2026, per the recruiter's email.

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Screen |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; the panel is also the values round and scores against the four values |

Interviewers' names are not assigned yet, so there is no interviewer read. This is loop mode: one shared fit snapshot, then a mini-pack per round.

## How to use this pack

- Personas are how a question is asked; types are what it scores. Each question carries one type tag.
- Type key: VAL is values or behavioural alignment; EXP is a deep-dive on what you actually did; JD is the role's stated requirements; CO is company and strategy knowledge; CASE is a live problem.
- Provenance: `[grounded]` traces to something you gave me or a document named in Sources; `[inferred]` is my derivation, named; `[generic]` is a role-family pattern with no claim about Ashgrove or about you.
- Guidance is scaffolding, not a script. Wherever it says answer slot, the words are yours: answer from what happened, and if the thing did not happen or was not yours, say so plainly.
- The highest-ROI prep in the pack is D1, the scope objection. It is also the question B1, D3 and G1 lean on.
- Every block of proposed language below is pending your approval.

## Fit snapshot (shared by all three rounds)

Your evidence is the sentences in your message, quoted exactly. No CV was provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log and training tellers, not the process across branches and the contact centre, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any step beyond the log was yours, say which and what you did, in your own words; if the log was where your part ended, or there was no such step, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence says a monthly complaints spreadsheet, not what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times. If the spreadsheet counted either, say which and how, in your own words; if it held something else, or you are not sure what it counted, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The sentence says tellers, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD names supervisors. If you ever helped a supervisor with an escalation, say what you did and how; if you did not, or it was not your role, say so plainly and stay with training the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have worked with a digital team, say with whom and what your part was, in your own words; if you have not, say so plainly and say what you would want to learn first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | Lead with the sentence in its own terms: six years in retail banking, the last three as a branch supervisor. The JD says customer operations and your sentence says retail banking, so keep your words and let the interviewer do the mapping |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | The JD says regulated and your sentence says formal; the material does not show whether formal meant regulated. Words: "I handled the branch's formal complaints log." Answer slot: if the log fell under any regulator's rules, say which and what that meant for how you handled a complaint; if it did not, or you do not know, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Never imply senior-level presenting |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The JD says Excel and your sentence says spreadsheet; the material does not say which tool. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was built in Excel, say so and what it did, in your own words; if it was another tool, say which, plainly, and stay with what you built |

## Grounding brief (shared)

The strategy brief reached me through your message, so only these four points are used. Quotes are from your message.

| Item | What the brief says | Provenance | How to use it |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] | The anchor for A5 and G3. Say it the way the brief does |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | [grounded] | The anchor for G2 and J3. Say hubs, not closures; the brief says consolidate |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] | Mention only if the conversation reaches new products. One sentence of your own thinking, framed as thinking |
| Competitive frame | "the main competitive pressure is app-only banks" | [grounded] | Useful in G3: a member who starts a complaint in an app has an app-only bank to compare with |

---

# Round 1 — The recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly screen: the biography, why Ashgrove, what you have read | Dominant, 5 questions. The recruiter screen prior is Conversational plus a light Skeptic, and the email says the recruiter runs this round | A 90-second arc built only from your quoted sentences (A1); treat casual questions on JD topics as scored |
| Skeptic, light | Knockout checks on the two things your message says you have not done | 3 questions. The same prior; F2 and F8 are stated negatives a screener checks first | Plain acknowledgment, then a plan said as a plan |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Three beats, each a clause the quotes state: six years in retail banking; the last three as a branch supervisor; the branch's formal complaints log and training new tellers on the escalation script. Tell them in your own words in about 90 seconds. Answer slot: why this role, from what you honestly want next; the pack does not know your reason | Recruiter screens open on the biography. F6 is the requirement it answers and F1 and F4 are the rows it should carry. EXP because it is the background told aloud |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Choose one published value and say in your own words why it matters to you; Plain Words and Own the Fix are both near a complaints role, but pick the one you mean. Add one line on the brief: the 40 percent digital target by 2028 changes what member service is. Answer slot: if your honest reason is different, say that. The guidance makes no claim about your past | Motivation is asked in every screen; CO because it tests whether you read what they sent. The values and brief are in Sources |
| A3 | "Tell me about the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say it in the sentence's own terms: you built it, it was monthly, it was about complaints, your regional manager used it. Answer slot: the JD asks for reporting on volumes and resolution times and for Excel. If the spreadsheet counted either, say which and how; if it held something else, or you are not sure what it counted, say so plainly. If it was built in Excel say so; if another tool, say which. Never describe a measure you did not track | F3 and F9 both rest on this one sentence, so a recruiter holding the JD will ask. EXP because it tests what was actually yours |
| A4 | "Have you worked with digital teams on self-service journeys?" | JD | [grounded] | No story is mapped because F5 has no evidence. Answer slot: if you have, say with whom and what your part was; if not, say so plainly and say what you would want to learn first | The JD's digital line is a screening item and F5 is silent, so the question is a checkbox the recruiter must tick |
| A5 | "What have you read about where we're heading?" | CO | [grounded] | Name two points from the brief as it states them: 40 percent of member service digital by 2028, and eight branches consolidating into five hubs over 2027. Then one sentence of your own thinking on what each could mean for complaints, framed as your thinking and not as knowledge of their plans. Two points beat four | The recruiter sent the brief, so being unfamiliar with it would be the miss. CO because it scores homework depth |
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one your own words already name. For the contact centre: "I haven't worked in a contact centre." Then the plan, said as a plan: learn how the contact-centre colleagues handle complaints today before proposing anything. Do not invent a modest weakness to avoid the real one | F2 is the likeliest knockout item. JD because it scores the stated requirement; the Skeptic delivers it |
| B2 | "This role presents to senior leaders, and you've never presented above regional level. How do you feel about that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan said as a plan: how you would prepare the first monthly report, including asking your manager what the leaders want to see. Answer slot: if you have presented in any other setting, say what and to whom; if not, say so plainly. Never imply senior-level presenting | F8 is a stated gap the recruiter can see in the JD. JD because it scores a stated requirement |
| B3 | "You've been a branch supervisor for the last three years — why a member experience role now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Start from the sentence: six years in retail banking, the last three as a branch supervisor. Answer slot: the reason for the move, in your own words; the pack does not know it. If one of the four values is part of the reason, say which | A screen checks that the move makes sense. F6 is the evidence base; EXP because it tests consistency of the story |

## Reverse questions for the recruiter

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does the Head of Member Services most need the first hire in this role to change or protect?" | It tells you what round 2 will press, and shows you are thinking about the manager's problem |
| 2 | "Is any material for the panel's 20-minute case shared beforehand, or is it live?" | It decides whether you prepare a deliverable; it is also a fair logistics question |
| 3 | "How do the three rounds' scores come together for the decision?" | It shows how much the values round weighs |
| 4 | "What do the branches and the contact centre each most need from this role?" | It shows you see the role as sitting between two teams |
| 5 | "What happens after the 20th, and when would I hear?" | Ordinary and expected; closes the screen cleanly |

---

# Round 2 — The Head of Member Services, your future manager (45 minutes)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" stories | Dominant, 4 questions. The hiring-manager prior leans Case and Skeptic, and the email says this round is mostly behavioural, which moves Behavioral to the top | Where a quoted sentence carries a story, map it at its scope; where none does, a selection scaffold ending in its honest branch |
| Skeptic | Quiet probing of the gaps | 3 questions. The manager owns the outcome of the hire; F1, F2 and F8 are where the material is thin | One rehearsed answer for the scope objection (D1), held through two follow-ups |
| Data-Driven Prober | Reads the log and spreadsheet line by line | 2 questions. They are the only two artifacts your message names, and a manager reading closely would start there | Say what you know about how each was built and what it counted; say plainly where you do not know |
| Case / Strategist | Live problems | Low; one question sits in the behavioural bank as C4 and one in D2. The prior says Case but the email says mostly behavioural, and the 20-minute case is in round 3 | Clarify, then structure |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship that was intact afterwards. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role reports monthly, to leaders (F8), and a manager wants to know you can say a hard thing. VAL because it tests behaviour, not a published value by name |
| C2 | "Tell me about a time you helped someone handle an escalation well." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4 at the quote's scope: you trained new tellers on the escalation script. Answer slot: the JD says coach branch supervisors, so expect a follow-up on how you knew the training worked. If you checked, say how and what you found; if you did not follow it up, say so plainly and describe the training | F4 is the nearest evidence to the JD's coaching line. EXP because it tests what was yours |
| C3 | "Tell me about a time you got a team you didn't manage to change how it did something." | JD | [grounded] | Selection scaffold: the JD's work crosses branches, the contact centre and digital teams, so choose a change you could not simply order: a named change, the team, what you did to bring them with you, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1 and F5 both depend on influencing without authority; JD because it scores the role's cross-team shape |
| C4 | "A branch supervisor handles escalations differently from how you would. How do you coach them?" | CASE | [generic] | Structure it as how you would: ask how they handled it and why before judging; agree what a good escalation looks like; change one thing at a time; check back afterwards. The question needs no claim about your past, so the guidance makes none | F4's requirement asked as a live problem, so the manager sees your approach without needing a story you do not have |
| D1 | "You handled the branch's formal complaints log, and you've never worked in a contact centre. This role owns the process across all branches and the contact centre — what makes you the person to own that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Highest-ROI prep in the pack.** Hold only what the quote carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Follow-up 1, that is one branch: concede it exactly, the log was the branch's. Follow-up 2, the contact centre: "I haven't worked in a contact centre," then the plan as a plan: learn how the contact centre and the other branches handle complaints today before proposing changes. Follow-up 3, a contact centre may not accept a branch person: hold, and concede that trust is earned by listening. Never widen the log. Answer slot: if any of your complaints work touched another branch or team, say what and which part was yours; if none did, say so plainly and stay with the log | F1 and F2 together are the biggest gap in the loop, and the manager will ask in some form. JD because it scores the headline requirement |
| D2 | "What would your first 90 days look like?" | CASE | [generic] | A shape, not facts: listen first to branch supervisors, contact-centre colleagues and digital teams; learn what complaint reporting exists and what it counts; agree with your manager what good looks like for the first report; pick one small problem you will carry to the end. Say what you would need to learn before committing to targets. All of it is plan | The ramp plan is the Skeptic's standard follow-up to D1; it makes F2 and F5 into a plan |
| D3 | "Why you, and not someone who has run a contact-centre complaints team?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Sixty seconds. Say what the sentences carry: six years in retail banking, the last three as a branch supervisor, the branch's formal complaints log, training new tellers on the escalation script. Concede plainly: "I haven't worked in a contact centre." Then stop and let them draw the inference; do not tell them what your work proves. Hold through a second push by returning to those sentences | A Pressure-style version of F1 and F2; JD because it scores fit against the stated requirement |
| E1 | "Walk me through the monthly complaints spreadsheet you built — what's in it, and who reads it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Quote beats: you built it, it was monthly, it was about complaints, your regional manager used it. Answer slot: if it counted volumes or resolution times, say how each was counted and the assumption behind it you would trust least; if you do not know how a figure was counted, say so plainly. If anyone else contributed, say so | F3 and F9 are the reporting requirements and this is the only artifact in your material. EXP because it tests attribution and how it was counted |
| E2 | "Your formal complaints log — what made a complaint formal, and what rules did it have to follow?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: the JD says regulated complaints, so expect this probe. If the log fell under any regulator's rules or your credit union's, say which and what they meant for how you handled a complaint; if it did not, or you do not know, say so plainly and describe what you handled in the log at the sentence's scope | F7 is the weakest-evidenced requirement in the JD. EXP because it tests what the log actually was |

*Proposed language above is pending your approval.*

## Reverse questions for the Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would you want this role to have changed in complaints handling by the end of the first six months?" | Gets the success criteria from the person who will judge them |
| 2 | "How do complaint numbers reach senior leaders today, and what do they ask about them?" | Tells you the audience for F8 and shows you are thinking about reporting as a conversation |
| 3 | "Where do you see the branches and the contact centre pulling in different directions on complaints?" | Shows you see the seam, and you learn their view of it |
| 4 | "Who would I work with on the digital side for self-service journeys?" | Makes F5 a practical question |
| 5 | "What support is there for someone presenting to senior leaders for the first time?" | Honest about F8 and signals that you plan to close it |

---

# Round 3 — The panel of two branch managers (60 minutes)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Stories scored against the four published values | Dominant, 4 questions. The email says the panel is the values round and scores against the four values | One question per value; map a quoted sentence where one carries it, a scaffold where none does |
| Case / Strategist | The 20-minute complaint escalation case | 3 questions. The email names a 20-minute case in this round | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Peer Evaluator | Seam-splitting between the role and branch supervisors | 2 questions. The role coaches branch supervisors, and a panel's prior blends each member's relationship; here the members are branch managers, whom the role works alongside | Offer seam principles, not a pretended knowledge of their seam; reciprocity framing |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold: a named decision where the member's interest and something internal pulled apart; what you chose; what it cost or risked; how the member was left. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always. Your material carries no sentence for this value, so it is a scaffold. VAL because it scores a published value |
| J2 | "Tell me about a time something you or your team wrote needed explaining twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4 at the quote's scope: the escalation script you trained new tellers on. Answer slot: Plain Words puts the writing on trial, so expect a probe on whether the script was clear. If you changed any wording, or heard it needed explaining, say what and what you did; if you did not write or change it, or it never came up, say so plainly and stay with the training | Plain Words. F4 is the only sentence near written material. VAL because it scores a published value |
| J3 | "Tell me about a time you put what a local branch needed ahead of a number." | VAL | [grounded] | Selection scaffold: a named local need, the number it pulled against, what you did, what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Neighbours, Not Numbers. F3 is the numbers side of this role, and the value sits against it. VAL because it scores a published value |
| J4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] | Selection scaffold: a problem you found, not necessarily one you could fix yourself; show you staying with it after passing part of it on, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Own the Fix. Your material carries no sentence for it. VAL because it scores a published value |
| G1 | "A member has complained about the same problem three times, and each time the case went back and forth between a branch and the contact centre. The branch says it is the contact centre's, the contact centre says it is the branch's. You own the process. What do you do?" | CASE | [generic] | Structure aloud: clarify first (what the complaint is, what the member was told, whether a time limit applies to this kind of complaint); objective (the member's problem fixed, one owner named, the member not retelling it again); approach (name the owner now, tell the member in plain words what happens next, then look at why it bounced); metrics and risks (time to resolution, repeat contacts, blame between teams). Challenge one premise politely, such as who owns it now. The question needs no claim about your past, so the guidance makes none | The panel's 20-minute case is on an escalation, and the JD's end-to-end line is F1. `[generic]` because the panel will bring its own case; this is practice for the method |
| G2 | "Eight branches are becoming five hubs over 2027. How would you keep complaints handling local through that?" | CO | [grounded] | Clarify first: which branches, when, and what changes for members and staff. Then your principle, in your own words, with Neighbours, Not Numbers as the test; then a plan; then the risks. Say it as thinking, not as knowledge of their plans | The brief's consolidation point and the value that sits against it; the panel are branch managers, so it is theirs. CO because it scores strategy fluency |
| G3 | "A member starts a complaint in the app. What does a good journey look like, in plain words?" | CASE | [grounded] | Clarify (what the member has done, what the app can resolve), then the member's steps, the plain-words test (explained once), where a person takes over, who owns it, and what you would measure. Name the digital teams as people you would work with. The brief's 40 percent target is the context. Answer slot: if you have worked with a digital team, say so in your own words; if not, say so plainly | The brief's digital shift and F5, asked as a live problem. CASE because it scores structure |
| H1 | "Where does your role end and a branch supervisor's begin when a complaint escalates — and what happens when we disagree about it?" | CASE | [grounded] | Offer principles, not a pretended knowledge of their seam: one owner at a time; the member told what happens next; the supervisor's judgment respected where it is sound; a way to disagree that does not make the member wait. Ask what their supervisors do today before drawing the line | The JD's coaching line from the branch managers' side; the Peer Evaluator's seam question |
| H2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the quote carries and no more: "I built the monthly complaints spreadsheet our regional manager uses." Do not add "alone" or "from scratch." Answer slot: if anyone else contributed, say who and how; if no one did, say so plainly. A scaffold for the wider question: share credit by naming people and what they did | The Peer Evaluator's credit probe, aimed at the one artifact you built. VAL because it scores how you describe shared work |

*Proposed language above is pending your approval.*

## Values cheat sheet

The panel scores against these four. Names are from the page you copied on 11 November 2026.

| Value | Working meaning, paraphrased | Mapped story or selection scaffold |
|---|---|---|
| Members First, Always | Decisions are made from the member's side | Selection scaffold (J1): a named decision where the member's interest and something internal pulled apart. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs something explained again, the writing failed | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Nearest sentence, at its own scope; see the J2 slot on whether the script was clear |
| Neighbours, Not Numbers | Each branch is part of its town and is not just a figure | Selection scaffold (J3): a named local need and the number it pulled against. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem stays with it until it is solved | Selection scaffold (J4): a problem you found and stayed with after passing part of it on. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Reverse questions for the panel

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new lead do in their first month that would genuinely help your branch?" | The reciprocity question: it shows you are thinking about their load, not only your own |
| 2 | "When a complaint escalates from your branch today, what do you wish happened differently?" | Asks for the thing the role exists to fix, from the people who live with it |
| 3 | "How do you expect eight branches becoming five hubs to change what your supervisors need from complaints support?" | Ties the brief to their daily work and shows you read it |
| 4 | "Which of the four values is hardest to live at the counter on a busy day?" | Turns the values round into a conversation, from the scorers' own experience |
| 5 | "What does Own the Fix look like when the fix sits with another team?" | Goes to the seam this role sits in, using their own words |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B1, D1, D2, D3, G1 |
| "report monthly on complaint volumes and resolution times" | A3, E1 |
| "coach branch supervisors on escalations" | C2, C4, H1 |
| "work with digital teams on self-service journeys" | A4, C3, G3 |
| "4+ years in financial-services customer operations" | A1, B3 |
| "experience handling regulated complaints" | E2, G1 |
| "confident presenting to senior leaders" | B2, C1 |
| "comfortable with Excel reporting" | A3, E1 |

Values coverage: Members First, Always is J1; Plain Words is J2; Neighbours, Not Numbers is J3 and G2; Own the Fix is J4. No headline figure appears in your material, so there is no defend-the-number question beyond the slots in A3 and E1.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says the branch's log, not the process across branches. D1's slot stays inside the log |
| Worked in a contact centre, or has contact-centre experience | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Presented to senior leaders | Negative you stated, F8 | "I haven't presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: training new tellers on the escalation script. C2's slot asks only how you knew the training worked |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: the monthly complaints spreadsheet. A3 and E1 ask only what it counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: the branch's formal complaints log. E2's slot asks only what rules the log fell under |
| Expert in Excel | Inflated form of F9 | F9's quote at its own scope: the spreadsheet you built. A3's slot asks only which tool |

## Sources

Provided documents: the job description, the values text copied from ashgrovecu.org/about/values on 11 November 2026, the recruiter's email on the process, the July 2026 strategy brief as relayed in your message, and your background in your message. No tuesday-dossier.md was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Could not have moved the values cheat sheet or the VAL questions: the pasted values text fixes the four names and their wording |
| 2. Ashgrove interview process, member services roles | skipped | Could not have moved the loop: the recruiter's email gives the three rounds, who runs each and what each holds, and names the panel as the values round |
| 3. Ashgrove strategy and recent news | skipped | Could not have moved the CO and CASE questions: the July 2026 brief you relayed supplies the four points the pack uses |
| 4. Interviewer name and company | n/a | No names are assigned, so there is no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewers' names, once assigned → an interviewer read, persona weights adjusted to their public footprint, and a reverse question tied to each one's own path
- How many hours you have between now and 20 November → a prep triage of the few things to do well, in order
- Your answers to the answer slots on F1, F3, F4, F5, F7 and F9 → those rows move from discovery to story-mapped answers; each fact you give outside a drill becomes quoted evidence
- The layout of the monthly complaints spreadsheet, with no member data → F3 and F9 could rise from medium and low toward high
- The recruiter's answer on whether the panel's case material is shared in advance → a build section for it if so
- The full text of the strategy brief → a fuller grounding brief and sharper CO questions than the four relayed points allow
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → the strategy brief, interviewer talks and writing, loop reports for member-services roles, and recent organisational context
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence, per-gap strategy limits and the objection a dossier names, in place of the ones this pack inferred
