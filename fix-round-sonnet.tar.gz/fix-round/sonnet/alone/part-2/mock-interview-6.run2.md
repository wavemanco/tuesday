I'll read the reference files before building the pack.
Pack is written. I'm running a quick format check for stray brackets and cell breaks, then I'll present it.
Your prep pack for all three rounds is saved at /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-6-denied-bc850e46/larkfield-systems_engineering-manager_interview_pack.md. It has 29 questions across the three rounds. I did not run the format check I started on the file. It is built in loop mode: one shared fit snapshot, then a mini-pack per round with its own persona weights, question bank and reverse questions.

I built it from what you wrote, since I had no full JD or CV. The three company searches (values, interview process, strategy) were refused, so company-specific content is generic and there is no Monday values cheat sheet. The pack's highest-ROI prep is T-A2, the Tuesday question on hardware partnership.

Say the word and I'll play the Skeptic on T-A2, as the Director on Tuesday.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full JD and a CV or a few bullets on your current role? That would turn several answer slots into story maps.
Did the recruiter say anything about what to prepare, such as a case, a presentation, or the panel's focus?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack (loop mode): Engineering Manager, Larkfield Systems

**Candidate:** Yusuf. **Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people), from the role description in your message. **Interviewer names:** none given.

| Round | When | Length | Who and relationship | Persona weights, in short |
|---|---|---|---|---|
| 1 | Tuesday | 45 min | Director of Engineering, the hiring manager and your would-be boss | Skeptic, Case/Strategist, Conversational |
| 2 | The Thursday after | 60 min | Panel: two staff engineers and a product manager | Peer Evaluator, Data-Driven Prober, Values/Behavioral |
| 3 | The following Monday | 30 min | VP Engineering; the recruiter's description, as you relayed it, is "values and leadership philosophy" | Values/Behavioral, Pressure, Case/Strategist |

The three rounds, their lengths and who runs them come from your message, so persona weights rest on those, not on an archetype fallback. Loop mode: one shared fit snapshot, then a mini-pack per round, then shared prohibited claims, sources and upgrade menu.

## How to use this pack

Personas are how a question is asked; types are what it scores. The guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Behavioral and values alignment: whether past behavior shows what is asked |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, delivered out loud |

Question IDs read round letter, then persona letter, then number: T for Tuesday, H for Thursday, M for Monday. Provenance labels: `[grounded]` traces to your message, `[inferred]` is derived from an adjacent source, `[generic]` is a role-family pattern with no claim about you or Larkfield. An answer slot is an instruction for the interview, not a question for you now.

## Prep triage (three rounds over two weeks)

Do these, in this order, and do them well:

1. **Before Tuesday: T-A2, the highest-ROI prep in the pack.** It is aimed at where your material is thinnest (F6, F8). Rehearse the plain acknowledgments and your ramp plan until they are boring, then T-A1 and T-A3.
2. **Before Tuesday: your account of the reliability quarter (T-A4) and of the 60% figure.** The same figure comes back as H-B1 and M-B2, so one honest account, with its limits, serves all three rounds.
3. **Before Tuesday: the 90-second arc (T-C1) and the hiring answer (T-C3).**
4. **Between Tuesday and Thursday:** H-A1 and H-A2 (the seams with product and hardware), then H-B1 and H-B2.
5. **Between Thursday and Monday:** M-B1 and M-B3 (the scope step and managing managers), then M-A1 to M-A3.

Everything else in the pack is insurance.

## Fit snapshot (shared)

Requirements are quoted from the role description in your message; evidence is your own sentences from the same message. You gave no CV, so rows with no sentence say `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | The words stay at the quote's scope: "3 as a team lead of 6". The pack's observation: your sentence states a team lead of 6 and says nothing about leading more than one team. Answer slot: expect a probe on the step to two squads. If any lead work of yours already covered more than one team, say what it was and what part was yours, in your own words; if it did not, say so plainly and stay with the team lead role your sentence names |
| F2 | "building device-management services" — your message | none given | none | [grounded] | discovery | Your material does not show device-management or industrial IoT work; the only domain it names is a payments company. Answer slot: the role's domain makes a probe likely. If any work of yours is close to device-management services, say what it was and what part was yours, in your own words; if none is, say so plainly, then say how you would learn the domain, as a plan and never as a past |
| F3 | "own delivery, hiring and growth for 11 engineers" — your message (the delivery part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The words stay at the quote's scope: "I pushed a reliability quarter through against roadmap pressure", and the burden dropped 60% "after" it. The pack's observation: the quote shows one reliability quarter, not the wider delivery of a team's roadmap. Answer slot: expect a probe on how you decide what ships. If the call on that quarter was yours to make, say how you made it; if it was not, or was made some other way, say so plainly and stay with the quarter you pushed through. The 60% raises the figure slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words; "I don't know how it was counted" is an honest answer |
| F4 | "own delivery, hiring and growth for 11 engineers" — your message (the hiring part) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: you run the hiring loop for backend roles. The "about 40 interviews" raises the figure slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F5 | "own delivery, hiring and growth for 11 engineers" — your message (the growth part) | none given | none | [grounded] | discovery | Your material does not show work on engineers' growth. Answer slot: the role's growth line makes a probe likely. If you have worked on any engineer's growth, say what it was and what part was yours, in your own words; if you have not, or it was not yours, say so plainly and say how you would approach it, as a plan |
| F6 | "partner with hardware and product on roadmap" — your message (the hardware side) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | low | [grounded] | discovery | The sentence states a negative about owning, and the plain acknowledgment is yours to say: "I've never owned a hardware-adjacent roadmap." The role's line is about partnering, and your material is silent on that. Answer slot: if you have worked alongside hardware-adjacent teams on any roadmap, say how and what your part was, in your own words; if you have not, or it was not yours, say so plainly and move to your plan for learning it |
| F7 | "partner with hardware and product on roadmap" — your message (the product side) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The words stay at the quote's scope: "roadmap pressure". The pack's observation: the quote does not say where the pressure came from or whether a product partner was involved. Answer slot: if the pressure came from product and you worked it through with them, say how, in your own words; if it came from elsewhere, or was handled differently, say so plainly and stay with the quarter you pushed through |
| F8 | Leading other leaders — not in the role description; you raised it — your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never managed managers." Then how you would learn it, said as a plan and never as a past. The pack's observation: the role description you gave does not say whether the squads have leads, which is a question for the Director (reverse question T-R2) |

Requirement coverage:

| Requirement | Questions |
|---|---|
| Lead two squads (F1) | T-A3, M-B1, M-C2 |
| Building device-management services (F2) | T-C2, T-B1, H-C3 |
| Own delivery (F3) | T-A4, T-B2, T-B3, H-B3, M-C1 |
| Hiring (F4) | T-C3, H-B2, M-A4 |
| Growth (F5) | M-A3 |
| Partner with hardware (F6) | T-A2, H-A2, T-B2 |
| Partner with product (F7) | H-A1, H-C1, T-B2 |
| Managing managers, your own flag (F8) | T-A1, M-B3 |
| The 60% figure (F3, F7) | T-A4, H-B1, M-B2 |

---

## Round 1: Tuesday, Director of Engineering (hiring manager), 45 min

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gaps: hardware, scale, managing leads | High. The relationship prior for a hiring manager is Case/Strategist plus Skeptic, and F6 and F8 are stated gaps, so this persona is weighted first | Rehearse the T-A2 objection until it is boring; plain acknowledgment, then a ramp plan in your own words; hold the plan through two follow-ups |
| Case/Strategist | A live problem from the squads' roadmap, with a request to think aloud | Medium to high. The other half of the hiring-manager prior; 45 minutes leaves room for one or two cases | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully (T-B1 to T-B3) |
| Conversational | "Walk me through the journey", casual questions on JD topics | Medium. The boss round opens conversationally, and casual questions are still scored | A 90-second arc built only from your own sentence (T-C1) |
| Data-Driven Prober | Pushes the 60% to its assumptions | Low to medium. A boss reading your background may probe the figure; it is covered inside T-A4 and fully in H-B1 | Know what you can and cannot say about how the figure was counted |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick the gap that matters most to this role and say it in the quote's own terms: "I've never owned a hardware-adjacent roadmap." or "I've never managed managers." Then give your ramp as a plan, in your own words, never as a past. Do not soften the gap with experience your material does not state; T-A2 carries the hardware probe in full | F6 and F8 are the stated gaps and this is the Skeptic's stem for them; JD because it scores the role's own requirements |
| T-A2 | "Partnering with hardware on the roadmap is central here, and your background is in payments. Walk me through how you would become effective with hardware partners." | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." and "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI rehearsal in this pack. Level one: the plain acknowledgment, "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked alongside hardware-adjacent teams on any roadmap, say how and what your part was, in your own words; if you have not, or it was not yours, say so plainly and go to your plan. Level two, "what would you do in your first thirty days": give your own plan; the pack supplies none. Level three, "that costs my team time, what does it cost me": concede the ramp cost explicitly and specifically, in your own words. Hold the plan through both follow-ups and never retreat into hardware experience your material does not state | F6 is where the role's partnering mandate presses hardest on the thinnest evidence, so this objection arrives in some form; JD because it scores a stated requirement, and it is the deepest rehearsal because it takes the most follow-up levels |
| T-A3 | "This role is two squads and 11 engineers, and you have been a team lead of 6. What changes?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Say what your sentence states, "3 as a team lead of 6", and stop there for the past. Answer slot: if any lead work of yours already covered more than one team, say what it was and what part was yours; if it did not, say so plainly and stay with the team lead role your sentence names. What changes at larger scale is your thinking, offered as a plan | F1 is the scale step the Director will price first; EXP because it tests what the lead role actually covered, with JD content in the 11 |
| T-A4 | "Tell me about the reliability quarter you pushed through against roadmap pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The beats are the ones the sentence states: a reliability quarter, pushed through, against roadmap pressure, and the burden dropping 60% after. Tell them in your own words and keep "after". Answer slot: the role's delivery line makes a probe on trade-offs likely. If you made the case to stakeholders, say how and with whom; if the call was not yours alone, or was made another way, say so plainly and stay with the quarter. Add the figure slots: how the 60% was counted, what it is sensitive to, the assumption you would defend least, and which part was yours | F3 and F7 carry this story, and it is the strongest evidence you quoted; EXP because the probe is on attribution |
| T-B1 | "Suppose you have just taken over two squads building device-management services and a hardware date is slipping. What do you need to know first?" | CASE | [generic] | Clarify first (what is fixed, the date or the scope, and who decides), then objective, segmentation of the work, approach, metrics, risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem set in the role's hardware-partnering line (F6, F7 requirement); `[generic]` because it is a pattern, not a fact about Larkfield |
| T-B2 | "Product wants new features, hardware wants stability on what has already shipped, and your engineers are split across both. How do you decide where the next quarter goes?" | CASE | [generic] | Structure it: what you need to know first, the decision criteria, who has a say and who decides, how you would tell the losing side, what you would measure after. No claim about your past | The roadmap tension the role description names; CASE because it scores structure, and generic because it holds no Larkfield fact |
| T-B3 | "Two squads inherit a noisy on-call and a full roadmap. How do you decide whether to spend a quarter on reliability?" | CASE | [generic] | Structure only: what evidence you would want, what the cost of not acting is, how you would size the quarter, how you would protect the rest of the roadmap, how you would know it worked. No claim about your past | A neighbour of F3's ground, kept free of your story so it tests reasoning rather than recall; CASE with a JD delivery link |
| T-C1 | "So, walk me through the journey to this role." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc whose past beats are the sentence's: 9 years in engineering, 3 as a team lead of 6, currently at a payments company. Answer slot: why this role and why industrial IoT; give only reasons you actually hold. If none is specific to Larkfield, say what draws you to the role as the description states it and stop | The Conversational opener is nearly certain in a boss round, and F1 is the sentence it draws on; EXP because it is a tour of your own history |
| T-C2 | "What are you actually playing with these days that is close to device-management?" | JD | [grounded] | Answer slot: the role names device-management services, so a casual probe is likely and it is scored. If any current work or study of yours is close, say what it is and what part is yours, in your own words; if none is, say so plainly and say what you would read or build first, as a plan | F2 is a discovery row, so the honest answer has to be ready in either direction; JD because the domain is the role's |
| T-C3 | "You would own hiring for these squads. How do you run hiring today?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | The beats are the sentence's: you run the hiring loop for backend roles, and there were about 40 interviews last year. Tell them in your own words. Answer slot for the figure: how the 40 was counted, what it is sensitive to, the assumption you would defend least, and which part was yours; "I don't know how it was counted" is an honest answer | F4 is the row with the clearest strength and no gap, so it is a place to be crisp; JD because it scores the hiring requirement |

**Reverse questions, Tuesday** (the Director is your would-be boss)

| # | Question | Why it lands |
|---|---|---|
| T-R1 | "What would a good first 90 days look like in this role, and what would tell you it was not working?" | It gets the success criteria from the person who will judge you, and shows you are planning |
| T-R2 | "Do the two squads have leads or tech leads today, and how do you expect that to change?" | It asks the question your gap (F8) turns on instead of assuming the answer |
| T-R3 | "How do the squads and the hardware teams plan together today, and where does that most often come apart?" | It shows you are thinking about the seam before you own it, which answers F6 without claiming it |
| T-R4 | "What is the hardest unresolved problem the two squads have inherited?" | It invites the Director to tell you what the job really is |
| T-R5 | "How do you prefer to hear bad news, and how do engineers here usually grow into the next level?" | It tests the working relationship and the growth line (F5) in one calm question |

---

## Round 2: The Thursday after, panel of two staff engineers and a product manager, 60 min

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting with product and hardware, "what would you need from us", credit-sharing | High. The panel prior blends the top two personas of each member's relationship; I have assumed the staff engineers read as peers and the product manager as cross-functional. No names are known, so I cannot assign personas per member | Reciprocity framing; propose seam principles rather than pretending to know the seam (H-A1 to H-A4) |
| Data-Driven Prober | The 60% and the 40 interviews, to their assumptions | High. Staff engineers are the likeliest people to probe a figure, and F3 and F4 both carry figures | Say plainly how much you know about how each figure was counted (H-B1 to H-B3) |
| Values/Behavioral | Scenario stories, often from the product manager | Medium. A cross-functional interviewer leans to a behavioral conversation; Monday is the named values round, so this is lighter | A story only where your own sentence carries one, otherwise a selection scaffold with its honest branch (H-C1 to H-C3) |
| Conversational | Rapport openers | Low. It appears as a warm-up; T-C1's arc covers it | Reuse the arc |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H-A1 | "Product and engineering disagree about what goes on the roadmap. How do you work through that with me?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Principles first: what you would bring to the product manager's roadmap, not only what you need from it. The closest story is the one your sentence carries: a reliability quarter pushed through against roadmap pressure. Answer slot: if the pressure came from product and you worked it through with them, say how, in your own words; if it came from elsewhere, or was handled differently, say so plainly and stay with the quarter | F7 is the evidence for the product-partnering line; JD because it scores that line, with Peer Evaluator delivery |
| H-A2 | "Our teams sit next to the hardware teams. Where is the seam between the device-management services and the hardware, and what happens when we disagree?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Do not pretend to know the seam; ask where it sits today, then offer principles for how a seam should work. If pressed, the plain acknowledgment is "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked alongside hardware-adjacent teams on any roadmap, say how and what your part was; if you have not, or it was not yours, say so plainly and stay with your principles | F6 is where a staff engineer will test the seam; JD because it is the role's partnering line, delivered peer-to-peer |
| H-A3 | "How do you handle credit when work spans two squads?" | VAL | [generic] | A selection scaffold: pick a time credit for shared work was at stake; it needs a named piece of work, what you did to share credit, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer Evaluator's credit stem; `[generic]` because none of your sentences carries a credit story |
| H-A4 | "What would you need from us in your first month, and what would you give us?" | JD | [generic] | Lead with what you would give: listening to where the squads hurt, protecting their time where you can, and being plain about what you do not yet know. Then what you need. It is a stance, so it makes no claim about your past | The reciprocity move from the persona's counter-strategy, asked directly; `[generic]` because it is a pattern |
| H-B1 | "Walk me through how the 60% on-call drop was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot, four parts, each in your own words: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Keep the sentence's own order: the burden dropped 60% after the push | F3 and F7's figure is the magnet target for staff engineers; EXP because it scores whether the number survives |
| H-B2 | "About 40 interviews last year. How was that counted, and how many were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slot, in your own words: how the 40 was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know exactly how it was counted, say so plainly and say what you do know | F4's figure, probed to its denominator; EXP because the probe is on attribution |
| H-B3 | "When on-call is noisy across two squads, how do you decide what to fix first and who fixes it?" | CASE | [generic] | Structure: what you would want to know first, how you would rank the noise, who owns which part, what you would measure, what you would stop doing. No claim about your past | A staff-engineer problem set in F3's territory and kept free of your story so it tests reasoning; `[generic]` because it is a pattern |
| H-C1 | "Tell me about a time you worked through a disagreement with a product partner." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Use your sentence only if it fits: a reliability quarter pushed through against roadmap pressure. Answer slot: if the pressure came from a product partner and you worked it through with them, say how and what your part was; if it came from elsewhere, or you have a better example, say so and use that; if neither, say so plainly and say how you would handle it | The product manager's likeliest behavioral stem, from the JD's product-partnering line (F7); VAL because it asks for demonstrated behavior |
| H-C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold: pick a time with a named customer-side stake, the internal metric you did not chase, and a clear result for the customer. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem with no sentence of yours behind it, so it is a scaffold and not a story map |
| H-C3 | "What do you think is different about shipping software that manages devices in the field, compared with the payments services you have worked on?" | CO | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Think aloud and be candid about what you would want to learn. Do not assert what Larkfield's customers or devices are like; you have no sourced Larkfield facts here. Answer slot: if you have seen a difference first-hand, say what and where; if not, say so plainly and say what you would ask the staff engineers first | F2's domain question in its CO form; the premise is only your payments background, and the guidance stays inside it |

**Reverse questions, Thursday**

| # | Question | Why it lands |
|---|---|---|
| H-R1 | "What do you most want a manager to take off your plate, and what do you most want them to leave alone?" | A reciprocity question for the staff engineers; it shows you are pricing your impact on their work |
| H-R2 | "What could a new person do in their first month that would genuinely help your team?" | The peer reciprocity question; it turns an evaluation into a working conversation |
| H-R3 | "How is the roadmap set between product and hardware, and where does engineering's voice come in?" | Aimed at the product manager; it asks about the seam (F6, F7) without claiming it |
| H-R4 | "Can you give me an example of an engineering trade-off that went well recently, and why it did?" | It makes the panel tell you what good judgment looks like here |
| H-R5 | "What does on-call look like for the squads today?" | It connects to your strongest story without asserting more of it than your sentence says |

---

## Round 3: The following Monday, VP Engineering, 30 min

No values cheat sheet: the recruiter's description, as you relayed it, detects a values-style round, but Larkfield's published values were not retrievable (the searches were refused), so there is nothing to map. The VAL questions below are themed from "values and leadership philosophy" and from persona stems.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Stories and principles on how you lead | High. "Values and leadership philosophy" is the recruiter's description as you relayed it | A story only where your sentence carries one; "we" for context, "I" for contribution (M-A1 to M-A4) |
| Pressure | Time-boxed challenges to the scope step and the figure | Medium. The skip-level and executive prior is Case/Strategist plus Pressure, and 30 minutes invites sixty-second challenges | Pause, restate, hold through two follow-ups, concede specifically (M-B1 to M-B3) |
| Case/Strategist | Altitude questions about what engineering should be known for | Medium. The other half of the executive prior; the strategy facts are not researched, so these stay generic | Structure aloud; be plain about what you have not researched (M-C1, M-C2) |
| Conversational | Rapport | Low. Thirty minutes leaves little room | Reuse the T-C1 arc |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-A1 | "What is your philosophy on leading engineers?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | State two or three principles in your own words, each one you can point to behavior for. The past you may reference is only what your sentence states: 3 as a team lead of 6. Answer slot: for each principle, if you can point to an example, say what it was and what part was yours; if no example comes to mind, say so plainly and say how you would put it into practice | The values round's central prompt; F1 is the only sentence of yours about leading, so it is the only past the answer may lean on |
| M-A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Use your sentence only if it fits. Answer slot: if the roadmap pressure came from leadership and you made the case to them, say what you said and how it landed, in your own words; if it did not, or you have a better example, say so and use that; if neither, say so plainly and say how you would deliver one. Choose a story in which the hard truth actually landed, and where your material shows none, say so rather than supplying an ending | The persona stem for the values round; F3 and F7 hold your closest sentence and the material does not show who applied the pressure |
| M-A3 | "How do you help engineers grow?" | VAL | [grounded] | A selection scaffold: pick a time you helped one engineer grow; it needs a named person or situation, what you did, and an outcome you did not invent. Answer slot: if you have done this, say what and what part was yours, in your own words; if you have not, or it was not yours, say so plainly and say how you would approach it, as a plan | F5 is a discovery row: the role names growth and no sentence of yours speaks to it, so the honest branch has to be ready |
| M-A4 | "Tell me about a hiring call that was hard to make." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Your sentence carries the loop and the volume, not a hard call. Answer slot: if a hiring call was hard, say what made it hard and what part was yours, in your own words; if none comes to mind, say so plainly and say how you would make a hard hiring call | F4 is your strongest row, and the VP may use it to test judgment, not volume |
| M-B1 | "Sixty seconds: you have been a team lead of 6, and this is two squads and 11 engineers. Why you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Pause and restate. Hold: what your sentence states, 9 years in engineering and 3 as a team lead of 6. Concede specifically: the step to two squads is real, and say what you would do about it as a plan. Answer slot: if any lead work of yours already covered more than one team, say what it was and what part was yours; if it did not, say so plainly. Hold through two follow-ups and never fold on what the sentence carries | F1 under Pressure delivery; JD because it scores the first line of the role |
| M-B2 | "That on-call result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold: you pushed a reliability quarter through against roadmap pressure, and the burden dropped 60% after. Concede in your own words what you cannot attribute. Answer slot: which part was yours and which was the team's; if you do not know how much of the drop the quarter caused, say so plainly. Keep "after", and do not say you cut it | The Pressure stem aimed at F3 and F7, the figure's attribution; EXP because it scores honesty about your share |
| M-B3 | "If this role means leading leads, you would be doing that for the first time. How do you think about that step?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The plain acknowledgment: "I've never managed managers." Then your plan in your own words, as a plan and never as a past. Do not assume the role includes leads; the role description you gave does not say, and T-R2 asks | F8 is a stated gap; the VP may reach it from the leadership-philosophy side |
| M-C1 | "How would you think about where reliability sits against new features for a device-management platform?" | CASE | [generic] | Structure aloud: what you would want to know, how the answer changes with the customers' tolerance for failure, how you would frame it to product, what you would measure. Be plain that you have not researched Larkfield's position. No claim about your past | A strategy-altitude prompt at F3's ground; `[generic]` because strategy research was not available |
| M-C2 | "Two squads, 11 engineers, hardware and product both asking for the same quarter. What do you want engineering to be known for in a year?" | CASE | [generic] | Name two or three things you would want, say why each matters to the people who depend on engineering, and say what you would stop doing to make room. No claim about your past | The altitude question the executive prior predicts; F1's role scope is the setting |

**Reverse questions, Monday**

| # | Question | Why it lands |
|---|---|---|
| M-R1 | "What do you want engineering leadership at Larkfield to be known for in two years?" | It meets the VP at their altitude and invites their philosophy |
| M-R2 | "What kind of engineering manager has grown best here, and what did they have in common?" | It asks what the values look like in people |
| M-R3 | "When hardware and software deadlines conflict, how does the company decide?" | It touches F6's ground and asks what a partnership really costs |
| M-R4 | "What was the hardest leadership trade-off you faced in the last year?" | A values-round question that gets a real story, not a slogan |
| M-R5 | "What would make you regret this hire in a year?" | It names the failure mode so you can speak to it |

---

## Prohibited claims (shared)

Built before the banks were written. Each entry names its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F8 | The plain acknowledgment: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." The partnering probe is met through F6's slot |
| Has led two squads or a team of 11 | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation: the sentence says a team lead of 6 |
| Owned delivery of a team's roadmap | Inflated form of F3 | F3's quote at its own scope: "I pushed a reliability quarter through against roadmap pressure". The slot stays inside that quarter |
| Cut on-call burden by 60% | Inflated form of F3 and F7; the sentence says the burden dropped "after" the push | The sentence whole: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The pack's observation: it does not say how much of the drop the quarter caused |
| Owned hiring for the squads | Inflated form of F4 | F4's quote at its own scope: "I run our hiring loop for backend roles" |

## Sources

Provided documents: your message (the role description, the three rounds with their lengths and interviewers, the recruiter's description of the Monday round, and your background sentences). No dossier was present.

Searches sent, each refused, none returning a result:

- "Larkfield Systems industrial IoT values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have fed a values cheat sheet for Monday and the VAL themes; the VAL questions are themed from the recruiter's description and persona stems instead |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. It would have checked the loop and the Monday round's format; persona weights rest on your message |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The search was refused. It would have fed company-grounded CO and CASE questions; those stay generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `Engineering Manager` JD | skipped | The role description you gave fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the eight fit rows quote the posting's own wording, and the role's scope, such as whether the squads have leads (F8) and what on-call expects, stops being a question
- A CV or a bullet list of your last role → more of F1 to F7 get quoted evidence, more answers become story maps instead of slots, and T-C1's arc can carry more than one sentence
- Your answers to the slots in F2, F5, F6 and F7 (any work close to device-management, any engineer-growth work, any work alongside hardware-adjacent teams, who applied the roadmap pressure) → those rows upgrade and the matching questions turn from slots into story maps
- Interviewer names for the Director, the two staff engineers, the product manager and the VP → an interviewer read, persona weights per panel member, and reverse questions tied to their own paths
- The recruiter's prep email, or any note on the panel's focus → coverage of any case, presentation or take-home, and sharper persona weights for Thursday
- Search permission, then a deeper research pass (up to 6 further searches and 2 further fetches, several more minutes) → Larkfield's published values for a Monday cheat sheet, a strategy brief behind the CO questions, and loop details to check against your recruiter's account
- A tuesday-dossier.md from job-underwriter → verified evidence, an underwriter-chosen objection and prohibited claims, in place of the ones inferred here (never a prerequisite)
