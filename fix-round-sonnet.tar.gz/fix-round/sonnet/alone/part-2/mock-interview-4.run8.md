I'll read the skill's reference files first.
The pack is written, and I'm presenting it now. I built it from your dossier for a 45-minute hiring-manager round.

Your prep pack is saved at /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-4-denied-358149b0/quartzline_product-manager-platform-apis_interview_pack.md. It has 22 questions and 6 reverse questions.

- **Web searches were refused.** All three searches (values, interview process, strategy) were denied, so nothing in the pack is researched about Quartzline. There are no company-strategy questions and no values cheat sheet, and the persona weights rest on your description of the round. The upgrade menu lists what that costs and what would restore it.
- **Highest-ROI prep is A1.** It is the underwriter's objection: "never held the PM title or owned a roadmap". The answer is to concede the two sourced negatives first, then hold the two quoted claims at their own scope, then give a ramp plan. Your roadmap-input sessions are medium confidence, so the pack coaches you to state their limits before you're asked.
- **Some fit rows are graded by me.** The dossier gives gap strategies only for R1, the roadmap sub-claim and R5. I graded the rows for R2, R3, R4 and the other responsibilities from your quoted evidence, and the pack labels them as inferred.

Say the word and I'll play the Skeptic on A1 so you can rehearse it live.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Quartzline — Product Manager, Platform APIs — interview prep pack

Round: one 45-minute conversation with the hiring manager (interviewer not named). Built from tuesday-dossier.md (version 1.1) and your message; no web research was available, so nothing here rests on researched facts about Quartzline.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values (here, themed from persona stems only: no published values were in hand) |
| EXP | Whether a claim about your work survives scrutiny, including what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none written: strategy research was refused) |
| CASE | A live problem from the role, scored on structure |

An answer slot is an instruction for the interview, not a question for you now: it names what the interviewer will probably probe, then gives two honest branches, the second of which allows that the practice never existed or was not yours. Question IDs run by persona; bank letters skip F so that F1 to F9 mean fit-snapshot rows only.

## Fit snapshot

Requirement text is the dossier's role_profile, which stands as the JD. Evidence is quoted from the dossier's verified_candidate_evidence, numbered 1 to 3 in the order the dossier lists them. Confidence and gap type on F1, F2 and F6 are the underwriter's; the other rows are graded here from the quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [inferred] | transferability | Bridge as adjacent, never as product management experience: that is the underwriter's condition, and the limit stays in your words. Say the two quotes at their own scope: you led the integrations, and you ran the sessions that fed client evidence to product. The limit, sourced by prohibited_claims "Having held a product manager title or role": "I haven't held a product manager title or role." The second quote is confirmed with limited inspectable proof, so expect a probe on it and name its limits before it is asked |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | A gap the dossier records: uncertain_or_weak_areas acknowledge_gap on "Owning a roadmap and prioritization authority (R1 sub-claim)", and prohibited_claims "Having owned a product roadmap". Words: "I haven't owned a product roadmap." Then how you would learn it, said as a plan and never as a past. No bridge, no answer slot, nothing added to make the gap feel smaller |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | transferability | Your material says the integrations, not shipping a product, and the words stay at the quote's scope: you led integrations through to go-live. Answer slot: the JD's line makes a probe on what went live likely. If you can say what went live at the end of an integration you led, and what part of it was yours, say so in your own words; if you cannot, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | low | [inferred] | discovery | The quotes touch REST APIs, architecture and a playbook; they do not show whether API docs or schemas were part of that work. Answer slot: if you read or wrote API docs, or worked with schemas, on those integrations, say which and what you did; if you did not, say so plainly and stay with the playbook and the integrations |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [inferred] | discovery | The quotes show clients and product; they do not show engineering or sales. Answer slot: if engineering or sales were part of any of that work, say who and what you did together; if they were not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy is clarify. Nothing in the verified evidence speaks to it: UAT and go-live are nearby, not the same. Answer slot: the JD's own wording makes "what did agile delivery look like for you" the likely probe. If you worked that way, say how in your own words; if your teams never did, say so plainly, and say what you would want to confirm about how this team defines it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [inferred] | discovery | The quote shows sessions that fed client evidence to product; it does not show how the evidence reached the sessions. Answer slot: if you can say how the client evidence reached those sessions, say so in your own words; if you cannot, or it was not yours, say so plainly and stay with running the sessions |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | discovery | The quote lists requirements among the stages; it does not show what form they took or who received them. Answer slot: if you can say what form the requirements took and who they went to, say so in your own words; if there was no such step, or it was not yours, say so plainly and stay with the integrations you led |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Your material says nothing here, and the dossier notes no current adoption baseline is stated. Answer slot: if any outcome of the integrations you led was counted, say what and by whom; if nothing was, say so plainly, and say what you would measure first |

## Persona weights

No interviewer profile exists, so weights come from the round and the loop. Your words establish the loop for this pack: one 45-minute session, run by the hiring manager. No values-style round is detected, because no loop source documents one and no archetype is assumed.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the missing title and roadmap | High. The hiring-manager prior is Case/Strategist plus Skeptic, and the underwriter named one objection (A1), which is a Skeptic item. 5 questions | Rehearse A1 until it is boring; concede the sourced negatives first, hold the quotes at their scope, give a ramp plan |
| Case/Strategist | Live problems on partner API adoption, breaking changes, specs | High. The same prior; the JD's responsibilities (roadmap, specs, adoption metrics) are live-problem material. 5 questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Data-Driven Prober | Presses on the 30+ figure and on what shipped | Medium. A headline figure and a must-have requirement both invite denominators. 3 questions | Say plainly what you do and do not know about how the figure was counted; name the weakest assumption before asked |
| Conversational | Journey question, playbook, working across teams | Medium. A 45-minute manager conversation usually opens this way, and casual questions are still scored. 3 questions | A 90-second arc built only from your three quoted sentences |
| Pressure | Time-boxed challenges on the same gaps | Low to medium. Nothing in the material signals a stress style; the gaps make it possible. 2 questions | Pause, restate, anchor in what you stated, hold through two follow-ups |
| Peer Evaluator | Seam with the two squad leads | Low. The interviewer is a manager, but decision authority versus the squad leads is an open risk in the dossier. 2 questions | Offer seam principles, not a claim about where the seam is; frame what you bring the squads |
| Values/Behavioral | Open behavioral prompts | Low. No values round is detected and no published values are in hand. 2 questions | Selection scaffolds that end in an honest branch |

## Question banks

### Bank A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | The highest-ROI rehearsal in this pack: the underwriter named this objection from evidence you confirmed, and both negatives in it are sourced by the prohibited_claims items quoted here and by the acknowledge_gap area on "Owning a roadmap and prioritization authority (R1 sub-claim)". Concede first, plainly, before the comparison is made: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Hold at the quotes' scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live; you ran quarterly roadmap-input sessions feeding client evidence to product. Say the second with its limit up front: it is confirmed with limited inspectable proof, so say what you can show from those sessions and what you cannot. Do not argue the comparison; say what you would do to close the gap, as a plan: learn the roadmap and the reasoning behind it, learn how each squad lead decides, and agree with the hiring manager which decisions are yours. Follow-up 1, "that is integration work, not product work": agree it is adjacent, return to the quotes, add nothing. Follow-up 2, "so why not the PM with three years of the job": say the PM has something you do not, then say what the quotes carry and stop. Follow-up 3, "what would you get wrong first": say plainly what you do not yet know, the roadmap's history and where each squad lead's decision rights end, and how you would find out in your first month | F1 and F2 are where this objection lands, and the underwriter's named objection replaces an inferred one. JD because it scores the 3+ years must-have; the delivery is Pressure-style, which is why the hold-then-concede structure is in the cell |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)"; prohibited_claims: "Having set prioritization for an engineering squad" | Pick one answer, not a list, and lead with the real one: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Sources: the acknowledge_gap area and the prohibited_claims item quoted here. Then the ramp plan, said as a plan: in my first weeks I would read the current roadmap and the reasoning behind it, learn how each squad lead makes their calls, and ask which decisions are mine and which stay with them. Stop there; adding a strength to soften it hands the interviewer the follow-up | F2 is the capability row and the one gap with nothing to bridge, so the plain answer and the plan are the whole defense. JD because it scores the stated responsibility; the Skeptic stem is the usual way it arrives |
| A3 | "Walk me through how one of your quarterly roadmap-input sessions worked." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on the beats the quote states: you ran them, they were quarterly, they fed client evidence to product; tell these in your own words. This evidence is confirmed with limited inspectable proof, so volunteer the limit: say what exists to show from them, an agenda or notes if any, and if nothing was kept, say so plainly. Answer slot: the JD's line "Run discovery with integration partners" makes a probe on how the client evidence reached those sessions likely. If you can say how, say it in your own words; if you cannot, or it was not yours, say so plainly and stay with running the sessions. Second slot: if a product decision changed because of what you fed in, say which and what part was yours; if you do not know, or none did, say so plainly | F1 and F7 rest on this one medium-confidence sentence, so a prober will find the seam here first. EXP because it tests what was actually yours |
| A4 | "Why leave integration leadership for product, why here, and why now?" | JD | [generic] | Selection scaffold, because your material carries nothing on motivation. Pick the specific moment in your work when the question stopped being how to get one client live and became what the platform should do; it needs a named moment and what you did next. If no such moment comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach the move. For "why here", use only what you have read yourself about Quartzline; the pack could not research it and supplies no fact about the company | Motivation consistency is what the Skeptic scores, and F1 makes the question sharper. JD because it scores fit to this role |
| A5 | "What has agile delivery looked like where you've worked?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The dossier's strategy here is clarify: no verified entry speaks to agile delivery, and UAT and go-live in the quote are nearby, not the same. Answer slot: the JD's wording is "Agile delivery experience", and this question is its probe. If you worked that way, say how in your own words; if your teams never did, say so plainly and return to the integrations you led. Then the honest clarifier: what you would want to confirm is how this team runs delivery with its two squads | F6 is a discovery row, so the answer is a slot and a question back, never a story supplied by the pack. JD because R5 is a stated requirement, and it is preferred, so it is likely a short exchange |

### Bank B — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Suppose adoption of one partner API endpoint has been flat for two quarters. What do you need to know first, and how would you diagnose it?" | CASE | [generic] | Clarify first: how adoption is defined and measured, what the baseline is, flat against what, and which partners. Objective: say what decision the diagnosis serves. Segment partners by where they are, for example not started, integrating, live, lapsed. Approach: compare segments, then look for what is different about the ones that stall. Metrics: one leading and one lagging. Risks: measuring the wrong thing. Challenge one premise politely, that "flat" may be a measurement artifact. This answer makes no claim about your past | The JD makes adoption metrics a responsibility and the dossier says the baseline is unknown (F9), so this is the likeliest live problem. CASE because it is a live problem set in the role |
| B2 | "Two of our largest partners rely on the current behavior of an endpoint; a third needs it changed to launch. How do you decide what to do?" | CASE | [generic] | Clarify what breaks, for whom, and by when. Options: a new version, a deprecation window with notice, an opt-in flag, or declining with an alternative. Criteria: partner dependency, cost to the squads, reversibility. Then say who decides: you would bring a recommendation and the trade-offs to whoever owns the call, and you want to learn where that line sits. Close on how partners are told and how you would watch adoption afterward. This answer makes no claim about your past | F2 and F8 make trade-offs between partners and squads central to the role; the answer must not pretend to authority the dossier lists as unverified. CASE because it is a live problem |
| B3 | "Walk me through how you'd go from a partner's first request to a written spec the squads can build from." | CASE | [generic] | Structure: the problem in the partner's terms and who else has it; requirements; the API shape, with an example call, response and error cases, since the JD names API docs and schemas; acceptance criteria written so user acceptance testing can run; handoff, open questions, and how you would learn the squad's own format first. Think aloud, and say what you would need to confirm. This answer makes no claim about your past | F4 and F8 are discovery rows, so a hypothetical walkthrough lets you show technical fluency without claiming a spec you did not write. JD content with CASE delivery; tagged CASE because it asks for a live structure |
| B4 | "What would you want the adoption metrics for the partner API platform to be, and how would you know they're right?" | JD | [generic] | Offer a small set with definitions, for example partners reaching a first successful call, active partners over time, depth of use, and time from agreement to go-live. Then the weakest-assumption move, in your own words: name the assumption you would defend least before the interviewer does. Ask how adoption is measured today and what the baseline is. This answer makes no claim about your past | F9 is the row; the metric-design question is where the weakest-assumption move is rehearsed. JD because adoption metrics are a named responsibility |
| B5 | "A partner's lead tells you they need webhook support next quarter; no other partner has asked. How do you decide if it belongs on the roadmap?" | CASE | [generic] | Ask what the partner is trying to do before the feature; check whether others have the same need under another name; size cost with the squad leads; set criteria in advance. Then the decision line: you would bring a recommendation, with the evidence, to whoever owns the call, and you would want to know where that line sits. This answer makes no claim about your past | F2 and F7 meet here: roadmap judgment fed by partner evidence. CASE because it is a live problem |

### Bank C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. How was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number at its own scope: 30+ counts client integrations, not clients, and you led them. The dossier marks this high confidence with an inspectable playbook. Slots, all in your own words: how you counted it, meaning what made something count as one integration, and if you do not know how it was counted, say so plainly; what the number is most sensitive to; the assumption you would defend least, named before they ask; and which part was yours, since the quote says you led integrations end to end, so if any stage was shared, say which and with whom, and if none was, say so plainly | The 30+ figure is the pack's one headline metric, and F3 and F8 lean on the same sentence. EXP because it tests attribution and counting |
| C2 | "The posting asks for shipped API or platform products. Which go-live you led is closest to that, and what exactly went live?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Bridge with its limit named, as the underwriter positioned it: adjacent, never the same. Say the quote at its scope: you led client integrations of the vendor's REST APIs through go-live. Do not take the JD's wording for it. Answer slot: if you can say what went live at the end of one integration you led, and what part of it was yours, say so in your own words; if you cannot, say so plainly and stay with the integrations you led | F3 is a must-have with only adjacent evidence, so this is the Prober's version of the Skeptic's A1. JD because it scores R2 directly |
| C3 | "What did you track on the integrations you led, and what happened to those numbers?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the JD's line "Define and track adoption metrics" makes this probe likely. If any outcome of those integrations was counted, say what was counted and who counted it, in your own words; if nothing was, or it was not yours, say so plainly. Then say what you would measure first on a partner platform, and ask how adoption is measured today. Never describe a measure you did not track | F9 has no evidence at all, so the honest answer is a slot and a plan. JD because adoption metrics are a named responsibility |

### Bank D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc using only the beats the quotes state: you led 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live; you wrote the internal integration playbook your team uses; you ran quarterly roadmap-input sessions feeding client evidence to product, confirmed with limited inspectable proof, which you say plainly. The last step, why product, is yours. Answer slot: if one moment pulled you toward product, say what it was; if no single moment did, say so, and say what you want from the next role | F1 is the spine and this is where the three quotes are first heard together. EXP because it tests whether the story holds as told |
| D2 | "Tell me about the integration playbook you wrote — what's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Beats the quote states: you wrote it, it is internal, it is about integrations, your team uses it. The dossier calls this high confidence and inspectable, but the contents are not in the dossier, so the pack names none: open the playbook before the interview and pick two sections to walk through in your own words. Answer slot: the JD's line "Technical fluency: API docs, schemas" makes a probe on whether the playbook or the integration work involved them likely. If it did, say how; if not, say so plainly and stay with the playbook | F4 is a discovery row and the playbook is the one artifact you can open and show. EXP because it tests what was actually yours |
| D3 | "Tell me about a time you worked with engineers, sales and customers on the same piece of work." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Start with what the quotes carry: client integrations you led, and sessions feeding client evidence to product. Engineering and sales are not in them. Answer slot: if engineering or sales were part of any of that work, pick that instance and say who, what you needed from each, and what part was yours; if neither was, say so plainly and stay with clients and product. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5 is a discovery row on a stated requirement. EXP because it asks for a chosen instance, which is an open prompt |

### Bank E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You ran quarterly roadmap-input sessions. How much of that was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Pause and restate the question. Hold the sentence: you ran them. Concede specifically and early: this is confirmed with limited inspectable proof, so say what you can show and what you cannot. Answer slot: if others co-ran or prepared any part, say which; if none did, say so plainly. Hold through two follow-ups by returning to the sessions, never by adding to them, and never by calling them roadmap ownership | F1 and F7 lean on a medium-confidence sentence, which is where a pressure style presses. EXP because it tests attribution |
| E2 | "Sixty seconds: why should I take a chance on you?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | Time-box it: about 15 seconds conceding, 30 holding, 15 closing. Concede: "I haven't held a product manager title or role" (source: the prohibited_claims item quoted here). Hold: you led 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live. Close with the ramp plan from A2 in one sentence and what you would want to confirm about the seat | F1 again, compressed; the rehearsal is brevity without bluffing. JD because it scores the whole fit |

### Bank G — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "We have two squad leads with their own views on priorities. Where's the seam between you and them, and what happens when you disagree?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Offer seam principles instead of claiming to know the seam: neither the JD nor the dossier says where it sits, and the dossier flags decision authority as unverified. Principles: agree decision rights early and write them down; disagree with evidence in the open; take an unresolved call to whoever sits above both. Reciprocity: what you bring the squads is client evidence, as in the quoted sessions, in whatever form the leads find useful. Then ask which decisions are yours and which are theirs | F2 and F8 sit exactly on this seam, and the dossier's open risk makes it worth rehearsing even at low weight. CASE because it is a live collaboration problem |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a piece of work that spanned two teams; use "we" for the context and "I" for your contribution; it needs the work named, what you did, what others did, and how you named them. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A collegial question about turf and attribution, likely if the manager wants a view on how you work beside the squads. EXP because it tests what was actually yours |

### Bank H — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you had to deliver an unpopular truth to a stakeholder." | VAL | [generic] | Selection scaffold: pick a time with a named stakeholder, the truth you told, and a relationship that was still intact afterward; "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5 asks for stakeholder management and your material shows clients and product only. VAL because it is a behavioral prompt; no published values were in hand, so the theme is a persona stem |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with the customer's need named, the internal metric named, and what you chose; the hard truth must have landed, and if your material shows none, say so rather than supplying an ending. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A partner-facing platform makes customer-versus-metric trade-offs likely (F5, F9). VAL for the same reason as H1 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 3+ years product management experience | A1, A2, A4, E1, E2 |
| R2 Shipped API or platform products | C2 (C1 for the figure behind it) |
| R3 Technical fluency: API docs, schemas | D2, B3 |
| R4 Stakeholder management across engineering, sales, customers | D3, H1, H2, G2 |
| R5 Agile delivery experience | A5 |
| Own the roadmap | A1, A2, E2, B2, B5, G1 |
| Run discovery with integration partners | A3, B5 |
| Write specs and drive delivery with two engineering squads | B3, B2, G1 |
| Define and track adoption metrics | B1, B4, C3 |
| CO questions | none: strategy research was refused, so none could be grounded |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this role make alone, and which belong to the squad leads?" | The dossier's first risk: decision authority is asserted in the JD but not evidenced. It reads as diligence and answers what you need to know before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second risk: adoption metrics are a named responsibility with no baseline stated. It connects to B1, B4 and C3 |
| 3 | "What would a strong first quarter look like in this seat?" | It lets the manager define success in their own words, which the ramp plan in A1 and A2 can then be matched to |
| 4 | "How do the two squads divide the platform, and where do their roadmaps meet?" | The JD names two squads and nothing about the seam; the answer informs G1 |
| 5 | "How does delivery run with the two squads day to day?" | It is the clarifier F6 needs: the answer shows how this team defines agile delivery |
| 6 | "What happens to partner evidence today between a partner conversation and the roadmap?" | It invites the manager to describe where the sessions in F1 and F7 would plug in, without claiming anything |

## Prohibited claims

Not coached in any cell of this pack, including answer slots and drill feedback.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | prohibited_claims, dossier | The quotes at their own scope (F1) plus the plain acknowledgment the dossier item sources: "I haven't held a product manager title or role." |
| Having owned a product roadmap | prohibited_claims and the acknowledge_gap area on "Owning a roadmap and prioritization authority (R1 sub-claim)", dossier | "I haven't owned a product roadmap," then a ramp plan said as a plan. No bridge and no answer slot. The roadmap-input sessions in F1 stay at their own scope: sessions that fed client evidence to product |
| Having set prioritization for an engineering squad | prohibited_claims, dossier | "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says the integrations, not shipping a product. C2's slot stays inside the integrations |
| Ran product discovery with integration partners | Inflated form of F7 | F7's quote at its own scope: sessions feeding client evidence to product. A3's slot asks only how the evidence reached the sessions |
| Wrote product specs and drove delivery with engineering squads | Inflated form of F8 | F8's quote at its own scope: requirements as one stage of integrations you led. The slot asks only what form they took and who received them |

## Sources

Provided: tuesday-dossier.md, version 1.1. Sections consumed: role_profile (the JD equivalent: requirements and responsibilities); handoff_to_mock_interview (verified_candidate_evidence, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims); decision, as context only. The dossier carries no evidence_map, evidence_state or risk_register, so the grading on F3 to F5 and F7 to F9 is this pack's inference and is labeled so. Where the pack rests on your confirmed evidence: every quote in the fit snapshot. Where it rests on its own inference: the persona weights and every generic scaffold.

Searches sent, all refused, nothing returned:
- Quartzline company values: refused
- Quartzline interview process product manager: refused
- Quartzline strategy API platform news: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Search refused. It would have supplied published value names for the VAL themes, which now come from persona stems only |
| 2. Quartzline interview process, product manager | unavailable | Search refused. It would have documented the loop; the persona weights instead rest on your words (one 45-minute hiring-manager session) and the hiring-manager prior |
| 3. Quartzline strategy and recent news | unavailable | Search refused. It would have supported CO questions and a grounding brief; none are written |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. Representative product manager JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Prep time available → a triage schedule sized to it, with the few things to do well in order
- The interviewer's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their own path
- The recruiter's prep email → focus areas and any pre-declared deliverable, which would get its own build section
- Your own answers to the slots in A3, A5, C1, C2, C3, D2 and D3 → rows F3 to F9 move from inferred toward grounded
- An agenda, notes or output document from one roadmap-input session → raises the evidence behind F1 and F7 from medium toward high
- The integration playbook's contents → D2 gets named sections to walk through instead of a prompt to pick two
- Search access, or Quartzline's values page and a strategy note pasted in → CO questions, a grounding brief, and VAL questions mapped to published values; a deeper research pass would be up to 6 more searches and 2 more fetches, several more minutes
