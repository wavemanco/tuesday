I'll read the reference files the skill points to before writing the pack.
The pack is written and saved. Here's the handoff.

Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-denied-670897d4/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 22 questions across seven interviewer styles, a fit snapshot of your background against the JD, reverse questions and a prep order for the two days before Friday.

- **Assumption:** I built it as a hiring-manager round, since your note didn't say whether Tobias would be your manager. That puts the most weight on live problems and on probing your gaps.
- **No company research:** web search wasn't permitted in this session, so none of the four lookups ran. The pack uses only your JD and your background note. It names no company values, no Saltmarsh strategy and nothing about Tobias beyond his title.
- **Highest-ROI prep:** B1, "You haven't worked on a game with in-app purchases. How would you handle that?" It's a gap you stated yourself, so wording can't close it. The only honest answer is a plain acknowledgment plus a learning plan, and the pack lays out how to hold that through four follow-ups.
- **Answer slots:** Several questions end in a slot rather than a scripted answer, because your note doesn't say whether the puzzle title ran as a live service or which teams your drops involved. Answer them truthfully, in either direction, from your own experience.

Say the word and I'll play the Skeptic on B1, live, with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and has the recruiter said anything about what the hour will cover? Either answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager, 60 minutes, on Friday. Your note did not say whether Tobias is the person you would report to, so the persona weights rest on that assumption and the persona table shows the reasoning.
**Research:** web search was not permitted in this session, so nothing here comes from outside your JD and your background note. Sources lists every call that was sent.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding for a spoken answer of 90 to 120 seconds, not a script: say it in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values a company publishes, not generic virtue |
| EXP | Whether your background survives scrutiny; what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

Every question has a Provenance cell. The label is `[grounded]` (traceable to your JD or your message), `[inferred]` (derived, with the derivation named) or `[generic]` (a pattern for the problem, no claim about you or Saltmarsh). Where the guidance says something about your past, the sentence it rests on is quoted beside the label.

An **answer slot** is an instruction for the interview, not a question for you now. It names a likely probe and gives two honest branches: say what you did, in your own words, or say plainly that it was not yours or did not exist. Either branch is a good answer. Fit-snapshot rows are F1 to F10; question banks use the letters A to E, G and H, so no question ID collides with a row.

## Prep triage

You have the two days before Friday. In order:

1. **B1**, the highest-ROI prep in the pack: say it aloud until it is boring.
2. **D1**, your 90-second arc, built only from the four sentences quoted there.
3. **C1**: find out, before Friday, how your studio's retention numbers were counted and what part of producing them was yours, so the answer slot is answerable from fact.
4. **A1 and A2**, aloud, clarifying first.
5. **The answer slots on F1, F3, F4 and F5**: decide your truthful answer to each, in your own words.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives the years and the weekly calendar; it does not say whether the title ran as a live service. Answer slot: the JD names live-service, so expect a probe on it. If the title ran as a live service, say what that meant for the weekly drops, in your own words; if it did not, or you are unsure the studio would call it that, say so plainly and stay with the calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but one sentence with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you ran the weekly content-drop calendar for your main title, for the last two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your sentence is a weekly content-drop calendar for one title; the JD says a live-events calendar for two. The words stay at your scope: "I ran the weekly content-drop calendar for our main title." Answer slot: expect a probe on how your weekly calendar was built. If anything shaped which drop went in which week, say what it was and what part was yours, in your own words; if nothing did, or it was not yours, say so plainly and stay with the weekly calendar |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not say which teams the weekly drops involved. Answer slot: the JD names four disciplines, so expect a probe on each. If your drops needed input from design, art, engineering or community, say which and what your part was, in your own words; if you worked with only some of them, or the drops did not run that way, say so plainly and describe the people you did work with |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your sentence is presenting monthly retention numbers; the JD says owning a review and its KPIs. The words stay at your scope: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on the numbers you presented. Say how they were counted, which part of producing them was yours, and the assumption behind them you would defend least, in your own words; if you do not know how they were counted, say so plainly and stay with presenting them |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Reword only the sentence and stop where it stops: "I wrote the release checklist our QA team still uses." Answer slot: expect a probe on the checklist itself. Say what it covers, in your own words; if QA changed it after you wrote it, say how, and if not, say so plainly |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Reword only the sentence: "I presented the monthly retention numbers to the studio head." It carries no figures, so this pack has no number to defend and supplies none. Expect a probe on how the numbers were counted; C1 holds the slots |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | Derived from the one written artifact in your material: a checklist touches the requirement without showing writing for readers who were not in the room. Answer slot: if you wrote anything else for a wider readership, say what it was and who read it, in your own words; if the checklist is the only such piece, say so plainly and stay with it |
| F9 | Leading a team: not a JD requirement (the JD says "coordinate"); raised by your message | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't led a team." Then how you would get work moving across disciplines without managing them, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | In-app purchase experience: not in the JD; raised by your message | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't worked on a game with in-app purchases." Then what you would learn first and from whom, said as a plan and never as a past |

No requirement in the JD is a gate: "3+ years" is a length-of-experience requirement, graded in F1 like any other row.

## Persona table

Relationship prior for a hiring-manager round is Case/Strategist plus Skeptic. No loop source beyond your own words establishes the round (one 60-minute conversation with Tobias), and the fallback archetype is Generic, so the loop adds no tilt and the weights rest on the relationship prior and your material.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: schedule a clash, diagnose a bad event, design a checklist | High. The hiring-manager prior; the JD's duties (calendar, release checklist, post-event review) convert directly into live problems. Bank A, 5 questions | Clarify, objective, options, trade-off, decision, risks; say the framework aloud; challenge one premise politely |
| Skeptic | Quiet, persistent probing of the gaps: purchases, leading, live-service, why this move | High. The hiring-manager prior; you have stated two gaps (F9, F10) and F1 is unresolved. Bank B, 5 questions | Rehearse B1 until it is boring; plain acknowledgment of what you stated, then a plan; never a bluff on a competency the interviewer owns |
| Data-Driven Prober | Reads your retention line and asks how the numbers were counted | Medium. The JD asks for comfort with retention metrics and KPIs (F5, F7), and your retention sentence is the line a prober reads. Bank C, 3 questions | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational | The biography opener, "what are you playing", "why us" | Medium. The round's structure is unknown, and casual-register questions are scored the same. Bank D, 3 questions | A 90-second arc; treat casual questions about live ops as scored |
| Pressure | Time-boxed "why you" and "how much was you" | Low. No signal for it; included because the stated gaps invite a "why you" challenge. Bank E, 2 questions | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator | Seams between teams and credit-sharing | Low. Tobias is assumed senior to the role, but the JD's cross-team coordination (F4) makes it likely in later conversations. Bank G, 2 questions | Reciprocity framing; seam principles rather than a map of teams you have not seen |
| Values/Behavioral | Stories mapped to published values | Low. No loop source documents a values round and no values page was read, so the pack cannot name values. Bank H, 2 questions, from persona stems only | Stories with a named stake; choose ones where the hard truth landed, and say so plainly where your material shows none |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "An event for one of the two titles lands the same week as a major engineering release for the other. How do you plan the calendar?" | CASE | [generic] | Clarify first, aloud: which dates are fixed for players and which can move, what engineering capacity each release needs, and who decides priority between the titles. Then objective, two options with the trade-off of each, your pick, and who you tell and when. Say the framework before using it and challenge one premise, such as whether both must ship that week. It asks about no past, so the guidance claims none | F3's requirement, two titles on one calendar, as a live problem; `[generic]` because the pack has no research on how Saltmarsh runs it |
| A2 | "An event you scheduled is underperforming on day two. How do you diagnose it, and what do you decide that day?" | CASE | [generic] | Clarify what underperforming is measured against and for which players. Check what else changed in the build or the schedule before blaming the event design, segment the shortfall, separate what you can decide today from what waits for the review, and say what you would tell the teams. Name the assumption in your read you would defend least | F5 and F7 as a decision under data; CASE because it is a live diagnosis |
| A3 | "How would you set up the post-event review: what goes in it, who gets it, and how do you write it up so someone who wasn't in the room can act on it?" | JD | [generic] | Structure: what the event was meant to do, written down before it ran; what happened against that; what you would change; who owns each change. Say which KPIs you would pick and why, and the weakest assumption in how you would read them. For the writing, say what the first line of the write-up would be. It asks about no past, so the guidance claims none | F5 and F8 are the JD lines it scores; JD content with CASE delivery |
| A4 | "Design a release checklist for an event that touches art, engineering and community. What sections does it need, and who signs off on each?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Open with the one sentence your material carries: "I wrote the release checklist our QA team still uses." Then design aloud as a hypothetical: sections by team, a go or no-go owner for each, what blocks a release, what happens after it ships. Do not present the design as a description of yours. Answer slot: expect a probe on the checklist itself. Say what it covers, in your own words; if QA changed it after you wrote it, say how, and if not, say so plainly | F6 is the row it scores; JD because the JD names the checklist, CASE because the ask is a design |
| A5 | "A proposed event adds a limited-time offer. What do you ask before it goes on the calendar?" | CASE | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Ask: what the offer is meant to do, who owns the decision to run it, how the event's success will be measured, and what the risk to player trust is if it goes badly. If you flag the gap, flag it once and plainly: "I haven't worked on a game with in-app purchases", then ask the questions anyway. The questions are the answer; do not describe offers from experience | F10 as a live problem, so a stated gap is met with structure; CASE because it is a decision, not a history |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Presented the monthly retention numbers to the studio head." | **Highest-ROI prep in the pack.** Level 1: the plain acknowledgment, then the plan: "I haven't worked on a game with in-app purchases." Say what you would learn first and from whom, in your own words. Level 2, if pressed on how fast: give the timeframe you would actually commit to. Level 3, if asked what you could not yet do: name it specifically; a named limit costs less than a vague one. Level 4, if asked whether that makes you the wrong hire: hold, and return only to what your material carries, the weekly calendar for your main title and the retention numbers you presented. Never describe purchase work, offers or pricing from experience, and do not stretch retention reporting into it | F10 is a gap you stated and wording cannot close it, so the whole rehearsal is candor plus a plan. Ranked first because it needs no probing to surface; the likelihood reasoning is in the persona table. JD because it tests fit against the full role, gaps included |
| B2 | "You haven't led a team, and this role coordinates design, art, engineering and community on each update. How would you get four disciplines moving without being anyone's manager?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first: "I haven't led a team." Then your plan: what you would agree with each discipline up front, and where you would escalate. Answer slot: expect a probe on what your weekly drops needed from other teams. Say which disciplines you worked with and what your part was, in your own words; if you worked with fewer, or the drops did not run that way, say so plainly and describe the people you did work with | F9 and F4; the question is premised only on a stated negative and the JD's own line; JD because it scores the coordination requirement |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick one and say it plainly; the choice shows self-assessment. Your material states two limits, "Never led a team, and never worked on a game with in-app purchases." Choose the one you can attach a first step to, state the step as a plan, and do not choose a gap you could not defend. Do not answer "none" | F9 and F10; the standard Skeptic stem, scored on honest self-assessment |
| B4 | "You've been an associate producer at a puzzle-game studio. Why this move, and why now?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | Three beats in your own words: what in this JD you want to do (use its own lines, for example "Plan and run the live-events calendar for two of our mobile titles"), what in your material sits next to it, and what you would still need to learn. Answer slot: the reason for "now" is yours to give; if part of it is that the role is a step up, say that plainly. Do not invent a reason that sounds better | F1 and F3; motivation consistency is what the Skeptic scores, and JD because the answer is anchored in its lines |
| B5 | "The JD asks for 3+ years producing live-service games or apps. Was your puzzle title run as a live service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if the title ran as a live service, say what that meant for the weekly drops, in your own words; if it did not, or you are unsure the studio would call it that, say so plainly and stay with the calendar you ran. Hold the years as stated: four years as an associate producer | F1 is unresolved on exactly this point; JD because it scores the first requirement directly |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start with what the sentence carries: "I presented the monthly retention numbers to the studio head." Answer slot: say how the numbers were counted, what they are most sensitive to, the assumption behind them you would defend least, and which part of producing them was yours, in your own words; if you do not know how they were counted, say so plainly and stay with presenting them. Do not offer a figure or a definition you cannot repeat under a second question | F7 and F5; EXP with defend-the-number discipline, since this is the sentence a prober reads |
| C2 | "On the day after an event ends, which retention number do you look at first, and why?" | JD | [generic] | Say what you would look at, over what window, compared to what, and why; then say what it cannot tell you. If the studio's own definition is something you would check first, say so. If asked which you actually used, answer only from what you actually used | F7's requirement as a working question; `[generic]` because it asks for a method, not a history |
| C3 | "What can retention numbers not tell you about whether an event worked?" | JD | [generic] | Name two limits and how you would cover each, for example other changes shipping in the same period, and no view of what would have happened without the event. Name the weakest assumption in how you would read the numbers | F7 and F5; tests whether you know the limits of the metric you are asked to be comfortable with |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from those four sentences, in your own words. End on why this role (B4). Add no team sizes, scope or results those sentences do not state | F1, F2, F6 and F7 together; EXP because it is the opener that every later probe builds on |
| D2 | "What are you actually playing, and following, in mobile live ops these days?" | CO | [generic] | Selection scaffold: pick one or two live events or updates you have actually played or watched; for each, say what you noticed about how it was scheduled and what you would have asked the team. If none comes to mind, say so plainly, then name what you will play before Friday | The casual-register question is scored; `[generic]` because no strategy research was possible |
| D3 | "Why Saltmarsh?" | CO | [grounded] | Use only what you can source: the JD's own lines, "Plan and run the live-events calendar for two of our mobile titles" and "coordinate design, art, engineering and community teams on each update", and say what about that work draws you. Find and play both titles before Friday and cite what you actually saw. Do not state claims about the studio's strategy you have not read | CO from the only company source in hand, the JD; no strategy claim is available to make |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head."; "Never led a team, and never worked on a game with in-app purchases." | Hold-then-concede. Hold: those three sentences, at their own scope. Concede once and specifically: "I haven't worked on a game with in-app purchases", then say what you would do about it. Pause and restate the question first; do not claim to be better. If challenged twice, return to the same three sentences and the same concession | F10 and F3 under time pressure; JD because it scores fit against the role, delivered as a stress question |
| E2 | "That retention reporting: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Pause and restate. Hold through two follow-ups on what the sentence says: "I presented the monthly retention numbers to the studio head." Answer slot: say which part of producing and choosing those numbers was yours, in your own words; if others produced them, or you do not know how they were counted, say so plainly and stay with presenting them. Concede only what is true, specifically; do not fold the core sentence to restore harmony | F5's attribution probe; EXP because it scores precise attribution |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design and engineering both want the same slot in the calendar. Where is the seam between us, and what happens when we disagree?" | CASE | [generic] | Offer seam principles, not a map of a team you have not seen: who decides, who is consulted, what you bring them (a clear brief and a date they can plan against), and when it escalates. Show spine and tact: say what you would hold firm on. It asks about no past, so the guidance claims none | F4's cross-team requirement as a live problem; CASE delivery with a peer's collegial packaging |
| G2 | "How do you handle credit when an update spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned several people; it needs a piece that was named as yours, a piece that was someone else's, and what you said publicly. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Use "we" for the work and "I" only for what was yours | F4; the Peer persona's credit stem, VAL because it scores behavior toward colleagues |

### H. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and an intact relationship afterward. Where such a time sits in your retention reporting, tell it; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The persona's own stem; no published values were read, so no value is named. VAL because it scores behavior under a stake |
| H2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the metric pointed one way and the player experience the other; it needs the choice you made, who disagreed, and what you would say about it now. If no such time comes to mind, say so plainly, then say how you would handle it | The persona's customer-over-metric stem, applied to players; `[generic]` because it carries no claim about you or Saltmarsh |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "3+ years producing live-service games or apps" | B5, B4, D1 |
| "experience running a content calendar" | A1, D1 |
| "Plan and run the live-events calendar for two of our mobile titles" | A1, B3 |
| "coordinate design, art, engineering and community teams on each update" | B2, G1, G2, A1 |
| "own the post-event review and the KPIs it reports" | A2, A3, C1, E2 |
| "manage the release checklist with QA" | A4 |
| "comfortable with player-retention metrics" | C1, C2, C3, A2 |
| "clear written communication" | A3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for this role across the two titles?" | The JD names two titles; it asks for a measurable target and shows you are thinking about both |
| R2 | "Where do updates most often get tight, and who feels it first?" | Signals you think in handoffs, and invites real information about the four teams |
| R3 | "How is the post-event review used today: who reads it, and what has changed because of one?" | The JD says the role owns it; it shows you care about the loop closing, not the document |
| R4 | "If there is a purchase side to the titles, what should I learn first about how it interacts with the event calendar?" | Turns the gap you stated into a question about learning, so it is raised on your terms rather than probed |
| R5 | "How does Live Ops work with design, art, engineering and community day to day, and where does the producer escalate when priorities clash?" | Tests the coordination requirement from the other side and shows you want clear escalation |
| R6 | "What would you want to see from me in the first month to know you hired right?" | Makes the interviewer state their bar, and gives you one last chance to address it |
| R7 | "Is there anything in my background you would want to dig into that we haven't covered?" | Invites any remaining doubt while you can still answer it |

## Prohibited claims

Built from the fit snapshot before the banks. No dossier was present, so every entry is built locally.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for the main title, not events and not two titles. A1's guidance claims nothing about your past |
| Owned the KPIs or the post-event review | Inflated form of F5 | F5's quote at its own scope: your material says you presented the numbers. C1 and E2's slots stay inside presenting |
| Managed releases with QA | Inflated form of F6 | F6's quote at its own scope: your material says you wrote the checklist QA still uses. A4's slot stays inside the checklist |
| Has led a team | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the JD text and your background note, both from this conversation. No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Queries sent, all refused (the host did not grant search permission):

- `Saltmarsh Games values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games strategy news mobile` — refused
- `Tobias Wrenfield Saltmarsh Games` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Search refused. Would have supplied official value names for VAL questions and a values cheat sheet if a values round were detected; Bank H is stem-only instead |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Search refused. Would have documented the loop; persona weights rest on the relationship prior and your own description of the round |
| 3. `Saltmarsh Games strategy news mobile` | unavailable | Search refused. Would have grounded CO and CASE questions in current strategy; D2 and D3 are generic or JD-only as a result |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Search refused. Would have supplied the interviewer read and a tailored reverse question; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The recruiter's prep email or any stated focus areas for the hour → coverage assumed from the hiring-manager prior becomes coverage grounded in what they said, and any announced deliverable gets its own build section
- Whether Tobias is the person you would report to → persona weights recomputed; a skip-level or peer reading changes banks A, B and G
- Permission to search the web → a values cheat sheet if a values round is documented, the loop structure, a grounding brief for CO questions, and Tobias's public footprint for an interviewer read; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can be added once search is available
- Your answers to the slots on F1, F3, F4, F5 and F8 → those rows move from `discovery` or `transferability` toward story-mapped answers, and the matching questions (B5, B2, A4, C1, A3) become mapped stories instead of slots
- The release checklist itself, a retention report you presented, or an export of a content calendar → the inspectable artifacts for this field; F2, F5, F6 and F7 can rise from `medium` to `high`
- A job-underwriter dossier → verified evidence and a prohibited-claims list from a deeper evidence review in place of the locally built one
