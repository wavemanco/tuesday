I'll read the reference files before writing anything.
Searches were declined, so the pack rests on your notes only. Values, interview process and Dan's public footprint are logged as unavailable. I'm writing the pack file now.
The pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-1-denied-6059ce34/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It's built for one 60-minute peer conversation with Dan.

It has 21 questions across seven personas: Prober 5, Peer 4, Case 3, Skeptic 3, and 2 each for Conversational, Pressure and Values. Each question carries a type tag, answer guidance, provenance quotes and a rationale. The file also has a fit snapshot, a read of Dan, a requirement-coverage table, six reverse questions, a prohibited-claims list and an upgrade menu.

- **Research was declined.** My three searches (Northwind's values, its interview process, and Dan's public footprint) were refused. The pack rests only on what you gave me, and the Sources section logs each as unavailable.
- **No values section.** Without a values source, the two Values questions use generic prompts, and no values cheat sheet was built.
- **Highest-ROI rehearsal.** D1 is "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role?" It targets the biggest stated gap, in Dan's own function, and is rehearsed through three follow-ups.
- **Answer slots.** Wherever Priya's material doesn't say what she did (F1–F4, e.g. the partner motion or the independent SQL analysis), the guidance leaves a slot for her to fill from her own experience, with an honest second branch.

Say the word and I'll play Dan as the Skeptic on D1, or as the Prober on A1 and A2.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Did the recruiter, or Dan, say anything about what the 60 minutes will cover, or ask Priya to bring anything? A case or deliverable would add a build section.
2. Can you paste the full JD text and Priya's CV lines on the revenue model, the volume targets and the store-surface proposal? That would turn several of the answer slots into story maps.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy. A peer: Priya and Dan report to the same VP
- **Round:** one 60-minute conversation. Your message establishes the loop, so no archetype fallback is used. No values-style round is documented, so there is no values cheat sheet
- **Research basis:** your notes only. The three searches were declined, so company values, interview process and Dan's public footprint are not established (see Sources)

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows values, asked here from a persona stem because no published values were read |
| EXP | Whether a claim from the background survives scrutiny, and what was actually yours |
| JD | Whether you can do the stated job, gaps included |
| CO | Whether you can think at Northwind's altitude: its strategy, competition and recent moves |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for this conversation. It names what the interviewer will probably probe and gives two honest branches, one of which always lets the practice not have been yours, or not have existed. F1 to F7 are the fit-snapshot rows. A1 to G2 are the questions.

## Fit snapshot

Requirements are quoted from the JD highlights in your message (a summary, not the full JD text). Evidence is quoted from your notes on Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market, and the words stay there: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's own-the-strategy line makes a probe on that work likely. If any part of it was yours to set, say which and how you decided, in your own words; if none was, say so plainly and describe the work you did |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material says a proposal and a credit, with nothing inspected behind the figure, and the words stay there: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's lifecycle language makes a probe on which stage the change touched likely. If you know, say which, in your own words; if it was not tied to a stage, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | low | [inferred] | discovery | The quote claims skill, and the pack does not stretch it to independent analysis. Words: "I'm skilled in SQL and Tableau." Answer slot: if you ran an analysis start to finish yourself, name it and say what was yours; if you did not, or others did part of it, say so plainly and stay with the skill statement |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in carrier negotiations, with nothing inspected behind it, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: expect a probe on what the model was used for in those negotiations. If you can say which part of that was yours to decide, say it in your own words; if none was, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | A CV-style line with nothing inspected behind it. Lead with its own terms: you set annual volume targets, and the consensus was cross-org. Nothing is added to it here. The probe on how consensus was reached is rehearsed in B1 |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | Words: "I use AI tools daily." The pack reads this as use, and keeps it there. What you use and for what is in your own words (E2) |
| F7 | "Director of Sales Strategy" — Dan's title, from the coach's notes; sales-ops and quota work is his function's territory, not a JD line | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it has been stated. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. F5's targets stay at their own scope and are not renamed |

## Reading the interviewer

The facts below come from the profile summary you supplied. A search for more of Dan's public footprint was declined, so nothing beyond your summary is used.

| Signal | Source | Reading (the pack's analysis) | Provenance |
|---|---|---|---|
| "relentlessly data-driven" | Dan's profile self-description, per your message | Expect every number to be probed to its inputs. State assumptions early and say plainly what you do not know. Rehearse A1 to A3 first | [grounded] |
| "pricing and monetization roles, with one early-stage-startup chapter" | Dan's career, per your message | Pricing, packaging and unit economics are his native language, so C1 and C2 build them into the plan. The startup chapter makes a pace or scrappiness probe about big-company habits plausible (D3) | [grounded] |
| Peer, same VP | Your message | He is weighing what you add to or take from his load. Reciprocity beats self-presentation (B1, B3) | [grounded] |
| Mirror opportunity: his pricing and monetization path against F4's "built a partner-level revenue model used in carrier negotiations" | Dan's profile plus F4's evidence cell | Describe the model in the quote's own terms and ask for his view. Do not call it pricing work, since the quote does not say that. No quote carries Priya's side of his startup chapter, so no mirror is offered there | [grounded] |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Reads the background line by line, asks how numbers were counted, goes two levels deeper than the answer | High. Peer prior, raised by the self-described "relentlessly data-driven" signal. 5 questions (A) | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know. Name the weakest assumption you know of before he does. Offer to walk through an analysis end to end only if you ran one yourself |
| Peer Evaluator | Seam-splitting between adjacent teams, "what would you need from me", credit and disagreement scenarios | High. Peer prior; same VP, adjacent functions. 4 questions (B) | Reciprocity: what you bring his team, not only what you need. Propose seam principles rather than pretending to know the seam. Disagreement stories that show spine and tact together, only where you have one |
| Case / Strategist | A live problem on the real role: plan a GTM, respond to bundling, find whitespace | Medium. The pricing and monetization spine tilts cases toward pricing, packaging and unit economics. A peer is less likely than a hiring manager to run a long case, but 60 minutes allows one. 3 questions (C) | Clarify, objective, segmentation, approach, metrics, risks. Think aloud, and challenge one premise respectfully |
| Skeptic | Quiet, persistent probing of the gaps and of why here, why now | Medium. The fit snapshot carries real gaps (F1, F4, F7), and the startup chapter raises pace probes. 3 questions (D) | Rehearse D1 until it is boring. Bridge only from quoted evidence, name the limit before it is asked, and add a concrete ramp plan |
| Conversational | Friendly opener, "walk me through the journey", a casual question on a hot JD topic | Low. It is the likely opener rather than the likely bulk. 2 questions (E) | Pre-script the 90-second arc from your quotes. Treat the casual AI question as scored |
| Pressure | Interrupts or time-boxes, such as "how much of that was actually you" | Low. Not a peer prior; it appears as a challenge on the number or the gap. 2 questions (F) | Pause, restate, hold the quoted position through two follow-ups, concede only what the material really does not carry |
| Values / Behavioral | Scenario probes that look for demonstrated behavior | Low. No values-style round is documented and the values page was not read. 2 questions (G) | Selection scaffolds ending in the honest branch. Choose stories in which the hard truth actually landed |

## Question banks

### Requirement coverage

| JD requirement (highlights) | Covered by |
|---|---|
| own GTM strategy for two new product lines | A4, C1 |
| identify whitespace across land/adopt/expand/renew | C3 |
| run independent analysis in SQL and Tableau | A3 |
| partner-motion design experience required | A5 |
| strong cross-functional influence | B1, B2, B3 |
| AI experience a plus | E2 |
| Not in the highlights, raised by Dan's function (F7) | D1, D2, B4, F2 |

The highest-ROI prep in the pack is D1. It aims at the biggest stated gap, in Dan's own function, and it will arrive in some form.

### A. Data-Driven Prober (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open on the quote's own terms: "I proposed a store-surface change, and it was credited with a ~$400M ARR uplift." The figure stays on the uplift, and the credit stays a credit. The defend-the-number slots come next, each in your own words: how it was counted, what it is most sensitive to, which part was yours. Answer slot: if you know how the figure was counted, say how and stop there; if you do not, or the counting was not yours, say so plainly and return to what you proposed | F2 holds the only headline number, and a peer who calls himself data-driven reads numbers to their inputs. EXP because it tests whether the claim survives scrutiny and who counted what |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name, before he does, the assumption you would defend least. The pack does not name one for you. Answer slot: if you know of one, say it, in your own words; if you do not know how the figure was built, say so plainly and return to the proposal | The second level down on F2, where a prober's follow-up goes. EXP because it scores whether the candidate knows their own assumptions |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau, from the question to the answer." | JD | [inferred] "skilled in SQL/Tableau" | Say the quote at its own scope: "I'm skilled in SQL and Tableau." Then choose an example where you wrote the queries or built the view yourself and can state the question it answered, the data it used, what it showed and what happened next. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, the skill statement, or how you would approach a first analysis here. Offer a full walk-through only if you did it | F3 is the thinnest evidence against a JD line that says independent analysis. JD because it scores the stated tool requirement, with a prober asking about ownership |
| A4 | "The role owns GTM strategy for two new product lines. Where have you worked on something like that?" | JD | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Say what your material says: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Answer slot: if any part of that work was yours to set, say which and how you decided; if none was, say so plainly and describe the work you did. Do not rename the work to match the JD's phrase | F1 is the headline responsibility and the widest distance between the JD's words and the evidence. JD because it tests fit to the stated job |
| A5 | "Partner-motion design experience is required for this role. What is the closest thing you have done?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say the quote at its own scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: expect a follow-up on what the model was used for in those negotiations and which part of that was yours to decide. If you can say, say it in your own words; if its use was not yours to shape, or nothing beyond the model was yours, say so plainly and stay with the model. Then ask Dan how Northwind's partner motion works today rather than guessing | F4 is the only JD line marked required that has adjacent evidence and no direct match. JD because it scores the stated requirement; it is the Prober's to press because it reads the background line by line |

### B. Peer Evaluator (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose seam principles rather than pretending to know the seam: ask where he feels it today before drawing one. Say that on shared questions you would bring the data to him first, and take what stays unresolved to the shared VP together. For your own side, say only what the quote says: "I set annual volume targets with cross-org consensus." Answer slot: expect "tell me about a disagreement in that process". If there was one, say what it was and what you did; if there was none, or the consensus was not yours to build, say so plainly and describe how you would handle one here | Peer seam question. F5 is the evidence for cross-functional influence. JD because it scores that stated requirement, delivered in peer register |
| B2 | "How do you handle credit when work spans teams?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the quote's own verbs: you proposed, and the change was credited. Say "I proposed it", and let others' roles be what they were. Answer slot: expect "who else was involved". If others shared the work, name them and say what each did; if not, say so plainly and return to the proposal. For the principle, say in your own words how you credit people whose work you relied on | Credit-sharing is a standard peer probe, and F2 is where credit language already sits in the material. JD for cross-functional influence, with a behavioral flavor |
| B3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Reciprocity first. Asks: how Sales Strategy defines land, adopt, expand and renew today, which data he trusts, and how targets and quotas are set for existing lines. Offers: early drafts of anything touching his team's numbers, and your analysis shared. These are commitments about the future, not claims about your past. The quota ask is deliberate: it turns F7 into a question for him | The reciprocity question for a peer. JD because it scores cross-functional partnership. `[generic]` because it carries no claim about the candidate |
| B4 | "Say a rep is paid on an established product and you want their attention on a new line. How do you handle that?" | CASE | [grounded] "No classic sales-ops or quota-setting experience." | Start with the sourced acknowledgment, briefly: "I don't have classic sales-ops or quota-setting experience." Then structure it: first clarify how compensation and quotas work for new lines today and what has been tried, then the objective, the options with their tradeoffs, who decides (you, Dan and your VP), and the metrics. Think aloud and challenge one premise, for example whether attention is the real constraint. The structure is a pattern for the problem, not a claim about your past | Lands where Dan's function and this role collide, and where F7 matters. CASE because it is a live problem asked by a peer |

### C. Case / Strategist (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Take the three priorities: enterprise expansion, Compass, profitability. Sketch the GTM plan for a new line. What do you need to know first?" | CASE | [grounded] your research note: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Clarify first: whether Compass is one of the two new lines, what stage each line is at, who the first buyer is, and what profitable means for it. Then objective, segmentation by the JD's own stages (land, adopt, expand, renew), approach, metrics, risks. Name the tension aloud: expansion spend against the profitability priority. Put pricing and packaging in the plan, since that is his native ground. The question needs no claim about your past | A peer with a pricing and monetization spine is likely to take a case there. The three priorities come from your research note |
| C2 | "A much larger platform vendor bundles a competing capability into its suite. How does your GTM for a new line respond?" | CO | [grounded] your research note: "bundling by a much larger platform vendor" | Anchor on what you know and flag it: "As I understand it, bundling is the main competitive threat. Correct me if that has moved." Clarify which line the bundle touches, segment buyers by exposure, decide where to compete standalone and where through integration with the suite, test pricing and packaging responses with his team's data, and set triggers for revisiting. Do not claim knowledge of the vendor's roadmap or of Northwind's win and loss data | Ties to a researched strategy fact. CO because it scores thinking at the company's altitude, with CASE delivery |
| C3 | "Where would you look for whitespace across land, adopt, expand and renew for a new line, and what would you deliberately not chase?" | JD | [generic] | Start with definitions: what counts as each stage in Northwind's data. Then the data check before any conclusion: reconcile stage totals to a source you trust, define cohorts, look at conversion and retention by segment. Form one hypothesis per stage, rank by size and effort, and name the anti-pick, what you would cut and why. Describe the SQL as the approach you would take, not as history | The JD's whitespace requirement, delivered as a case, with the data discipline a data-driven peer will test. `[generic]` because it is a pattern for the problem |

### D. Skeptic (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | The deepest rehearsal in the pack. Level 0: say it plainly and first, in the sourced words: "I don't have classic sales-ops or quota-setting experience." Name the limit before it is asked: "The nearest thing in my material is that I set annual volume targets with cross-org consensus, and I'm not calling that quota-setting." Then a plan, said as a plan: in the first month, learn from his team how targets and quotas are set for existing lines. Follow-up 1, "targets aren't quotas, so what is the difference?": concede explicitly that you cannot speak to how quotas work at Northwind, and hold that the targets and the consensus are what you did. Follow-up 2, "so why should I be comfortable?": hold by returning to the quote and the plan, never by adding experience. Follow-up 3, "what if you get a new-line quota design wrong?": propose designing it with his team before it ships. Concession wording: "That is a real gap on the mechanics, and your team is where I would learn them." Never fold on the quoted facts | F7 is the pack's biggest stated gap, in the peer's own function. JD because it scores fit to the function; Skeptic because it is a quiet cross-examination of the gap |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Selection scaffold: pick the item where your material is thinnest and that you can pair with a concrete first-month plan. F7 is stated, so you can use the sourced words for it. For F1, F3 and F4 the pack cannot say from here whether they are weak or strong for you, so name one of those only if you can say truthfully that it is. If no single item comes to mind, say so plainly, then give the nearest, the sales-ops and quota one, or how you would find out | Stock Skeptic stem. JD because it scores honest self-assessment against the listed requirements |
| D3 | "You have spent most of your career at a large consumer-tech company. Why a data-infrastructure company of about three thousand people, and why now?" | JD | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Own the shape in the quote's words: two years of strategy consulting, then nine at a large consumer-tech company in product strategy and ops. Your reason for here and now is yours and the pack cannot supply it. Say your real reason, and tie it to one of Northwind's three priorities only if that is genuinely what draws you; if not, say what does. On pace, expect a probe because his path includes an early-stage chapter: answer from what you have actually done, and if your material does not speak to it, say so plainly and say how you would get up to speed. Your material does not show business-customer work either way, so do not volunteer a claim about it | The motivation and fit probe, sharpened by F1's distance and Dan's startup chapter. JD because it scores whether the move to this role is credible |

### E. Conversational (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops", "built a partner-level revenue model used in carrier negotiations", "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc in three beats from the quotes: two years of strategy consulting at a top firm; then nine at a large consumer-tech company in product strategy and ops; two items from that time in the quotes' own words, the model and the proposal. Then to Northwind: your actual reason, in your own words. Add no titles, team sizes or product names that the quotes do not carry | The biography opener is scored for economy. EXP because it is the first test of whether the background holds together (F1, F2, F4) |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it at the quote's scope: "I use AI tools daily." Then, in your own words, which tools and what for; the pack does not know. If the use is narrower than daily suggests for work tasks, say what it is. The pack reads F6 as use and no further, so keep your description at use. Then turn it toward Compass and ask how Dan sees it changing the expansion motion | The JD's AI plus, asked casually, and casual questions on hot JD topics are still scored. JD because it scores a stated plus |

### F. Pressure (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ~$400M result. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate the question. Hold the position the quote carries: "I proposed the change, and it was credited with the ~$400M ARR uplift." Hold it through two follow-ups by returning to the proposal and the credit, never by adding to either. Answer slot: if you know how credit for the uplift was assigned, say how; if you do not, say so plainly and return to the proposal. Never fold on "I proposed it" | Stock Pressure stem on F2. EXP because it scores attribution honesty; Pressure because it tests composure when the number is challenged |
| F2 | "Sixty seconds: why you over someone who has run sales-ops for years?" | JD | [grounded] "No classic sales-ops or quota-setting experience.", "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops", "built a partner-level revenue model used in carrier negotiations", "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate. Do not claim a comparison you cannot win: "I don't have classic sales-ops or quota-setting experience." Then three beats in the quotes' words: the product strategy and ops years, the revenue model used in carrier negotiations, the proposal credited with the ARR uplift. Close with learning the mechanics from his team. Hold the beats through two follow-ups and concede specifically on the mechanics | Time-boxed version of D1's objection. JD because it scores fit; Pressure because of the clock and the comparison |

### G. Values / Behavioral (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a nameable stake, say what the truth was, who heard it, what happened after, and that the relationship held. Choose one where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. No story is mapped, because no quoted sentence carries one | Persona stem. VAL because it scores behavior; low weight because no values round is documented |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time where the metric cost was nameable, and say what you did and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. No story is mapped | Persona stem. VAL for the same reason; it is also a natural fit for a company with an expansion and renewal focus |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Your background is in pricing and monetization. When you look at a new product line, what do you want settled about pricing and packaging before sales starts selling it?" | Tied to Dan's own path. It invites him to teach in his native language, and shows you read his profile | [grounded] "pricing and monetization roles, with one early-stage-startup chapter" |
| R2 | "What could a new person on the Emerging Products side do in the first month that would genuinely help your team?" | The reciprocity question for a peer: it asks what reduces his load | [generic] |
| R3 | "Where do you see the line between your team's work and this role today, and where is it still unsettled?" | Moves the seam from a risk to a joint design problem, and surfaces how he sees the split | [generic] |
| R4 | "How do you expect Compass to change how Sales Strategy works the expansion motion?" | Uses a researched priority and asks for his view, not a recital of it | [grounded] your research note: "an AI copilot launch ('Compass')" |
| R5 | "Where, if anywhere, are you already seeing bundling pressure in the field?" | Shows you took the competitive frame seriously while asking, not asserting | [grounded] your research note: "bundling by a much larger platform vendor" |
| R6 | "You have worked in an early-stage company as well. What did that change about how you run strategy at this size?" | A second tie to his path, and it turns a possible pace probe into his story | [grounded] "one early-stage-startup chapter" |

## Prohibited claims

Built locally from the fit snapshot before the banks were written. No dossier was supplied.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not go-to-market. A4's slot stays inside the work she did |
| Drove or generated the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed, and credited with. The figure stays attached to the uplift credited to the change |
| Found whitespace across the customer lifecycle | Inflated form of F2 | F2's quote at its own scope. The material says a proposal and a credit, not how the opportunity was found |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope. The material says a revenue model used in carrier negotiations. A5's slot stays inside what the model was used for |
| Has sales-ops or quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Her annual volume targets were sales quotas | Inflated form of F5, and at odds with F7 | F5's quote at its own scope. The limit is the pack's observation: the material says volume targets with cross-org consensus |
| Ran independent SQL and Tableau analyses | Inflated form of F3 | F3's quote at its own scope: skilled. A3's slot asks only about an analysis you ran yourself |
| Built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: use |

## Sources

Provided documents: your message, which supplied the JD highlights (not the full JD text), the candidate summary, Dan's profile summary and your research note. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Query | What came back |
|---|---|
| Northwind Data company values principles | refused |
| Northwind Data interview process strategy role | refused |
| Dan Kovac Director of Sales Strategy Northwind Data | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have supplied published value names for VAL themes. Bank G is built from persona stems instead |
| 2. `Northwind Data interview process` | unavailable | The search was refused. It would have shown whether other rounds or a case format exist. Persona weights rest on your description of this one session |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the three priorities and the main competitive threat that feed C1, C2, R4 and R5 |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. It would have added talks and writing to the interviewer read and to R1 and R6 |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the requirement column of the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search → company values, the documented interview process and Dan's public footprint; a values page that a loop source ties to a round would also restore the values cheat sheet
- Full JD text → F1 to F6 move from your highlights to verbatim JD lines, and any requirement the highlights left out gets a question
- Priya's CV lines on the revenue model, the volume targets and the store-surface proposal → more quotes, so A4 and D3 can become story maps instead of slots
- Her answers to the answer slots in F1 to F4 → those rows upgrade from slots to story maps, and A3 to A5 sharpen
- The review or attribution write-up that credited the store-surface change → the inspectable artifact that could raise F2 above medium
- A workbook or query she can walk through, and the carrier-negotiation model → the same for F3 and F4
- The recruiter's note on what the 60 minutes will cover, or any case or deliverable → coverage tuned to it, plus a build section for any announced deliverable
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, needs search permission) → a grounding brief on Northwind's strategy and sharper CO questions
- A verified-evidence dossier → user-confirmed claims mapped to the banks, and a sourced prohibited list in place of this locally built one
