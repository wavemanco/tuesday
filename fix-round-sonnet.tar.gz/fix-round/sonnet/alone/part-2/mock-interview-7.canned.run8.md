I'll read the reference files the skill requires before building the pack.
The pack is written. I'm running a quick check on the saved file for stray brackets and pipe characters inside cells, then I'll present it.
Your prep pack is saved as /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-canned-4059bdf8/saltmarsh-games_live-operations-producer_interview_pack.md. I built it assuming Tobias is the hiring manager for your Friday session. The pack's Sources section shows what that rests on.

Say the word and I'll play the Skeptic on C1, the question the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Built on the assumption that he is the hiring manager for this 60-minute session, which Sources row 2 rests on.
**Mode:** Session pack, first version.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the company's published values |
| EXP | Whether your claims survive scrutiny and which part was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's current strategy |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to your documents or to research cited in Sources; `[inferred]` is derived and the derivation is named; `[generic]` is a role-family pattern that asserts nothing about you or Saltmarsh. An answer slot is an instruction for the interview, not a question for this conversation: it tells you what a probe is likely to ask and gives you two honest branches.

## Prep triage

Sized to the days between now and Friday. I do not know how many hours you have, so each line is a block, not a duration.

| Order | When | Do this | Tied to |
|---|---|---|---|
| 1 | Wednesday | Rehearse the in-app-purchase objection aloud until the plain acknowledgment and the hold are boring: C1, then C2 | C1, C2, section 13 |
| 2 | Wednesday | Run A1 and A2 aloud against a timer; the tabletop is the documented first half of this session | A1, A2 |
| 3 | Thursday | For B1 and B2, decide now whether a real instance comes to mind; if not, rehearse the honest branch. Answer the slots on F1, F2, F3, F5 for yourself | B1, B2, B3, B4 |
| 4 | Thursday | Write down what you do and do not know about how the retention numbers were counted; then say E2 in sixty seconds | D1, E2 |
| 5 | Friday morning | Pick three reverse questions; read the values page and the Project Larkspur news page in full, since this pack saw only a snippet of the latter | R1 to R6 |

Everything else is insurance.

## Fit snapshot

Requirements are the JD's own lines. Evidence is your own sentences, quoted. Two things you stated sit outside the JD's lines and are handled in section 13 and in C1 and C3: "Never led a team, and never worked on a game with in-app purchases."

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says the weekly content-drop calendar for your main title, not live events and not two titles, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD names two titles, so expect a probe on handling more than one. If any of your calendar work covered more than the main title, say what; if it covered one title, say so plainly and stay with that calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | Neither sentence shows whom you worked with on a drop beyond the QA team that uses your checklist. Answer slot: the JD lists four disciplines, so expect a probe on who you needed for a drop. If design, art, engineering or community were part of a drop, say which and what you needed from each, in your own words; if any were not, or the coordination was someone else's, say so plainly and stay with the calendar and the checklist |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a review or reported KPIs for events, and the words stay there: "Presented the monthly retention numbers to the studio head." Answer slot: if you also ran a review of a drop's results, say what it covered and which part was yours; if there was no such review, say so plainly and stay with the monthly numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead with the checklist in the quote's own terms: you wrote it, and the QA team still uses it. The material says wrote, not ran each release against it, so the words stop at the quote. Expect a release-by-release probe; A2 and B3 rehearse it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | The material gives four years as an associate producer and the weekly drops, and does not say whether the title ran as a live service. A years requirement is a threshold to weigh, not a gate. Answer slot: if the main title was operated as a live service, say how, in your own words; if it was not, or the drops were something else, say so plainly and stay with the drops |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with the calendar in the quote's own terms: weekly, content drops, your main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but nothing inspected stands behind the line; the probe is how the numbers were counted, which D1 rehearses. Lead with the quote's terms: monthly, retention numbers, the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The only written artifact in the material is the checklist, and the quote does not show how it read or who it was for. Answer slot: the JD asks for clear writing, so expect a request for an example. If you wrote other material that others relied on, say what; if the checklist is your main example, say so plainly |

## Reading the interviewer

Public professional footprint only: one talk page returned by search, read as a snippet, not fetched.

| # | Item | Provenance | Source or derivation |
|---|---|---|---|
| I1 | Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | [grounded] | Search result for his GDC 2026 talk page, snippet only |
| I2 | Gave the GDC 2026 talk "Patch Notes Are a Promise"; the result gives his argument as: a live team is judged by how often its patch notes describe what actually shipped | [grounded] | Same result, snippet only |
| I3 | Implication: how closely an announcement matches what shipped is a theme he has chosen to speak on, so expect it to colour how he hears answers about updates and player messages; A3 and B2 rehearse it | [inferred] | Derived from I2 and the published value Ship the Patch Not the Promise; one talk is one data point |
| I4 | Implication: a QA background means the release-checklist line can be probed from the inside; A2 and B3 rehearse it | [inferred] | Derived from I1 and F4 |
| I5 | Mirror opportunity, shared vocabulary: his talk title and the company's value both set a promise against what shipped. Pair it with F4's quote, "Wrote the release checklist our QA team still uses.", as a plain statement of what you wrote, not as a claim to share his view | [inferred] | Derived from I2, the published value and F4 |
| I6 | No shared career jump is offered: his path runs from QA lead to Head of Live Operations, and no fit-snapshot row's evidence carries your side of a comparable jump | [inferred] | Absence check against F1 to F8 |

## Persona table

Weights follow three passes: relationship prior, interviewer signals, then the loop. The loop source (Sources row 2) documents a live-incident tabletop followed by a values conversation, so both are weighted up whatever the prior says.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop: a simulated outage during a live event | High. The loop source documents the tabletop for this session, and the hiring-manager prior also points here | Clarify, objective, who you pull in, decision, metrics, risks; think aloud; challenge one premise. Bank A |
| Values / Behavioral | The values conversation after the tabletop | High. The loop source documents it and the company publishes three named values | Map each value to a story only where your own sentence carries one; otherwise use the selection scaffold and its honest branch. Bank B |
| Skeptic | Quiet probing of the gaps in F1, F2, F3 and the two stated negatives | Medium-high. The hiring-manager prior includes it and the fit snapshot has thin rows exactly where the JD presses | Rehearse the in-app-purchase objection until it is boring; hold what the quotes carry, concede the rest plainly. Bank C |
| Data-Driven Prober | Follow-ups on the retention numbers and the post-event review | Medium. The JD names retention metrics and KPIs, and your message gives retention numbers as the one metric line | Say what you know and do not know about how each number was counted. Bank D |
| Pressure | Time-boxed or interrupting follow-ups inside the tabletop or on attribution | Low-medium. The tabletop is time-pressured by design, but nothing documents a stress style | Pause, restate, hold through two follow-ups, concede specifically. Bank E |
| Conversational | The opening journey question and casual JD talk | Low. A single 60-minute session leaves little room for chat, but openers are still scored | A 90-second arc built only from your quoted sentences. Bank F |
| Peer Evaluator | Not weighted | The loop source puts you with the hiring manager, not a peer | None needed |

## Question banks

### Bank A: Case / Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Mid-event, players report they cannot claim rewards and the community team says it is spreading. What do you do first?" | CASE | [generic] | Think aloud in order. Clarify first: what is broken, since when, how many players, whether the event is still running. State the objective in one line: stop the harm to players, then protect their trust. Say who you pull in and for what: engineering to diagnose, community to talk to players, design for the event rules, QA to verify a fix. Say what you would decide and what you would take to the Head of Live Operations. Close with the metrics you would watch and the risk you accept. Challenge one premise aloud, such as whether the event should keep running. No claim about your past is made | The loop source documents a live-incident tabletop on a simulated outage during a live event; CASE because it scores structure under time, generic because the scenario's details are the interviewer's to set |
| A2 | "Engineering has a fix for the reward bug. QA has not finished the release checklist and players are leaving. Do you ship?" | CASE | [inferred] "Wrote the release checklist our QA team still uses." | Decide aloud, then defend it: what the unfinished items protect, whether any can run in a reduced form and who has the authority to waive them, what players are told either way, and the condition under which you would reverse. The one claim you may attach to yourself is the quote at its own scope: you wrote the release checklist your QA team still uses; stop there. Answer slot: the JD says you manage the checklist with QA, so expect a probe on whether you have faced this call. If you have, say what you decided, who decided and what happened; if you have not, or it was not yours to decide, say so plainly and answer as the plan you would follow | F4 is the evidence for the checklist requirement. The question joins it to the published values Players Before Plans and Leave the Build Greener, a derivation, hence inferred; CASE because it scores a decision under conflict |
| A3 | "The event is stable again. What is the first message players should see, and what stays out of it?" | CASE | [inferred] | Order it as players need it: what happened, what is fixed or still being worked on, what players should do, when the next update comes. Leave out anything not built or confirmed; the published value Ship the Patch Not the Promise is the test: announce what is built, not what is hoped. Say the actual sentences aloud in plain words. No claim about your past is made | F8 is the JD's written-communication line, and this tests it live. The link to the value and to the talk theme in I2 is a derivation, hence inferred |
| A4 | "Both titles want the same weekend for their biggest event, and art and engineering can support only one. How do you decide?" | JD | [generic] | Clarify first: how far the two audiences overlap, what each event is for, what is already promised to players, what each team can deliver by then. State the objective, name the options, choose one and say the condition that would change your mind. The published value Players Before Plans, that the players win when the calendar and the players disagree, is a lens you may name; say which players you mean. No claim about your past is made | F1 is the JD's two-title calendar and its evidence sits at one title, so the requirement arrives as a case; JD content, CASE delivery |
| A5 | "We are moving to a season-pass model with a shared events calendar from February. What would you want to know before planning a calendar for it?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Use only what the announcement says, as you read it: from February 2027 Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar, and per-title event teams give way to a single live-ops group. You saw it only in summary, so say "as I read the announcement". Ask what you would need: who owns the shared calendar once per-title event teams are replaced, what a season fixes in advance versus what stays open, what commitments to players the pass creates. Your own experience enters only as the quote at its scope. Do not critique the announcement | Sources row 3 supplied the announcement; CO because it tests current strategy. F1 supplies the only calendar sentence you have, and its scope is one title |

### Bank B: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed, and which one won." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Value: Players Before Plans, "when the calendar and the players disagree, the players win". Selection scaffold: pick a moment when a planned drop and what players needed pulled apart; it needs a named stake, the decision that was yours, and what it meant for players. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the quote at its scope, or how you would handle it. Do not supply an ending | The first published value, from the fetched values page. The prompt is open and its theme comes from the value; F6's quote is the only calendar sentence available, so it is the nearest |
| B2 | "Tell me about a time you decided what to announce and what to hold back." | VAL | [grounded] | Value: Ship the Patch Not the Promise, "we announce what is built, not what is hoped". Selection scaffold: an occasion where a date or feature was promised, or could have been; what you chose to say, who pushed back, what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or what you would say in that spot as a plan | The second published value. No quote in your material speaks to announcements, so this is the scaffold case and the guidance claims nothing about your past |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Value: Leave the Build Greener, every release leaves "the codebase and the checklist better than it found them". Story-map: the checklist you wrote and the QA team still uses, told in your own words. Answer slot: the value speaks of the checklist improving with releases, so expect a probe on what changed in it. If it changed after a release, say what and why; if it did not, or the changes were not yours to make, say so plainly and stay with the checklist you wrote | The third published value, and F4 is the one row whose evidence carries a story for it. VAL because it scores behaviour against a named value |
| B4 | "Tell me about a time you had to give someone senior news they did not want." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | The setting is the quote's: monthly, retention numbers, the studio head. Answer slot: if a month's numbers were unwelcome, say what you told the studio head and what happened next, in your own words; if none were, or you only reported what others had found, say so plainly and use the nearest honest example. Do not supply an ending | The theme comes from the Values persona's stem, not from a Saltmarsh source, and it matches the promise-versus-shipped theme in I2. F7 supplies the quote; VAL because it scores candour |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have not worked on a game with in-app purchases, and two of our titles move to a season-pass model in February 2027. How do you get up to speed on the numbers that come with that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Presented the monthly retention numbers to the studio head." | **Highest-ROI prep in this pack.** Hold-then-concede. Concede first, in the stated words: "I haven't worked on a game with in-app purchases." Then hold only what the quote carries: you presented the monthly retention numbers to the studio head. Then a ramp plan, said as a plan and never as a past: what you would ask for in the first week and how you would check you read it correctly. Hold through two follow-ups by returning to the quotes, never by adding to them. Never name a monetization metric as one you have tracked | F3 and F7 are where this objection presses hardest, and the premise has a source: the negative you stated. The season-pass fact comes from Sources row 3. JD because it scores owning the KPIs |
| C2 | "Which of those numbers would you be least able to speak to?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The second follow-up level of C1. Answer slot: name the one measure whose counting you could not explain; if you could explain every number you presented, say so plainly and say how you would test that against event numbers. If you cannot say which, say that and say you would start by asking how each is defined. Do not guess a definition | Same objection, one level deeper: it asks you to name your weakest assumption before the interviewer does. F7 is the row it presses on |
| C3 | "The role coordinates design, art, engineering and community on every update, and you have never led a team. What makes those teams work to your calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Concede in the stated words: "I haven't led a team." Do not contest it. Hold: the JD's verb is coordinate, and the calendar quote is what you bring. Answer slot: the JD lists four disciplines, so expect a probe on who you worked with on drops. If you worked with design, art, engineering or community, say which and how you kept them on the calendar; if you did not, or the calendar was only your own list, say so plainly and stay with the quote | F2 is the thin row behind this, and the premise has the stated negative as its source. JD because it scores the coordination line |
| C4 | "Walk me through your four years as an associate producer. What was your scope, and which parts were yours?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Story-map on the three own-work sentences, each at the scope it states: the weekly content-drop calendar for your main title, the checklist the QA team still uses, the monthly numbers to the studio head. Answer slot: the JD asks for producing live-service games, so expect a probe on whether the title ran as a live service. If it did, say how, in your own words; if it did not, or the drops were something else, say so plainly | F5 is the years requirement. EXP because it tests which parts were yours rather than the requirement itself |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented to the studio head. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Four moves, each in your own words: how the number was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how something was counted, say so plainly; that is a credibility gain. Offer a method only if it is the one used. If you did any of the analysis yourself, offer to walk through it end to end | F7 is your one metric line, and metric lines are where probers start. EXP because it tests attribution and counting |
| D2 | "Retention for the week after an event ended is down against the previous event. What do you look at first?" | CASE | [generic] | Clarify first: which retention measure and cohort, and compared with which event on length, rewards and timing. Then check whether the data itself changed, including any release in that window. Then segments of players. Then what you would report and what you would not claim. State a hypothesis early and say what would disprove it. No claim about your past is made | F7 requires comfort with retention metrics; CASE because it is a live diagnosis. Generic because the metric and the event are the interviewer's to set |
| D3 | "When an event closes, what goes in the post-event review, and what would you hold yourself to in the KPIs it reports?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Offer a structure as a proposal, not as history: what the event set out to do, what shipped against what was planned, the numbers with their definitions beside them, what you would change next time. Answer slot: the JD says you own this review, so expect a probe on a review you have run. If you ran or contributed to one after a drop, say what it covered and which part was yours; if there was none, say so plainly and stay with the quote at its scope | F3 is the JD's post-event review line, and its evidence is adjacent only. The Leave the Build Greener value ties reviews to improvement, but that link is not needed to answer |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That calendar you say you ran. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause and restate the question. Then give the quote at its scope and no more. Hold through two follow-ups by returning to it, never by adding to it. Answer slot: if some decisions on the calendar were others', say which; if all of it was yours to set, say so plainly; if you are not sure where your part ended, say that | The standard attribution probe aimed at F1 and F6, the claims a pressure style tests first. EXP because it scores what was actually yours |
| E2 | "Sixty seconds: why you, rather than someone who already runs live events?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Three beats, each one sentence at its own scope: the weekly calendar for your main title, the checklist the QA team still uses, the monthly numbers to the studio head. Stop at the beats. If pressed on gaps, concede in the stated words: "I haven't led a team" and "I haven't worked on a game with in-app purchases", then stop | F1, F3 and F4 supply the three beats; the concession draws on the stated negatives. JD because it scores fit against the posting under time pressure |

### Bank F: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | A 90-second arc in three beats, each one of the sentences: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for your main title for the last two years; the release checklist the QA team still uses. Then one sentence on why Saltmarsh, in your own words, naming something you have actually read on its site | The opener is scored even when it feels casual. F5 and F6 supply the beats |
| F2 | "What does a normal week of that content-drop calendar look like?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The beats are the quote's: weekly, content drops, your main title. Answer slot: the JD lists design, art, engineering and community, so expect a probe on who was part of a drop. If any were, say which and what you needed from each; if none were, say so plainly | Casual register on a hot JD topic. F2 and F6 are the rows it covers |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 live-events calendar for two titles | A4, C4 for scope, E1 |
| F2 coordinate four disciplines | A1, C3, F2 |
| F3 post-event review and KPIs | C1, D3 |
| F4 release checklist with QA | A2, B3 |
| F5 3+ years producing live-service games or apps | C4, F1 |
| F6 content calendar | E1, F2 |
| F7 player-retention metrics | C1, C2, D1, D2 |
| F8 clear written communication | A3 — none other; the only live test of this line in the banks, and the upgrade menu names the writing sample that would add evidence |

## Values cheat sheet

A values conversation is documented for this session (Sources row 2). Values are named exactly as Saltmarsh's page gives them.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When a plan and the players pull apart, the players take priority | No quote carries a story. Selection scaffold (B1): pick a moment a planned drop and player needs pulled apart, with a named stake and your own decision; if none comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it |
| Ship the Patch Not the Promise | Announce what exists, not what is hoped for | No quote carries a story. Selection scaffold (B2): an occasion you chose what to announce and what to hold back; if none comes to mind, say so plainly, then give the nearest thing or a plan |
| Leave the Build Greener | Each release should leave the code and the checklist better than before | F4: "Wrote the release checklist our QA team still uses." — your message. Answer slot in B3 covers what changed in it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live operations from QA. Which QA habit do you most want your producers to carry?" | Ties to his own path (I1) and invites him to say what he scores for, in his terms; it also gives you a hook to mention the checklist (F4) briefly |
| R2 | "Project Larkspur retires per-title event teams in favour of a single live-ops group. Where does this role sit in that, and are the two titles in the JD the two the announcement names?" | The JD names two titles without naming them, and the announcement names two; the answer tells you what you would actually be running, and it shows you read the announcement |
| R3 | "What does a post-event review look like today, and what is the most recent decision it changed?" | The JD gives you ownership of this review (F3); you learn the standard you will be held to |
| R4 | "Which KPIs does the review report today, and which change with the season pass?" | Honest about the in-app-purchase gap (C1) and turns it into a ramp question |
| R5 | "When an event goes wrong mid-run, where does the producer's call end and yours begin?" | Follows the tabletop (A1, A2) and shows you think about authority before you need it |
| R6 | "What would a strong first ninety days look like for this role?" | A standard question that anchors the conversation in what you would deliver; it works in any hiring-manager round |

## Prohibited claims

What this pack will not coach, and why. Each entry lists the claim, not a finding that you lack the thing.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." — your message | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or tracked monetization metrics | Negative you stated, same sentence | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot; then a ramp plan said as a plan |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. Your material says a weekly content-drop calendar for your main title. A4's guidance and C4's slot stay inside that scope |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. Your material says you presented monthly retention numbers, not that you owned a review. D3's slot asks only what a review covered |
| Managed the release checklist release by release | Inflated form of F4 | F4's quote at its own scope. Your material says you wrote it and the QA team still uses it |
| Four years producing a live-service game | Inflated form of F5 | F5's quote at its own scope: four years as an associate producer at a puzzle-game studio. C4's slot asks only whether the title ran as a live service |

## Sources

Provided documents: the job description text and your message giving your background. No dossier was present.

Searches sent:

1. "Saltmarsh Games values" returned saltmarshgames.com/values
2. "Saltmarsh Games interview process live operations producer" returned saltmarshgames.com/careers/interviewing
3. "Saltmarsh Games mobile studio news strategy" returned saltmarshgames.com/news/project-larkspur
4. "Tobias Wrenfield Saltmarsh Games" returned talks.gdconf.example/2026/patch-notes-are-a-promise

Fetches sent: saltmarshgames.com/values (read in full), saltmarshgames.com/careers/interviewing (read in full). The news page and the talk page were seen as search snippets only.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet: three published values by name; themes for B1 to B3 |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: a recruiter call, then a single 60-minute session with the hiring manager, a live-incident tabletop on a simulated outage then a values conversation, no take-home. This drove persona weights, bank A and B depth, the values sheet, and the absence of a graded-deliverable section |
| 3. `Saltmarsh Games strategy` / recent news | yes | A5, C1 and R2; snippet only, so no claim goes beyond the snippet's words |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read I1 to I6, R1; snippet only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Confirmation that Tobias is the hiring manager for this session, and how the hour splits between the tabletop and the values conversation → persona weights for banks A and B, and which bank leads
- A copy of the release checklist you wrote, or a slide from the monthly retention presentation → F4, F3 and F7 move from medium toward high, and D1 and D3 gain inspectable material
- A writing sample, such as release notes, a player-facing message or a post-event summary you wrote → F8 moves from low, and A3 can be coached from your own words
- Your own answers to the slots on F1, F2, F3 and F5, stated in your message → each becomes quoted evidence, and the rows and bank cells that draw on them are rebuilt
- The names of the two titles in the JD → A4 and A5 become specific, and R2 may fall away
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, if you want it → a grounding brief on Project Larkspur read in full, more of Tobias's talk, and loop reports for this role
- A tuesday-dossier.md from an earlier evidence pass → verified evidence and an agreed objection would replace the inferred ones here
