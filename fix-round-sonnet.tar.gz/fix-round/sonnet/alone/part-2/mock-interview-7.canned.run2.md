I'll read the reference files the skill requires before building the pack.
Research is done, so I'm writing the pack to a file now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-canned-ca5bb836/saltmarsh-games_live-operations-producer_interview_pack.md`.

I assumed Tobias is the hiring manager. Saltmarsh's careers page describes the interview as one session with the hiring manager: a live-incident tabletop on a simulated outage, then a values conversation, with no take-home. So the pack is built around that format:

- **Order of the hour:** it opens with tabletop scenarios and written player messages, then moves to the three published values.
- **Highest-ROI prep:** C1, the in-app-purchase gap you named. Concede it in plain words, then give a plan for what you'd learn first, without stretching retention into revenue.
- **Interviewer and strategy facts:** these come from search-result snippets, not fetched pages. That covers Tobias's GDC talk and earlier QA role, and the Project Larkspur shared-calendar announcement. Confirm them before you mention them aloud.

Say the word and I'll play the Skeptic on C1 for a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to in this role, and did the recruiter say anything about what the Outage Hour will cover? Either answer changes the persona weights and the tabletop scenarios.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Friday, 60 minutes. Relationship assumed: hiring manager, because the careers page describes the single interview as one with the hiring manager (unconfirmed, see Sources and the upgrade menu).

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. The highest-ROI prep in this pack is C1, the in-app-purchase objection, because it is the gap you named yourself and the one most likely to be put to you directly.

Type key:

- VAL: whether past behavior shows the company's published values
- EXP: whether your CV claims survive scrutiny, and what was actually you
- JD: the stated responsibilities and requirements
- CO: company and strategy knowledge
- CASE: a live problem from the role, scored on structure

The documented loop is one 60-minute session: a live-incident tabletop on a simulated outage, then a values conversation. Rehearse the A bank first, then B, then C.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title; the JD says live events for two titles, and the words stay at the quote's scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's wording makes a probe on the scale of your calendar likely. Say, in your own words, what the calendar covered and how a week ran; if it covered one title only, or the drops were not events, say so plainly and use the quote's own word, content drops |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | Your quote names the calendar, not the teams, so nothing in it shows which disciplines you worked with; the JD's verb is coordinate, not manage. Answer slot: the JD names four disciplines, so expect a probe on each. If you worked with any of them on the weekly drops, say which and what you did with each, in your own words; if some were not part of your drops, or the calendar did not involve coordinating them, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presenting the numbers, nothing about producing them, and the JD's word is own; the words stay at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on where the numbers came from and which part of the work behind them was yours. Say so in your own words; if you presented figures someone else produced, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in terms, but nothing inspected sits behind it, so expect a probe on what the checklist contains. Lead with the quote's own terms: you wrote it, and QA still uses it. The JD says manage and the quote says wrote, so the word manage stays out of your answer |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your quote gives the years and the title, and the JD's years line is a requirement to be graded, not a gate. Answer slot: expect a probe on what the four years consisted of. Describe the title and what the weekly content drops involved, in your own words; if part of the four years was on other work, say so plainly and stay with the four years and the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it. Lead with the sentence as written; a named record beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement, and your material gives no figure and no definition of retention, so expect a probe on how the numbers were counted (D1). Lead with the quote's terms, and say plainly if you do not know how a figure was counted |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote is a written document in daily use by another team, and the words stay there: "I wrote the release checklist our QA team still uses." Your material holds no other writing sample, and clear is a judgment the interviewer makes, so let the artifact speak and do not describe yourself as a clear writer |
| F9 | Role-family pattern, no source: understanding how a title earns where it sells in-app purchases | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [generic] | capability | A gap wording cannot close, and you stated it: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The same sentence says you have never led a team; the JD's verb in F2 is coordinate, so that sentence is not a gap against a stated requirement, but expect it to come up (C2). Nothing added to make either gap feel smaller |

## Prohibited claims (built before the banks)

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative you stated, F9 | The plain acknowledgment F9 gives: "I've never led a team." No slot |
| Worked on a game with in-app purchases, or owned monetization | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." Then a plan for what you would learn first, said as a plan |
| Planned and ran live events across two titles | Inflated form of F1 | F1's quote at its own scope; the pack's observation is that your material says a content-drop calendar for your main title. C4's guidance stays with the quote and then gives a plan |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope; the pack's observation is that your material says presenting the numbers. D2's slot asks only where the numbers came from |
| Managed releases with QA | Inflated form of F4 | F4's quote: "Wrote the release checklist our QA team still uses." The pack's observation is that your material says wrote |
| Four years of live-service production | Inflated form of F5 | F5's quote at its own scope; the pack's observation is that your material gives the years and the title. F1's slot in the banks asks only what the four years consisted of |

## Reading the interviewer

Public professional footprint only. The facts about the talk and the earlier QA role come from one search-result snippet, not a fetched page; confirm them before you refer to either aloud.

| Observation | Basis | Provenance | What it means for you |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games | Your message | [grounded] | The careers page describes the interview as one with the hiring manager; confirm he is that person (upgrade menu) |
| GDC 2026 talk "Patch Notes Are a Promise"; his argument is that a live team is judged by how often its patch notes describe what actually shipped | Search result: talks.gdconf.example, snippet only | [grounded] | The theme sits beside the second published value, "we announce what is built, not what is hoped". Expect precision about what was built versus hoped, and attribution answers you can back under a second question |
| Previously a QA lead at a console studio | Same search result | [grounded] | The release checklist is likely to be probed by someone who knows release checklists from the QA side (A5, B3, E2). Mirror opportunity, shared vocabulary rather than a shared career jump: F4's "Wrote the release checklist our QA team still uses" |
| His talk is about written patch notes | Same search result | [grounded] | Mirror opportunity for F8: "Wrote the release checklist our QA team still uses" is the written artifact to point at; A6 rehearses a live written message |

## Persona table

Loop source: the Saltmarsh careers page (Interviewing at Saltmarsh), read in full, which documents a single 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home. It establishes the loop, so no archetype fallback is used.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop: a simulated outage during a live event | High. The careers page documents the tabletop, and it comes first | Clarify, objective, segmentation, actions, metrics, risks; think aloud; challenge one premise respectfully (A1 to A6) |
| Values / Behavioral | The values conversation after the tabletop | High. The careers page documents it, and the three published values give the prompts | Map a story to each value where your quoted sentences carry one, and use the selection scaffold with its honest branch where none does (B1 to B5, cheat sheet below) |
| Skeptic | Probing the gaps you named | Medium-high. You stated two gaps, and a hiring manager is derisking them | Rehearse C1 until it is boring: concede in the exact words, hold the quoted facts, add nothing (C1 to C4) |
| Data-Driven Prober | Retention numbers and attribution | Medium. Your material has a retention line with no figure behind it, and the interviewer's public theme is accuracy about what shipped | Know how the numbers were counted or say plainly you do not (D1 to D3) |
| Pressure | Time-boxed challenges inside the tabletop or on motive | Low-medium. The documented format is a simulation, not a stress interview; the pressure comes from the scenario | Pause, restate, anchor in what you said, hold through two follow-ups (E1, E2) |
| Conversational | The opening and closing minutes | Low. A single session leaves little room, but the opener is still scored | A 90-second arc built only from your quoted sentences (F1, F2) |
| Peer Evaluator | Not built | Low. The documented interviewer is a hiring manager, not a peer; if the relationship turns out to be a peer, say so and the banks get reweighted | None |

## Question banks

### A. Case / Strategist (highest weight; the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a live event. Players report the event reward won't claim, and the support queue is filling. Engineering says a fix is two hours out. What do you do in the first fifteen minutes?" | CASE | [inferred] | Think aloud in this order: what you need to know first (what is failing, for whom, since when, whether the event or the build is the cause); the objective (protect players, stop the problem growing); how you split players (all, one platform, one region, one cohort); the first moves (who you pull in from engineering, QA and community, what players hear now, when the next update comes); the numbers you would watch; and one premise you challenge aloud, such as how firm the two-hour figure is. The values page says "we announce what is built, not what is hoped", so tell players what is known and when you will update, and promise no fix time before it is built. The question needs no claim about your past, so the guidance makes none | The careers page documents a tabletop on a simulated outage during a live event; the actual scenario is not public, so this one is a stand-in derived from the format. CASE because it scores structure and the company's own vocabulary |
| A2 | "Engineering comes back: the fix needs a client build and store review, not a server change, and the event ends in 36 hours. Extend the event, compensate players, or let it end: how do you decide, and who is in the room?" | CASE | [inferred] | Name the decision and its owner before the options. For each option say what it costs players, what it costs the event's goal and who else it touches; say what you need from engineering and QA to choose; say what you would tell players and what you would record for the review afterwards. The first published value, "when the calendar and the players disagree, the players win", is a lens for ranking the options; say aloud if another cost pushes against it. No claim about your past | A tabletop escalates, so this extends A1. It scores whether you decide with the right people and keep players ahead of the calendar; CASE |
| A3 | "The event is over. You have an hour to brief the studio head on what happened. What's in the review, and which numbers lead?" | JD | [generic] | Clarify first: what was the event for? Then a timeline, what players saw against what they were told, and the one or two numbers that answer the event's goal, each with the weakest assumption behind it said aloud (cohort size, other changes in the same window). Finish with what you would change in the calendar or the checklist because of it. No claim about your past | F3's requirement, delivered as a live problem. Generic because the pack does not know this studio's KPIs |
| A4 | "From February 2027, two of our titles share one events calendar. What goes wrong when two titles share a calendar, and what do you want in place before the first shared event?" | CO | [inferred] | Do not recite the announcement; show you have thought about it. Clarify what is shared (calendar, team, QA, comms) and what is not (players, economies, release dates); name two or three failure modes (events colliding, one title's issue crowding the other's comms, shared QA capacity) and what you would want first (one owner for the calendar, a visible conflict rule, a shared release checklist); challenge one premise by asking how priorities between titles get decided. No claim about your past | The Project Larkspur search result (September 2026) says two titles move to one shared calendar from February 2027; that page was not fetched, so this is derived from a snippet. The JD says "two of our mobile titles" without naming them, so do not assume they are the same two. CO because it tests current strategy, with CASE delivery |
| A5 | "A build is due tonight for the next event. At four o'clock QA reports an open issue. How do you run that call?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Run the call as a decision: what the issue is and who it touches, the options (ship, delay, ship with the issue known), who decides, what players are told. For the checklist, say the true thing: "I wrote the release checklist our QA team still uses." Answer slot: the JD names the release checklist and the third value says every release leaves "the checklist better than it found them", so expect a probe on what yours covered and whether it changed. Say, in your own words, what it covered and anything you changed after a release; if it did not change, or you cannot recall its contents, say so plainly and stay with writing it and QA still using it | F4 is the evidence for the release-checklist requirement and the likeliest place a former QA lead probes. JD because it scores that requirement, CASE in its delivery |
| A6 | "Write me the two-sentence player message for that outage. Say it out loud." | JD | [grounded] | Say what is wrong, what players should do now, what is known and not yet known, and when the next update comes, in two sentences and short words. Announce only what is built, per the values page: "we announce what is built, not what is hoped". No fix time you cannot stand behind. No claim about your past | The JD asks for clear written communication (F8), and a live draft is the only way an interviewer can score it in a session with no take-home. JD primary |

### B. Values / Behavioral (highest weight; the second half of the hour)

Values by name, from the company's values page: Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players wanted different things." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a time a date or a drop and what players needed pulled apart. It needs a named stake, what you moved or gave up, who you had to persuade and what players got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years", or say how you would handle it | Players Before Plans, the first value. An open prompt, since no quoted sentence carries a calendar-versus-players story; F1 is the nearest evidence and not the story |
| B2 | "Tell me about a time you told someone something wasn't ready when they wanted it announced." | VAL | [grounded] | Selection scaffold: pick a time you held an announcement back or corrected one. It needs the stake, who wanted it, what you said and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | Ship the Patch Not the Promise, the second value. An open prompt whose theme comes from the value's wording; no quoted sentence carries it, so it is a scaffold |
| B3 | "Tell me about something you wrote or changed that made the next release easier." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story map from F4, with the beats the sentence states: you wrote the checklist, and the QA team still uses it. Tell those in your own words. Answer slot: the value says every release leaves "the checklist better than it found them", so expect a probe on whether yours changed over time. If you changed it after any release, say what and why, in your own words; if it did not change, or was not yours to change, say so plainly and stay with writing it and QA still using it. Describe the checklist and let the interviewer draw the inference | Leave the Build Greener, the third value, and F4 is the only quoted sentence that carries it. VAL, with EXP secondary because it is a story about your own work |
| B4 | "Tell me about a time the numbers told you something the team didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Story map from F7, with the beats the sentence states: monthly retention numbers, and the studio head as the audience. Answer slot: expect a probe on whether any month's numbers were unwelcome. If one was, say what it was and how it landed, in your own words; if none were, or the numbers were not yours to deliver first-hand, say so plainly and say how you would frame a bad number | Delivering a hard truth is the standard values stem, and it sits beside the second value's honesty about what is built. F7 carries the only relevant sentence, and it does not show an unwelcome result |
| B5 | "Which of our three values would be hardest for you to live by, and why?" | VAL | [grounded] | Pick the one where you feel a real pull the other way, name the tension in your own words, and say what you would do in practice. Say the value by its official name. No claim about your past is needed, so the guidance makes none | Rewards candor over slogan familiarity; tests that you can name all three values. VAL |

### C. Skeptic (medium-high)

C1 is the highest-ROI prep in the pack: the most likely objection, given the most follow-up levels.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases. What would you want to understand about how a title earns before you scheduled its next event?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | Concede first, in these words: "I haven't worked on a game with in-app purchases." Then the plan, said as a plan: the things you would ask before scheduling, such as how the title earns today, which numbers the studio watches for an event, who owns them and what a good event week looks like to them. Follow-up one, "So how would you judge an event commercially?": do not claim a method you have not used; return to what is yours, "I ran the weekly content-drop calendar for our main title for the last two years" and "I presented the monthly retention numbers to the studio head". Follow-up two, "Is that enough?": hold at the same two facts and name the limit before they do, that your material shows the calendar and the numbers you presented, not revenue. Follow-up three, a harder push on time: give a first-weeks plan, not a past. Never stretch retention into revenue and never claim adjacent monetization experience | You named this gap yourself, F9, and the loop's first-hand interview makes a direct question likely. JD because it scores whether you can do the listed job with a stated gap, and the deepest rehearsal because this is where the material is thinnest |
| C2 | "Coordinating design, art, engineering and community on each update is coordination, not management. What's your experience of getting those teams to move?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say it first: "I've never led a team." Answer slot: the JD names four disciplines, so expect a probe on each. If you worked with any of them on the weekly drops, say which and what you asked of them, in your own words; if some were not part of your drops, or the calendar did not involve coordinating them, say so plainly and stay with "I ran the weekly content-drop calendar for our main title for the last two years". Hold through two follow-ups by returning to the calendar, never by adding to it | F2 is the requirement and F9 the stated negative. JD because it scores the coordination requirement; Skeptic because it comes at the gap |
| C3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Never led a team, and never worked on a game with in-app purchases" | Calibrated candor, in your own words: the pack's observation is that your material shows one main title's weekly calendar and numbers you presented, and says in-app purchases and leading a team are not there. Choose the answer that is honestly true for you. If it is in-app purchases, "I haven't worked on a game with in-app purchases" is sourced; follow it with what you would do in the first weeks as a plan. Do not offer a strength dressed as a weakness | The persona stem for the Skeptic, and a motivation-and-self-assessment check. JD because it scores the whole requirement list |
| C4 | "The role runs the calendar for two titles. You've run the calendar for your studio's main title. How would you run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say what you ran, at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years". Then a plan, said as a plan: what two calendars share (QA, comms, release steps), what stays separate (players, cadence), how a clash gets resolved and who decides. Do not say you have done it; claim nothing beyond the quote | F1 is the evidence and the JD's two-title line is the raising source. JD because it scores the calendar requirement |

### D. Data-Driven Prober (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer in your own words on four points: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how a figure was counted, say so plainly; that is an honest answer and a stronger one than a method you cannot repeat. Name the weakest assumption before they do. The pack supplies no method, because your material states none | F7 holds the only retention line, with no figure and no definition behind it, so a prober goes to how it was counted. EXP because it tests what you can stand behind |
| D2 | "You presented the numbers. Where did they come from, and which part of the work behind them was yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start from the quote: "I presented the monthly retention numbers to the studio head." Answer slot: say, in your own words, where the numbers came from and which part of the work behind them was yours; if someone else produced them, say so plainly and stay with presenting them. Hold through two follow-ups by returning to the presenting | F3 is thin where the JD says own. EXP because attribution is what is scored |
| D3 | "Which retention measures would you put in a post-event report, and what would make you distrust one?" | JD | [generic] | Structure it: state the question the event was meant to answer, name the one or two numbers that answer it, then name what could make them misleading (a small cohort, other changes in the same window) and what you would check first. No claim about your past | Covers the retention-metrics requirement (F7) as a forward-looking problem, so it needs no claim about your past. Generic because the pack does not know this studio's measures |

### E. Pressure (low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, rather than someone who has already run live events on a monetized title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team, and never worked on a game with in-app purchases" | Pause, restate the question, then hold on what is yours: "I ran the weekly content-drop calendar for our main title for the last two years" and "I wrote the release checklist our QA team still uses". Concede specifically: "I haven't worked on a game with in-app purchases." Do not say you are the better candidate and do not tell them what your work proves; describe it and let them draw the inference. Hold through two follow-ups, and do not fold on the facts to restore harmony | The persona stem for the Pressure interviewer, aimed at F9. JD because it scores the 3+ years requirement (F5) against the stated gap |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold the sentence as written: "I wrote the release checklist our QA team still uses." Answer slot: if QA or anyone else shaped it, say so in your own words, because sharing credit is the honest version; if it was yours alone, say so plainly. Hold through two follow-ups by returning to the sentence, never by adding to it | F4 is the line most likely to be probed by an interviewer with a QA background, and the attribution question is the persona's standard stem. EXP |

### F. Conversational (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey so far." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc with four beats, each at its own scope: the four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the main title for the last two years, the release checklist QA still uses, the monthly retention numbers you presented to the studio head. Answer slot: the JD's years line makes a probe on what the four years consisted of likely; if part of them was on other work, say so plainly and stay with the calendar. Why live operations and why Saltmarsh is your own reason, in your own words; the pack supplies none | The opener is scored. F5 is the row it covers, and the arc is built only from your quoted sentences. EXP |
| F2 | "What are you actually playing these days, and what do you notice about how it runs its events?" | CO | [generic] | Name something you really play and one thing you noticed, in your own words. Nothing in the pack can answer this for you, so it supplies nothing, and an invented answer is the one that fails | The casual-register question about a hot JD topic is still scored; it tests genuine interest. CO because it is about the products and the live-ops craft |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | C4, C3, A4, F1 |
| "coordinate design, art, engineering and community teams on each update" | C2, A1, A2 |
| "own the post-event review and the KPIs it reports" | A3, D2, D3 |
| "manage the release checklist with QA" | A5, B3, E2 |
| "3+ years producing live-service games or apps" | E1, F1 |
| "experience running a content calendar" | C4, B1, F1 |
| "comfortable with player-retention metrics" | D1, D3, B4 |
| "clear written communication" | A6 |
| Stated gap, no JD line: in-app purchases | C1, C3, E1 |

## Values cheat sheet

A values-style round is detected because the careers page documents a values conversation as part of the interview.

| Value (official name) | Working meaning | Your mapped story | Where it is rehearsed |
|---|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold: pick a time a date or drop and what players needed pulled apart, with a named stake, what you moved, who you persuaded and what players got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | B1, A2 |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold: pick a time you held an announcement back or corrected one, with the stake, who wanted it and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | B2, A1, A6 |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses" | B3, A5 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You came to live operations from QA. What did that teach you about running a release night that you'd want a producer to know on day one?" | Tied to his path, and it turns the checklist line (F4) into a peer conversation. Use it only after you have confirmed the QA background and the talk, because both come from one snippet | [grounded] |
| R2 | "With one shared events calendar from February 2027, how would you describe this role's scope: the two titles, or the shared calendar?" | Shows you read the recent announcement, and surfaces how the JD's "two of our mobile titles" fits it. Confirm the announcement's wording before you use it | [grounded] |
| R3 | "What does a post-event review look like when it's working: who reads it, and what has changed because of one?" | Goes to the JD's post-event review requirement and to the third value's "checklist better than it found them" | [grounded] |
| R4 | "Where does revenue sit in this role: what do producers see about how an event earns, and who owns that read?" | Turns the in-app-purchase gap into diligence rather than apology, and answers something you need to know before accepting | [generic] |
| R5 | "Which of the three values do people find hardest to live by in practice?" | Lands on the published values and invites candor, which a values conversation rewards | [grounded] |
| R6 | "What would make you say, a year in, that this hire worked?" | Gets the interviewer's own success measure for the role, so you can hear what the first year is for | [generic] |

## Sources

Provided documents: the JD text and your background, both pasted in your message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | The three value names and wordings, from the fetched values page: the B bank, the values cheat sheet, and the value references in A1, A2, A5 and A6 |
| 2. Saltmarsh Games interview process, live operations producer | yes | The documented loop from the fetched careers page: persona weights, the A and B banks, and the values-style round |
| 3. Saltmarsh Games strategy and recent news | yes | One search-result snippet on Project Larkspur: A4 and R2. The page itself was not fetched because both fetches went to targets 1 and 2 |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | One search-result snippet: the interviewer read and R1. The page was not fetched, and its host is a third-party domain, so confirm the talk and the QA background before referring to them |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries, with what came back:

- "Saltmarsh Games values" returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process Live Operations Producer" returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games mobile studio news strategy" returned https://saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise

Fetches: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both returned their text.

No dossier was present.

## Upgrade menu

- Confirmation that Tobias is the hiring manager, plus anything the recruiter said about the Outage Hour (scenario type, who is in the room) → persona weights are rechecked and the A bank's stand-in scenarios can be swapped for the real shape
- Your answers to the slots in F1, F2, F3 and F5 (what the calendar covered, which disciplines you worked with, where the retention numbers came from, what the four years consisted of) → those rows move from `discovery` and `transferability` toward `grounded` quotes, and C2, D2 and F1 become story maps
- A time you moved a date or held back an announcement for players → B1 and B2 become story maps instead of selection scaffolds
- Your release checklist, or a redacted copy of a write-up you did after a content drop → F4 and F8 can move from `medium` to `high`, since a checklist or review document is the inspectable artifact in this field
- Your CV text → more quotable sentences for the fit snapshot, and a check that the pack's quotes match what the CV says
- The fetched Project Larkspur announcement and the talk page, rather than snippets → A4, R1 and R2 rest on fetched pages, and the interviewer read can be confirmed
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on strategy, the interviewer's talks and writing, and loop reports from other candidates
- A tuesday-dossier.md from job-underwriter → a verified-evidence list, a named highest-ROI objection and prohibited-claims constraints that would sharpen C1 and the banks; the pack is complete without it
