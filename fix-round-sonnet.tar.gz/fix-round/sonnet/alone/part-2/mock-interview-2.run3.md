I'll read the reference files the skill requires before writing the pack.
I'll write the pack to the working directory now. All three company searches were refused, so the company-specific parts are generic and labeled that way.
Your prep pack is saved as `atlas-freight_operations-manager_interview_pack.md` in the working directory. I built it for a hiring-manager round, since you didn't say who you're meeting.

My three searches on Atlas Freight were refused, so nothing company-specific is in it. The case questions are generic, and there are no values or strategy sections. The pack rests on your JD and your background, with every claim about you tied to your own wording.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is interviewing you (your future manager, a peer or another site's manager, or HR), and has the recruiter said anything about the format or something to prepare? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** unknown. This pack assumes a hiring-manager round, because nothing said who you are meeting. If that is wrong, the persona weights and every bank reorder (see the upgrade menu).
**Version:** first pass.

## How to use this pack

- **Personas** say how a question arrives (skeptic, case-led, prober and so on). **Types** say what is being scored. Rehearse both: the same question lands differently in each register.
- **Type key:**
  - `JD`: a stated responsibility or qualification in the posting, including its gaps.
  - `EXP`: whether your own stated experience survives a follow-up, and what was actually you.
  - `CASE`: a live problem set in the role, scored on structure.
  - `CO`: company and strategy knowledge. None appears here, because company research did not run (see Sources).
  - `VAL`: published-values alignment. None appears here, for the same reason.
- Question IDs run by persona. The letter F is skipped because F1 to F7 are fit-snapshot rows.
- **Answer guidance is scaffolding, not a script.** Say it in your own words. Where a cell says "Answer slot", it is an instruction for the interview, not a question for this conversation. Answer whichever branch is true, and either branch is a good answer.
- Labels: `[grounded]` rests on something you wrote or the JD you pasted; `[inferred]` is this pack's derivation, named; `[generic]` is a pattern for the role family with no claim about you or Atlas.

## Prep triage (sized to the week you have)

| Order | Do | IDs |
|---|---|---|
| 1 | Say the scope concession aloud until it is boring: three supervisors against twelve, and what you will and will not claim | A1, A2, A3 |
| 2 | Know what you can and cannot say about the 40%: how it was counted and which part was yours | C1, C2, E2 |
| 3 | Settle the Power BI answer: the plain acknowledgment, then a plan stated as a plan | A4, B3 |
| 4 | One case a day, aloud, with the structure said before the content | B1, B2, B4 |
| 5 | The 90-second journey and the surge plan, told at the scope of your own sentences | D1, D2 |
| 6 | Pick three reverse questions and say them out loud once | Reverse questions |

Everything else is insurance.

## Fit snapshot

The quotes in the evidence column are your own words, and everything later in the pack draws on them and on nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a senior shift manager over 3 supervisors and a surge plan run for the site, in warehouse and distribution work; it does not say terminal operations or four sites. The words stay at that scope: "I'm currently a senior shift manager over 3 supervisors" and "I ran the site's peak-season surge plan two years running." Answer slot: the JD's "terminal" and "4 sites" make a probe on both likely. If any of your work was terminal operations, or reached beyond one site, say what and how, in your own words; if none did, say so plainly and stay with the shift you manage and the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says mis-pick rate, not on-time performance or cost-per-shipment, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: expect a probe on which measures you watch. Say which measures you watched alongside mis-pick rate and what happened to them; if mis-pick was the only one, or none of the others were yours to watch, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows three supervisors, not twelve, and the words stay at three: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's twelve makes a probe on span likely. If you have been responsible for supervisors beyond those three, say who and when, in your own words; if not, say so plainly and stay with the three |
| F4 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | The material says solid Excel and does not show what it was used for; the JD's "reporting" makes a probe likely. Answer slot: say what you use Excel for and who sees the output, in your own words; if none of it is reporting, say so plainly and stay with what you do use it for |
| F5 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The material says seven years in ops and does not show how many of them were spent leading others; the words stay at the quote: "I have 7 years in warehouse and distribution ops." Answer slot: say how many of those years you held a supervising or managing role, in your own words; if fewer than five, say so plainly and stay with the seven years in ops and your current role |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a credential with no certificate inspected behind it, so expect a probe. Lead with it in the quote's own terms: "I'm green belt certified." Say which methodology the certificate names only if you know it exactly |

## Persona table

**How the weights were set:** no loop source was available (the company searches were refused), so the loop falls back to the generic archetype, which carries flat weights. The only tilt is the hiring-manager prior, which favors Case/Strategist and Skeptic. That prior is an assumption, because the round was not stated.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (Bank A) | Three supervisors against twelve; warehouse and distribution against terminal operations; the five-plus years; Power BI | high: the hiring-manager prior includes it, and F1, F3, F5 and F6 give it material | Rehearse A1 until it is boring; hold bridges at the quotes' scope; say the concession before it is asked for |
| Case/Strategist (Bank B) | Live operations problems from the JD: on-time performance, cost-per-shipment, a daily report, a surge | high: the hiring-manager prior includes it, and the JD is operational throughout | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (Bank C) | Line-by-line questions on the 40% and the pick path | medium: a headline figure draws probes in any round | Know what you can say about how the figure was counted and say plainly what you do not know; name the weakest assumption first |
| Conversational (Bank D) | "Walk me through the journey"; casual questions about the surge plan and the Lean/Six Sigma plus | medium: casual-register questions are scored and can open any round | A 90-second arc told at the scope of your sentences; treat casual questions about JD topics as scored |
| Pressure (Bank E) | "Why you over someone who runs several sites?"; "how much of that was you?" | low: no skip-level or executive signal in what was provided | Pause, restate, anchor in what you stated; hold through two follow-ups before conceding anything real |
| Values/Behavioral (Bank G) | Standards with supervisors; an unpopular truth to leadership | low: no loop source documents a values round, so none is detected | Choose instances where the hard truth landed; if none comes to mind, say so plainly |
| Peer Evaluator (Bank H) | Seams between sites; credit across teams | low: rises if the interviewer turns out to run another site or function | Seam principles rather than pretending to know the seam; reciprocity: what you bring their team |

## Question banks

**Highest-ROI prep in this pack: A1.** The step from three supervisors to twelve will be raised in some form, and a rehearsed, non-defensive answer changes the interview.

### Bank A: The Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You manage three supervisors today and this role has twelve. What makes you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Concede the size of the step before you are asked, then hold only what the quote carries: "Twelve is a bigger span than the three I'm currently a senior shift manager over." Answer slot: if you have been responsible for supervisors beyond those three, say who and when, in your own words; if not, say so plainly and stay with the three. Follow-up 1, "three isn't twelve": concede the arithmetic, return to the quote. Follow-up 2, "what breaks first at that size": say what you expect would break first and why, as a view about the future, in your own words. Follow-up 3, "why not someone already running a bigger team": say your record at its own scope and stop: "I cut mis-pick rate 40% by redesigning the pick path" and "I ran the site's peak-season surge plan two years running." Let the interviewer draw the inference. Close with how you would spend your first weeks, as a plan: what you would learn about each site before changing anything | F3 and F1 are where the JD's span presses hardest on this material, so this objection arrives in some form; the Skeptic stem asks it directly. JD because it scores a stated requirement; it gets the deepest rehearsal because the limit is named before it is asked for |
| A2 | "Your background is warehouse and distribution. This role is terminal operations across four sites. How does one get you to the other?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running" | Say the background at its own scope: "I have 7 years in warehouse and distribution ops" and "I ran the site's peak-season surge plan two years running." Answer slot: if any of your work was terminal operations, or reached beyond one site, say what and how, in your own words; if none did, say so plainly, then say what you would learn first about a terminal before changing anything. Do not tell them the work proves you can; describe it and let them decide | F1 is the row where "terminal" and "4 sites" are not carried by the material, so a kind-of-work probe is likely; JD because it scores the first line of the posting |
| A3 | "The posting asks for five-plus years of operations leadership. How many of your seven years were spent leading others?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Give the number yourself, in your own words, before the interviewer does the arithmetic. Answer slot: say how many of those years you held a supervising or managing role and what the role was; if fewer than five, say so plainly and stay with the seven years in ops and "I'm currently a senior shift manager over 3 supervisors." Where a figure could be read two ways, say the lower reading; do not round up | F6 is a discovery row: the material does not show how the seven years divide. JD because the requirement is stated in the posting |
| A4 | "The role builds reporting in Excel and Power BI. Where are you on the Power BI side?" | JD | [grounded] "never used Power BI" | Say it plainly: "I haven't used Power BI." Hold that through two follow-ups; do not soften it into "some exposure". Then say how you would learn it, as a plan and never as a past: what you would build first and from what data, in your own words. Do not claim your Excel work transfers; if asked, answer from what you actually use Excel for | F5 is a stated gap, and a stated gap is the one an interviewer finds in one question. JD because it scores a named tool in the posting |
| A5 | "Why this move, and why now?" | JD | [generic] | A selection scaffold with no claim about your past: say what you want more of in your work, which lines of this posting you want (the daily terminal ownership, the four sites, the twelve supervisors) and why now. The reasons are yours; this pack does not know them and will not supply any. If a reason concerns your current employer, say it as a plain fact without blame. If no reason comes to mind beyond the step up, say so plainly | The Skeptic scores motivation consistency for a move like this; JD because the answer should point at the posting's own lines, and `[generic]` because it asserts nothing about you |

### Bank B: The Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four sites has slipped over the last three weeks while the other three are steady. What do you need to know first, and what do you do in your first week?" | CASE | [generic] | Clarify before structuring: when it started, what changed (volume mix, staffing, equipment, customers, carriers), and whether on-time is measured the same way at all four sites. State the objective, then segment (inbound or outbound, shift, lane, customer), name hypotheses and the quick checks that separate them, say who among the supervisors owns each action, name the metric that tells you it worked, and name one risk. Challenge one premise respectfully, for example whether the measure is consistent across sites. The question needs no claim about your past, so the guidance makes none | The JD's on-time requirement set as a live problem across the site structure it describes; CASE because it scores structure and not a right answer |
| B2 | "Cost-per-shipment is rising at all four sites while on-time is flat. Where do you look?" | CASE | [generic] | Split the ratio first: is cost up, are shipments down, or both. Then break cost into its parts (labor and overtime, handling and rework, damage, transport) and ask what changed at all four sites at once, since a shared cause is likelier than four separate ones. Say which check is cheapest and which action you would hold until you know. Name how you would confirm the fix. No claim about your past | The JD's second measure, asked as a diagnosis; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B3 | "You take over twelve supervisors who each report their daily numbers in their own spreadsheet. Design the one daily terminal report: what is on it, and what would you build it in?" | CASE | [grounded] "solid Excel"; "never used Power BI" | Start with who reads it and which decision each line drives, then one shared definition per measure, one data source, one cadence. Name the tool you would actually start in and be exact about it: "solid Excel" is what your material says and Power BI is not yet something you have used, so do not name Power BI as a skill. Answer slot: if you are asked what you use Excel for today, say what and who sees the output, in your own words; if none of it is reporting, say so plainly and stay with what you do use it for | The JD's reporting line asked as a design problem, with F4 and F5 as the limits on what you can claim; CASE with JD content |
| B4 | "It is six weeks to peak. Three of the four sites are short of people for the surge and the fourth has capacity. How do you plan it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Clarify the forecast and what "short" means in heads and in hours. Lay out the options (cross-site cover, overtime, temporary labor, shaping volume with customers, cross-training) with the trade-off of each, then triggers for switching plans, how the twelve supervisors are briefed, the metrics, and one risk. If you draw on your own surge plan, tell it at its own scope: "I ran the site's peak-season surge plan two years running." Add nothing about it that the sentence does not say | The surge sentence is the one piece of your record that this scenario can touch, so the case lets you use it without stretching it; CASE because the structure is what is scored |

### Bank C: The Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-pick rate by 40%. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot, each part in your own words: how the 40% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Name the weakest assumption before the prober does. If you know how it was counted, say it exactly; if you do not know how it was counted, say so plainly and say what you would check to find out. This pack supplies no baseline, period or method, because an explanation you cannot repeat under a second question is worse than none | F2 holds your only quantified claim, which is the first thing a prober tests; EXP because it scores whether the figure survives |
| C2 | "Walk me through how you redesigned the pick path." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Tell it in the beats the sentence states: the pick path, the redesign, the mis-pick rate that fell 40%. Where the interviewer goes past those beats, answer from what you did, in your own words, and say plainly where you do not recall or where a decision was someone else's. Answer slot: say which part of the redesign was yours; if part was shared or set by someone else, say which part and keep the rest | F2 again, from the process side: the prober moves from the number to what produced it. EXP because it tests what was actually yours |
| C3 | "Tell me about a time you moved a service or cost number you were responsible for." | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The nearest sentence in your material is the mis-pick result, so tell it at its scope, and say plainly that it is a quality measure, not on-time performance or cost-per-shipment. Answer slot: say which measures you watched alongside mis-pick rate and what happened to them; if mis-pick was the only one, or none of the others were yours, say so plainly and stay with the mis-pick result | The JD's two measures, asked as an open prompt; the honest answer starts from the nearest sentence rather than a stretched one. JD because it scores the posting's first accountability |

### Bank D: The Conversational / Rapport Builder (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc in three beats: "I have 7 years in warehouse and distribution ops", "I'm currently a senior shift manager over 3 supervisors", then the move you want and why, in your own words. Answer slot: where the arc needs a step these sentences do not carry (earlier roles, dates), say it in your own words if you can state it precisely, and leave it out if you cannot. End on this role, not on what you are leaving | A casual opener is scored for economy and direction; EXP because it fixes the record the later questions probe |
| D2 | "Tell me about the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Tell it at the sentence's scope: "I ran the site's peak-season surge plan two years running." The beats are the plan, the site's peak season, and the two years. Where the interviewer asks past those beats, answer from what you did and say plainly where you do not recall or where it was someone else's call. Do not call it anything the sentence does not call it | The surge plan is one of your two repeatable stories in this material, and a friendly register is where it gets embroidered; EXP because it scores the story's attribution |
| D3 | "What are you working on in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Lead with the credential: "I'm green belt certified." Answer slot: the posting lists Lean/Six Sigma as a plus, so a probe on use is likely. If you have used it on any project, say what and which part was yours; if you have not applied it on a project, or have nothing current, say so plainly and stay with the credential. Say which methodology your certificate names only if you know it exactly | F7 is the posting's plus, and a casual question about a plus-skill is still scored; JD because it scores a stated qualification |

### Bank E: The Pressure Interviewer (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already runs several sites?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, restate the question, then answer in under a minute from three sentences at their own scope: "I cut mis-pick rate 40% by redesigning the pick path", "I ran the site's peak-season surge plan two years running", "I'm green belt certified." Hold through two follow-ups. Concede specifically: someone who runs several sites has run a bigger span than you have. Do not claim to be better; describe what you have done and stop | The hiring-manager derisking question in its time-boxed form; JD because it scores fit against the stated role |
| E2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold-then-concede. Pause, restate, and hold the sentence as far as you can defend it. Answer slot: say which part was yours and which was not, in your own words; if all of the redesign was yours, say so, and if part was shared or set by someone else, say which part and keep the rest. If the follow-up turns to how the figure was counted, answer as in C1. Shrinking a claim gracefully reads as credibility; defending an inflated one does not | The attribution probe on F2's only figure; EXP because it exists to test what was actually yours |

### Bank G: The Values / Behavioral Interviewer (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to hold a supervisor to a standard." | JD | [generic] | A selection scaffold with no claim about your past: pick an instance with a named standard, a moment where you did not let it slide, and a working relationship still intact at the end. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's supervisor-leadership line as an open prompt, since twelve supervisors is the role's core; JD with EXP delivery, `[generic]` because no quoted sentence carries the story |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | A selection scaffold with no claim about your past: pick an instance with a named stake, a moment you did not soften the message, and what happened to the relationship afterwards, including if it cost you something. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values-round stem; EXP rather than VAL because no published Atlas values were available to score against |

### Bank H: The Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Two of our sites compete for the same overflow freight and the same drivers. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Offer principles rather than pretending to know the seam: a shared priority both sites sign up to, one agreed data source for the decision, who decides and by when, and an escalation path. Then reciprocity: say what you would do for their site, not only what you need. No claim about your past | Four sites make seam problems part of the job; CASE because it is a live problem about the role |
| H2 | "How do you handle credit when work spans teams?" | EXP | [generic] | State the principle in a sentence. Then, if an instance comes to mind, tell it plainly, and say which part was yours; if none comes to mind, say so plainly and say how you would handle it. No claim about your past is made for you | A standard peer stem about credit-sharing; EXP because it scores how you attribute work |

### Requirement-coverage line

| JD requirement | Questions | Note |
|---|---|---|
| "Own daily terminal operations across 4 sites" | A1, A2, B1, B4 | |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C3 | The 40% figure is covered by C1, C2 and E2 |
| "lead a team of 12 supervisors" | A1, G1, B3 | |
| "build reporting in Excel/Power BI" | A4, B3 | |
| "5+ years operations leadership required" | A3 | |
| "Lean/Six Sigma a plus" | D3, E1 | |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How are on-time performance and cost-per-shipment defined and reported today, and is it the same definition at all four sites?" | It asks how the numbers are counted, which is the discipline a prober scores, and it shows you start from the posting's two measures |
| R2 | "Which of the four sites is furthest from where you want it to be, and what do you think is behind that?" | It asks where you would start, which is the real first question of the job |
| R3 | "What does the supervisor team look like today, and where is the span hardest to manage?" | It gets the twelve-supervisor reality onto the table in the interviewer's words and not your guess |
| R4 | "What reporting exists today in Excel and Power BI, and what would you want built first?" | It turns the Power BI gap into a scoping conversation and shows you are already thinking about the first report |
| R5 | "What does success look like at 90 days and at six months?" | It makes the criteria explicit, so the rest of the interview can be heard against them |
| R6 | "Where do the four sites depend on each other, and who decides when they conflict?" | It signals you see the seam problem before you are asked about it |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed twelve supervisors | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors". The limit is the pack's observation: your material shows three supervisors, not twelve. A1's slot stays inside the three |
| Delivered on-time-performance or cost-per-shipment results | Inflated form of F2 | F2's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path". The limit is the pack's observation: the material says mis-pick rate. C3's slot asks only which measures were watched alongside it |
| Built operational reports or dashboards | Inflated form of F4 | F4's quote at its own scope: "solid Excel". B3's slot asks only what Excel is used for and who sees the output |
| Has used Power BI | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I haven't used Power BI." No slot |
| Has five or more years of operations leadership | Inflated form of F6 | F6's quote at its own scope: "7 years in warehouse and distribution ops". The limit is the pack's observation: the material says seven years in ops, not how many were spent leading others. A3's slot asks only how many years you held a supervising or managing role |

## Sources

**Provided documents:** your message, which carried the job description text and your background. No CV file, no interviewer profile, no recruiter notes, no assessment, no dossier.

**Searches sent (all three refused; nothing was returned or used):**

- `Atlas Freight regional logistics company values`: refused
- `Atlas Freight interview process operations manager`: refused
- `Atlas Freight regional logistics strategy news`: refused

No page fetches were sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have fed a values cheat sheet and VAL questions on the published names; neither is in this pack |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. It would have fed the loop structure and persona weights; the pack uses the generic archetype and the hiring-manager assumption instead |
| 3. `Atlas Freight` strategy / recent news | unavailable | The search was refused. It would have grounded CO and CASE questions in current priorities; the CASE bank is `[generic]` instead |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting (name and role) → persona weights reset from the relationship, a tailored reverse question, and a reading of their public footprint
- The recruiter's guidance on format, focus areas or something to prepare → coverage re-aimed, and a build section for any pre-declared deliverable
- Atlas Freight's careers or values page pasted in, or web search allowed in this session → loop structure replacing the generic fallback, and a values cheat sheet if a values round shows up; this would also let targets 1 to 3 above run
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, run only if you say yes and search is allowed) → a grounding brief on Atlas's strategy and recent moves, so the CASE and CO questions stop being generic
- Your answers to the answer slots, stated in your own words (how many years you held a supervising or managing role, how the 40% was counted, what you use Excel for, which measures you watched beside mis-pick rate, whether any of your work reached terminal operations or beyond one site) → F1, F2, F3, F4 and F6 rewritten from slots into your own sentences
- Inspectable artifacts: the green belt certificate, a before-and-after sheet for the mis-pick figure, a surge-plan document with sensitive details removed → F7, F2 and F1 move from `medium` toward `high`
- A tuesday-dossier.md from job-underwriter, if you have one → an objection chosen from evidence and an absolute prohibited-claims list for every cell
