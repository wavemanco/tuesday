I'll read the skill's reference files before building the pack.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-3-denied-139c0132/stripe_product-operations-manager_interview_pack.md`. It has 21 questions across seven interviewer styles, a worksheet in place of a fit snapshot, reverse questions and an upgrade menu.

I built it from your message alone, assuming a final round with an unknown interviewer and format. Web search wasn't permitted, so all four research searches were refused. That means the pack has no Stripe-specific facts: no published values, no documented loop and no strategy questions. Because you gave me no job description or CV, every question is generic and none claims anything about your past. The pack names B1, "which part of this role would you be weakest at on day one", as the question most worth rehearsing, though it isn't yet tailored to your background.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in this final round (future manager, peer, skip-level or a cross-functional partner), and has the recruiter told you the format, focus areas or any deliverable? The answer reweights every question bank.
Can you paste the job description and your CV, or a few lines on your background? If not, I'll keep working from the generic pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round. **Interviewer(s) and relationship:** not given. **Format:** not given. **Built on:** your message only. No JD, no CV, no recruiter guidance and no research came back, so every row below is `[generic]` and no sentence in this pack makes a claim about your past or about Stripe's own practice. Each section says what it would become with more input.

## How to use this pack

Personas describe how a question arrives (who is asking, in what register). Types describe what the question is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past or hypothetical behavior fits a company's values |
| EXP | Whether your work claims survive scrutiny; what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack; see the coverage table) |
| CASE | Structure and reasoning on a live problem |

Where a question asks about your past, the guidance is a selection scaffold that ends in an honest branch, because no sentence of yours was supplied for it to be mapped to.

## Fit snapshot (worksheet variant)

No JD and no CV were supplied, so this is a worksheet. The requirements are role-family prose, not quotes, and the evidence column is empty on purpose. Fill the evidence column yourself before the interview, using only things you did.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate a cross-functional launch or release across engineering, design, sales and support (role-family requirement, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a named launch, the teams involved, and the part that was yours. Selection scaffold: pick the launch where your own role is easiest to state in one sentence; if no launch comes to mind, say so plainly, then give the nearest coordination work your material does carry, or how you would run one |
| F2 | Define, track and report operating metrics for a product area (role-family requirement, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a metric you reported, how it was counted and what it was sensitive to. Selection scaffold: pick a number you can explain to its assumptions; if none comes to mind, say so plainly, then give the nearest reporting you did, or how you would set the metric up |
| F3 | Build or improve a process, intake or prioritization mechanism for product teams (role-family requirement, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a process you changed and what happened to the work afterward. Selection scaffold: pick a process where you can say what it replaced; if none comes to mind, say so plainly, then give the nearest improvement you made, or how you would approach one |
| F4 | Influence senior and peer stakeholders without formal authority (role-family requirement, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a disagreement, who held the decision, and what you did. Selection scaffold: pick a disagreement where you did not own the call; if none comes to mind, say so plainly, then give the nearest case, or how you would handle one |
| F5 | Turn customer or field feedback into input for product decisions (role-family requirement, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a feedback channel you worked with and a decision it touched. Selection scaffold: pick a case where feedback reached a decision you saw; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would build the loop |
| F6 | Structure ambiguous problems and make progress without a defined playbook (role-family requirement, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a problem with no owner and the first move you made. Selection scaffold: pick a problem you were handed unstructured; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would start |

No row is a gate: nothing supplied names a term such as location, authorization or schedule, so none is invented here.

## Persona table

The weights rest on a role-family pattern, not on a documented Stripe loop, and no interviewer was named. Treat them as flat with a tilt, and recalibrate if you know who you are meeting.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems: plan a launch, diagnose a metric, design a process | Highest. [generic] The role sits across teams, so live operating problems are a natural way to test it, and a final round often includes one | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of weakest area, motivation, why this role and why now | High. [generic] A final round is where gaps get cross-examined; the specific gap cannot be named until you share a CV | Rehearse the most predictable objection until it is boring; calibrated candor over bluffing |
| C. Peer Evaluator | Seam between product operations and product teams; credit; disagreement | Medium-high. [generic] Final loops often include someone who would work beside you; weight rises sharply if you tell me the interviewer is a peer | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| D. Data-Driven Prober | Metrics probed to their assumptions | Medium. [generic] An operations role is about numbers, and any figure you cite becomes a target | Say how a number was counted, name the assumption you would defend least, say plainly when you do not know |
| E. Values/Behavioral | Behavioral stories tied to the company's published values | Medium. [generic] Weight unknown: no loop source was read and the published values are not in hand, so no values-style round is assumed | Choose stories where the hard truth landed; where none exists, say so |
| F. Pressure | Interruptions, time-boxing, motive challenges | Lower. [generic] More likely from a skip-level or executive than from a peer | Pause, restate, hold a position through two follow-ups, concede specifically |
| G. Conversational | Friendly opener that is still scored | Lower. [generic] Appears at the start or end of most conversations | A prepared 90-second arc; treat casual questions as scored |

**Highest-ROI prep: B1.** Some form of "where would you be weakest on day one" is the question most worth rehearsing, because it is asked in nearly any loop and a rehearsed, non-defensive answer changes the conversation. It is generic until a CV is supplied, so the candidate-specific version of the objection is not yet named.

## Question banks

### A. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks out. Engineering says it is on track, support says they are not ready, and sales is already promising it to customers. What do you do first?" | CASE | [generic] | Clarify first: what ready means, who makes the go or no-go call, whether the date or the scope is fixed. Then objective, then segment the gaps (product, support readiness, external commitments), then approach (one shared readiness view, named owners, a decision date), metrics, risks. Challenge one premise aloud, such as whether the date is truly fixed. The question asks about no past, so the guidance makes no claim about yours | Covers F1 and F6. CASE because it scores structure, not the right answer |
| A2 | "A key adoption metric dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Clarify whether the metric or the world changed: definition, instrumentation, data pipeline. Then segment (product, customer type, region, channel), list recent changes, and rank hypotheses by what is cheapest to check. Say what you would check first and what would change your mind | Covers F2 and F6. CASE because the data-quality-first move is what the question scores |
| A3 | "Product teams get requests from sales, support and leadership with no shared process. Design an intake and prioritization approach." | CASE | [generic] | Clarify volume, who feels the pain, and what exists today. State principles before mechanics, start lightweight, define how you would know it worked, and name the risk that it becomes bureaucracy | Covers F3. CASE because it is a design problem with no right answer |
| A4 | "What should a product operations function own, and what should product managers keep?" | CASE | [generic] | Offer seam principles, not a claim about this organization: ask what the current arrangement is, say what you would want decided by the person closest to the product, and say how you would handle overlap. Name one thing you would deliberately not own | Covers F3 and F4. CASE because it tests whether you can reason about a boundary without knowing the facts |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal. Selection scaffold: look at the six worksheet rows and take the one where you have least to point to. Name it plainly, then give a ramp: what you would learn first, from whom, and what you would check at 30 days. Do not choose a fake weakness. If no gap comes to mind, say so plainly, then name the area where you have least inspected proof and how you would verify it. Hold through two follow-ups by repeating the ramp, never by adding claims | Likely in some form in any loop; JD because it scores the role's requirements, gaps included. Which gap it targets depends on a CV not yet supplied |
| B2 | "Why leave, why Stripe, and why now?" | JD | [generic] | Three short beats in your own words: what pulls you toward this kind of work, what you are leaving without disparaging it, why this company. For the third beat say only what you actually know about Stripe; if little, say so plainly, then say what you would want to learn. Consistency across rounds matters more than polish | Motivation consistency is the Skeptic's core test; JD because the role's draw is part of fit |
| B3 | "Product operations owns no product. A product manager disagrees with your recommendation and can simply ignore it. How do you proceed?" | JD | [generic] | Clarify what the disagreement is about and who owns the decision. Then: show the data and the other view side by side, agree who decides and by when, escalate only with both views documented. Concede that you may be wrong. The question asks about no past, so the guidance makes none | Covers F4. JD because influence without authority is a role-family requirement; it presupposes nothing about you |
| B4 | "A product team says your function slows them down. What is your response?" | JD | [generic] | Take the complaint seriously first: ask what specifically costs them time. Then separate cost from value, offer to measure it, and say what you would remove if it did not pay for itself. A defensive answer fails here more than a wrong one | Covers F3. JD because it tests whether process is a means or an end |

### C. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose principles, not a map of a seam you do not know: ask how it works today, say who you would want deciding what, and describe how you would raise a disagreement (evidence, a named decision owner, a date). Show spine and tact together | Covers F4. JD because it scores partnership fit |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an instance from your own work where credit was shared, and say we for context and I for your contribution. If no instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the peer round; VAL because it tests collaborative behavior |
| C3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Reciprocity: lead with what you would bring them (visibility, a cleaner handoff, fewer surprises), then the two or three things you would need to learn from them. Ask rather than assume | Covers F4. JD because a peer is pricing what the hire adds to their load |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number you have reported in your work. Walk me through how it was counted." | EXP | [generic] | Selection scaffold: choose a figure you can take to its definition. Say how it was counted, what it was sensitive to, the assumption you would defend least, and which part was yours, each in your own words, before the interviewer asks. If you do not know how it was counted, say so plainly and return to what you do know. Never explain a method you did not use | Covers F2. EXP because it scores attribution honesty; the metric is yours to choose |
| D2 | "What three metrics would you put on a launch readiness view, and what would each fail to tell us?" | JD | [generic] | Pick three that cover different things (product, support, commitments), and for each say what it hides. Naming each metric's blind spot is the point. The question asks about no past | Covers F2. JD because it tests whether you know a metric's limits |
| D3 | "How would you tell whether a process you introduced actually helped, rather than just added work?" | JD | [generic] | Say what you would measure before and after, what you would ask the people using it, and what result would make you remove it. Concede what you could not measure cleanly | Covers F3. JD because it probes the assumptions behind any improvement claim |

### E. Values/Behavioral (weight 3)

Stripe's published values are not in hand, so none is mapped by name here.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship intact afterward. Where the hard truth actually landed, say so; where it did not, say that. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the values round; VAL because it scores behavior, not virtue |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a case with a real trade-off and a decision you can name. Say what was given up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F5. VAL because it scores a decision, not a slogan |
| E3 | "You discover a mistake in a report leadership has already acted on. What do you do?" | VAL | [generic] | Say who you would tell first, how you would size the impact before escalating, how you would correct the record, and what you would change so it does not recur. The question asks about no past | VAL because it tests candor under cost; it presupposes nothing about you |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then give one or two differences you can back from your own work, and concede concretely what an internal candidate knows that you do not. Hold through two follow-ups; do not fold on the core point. If no difference comes to mind, say so plainly, then say what you would do to close the context gap | Persona stem for the pressure round; JD because it tests fit under challenge |
| F2 | "Pick the project you are proudest of. How much of it was actually you?" | EXP | [generic] | Name your part precisely, with we for context and I for contribution. Hold your account through two follow-ups, then concede specifically what others did. If part of it was not yours, say so plainly and return to the part that was | EXP because it scores attribution under pressure |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in three beats: where you started, the turn that led here, why this role. Built from your own history; no CV was supplied, so no beats are given. Tell it in your own words | EXP because it is the CV in spoken form, and casual openers are scored |
| G2 | "What have you been working on or learning lately?" | JD | [generic] | Pick something real and recent that connects to the role. If nothing comes to mind, say so plainly, then name what you plan to learn about the role before day one | JD because casual questions on role topics are scored; weak answers here read as low interest |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 cross-functional launch | A1 |
| F2 operating metrics | A2, D1, D2 |
| F3 process and prioritization | A3, A4, B4, D3 |
| F4 influence without authority | A4, B3, C1, C2, C3 |
| F5 customer feedback into decisions | E2 |
| F6 ambiguity and structure | A1, A2 |
| Company strategy knowledge | none, and why: no research came back, so a CO question would be invented |
| Company values by name | none, and why: the published values are not in hand |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make someone in this role clearly successful at six months, and how would you know" | Shows you think in outcomes and gives you the real scoring sheet |
| R2 | "Where does product operations end and the product teams begin today, and where is that line still contested" | Shows seam awareness and surfaces the live tension in the role |
| R3 | "What is the hardest cross-team problem this function has not yet solved" | Invites a real answer, and you can connect it to your own thinking on the spot |
| R4 | "How does the team decide what to stop doing" | Tests whether the function is a process engine or a judgment function |
| R5 | "What would a new person do in their first month that would genuinely help your team" | The reciprocity question for a peer interviewer; useful from anyone |
| R6 | "What has surprised you most since joining" | A rapport opener that tends to produce candid answers |

Rapport-style interviewers weight this slot heavily; never answer that everything has been covered. None of these is tied to an interviewer's own path, because no interviewer was named.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No sentence of yours was supplied, so nothing is stretched and no negative was stated | Every experience question above is a selection scaffold ending in an honest branch. Nothing here asserts a launch, a metric, a process or a decision as yours |

## Sources

Provided documents: none.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, all refused (permission not granted, no results returned):

- Stripe operating principles and values: refused
- Stripe interview process, Product Operations Manager, final round: refused
- Stripe strategy, recent news: refused
- Stripe Product Operations Manager job description: refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have moved the values cheat sheet (section 10) and VAL questions by value name |
| 2. Stripe interview process, product operations | unavailable | Would have moved persona weights and the loop structure; the generic archetype stands in |
| 3. Stripe strategy and recent news | unavailable | Would have moved CO questions and the grounding brief |
| 4. Interviewer name and company | n/a | No name was given, so no query could be formed; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the worksheet rows into quoted `[inferred]` requirements |

## Upgrade menu

- Recruiter's note on who you meet, the format, focus areas and any deliverable → persona weights recomputed from a stated relationship, and a build section for any announced deliverable
- Interviewer's name → an interviewer read, a reverse question tied to their path, and persona weights from their public footprint
- JD text → the six `[generic]` requirement rows become quoted `[grounded]` rows and JD questions map to its own words
- CV or a few lines on your background → the worksheet becomes a fit snapshot with your quoted evidence, selection scaffolds become story-mapped answers, and B1 names your real likeliest objection
- Web search access, or Stripe's published values page and loop description pasted in → a values cheat sheet by name, CO questions, and a documented loop; a deeper pass would add up to 6 more searches and 2 more fetches over several more minutes
- Prep time available → a prioritized schedule sized to it
- A prior `tuesday-dossier.md` from the job-underwriter skill → verified evidence and a named top objection, never required
