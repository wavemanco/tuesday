I'll start by reading the skill's reference files.
Fixing one typo in the pack, then I'll hand it over.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-4-denied-2248981e/quartzline_product-manager-platform-apis_interview_pack.md`. It's built for a 45-minute hiring-manager round, using your dossier as the source for the role and your evidence. It has 20 questions across six interviewer styles.

All three Quartzline searches (values, interview process, strategy) were refused. Nothing in the pack is sourced from outside your dossier. Question B5, which asks about the company's strategy, is labeled generic, and there is no values section.

The top rehearsal is A1, the objection the dossier named: "You have never held the PM title or owned a roadmap…". The pack coaches you to concede what the dossier says you haven't done, hold only your three confirmed evidence lines, and offer a ramp plan. After that, rehearse D2 and D1. D2 asks about your quarterly roadmap-input sessions, the claim the dossier marks as likely to be probed. D1 asks how the "30+" integrations were counted.

Say the word and I'll play the hiring manager on A1 as a live drill.
I can also save an updated `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry forward.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday. Interviewer: hiring manager, name not given. Built from the dossier you carried (conditional_go) plus your note on the round. No company research was available (see Sources), so company-specific content is absent rather than guessed.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: does a claim survive scrutiny, and what was actually yours |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth and altitude |
| CASE | Live problem from the role: structure and reasoning |

Highest-ROI prep: A1, the objection the underwriter named. Rehearse it until it is boring, then D2 and D1, the two places the dossier says a probe is most likely to find a seam. An answer slot in a guidance cell is an instruction for the interview, not a question for you now.

## Fit snapshot

Evidence quotes below are from the dossier's verified_candidate_evidence list, entry 1, 2 or 3. The confidence notes on those entries (entries 1 and 2 high, entry 3 medium: confirmed, limited inspectable proof) are in the Confidence column, not in the quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence, entry 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence, entry 3 | low | [grounded] | transferability | The dossier grades this a bridge: adjacent work, positioned as adjacent and never as product management experience. The words are the two quotes at their own scope. The limit is the pack's observation: your material shows integration delivery and evidence passed to product, not a product role. No wider step is offered; the roadmap part of R1 is F2 |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area (uncertain_or_weak_areas) and lists `prohibited_claims: "Having owned a product roadmap"`. Words: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: how you would learn where roadmap decisions sit between the PM and the two squad leads. No bridge and no slot here |
| F3 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence, entry 3 | medium | [grounded] | discovery | Confirmed with limited inspectable proof, so expect a probe and volunteer the limit first. Words: "I ran quarterly roadmap-input sessions that fed client evidence to product." Answer slot: the discovery line makes a probe likely on whether those sessions put questions to partners or clients directly. If they did, say what you asked and what part was yours, in your own words; if the sessions only passed on evidence gathered elsewhere, or there was no discovery step, say so plainly and stay with the sessions |
| F4 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence, entry 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence, entry 2 | high | [grounded] | transferability | High grades the integration work (entry 1 has an inspectable playbook behind it), not the requirement. The words are the two quotes at their own scope. The limit is the pack's observation: the material says integrations led through go-live and a playbook written, not the release of an API or platform product. Any wider step is a slot inside the quote: which of the listed stages were yours, in your own words |
| F5 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence, entry 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence, entry 2 | low | [inferred] | discovery | REST APIs and an architecture stage touch technical fluency, but the quotes do not show whether API docs or schemas were part of it. Answer slot: the requirement names docs and schemas, so expect a probe on them. If you wrote, read or worked from either, say which and how, in your own words; if you did not, say so plainly and stay with the architecture and playbook quotes |
| F6 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence, entry 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence, entry 3 | medium | [inferred] | discovery | The quotes carry clients and product; they do not show engineering or sales. Answer slot: the requirement names all three groups, so expect a probe on the two the quotes do not mention. If engineering or sales were among the people you worked through in those integrations or sessions, say who and how, in your own words; if they were not, say so plainly and stay with the client side the quotes carry |
| F7 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier's strategy for this area is clarify. Nothing in your quoted material speaks to it, so the pack puts no story in your mouth. Answer slot: the posting's line is "Agile delivery experience", so expect a probe on what that means here. If you have worked in an agile delivery setting, say how it ran and what your part was, in your own words; if you have not worked that way, say so plainly, and say what you would want to confirm about how Quartzline defines it |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | none given | low | [grounded] | discovery | Entry 1 mentions requirements and nothing about specs or squads, and the pack stops there. Answer slot: the line makes a probe likely on written specs. If any requirements you scoped were written up for an engineering team to build from, say what the document was and who used it; if none were, or you did not write them, say so plainly. Squad prioritization is the dossier's `prohibited_claims: "Having set prioritization for an engineering squad"`, covered in F2 and section 13 |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | low | [grounded] | discovery | The dossier notes no adoption baseline is stated on the employer's side either. Answer slot: the line makes a probe likely on what you tracked. If anything was counted after a go-live, say what and how it was counted, in your own words; if nothing was, or it was not yours, say so plainly and say what you would measure first |

## Persona table

No interviewer profile exists, so weights come from the relationship prior (hiring manager: Case/Strategist and Skeptic), adjusted by the dossier. The round is one session you described yourself, so no loop archetype is assumed.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet probing of the title, roadmap and agile gaps | High. Hiring manager prior, and the underwriter named a specific objection from evidence you confirmed | Concede the sourced gaps plainly, hold only what the quotes carry, state the limit before it is extracted, bring a ramp plan |
| Case/Strategist (bank B, 5 questions) | Live problems on the partner API roadmap and the two squads | High. Hiring manager prior; the posting's responsibilities are all case-able | Clarify, then structure, then answer; say out loud that you are giving a method, not a past |
| Conversational (bank C, 3 questions) | The biography opener and a casual question about how you work with engineering | Medium. A 45-minute manager conversation almost always opens this way, and casual questions are still scored | A 90-second arc built only from your three quoted sentences |
| Data-Driven Prober (bank D, 3 questions) | Defend the 30+, then the sessions | Medium. Entry 1 carries a figure and entry 3 is the dossier's flagged probe seam | Say how the figure was counted, or plainly that you do not know; volunteer the limit of the sessions |
| Peer Evaluator (bank E, 2 questions) | Seam and credit questions about the squads | Low. This is a manager round, but the role sits next to two squad leads so it can arrive in manager form | Propose seam principles rather than pretending to know the seam |
| Pressure (bank F, 2 questions) | Time-boxed challenge on why you, and on how much was you | Low. No signal for it, but the objection can be asked this way | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral (no bank) | Not detected | Low. No loop source names a values round, and the company's published values were not retrievable, so a bank would be invented | See the upgrade menu |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims: "Having held a product manager title or role"`; `prohibited_claims: "Having owned a product roadmap"` | The highest-ROI rehearsal in the pack; the underwriter named this objection. Four moves. (1) Concede first and plainly: "I haven't held a product manager title or role, and I haven't owned a product roadmap." (2) Hold only what the quotes carry: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live", and "Ran quarterly roadmap-input sessions feeding client evidence to product". Name the limit yourself before it is extracted: this is adjacent work, not the job, and the sessions are confirmed but thinly documented, so say what they were and stop. (3) Say where you would start, as a plan and not a past: find out how roadmap decisions split between the PM and the two squad leads, and how adoption is measured today. (4) Follow-ups. If "that's delivery, not product": agree with the limit, return to the two quotes, add nothing. If "why you over someone with three years": do not argue the comparison; say what the quotes carry and what you would need to learn. Let the interviewer draw any inference | F1 and F2 are the dossier's own gaps, and a manager hiring into a role with a title requirement asks this early. JD because it scores R1; tagged to the Skeptic persona because it is a cross-examination of the background |
| A2 | "Which API or platform products have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Hold the two quotes at their own scope: the integrations, and the playbook. Answer slot: the requirement says shipped API or platform products, so the probe lands on which stages were yours. Say which of scoping, requirements, architecture, UAT and go-live were yours and how, in your own words; if a stage was not yours, say so plainly and describe the stages that were. Let the interviewer decide whether that is the same thing as shipping a product; the answer does not claim it | F4 is the must-have where the material is adjacent rather than direct; JD because R2 is must-have |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] `prohibited_claims: "Having owned a product roadmap"`; `prohibited_claims: "Having set prioritization for an engineering squad"` | Answer with the dossier's sourced gap instead of a soft one: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the ramp, as a plan: how you would learn where decisions sit between you and the two squad leads, and what you would read and ask in the first weeks. Do not substitute a strength dressed as a weakness; it costs the honesty this question is scoring | F2 is the largest sourced gap, so it is the honest answer; JD because it asks you to rank the posting's own responsibilities |
| A4 | "I don't see agile delivery in your background — how would you handle that on a team running two squads?" | JD | [grounded] | No quoted sentence speaks to agile delivery, so nothing about your past goes in the answer without being yours. Answer slot: the posting's line is "Agile delivery experience", marked preferred rather than must-have, so expect a probe on what it means in practice. If you have worked in an agile delivery setting, say how it ran and what your part was, in your own words; if you have not worked that way, say so plainly and say what you would want to confirm about how Quartzline defines it and runs it | F7 is a clarify area in the dossier: the evidence may exist but was never established; JD because R5 is a stated requirement |
| A5 | "Why leave integration delivery for product, and why now?" | JD | [generic] | Your quoted material carries no sentence about your reasons, so this is a selection scaffold, not a story map. Pick the reason that is genuinely yours: it needs a specific thing about the work in your quotes that pulled you toward product, a reason this role rather than product roles in general, and nothing that sounds like escape from the current job. If no clear reason comes to mind, say so plainly, then give the nearest honest thing you do have, or how you would test the move before committing | The motivation probe is standard for a candidate changing function; JD because it scores whether the move is coherent with the role |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've just taken over the partner API roadmap and two squads. Sketch your first 60 days — what do you need to know first?" | CASE | [grounded] | Clarify before structuring. Your first questions are the two the dossier leaves open: which decisions the PM makes alone versus the squad leads, and how adoption is measured today and from what baseline. Then objective, who the partners are and how they differ, approach by week, the metric you would watch, and the risks. Say aloud that this is a method and not a claim about past work | The posting's responsibilities and the dossier's unknowns make this a natural opener; CASE because it tests structure before answers |
| B2 | "Suppose partner adoption is flat quarter over quarter. Diagnose it." | CASE | [grounded] | First pin down the definition: what counts as adopted (first call, steady use, production volume) and whether the baseline exists. Then segment partners, list two or three hypotheses with the data that would confirm each, name how you would instrument it, and say which assumption you would defend least. If asked whether you have tracked this before, answer from F9's slot, not from this case | F9 and the dossier's adoption-baseline risk; CASE because it is a live diagnosis |
| B3 | "A key partner asks for a change this quarter, but one squad is mid-quarter. How do you decide?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims: "Having set prioritization for an engineering squad"` | Open with who decides, since that is the dossier's unresolved question, then criteria: how many partners want it, what it unblocks, cost of delay, and what gets displaced. The evidence you would bring is of the kind in "Ran quarterly roadmap-input sessions feeding client evidence to product"; say that quote at its own scope, and its limit if pressed. If the follow-up is whether you have made this call before: "I haven't set prioritization for an engineering squad." Then return to the method | F2 and F8 sit exactly here; CASE because the interviewer scores reasoning, not a past |
| B4 | "A partner-facing endpoint needs a breaking change. What goes in the spec, and who reviews it?" | JD | [grounded] | A method, with no claim about your past: the problem and affected partners, the contract and schema impact, the migration path and deprecation window, partner communication, how success is measured, and review with the squad lead before it is final. Docs and schemas are the R3 probe, so know what you would put in each. Any claim that you have written specs belongs to F8's slot, not here | R3 and the specs responsibility; JD content with CASE delivery |
| B5 | "Where would you take the partner API platform in your first year, and what would you decide not to build?" | CO | [generic] | Research was unavailable, so this cannot name Quartzline's strategy. Answer in method: where partners get stuck, what adoption would need to show, one thing to build and one to decline with the reason. Do not recite facts about Quartzline you have not read; if you have read its materials, use those in your own words | A year-one question tests altitude, and the posting makes roadmap the headline responsibility; CO because it asks for company-level thinking, labeled generic for the honest reason above |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each a quote at its own scope: the integrations led, the playbook written, the sessions run. The quotes carry no dates, so order them as they really happened and do not add any. Close on why product, in your own words (A5). Do not call any beat product management | The biography opener is almost certain; EXP because it is where the CV is first tested |
| C2 | "How does your team use the playbook you wrote?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The playbook is the one artifact with inspectable proof, so be ready to walk through it end to end in your own words. Say that you wrote it and that the team uses it; what is inside it and how it changed practice is for you to say from memory, and if you do not remember a detail say so plainly | F4 and F5 rest partly on this artifact; EXP because it tests a concrete claim |
| C3 | "How do you like to work with engineering day to day?" | JD | [generic] | A casual question that is still scored for R4 and R5. Give your working principles in your own words: how you bring problems rather than solutions, how you handle disagreement, how you treat engineering time. If an example comes to mind, use it; if none does, say so plainly and describe how you would work | R4 names engineering and R5 is delivery practice; asked casually it is easy to under-prepare |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You led 30+ integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Four slots, each in your own words. How it was counted: what made something one end-to-end integration, and whether "30+" is a list you can point to. What it is sensitive to: what would move the number. The assumption you would defend least: name it before they do. Which part was yours: the quote says "Led", so start there and say which of the listed stages you did yourself. If you do not know how it was counted, say so plainly | The headline figure of F4 and F6; EXP because it is a defend-the-number question |
| D2 | "Walk me through one of those quarterly roadmap-input sessions — what did you bring and who was in the room?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | This is the dossier's medium-confidence claim, confirmed but with limited inspectable proof, so volunteer the limit before it is extracted: say what the sessions were and what you can and cannot speak to. Describe one session in your own words. Answer slot: the roadmap line in the posting makes a probe on what came of the sessions likely. If you saw what happened to what you brought, say it in your own words; if you did not, or nothing visibly came of it, say so plainly and return to the sessions. Add nothing about outcomes you cannot back | F3 and F6; the dossier flags this as the place to expect a probe |
| D3 | "After go-live, how did you know an integration had worked?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the adoption-metrics line makes a probe likely on what was measured. If anything was counted after a go-live, say what and how it was counted, in your own words, and the assumption behind it you would defend least; if nothing was, or it was not yours, say so plainly, then say what you would measure first in this role | F9; JD because it scores the adoption-metrics responsibility |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You'll sit between partners and two squads. Where's the seam between you and a squad lead, and what happens when you disagree?" | CASE | [grounded] | Do not pretend to know the seam: it is the dossier's open question. Offer principles instead: who owns the what and why versus the how and when, how a disagreement gets written down, and who breaks a tie. Then say you would confirm the real split in the first weeks. This makes no claim about your past | The authority split is the dossier's risk to validate; CASE because it asks for a position on a live seam |
| E2 | "How do you handle credit and escalation when work spans sales, engineering and customers?" | JD | [generic] | A principles question for R4. Pick an example from your own work if one fits; the quotes carry clients and product but do not show sales or engineering, so use F6's slot before claiming any. If no example comes to mind, say so plainly and describe how you would handle it | R4 names all three groups; the question arrives collegially but scores the same requirement |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM who's done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims: "Having held a product manager title or role"` | A1 cut to a minute. Pause, restate the question, concede "I haven't held a product manager title or role", state the one quote, name the limit, and finish on the ramp. Hold through two follow-ups by returning to the quote, never by adding to it | The time-boxed version of A1; JD because it scores the same requirement |
| F2 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold "Led" and the stages the quote lists. Answer slot: say which stages were yours and which were done by others, in your own words; if some were not yours, say so plainly. Specific concession on what was a team effort wins over a flat defense | The attribution probe the pressure style uses; EXP because it tests what was yours |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years product management experience | A1, A3, A5, F1 |
| R2: Shipped API or platform products | A2, D1, F2 |
| R3: Technical fluency: API docs, schemas | B4, C2 |
| R4: Stakeholder management across engineering, sales, customers | C3, E2, B3 |
| R5: Agile delivery experience | A4, C3 |
| Own the roadmap for the partner-facing API platform | A1, A3, B3, F1 |
| Run discovery with integration partners | D2, B1 |
| Write specs and drive delivery with two engineering squads | B4, B1, B3, E1 |
| Define and track adoption metrics | B2, D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier: the posting asserts authority but nothing evidences it. It reads as diligence and settles something you need to know before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier: adoption is a named responsibility with no stated baseline. It shows you think in measures and tells you what you would inherit |
| 3 | "What would you want me to have learned by the end of 90 days, and what would worry you at that point?" | Turns the A1 and A3 ramp plan into a shared target, and invites the manager to name the concern that is in their head |
| 4 | "What does agile delivery look like in practice for the two squads?" | F7 is a clarify area: asking is the honest version of a claim you cannot yet make |
| 5 | "How does partner feedback reach the roadmap today, and who runs that loop?" | Opens a natural place to state your sessions quote at its own scope, and tells you whether the role inherits a feedback process or builds one |
| 6 | "Is there anything about my background you would want me to address that we haven't covered?" | Lets the title concern surface where you can answer it with the A1 structure instead of leaving it unspoken |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: `prohibited_claims: "Having held a product manager title or role"` | "I haven't held a product manager title or role." Then "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" at its own scope |
| Having owned a product roadmap | Sourced: `prohibited_claims: "Having owned a product roadmap"`, and the acknowledge_gap area in uncertain_or_weak_areas | "I haven't owned a product roadmap." Then "Ran quarterly roadmap-input sessions feeding client evidence to product" at its own scope; the limit is the pack's observation that the material says the sessions, not who decided what |
| Having set prioritization for an engineering squad | Sourced: `prohibited_claims: "Having set prioritization for an engineering squad"` | "I haven't set prioritization for an engineering squad." Then a ramp plan, never a past |
| Shaping or influencing what product built | Inflated form of F3 | The sessions quote at its own scope. The limit is the pack's observation: the material says evidence was fed to product, not what product did with it. D2's slot asks only what you saw happen |
| Describing the integration work as product management experience | Inflated form of F1; the dossier's decision conditions also say the bridge is adjacent and never product management experience | The two quotes at their own scope, positioned as adjacent work |
| Having shipped an API or platform product | Inflated form of F4 | The integrations and playbook quotes at their own scope. The limit is the pack's observation: the material says integrations led through go-live, not a product released. A2's slot asks only which stages were yours |

## Sources

Provided documents: tuesday-dossier.md, version 1.1. Sections consumed: role_profile (requirements and responsibilities stand as the posting's lines; its unknowns are the underwriter's analysis and feed reverse questions only), handoff_to_mock_interview (verified_candidate_evidence, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims), and decision (context only). The dossier carries no evidence_map, evidence_state or risk_register, so those were not used. F1, F2 and F7 take their confidence and gap type from the dossier's uncertain_or_weak_areas; the other rows apply the same bands and gap types and are the pack's own grading.

Searches sent, all refused for lack of permission: "Quartzline company values", "Quartzline interview process product manager", "Quartzline API platform strategy news". No pages were fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Every call was refused. Would have fed a values cheat sheet; none is in this pack, and no values-style round is detected from your own description of the round |
| 2. Quartzline interview process, product manager | unavailable | Every call was refused. Would have checked the loop; persona weights rest on your description of one hiring-manager conversation and the relationship prior |
| 3. Quartzline strategy and recent news | unavailable | Every call was refused. Would have grounded B5 and a grounding brief; B5 is labeled generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative product manager JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access for company research, or a pasted values page, careers page or strategy brief → B5 moves from generic to grounded, and a values cheat sheet and grounding brief become possible
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → recent strategy, org context and loop reports for this company, once search is permitted
- The interviewer's name and title → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep email → any pre-declared focus areas or deliverables, which this pack currently assumes are absent
- Your answers to the slots in F3, F5, F6, F7, F8 and F9 → those rows move from discovery to quoted evidence and the matching guidance cells become story maps
- The agenda or notes from one roadmap-input session → F3 and D2 move from medium toward high confidence, because an inspectable artifact would stand behind the claim
- The raw CV behind the confirmed claims → every row quoted from the dossier can be checked against your own wording
- Hours you have before Thursday → a prep triage sized to them
