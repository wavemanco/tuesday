I'll read the reference files the skill points to before building anything.
I've built your pack and saved it. This is the hand-off.

Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-3-denied-447fcda7/stripe_product-operations-manager_interview_pack.md`.

I built it without knowing who you're meeting, so the persona weights are flat across all seven. All four web searches were refused (permission not granted), so the pack states nothing about Stripe's values, interview loop or strategy. You haven't shared a JD or CV, so the fit snapshot is a worksheet. It has 20 questions across seven interviewer styles, six reverse questions, and a coverage table.

The most valuable prep is B2, "Which part of this role would you be weakest at on day one?". It has the deepest rehearsal because it targets your biggest gap, which the pack can't see yet.

Say the word and I'll play the Skeptic on B2 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposes, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in this final round (hiring manager, peer, skip-level, cross-functional, or several back-to-back sessions), and did the recruiter name any focus areas or a deliverable such as a presentation or take-home? Your answer reweights every question bank.
2. Can you paste the JD and your CV, or a few lines on your relevant experience? I'll carry on without them, but with them the worksheet becomes a real fit snapshot built from your own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer and relationship: not given. Built on the assumption that the relationship is unknown, so persona weights are blended and flat. No JD and no CV were supplied, and no company research ran, so this pack is a structured worksheet plus generic rehearsal material. Nothing in it states a fact about Stripe.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores. Rehearse both.
- Types: VAL (behavior against published values), EXP (your work history under scrutiny), JD (the role's responsibilities), CO (company and strategy knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Where it says "selection scaffold", it tells you how to pick your own story. It never supplies one.
- The fit snapshot below is a worksheet. Write your own sentences into the Evidence column and ask me to regenerate the rows and the banks that draw on them.
- The highest-ROI prep in this pack is B2, "Which part of this role would you be weakest at on day one?". It gets the deepest rehearsal because it targets whatever your biggest gap turns out to be, which the pack cannot see yet.

## Fit snapshot (worksheet)

No background was supplied, so every evidence cell reads none given. The requirements are role-family patterns for a product operations role, written as plain prose and not quoted from any posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate cross-functional product launches so teams share one view of readiness (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a named launch, the teams involved, and what you personally decided or unblocked. Selection scaffold: pick a launch where at least two teams disagreed about readiness; if none comes to mind, say so plainly, then give the nearest coordination work your material does carry, or how you would handle it |
| F2 | Design and run operating processes and cadences such as planning, reviews and escalation paths (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed, who used it, and what you saw afterward. Selection scaffold: pick a recurring meeting or process you improved; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Define, track and report product or process metrics (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a figure you reported, how it was counted and which part was yours. Selection scaffold: pick one metric you reported and be ready to say how it was counted, what it is sensitive to and which assumption you would defend least; if none comes to mind, or you do not know how it was counted, say so plainly |
| F4 | Turn customer and field feedback into input for product decisions (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a feedback channel you used and a decision it informed. Selection scaffold: pick a time customer input changed a plan; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Improve tooling, documentation and workflows so they scale beyond one person (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a tool or document others kept using. Selection scaffold: pick something you built or improved that outlasted your attention to it; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Influence engineering, design, go-to-market and support partners without direct authority (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer team and how it ended. Selection scaffold: pick a time you needed another team to move without being able to direct it; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Communicate clearly to senior stakeholders in updates and decision requests (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is an update or decision request you wrote or gave and what it led to. Selection scaffold: pick one communication to senior people that changed an outcome; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

The relationship to the interviewer is unknown, and no loop source (a careers page, a candidate guide, or your own or a recruiter's description of the sessions) was read. So the fallback archetype is Generic, with flat weights. Each persona's likelihood below is a prior from a possible relationship, not a documented fact about Stripe's loop.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems about launches, metrics and process | Flat weight. Appears in the hiring-manager and skip-level priors, and a product operations role lends itself to live problems | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| B. Skeptic | Quiet probing of gaps and motivation | Flat weight. Hiring-manager prior. With no CV in hand the gap is unknown, which is why B2 carries the deepest rehearsal | Rehearse the weakest-on-day-one answer until it is boring. Bridges only from adjacent work you actually did, plus a ramp plan said as a plan |
| C. Values / Behavioral | Scenario probes on how you behave | Flat weight. Cross-functional prior. Its bank is short because no published values were in hand | Choose stories where you can say what you did. Use "we" for context and "I" for your contribution. Where no story fits, say so plainly |
| D. Peer Evaluator | Seam-splitting with adjacent teams, credit, collaboration | Flat weight. Peer prior | Reciprocity framing: what you bring their team. Propose seam principles instead of pretending to know the seam |
| E. Data-Driven Prober | Reads numbers to their assumptions | Flat weight. Peer prior | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| F. Pressure | Interrupts, time-boxes, plays devil's advocate | Flat weight. Skip-level prior | Pause, restate, hold a position through two follow-ups, concede specifically and never fold on the core |
| G. Conversational | Friendly, unstructured, still scored | Flat weight. Cross-functional prior | A pre-built 90-second arc. Treat casual questions as scored. Never answer "any questions?" with none |

## Question banks

Every question here is `[generic]`: with no JD, no CV and no company research, none rests on a quoted sentence of yours or a fact about Stripe. Each interviewer line below is an open prompt that asks you to choose an instance, or a live problem that assumes nothing about your past.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A new product is two weeks from launch. Engineering says it is ready, support says it is not, and a go-to-market team has already told customers a date. What do you do in your first two days?" | CASE | [generic] | Ask first: what does ready mean, what does slipping cost against shipping, who decides. Then state the objective, list who must be aligned, propose one shared readiness view and the first conversation you would have, name the metric you would watch, and name the main risk. Challenge one premise aloud, for example whether the date is fixed. The question needs no claim about your past, so the guidance makes none | Live version of F1's requirement. CASE because it scores structure, not history |
| A2 | "The share of launches going out on their planned date dropped 20 percent this quarter. Diagnose it." | CASE | [generic] | Clarify the definition and the denominator before anything else, and say you would check whether the measurement changed before assuming the process did. Segment by team, launch size and stage. State two or three hypotheses, the data that would separate them, and the first check. Do not invent numbers. The question needs no claim about your past | Live version of F3's requirement. CASE and not EXP because it tests reasoning over a number you did not produce |
| A3 | "You inherit a weekly product review that everyone says is a waste of time. What do you do?" | CASE | [generic] | Clarify what the review is for and who it serves. Gather evidence from attendees before changing anything. Propose a small change with a way to tell whether it worked, and name what you would not touch yet. The question needs no claim about your past | Live version of F2's requirement. CASE because it scores how you approach a process you did not design |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why product operations, and why now?" | JD | [generic] | Selection scaffold: one decision you made that moved you toward this work, what you are moving away from without disparaging it, and what you want next. Say it in your own words and keep it under a minute. If no single reason comes to mind, say so plainly, then give the nearest thing your material does carry | Motivation consistency is the Skeptic's core test. JD because it scores fit to the function |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Name the gap before it is asked for: look at your F rows where you wrote none given or found the thinnest evidence, pick the one you would least want probed, and say it plainly in your own words. Then give a ramp plan, said as a plan and never as a past. Hold through three follow-ups. First, how would that show up for the team. Second, what have you done about it so far; answer only with real steps, and if there are none, say so plainly. Third, why should we hire you with that gap; return to what your material does carry. Concede the limit specifically and do not widen it. Answer slot: if you have already started closing this gap, say what you did; if not, say so plainly and say what you would do in the first week | Aimed at the pack's biggest unknown. Without a CV this is the one prep that gets sharper the more of F1 to F7 you fill in. JD because it scores honest self-assessment against the role |
| B3 | "Product operations is often seen as overhead. Convince me this role pays for itself." | JD | [generic] | Name what you would measure, in terms of outcomes such as launch predictability or time to decision, before defending the role. Concede where overhead is a real risk and say how you would keep it small. The question needs no claim about your past, so the guidance makes none | Devil's-advocate framing of F2's requirement. JD because it tests whether you can define the role's value |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where the truth actually landed, with a named stake, what you said, and the relationship still intact after. Use "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 and F7 both draw on this. VAL because it scores behavior, though Stripe's published values were not in hand and this pack cannot map it to them |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision with a named customer need, the metric you set aside, and what you did about the cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4's requirement. The only question in this pack on customer input, so it carries that coverage |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and mine, and what happens when we disagree?" | CASE | [generic] | Offer seam principles instead of claiming to know the seam: who owns the decision, who owns the follow-through, and how a disagreement gets raised early. Say you would ask them how they see the seam before proposing yours. The question needs no claim about your past | F1 and F6 at the boundary. CASE delivery of a collaboration question |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a piece of cross-team work where credit could have gone unevenly, and say what you did about it. Use "we" for the whole and "I" only for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6. VAL because it scores partnership behavior |
| D3 | "What would you need from me in your first month, and what can you bring my team?" | JD | [generic] | Lead with what you would bring the peer's team, then what you would need. Keep both to things you can truthfully offer, and name a way to find out what the peer's team needs. The question needs no claim about your past | Reciprocity question. F6's requirement from the peer's side |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a metric you have been responsible for reporting. Walk me through how it was counted." | EXP | [generic] | Selection scaffold: pick one metric and be ready to answer four things in your own words: how it was counted, what it is sensitive to, which assumption you would defend least, and which part was yours. Name the weakest assumption before they do. If you do not know how it was counted, say so plainly. If no such metric comes to mind, say so plainly, then give the nearest thing your material does carry | F3. EXP because it tests whether a figure survives scrutiny, which no pack can rehearse for you without the figure |
| E2 | "How would you decide whether a process change actually worked?" | JD | [generic] | Name a baseline, a comparison, a check on what else changed at the same time, a counter-metric, and a time window. The question needs no claim about your past | F2 and F3 together. JD because it scores the role's judgment, not your history |
| E3 | "Launch data lives in three systems and they disagree. What do you do?" | CASE | [generic] | Clarify which numbers disagree and by how much. Find where the definitions differ before assuming error. Agree one source of truth with the people who own each system, and say what you would report in the meantime and with what caveat. The question needs no claim about your past | F3 and F5. CASE because it is a live problem |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give two reasons in your own words, each one a thing you did and can be asked about. Do not criticize internal candidates. If a second follow-up pushes, hold the position and concede only what is true. If you cannot yet name two reasons, say so plainly and use your F-row evidence to find them | F7's spoken form. JD because it scores fit to the role under time pressure |
| F2 | "Pick the project you are proudest of. How much of it was actually you?" | EXP | [generic] | Hold-then-concede. Say what you did in your own verbs, then what others did, then the part you are least sure was yours. Hold the core through two follow-ups, then concede specifically. Answer slot: if part of it was someone else's, say so plainly and return to the part that was yours | Attribution probe. EXP because it tests the honesty of your own claim |
| F3 | "I am not convinced product operations is more than project management. Change my mind in two minutes." | JD | [generic] | Define the difference in outcomes you would own, concede where the two overlap, and give one example of a decision a project manager would not own. Keep it to the role, not your history. The question needs no claim about your past | F2's requirement under challenge. JD because it scores whether you understand the function |

### G. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Selection scaffold for a 90-second arc: where you started, the one or two moves that mattered and why you made them, and why this role is next. Build it from your CV in your own words. If a move has no clear reason, say so plainly | F7's spoken form. EXP because it is the CV told aloud and the pack has none yet |
| G2 | "What has caught your eye about where we are headed, and where does product operations fit?" | CO | [generic] | The pack could not research Stripe, so it supplies no company fact. Do a short read of Stripe's own published material and bring two things you actually read: one current priority and one implication for product operations. Say plainly where you are inferring. If you have not done the reading, say so and ask the interviewer how they see it | The one CO question. It is `[generic]` because no strategy research ran, so it is more valuable once the search permission in the upgrade menu is granted |
| G3 | "What would a great first 90 days look like to you?" | JD | [generic] | Give a plan, never a past: listen and map first, pick one process or measure to improve with partner agreement, and agree how you would report progress. The question needs no claim about your past | F1 and F2 as a plan. Casual register, still scored |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Launch coordination | A1, D1, G3 |
| F2 Operating processes | A3, B3, E2, F3, G3 |
| F3 Metrics | A2, E1, E2, E3 |
| F4 Customer and field feedback | C2 only. One question because no raising source asked for more |
| F5 Tooling and workflows that scale | E3. No further question: none was raised by a source |
| F6 Influence without authority | C1, D1, D2, D3 |
| F7 Senior communication | F1, G1, C1. None tests written communication: a spoken round may not, and if a writing exercise is announced, send it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does product operations own here that no one else does, and what is deliberately not its job?" | Shows you think in boundaries, and gives you the seam principles D1 asks for |
| R2 | "How is success in this role measured at six months, and who decides?" | Shows you want a measurable bar |
| R3 | "Where do product teams and the teams around them disagree most, and where does this role sit in that?" | Shows you are looking for the real problem, not the job description |
| R4 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, and it works with a peer. It reverses the usual direction |
| R5 | "What is one launch or process that went worse than you wanted recently, and what changed afterward?" | Invites an honest story and shows you are comfortable with imperfect work |
| R6 | "What would you want a new person to have changed by the end of their first year?" | Surfaces what the team actually hopes the role will fix |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any project, figure, launch, process, tool or outcome as yours | No candidate material was supplied, so the pack has no sentence of yours to rest one on | Selection scaffolds that end in the honest branch. Your own sentences go into the F rows and the pack regenerates from them |
| Any fact about Stripe's values, loop, strategy or products | Research did not run, so none was established | G2's instruction to read Stripe's own published material and bring only what you read |

No inflated-form entries are listed, because there is no quoted sentence of yours for a requirement to widen.

## Sources

Provided documents: none. The only inputs were the company, the role title and the round type, as stated in your message.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Every search was refused (permission not granted), so no results came back.

| Query | Outcome |
|---|---|
| Stripe operating principles values | refused |
| Stripe interview process Product Operations Manager | refused |
| Stripe strategy news 2026 annual letter stablecoins agentic commerce | refused |
| Stripe Product Operations Manager job description | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have supplied the values cheat sheet and mapped VAL questions. Without it, no values-style round is detected and the C bank is short |
| 2. Stripe interview process, product operations | unavailable | Would have set the loop structure and persona weights. Without it the archetype is Generic and weights are flat |
| 3. Stripe strategy and recent news | unavailable | Would have grounded G2 and the CASE bank in current priorities. Without it they are `[generic]` |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the F rows into quoted `[inferred]` requirements. Without it they are `[generic]` prose |

## Upgrade menu

- Search permission, then a deeper pass if you want it (up to 6 more searches and 2 more fetches, several more minutes) → Stripe's published values and a values cheat sheet, documented loop structure, current strategy for G2 and the CASE bank, and a representative JD that turns the F rows into quoted requirements
- Your CV, or a few lines on relevant experience → the worksheet becomes a real fit snapshot with your quotes, selection scaffolds become story maps, B2 aims at your actual gap, and the prohibited list fills in
- The JD text → the seven `[generic]` rows become `[grounded]` quotes, and JD-tagged questions can raise answer slots
- Who you are meeting and in what round, or, if your final is several sessions, the schedule → persona weights stop being flat, and per-session mini-packs become possible
- The recruiter's prep email → coverage of any pre-declared deliverable such as a presentation or take-home
- The interviewer's name → an interviewer read and a reverse question tied to their public path
- How much prep time you have → a prioritized schedule
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence, the objection worth the deepest rehearsal, and absolute prohibited claims, in place of the inferred ones here
