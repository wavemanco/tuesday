I'll read the reference files before building the pack.
Web search was refused, so I'm building the pack from what you gave me and labeling it accordingly. Writing the file now.
Your prep pack for all three rounds is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-6-denied-07857b9c/larkfield-systems_engineering-manager_interview_pack.md`.

I built it as a loop. It has one shared fit snapshot and prohibited-claims list, then a mini-pack for each round: persona weights, 9–11 questions, and reverse questions. The prep triage is sized to your two weeks.

It rests on two assumptions:
- **Thursday's staff engineers:** I assumed they sit outside the squads you'd lead.
- **Company facts:** web search was refused in this session, so the pack has no Larkfield research. The three searches I tried are listed as refused in the Sources section. The company-strategy questions are labeled generic, and there is no values cheat sheet.

The highest-ROI prep is A1, the Tuesday "weakest part on day one" question, where you name the hardware-roadmap gap yourself before they do.

Say the word and I'll play the hiring manager on A1, or any other persona or question you pick.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do the two Thursday staff engineers sit inside the squads you'd lead? If they do, I'll reweight that bank toward what they'd need from a manager.
Did the recruiter say anything about Tuesday's or Thursday's format beyond what you told me, such as a case, a presentation or a take-home? An announced deliverable would get its own build section.
Can you paste the full job description and your CV, or say skip and I'll stay with your summary? The pack's evidence currently rests on four sentences from your message.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack — Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Role as described: "Engineering Manager — Larkfield Systems (industrial IoT, ~600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap."

| Round | When | Who | Relationship to you |
|---|---|---|---|
| 1 | Tuesday, 45 min | Director of Engineering, the hiring manager | Your would-be boss |
| 2 | The Thursday after, 60 min | Panel: two staff engineers and a product manager | Peers and a cross-functional partner. Assumed: the staff engineers sit outside the squads you would lead; if they sit inside them, bank E shifts toward what they would need from a manager |
| 3 | The following Monday, 30 min | VP Engineering | Skip-level; described by the recruiter as "values and leadership philosophy" |

This is a first version. Web research was not available in this session (see Sources), so company facts are absent rather than guessed, and every question about the company's strategy is `[generic]`.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: every sentence about your past comes from something you wrote, and anything the pack could not know is an answer slot for you to fill in your own words. A slot has two honest branches, and "that was not mine" or "that did not exist" is a fine answer.

Type key:

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows values or leadership philosophy, not generic virtue |
| EXP | Whether claims about your work survive scrutiny and attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, scored on structure and reasoning |

## Prep triage (two weeks, three rounds)

1. Before Tuesday: say A1 aloud until it is boring. Then settle, in your own words, what was yours and what was the team's in your reliability story, because A4, C1, P1, G1, I2 and J2 all draw on it.
2. Before Tuesday: write your own answers to the slots in fit rows F1, F2, F4 and F6 above. Each takes a few minutes and each is a likely probe.
3. Before Tuesday: rehearse C1 and C2, the two numbers. "I don't know how it was counted" is acceptable where true.
4. Between Tuesday and Thursday: practice one case structure on B1, E4 and P3, out loud. Clarify, objective, options, risks.
5. Weekend before Monday: I1 and I2 are the core of the VP round; J1 and J2 are the composure drills.

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description you gave me. Evidence is four sentences of yours, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material says a team lead of 6 at a payments company, and the words stay there: "9 years engineering, 3 as a team lead of 6." It does not show two squads or device-management work. Answer slot: the role names two squads, so expect a probe on whether any of your leading covered more than one team; if it did, say which and which part was yours, and if it did not, say so plainly and stay with the team of 6. Second slot: the role names device-management services, so expect a probe on the nearest work you have touched; say what it was in your own words, and if none is near, say so plainly and say how you would ramp |
| F2 | "own delivery" — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material says you pushed a reliability quarter through, and the words stay there: "I pushed a reliability quarter through against roadmap pressure." It does not show what else you were accountable for delivering. Answer slot: expect a probe on what you were accountable for delivering; if something was yours, say what and how you answered for it, and if it was shared or set elsewhere, say so plainly and stay with the reliability quarter |
| F3 | "hiring and growth for 11 engineers" — hiring half, role description, your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap on the hiring half, but a line with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms: "I run our hiring loop for backend roles." The figure raises the defend-the-number slots only: how the 40 was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F4 | "hiring and growth for 11 engineers" — growth half, role description, your message | none given | none | [grounded] | discovery | Your material says nothing about developing engineers, so there are no words to give you and the pack makes none. Answer slot: the role names growth, so expect a probe; if you have helped an engineer grow, say who in general terms and what was yours, and if you have not, say so plainly and say how you would start |
| F5 | "partner with hardware and product on roadmap" — hardware half, role description, your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Never a claim to hardware roadmap work, and nothing added to make the gap feel smaller |
| F6 | "partner with hardware and product on roadmap" — product half, role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The phrase "against roadmap pressure" touches the product half without showing who the pressure came from or whether product partners were part of it. Answer slot: the role names product partnership, so expect a probe; if product was part of that conversation, say how you made your case and what was yours, and if the call was made elsewhere or there was no such conversation, say so plainly and stay with "I pushed a reliability quarter through" |

The role description as you gave it does not mention managing managers. The sentence about it is in your message, so it is carried as your stated limit in the prohibited list and in A1, not as a requirement.

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 two squads, device-management services | A2, A3, B2, P3, J1 |
| F2 own delivery | A4, B3, P1, I2, J2 |
| F3 hiring | C2, P2, I3 |
| F4 growth | B2, D2, G2 |
| F5 partner with hardware | A1, B1, E4, P3 |
| F6 partner with product | A4, E1, E2, E3, E4, G1 |

## Prohibited claims

Built before the banks. Nothing in this pack coaches these, and no answer slot names them as something to claim.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F5 | The plain acknowledgment from your own sentence: "I've never managed managers." No slot. The role description as given does not raise it, so it is not asked about |
| Has owned or shaped a hardware-adjacent roadmap | Negative you stated, F5 | "I've never owned a hardware-adjacent roadmap." Then a ramp plan said as a plan. No slot |
| Has led two squads, or a team of 11 | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6." The limit is the pack's observation: the material says a team of 6, not two squads. B2 and A2 stay inside that scope |
| Owned delivery across a roadmap | Inflated form of F2 | F2's quote at its own scope: "I pushed a reliability quarter through." The material says one quarter, not delivery as a standing responsibility |
| Cut on-call burden by 60% yourself | Inflated form of F2 | The sentence says the burden dropped after you pushed, and the words stay there. The material does not say how the drop was counted or what caused it |
| Hired about 40 people, or personally conducted 40 interviews | Inflated form of F3 | "I run our hiring loop for backend roles." The material says 40 interviews, not whose or what they counted |

## Round 1 — Tuesday, Director of Engineering (hiring manager)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet probing of the gaps: day-one weakness, scale, why this domain | Highest. A hiring-manager round prior is Case plus Skeptic, and F1 and F5 give a Director of Engineering real gaps to price | Rehearse A1 until it is boring; name the limit before it is asked for; hold, then concede specifically |
| Case / Strategist (bank B) | Live problems from the role: a hardware dependency slips, a first-60-days plan, quarter planning | High. Same prior; the role description is built around roadmap partnership with hardware and product | Clarify, objective, options, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (bank C) | Reads the lines closely and asks how the numbers were counted | Medium. A boss who reads closely will find the two figures in F2 and F3 | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| Conversational (bank D) | Biography and growth questions in a friendly register | Medium-low. Opening arc plus a growth question the role names; casual does not mean unscored | A 90-second arc built from your own sentences; do not answer "I think you've covered everything" in the reverse slot |

### Bank A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI prep in this pack: this question arrives in some form in a boss round. Name it yourself before they do, in your words: "I've never owned a hardware-adjacent roadmap." Then your plan, said as a plan: the first two things you would do to learn it, in your own words. Follow-up 1, how would you close it: hold on the plan. Follow-up 2, what if the first thing you try does not work: concede that you do not know, specifically, and name what you would do next. Follow-up 3, why take the risk on you: return to what your own sentences carry, never to something added. Keep the limit named the whole way; do not volunteer "I've never managed managers" unless the conversation reaches it | F5 is your largest stated gap and the one a boss will price first. JD because it scores the stated role; the Skeptic delivery is why it sits here |
| A2 | "You've led a team of 6. This role covers two squads and 11 engineers. What changes at that size?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Start from the sentence at its own scope: "3 as a team lead of 6." Answer slot: if any of your leading covered more than one team, say which and which part was yours; if it did not, say so plainly and stay with the team of 6. Then say, as a question-shaped answer, what you would want to find out about each squad before changing anything | F1 is the gap between the scope you described and the scope the role names; the premise is built from your own sentence and the role's |
| A3 | "You come from payments. Why device management, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | This is a motivation question and your reasons are yours. Selection criteria: one reason tied to something in the role itself, said in your own words, that you could follow with the first thing you would want to learn. If no reason beyond the role comes to mind, say so plainly and say what you are looking for in your next role. Do not claim domain familiarity your material does not show | F1's domain half is the likeliest place a Director of Engineering tests motivation; the Skeptic's "why here, why now" stem |
| A4 | "Tell me about a time you pushed back on roadmap pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the sentence, and it has these beats: a reliability quarter, roadmap pressure, you pushed it through, the on-call burden dropped afterwards. Tell them in your own words. Answer slot: the role names product partnership, so expect a probe on who the pressure came from and how the case was made; if product was part of that conversation, say how you made it and what was yours, and if the call was made elsewhere or there was no such conversation, say so plainly and stay with the quarter. Also name what the quarter cost, if anything did; if nothing did, say so | F6 is the evidence for the product-partner requirement and thin on its own; EXP because it tests what was actually yours |

### Bank B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A hardware team tells you a firmware change will slip by a quarter, and one of your squads has promised product a date that depends on it. Walk me through your next week." | CASE | [generic] | Structure it. Clarify first: what exactly is slipping, who depends on it, what is fixed. Objective. Options: re-scope, re-sequence, renegotiate the date, a partial delivery. Who you would bring in and when. What you would tell product and what you would not yet commit to. What you would watch. The question needs no claim about your past, so the guidance makes none | A live problem built from the role's hardware-and-product line (F5, F6) and asked as a decision; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "You've just taken on two squads and 11 engineers. What do you do in your first 60 days?" | CASE | [generic] | Principles before plans: listen first, learn how each squad works and what each is accountable for, meet the partners, then decide what to change. Say what you would ask each engineer, and what you would not change until you understood it. Claim nothing about having done this; the structure carries it | F1 and F4 in one live prompt; CASE because the Director of Engineering is scoring structure and humility over a plan |
| B3 | "Sketch how you would decide what the two squads work on next quarter. What do you need to know first?" | CASE | [generic] | Clarify, objective, inputs (what product needs, what hardware dates constrain, what the squads' own health needs), a decision rule, metrics, risks. Challenge one premise respectfully. No claim about your past is required | F2, own delivery, as a live problem; Case stem; `[generic]` because the pack has no information on how these squads plan |

### Bank C — Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 60% figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the sentence at its scope: the burden dropped after you pushed. Answer slots only: how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours; each in your own words. If you do not know how it was counted, say so plainly. Do not say the reliability work caused the drop unless you can say how you know | The headline figure on your background is a magnet for a prober (F2); EXP because the score is attribution |
| C2 | "You said you run the hiring loop for backend roles, about 40 interviews last year. How was that number reached, and which part was yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say the first half in its own words: "I run our hiring loop for backend roles." Answer slots: what the 40 counted, whether those were interviews you conducted or interviews across the loop, and which part was yours; if you do not know how it was counted, say so plainly | F3's figure; the question asks only the defend-the-number slots |

### Bank D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc, told in your own words and built from sentences you have written: the years of engineering and the stretch as a team lead of 6; the hiring loop you run; the reliability quarter. Then your own reason for this role, which the pack cannot supply. Stop at 90 seconds | The biography question is scored even when it feels casual; JD because the arc should land on the role |
| D2 | "Tell me about an engineer you helped grow." | JD | [grounded] | Selection criteria, because nothing you wrote carries this: one named situation, what you did specifically, and what changed for them afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it. Do not describe growth work your material does not show | F4 is thin and the role names growth, so a boss will ask; JD because it scores the stated requirement |

### Reverse questions — Tuesday

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make the first six months a clear success in this role, and how will you and I know?" | Turns the round into a conversation about expectations with the person who will judge you, and gives you something to calibrate against |
| R2 | "How are the two squads structured today — is there a lead or senior engineer in each, and how do you see this role working with them?" | The role says 11 engineers; the answer tells you whether leading leads is part of the job, which your own stated limit makes worth knowing |
| R3 | "How do the squads and the hardware team plan together today, and what would you change?" | Signals you are thinking about the seam you have said you have not owned, as a learner |
| R4 | "What does the hiring plan for the group look like, and what is the bar you want?" | Ties to the hiring loop you run and lets you hear their bar |
| R5 | "What do you most want to be different about how this group delivers a year from now?" | A boss's honest answer here is the real brief for the role |

## Round 2 — Thursday, panel (two staff engineers and a product manager)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (bank E) | Seam-splitting between engineering, product and hardware; what a manager would need from them; credit and disagreement | Highest. Panel rule: blend the top two personas of each member's relationship; the staff engineers and the product manager all price what the hire costs and contributes to their work | Reciprocity framing: what you bring their work, not only what you need; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober (bank P) | Staff engineers checking your technical credibility on your own stated work | Medium-high. Staff engineers are the likeliest to dig into the reliability story and the hiring bar | Know what you can and cannot say about how each claim was reached; say plainly when you do not know |
| Values / Behavioral (bank G) | The product manager's scenario probes on disagreement and hard conversations | Medium. A cross-functional member prior; no published values were in hand, so these are themed by the role's partnership line | "We" for context, "I" for contribution; choose stories where the hard truth landed, and where your material shows none, say so |

### Bank E — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where does engineering end and product begin on a roadmap decision, and what happens when we disagree?" | JD | [generic] | Offer seam principles rather than pretending to know their seam: who owns the what and the why, who owns the how and the when, how a disagreement is escalated and how it is recorded. Then reciprocity: what you would try to make easier for them. No claim about your past | F6 as a collegial probe; the seam question is the Peer stem; `[generic]` because the pack has no information on how this company splits it |
| E2 | "Tell me about a time you and a product partner disagreed on priorities." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Open prompt on the role's product-partnership line. Answer slot: the roadmap pressure in your sentence may or may not have come from product; if it did and you argued it with them, say what you said and what was yours; if it came from elsewhere or you did not argue it, say so plainly and use another time. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6; VAL because it scores disagreement style with an equal |
| E3 | "How do you handle credit when work spans engineering and product?" | VAL | [generic] | Selection scaffold: a principle (name the people who did the work, say we for context and I for what you did), then one instance in your own words. If no instance comes to mind, say so plainly and say how you would handle it. The pack supplies no instance | The Peer credit stem; `[generic]` because nothing you wrote speaks to it |
| E4 | "Product wants a date for a feature that depends on a hardware release you do not control. What do you tell them?" | CASE | [generic] | Clarify what is known and what is not; separate what you can commit from what you cannot; give a range and name the dependency; say what you would watch and when you would update them. No past is claimed | F5 and F6 as a live problem the product manager can score directly |

### Bank P — Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through that reliability quarter." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say what the sentence says, in order: a reliability quarter, roadmap pressure, you pushed it through, the burden dropped after. Answer slot: staff engineers will ask what was in it and who chose it; if you chose what went in, say how, and if it was set elsewhere or by the team, say so plainly and stay with "I pushed a reliability quarter through." Also say which part was yours | F2 and the defend-the-number probe in a technical register |
| P2 | "How do you decide what a good engineer looks like when you interview?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start from "I run our hiring loop for backend roles." Answer slot: if you designed or changed the loop's structure or its bar, say what and why in your own words; if the loop was inherited, or you only ran it, say so plainly and stay with the loop you run | F3; staff engineers care about the bar the manager sets |
| P3 | "Suppose a device-management service starts failing updates on a few percent of devices. What do you ask first?" | CASE | [generic] | An engineering manager's structure, not a debugging session: scope (which devices, since when, what changed), triage versus root cause, who is needed, how you would communicate, what you would ask the on-call. Say what you do not know about the domain, plainly | F1's domain half and F5's hardware seam as a live prompt; `[generic]` because the pack has no information on this stack |

### Bank G — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Open prompt from the Values stem. Answer slot: the pressure in your sentence may or may not have involved leadership; if you went to leadership and the hard truth landed, say what you said and what happened; if it did not involve them, say so plainly and use another time. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 and the Values stem; a product manager will weigh how you handle a hard conversation |
| G2 | "What do you do when someone on your team is struggling and the roadmap cannot wait?" | VAL | [generic] | Principles, not a story: notice early, talk to them directly, decide what support and what scope change help, protect the roadmap by naming the trade-off, follow up. Claim nothing about having done it; if an instance comes to mind, say it in your own words | F4 as a hypothetical; `[generic]` because nothing you wrote speaks to it |

### Reverse questions — Thursday

| # | Question | Why it lands |
|---|---|---|
| R6 | "What could a new engineering manager do in their first month that would genuinely help your work?" | Reciprocity for peers; shows you are thinking about what you add |
| R7 | "Where do technical decisions across the two squads get made, and where does a manager's call end and a staff engineer's begin?" | Seam between you and the staff engineers, asked as a working question |
| R8 | "How does product learn about hardware constraints today, and how early?" | Directed at the product manager; surfaces the seam in their terms |
| R9 | "How does on-call work for the squads today?" | A neutral question that gets the group's reliability picture without presupposing one |
| R10 | "What did the last person to join this group wish they had known?" | Invites a candid answer and signals you plan to learn quickly |

## Round 3 — Monday, VP Engineering (values and leadership philosophy)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (bank I) | Leadership philosophy and scenario probes | Highest. The recruiter described the round as values and leadership philosophy, which is a loop source naming a values-style round; no published values were in hand | One view stated plainly, with an example and its cost; "we" for context, "I" for contribution |
| Pressure (bank J) | Time-boxed challenges, "how much was actually you" | Medium-high. Skip-level and executive prior; 30 minutes rewards composure | Pause; restate; hold through two follow-ups; concede specifically |
| Conversational (bank K) | Opening, motivation, "tell me about your team" | Medium. A leadership-philosophy conversation often opens warmly | Prepared arcs; casual questions are scored |
| Case / Strategist (bank L) | A strategy or prioritization question at VP altitude | Low-medium. Skip-level prior, tempered by the stated focus; with no research the strategy question stays generic | Hypotheses and questions, never recitation |

### Bank I — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "What's your leadership philosophy?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The philosophy is yours and the pack does not write it. Shape: one sentence stating the view; one example from your own words, which may draw on the sentences you have written; one sentence on what the view costs. Do not let the example say more than your sentences do | The recruiter's stated focus makes this likely; the structure keeps it from becoming a slogan |
| I2 | "Tell me about a time you put a team's long-term health ahead of a short-term deadline." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the sentence: roadmap pressure, a reliability quarter, you pushed it through, the on-call burden dropped afterwards. Answer slot: a VP will ask what you gave up and who was unhappy; if something was given up, say what, and if nothing was, say so plainly. Land the hard truth in your own words | The leadership-philosophy focus plus F2's story; the most likely place for this round to test it |
| I3 | "Tell me about a hiring decision you stood behind when others disagreed." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slot: if a disagreement arose in the loop and the call was yours, say what the disagreement was and how you decided; if there was none, or the call was not yours, say so plainly and stay with "I run our hiring loop for backend roles." Do not describe a hire you cannot name | F3 and the role's hiring line; VAL because the VP scores judgment under disagreement |
| I4 | "When have you changed your mind about how to lead a team?" | VAL | [generic] | Selection criteria, because nothing you wrote carries it: a specific belief, what changed it, what you did differently afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A leadership-philosophy probe about growth in your own practice; `[generic]` because the material is silent |

### Bank J — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Sixty seconds: why you, for two squads, with a team of 6 behind you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Pause, restate, answer. Hold on the sentence: "3 as a team lead of 6." Concede specifically and in your own words that the scope is wider than what the sentence carries, and say what you would learn first. If you have led more than one team, say so plainly; if you have not, say so. Do not argue the scale away | F1 under time pressure; hold-then-concede on what the sentence carries |
| J2 | "That reliability result — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold at the sentence's scope: "I pushed a reliability quarter through." Concede what the sentence does not say: what was the team's, and, if you do not know how the figure was counted, say so plainly. Never say you cut the burden by 60%; say what dropped and what you did | The Pressure stem aimed at F2 |

### Bank K — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "What's drawing you to industrial IoT?" | JD | [grounded] | Your reason is yours and the pack does not supply it. Selection criteria: one thing about this kind of work you can say in your own words and follow with something you would want to learn. If no reason beyond the role comes to mind, say so plainly and say what you are looking for | The role's domain; casual register, still scored |
| K2 | "Tell me about the team you lead now." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot: describe the team, what they are good at, and how you lead them, in your own words; the sentence gives only that it is a team of 6. Do not describe their work in the role's terms | A VP who asks about your leadership philosophy often asks about the people who see it; F1 |

### Bank L — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "What do you think matters most for an engineering org of around 600 people in industrial IoT over the next two years?" | CO | [generic] | Research was unavailable, so keep this at the level of hypotheses and questions: what you would want to learn about the company's customers, hardware cadence and reliability expectations before forming a view. State a hypothesis, label it as one, and ask what the VP sees. Do not cite company facts | CO is the differentiator type, and the pack cannot ground it without research; `[generic]` for that reason |
| L2 | "You have capacity for one thing next quarter: reliability work, a hardware-integration feature, or a hiring push. How do you choose?" | CASE | [generic] | Clarify what is known, state criteria, name the decision rule, say who you would consult, and what you would tell the squads. Name the trade-off you are making. The question needs no claim about your past | F2 and F4 as a prioritization problem at VP altitude |

### Reverse questions — Monday

| # | Question | Why it lands |
|---|---|---|
| R11 | "What does leading well look like in this engineering org — what do you see managers here do that you would want more of?" | Mirrors the round's stated focus and asks for the VP's own philosophy |
| R12 | "Where do you see the biggest leadership stretch for the org in the next year?" | Shows altitude; answers what the role is really for |
| R13 | "How do you want managers to handle a conflict between a product date and engineering health?" | Lets you hear the VP's own position on the trade-off you will be asked about |
| R14 | "How does the org grow its managers — what does support look like for a new manager?" | Ties to the growth half of the role |
| R15 | "What would you want a new manager's first ninety days to show you?" | Gets the VP's bar in their own words |

## Sources

Provided documents: your message — the role description, the three rounds and who runs them, the recruiter's description of the VP round, and four sentences about your background. No JD text, CV, interviewer names, recruiter email or `tuesday-dossier.md` was provided.

Searches sent, all refused (this session had not granted web search):

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems engineering manager interview process" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Every call was refused. It would have fed the values cheat sheet and the VAL themes; the cheat sheet is dropped and bank I rests on the recruiter's stated focus |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Every call was refused. The loop here comes from your own description of three rounds and who runs each, so persona weights follow it; a documented loop would have added case formats and scoring |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Every call was refused. The CO and CASE questions are `[generic]` for that reason |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so no query could be formed; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | The role description you gave me fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text → the requirement quotes become exact, and any requirement the summary dropped gets a question; the F rows currently quote your summary
- Your CV → the F rows' evidence now rests on four sentences from your message; CV lines could move F1, F2 and F6 and settle where the domain gap is real
- Your answers to the slots in F1, F2, F4 and F6 → those rows regenerate on your own words, and the guidance that draws on them gets sharper
- The pager or incident dashboard export behind the on-call figure → C1's evidence could move from `medium` to `high`
- The interview scorecard or rubric for your backend hiring loop → F3 could move from `medium` to `high`
- The interviewers' names and titles → persona weights read from their public footprint, and a reverse question tied to each person's own path
- The recruiter's prep notes for Tuesday and Thursday → coverage of any announced case, presentation or take-home, which would get its own build section
- Larkfield's published values or careers page, pasted → the values cheat sheet for Monday, and VAL questions themed by name
- Web search access, or a pasted strategy brief → the CO and CASE questions become `[grounded]`; with search working, a deeper research pass is available — up to 6 more searches and 2 more fetches, several more minutes
- A `tuesday-dossier.md` → verified evidence, a named highest-objection and absolute prohibited claims from an underwriting pass; the pack stands without it
