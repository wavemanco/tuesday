I'll read the reference files the skill points to before building the pack.
Your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md`. It has 19 questions across six personas, a fit snapshot of the JD against your background, reverse questions, and a list of claims it won't coach.

I assumed Tobias is your future manager, so the banks lean on live case problems and Skeptic probing. All four web searches I tried were refused, so nothing comes from outside your JD and your message. There are no Saltmarsh-specific questions, no values sheet and no interviewer read.

Your two stated limits, never led a team and never worked on a game with in-app purchases, are in the pack as plain acknowledgments, not things to bridge over. B1, the in-app-purchases question, is the one to rehearse first. The thinnest JD match is "own the post-event review and the KPIs it reports". Your material shows presenting retention numbers, not owning a review.

Say the word and I'll play the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. I can convert the pack to a Word document if you want one.

What did the recruiter say about the round: is Tobias your future manager, and is there a focus area or prep task? Either answer reweights every bank.

Do you want a deeper research pass on Saltmarsh and Tobias, up to 6 more searches and 2 more fetches and several more minutes? It needs search access to be allowed this time, or you could paste their values page and any recent press instead.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: one 60-minute interview, Friday. Relationship assumed to be the hiring manager; you have not confirmed it, and the persona weights below say what changes if it is wrong.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did. An answer slot is an instruction for the interview, not a question for me.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. None in this pack: no published values are in hand |
| EXP | Whether the claims in your background survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company's strategy and market. None in this pack: company research did not run |
| CASE | A live problem from the role, scored on structure and reasoning |

Highest-ROI rehearsal in this pack: B1, the in-app-purchases question. It is aimed at a limit you named yourself, so it is the objection most likely to arrive in some form. Rehearse it until it is boring. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." The JD says live-events calendar and two titles, so expect a probe on both. Answer slot: the JD calls it a live-events calendar and your sentence says content-drop calendar. If the two were different things in your work, say plainly how, in your own words; if they were the same, say that. If the two-title scope comes up, say plainly that the calendar you ran was for the main title |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Derivation: the calendar sentence touches this requirement without showing which teams the drops involved. Answer slot: the JD names four teams, so expect a probe on who you worked with. Say which of them you worked with on the drops and what you needed from each, in your own words; if you did not work with one, or the drops did not run that way, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the numbers, and the words stay there: "I presented the monthly retention numbers to the studio head." The pack's observation is that the sentence does not show a review or a share in defining the numbers. Answer slot: expect a probe on what happened after you presented them. If anything followed from them, say what; if nothing did, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | The words stay at "I wrote the release checklist our QA team still uses." The sentence says wrote and still uses; it does not show who took each release through it. Answer slot: expect a probe on how the checklist is used. Say what it covers and what you know of how QA uses it; if you cannot say, say so plainly and stay with the sentence |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years and the studio are stated; whether the main title was run as a live-service game is not. The JD says producing and your title says associate producer, so expect a probe on both. Answer slot: if the title was run as a live-service game, say so in your own words; if it was not, say so plainly and stay with the four years and the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The closest match in your material. Lead with the quote's own terms, weekly cadence, main title, two years, because a named cadence beats an adjective. Nothing is inspected behind it, so expect a probe on it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | Lead with "I presented the monthly retention numbers to the studio head": monthly, and to a named audience. Nothing is inspected behind it, so expect a probe on how the numbers were counted. Answer slot: say how they were counted if you know, what they were sensitive to, and which part was yours, in your own words; if you do not know how a figure was counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | Derivation: the checklist is writing you did, and the material does not show what else you have written or who read it. Answer slot: if you have another piece of writing you can point to, say what it was and who read it; if not, say plainly that the checklist is the writing you have to point to |
| F9 | Leading a team: not a JD line, raised by you — your message | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "Never led a team." Then how you would learn to move people you do not manage, said as a plan and never as a past. The pack's observation is that the JD says coordinate, not lead, and coordinating is not leading. Nothing is added to make the gap feel smaller |
| F10 | Working on a game with in-app purchases: not a JD line, raised by you — your message | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "Never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The pack's observation is that the JD names mobile titles and KPIs but not in-app purchases, so how hard this is probed depends on the titles, which your material does not show |

## Persona table

Weights: the relationship prior for a hiring-manager round, assumed. No interviewer signals were available. Loop: your message establishes one 60-minute conversation with Tobias and does not say what it holds, so the fallback archetype is Generic and I applied no tilt from it. If Tobias is not your future manager, the Skeptic weight drops and the Peer weight rises.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist (5 questions) | Live problems from the role: build the calendar, diagnose an event that is underperforming, handle a blocked release | High. It is a hiring-manager prior, and the JD is made of planning, running and reviewing, which is case material | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| B. Skeptic (4) | Quiet probing of the gaps and of the distance between one puzzle title and two mobile titles | High. It is the second hiring-manager prior, and you named two limits yourself (F9, F10) | Rehearse B1 until it is boring. Use the quotes at their own scope and give the limit plainly |
| C. Data-Driven Prober (3) | Line-by-line questions on the retention numbers and what you did with them | Medium. The JD asks for comfort with retention metrics and the role reports KPIs, and F7 is the evidence a prober would read | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know |
| D. Conversational (3) | The opening walk-through, casual questions about the games you play and how you write | Medium. Every interview has an opener and a casual register, and it is still scored | Prepare a 90-second arc from your own sentences, and treat casual questions about JD topics as scored |
| E. Pressure (2) | A time-boxed challenge, or a question about how much was yours | Low. It is not in the hiring-manager prior, though attribution questions arrive from any persona | Pause, restate, anchor in what you said, hold through two follow-ups before conceding anything real |
| G. Peer Evaluator (2) | Seam-splitting between the producer and design, art, engineering and community | Low as asked by Tobias, higher if any of those teams meets you. The JD makes coordination core. Letter F is skipped so question IDs do not collide with fit rows | Offer seam principles rather than pretending to know the seam, and frame what you bring them |

No Values/Behavioral bank: no published values are in hand and no values round is established, so nothing here is mapped to a company value.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles each have an event planned this month and they share the same art team. Walk me through how you'd build the calendar. What do you need to know first?" | CASE | [generic] | Clarify first: each event's goal, the art team's capacity, fixed dates, what QA needs and when. Then objective, how you would sort the work, approach, how you would know each event worked, and the risks. Say your assumption aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's two-title calendar line (F1) is the core of the role. CASE because it scores structure, not history |
| A2 | "An event went live two days ago and retention among players who joined it is well below what the team expected. The review is a week away. What do you do today?" | CASE | [generic] | Clarify what was expected and how that was set, whether the shortfall is everywhere or in one group, and what changed in the build or the schedule. Then say what you would check first, what you would hold off concluding, and what you would tell the team today. Name the assumption you would defend least before they do. No claim about your past | The JD's review-and-KPIs line (F3) and retention line (F7). CASE because it is delivered as a live diagnosis, JD in content |
| A3 | "It's release morning. QA has flagged a blocker on the event build, and community has already announced the start time. Walk me through the next hour." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: get the facts from QA, decide who decides, lay out the options (hold, slip, ship with a mitigation) with what each costs, and what goes to community and when. Answer slot: if the interviewer asks what your checklist would have said here, say what it covers and what you know of how QA uses it; if it did not cover this, say so plainly | F4 is the evidence for the release line, and a blocked release is where a checklist gets tested. CASE because the scoring is the reasoning under time pressure |
| A4 | "Both titles want the same weekend for their biggest event. How do you decide?" | CASE | [generic] | Ask what each event is meant to achieve, what each costs to move, and who owns the call. Offer a decision rule and say what you would give up. Say how you would tell both leads. No claim about your past | The JD's two-title line (F1) at its sharpest point. CASE because it scores prioritization out loud |
| A5 | "What would your first 30 days here look like?" | JD | [generic] | A plan, said as a plan: what you would read, who you would ask, what you would not change until you understand it. Fold in the two things you have not done (F9, F10) as things you would ask about early, in plain words. No claim about your past | Gives you a place to turn F9 and F10 into a ramp. JD because it scores readiness for the listed job |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see in-app purchases anywhere in your background. How would you approach that if it came up in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." [grounded] "Presented the monthly retention numbers to the studio head." | Deepest rehearsal in the pack; limit named first: do not describe retention numbers as purchase experience. Level one: say it plainly, "never worked on a game with in-app purchases", then go to a plan said as a plan: what you would ask for first, who owns the numbers you have not worked with, and what you would not change before you understand it. Level two, "So how do I trust you with the KPIs?": hold on what the quote carries, you presented the monthly retention numbers to the studio head, and concede specifically that you have never worked on a game with in-app purchases. The pack's observation is that the quote does not say the numbers were purchase-related. Level three, "What if it takes you six months?": promise no date; ask what the team needs by when and plan back from that | F10 is the limit you named and the likeliest probe. JD because it scores the listed role; Skeptic delivery because it goes at a gap |
| B2 | "You'd coordinate design, art, engineering and community on each update, and you haven't led a team. How do you get those teams to move on your timeline?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first: "Never led a team." Then stay with the calendar you ran, in the quote's words. Answer slot: say which of those four teams you worked with on the drops and what you needed from each, in your own words; if you did not work with one, or the drops did not run that way, say so plainly. Hold through two follow-ups by returning to the calendar, never by adding to it; concede that coordinating is not leading | F9 and F2 together. JD because it scores the coordination line; the premise on leading is yours, the premise on coordinating is the JD's |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." [grounded] "Presented the monthly retention numbers to the studio head." | Pick the one that is honestly true for you and name it first. The pack's observation is that F3, F9 and F10 are where your material is thinnest, but the honest answer is yours. Then the ramp in one sentence. Answer slot: if your honest answer is a different line, use that one and say why | Asked in nearly every hiring-manager round. JD because it scores self-assessment against the listed requirements |
| B4 | "You've run a calendar on one main title at a puzzle-game studio. We run events across two titles. What's different?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." [grounded] "4 years as an associate producer at a puzzle-game studio." | Hold the quotes at their scope: a weekly content-drop calendar for the main title, at a puzzle-game studio. Then ask what the two titles' calendars share, and say what you would want to know first. Answer slot: if content drops and live events were different things in your work, say plainly how; if they were not, say that | F1 and F5: the scope step from one title and one genre to the JD's wording. JD because it scores the listed requirement; the probe is the Skeptic's |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how they were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The defend-the-number move. Say how they were counted if you know, what they were most sensitive to, the assumption you would defend least, and which part was yours, each in your own words. Answer slot: if you also produced or analysed them, say so; if they came from someone else or a tool, say so plainly and stay with presenting them. If you do not know how a figure was counted, say that | F7 is the only evidence for the retention line and a prober reads it first. EXP because it tests what was yours |
| C2 | "What would you want on an event's post-event review, and why those measures?" | JD | [generic] | Choose a few measures you can define aloud in a sentence each. Say what decision each one informs and what you cannot tell from it. Say which you would trust least. No claim about your past | The JD's review line (F3). JD because it scores the listed responsibility; asked as a prober would, down to assumptions |
| C3 | "Tell me about a time a content drop didn't land the way you expected. What did you do?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The beat the quote states: you ran the weekly calendar for the main title. Answer slot: the JD's review line raises this. If a drop that missed comes to mind, say what you saw and what you did, in your own words; if none comes to mind, or what happened was not yours, say so plainly and say how you would review one | F3 and F6. EXP because it asks for an instance you choose |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get from where you started to applying here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." [grounded] "Wrote the release checklist our QA team still uses." [grounded] "Presented the monthly retention numbers to the studio head." | A 90-second arc built from your four sentences in order: the four years, the calendar, the checklist, the retention numbers. Answer slot: why this role and this studio, in your own words; if you do not have a reason you can stand behind yet, say what draws you to the work itself | F5, F6, F4 and F7 as one story. EXP because it is your history, asked casually and scored |
| D2 | "What are you actually playing and paying attention to in mobile live events these days?" | JD | [generic] | Name a game you actually play and one thing it does with events that you noticed. If you do not follow live events as a player, say so plainly and say what you would study before starting. No claim about your past | The JD is for mobile titles with a live-events calendar (F1). JD because it scores interest in the listed work, asked casually |
| D3 | "When something has to be written down for four teams who'll each read it differently, what does a good version look like?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | The one writing sentence you have: the release checklist QA still uses. Answer slot: if you have another piece of writing you can point to, say what it was and who read it; if not, say plainly that the checklist is what you have and describe what good looks like as principles | F8, and the JD's written-communication line. JD because it scores a listed requirement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." [grounded] "Wrote the release checklist our QA team still uses." [grounded] "Presented the monthly retention numbers to the studio head." | Pause and restate. Give the three sentences in your own words, then concede in one clause that you have never worked on a game with in-app purchases. Hold through two follow-ups by returning to what the quotes carry. Never say what they prove | F10 under time pressure. JD because it scores the listed role; Pressure is the delivery |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours and which were someone else's, in your own words; if the line between them was not clear, say that. Hold through two follow-ups, concede specifics, never the core | F1 and F6. EXP because it tests attribution |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design, art, engineering and community will each want something different from the same update. Where's the seam between your role and theirs, and what happens when we disagree?" | JD | [generic] | Offer seam principles rather than claiming to know this seam. Say what you would bring them, not only what you need. Answer slot: if a disagreement with one of those teams comes to mind from your calendar work, say what it was and what you did; if none does, say so plainly and answer as principles | F2 and the JD's coordination line. JD because it scores the listed responsibility, delivered as a peer would |
| G2 | "How do you handle credit when an update spans four teams?" | EXP | [generic] | "We" for context, "I" for what you did. Answer slot: if an example comes to mind from your own work, tell it at the scope you had; if none does, say so plainly and answer as principle | F2. EXP because it probes attribution, asked collegially |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A4, B4 |
| "coordinate design, art, engineering and community teams on each update" | B2, G1, G2 |
| "own the post-event review and the KPIs it reports" | A2, B1, C2, C3 |
| "manage the release checklist with QA" | A3 |
| "3+ years producing live-service games or apps" | B4, D1 |
| "experience running a content calendar" | B4, C3, E2 |
| "comfortable with player-retention metrics" | A2, C1, C2 |
| "clear written communication" | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which KPIs does the post-event review report today, and which of them does this role own versus report?" | Pins down F3 and F10 with the person who decides, and shows you are thinking about the review before you have it |
| R2 | "How are the two titles' calendars planned together now, and who settles it when two events want the same slot?" | The JD's two-title line (F1) as a working question, not a quiz |
| R3 | "Where does the producer sit when design, art, engineering and community disagree about an update?" | Shows you understand coordination without direct authority (F9), and the answer tells you what you are signing up for |
| R4 | "How is the release checklist used with QA today, and what would you want changed?" | Invites Tobias to describe the process you are being hired to manage (F4), and shows you ask before you change |
| R5 | "What would the first 90 days need to deliver for you to say the hire was right?" | Turns A5 into his criteria, so you hear the bar rather than guess it |
| R6 | "What did the team learn from the last event that missed, and what changed after?" | Shows the review habit you would be joining; the answer shows how the team treats a miss |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated, F9 | The plain acknowledgment: "Never led a team." No slot. The pack's observation is that the JD says coordinate, not lead |
| Has worked on a game with in-app purchases | Negative you stated, F10 | The plain acknowledgment: "Never worked on a game with in-app purchases." No slot. Retention numbers are not described as purchase experience |
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar for the main title |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says the numbers were presented |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says you wrote the checklist and that QA still uses it |

## Sources

Provided documents: the JD text you pasted, and your background message.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

All four searches were refused, so nothing in this pack comes from the web. Queries sent, each refused:

- `Saltmarsh Games mobile studio values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games strategy news mobile titles` — refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet if a values round turned out to be documented. No VAL questions and no values sheet |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have fixed the loop and the persona weights. Weights rest on the Generic fallback plus the assumed hiring-manager prior |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have fed CO questions and a grounding brief. Neither is in the pack |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have fed an interviewer read and a reverse question tied to his path. Reverse questions are role-generic |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- The recruiter's confirmation of who Tobias is to the role and what the 60 minutes will cover → persona weights reset from an assumption to a fact, and any named focus area or prep task gets its own build section
- Search access, or a pasted values page and any recent press on Saltmarsh → company-specific CO questions, a grounding brief, and a values sheet if a values round is documented
- Tobias's public talks or writing, if any exist → an interviewer read and a reverse question tied to his own path
- Your answers to the slots in F1, F2, F3, F5 and F8, said outside a drill → those rows get quoted evidence and their bridges are rewritten
- The release checklist itself, a calendar export, or a post-event write-up you are allowed to share → F4, F6 and F8 can rise from `medium` or `low` toward `high`, because each is an artifact someone else can inspect
- A `tuesday-dossier.md` from a job-underwriter run → the objection worth deepest rehearsal arrives evidence-derived rather than inferred, with strategy limits per weak area
