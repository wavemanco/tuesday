I'll read the reference files before building the pack.
Web search was refused, so I'm building the pack from your message alone. I also can't see the market report. It isn't in this conversation, so I'll flag that in the pack. Writing the pack now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-5-denied-da3a004a/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It is built for a panel round with Deepa as future manager and Ross as Commercial Director, with a four-hour triage order and a 15-minute POV build with theses, concessions and an anti-pick.

Two limits to know about:
- **No web research.** All six searches were refused, so there is nothing on Kelverton's values, strategy or the panelists. The CO and CASE questions are generic, and the Sources section lists each refused search.
- **No market report.** It wasn't in this conversation, so the pack doesn't use it. The POV section tells you to bring one point from it and one thesis that departs from it.

The highest-ROI prep is C1, the "you haven't sold into rail" objection, rehearsed through three follow-ups.

Say the word and I'll play Ross on B3 (influenced revenue versus quota) or Deepa on C1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description, or the market report's headline points, if you have them? Either would turn several `[generic]` rows into `[grounded]` ones and sharpen the POV differentiation.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one 60-minute panel on Tuesday. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are a POV you present without slides; the rest is Q&A.

**What this was built on:** your message and the recruiter's email as you quoted it. No job description was supplied, the market report's text was not in this conversation, and web search was refused, so nothing here comes from research. Say so if any of that changes and the affected sections will be rebuilt.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words.
- Type key: **VAL** values alignment (no bank in this pack, see the persona table); **EXP** whether your CV claims survive scrutiny; **JD** the role as stated; **CO** company and strategy knowledge; **CASE** a live problem from the role.
- Provenance: `[grounded]` rests on something you or the recruiter wrote; `[inferred]` is derived from an adjacent source; `[generic]` is a role-family pattern with no claim about Kelverton or you.
- Row IDs: F1 to F4 are fit-snapshot rows. Question letters skip F so the two never collide.
- Where a cell holds language for you to say, it is proposed, pending your approval. Rehearse it only if it is true in your own words.

## Prep triage: four hours

| Order | Time | What | Tied to |
|---|---|---|---|
| 1 | 75 min | Build the POV; say it aloud twice, timing it against the 15 minutes | Graded deliverable below; A1 to A4 |
| 2 | 45 min | Rehearse the no-rail-sales objection to three follow-up levels. This is the highest-ROI prep in the pack | C1, D1, F4 |
| 3 | 40 min | Rehearse the £4M and the 6-to-40 answers, including saying plainly what you do not know about how they were counted | B1, B2, B3, G2 |
| 4 | 30 min | Reread the market report: mark one point you share with it and one you would push on | POV build; E2 |
| 5 | 20 min | Choose your reverse questions | Reverse questions |
| 6 | 30 min | One full run: POV, then C1 and B1 back to back | Whole pack |

Everything else in the pack is insurance.

## Fit snapshot

No job description was supplied, so the requirements are the recruiter's own words and your description of the company, quoted. Proposed bridge language in this table is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, as you quoted it | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material carries an ISV channel, not operator partnerships, and the words stay at the channel: "For the last four of nine years in partnerships I was running the ISV channel at a payments company." Answer slot: the brief makes a probe on how an ISV channel carries over to operators likely. If anything from running it applies to operators, say what, in your own words; if nothing does yet, say so plainly and stay with the channel |
| F2 | "land on what it means for the operators themselves" — recruiter's email, as you quoted it | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The quote's scope is bus and light rail network planning; your material does not say train operators, and the pack's reading of that limit is not words for you. Say it at its own scope: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: if anything from that work applies to how train operators plan, say what; if nothing does, or you have not worked on train operators, say so plainly and stay with bus and light rail |
| F3 | "Ross will push on commercials" — recruiter's email, as you quoted it | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | discovery | Plain acknowledgment, from your own sentence: "I haven't carried a direct quota; what I have is influenced revenue." Answer slot: the figure raises four things, each in your own words: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly |
| F4 | "they sell scheduling software to train operating companies" — your message, describing the company | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Never a claim to rail selling, and nothing added to make the gap feel smaller |

## Graded deliverable: the 15-minute POV

**The brief, in the recruiter's words as you quoted them:** "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

**Facts you can build on** (each is the fit row it comes from and a sentence quoted from that row's evidence cell):

- F1: "took it from 6 partners to 40, roughly £4M of influenced revenue"
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F3: "never carried a direct quota, only influenced revenue"
- F4: "Never sold into rail specifically"

I could not read the market report, so the pack names no point from it. You supply the report-side items below.

**Differentiation strategy.** The report was written by Kelverton's strategy team, so both panelists know it. Reciting it scores as homework. Bring one point from it to show you read it, then one thesis that departs from it, with reasons. The role's real job includes saying no, so include the anti-pick.

**Proposed shape of the talk, pending your approval:**

| Minutes | Beat | Note |
|---|---|---|
| 1 | Where you stand | One sentence from F4 so Deepa and Ross never have to raise it first: "I've never sold into rail specifically." Then the F2 quote at its own scope |
| 2 | One point you share with the report | Your pick; stay brief |
| 6 | One thesis and its 18-month shape | Choose from the table below; the three-phase shape (learn, prove, extend) is a scaffold, not a claim about Kelverton |
| 2 | Your concession and what would change your mind | Mandatory, and spoken before they ask |
| 2 | What it means for the operators | The requested close, below |

**Thesis options.** All three are `[generic]` hypotheses to test against the report and the panel, not facts about Kelverton's market.

| Thesis | The claim | Mandatory concession | Why it differentiates |
|---|---|---|---|
| T1: go deep before wide | If the report shows the operator base is a small, named set, a few deep operator relationships beat a broad programme. Check this against the report before you say it | Slower on partner counts and pipeline signals, which Ross will notice | The broad-programme answer is the one a partnerships background points to, and any prepared candidate gives it |
| T2: measure what changes for the operator | Judge the partnerships by something an operator can see change, paired with one commercial measure | Operator outcomes are harder to attribute than partner counts, and Ross will ask for the commercial measure | Moves the conversation from counting partners to what operators experience, which is the close they asked for |
| T3: operators shape the partner roadmap | Give operators' planning teams a standing say in which partnerships get built | It costs operators time, and delivery depends on product commitments partnerships does not control | Treats operators as co-designers rather than buyers |

**The anti-pick.** A broad partner programme (tiers, certification, a marketplace) as the headline for the first 18 months. Proposed language, pending your approval: "The obvious move from an ISV background is to widen the base. I would hold that back until" and finish the sentence with your own reason. Say it only if it is your real view.

**The requested close, pending your approval.** End on operators. Pick one of three, whichever your thesis supports, and say it in plain words: one thing an operator can do in 18 months that they cannot now; one thing they no longer have to carry themselves; one thing they now get a say in. Supply the specific yourself once you have read the report's operator material.

## Persona table

The loop here is one session, established by the recruiter's email, so this is a panel blend: the top two personas for each panelist's relationship, adjusted by the recruiter's one line about Ross.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The POV itself, then live problems on operator partnerships | High. The brief is a POV on "where you'd take our operator partnerships", and Deepa is "your future manager", which a hiring-manager round prior weights toward case and skeptic | Clarify, then objective, approach, measures, risks; challenge one premise respectfully |
| Data-Driven Prober | Ross on the £4M and the 6-to-40 | High. The recruiter wrote "Ross will push on commercials", and your commercial evidence is influenced revenue | Know what you can and cannot say about how the figure was counted; say plainly where you do not know |
| Skeptic | Deepa on rail, quota and ISV-to-operator | High. F4 and F3 are gaps you named yourself | Rehearse the one predictable objection until it is boring |
| Pressure | Ross, time-boxed or interrupting | Medium. A commercial director in an executive prior carries pressure, and "push on commercials" fits it | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational | The opening, and any casual asks | Medium-low. The loop is one structured panel, but the opener is still scored | A 90-second arc, built from your own quotes |
| Peer Evaluator | The partnerships-to-commercial seam, since the panel spans both | Medium-low. No peer is on the panel; the seam appears between the two panelists | Reciprocity framing and seam principles |
| Values / Behavioral | Not detected as a round | Low. The recruiter's email names no values round, so no values bank is built; C2 covers the behavioral shape | n/a |

## Question banks

Letters skip F. Proposed guidance in these tables is pending your approval.

### A. Case / Strategist (heaviest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through where you'd take our operator partnerships over the next 18 months, and land on what it means for the operators." | CASE | [grounded] | The build is the POV section above; this row is live delivery. Thesis in the first minute so the panel can steer you, then your concession, then the operator close. The guidance makes no claim about your past | The recruiter's brief names this ask outright, so it is the one near-certain question. CASE because it scores structure and altitude |
| A2 | "What would you need to learn about our operators before committing to any of that?" | CASE | [generic] | Clarify before you structure: name two or three things you would want to learn, who you would ask first for each, and which would change your plan most. Do not pretend to know what operators want | The follow-up that tests whether the POV is a position or a performance. CASE because the scoring is clarifying behavior |
| A3 | "What is the biggest risk to your plan, and how would you know by month six?" | CASE | [generic] | Name the risk your own thesis creates (your concession is the natural choice), then one signal you would watch. Supply no figure you cannot defend | Panels follow a POV with its weak point. CASE for the live risk reasoning |
| A4 | "Where should our operator partnerships say no?" | CO | [generic] | Use your anti-pick, say why, and say what would change your mind. Hold it as a view, not a lesson claimed from your past | The role includes saying no, so this is the likeliest differentiator. CO because it tests thinking at the company's altitude; generic because no strategy research ran |
| A5 | "Walk us through your first 90 days." | CASE | [generic] | A plan, never a past: listen, map, one small proof. Tie each step to a thing you named in A2 | Hiring managers close a POV with the start line. CASE because it is a live plan |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that £4M of influenced revenue was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say the figure in the quote's own terms, "roughly £4M of influenced revenue", and keep "influenced" every time. Answer slot: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours, each in your own words. If you do not know how it was counted, say so plainly and do not reconstruct a method now | F3 is the commercial evidence Ross will press. EXP because it tests whether the number survives attribution questions |
| B2 | "How much of the growth from 6 to 40 partners was you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel", "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold only what the quotes carry: for the last four of nine years in partnerships you were running the ISV channel, and you took it from 6 partners to 40. Answer slot: which parts of that growth were yours and which were shared; if it was not all yours, or you do not know the split, say so plainly and stay with what you do know | F1 is where attribution gets tested. EXP because "how much was you" probes ownership |
| B3 | "Our commercial team carries targets. You have influenced revenue, not quota. How does that change what you would commit to here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Plain acknowledgment from your sentence: "I haven't carried a direct quota; what I have is influenced revenue." Answer slot: say what measure you would be willing to be held to in the first 18 months and by when, in your own words; if you cannot name one without seeing the commercial picture, say so plainly and say what you would want to see | F3, aimed straight at the recruiter's "push on commercials". JD because it scores the role's commercial side |
| B4 | "What commercial measures would you put on operator partnerships, and which would you refuse to be measured on?" | CASE | [generic] | Pair one thing an operator can see change with one commercial measure, name one you would refuse and why, and offer no figures. It is T2 from the POV section under questioning | Gives Ross a decision to push on. CASE because it is a live design problem |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have not sold into rail. Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically", "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **Highest-ROI prep in the pack: the deepest rehearsal.** Level 0: "I've never sold into rail specifically." Then at the quote's scope: "I spent five years in transport consulting, on bus and light rail network planning." Then a plan, not a past: who you would learn from first. Follow-up 1, "Bus and light rail are not train operators": concede at once, "That is right: my operator work is bus and light rail." Follow-up 2, "What would we find out in month one that you do not know?": name one thing about how train operators plan or buy that you would not claim to know, chosen from the report. Follow-up 3, "Why take the risk?": return to the two facts the quotes carry and stop; add nothing and compare yourself to nobody | F4 and F2 together are the objection most likely to be asked in some form. JD because it is a stated-role weakness probe |
| C2 | "Tell me about a time an operator's constraint shaped a plan you were working on." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pick a time in the bus and light rail network planning where an operator's constraint changed what was planned; it needs the constraint, what changed and what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing the network planning does carry, or how you would find out | F2, and the recruiter's "what it means for the operators themselves", raises this. EXP because it checks the operator-side claim against an instance |
| C3 | "You began in transport consulting and then moved into payments partnerships. Why come back to transport, and why a vendor?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "9 years in partnerships, last 4 at a payments company running the ISV channel" | The two facts are the arc, in order. Answer slot: say what drew you back and why now, in your own words; if it was not a deliberate return, say so plainly and say what draws you to this role | Motivation consistency is the Skeptic's core. JD because it tests fit with the role |
| C4 | "Your partners were ISVs. Ours are operators. What is different?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Stay at the quote: you were running the ISV channel. Name one difference you would expect and how you would test it in the first months, as a hypothesis, not a lesson claimed. If you have worked with operators as partners, say so; if not, say so plainly | F1 is the bridge row. JD because it scores the role's partner type |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, rather than someone who has sold into rail?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel", "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "Never sold into rail specifically" | Hold on the two facts the quotes carry, then concede the gap without a qualifier: "I've never sold into rail specifically." Hold through two follow-ups by returning to the two facts, never by adding to them | F4 under time pressure. JD because the stated requirement is the target |
| D2 | "If operator partnerships had added no revenue by month twelve, what would you tell Ross happened?" | CASE | [generic] | Do not promise a number. Name the measure from A3 and B4, hold it, and concede what partnerships does not control, specifically | Tests whether you hold a position under a commercial challenge. CASE because it is a live hypothetical |
| D3 | "Convince me that operator outcomes pay back before revenue-first does." | CASE | [generic] | T2 under fire: pair the operator measure with a commercial one, concede that attribution is harder, and do not fold on the core claim to restore harmony | Ross is the likelier source. CASE because it is a live argument |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "9 years in partnerships, last 4 at a payments company running the ISV channel", "took it from 6 partners to 40, roughly £4M of influenced revenue" | Three beats the quotes state, in order: the transport consulting, the partnerships years, the ISV channel growth. Answer slot for the last beat: say what brought you to this role in your own words; if the move was not planned, say so plainly. About 90 seconds | The casual opener is still scored. EXP because it is your career arc |
| E2 | "What have you been noticing about operators and scheduling lately?" | CO | [grounded] "which I've read" | Your honest answer is the report: say what you read and one point you would push on or add. If you remember only part of it, say which part. The pack supplies no content from the report | The report is the one piece of Kelverton homework you have. CO because it tests current knowledge; grounded only on your having read it |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where is the seam between partnerships and the commercial team, and what happens when we disagree on a deal?" | CASE | [generic] | Offer seam principles rather than pretending to know the seam: who holds the account, who holds the partner relationship, how credit is recorded. Say what partnerships gives the commercial team, not only what it needs. If you have a disagreement story, use it; if not, say how you would handle one | The panel spans both sides of the seam. CASE because it is a live collaboration scenario |
| G2 | "When a partner-influenced deal closes through someone else's pipeline, who gets the credit?" | EXP | [grounded] "roughly £4M of influenced revenue", "only influenced revenue" | Stay in the quote's own term, influenced revenue. Answer slot: if there was a rule for crediting influenced revenue, say what it was and whether it was yours; if there was none, or you do not know, say so plainly. Then offer a principle for here | F3 again, in collegial packaging. EXP because it probes credit attribution |

### Requirement coverage

No job description was supplied, so this maps the recruiter's asks and your named gaps.

| Requirement | Questions |
|---|---|
| POV on operator partnerships (F1) | A1, A2, A3, A4, A5, D3 |
| What it means for the operators (F2) | A1, C2, B4, D3 |
| Commercials (F3) | B1, B2, B3, B4, D2, G2 |
| Selling software to train operating companies (F4) | C1, D1 |
| ISV to operator partnerships (F1) | C4, B2 |
| Motivation | C3, E1 |
| The market report | A1, E2 |

## Reverse questions

No interviewer profile exists, so these are role-generic.

| Question | Why it lands |
|---|---|
| "In 18 months, what would you want operator partnerships to be able to point to?" | It asks Deepa for her scoring sheet and shows you think in outcomes |
| "How do operators tell Kelverton what they need today, and where does partnerships sit in that conversation?" | It tests your operator-first thesis against the real process |
| "How does the commercial side count partner-influenced deals today, and what would you change?" | It goes to Ross's ground and shows you understand attribution |
| "Which parts of the market report are still hypotheses rather than decisions?" | It shows you read it and asks where the thinking is open |
| "What would make you say in month six that this hire was a mistake?" | It surfaces the real objections while you can still answer them |

## Prohibited claims

Not coached in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail or carried a rail sales target | Negative you stated, F4 | "I've never sold into rail specifically." No slot |
| Carried a quota, or owned or closed £4M | Negative you stated, F3 | "I haven't carried a direct quota; what I have is influenced revenue." No slot |
| Knows train operating companies from the inside | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The limit is the pack's observation, not words for you: your material says bus and light rail, not train operators |
| Built the ISV channel from nothing, or recruited the partners yourself | Inflated form of F1 | F1's quotes at their own scope: running the ISV channel, and taking it from 6 partners to 40. The limit is the pack's observation: your material does not say who recruited them. B2's slot stays inside the growth |

## Sources

Provided: your message, including the recruiter's email as you quoted it. The market report was said to be attached; its text was not in this conversation, so it was not read and nothing here draws on it. No dossier was present.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Query sent | Result |
|---|---|
| Kelverton Rail values | refused |
| Kelverton Rail interview process partnerships | refused |
| Kelverton Rail strategy news train operating companies scheduling software | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager rail technology software job description | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The one search was refused. It would have named the published values; none is used, and no values round is detected from the recruiter's email, so no values sheet is built |
| 2. `Kelverton Rail interview process partnerships` | unavailable | The one search was refused. The recruiter's email already fixes this loop as one panel session; it would only have corroborated it |
| 3. `Kelverton Rail strategy news` | unavailable | The one search was refused. It would have grounded A4 and the CO and CASE rows; they stay `[generic]` and no grounding brief is built |
| 4. `Deepa and Ross, Kelverton Rail` | unavailable | Both searches were refused. The interviewer read is absent and the reverse questions are role-generic |
| 5. representative `Senior Partnerships Manager` JD | unavailable | The one search was refused. Fit rows rest on the recruiter's words and your message, not a JD |

## Upgrade menu

- The market report's text, or its key points → section "Graded deliverable" gets a named consensus point to share and one to depart from; A4 and E2 can become `[grounded]`
- The job description → F1 to F3 requirements become exact JD lines, and uncovered requirements gain JD questions
- Your answers to the slots in F1, F2 and F3 (how the £4M was counted, what carried over from the bus and light rail work) → those rows can be upgraded from `medium` and the guidance can quote you
- Permission to run web search → values names, Kelverton's published strategy, and any public footprint for Deepa or Ross, each tailoring questions that are `[generic]` now; a deeper pass adds up to 6 more searches and 2 more fetches and several more minutes, offered once
- A recruiter reply on what Deepa and Ross most want the POV to settle → persona weights move off the round-type priors
- A tuesday-dossier.md from an earlier evaluation, if you have one → verified evidence and an objection derived from it; never required
