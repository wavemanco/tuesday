I'll read the reference files the skill points to before building the pack.
Web search was denied, so I'm building the pack from your JD and background alone and marking the company research as unavailable. I'm writing the file now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-2-denied-97f048e3/atlas-freight_operations-manager_interview_pack.md`.

The web searches on Atlas were denied, so I built it from your JD and background alone. The Sources section marks company research as unavailable. Because I don't know the round or the interviewer, persona weights are flat, which is weaker than a pack built for a known round. It has 22 questions across seven interviewer styles, plus reverse questions and a list of claims it won't coach.

The pack names the scale objection as your highest-ROI prep (A1): twelve supervisors across four sites, against the three you lead now. Power BI is second. For that, your own words are the plain acknowledgment ("I haven't used Power BI") plus a plan.

Say the word and I'll play the Skeptic on A1 so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you know what kind of round this is (recruiter screen, hiring manager, panel, something else), and has the recruiter said anything about focus areas or a take-home? Either answer would reweight every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: unknown. Round type and relationship: unknown (you said you don't know who is interviewing you). This is a full-loop pack with flat persona weights, which is weaker than a pack built for a known round. Company research did not run (see Sources), so nothing here is stated about Atlas beyond what your JD says.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type tags: VAL = behavior against values; EXP = does your experience survive scrutiny; JD = a stated requirement of the role; CO = company and strategy knowledge; CASE = a live problem set in the role.
- Provenance tags: `[grounded]` traces to your message or the JD you pasted; `[inferred]` is derived from a grounded fact, with the derivation named; `[generic]` is a role-family pattern with no claim about you or Atlas.
- Guidance is scaffolding, not a script. Say it in your own words. Where a cell is marked Answer slot, it is an instruction for the interview: say what is true for you, and where the practice named was not yours or never existed, say that plainly.
- Everything this pack says about your past is one of your own sentences, quoted. Anything past those sentences is yours to supply from memory, or to leave out.

## Prep triage

You have about a week. Do these in order, each aloud, not just read:

1. A1, the scale objection (twelve supervisors, four sites, against the three you lead). This is the highest-ROI prep in the pack: it will arrive in some form in any round.
2. A2 and E3, the Power BI answer: one plain sentence, then a plan. Decide now what concrete step you will actually take before the interview, and say only what you really did.
3. B1 and B2, defending the 40%. Find out, before the interview, how that figure was counted.
4. B3: check whether you hold any on-time or cost numbers from your own work. Whether you do is the answer.
5. D1, your 90-second journey, then D2, the surge plan.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift manager over three supervisors and a surge plan at the site, not terminals and not four sites, and the words stay at that scope: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's 4 sites make a probe on multi-site work likely. If your work has covered more than one site, say where and which part was yours; if it has not, say so plainly and stay with the site you have described |
| F2 | "drive on-time performance" — JD | none given | none | [grounded] | discovery | Your material does not show either way. Answer slot: if you have tracked on-time performance or a delivery-timeliness measure in any role, say what it was and what you did with it, in your own words; if you have not, say so plainly and say which measure you would look at first |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The sentence is about mis-pick rate, which is neither of the JD's measures, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." It is a figure on a CV line with nothing inspected behind it, so expect a probe on how it was counted. Answer slot: if you tracked any cost measure, say which and what you did with it; if you did not, say so plainly and return to the mis-pick work |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The sentence says three supervisors, not twelve; the words stay at "I'm currently a senior shift manager over 3 supervisors." Answer slot: expect a probe on span. If any role has given you more than three supervisors, say which and what part was yours; if none has, say so plainly and return to the three you lead now |
| F5 | "build reporting in Excel/Power BI" — JD, Excel half | "solid Excel" — your message | low | [inferred] | discovery | Derived from a self-description: the sentence names the tool and says nothing about reports built. The words stay at "I have solid Excel." Answer slot: if you have built reports in Excel, say what they covered and who read them; if you have not, or none were yours, say so plainly and leave Excel at solid |
| F6 | "build reporting in Excel/Power BI" — JD, Power BI half | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | discovery | The sentence gives operations years, not leadership years, and your material does not show how many of the seven involved leading people. This is an experience requirement, graded like any other row and not a gate. Answer slot: say when you first led people and what the team was, in your own words; if the leadership years are fewer than the seven, say the number plainly and say what the other years covered |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification stated with nothing inspected behind it. Lead with it in the quote's own terms: you are green belt certified. The sentence says certified and nothing about projects, so expect the probe on where you have applied it |

## Persona table

No relationship or loop source was supplied or found, so no relationship prior applies. The fallback is the Generic archetype (screen, hiring manager, panel) with flat weights, which rests on a pattern and not on Atlas's documented process. Depth is three questions per persona, with five for the Skeptic because the biggest gaps in the fit snapshot (F1, F4, F6) are the material that persona probes, and two for the Peer Evaluator. A depth choice is not a likelihood.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps: span, terminals, Power BI, why leave | Even. Nothing known about the round. Learning the interviewer is a hiring manager would raise it together with the Case persona | Rehearse A1 until it is boring; hold only what your quotes carry; bridges come from your own sentences, then a plan |
| Data-Driven Prober | Reads the CV line by line and asks for denominators | Even. A peer or technical round would raise it | B1 to B3: know what you can and cannot say about how the 40% was counted, and say plainly when you do not know |
| Case / Strategist | Live problems from the role | Even. A hiring-manager round would raise it | C1 to C3: clarify, structure, answer, check; think aloud |
| Conversational | Friendly and unstructured, and still scored | Even. A recruiter screen would raise it | D1 to D3: a 90-second arc built from your quoted sentences |
| Pressure | Interrupts, time-boxes, tests composure | Even. A skip-level round would raise it | E1 to E3: hold through two follow-ups, concede only what is true |
| Values / Behavioral | Scenario probes | Even. No values-style round is detected: no loop source documents one and the Generic archetype reads no. Behavioral questions can still arrive in any round | F1 to F3: pick stories by criteria; if none fits, say so plainly |
| Peer Evaluator | Seam-splitting and credit-sharing | Even. Only a peer round would raise it | G1 to G2: propose principles, not a seam you do not know |

## Question banks

Requirement coverage:

| JD requirement | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, C1, C2, E2, G1 |
| "drive on-time performance" | B3, C1 |
| "cost-per-shipment down" | B3 |
| "lead a team of 12 supervisors" | A1, E2, F3 |
| "build reporting in Excel/Power BI" | A2, C3, E3 |
| "5+ years operations leadership required" | A5, D1 |
| "Lean/Six Sigma a plus" | D3 |

The surge plan is not a JD requirement; it is covered as your strongest quoted story in D2 and C2. No CO question is grounded in Atlas's strategy, because no research ran; A4 is the only CO-flavored question and its Atlas half is generic.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role has twelve supervisors across four sites, and you are over three today. What makes you think you can step up to that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Say it flat, without apologizing for the number and without padding it. Answer slot: the JD sets the span, so expect a probe on whether any role has given you more than three supervisors or covered more than one site; if one has, say which and what part was yours; if none has, say so plainly and return to the three you lead now. Follow-ups: if pressed on span, return to the sentence rather than adding to it. If pressed on leading people you would not see daily, give a first-thirty-days plan said as a plan and not a past: what you would ask, whom you would meet first, what you would look at before changing anything. Name one thing you expect to get wrong early, in your own words | F4 and F1 are the widest gaps between the JD's stated scale and the quoted evidence, so this objection arrives in some form in any round. JD because it scores a stated requirement; the Skeptic delivers it quietly and keeps coming back |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Name Power BI. It is the one gap you stated, so the words are already yours: "I haven't used Power BI." Then a plan, said as a plan: one concrete first step, who you would ask, how you would know it was working. Hold the other half of the sentence at its scope: "solid Excel." Answer slot: if you have built reports in Excel, say what they covered and who read them; if you have not, or none were yours, say so plainly and leave Excel at solid. If you take a real step before the interview, such as working through a Power BI tutorial, say only what you actually did | F6 is the requirement you have said you cannot meet today and F5 is its Excel half. JD because it scores the stated requirement, in the Skeptic's day-one stem |
| A3 | "Your background is warehouse and distribution; this role is terminal operations. What carries over, and what doesn't?" | JD | [grounded] "7 years in warehouse and distribution ops" | State the background in the quote's terms: "I have 7 years in warehouse and distribution ops." Do not describe what a terminal is or how Atlas runs one; the pack has no source for that. Answer slot: if any of your seven years touched freight terminals, say where and what you did; if none did, say so plainly, name the questions you would ask about the terminals in your first week, and let the interviewer fill in the difference. Saying what does not carry over, in your own words, is part of the answer | F1 is where the JD's word terminal meets your warehouse background. JD because it scores the stated requirement, delivered as the Skeptic's mismatch probe |
| A4 | "Why leave a senior shift manager role for this one, and why Atlas?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The reason must be yours and specific, and the pack has no Atlas research to supply one. Selection criteria: one thing in the JD you want more of, said in your own words, and one thing about Atlas you can point to from the company's own site or from your recruiter. Open from the sentence, "I'm currently a senior shift manager over 3 supervisors," then say what you want next. If no Atlas-specific reason comes to mind yet, that is research to do before the interview; until then say plainly what draws you to the role | Motivation consistency is what the Skeptic scores; the question presupposes only your current role. JD with a CO half, and the CO half is generic because no research ran |
| A5 | "The posting asks for five or more years of operations leadership. Where do your years sit against that?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say the quote at its own scope: "I have 7 years in warehouse and distribution ops." The sentence gives operations years, not leadership years, so the number that answers this question is one only you can give. Answer slot: say when you first led people and what the team was, in your own words; if the leadership years are fewer than the seven, say the number plainly and say what the other years covered | F7 is a titled-years requirement the quote does not split. JD because it scores the stated requirement; the Skeptic asks it because the answer is checkable |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend the number in four beats, in your own words: how the rate was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. The sentence gives the figure, the measure and the change: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: for each beat say what you know; where you do not know how the figure was counted, say so plainly instead of reconstructing it, and return to the sentence. The pack supplies no baseline, period or method | F3 carries the only figure in your material, and quantified claims are where a Prober starts. EXP because it tests what the sentence can bear |
| B2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name the assumption you know of before they do; it turns a gotcha into credibility. Answer slot: name it in your own words, since the pack names none; if you know of none, say plainly that you do not know how part of the figure was built, and say what you would check to firm it up | The weakest-assumption move is the standard rehearsal for a figure (F3). EXP because it scores whether you know your own number |
| B3 | "The role is judged on on-time performance and cost-per-shipment. What have you tracked on either?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Your own observation to hold: the sentence is about mis-pick rate, which is neither measure, and you have stated nothing else on either. Answer slot: if you have tracked on-time performance or a cost measure in any role, say which and what you did with it, in your own words; if you have not, say so plainly, return to the mis-pick work, and say which of the two you would want to see first in your first week and why | F2 has no quote and F3's quote is adjacent, and together they are the JD's headline performance duties. JD, asked the Prober's way: for the denominator |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance at one of your four sites has dropped for two weeks while the other three are steady. Walk me through your diagnosis." | CASE | [generic] | Structure it aloud. Clarify first: what on-time means for this measure, where in the day the misses cluster, what changed at that site. Then split the problem into a few buckets, say which you would check first and why, name the data you would pull, separate the first day from the first week, and close with how you would know it worked. Challenge one premise respectfully, such as whether the dip is real. The question needs no claim about your past, so the guidance makes none | The JD's on-time line (F2) as a live problem. CASE because the Strategist scores clarifying and structure over the answer; generic because it is a problem pattern, not a fact about Atlas |
| C2 | "Peak season is six weeks out and the volume forecast just went up. What do you need to know first, and what does your plan look like?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Clarify, then structure: what the forecast is based on, where capacity binds, what you would stage first, how you would watch it daily, and what you would drop if it slips. Option: one sentence from your own history, then back to the case: "I ran the site's peak-season surge plan two years running." Everything beyond that sentence is yours to supply or leave out; the case itself needs none of it | F1 carries the surge sentence. CASE because the Strategist scores reasoning on a live problem; the optional sentence is there because this is your strongest quoted story |
| C3 | "Design the weekly operations report for four sites. What's in it, and who reads it?" | CASE | [generic] | Say it as a design, not as something you have built. Audience first, then the decisions they must make, a small set of measures (the JD names on-time performance and cost-per-shipment), definitions that hold across sites, where the data comes from, how often it refreshes, and what you would build first in Excel before anything heavier. The question needs no claim about your past | The JD's reporting line (F5, F6) as a live problem; it tests your thinking independent of your tool experience. CASE with a JD tag |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc from four sentences: the seven years in warehouse and distribution ops; where you are now, a senior shift manager over 3 supervisors; the mis-pick work, cutting the rate 40% by redesigning the pick path; running the site's peak-season surge plan two years running. Close on why this role, in your own words. Between those beats the pack has nothing, including how one role led to the next, so any bridge is yours to supply or leave out | The biography question is scored even when it sounds casual; F1, F3 and F7 draw on the same sentences. EXP because it tests whether the story hangs together |
| D2 | "Tell me about the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The beats the quote states, in your own words: you ran the site's peak-season surge plan, and you ran it two years running. The pack has nothing past that, so what the plan contained and how it went are yours to supply from memory. Name a figure only if you know how it was counted, and say plainly where you do not | F1's second quote is the strongest story available and one any style will ask about. EXP because it tests what was actually yours |
| D3 | "Lean and Six Sigma are a plus for this role. Where does that show up in your work?" | JD | [grounded] "green belt certified" | Lead with the certification in its own terms: "I'm green belt certified." Answer slot: the JD names it as a plus, so expect a probe on where you have used it; if you applied Lean or Six Sigma methods in a piece of work, say what the piece was and what your part was, in your own words; if you did not, say so plainly and return to the certification | F8 is closed on the certification and open on application. JD because it scores the stated plus, asked in the casual register the Conversational persona uses |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold: your sentence has you as the one who cut it, by redesigning the pick path. Say that in those words, and hold it through two follow-ups by returning to the sentence rather than adding to it. Concede only what you know. Answer slot: if others contributed to the redesign or its rollout, name them and what they did; if you do not know how much of the movement came from other causes, say so plainly. Pause before answering and restate the question in a clause | F3's figure is where an attribution probe lands. EXP because it tests precise attribution under pressure, the hold-then-concede structure |
| E2 | "Sixty seconds: why you over someone who has already run multiple sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | Time-box it: pause, restate the question in a clause, then use only the two sentences: "I'm currently a senior shift manager over 3 supervisors," and "I ran the site's peak-season surge plan two years running." Let the interviewer draw the inference; do not say what the work proves. Hold through two follow-ups. Answer slot: the JD sets four sites, so expect the multi-site point to be pressed; if your work has covered more than one site, say where; if it has not, say so plainly and stay with the two sentences | F1 and F4 again, in the Pressure persona's stem. JD because it scores the stated scale; the persona is testing composure, not content |
| E3 | "You've never used Power BI. Why would I hire someone who hasn't?" | JD | [grounded] "solid Excel, never used Power BI" | Hold-then-concede, with the concession already sourced: "I haven't used Power BI." Say it once, without apology. Hold the other half of your sentence: "solid Excel." Then the plan, said as a plan: what you would do first, how soon, how you would know it was working. Over two follow-ups return to the acknowledgment and the plan; do not add a claim to close the gap | F6 is the gap you stated, so this is the likeliest pressure line. JD because it scores the stated requirement; Pressure because it tests whether you fold or inflate |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: pick a time the message was unwelcome, name the stake, show a moment you did not soften the substance, and end with the relationship intact. Use we for context and I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. None of your quoted sentences carries a story for this, so the pack maps none | A persona stem. VAL because it scores past behavior; no published Atlas values were in hand, so it scores the behavior itself |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a real trade-off with a named metric on one side and a customer on the other, a decision that was yours, and what it cost. We for context, I for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack maps no story from your sentences | A persona stem, and the shipper side of logistics makes it plausible in any round. VAL, scored on the behavior |
| F3 | "Tell me about a time you had to hold a team to a standard it was missing." | VAL | [generic] | Selection criteria: a standard that was clear beforehand, a gap you saw, an action that was yours, and an outcome you can state without inflating it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from the JD's line about leading supervisors (F4). VAL because it scores behavior; generic because no quoted sentence carries a story for it |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites run side by side. Where's the seam between yours and mine, and what happens when we disagree?" | JD | [generic] | Propose principles rather than pretending to know the seam: who decides what, how a disagreement is raised and by when, how credit is shared. Say you do not yet know Atlas's seams and ask what the real ones are. The question needs no claim about your past | A persona stem, relevant only if a peer is in the loop; the JD's four sites (F1) are what make a seam question likely. JD with a peer delivery |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection criteria: a case where work crossed teams and both your contribution and theirs were clear. We for context, I for contribution. If no such time comes to mind, say so plainly, then give how you would handle it | A persona stem; scored as partnership fit. VAL because it tests behavior, not a requirement |

## Reverse questions

No interviewer profile exists, so none is tied to an interviewer's path.

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for someone taking on the four sites?" | It shows you are planning the ramp, and the answer tells you what they think the hardest part is |
| R2 | "How is on-time performance measured today, and what is pulling it furthest off target?" | It follows the JD's own headline duty and gets you the definition before you are asked to drive it |
| R3 | "What reporting do supervisors and site leads use today, and where does it live?" | It turns the Power BI gap into a question about their tooling, and you learn how much of the ramp is tools |
| R4 | "What does the team of twelve supervisors look like: tenure, open seats, where would they need the most from me?" | It shows you are thinking about span and people, which is where your scale objection (A1) sits |
| R5 | "How do the four sites differ most, and what is common to all of them?" | It signals you will not assume one site's playbook transfers |
| R6 | "What would make you say, a year from now, that this was the right hire?" | It makes success concrete, and the answer is a list of what to prioritize |

## Prohibited claims

These are claims this pack will not coach, with the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Power BI, or built Power BI reporting | Negative you stated, F6 | The plain acknowledgment: "I haven't used Power BI." Then a plan, said as a plan. No slot |
| Leads or has led a team of twelve supervisors; operates or has operated four sites | Inflated form of F4 and F1 | The quotes at their own scope: "currently a senior shift manager over 3 supervisors" and "ran the site's peak-season surge plan two years running." The limit is the pack's observation: the material says three supervisors and the site, not twelve supervisors or four sites |
| Reduced cost-per-shipment | Inflated form of F3 | F3's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path." The limit is the pack's observation: the material says mis-pick rate, not cost |
| Five or more years of operations leadership | Inflated form of F7 | F7's quote at its own scope: "7 years in warehouse and distribution ops." The limit is the pack's observation: the sentence says operations years, not leadership years |
| The pick-path redesign was a Lean or Six Sigma project | Inflated form joining F3 and F8 | The two quotes kept separate, each at its own scope: "cut mis-pick rate 40% by redesigning the pick path" and "green belt certified." The pack's observation: nothing in the material connects them. No slot |

## Sources

Provided documents: the JD text and your background, both in your message. No dossier, CV file, interviewer profile or recruiter guidance was supplied.

Searches sent, each refused by the host's permission setting and nothing returned:

- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight regional logistics strategy news terminals` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have fed published value names for VAL questions and, only if a values-style round were detected, a values cheat sheet. Neither exists in this pack |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have fixed the loop structure and the persona weights; the weights are flat instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have grounded a CO or CASE question and a grounding brief; both are absent or generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form |
| 5. representative Operations Manager JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Recruiter's note on the round type, the interviewers' names and titles, and any focus areas → persona weights built from the round and a tailored reverse question; usually one email to the recruiter
- Search access, or a pasted company careers or values page → rows 1 to 3 above stop being unavailable; loop structure and any published values replace the flat weights and the generic VAL bank
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Atlas's current context and strategy-grounded CO and CASE questions; it needs search access, which was refused this session
- Your answers to the slots on F1, F2, F3, F4, F5 and F7 → those rows move from `discovery` or `transferability` toward `[grounded]` stories, and the guidance on A1, A5, B3 and C3 becomes story-mapped
- Your green belt certificate and the pick-path before-and-after figures or report → F3 and F8 can rise from medium to high, and B1 gets real answers
- A sample Excel report you built → F5 can rise from low
- A tuesday-dossier.md from a job-underwriter run → verified evidence, absolute prohibited claims, and the underwriter's named top objection in place of the one this pack inferred
