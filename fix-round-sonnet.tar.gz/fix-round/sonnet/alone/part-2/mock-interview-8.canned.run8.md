I'll read the reference files the skill requires before writing anything.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-canned-c1e1a62e/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It covers all three rounds on 20 November, with a mini-pack for each, and every answer is built only from your own sentences or marked as something for you to fill in.

I built it without interviewer names, since none are assigned, so there is no interviewer read yet. Persona weights come from the round types and the recruiter's description.

- **Highest-ROI prep:** 2B1, the contact-centre question. The JD's first line names the contact centre and you've said you haven't worked in one, so expect it in all three rounds. The pack drills it in three levels: say the limit first, hold on what you actually did, then give a plan for what you'd learn.
- **Second most likely:** the senior-leaders presentation gap, rehearsed in 2C4 and 3F2.
- **Round 3:** the panel scores the four values by name, so you'll find one question for each. The pack also has three practice cases for the 20-minute escalation case and a cheat sheet mapping each value to the sentence of yours it can rest on.
- **Where the pack leaves blanks for you:** the spreadsheet is the main one. Your material doesn't say what it counted or whether it was built in Excel. A few other answers (regulated complaints, coaching above teller level, digital-team work) are also left as short fill-in prompts, so rehearse those with the real answer.
- **Menu items worth acting on:** a recruiter email asking what the 20-minute case looks like, and Ashgrove's jurisdiction and regulator, which none of your inputs state.

Say the word and I'll play the Skeptic on 2B1 so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview pack for Dara

Three rounds on 20 November 2026, built on 11 November 2026.

| Round | Who | Length | Shape |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Screen |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; this is the values round, scored against the four published values |

Names are not assigned for any interviewer, so no interviewer read is included. This pack runs in loop mode: one shared fit snapshot, then a mini-pack per round.

## How to use this pack

- **Personas describe how a question arrives; types describe what it is scoring.** Every question carries both.
- **Type key.** VAL: whether past behaviour shows a published value. EXP: whether what you said about your work survives a follow-up. JD: whether you can do a listed requirement, gaps included. CO: whether you know where the company is heading. CASE: a live problem from the role, scored on structure and reasoning.
- **Question IDs.** Round digit, then persona letter, then number. A Conversational, B Skeptic, C Values/Behavioural, D Case/Strategist, E Peer Evaluator, F Pressure. Example: 2B1 is round 2, Skeptic, first question.
- **Guidance is scaffolding, not a script.** Every line in quotation marks inside a guidance or bridge cell is proposed wording, pending your approval. Change it into your own words.
- **Answer slots.** An answer slot is an instruction for the interview, not a question for you now. It lists two honest branches: say how it went if it was yours, or say plainly that it was not, and return to what your own sentences carry.
- **Highest-ROI prep: 2B1.** The contact-centre objection is the one most likely to be asked in some form in rounds 1, 2 and 3, because the JD's first line names the contact centre and you have said you have not worked in one. It gets the deepest rehearsal below. The second most likely is the senior-leaders presentation gap, rehearsed in 2C4 and 3F2.

## Fit snapshot (shared across all three rounds)

Proposed wording in the bridge column: pending your approval. Confidence grades your evidence; provenance grades what this pack wrote about it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD, branch part | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log, not the process, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how far beyond the log you reached likely. If any other step of a complaint's path was yours, say which, in your own words; if the log was the extent of it, or no other step was yours, say so plainly and stay with the log |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD, contact-centre part | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work |
| F3 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | Your material says a formal complaints log and does not show what, if anything, regulated it. Answer slot: the JD's regulated line makes a probe on which requirements, if any, applied to the log likely. If any did, say which and what part of meeting them was yours, in your own words; if you do not know, or none applied, say so plainly and stay with "I handled the branch's formal complaints log." |
| F4 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Lead with the sentence in its own terms: "6 years in retail banking, the last 3 as a branch supervisor." Six is more than the JD's four, and the interviewer can map the sentence to the JD's term. Do not adopt "customer operations" as your own description of your work |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The sentence says a monthly complaints spreadsheet and does not show what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's monthly-reporting line makes a probe on what the spreadsheet counted likely. Say what it counted, in your own words; if you do not know how it was counted, say so plainly and stay with the spreadsheet |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The sentence says spreadsheet, not which tool. Answer slot: say which tool it was built in, in your own words; if it was a tool someone else chose, or you do not remember, say so plainly and stay with the spreadsheet |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message and "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | The sentence says new tellers, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Your other sentence has you as a branch supervisor for the last three years, which is as far as it goes. Answer slot: the JD's coaching line makes a probe on whether you have trained anyone beyond new tellers likely. If you have, say who and what you did, in your own words; if not, say so plainly and stay with the new tellers |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the JD's digital line makes a probe likely. If you have worked with a digital or app team, say on what and what part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have said it: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Never a claim to senior presentations |

## Grounding brief: Ashgrove's July 2026 strategy

The four items are as you relayed them from the brief the recruiter sent. The reading in the third column is this pack's, not the brief's.

| Item | What the brief says | What it means for this role | Provenance |
|---|---|---|---|
| Digital | "move 40% of member service to digital channels by 2028" | Self-service journeys, the JD's digital line, are the main route to that target, which is why F8 gets asked in all three rounds | [grounded] |
| Hubs | "consolidate eight branches into five hubs over 2027" | Branch managers on the round 3 panel may be affected; the value "Neighbours, Not Numbers — every branch is part of its town" is the one to expect it to be tested against. Whether their branches are among the eight is not known | [inferred] |
| Small business | "launch a small-business lending product in Q1 2027" | A new product is a new place for complaints to arise, so a question on preparing the process for it is likely (2D3) | [inferred] |
| Competition | "the main competitive pressure is app-only banks" | Digital speed is the baseline; the reasoning to bring is where a human answer still matters, and what complaint handling signals to members about that | [inferred] |

## Persona table

| Round | Persona | Weight | How it shows up | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| 1 | A Conversational | high | Friendly biography and motivation questions, scored | Recruiter-screen prior is Conversational plus a light Skeptic | A 90-second arc, rehearsed; treat casual questions as scored |
| 1 | B Skeptic | medium | Quick knockout checks against the JD's requirement list | Same prior; the recruiter owns the screen and will check the requirements one by one | Say the stated gaps first and plainly, then a plan |
| 2 | C Values/Behavioural | high | "Tell me about a time" prompts | The recruiter says this round is mostly behavioural, which lifts it above the hiring-manager prior | Stories only from your own sentences; where none carries one, a selection scaffold with its honest branch |
| 2 | B Skeptic | medium | Probes at the contact-centre, digital and reporting gaps | Hiring-manager prior: they are buying capability and derisking gaps, and this person would be your manager | Hold-then-concede; the deepest rehearsal in the pack is here (2B1) |
| 2 | D Case/Strategist | medium | Live problems from Ashgrove's strategy | Hiring-manager prior, held down because the round is mostly behavioural | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise |
| 3 | C Values/Behavioural | high | Scenario prompts scored against the four values by name | The recruiter says the panel is the values round and scores against the four values | One story or scaffold per value, below |
| 3 | D Case/Strategist | medium-high | The 20-minute complaint-escalation case | Twenty of the sixty minutes are the case | Think aloud, clarify before answering, name one premise you would challenge |
| 3 | E Peer Evaluator | medium | Seam and credit questions from branch managers | Panel rule: blend each member's top two; branch managers are people whose supervisors this role would coach, which is this pack's reading, not a stated fact | Propose seam principles instead of claiming to know the seam; reciprocity framing |
| 3 | F Pressure | low | Short, interrupting challenges at the gaps | Panel prior includes a pressure member; low because no source says this panel is adversarial | Pause, restate, hold two follow-ups, then concede specifically |

The loop is established by the recruiter's email, which names the sessions, who runs each and what each holds. With no interviewer names, weights rest on relationship priors only.

---

## Round 1 mini-pack: recruiter screen (30 minutes)

Proposed wording in these cells: pending your approval.

### Conversational (A), high

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped, 90 seconds, in this order and no further than each sentence goes: the six years in retail banking and the last three as a branch supervisor; the complaints log and the new-teller training; the monthly spreadsheet. Tell each in your own words. Answer slot: why this role and why now is yours to say, and no sentence of yours gives it; say it in your own words and keep it to one reason you can defend | The recruiter opens with the biography and scores whether it matches the CV; F4 is the years requirement and F1 and F5 are the rows this arc touches. EXP because it tests whether the arc survives a follow-up |
| 1A2 | "What's pulling you to Ashgrove, and to this move now?" | CO | [grounded] | The question needs no claim about your past, so the guidance makes none. Name one of the four published values by its name and say in your own words why it matters to you, then one item from the strategy brief you can speak about without notes. A sentence each. The reasons are yours; the pack does not supply them | Motivation consistency is the standard recruiter check, and the recruiter sent the brief, so Ashgrove-specific answers are expected. CO because it scores homework |
| 1A3 | "How do you feel about self-service for a member whose problem has gone wrong — where does an app help, and where does it get in the way?" | JD | [grounded] | The question asks for your view and not your past, so the guidance makes no claim about it. Give two or three criteria in your own words, such as how much judgement the answer needs and whether the member can reach a person at any step, and the plain-words test from the values page: if a member needs it explained twice, it was written wrong. If a digital team comes up, F8's slot applies: say what you worked on with one if you did; if you did not, say so plainly | The JD's digital line is F8, a row with no evidence, and the brief's 40% target makes the topic likely. JD because it scores that requirement, asked casually here and formally in 2B2 |
| 1A4 | "You've seen our strategy brief. Which part of it matters most for how members complain and get an answer?" | CO | [grounded] | Pick one of the four items and go in order: what changes for the member, what changes for the complaints process, what you would want to know first. Name the tension if you see one, for example between the hub plan and "every branch is part of its town". Claims about the past: none | The recruiter sent the brief and will notice whether it was read. CO because it asks for altitude, not experience |

### Skeptic (B), medium

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1B1 | "This role owns complaints across branches and the contact centre, and you haven't worked in a contact centre. Where does that leave you?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The short version of 2B1, built from three beats. Say the limit first: "I've never worked in a contact centre." Then what your sentence carries, at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Then one sentence of plan, in your own words, on what you would learn first and from whom. Stop there | The recruiter is the first to check F2, and a rehearsed plain answer here sets up round 2. JD because it scores the contact-centre part of the first requirement |
| 1B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose from what you have stated yourself: the contact centre, or presenting above regional level. Say it first and plainly, before the recruiter finds it, then a plan in your own words. If you have no digital-team work, that can be your answer too; F8's slot applies. Do not choose a weakness you have not stated and then explain it away | Calibrated candor is what this question scores, and F2 and F9 are the two gaps you named. JD because the answer is read against the requirement list |
| 1B3 | "How comfortable are you with Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Lead with the sentence as it is. Answer slot: say which tool the spreadsheet was built in and what it did, in your own words; if it was a tool someone else chose, or you do not remember, say so plainly and stay with the spreadsheet. Offer to talk it through in a later round rather than describing it from memory of what such sheets usually do | The JD lists Excel among its requirements and recruiters tick it off in screens. F6 is a discovery row, which is why this is a slot and not a story. JD because it scores a listed requirement |
| 1B4 | "The role needs experience handling regulated complaints. What's yours?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with the sentence: "I handled the branch's formal complaints log." Answer slot: say which requirements, if any, applied to the log, and what part of meeting them was yours, in your own words; if you do not know, or none applied, say so plainly and stay with the log. Do not name a regulation you did not work under | The JD's regulated line is the requirement F3 leaves open, and the jurisdiction is not stated in any of your inputs. JD because it scores that requirement |

### Reverse questions, round 1

| Question | Why it lands |
|---|---|
| "Which parts of the complaints process sit with the contact centre today and which with branches, and where would this role's ownership start and stop?" | It takes the contact-centre gap seriously by asking for the boundary, and the recruiter can answer without a hiring-manager's view |
| "What does the 20-minute case look like — a written scenario or a conversation, and is there anything I should read beforehand?" | Only the recruiter can answer it, and it shows you are preparing for the format |
| "Who will be on the panel, and what are their roles in complaints today?" | It gets the interviewer names the pack still lacks, and it shows interest in the people the role would work with |

---

## Round 2 mini-pack: Head of Member Services, your future manager (45 minutes)

Proposed wording in these cells: pending your approval.

### Values/Behavioural (C), high

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "Tell me about a time a complaint you handled was hard to close." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, because your sentence carries the log and no hard case. Pick one case from the log with a named member situation, a decision that was yours, and an ending you can state without adding to it. If no such case comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would handle a hard-to-close complaint | A manager buying complaints capability asks for the hardest case, and F1 is where the pack's evidence ends. EXP because it tests what was actually yours |
| 2C2 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the sentence's own beats: new tellers, the escalation script, training. Tell those in your own words and stop there. Answer slot: the JD's coaching line makes a probe on whether you have trained anyone beyond new tellers likely. If you have, say who and what you did, in your own words; if not, say so plainly and stay with the new tellers | F7 is the transferability row for the JD's coaching line, and a manager will test how far it goes. JD because it scores that requirement through a behavioural prompt |
| 2C3 | "Tell me about a time you had to give someone senior an unwelcome truth." | VAL | [grounded] | Selection scaffold; your material has no sentence for this. Pick a time with a named stake, a moment you did not fold, and a relationship that was intact at the end; the ending has to be one that actually happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The JD's senior-leaders line raises it and it is a standard stem for this persona. VAL because it scores whether the hard truth landed, not generic virtue |
| 2C4 | "Tell me about the last time you presented numbers to someone senior." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Say the limit first: "I've never presented to anyone above regional level." Answer slot: if you walked the regional manager or anyone else through the monthly spreadsheet's figures in person, say who, what they asked and what you did with it; if you sent it on, or you do not know, say so plainly and stay with "I built the monthly complaints spreadsheet our regional manager uses." Then a plan, in your own words, for a first leadership presentation: what you would lead with and who you would ask to review it | F9 is a stated gap and this manager would be the one receiving your reports. JD because it scores the senior-leaders requirement |

### Skeptic (B), medium

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2B1 | "You haven't worked in a contact centre, and this role owns complaints across the branches and the contact centre. Why should I think you can own that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI prep in this pack. Hold-then-concede, three levels. Level 1: pause, restate, and say the limit before it is pressed: "I've never worked in a contact centre. I handled the branch's formal complaints log and trained new tellers on our escalation script." Level 2, "why would that transfer?": say what each of those was, no wider, and stay. Answer slot: if any step in the log's handling touched a contact centre or its team, say what and what was yours; if none did, say so plainly and stay with the log. Level 3, "what would you do in your first month?": say it as a plan, in your own words, naming what you would learn first and from whom. Concede explicitly that this is the part you would need to learn, and never fold on the two things you did do | The JD's first line names the contact centre and F2 is a stated gap, so this arrives in some form from every interviewer. JD because it scores the first requirement; Skeptic because it presses the gap, and it is rehearsed deepest because it is the likeliest |
| 2B2 | "Digital will matter more each year here. What have you done with a digital team?" | JD | [grounded] | Answer slot: if you have worked with a digital or app team, say on what and what part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first. Link to the brief's 40% target only as a reason the question matters, not as experience | F8 is a discovery row with no evidence, and the 40% target makes a manager's probe on it likely. JD because it scores the digital requirement |
| 2B3 | "Walk me through the monthly complaints spreadsheet — what goes into it and what comes out?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped: the spreadsheet, that you built it, that the regional manager uses it, in your own words and no further. Answer slot: say what it counted and how, in your own words. Name the assumption behind its figures that you would defend least, before they ask; if you cannot, say plainly that you do not know how any figure was counted | F5 and F6 are discovery rows that this question opens. EXP because it tests whether the claim survives a follow-up, with the weakest-assumption move |

### Case/Strategist (D), medium

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2D1 | "Eight branches become five hubs over 2027. What does that do to complaints, and what would you want in place before it starts?" | CASE | [grounded] | The question asks about no past, so the guidance makes no claim. Think aloud in order. Clarify: which branches, when, what members will see, and what complaint volumes and resolution times exist by branch today, since you need a baseline to see an effect. Objective: a member always knows who holds their complaint. Segment: members by channel, and complaints by type. Approach: one named owner per complaint through the move, plain-words notices. Metrics: the same figures by branch before and after. Risk: a complaint falling between an old counter and a new hub. Challenge one premise, for instance whether volume alone says how members feel | The hub plan is the brief's most direct effect on branches and complaints. CASE because it is a live problem from the role |
| 2D2 | "Forty percent of member service moves to digital by 2028. Which complaints would you never leave to self-service, and which could you?" | CASE | [grounded] | No claim about your past. Offer criteria and test them aloud: how much judgement the answer needs, what is at stake for the member, whether anything regulated applies (ask what applies; do not state it), whether a member could understand it without explanation twice, and whether a person is reachable at every step. Name what you would measure to know it worked | Joins the brief's 40% target to the JD's digital line. CASE because it scores structure on a role problem |
| 2D3 | "A small-business lending product launches in Q1 2027. How would you get the complaints process ready for it?" | CASE | [grounded] | No claim about your past. Clarify what the product is and who members will talk to first; expect new complaint types and decide who owns them; prepare branch supervisors on escalations before launch, since coaching them is in the JD; decide what the monthly report should show from the first month. Risk: a new product's complaints being treated as old categories | A new product is a new source of complaints and falls inside the role's reporting and coaching lines. CASE because it is a live planning problem |

### Reverse questions, round 2

| Question | Why it lands |
|---|---|
| "What would you want to see from the Member Experience Lead in the first 90 days?" | It asks the future manager to set the bar, which shows you are thinking about delivery |
| "Where do the monthly complaint figures go today, and what decision has one ever changed?" | It treats reporting as a way of deciding things, which is what the JD's reporting line is for |
| "How do the contact centre and the branches hand a complaint to each other at the moment?" | It addresses the contact-centre gap by asking to learn the real boundary |
| "Where do you expect complaints to sit in the move to 40% digital?" | It uses the brief and shows you read it for the role, not for the company |

---

## Round 3 mini-pack: panel of two branch managers (60 minutes, with a 20-minute case; the values round)

Proposed wording in these cells: pending your approval.

### Values/Behavioural (C), high

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3C1 | "Tell me about a time you decided something from the member's side of the counter when it was harder for the branch." | VAL | [grounded] | Value: Members First, Always. Selection scaffold; no sentence of yours carries a story for this. Pick a time with a named decision that was yours, who pushed back, and what the member ended up with, stated as it happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The first published value; the panel scores against all four by name. VAL because it scores a specific decision, not slogan familiarity |
| 3C2 | "Tell me about a time something you or your team said to a member didn't land the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Plain Words. Story-mapped on the sentence's own beats: training new tellers on the escalation script. Answer slot: the value's line, "if a member needs it explained twice, we wrote it wrong", makes a probe on wording likely. If you changed or flagged any wording because members misunderstood, say what and what was yours; if not, say so plainly and stay with the training | Plain Words is one of the four values and F7 is the nearest row. VAL because it scores whether past behaviour shows the value |
| 3C3 | "You built a monthly complaints spreadsheet. How do you stop numbers like that standing in for the member behind them?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Value: Neighbours, Not Numbers. Story-mapped: the spreadsheet at its own scope. Answer slot: the value's line, "every branch is part of its town", makes a probe on whether the reporting kept the branch visible likely. If it did anything of the kind, say what; if it did not, or you do not know what the figures showed at branch level, say so plainly. Then, as a plan in your own words, what you would add so a number stays tied to a branch and a member | The hub plan sharpens this value for branch managers, which is this pack's reading, and F5 is the row the question stands on. VAL because the question tests the numbers against the value |
| 3C4 | "Tell me about a time you kept hold of a problem someone else found until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Own the Fix. Story-mapped on "I handled the branch's formal complaints log". Answer slot: if one case from the log comes to mind where you stayed with it to the end, say what the fix was and which part was yours; if the log was a record and the fixing sat with others, say so plainly and stay with the log | The fourth value, and the JD's own "Own the member complaints process" echoes it, with F1 as the row. VAL because it scores stayed-with-it behaviour |

### Case/Strategist (D), medium-high

Three practice cases for the 20-minute case. Their format is not known; ask the recruiter (round 1 reverse question).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3D1 | "A member writes to the contact centre about a fee dispute they raised in a branch twice. The branch says it is resolved; the member says nobody called back. You are the lead. What do you do first?" | CASE | [generic] | Think aloud. Clarify first: what the member has been told, in what words, what was promised, whether anything is time-limited and what rules apply here. Objective: the member's problem fixed, held by one named person through to the end. Approach: name the owner to the member, check both records, reply in plain words, say when they will hear next. Then root cause and what goes in the monthly report. Risk: blaming the branch or the contact centre in front of the member | The panel's case is a complaint escalation, and this shape spans both channels in the JD. CASE because it is a live problem; generic because it is a pattern, not a fact about Ashgrove |
| 3D2 | "A supervisor wants to close a complaint fast because the request is outside policy, and the member is upset. How do you coach them, in the moment and afterwards?" | CASE | [generic] | Think aloud. In the moment: ask the supervisor what they think the issue is, find who can decide what, and keep the member told. Afterwards: coach in private, start from the supervisor's own reasoning, agree what to do differently, and check in. Name one premise to challenge, such as whether the policy is the issue or the explanation of it | It tests the JD's coaching line on a live problem in front of the people whose supervisors you would coach. CASE because it asks about no past; generic for the same reason as 3D1 |
| 3D3 | "A branch's services are moving into a hub. A member complains: it's not about the money, it's about the town. What does the complaints process do with that?" | CASE | [grounded] | Think aloud: listen and record it in the member's words; decide whether it is a complaint or feedback by asking what the rule is here; reply in plain words; route it to someone who can act; show the theme in the monthly report so it is seen as more than a count. Link to the values "Neighbours, Not Numbers" and "Members First, Always" in your own words | Joins the hub plan to a value the panel scores. CASE because it is a live problem; grounded in the brief and the values page |

### Peer Evaluator (E), medium

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3E1 | "Where's the seam between your job and a branch manager's when a complaint escalates, and what happens when we disagree?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Propose seam principles instead of claiming to know the seam: a member keeps one owner; the branch keeps the relationship; you hold the process and the reporting. Say what happens when you disagree in a plan, in your own words. Answer slot: if a disagreement with an equal comes to mind, say what it was and how it ended; if none does, say so plainly and stay with "the last 3 as a branch supervisor" | Branch managers are the people who would work alongside this role, which is this pack's reading. F4's sentence is the only one that puts you in a branch role. JD because it scores the coaching and ownership lines from the peer side |
| 3E2 | "Some supervisors won't welcome a coach from outside their branch. How would you earn it?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say you were a branch supervisor for the last three years, which is as far as that sentence goes. Then the method, as a plan: ask how they handle escalations before offering a script, and work from their cases. Answer slot: if you have trained anyone beyond new tellers, say who; if not, say so plainly and stay with the new tellers | F7 is the row, and the question tests how the coaching lands. JD because it scores the coaching requirement |
| 3E3 | "What would you want from branch managers in your first three months?" | JD | [generic] | Reciprocity first: what you would bring them, then what you would ask. Offer to take one escalation that costs a branch the most time; ask them which one that is. Principles, not claims about your past | The reciprocity question for a peer panel. JD because it scores partnership fit |

### Pressure (F), low

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3F1 | "Sixty seconds: why you over someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause, restate, hold. Hold on what your sentences carry: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Concede specifically: "I've never worked in a contact centre." Hold it through two follow-ups; the concession is the one thing you add. Do not argue you are better; say what you would learn and how | The stem tests composure at the gap F2 names. JD because the answer is read against the first requirement |
| 3F2 | "You've never presented above regional level. This role reports monthly to senior leaders. Convince me." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Hold: "I built the monthly complaints spreadsheet our regional manager uses." Concede: "I've never presented to anyone above regional level." Hold through two follow-ups, then offer the plan, in your own words: how you would prepare a first leadership report and who you would ask to review it. Do not claim presentations you have not given | F9 and F5 together make this the second most likely objection after 2B1. JD because it scores the senior-leaders requirement under pressure |

### Values / principles cheat sheet (round 3)

| Value (official name) | Working meaning (paraphrased) | Mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quote carries a story. Selection scaffold: pick a decision that was yours, taken from the member's side when it was harder for the branch, with who pushed back and what the member ended up with; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | 3C1 |
| Plain Words | Write so a member never needs it explained twice | F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beats: training new tellers on the script. Slot in 3C2 for any wording you changed | 3C2 |
| Neighbours, Not Numbers | Treat every branch as part of its town | F5: "I built the monthly complaints spreadsheet our regional manager uses." Beat: the spreadsheet. Slot in 3C3 for what it showed at branch level | 3C3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beat: the log. Slot in 3C4 for a case you stayed with | 3C4 |

### Reverse questions, round 3

| Question | Why it lands |
|---|---|
| "What would a new complaints lead do in the first month that would genuinely help your branch?" | The reciprocity question for a peer panel: it asks how to reduce their load |
| "Which escalation costs your branch the most time right now?" | It starts from the panel's own work and gives the case practice a real example |
| "How are you thinking about the move to hubs, and what do you want from complaints when it happens?" | It shows you connected the hub plan to the value "Neighbours, Not Numbers". Ask it with care, since it may touch on the panel's own branches |
| "Which of the four values do you see tested hardest when a complaint escalates?" | It suits a values round and gets you real examples to answer with |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | 1B1, 2B1, 2C1, 3C4, 3D1, 3F1 |
| "report monthly on complaint volumes and resolution times" | 2B3, 3C3, 3F2 |
| "coach branch supervisors on escalations" | 2C2, 3D2, 3E1, 3E2 |
| "work with digital teams on self-service journeys" | 1A3, 1A4, 2B2, 2D2 |
| "4+ years in financial-services customer operations" | 1A1 |
| "experience handling regulated complaints" | 1B4, 2C1 |
| "confident presenting to senior leaders" | 1B2, 2C3, 2C4, 3F2 |
| "comfortable with Excel reporting" | 1B3, 2B3 |

## Prohibited claims

Built from the fit snapshot before the banks were written; the banks follow it.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment F9 gives: "I've never presented to anyone above regional level." No slot |
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says the branch's log, not the process. The slots stay inside the log |
| Handled regulated complaints | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The material does not say what regulated the log. The slot asks only which requirements, if any, applied to it |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: "I trained new tellers on our escalation script." The material says new tellers, not supervisors. The slot asks only whom else you trained |
| Reported complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The material does not show what it counted. The slot asks only what it counted |
| Built Excel reporting | Inflated form of F6 | F6's quote at its own scope: the sentence says spreadsheet, and the pack's observation is that it does not name the tool. The slot asks only which tool it was built in |

## Sources

Provided documents: the job description you pasted; the four published values you copied on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email naming the three rounds on 20 November; the July 2026 strategy brief's four items as you relayed them; your own background as stated in your message. No dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values already name all four, so the values sheet and the VAL questions are fixed |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email already fixes the loop: three sessions, who runs each and what each holds, including that round 3 is the values round |
| 3. `Ashgrove Credit Union strategy` | skipped | The July 2026 brief, about four months old, already supplies the CO and CASE material |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name was given; the interviewer read is absent and the menu below says what a name would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names (Head of Member Services and the two branch managers) → an interviewer read, persona weights adjusted from their public roles, and a reverse question tied to each person's own path
- Your answers to the slots, stated outside a drill: what the monthly spreadsheet counted and which tool it was built in (F5, F6), whether any regulatory requirement applied to the formal complaints log (F3), whom else you have trained on escalations (F7), any work alongside a digital team (F8) → those rows move from `discovery` to evidence and the guidance cells regenerate
- A redacted copy of the monthly complaints spreadsheet or a report from it, the inspectable artifact for complaints reporting → F5 and F6 can reach `high`
- The jurisdiction and regulator that apply to Ashgrove's complaints → the "regulated" rows (F3, 1B4) can name the real requirements instead of staying generic
- A recruiter email asking for the 20-minute case's format and any pre-reading → the round 3 case bank can be matched to it, and any pre-declared deliverable gets its own build section
- How many hours you have before 20 November → a prep triage, ordered by the few things worth doing well
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, on the competitive set and recent organisation context → a sharper app-only-banks answer and a recent-context section; say the word and I will run it
- A tuesday-dossier.md with verified evidence from the job-underwriter → better-graded evidence and a recorded list of claims not to make; never required for this pack
