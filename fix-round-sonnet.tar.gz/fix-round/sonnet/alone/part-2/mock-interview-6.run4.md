I'll read the reference files the skill points to before writing anything.
Search wasn't granted, so I'm building from what you've told me and labeling everything else generic. Writing the pack now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-6-denied-d7f230d4/larkfield-systems_engineering-manager_interview_pack.md`. It's a loop pack: one shared fit snapshot, then a mini-pack for each of the three rounds (10, 12 and 10 questions) with its own persona weights and reverse questions. I assumed the Director is your would-be boss, the panel is a mix of peer and cross-functional styles, and Monday's round is values-led, as the recruiter said.

- **Research:** web search wasn't permitted in this session, so none of the company facts come from Larkfield itself.
  - There's no values cheat sheet, no company-strategy questions, and the case questions are labeled generic.
  - Everything about you is quoted from your message.
- **Highest-ROI prep:** question A2, "I don't see a hardware-adjacent roadmap in your background." It's built from your own admission and will come up in some form in all three rounds.
- **Second priority:** the 60% on-call figure. It gets probed by the staff engineers (D1) and challenged by the VP (I1, I3).

Several fit-snapshot rows (domain, growth, hardware and product partnership) have answer slots instead of scripted stories, because your message doesn't say whether the experience exists. Answer them in your own words and I'll rebuild those rows and the guidance that rests on them.

Say the word and I'll play the Skeptic on A2 as a drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Did the recruiter give any focus areas or pre-work for any of the three rounds? That could add a graded-deliverable section.
2. Can you paste the full job description and your CV? Both would turn the thinnest rows into quoted evidence.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack (loop mode): Engineering Manager, Larkfield Systems

Candidate: Yusuf. Three scheduled rounds, in this order:

- Round 1, Tuesday, 45 min: the hiring manager, a Director of Engineering and your would-be boss. Name not given.
- Round 2, the Thursday after, 60 min: a panel of two staff engineers and a product manager. Names not given.
- Round 3, the following Monday, 30 min: the VP Engineering, described by the recruiter as "values and leadership philosophy". Name not given.

Shared fit snapshot and sources sit around three per-round mini-packs. Interviewer reads are dropped because no names were given.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows values and leadership judgment, not generic virtue |
| EXP | Whether your own claims survive scrutiny: what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: see Sources) |
| CASE | A live problem set in the role; asks about no past |

"Answer slot" means an instruction for what to say in the interview, with two honest branches. Either branch is a good answer. Anything you state outside a drill becomes new material: send it and the affected rows regenerate.

## Prep triage

You have about two weeks and three rounds. The few things worth doing well, in order:

1. Before Tuesday: say A2 aloud until it is boring. It is the highest-ROI prep in this pack, because the hardware-roadmap objection will arrive in some form in all three rounds. Then A1 and A3.
2. Before Tuesday: the 90-second arc in C1, and the first-30-days structure in B1.
3. Before Tuesday: write out your own answers to the slots in F1, F3 and F5 to F7 below, and send them to me. They are the thinnest rows and the ones a Director will press.
4. Between Tuesday and Thursday: D1 and D2 (defend the 60% and the 40 interviews), then E2.
5. Between Thursday and Monday: I1, I2 and H5, then H2. Draft H1 in your own words.
6. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description you pasted. Evidence is your own sentences from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description, your message | "9 years engineering, 3 as a team lead of 6" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | Say it at its own scope: "I've been a team lead of six for three of my nine years in engineering." Plain acknowledgment: "I've never managed managers." The pack observes that the role description names two squads and eleven engineers and does not say whether leads sit between you and the engineers (see reverse question K1). Answer slot: expect a probe on the step from one team to two squads. If you have a view on how you would run that step, say it as a plan, in your own words; if you have none yet, say so plainly and stay with the team of six |
| F2 | "device-management services" and "industrial IoT" — role description, your message | "currently at a payments company" — your message | low | [inferred] | discovery | The pack observes that your material does not show work on devices, fleets or remote operation. Answer slot: expect a probe on distance from industrial IoT. If any of your work touched devices or remote operation, say what it was and which part was yours; if none did, say so plainly and stay with the team you led |
| F3 | "own delivery" — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Say it at its own scope, in the sentence's order: the burden dropped after the quarter you pushed through. The pack observes that the sentence shows a sequence, not a cause, and does not show how delivery was tracked. Answer slot: expect a probe on how delivery was owned day to day. If you set or tracked it, say how, in your own words; if you did not, or it was not yours, say so plainly and stay with the reliability quarter |
| F4 | "hiring and growth for 11 engineers" (hiring) — role description, your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms: "I run our hiring loop for backend roles." Keep "about 40" attached to interviews, which is the noun it came from |
| F5 | "hiring and growth for 11 engineers" (growth) — role description, your message | none given | none | [grounded] | discovery | The pack observes that your material is silent on developing engineers. Answer slot: expect a probe on growth. If you have had a hand in anyone's growth, say what you did and what part was theirs; if not, or it was not yours, say so plainly and say what you would ask each of the eleven engineers first |
| F6 | "partner with hardware and product on roadmap" (hardware) — role description, your message | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | Plain acknowledgment, from your own words: "I've never owned a hardware-adjacent roadmap." Your sentence is about owning, not partnering, and says nothing either way about working beside a hardware group. Answer slot: expect a probe on hardware partnership. If you have worked alongside a hardware or hardware-adjacent group, say how and which part was yours; if you have not, say so plainly, then give a plan for learning it, said as a plan and never as a past |
| F7 | "partner with hardware and product on roadmap" (product) — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | transferability | At its own scope the sentence says roadmap pressure and a reliability quarter pushed through; it does not say who applied the pressure. Answer slot: expect a probe on partnering with product. If the pressure came from product, say how you made your case and what part of the decision was yours; if it came from elsewhere, or the decision was not yours, say so plainly and say what happened |

---

# Round 1: Tuesday, 45 min, Director of Engineering (hiring manager)

### Persona table

The loop is established by your own words (who, how long, what each round is), so these weights follow the rounds you named, not a fallback pattern. The hiring-manager prior is Case/Strategist plus Skeptic.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gap between your background and this role | Highest, 4 questions. Hiring-manager prior, and F1 and F6 hold limits you stated yourself, which is where a boss de-risks first | Rehearse A2 until it is boring: state the limit plainly, then a learning plan, then stop |
| Case/Strategist | Live problems on the squads' real roadmap and delivery | High, 4 questions. Hiring-manager prior: they are buying capability on their own problems | Clarify, then objective, then approach, then risks; think aloud; challenge one premise respectfully |
| Conversational | Chatty opener and casual follow-ups | Lower, 2 questions. It fills the first minutes of a 45-minute slot, and casual questions are still scored | A pre-scripted 90-second arc (C1); treat casual questions on the reliability quarter as scored |

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers"; "never owned a hardware-adjacent roadmap" | Pick one limit and say it plainly in your own words, from your own two sentences. Then a first-weeks learning plan, said as a plan: what you would ask the hardware group and the squads before you decide anything. Stop there; do not volunteer a third weakness. If the weakest part is something else you know about yourself, say that instead, plainly | F1 and F6 hold the limits you stated, so the Director will go there first; JD because it scores honest self-assessment against the stated role |
| A2 | "I don't see a hardware-adjacent roadmap in your background. How would you handle that part of this role?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Level 0, plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Level 1, the plan, said as a plan: what you would ask the hardware group in the first month, such as which dates are fixed by hardware and which software can move. Level 2, if they push on "what if hardware slips": say what you would escalate and to whom, without claiming you have done it. Level 3, concede exactly: "I don't yet know how hardware dependencies constrain these squads' plans, and that is the first thing I would learn." Answer slot: if you have worked alongside a hardware or hardware-adjacent group, say how and which part was yours; if you have not, say so plainly. Hold by returning to the plan, never by adding experience | F6 is the biggest gap and the one you named yourself, so this objection arrives in some form in all three rounds; JD because it scores the stated roadmap-partnership requirement |
| A3 | "You've said you haven't managed managers. If this role put team leads between you and your engineers, how would that change how you work?" | JD | [grounded] "I've never managed managers"; "9 years engineering, 3 as a team lead of 6" | Plain acknowledgment first: "I've never managed managers." The question is conditional because the description does not say whether leads exist; ask the structure back (K1). Then your quote at its own scope: "I've been a team lead of six for three of my nine years in engineering." Then a plan: what you would want from a lead you manage, and what you would stop doing yourself. Answer slot: if you have had anyone on your team take on lead duties, say what you did and what part was theirs; if not, say so plainly and stay with the team of six | F1 holds the stated limit and the one-team scope; JD because the description's "growth" and "two squads" clauses raise the question |
| A4 | "Why leave a payments company for industrial IoT?" | JD | [grounded] "currently at a payments company" | A selection scaffold: pick two reasons that are actually yours, and tie each to a clause in the role description (the squads, the growth of eleven engineers, the hardware partnership). Do not claim knowledge of industrial IoT you cannot back; say what you want to learn. If no reason beyond "I want to manage" comes to mind, say that plainly, then say what you would want to be true about your first year | F2 shows no domain evidence, so motivation will be tested; the pack could not research Larkfield's own priorities, so the answer has to rest on your reasons |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit two squads building device-management services and eleven engineers. What do you need to know first, and what do you do in the first 30 days?" | CASE | [generic] | Structure it aloud: what each squad owns and what it is promised to deliver; delivery state; who the engineers are and what each wants; where hardware and product dependencies sit; then three early actions and the risks of each. Challenge one premise, such as asking whether either squad has a lead today. A plan, never a past: make no claim about having done this | The role description's "two squads" and "11 engineers" are the live problem; [generic] because it is a pattern, not a fact about Larkfield |
| B2 | "Product wants a feature in three weeks, and the hardware team says a dependency slips by six weeks. What do you do?" | CASE | [generic] | Clarify first: what exactly depends on the hardware piece, and whether a partial release is possible. Then options with a trade each, who you talk to and in what order, and what you would concede. If you reach for your own experience, the only sentence your material carries is the reliability quarter at its own scope, "pushed a reliability quarter through against roadmap pressure", and it says nothing about hardware | F6 and F7 are the roadmap-partnership gaps; CASE because a live problem tests structure when experience is thin |
| B3 | "One squad is hitting its dates and the other is not, and you have one hiring slot. Where does it go?" | CASE | [generic] | Ask what is behind the miss before choosing: skills, load, scope, or a dependency. State the criterion you would use, the option you would pick, and the cost of the option you passed on. Think aloud and name the one fact that would change your mind | The role pairs delivery and hiring across two squads (F3, F4); CASE because it forces a trade |
| B4 | "Two squads share an on-call rotation for services customers depend on. How would you structure it?" | CASE | [generic] | Build from first principles: who is paged first, how load is shared between squads, how incidents feed back into the roadmap. Your quote carries the on-call outcome of your reliability quarter, not the method, so do not describe a method as yours. If a part of your own experience informs the answer, say only what your sentence says | F3 is the closest evidence and carries an outcome, not a method; CASE because it asks about no past |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6"; "currently at a payments company" | A 90-second arc with three beats the quotes carry: nine years in engineering; three of them as a team lead of six; now at a payments company. Then one sentence on why this role, in your own words. Practice it timed; it sets the Director's frame for the next 40 minutes | F1 holds the arc; EXP because it tests whether your account of yourself stays at its own scope |
| C2 | "Tell me about the reliability quarter." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F3 using only the sentence's beats: a reliability quarter, roadmap pressure against it, you pushed it through, the on-call burden dropped 60% after. Tell them in your own words. Answer slot: expect a probe on who applied the roadmap pressure and what was traded; if you can say, say it; if you do not remember or it was not yours to decide, say so plainly and return to the quarter | F3 is your headline story and F7 depends on it; EXP because casual questions about the headline claim are still scored |

### Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| K1 | "How are the two squads structured today, and are there leads or senior engineers who would be my first point of contact?" | It asks the structure F1 depends on without confessing anything, and your would-be boss answers it from their own view |
| K2 | "Where does hardware's roadmap constrain the squads' dates today?" | It shows you are already mapping the F6 gap and gives you the facts A2's plan needs |
| K3 | "What does a good first 90 days look like to you?" | It converts B1 into the Director's own success criteria |
| K4 | "What is the biggest delivery risk for these squads right now?" | It tests the "own delivery" clause from the boss's side and tells you where Round 2 will press |
| K5 | "How do you and your managers handle roadmap pressure between product and engineering?" | It opens the topic of your reliability quarter as a peer conversation about their practice rather than a defense of yours |

---

# Round 2: Thursday, 60 min, panel (two staff engineers and a product manager)

### Persona table

Panel rule: blend the top two personas of each member's relationship. Names are unknown, so personas are assigned to the panel as a whole, not per member. Staff engineers are closest to the Peer and Prober priors (they will weigh what working with you costs and contributes, and probe numbers collegially). The product manager is cross-functional: Values/Behavioral plus Conversational.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Line-by-line questions on your 60% and your 40 interviews | Highest, 4 questions. Both numbers are your headline claims (F3, F4), and a staff engineer will ask how they were counted | Know what you can and cannot say about how each number was counted; say plainly when you do not know; name the assumption you would defend least before they do |
| Peer Evaluator | "Where's the seam between us, and what happens when we disagree?" | High, 3 questions. Staff engineers will price what a new EM does to their work | Reciprocity: what you offer their work, not only what you need; propose seam principles rather than pretending to know the seam |
| Values/Behavioral | Scenario probes from the PM about disagreement with product | Medium, 3 questions. A cross-functional interviewer; Larkfield's published values were not available, so themes come from the role description | Choose a story your own sentence carries where one exists; where none does, say so and describe how you would handle it |
| Conversational | A friendly opener and "why this role" | Lower, 2 questions. A 60-minute panel opens warm, and warmth is still scored | A short arc (G1) and a specific answer on industrial IoT (G2) |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Slots a figure raises, each in your own words: how the 60% was counted; what it is sensitive to; the assumption behind it you would defend least; and which part of the change was yours. If you do not know how it was counted, say that plainly and say what you do know: the burden dropped after the quarter you pushed through. Never name a method, baseline or attribution you cannot repeat under a second question | F3 is the headline figure and the likeliest probe from a staff engineer; EXP because it scores attribution honesty |
| D2 | "You said about 40 interviews last year. What does that number cover?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Keep the number on its own noun: it counts interviews, not hires. Say what it covers in your own words: how it was counted, whether you ran or sat in them, and which part of the loop was yours. If it is approximate, say so, as the original does ("about"). If you do not know, say so plainly and say what you do know: you run the hiring loop for backend roles | F4 is the second headline figure; EXP because a probe moves the number to the wrong noun |
| D3 | "How do you calibrate interviewers on a loop?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | The role raises hiring for eleven engineers, and your sentence says you run the loop, not how. Answer slot: if you calibrate interviewers, say how, in your own words; if there is no such step, or it is not yours, say so plainly and describe how you run the loop | F4 covers the hiring clause; JD because it scores the hiring requirement beyond the headline number |
| D4 | "A squad proposes a design to roll out a software update to a large fleet of devices. What do you ask before you let it go ahead?" | CASE | [generic] | Questions first, generic to the problem and not about you: what happens if it fails halfway, how a bad update is rolled back, how the rollout is staged, and how you would know early that it is going wrong. Then say plainly which parts of this are outside your experience and how you would close them. No claim about fleet work: your material does not show any | F2 is the domain gap, and staff engineers test technical judgment as an EM's partner; CASE because it asks about no past |

### Bank E: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where is the seam between what an engineering manager decides and what staff engineers decide, and what happens when we disagree?" | JD | [generic] | Offer principles, not a map of a seam you have not seen: you would ask what the staff engineers want to own technically, you would keep delivery and people decisions, and for disagreements you would want the reasoning on the table before either decides. Then ask how it works today. Say plainly that you are proposing principles, not describing their setup | F1 and F5 raise the role's people and delivery ownership; JD because it scores how you would work with technical leads |
| E2 | "How do you decide what a squad takes on when engineers push for technical work and product pushes for features?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The only sentence your material carries here is the reliability quarter, at its own scope: you pushed it through against roadmap pressure. Answer slot: if you decided between technical work and features, say what the criterion was, in your own words, and who else was in the room; if the decision was not yours, or there was no such choice, say so plainly and return to the quarter | F3 and F7 are the nearest evidence; JD because it scores the "own delivery" and roadmap clauses |
| E3 | "What would you need from us in your first month?" | JD | [generic] | Reciprocity: what you would ask of the staff engineers (where the technical risk lives, which parts of the services they would not change without a fight) and what you would give back (clear priorities, protection from roadmap churn, a hiring plan). Frame the give as a commitment for the future, not something you have done | A peer-style panel prices what the hire costs and contributes; JD because it tests partnership against the role description |

### Bank F: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold: pick a time that has a named customer stake, a metric you did not hit or gave up, and an outcome you can state without embellishing. Check you can say which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Nothing quoted carries this story, so it is a scaffold; VAL because a PM scores whether past behavior shows customer judgment |
| F2 | "Tell me about a time you and a product manager wanted different things from the same quarter. What happened?" | VAL | [generic] | A selection scaffold: pick an occasion where you and a product partner wanted different things, you can say what each wanted, how it was decided, and your part. The only nearby sentence, "roadmap pressure", does not say it came from product, so use it only if it did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role description's "partner with ... product on roadmap" raises it (F7); VAL because the PM is scoring partnership behavior |
| F3 | "Tell me about a time you made a delivery call that an engineer you respected disagreed with." | VAL | [generic] | A selection scaffold: pick a call that was yours to make, with a named disagreement from someone whose judgment you respected, and a state of the relationship afterward you can describe plainly. Do not supply an ending you do not remember. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role description's "own delivery" raises it (F3); VAL because it scores disagreement style with technical peers |

### Bank G: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, tell us a bit about yourself." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6"; "currently at a payments company" | Use C1's arc, cut to 60 seconds for three listeners: nine years in engineering, three as a team lead of six, now at a payments company, then one sentence on why this role. Make eye contact with the PM as well as the engineers | F1 holds the arc; EXP because the opener is scored against the rest of the hour |
| G2 | "What interests you about industrial IoT specifically?" | JD | [grounded] "currently at a payments company" | Your material shows no IoT work (F2), so answer from your real curiosity and what you have actually looked at, in your own words. Pick one thing about the domain that you can say something specific about without bluffing. If you have not looked closely yet, say so plainly and say what you would want to learn first | F2 is the domain gap; JD because a casual question about the core domain is still scored |

### Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| L1 | "What could a new engineering manager do in the first month that would genuinely help your work?" | The reciprocity question for a peer-style panel; it signals you are pricing your effect on their load |
| L2 | "What do you wish engineering managers did differently here?" | It invites candor and tells you where the Skeptic in Round 3 may go |
| L3 | "How do hardware release cycles show up in your planning?" | It addresses F6 from the people who live with it |
| L4 | "Where do product and engineering most often disagree, and how does it get resolved?" | It gives the PM an open lane and tells you how F7 would play out |
| L5 | "What is the on-call load like for the squads today?" | It connects to your reliability quarter as a real interest, not a defense of it |

---

# Round 3: Monday, 30 min, VP Engineering ("values and leadership philosophy")

### Persona table

A loop source documents this round: the recruiter's description, relayed in your message. It names values and leadership philosophy, so a values-style round is detected. The executive prior is Case/Strategist plus Pressure; the recruiter's description moves Values/Behavioral to the top and the case work to the other rounds.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes on how you lead, as a conversation | Highest, 5 questions. The recruiter named the round's purpose | Map a story to each question only where one of your own sentences carries it; "we" for context, "I" for contribution; where none does, say so |
| Pressure | Time-boxed, devil's-advocate challenges on your claims | Medium, 3 questions. Executive prior, and your 60% claim and your limits (F1, F3) are the natural targets | Pause, restate, anchor in what you stated, hold through two follow-ups, concede one thing specifically |
| Conversational | Warm opener and "what do you want next" | Lower, 2 questions. A 30-minute slot opens fast and closes fast | A 60-second arc and one specific "what I want to learn here" |

### Bank H: Values/Behavioral

Larkfield's published values were not available to this pack, so these questions theme from the recruiter's words and from the role description, not from named values. See the upgrade menu.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What's your leadership philosophy?" | VAL | [generic] | Do not recite a philosophy; show one. Pick two or three principles that your own behavior shows, and tie each to one thing you actually did. A selection scaffold: for each principle, ask whether you can name the occasion. If a principle has no occasion behind it, cut it. If no such principle comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The recruiter's "leadership philosophy" raises it; VAL because it scores whether stated values and past behavior agree |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped only on the sentence's beats: a reliability quarter, roadmap pressure against it, you pushed it through, on-call burden dropped 60% after. Answer slot: if the truth was delivered to someone in leadership, say who you told, what you said and how it landed, in your own words; if it was not delivered to leadership, or you cannot recall how it landed, say so plainly and return to the quarter | F3 and F7 are the nearest sentence; VAL because a VP scores whether the hard truth actually landed |
| H3 | "How have you helped someone on your team grow?" | VAL | [generic] | A selection scaffold: pick one person, say what you noticed, what you did, and what changed, and keep their part separate from yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role's "growth for 11 engineers" raises it (F5); VAL because a VP of values scores how you treat the people you lead |
| H4 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | The same scaffold as F1, with the stakes raised for a VP: name the customer stake, the metric you gave up, and what you would do differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | It is a standard values stem; VAL because it distinguishes a decision from a slogan |
| H5 | "How do you decide when to hold a line against roadmap pressure and when to give way?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your sentence carries the hold: you pushed the quarter through against roadmap pressure. Say that at its own scope. Answer slot: if there was a time you gave way, say what it was and what you decided; if there was none, say so plainly and say how you would tell the two apart. Do not claim a decision rule you cannot describe in your own words | F3 and F7 hold the hold; VAL because a VP scores the judgment between conviction and flexibility |

### Bank I: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold-then-concede. Pause and restate the question. Hold only what the sentence carries: the burden dropped after the quarter you pushed through. Through two follow-ups, return to that sentence. Concede one thing specifically: say what you cannot separate from the team's work, in your own words. Answer slot: say which part was yours; if you do not know how the 60% was counted, say so plainly, and never fold on the core claim | F3 is your headline claim, and "how much was you" is the stock attribution probe; EXP because it scores precise attribution under pressure |
| I2 | "Sixty seconds: why you, over someone who has already managed managers?" | JD | [grounded] "I've never managed managers"; "9 years engineering, 3 as a team lead of 6" | Plain acknowledgment first: "I've never managed managers." Then your sentence at its own scope: a team lead of six for three of nine years. Then what you would do in the first stretch, as a plan. Hold through two follow-ups by returning to what you can stand behind; concede exactly the limit and no more. Do not add experience to the answer to win the moment | F1 holds the limit and the one-team scope; JD because the executive prior is a challenge to your fit |
| I3 | "You pushed a reliability quarter through against roadmap pressure. It sounds like you put engineering ahead of the business. Convince me otherwise." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold your sentence at its own scope. Answer slot: say what was traded away for the quarter and who agreed to it; if nothing was traded, or the decision was not yours, say so plainly. Concede where it is fair: roadmap pressure has a business cost, and you would say so. Do not supply a business outcome you did not state | F3 and F7 are the evidence and the likeliest target; VAL because a VP tests whether the leader sees the business trade |

### Bank J: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6"; "currently at a payments company" | A 60-second version of C1's arc: nine years in engineering, three as a team lead of six, now at a payments company, then one sentence on what you want next. Keep it tight: this is a 30-minute round | F1 holds the arc; EXP because a short slot makes the opener a larger share of the score |
| J2 | "What are you hoping to learn here that you can't where you are?" | JD | [grounded] "currently at a payments company" | Say one or two specific things in your own words, tied to the role description: the hardware partnership, a second squad, the growth of eleven engineers. Make it a want, not a deficit speech; your limits were handled in the earlier rounds | F2 and F6 are the domain and hardware gaps; JD because a VP hears this as a signal of self-awareness |

### Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| M1 | "What does engineering leadership hold as non-negotiable in how managers lead here?" | It asks for the values in practice, which is what the round is scoring |
| M2 | "What did an engineering manager who joined from a different industry need to learn first?" | It addresses F2 as an interest in learning, from the person who has watched it happen |
| M3 | "Where is engineering's biggest growth edge over the next year?" | It signals altitude beyond the two squads |
| M4 | "How do you want managers to balance roadmap pressure and reliability?" | It opens the H5 and I3 topic as a conversation about their philosophy |
| M5 | "What would make you say, twelve months in, that this hire worked?" | It gets the success criterion in the VP's own words |

---

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Lead two squads building device-management services" | A1, A3, B1, B3, B4, E1, I2, K1 |
| "device-management services" and "industrial IoT" | A4, B4, D4, G2, J2, M2 |
| "own delivery" | B1, B2, B3, C2, D1, E2, F3, H5 |
| "hiring and growth for 11 engineers" (hiring) | B3, D2, D3 |
| "hiring and growth for 11 engineers" (growth) | A3, H3, J2 |
| "partner with hardware and product on roadmap" | A1, A2, B2, E2, F2, H5, I3, K2, L3 |

CO questions: none, and why: company strategy could not be researched (see Sources), and a CO question without a source would be generic.

## Prohibited claims

Built from the snapshot before the banks were written. These are the claims this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 | The plain acknowledgment F1 gives: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment from your own words: "I've never owned a hardware-adjacent roadmap." Slots stay on whether you have worked alongside such a group |
| Led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope: a team lead of six. The limit is the pack's observation: your material says one team of six, not two squads |
| Owned delivery across a roadmap | Inflated form of F3 | F3's quote at its own scope. The pack observes that the sentence does not say how delivery was tracked |
| Cut on-call burden by 60% through your own work alone | Inflated form of F3 | F3's quote in its own order: the burden dropped after you pushed the quarter through. D1 and I1 slots ask only how it was counted and which part was yours |
| Hired about 40 engineers | Inflated form of F4 | F4's quote: "about 40 interviews last year", on interviews. D2 keeps the number on its noun |

## Sources

Provided documents: your message (the role description, the three round descriptions, and your own background sentences). No CV, no full job description, no interviewer names, no values page, no strategy brief.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Search was not granted in this session, so the values cheat sheet is not built and Round 3's VAL bank themes from the recruiter's words, not published values |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Search was not granted. The loop rests on your own account of the three rounds, which establishes it; the persona weights follow your description and the relationship priors |
| 3. Larkfield Systems strategy and news | unavailable | Search was not granted. It would have fed CO and CASE questions grounded in Larkfield's strategy; none are in this pack and the CASE questions are labeled generic |
| 4. Interviewer name | n/a | No names were given, so there was no query; the interviewer reads are absent |
| 5. Representative engineering manager JD | unavailable | No call sent: search was refused on the first three, and I did not retry. A full posting would add rows to the snapshot |

Queries sent, all refused: "Larkfield Systems industrial IoT values"; "Larkfield Systems interview process engineering manager"; "Larkfield Systems industrial IoT device management strategy news".

## Upgrade menu

- The full job description text → the six rows built from a three-clause description gain every other stated requirement, and any gate terms (location, travel, schedule) are surfaced
- Your CV → evidence cells currently rest on your message alone; every row would gain quoted lines
- An on-call or incident report showing the numbers before and after your reliability quarter → F3 could rise from medium and D1, I1 could be rehearsed against it
- Scorecards or loop documents from your hiring work → F4 could rise from medium
- Larkfield's published values page, pasted → a values cheat sheet for Round 3, with each value mapped to a story your sentences carry or a scaffold
- Answers to the slots in F1, F2, F3, F5, F6 and F7, in your own words → each becomes quoted evidence and the affected rows and guidance regenerate
- The interviewers' names → an interviewer read, persona weights adjusted per person, and a reverse question tied to each path
- The recruiter's notes on any round, or any pre-work → a graded-deliverable section if one was announced
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; search was not granted this session) → CO and CASE questions grounded in Larkfield's current strategy
- A tuesday-dossier.md from earlier work → verified evidence and a named top objection, if you have one
