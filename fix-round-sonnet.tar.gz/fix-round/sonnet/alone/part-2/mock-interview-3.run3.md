I'll start by reading the reference files the skill requires.
Web search was denied in this session, so I'm building the pack from what you've told me plus labeled role-family patterns, with nothing about Stripe taken from memory. I'm writing it to a file now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-3-denied-27d334d8/stripe_product-operations-manager_interview_pack.md`.

Web search was denied in this session. All four searches I sent (Stripe's values, interview process, strategy and a representative job description) were refused, so nothing in the pack is a fact about Stripe. It's built from your message plus role-family patterns labeled `[generic]`. I assumed a final round with an unknown interviewer, so the persona weights are blended. The pack has:

- **Fit worksheet:** seven product-ops requirements with empty evidence cells for you to fill in.
- **Question banks:** 20 questions across seven interviewer styles, plus a requirement-coverage table.
- **Reverse questions:** six, with why each lands.
- **Prohibited claims:** what the pack won't coach.
- **Upgrade menu:** what each missing input would add.

Three things are missing because of the research gap. There is no values cheat sheet, no Stripe-strategy questions and no interviewer read. The pack's provisional highest-ROI prep is B1, "Which part of this role would you be weakest at on day one?" It stays provisional until I see your background.

Say the word and I'll play the Skeptic on B1 live. I can also save a `tuesday-dossier.md` recording the gaps this prep exposes, and convert the pack to Word if you'd like.

Two questions would restructure the pack:
- Who are you meeting, and is the final one session or several? Include any focus areas or deliverables the recruiter mentioned.
- Can you paste the job description and a few lines of your background or CV? If you'd rather not, I'll proceed without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer and relationship: not given, so persona weights are blended. No job description, CV or interviewer profile was supplied, and web research was not available in this session, so this pack is built from your message and from role-family patterns labeled `[generic]`. Nothing here is a fact about Stripe.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it is testing |
|---|---|
| VAL | Whether past behavior shows a company's published values, not generic virtue |
| EXP | Whether the claims on your CV survive scrutiny, and what was actually you |
| JD | The stated responsibilities and qualifications of the role, gaps included |
| CO | Homework depth on the company, its strategy and its recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Because no CV was supplied, every question below that asks about your past comes with a selection scaffold, not a mapped story. Each ends with the same honest branch: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. That branch is a legitimate answer, not a failure.

The pack's provisional highest-ROI prep is B1, the day-one weakness question, because it is the one question that finds whatever is thinnest in your background. It is provisional because without your CV the pack cannot name the objection that is specific to you; sending the CV replaces it.

## Fit snapshot

This is the worksheet variant: with no JD and no CV, the requirements below are role-family patterns written as plain prose, not quotes, and every evidence cell is empty. Fill the evidence column yourself before you rehearse.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run cross-functional launch or release processes for product teams (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is one launch or release you helped coordinate, with the teams involved and the part you owned named in your own words. Pick an instance where you can say who disagreed and how it was resolved; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define, track and explain product or operational metrics (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a metric you owned and can explain end to end: how it was counted, what it was sensitive to, and the assumption you would defend least. If you do not know how a number was counted, say that plainly; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Build or improve operating cadences and mechanisms such as planning cycles and reviews (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or changed, with what it replaced and what changed afterward, in your own words. Pick one where you can separate what you designed from what you inherited; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influence product, engineering and go-to-market partners without direct authority (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a disagreement across teams where you had no authority and the relationship was intact afterward. It needs a named stake and a moment you did not fold; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Turn customer, field and internal feedback into product priorities (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a case where feedback from several sources changed what a team did, with your part separated from the team's. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Communicate clearly to senior leaders, including unwelcome news (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a message you delivered to someone senior that they did not want to hear, and what happened to it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Clear understanding of why product operations, and why this company (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a reason for the move that you can say in two sentences and that matches your own history. It also needs one thing about Stripe that you read or used yourself; the pack supplies none |

## Persona table

No loop source establishes how Stripe's final round is run, and the research that would have found one was refused, so the fallback archetype is Generic: flat weights, said plainly. The weights below tilt slightly toward the hiring-manager pairing of Case/Strategist and Skeptic. Recalibrate them once you know who you are meeting.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A live problem set in the role: plan this launch, diagnose that metric | High. A hiring-manager prior puts it first, and product operations work is mostly structuring ambiguous situations. 4 questions (A) | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic | Quiet probing of gaps, motivation and why-now | High. Same hiring-manager prior, and a role that is often confused with adjacent ones invites it. 4 questions (B) | Rehearse the most predictable objection until it is boring. Use only adjacent evidence you actually have, plus a concrete ramp plan |
| Peer Evaluator | Where the seam sits between teams, collaboration and credit | Medium. Plausible if a peer is on the final loop; the role itself sits between teams. 3 questions (C) | Reciprocity framing: what you bring their team. Offer seam principles rather than pretending to know the seam |
| Values/Behavioral | Scenario probes, often from outside the function | Medium. A cross-functional interviewer is plausible, but no loop source says Stripe runs a values-style round, and no published values were read, so themes come only from the standard stems. 2 questions (D) | Choose stories where the hard truth actually landed; say plainly where you have none |
| Data-Driven Prober | Reads claims line by line and asks for inputs and assumptions | Medium. A metrics-heavy role invites it, from a peer or a manager. 3 questions (E) | Know what you can and cannot say about how each number was counted; name the weakest assumption before they do |
| Conversational/Rapport | Friendly, unstructured openers | Medium to low as a standalone, but the opener and the closing slot are scored in any round. 2 questions (F) | A 90-second arc for the biography question; never answer the closing slot with a pass |
| Pressure/Stress | Interrupts, time-boxes, tests composure | Low to medium. Possible in a final round with a senior interviewer. 2 questions (G) | Pause, restate, anchor in what you actually said, hold through two follow-ups before conceding anything real |

## Question banks

Every question is labeled `[generic]`: none rests on a quoted sentence of yours, and none presupposes anything about your past. Where a question asks for a time, it is an open prompt and you choose the instance.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two weeks before a launch, engineering, support and go-to-market each believe a different readiness date is realistic. What do you do?" | CASE | [generic] | Clarify first: what the launch has to achieve, who decides the date, and what evidence each team is using. Then structure: compare the three views on shared criteria, find what actually blocks each, propose options with a recommendation, and say how you would communicate the outcome. Challenge one premise, for example whether one date has to serve all three teams | F1's requirement set in a live situation. CASE because it asks for structure, not a story |
| A2 | "An adoption metric for a recent launch fell 20 percent week over week. Diagnose it." | CASE | [generic] | Ask what the metric is and how it is counted, whether anything changed in instrumentation, and which segments moved. Then rank hypotheses: measurement, mix shift, a real behavior change, an external cause. Name the assumption you would defend least before you are asked, and say what data would settle it | F2's requirement; the persona's own stem. The weakest-assumption move is built in |
| A3 | "You take over a weekly product review that people attend but nothing changes afterward. What do you do in your first month?" | CASE | [generic] | Diagnose before prescribing: what decisions the meeting is meant to make, who owns the follow-through, and what the attendees actually want from it. Propose a small change you can test, a way to tell whether it worked, and what you would stop doing | F3's requirement. Tests whether you reach for process before understanding |
| A4 | "Support, sales and customers all send product requests that conflict with the roadmap. How do you decide what reaches product teams?" | CASE | [generic] | Structure it as intake, triage, evidence, decision and closing the loop with the people who asked. Say what you would need to know first, for example how many sources and how much volume. Name one thing you would deliberately not forward and why | F5's requirement. CASE rather than EXP because it asks for a method, not a past |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack, provisionally. Pick one requirement from F1 to F6 where your own material is thinnest, name it plainly, and follow it with a concrete first-month plan, not reassurance. Hold the answer through two follow-ups; concede a specific limit rather than retreating to a generic strength. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | This question finds the thinnest row of whichever snapshot you complete. JD because it scores the role's listed demands, Skeptic because the interviewer is deciding what to derisk |
| B2 | "Why product operations, rather than product management or program management?" | JD | [generic] | Say what you want to spend your days doing, in terms of the work, not the title. Where your material carries a reason, use it in your own words; where it does not, say so plainly, then give the nearest thing it does carry, or how you would handle it. Do not criticize the adjacent roles | F7's requirement. Role confusion is the likeliest motivation probe for this title |
| B3 | "Why are you looking to move now, and why this role?" | JD | [generic] | A two-sentence reason that is true and forward-looking, then one specific thing about the role. Rehearse until it is boring. Keep it consistent with what you told the recruiter | F7's requirement; the Skeptic's why-now stem. Inconsistency here costs more than weakness elsewhere |
| B4 | "What have you looked at on Stripe's own products or public materials that made you want this role, and what would you question?" | CO | [generic] | Choose something you read or used yourself and describe it as what you saw, not as a summary of the company. Offer one respectful question or critique. The pack supplies no Stripe facts, so nothing here is borrowed; if you have not looked yet, do it before the interview | CO because it scores homework depth. This is the thin spot in the pack: the strategy research that would have grounded a sharper question was not available |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Offer principles, not a pretended map: who owns the decision, who owns the process, and how disagreements get escalated. Say you would want to learn how it works here before proposing changes. Show spine and tact together | F4's requirement. The peer stem verbatim from the persona model |
| C2 | "How do you handle credit when work spans teams?" | EXP | [generic] | State your principle first, then choose one instance where the work was shared and say exactly which part was yours, with we for context and I for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4's requirement. Attribution honesty is what a peer is checking |
| C3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Reciprocity: lead with what you would bring, then ask for specific things such as context, introductions and examples of past decisions. Avoid a list of needs only | Rewards the reciprocity framing the persona calls for |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: choose a time with a named stake, a moment you did not soften it, and a relationship still intact afterward. Use we for context and I for what you said and did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6's requirement; the values persona's own stem. No published Stripe values were read, so this is not mapped to any |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision where the two pulled in different directions, what you chose, what it cost, and who you had to bring along. Say what was your call and what was not. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5's requirement; the persona's other stem |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a metric you have owned. How was it counted, and which assumption behind it would you defend least?" | EXP | [generic] | Choose a metric you can explain without notes. Say how it was counted, what it was sensitive to, and name the weakest assumption in your own words before they ask. If you do not know how a figure was counted, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2's requirement. EXP because it tests whether a claimed number survives questioning |
| E2 | "How would you decide what to measure for a product launch, and how would you know the measure was wrong?" | JD | [generic] | Start from the decision the measure supports, then pick a small set, define each precisely, and set a check such as comparing against a second source. Say what you would do if the numbers disagreed with what teams report | F2's requirement as a method question; presupposes nothing about your past |
| E3 | "Tell me about an analysis you did yourself, start to finish. Where did the data come from, and what did you leave out?" | EXP | [generic] | Choose one you can walk through end to end, and be ready to say what was excluded and why. Separate what you did from what a teammate did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's offer-a-walkthrough counter-strategy, asked as a question. F2's requirement |

### F. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, two or three turning points, and why this role is the next step. Every line must be something you can stand behind when asked a follow-up. No CV was supplied, so the pack cannot draft the arc; write it from your own sentences and keep it consistent with your CV | F7's requirement. Casual in register, but it is the question the whole interview is calibrated against |
| F2 | "Is there anything we have not covered that you would like us to know?" | JD | [generic] | Have one prepared item: something relevant that earlier questions did not reach, said in under 30 seconds. Never answer that the interviewer has covered everything | The closing slot is scored in rapport-style conversations, and the persona model flags the empty answer as a preparation signal |

### G. Pressure/Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give two reasons that rest only on things you can substantiate. Hold your position through two follow-ups; concede one specific limit, for example what you would need to learn about the company, without folding on the core claim | Tests composure. The persona's own stem, with the hold-then-concede structure |
| G2 | "Product operations can look like overhead. Convince me this role pays for itself." | JD | [generic] | Say what the work changes in terms a product leader cares about, such as decisions made faster or fewer surprises at launch, without inventing a number. Hold the position through two follow-ups; concede that the value is hard to measure and say how you would try | F3's requirement. Pressure because it challenges the role's existence, not your history |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 cross-functional launches | A1, C1 |
| F2 metrics and analysis | A2, E1, E2, E3 |
| F3 operating cadences | A3, G2 |
| F4 influence without authority | C1, C2, C3 |
| F5 turning feedback into priorities | A4, D2 |
| F6 communicating with senior leaders | D1, G1 |
| F7 why the role and why the company | B2, B3, B4, F1, F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does product operations own here, and what sits with product managers and engineering?" | Shows you are thinking about the seam before you try to change it, which is the C1 answer made real |
| R2 | "What would make the first six months a clear success in this role?" | Gets the real scorecard in the interviewer's own words and lets you test it against your plan |
| R3 | "Which launch or process recently went well, and which would you do differently?" | Invites candor and signals you think in terms of mechanisms, not blame |
| R4 | "How do product teams here decide what to measure, and who owns the definitions?" | Connects to the metrics work in F2 and surfaces how much ambiguity you would inherit |
| R5 | "What is the hardest part of working across teams here?" | A peer-friendly question that turns the last part of the interview into a conversation |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question; strongest if a peer is in the loop |

None of these is tied to an interviewer's own career path, because no interviewer profile was supplied; the upgrade menu says what one would add.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your past, numbers, team sizes, tools or results that you have not told me | No candidate sentence was supplied, so the pack holds nothing to quote and nothing it may assert | Your own words, limited to what you did; where a question asks for something you did not do, say so plainly and describe how you would handle it |
| Any statement about Stripe's values, strategy, products or hiring process presented as fact | Research was refused, and model memory is not a source for these | What you read or used yourself, described as what you saw |

## Sources

Provided documents: none. Your message supplied the company, the role and the round.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Queries sent, all refused (no permission granted for web search):

- Stripe operating principles values: refused
- Stripe interview process Product Operations Manager: refused
- Stripe Product Operations Manager job description: refused
- Stripe strategy 2026 annual letter stablecoins agentic commerce: refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have added the values cheat sheet and named VAL themes; none is included |
| 2. Stripe interview process, product operations | unavailable | Would have set the loop and persona weights; the Generic fallback archetype is used instead |
| 3. Stripe strategy and recent news | unavailable | Would have grounded CO and CASE questions in current priorities; the CO and CASE banks are generic |
| 4. Interviewer name | n/a | No name was given, so there was no query to form; no interviewer read is included |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the F1 to F7 requirements into quoted, inferred rows; they are generic prose |

## Upgrade menu

- The job description text → F1 to F7 become quoted requirements, JD-tagged questions are tied to its exact lines, and some answer slots become possible
- Your CV or a few lines on your background → the worksheet becomes a real fit snapshot, selection scaffolds become story-mapped answers, and the pack can name the objection specific to you
- Who you are meeting and whether the final is one session or several → persona weights are recomputed, and per-session mini-packs become possible
- The recruiter's prep email, including any announced deliverable → a build section for a case, presentation or take-home
- The interviewer's name → an interviewer read from their public footprint and a reverse question tied to their own path
- Stripe's published values page, or its description of the interview loop, pasted in → a values cheat sheet and loop-based weights
- Web search access for a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief and strategy-based CO and CASE questions
- A tuesday-dossier.md, if you already have one → verified evidence and claims to avoid, which would sharpen the highest-ROI objection
