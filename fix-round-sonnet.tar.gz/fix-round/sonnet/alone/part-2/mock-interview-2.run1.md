I'll read the reference files the skill points to before building the pack.
I'm finishing the pack. Two cell references in the saved file need correcting, then I'll present it.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-2-denied-8b4bbb89/atlas-freight_operations-manager_interview_pack.md`. It has 23 questions across seven interviewer styles. I built it for a hiring-manager round, since I don't know who you're meeting.

The three web searches on Atlas Freight were refused, so the pack has no facts about the company beyond your JD. The company-knowledge question is thin and the values questions are generic.

The question to rehearse most is B1: "This role is twelve supervisors across four sites. You lead three today. Why should I believe the step up works?" Expect it in some form. The pack coaches you to say the number plainly and move to a first-30-days plan. The other gap it flags is Power BI, which you said you've never used.

Say the word and I'll play the Skeptic on B1, with follow-ups that react to what you say.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting, and is it a recruiter screen, the hiring manager, a peer or a panel? The answer reweights every bank, and any focus areas or exercises the recruiter mentioned would sharpen it further.
Would you paste your CV text? The pack currently quotes only your message, and your CV's own lines would replace those quotes and could change some gap ratings.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not given. Relationship and round type: not given, so this pack is built as a hiring-manager round and reweights the moment you tell me otherwise. Interview: next week.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and only say what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether the claims on your background survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its level |
| CASE | Structure and reasoning on a live problem from the role |

Labels in the Provenance column: `[grounded]` means traceable to your JD or your message, with the sentence quoted beside it. `[inferred]` means derived from something adjacent. `[generic]` means a pattern for this kind of question with no claim about you or Atlas Freight.

An answer slot is an instruction for the interview, not a question for me. It asks you to say what is true in your own words, and every slot has a second branch for when the practice was not yours or never existed. That branch is a limit, not a confession.

## Prep triage

You have about a week. Do these in order, aloud, not in your head.

1. B1 and D3, three times each. This is the highest-ROI prep in the pack: the step from leading 3 supervisors to a team of 12 is visible in the JD itself, so expect it in some form.
2. C1, C2 and D2. Write down what you actually know about how the 40% was counted and which part was yours. Where you don't know, practise saying so plainly.
3. B3 and A5. Have your plan for the reporting requirement ready as a plan, not as a past.
4. One case a day from A1 to A4, aloud, timed.
5. The F1 arc, the reverse questions, then B2 and B5.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material is warehouse and distribution work, a shift-manager role and the site's surge plan. It does not show terminals or work across several sites, and the words stay at that scope: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on scope likely. Say what the surge plan covered and what part was yours, in your own words; if it was narrower than that, or not yours to set, say so plainly and stay with the plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate is a different measure from on-time performance and cost per shipment, and the words stay at the measure: cut mis-pick rate 40% by redesigning the pick path. Answer slots, each in your own words: how the 40% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you don't know how it was counted, say so plainly |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The JD says 12 and your sentence says 3, and the number stays attached to its noun: "I'm currently a senior shift manager over 3 supervisors." Say the number, then move to how you would take on the larger team, said as a plan and never as a past |
| F4 | "build reporting in Excel/Power BI" — JD, the Excel half | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" says skill with the tool, not what was built with it or who used it. Answer slot: say what you use Excel for, in your own words; if it is mostly not reporting, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD, the Power BI half | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your quotes show seven years in the field and a current supervising role; they do not show how many of the seven years were spent in which roles. A length-of-experience requirement is a risk to rehearse, not a gate. Answer slot: name each role behind the seven years and what it covered, in your own words; if you can't separate the years by role, say so plainly and stay with "7 years in warehouse and distribution ops" |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification line with nothing inspected behind it, so expect a probe on it. Lead in the quote's terms: "I'm green belt certified." Your sentence does not name the framework, so say which one the belt is in. Answer slot: if you have applied it on real work, say where and what was yours; if not, say so plainly and stay with the certification |

## Persona table

No loop source established Atlas Freight's process (the lookups were refused, see Sources), so these weights rest on this skill's hiring-manager prior and on the fit snapshot, not on a documented loop. If your round is a recruiter screen, peer chat or values round, tell me and I'll reweight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy applied to you |
|---|---|---|---|
| Case/Strategist (bank A) | Live problems on terminal operations: diagnose a slipping metric, plan a surge | High. The hiring-manager prior leads with this persona, and the JD asks you to own daily operations | Clarify, objective, segmentation, approach, metrics, risks, thinking aloud. Where the surge case arrives, name your own work once in the quote's words (F1): "ran the site's peak-season surge plan two years running" |
| Skeptic (bank B) | Quiet, persistent probing of the team-size step and the tool gap | High. The hiring-manager prior leads with it, and F3, F5 and F1 are where the material is thinnest | Rehearse the single most predictable objection until it is boring: F3, "currently a senior shift manager over 3 supervisors", held at that scope, then a ramp plan |
| Data-Driven Prober (bank C) | Walks the 40% down to its inputs | Medium. Not a hiring-manager default, but a quantified claim is the line a close reader of your background goes to first | Know what you can and cannot say about how the figure was counted (F2): "cut mis-pick rate 40% by redesigning the pick path". Name the weakest assumption before they do |
| Pressure (bank D) | Time-boxed challenges to why you, and to how much was you | Medium. Prior only; nothing in the material shows this loop uses it | Pause, restate, hold through two follow-ups, concede specifically (F3) |
| Conversational (bank F) | Friendly opener, journey question, a casual question on the JD's plus-skill | Medium. Tilts up if the first conversation is a recruiter screen, which is not assumed | A 90-second arc built only on what your quotes state (F6) |
| Values/Behavioral (bank E) | Scenario probes | Low. No loop source documents a values round, so none is detected, and no published values were available | Selection scaffolds with an honest branch; no values sheet is built |
| Peer Evaluator (bank G) | Seam-splitting between sites, credit-sharing | Low. Applies only if a peer is in the loop | Seam principles rather than a pretended seam; "we" for context, "I" for contribution |

## Question banks

Ordered by weight. IDs run by persona.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one of your four terminals has slipped over the past month. What do you need to know first, and how do you structure the diagnosis?" | CASE | [generic] | Think aloud in order: clarify (which terminal, what counts as on-time, since when, what changed), objective, segmentation, approach, metrics, risks. Challenge one premise respectfully, for example whether the slip is real or a change in how it is measured. The case asks nothing about your past, so the guidance makes none | A live problem built from the JD's on-time performance line (F2's requirement); CASE because it scores structure and clarification before an answer |
| A2 | "Cost per shipment is rising while volume is flat. Where do you look first, and what would make you stop looking?" | CASE | [generic] | Same structure. Name the cost components you would ask to see rather than asserting which one is the cause, say what data you need before you conclude, and say what would change your mind. No claim about your past | The JD's cost-per-shipment line (F2's requirement) asked as a decision; CASE because the reasoning is the score |
| A3 | "Peak season is six weeks out and volume across the four sites is forecast well above normal. Sketch the surge plan and tell me what you need to know first." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Name your own work once, in the quote's words, then work the case as a case: clarify (forecast, constraints, what service level is protected), objective, a plan per site, risks, how the supervisors get briefed. What your own plans contained is yours to say only if you did it; this guidance does not supply it | F1 is the only evidence on surge work; CASE because it is delivered live, and it lets the strongest line in your material meet the JD's four sites |
| A4 | "You'd inherit twelve supervisors across four sites, and today you lead three. What do you do in your first 30 days?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | A plan, not a past. Open with the quote at its own scope, "I'm currently a senior shift manager over 3 supervisors", then the plan: what you would ask each supervisor before changing anything, which site you would see first and why, what you would measure, what you would leave alone. Say it as intentions, never as things you have done | F3 is the evidence for the team-size requirement; JD because it scores a stated requirement, asked as a plan so it tests reasoning rather than history |
| A5 | "What goes on a daily operations report for four terminals, and how would you build it?" | JD | [grounded] "solid Excel" | Structure it: who reads it, what decision each line supports, a handful of measures (the JD names on-time performance and cost per shipment; ask what else), how often, where the data comes from, how you would know it is trusted. On tools, "solid Excel" is the quote's scope; for Power BI use B3's plain words and plan | F4 and F5 are the reporting requirement's evidence; JD because the requirement names the work, CASE delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role is twelve supervisors across four sites. You lead three today. Why should I believe the step up works?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Follow-up one ("three isn't twelve"): concede by saying the number the quote states, then give the plan, what you would learn from the supervisors before changing anything. Follow-up two ("what makes you think you'd hold up"): return to the plan and which site you would see first, and do not reach for a past the quote does not carry. Never argue the number; say it and move to the plan | F3 is where the JD presses hardest, so this objection arrives in some form; JD because it scores the stated requirement, delivered as a Skeptic |
| B2 | "The JD has you owning four terminals. What is the biggest operation you've been accountable for?" | JD | [grounded] "ran the site's peak-season surge plan two years running" | Story-mapped on F1: you ran it, it was the site's, two years running, the beats the quote states, told in your own words. Answer slot: the JD's four-site line makes a probe on scope likely. Say what the plan covered and what part was yours; if it was narrower than that, or not yours to set, say so plainly and stay with the plan you ran | F1 is the nearest evidence for the operating-scope requirement and the likeliest place to be probed; JD because it tests the stated requirement |
| B3 | "Power BI is in the job and you've never used it. How do you handle that?" | JD | [grounded] "solid Excel, never used Power BI" | Plain words first: "I haven't used Power BI." Then what the quote carries: "solid Excel." Then the plan, said as a plan: what you would build first and how you would learn it before you needed it. No claim to Power BI work, and no softener like "I've dabbled" | F5 is a gap you stated; F4 is the nearest evidence. JD because it is a stated requirement, Skeptic because it goes straight at the gap |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "never used Power BI" | Choose the one you can say plainly in one sentence. Your quotes give two candidates: the size of team ("I'm currently a senior shift manager over 3 supervisors") or Power BI ("I haven't used Power BI"). Say it, then the ramp as a plan. Don't offer a weakness that is a strength in disguise | F3 and F5 are the two gaps you have named; JD because it asks which listed requirement is weakest |
| B5 | "The JD asks for 5+ years of operations leadership. Walk me through the roles behind your seven years." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Story-mapped on F6: seven years in warehouse and distribution ops, now a senior shift manager over 3 supervisors, the beats the quotes carry. Answer slot: the JD's 5+ years line makes a probe on the roles behind the seven years likely. Name each role and what it covered, in your own words; if you can't separate the years by role, say so plainly and give what you can state | F6 is a discovery row: the material does not show the leadership years, and the requirement is stated as required. EXP because it tests what each role actually was |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the figure in the quote's own words. Answer slot: say how the 40% was counted, in your own words; if you don't know how it was counted, say so plainly. That sentence is a credibility gain, not a failure | F2 holds your only quantified claim, so a defend-the-number question is near-certain; EXP because it tests how the figure was reached |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The weakest-assumption move: name, in your own words, the assumption behind the 40% you would defend least, before they do, and what the figure is sensitive to. If you don't know of one, say so plainly rather than inventing one | F2's number is the line a prober goes to; EXP because it tests whether you know your own assumptions |
| C3 | "The role is judged on on-time performance and cost per shipment. What have you measured?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what you measured in the quote's terms: mis-pick rate. Answer slot: say what the mis-pick rate counted and what else, if anything, was counted alongside it; if nothing else was, say so plainly and stay with the mis-pick rate. Never describe a measure you did not track | F2's thin bridge, rehearsed so the honest answer is ready before the probe; the question's premise is the JD's, and the guidance does not adopt it |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has already run several sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "green belt certified"; "currently a senior shift manager over 3 supervisors" | Pause, restate the question, then sixty seconds from what the quotes carry: seven years in warehouse and distribution ops, green belt certified. Hold through two follow-ups. Concede only what a quote states, for example "I'm currently a senior shift manager over 3 supervisors", and never fold on the core claim to restore harmony | F1, F3 and F7 are the evidence available against a candidate with wider scope; JD content, Pressure delivery |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: say which part was yours, in your own words; if the work was shared, or most of it was not yours, say so plainly. "We" for context, "I" for what you did. Hold the quote's scope through two follow-ups and concede specifically | F2's attribution is what this probe tests; EXP because it checks what was actually yours |
| D3 | "I'm not convinced a shift manager can run four terminals. Convince me." | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | Pause, restate. Hold with the two quotes at their scope: a senior shift manager over 3 supervisors, and you ran the site's peak-season surge plan two years running. On each follow-up concede the scope the quotes state and add none, then give the ramp as a plan | F1 and F3 are the pressure points on the headline requirement; JD content, Pressure delivery |

### E. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship that was intact afterwards, and say what you did and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard persona stem; no published Atlas Freight values were available, so this is a pattern and not a values mapping |
| E2 | "Tell me about a time you had to bring a team of supervisors along with a change you wanted." | VAL | [generic] | Selection scaffold: pick a change where someone pushed back, say what you did about it and how it ended, "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's team-of-supervisors line raises the theme (F3's requirement); VAL because it scores behavior, not a skill |

### F. Conversational/Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc on the beats the quotes state: seven years in warehouse and distribution ops, now a senior shift manager over 3 supervisors. Close in your own words with why this role. Any step you add in between should be one you can stand behind under a follow-up | F6 supplies the beats; EXP because the opener is still scored for what you actually did |
| F2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Lead in the quote's terms: "I'm green belt certified", and say which framework the belt is in, since the quote does not. Answer slot: if you are applying it on current work, say where and what was yours, in your own words; if you aren't, say so plainly and stay with the certification | F7 is the plus-skill row; JD because the JD names it, asked casually because casual questions on a JD plus are still scored |
| F3 | "What do you know about Atlas Freight, and what is pulling you to this role?" | CO | [generic] | No verified facts about Atlas Freight were available to this pack. Say only what you found yourself, and treat the JD's own words as your anchor: "regional logistics, 800 employees" and four sites. For what is pulling you, give a reason you actually hold and a specific one, not a complaint about where you are. If you have found little, say so plainly and say what you would want to understand first | The company-knowledge slot, thin because research did not run; CO because it tests homework |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Two of the sites want the same resources in the same week. How do you and I settle it?" | CASE | [generic] | Offer seam principles instead of a pretended seam: who decides, what data settles it, when it escalates. Frame it as reciprocity, what you bring the other site, not only what you need. No claim about your past | Peer-style collaboration scenario set in the JD's four-site structure; CASE because it is a live problem |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | "We" for context, "I" for contribution. Use a story only where you can say exactly which part was yours; if none comes to mind, say so plainly and say how you would decide credit | A standard peer stem; VAL because it scores behavior toward equals |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A2, A3, B2, D1, D3 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, C3 |
| "lead a team of 12 supervisors" | A3, A4, B1, D3, E2 |
| "build reporting in Excel/Power BI" | A5, B3 |
| "5+ years operations leadership required" | B5, D1 |
| "Lean/Six Sigma a plus" | F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance defined here, and does the definition differ across the four sites?" | Shows you would measure before you change anything, and quietly settles what the JD's wording on that line means |
| R2 | "What does daily reporting look like today, and who builds it?" | Scopes the Excel/Power BI requirement honestly, and shows you ask where the data lives before proposing tools |
| R3 | "Of the twelve supervisors, where is the team strongest, and where is it thinnest?" | A leadership question: it asks for the team as people, not a headcount |
| R4 | "Which of the four sites is hardest to run, and why?" | Invites the real operating picture and tells you where you would be tested first |
| R5 | "What would a good first 90 days look like, and what would a good first year look like?" | Converts the job into criteria you can be measured on and shows you are planning to deliver |
| R6 | "Which cost-per-shipment lever does the team already know about but has not been able to pull?" | Shows you think in levers and constraints, and surfaces what has already been tried |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team of 12 supervisors | A claim F3's quote contradicts | The quote itself: "currently a senior shift manager over 3 supervisors". Nothing more |
| Owned terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material says warehouse and distribution work, a shift role and the site's surge plan. B2's slot stays inside what the plan covered |
| Improved on-time performance or cost per shipment | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says mis-pick rate. C3's slot asks only what the mis-pick rate counted |
| Built reporting in Power BI, or has Power BI experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't used Power BI." No slot |
| Built Excel reporting or dashboards | Inflated form of F4 | F4's quote at its own scope: "solid Excel". The limit is the pack's observation: your material says the tool, not what was built. F4's slot asks only what you use it for |
| Seven years of operations leadership | Inflated form of F6 | F6's quote at its own scope: "7 years in warehouse and distribution ops". B5's slot asks only for the roles behind it |

## Sources

Provided documents: the JD text and your message describing your background. No dossier, CV, interviewer profile or recruiter guidance was provided.

Searches sent, every one refused (no result returned):

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics news strategy 2026" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have moved the values cheat sheet and given the VAL bank (E1, E2) published values to map to; as it is those two are selection scaffolds |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have moved the loop structure and the persona weights, which rest here on the hiring-manager prior and no documented loop |
| 3. `Atlas Freight regional logistics news strategy 2026` | unavailable | Every call was refused. It would have moved question F3 in the Conversational bank and given the CASE bank a grounding in Atlas Freight's current priorities |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Not in this pack because their conditions did not hold: graded deliverables (none announced), grounding brief (no L2 research), interviewer read (no profile), values cheat sheet (no values-style round detected and no published values in hand), delivery coaching (no assessment).

## Upgrade menu

- Who you are meeting and what kind of round it is, in a line → persona weights recomputed from the hiring-manager assumption, and a banks reorder if it is a recruiter screen, a peer or a values round
- The recruiter's note on focus areas or any pre-declared exercise → coverage in place of round-type priors, and a build section if a deliverable was announced
- The interviewer's name or public profile → an interviewer read and a reverse question tied to their own path
- Your CV text → the evidence column for F1 to F7 moves from your message to your CV's own lines, and F4 and F6 may be regraded
- Atlas Freight's values or careers page pasted in, or search access granted → a values cheat sheet if a values round is documented, a loop that replaces the assumed one, and a CO bank grounded in their current priorities
- Your answers to the slots on B2, B5, C1, C3, F2 and the F4 row → F1, F2, F4 and F6 move from `transferability` or `discovery` toward `none` where your answers support it, and the bridges become your own words
- The green belt certificate, and the before-and-after mis-pick report behind the 40% → F7 and F2 could reach `high`, since a certificate and a before-and-after report are the inspectable artifacts for these claims in operations
- A `tuesday-dossier.md` from an earlier evidence review, if you have one → verified evidence and a named top objection in place of the one inferred here
