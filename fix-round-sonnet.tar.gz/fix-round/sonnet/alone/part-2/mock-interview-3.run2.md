I'll read the skill's reference files first.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-3-denied-5f4aa9d2/stripe_product-operations_interview_pack.md`. I wrote it to `stripe_product-operations-manager_interview_pack.md` in that same directory, so use that filename.

My web searches were refused, so the pack holds no facts about Stripe's values, loop or strategy. I had no JD or CV either, so every row is generic. It has 22 questions across seven interviewer styles and six reverse questions. It also has a worksheet in place of a fit snapshot. I built it as a final round with an unknown interviewer and flat weights across the styles. The question I'd rehearse first is B1: "Which part of this role would you be weakest at on day one?"

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in this final round (future manager, peer, skip-level, cross-functional), and did the recruiter name any focus areas or a deliverable such as a presentation? Your answer reweights every bank.
2. Can you paste the JD and your CV? Either one turns the generic rows into answers built from your own words, and I'll proceed without them if you'd rather not.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer name, relationship to you and session schedule: not given. Built on the Generic loop archetype with blended persona weights (see the persona table). No JD, no CV and no web research were available, so nothing here is a fact about Stripe or about you. Every row is `[generic]` and is meant to be upgraded.

## How to use this pack

- Personas are how a question is asked. Types are what is being scored. Tags: VAL (behavioral and values alignment), EXP (work-experience deep-dive), JD (role and responsibility fit), CO (company and strategy knowledge), CASE (live problem).
- Answer guidance is scaffolding, not a script. Where it says to pick an instance from your own work, the instance and every detail in it must be yours. Nothing in this pack supplies a project, a number or an outcome for you.
- Because no CV was supplied, experience questions carry a selection scaffold that ends with an honest branch. Rehearse the branch you can truthfully take.

## Fit snapshot (worksheet variant)

No JD, recruiter wording or fetched posting was available, so the requirements below are role-family prose, not quotes from a posting for this role. No evidence has been given, so every evidence cell reads none given. No row is a gate; the material does not show whether a term such as location or work authorization applies.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or programs that cross several functions (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is one named effort that crossed functions, with your own part separable from the team's. Selection scaffold: pick one such effort and say what was yours; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it |
| F2 | Build or improve the operating rhythm of a product organization, such as planning, reviews and intake (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a process you introduced or changed, who used it afterward, and what you can show about whether it held. Selection scaffold: pick one process where your role in setting it is clear; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it |
| F3 | Define and track metrics and turn data into decisions (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a figure you reported, with how it was counted and what part was yours. Selection scaffold: pick one figure whose counting you can explain; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it |
| F4 | Influence and align stakeholders without direct authority (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a time a group moved because of something you did, with the stake and the relationship afterward. Selection scaffold: pick one such time; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it |
| F5 | Improve tooling and workflows that teams use to plan and track work (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a tool or workflow you changed and what you know about its use afterward. Selection scaffold: pick one where your hand in it is clear; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it |
| F6 | Work fluently with a technical product and its users (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a technical product you worked closely with, and in what capacity. Selection scaffold: pick one and state your capacity exactly; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it |

## Persona table

Stripe's loop is not documented in anything I could read, so the weights rest on the Generic archetype, which means flat, and on relationship priors for an unknown final-round interviewer. Recalibrate if you know who you are meeting.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems: diagnose a metric, plan a process, resolve a conflict between teams | high. A hiring manager or skip-level leans here, and product operations work is problem-shaped [generic] | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic | Quiet probing of day-one weaknesses, motivation, and influence without authority | high. A final round is where gaps get cross-examined, and with no CV I cannot yet say which gap [generic] | Rehearse the single most predictable objection until it is boring. See B1 |
| Peer Evaluator | Seam between teams, what you would need, credit and disagreement | medium. A peer or cross-functional interviewer is plausible in a multi-session final for a role that sits between teams [generic] | Reciprocity framing, seam principles rather than a pretended seam |
| Values/Behavioral | Scenario prompts and stories | medium. No source established a dedicated values round, so this rests on the archetype, not on a documented session [generic] | Pick stories where the hard truth actually landed. "We" for context, "I" for contribution |
| Data-Driven Prober | Counting, assumptions, what was yours | medium. Anyone who reads a CV closely will probe its numbers [generic] | Know how each figure was counted, name your weakest assumption first, say plainly when you do not know |
| Pressure | Time-boxed, devil's advocate | low. Possible at skip-level altitude, but nothing indicates it [generic] | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational | Friendly openers that are still scored | low. Likely as a warm-up, with little depth to prepare [generic] | A 90-second arc for the biography question |

## Question banks

Highest-ROI prep in this pack: B1, "Which part of this role would you be weakest at on day one?" It is inferred from the role family, not from your CV, because no CV was given. Once a CV exists, the real objection replaces it.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you're supporting keeps slipping, and three teams each say it's another team's dependency. What do you do in your first week?" | CASE | [generic] | Clarify first: what is launching, who owns the final call, what exactly slipped and why. State your objective, then break the dependencies into groups, then your approach: one shared view of dependencies, one named owner per item, a short check-in cadence. Name the metric you would watch and the main risk. Challenge one premise aloud, for example whether the problem is dependencies at all or unclear scope. The question asks about no past, so the guidance makes no claim about yours | Tests F1 as a live problem, because coordinating across teams is the role-family core. CASE because it is scored on structure, not on a history |
| A2 | "Adoption of a recently launched feature dropped 20% week over week. Diagnose it." | CASE | [generic] | Ask how adoption is defined and measured, whether the instrumentation or a release changed, and over what period. Split by segment, then rank hypotheses and say which data you pull first and what decision each result would change. Say what you would not conclude from one week | Tests F3. A stem straight from the Case persona, so it is a likely format whichever interviewer arrives |
| A3 | "Sketch how you would set up a quarterly planning and review process for a product organization that doesn't have one. What do you need to know first?" | CASE | [generic] | Start with the questions: who decides today, what already exists informally, what has gone wrong. Then principles, not a template: minimum process that earns its keep, a pilot with one team, a way to see whether people actually use it. Name what would make you stop or change course | Tests F2. The "what do you need to know first" stem rewards clarifying before answering |
| A4 | "Two product teams want the same shared resource for the same launch window and neither will give way. How do you decide?" | CASE | [generic] | Clarify what is truly constrained and what each team loses. Frame the decision criteria before the answer, say who should make the final call, and where you would escalate and why. Show how you keep both teams trusting you afterward | Tests F4 without needing a past story. Influence without authority is where this kind of role is hardest |
| A5 | "What do you think a product operations team should focus on at Stripe over the next year, and what would you want to learn first?" | CO | [generic] | This pack holds no verified facts about Stripe's current priorities, because research was unavailable. Before the interview, read Stripe's own published material and bring one specific thing you found, saying where you found it. Then say what you would ask in your first weeks. If you have not looked yet, say what you would read first. Never recite from memory | The honest cost of missing research: a CO question that would otherwise be grounded in current strategy stays generic. CO because it scores homework depth |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Before the interview, go through F1 to F6 and choose the one where your honest evidence is thinnest. Name it plainly in one sentence, then give a concrete ramp: what you would ask, who you would learn from, and what you would produce in the first 30 days. Do not pick a disguised strength. If you cannot choose, that is the finding: send me a CV and this answer gets built from your own words | The likeliest question for any candidate in a final round, and the one a rehearsed non-defensive answer helps most. JD because it scores the role's stated demands, including its gaps |
| B2 | "Why leave your current role, why this role, and why now?" | JD | [generic] | Three short parts, each in your own reasons: what you want more of, what this role offers that is specific to the work, why now. Keep each part checkable. Avoid admiration for the company as the only reason | Scores motivation consistency, which a Skeptic cross-examines. JD because it tests fit with the role |
| B3 | "In this kind of role you often can't tell people what to do. Where does your influence come from?" | JD | [generic] | Selection scaffold: pick one time you moved a group you did not manage. It needs a named stake, what you did to earn agreement, and an intact relationship at the end. Tell it with I for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would build influence in a new group | F4 is the requirement behind this, and it is the usual stress point of an operations role. JD because it scores a stated competency |
| B4 | "You'll be dropped into a product area you don't know. What do you do in your first 30 days?" | JD | [generic] | A ramp plan, not a past story: who you talk to first, what you read, what small thing you deliver early to learn the area, and how you check you are learning the right things. Say what you would ask your manager in week one | Covers F6 and gives B1 a rehearsed continuation. The plan carries no claim about your history |

### C. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, such as who owns the decision, who owns the follow-through and who needs to be informed, instead of pretending to know the seam. For disagreement: say what you would bring to the peer first, how you would surface the difference early, and when you would escalate | Tests F4 in collegial packaging. A principle-based answer survives not knowing their team |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a piece of work across teams where the shares are distinguishable. Use we for the context and I for your contribution, and show you named others' parts out loud. If no such work comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Credit-sharing is a peer evaluator's collaboration check on F1. VAL because it scores behavior, not a published value |
| C3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Two short lists. What you need: context, access, introductions, one honest view of what is broken. What you offer: a way to reduce their coordination load that you can state without claiming it already exists. Reciprocity beats a list of needs | Reciprocity is what a peer is pricing. The question asks about the future, so it needs no past claim |

### D. Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: choose a time the hard truth actually landed, not one with a tidy ending you would have to supply. You need what you said, to whom, what it cost you, and what changed. Use I for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard stem for a behavioral interviewer, and relevant to F4. No published Stripe values were retrievable, so it is not mapped to any |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: choose one decision where the customer cost and the metric cost were both real and you can state both. Say what you chose, what you gave up and what you learned. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would weigh the two | Another standard behavioral stem. Whether Stripe frames its values this way is not established in this pack |
| D3 | "A stakeholder asks for a report that would take a week, and you think the decision doesn't need it. What do you do?" | JD | [generic] | A decision approach: ask what decision the report supports, offer a smaller version that answers it, agree what you would not build, and keep the relationship. No past claim is needed | Tests prioritization and F3, in a hypothetical that tells the interviewer how you protect your own time and others' |

### E. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Choose a result you've reported with a number. Walk me through how it was counted." | EXP | [generic] | Selection scaffold: choose one figure whose counting you can explain. Say how it was counted, what it is sensitive to, and which part was yours, in your own words, and do not name a method you did not use. If you do not know how it was counted, say so plainly. If no such figure comes to mind, say so plainly, then say how you would measure the work | Every headline number on a CV is a probe target, and F3 raises it. EXP because it scores whether your claims survive scrutiny |
| E2 | "For that same result, which assumption would you defend least?" | EXP | [generic] | Name the weakest assumption you know of in your own words, before the interviewer does. If you do not know one, say so plainly and say how you would find out | The follow-up that turns a gotcha into a credibility gain. It stands on E1 |
| E3 | "You're asked for the one metric that shows whether a launch process is working. What is it, and how could it mislead you?" | JD | [generic] | Say what you would measure and why. Then say how it could mislead, such as gaming, lag or ignoring quality, and what second signal you would pair it with. Ask what the process is for before you answer | Tests F3 and F2 together. It scores whether you know a metric's limits |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give two reasons you can back with something you actually did. Hold them through two follow-ups. Concede specifically what an internal candidate has, which is context, and say how you would close that gap. If you cannot back a reason with your own work, drop it | Tests composure. The reasons cannot be written until your evidence exists, so this cell stays scaffolding |
| F2 | "Pick a result you're proud of. How much of it was actually you?" | EXP | [generic] | Choose a result where you can separate your part from the team's. State your part in one sentence with I, name others' parts, and hold that through two follow-ups. Concede exactly what you do not know about the rest. Never claim a share you cannot defend | Attribution probes are the pressure persona's favorite. EXP because it scores what you actually did |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in three beats: where you started, what turned you toward operations-type work, why this role now. Write it from your own sentences. The CV I have not seen is where the beats come from | The most common casual opener, and it is scored. EXP because it frames your history |
| G2 | "What are you actually playing with these days in how teams plan and track their work?" | JD | [generic] | Name one real thing you have tried and say what you learned from it. If you have tried nothing recently, say so plainly and say what you would try first and why | Tests F5 in a casual register. The question is likely to be treated as a scored one |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 cross-functional coordination | A1, C2 |
| F2 operating rhythm | A3, E3 |
| F3 metrics and data | A2, E1, E2, E3 |
| F4 influence without authority | A4, B3, C1, D1 |
| F5 tooling and workflows | G2 |
| F6 technical product fluency | B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would success in this role look like at 90 days, and at one year?" | Makes the interviewer define the bar, and shows you think in outcomes |
| R2 | "Which product teams does this role work with most, and where is the coordination hardest today?" | Shows you expect friction and want the real seams, not the org chart |
| R3 | "How does the team tell whether its processes are working, and what has been retired because it wasn't?" | Signals you measure process, and that you are willing to remove it |
| R4 | "What decision would you like this role to be able to make without escalating?" | Probes the actual authority behind the influence question in B3 |
| R5 | "What is the hardest thing about this role that doesn't show up in the job description?" | Invites candor, and gives you the real day-one risk for B1 |
| R6 | "If you're a peer on the team: what could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer interviewer, and it signals partnership. Skip it if the person is not a peer |

No interviewer profile was available, so no question is tied to an interviewer's own path.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No sentence of yours was supplied, so there is no wording to stretch and no stated negative to protect | Entries get built when a CV or your own words arrive. Until then, any claim you reach for under pressure should be one you can back with something you actually did |

## Sources

Provided documents: none.

Searches sent, all refused, so nothing was read:

- Stripe operating principles values users first: refused
- Stripe interview process Product Operations Manager final round: refused
- Stripe strategy news 2026 stablecoins agentic commerce annual letter: refused
- Stripe Product Operations Manager job description responsibilities qualifications: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search was refused. It would have fed a values cheat sheet, which stays absent: it needs published values in hand and a documented values round |
| 2. Stripe interview process for the role family | unavailable | Search was refused. It would have established the final-round structure, so persona weights rest on the Generic archetype instead |
| 3. Stripe strategy and recent news | unavailable | Search was refused. It would have grounded A5 and a grounding brief; A5 stays generic |
| 4. Interviewer name and Stripe | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Search was refused. It would have supplied quoted requirements for the fit snapshot; the rows are role-family prose instead |

## Upgrade menu

- A JD, pasted: the six role-family rows become quoted requirements, and the JD-tagged questions gain a raising source for answer slots
- Your CV: the worksheet becomes a real fit snapshot, selection scaffolds become story-mapped answers, headline figures get defend-the-number questions, and the prohibited list gets real entries
- Permission for web search: Stripe's published values, documented loop structure, a recent-strategy sweep and a representative JD, which would ground A5, the persona weights and possibly a values cheat sheet; a deeper pass is up to 6 more searches and 2 more fetches, several more minutes
- Interviewer names and roles: an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their path
- The recruiter's prep email, including any declared deliverable: coverage of the deliverable, and focus areas replace assumed coverage
- Your schedule, if your final is several sessions: per-session mini-packs with their own weights
- Prep time available: a prioritized prep triage
- A working-style assessment, if you have one and want to share it: delivery coaching keyed to question IDs
- A tuesday-dossier.md from job-underwriter: verified evidence, a named highest-ROI objection and absolute prohibited claims
