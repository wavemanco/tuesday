I'll read the skill's reference files first.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-2-denied-81945776/atlas-freight_operations-manager_interview_pack.md`. I built it for a hiring-manager round, since you don't know who is interviewing you.

- **What it holds:** a fit snapshot of the JD against your own words, 22 rehearsal questions across seven interviewer styles, six questions for you to ask them, and a list of claims it won't coach.
- **No company research:** my three web searches on Atlas Freight were refused, so the pack has no facts about Atlas beyond your JD. It also has no company-knowledge questions or values cheat sheet.
- **Highest-ROI prep:** A1, "you lead three supervisors today and this role has twelve." Your material says three, and the pack coaches you to hold that at three, concede the gap plainly and give a plan for the rest.
- **Open slots:** where your material was silent, the pack leaves an answer slot instead of filling in details. The ones that matter most are the 40% figure (how it was counted, which part was yours) and how many of your seven years were in a leadership post.
- **Power BI:** you said you've never used it. The pack coaches "I've never used Power BI," followed by how you'd learn it.

Say the word and I'll play the Skeptic on A1 so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is interviewing you — your future manager, a peer, a recruiter or a panel — and did the recruiter mention a focus area, a presentation or a take-home? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack — Operations Manager, Atlas Freight

Interviewer: not known. Relationship: not known; built on the assumption of a hiring-manager round. Interview: next week.

## How to use this pack

- Personas are how a question is asked. Types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.
- Type key:
  - VAL: whether past behavior shows values, not generic virtue
  - EXP: whether your claims survive scrutiny and attribution
  - JD: whether you can do the listed job, gaps included
  - CASE: a live problem from the role, scored on structure
  - CO: company and strategy knowledge (no CO questions in this pack; see Sources and the upgrade menu)
- Answer slots are instructions for the interview, not questions for you now. Each ends by letting you say the practice was not yours or never existed. Either honest branch is a good answer.
- Bank IDs skip the letter F so they never collide with fit-snapshot rows (F1 to F7).
- The loop is not established, so persona weights rest on a generic archetype and a hiring-manager assumption, not on Atlas's documented process.

## Prep triage (interview next week)

1. A1: rehearse the three-versus-twelve answer until it is boring. It is the highest-ROI prep in this pack.
2. A5: work out, before anyone asks, how your seven years divide between roles.
3. C1 and E2: be able to say how the 40% was counted and which part was yours.
4. A3 with B5: say the Power BI line plainly, then the plan.
5. B1 and B2 aloud once each, thinking out loud, clarifying before structuring.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution work and a surge plan for the site, not terminal operations or more than one site, and the words stay there: "I have seven years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site and terminal lines make a probe likely on whether any of your work was terminal operations or reached beyond one site. If any was, say which and what part was yours; if none was, say so plainly and stay with the warehouse and distribution work |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says mis-pick rate, not on-time performance or cost per shipment, and the words stay at that scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: a figure raises four probes. How it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer each in your own words; where you do not know, say so plainly |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says three supervisors where the JD says twelve, and the words stay at three: "I'm currently a senior shift manager over three supervisors." Answer slot: if you have led a larger group at any point, say where and how many; if not, say so plainly and stay with the three. How you would approach a larger group is a plan, said as a plan and never as a past |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | Your material says an Excel skill, not what was built in it, and the pack writes no claim about reporting from it. Answer slot: the JD's build-reporting line makes a probe on what you have built likely. If you built any reporting, say what it showed and who used it, in your own words; if you did not, or it was someone else's, say so plainly and stay with the skill level you stated |
| F5 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives seven years in ops and a current management role, and does not show how many of the seven were in a leadership post. This is a requirement of length, not a gate. Answer slot: the JD marks it required, so a probe on the count is likely. Say how the seven years divide between roles, in your own words; if fewer than five were in a leadership post, say so plainly and stay with the current role |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification line with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: "I'm green belt certified." Answer slot: expect a probe on how you have used it. If you applied it to any of your work, say what and how, in your own words; if you did not, say so plainly and state the certification as it stands |

No row is a hard gate: the JD's years requirement is a length of experience, and nothing else in it is a term such as a licence, location or schedule.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of the three-versus-twelve gap, the terminal and four-site scope, and Power BI | Highest. A hiring manager buys capability and derisks gaps, and F3, F1, F5 and F6 are where this material is thinnest | Rehearse the single most predictable objection (A1) until it is boring; bridge only from what you said; give a plan for the rest |
| Case/Strategist (B) | Live problems from the role: on-time drop, peak surge across sites, a first-ninety-days plan, a scorecard | Highest. Hiring-manager prior, and the JD is operational, so live problems are likely | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (C) | Reads your lines closely and asks how the 40% was counted | Medium. The JD names reporting and cost-per-shipment, and the 40% is the one headline number | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Conversational (D) | A friendly "walk me through the journey" that is still scored | Medium. Openers are near-universal, and the JD flags Lean/Six Sigma as a plus, which a casual question can probe | A 90-second arc built from your own sentences; treat casual questions about the JD's plus-skill as scored |
| Pressure (E) | Time-boxed "why you" and "how much of that was you" | Lower. Plausible in an operations loop, but nothing in the inputs signals a stress style | Pause, restate, hold two follow-ups, then concede specifically |
| Values/Behavioral (G) | Scenario probes on an unpopular truth or service over a metric | Lower. No values-style round is detected: no loop source was available and the generic archetype assumes none | A selection scaffold per question, ending in its honest branch |
| Peer Evaluator (H) | Seam-splitting between sites or teams, credit-sharing | Lowest. A peer may sit in a multi-session loop; nothing says so | Reciprocity framing; propose seam principles rather than pretending to know the seam |

## Question banks

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, B1, B2, B3 |
| "drive on-time performance and cost-per-shipment down" | A4, B1, B4 |
| "lead a team of 12 supervisors" | A1, B3, E1 |
| "build reporting in Excel/Power BI" | A3, B5, C2 |
| "5+ years operations leadership required" | A1, A5 |
| "Lean/Six Sigma a plus" | D3 |
| Headline figure on your CV: the 40% | C1, E2 |

### A. Skeptic (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead three supervisors today and this role has twelve. What changes, and where would you be weakest on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I'm currently a senior shift manager over three supervisors." Concede the arithmetic plainly: the role has twelve, which is more than three. Follow-up one, "why would three prepare you for twelve?": return to the three and describe how you lead them, in your own words, never adding to it. Follow-up two, "what would you do in your first month?": answer as a plan, said as a plan and never as a past. Answer slot: if you have led a larger group at any point, say where and how many; if not, say so plainly and stay with the three. Name the one area where you would need ramp-up before they name it | F3 is the widest numeric gap and F6 the nearest hard requirement, so this objection arrives in some form; JD because it scores the stated team-size line, and Skeptic because it presses the gap quietly |
| A2 | "How does a warehouse and distribution background carry over to terminal operations across four sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running" | Tell only the beats the quotes state: seven years in warehouse and distribution ops, and the site's peak-season surge plan, run two years running. Answer slot: if any of your work was terminal operations or reached beyond one site, say which and what part was yours; if none was, say so plainly and stay with the warehouse and distribution work | F1 is where the role's scope presses hardest; JD because it scores the stated scope, premised only on F1's own quotes |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "currently a senior shift manager over 3 supervisors" | Choose from your own self-assessment and name it before they do. Two items carry a limit you have stated: "I've never used Power BI", followed by how you would learn it, said as a plan and never as a past; and the three supervisors against the JD's twelve, rehearsed in A1. Never name a weakness you could not then discuss for two follow-ups | F5 is the one stated absence and F3 the widest gap; JD because it scores the whole requirement list, and Skeptic because the stem asks you to indict yourself |
| A4 | "You cut mis-pick rate. How does that translate to on-time performance and cost per shipment?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold at the quote's scope: "I cut mis-pick rate 40% by redesigning the pick path." The link to the JD's metrics is reasoning, so say it as reasoning ("I would expect…"), never as a result you achieved. Answer slot: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words; where you do not know, say so plainly | F2 is where the JD's headline metrics are furthest from the evidence; EXP because it tests what the figure actually covers |
| A5 | "The role requires five or more years of operations leadership. How many of your seven years were in leadership?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: say how the seven years divide between roles, in your own words, and which were in a leadership post. State the count as a count, not an adjective. If fewer than five were, say so plainly and stay with the current role: "I'm currently a senior shift manager over three supervisors." Decide this answer before the interview so it is not worked out live | F6 is a required line the evidence does not count; JD because it scores a stated requirement |

### B. Case/Strategist (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four sites drops ten points in a month. Diagnose it." | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: which site, which lanes or shifts, since when, and what changed. State the objective, then segment: network-wide against site-specific, inbound against outbound, then by cause. Name the metrics you would pull, the quick containment, and the risk of fixing the symptom. Think aloud and challenge one premise respectfully | A live problem from the JD's on-time line (F2's requirement), asked as a decision rather than a record; generic because it is a pattern for the problem, not a fact about Atlas |
| B2 | "Peak season hits all four terminals at once with no extra headcount. Plan the first two weeks." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | You may say what the quote says: you ran the site's peak-season surge plan two years running. Anything about what that plan contained is yours to say in your own words; name only what it did contain. Then structure the problem: demand forecast, constraints, what you would protect first, how you would tell early that a site is slipping, and what you would trade off | F1 and F6 touch scale; CASE delivery with the one surge-plan quote as the only grounding |
| B3 | "You inherit twelve supervisors across four sites. Walk me through your first thirty days." | CASE | [generic] | A plan, said as a plan. Structure it: listen before changing anything, see each site, establish the baseline numbers each site already uses, find where the four sites differ before standardizing, and agree two or three early priorities with your manager. Say what you would not change yet | F3 and F1 together are the role's real job; CASE because the answer is a plan, not a record |
| B4 | "Cost per shipment has crept up for two quarters. Where do you look first, and what would you report weekly?" | CASE | [generic] | Clarify what is in the cost figure and who owns each part. Segment by site, lane and cost line, find the driver before proposing a fix, and say what the weekly view contains and who reads it. The tool is secondary to the content | F2's second metric and F4's reporting requirement in one problem; CASE because it is diagnostic |
| B5 | "Design the daily scorecard you would want from each of the four sites." | CASE | [grounded] "never used Power BI" | Content first: the few measures that decide the day, the cut-off times, who acts on which number. If asked which tool, the honest line is the one you stated: "I've never used Power BI", followed by how you would learn it, said as a plan and never as a past | F4 and F5 are the reporting rows; CASE because it is a design problem, with the stated gap carried honestly |

### C. Data-Driven Prober (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick figure was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what the quote says: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, in your own words. Name the weakest assumption before they do. If you do not know how the figure was counted, say so plainly and say what you do know | F2's only quantified claim and the likeliest place to be probed; EXP because it tests whether the figure survives scrutiny |
| C2 | "The role is about building reporting. What have you built in Excel?" | JD | [inferred] "solid Excel" | Answer slot: if you built any reporting, say what it showed and who used it, in your own words; if you did not, or it was someone else's, say so plainly and stay with the skill level you stated, "solid Excel". Never name a report you could not walk through end to end | F4 has the thinnest evidence of any row that carries a claim; JD because it scores the stated requirement, inferred because the quote says a skill, not an output |
| C3 | "Walk me through the surge plan you ran. What did the two seasons look like side by side?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Tell only the beats the quote states: the site's peak-season surge plan, run two years running. Answer slot: the JD's on-time line makes a probe on what was tracked likely. If you tracked results, say what and how they were counted; if nothing was tracked, or it was not yours to track, say so plainly and return to the plan you ran | F1's surge quote, probed for the numbers behind it; EXP because it tests attribution |

### D. Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc whose beats are these sentences and nothing else, in the order that tells your story best. Say each at its own scope and let the interviewer draw the inference. End on why this role, which is yours to say | The near-universal opener, still scored; EXP because it is a CV walk-through |
| D2 | "What draws you to this role at Atlas?" | JD | [generic] | Pick one line from the JD you want, for instance the daily ownership or the four-site scope, and say why in your own words. If no reason comes to mind, say so plainly, then give the nearest thing you do want from the role. Company facts are not in this pack because research was unavailable; add one you have verified yourself | Motivation consistency; generic because no company facts were established |
| D3 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | State the certification as it stands: "I'm green belt certified." Answer slot: if you apply it to any of your current work, say what and how, in your own words; if you do not, say so plainly and say what you would use it on | F7 is the JD's plus-skill, asked casually; JD because it scores the stated plus |

### E. Pressure (weight lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has already led twelve supervisors?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "currently a senior shift manager over 3 supervisors" | Pause, restate the question, then hold. Offer two or three points from your own sentences at their own scope, and concede the span plainly: you lead three now and the role has twelve. Do not argue the other candidate down. Hold through two follow-ups before conceding anything more | F3 is where a challenge lands; JD because it scores the stated team size, Pressure because of the time-box |
| E2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say in your own words what was yours and what was others'; if others contributed, say so plainly, and if it was all yours, say that. Never widen it under pressure | F2's figure tested for attribution; EXP because it is the classic attribution probe |

### G. Values/Behavioral (weight lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | No quoted sentence carries this, so pick a time: it needs a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for a values probe; generic because no published values were available |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time with a named customer need, the metric you set aside, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; relevant because the JD pairs on-time performance with cost, which can pull apart |

### H. Peer Evaluator (weight lowest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our sites run side by side. Where is the seam between yours and mine, and what happens when we disagree?" | CASE | [generic] | Propose seam principles rather than pretending to know the seam: who owns the customer commitment, who owns the resource, how a disagreement escalates. Use reciprocity framing: what your site offers the other, not just what you need | Peer stem; the four-site JD makes seams likely |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a time with more than one team involved: "we" for context, "I" for your contribution, and one thing a colleague did that you name. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer stem for a credit probe |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How is on-time performance trending across the four sites, and which is furthest from where you want it?" | Shows you think at the network level and hands you the diagnostic problem in B1 for real |
| 2 | "What does reporting look like today, and what would you want built in the first ninety days?" | Lets you place the Power BI gap on the table early, in a conversation about what the role needs |
| 3 | "How long have the twelve supervisors been in role, and where is the team strongest?" | Turns the three-versus-twelve gap into a question about the team you would inherit |
| 4 | "What has worked and not worked in peak season across the four sites?" | Invites the peak conversation on their ground, which is where your surge-plan quote belongs |
| 5 | "What would make you say, at six months, that this hire was the right one?" | Gets the real success criteria and signals you work to outcomes |
| 6 | "What happens after this round, and is there anything you would like me to prepare?" | Cheap, un-researchable process information, and a signal you plan ahead |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team of twelve supervisors | Inflated form of F3 | F3's quote at its own scope: three supervisors. The limit is the pack's observation: your material says three, not twelve. A1's slot asks only whether you led a larger group anywhere |
| Owned terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The pack's observation: your material says warehouse and distribution work and a site's surge plan, not terminal operations or multiple sites. A2's slot stays inside that work |
| Drove on-time performance and cost per shipment down | Inflated form of F2 | F2's quote at its own scope: the mis-pick rate. A1, A4 and C1 ask only how that figure was counted and which part was yours |
| Built Power BI reporting, or has used Power BI | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." Followed by a plan, never a past. No slot |
| Has five or more years of operations leadership | Inflated form of F6 | F6's quotes at their own scope. The pack's observation: your material gives seven years in ops, not how many were in a leadership post. A5's slot asks for the division by role |
| Led Lean or Six Sigma projects | Inflated form of F7 | F7's quote at its own scope: green belt certified. D3's slot asks only how you have applied it, with either honest branch |

## Sources

Provided documents: the job description text and the background statements in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Calls sent:
- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight regional logistics news strategy` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have fed a values cheat sheet; section 10 is dropped, and the VAL questions use persona stems and selection scaffolds |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have fed the loop structure; persona weights rest on the generic archetype and the hiring-manager assumption |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have fed company and strategy questions; the pack has no CO question and the CASE bank is generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Nothing in this pack states a fact about Atlas Freight beyond the JD you supplied.

## Upgrade menu

- The interviewer's name and role → a reading of their public footprint, persona weights adjusted from it, and a reverse question tied to their own path
- Who you are meeting and the recruiter's prep email, including any focus areas, a presentation or a take-home → persona weights reweighted for the actual round, and a build section for any declared deliverable
- Atlas Freight's values page, careers page or a description of the loop, pasted here → section 10 if a values round exists, CO questions, and the three refused research targets answered from provided text
- Search access, and a yes to a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Atlas's strategy and recent context, offered once
- Your answers to the slots on F1, F2, F3, F4, F6 and F7 (terminal and multi-site work, how the 40% was counted, any larger group led, any reporting built, how many of the seven years were in leadership, how you applied the belt) → those rows move from discovery or transferability to quoted evidence and the matching answers become story-mapped
- How many hours you can give this week → a triage sized to it
- A tuesday-dossier.md from a prior evaluation of this role → verified evidence, a named highest-risk objection and prohibited claims arriving ready-made
