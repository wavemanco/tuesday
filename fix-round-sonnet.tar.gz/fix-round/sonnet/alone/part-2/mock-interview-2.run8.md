I'll read the reference files the skill requires before building the pack.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-2-denied-4424e6b1/atlas-freight_operations-manager_interview_pack.md`. It has 22 questions across seven interviewer styles, built on blended weights since you don't know who is interviewing.

Web search was denied in this session, so the pack has no facts about Atlas Freight. The company question (E2) is a scaffold for you to fill from their site, and the Sources section lists the three refused searches.

The pack names two things to rehearse hardest:
- **A2 (scale):** "you lead three supervisors, this role has twelve across four sites." This is the highest-ROI prep.
- **A1 (Power BI):** say "I've never used Power BI" plainly, then give a plan.

Wherever your background didn't show something the interviewer will probe, the guidance is a slot for you to fill honestly rather than a story I made up. The main slots are how many sites you covered, how many of your seven years you led people, what changed beyond mis-picks after the pick-path redesign, and how the 40% was counted.

Say the word and I'll play the Skeptic on A2 and push back on what you say.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you know what kind of round this is (recruiter screen, hiring manager, panel) or what the interviewer's title is, even roughly? Either answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees). Interviewer: not known. Relationship and round type: not known, so persona weights are blended and say so below.

## How to use this pack

- Personas are how a question is asked; types are what it scores. Every question carries both.
- Type key: **VAL** is values and behavioral alignment. **EXP** is a work-experience deep-dive. **JD** is the stated role and its requirements. **CO** is company and strategy knowledge. **CASE** is a live problem from the role.
- Guidance is scaffolding, not a script. All wording in it is proposed, pending your approval: change anything that is not true for you, and say it in your own words.
- Provenance labels: `[grounded]` traces to what you or the JD said; `[inferred]` is a derivation, named; `[generic]` is a role-family pattern with no claim about you or Atlas Freight.
- An answer slot is an instruction for the interview, not a question for this chat. Where the material does not show a practice, the slot lets either answer be the honest one.

## Prep triage (interview next week)

1. A2, the scale question. This is the pack's highest-ROI prep: rehearse it until it is boring, including the specific concession.
2. A1 and F5 in the fit snapshot: say the Power BI line plainly and have a plan ready.
3. C1, C2, C4: the three numbers-and-method probes on your own claims.
4. B1 to B4: say each case structure aloud once, clarifying first.
5. D and E arcs: the 90-second biography (E1) and one honest story per D prompt, or the honest branch.

Everything else is insurance.

## Fit snapshot

Proposed wording in the bridge column, pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution operations and a surge plan you ran, with nothing inspected behind it; it does not show how many sites that covered or whether any were terminals. The words stay at the quotes: "I have 7 years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on breadth likely. If you covered more than one site, say which and what you answered for; if you did not, or the sites were not terminals, say so plainly and stay with the surge plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is about mis-picks; the JD's measures are on-time performance and cost per shipment, and the material does not show either was tracked. The words stay at the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: expect a probe on whether the redesign moved on-time performance or cost. If you tracked either, say what and how it was counted; if you did not, say so plainly and say what you would measure first |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The material shows three supervisors against the JD's twelve, and nothing about span beyond that. The words stay at the quote: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have led more than three at any time, say when and how many; if you have not, say so plainly and return to the three. How you would run twelve across four sites is a plan, said as a plan and never as a past |
| F4 | "build reporting in Excel/Power BI" — JD (Excel part) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" states a skill level and does not show whether you built reporting. Answer slot: if any of your Excel work was reporting that others used, say what it showed and who used it; if it was analysis for your own use, or none of it was reporting, say so plainly and say what you have used Excel for |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI part) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The material gives seven years in operations and a current leadership role, and does not show how many of the seven years were spent leading people. Answer slot: count the years you led others and name the roles, in your own words; if it is fewer than the seven, say which years and say so plainly |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | Lead with the certification in its own terms: "I'm green belt certified." No gap, but a certification with no certificate inspected, so expect a probe on use. Answer slot: if the green belt came with a project, say what it was and what was yours; if you have applied Lean or Six Sigma methods anywhere else, say where; if the certification is what you hold, say so plainly and return to it |

## Persona table

Your note did not say who is interviewing or what round it is. No loop source was available (research was refused, see Sources), so the fallback archetype is Generic (screen, hiring manager, panel) with blended weights, and they rest on a pattern rather than on Atlas Freight's process.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the gaps: scale, breadth, Power BI, why now | High. Hiring-manager rounds prior toward Skeptic, and the fit snapshot has more gap rows (F1 to F6) than clean ones (F7); the stated Power BI gap and the 3-versus-12 supervisor step are the two most predictable | Rehearse A2 until boring; say the limit before it is asked; bridge only from what you stated |
| B. Case / Strategist | Live operational problems: diagnose on-time, cost, surge | High. Hiring-manager prior, and the JD is an operations-ownership role | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| C. Data-Driven Prober | Reads the lines closely: the 40%, the surge plan, the green belt | High. Your one quantified claim is a magnet target, and peer and technical rounds prior toward Prober | Know what you can and cannot say about how the 40% was counted; say plainly where you do not know |
| D. Values / Behavioral | Scenario prompts: unpopular truth, customer over metric, a supervisor not performing | Medium. No published Atlas Freight values were in hand and no values round was established, so this is the pattern for a Generic loop, not a documented round | Choose stories where you can name the stake and the ending; use the honest branch where none comes to mind |
| E. Conversational | Biography and "what do you know about us" | Medium. A recruiter-stage conversation is plausible in a Generic loop, and casual questions are still scored | A 90-second arc built from your own sentences |
| F. Peer Evaluator | Seams between sites, credit, disagreement | Medium-low in weight, shown here as two questions. The JD's four sites suggest site-level counterparts, which is an inference from the JD, not a known fact | Offer seam principles; do not pretend to know the seam |
| G. Pressure | Time-boxed challenge: why you, how much was you | Low-medium. Skip-level and technical rounds prior toward Pressure; the 40% and the scale step are where it would aim | Hold through two follow-ups, then concede the specific limit |

## Question banks

Proposed wording, pending your approval. Ordered by weight.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role builds reporting in Excel and Power BI. Where are you on that today?" | JD | [grounded] "never used Power BI"; "solid Excel" | Say the Power BI line plainly: "I've never used Power BI." Then Excel at its own scope: "solid Excel." Then a plan, said as a plan: what you would build first, who would use it, and how you would get trained, each filled from what you would actually do. Answer slot: if any of your Excel work was reporting that others used, say what it showed; if none was, say so plainly and say what you used Excel for. Never describe a dashboard you did not build | F4 and F5 are the JD's tool line against your stated gap. JD because it scores a stated requirement; the question is open and presupposes nothing past the JD |
| A2 | "You currently lead three supervisors, and this role has twelve across four sites. What changes at that scale?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold the fact: "I'm a senior shift manager over 3 supervisors." Name the step up before they do: twelve is more than three, and four sites is a wider footprint than the material shows. Then a plan, said as a plan: what you would learn first about the twelve and the four sites, and how you would divide your time, each filled from what you would actually do. Answer slot: if you have led more than three at any time, say when and how many; if you have not, say so plainly and return to the three. Hold through two follow-ups by returning to the three, never by adding to them | F3 is the JD's headline team line against the quote, and this objection will arrive in some form. JD because it scores the stated requirement, with a hold-then-concede delivery |
| A3 | "Of your seven years in operations, how many were spent leading people?" | EXP | [grounded] "7 years in warehouse and distribution ops" | Do not blend the seven years into leadership years. Answer slot: count the years you led others and name the roles, in your own words; if it is fewer than seven, say which years and say so plainly. Then return to the quote: "7 years in warehouse and distribution ops" | F6 is the JD's required-years line; the quote shows operations years, not leadership years. EXP because it tests what the CV claim contains |
| A4 | "This role covers four sites. What is the widest footprint you have been responsible for?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running" | Answer slot: if you covered more than one site, say which and what you answered for; if you did not, or the sites were warehouse and distribution rather than terminals, say so plainly and return to the surge plan you ran: "I ran the site's peak-season surge plan two years running." Then a plan for getting to know four sites, said as a plan | F1 is the JD's terminal-and-four-sites line against warehouse and distribution quotes. JD because it scores the stated footprint |
| A5 | "Why leave where you are, and why this, and why now?" | JD | [generic] | A selection scaffold: a reason that is about this role and is true, that criticises no one, and that you could repeat tomorrow. If no clear reason comes to mind, say so plainly, then give the nearest honest thing, or how you are weighing the move. Make no claim about Atlas Freight that you have not read | Motivation consistency is what the Skeptic scores; `[generic]` because it makes no claim about your past or this employer |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four sites has dropped ten points over two weeks. How do you diagnose it?" | CASE | [generic] | Clarify first: what counts as on-time here, which lanes and customers, when it started, what changed. State the objective, then segment: by site, lane, shift, customer, day of week. Then approach: check the data before conclusions, separate containment from root cause. Name the metrics you would watch and the risk of fixing one measure at the cost of another. Think aloud and challenge one premise respectfully | The JD says drive on-time performance; a live problem tests structure, not the right answer. `[generic]` because it is a pattern for the problem |
| B2 | "Cost per shipment is up 8% quarter on quarter at one site. What do you look at first?" | CASE | [generic] | Clarify how cost per shipment is defined and whether volume moved, since a lower denominator raises it. Split into components, separate rate from mix, and ask for the data. Name the trade-off with on-time performance, and what you would not cut blind | The JD says cost-per-shipment down; CASE because the test is reasoning about the denominator and the trade-off |
| B3 | "Peak volume is forecast 30% over last year across all four sites with the same headcount. What is your plan?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure the plan generically: clarify the forecast and its confidence, what flexes and what does not, what you would protect first. If you reach for your own experience, say only what the quote carries: "I ran the site's peak-season surge plan two years running." Add no figure, headcount or outcome you did not track | F1 holds the surge-plan quote, and this is where it earns its use. CASE because it is a live problem, with the quote used only as stated |
| B4 | "One of your twelve supervisors keeps missing on-time targets while the others hit them. What do you do?" | CASE | [generic] | Facts first: is it the person, the site, or the lane mix. Then a conversation before a conclusion, what support or change you would offer, and when you would escalate. Name what you would measure to know it is working. Nothing here is a claim about your past | The JD's twelve-supervisor line as a decision rather than a history. `[generic]` because it presupposes nothing about you |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the 40% reduction in mis-picks. How was it counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the claim at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you know how mis-picks were counted and over what period, say so; if you do not know how it was counted, say so plainly. Name the assumption you would defend least, in your own words, before they do; if none comes to mind, say so. Say which part was yours, and if others contributed, say what was theirs | F2 holds your one quantified claim, and every figure is a defend-the-number target. EXP because it tests attribution and counting |
| C2 | "Did the redesign change throughput, on-time performance or cost? How do you know?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you tracked any of those after the redesign, say which and how it was counted; if you did not, say so plainly, say you tracked mis-picks, and say what you would measure first. Do not describe an effect you did not measure | F2's bridge rehearsed, so the honest answer is ready before the probe. EXP because it tests whether the number reaches the JD's measures |
| C3 | "Walk me through the surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The beats the quote states: the site's surge plan, for peak season, run two years. Tell them in your own words. Answer slot: if anything changed between the two years, say what and who decided; if the plan ran the same both years, say so plainly. Add no figure, headcount or outcome you did not track | F1's surge quote, premised only on what it says. EXP because it tests what was actually yours |
| C4 | "Lean and Six Sigma are a plus here. How have you used your green belt?" | JD | [grounded] "green belt certified" | Start with the quote: "I'm green belt certified." Answer slot: if the green belt came with a project, say what it was and what was yours; if you have applied Lean or Six Sigma methods anywhere else, say where and what was yours; if the certification is what you hold, say so plainly and return to it | F7 is the only requirement with a clean quote, and a certification line draws a probe on use. JD because it scores the stated plus |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's stem; Atlas Freight's published values were not available, so this is the pattern and `[generic]` |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision where the two pulled apart, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing, or how you would weigh it | The persona's stem; VAL because it tests behavior, not slogans |
| D3 | "Tell me about a time a supervisor on your team was not performing." | VAL | [generic] | Selection scaffold: pick a time with a named gap, a conversation you had, and what changed after. Say what was yours and what was theirs. If no such time comes to mind, say so plainly, then give the nearest thing, or how you would handle it | Raised by the JD's twelve-supervisor line; open prompt, so it supplies no event |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey into operations." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc with two fixed beats from your own sentences: "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors". Answer slot: the roles, dates and moves between them are not in the material; tell them in your own words, and if a step is hard to place, say so plainly. Close on why this role, in your own words | The biography question is scored; E is where a rehearsed arc pays most. EXP because it tests whether the CV line holds |
| E2 | "What do you know about Atlas Freight?" | CO | [generic] | Research could not be run for this pack, so this is a scaffold: before the interview, read their site and any recent news yourself and bring two facts you actually found plus one question they raise. If you found little, say so plainly, then say what you would want to learn. Say nothing about them that you did not read | Homework depth is scored in casual form; `[generic]` because no Atlas Freight facts were established |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our sites sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who decides when volume or people move between sites, what gets escalated, and how you would settle a disagreement with a peer using the shared on-time and cost measures. Make no claim about your past | The JD's four sites make site-level counterparts plausible; JD because it scores the multi-site mandate |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams, say who did what, and how the credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing, or how you would handle it | The persona's stem; VAL because it tests collaboration behavior |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has already run twelve supervisors across several sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate, then hold on the quotes only: "7 years in warehouse and distribution ops", "green belt certified", "I cut mis-pick rate 40% by redesigning the pick path." Concede the specific step: twelve supervisors across four sites is more than the three you lead now. Close on how you would ramp, said as a plan. Hold through two follow-ups by returning to the quotes | A2's objection in time-boxed form. JD because it scores the role's scale; the delivery is hold-then-concede |
| G2 | "That 40% mis-pick reduction. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold at the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if others contributed, say who and what was theirs and what was yours; if it was yours throughout, say so plainly. Concede only what you can name, and add nothing | The persona's stem on F2's quote; EXP because it tests attribution under pressure |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A4, B3, C3, F1 |
| Drive on-time performance and cost-per-shipment down | B1, B2, C2 |
| Lead a team of 12 supervisors | A2, B4, D3, G1 |
| Build reporting in Excel/Power BI | A1 |
| 5+ years operations leadership required | A3, E1 |
| Lean/Six Sigma a plus | C4 |

## Reverse questions

Proposed wording, pending your approval. No interviewer profile was available, so none is tied to an interviewer's path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four sites today, and which site is furthest from where you want it?" | It shows ownership of the JD's headline measure and gets you the baseline you have no data on |
| R2 | "What reporting do the supervisors and this role rely on today, and what is missing?" | It turns the Power BI gap into a question about their stack, so you learn what you would actually be building |
| R3 | "How is cost per shipment measured here, and what moves it most?" | It shows you ask about the denominator, as B2 rehearses |
| R4 | "How is the supervisor team structured across the sites, and where is the bench thin?" | It engages the scale step from three to twelve directly, without claiming you have done it |
| R5 | "What would a good first 90 days in this role look like?" | It lets them define success in their terms and gives you a ramp to speak to |
| R6 | "If one of your sites handed work to mine, what could a new operations manager do in the first month that would genuinely help your team?" | The reciprocity question if a site-level peer is in the room: what you bring them, not only what you need |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across several sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says warehouse and distribution operations and a surge plan, not how many sites or terminals. A4's slot stays inside that |
| Reduced on-time performance or cost per shipment | Inflated form of F2 | F2's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path." The limit is the pack's observation: the material says mis-picks. C2's slot asks only what was tracked afterwards |
| Led twelve supervisors | A claim your quote contradicts, F3 | "currently a senior shift manager over 3 supervisors" — your message. The contradicting quote and nothing more |
| Has used Power BI, or built Power BI reporting | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Treated the pick-path redesign as a Lean or Six Sigma project | Inflated form joining F2 and F7 | Each quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path" and "green belt certified". The limit is the pack's observation: the material does not connect them. C4's slot asks only about the certification and its use |

## Sources

Provided documents: the job description text and your background, both pasted in your message. No dossier was consumed.

Searches sent (all refused, none returned a result):
- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics news strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have named the published values for the VAL bank and a values cheat sheet; the D bank is generic as a result |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. It would have fixed the loop and the persona weights; the fallback archetype is Generic, said above |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. It would have grounded E2 and added a strategy-based CO or CASE question |
| 4. interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who is interviewing and which round it is, even a title → persona weights recomputed from a blended guess to a real tilt, and reverse questions retuned
- The recruiter's prep email, or any stated focus areas or deliverable → coverage of what they plan to score, and a build section for any announced deliverable
- Atlas Freight's published values or a description of their interview loop, pasted from their careers page → a values cheat sheet, loop-based persona weights, and E2 grounded instead of `[generic]`
- Search access, if you grant it → rows 1 to 3 of the accounting above run; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) could then add a strategy brief for CO and CASE questions
- Answers to the slots, typed out of the pack as plain facts: how many sites you covered, how many of the seven years you led people, what was tracked after the pick-path redesign, how the 40% was counted → F1, F2, F3, F6 and F7 move toward story-mapped guidance
- An inspectable artifact, such as a shift KPI scorecard or the pick-path redesign write-up, or the green belt certificate → F2 and F7 confidence from medium toward high
- A tuesday-dossier.md from an earlier evidence review → verified evidence, the objection to rehearse deepest, and a binding prohibited-claims list, never required
