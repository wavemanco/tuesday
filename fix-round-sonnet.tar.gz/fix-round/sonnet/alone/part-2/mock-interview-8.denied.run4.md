I'll read the reference files the skill requires before building the pack.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-denied-d8a81132/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop from the recruiter's email, with persona weights from round type, since none of the interviewers are named yet. It has 31 questions across the three rounds, and I ran no searches because your pasted material already covered values, strategy and the loop.

The pack names C1 as the highest-ROI prep. C1 is the Round 2 question about never having worked in a contact centre, with its full set of follow-ups.

Say the word and I'll play the Head of Member Services on C1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.
Beyond the pack, I can build a one-page day-of card for 20 November, since all three rounds fall on one day.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview pack for Dara

Loop mode: three rounds on 20 November 2026, built on 11 November 2026.

| Round | Length | Who | What the recruiter's email says |
|---|---|---|---|
| 1 | 30 minutes | The recruiter | "30 minutes with me" |
| 2 | 45 minutes | Head of Member Services, who "would be your manager" | "mostly behavioural" |
| 3 | 60 minutes | A panel of two branch managers | "including a 20-minute case on a complaint escalation"; "The panel is also the values round — they score against the four values." |

Interviewers beyond their roles have not been assigned, so there is no interviewer read; persona weights come from round type and from the email.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each round has its own persona weights, with the reasoning shown so you can change them if you know something the pack does not.
- **Type key.** VAL: whether past behaviour shows the published values. EXP: whether your background survives scrutiny and attribution. JD: whether you can do the listed job, including its gaps. CO: company and strategy knowledge. CASE: a live problem from the role. A question with two natures carries its primary tag, and the rationale says the rest.
- **Guidance is scaffolding, not a script.** Every scripted line is proposed wording, pending your approval; say it in your own words.
- **Answer slots are instructions for the interview, not questions for this chat.** Where your material does not show something, the slot gives you two honest branches. "That wasn't mine" or "that never existed" is a complete answer. If you send me what you would say outside a drill, I will quote it into the fit snapshot and regenerate the rows that depend on it.
- **All three rounds are on one day.** Tell the same facts the same way each time; the sentences in the fit snapshot are the shared source.

## Prep triage

Sized to the nine days from today to 20 November. Proposed order, pending your approval.

| Order | Do this | Where | When |
|---|---|---|---|
| 1 | Write your real answers to the answer slots. The pack cannot supply them, and several questions below rest on them | Fit snapshot F2, F3, F4, F5, F6, F8 | 11–13 Nov |
| 2 | Rehearse the contact-centre question aloud through all its follow-ups, then the two plain acknowledgments | C1, B1, B2 | 12–15 Nov |
| 3 | Choose a story, or the honest branch, for each of the four values; run the case as a timed 20 minutes | F1–F5, G1–G3 | 14–17 Nov |
| 4 | Tighten the opening arc and the manager-round behavioural answers | A1, C2–C4, D1–D4 | 16–18 Nov |
| 5 | Pick the reverse questions you would actually ask in each round; run C1 once more | RQ1.1–RQ3.5 | 18–19 Nov |

Everything else is insurance.

## Fit snapshot

Bridge wording is proposed, pending your approval. Each row holds one confidence, one provenance and one gap type; qualifiers live in the last column.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | A statement with nothing inspected behind it, so expect a probe. Say it in the quote's own terms: "I have 6 years in retail banking, the last 3 as a branch supervisor." The JD says customer operations and the quote says retail banking and branch supervisor, so leave the connection to the interviewer instead of renaming your work in the JD's words |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says a formal complaints log and does not say what governed the complaints in it, so the words stay at the log: "I handled the branch's formal complaints log." Answer slot: the JD's complaints line makes a probe on what governed the log's complaints likely. If something outside the branch set how they had to be handled, say what it was and what part was yours, in your own words; if nothing did, or you do not know, say so plainly and stay with the log |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says you built a monthly complaints spreadsheet and that your regional manager uses it; it does not say what the sheet showed. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's reporting line makes a probe on what the sheet showed likely. Say what it showed, in your own words, and what part was yours; if you do not know, or it showed little, say so plainly and stay with what you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The quote says spreadsheet and does not say which tool; reading it as Excel is this pack's derivation. Answer slot: if it was built in Excel, say so and describe what you built in your own words; if it was another tool, say so plainly and stay with the fact that you built it |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and an escalation script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's supervisors line makes a probe on how supervisors differ from tellers likely. Say what you did with the tellers in your own words; if you have helped another supervisor through an escalation, say what happened and what part was yours; if not, say so plainly and stay with the tellers |
| F6 | "Own the member complaints process end to end across branches and the contact centre" — JD, branches part | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's across-branches line makes a probe on whether your involvement reached past your own branch likely. If you dealt with complaints from another branch, say how and what part was yours; if not, say so plainly and stay with your branch's log |
| F7 | "Own the member complaints process end to end across branches and the contact centre" — JD, contact centre part | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not mention digital work. Answer slot: the JD's digital-teams line makes a probe likely. If you have worked with a digital or online team on something members did for themselves, say what it was and what part was yours; if not, say so plainly and say, as a plan, how you would start |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated the absence. Words: "I've never presented to anyone above regional level." Then how you would prepare for a first leadership presentation, said as a plan and never as a past. No slot: your material does not show what you have presented at regional level or below, and the upgrade menu says what to send if you want that read |

## Grounding brief

A short brief from the four strategy points and the JD header you gave me. The full July 2026 brief was not pasted.

| Item | As supplied | Provenance | Used in |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] | A3, E1, RQ2.3 |
| Branch network | "consolidate eight branches into five hubs over 2027" | [grounded] | A3, E2, G3, RQ3.3 |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] | A3, RQ2.3 |
| Competition | "the main competitive pressure is app-only banks" | [grounded] | A3 |
| Organisation | "member-owned, about 900 staff" | [grounded] | A2 |
| Brief date | July 2026, supplied by the recruiter | [grounded] | Freshness: about four months old on 11 November 2026 |
| Complaints | None of the four points, as you gave them, mentions complaints | [grounded] | Why E1, E2 and G3 ask for hypotheses, not facts |

---

# Round 1: recruiter screen (30 minutes)

## Persona table, Round 1

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly and unstructured; casual questions that are still scored | High, 5 questions. The prior for a recruiter screen is Conversational plus a light Skeptic, the email says "30 minutes with me", and no interviewer information moves it | Treat casual questions on the JD's hot topics as scored; prepare the opening arc; never answer "I think you've covered everything" in the reverse-question slot. See A1–A5 |
| Skeptic (light) | Knockout checks on the JD's four stated requirements, in a friendly register | Medium, 3 questions. Prior is "light Skeptic"; F7 and F9 are your stated gaps and the screen is the first place they can surface | Plain acknowledgment, then a plan. See B1–B3 |
| Others | Pressure, Prober, Case, Peer, Values | Low, no questions. Nothing in the email points to them in a 30-minute screen, and the email places the values scoring in Round 3 | None planned; Round 2 and Round 3 banks cover them |

## Question bank, Round 1 (proposed wording, pending your approval)

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Build a 90-second arc of three beats, each a clause of your own sentences, in your own words: the 6 years in retail banking and the last 3 as a branch supervisor; the branch's formal complaints log and training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Close on why this role and why now. Answer slot: the pack does not know your reason for wanting a lead role across branches and the contact centre; say your own, and if no reason comes to mind, say so plainly and say what you want to learn from the call | The stem is the Conversational persona's, and F1, F2 and F3 are the rows the arc draws on. EXP because it tests whether the background survives being told aloud |
| A2 | "Why a credit union, and why Ashgrove?" | CO | [grounded] | Pick one thing that is genuinely yours and say it in your words, tied to something Ashgrove has published: for example the value "Members First, Always — we decide from the member's side of the counter." or one move in the strategy brief. It should be something you can speak to for 30 seconds without notes and connect to complaints. If no reason comes to mind, say so plainly, then say what you would want to understand about a member-owned organisation | A motivation probe in the casual register, with the pasted values page and the JD header as raising sources. CO because it tests homework at a light level |
| A3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Bring one item from the brief to show you have read it: "move 40% of member service to digital channels by 2028", "consolidate eight branches into five hubs over 2027", "launch a small-business lending product in Q1 2027", or "the main competitive pressure is app-only banks". Then one thing you would want to understand about its effect on complaints, as your own question. Reciting the brief scores as homework; connecting one item to complaints, as a question, scores as judgment. Do not claim to know the effect; the four points as you gave them do not mention complaints | The CO coverage rule asks for a strategy-grounded question once research or a brief is in hand. F6 and F8 are the rows the brief's hub and digital moves touch |
| A4 | "Tell me about the complaints side of your current branch. What did that involve?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say it in the quote's terms: you handled the branch's formal complaints log and trained new tellers on the escalation script. Answer slot: the JD's complaints line makes a probe on what governed the log's complaints likely. If something outside the branch set how they had to be handled, say what it was and what part was yours, in your own words; if nothing did, or you do not know, say so plainly and stay with the log. If asked about the script, say what you taught from it; if you did not write it, say so | F2 is where the JD's complaints requirement is thinnest in your material and a screen is the first place it is checked. EXP because it tests what was actually yours; the gap is discovery, so the guidance is a slot |
| A5 | "How comfortable are you reporting in Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the sentence in your words: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: your material says spreadsheet, not which tool. If it was built in Excel, say so and describe what you built; if it was another tool, say so plainly and stay with what you built. Do not name functions or features you did not use | F4 is a listed requirement and a quick yes-or-no in a screen. JD because it scores the stated skill |

### B. Skeptic, light (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would be your weakest on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose one that is true and say it plainly. Your own sentence gives you two: "Never worked in a contact centre" and "I've never presented to anyone above regional level". Pick the one you would least like asked, say it in one sentence, then a plan, said as a plan, for closing it. If there is a third weakness the pack has not seen, add it as your own | The stem is the Skeptic's. F7 and F9 are the stated gaps; JD because it scores honest self-assessment against the role |
| B2 | "This role presents to senior leaders. What presenting have you done at that level?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The plain acknowledgment, in your words: "I've never presented to anyone above regional level." Stop there and do not fill the pause. Then a plan, said as a plan, for how you would prepare a first presentation to senior leaders. Do not describe any earlier presentation as senior | F9 is a capability gap, so the words are your stated negative and a plan, nothing more. JD because the requirement is listed |
| B3 | "The post asks for four-plus years in financial-services customer operations. Where does yours come from?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it in the quote's terms: 6 years in retail banking, the last 3 as a branch supervisor. Leave the link to "customer operations" to the interviewer rather than renaming your work in the JD's words; if they ask for more, say what the work was in your own words | F1 is the experience requirement and a presentation gap. JD because it checks a listed threshold |

## Reverse questions, Round 1

| # | Question | Why it lands |
|---|---|---|
| RQ1.1 | "Once they are assigned, could you tell me who the Head of Member Services and the two branch managers are?" | The email says interviewers beyond their roles are not yet assigned; names are the one input that unlocks an interviewer read (public footprint only), and a recruiter can share them |
| RQ1.2 | "Who does the Member Experience Lead work alongside day to day: contact centre, branch network, digital?" | The JD names all three; the answer tells you where the seams are before Rounds 2 and 3 |
| RQ1.3 | "What does the hiring team want to be different a year after this person starts?" | Gives you the scoring sheet for the later rounds and shows you think in outcomes |
| RQ1.4 | "Is there anything in my background you would want me to address before the later rounds?" | Invites F7 and F9 while there is still a round to respond in, and shows candour |
| RQ1.5 | "How will the panel score the four values, and is there anything you can share about what a strong answer looks like?" | The email says the panel scores against the four values; the recruiter may share the format |

---

# Round 2: Head of Member Services (45 minutes)

## Persona table, Round 2

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps: contact centre, leadership presenting, how far the complaints experience reaches | High, 4 questions. This person "would be your manager", and the prior for a hiring manager is Case/Strategist plus Skeptic; F7 and F9 are the gaps a manager is buying down | Rehearse the contact-centre objection until it is boring: plain acknowledgment, hold, concede, plan. See C1–C4 |
| Values / Behavioral | "Tell me about a time" scenario probes in STAR shape | High, 4 questions. The email says "mostly behavioural", which lifts this persona above the hiring-manager prior, even though only Round 3 is scored against the four values | A story where one of your quoted sentences carries it, or the honest branch; "we" for context, "I" for contribution. See D1–D4 |
| Case / Strategist | A live problem on the manager's roadmap | Low, 2 questions. The prior puts Case first for a hiring manager; "mostly behavioural" pulls it to two | Clarify, objective, segmentation, approach, metrics, risks; think aloud. See E1–E2 |
| Others | Pressure, Prober, Peer, Conversational | Low, no separate bank. Pressure arrives inside C1's follow-ups | None planned |

## Question bank, Round 2 (proposed wording, pending your approval)

### C. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never worked in a contact centre, and this role owns complaints there as well as in branches. Why should I believe you can do that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI prep in this pack: some form of this question is the likeliest of the loop, because it aims at your stated gap against the JD's contact-centre scope. Open with the plain acknowledgment: "I have never worked in a contact centre." Name the limit before it is asked for: your complaints experience is the branch's, as the sentence has it, "I handled the branch's formal complaints log and trained new tellers on our escalation script." Hold there through two follow-ups by returning to that sentence, never by saying the work is the same as a contact centre's. Follow-up 1, how is a contact centre different: answer slot: if you know how complaints reach a contact centre, say what you know and where it comes from; if you do not, say so plainly. Follow-up 2, sixty seconds on why you: restate the sentence, concede the gap in the same breath, then a plan, said as a plan, for learning the contact centre before changing anything, in your own first steps | F7 is the stated gap and F6 is the part of the same requirement your quotes do reach. JD because it scores a listed responsibility, with Pressure in the delivery; deepest means three levels of follow-up, the limit named first, and the concession worded in advance |
| C2 | "Tell me about a complaint you took from the moment a member raised it to the moment it was closed." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from the sentence: you handled the branch's formal complaints log. Answer slot: the JD's across-branches line makes a probe on how far your involvement in a complaint went likely. If you took one through from one stage to the next, pick it and say which stages were yours, in your own words; if you did not, or the log was a record of complaints others handled, say so plainly and stay with the log. Choose one you can describe without identifying the member | F6 is the requirement this question presses. EXP because it tests what part was actually yours; the theme comes from the JD, and the second branch lets the practice never have existed |
| C3 | "You would be coaching branch supervisors, and you are one. How do you coach people at your own level?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with what the sentence says, in your words: you trained new tellers on the escalation script. Then a plan, said as a plan, for how coaching a supervisor would differ, for example starting by asking how they handle an escalation before telling them anything. Answer slot: if you have helped another supervisor through an escalation, say what happened and what part was yours; if not, say so plainly and stay with the tellers | F5 is a transferability gap: the quote reaches tellers, not supervisors. JD because it scores the listed coaching responsibility |
| C4 | "What did the monthly complaints spreadsheet your regional manager uses actually tell them?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the sentence: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: the JD's reporting line makes a probe on what the sheet showed likely. Say what it showed, in your own words, and what part of it was yours; if you do not know what your regional manager did with it, or it showed little, say so plainly and stay with what you built | F3 is the reporting requirement and F4 the tool; both rest on one sentence, so the probe lands here first. EXP because it tests attribution and substance |

### D. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you had to deliver an unwelcome message to someone more senior." | VAL | [generic] | Selection scaffold. Pick a time the message was unwelcome to someone more senior than you, you named the facts plainly, and the relationship was intact afterwards; it needs a named stake and a moment you did not soften it to stay comfortable. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Choose one where the message landed; if you have none, do not supply an ending | A persona stem, and the JD's senior-leaders line makes senior-facing candour likely. No quoted sentence carries a story here, so it is a scaffold. F9 is the row it sits beside |
| D2 | "Tell me about a complaint that was hard to resolve and what you did." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from the sentence: you handled the branch's formal complaints log. Pick one complaint you can describe without identifying the member and say what made it hard and what part was yours, in your own words. Answer slot: if a complaint comes to mind, tell it; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | The theme comes from the JD's complaints responsibilities (F2, F6). EXP because it tests what was actually yours; a behavioural question in a mostly behavioural round |
| D3 | "Tell me about a time you taught someone a process and it did not land the first time." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from the sentence: you trained new tellers on the escalation script. Answer slot: if a teller needed it explained again, say what you changed and why; if none did, or you do not remember, say so plainly and stay with training the tellers on the script. Keep to one example you can finish in two minutes | F5 is the coaching row; the question sits where the JD's coaching line meets the Plain Words value. EXP because it tests whether the teaching was really yours |
| D4 | "Tell me about a time you worked with another team to fix something that was not working for members." | JD | [grounded] | Selection scaffold. Pick a time you worked with a team outside your own to change something members used; it needs a named problem, who the other team was, what you contributed, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's digital-teams line and the strategy's digital shift raise the theme; F8 has no quote, so it is a scaffold. JD because it scores the stated responsibility |

### E. Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We want 40% of member service on digital channels by 2028. What happens to complaints?" | CO | [grounded] | Clarify first: what counts inside the 40%, and whether complaints sit inside it. State the objective in the member's terms. Split by how a complaint arrives and who resolves it, not by an assumption about volumes. Metrics: complaint volumes and resolution times, the JD's own two measures, before and after, by channel. Risks: a member who needs a person, and wording that has to be explained twice. Say each point as a hypothesis, not a fact about Ashgrove, and challenge one premise respectfully, for instance whether the same share fits every town | The brief's headline target meets the JD's reporting and digital lines (F3, F8). CO with CASE delivery; nothing in it claims anything about your past |
| E2 | "Eight branches become five hubs over 2027. What would you watch in complaints, and why?" | CASE | [grounded] | Say what you would want to know first: which branches, in what order, and what changes for members; you know only "eight branches into five hubs", not which. Then two or three things to watch, as hypotheses: who raises complaints, how long they take to resolve, and what members say about the change. Tie one to Neighbours, Not Numbers: "every branch is part of its town." | The hub move is the strategy item most likely to reach a complaints lead's first year. CASE because it is a live problem on the manager's roadmap; no claim about your past |

## Reverse questions, Round 2

| # | Question | Why it lands |
|---|---|---|
| RQ2.1 | "What would make the first ninety days a success in your eyes?" | Your manager owns the sheet they will judge you on; the answer turns it into goals you can name |
| RQ2.2 | "How do complaints move between the contact centre and the branches today, and who decides when one changes hands?" | This is the seam behind F7, and it echoes Own the Fix: it asks about ownership before you have answers |
| RQ2.3 | "Of the 2026 strategy moves — digital to 40%, five hubs, small-business lending — which will put the most pressure on complaints first?" | Shows you read the brief and lets the manager rank; the four points as you gave them do not mention complaints, so this fills that gap |
| RQ2.4 | "What do senior leaders want from the monthly complaints report, and who would I present it to first?" | Names F9 as a thing you are already planning for and invites help on the audience |
| RQ2.5 | "What is already in flight with the digital team on self-service that complaints should plug into?" | Turns F8's silence into an ownership question and uses the JD's digital line |

---

# Round 3: panel of two branch managers (60 minutes, with a 20-minute case)

## Persona table, Round 3

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes keyed to each published value, in STAR shape | Highest, 5 questions. The email says "The panel is also the values round — they score against the four values", and the prior for a dedicated values round is Values/Behavioral plus Conversational | Map a story to each value where one of your quoted sentences carries it; where none does, a selection scaffold ending in the honest branch. See F1–F5 and the values cheat sheet |
| Case / Strategist | The live complaint-escalation case, with follow-ups | Medium, 3 questions. The email puts "a 20-minute case on a complaint escalation" inside the hour | Clarify, objective, owner, next step, record, check; think aloud; hold a position through two follow-ups. See G1–G3 |
| Peer Evaluator | Seam-splitting between branches and the complaints lead; credit | Low, 2 questions. The JD has the role coaching branch supervisors across branches, so branch managers are its likeliest partners; with no names, the panel prior blends relationships without a per-member split | Offer seam principles, not a claimed seam; reciprocity framing. See H1–H2 |
| Skeptic | The tension between numbers and towns | Low, 2 questions. Your stated gaps sit mainly in Round 2; this panel's version is how a reporting role keeps people in view | Hold the member's-side position and concede the process. See I1–I2 |

## Question bank, Round 3 (proposed wording, pending your approval)

### F. Values / Behavioral (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Members First, Always: tell us about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold. Pick a time what the member needed and what a process, script or target said pulled apart, and you went with the member. It needs the decision, what it cost, and what the member got; the cost is what makes it believable. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Value 1 of 4, scored by the panel per the email. No quoted sentence carries a story for it, so it is a scaffold; the published value is the raising source |
| F2 | "Plain Words: tell us about a time you changed how something was explained to members." | VAL | [grounded] | Selection scaffold. Pick an example where the original wording failed because a member needed it explained twice, say what you changed, and what happened. Say only what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Value 2 of 4: "if a member needs it explained twice, we wrote it wrong." No quote says anything about wording, so it is a scaffold; F5 is the nearest row and does not reach it |
| F3 | "Neighbours, Not Numbers: tell us about a time you did something because of the people a branch serves rather than because of a figure." | VAL | [grounded] | Selection scaffold. Pick a time a person or a town was visible behind a figure and you acted on it. The JD has you reporting volumes and resolution times, so choose a story where the two sit together rather than one against the other. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Value 3 of 4, and the one the strategy's eight-into-five hubs tests hardest. No quote carries a story, so it is a scaffold; F3 is the reporting row it sits beside |
| F4 | "Own the Fix: tell us about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from the sentence: you handled the branch's formal complaints log. Answer slot: if there was a problem you kept hold of until it was solved, pick it, say what part was yours and how you knew it was solved; if no such time comes to mind, or others closed what you logged, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Value 4 of 4: "whoever finds the problem keeps hold of it until it is solved." F2 is the only row whose quote touches it, and it stops at the log |
| F5 | "Which of our four values would be hardest for you to live in this role?" | VAL | [grounded] | Pick a real one and say why. A reading of the material, not a fact about you: Neighbours, Not Numbers is the likeliest tension, because the JD has you reporting volumes and resolution times and the brief has eight branches becoming five hubs. Say what you would do about it, as a plan. Do not answer "none" or offer a strength in disguise | A values panel tends to test self-awareness against the published set; VAL because it scores honesty about fit with the four values |

### G. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A branch supervisor has escalated a complaint to you. Walk us through what you do." | CASE | [generic] | Clarify before you structure: what the member is asking for, what has already been said to them, what rules or deadlines apply and who set them, and who is holding it now. Then the objective from the member's side; the next step you take today and who you tell; how the supervisor stays involved; what gets recorded; what you check afterwards. Use the panel's own words as you go: the member's side of the counter, plain words in anything sent to the member, whoever finds it keeps hold. Think aloud, say hypotheses as hypotheses, and challenge one premise respectfully | The 20-minute case from the email. CASE; it presupposes nothing about your past, and the values vocabulary comes from the pasted page |
| G2 | "The supervisor disagrees with the outcome you propose. What do you do?" | CASE | [generic] | Hold the member's-side position through two follow-ups; ask what the supervisor sees before defending. Concede specifically what you do not know, such as what the supervisor knows about the member and the town. Agree who decides and how it is recorded. Do not fold on the core just to restore harmony | A pressure follow-up is the natural second beat of a live case; hold-then-concede is the type's bar |
| G3 | "A member whose branch is joining a hub tells you Ashgrove has abandoned their town. What do you say?" | CASE | [grounded] | Listen first and say back what they told you; reply in plain words, with no scripted line. Do not promise hub decisions you do not control. Say who will hold their complaint and what happens next. You know only "eight branches into five hubs" from the brief; do not speak as though you know which branches or why | The hub move meets Neighbours, Not Numbers, in front of the people who run branches. CASE; no claim about your past |

### H. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our branches and your team sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Offer seam principles instead of pretending to know the seam. For example: the branch manager holds knowledge of the member and the town; the complaints lead holds the view across branches; both are heard before an outcome is settled; agree in advance who decides when they differ. Ask what the seam is today before proposing anything | The persona stem for peers, with the JD's across-branches scope as the reason it is likely here. CASE because it asks for a position, not a past |
| H2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you built in the sentence's terms: you built the monthly complaints spreadsheet your regional manager uses. "We" for context, "I" for what you built. Answer slot: if anyone else supplied or checked what went into it, say who and what; if no one did, say so plainly and stay with what you built. Never claim a share the sentence does not state | The peer stem. F3 is the only row with a build claim in your own words; EXP because it tests attribution |

### I. Skeptic (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "You would report monthly volumes and resolution times upwards, and we look after people, not figures. How do you keep the people in the report?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the sentence in your words. Answer slot: if the sheet carried any account of the people behind the figures, say what; if it did not, say so plainly. Then a plan, said as a plan, for what you would add to a monthly report so a town's story is not lost | Neighbours, Not Numbers meets the JD's reporting line (F3). VAL because it scores whether the value survives your own job description |
| I2 | "Would you ever side with a member against a branch's decision, and would we hear about it first?" | VAL | [generic] | Hold the member's-side position, which is Members First, and concede the process: say you would involve the branch manager before the outcome and tell them after, and that you may not have the full picture of the member and the town. Do not fold to "never" or harden to "always" | A probe a branch audience is likely to press, between Members First and Neighbours, Not Numbers. VAL with Pressure delivery; the guidance claims nothing about your past |

## Values and principles cheat sheet

Working meanings are paraphrases of the published values you pasted. Proposed wording, pending your approval.

| Value (official name) | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decisions are made the way the member sees them from their side of the counter | Scaffold, F1: a time the member's need and a process or target pulled apart, with the decision, the cost and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member has to ask twice, the failure sits with whoever wrote it | Scaffold, F2: a time the original wording failed and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Each branch belongs to its town, so it cannot be treated as a line in a table | Scaffold, F3: a time a person or a town was visible behind a figure. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | The person who finds a problem stays with it until it is resolved | F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The beat the sentence states is the log. Answer slot, as F4: if there was a problem you kept hold of until it was solved, say what part was yours; if not, or others closed what you logged, say so plainly and stay with the log |

## Reverse questions, Round 3

| # | Question | Why it lands |
|---|---|---|
| RQ3.1 | "What does a good escalation from one of your supervisors look like today, and what makes a poor one hard to handle?" | Escalation is the JD's coaching subject (F5); you learn what the panel wants from supervisors and show you are asking before you coach |
| RQ3.2 | "What could a new lead do in their first month that would genuinely help your branch?" | The reciprocity question: it turns the panel from judges into partners and asks what you bring them |
| RQ3.3 | "As branches move toward five hubs, what do you hope complaints handling will protect for your town?" | Ties to Neighbours, Not Numbers and the brief's hub move without assuming which branches are affected |
| RQ3.4 | "Which of the four values is hardest to live by on a busy day, and what does that look like at your branch?" | Invites a real story, shows you read the values as working rules, and echoes F5 |
| RQ3.5 | "A year in, what would make you say the complaints lead was on the member's side of the counter?" | Uses the panel's own value as the success measure and gives you a bar to prepare against |

---

## Requirement coverage

| Stated JD requirement | Fit rows | Question IDs |
|---|---|---|
| 4+ years in financial-services customer operations | F1 | B3, A1 |
| Experience handling regulated complaints | F2 | A4, C2, D2 |
| Own the member complaints process end to end across branches and the contact centre | F6, F7 | C1, C2, G1 |
| Report monthly on complaint volumes and resolution times | F3 | C4, E1, I1 |
| Coach branch supervisors on escalations | F5 | C3, D3 |
| Work with digital teams on self-service journeys | F8 | D4, E1 |
| Confident presenting to senior leaders | F9 | B2, D1 |
| Comfortable with Excel reporting | F4 | A5, C4 |
| The four published values (a values-scored round is documented) | F2 | F1–F5, I2 |

## Prohibited claims

What this pack will not coach, with the basis and the honest form. Built before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says a formal complaints log, not what governed it. The slots stay inside the log |
| Six years of complaints experience | Inflated form of F1 and F2 | F1's quote at its own scope: "6 years in retail banking, the last 3 as a branch supervisor." The material does not say how long the complaints log was yours |
| Owned the complaints process end to end | Inflated form of F6 | F6's quote at its own scope: "I handled the branch's formal complaints log." The material says one branch's log, not a process |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: "I trained new tellers on our escalation script." The material says new tellers, not supervisors |
| Reported complaint volumes and resolution times each month | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The material does not say what the sheet showed |
| Built the complaints reporting in Excel | Inflated form of F4 | F4's quote at its own scope: the sentence says spreadsheet, not which tool |
| Has worked in a contact centre | A negative you stated, F7 | The plain acknowledgment F7 gives: "I have never worked in a contact centre." No slot |
| Has presented to senior leaders | A negative you stated, F9 | The plain acknowledgment F9 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description (your message); the values text copied on 11 November 2026 from ashgrovecu.org/about/values (your message); the recruiter's email on the three rounds (your message); the four strategy points from the July 2026 brief, as you gave them; your background (your message). No dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text is pasted and in hand; it fixes the values cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member experience lead` | skipped | The recruiter's email fixes the loop: three rounds, who runs each, their length, and the panel's values scoring; it fixes every persona weight |
| 3. `Ashgrove Credit Union strategy` | skipped | The four points from the July 2026 brief are in hand and fix the CO and CASE questions; the full brief was not pasted |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names were given, so no query could be formed; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

This is an L1 run; no L2 targets ran.

## Upgrade menu

- The names of the Head of Member Services and the two branch managers, once assigned → an interviewer read from public professional footprint only, persona weights tuned per person, and a reverse question tied to each one's career path
- The full text of the July 2026 strategy brief → the grounding brief grows beyond four points, and E1, E2, G3 and A3 become fuller `[grounded]` rows instead of hypotheses
- Your own answers to the answer slots in F2, F3, F4, F5, F6 and F8, sent in chat in your own words → those rows regenerate with your sentences, and A4, A5, C2–C4, D3 and H2 get story maps instead of slots
- What you have presented at regional level or below, only if it is true, and to whom → F9 can be re-examined and B2 can carry a quoted sentence beside the acknowledgment
- A CV or the artifacts behind the summary, such as an anonymised extract of the complaints log, the layout of the monthly spreadsheet, or the escalation script you trained tellers on → F1–F6 confidence can rise from medium toward high
- The recruiter's confirmation of what "regulated complaints" means at Ashgrove, and what the 20-minute case will cover → F2 and G1 can be tuned to the real scope
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering interviewer footprint once names exist, loop reports for this role family and recent organisation context → say so and I will run it; it is not run unless you ask
- A tuesday-dossier.md from an earlier evaluation of this role → a named objection, verified evidence and prohibited claims arriving ready-made; never a precondition for this pack
