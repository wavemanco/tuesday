I'll read the reference files before building the pack.
Pack is written. I'm checking it for stray pipe characters in table cells, then I'll present it.
Your prep pack for all three rounds is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-6-denied-a99ebe24/larkfield-systems_engineering-manager_interview_pack.md`.

I built it in loop mode: one shared fit snapshot, then a bank and reverse questions for each round. It rests on the role description you gave me and your four statements about your background. I wasn't able to check the pack's table formatting in this session, so skim the tables when you open it.

My three web searches were refused, so nothing comes from outside research. That means there is no values cheat sheet for Monday and no question grounded in Larkfield's strategy. Persona weights come from your own description of the three sessions.

The highest-ROI prep is A2, the "you haven't owned a hardware-adjacent roadmap" question. It's most likely on Tuesday, from your would-be boss. E1, E2 and J2 are the next most important, because they cover your 60% on-call figure, which can come up in all three rounds.

Say the word and I'll play the Skeptic on A2, or the Thursday panel on E1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job description and your CV, or say skip? Either one would replace several answer slots with your own quoted sentences.
Did the recruiter say anything about what Thursday's panel will cover, or whether to bring something?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Built from the role description and the four statements about your background in your message; no CV, no full JD, no company research (see Sources).

| Round | When | Who and relationship | Length |
|---|---|---|---|
| 1 | Tuesday | Director of Engineering, the hiring manager and your would-be boss | 45 min |
| 2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min |
| 3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min |

No interviewer names were given, so there is no interviewer read.

## How to use this pack

- Personas describe how a question arrives (who is asking, in what register). Types describe what is being scored. Every question carries both.
- Type key: VAL is values or behavioral alignment. EXP is a deep-dive on what you actually did. JD is the stated role requirements, including the gaps. CO is company and strategy knowledge. CASE is a live problem. No CO question appears because company research did not run.
- Provenance labels: `[grounded]` rests on your words or the role description you supplied; `[inferred]` is derived from an adjacent source; `[generic]` is a pattern for the problem with no claim about Larkfield or about you.
- An answer slot is an instruction for the interview, not a question for you now. It names what an interviewer will probably probe, then gives two honest branches: say what you did, in your own words, or say plainly it was not yours or never existed and return to what you can stand behind.
- Guidance is scaffolding, not a script. Say it in your own words, and say only what you did.
- Question IDs run by persona bank: A–C for Tuesday, D, E, G for Thursday, H, J, K for Monday. F and I are skipped so no ID collides with a fit row or a numeral.

## Prep triage (three rounds over two weeks)

1. Before Tuesday: A2 first and most. It is the highest-ROI rehearsal in the pack. Then A1, C1, C2, B1.
2. Between Tuesday and Thursday: E1, E2, E3, then D1 and D4. Thursday's panel is where the numbers get probed.
3. Between Thursday and Monday: H1, H2, H4, J1, J2.
4. Everything else is insurance.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the role description in your message. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material gives a team lead of 6 against the role's two squads and 11 engineers, with nothing inspected behind it, so the words stay at that scope: "Three of my nine years in engineering have been as a team lead of six." Answer slot: the two-squads line makes a probe on how you would split attention likely. If you have led more than one team or workstream at once, say which and what you did, in your own words; if not, or it was not you, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description in your message (delivery element) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote carries one reliability quarter and a 60% figure, with nothing inspected behind it, not ownership of delivery, and it says "after", not "because". Words: "I pushed a reliability quarter through against roadmap pressure, and the on-call burden dropped 60% after." Answer slot: the figure raises how the 60% was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Say each in your own words; if you do not know how it was counted, say so plainly |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description in your message (hiring element) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap on the wording, but a line with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms: you run the hiring loop for backend roles. The quote does not say whether the 40 interviews were all yours or the loop's total, which is the pack's observation; the defend-the-number slots are in C2 and E3 |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description in your message (growth element) | none given | none | [grounded] | discovery | Your material does not show whether you have grown engineers. Answer slot: the growth line makes a probe on whose development you drove likely. If you have grown someone's career, say whose and what you did, in your own words; if not, or it was not your role, say so plainly and say how you would go about it, as a plan and not a past |
| F5 | "partner with hardware and product on roadmap" — role description in your message (hardware element) | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The role's word is partner and your stated negative is about owning; your material says nothing either way about working alongside a hardware team, and nothing here is added to make the gap feel smaller |
| F6 | "partner with hardware and product on roadmap" — role description in your message (product element) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [grounded] | discovery | The quote touches roadmap pressure and does not say whose it was or whether a product partner was involved. Answer slot: the product-partnership line makes a probe on how you work with product likely. If a product partner was on the other side of that pressure, say what was said and what part was yours, in your own words; if not, or no product partner was involved, say so plainly and stay with what the quote carries |
| F7 | "Lead two squads building device-management services" — role description in your message (domain element) | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [grounded] | discovery | The quote places you at a payments company and says nothing about devices or IoT. Answer slot: the device-management line makes a probe on any contact with devices or hardware integration likely. If any of your services touched devices, say what and which part was yours; if none did, say so plainly and say how you would get up to speed on the domain |

### Requirement coverage

| Requirement | Fit row | Questions that cover it | JD-tagged question |
|---|---|---|---|
| Lead two squads | F1 | A1, B3, K1 | A1 |
| Device-management domain | F7 | A3, K2 | A3 |
| Own delivery | F2 | B1, B2, E1, E2, J2 | E2 |
| Hiring for 11 engineers | F3 | C2, E3 | C2 |
| Growth for 11 engineers | F4 | H3 | H3 |
| Partner with hardware on roadmap | F5 | A2, B1, H4, J1 | A2 |
| Partner with product on roadmap | F6 | D4, G1, K1 | G1 |

## Round 1: Tuesday, hiring manager (Director of Engineering), 45 min

### Persona weights and reasoning

The loop here rests on your own description of the three sessions, not on an archetype.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gap between your background and two squads with hardware partnership | High. The hiring-manager prior is Case/Strategist plus Skeptic, and your own message names the gaps (F5), so the objection has a source | Rehearse A2 until it is boring; concede plainly; give a plan, not a claim |
| Case/Strategist | Live problems set in the role's own seams | High. Same prior; a 45-minute round has room for one or two | Clarify, objective, options, metrics, risks; think aloud; challenge one premise politely |
| Conversational | The journey question and a casual chat about hiring | Lower. The prior puts it third; included because casual questions are still scored | A 90-second arc scripted from C1; treat C2 as scored |
| Values/Behavioral | Scenario probes | Low this round. Monday is described as the values round, so most of it should land there | Covered in Monday's bank |

### Bank: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've been a team lead of six. This role is two squads and eleven engineers. What changes for you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say the quote at its scope: three of your nine years have been as a team lead of six. Answer slot: the two-squads line makes a probe on how you would split attention likely. If you have led more than one team or workstream at once, say which and what you did, in your own words; if not, or it was not you, say so plainly and stay with the team of six. Then say what you would learn first about each squad, as a plan: what each is committed to, where each is stuck, what each needs from you in the first weeks | F1 is the evidence for the two-squads line and the first place a hiring manager tests scope. JD because it scores a stated requirement |
| A2 | "This role partners with hardware on the roadmap, and you haven't owned a hardware-adjacent roadmap. How do you get there?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The highest-ROI prep in this pack. Name the limit before you are asked: "I haven't owned a hardware-adjacent roadmap, and I'd expect my first months to be about learning where its dates are fixed." Then the plan, as questions you would ask hardware and product: which dates are fixed, which can move, what a slip costs each side. Expect follow-up one, "so you'd be learning on my roadmap?" Hold the plan and add no past. Expect follow-up two, "hardware slips and product won't move, now what?" Answer it as a live problem with structure, not as an experience. Concede only what you said, in those words, and never fold the plan | F5 is the stated gap the whole loop turns on, and your would-be boss is the likeliest to ask it first. JD because it scores the hardware-partnership line; named highest-ROI because it will arrive in some form |
| A3 | "What draws you to industrial IoT, coming from a payments company?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start from the quote's own facts: you are currently at a payments company. The reason is yours to say in your own words: one reason about the work in the role description, one about the step to managing. Claim nothing about Larkfield beyond the role description. Answer slot: if you have already worked near devices, say what and your part; if not, say so plainly. If no strong reason comes to mind, say so plainly and say what you are weighing | F7 is the domain gap behind this question. JD because it scores the device-management requirement, delivered as a motivation probe |

### Bank: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Hypothetical: hardware tells you a device launch has moved up six weeks. Product wants the full feature set. Your two squads are already full. Walk me through your first hour and your first week." | CASE | [generic] | Clarify first: what exactly moved and why, what is fixed on the hardware side, what product means by full. Restate the objective. Lay out three levers, scope, sequence and capacity, and who must agree to each. Challenge one premise politely, whether the six weeks is firm. Say what you would tell each side and when, and what you would watch. Think aloud. The question needs no claim about your past, so the guidance makes none | F5 and F6 are the seams the role sits on, and a hiring manager tends to test them on a live problem. CASE because it scores structure; generic because it is a pattern for the problem |
| B2 | "A service one squad owns pages its on-call every night, and the quarter's roadmap is already committed. What do you do?" | CASE | [generic] | Diagnose before deciding: what is paging, what it costs, whether it is getting worse. Then the trade: the cost of the status quo against the cost of moving a commitment, who you would take it to and what you would bring them. Then options, a carve-out, a protected slice, a full quarter, and what you would measure and when you would stop. Answer it as a case first; if the interviewer then asks about your own experience, E2 is the home for it | F2 is the delivery-versus-reliability tension in the role's terms. CASE because a hiring manager can set this live; generic because it asserts nothing about Larkfield |
| B3 | "You take over two squads and eleven engineers on Monday. What do you do in your first thirty days, and what do you deliberately leave alone?" | CASE | [generic] | Listen before changing: one-to-ones, the state of delivery, the hardware and product counterparts. Name one change you would not make yet and why, and the signals you would want by day thirty. Plan, not past | F1 and F4 are the scope and people mandate. JD content, CASE delivery, because it is a plan question |

### Bank: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with the beats the quote states: nine years in engineering, three of them as a team lead of six, now at a payments company. The reason for this role is yours, in your own words. Beats beyond the quote come from your CV, which this pack has not seen | F1. EXP because it tests whether the career story holds against the CV; the register is conversational |
| C2 | "Tell me about the hiring loop you run." | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Story-map on F3: the loop for backend roles, and the figure, told as the quote states them. The figure raises how the 40 was counted, whether those were interviews you conducted or the loop's total, what it is sensitive to, and the assumption you would defend least. Say each in your own words; if you do not know how it was counted, say so plainly. Answer slot: the hiring line makes a probe on who made the final call likely. If the call on offers was yours, say how it was made, in your own words; if it was not yours, or the loop had no such decision, say so plainly and stay with running the loop | F3 is your best-aligned row, so expect it to be dug into. JD because it scores the hiring line, with EXP content |

### Reverse questions for Tuesday

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good first ninety days look like for whoever takes these two squads, and what would tell you at day ninety that it is going wrong?" | Gets your would-be boss's own definition of success and early warning signs |
| 2 | "Where does the hardware roadmap meet the squads' roadmap today, and where does it hurt?" | Aims at your biggest gap with curiosity, and lets him describe the seam |
| 3 | "When product and hardware pull in different directions, how are delivery and reliability trade-offs decided?" | Shows you think in trade-offs and surfaces who owns the call |
| 4 | "How is growth handled for the engineers today, and who is closest to a next step?" | Opens the growth line (F4) as a conversation rather than a probe |
| 5 | "What would make you hesitate about my profile?" | Invites the objection from the person who decides, while you can still answer it |

## Round 2: the Thursday panel (two staff engineers and a product manager), 60 min

### Persona weights and reasoning

A panel blends the top two personas of each member's relationship. The staff engineers weigh as technical peers (Peer Evaluator, Data-Driven Prober); the product manager weighs as cross-functional (Values/Behavioral, Conversational). Names are unknown, so personas are not assigned per member.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between an engineering manager and senior engineers; disagreement and credit | High. It is the first persona of the staff-engineer relationship and the whole panel is people you would work beside | Reciprocity: say what you would bring them as well as what you need; offer seam principles rather than pretending to know their seam |
| Data-Driven Prober | Reads each number to its assumptions | High. Your two figures, the 60% and the 40, are the obvious targets | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| Values/Behavioral | Scenario probes from the product manager | Medium. Cross-functional prior, and the product partnership is in the role description | Choose a story by the criteria in the guidance; "we" for context, "I" for your part |
| Conversational | Chatty openers | Low. It comes with the cross-functional prior but weighs least | Treat casual questions as scored |

### Bank: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where is the seam between what an engineering manager decides and what staff engineers decide, and what happens when we disagree?" | JD | [generic] | Do not pretend to know their seam. Offer principles: agree up front who decides what and who is consulted; disagree in the open, on the reasons, with a time-box; settle who breaks a tie and how it is recorded. Then ask them where the seam sits today. All pattern; no claim about your past | The panel is pricing what you would cost and add to their work. JD because the role is defined partly by how you partner; generic because it is a principle |
| D2 | "Tell me about a time you disagreed with a senior engineer about direction." | VAL | [generic] | Selection scaffold: pick a time with a named technical disagreement, what each of you argued, what you did, how it ended and how the relationship stood afterward. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | The Peer Evaluator's disagreement probe. Nothing quoted in the fit snapshot carries it, so the guidance is a scaffold; VAL because it scores behavior with an equal |
| D3 | "What would you need from the staff engineers in your first month, and what could you do for them?" | JD | [generic] | Reciprocity framing: give the ask and the offer together. Say what you would want to learn from them, and what you would take off their plates; the specifics are yours to choose. Do not claim past results | The reciprocity question for a peer panel. JD because it scores partnership, which the role description names |
| D4 | "A product manager brings a feature with a customer deadline while a squad is halfway through a reliability fix. How do you and the PM decide together?" | CASE | [generic] | Restate; clarify what the deadline is attached to and what is left on the fix; cost of each delay; options, finish the fix first, split the squad, descope the feature; decide with the PM on shared facts; say how you would tell the squad. Nothing about your past is asserted | F6 and F2 meet in this scenario, and a product manager on the panel can set it live. CASE because it scores structure |

### Bank: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say the sentence at its scope first: the on-call burden dropped 60% after you pushed a reliability quarter through. Keep "after"; do not say "because" unless you can say how you know. Then, in your own words: how the 60% was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | F2 holds the pack's headline number, and a number is where this persona starts. EXP because it tests attribution and counting |
| E2 | "Walk me through that reliability quarter: what was the pressure on the roadmap, and how did you handle it?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-map on F2 with the beats the quote states: a reliability quarter, roadmap pressure against it, you pushed it through, the on-call burden dropped 60% after. Whose pressure, what was asked of whom and how it was decided are not in the quote. Answer slot: the own-delivery line makes a probe on how that quarter was decided likely. If you made the case to someone, say to whom and what you said, in your own words; if the call was not yours, or there was no such case, say so plainly and stay with what you did | This is the story most likely to be asked in some form in all three rounds. JD because it scores own-delivery, with EXP content |
| E3 | "You said about 40 interviews last year. How was that counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | The defend-the-number slots, in your own words: how the 40 was counted, whether the interviews were ones you conducted or the loop's total, what the figure is sensitive to, the assumption you would defend least. If you do not know how it was counted, say so plainly | F3's figure, and the one a prober reaches after the 60%. EXP because it tests counting and attribution |

### Bank: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you and a product partner disagreed about what to build first." | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Selection scaffold: a named disagreement about priority, what each side argued, what you did, how it ended, the relationship afterward. If the reliability quarter is the time you pick, the quote carries only a reliability quarter, roadmap pressure against it, and that you pushed it through. Answer slot: who the pressure came from is not in the quote; if it was a product partner, say what was said and what part was yours, in your own words; if it was someone else, or no product partner was involved, say so plainly and pick another time or say none comes to mind. If no time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 is where the product-partnership line is thinnest. JD because it scores that line; VAL-style in delivery |
| G2 | "Tell me about a time you had to say no to a request from another team." | VAL | [generic] | Selection scaffold: a named request, your reason, how you said it, what the other team did next, the relationship afterward. Choose one where the hard truth landed; where your material shows no ending, say so rather than supplying one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A cross-functional interviewer's standard probe, and no quote carries it, so it is a scaffold. VAL because it scores behavior under a conflict of priorities |

### Reverse questions for Thursday

| # | Question | Why it lands |
|---|---|---|
| 1 | To the staff engineers: "What is the one thing a new engineering manager could do in their first month that would genuinely help you?" | The reciprocity question for people who will work beside you |
| 2 | To the product manager: "Where does the conversation between product, hardware and engineering break down most often?" | Goes at the seam in F5 and F6 and lets them describe it |
| 3 | "When a squad and the roadmap disagree, how is it settled, and who has the last word?" | Tells you how the seam in D1 works in practice |
| 4 | "What would you want the person in this role to do differently from how it is done today?" | Invites candid gaps from the people closest to the work |
| 5 | "How do the squads handle on-call today, and how do you feel about it?" | Shows reliability matters to you as something lived, and invites an honest answer |

## Round 3: the following Monday, VP Engineering ("values and leadership philosophy"), 30 min

### Persona weights and reasoning

The recruiter's description is a loop source for a values-style round. Published company values are not in hand, so there is no values cheat sheet (see the upgrade menu).

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Leadership-philosophy and behavior probes | High. The recruiter's words name the round's focus | Story-map where a quote carries a story, scaffold where none does; do not say what your work proves |
| Pressure | Time-boxed challenges, motive questions | Medium. The skip-level or executive prior includes it, and 30 minutes forces short answers | Pause, restate, hold a challenged position through two follow-ups, concede specifically |
| Case/Strategist | One altitude question about trade-offs across the squads | Medium. Same executive prior; a values round still leaves room for one structural question | Clarify, structure, think aloud |
| Conversational | Warm opener | Low | A short opener from C1 |

### Bank: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Two or three beliefs, each in one sentence of your own. After each, say what you did only where one of your sentences carries it: you run a hiring loop for backend roles; you pushed a reliability quarter through against roadmap pressure. Otherwise say it as how you would act. Do not tell the VP what the work proves; let them draw the inference. If you have not put a belief into words before, say so and give the one you would defend | The recruiter's own words name this round's theme. F2 and F3 are the two quotes a belief could be tied to |
| H2 | "Tell me about a time you pushed back on something senior leadership wanted." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-map on F2 with the quote's beats: a reliability quarter, roadmap pressure against it, you pushed it through, the on-call burden dropped 60% after. Answer slot: the quote does not say whose pressure it was or whether leadership was involved. If seniors were involved, say whom and what you said, in your own words; if the pressure came from elsewhere, or it never reached leadership, say so plainly and say no such time comes to mind or choose another. Where your material shows no ending for the hard truth, say so rather than supplying one | The persona's unpopular-truth stem, and F2 is the one quote that touches pressure against a plan. VAL because it scores behavior toward seniority |
| H3 | "Tell me about a time you helped someone on your team grow." | JD | [generic] | Selection scaffold: a named person, what they could not do before, what you did and what was theirs, where they are now. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | F4 is a discovery gap and the role says growth for 11 engineers. JD because it scores that line, asked as a values probe |
| H4 | "Where do you expect to be stretched in this role?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Concede in your stated terms: "I haven't managed managers, and I haven't owned a hardware-adjacent roadmap." Then for each, how you would learn it, as a plan and never a past: whom you would ask, what you would read, how you would test your own understanding. Name nothing you have not said | F5 carries both stated negatives. VAL because a values round scores candor about limits |

### Bank: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Sixty seconds: why you, over a manager who has run hardware-adjacent teams?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Pause and restate. Hold: two things you did, at their scope, and leave the weighing to the VP: you run the hiring loop for backend roles; you pushed a reliability quarter through against roadmap pressure. Concede one limit exactly: "I haven't owned a hardware-adjacent roadmap." If pushed with "so what makes you better?", return to the same two sentences; add nothing | F5 against F2 and F3. JD because it scores fit against the role including its gap; the structure is hold then concede |
| J2 | "That 60% on-call drop: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the sentence's own verb: you pushed a reliability quarter through. Answer slot: which parts were yours and which were others', in your own words; if others did parts, say who and what; if you do not know how much of the drop came from the quarter itself, say so plainly. Hold through two follow-ups by returning to what you did; concede the uncertainty specifically, and do not fold on what you know | The persona's attribution stem, aimed at F2. EXP because it scores attribution under pressure |

### Bank: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Two squads, eleven engineers, and both hardware and product making asks. How do you decide what the squads don't do?" | CASE | [generic] | Objective first. Name the sources of asks. Give ranking criteria: customer commitment, cost of delay, reversibility, risk to reliability. Say who decides what, how you say no and keep a record, and what you would review monthly. Plan, not past | F1, F5 and F6 together, at the altitude a VP works at. CASE because it scores structure |
| K2 | "What do you think is different about running engineering for a fleet of physical devices compared with a web service?" | CASE | [generic] | Reason aloud from first principles rather than from claimed experience: what stays the same, what changes, and what you would ask a squad to teach you first. Name what you would want to learn rather than asserting domain facts | F7 is the domain gap and an executive may test whether you can think in it. CASE because it scores reasoning; no CO question is possible because company research did not run |

### Reverse questions for Monday

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would make this hire a clear success in your eyes at twelve months, and what would make it a miss?" | Gets the VP's own bar, and lets you hear any worry about the gaps |
| 2 | "How do you decide how much to invest in reliability versus new work, and who owns that call?" | Fits a leadership-philosophy round and touches F2 without claiming it |
| 3 | "What was the hardest trade-off between hardware dates and software quality your managers faced recently?" | Aims at F5 at the right altitude, and invites a real story |
| 4 | "How do you develop managers here, and what would you expect of me in my first year on that front?" | Turns "I haven't managed managers" into a forward conversation |
| 5 | "What does the engineering organization actually recognise and reward, in practice?" | Reads the values in use when the published ones are not in hand |

## Prohibited claims

Built from the fit snapshot before the banks were written. No guidance, slot, bridge or rationale in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated (F5's quote) | The plain acknowledgment: "I haven't managed managers." No slot |
| Has owned a hardware-adjacent roadmap | A negative you stated (F5's quote) | The plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." No slot |
| Has led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a team lead of 6, not two squads |
| Owned delivery | Inflated form of F2 | F2's quote at its own scope: a reliability quarter pushed through against roadmap pressure. The material does not say you owned delivery |
| The reliability quarter caused the 60% drop | Inflated form of F2 | F2's quote says "after". E1's and J2's slots ask only how it was counted and which part was yours |
| Has handled hardware-roadmap pressure | Inflated form of F2 and F6 | The quote says roadmap pressure and does not say which roadmap. Keep it at that scope |
| Designed the hiring loop or made the hiring decisions | Inflated form of F3 | F3's quote at its own scope: you run the loop for backend roles. The material does not say who designed it or decided offers; C2's slot asks only about the call on offers |

## Sources

Provided documents: your message (the role description, the three scheduled rounds, the recruiter's description of Monday's round, and four statements about your background). No dossier was present. No CV and no full JD were provided.

Searches sent, by query:
- "Larkfield Systems industrial IoT company values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems device management strategy news": refused

Fetches: none.

The loop rests on your own description of the three sessions, so persona weights do not use an archetype fallback. Monday's round is detected as values-style from the recruiter's description; published values are not in hand, so there is no values cheat sheet.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | All calls were refused. It would have fed a Monday values cheat sheet with the published value names; nothing in the pack comes from it |
| 2. Larkfield Systems interview process, engineering manager | unavailable | All calls were refused. It would have added case formats and any documented loop detail; the loop here rests on your description instead |
| 3. Larkfield Systems strategy and recent news | unavailable | All calls were refused. It would have grounded a CO question and the strategy-based CASE questions; the CASE questions here are generic |
| 4. Interviewer name at Larkfield Systems | n/a | No interviewer names were given, only titles, so there was no query to form; the interviewer read is absent |
| 5. Representative engineering manager JD | skipped | The role description you supplied fixes the fit rows and the JD-tagged questions; a full JD would add rows (see the upgrade menu) |

## Upgrade menu

- The full job description text: any requirement beyond the three lines you gave becomes a new fit row and gets a JD-tagged question, and the coverage table grows to match.
- Your CV: F4, F6 and F7 could carry your own quoted sentences where they are answer slots now, and the Monday and Tuesday stories could be mapped to more than four quotes.
- Larkfield's published values pasted in, or search permission granted: a values cheat sheet for Monday with the official value names mapped to your stories, plus a CO question grounded in current strategy.
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, if search is permitted: a strategy brief, recent organization context and loop reports, offered once and run only on your say-so.
- The names or public profiles of the three kinds of interviewer: an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each one's own path.
- The recruiter's note on what the Thursday panel will cover and whether to bring anything: coverage matched to their stated focus, and a build section if a deliverable was announced. Usually one email to the recruiter.
- Any working contact you have had with a hardware team, in whatever capacity: F5 and A2 could move from a plain acknowledgment and a plan toward a story you can stand behind.
- Any engineer whose growth you drove: F4 and H3 could move from a scaffold to a story map.
- An on-call or paging export showing the load before and after the reliability quarter, and the hiring-system record of the interviews you ran: either would move F2 or F3 from medium toward high and make E1 and E3 answerable from the records.
- A tuesday-dossier.md from an earlier evaluation of this role: verified evidence, an objection named from the evidence rather than inferred, and strategy limits for each weak area. It is never required.
