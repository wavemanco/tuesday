I'll read the reference files before building the pack.
Your prep pack is saved as `ashgrove_member-experience-lead_interview_pack.md`. I built it as a loop pack for the three rounds on 20 November, with a shared fit snapshot and then a mini-pack per round. The interviewers beyond their roles aren't assigned, so there's no interviewer read and the reverse questions are role-generic. No searches were run, because the values page, the recruiter's email, the JD and your strategy summary already fixed everything a search could have changed. I didn't read the strategy brief itself, only your summary of it.

The contact-centre gap is the objection to rehearse most. It comes up in A4, B1, B5 and, hardest, in G1 with its two follow-ups. The pack also leaves several answer slots blank (F1, F3, F4, F5, F7, F9). Only you can fill those, and filling them is the first step in the prep triage.

Say the word and I'll play the panel on G1, or on any other question you pick.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Built 11 November 2026 for three rounds on 20 November 2026, run as a loop pack: one shared fit snapshot, then a mini-pack per round.

| Round | Length | Who | Relationship |
|---|---|---|---|
| 1 | 30 min | The recruiter | Recruiter screen |
| 2 | 45 min | The Head of Member Services, who would be your manager | Hiring manager, mostly behavioural |
| 3 | 60 min | A panel of two branch managers, with a 20-minute complaint-escalation case | Panel, scored against the four published values |

Interviewers beyond these roles have not been assigned, so there is no interviewer read and the reverse questions are role-generic. The upgrade menu says what names would unlock.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values |
| EXP | Whether what you have said about your work survives follow-up |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Ashgrove's altitude: its strategy, its pressures |
| CASE | Structure and reasoning on a live problem from the role |

Labels: `[grounded]` rests on a document you gave me, `[inferred]` is derived from one with the derivation named, `[generic]` is a pattern with no claim about you or Ashgrove.

An answer slot is an instruction for the interview, not a question for me. Take the branch that is true for you. Either branch is a good answer; an invented one is not.

The highest-ROI prep in this pack is the contact-centre objection. It arrives as A4, B1, B5 and, in its deepest form, G1. Rehearse G1 until the concession sounds boring.

## Prep triage

Nine days, 11 to 20 November. In this order:

1. Say G1 aloud, with its two follow-ups, until you can do it without adding anything to what your quotes carry (A4, B1, B5, G1).
2. Write your own answer to each open slot in F1, F3, F4, F5, F7 and F9 before rehearsing anything else. The pack cannot supply them and must not.
3. Run D2 aloud against a 20-minute timer, twice. Then choose a real story for each of C4 to C7 or settle on the honest branch.
4. Say A3, D3 and D4 once each, using one strategy point and your own view.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal log and a script you trained tellers on, with nothing inspected behind it, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end across branches" makes a probe on what sat beyond the branch likely. If any part of the process beyond the branch's log was yours, say which, in your own words; if none was, say so plainly and stay with the log and the script |
| F2 | "the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The quote says what you built and who uses it, not what it counted, and the bridge should not be stretched. Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet counted. If it counted either, say which and how it was counted, in your own words; if it counted neither, say so plainly and say what it did count |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | "Formal" touches the requirement, and your material does not show what rules or deadlines the log worked to. Answer slot: if the log came with rules or deadlines you worked to, say what they were and whose they were, in your own words; if it did not, or you do not know, say so plainly and stay with the log you handled |
| F5 | "coach branch supervisors on escalations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message; "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your words stay at the quote's scope: "I trained new tellers on our escalation script." Answer slot: if the people you took through the script included anyone other than new tellers, say who and what you covered; if not, say so plainly and stay with the tellers |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms (six years in retail banking, the last three as a branch supervisor), because the JD's phrase is not your phrase and swapping it in invites a probe on the difference |
| F7 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The quote says spreadsheet, not which tool, and says nothing of what it did. Answer slot: if it was built in Excel, say so and say what it counted; if it was another tool, say which; if you do not know what a figure in it depended on, say that plainly |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for one, said as a plan and never as a past. The limit you stated is above regional level; your material is silent on presenting at regional level, so claim nothing about it either way |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: the JD and the brief's digital line make a probe likely. If you have worked with a digital or app team on anything members use themselves, say what and what part was yours; if not, say so plainly and say what you would ask the digital team first |

## Grounding brief

The wording below is yours, from the summary of the July 2026 strategy brief you gave me. I have not read the brief itself.

| Strategy point | Provenance | Where it surfaces in this loop |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | [grounded] | F9, A3, D4 |
| "consolidate eight branches into five hubs over 2027" | [grounded] | D3, C6, R3-4 |
| "launch a small-business lending product in Q1 2027" | [grounded] | Background only: no question is built on it |
| "the main competitive pressure is app-only banks" | [grounded] | A3, D4 |

# Round 1: recruiter screen (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly walk through your background, motivation and what you know of Ashgrove | High. The relationship prior for a recruiter screen is Conversational first, and a casual question here is still scored | A prepared 90-second arc (A1); treat "what do you know about us" as scored (A2, A3) |
| Skeptic, light | Quiet checks on the stated gaps in F2 and F8 and on the regulated-complaints line in F4 | Medium. The prior adds a light Skeptic to a recruiter screen, and your own message names two gaps the JD touches | Name the limit first, then the plan (A4, B1); hold the quote on F4 (B2) |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey. How did you get to where you are now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Three beats, each at the scope its sentence states: the six years in retail banking and the last three as a branch supervisor; the formal complaints log and the escalation script; the monthly spreadsheet the regional manager uses. Close on what draws you to the role, as a reason that is yours. If no single reason comes to mind, say so plainly and say which line of the JD you would most want to do. About 90 seconds | F6 is the requirement this round checks most directly, and the biography question is where it is told aloud. EXP because it tests whether the CV line holds when spoken |
| A2 | "What is it about Ashgrove that interests you?" | CO | [grounded] | Choose one phrase from the published values or the brief that you can honestly say you mean, such as "if a member needs it explained twice, we wrote it wrong" or "move 40% of member service to digital channels by 2028", one line of the JD you want to do, and why. The reason has to be yours: if none comes honestly, say so plainly, then say what you most want to learn about the role | Motivation arrives in a friendly register in a recruiter screen. CO because it scores whether the reason is specific to Ashgrove, and the values page and brief are the sources for it |
| A3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Bring one point from the brief to show you read it, then one view of your own on what it means for complaints, said as your view. Do not recite all four points: the recruiter sent them, so reciting them proves only that you read the email. The view can be as simple as which of the four points you would watch first from a complaints seat, and why | The brief is the consensus answer, so the differentiator is the thought of your own. CO because it scores strategy fluency, and the digital and hub points are the ones that reach F9 |
| A4 | "The role covers the contact centre as well as the branches. How do you feel about that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The earliest form of the highest-ROI objection. Say the limit first: "I've never worked in a contact centre." Then what you do carry, at its scope: "I handled the branch's formal complaints log." Then a plan, said as a plan: what you would want to learn first about how a complaint reaches the contact centre and leaves it. Never an analogy that stands in for contact-centre work | F2 is the stated gap in the JD's own opening line, so it is asked in friendly form here before it is asked hard later. JD because it scores a stated responsibility, gap included |
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of your two stated gaps and say it plainly: "I've never worked in a contact centre" or "I've never presented to anyone above regional level." Then the plan for it, in a sentence or two. Do not offer a third weakness you have not stated, and do not dress either one as a strength | F2 and F8 are the gaps your own message states, so the answer should come from them. JD because it scores honest self-assessment against the listed requirements |
| B2 | "The role asks for experience handling regulated complaints. What did that look like for you?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold what the quote carries: "I handled the branch's formal complaints log." Answer slot: the JD asks about regulated complaints, so expect a probe on what the log worked to. If it came with rules or deadlines you worked to, say what they were and whose they were, in your own words; if it did not, or you do not know, say so plainly and stay with the log. Hold through two follow-ups by returning to the log, never by adding to it | F4 is the requirement the quote touches without showing. JD because it scores a stated requirement; the slot lets the premise be false |
| B3 | "What's prompting you to look at this role now?" | JD | [generic] | Selection criteria: a reason that points toward what the role offers, in the JD's own words, rather than away from where you are; one thing you can name; nothing you do not mean. If no single reason comes to mind, say so plainly, then say which part of the JD you would most want to do | The Skeptic's motivation check in a recruiter screen. JD because the answer is judged against the role; `[generic]` because it is a pattern and makes no claim about you |
| B4 | "The role needs comfort with Excel reporting. Tell me about the reporting you've done." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | At the quote's scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was built in Excel, say so, and say what it counted and how; if it was another tool, say which; if you do not know what a figure in it depended on, say that plainly rather than guess. Do not describe features you did not use | F7 and F3 are the reporting rows, and both are thin. JD because it scores the stated tool requirement; the slot keeps the answer inside what you built |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "How does the complaints process run today between the branches and the contact centre, and who owns it now?" | The JD's opening line is about owning that process across both, and F2 is the gap in it; this learns where the seam is before you are tested on it |
| R1-2 | "How will the three rounds on 20 November be scored, and does the panel case need any preparation?" | The recruiter's email names the case but not its materials, so this asks the one person who can say |
| R1-3 | "When will the interviewers for the second and third rounds be confirmed?" | Names unlock an interviewer read and sharper reverse questions; the recruiter has said they are not yet assigned |
| R1-4 | "Is there anything in my background you would want me to be ready to speak to in the later rounds?" | Invites the recruiter to name the concern directly, and F2 and F8 are the likeliest answers |
| R1-5 | "What does the first quarter in this role need to deliver?" | Ties your preparation to the outcome the role is hired for rather than the interview |

# Round 2: Head of Member Services, your future manager (45 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values and Behavioural | "Tell me about a time" prompts, with the four values likely to colour the stories | High. The recruiter calls this round mostly behavioural | Real stories where your quotes carry one; the honest branch where they do not (C1 to C3) |
| Skeptic | The contact-centre limit, the senior-presenting limit and the digital line, asked as a manager sizing the gaps | High. The hiring-manager prior includes a Skeptic, and F2, F8 and F9 are exactly where this interviewer would be buying risk | Limit first, plan second (B5 to B8) |
| Data-Driven Prober | Line-by-line questions on the monthly spreadsheet | Medium. The JD's reporting line sits with this manager, and F3 and F7 are the thin rows | Say what the spreadsheet counted, or say plainly that you do not know (F1, F2) |
| Case and Strategist | One live reporting design problem | Low. The hiring-manager prior is Case, but the recruiter says mostly behavioural, so one JD-driven case is enough | Clarify, structure, then metrics and risks (D1) |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to someone more senior." | VAL | [generic] | Selection criteria: a real moment with a named stake, a point where you did not fold, and a relationship that was intact afterwards. Tell it with "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem for a manager round that the recruiter calls mostly behavioural. VAL because it scores behaviour; it is the nearest rehearsal for F8's senior-audience limit |
| C2 | "Tell me about a time a complaint was hard to resolve." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pick an actual complaint from the log you handled: what the member's problem was, what you did and what happened next, with the stake named. Nothing here supplies the complaint for you. If no such complaint comes to mind, say so plainly, then describe how you handled the log | F1 is the complaints evidence and this is the prompt that opens it. EXP because the story must be yours and survive follow-ups |
| C3 | "Tell me about training new tellers on the escalation script." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | At the quote's scope: you trained new tellers on the escalation script. Answer slot: the JD asks about coaching branch supervisors on escalations, so expect a probe on who else you took through it. If the people you trained included anyone other than new tellers, say who and what you covered; if not, say so plainly and stay with the tellers. Do not say who wrote the script | F5 is the coaching row and the question is premised on its own quote. JD because it scores the stated coaching requirement; EXP is the delivery |
| B5 | "You've been a branch supervisor. How would you earn credibility with the contact centre team?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Limit first: "I've never worked in a contact centre." Then a plan, said as a plan: what you would ask them first, what you would want to watch before proposing anything, and how you would find out where branch and contact-centre handoffs go wrong. Nothing about their work is assumed here | F2 again, in the manager's frame: the second form of the highest-ROI objection. JD because it scores the cross-channel part of the role |
| B6 | "Tell me about the most senior audience you have presented to." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say the stated limit plainly: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and what, in your own words; if you have not presented in that way, say so plainly. Then a plan for preparing for a senior audience: what decision they need and what you would bring. Do not describe the regional manager's use of your spreadsheet as a presentation | F8 is the stated capability gap, and the JD names senior presenting as a requirement. JD because it scores a stated requirement; the slot lets the premise be false |
| B7 | "You'd be coaching supervisors, and you've been one yourself. How would you handle a supervisor who disagrees with you on an escalation?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Structure it, with no claim about the past: what you would ask first, what you would concede if they were right, what you would hold, and how you would follow up. Say which side of the disagreement you would want to understand before ruling on it | F5 is the coaching row, and a former supervisor coaching supervisors is the seam a manager probes. JD because it scores the coaching requirement; delivered as a short case |
| B8 | "The role works with digital teams on self-service journeys. What have you worked on with them?" | JD | [grounded] | Answer slot: if you have worked with a digital or app team on anything members use themselves, say what and what part was yours, in your own words; if not, say so plainly and say what you would ask the digital team first. The brief's 40% digital line is why this is asked | F9 has no evidence either way, so the second branch has to be available. JD because it scores a stated responsibility; the strategy brief is the raising source |
| F1 | "Walk me through the monthly complaints spreadsheet. What was in it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Beats the quote states: you built it, it is monthly, the regional manager uses it. Answer slot: the JD names volumes and resolution times, so expect a probe on what it counted. If it counted either, say which and how it was counted, in your own words; if it counted neither, say so plainly and say what it did count | F3 and F7 are the reporting rows, and the Prober is where they are tested. EXP because it tests what you built |
| F2 | "Which figure in that report would you trust least, and why?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if the report carried volumes or resolution times, say which figure you would trust least and what it depends on, in your own words; if you do not know how a figure was counted, say that plainly. If it carried neither, say so and stay with what it did count. Naming your weakest assumption before the interviewer does is the move | The Prober's stem, applied to F3. EXP because it tests whether you know your own report's limits |
| D1 | "If I asked you to report monthly on complaint volumes and resolution times across branches and the contact centre, what would you need to know first?" | CASE | [generic] | Clarify aloud before structuring: what counts as a complaint in each channel, when the clock starts and stops, and who needs the report. Then objective, how the figures would be cut, what you would measure, and the risks, such as two channels counting differently. Challenge one premise politely. No claim about your past is needed | The JD line "report monthly on complaint volumes and resolution times" turned into a live problem. CASE because it scores structure; `[generic]` because the structure is a pattern |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "Where is the complaints process working well today, and where does it hurt most?" | Asks the future manager for their own view of the problem the role exists to fix |
| R2-2 | "How is the monthly complaints report used now, and what decisions does it feed?" | Turns F3 and F7 into a question about what a good report is for |
| R2-3 | "How will the 2027 move from eight branches to five hubs change what members complain about?" | Uses the brief's consolidation point as a question rather than a recital |
| R2-4 | "What does the working relationship with the digital team look like today, and where do complaints surface in self-service?" | F9 has no evidence, so this learns the ground before it is probed |
| R2-5 | "What would tell you in my first three months that the hire was right?" | Asks the manager for their own measure of success |

# Round 3: panel of two branch managers (60 minutes, including a 20-minute case)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values and Behavioural | Stories scored against the four published values | High. The recruiter says the panel is the values round and scores against the four values | One story or honest branch per value (C4 to C7) |
| Case and Strategist | The 20-minute complaint-escalation case, and strategy questions in its vocabulary | High. The recruiter names the case and its length, and the JD's escalation line is its theme | Clarify, structure, concede what you do not know (D2 to D4) |
| Peer Evaluator | Where branch and complaints lead meet, and what happens when they disagree | Medium. Branch managers are the people whose supervisors you would coach, so the seam is theirs | Propose seam principles, not a pretended seam; reciprocity (E1, E2) |
| Pressure | A time-boxed challenge on the gaps | Low. Nothing in the recruiter's email signals a stress style, but the contact-centre limit is the one a panel might press | Hold then concede (G1) |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C4 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Value: Members First, Always. Selection criteria: a real decision, who it was for, what pressure pulled the other way, what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first of the four published values, and the panel scores against all four. VAL because it scores behaviour against that value, and the stem is the value's own wording |
| C5 | "Tell me about a time you explained something and had to explain it twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Plain Words. At the quote's scope: you trained new tellers on the escalation script. Answer slot: the value's test is whether it had to be explained twice; if any part of the script or the training had to be explained again and you changed how you explained it, say what; if not, say so plainly and stay with the training | F5 is the nearest quote to a plain-words story and carries only the training. VAL because it scores the value; the slot lets the premise be false |
| C6 | "Tell me about a time you weighed what a number said against what a branch or its town needed." | VAL | [grounded] | Value: Neighbours, Not Numbers. Selection criteria: a real moment where a figure and a local need pulled apart, what you did, what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value sits against the brief's consolidation point, so the panel of branch managers may press here. VAL because it scores behaviour against that value |
| C7 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Own the Fix. The quote carries the log you handled. Answer slot: the value says whoever finds the problem keeps hold of it, so expect a probe on a case you stayed with. If there was a complaint you stayed with until it was resolved, say what it was, what you did and what was yours; if there was none, or it passed to someone else, say so plainly and describe how you handled the log | F1 is the closest quote to the value, and the value's own wording raises the slot. VAL because it scores behaviour against that value |
| D2 | "A member's complaint has been passed between the contact centre and a branch twice. The branch supervisor wants to close it as resolved and the member does not. Walk us through what you do." | CASE | [generic] | A practice case of mine, not Ashgrove's. Clarify aloud first: what the complaint is about, what the member has been told and in what words, how long it has been open, and what the policy counts as resolved. Then the objective: the member's problem actually solved and the record true. Then who holds it from now on, what you tell the member in plain words, how you hear the supervisor's reason and concede if the facts support it, and what you check on time limits or rules. About three minutes clarifying, ten on approach, five on risks and how you would know it is fixed | The panel's case is a complaint escalation, so this rehearses its shape. CASE because it scores structure; `[generic]` because the scenario is invented and no claim about you rests on it |
| D3 | "From 2027 eight branches become five hubs. What happens to complaints when that goes through, and what would you set up before it starts?" | CO | [inferred] derived from the brief's consolidation point and the Neighbours, Not Numbers value; no claim about Ashgrove's plans | Two thesis options, each with a concession. One: if a branch closes, a member could lose the person who knew their history, so complaints reaching a hub need that history visible; concede that you do not know what Ashgrove's systems hold. Two: the closing branches' towns may read the change as numbers over neighbours, so the complaint route is where it shows first; concede that you cannot say how many members it touches. Lead with one, and ask what is already planned. Do not promise complaints will not rise | The brief's consolidation point, in the vocabulary of the value the panel scores. CO because it scores strategy fluency; CASE is the delivery |
| D4 | "40% of member service moves to digital by 2028. Where do complaints fit in a self-service journey, and what should never be self-service?" | CO | [inferred] derived from the brief's digital target and competitive point, and the Plain Words value | Thesis: a member should be able to raise a complaint and see where it stands without explaining twice, which is Plain Words in a digital journey; concede that you need to know what the digital team has already built. Anti-pick: say what should stay with a person, such as a complaint where the member needs to be heard rather than routed, with your reason. Keep the app-only bank pressure to one clause, not a lecture | F9 has no evidence, so this answers it as a view rather than a past. CO because it scores strategy fluency and uses the brief's digital and competitive points |
| E1 | "Our branches and your team will sit side by side on escalations. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who holds the complaint, who speaks to the member, and what gets recorded. For disagreement: hear the branch's reason first, concede what the facts support, escalate only what cannot be settled. No claim about your past is needed | The Peer Evaluator's stem, with the panel as the seam. JD because it scores the cross-branch part of the role |
| E2 | "What would you need from us, and what can we expect from you?" | JD | [generic] | Say what you would bring to the branches before what you need from them: what you would want to learn about each branch, and what you would tell them about where a complaint stands. Keep the needs to two or three | Reciprocity: the panel prices what the hire costs and contributes to their work. JD because it scores partnership fit |
| G1 | "Sixty seconds: why should we trust you with a role that spans the contact centre when you haven't worked in one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | The deepest rehearsal in the pack. Concede first, in your own words: "I've never worked in a contact centre." Hold at the quotes' scope: "I handled the branch's formal complaints log" and "I built the monthly complaints spreadsheet our regional manager uses." Follow-up one, "So what do you bring across channels?": return to those two sentences and say what you would learn first, as a plan. Follow-up two, "Then why not someone who has?": repeat the concession in the same words and the plan, and add nothing to what the quotes carry. If the panel adds the presenting point, the same shape: "I've never presented to anyone above regional level." The limit, named before it is asked: your material says the branch's log and a script, not a process across channels | F2 and F8 are the stated gaps and this is where they arrive hardest. JD because it scores the stated requirement; the Pressure style tests whether you hold without defending and concede without folding |

## Values cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | Selection scaffold on C4: a real decision for a member, the pressure against it, what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs something explained twice, the writing was at fault | F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Carries the training only; C5's slot covers the rest |
| Neighbours, Not Numbers | Each branch is part of its own town, and a figure does not outrank that | Selection scaffold on C6: a moment when a figure and a local need pulled apart. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Carries the log only; C7's slot covers a case you stayed with |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What would a new complaints lead do in their first month that would genuinely help your branches?" | Reciprocity: asks what the panel needs, not only what you need |
| R3-2 | "When a complaint is escalated from your branch today, what does a good handoff look like and what makes it go wrong?" | Learns the seam E1 asks about from the people who live on it |
| R3-3 | "Where would your supervisors most welcome coaching on escalations?" | F5 is the coaching row, and this asks for the target rather than assuming it |
| R3-4 | "How do you see Neighbours, Not Numbers playing out as eight branches become five hubs?" | Puts the value beside the brief's consolidation point, asked as curiosity and not as a challenge |
| R3-5 | "Which of the four values is hardest to hold to in a busy week, and what does that look like?" | Invites candour from a panel scoring against those values |

# Shared sections

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | A4, B1, B5, D2, G1 |
| "report monthly on complaint volumes and resolution times" | B4, F1, F2, D1 |
| "coach branch supervisors on escalations" | C3, B7, E1, R3-3 |
| "work with digital teams on self-service journeys" | B8, D4 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | B2, C2 |
| "confident presenting to senior leaders" | B6, C1, G1 |
| "comfortable with Excel reporting" | B4, F1, F2 |
| Published values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | C4, C5, C6, C7 |
| The brief's digital, hub and competitive points | A3, D3, D4 |

## Prohibited claims

Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says the branch's log and a script, not a process across branches. F1's slot stays inside the log and the script |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." The slot in B6 asks only about regional level |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says a formal log, not what rules governed it. B2's slot asks only what the log worked to |
| Coached supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: "I trained new tellers on our escalation script." C3's slot asks only who else you took through the script |
| Wrote or designed the escalation script | Inflated form of F5 | The quote says "our escalation script" and that you trained tellers on it. The limit is the pack's observation: your material does not say who wrote it. No slot |
| Reported complaint volumes and resolution times to leadership | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." F1 and F2's slots ask only what the spreadsheet counted |
| Built Excel reporting | Inflated form of F7 | F7's quote at its own scope; the limit is the pack's observation: your material says spreadsheet, not which tool. B4's slot asks only which tool it was and what it counted |

## Sources

Provided documents: the job description as pasted; Ashgrove's four values as pasted, copied on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the process; your summary of the July 2026 strategy brief (the brief itself was not read); your background as you described it in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved section 10: the values page you pasted supplies all four names and their wording |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights or the loop: the recruiter's email gives the three sessions, who runs each and what each holds |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO bank or grounding brief: your summary of the July 2026 brief supplies current priorities, though the brief itself was not read |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No name was given, only roles, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names for rounds 2 and 3 → an interviewer read, persona weights adjusted from public footprint, and a reverse question tied to their own path; nothing in this pack changes until then
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports, recent Ashgrove organisation context and, once names exist, the interviewers' public footprint; say yes and it runs
- Your own answers to the slots in F1, F3, F4, F5, F7 and F9, stated outside a drill → those rows gain quoted evidence and their gap types and confidence are re-graded
- The monthly complaints spreadsheet itself, with member details removed → F3 and F7 can move from `low` toward `high`, because it is the inspectable artifact for complaints reporting
- The full 2026 strategy brief → the grounding brief and D3 and D4 can quote its own wording instead of your summary
- Ashgrove's published complaints procedure → D2's `[generic]` scenario can use Ashgrove's real stages
- Your CV → evidence cells can quote it as well as your message, and F6 and F1 may gain detail
- The recruiter's answer on how the panel case is run → D2 can be shaped to its actual format
- A `tuesday-dossier.md` from a job-underwriter pass, if you have one → verified evidence and a prohibited-claims list to replace the one built here
