I'll read the skill's reference files first.
I have what I need from the references. Building the pack now. Your three rounds make this loop mode: a shared fit snapshot, then a mini-pack per round.
Dara, your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-denied-5a78e94d/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a pack for all three rounds on 20 November. It has one fit snapshot, then a mini-pack per round with its own persona weights, 8 to 12 questions and reverse questions. The values cheat sheet sits in the panel round, since the recruiter said that round scores against the four values. It runs on your pasted material only, so I ran no web searches. The highest-ROI prep is C1, the contact-centre objection.

Say the word and I'll play the Skeptic on C1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Built 11 November 2026 for three rounds on 20 November 2026.

| Round | Who | Length | What you were told |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | A conversation |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewer names are not assigned yet, so there is no interviewer read. This is a loop-mode pack: one shared fit snapshot, then a mini-pack per round.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores.
- Type key. VAL: whether past behaviour shows a published value. EXP: whether what you said about your work survives a follow-up. JD: whether you can do the listed job, gaps included. CO: whether you understand the company and its strategy. CASE: a live problem from the role.
- Provenance labels. `[grounded]` traces to a document you gave me. `[inferred]` is derived from one, with the derivation named. `[generic]` is a role-family pattern with no claim about you or Ashgrove.
- Guidance is scaffolding, not a script. Say it in your own words.
- An answer slot is an instruction for the interview, not a question for me. If its second branch is the true one, say that plainly. It is a limit, not a confession. If you fill a slot, send me the answer and I will regenerate the rows it touches.
- Question IDs run by persona: A and B are round 1, C to E round 2, G to J round 3. F is skipped so it never collides with the fit-snapshot rows F1 to F9.

## Prep triage

Sized to the nine days between today and 20 November.

1. Today to 13 November: say C1 aloud until the opening limit comes out plainly, then B1. C1 is the highest-ROI prep in this pack.
2. 13 to 15 November: fill the answer slots in the fit snapshot (F1, F3, F4, F5, F7, F9) in your own words, and prepare A1 and A3.
3. 15 to 17 November: for G1 to G4, pick one real story per value from your own experience using the scaffolds. Where none comes to mind, rehearse the honest branch.
4. 17 to 18 November: run H1 to H4 aloud against a 20-minute timer, ending with the two-minute recommendation.
5. 19 November: one live drill, on C1 or H1.
6. Everything else in this pack is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log and the escalation script, not the process across branches, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: the JD's end-to-end line makes a probe on which parts of the work beyond the log were yours likely. If any were, say which and how you decided, in your own words; if the log was where your part began and ended, or there was nothing beyond it you touched, say so plainly and stay with the log and the script |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then a plan, said as a plan and never as a past: what you would learn first about how a complaint reaches the centre and how it is recorded there, and from whom. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says you built a monthly complaints spreadsheet your regional manager uses, with nothing inspected behind it, and does not show what it counted. Answer slot: the JD's monthly-reporting line makes a probe on what the sheet showed likely. Say what it showed, in your own words, and how each item on it was counted; if you do not know how something was counted, or someone else decided what went into it, say so plainly and stay with the fact that you built it |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message, "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material says tellers, not supervisors, and the words stay there: "trained new tellers on our escalation script", with the last three of your six years in the supervisor's role as the second quote gives them. Answer slot: the JD's coaching line makes a probe on whether you have coached anyone at supervisor level likely. If you have, say who and on what, in your own words; if not, say so plainly and stay with the tellers and the script |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material speaks to this either way. Answer slot: the JD's digital-teams line makes a probe on any work with a digital or product team likely. If you have worked with one, on anything, say what it was and your part in it, in your own words; if you have not, say so plainly, then say what you would want to learn from them first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The quote already reaches the years; the JD's phrase is customer operations and yours is retail banking in a branch supervisor role. Say it in your terms: "6 years in retail banking, the last 3 as a branch supervisor." Never swap the JD's phrase in as though it were your title |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your material says formal and does not say which rules, if any, the log fell under; that is the pack's own observation, and reading formal as possibly reaching the JD's word is this pack's derivation, no more. Answer slot: the JD's regulated line makes a probe on what made a complaint formal in your branch likely. If rules from outside the branch applied, say which and what they meant for how you handled each complaint; if the log was an internal record only, or you do not know what rules applied, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." The pack's observation is that your material is silent on presenting at regional level or below; B2 and H4 carry that as an answer slot. Then a plan, said as a plan: who would review your first monthly report before it goes up, and what the people reading it would need from it. Nothing added to make the gap feel smaller |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your material says spreadsheet and does not name the tool; that it may be Excel is this pack's derivation and goes no further. Answer slot: the JD's Excel line makes a probe on what you built the sheet in and what you did in it likely. If it was Excel, say what you did in it, in your own words; if it was another tool, or your own Excel work was limited, say so plainly and stay with the fact that you built the monthly sheet |

No requirement in the JD is a gate. The 4+ years line is a length-of-experience requirement, so it is graded like any other row.

## Grounding brief

From the strategy brief as you relayed it, and the JD. The brief is dated July 2026 in your message.

| Item | What it says | Where it bites in this pack | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" — your message | A2, D4, E1, reverse questions in rounds 2 and 3 | [grounded] |
| Hubs | "consolidate eight branches into five hubs over 2027" — your message | E2, G5, reverse questions in round 3 | [grounded] |
| Small-business lending | "launch a small-business lending product in Q1 2027" — your message | No question depends on it; it is a reverse question in round 2 | [grounded] |
| Competition | "the main competitive pressure is app-only banks" — your message | A2, E1 as the frame for why self-service sits in the JD | [inferred] |
| Organisation | "member-owned, about 900 staff" — JD | A5 | [grounded] |

How to use it: bring one item to show you read it, then one view of your own, put as something you want to find out. The recruiter already sent you the brief, so reciting it proves little beyond having read it.

---

# Round 1: the recruiter (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A) | A friendly walk through your path and why this role; casual questions about the credit union | High. The recruiter's email makes round 1 a 30-minute conversation with the recruiter, and a recruiter screen's prior is Conversational plus a light Skeptic | One 90-second arc whose beats are the quote's: "6 years in retail banking, the last 3 as a branch supervisor." Treat casual questions about the JD's hot topics as scored, and use the reverse-question slot |
| Skeptic, light (B) | Knockout-style checks on the JD's contact-centre, senior-leader and motivation lines | Medium. The prior for a recruiter screen is knockout checks in a friendly register, and the JD presses on lines your material has limits on (F2, F8) | Say a limit before it is pressed, plainly; hold only what your quoted sentences carry; close with a plan |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your path in retail banking, and why this role now." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Two beats the quote states: six years in retail banking, then the last three as a branch supervisor. Keep to the quote's numbers. Close on why this role. Answer slot: the reason is yours alone; say in your own words what draws you to a role that owns complaints across branches. If there is more than one reason, lead with the one you can say without criticising anyone. About 90 seconds, ending on the reason, not the history | F6 is the evidence for the years requirement, and the screen opens on the path. EXP because it checks that the path told aloud matches what you wrote; Conversational because it arrives as an opener |
| A2 | "What do you know about us, and what made you apply?" | CO | [grounded] | Bring one fact from the brief, then one view of your own, put as something you want to find out. Example: the 40% digital line raises where a complaint goes when it starts in one channel and needs a person. Name two of the four values by their exact names, from Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix, and say which you would hold yourself to first. Do not recite the brief | CO because it tests homework on current strategy; the brief and the pasted values are the sources. A recruiter screen carries the motivation probe in a friendly register |
| A3 | "Tell me about your current role and what you do day to day." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Three beats, each one the quotes state: the last three years as a branch supervisor; handling the branch's formal complaints log and training new tellers on the escalation script; building the monthly complaints spreadsheet your regional manager uses. Stay at the scope of the sentences: handled, trained, built. If a follow-up goes beyond them, answer only from what you did, or say plainly that it was not yours | F1, F3 and F4 are the rows this answer carries, and the recruiter is the first to compare it with the JD. EXP because it checks the story told aloud against what you wrote |
| A4 | "Tell me about the formal complaints log you handled — what made a complaint formal there?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from the quote's own words: you handled the branch's formal complaints log. Then say what made a complaint formal there, in your own words. Answer slot: the JD says regulated, so expect a probe on rules. If rules from outside the branch applied to the log, say which and what they meant for how you handled each complaint; if the log was an internal record only, or you do not know what rules applied, say so plainly and stay with the log you handled | F7 is the row the JD's regulated-complaints requirement presses on, and a screen is where it is first checked. JD because it scores a stated requirement |
| A5 | "You've worked in retail banking. How do you see a credit union differing from a bank?" | CO | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Answer from what you have seen, in the quote's terms, and say what you would want to learn. Tie one difference to a published value by its exact name; the JD calls Ashgrove member-owned. Answer slot: if any of your years were at a member-owned institution, say so; if none were, say so plainly and stay with retail banking | F6 supports the years; CO because it tests whether you understand what kind of organisation you are joining. Asked in a conversational register |
| B1 | "Your background is branch-side, and this role covers the contact centre too. How do you see that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open with the limit, in the words you stated: "I've never worked in a contact centre." Then what the second quote carries, at its own scope: you handled the branch's formal complaints log and trained new tellers on the escalation script. Close with a plan, as a plan: what you would learn first and from whom. About 60 seconds. The full rehearsal is C1 | F2 is the largest gap against the JD, and a screen's knockout check lands on it first. JD because it scores a stated requirement; light Skeptic register |
| B2 | "The role asks for confidence presenting to senior leaders. Where are you on that today?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say the limit in the words you stated: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level or below, say to whom and about what, in your own words; if you have not, say so plainly. Close with a plan, as a plan: who would review your first monthly report before it goes up. Under 60 seconds. The full rehearsal is H4 | F8 is the second limit your message states, and the JD names senior leaders outright. JD because it scores a stated requirement |
| B3 | "Why move from the branch to a role that sits across branches and the contact centre?" | JD | [generic] | The reason is yours, so the pack supplies none. Make it about the role's own scope: owning complaints across branches and the contact centre, which is the JD's line. If you have more than one reason, lead with the one you can say without criticising anyone. If part of the pull is something the role does not do, leave it out rather than stretch the role to fit | A motivation-consistency probe that the Skeptic prior predicts. JD because the answer must connect to the role's scope; `[generic]` because no quoted sentence is needed for it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "The strategy brief is from July. Has anything in it moved since?" | Shows you read it, and checks that the facts you lean on in later rounds are current |
| R1.2 | "How is the panel's score against the four values used in the decision?" | Tells you how much weight round 3 carries before you spend prep on it |
| R1.3 | "Who will I meet in rounds 2 and 3, and has the panel been confirmed?" | Practical, and the answer unlocks the interviewer read in the upgrade menu |
| R1.4 | "How much of this role sits in the contact centre from the first day, and how much phases in?" | Lets you hear the real weight of F2 before round 2, in a setting where it is a logistics question |
| R1.5 | "What would a strong first 90 days look like, as the hiring team describes it?" | Turns the screen into a conversation about delivery and gives you vocabulary for round 2 |

---

# Round 2: the Head of Member Services (45 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (D) | Scenario probes and "tell me about a time" stems from the person who would be your manager | High. The recruiter's email calls this round mostly behavioural | Where one of your quoted sentences carries a story, map it and tell it in its own scope; where none does, use the selection scaffold and its honest branch. "We" for context, "I" for what you did |
| Skeptic (C) | Quiet, persistent probing of the contact-centre gap, the supervisor-coaching line and the monthly sheet | High. A hiring-manager prior is a Skeptic buying capability and derisking gaps, and the email says this person would be your manager | Rehearse C1 until it is boring: limit first, hold only what the quotes carry, concede specifically, never fold the core position |
| Case / Strategist (E) | A live problem on the role's own roadmap: digital shift, hubs, the monthly report | Medium. The hiring-manager prior includes live problems, tempered by the email's "mostly behavioural" | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never worked in a contact centre, and this role owns complaints across branches and the contact centre. Why should I believe you can own the contact-centre side?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Opening, limit first: "I've never worked in a contact centre." Then hold only what the second quote carries: you handled the branch's formal complaints log and trained new tellers on the escalation script. Then a plan, said as a plan: what you would learn first, and from whom, before you changed anything. Follow-up 1, a branch log is not a contact-centre queue: concede the difference plainly, do not argue equivalence, return to the plan. Follow-up 2, who would you lean on in month one: answer with roles, not names, as a plan. Follow-up 3, would you rather we carved the centre out: hold, because the role as written covers both, and your position is that you would want to learn the centre before proposing any change to it. Never fold the core position to restore harmony: the position is that you will learn it, never that you have done it. Opening 90 to 120 seconds; each follow-up 30 | F2 is the gap the JD's first responsibility line presses on, so this objection is likely to arrive in some form in every round. JD because it scores a stated requirement; Skeptic because it targets the gap, from the person who would be your manager |
| C2 | "You've handled the formal complaints log and trained new tellers on the escalation script, but this role coaches supervisors on escalations. What makes you the person to coach them?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | Hold what the quotes carry: you handled the log and trained new tellers on the script, and the last three of your six years were as a branch supervisor. Concede the difference first: your material says tellers, not supervisors. Answer slot: if you have coached anyone at supervisor level, say who and on what, in your own words; if not, say so plainly and stay with the tellers and the script. Then a plan, said as a plan: how you would open a first coaching conversation. Hold through two follow-ups by returning to the quotes, never by adding to them | F4 is transferability: adjacent work, a different audience. JD because it scores a stated requirement; Skeptic because it presses the adjacent-not-direct seam |
| C3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick the one that is true and name it before you are pressed. Two limits are in your own words: "I've never worked in a contact centre." and "I've never presented to anyone above regional level." The digital-teams line is one your material is silent on (F5). Say your pick, then one sentence of plan. Avoid a strength dressed as a weakness | F2, F8 and F5 are the candidates for the honest answer. JD because the question is about the listed job; Skeptic because it asks you to price your own gap |
| C4 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The sentence carries one fact: you built the monthly complaints spreadsheet your regional manager uses. Tell it in those terms. Answer slot: the JD asks for monthly reporting and Excel, so expect probes on what it showed, which tool it was in, and how each item was counted. Say what it showed, the tool, and how each item was counted, in your own words; if you do not know how something was counted, say so plainly. If part of it was not yours, or it was not in Excel, say so plainly and stay with the fact that you built it. If anything on it is an assumption you would defend least, say which and why before you are asked | F3 and F9 both rest on this one sentence, so a probe goes deepest here. EXP because it tests attribution and method; a prober's style in the Skeptic's chair |
| D1 | "Tell me about a time a complaint had to be escalated and you had to decide what happened next." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | No quoted sentence carries an escalation story, so this is a selection scaffold. Pick a case with a named stake for the member, a decision that was yours, what you did, and where it ended. "We" for context, "I" for what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the log and the escalation script, or how you would handle it | F1 and F4 both press on escalation. JD because the theme comes from the role's own scope; behavioural delivery because the email calls the round mostly behavioural |
| D2 | "Walk me through how you trained new tellers on the escalation script." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beats the quote states: new tellers, the escalation script, the training. Tell them in your own words. Answer slot: the JD's coaching line makes a probe on how you taught it likely. If you reworded or reordered anything in the script or in how you taught it, say what and why; if you did not, or the script was not yours to change, say so plainly and stay with the training | F4 is the nearest thing to the coaching requirement. EXP because the training is the part of your message a manager can test directly |
| D3 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [generic] | A selection scaffold. Choose a case with a named stake, a moment you did not soften the point, and a relationship that was intact at the end. Pick one where the hard truth actually landed. "We" for context, "I" for what you said. If no such time comes to mind, say so plainly, then say how you would handle it | The JD's senior-leaders line makes this a likely stem, and F8 is why the word senior is sensitive for you. VAL because the bar is behaviour under pressure, not the role's skills |
| D4 | "Tell me about a time you worked with another team to fix something that kept going wrong for members." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | F5 has no sentence behind it, so this is a selection scaffold. Pick a case with a named other team, a problem you both could see, what each side did, and how it ended. The nearest thing your material carries is that you built the monthly complaints spreadsheet your regional manager uses; do not stretch it into work with a digital team. If no such time comes to mind, say so plainly, then say how you would start with a digital team on a self-service journey: from what the complaints show | F5 is the one requirement with nothing behind it. JD because the theme is the JD's own line, delivered as a behavioural stem |
| E1 | "Our plan moves 40% of member service to digital channels by 2028. Which complaints would you want to keep with a person, and why?" | CO | [grounded] | Clarify first: what counts as member service in the 40%, and who decides what moves. Objective: members who complain are not worse off for the channel. Segment complaint types by what you would want to know about each, not by assumption. Approach, then metrics: the JD's volumes and resolution times, by channel. Risk: a complaint that starts in one channel and needs a person in another. Challenge one premise respectfully, such as whether 40% of service is the same as 40% of complaints. Think aloud | The brief's digital line is the likeliest strategy case for a manager who owns member services. CO because it tests the company's own vocabulary; the guidance makes no claim about your past |
| E2 | "We are consolidating eight branches into five hubs over 2027. What would you want to know about complaints before and during that?" | CASE | [inferred] | The scenario is derived from the brief's hubs line. Clarify the timetable and which branches. Ask what you would want to see by branch before the change, so a town's complaints are not lost inside an average. Name what you would watch during it, and say you do not yet know what the plan adds beyond the brief. Do not take a side on the hubs; describe how complaints should be handled through the change | A case set in the role and on the company's strategy. `[inferred]` because the question is derived from one line of the brief, not from a documented interview question |
| E3 | "You are building the monthly complaints report for senior leaders. What goes in it, and how do you decide?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Clarify who reads it and what they decide from it. Start from the two measures the JD names, volumes and resolution times, and say how each would be counted. Lead with what changed since last month. Keep it to one page. Answer slot: if the sheet you built showed measures like these, say which, in your own words; if it did not, say so plainly and design from the JD's two | F3 content, delivered as a case; it also tests the senior-leader framing F8 is thin on. JD content, CASE delivery |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would you want the first monthly complaints report to tell you?" | Gets the manager's own definition of success for the reporting line, and shows you start from the reader |
| R2.2 | "Where do complaints change hands between branches and the contact centre today, and how well does that work?" | Opens the F2 gap as curiosity about the system rather than a defence |
| R2.3 | "Which complaints do you expect the digital shift to take first, and which would you not want it to take?" | Ties you to the brief's 40% line and the JD's self-service line |
| R2.4 | "Will complaints on the small-business lending product come through the same process?" | Shows you read the brief's Q1 2027 launch as something that lands on this role |
| R2.5 | "What should a new lead not change in the first three months?" | Signals judgment, and the answer tells you the manager's tolerance for change |

---

# Round 3: the panel of two branch managers (60 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (G) | Stories scored against the four values by name | High. The recruiter's email says the panel is the values round and scores against the four values | Map a story to each value where a quoted sentence carries one; elsewhere use the scaffold and its honest branch; land the hard truth |
| Case / Strategist (H) | The 20-minute complaint-escalation case, plus a short follow-up | High. The email gives the case 20 of the 60 minutes | Say the frame aloud first; clarify before structuring; challenge one premise respectfully; close with a short recommendation |
| Peer Evaluator (J) | Seam-splitting between a branch and your process: what you need from them, what they can count on from you | Medium. The panel is two branch managers, and the JD's coaching line puts supervisors in the branches; this is the pack's derivation, not a stated format. `[inferred]` | Reciprocity: say what you bring their branches as well as what you need; offer seam principles rather than pretending to know their seams |

A time-boxed or interrupting style is possible in a case. No source says either way, so it is not weighted; H1's structure holds up under interruption.

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you made a decision from the member's side of the counter when something else pulled the other way." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | No quoted sentence carries this story, so this is a selection scaffold. Pick a case where the member's interest and a process, a target or a colleague's view pulled apart; name what pulled, what you decided, and what happened to the member. "We" for context, "I" for the decision. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the formal complaints log you handled, or how you would decide | F1 is the nearest evidence. VAL because the panel scores against Members First, Always, the first published value |
| G2 | "Tell me about a time you had to explain something so a member did not need it explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold with one quote beside it. Pick a moment where an explanation needed changing: what the first explanation was, what you changed, how you knew it had landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is training new tellers on the escalation script, or how you would write it. Answer slot: Plain Words says if a member needs it explained twice, we wrote it wrong, so expect a probe on wording. If you reworded anything, say what and why; if you did not, or it was not yours to change, say so plainly and stay with the training | F4 is the nearest sentence. VAL because the panel scores Plain Words by name |
| G3 | "Tell me about a time local knowledge of a branch's town changed how you handled something." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold. Pick a case with a named local circumstance, what you knew because of it, and what you did differently. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the branch's formal complaints log you handled, or how you would learn a town's circumstances before acting | F1 is the nearest evidence, and nothing in your material speaks to local knowledge. VAL because the panel scores Neighbours, Not Numbers; the panel being branch managers makes this value live in the room |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The sentence carries handling the log; tell that in its terms. Answer slot: Own the Fix says whoever finds the problem keeps hold of it until it is solved, so expect a probe on a problem that stayed with you. If one did, say what it was, what you did and how it ended, in your own words; if the log was a record rather than something you followed through, or someone else took it on, say so plainly and stay with the log | F1 and F4 are where this value would be tested. VAL because the panel scores Own the Fix, and it is the value closest to the role's end-to-end line |
| G5 | "We are consolidating eight branches into five hubs over 2027, and one of our values is Neighbours, Not Numbers. How do those two sit together for you?" | CO | [inferred] | The pairing is derived from the brief's hubs line and the pasted values. Do not pick a side. Name the tension fairly, then offer a principle: members of every affected branch should be heard and counted by branch, so a town is not lost inside an average. Say that what you know comes from the brief. Hold the position through two follow-ups: you are describing how complaints should be handled through the change, not arguing for or against hubs | The panel are branch managers and the hubs line concerns branches. CO because it tests whether you can hold a values-versus-strategy tension at the company's altitude; `[inferred]` because the question is this pack's derivation |
| H1 | "A member has complained about the same issue at a branch twice. The branch supervisor tells you it is resolved, but the member's third contact, with the contact centre, says it is not. You have twenty minutes: what do you do?" | CASE | [generic] | Say the frame aloud first. Clarify: what the member says the issue is, what the record shows at each contact, what the member has been told, and what rules or deadlines apply to a complaint at this stage. Objective: the member hears one clear answer from one named person. Separate fact from the supervisor's view from the member's. Approach: decide who holds the case from now, tell the member in plain words what happens and when, check the record, and speak to the supervisor separately. Record: how it shows in the monthly report. Risk: the member told two things, or branch and centre closing it differently. Challenge one premise respectfully: ask who decided it was resolved and on what basis. Name Own the Fix or Plain Words when it fits naturally | The recruiter named a 20-minute complaint-escalation case, and the JD's branches-and-contact-centre scope sets its shape. CASE; the scenario is a generic pattern, not Ashgrove's real case |
| H2 | "The supervisor insists the process was followed and feels second-guessed. How do you handle that conversation?" | CASE | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Structure: the member first, then the supervisor; separate what the record shows from what anyone concluded; ask before telling; agree one next step. You can say the last three of your six years were as a branch supervisor, and no more than that. If asked whether you have coached supervisors, answer from the F4 slot in C2 | F4 is the row this case presses on. CASE because it is a live problem on the role's coaching line |
| H3 | "Three weeks on, the same problem reaches four more members across two branches. What now?" | CASE | [generic] | Move from the case to the cause: confirm it is the same problem, find where in the process it starts, name one owner, fix it, tell affected members plainly, and decide what the next monthly report should show. Say what you would not do yet: assume the cause. The owner keeps hold until it is solved, which is Own the Fix by name | Tests pattern thinking and the link from escalation to reporting, the JD's two responsibilities together. CASE; generic because the numbers are the pack's own illustration |
| H4 | "Close the case: give us your recommendation in two minutes, as you would to a senior leader." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Answer first, then three reasons, one risk, and one thing you need decided. Practise it aloud with a timer. If asked about presenting experience, say the limit in your own words: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level or below, say what and to whom; if you have not, say so plainly and stay with what you are doing now, giving a recommendation to this panel | F8 is the limit the JD's senior-leaders line presses on, and the end of the case is where it is tested live. JD because it scores a stated requirement |
| J1 | "We run the branches your process will land in. What do you need from us, and what can we count on from you?" | JD | [generic] | Reciprocity first: name two things branches could count on from you and two things you would ask of branches, as principles, in your own words. Do not pretend to know their seams yet; say you would learn each branch's way of working before changing anything | The Peer prior, applied to the JD's end-to-end line. JD because the answer is the role's working relationship |
| J2 | "Where is the line between coaching a supervisor and policing one?" | JD | [generic] | Offer a principle, not a story you do not have: the member comes first, the record is shared, the coaching is private and starts with asking. Say where you would hold the line, and one thing you would concede. If a follow-up asks for your own experience, answer from the F4 slot in C2 | F4's coaching line from the branch manager's side. JD because it scores the stated responsibility |
| J3 | "You built the monthly complaints spreadsheet your regional manager uses. How much of it was yours, and did anyone else work on it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say exactly what was yours; the sentence says built, so use it and do not widen it. Answer slot: if anyone else contributed to it, reviewed it or used it beyond the regional manager, say so and name your part, in your own words; if no one else did, say that. Credit others where it is true | F3 under attribution scrutiny. EXP because it asks "how much was actually you", framed collegially by people who would work with the output |

## Values cheat sheet

The four values are quoted by name from the page you copied this morning from ashgrovecu.org/about/values.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | The decision is made from the member's side of the counter | F1: nearest sentence "I handled the branch's formal complaints log and trained new tellers on our escalation script." It carries no decision story, so use G1's scaffold, ending in its honest branch |
| Plain Words | If a member needs it explained twice, the wording was wrong | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Tell the training beats in the quote's terms; G2 holds the slot on wording |
| Neighbours, Not Numbers | A branch belongs to its town, not only to a total | F1: nearest sentence "I handled the branch's formal complaints log and trained new tellers on our escalation script." It carries no local-knowledge story, so use G3's scaffold, ending in its honest branch |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Tell the handling in its terms; G4 holds the slot on following a problem through |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "When a complaint escalates from your branch, what do you most want from the person who takes it?" | Puts the panel's own need first and gives you the seam principles for J1 |
| R3.2 | "Where do you see Neighbours, Not Numbers show up day to day in your branch?" | Invites a real example, and gives you the panel's own evidence of the value |
| R3.3 | "How are you and your teams hearing about the move to hubs, and what are members asking?" | Shows you read the brief and care about their side of it; leave it if they cannot speak to plans |
| R3.4 | "What would help your branch most from this role in the first quarter?" | The reciprocity question: it asks what the new person could do for them |
| R3.5 | "What is one escalation from your branch you were proud of how it was handled?" | A rapport question that also shows you what the panel scores as good |

---

## Requirement coverage

| JD requirement | Fit row | Question IDs |
|---|---|---|
| "Own the member complaints process end to end" | F1 | A3, D1, G4, H1, J1 |
| "across branches and the contact centre" | F2 | B1, C1, C3, H1 |
| "report monthly on complaint volumes and resolution times" | F3 | C4, E3, J3 |
| "coach branch supervisors on escalations" | F4 | C2, D2, H2, J2 |
| "work with digital teams on self-service journeys" | F5 | D4, E1 |
| "4+ years in financial-services customer operations" | F6 | A1, A5 |
| "experience handling regulated complaints" | F7 | A4, H1 |
| "confident presenting to senior leaders" | F8 | B2, C3, D3, H4 |
| "comfortable with Excel reporting" | F9 | C4 |

No figure appears in your material beyond the years, so there is no defend-the-number question beyond C4's assumption slot.

## Prohibited claims

Built locally from the fit snapshot before the banks were written. No guidance cell in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log and the script, not the process across branches. F1's slot stays inside the log |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." The slot in B2 and H4 asks only about regional level or below |
| Has coached branch supervisors | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says tellers, not supervisors. C2's slot asks only whether anyone at supervisor level was coached, with the second branch open |
| Reported volumes and resolution times every month | Inflated form of F3 | F3's quote at its own scope. C4's slot asks only what the sheet showed |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says a formal log, not which rules applied. A4's slot asks what made a complaint formal |

## Sources

Provided documents: the JD you pasted; the four values you copied from ashgrovecu.org/about/values; the recruiter's email on the process; the four points of the July 2026 strategy brief as you relayed them; your background as you wrote it. No dossier was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page is in hand and fixes the values cheat sheet and bank G: four principles by name |
| 2. Ashgrove interview process, complaints and member-service roles | skipped | The recruiter's email fixes the loop: three sessions, who runs each, what each holds; persona weights follow it |
| 3. Ashgrove strategy and recent news | skipped | The brief's four points as you relayed them fix A2, E1, E2 and G5; a deeper pass is the offer in the upgrade menu |
| 4. Interviewer name and Ashgrove | n/a | No interviewer names were given, so no query could be formed; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → the nine fit rows can take quotes beyond the five sentences in your message, and several `[grounded]` answer slots can become story maps
- A redacted copy of the monthly complaints spreadsheet, or an extract of the complaints log → F1, F3, F7 and F9 can rise from medium or low toward high, and C4 gets a real defend-the-number rehearsal
- Your answers to the answer slots in F1, F3, F4, F5, F7 and F9 → each becomes quoted evidence and the rows and questions that draw on it regenerate
- The names of your three interviewers → an interviewer read from public professional footprint, and a reverse question tied to each person's path
- The recruiter's answer on how round 2's behavioural questions and round 3's value scoring work, such as how many questions are scored → persona weights and bank depth in rounds 2 and 3 can be recalibrated; usually one email
- The full strategy brief text, rather than the four points → the grounding brief and E1, E2 and G5 can quote the brief itself
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes → a fuller strategy and recent-news picture, role-family loop reports, and which complaints rules Ashgrove works to, so A4 and H1's clarifying questions can be exact
- A previously saved tuesday-dossier.md → verified evidence and any prohibited claims would replace the locally built list
