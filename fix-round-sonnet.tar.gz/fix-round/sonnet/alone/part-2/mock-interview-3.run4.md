I'll read the reference files the skill calls for before building the pack.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-3-denied-9ac54eb4/stripe_product-operations-manager_interview_pack.md`.

I built it for a single final-round conversation, with flat relationship weights. I don't have a job description, your CV, or your interviewer's identity.

Web search was refused in this session, so none of the research ran. The pack has nothing on Stripe's published values, interview loop or current strategy. The values cheat sheet and the company-research section are dropped, and the two Stripe-specific questions (A5, G3) stay generic. The Sources section lists every refused search.

The pack has 22 questions across seven personas, a fit snapshot, reverse questions and a prohibited-claims section. Because I had no CV, every question about your past is a selection scaffold. It ends with an honest fallback, so nothing in it asserts experience you haven't told me about.

The most important prep is B1, "Which part of this role would you be weakest at on day one?" It is the likeliest question to come up for any candidate.

Say the word and I'll play the Skeptic on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Who is your final-round interviewer (future manager, a peer, or someone senior), and did the recruiter name any focus areas or a deliverable? The answer reweights every bank.
2. Can you paste the job description and your CV, or would you rather I proceed without them? Each turns the generic rows into rows built on your own words.
3. Is there anything about the role's location, onsite expectations or work authorization that you haven't confirmed you meet? That is row F6 of the fit snapshot, which I can't settle from what I have.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Final round. Interviewer name and relationship: not given. Built on this assumption: a single final-round conversation with persona weights tilted only by the round label and the role family, no job description, no CV, and no web research (the search calls were refused; see Sources). Regeneration changelog: none, this is the first version.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: every sentence about your own past has to come from you, in your own words, because this pack was given nothing about your background and invents none.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment: does past behavior show a specific value |
| EXP | Work-experience deep-dive: what you actually did and how you can defend it |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth |
| CASE | A live problem set in the role, scored on structure and reasoning |

Persona weights rest on a generic pattern, not on Stripe's documented process: nothing read in this session establishes how Stripe runs its final round.

## Fit snapshot

No CV and no job description were supplied, so this is the worksheet variant: every evidence cell reads `none given`, and the requirements are role-family patterns written as plain prose, not quotes. When you add a CV or JD, these rows regenerate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Role-family pattern: coordinate launches and rollouts across product, engineering and go-to-market teams without owning those teams | none given | none | [generic] | discovery | Strong evidence is a launch or rollout you coordinated, with the teams involved and what you personally decided named in your own words. Selection scaffold: pick one instance with named teams, a real disagreement and a concrete outcome; if no such instance comes to mind, say so plainly, then give the nearest work your material does carry, or how you would run it |
| F2 | Role-family pattern: define and track product-health metrics and diagnose movements in them | none given | none | [generic] | discovery | Strong evidence is a metric you defined or tracked, with how it was counted and what it is sensitive to. Selection scaffold: pick one number you can explain end to end, including the assumption you would defend least; if you do not know how a figure was counted, say so plainly, then give the nearest work you did carry, or how you would find out |
| F3 | Role-family pattern: design and improve operating processes and cadences between teams | none given | none | [generic] | discovery | Strong evidence is a process or cadence you set up or changed, who used it, and what changed afterwards. Selection scaffold: pick one process with a named before and after; if none was yours, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F4 | Role-family pattern: gather feedback from users, operators or internal teams and turn it into priorities | none given | none | [generic] | discovery | Strong evidence is a feedback channel you ran and a decision it informed. Selection scaffold: pick one decision where feedback changed the outcome, naming your part; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Role-family pattern: communicate clearly, in writing and live, to senior audiences | none given | none | [generic] | discovery | Strong evidence is a memo, update or readout you wrote for senior readers and how it was received. Selection scaffold: pick one communication where the audience mattered; if you have none that fits, say so plainly and describe how you would structure one |
| F6 | Role-family pattern: the role's location, onsite expectations and work-authorization terms | none given | none | [generic] | hard_gate | Your material does not establish whether this is met. This is a term you meet or do not, so wording cannot help and the pack coaches nothing here |

## Persona table

Relationship to the interviewer is unknown, so the relationship priors are flat. The tilt below comes only from the round label and the role family, and you should recalibrate it if you know who is in the room.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| A Case/Strategist (weight 4) | Live problems set in the role: launch conflicts, metric drops, intake prioritization | High. A final round for an operations role in a product organization commonly includes live problems; relationship unknown, so this is a role-family tilt only | Clarify, then objective, segmentation, approach, metrics, risks; think aloud and challenge one premise respectfully | [generic] |
| B Skeptic (weight 4) | Quiet probing of weakest areas and motivation: why this role, why now | High. Final rounds are where remaining doubts are tested; the objection itself cannot be inferred without a CV | Rehearse the single most predictable objection until it is boring; bridge only from adjacent work you can state, and name the limit plainly | [generic] |
| C Values/Behavioral (weight 3) | Scenario probes mapped to company values, STAR-shaped | Medium. No values-style round is detected: no loop source was read, and the generic fallback reads no | Choose stories where the hard truth actually landed; use "we" for context and "I" for contribution; if none fits, say so | [generic] |
| D Peer Evaluator (weight 3) | Seam-splitting with adjacent teams, credit, collaboration | Medium. Operations roles sit between teams, so seam questions are likely whoever asks; relationship unknown | Reciprocity framing; propose seam principles, not a claimed knowledge of the seam | [generic] |
| E Data-Driven Prober (weight 3) | Line-by-line probing of numbers and analyses | Medium. Any metric you mention can draw this; no CV means no known headline numbers | Know what you can and cannot say about how each number was counted; name the weakest assumption first | [generic] |
| F Pressure (weight 2) | Time-boxed or interrupted answers, attribution challenges | Low to medium. Applies mainly if a senior or stress-style interviewer is in the loop; unknown | Pause, restate, hold a challenged position through two follow-ups, then concede specifically | [generic] |
| G Conversational (weight 2) | Friendly openers, journey and motivation questions that are still scored | Medium. Openers are near-universal; low weight only because the depth sits elsewhere | Prepare a 90-second arc from your own account; treat casual questions as scored | [generic] |

## Question banks

Every row carries `[generic]` alone in Provenance because the guidance makes no claim about your past: with no CV there is no quoted sentence of yours to rest one on. Where a question asks about your past, it is an open prompt, and the guidance is a selection scaffold ending in its honest branch.

### A. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks out and three teams each say a different date is the real one. How do you get to one plan?" | CASE | [generic] | Clarify what each date is tied to, what slipping costs, and who holds the decision. Then state the objective, lay out two or three options with their trade-offs, name the decision owner and the date it is decided, and say how the result is communicated and what you would watch. Think aloud and challenge one premise respectfully | Covers F1 as a live problem asking about no past; CASE because it is scored on structure |
| A2 | "A key adoption metric for a product dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Check first whether the number is real: definition, instrumentation, data delays. Then segment, check recent changes and outside factors, rank hypotheses by cost to test, and say what you would report before the cause is known. Name the assumption in your diagnosis you would defend least | Covers F2; the persona stem for this type; CASE with a metrics lens |
| A3 | "Product teams send you requests all week and you can do a fraction. How do you decide what gets done?" | CASE | [generic] | Ask what the operating goals are and who decides priorities. Offer a small set of criteria, a visible intake and queue, a way to say no with reasons, and a review rhythm. State your criteria as principles to adapt, not as a claimed past practice | Covers F3 and F4; CASE because it tests structure; JD flavor |
| A4 | "Sketch the plan for an operating cadence between product, engineering and support for a product that is scaling. What do you need to know first?" | CASE | [generic] | Open with the questions: what breaks today, who attends, what decisions the cadence must produce. Then goal, a minimal first version, how you would measure whether it helps, and when you would stop doing it | Covers F3; the persona stem; CASE with a process lens |
| A5 | "Which parts of Stripe's business would you want to understand best before your first day, and how would you go about learning them?" | CO | [generic] | No research ran, so this pack states nothing about Stripe's business. Prepare from Stripe's own public materials and say which you read; if you have not studied it, say so plainly, then say what you would read first and why | Homework depth; CO questions stay generic until research runs, and the upgrade menu says what would change that |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack: it is the most predictable question for any candidate and the one where the interviewer tests honest self-assessment. Pick a real weak area from your own self-assessment; if no single area comes to mind, say so plainly, then name the nearest area where you have least practice. State the limit once, say how you would close it in the first 90 days and how you would know it was closed. Hold through two follow-ups by repeating the plan, not by adding experience | F1 to F5 all leave a weak area open; JD because it scores the role's own requirements, Skeptic because it probes the gap |
| B2 | "Why this role, and why now?" | JD | [generic] | Give your real reasons in your own words: one about the work, one about the timing. If your reasons are mixed, say so briefly and lead with the one you would still stand behind a month from now | Motivation consistency is what the persona scores; JD because it tests fit to the role |
| B3 | "Product operations means different things at different companies. What do you take it to mean here, and where would you push back on that?" | JD | [generic] | State your working definition as a hypothesis and ask what the scope actually is. Offer one place you would push back, with reasoning, and stay open to being corrected | Tests whether you understood the scope or assumed it; JD |
| B4 | "What is the feedback you've had that was hardest to hear, and what did you change?" | EXP | [generic] | Selection scaffold: pick feedback that was specific and that you acted on, with a visible change afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Honest self-assessment is what the persona scores; EXP because it asks what you did |

### C. Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem; VAL because it scores behavior, not slogans |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two actually conflicted, name what you gave up and who agreed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem; VAL; no Stripe value is quoted because none was fetched |

### D. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know the seam: who owns the outcome, who owns the process, how a disagreement is escalated and how it is recorded. Ask how it works today | Peer stem; JD because it scores the working relationship the role needs; F1 and F3 |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick work that spanned teams, use "we" for context and "I" for your contribution, and say how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; EXP because it tests attribution honesty |
| D3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Answer both halves: a short list of what you would need, and one or two things you could offer, stated as intentions and not as past results | Reciprocity framing; JD |

### E. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a number you've reported and walk me through how it was counted." | EXP | [generic] | Selection scaffold: pick a number you can explain end to end. Say how it was counted, what it is sensitive to, which assumption you would defend least, and which part was yours. If you do not know how a figure was counted, say so plainly, then say what you do know | Defend-the-number rehearsal; EXP; F2 |
| E2 | "Pick an analysis you did yourself and walk me through it end to end." | EXP | [generic] | Selection scaffold: pick one you can retell from question to decision, naming the data, the choice you are least sure of, and what happened to the result. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one | The persona's counter-strategy rehearsed; EXP; F2 |
| E3 | "You're asked whether a launch worked. What would you measure, over what window, and what would make you say it didn't?" | CASE | [generic] | Clarify the launch goal first, then pick a small set of measures, a window, a comparison point and a stated threshold for failure. Name the assumption in your measurement you would defend least | Covers F2 as a live problem asking about no past; CASE |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Hold-then-concede: state two reasons in your own words in under a minute. Under a challenge, hold the core reason through two follow-ups, then concede specifically what an internal candidate knows that you do not and how you would close it | Persona stem; JD; composure scored |
| F2 | "Pick a result and tell me how much of it was actually you." | EXP | [generic] | Selection scaffold: pick a result where you can separate your part from the team's. Say what was yours, what was not, and who else contributed. Hold through two follow-ups by returning to what you did; concede plainly where the line is blurry. If no such result comes to mind, say so plainly, then give the nearest thing your material does carry | Attribution honesty is exactly what the probe tests; EXP with Pressure delivery |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc from your own account: where you started, the two or three moves that mattered, and why this role is next. This pack has no CV, so it supplies no beats; draft the arc yourself and rehearse it aloud | Persona stem; EXP because every claim in it is checkable |
| G2 | "What are you working on or reading at the moment, outside your day job?" | JD | [generic] | Answer with something real and be ready for one follow-up. If nothing comes to mind, say so plainly and say what you would like to learn next | Casual register, still scored for genuine interest; JD at low weight |
| G3 | "Why Stripe?" | CO | [generic] | Say what you actually found in Stripe's own public materials, in your own words, and name the source. No research ran, so this pack states nothing about Stripe. If you have not looked closely, say so plainly and say what drew you to apply | Motivation and homework depth together; CO |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 launches and rollouts | A1, B1, D1, D3 |
| F2 metrics and diagnosis | A2, E1, E2, E3 |
| F3 processes and cadences | A3, A4, D1 |
| F4 feedback to priorities | A3, C2, B4 |
| F5 senior communication | B1, F1, G1 |
| F6 location and work authorization | none, and why: a gate the material does not settle, surfaced in the fit snapshot and not rehearsed |

## Reverse questions

| # | Question to ask | Why it lands | Provenance |
|---|---|---|---|
| R1 | "What would a successful first 90 days look like for this role, and how would you know?" | Shows you think in outcomes and gives you the interviewer's own success criteria to answer against | [generic] |
| R2 | "Where does product operations end and product management begin on this team today?" | Moves the seam question from a probe to a conversation and tells you where the real friction is | [generic] |
| R3 | "Which process or cadence do you wish worked better right now?" | Invites the interviewer to name a real problem you could discuss solving, without you presuming one | [generic] |
| R4 | "How is the impact of this team measured and reviewed?" | A candidate who asks about measurement signals they expect to be accountable for it | [generic] |
| R5 | "What is the hardest thing about this role that doesn't show up in the job description?" | Surfaces the gap between the posting and the job, and shows you are weighing the role honestly | [generic] |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question: shifts from what you need to what you give; strongest if the interviewer is a peer | [generic] |

None is tied to the interviewer's own path because no interviewer name or profile was given.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No candidate material was supplied, so no quoted sentence exists to widen and no negative was stated | Every claim about your past stays in your own words; each guidance cell is a selection scaffold ending in its honest branch, so nothing here asserts an experience you have not told me about |

## Sources

Provided documents: the user's message naming the company, the role and the round. No job description, CV, dossier or interviewer information was provided.

Searches sent, all refused (the host did not grant search permission), none returned a result:

- "Stripe operating principles values" — refused
- "Stripe interview process Product Operations Manager" — refused
- "Stripe strategy 2026 annual letter stablecoins agentic commerce" — refused
- "Stripe Product Operations Manager job description responsibilities qualifications" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Every call was refused. Would have moved: a values cheat sheet and the VAL bank, which now rests on persona stems alone |
| 2. Stripe interview process for this role family | unavailable | Every call was refused. Would have moved: loop structure and persona weights, which now rest on the generic archetype |
| 3. Stripe strategy and recent news | unavailable | Every call was refused. Would have moved: the CO questions A5 and G3, which stay generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Every call was refused. Would have moved: the fit snapshot requirements, which are generic prose and not quoted |

## Upgrade menu

- The job description text: the six generic requirement rows in the fit snapshot become quoted, grounded requirements, and the coverage table is checked against the JD's own list
- Your CV or a few lines on your background: the worksheet becomes a real fit snapshot with your sentences quoted, guidance becomes story-mapped where a sentence carries a story, and the prohibited list gets real entries
- Who your final-round interviewer is and how you relate to them (manager, peer, senior): persona weights become specific, and a name adds an interviewer read and a reverse question tied to their path
- The recruiter's guidance, if any (focus areas, a deliverable, the structure of the day): coverage stops being assumed from round-type priors, and any pre-declared deliverable gets its own build section; usually one email to the recruiter
- Your confirmation on the role's location and work-authorization terms: the gate row F6 is settled one way or the other
- Search permission: targets 1 to 3 and 5 run, which brings Stripe's published values, any documented loop, current strategy and a representative JD; a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is offered once, after that
- Your final-round schedule, if your final is several sessions: per-session mini-packs with their own weights
- A `tuesday-dossier.md` from an earlier evidence pass, if you have one: it would supply a verified-evidence base, the objection worth deepest rehearsal and a binding list of claims to avoid
