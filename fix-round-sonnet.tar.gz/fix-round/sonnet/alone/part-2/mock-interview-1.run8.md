I'll read the reference files before writing anything.
The prep pack is saved. It has 22 questions across seven interviewer personas, tagged by question type, each with answer guidance and a rationale. I built it for a single 60-minute conversation with Dan as a peer, as you described.

Web search was refused for all three attempts, so the company facts rest only on your research note and your description of Dan. I did not check any of them independently. The pack names a refused search as a gap rather than filling it in. The pack also quotes your descriptions of Priya, not her résumé text, and your JD highlights, not the full posting.

- **Most important rehearsal (C1):** "I don't see quota-setting or sales-ops in your background." Priya should say plainly "I have no classic sales-ops or quota-setting experience." Then she can name what her material does carry, without calling her volume targets quotas, and add a ramp plan. E2 is the same gap under a sixty-second clock.
- **Probes to expect from Dan:** His "relentlessly data-driven" profile makes the ~$400M ARR figure (B1, E1) and the SQL/Tableau claim (B3) the likeliest to be taken apart. His pricing background makes D2 a risk. The pack lets Priya reason about pricing but not claim experience in it.
- **Thin evidence:** The material does not show whitespace analysis across land/adopt/expand/renew, and it covers the partner-motion requirement only partly. Those slots are marked in the pack for Priya to answer from her own experience.
- **Left out on purpose:** a values cheat sheet, deliverable builds, a prep-triage schedule and a delivery-coaching section, because none had a trigger in what you gave me.

Next steps, all optional:
- Say the word and I'll play Dan on C1, the objection the pack names as the most important to rehearse.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed.
- I can convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer; both report to the same VP. **Round:** one 60-minute conversation with Dan (all as you described it).

## 1. How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and rehearse only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values: does past behavior show the trait, in a specific decision |
| EXP | Experience deep-dive: do the claims on your background survive scrutiny, and what was actually yours |
| JD | Role-driven: can you do the listed job, including where your background is thinner |
| CO | Company and strategy knowledge: can you think at Northwind's altitude |
| CASE | Live problem from the actual role: structure and reasoning, delivered aloud |

Provenance labels: `[grounded]` traces to what you gave me; `[inferred]` is a derivation, named; `[generic]` is a role-family pattern with no claim about this company or about Priya. Where guidance says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly the thing was not yours.

**The single highest-ROI prep in this pack is C1**, the "no quota-setting or sales-ops" objection. It is the one most likely to arrive in some form from a Sales Strategy peer, and it is aimed at exactly where the material is thinnest. Rehearse it until it is boring.

## 4. Fit snapshot

Evidence cells quote only the coach's notes and the JD highlights as given. Medium means confirmed and plausible, with nothing inspected behind it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes; "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material says a proposal and a credited uplift, not a go-to-market for product lines, and the words stay at that scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's two-product-lines line makes a probe on what happened after the proposal likely. If any step after the proposal was yours, say which and what you decided, in your own words; if the proposal was where your part ended, or there was no such step, say so plainly and stay with the proposal. The ~$400M raises its own slots, covered in B1 |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | Nothing in the material speaks to analysis across those four stages. Answer slot: expect a probe on whether any of your analysis looked across stages of a customer or partner relationship. If some did, say which stage and what you found, in your own words; if none did, say so plainly and say how you would start |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The quote already names both tools in the JD's terms, but it is a skills line with nothing inspected behind it, and a data-driven peer will test it live. Lead with it in its own terms: "I'm skilled in SQL and Tableau." Rehearse one analysis end to end (B3) rather than adding adjectives |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The quote carries a model built and used in negotiations, not a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: expect the probe on what part of the partner relationship was yours to shape. If any decision about how the partner relationship was run was yours, say which and how you decided; if there was no such step, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Reword only it: "I set annual volume targets with cross-org consensus." Nothing is added about how consensus was reached; where Dan asks, A2's slot applies |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | The quote reaches the plus as a user of AI tools, and the words stay there: "I use AI tools daily." Answer slot: if asked what for, say what you use them for and where they fell short, in your own words; if your use is narrower than Dan expects, say so plainly |
| F7 | Sales-operations and quota-setting fluency, as a role-family expectation for a Sales Strategy peer seat (no JD line; raised by the coach's own note) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it was stated. Words: "I have no classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller, and F5's volume targets are not offered as a stand-in |

## 7. Reading the interviewer

Public professional signals only, as you supplied them. Nothing here was independently checked (see Sources).

| Signal | Source | Practical implication | Provenance |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | Dan's profile, via your message | Expect every number you give to be taken two levels down. Know what you can and cannot say about how each figure was counted, and say plainly when you do not know | [inferred] |
| Career spine in pricing and monetization roles | Dan's profile, via your message | Economics questions will arrive in his native language: packaging, unit economics, how a product earns. Reason aloud and invite his correction; do not claim pricing experience (see section 13) | [inferred] |
| One early-stage-startup chapter | Dan's profile, via your message | Builder stories may land with him, and a probe on pace and scrappiness in a large-company background is plausible. C4 rehearses it | [inferred] |
| Peer, same VP | Your message | The hire changes his load as well as the VP's. Reciprocity framing (what you bring his team) belongs in A4 and in the reverse questions | [inferred] |

**Mirror opportunity.** F4's quote, used exactly and at its own scope, is the one line near his monetization vocabulary. Do not describe it as pricing. No shared career jump is offered: his startup chapter has no counterpart in the candidate's quoted material, and shared identity or background is never a strategy.

## 8. Persona table

Weights start from the relationship prior (peer: Peer Evaluator plus Data-Driven Prober), then move on the signals above. The loop is the one you described: a single conversation with Dan, no values round named, so no fallback archetype is applied.

| Persona | Qs | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| A. Peer Evaluator | 5 | Seam-splitting between Emerging Products GTM and Sales Strategy; "what would you need from me"; credit across teams | High. Peer prior, and the JD's cross-functional influence line (F5) is the requirement a peer can score directly | Offer seam principles rather than pretending to know the seam; lead with what you bring his team; credit stories told at the scope of the quotes in F1 and F5 |
| B. Data-Driven Prober | 4 | Line-by-line probe of the $400M figure, the revenue model, the SQL and Tableau claim | High. Peer prior plus his self-description (section 7) | Know how the ~$400M was counted, or say plainly you do not; name the assumption you would defend least before he does; offer to walk one analysis end to end |
| C. Skeptic | 4 | The quota and sales-ops gap, the partner-motion requirement, why leave nine years in one place, how you work with no playbook | High. F7 is a stated gap and F4 is a required line the quote only partly reaches; the startup signal adds a scrappiness probe | Rehearse C1 until it is boring; plain acknowledgment of F7 and then a ramp plan; hold the quotes' scope on F4 |
| D. Case / Strategist | 3 | Live problems on Compass, the new product lines, bundling, whitespace | Medium. Not dominant for a peer, but his pricing spine tilts cases toward packaging and economics, and the JD is GTM strategy | Clarify, objective, segmentation, approach, metrics, risks; say the framework aloud; challenge one premise per case |
| E. Pressure | 2 | "How much of that was actually you"; sixty-second why-you | Low to medium. Peers are not the usual source, but a data-driven peer can press collegially on attribution | Pause, restate, hold the quoted claim through two follow-ups, concede one specific limit |
| F. Conversational | 2 | Opening "walk me through the journey"; a casual AI question | Medium. Every conversation opens this way, and the JD names AI as a plus | A 90-second arc built only from the quoted beats; treat the casual AI question as scored |
| G. Values / Behavioral | 2 | Unpopular truth, customer versus metric | Low. No values round is named in your description of the session, and no published values were in hand | Selection scaffolds ending in the honest branch; no invented story |

## 9. Question banks

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 own GTM strategy for two new product lines | D1, D2, C4, A5 |
| F2 whitespace across land/adopt/expand/renew | D3, B4 |
| F3 independent analysis in SQL and Tableau | B3, B2, D3 |
| F4 partner-motion design experience | C2, B2 |
| F5 cross-functional influence | A1, A2, A4 |
| F6 AI experience a plus | F2 |
| F7 sales-ops and quota-setting gap (not a JD line) | C1, E2 |
| Headline metric, the ~$400M figure | B1, E1 |

### A. Peer Evaluator (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between Emerging Products GTM and Sales Strategy, and what happens when we disagree?" | JD | [generic] | Offer principles, not a map you cannot know yet: who owns the decision on what, shared definitions for the numbers you both report, and an agreed place to take a disagreement. Say what you would want to learn from him first. For disagreement, say you would bring the data and the decision rule before the meeting. The question needs no claim about your past, so the guidance makes none | F5 is the requirement a peer scores directly. JD because it tests the stated influence line; the peer stem is the persona's signature question |
| A2 | "You set annual volume targets with cross-org consensus. Walk me through how you got the orgs to agree." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Tell the beats the quote states: annual volume targets, set, with consensus across orgs. Answer slot: the JD's cross-functional line makes a probe on where the orgs differed likely. If they differed, say where and what part of resolving it was yours, in your own words; if there was no disagreement, or the consensus was reached before you, say so plainly and stay with the targets | F5 is the evidence for the influence requirement and the likeliest place a peer probes. EXP because it tests what was actually yours |
| A3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what you proposed, and that the uplift was credited to the change, at those words. Answer slot: if others carried the change forward, name who and what they did; if no one did, or you do not know how the credit was assigned, say so plainly. The principle to state is naming other people's parts specifically | F1 holds the one quote that makes credit a live question for this candidate. VAL because the stem scores how you treat peers, an open prompt from the persona list |
| A4 | "What would you need from me and Sales Strategy in your first 90 days?" | JD | [grounded] "skilled in SQL/Tableau" | Ask for what a new owner of two product lines needs: how Sales Strategy defines the lifecycle stages, which data is trusted, where Sales Strategy wants a say. Then reciprocity, at the quote's scope: you are skilled in SQL and Tableau and can run analysis yourself, so the ask is data access and definitions rather than analyst time | F3 gives the one capability that reduces his load. JD because it scores whether the hire adds to or subtracts from a peer's workload |
| A5 | "Enterprise expansion and the Compass launch are both priorities. Where do they collide in a sales motion?" | CO | [grounded] | Company facts come from your research note, not independently checked: enterprise expansion, Compass, profitability. State hypotheses and label them: for example whether Compass leads with existing enterprise accounts or opens new ones. Ask Dan how Sales Strategy sees it today. No claim about your past | CO grounded in the stated priorities. Tagged CO rather than CASE because it tests company fluency and asks no structured build |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The ~$400M ARR uplift on your background. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the sentence says: you proposed the change, and the uplift was credited to it. Hold at "proposed" and "credited with"; do not say drove, delivered or owned. Four slots, each in your own words: how the ~$400M was counted; what it is most sensitive to; the assumption you would defend least, named before he does; which part was yours. If you do not know how it was counted, say so plainly rather than reconstruct it | F1 carries the only headline metric, and a data-driven peer will take it apart. EXP because it tests attribution and the weakest-assumption move |
| B2 | "Walk me through the partner-level revenue model. What was it built to answer, and how much of it was yours?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats from the quote: you built it, it was partner-level, it was used in carrier negotiations. Answer slot: the JD asks for independent analysis, so expect a probe on the model's mechanics. If you wrote the queries or built the views yourself, say which; if others supplied data or built parts, say so plainly and stay with what you built. If you do not know how an input was derived, say so | F4 and F3 meet here. EXP because the probe is on authorship and mechanics |
| B3 | "Pick one analysis you ran yourself end to end in SQL or Tableau. What was the question, and what did the data say?" | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold, since the quote names the skill and no story: pick one where you wrote the query or built the view yourself; state the question, the finding, and the assumption you would defend least. If no analysis comes to mind that was entirely yours, say so plainly, then give the nearest one and say which parts were someone else's | F3 is a skills line with nothing inspected, so the probe arrives as a live request. JD because it scores the stated tools; an open prompt, so no event is presupposed |
| B4 | "Which metrics would tell you a new product line is landing, adopting, expanding and renewing?" | JD | [generic] | One metric per stage, and for each what it is sensitive to and which would mislead you early. Ask what data exists today before committing. State the weakest assumption in your own list. No claim about your past | F2's requirement, asked as a build rather than a record. JD because the stage names come from the JD highlights; the answer pattern is generic |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see quota-setting or sales-ops in your background. How would you handle that in a role that sits right beside Sales Strategy?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | **Deepest rehearsal in the pack.** Level 1, plain acknowledgment, then stop: "I have no classic sales-ops or quota-setting experience." Level 2, the nearest quoted ground at its own scope: "I set annual volume targets with cross-org consensus." Do not call these quotas. If he asks how the two differ, say what you can from your own work, or that you do not know yet. Level 3, a plan and never a past: what you would ask him to walk you through first, and where you would want his read on how much of the job this is. Concede the gap by name; do not fold the quoted ground | F7 is the stated gap and the most predictable objection. JD because it scores a gap against the seat; Skeptic delivery because he is the owner of adjacent turf |
| C2 | "Partner-motion design is required here. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any decision about how the partner relationship was run was yours, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the model. Hold through two follow-ups by returning to the model, never by adding to it | F4 is where the JD's required line presses hardest. JD because it scores the stated requirement; the question's premise is the JD's, and the guidance does not adopt it |
| C3 | "Eleven years, nine of them at one company. Why leave now, and why a B2B data-infrastructure company?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Motivation is yours to state and the pack cannot supply it. Selection scaffold: give the one reason that is true, in a sentence; connect it to the JD's two-new-product-lines line only if that is actually part of why. If you have no single reason, say so plainly rather than manufacture one. Keep to the quoted tenure and function | The tenure and the sector change are the motivation probe's anchor, F1. EXP because it tests whether your story survives cross-examination; Skeptic stem is "why leave, why here, why now" |
| C4 | "Two new product lines means there's no history to model from. How do you work when the playbook doesn't exist yet?" | JD | [generic] | Selection scaffold, since no quoted sentence carries it: pick a time you worked without a playbook; it needs a named decision, what evidence you used, and what you would change. If no such time comes to mind, say so plainly, then describe how you would start: clarify the objective, state hypotheses, test the cheapest one first | F1's requirement meets the startup signal in section 7, which is `[inferred]`. JD because the premise comes from the JD's new-product-lines line; no quote supports a story, so none is supplied |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sketch the go-to-market plan for Compass. What do you need to know first?" | CASE | [grounded] | Compass and the stated priorities come from your research note, not independently checked. Clarify first: who buys, which accounts first, how it is priced. Then objective, segmentation, approach, metrics, risks, with a hypothesis stated early. Challenge one premise respectfully. No claim about your past | F1's requirement, delivered live on the actual roadmap. CASE because it scores structure over the right answer |
| D2 | "A much larger platform vendor is bundling something competitive. How do you position and package against it?" | CO | [grounded] | The threat comes from your research note. Structure: what the bundle includes and what it does not, the standalone value metric, attach versus standalone, and the profitability constraint. Say you are reasoning, not reporting experience, and invite his correction since pricing is his native ground. No claim about your past | F1's requirement meets the stated competitive threat and his pricing spine, which is `[inferred]`. CO because it tests current strategy fluency; CASE delivery |
| D3 | "You have one customer base and four stages: land, adopt, expand, renew. How would you find the biggest whitespace for a new product line?" | CASE | [grounded] "skilled in SQL/Tableau" | Clarify the product and segments, then a hypothesis per stage, then the cuts you would run and in which tool: you are skilled in SQL and Tableau, so you can say you would run them yourself. Prioritize by size and effort, name the data you would doubt, and the risk. State no past analysis; F2's slot belongs to this question's follow-up | F2 is the only requirement with no evidence, so it is best rehearsed as a live build. CASE because the stage language is the JD's own |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate. Hold: "I proposed the change." Concede exactly the limit the quote carries: the uplift was credited to the change, and you will not claim more than that. Hold through two follow-ups; do not fold the proposal. Slot: if you know who credited it and how, say so; if not, say so plainly | B1's figure under pressure; F1 is the source. EXP because it is the attribution probe; Pressure delivery tests whether you shrink the claim gracefully |
| E2 | "Sixty seconds: why you over a candidate who has carried a quota and run sales ops?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | One sentence of plain acknowledgment, then only quoted ground: "I built a partner-level revenue model used in carrier negotiations", "I set annual volume targets with cross-org consensus", "I'm skilled in SQL and Tableau". Do not claim to be better; ask what share of the job the quota side is and let him weigh it | F7 under a clock. JD because it scores the gap against the seat; Pressure because of the time box |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the beats the quotes state: two years in strategy consulting at a top firm, then nine years in product strategy and operations at a large consumer-tech company. The reason for each move is yours to state; if there was no single reason, say so plainly. End on what draws you to this role, in your own words | F1 and F7 carry the biography beats. EXP because it is a CV walk; Conversational because it is the casual opener that is still scored |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say you use AI tools daily, then slot: which tools, for what task, and where one fell short, in your own words; if your use is narrower than he may expect, say so plainly. Do not claim building models or AI products. You may turn it to Compass only as a question to him | F6 is the JD's plus, asked casually. JD because it scores a listed plus; Conversational stem |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem; no quote carries a story, so none is supplied. VAL because it scores behavior, not company knowledge |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: the metric, the customer interest, what you decided, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem; relevant to a loop that, per your note, includes a profitability priority. VAL because it scores a tradeoff |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've worked in pricing and monetization and had a startup chapter. What did you carry from one into the other that you still use on Sales Strategy?" | Tied to his own path. It turns a probe into a peer conversation and shows the research was on him |
| R2 | "What's one thing a new person on my side could do in the first month that would genuinely help your team?" | The reciprocity question for a peer; it shows you price the hire by his load, not only your own |
| R3 | "Where do you want Emerging Products to own the call and where Sales Strategy? How have disagreements gone so far?" | Tests the seam from his side and invites a story rather than a policy |
| R4 | "A year in, what's the one number you'd use to judge whether Compass's go-to-market is working, and how much do you trust that data today?" | Speaks to a data-driven peer's vocabulary and to the data quality he lives with |
| R5 | "Is bundling by the larger platform vendor showing up in deals you see?" | A question only a Sales Strategy peer can answer first-hand; it tests your research note against his view |
| R6 | "With profitability a stated priority, how does that change how the new lines are funded and measured against growth?" | Connects the three stated priorities to the role's real constraints |

## 13. Prohibited claims

Built from the fit snapshot before the banks were written. None of these appears in any guidance cell as something to say.

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a quota or run sales ops | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I have no classic sales-ops or quota-setting experience." No slot |
| Treats annual volume targets as quotas | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says volume targets set with consensus, not quotas |
| Owned or led go-to-market for product lines | Inflated form of F1 | F1's quote at its own scope. The material says a proposal and a credited uplift, not a go-to-market |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F1 | "Proposed" and "credited with", as quoted. B1 and E1's slots cover only how it was counted and what was yours |
| Designed the partner motion | Inflated form of F4 | F4's quote at its own scope. The material says a model built and used in negotiations |
| Has pricing or packaging experience | Inflated form of F4 | F4's quote at its own scope; D2 is reasoning, offered as such, not a record |
| Built or shipped AI products, or Compass-type experience | Inflated form of F6 | F6's quote: "uses AI tools daily", nothing wider |

## 14. Sources

**Provided:** your message (role and company, JD highlights as summarized, a summary of Priya's background, a summary of Dan's profile, your research note on Northwind's three stated priorities and the bundling threat). Candidate quotes are your words about her, not her résumé text; the JD lines are your highlights, not the full posting.

**Searches sent (all refused, none returned results):**

1. "Northwind Data company values principles B2B data infrastructure" — refused
2. "Northwind Data interview process GTM strategy emerging products" — refused
3. "Dan Kovac Director of Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The call was refused. Would have moved published value names into VAL questions; G1 and G2 use persona stems instead |
| 2. Northwind Data interview process, strategy GTM role family | unavailable | The call was refused. Would have documented the loop; persona weights rest on your description of one conversation with a peer |
| 3. Northwind Data strategy and recent news | skipped | Your research note already supplies the priorities and threat that A5, D1 and D2 use; it was not independently checked |
| 4. Dan Kovac, Northwind Data | unavailable | The call was refused. Would have added his public talks and writing; the interviewer read uses only the profile summary you gave |
| 5. Representative Senior GTM Strategy Lead JD | skipped | Your JD highlights fix the fit snapshot and the JD-tagged questions |

No dossier was supplied. The values cheat sheet, graded-deliverables, grounding-brief, prep-triage and delivery-coaching sections are omitted: no values-style round is documented in what you described, nothing was declared as a deliverable, no strategy brief beyond your note was in hand, prep time was not given, and no assessment was offered.

## 15. Upgrade menu

- The full JD text → F1 to F6's requirement quotes become the posting's own words, and any mid-list requirement the highlights omitted gets a question
- Priya's résumé text → the evidence cells quote her own sentences instead of your summary, and the confidence bands can move
- A readout or document behind the ~$400M figure, and the revenue model or its deck → F1 and F4 can move from medium toward high, and B1 and B2's slots get concrete
- Your answers to the slots on F1, F2, F4 and F6, outside a drill → those rows regenerate from her own words
- Northwind's published values and interview process, or the recruiter's description of the loop → a values cheat sheet if a values round is documented, and persona weights from a documented loop
- Dan's public talks and writing → a tailored reverse question and persona weights from his own themes
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, needs search permission → a grounding brief on Northwind's strategy and competitive set, and a sharper D2
- How much prep time you have → a prioritized schedule
- A tuesday-dossier.md from an earlier session → verified evidence and any prior prohibited claims would be carried in, never required
