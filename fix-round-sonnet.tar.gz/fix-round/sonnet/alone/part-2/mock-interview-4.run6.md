I'll start with the reference files the skill points to.
I've read most of the skill's reference files. Two sections of the interaction grammar are left, the research tiers and trigger hygiene, and then I'll build the pack.
Search wasn't permitted, so I'm building from your dossier alone. I'll write the pack and mark the research targets as unavailable in the Sources section.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-4-denied-466acb01/Quartzline_product-manager-platform-apis_interview_pack.md`.

I built it from your dossier and the hiring-manager round, which put the Skeptic and Case personas first. The web searches on Quartzline's values, loop and strategy were refused, so the pack has no company-specific research and no CO questions. The Sources section lists each refused search and what it would have fed.

The most important part is A1, the objection your dossier named, which gets the deepest rehearsal:
- **Concede:** the pack gives you the plain acknowledgments your dossier's prohibited claims support, covering the PM title, the roadmap and squad prioritization.
- **Bridge:** it keeps to your three confirmed evidence lines at their own scope. The roadmap-input sessions are medium confidence, so expect a probe on them.
- **Follow-ups:** it rehearses three, ending in your reverse question on decision authority.

Say the word and I'll play the Skeptic on A1 as a live drill. I can also save a tuesday-dossier.md with this prep's `pack_feedback` for you to carry forward. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: 45-minute conversation with the hiring manager, Thursday. Interviewer name: not given. Built on your tuesday-dossier.md (conditional_go).

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values: does past behavior show what the company says it values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually you |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge. No CO question appears in this pack: the research that would feed one was unavailable (see Sources) |
| CASE | A live problem from the actual role, scored on structure and reasoning |

The single highest-ROI rehearsal is A1, the objection your dossier named. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [grounded] | transferability | The dossier's condition: position this as adjacent work, never as product management experience. Words at the quote's own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The limit is the pack's observation: your material shows integration leadership, not a product role. Plain acknowledgment, sourced from dossier prohibited_claims: "I haven't held a product manager title or role." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier responsibilities (R1 sub-claim: owning a roadmap and prioritization authority) | none given | none | [grounded] | capability | The dossier records this as a gap with no credible evidence and the strategy acknowledge_gap, so there is no bridge and no answer slot. Words, sourced from dossier acknowledge_gap and prohibited_claims: "I haven't owned a product roadmap." Then how you would learn it, said as a plan and never as a past |
| F3 | "Run discovery with integration partners" — dossier responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | Confirmed, limited inspectable proof, so expect a probe and volunteer the limit before it is extracted. Words at the quote's scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Your material says clients and product, not integration partners or discovery, so the words stay at the sessions. Answer slot: the JD's discovery line makes a probe on what came out of the sessions likely. If any decision or priority changed because of what you fed in, say what and which part was yours; if nothing did, or you could not see what happened next, say so plainly and stay with the sessions |
| F4 | "Shipped API or platform products" — dossier R2 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | transferability | Both quotes are inspectable and both stay at their own scope: the integrations, and the playbook. The pack's observation: your material shows work on the vendor's APIs and the playbook, which is adjacent to the requirement and does not reach it. Answer slot: expect a probe on where your integrations work stops and the platform begins. Say where your part ended in your own words, and if you cannot place the line, say so plainly and return to the integrations |
| F5 | "Technical fluency: API docs, schemas" — dossier R3 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote shows REST APIs and an architecture stage and does not show whether API docs or schemas were part of it. Answer slot: the JD names docs and schemas, so expect a probe. If you read, wrote or reviewed either, say which and how, in your own words; if you did not work with them, say so plainly and stay with the architecture stage in your sentence |
| F6 | "Stakeholder management across engineering, sales, customers" — dossier R4 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes name clients and product and do not say whether engineering or sales were involved. Answer slot: the JD lists three groups, so expect a probe on the ones the quotes do not name. If you worked with engineering or sales on any of this, say who and what for; if you did not, say so plainly and stay with the clients and product |
| F7 | "Agile delivery experience" — dossier R5 (preferred) | none given | low | [grounded] | discovery | The dossier's strategy is clarify. No quote speaks to this requirement, so none is stretched to fit it. Answer slot: the JD's agile delivery line makes this probe likely. If you worked inside sprints, planning or reviews, say which and what your part was; if your work ran another way, or you never worked that way, say so plainly and say what you would want to confirm about how this team defines it |
| F8 | "Define and track adoption metrics" — dossier responsibilities | none given | none | [grounded] | discovery | Your material is silent on this, which is not the same as an absence. Answer slot: if you defined or tracked anything that showed how clients used an integration, say what was counted and how; if nothing was tracked, or it was not yours, say so plainly and say what you would measure first |
| F9 | "Write specs and drive delivery with two engineering squads" — dossier responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote names requirements and go-live stages and does not say whether you wrote specs or worked with engineering squads. Answer slot: if you wrote any requirements document that engineers worked from, say what it was and your part; if you did not, say so plainly and stay with the stages in your sentence |

Requirement coverage, mapped to question IDs:

| Requirement | Covered by |
|---|---|
| R1 3+ years product management experience | A1, A2, A4, D1, F1 |
| R1 sub-claim: owning a roadmap, prioritization authority | A1, A2, B2 |
| R2 Shipped API or platform products | C1, C2, F2 |
| R3 Technical fluency: API docs, schemas | D3, C2 |
| R4 Stakeholder management | A5, B4, B5, E1 |
| R5 Agile delivery experience | A3 |
| Run discovery with integration partners | A5 |
| Write specs and drive delivery with two engineering squads | B1, E1 |
| Define and track adoption metrics | B3, C3 |
| Own the roadmap for the partner-facing API platform | A1, A2, B2 |

## Persona table

The loop rests on your own words: one 45-minute conversation with the hiring manager. No loop source describes anything more, so weights come from the hiring-manager relationship prior plus your dossier.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the title and roadmap gap, why now, weakest area | Highest. The hiring-manager prior is Case plus Skeptic, and your dossier names a specific objection and two weak areas | Rehearse A1 until it is boring: concede plainly, bridge at the quotes' scope, state the limit before it is asked for |
| Case / Strategist (B) | Live problems from the partner API roadmap and the two squads | High. The hiring-manager prior, and the JD's responsibilities are roadmap, specs and metrics work | Clarify, objective, options, criteria, who decides, metrics, risks; think aloud and say what you would need to know |
| Data-Driven Prober (C) | Defend-the-number on 30+, the playbook, post-go-live tracking | Medium. 30+ is the one headline figure in your evidence | Say how it was counted and what you do not know; offer to walk through the playbook end to end |
| Conversational (D) | The opening journey question and casual probes on APIs | Medium. Your note names a conversation, and casual questions inside one are still scored | A 90-second arc built from your three quotes |
| Peer Evaluator (E) | Seam between the PM and the two squad leads | Medium-low. Your note names only the hiring manager, but decision authority is the open question in your dossier | Propose seam principles and ask how it works today rather than pretending to know |
| Pressure (F) | Time-boxed why-you and how-much-was-you | Low-medium. The title gap invites a short sharp version of A1 | Pause, restate, hold two follow-ups, then concede specifically |
| Values / Behavioral (G) | One or two behavioral prompts | Low. No values-style round is detected: no loop source documents one and no values page was read | Selection scaffolds; if nothing comes to mind, say so |

## Question banks

### A. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The highest-ROI prep in this pack, and your dossier named it. Deepest rehearsal means concede first, then bridge, then hold through three follow-ups. Concede, sourced from dossier prohibited_claims: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Bridge at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live. I wrote the internal integration playbook my team uses. I ran quarterly roadmap-input sessions feeding client evidence to product." Name the limit as the dossier frames it: this is adjacent work, not product management. The sessions are the medium-confidence item, so expect a probe: say what you can show from them; if nothing, say so plainly. Follow-up 1, "so why not hire the PM": return to the quotes, add nothing. Follow-up 2, "show me you can prioritize between two squads": the sourced words are "I haven't set prioritization for an engineering squad" (dossier prohibited_claims); then say, as a plan, how you would learn it, such as asking which decisions are the squad leads' and which are yours. Follow-up 3, "what would you need to be true for this to work": say it as a plan and ask reverse question 1 | F1 and F2 are where this lands. JD because it scores the title requirement; the wording is your dossier's, kept because each negative in it has a sourced basis in prohibited_claims |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] dossier acknowledge_gap for owning a roadmap and prioritization authority | Name the weakest part your material already shows and do not reach for a milder one. Sourced words: "I haven't owned a product roadmap." Then a plan, never a past: what you would ask the two squad leads in the first weeks and what you would read. Do not offer a bridge for this area; the dossier found nothing to bridge with | F2 is the dossier's no-evidence area, so candor is the strategy it allows. JD because it scores a stated responsibility |
| A3 | "Tell me about a time you worked within an agile delivery process." | EXP | [grounded] the JD's agile delivery line, dossier R5 | An open prompt with no quoted sentence behind it, so this is the clarify case. Answer slot: if you worked inside sprints, planning or reviews, say which and what your part was, in your own words; if your work ran another way, or you never worked that way, say so plainly. Then say what you would want to confirm about how this team defines agile delivery, which turns the gap into a question | F7 is a discovery gap and the dossier's strategy is clarify. EXP because it tests whether a real instance exists |
| A4 | "Why move from integration leadership into product, and why now?" | JD | [generic] | No quoted sentence carries your reason, so the reason is yours to give. Answer slot: say your own reason in your own words; if there is no single reason, say so plainly. Then one beat from your quotes, "I led 30+ end-to-end client integrations of the vendor's REST APIs", and then what you want to learn here. Keep it consistent with your answer to D2 | F1 is the title gap, and motivation consistency is what a skeptic checks next. JD because it scores fit for the role, [generic] because it is a pattern of the question |
| A5 | "Tell me about a time evidence from clients changed what product did." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on the sentence: the quarterly sessions, the client evidence, product as the recipient. Tell those beats in your own words. Medium confidence, so volunteer the limit before it is extracted. Answer slot: the JD's discovery line makes "what changed" the likely probe. If a decision or priority changed because of what you fed in, say what and which part was yours; if nothing did, or you could not see what happened next, say so plainly and stay with the sessions | F3 is the medium-confidence item with limited inspectable proof. EXP because it tests what was actually yours |

### B. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says an API behavior is blocking their go-live, and the two squads disagree about whether to fix it now or ship what is planned. What do you do, and what goes in the spec?" | CASE | [generic] | No claim about your past is needed. Structure: clarify first (how many partners, what blocking means, what the planned work serves); objective; two or three options with a trade-off each; the decision and who makes it, saying aloud that you would want to know which decisions are yours and which are the squad leads'; the spec's first lines; the metric that tells you it worked; the risk | JD responsibilities F9 and F2 set the scene: delivery with two squads and an open decision-rights question. CASE because it asks for live reasoning |
| B2 | "How would you decide what the partner API platform should build next?" | CASE | [generic] | State the criteria before the list, then name the inputs you would want (partner evidence, adoption data, squad capacity) and what you would need to find out about each. Say what you would not decide alone. If asked how you have done this, that is A2's territory: the sourced words are "I haven't owned a product roadmap" | F2 is the roadmap requirement and the gap, so the live version is better rehearsed than avoided. CASE because it asks for a method |
| B3 | "Partner API adoption has been flat for two quarters. Diagnose it." | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | First clarify how adoption is defined and measured here, since your dossier lists that as unknown. Then a funnel: the stages in your own sentence, scoping, requirements, architecture, UAT, go-live, are a ready structure to find where partners stall. Segment, form hypotheses, say what data would test each. Use the stages as a frame only and do not claim you measured any of them | F8 is silent on metrics, so the case rehearses the reasoning without a claim. CASE because it is a diagnosis |
| B4 | "We want to retire an API version a few large partners still use. Plan it." | CASE | [generic] | Clarify what retiring means and who depends on it; objective; stakeholder map across engineering, sales and customers; sequence (notice, migration help, date, exceptions); the risk to the largest partners; how you would know it worked | F6 lists three stakeholder groups, and this case touches all three. CASE because it is a live plan |
| B5 | "Sales has promised a partner a custom endpoint to close a deal. What do you do?" | CASE | [generic] | Ask what was promised and by when before anything else. Separate the customer need from the requested endpoint; check what the squads can absorb; offer sales an alternative they can say yes to; decide and communicate. Say plainly where the decision would belong to someone else, which ties to reverse question 1 | F6 again, from the sales side. CASE because it is a conflict with a live decision |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. How was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Keep the 30+ attached to client integrations of the vendor's REST APIs and to nothing wider. Answer slot, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how a figure was counted, say so plainly and say what you do know | F4 uses this figure. EXP because quantified claims are what probers read first |
| C2 | "Tell me about the integration playbook: what is in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Inspectable evidence, so this is your strongest ground. Say that you wrote it and that your team uses it; say what it covers only as you know it. Answer slot: if you can say what changed in how integrations were run once it existed, say it; if you cannot, say so plainly and stay with having written it. Offer to walk through it end to end, after checking you are free to show it | F4 and F5 draw on it. EXP because a document is the one artifact a prober can ask to see |
| C3 | "How did you know an integration had gone well?" | JD | [grounded] the JD's adoption metrics line, dossier responsibilities | Answer slot: if you tracked anything after go-live, say what was counted and how; if nothing was tracked, or it was not yours, say so plainly, and then say what you would measure first for a partner API | F8 is silent, so the honest branch must be ready before the probe arrives. JD because it scores the adoption-metrics responsibility |

### D. Conversational / Rapport Builder (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in four beats: the integrations you led; the playbook you wrote; the sessions that fed client evidence to product; then why this role, in your own words. Say the sessions as input to product, not as ownership of anything | F1, F3 and F4 are the evidence. EXP because it sets the story every later probe reads against |
| D2 | "What draws you to partner-facing APIs specifically?" | JD | [generic] | The reason is yours. Answer slot: say it in your own words; if the honest answer is that the role drew you rather than the area, say so plainly. Pair it with one beat from your quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs" | A4's twin in a friendlier register, and the two answers must agree. JD because it scores interest in the role's domain |
| D3 | "What are you actually playing with in API tooling or docs these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Pick something real you use or read now and name it. If nothing comes to mind, say so plainly, then give the nearest thing your material carries, the playbook you wrote, or say how you would get up to speed on this team's docs and schemas | F5 is the technical-fluency requirement, asked casually and still scored. JD because the JD names API docs and schemas |

### E. Peer Evaluator (weight: medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "If you were the PM and I led one of the squads, where is the seam between us, and what happens when we disagree?" | CASE | [generic] | Propose principles rather than claiming to know the seam: who decides what is built and who decides how, how disagreements escalate, what each side needs from the other. Then ask how it works today. This is reverse question 1 asked live. Do not describe yourself as having prioritized for a squad | F2 and F9: decision authority is the dossier's open risk. CASE because it is a live collaboration problem |
| E2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Wrote the internal integration playbook her team uses" | Use we for context and I for contribution. Beat available from your quote: you wrote the playbook, and your team uses it. Answer slot: if you have a time when credit was shared across teams, say what happened and your part; if none comes to mind, say so plainly and say how you would handle it | F4's playbook is the one cross-person artifact in your evidence. VAL because it scores collaboration behavior |

### F. Pressure (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM who has done this for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, restate. Concede in one clause, sourced from dossier prohibited_claims: "I haven't held a product manager title or role." One beat: "I led 30+ end-to-end client integrations of the vendor's REST APIs." One plan clause. Hold through two follow-ups by returning to the quote, not by adding to it | F1 in its short form; A1 is the long one. JD because it scores the title requirement |
| F2 | "That integration work: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Anchor in the verb you stated: led. Answer slot: which stages were yours and which belonged to others, in your own words; if you cannot split it, say so plainly. Hold through two follow-ups, then concede specifically where a part was not yours. Never fold on the core claim to restore harmony | F4 uses the same sentence. EXP because it tests attribution under pressure |

### G. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or say how you would handle it | No values-style round is detected, so this is touched, not weighted. VAL because it scores behavior |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | A selection scaffold. If one time comes to mind, give the stake, what you chose and what it cost. If none does, say so plainly, then give the nearest thing your material carries: the sessions carried client evidence to product, and nothing in that sentence says more than that | F3 is the nearest sentence. VAL because it scores a customer-first choice |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Your dossier's risk: decision authority is asserted in the JD and not evidenced. It reads as diligence and answers what you need to know before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second risk: adoption metrics are a named responsibility with no stated baseline. It also tells you what C3 and B3 will be measured against |
| 3 | "How do the two squads run delivery today, and what would you want the PM's part in it to be?" | Settles the agile question from F7 by asking how this team defines it, which is the clarify move in question form |
| 4 | "What would you need to see from someone without the PM title to be comfortable by the end of the first quarter?" | Puts the title objection on the table on your terms and lets you answer it live. Listen for what they name, because it is their scoring sheet |
| 5 | "Which partner integration problems come back most often, and who hears about them first?" | Invites the hiring manager to describe discovery as it works here, which tells you whether your sessions evidence (F3) maps onto it |
| 6 | "What would the best first 30 days for this hire look like to you?" | A preparation signal, and the answer gives you the ramp plan A1 and A2 ask you to state |

## Prohibited claims

Taken from your dossier's `prohibited_claims`; each binds every cell above.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | The plain acknowledgment: "I haven't held a product manager title or role." The F1 quote at its own scope, as adjacent work |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap | The plain acknowledgment: "I haven't owned a product roadmap." The pack's observation: your material says input sessions that fed client evidence to product. No bridge, no slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | The plain acknowledgment: "I haven't set prioritization for an engineering squad." Said as a plan to learn, never as a past |
| Shipped API or platform products | Inflated form of F4 | F4's two quotes at their own scope. The pack's observation: your material shows work on the vendor's APIs and the playbook, which sits next to that requirement |

## Sources

Provided documents: tuesday-dossier.md, dossier version 1.1. It supplied role_profile (the JD lines and unknowns), handoff_to_mock_interview (verified evidence, weak areas and their strategies, the likely objection, risks, employer questions, prohibited claims). It carried no evidence_map. Your own words about the round (a 45-minute hiring-manager conversation on Thursday) set the loop.

Searches sent, all refused, none returned anything:
- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline API platform strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions mapped to named values; the pack carries two generic VAL questions instead |
| 2. Quartzline interview process | unavailable | Every call was refused. It would have fixed the loop and persona weights from a documented source; they rest on the hiring-manager prior and your own words |
| 3. Quartzline strategy and recent news | unavailable | Every call was refused. It would have fed CO and strategy-grounded CASE questions; none appear |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; no interviewer read appears |
| 5. Representative Product Manager, Platform APIs JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Allow web search → Quartzline's published values, its documented loop and recent strategy become researched facts, and a CO question and values cheat sheet become possible if a values round is documented
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes), offered once → a strategy brief for sharper CASE and CO questions
- The interviewer's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- The recruiter's prep email (focus areas, any pre-declared deliverable) → coverage tuned to what they name, and a build section for any deliverable
- Hours available before Thursday → a prep triage in priority order
- The full JD text → the five requirements and four responsibilities now taken from the dossier's role_profile become the posting's own lines
- Your answers to the slots in F3 to F9 → each row becomes story-mapped instead of a slot
- A roadmap-input session artifact (an agenda, a deck, or the follow-up notes product received) → F3 and A5 move from medium to higher confidence
