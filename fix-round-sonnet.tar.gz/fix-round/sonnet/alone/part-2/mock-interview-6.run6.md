Reading the skill's rules is done; now I'm running two quick searches on Larkfield Systems' values and recent strategy before building the three-round pack.
Search was blocked, so there's no company research. I'm building the three-round pack from your role description and background alone, and labelling everything else as generic.
Your prep pack for all three rounds is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-6-denied-e95403a8/larkfield-systems_engineering-manager_interview_pack.md`.

It's built from your role description and background alone. I tried two web searches (Larkfield's values and its recent strategy) and both were refused, so there's no company research in it. The one company question, C2, is labelled generic, and the pack has no published-values sheet.

It has 28 questions across the three rounds, with persona weights and reverse questions for each, plus a shared fit snapshot. The highest-ROI rehearsal is B1, the "I don't see a hardware-adjacent roadmap in your background" objection. It's the thinnest part of your story and it comes back in rounds 1 and 3 (A2, B3, I1), so it's worth practising until it's boring.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two questions that would change the pack:
1. Can you paste the full JD and your CV, or just the bullets for your current role? Several scaffold answers could become answers built from your own sentences, and I'd check the requirement rows against the posting's actual wording.
2. Did the recruiter say anything about what Tuesday's or Thursday's rounds will focus on, or ask you to bring something like a plan or presentation? A named deliverable would get its own build section, and a stated focus would reweight the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (three-round loop)

Candidate: Yusuf. Mode: loop, three scheduled rounds sharing one fit snapshot.

| Round | When | Who | Relationship |
|---|---|---|---|
| 1 | Tuesday, 45 min | Director of Engineering | Hiring manager, your would-be boss |
| 2 | The Thursday after, 60 min | Two staff engineers and a product manager | Panel: technical peers plus a cross-functional partner |
| 3 | The following Monday, 30 min | VP Engineering | Skip-level; the recruiter's words were "values and leadership philosophy" |

Built from your role description and your own message only. No full JD, no CV, no interviewer names, and no web research (search was refused), so company facts are absent rather than guessed, and anything not traceable to your message is labeled generic.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and where a cell says answer slot, the slot is an instruction for the interview, answered from your real experience, with either branch acceptable.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and leadership principles, not generic virtue |
| EXP | Whether your claims survive scrutiny: what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework depth on the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Bank letters by persona: Round 1 uses A (Case/Strategist), B (Skeptic), C (Conversational). Round 2 uses D (Peer Evaluator), E (Data-Driven Prober), G (Values/Behavioral). Round 3 uses H (Values/Behavioral), I (Pressure), J (Conversational). F-numbers belong to the fit snapshot only.

Highest-ROI prep in the whole pack: B1, the hardware-roadmap objection. It is the thinnest row of your material (F6), it is likely to arrive in some form in all three rounds (A2, B3, I1 are its other faces), and a rehearsed, non-defensive answer changes the interview.

## Prep triage

1. Before Tuesday: B1 first, then B2, A3 and C1.
2. Between Tuesday and Thursday: E1 and E2 (your two figures), D3, G1.
3. Between Thursday and Monday: I1 and I2 (hold-then-concede), H1 and H2.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from your description of the role. Evidence cells hold only your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material says a team lead of 6, not two squads, and nothing about what the team builds. The step from 6 to 11 engineers across two squads is the role's, and your sentence does not show it. Words stay at the quote: "9 years engineering, 3 as a team lead of 6." Answer slot: if your team's work has anything in common with device-management services, say what; if it has nothing in common, say so plainly and stay with the team of 6 |
| F2 | "own delivery, hiring and growth for 11 engineers" — your message (delivery part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The sentence ties a 60% drop to a quarter you pushed through. It does not say who set the dates or how delivery was tracked. Words: that sentence at its own scope. Answer slot: the role's delivery line makes a probe on dates likely. If you answered for dates on your team's committed work, say how that worked, in your own words; if someone else set or tracked them, or there were no such commitments, say so plainly and return to the quarter you pushed through |
| F3 | "own delivery, hiring and growth for 11 engineers" — your message (hiring part) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | The sentence says you run the loop for backend roles, and the figure counts interviews, not hires. It does not say who set the criteria or made the final call. Words: "I run our hiring loop for backend roles." Answer slot: the role's hiring line makes a probe on the loop likely. If its stages or the decisions at its end were yours to set, say which and how you decided; if others set or made them, or no such stages existed, say so plainly and describe how you run the loop |
| F4 | "own delivery, hiring and growth for 11 engineers" — your message (growth part) | none given | none | [grounded] | discovery | Your material is silent on growth. Answer slot: the role names growth. If you have supported an engineer's progression, say what you did and what part was yours; if you have not, say so plainly and say what you would do first |
| F5 | "partner with hardware and product on roadmap" — your message (product part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The sentence says "against roadmap pressure" and does not say who applied it or whether a product partner was involved; derived from that wording only. Answer slot: if a product partner was part of that quarter, say what happened between you and what was yours; if there was none, or the pressure came from elsewhere, say so plainly and return to the quarter |
| F6 | "partner with hardware and product on roadmap" — your message (hardware part) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The role says partner and your sentence says own, so your material does not show whether you have worked with a hardware or device team. Answer slot: if you have, say what and what part was yours; if you have not, say so plainly |

No requirement in your description is a gate (authorization, location, schedule, pay, travel, credential), so the snapshot has no gate row. If the posting names one, send it and the row appears.

---

# Round 1: Director of Engineering (Tuesday, 45 min)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Case/Strategist | Live problems from the role: a missed date, a hardware collision, the first 90 days | High. Hiring-manager prior is Case/Strategist plus Skeptic, and your role description (squads, delivery, hardware and product partnership) hands them material | Clarify before structuring, think aloud, challenge one premise respectfully |
| B Skeptic | Quiet probing of the hardware gap, the step from 6 to 11, why leave | High. Same prior; a would-be boss is derisking, and F5 and F6 are your thinnest rows | Rehearse B1 until it is boring; plain acknowledgment, then a plan |
| C Conversational | The opening biography and "why us" | Lower. A 45-minute round has an opener, and casual questions are still scored | A 90-second arc built from your quoted sentences |

## Bank A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You take over two squads building device-management services, and one keeps missing its dates. What do you need to know first?" | CASE | [generic] | Clarify before you structure: which dates, who set them, what changed, what depends on hardware. Then objective, segments (people, process, dependencies), a first-month approach, how you would know it is working, and the risk of diagnosing too early. Think aloud and challenge one premise, such as whether the dates were ever realistic. The question needs no claim about your past, so the guidance makes none | The role's squads-and-delivery line (F1, F2) set as a live problem; CASE because it scores structure over a right answer; generic because nothing researched fixes the real situation |
| A2 | "Hardware moves a device revision six weeks before your squads planned to ship against it. Walk me through the replan." | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Clarify what is fixed, what can move, who owns each call, and what customers were promised. Lay out options (cut scope, move the date, run a parallel path) with the cost of each and who must agree. State your limit once, in your own words: "I haven't owned a hardware-adjacent roadmap", then say what you would ask hardware in the first weeks, as a plan. Propose seam principles (decision rights agreed in advance) rather than pretending to know their seam | F6 is the row this case presses; CASE because the scoring is structure and honesty about the limit |
| A3 | "How would you split your first 90 days across delivery, hiring and growth?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Prioritize aloud and say what you would learn before committing: how delivery stands, who the people are, what the hiring situation is. On hiring, say what the quote carries: you run the hiring loop for backend roles. Answer slot: the role's hiring line makes a probe on the loop likely. If its stages or the decisions at its end were yours to set, say which and how you decided; if others set or made them, or no such stages existed, say so plainly and describe how you run the loop | The role's three headline verbs in one question; F3 is the closest evidence for the hiring part; JD content, CASE delivery |
| A4 | "Product and hardware each want their items first on the roadmap. How do you decide what comes off?" | CASE | [inferred] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure first: criteria agreed before the argument, who decides, what each side gives up, how the decision is told. A clarify note on your own example, derived from the thin match in F5: the sentence says "against roadmap pressure" and does not say who applied it. Answer slot: if a product partner was part of that quarter, say what happened between you and what was yours; if there was none, or the pressure came from elsewhere, say so plainly and use the structure alone | The role's partnership line; F5 is low confidence, so it appears only as a clarify note and never as your claimed story |
| A5 | "An engineer on one of your squads has plateaued. What do you do in the first month?" | JD | [grounded] | Structure: listen first, separate skill from motivation from context, agree what better looks like, check in on a rhythm you will keep. No claim about your past is made. Answer slot: the role names growth, so expect a follow-up on whether you have done this; if you have supported an engineer's progression, say what you did and what part was yours; if you have not, say so plainly and say what you would do first | F4 is empty, so this requirement needs a rehearsed answer more than any other; JD because growth is a stated line of the role |

## Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see a hardware-adjacent roadmap in your background. How would you handle the hardware side of this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." | The highest-ROI rehearsal in this pack. Level 1: say the limit first, in your own words: "I haven't owned a hardware-adjacent roadmap." Then the plan, said as a plan: what you would ask hardware in the first weeks, what is fixed versus movable, who settles a collision. Level 2, "that is half the job": concede specifically that you would be learning the hardware calendar while leading, and hold on what you stated: a team lead of 6 and the hiring loop for backend roles, nothing wider. Level 3, "why take the risk": do not fold and do not add; say what you would do about the risk. Answer slot: the role says partner and your sentence says own. If you have worked with a hardware or device team, say what and what part was yours; if you have not, say so plainly | F6 is the thinnest row and the likeliest first probe; JD because it is the role's partnership line, Skeptic delivery because it is aimed at derisking |
| B2 | "You've led a team of 6. This is two squads and 11 engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | Say what you have in the quote's terms: 3 years as a team lead of 6. Your material does not show more than one team. Answer slot: if you have overseen more than one team, or set direction for another lead, say what and what part was yours; if not, say so plainly. Then answer "what changes" as a plan: what you would ask before changing anything, including how the squads are organized and whether they have their own leads. If that turns to managing managers, the plain line is "I haven't managed managers." | F1 is the scale step; JD because the role fixes the team size |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick a true one from the role's own lines; the hardware roadmap sentence is the one your material states. Name it plainly, say what you would do about it in the first weeks, and stop. Avoid a strength in disguise. Answer slot: if another line of the role feels equally thin to you, say so in your own words; if none does, say so | A stem every skeptic reaches for; F6 gives you a true answer so you are not tempted to invent one |
| B4 | "You're at a payments company. Why leave, why here, why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Selection scaffold: choose reasons that are true and say them in your own words, tied to the role's lines you actually want (two squads, delivery, hiring, growth, partnership with hardware and product). No disparagement of your current employer. This pack will not supply your reason. If part of the reason is simply wanting to leave, say so plainly and pair it with what draws you here | Motivation consistency is scored in this persona; JD because it tests fit with the stated role |

## Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc from stated beats only: 9 years in engineering, 3 as a team lead of 6, currently at a payments company; you run the hiring loop for backend roles; your team's on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. Keep the 60% attached to the team's on-call burden. Answer slot: if there was a moment that turned you toward leading a team, say it in your own words; if there was no single moment, say so and move on. End with one line on why this role, in your words | An opener that is scored; F1, F2 and F3 supply every beat, so the arc is built from what you stated |
| C2 | "Why Larkfield, and why industrial IoT and device management?" | CO | [generic] | Research could not run, so say nothing about Larkfield that you have not read yourself this week. Use the role's own lines (two squads building device-management services, partnership with hardware and product) and say what draws you in your own words. Answer slot: if you have no history in industrial or device work, say so plainly, then what you would want to learn first; if you have some, say what it was and what part was yours | CO because it tests homework depth; generic because no company research ran, which is the cost of the refused search |

## Reverse questions, Round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "How are the two squads led today, and what would you want me to change in the first quarter?" | Surfaces the squad structure without conceding anything about managing managers, and shows you are thinking about the first quarter |
| R1.2 | "Where do hardware release dates and software commitments collide today, and who settles it?" | Turns your hardware gap into a question about the real seam, which is the honest posture |
| R1.3 | "What does success look like at six months across delivery, hiring and growth, and which matters most?" | Mirrors the role's three verbs and tells you how your boss will weigh them |
| R1.4 | "Is the 11 a steady state, or are there open roles?" | Shows you are already thinking about the hiring part of the job |
| R1.5 | "How do you like to hear bad news from the people who report to you?" | A working-style question that lets a future boss describe how disagreement should go |

---

# Round 2: Panel, two staff engineers and a product manager (Thursday, 60 min)

## Persona weights

Panel rule: blend the top two personas of each member's relationship. Names are unknown, so assignment is by role only. Staff engineers read as technical peers (Peer Evaluator and Data-Driven Prober); the product manager reads as cross-functional (Values/Behavioral and Conversational).

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| D Peer Evaluator | Seams with staff engineers, what you need from them, disagreement | High. Two of three panelists are technical peers, and they are pricing what you cost and contribute to their work | Reciprocity first: what you bring them; propose seam principles, not a claimed seam |
| E Data-Driven Prober | Your two figures, taken apart | High. Technical peers probe numbers collegially, and you have two (60% and about 40 interviews) | Know how each was counted; say plainly when you do not know; name the weakest assumption before they do |
| G Values/Behavioral | Roadmap pushback, working with product, changing your mind | Medium. The PM is cross-functional, and behavioral stories are the register that role asks in | One story at its stated scope; "we" for context, "I" for what you did |

## Bank D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where is the seam between an engineering manager and a staff engineer on technical direction, and what happens when we disagree?" | CASE | [generic] | Propose seam principles instead of a claimed seam: who decides what, what is reversible, how a disagreement escalates, how the decision is recorded. Offer reciprocity: what you would protect or provide for them. Disagreement story selection: pick a time you disagreed with a technical peer and held your position with the relationship intact; it needs a named stake and an end state. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The standard peer probe on turf; generic because it asks for a pattern, not a fact |
| D2 | "We will want a say in who joins the squads. How do you involve engineers in hiring?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what the quote carries: you run the hiring loop for backend roles. Answer slot: if engineers other than you take part in your loop, say how; if they do not, say so plainly and say how you would involve staff engineers here. This pack will not supply a process | F3 is your closest evidence for hiring, and staff engineers care who they will work with; JD content, Peer delivery |
| D3 | "A staff engineer says a reliability fix should jump the queue. Product says the date is committed. You decide. Walk us through it." | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure the decision: what each party is protecting, the cost of waiting, the options (both partial, swap, sequence), who must agree, how you tell whoever loses. Your own example at its scope, as one example and not the template: after you pushed a reliability quarter through against roadmap pressure, your team's on-call burden dropped 60%. Answer slot: who applied the pressure and what you gave up, if anything; if nothing was given up, or you do not remember the exchange, say so plainly | The two staff engineers and the PM are on opposite sides of this exact trade; F2 is the evidence, F5's limit applies to who pressed |

## Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how the 60% drop in on-call burden was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The metric slots, each answered in your own words and none supplied here: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Say what you know: it is your team's on-call burden, and it dropped 60% after you pushed the quarter through. "After" is a sequence, not a measured cause, so expect "how much of that was the quarter?". If you do not know how it was counted, say so plainly. Never name a baseline or method you cannot repeat under a second question | A headline figure is a magnet for probers; EXP because it tests attribution and counting |
| E2 | "You said about 40 interviews last year. What was counted, and how many were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | The same four slots in your own words: how it was counted, what it is sensitive to, the weakest assumption, which part was yours. The figure attaches to interviews, not hires or candidates, so keep that noun. If the 40 includes interviews others conducted, or you do not know the count, say so plainly | Second headline figure; F3 |
| E3 | "How do you tell a strong backend candidate from one who just interviews well?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | This asks for your method and the pack will not supply one. Answer slot: say in your own words what you look at and why, and which of those criteria were yours to set; if others set them, say so plainly and say how you apply them. Keep to two signals you can defend under a follow-up | Technical peers test hiring judgment; F3 |

## Bank G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you pushed back on a roadmap request." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Open prompt, raised by the role's partnership-on-roadmap line. Story-map the quote: roadmap pressure, you pushed a reliability quarter through, your team's on-call burden dropped 60%. Use "I" for "I pushed" and "we" for context. Answer slot: who applied the pressure and what you said or traded; if the exchange was not a conversation like that, say so plainly and describe the quarter as it was. Do not cast the requester as the opponent | The PM is the person on the panel most likely to ask this; F2 and F5 |
| G2 | "When have you changed your mind because of something an engineer on your team told you?" | VAL | [generic] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Selection scaffold: pick an instance with a named decision, who raised it, what you changed, and what it cost you to change. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Touches the growth line (F4) from the team's side; generic because it supplies no event |

## Reverse questions, Round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What could a new engineering manager do in the first month that would genuinely help your work?" | The reciprocity question; it converts peer scrutiny into a working conversation |
| R2.2 | "What does a squad do today when a reliability issue and a feature date collide?" | Echoes D3 and shows you want their reality, not your template |
| R2.3 | To the PM: "How does product learn about hardware constraints today, and where does that go wrong?" | Aims at the seam you have not owned, so you are learning it in front of them |
| R2.4 | To the staff engineers: "What technical decision are you most waiting for a manager to unblock?" | Shows you see your job as removing blockers |
| R2.5 | "Which part of device management would you say is most under-invested right now?" | Asks for their view and lets them lead, which a panel remembers |

---

# Round 3: VP Engineering (the following Monday, 30 min)

## Persona weights

Skip-level prior is Case/Strategist plus Pressure; a dedicated values round is Values/Behavioral plus Conversational. The recruiter's "values and leadership philosophy" tips the blend toward values. No case bank is built for this round; I3 carries the one structured problem.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| H Values/Behavioral | Stories about unpopular truths, hiring calls, customers over metrics | High. The recruiter's own words name it | Map a story only where your quoted sentences carry one; "we" for context, "I" for contribution; pick stories where the hard truth landed, and say so if your material shows none |
| I Pressure | Time-boxed answers, "why you", "how much was you" | Medium. Executives at 30 minutes compress and interrupt; skip-level prior includes it | Pause, restate the question, hold through two follow-ups, concede specifically |
| J Conversational | Open "what do you want" questions | Lower. Leadership-philosophy conversations are open-ended, but they are still scored | Pre-script the answer; never answer "I think you've covered everything" to the reverse-question slot |

## Bank H: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Open prompt, raised by the recruiter's "values and leadership philosophy". Test whether your one quoted story fits: it says "against roadmap pressure" and does not say who pressed. Answer slot: if the pressure came from leadership and you told them something they did not want to hear, say what you said and how it landed; if it did not, say so plainly and pick another example, or describe the quarter at its own scope. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The headline values story for this candidate; F5's limit on who pressed governs |
| H2 | "What is your leadership philosophy? What should engineers be able to say about working for you?" | VAL | [generic] | The pack will not write your philosophy; it must be one you hold. Structure it as two or three principles, each with what you do when it costs something. If a principle has a story behind it in your own material, tell the story at the scale you would tell it and let the VP draw the inference; do not state what it proves. If you cannot tie a principle to something you did, say it is one you are still testing | The recruiter named it directly; generic because it asks for your stance, not a past |
| H3 | "Tell me about a hiring call that was close. What tipped it?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Open prompt, raised by the role's hiring line. Story-map only what the quote carries: you run the hiring loop for backend roles. Answer slot: if a close call was yours, say what tipped it and how it turned out; if the final call was never yours, or no call was close, say so plainly and describe how you run the loop. Do not supply an outcome | F3 is your hiring evidence; values at a VP level are often shown through people decisions |
| H4 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard values stem; generic because no quoted sentence of yours speaks to customers |

## Bank I: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Sixty seconds: why you, when you haven't owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause, restate the question, anchor in what you stated. Hold: a team lead of 6; you run the hiring loop for backend roles; after you pushed a reliability quarter through against roadmap pressure, your team's on-call burden dropped 60%. Concede exactly one thing, the hardware limit, and follow it with a plan, not a past. Hold through two follow-ups without adding to the quotes, and do not say what your work proves | B1 under time pressure; F6 with F1, F2, F3 as the held ground |
| I2 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold-then-concede on attribution. Hold the sentence as you said it: it dropped 60% after you pushed the quarter through. Concede specifically. Answer slot: which part was yours; if others did parts, say who and what, plainly. Do not say you cut on-call by 60% | The stem the Pressure persona uses on every headline figure; F2 |
| I3 | "If the Director you would report to and I disagreed on direction, whose side are you on?" | CASE | [generic] | No claim about your past. Structure: clarify what the disagreement is, what each side protects, bring it to both of us rather than around either, commit once it is decided. Concede there are cases you would escalate. Do not choose a side to restore harmony | The one structured problem in this round; an executive probing escalation and loyalty |

## Bank J: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What do you want the next three years to look like?" | JD | [generic] | Selection scaffold: say what you want in your own words and tie it to what the role actually offers (two squads, growth of 11 engineers, partnership with hardware and product). No career-ladder lines you do not mean. If part of the answer is still open, say so plainly | Casual register, still scored; tests whether your motivation matches the role |
| J2 | "What would your current team say it is like to work for you?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer only from what you have actually heard. Answer slot: if you have asked your team for feedback and heard something, say what; if you have not, say so plainly and say how you would ask. Do not speak for them beyond what they said | A people-leadership signal; F1 and the empty F4 row both meet here |

## Reverse questions, Round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does your leadership philosophy look like in practice here? What is a recent decision that reflected it?" | Pulls the abstract question into a concrete one and shows you listen for practice |
| R3.2 | "What do engineering managers who thrive here have in common?" | Asks the VP to define success without you presuming |
| R3.3 | "How does engineering leadership hear whether hardware and product feel well served?" | Keeps your hardware gap in view as a thing you want to close |
| R3.4 | "What is the hardest tradeoff engineering leadership has made this year?" | Gets the VP talking about judgment, which is what a values round is for |
| R3.5 | "Where do you want engineering management to be in two years?" | A strategy-altitude question suited to a skip-level |

---

## Requirement coverage

| Requirement or figure | Questions |
|---|---|
| Lead two squads building device-management services | A1, B2 |
| Own delivery | A1, A3, D3 |
| Own hiring | A3, D2, E2, E3, H3 |
| Own growth | A5, G2, J2 |
| Partner with product on roadmap | A4, D3, G1 |
| Partner with hardware on roadmap | A2, B1, B3, I1 |
| 60% on-call figure | E1, I2 |
| About 40 interviews figure | E2 |
| Recruiter's "values and leadership philosophy" | H1, H2, H3, H4 |
| Company and strategy knowledge | C2 only, generic, because research did not run |

## Prohibited claims

What this pack will not coach, with its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, in F6's sentence | The plain acknowledgment: "I haven't managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, in F6's sentence | The plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then a plan, never a past |
| Has led two squads, or a team of 11 | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a team lead of 6 |
| Has set the criteria for, or made the final call in, hiring | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you run the loop for backend roles. A3 and the other hiring slots stay inside the loop |
| Cut on-call burden by 60% yourself | Inflated form of F2 and F5 | The sentence as you said it: it dropped 60% after you pushed the quarter through. The limit is the pack's observation: "after" is a sequence, and your material does not say what else changed |

## Sources

Provided documents: your message (the role description, the three rounds and who runs them, your background). No CV, no full JD.

Searches sent, both refused:

- "Larkfield Systems industrial IoT company values principles" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Both calls were refused. It would have fed a values cheat sheet and tied the Round 3 VAL questions to published values; they are open prompts themed on the recruiter's words instead |
| 2. Larkfield Systems interview process, engineering manager | skipped | Your own words fix the loop: three rounds, who runs each and how long, so persona weights follow from them |
| 3. Larkfield Systems strategy or recent news | unavailable | Refused. It would have grounded CO questions and a grounding brief; C2 is generic and no strategy section exists |
| 4. Interviewer names | n/a | No names were given, so there is no query to form; the interviewer read is absent |
| 5. Representative engineering-manager JD | unavailable | Search was refused, so I did not send it. It would have added inferred JD requirements beyond your summary |

## Upgrade menu

- Full JD text: F1 to F6 would quote the posting instead of your summary, and any requirement your summary left out would get a row and a question
- Your CV or the bullets for your current role: scaffolds such as D1, G2, H4 and H2 could become story-mapped answers, and F4 (growth) might gain evidence
- Your answers to the slots in F1 to F6: each answer is quoted into the snapshot and the rows that draw on it are regenerated
- Interviewer names, titles or public profiles: an interviewer read, persona assignments per panel member, and reverse questions tied to their paths
- Search permission: a published-values cheat sheet for Round 3, CO questions grounded in current strategy, and a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) if you want one
- The recruiter's guidance on what Tuesday and Thursday will focus on, or any deliverable to bring: coverage reweighted, and a build section for any declared deliverable
- A verified-evidence dossier from an earlier evidence-recovery pass: user-confirmed claims and a prohibited-claims list that would bind this pack, offered as an enhancer and never as a requirement
