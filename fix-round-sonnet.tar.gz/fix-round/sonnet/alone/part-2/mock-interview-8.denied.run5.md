I'll read the reference files the skill requires before writing anything.
I've saved your prep pack as `ashgrove-credit-union_member-experience-lead_interview_pack.md` in the working directory. I built it as three rounds on 20 November from the recruiter's email: the recruiter, then the Head of Member Services, then the two-branch-manager panel with the case and the values scoring. No interviewer names exist yet, so there is no interviewer read, and I ran no searches because your pasted material already covered values, loop and strategy. That's 28 questions in all (8, 9 and 11 per round), with reverse questions per round and a values cheat sheet in Round 3.

The pack names D1 in Round 2 as the highest-ROI rehearsal. It's the contact-centre objection, with three levels of follow-up, and you've said yourself you've never worked in one. Second is presenting above regional level, which you've also said you haven't done. The pack gives you plain wording for both gaps and leaves your plan for closing them in your own words. Where your material was silent, for example digital teams and whether your complaints were "regulated", it gives answer slots instead of stories, so check those slots first.

I can play the Skeptic on D1 as a live drill, with follow-ups that react to what you actually say. If you want, I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions. I can convert the pack to a Word document as well.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds on 20 November 2026. **Built:** 11 November 2026.

| Round | Length | Who | Format, from the recruiter's email |
|---|---|---|---|
| 1 | 30 minutes | The recruiter | Conversation about the process and fit |
| 2 | 45 minutes | The Head of Member Services, who would be your manager | Mostly behavioural |
| 3 | 60 minutes | A panel of two branch managers | Includes a 20-minute case on a complaint escalation. The panel is also the values round and scores against the four values |

Interviewers beyond their roles have not been assigned, so there is no interviewer read. All three rounds fall on the same day, so tell the same facts in each one.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script.

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's strategy well enough to think at its altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

Answer slots tell you what to say in your own words, with two honest branches. Meeting either branch is a full answer. The pack never fills a slot for you.

The highest-ROI rehearsal is **D1** (Round 2): the contact-centre objection, with three levels of follow-up. Second is **B2/D2**, presenting above regional level. Both are gaps you stated yourself, so the work is saying them plainly and then saying your plan.

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on which parts of a complaint's path the log covered likely. Say which parts were yours, in your own words; if the log covered only part of the path, or part was not yours, say so plainly and stay with the log |
| F2 | "the contact centre" — JD, the second half of the F1 line | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote shows a monthly complaints spreadsheet you built and a regional manager who uses it. It does not show what the spreadsheet counted. Answer slot: the JD's monthly-reporting line makes a probe on what it counted likely. Say what it counted, in your own words; if you do not know how a figure on it was counted, or it did not count what the probe names, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says tellers and a script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on what the training involved and what came of it likely. Say what you did and what came of it, in your own words; if there is nothing you can point to, or it was not yours, say so plainly and stay with training the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the strategy brief's digital shift makes a probe likely. If you have worked with any digital or product team, say what and which part was yours; if you have not, say so plainly and say what you would ask them first, as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on the length. It is a statement with nothing inspected behind it, so expect a probe on what the branch work covered. Lead with the quote in its own terms |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | The quote says formal, and it does not show whether outside rules applied. Answer slot: the JD's regulated-complaints line makes a probe likely. If anything about how complaints on the log had to be handled was set from outside the branch, say what and which part was yours; if nothing was, or you are not sure, say so plainly and stay with the log you kept |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Say it as it stands: you built the monthly complaints spreadsheet your regional manager uses. It says spreadsheet, so say spreadsheet unless it was in Excel, and add no features to it |

## Grounding brief

You sent a summary of the strategy brief, not the brief itself. Everything below comes from that summary, and the brief was published in July 2026.

| Item | Source | Provenance | How to use it |
|---|---|---|---|
| "move 40% of member service to digital channels by 2028" | The 2026 strategy brief, per your message | [grounded] | Feeds F5, E2 and A4. Expect complaints to be asked about in terms of where they start |
| "consolidate eight branches into five hubs over 2027" | The 2026 strategy brief, per your message | [grounded] | Context for the Neighbours, Not Numbers value and for G3. Do not criticise the plan and do not trade on it |
| "launch a small-business lending product in Q1 2027" | The 2026 strategy brief, per your message | [grounded] | A talking point for A4 only. The pack makes no claim about what it means for complaints |
| "the main competitive pressure is app-only banks" | The 2026 strategy brief, per your message | [grounded] | Why self-service matters in E2. The interviewers have the same brief, so bring one item and then your own thought |

## Persona weights by round

| Round | Persona | Weight | Reasoning shown | Counter-strategy |
|---|---|---|---|---|
| 1 | Conversational | 5 questions | Round-type prior for a recruiter screen. The recruiter's email gives only the length and says nothing of focus areas | A 90-second arc, and treat casual questions as scored |
| 1 | Skeptic | 3 questions | The prior says light. It is three because your two stated gaps (F2, F8) are what a screen checks | Say the gap in one sentence and move to the plan |
| 2 | Values / Behavioural | 4 questions | The email says "mostly behavioural", which overrides the manager prior | Map a story to each ask, or use the selection scaffold and its honest branch |
| 2 | Skeptic | 3 questions | A manager buys capability and derisks gaps. Round 2 is where F2 will be pressed hardest | Rehearse D1 until it is boring. Calibrated candour, no bluffing |
| 2 | Case / Strategist | 2 questions | The 20-minute case is in Round 3, so Round 2 gets a light share | Clarify, objective, approach, metrics, risks |
| 3 | Values / Behavioural | 4 questions | The email says the panel scores against the four values | One story per value, told in the same facts as Round 2 |
| 3 | Case / Strategist | 3 questions | The email includes a 20-minute complaint-escalation case | Say your framework aloud, ask a clarifying question first, challenge one premise |
| 3 | Peer Evaluator | 3 questions | The panel is two branch managers, and the JD has you coaching branch supervisors. That puts them next to your work, which is an inference | Propose seam principles, not facts. State what you bring, not only what you need |
| 3 | Skeptic / Pressure | 1 question | Held for one time-boxed challenge on F2 | Hold, then concede specifically |

## Round 1: the recruiter (30 minutes)

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey in retail banking." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Build a 90-second arc from those four sentences only. The six years and the last three as branch supervisor, then the complaints log, the escalation script, the spreadsheet. Answer slot: your first three years are not in my material. Name the roles and what you did in them, in your own words, or leave them out of the arc. Finish on why this role, in your own words | The biography question opens most screens, and F6 is its evidence. EXP because it tests that the arc matches the CV |
| A2 | "What does the complaints side of your current work involve?" | JD | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F1, F3 and F4: a log you handled, a script you trained new tellers on, a monthly spreadsheet you built. Tell each in those terms. Answer slot: the JD's end-to-end line makes a probe on which parts of a complaint's path the log covered likely. Say which were yours, in your own words; if the log covered only part of it, or part was not yours, say so plainly and stay with the log | The JD's first line is the process, so the recruiter will check it early. JD because it scores the stated responsibility |
| A3 | "Why Ashgrove, and why this role?" | CO | [grounded] "I handled the branch's formal complaints log" | Pick the one thing from the values or the strategy brief that actually draws you, and say why in your own words. The pack cannot supply your reason. The JD's own words, "Own the member complaints process", pair naturally with "Own the Fix". The only claim about your past is the log you handled, at its own scope | Motivation is scored in every screen, and a reason borrowed from the website is easy to hear. CO because it tests homework |
| A4 | "What do you know about where Ashgrove is heading over the next couple of years?" | CO | [grounded] | Bring one item from the brief and one thought of your own. For example, "move 40% of member service to digital channels by 2028" and a question about where complaints first show up as service moves. The interviewers have the same brief, so do not recite all four items. No claim about your past is needed | The recruiter sent you the brief, so it is fair game. CO because it differentiates prepared candidates |
| A5 | "The role asks for four-plus years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "Never worked in a contact centre" | Say the quote as it stands. Answer slot: the JD says customer operations and your material says retail banking. Expect a probe on what the branch work covered. Say it in your own words; if the interviewer means contact-centre work, say plainly "I haven't worked in a contact centre" and move on | F6 is a clean row, but the phrase can be read narrowly. JD because it scores the headline requirement |
| B1 | "The role covers the contact centre as well as the branches. You haven't worked in one — how would you get up to speed?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Open with the plain acknowledgment: "I haven't worked in a contact centre." Then what you have, at its own scope, and stop: "I handled the branch's formal complaints log." Then a plan, said as a plan: who you would sit with and what you would listen for first, in your own words | F2 is a gap you stated, so a screen will check it. JD because it scores a stated responsibility |
| B2 | "It says confident presenting to senior leaders. What's the most senior audience you've presented to?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Plain acknowledgment: "I haven't presented to anyone above regional level." Answer slot: if anything you showed or sent at regional level counts as presenting, say what it was, in your own words; if it does not, say so plainly. Then a plan for preparing a first leadership presentation, said as a plan. The spreadsheet is a work product, not a presentation, so do not call it one | F8 is a stated gap and the JD names it. JD because it scores a stated requirement |
| B3 | "Your log covered formal complaints. What made them formal?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: the JD's regulated-complaints line makes a probe on this likely. If anything about how complaints on the log had to be handled was set from outside the branch, say what and which part was yours; if nothing was, or you are not sure, say so plainly and stay with the log you kept | F7 is `low`, so the honest answer is the one to rehearse. JD because it scores the regulated-complaints requirement |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Who is on the panel, and what are their roles?" | Interviewers are unassigned, and the answer tells you whose concerns to rehearse for |
| 2 | "What is the 45-minute round with the Head of Member Services most interested in beyond the behavioural questions?" | A recruiter can name focus areas, and that is the one un-researchable fact |
| 3 | "How is the 20-minute case run — is there a pre-read, and do you want me to think aloud?" | Format changes how you prepare, and it shows you are preparing |
| 4 | "Is there anything in my background you'd want me to address before the next rounds?" | It invites the concern early, so the gap is spoken to rather than discovered |
| 5 | "What does the timeline look like after the 20th?" | A normal close, and it signals interest |

## Round 2: the Head of Member Services (45 minutes)

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Pick a time you told someone more senior something they did not want to hear. It needs the truth said plainly, what you stood to lose, and what happened after, all in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An open behavioural prompt, and the material has no sentence for it. VAL because it scores past behaviour. The pack makes no claim about your past |
| C2 | "Tell me about a time you coached someone on handling an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: you trained new tellers on the escalation script. Answer slot: the JD's coaching line makes a probe on what the training involved and what came of it likely. Say what you did and what came of it, in your own words; if there is nothing you can point to, or it was not yours, say so plainly and stay with training the tellers | The JD's coaching line is the role's third responsibility. JD because it scores that line, and F4 is a transferability row |
| C3 | "Tell me about the spreadsheet you built — how did it come to be used?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3 and F9: you built it, and your regional manager uses it. Answer slot: expect a probe on how it came to be used and what it counted. Say how, in your own words; if it was assigned to you, or you do not know how a figure on it was counted, say so plainly and stay with the fact that you built it | The reporting line and the Excel line share this one quote. JD because it scores both |
| C4 | "Tell me about a time you worked with a team outside your branch to fix something." | JD | [generic] | Selection scaffold. Pick a time you worked with a team outside your branch, of any kind. It needs the problem, who you worked with, and what changed. If no such time comes to mind, say so plainly, then say what you would ask the digital team first about where members get stuck, as a plan | F5 is silent and the JD names digital teams. JD because it scores that line. The scaffold is the honest form |
| D1 | "The role covers the contact centre as well as the branches, and you haven't worked in one. Why should I believe you can own it end to end?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | **The highest-ROI rehearsal in this pack.** Level 0: "I haven't worked in a contact centre." Then what you have, at its own scope, and no conclusion drawn: the log you handled, the script you trained new tellers on, the spreadsheet you built. Follow-up 1, "What do you think is different about a complaint that arrives by phone?": say what you would expect as a view, not an experience; if you do not know, say so and say who you would ask first. Follow-up 2, "What would you do in your first thirty days?": a plan in your own words, and never a past. Follow-up 3, "Why not someone who has run a contact centre?": hold on what the quotes carry, concede that such a candidate would be ahead on the contact centre, and say what you would do about it | F2 is the biggest gap you stated, and the Round 2 manager is the person it would affect. JD because it scores a stated responsibility, and it is the deepest rehearsal because it is the likeliest objection |
| D2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose from the two you stated, whichever you honestly think is weaker: "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level". Do not invent a safe weakness. Add a plan, said as a plan. For digital teams, F5 is silent, so say plainly that you have not told this pack about any such work and say what you would ask first | An honest self-assessment is what the question scores. JD because it scores the whole list, and both quotes are your own words |
| D3 | "You handled the branch's complaints log. How much of the end-to-end process was actually yours?" | EXP | [grounded] "I handled the branch's formal complaints log" | Hold: "I handled the branch's formal complaints log." Concede specifically: your material says one branch's log, not the process across branches. Answer slot: the JD's end-to-end line makes a probe on which parts of a complaint's path were yours likely. Say which, in your own words; if the log covered only part of it, or part was not yours, say so plainly and return to the log. Hold through a second follow-up by returning to the log, never by adding to it | F1 is where the JD's mandate presses hardest. EXP because it tests attribution |
| E1 | "Sketch how you'd report complaint volumes and resolution times each month to the leadership team. What do you need to know first?" | CASE | [generic] | Clarify first: who reads it, what decision it feeds, and whether branches and the contact centre count a complaint the same way. Then the objective, what to show, where the data comes from, the caveats, and one thing you would leave out. Challenge one premise: whether the volumes are comparable across channels. No claim about your past is needed | The JD's reporting line meets its leadership-presenting line here. CASE because it is a live problem from the role |
| E2 | "By 2028 the plan is for 40% of member service to move to digital channels. What does that do to complaints?" | CO | [grounded] | Clarify, then structure: where complaints first arise as the channel mix shifts, what self-service could prevent, what should stay human, and how you would measure it. Name a risk, such as members who get stuck in self-service. No claim about your past is needed | The brief supplies the premise and F5 is silent. CO because it tests strategy altitude |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would make you say in ninety days that this hire is working?" | It asks the manager to define the scoring sheet |
| 2 | "Where does the complaints process work well today, and where does it leak?" | It starts from the problem, which is the Own the Fix posture |
| 3 | "How does the work split between the branches and the contact centre in practice?" | It meets the F2 gap with curiosity, not defence |
| 4 | "Who would I present the monthly report to, and what decision does it feed?" | It moves toward the F8 gap by asking about the audience |
| 5 | "How do you expect the hub changes to reach the supervisors I would be coaching?" | It ties the strategy brief to the role's coaching line |

## Round 3: the panel of two branch managers (60 minutes, with a 20-minute case)

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold for Members First, Always. Pick a time where what the member needed and what the process wanted pulled apart. It needs the member's need named, the decision you made, and who disagreed or what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack makes no claim about your past | The published value is the raising source. VAL because the panel scores against it |
| F2 | "Tell me about a time you rewrote or re-explained something so someone understood it the first time." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4 for Plain Words: you trained new tellers on the escalation script. Answer slot: the published value makes a probe on whether the words were clear likely. If any of the training involved making wording clearer, say what and how you knew; if it did not, say so plainly and stay with training the tellers on the script | Plain Words is the one value about language, and the only quote near it is the script. VAL because the panel scores it |
| F3 | "Tell me about a time you weighed a branch's or a town's needs against a number." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Story-mapped on F6 for Neighbours, Not Numbers: three years as a branch supervisor. Answer slot: if a decision at that branch weighed the town's members against a number, say what and which part was yours; if none did, say so plainly and stay with the years you supervised the branch. The hub plan is the context for this value, so listen for it and do not argue with it | The brief's hub plan puts this value in the room. VAL because the panel scores it |
| F4 | "Tell me about a time you found a problem and stayed with it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1 for Own the Fix: the log you handled. Answer slot: pick one complaint from the log that stayed with you to its close and say what the member needed, what you did and how it ended, in your own words; if none stayed with you that way, or the log was a record you kept rather than cases you followed, say so plainly and stay with the log. Use the same facts you used in Round 2 | The value matches the JD's own words, "Own the member complaints process". VAL because the panel scores it |
| G1 | "A member has complained at the branch, then at the contact centre, and it has now come to you as an escalation. You have twenty minutes: what do you do?" | CASE | [generic] | Say your framework aloud. Clarify first: what the member is complaining about, what each touch has told them, and what rules or timescales apply. Then the objective, your approach (who holds it, what you tell the member and when, plain words), what you record, and the follow-up with the people involved. Challenge one premise, such as why it needed a third touch. No claim about your past is needed | The email says there is a 20-minute escalation case. CASE because it is a live problem from the role |
| G2 | "The supervisor involved thinks the member is wrong and does not want to apologise. How do you coach them?" | CASE | [generic] | Structure it: listen to the supervisor first, separate the facts from the tone, agree what the member is owed, and decide who tells the member. A coaching plan, not a past. Do not claim you have coached supervisors, because your quote says tellers | The JD's coaching line, asked as a decision. CASE because it presupposes nothing about your past |
| G3 | "A member complains that their branch is being consolidated into a hub. What do you do?" | CO | [grounded] | Clarify what the member is actually asking for. Separate the decision, which is not yours, from the member's experience of it, which is. Plain words, one named person who keeps hold of it, and what you record. Do not criticise the plan. No claim about your past is needed | The brief's hub plan, put as a complaint. CO because it tests strategy at the panel's own altitude |
| H1 | "When a complaint escalates from my branch, where is the seam between your role and mine, and what happens when we disagree?" | CASE | [grounded] | Propose principles and not facts about their branch. For example, the person who finds the problem keeps hold of it, which is their own value "Own the Fix", and you own the process and the support around it. Say how you would settle a disagreement and what you would want from them. No claim about your past is needed | The JD has you coaching branch supervisors, so the seam is the likely question. CASE because it is a live collaboration problem |
| H2 | "What would you need from us in your first month, and what could we expect from you?" | JD | [generic] | A reciprocity answer. What you need: to see how complaints are handled in branches, and to hear what supervisors find hard. What you bring: a monthly view across branches, as a plan. No claim about your past is needed | The panel are branch managers whose supervisors you would coach. JD because it scores the working relationship |
| H3 | "Tell me about a time work spanned teams and how credit was handled." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold with one quote. Pick a time work spanned teams and say who did what. The nearest thing your material carries is the spreadsheet, at its own scope. Answer slot: if others contributed to it, say who and what; if not, say so plainly and stay with the fact that you built it. If no such time comes to mind, say so plainly | The peer stem on credit. EXP because it tests attribution |
| I1 | "Sixty seconds: why you over someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Pause, restate the question, then hold on what the quotes carry: "I handled the branch's formal complaints log" and "I built the monthly complaints spreadsheet our regional manager uses". Hold through two follow-ups by returning to those, never by adding to them. Concede specifically: "I haven't worked in a contact centre", and that it is one branch's log. Do not claim you are better | The pressure version of F2. JD because it scores the same stated requirement |

### Values cheat sheet

| Value (official name) | Working meaning | Mapped story, or scaffold | Question |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold ending in its honest branch (F1). No row carries a quote for this one | F1 |
| Plain Words | If a member needs it explained twice, the writer got it wrong | F4: "trained new tellers on our escalation script", with the slot in F2 | F2 |
| Neighbours, Not Numbers | Every branch is part of its town | F6: "6 years in retail banking, the last 3 as a branch supervisor", with the slot in F3 | F3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log", with the slot in F4 | F4 |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do your supervisors find hardest about escalations today?" | It asks the panel for the real problem, which is what the coaching line is for |
| 2 | "How do you expect the hub changes to show up in complaints from where you sit?" | It invites their view of the strategy rather than offering yours |
| 3 | "When a complaint escalates from your branch, what do you want from this role in the first hour?" | It calibrates the case you have just done |
| 4 | "Which of the four values is hardest to hold in a branch on a busy day?" | It shows you took the values seriously and gets a real answer |
| 5 | "What could a new person in this role do in their first month that would genuinely help your branch?" | The peer reciprocity question |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 own the complaints process end to end | A2, D3, G1 |
| F2 the contact centre | B1, D1, D2, I1 |
| F3 monthly reporting | C3, E1 |
| F4 coach branch supervisors | C2, G2, H1 |
| F5 digital teams | C4, E2, G3 |
| F6 four-plus years | A5, A1 |
| F7 regulated complaints | B3 |
| F8 presenting to senior leaders | B2, D2, E1 |
| F9 Excel reporting | C3 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one branch's log, not the process across branches. D3's slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers and a script |
| Produced the volumes-and-times report | Inflated form of F3 | F3's quote at its own scope. C3's slot asks only what the spreadsheet counted |
| Handled complaints under outside rules | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material says formal, not what applied |
| Contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD; the values text you pasted, copied on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the process; your summary of the 2026 strategy brief (the brief itself was not seen); and the background in your message. No search or fetch was sent, and no dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the cheat sheet and the VAL bank, so a search could not change them |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the rounds, lengths, who runs each and that the panel scores the values, so persona weights are decided |
| 3. Ashgrove strategy | skipped | Your summary of the July 2026 brief fixes the CO bank and the grounding brief |
| 4. Interviewer names | n/a | No interviewer has been named, so there is no query to form |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → F1, F3, F4, F6 and F9 evidence from your message becomes CV quotes, and A1's slot for your first three years closes
- Answers to the answer slots in F1, F3, F4, F5 and F7, in your own words → those rows move from slots to story maps and the question guidance regenerates
- The complaints spreadsheet, or a description of what its columns counted → F3 and F9 can reach `high` and C3 becomes a story map
- The full strategy brief → the grounding brief gains figures and anything it says about complaints or service
- The interviewers' names and roles for Rounds 2 and 3 → an interviewer read, reweighted personas and a reverse question tied to their own path
- The recruiter's answer on how the 20-minute case is run, and whether there is a pre-read → a build section if it is a pre-declared deliverable
- Hours available for prep → a prioritised prep schedule sized to the time
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → role-family loop reports and recent organisation context
- A tuesday-dossier.md from an earlier evaluation → an evidence-derived objection and strategy limits per weak area, in place of the inferred ones here
