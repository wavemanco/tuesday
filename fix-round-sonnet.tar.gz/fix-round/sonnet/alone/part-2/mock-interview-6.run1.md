I'll read the reference files the skill requires before building the pack.
I'm cleaning up one garbled row in the coverage table of the saved pack, then I'll present it.
Your prep pack for all three rounds is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-6-denied-6c6ff245/larkfield-systems_engineering-manager_interview_pack.md`.

I built it from your message alone: the role line, the recruiter's note on Monday, and your four background sentences. I ran four web searches for Larkfield's values, interview process, strategy and a sample job description, and all four were refused. So nothing in the pack about Larkfield goes beyond what you told me. There is no values cheat sheet or company-strategy question yet. The case questions are generic.

It has one shared snapshot of your evidence against the role, a bank of questions for each round (12, 12 and 8), and reverse questions for each round. Your answer to the hardware-roadmap objection (A2) is the one to rehearse first. It comes back in some form in every round.

Say the word and I'll play the Skeptic on A2, the hardware-roadmap objection, which the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Would the two staff engineers on Thursday's panel sit beside you as peers or report to you? That reweights the Thursday personas.
Did the recruiter give any focus areas or pre-work for Tuesday or Thursday? Each declared item would get its own build section.
Can you paste the full job description or your CV, or tell me to go on without them?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (three-round loop)

Candidate: Yusuf. Loop mode, three scheduled rounds, no interviewer names given.

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1. Tuesday | Director of Engineering | 45 min | Hiring manager, your would-be boss |
| 2. Thursday after | Two staff engineers and a product manager | 60 min | Panel |
| 3. Following Monday | VP Engineering | 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

Built from your message only: the one-paragraph role description, the recruiter's description of Monday, and four sentences about your background. No JD text, no CV, and the research searches were refused, so nothing here about Larkfield goes beyond the role description you gave.

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Every question carries both, plus the sentences of yours it rests on.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and leadership beliefs, not generic virtue |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy (none in this pack, see Sources) |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer from your own experience in your own words, or say plainly the practice was not yours or never existed. Question IDs run by persona across the loop: A to D Tuesday, E to H Thursday, I to K Monday.

The single highest-ROI rehearsal in the whole loop is **A2**, the hardware-roadmap objection. It arrives in some form in every round: H2 is its Thursday packaging, J1 is the Monday gap.

## Prep triage

Two weeks, three rounds. Do these few things well, in order. Everything else is insurance.

1. Before Tuesday: say A2 out loud until it is boring, then A1, A4, C1, D1 and D2. A2 is the one an unrehearsed answer fails.
2. Between Tuesday and Thursday: E1 to E4 (the 60% and the attribution questions), F2, G1 and G3. Choose your stories now: your material carries one story, the reliability quarter, so pick one or two more yourself for the scaffolded questions.
3. Between Thursday and Monday: I1, I2, J1 and K1. Monday is 30 minutes, so each answer needs a one-minute version.
4. Insurance: B1 to B3, C2, C3, all reverse questions beyond the first two per round.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — the role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of six at a payments company, with nothing inspected behind it, and says nothing about squads or devices. The words stay at that scope: "I've been a team lead of six." The 3 in your sentence is read as years, so say years only if that is what you meant. Answer slot: the role's device-management line makes a probe on how your work maps likely. If any of your services dealt with devices, say which and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the team of six |
| F2 | "own delivery" in "own delivery, hiring and growth for 11 engineers" — the role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Your material says a reliability quarter and the pressure it was pushed against, with no artifact behind the 60%, and does not say what the team delivered. The words stay: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: the role's delivery line makes a probe on how that quarter was fitted against the roadmap likely. If the fit was yours to make, say what you decided and how, in your own words; if it was not, or there was no such decision, say so plainly and describe how you pushed it through |
| F3 | "hiring" in "own delivery, hiring and growth for 11 engineers" — the role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect the figure to be probed. Lead with the loop in the quote's own terms: you run the loop for backend roles, and the figure counts interviews |
| F4 | "growth" in "own delivery, hiring and growth for 11 engineers" — the role description in your message | none given | none | [grounded] | discovery | Your material is silent on this, which is not the same as a gap. Answer slot: the role's growth line makes a probe on the engineers you would be growing likely. If helping engineers develop was part of your job, say what you did, in your own words; if it was not, or was not yours, say so plainly and return to the hiring loop you run |
| F5 | "partner with hardware and product on roadmap" — the role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | You stated you have never owned a hardware-adjacent roadmap, and your material is silent on working alongside hardware or product people. The words for the part you stated: "I've never owned a hardware-adjacent roadmap." Answer slot: the role's partnering line makes a probe on working with either likely. If you have worked alongside product or hardware people on what got built, say how and what part was yours, in your own words; if you have not, or it was not yours, say so plainly and say how you would start |
| F6 | "values and leadership philosophy" — the recruiter's description of Monday's round, in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | discovery | The sentence states a pushed reliability quarter and the pressure against it; it does not state who applied that pressure or how the choice was made. Answer slot: the recruiter's line makes a probe on what you believe about leading likely. If the quarter shows a belief of yours, say which and why, in your own words; if it was a one-off, or the choice was not yours, say so plainly and stay at the scope the sentence gives |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 two squads, device-management services | A1, A3, A4, B2, C2 |
| F2 delivery | B1, B2, B3, D1, E3 |
| F3 hiring | D2, I3 |
| F4 growth | C3 |
| F5 partnering with hardware and product | A1, A2, B3, F2, G2, H2 |
| F6 values and leadership philosophy | G1, G3, I1, I2, I4, J2 |
| "industrial IoT, ~600 people" | none as a requirement: it is context, used by A3 and C2 |
| Company and strategy knowledge | CO: none, and why: every research search was refused, so nothing current is in hand |

## Round 1: Tuesday, Director of Engineering (hiring manager), 45 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (4 questions) | Quiet probing of what is missing from your background | High. The hiring-manager prior is Case/Strategist plus Skeptic, and the gaps in F5 are what a would-be boss weighs first | Rehearse A2 until it is boring; concede the stated limit plainly, hold what your sentences carry |
| Case/Strategist (3) | Live problems on the squads' roadmap | High. Second half of the hiring-manager prior. The banks are generic because no research on Larkfield came back | Clarify, objective, options, trade-offs, decision; think aloud; challenge one premise |
| Conversational (3) | Biography opener, casual questions on the role's topics | Medium. A 45-minute round opens with the biography, and casual questions about device-management are still scored | A 90-second arc built only from your sentences |
| Prober (2) | Line-by-line questions on your two figures | Medium. You gave two figures (the 60%, the 40 interviews) and any careful reader may ask for them to be defended. No interviewer profile exists to push this up or down | Know what you can and cannot say about how each was counted, and say plainly when you do not know |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Take the weakest part from your own sentence, not from a guess: "I've never owned a hardware-adjacent roadmap." Say it in one plain sentence, then say what you would do first as a plan, never as a past: who you would ask, what you would want to learn, how you would check it. Your plan, your words; the pack does not supply it. A2 is this answer under pressure | F5 is the widest gap against the role's partnering line and the one you named yourself. JD because it scores a stated requirement; Skeptic delivery |
| A2 | "You haven't owned a hardware-adjacent roadmap, and this role partners with hardware on roadmap. How would you handle that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The highest-ROI rehearsal in the pack. Hold-then-concede in four levels. Open: concede the stated part first and plainly, "I've never owned a hardware-adjacent roadmap", then say what your other sentence carries, at its scope, and let them draw the link. Follow-up 1, "What makes you think that carries over?": answer slot, if any of your work has depended on hardware or physical-device constraints, say how and what part was yours; if none has, or it was not yours, say so plainly and return to the reliability quarter. Follow-up 2, "What would you do in your first month?": a plan in your own words, covering who you would sit down with, what you would ask, and what you would not decide until you knew. Follow-up 3, "How would we know it was working?": name your own measure, the pack supplies none. Name the limit before it is asked for: your material shows no work alongside hardware either way, so claim none | F5 is the biggest gap against the role's partnering line, so this objection arrives in some form in all three rounds; H2 is its Thursday packaging and J1 the Monday gap. JD because it scores the requirement; Skeptic delivery |
| A3 | "Why Larkfield, and why leave a payments company for industrial IoT?" | JD | [grounded] | Your reasons, in your words; the pack cannot supply them. Structure: what draws you in the role as described to you (two squads, device-management services, partnering with hardware and product), what you are moving from, why now. Say nothing about Larkfield beyond the role description, because the research on it was refused and a fact you cannot source is the one that breaks on a follow-up | Motivation consistency is what the Skeptic scores, and F1 is the move being explained. JD because it tests fit with the stated role |
| A4 | "You've been a team lead of six. This role has eleven engineers across two squads. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start from the sentence: "I've been a team lead of six." Answer slot: the role's eleven engineers and two squads make a probe on what changes likely. If you have worked with a second team's engineers in any way, say how and what part was yours; if not, or it was not yours, say so plainly and say what you would find out first about the two squads | F1 is the scope gap in the snapshot. JD because the size of the job is stated in the role description |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Product wants a new feature set this quarter, hardware has a firmware release you depend on, and one squad is drowning in on-call. How do you decide what the squads do?" | CASE | [generic] | Structure it aloud. Clarify first: what is firm and what is soft, who decides, what the on-call load is costing. Then objective, options, trade-offs, your decision, and what you would tell product and hardware each. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | Live problem built from the role's delivery and partnering lines (F2, F5). Generic because it is a pattern for the problem, not a fact about Larkfield |
| B2 | "Sketch how you would plan the next two quarters across both squads. What do you need to know first?" | CASE | [generic] | Spend the first minute on questions, not answers: what is already committed to hardware and product, what the on-call load is, who the eleven engineers are, what depends on a hardware date. Then objective, approach, metrics, risks. Name your hypothesis early | The stem a hiring manager uses for roadmap fluency; F1 and F2 are the requirements it tests. Generic: no Larkfield research came back |
| B3 | "A hardware release slips six weeks and both squads' plans depend on it. What do you do in the first 48 hours?" | CASE | [generic] | Triage structure: what is actually blocked and what only looks blocked, who needs to hear it first, what each squad can do in the gap, what you would ask hardware before replanning. Think aloud and state what you would not decide until you knew more | Tests partnering under a live failure (F5) and delivery (F2); no claim about your past is needed |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. How did you get here, and what brings you to this?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with the three beats your sentence states: nine years of engineering, three as a team lead of six, currently at a payments company. Then why this role, in your own words. Answer slot: if a particular moment or decision moved you toward leading, say what it was; if it was gradual, or assigned, say so plainly | The biography question is scored even when it sounds casual. F1 is the evidence for the arc |
| C2 | "What are you actually playing with these days in device fleets or embedded software?" | JD | [grounded] | Casual questions on a role's hot topics are scored. Answer slot: if you have looked at any of this, say what and why it caught you; if you have not, say so plainly and say what you would read or try first. Claim no experience you have not told me about | The role's device-management line (F1) is the raising source; Conversational delivery |
| C3 | "How do you think about helping engineers grow?" | JD | [grounded] | Answer slot: the role's growth line is the probe. If supporting engineers' development was part of your job, say what you did and what part was yours; if it was not, or was not yours, say so plainly and return to the hiring loop you run. Do not describe a practice you did not carry out | F4 has no evidence behind it, so this is where the gap shows. JD because growth is a stated responsibility |

### Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your team's on-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Four slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Keep your sentence's word "after": it does not say "because", and the weakest move is to upgrade it | F2's figure is where a prober starts. EXP because it tests whether the claim survives scrutiny |
| D2 | "About 40 interviews last year. How was that counted, and which ones were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Keep the noun your sentence uses: interviews, not hires. Answer slot: how the figure was counted, which interviews were yours, and the assumption you would defend least, in your own words. If you do not know how it was counted, say so plainly | F3 is the line a hiring manager checks against the role's hiring responsibility. EXP; the figure is a defend-the-number item |

### Reverse questions for Tuesday

| Question | Why it lands |
|---|---|
| "How are the two squads structured today, and who leads day to day?" | Asks for a fact you need, and the answer tells you how the squads' leadership works before you are asked about it |
| "Which hardware release or customer commitment are the squads' plans most dependent on this year?" | Points at the partnering part of the role (F5) with a question you can follow with your own |
| "What would make you say, ninety days in, that hiring me was the right call?" | Turns the evaluation into a shared target and gives you the bar to rehearse against |
| "What is the on-call and incident picture for the two squads today?" | Shows you look at reliability from the first day, and asks rather than claims |
| "What worries you most about someone joining this role from outside industrial IoT?" | Invites the main objection out in the open where you can answer it, instead of leaving it unsaid |

## Round 2: Thursday, panel of two staff engineers and a product manager, 60 min

Assumption: the staff engineers are peers or technical partners rather than people who would report to you. If they would sit on your squads, tell me and Peer and Prober weights change.

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Prober (4 questions) | Depth on the reliability quarter and the figures | High. The panel prior blends each member's top two personas, and the staff engineers read as technical specialists, whose prior is Prober plus Pressure | Know what each number does and does not say; rehearse E1 to E4 aloud |
| Peer Evaluator (3) | Seam-splitting, credit, "what would you need from me" | High. All three panelists work beside the role, not above it | Reciprocity: what you bring them, and seam principles rather than a pretended seam |
| Values/Behavioral (3) | Scenario probes from the product manager | Medium. A cross-functional panelist's prior is Values plus Conversational. No published Larkfield values were retrievable, so the stems are generic | Selection scaffolds; your material carries one story, pick the rest yourself |
| Pressure (2) | Time-boxed challenges, "why you" | Medium. Part of the staff-engineer prior, weighted lower than Prober because the round is 60 minutes and collegial | Pause, restate, hold two follow-ups, concede specifically |
| Conversational | Opener from the product manager | Low. Covered by reusing C1; no separate bank | Reuse your C1 arc |

### Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Name the weakest assumption you know of before they do, in your own words; the pack does not name one. If you do not know how the figure was counted, say so plainly. Keep "after", not "because" | Persona stem aimed at F2's figure; EXP because it tests whether you know your own number |
| E2 | "How much of that was actually you, and how much was the team?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Use "we" for the context and "I" only for what your sentence carries: you pushed the quarter through. Answer slot: if others did specific parts, say which, in your own words; if you do not know how the work was split, say so plainly | Attribution probe on F2; the honest answer is precise, not modest |
| E3 | "Walk me through the reliability quarter." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Tell it with the beats your sentence states: the team's on-call burden, the 60%, that you pushed the quarter through, and the roadmap pressure it was pushed against. Anything further you say comes from your own memory, because the pack has none of it and adds none | The staff engineers will go below the headline. F2 is the evidence; the guidance stops where the sentence stops |
| E4 | "Which part of that quarter would you do differently?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: if there is a part you would change, say what and why, in your own words; if there is not, say so plainly rather than inventing one. Either answer is fine; an invented regret is the one that breaks | Honest self-assessment on F2, asked in a collegial register |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where is the seam between you and a staff engineer, and what happens when we disagree?" | CASE | [generic] | Offer seam principles, not a pretended seam: what is decided where, how a disagreement gets surfaced, who breaks a tie and how. Frame it as what you would propose, in your own words, and ask what the current seam is. The question needs no claim about your past | Peer stem; F1 is the role the seam is drawn around. Generic: no information about the squads' actual structure |
| F2 | "You will partner with product on the roadmap. Tell me about a time you disagreed with a product manager." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Selection scaffold. Pick a real time: a named stake, what you proposed, how it landed, the relationship intact afterward. The nearest thing your material carries is the reliability quarter pushed through against roadmap pressure, and the sentence does not say who applied that pressure, so use it only if it fits. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role's partnering line (F5) raises this. VAL because it scores behavior with a cross-functional partner |
| F3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time credit was shared or contested, say who did what, and what you did. Use "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then say how you would handle it | Persona stem for a peer; no claim about your past is made, so it is generic |

### Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a named customer or user, the metric you let slip, who disagreed, what happened to the relationship. Your material has no sentence that carries this, so choose a real time yourself. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for a cross-functional panelist. No published Larkfield value was retrievable to anchor it |
| G2 | "What would you need from product to do this job well, and what would you bring them?" | JD | [grounded] | Reciprocity framing. Say what you would ask of product in terms of decisions and information, then what you would give back. Offer principles, not a claim that you have done this with hardware. Your own words | The role's partnering line (F5); JD because it scores the requirement from the product side |
| G3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Selection scaffold: a named stake, a moment you did not fold, the relationship intact. Your reliability quarter is the one candidate in your material, and the sentence does not say whether it involved telling leadership anything, so test it against those criteria before using it. If it does not fit, or no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; F6 is the leadership-beliefs row. VAL because the hard truth has to have landed |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I run our hiring loop for backend roles — about 40 interviews last year" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" "I've never managed managers and never owned a hardware-adjacent roadmap" | Pause, restate, then hold. Hold only what your sentences say: a team lead of six, a hiring loop you run for backend roles, a reliability quarter pushed through against roadmap pressure. Then concede one thing specifically: "I've never owned a hardware-adjacent roadmap." Do not claim to be better than anyone, and do not fold on the three things you hold | Pressure stem; F1 to F5 are the evidence it draws on |
| H2 | "Why should two staff engineers trust you with their roadmap when you haven't owned a hardware-adjacent one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A2 in a sharper tone. Concede first, plainly: "I've never owned a hardware-adjacent roadmap." Hold through two follow-ups by returning to what your reliability sentence carries, never by adding to it. Offer the plan, not a past: what you would ask them first and what you would not decide alone | F5 again, aimed at the staff engineers. Rehearse together with A2 |

### Reverse questions for Thursday

| Question | Why it lands |
|---|---|
| "What could a new manager do in the first month that would genuinely help you?" | Reciprocity question for a peer: asks what you could add to their work, not only what you need |
| "How does hardware input reach the roadmap today, and where does it get stuck?" | Asks to the seam (F5) and invites an answer you can ask a follow-up on |
| "What is a technical decision the squads are still arguing about?" | A staff-engineer question: shows interest in their work rather than the process |
| "How do you decide today what does not get built?" | The product manager's side of the seam, and a question that has a real answer |
| "If you could change one thing about how the squads work together, what would it be?" | Open, low-risk, and useful: it tells you what you would be asked to fix |

## Round 3: Monday, VP Engineering, 30 min ("values and leadership philosophy")

The recruiter's description establishes a values-style round. Larkfield's published values could not be retrieved, so there is no values cheat sheet: the Monday questions are scaffolds themed from the recruiter's words, and reverse question 5 asks the VP for the values directly. Paste the values page and I will build the mapping.

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (4 questions) | Scenario and philosophy probes, "how do you lead" | High. The recruiter named values and leadership philosophy, and a values round is dedicated behavioral conversation | One story per belief; "we" for context, "I" for contribution; say plainly where your material has no story |
| Pressure (2) | Altitude and composure, short time-boxes | Medium. The skip-level prior is Case/Strategist plus Pressure, and 30 minutes means interruptions. Your stated gap on managers is what a VP can press | Pause, hold, concede specifically |
| Conversational (2) | Biography, what you want next | Medium. A 30-minute round has an opener, and casual questions are scored | One-minute arc |
| Case/Strategist | Strategy fluency | Low. Skip-level prior, but with no research behind it there is nothing current to rehearse; it is in the upgrade menu | No bank; say the framework aloud before using it if a strategy question arrives |

### Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pick two or three principles you actually act on, and give each one instance from your own work at its true scope. The one instance your material carries is the reliability quarter. Answer slot: if the quarter shows a belief of yours, say which and why; if it was a one-off, or the choice was not yours, say so plainly and use a different instance you choose. Do not state a principle your instances do not carry | The recruiter's "leadership philosophy" is the raising source; F6 is the row. VAL because a belief has to be shown by behavior |
| I2 | "What would your engineers say you are like to work for?" | VAL | [generic] | Selection scaffold: pick feedback you have really received and say what it was and what you did with it. If you have had none, say so plainly and say what you would hope they would say and how you would find out. Do not report feedback you have not had | Leadership philosophy from the other side. No sentence of yours carries this, so it is a selection question |
| I3 | "What do you look for when you hire, and what have you learned from running the loop?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start with the sentence: you run the loop for backend roles, about 40 interviews last year. Answer slot: the role's hiring line makes a probe on what you look for likely. If you have learned or changed something from running it, say what, in your own words; if the loop follows a format that was not yours, or nothing changed, say so plainly and return to the loop you run | F3 is the evidence. JD because hiring is a stated responsibility; VP altitude |
| I4 | "What is a belief about leading engineers you have changed your mind on?" | VAL | [grounded] | Selection scaffold: a belief you actually held, what changed it, and what you do differently. Your material has no sentence that carries this, so choose a real instance. If no such time comes to mind, say so plainly, then say what you believe now and why | The recruiter's "philosophy" line is the raising source. Asked at VP altitude, it scores reflection rather than a story |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You have told us you have never managed managers. Why should I think you would grow into this?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I run our hiring loop for backend roles — about 40 interviews last year" | Concede first, plainly: "I've never managed managers." Then hold what your sentences carry: a team lead of six, a hiring loop you run for backend roles. Say what you would want to learn first as a plan, never as a past. Do not describe the role as needing or not needing it; you do not know that from your material | The stated negative from F5's evidence, which a VP can press. Pressure delivery; JD because it scores the role's scale |
| J2 | "If I called your current team, what would they say you could do better?" | VAL | [generic] | Pick something true and specific that you have actually been told or recognize, say it plainly, and say what you are doing about it. If nothing comes to mind, say so plainly rather than manufacturing a flaw or deflecting. Do not use a strength dressed as a weakness | A pressure variant of I2; no claim about your past is made |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "So, walk me through the journey, and what you want from your next leadership role." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | The C1 arc in 60 seconds: nine years of engineering, three as a team lead of six, currently at a payments company. Then what you want next, in your own words, tied to the role as described to you and nothing else about Larkfield | F1 is the evidence for the arc; shorter than Tuesday because the round is 30 minutes |
| K2 | "What are you hoping to learn in this role that you can't learn where you are?" | JD | [grounded] | Your reasons in your words. Tie them to the role description's lines only: two squads, device-management services, partnering with hardware and product. Do not claim knowledge of Larkfield beyond that | Motivation consistency at skip-level; F5 and F1 are the parts of the role you have said are new to you |

### Reverse questions for Monday

| Question | Why it lands |
|---|---|
| "What do you want engineering leadership at Larkfield to be known for in two years?" | A VP-altitude question that asks for their direction, not a process detail |
| "How do you decide when a manager is ready for a bigger scope?" | Connects to your own stated limit on managing managers and asks how growth is judged here |
| "When hardware priorities and product priorities collide, who decides, and how?" | The seam in F5 asked at the level where it gets settled |
| "What do you wish you had known in your first year in your role?" | Invites a personal answer, and gives you something to carry into the offer conversation |
| "What are the company's values in practice, and where do they show up in engineering decisions?" | The published values were not retrievable, so this gets them from the person who will score you |

## Prohibited claims

What this pack will not coach, and why. The banks above were written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F5's evidence | The plain acknowledgment: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5's evidence | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." The slot asks only about working alongside product or hardware people |
| Led two squads, or managed eleven engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a team lead of six |
| Owned delivery or set the roadmap | Inflated form of F2 | F2's quote at its own scope: the material says a reliability quarter pushed through against roadmap pressure, not who set the roadmap |
| Cut the on-call burden by 60% as a result you caused | Inflated form of F2 | The quote at its own scope: it says the burden dropped 60% after you pushed the quarter through, not because of it |
| Hired about 40 engineers | Inflated form of F3 | The quote at its own scope: about 40 interviews last year, for backend roles |

## Sources

Provided documents: your message (the role description, the recruiter's description of Monday's round, four sentences about your background). The loop is established by your own words: three rounds, each with who runs it and how long, so no archetype fallback applies. Monday is detected as a values-style round from the recruiter's description; no published values were retrieved, so there is no values cheat sheet. No dossier was present.

Searches sent, all refused: "Larkfield Systems industrial IoT values", "Larkfield Systems interview process engineering manager", "Larkfield Systems industrial IoT device management news strategy", "Engineering Manager device management IoT platform job description".

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. Would have moved the Monday values cheat sheet and anchored G1, I1 and I4 to named values |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. Would have moved the panel's format and any case or exercise in Thursday's round; your own words establish the loop, so persona weights stand |
| 3. `Larkfield Systems` strategy and recent news | unavailable | The search was refused. Would have moved CO questions, which are absent, and made B1 to B3 specific |
| 4. interviewer name and company | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | unavailable | The search was refused. Would have added role-family requirement rows marked `[inferred]` beyond the one-line role description |

## Upgrade menu

- The full JD text: the six rows' requirements move from one line of role description to the JD's own wording, and any mid-list tool or method gets a question
- Your CV: evidence cells move from four sentences in your message to CV lines; for engineering management the artifacts that raise a band are the on-call or paging report behind the 60%, the applicant-tracking report behind the 40 interviews, and a quarter plan or roadmap document behind the reliability quarter
- Your answers to the slots in F1, F2, F4, F5 and F6: each answer you give outside a drill enters the snapshot verbatim and the rows and banks that draw on it regenerate
- Whether the staff engineers would sit on your squads or beside them: Thursday's persona weights and F1 to F3 change
- The recruiter's focus areas for Tuesday or Thursday, and any pre-work: a graded-deliverable section for each one declared; usually one email to the recruiter
- Interviewer names: an interviewer read, reweighted personas, and reverse questions tied to each person's path
- Larkfield's published values page, pasted: the Monday values cheat sheet, with a story or selection scaffold per value
- Search access: the four searches above would run, giving a grounded values map, loop check, strategy brief and a representative JD; a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, is offered once on top, and runs only if you say yes
- A tuesday-dossier.md from an earlier evaluation of this role would supply verified evidence and a named objection; it is never required
