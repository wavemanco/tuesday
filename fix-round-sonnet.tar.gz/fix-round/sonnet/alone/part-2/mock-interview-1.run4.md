I've read the skill's rules and I'm now running the research step. That means searching for Northwind's values and interview loop and for Dan's public footprint, then writing the pack.
Web search was refused, so I'm building the pack from what you gave me. I'll record each refused search in the Sources section.
The prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-1-denied-1f31554b/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

It has 21 questions across seven personas, built for a peer round with Dan as a single 60-minute conversation. Web search was refused. Northwind's values, its interview loop and Dan's public footprint are therefore not researched. The pack rests on your notes, and the Sources section says so.

Say the word and I'll play Dan as the Skeptic on D1, the "no sales-ops or quota-setting" question. The pack names it as the highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Did the recruiter say anything about the focus, the format, or an exercise to prepare? If so, I'll add a build section for it and reweight the personas.
2. Can you paste the full JD text and Priya's CV, or should I proceed without them? Her CV sentences would replace the single-line summaries I quoted, and the full JD would catch any mid-list requirement the highlights dropped.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer, both reporting to the same VP. **Format:** one 60-minute conversation.
Built on this assumption: a peer round run as a single conversation, with no recruiter guidance on focus areas or deliverables.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Every guidance cell is speakable in 90 to 120 seconds, and anything marked "Answer slot" is for you to fill in your own words or answer with the honest branch it gives.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior demonstrates the company's published values, not generic virtue |
| EXP | Whether the background's claims survive scrutiny, including what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you can think at the company's altitude: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the actual role |

The highest-ROI prep in this pack is **D1**, the sales-ops and quota-setting objection. It is the gap your notes state outright and the one a Sales Strategy peer is best placed to press. Rehearse it until the concession is boring. The A1 to A2 chain on the ~$400M figure is the second-deepest rehearsal.

## Fit snapshot

Requirements are quoted from the JD highlights in your notes, and evidence is quoted from your notes on Priya. Where a row says "answer slot", the pack does not know the answer and will not supply one.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, the coach's notes | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, not GTM ownership, and nothing inspected sits behind it. The words stay there: "For nine years I worked in product strategy & ops at a large consumer-tech company." Answer slot: the JD's GTM line makes a probe on how a product reached customers likely. If any of your product strategy work shaped that, say which piece and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, the coach's notes | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | Your material says you proposed the change and that it was credited with the uplift, not how the figure was counted or who built the change. The words: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slots: the figure raises how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Separately, the JD's lifecycle line makes a probe on whitespace work likely. If any of your analysis looked at where revenue was not yet captured, say what and what part was yours; if none did, say so plainly and say how you would start |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, the coach's notes | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap in wording, but a skill claim with nothing inspected behind it, so expect "show me one." Lead in the quote's terms: "I'm skilled in SQL and Tableau." Answer slot: name one analysis you ran yourself and what it showed, in your own words; if you did not run it yourself, say so plainly |
| F4 | "partner-motion design experience required" — JD highlights, the coach's notes | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a partner-level revenue model used in carrier negotiations, not the design of a partner motion. The words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe likely. If any part of how the model was used in those negotiations was yours to set, say which part and how you decided; if none was, or it was not yours, say so plainly and describe the model |
| F5 | "strong cross-functional influence" — JD highlights, the coach's notes | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap in wording, but a CV-style line with nothing inspected behind it. Lead with it in its own terms: "I set annual volume targets with cross-org consensus." Answer slot: expect "how did you get the consensus?" If the orgs disagreed, say about what and what part was yours; if they did not, say so plainly |
| F6 | "AI experience a plus" — JD highlights, the coach's notes | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | Your material says daily use and does not show what for. The words: "I use AI tools daily." The derivation: the JD's AI line, and the Compass launch in your research note, make a probe on what you do with them likely. Answer slot: name the tools and the tasks in your own words; if it is day-to-day use rather than work on AI products, say so plainly |
| F7 | Sales-ops and quota-setting experience — named in the coach's notes, not in the JD highlights | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and your notes state it. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to quota work, and nothing added to make the gap feel smaller. F5 is the nearest thing in the material and is not equated with it |

## Reading the interviewer

Public footprint only, and for Dan that is the profile description in your notes. Nothing was independently researched (see Sources).

| Observation | Source | What it means for the conversation | Provenance |
|---|---|---|---|
| Profile self-describes as "relentlessly data-driven" | Your notes on Dan's profile | Expect every number to be pressed to its inputs. A figure you can't explain costs more than one you flag as uncertain | [grounded] |
| Career spine is pricing and monetization, with one early-stage-startup chapter | Your notes on Dan's profile | Pricing, packaging and unit-economics framings are his native language, so a case in that register is the likelier case | [grounded] |
| Dan and Priya report to the same VP | Your notes | He is pricing what the hire adds to or takes from his own work, so reciprocity matters as much as capability | [grounded] |
| Shared vocabulary: revenue and monetization | Dan's spine above, paired with F4's "built a partner-level revenue model used in carrier negotiations" and F2's "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the words revenue model and ARR in their own terms. The pairing is vocabulary, not a shared career jump | [inferred] |
| Startup chapter | Your notes | No row of the fit snapshot carries Priya's side of a builder-to-scale jump, so it is not offered as a bridge. It stays in the reverse questions only | [inferred] |

## Persona table

Relationship prior for a peer round: Peer Evaluator and Data-Driven Prober. Adjusted by Dan's signals, then by the loop. Your own words establish the loop as one session, so no archetype fallback applies, and the only loop source is your note.

| Persona | Weight and depth | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| A. Data-Driven Prober | Highest, 5 questions | Collegial but literal: inputs, denominators, "which assumption would you defend least" | High. Peer prior, raised by the "relentlessly data-driven" self-description. F2 and F4 are the magnets | Know what you can say about how each number was counted, and say plainly where you do not know |
| B. Peer Evaluator | High, 4 questions | Seam-splitting, "what do you need from me", credit across teams | High. Peer prior; the shared VP makes it more likely | Reciprocity first. Offer seam principles, not a pretended seam. Disagreement answers show spine and tact |
| C. Case/Strategist | Mid, 3 questions | One live problem, probably pricing or packaging flavored | Medium. Pricing and monetization spine tilts it toward Compass packaging against bundling; a peer round makes it less central than for a hiring manager | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise |
| D. Skeptic | Mid, 3 questions | Quiet probing of the field and sales-ops credibility, then of partner-motion depth and motivation | Medium. F7 is a stated gap and F4 is a transferability row, and a Sales Strategy peer is placed to press both | One objection rehearsed until boring; concede in exact words; never claim quota work |
| E. Pressure | Low, 2 questions | A time-box or "how much was actually you", usually inside Prober delivery | Low as a style, but the content turns up inside A and D | Hold through two follow-ups, concede specifically, never fold on the core quote |
| F. Conversational | Low, 2 questions | Opening "walk me through the journey" and a casual AI question | Low as a style, near-certain as an opener in a 60-minute conversation | A 90-second arc; treat the AI question as scored |
| G. Values/Behavioral | Low, 2 questions | Behavioral prompts | Low. No Northwind values source was in hand and no values round is documented, so none is detected. These questions use persona stems and are swapped for named values once pasted | A selection scaffold with an honest branch |

## Question banks

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "That ~$400M ARR uplift your change was credited with: walk me through how it was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start with the quote at its own scope: you proposed the change, and it was credited with the uplift. Keep "credited with" in your words. Answer slot: say how the figure was counted, what it is sensitive to, and which part was yours, in your own words. If you do not know how it was counted, say so plainly and return to what you proposed | F2 holds the only quantified claim. EXP because it tests whether the number survives the denominator question. It is the first rung of a two-question chain with A2 |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move, done before he does it. Answer slot: name the assumption you would defend least, in your own words; if you do not know what the figure rested on, say so plainly and say what you would check first. Never name an assumption you cannot repeat under a second question | F2 again, at the second level of depth a Prober goes to. EXP because it scores whether you know your own number's limits |
| A3 | "Walk me through the revenue model you built for those carrier negotiations. What part of it would you trust least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | The beats are the ones the quote states: a revenue model, at partner level, used in carrier negotiations. Answer slot: expect questions on what went into it and what it was sensitive to. Say in your own words what you know; if you do not know a detail, or a piece was someone else's, say so plainly and return to the model | F4 is the other row a Prober will open. EXP because it tests attribution and depth on a built artifact |
| A4 | "Walk me through an analysis you ran yourself in SQL and Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | You say you are skilled in SQL and Tableau. Select one analysis you ran hands-on, with a question, a data source, and what the result showed. Rehearse it as 90 seconds from question to finding. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one | F3 is the JD's named tooling requirement and Dan describes himself as data-driven. JD because the requirement is in the posting; the open-prompt form lets you choose the instance |
| A5 | "Enterprise expansion is a stated priority. If I hand you account data with usage and contract fields, how do you find the whitespace?" | CASE | [grounded] | A structured live answer, no past claim. Clarify first: how land, adopt, expand and renew are defined in the data and what counts as an expanded account. Then segmentation, the approach, the metrics and the risks. Name the weakest assumption of your own approach. Challenge one premise respectfully | Covers the JD's whitespace line and the enterprise-expansion priority in your research note. CASE with a Prober's delivery because he will want the logic, not the answer |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Offer principles, not a pretended seam. For example, decision rights by type of question, shared definitions for the data both teams use, and a named path to the VP when you still disagree. Say you would like his view on where the seam sits today. The question needs no claim about your past, so the guidance makes none | The peer relationship makes this near-certain. JD because the seam is part of the role's cross-functional line; `[generic]` because it is a pattern, not a fact about Northwind |
| B2 | "Tell me about a time you got stakeholders from different orgs to agree on a number." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on the sentence: annual, volume targets, cross-org consensus. Tell those beats in your own words. Answer slot: if the orgs disagreed, say about what and what part was yours; if they did not, or someone else drove it, say so plainly and stay with the targets and the consensus | F5 is the evidence for the cross-functional influence line. EXP because the probe is how the consensus actually happened |
| B3 | "What would you need from my team in your first month, and what could you do for us?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity. What you need: how his team's data and planning definitions work. What you offer stays at the scope of the quote: hands-on SQL and Tableau analysis, offered as a first-month task and not as a prior accomplishment. Ask him what he would most want analyzed | The reverse-direction question a peer asks to price your cost to his team. JD because it tests the cross-functional line; the guidance claims only F3's wording |
| B4 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Principle first: credit named by contribution, and credit given before it is asked for. Then a selection scaffold: choose one shared piece of work where you can say who contributed what. Your figure's own wording, "credited with", is useful: you can say what you proposed without claiming what others built. Answer slot: if others built or measured it, say so plainly; if you cannot say, say so | A stem from the peer persona. VAL because it scores disagreement and credit style with equals; the figure makes the question land on F2 |

### C. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor is bundling competing capability into its suite. How would you price and package Compass against that?" | CASE | [grounded] | Clarify first: who buys Compass, whether it sells to existing enterprise customers or new ones, and what the objective is for the first year. Then options such as standalone, tiered, usage-based and bundled with core product, with the trade-off of each, the metrics you would watch and the risk of each. Say plainly that you do not know Northwind's pricing today. No past claim | Bundling and Compass come from your research note. CASE because it is a live problem in Dan's native pricing and packaging register |
| C2 | "Sketch the GTM plan for one new product line. What do you need to know first?" | CASE | [grounded] | Clarify, objective, segmentation, approach, metrics, risks, thinking aloud. Name what you would need first and from whom. The JD's two-product-lines line is the source; the guidance makes no claim about your past | Covers the JD's headline responsibility. CASE because the structure, not the plan, is scored |
| C3 | "Northwind is pushing enterprise expansion and profitability at once. Where do those pull against each other in a GTM plan?" | CO | [grounded] | Name the tension in general terms: reach and growth against efficiency and cost of acquisition. Say what you would want to see before choosing a side, such as payback and discount levels, without claiming to know Northwind's numbers. Offer a view, then flag the assumption it rests on | The two priorities are in your research note. CO because it tests whether you can think at the company's altitude |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see sales-ops or quota-setting in your background. How would you work alongside my team on that?" | JD | [grounded] "No classic sales-ops or quota-setting experience" and "set annual volume targets with cross-org consensus" | The deepest rehearsal in the pack. Hold: your words are "I don't have classic sales-ops or quota-setting experience." Say it first, before he asks twice. Limit, stated early: the nearest thing in your material is that you set annual volume targets with cross-org consensus, and you are not claiming it is the same work. Ramp plan, said as a plan: ask his team how territories and quotas are built, learn the planning cycle, and ask which definitions to adopt. Follow-up ladder: (1) "What is the closest thing you've done?" Answer from the quote and stop. (2) "Why should I trust your judgment on field-facing GTM?" Hold on what you stated, concede the gap in the same words, return to the plan. (3) "What if you're wrong?" Say what you would check and who you would ask. Never claim quota work and never add to the quote | F7 is the stated gap and F5 is the nearest adjacent evidence, so this objection arrives in some form from a Sales Strategy peer. JD because it scores the role's fit; the deepest rehearsal because the answer is the one that is easiest to get wrong by stretching |
| D2 | "Partner-motion design is a hard requirement. What part of it have you owned yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of how the model was used in those negotiations was yours to set, say which part and how you decided, in your own words; if none was, or it was not yours, say so plainly and describe the model. Hold through two follow-ups by returning to the model, never by adding to it | F4 is where the JD's partner requirement presses hardest. JD because it scores the stated requirement; the question allows the premise to be false |
| D3 | "You've spent nine years in consumer tech. Why B2B data infrastructure, and why now?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The pack cannot supply your reason. Build it in three parts: what draws you to this role, said in the JD's own terms; why now; and what you would be learning. Do not run down the previous employer. Answer slot: say your reason in your own words; if your interest in B2B is recent, say so plainly and say what you have done to learn it | The motivation probe is a Skeptic staple, and F1 raises it by the move from consumer to B2B. JD because it scores consistency of motive with the role |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's carried a quota?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations", "set annual volume targets with cross-org consensus", "skilled in SQL/Tableau", and "No classic sales-ops or quota-setting experience" | Pause, restate, then hold-then-concede. Hold with what you stated: a partner-level revenue model used in carrier negotiations, annual volume targets set with cross-org consensus, and SQL and Tableau skills. Concede in your own words that you have no classic quota-setting experience. Do not fold the core claims to restore harmony | A time-boxed stem built from the F7 gap. JD because it scores fit for the stated requirements; Pressure because it tests composure |
| E2 | "That uplift. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Anchor in the sentence: you proposed the change, and the uplift was credited to it. Answer slot: if others built, shipped or measured it, say so plainly and say what you did; if you do not know how the credit was assigned, say so. Hold through two follow-ups and concede only what you cannot back | F2's attribution is the likeliest pressure point. EXP because it tests honest attribution, delivered under pressure |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc on the quote's beats: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Land on why this role, in your own words. Answer slot: the reason for the move is yours to say; if it is still forming, say what draws you and what you want to learn | The near-certain opener. EXP because it is the CV in spoken form, scored on economy |
| F2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Name the tools and what you use them for, in your own words. Answer slot: if it is day-to-day use rather than work on AI products, say so plainly, and say what you are curious about in Compass. Do not describe building anything you did not build | The JD's plus-skill asked casually, which is how it is usually scored. `[inferred]` on the derivation in F6; JD because the posting names it |

### G. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem, because no Northwind values were in hand. VAL because it tests behavior against a generic virtue until the company's values arrive |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the metric and the customer pointed different ways, and say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for a values-style prompt, `[generic]` for the same reason. A strong customer-first story also mirrors a pricing-minded peer |

### Requirement coverage

| JD requirement (as quoted in F1 to F6) | Covered by |
|---|---|
| "own GTM strategy for two new product lines" | C1, C2, C3, F1, D3 |
| "identify whitespace across land/adopt/expand/renew" | A5, C3 |
| "run independent analysis in SQL and Tableau" | A4, B3 |
| "partner-motion design experience required" | D2, A3 |
| "strong cross-functional influence" | B1, B2, B4 |
| "AI experience a plus" | F2, C1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent your career on pricing and monetization, with one early-stage chapter. What did that chapter change about how you work with a go-to-market team?" | Tied to Dan's own path, so it turns the interview into a peer conversation. It signals you read him, not just the company |
| R2 | "What is one thing a new peer could do in their first month that would genuinely help your team?" | The reciprocity question for a peer round. It shows you are pricing your load on his team, not only your needs |
| R3 | "Where does Sales Strategy's work end and Emerging Products GTM begin today, and where is that seam still unsettled?" | Invites him to describe the seam, which you offered principles for in B1 |
| R4 | "Which of the two new product lines has the least obvious path to its first enterprise expansion, and what data do we have on it?" | Takes the JD's two-line scope seriously and speaks to his data-driven side |
| R5 | "How does bundling by larger platform vendors show up in the deals your team sees?" | Uses the competitive threat in your research note and asks for what only the field sees |
| R6 | "How will you and the VP judge this role at six and at twelve months, in numbers you would look at?" | Turns the role's success into measurable terms, which a data-driven peer will respect |

## Prohibited claims

Not coached in any cell of this pack. Built from the fit snapshot before the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove or generated the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: you proposed the change and it was credited with the uplift. The limit is the pack's observation: the material does not say who built it or how it was counted. A1, A2 and E2 stay inside that |
| Led or conducted the carrier negotiations | Inflated form of F4 | F4's quote at its own scope: a revenue model used in carrier negotiations. The material does not say what part of the negotiations was yours. D2's slot stays inside the model |
| Designed or ran a partner go-to-market motion | Inflated form of F4 | The model, as above. The limit is the pack's observation: the material says a revenue model, not a motion |
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. The material does not say GTM was part of it |
| Built, shipped or led AI products | Inflated form of F6 | F6's quote at its own scope: daily use of AI tools. The material does not show product work |
| Has done sales-ops or quota-setting work | Negative stated in the coach's notes, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |

## Sources

Provided documents: the coach's notes, which hold the role and JD highlights, the candidate summary, the interviewer profile description, and the research note on Northwind's priorities (enterprise expansion, the Compass AI copilot launch, reaching profitability, and bundling by a much larger platform vendor as the main competitive threat).

Searches sent, all refused by the host:
- "Northwind Data company values" — refused
- "Northwind Data interview process strategy GTM" — refused
- "Dan Kovac Northwind Data Director Sales Strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Search refused. It would have given the published value names for a values cheat sheet and named VAL questions; G1 and G2 use persona stems until they are in hand |
| 2. Northwind interview process | unavailable | Search refused. It would have confirmed the loop and moved persona weights; the weights rest on your own description of one peer conversation |
| 3. Northwind strategy and recent news | skipped | Your research note supplies the priorities and competitive threat that feed A5, C1 and C3; its date is not stated |
| 4. Dan Kovac at Northwind | unavailable | Search refused. It would have added public talks and writing to the interviewer read, which rests on the profile description in your notes |
| 5. Representative JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions; full text would upgrade them |

## Upgrade menu

- Full JD text → F1 to F6's requirements become full-sentence quotes, and any mid-list requirement the highlights dropped gets its own question
- Priya's CV → each row's single-line evidence becomes her own CV sentences, and the rows graded `medium` for lack of anything inspected can be reconsidered
- Recruiter's note on the format or any announced exercise → structure for a graded deliverable if one exists, and a check that the persona weights match the conversation
- Web search access for Northwind's values, loop and Dan's public talks → a values cheat sheet, loop-based persona weights, and a reverse question drawn from his writing
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes) → a Northwind strategy brief, a grounding section, and sharper C1 and C3
- The date of your research note → whether its priorities are current enough to rely on
- Priya's answers to the slots in A1, A2, D2 and F2 (outside a drill) → `[grounded]` story beats in place of slots
