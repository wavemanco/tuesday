Bash edits need approval here, so I'll use the Edit tool for these four fixes.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-5-denied-c89191c3/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It has 18 questions, a build section for the 15-minute POV, and a four-hour triage order.

I built it for a two-person panel (Deepa as future manager, Ross on commercials) using only your message and the recruiter's quoted email. Web search was refused in this session, so I ran no research on Kelverton, the interviewers or a representative JD. The market report also didn't reach me, so nothing draws on it. The pack says this in its Sources and upgrade menu.

- **Highest-ROI prep:** B1, "You've never sold into rail and you've never carried a direct quota, so why should we believe you?" Both gaps come from your own words. The pack has you concede them plainly, then hold only what you said: nine years in partnerships, the ISV channel, and the bus and light rail network planning.
- **Ross's likeliest target:** the "roughly £4M of influenced revenue" figure (C1, C2, D2). The guidance has you keep "influenced" attached and say plainly if you don't know how it was counted.
- **POV:** it has three thesis options, each with a concession, and an anti-pick. Because the panel's own strategy team wrote the report, you bring one item from it and then say where you depart. The last three minutes land on what it means for the operators.

I can play the Skeptic on B1 with live follow-ups, which is the question I'd drill first. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Can you paste the JD, or tell me to carry on without it? With it, the requirement rows quote its own lines and I add questions for anything the recruiter's email didn't cover.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, Tuesday. Panel of two, 60 minutes: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director), as the recruiter's email gives them. The first 15 minutes are a spoken POV with no slides; the rest is Q&A, with Ross pushing on commercials.

Built from your message and the recruiter's quoted email only. No JD was supplied, no web research ran (see Sources), and the market report's text did not reach this conversation.

## 1. How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type tag | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none banked: no values source in hand) |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | The stated job, including its gaps |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem |

Provenance labels: `[grounded]` traces to something you or the recruiter wrote; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about Kelverton or about you. An answer slot is an instruction for the interview, not a question for you.

## 2. Prep triage (four hours)

| Order | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 60 min | Choose one thesis, one concession and one anti-pick for the POV; write the 15-minute shape in your own words | Section 4, A2, A3 |
| 2 | 60 min | Say the POV aloud twice, timed to 13 to 14 minutes, ending on what it means for the operators | Section 4, D3 |
| 3 | 45 min | Rehearse the objection aloud with three follow-ups, until the concession is boring | B1, D1 |
| 4 | 30 min | Rehearse the figure under questioning: how it was counted, what it is sensitive to, what was yours | C1, C2, D2 |
| 5 | 30 min | Commercials: the quota answer and the investment case | C3, C4 |
| 6 | 15 min | Choose three reverse questions | Section 7 |

Everything else is insurance: A1, A4, A5, B2 to B4, E1, E2 are worth one read-through if time remains.

## 3. Fit snapshot

No JD was supplied, so requirements come from the recruiter's email, quoted, or are plain prose labelled `[generic]`. No requirement in the material is a gate (a term such as authorisation, location or pay), so no row is a `hard_gate`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, with nothing about operators, so the words stay at the channel: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: the recruiter's "operator partnerships" makes a probe on what carries across likely. If any of what you did on the channel carries over to operators, say which and why, in your own words; if little does, or it was not your part, say so plainly and stay with the channel |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | The quote's specific part is five years in transport consulting, in bus and light rail network planning; its vague part is "the operator world from the other side", which does not say which operators or which side. Keep the words at the network planning: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: if that work put you in front of operator teams, say who and what your part was, in your own words; if it did not, or the part was not yours, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | Your material says influenced revenue and no direct quota, and the words stay there: "I've never carried a direct quota, only influenced revenue." Answer slot: Ross's push makes a probe on how the roughly £4M of influenced revenue was counted likely. Say how it was counted, what it is sensitive to, the assumption you would defend least and which part was yours, in your own words; if you do not know how it was counted, say so plainly and stay with the figure as you gave it |
| F4 | Experience selling into rail operators (role-family requirement, no source quoted) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan in your own words and never as a past. Nothing added to make the gap feel smaller |
| F5 | "no slides needed, just talk us through it" — recruiter's email | none given | none | [grounded] | discovery | Your material does not show whether you have given a spoken POV to a senior panel. The format is the recruiter's, so a spoken 15 minutes is certain. Answer slot: if you have done something like it before, one line saying where is enough, in your own words; if you have not, say nothing about it and rehearse the shape in Section 4 aloud |

## 4. Graded deliverable: the 15-minute POV

The brief, in the recruiter's words: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

Settle one thing in your first 30 seconds: say aloud what you take "operator partnerships" to mean, and carry on. The phrase can be read more than one way, and an assumption said aloud is cheaper than a misread one.

### Facts to build on

| Fact | Source row | Quoted evidence |
|---|---|---|
| You ran an ISV channel at a payments company | F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." |
| You have five years in bus and light rail network planning | F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." |
| You have influenced revenue and no direct quota | F3 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." |

### Thesis options

Each is a choice you would defend, not a finding. Pick one, with its concession.

| # | Thesis | Provenance | Rests on | Mandatory concession | If it works, operators see |
|---|---|---|---|---|---|
| T1 | Fewer, deeper operator partnerships: concentrate effort on a small number of operators rather than the whole base | [generic] | A choice about focus, no claim about you | It gives up reach and concentrates dependence on a few operators | A named counterpart and shared measures, not only a supplier relationship |
| T2 | Build a partner ecosystem around the operator, so operators get more from the product without Kelverton building it | [grounded] | F1: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Your material is channel work in payments, not operator partnership work, and the model may not transfer; ecosystems also show slowly in the numbers | More choice around the core product, with Kelverton accountable for how the pieces fit |
| T3 | Make the operator's own measures the partnership's measures: agree two or three outcomes an operator's leadership already cares about and organise the partnership around them | [grounded] | F3: "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | You would have to agree what the partnership is worth commercially with Ross, not bring a number of your own | A partnership judged on outcomes they already track, so the case for it is theirs |

Anti-pick, to show judgement: say what you would not do. One candidate is "partner count as the headline target for 18 months", which is the easy number to report and the one your own F1 story invites. Concession: a count is simple to track and some on the panel may want it. Pick the anti-pick you would actually defend.

### Differentiating from the market report

Your message says Kelverton's strategy team circulated the report internally, so the panel already knows what it says. Reciting it scores as homework. Bring one item from it, in its own wording, to show you have read it, then say where your view departs and why. This pack has not seen the report, so it names no item; choose the one you can tie to a decision for an operator.

### Shape of the 15 minutes

| Minutes | Beat | Note |
|---|---|---|
| 0 to 1 | Say what you take "operator partnerships" to mean | One sentence; do not ask the panel to confirm |
| 1 to 3 | One item from the report, then your departure | Differentiation, not recital |
| 3 to 9 | Your thesis and why, with the concession said before they ask | One thesis, not three |
| 9 to 11 | The anti-pick | What you would not do |
| 11 to 14 | What it means for the operators themselves | The recruiter's requested close; one thing an operator notices early, one thing at the end of the 18 months, one thing they stop having to do |
| 14 to 15 | Stop | Do not add a new idea at the end |

## 5. Persona table

Weights follow three passes. Relationship priors: Deepa is your future manager (hiring-manager prior: Case/Strategist plus Skeptic); Ross is a Commercial Director and the recruiter says he "will push on commercials" (Prober plus Pressure prior). Interviewer signals: none, no public information was read. The loop: the recruiter's email gives one 60-minute panel session of a spoken POV then Q&A, and names no values round, so no values bank is built.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Deepa pushing on the POV: priorities, the first 30 days, an operator who is lukewarm | High: the hiring-manager prior, plus a POV on the next 18 months the recruiter announced | Clarify, then objective, segmentation, approach, measures, risks; think aloud; challenge one premise politely |
| Skeptic | The two stated gaps, F3 and F4, from either panellist | High: the same prior, and your own message states both gaps, so the objection is predictable | Rehearse B1 until it is boring; concede the two stated gaps in your own plain words |
| Data-Driven Prober | Ross on the figure: how counted, what it is sensitive to, what was yours | Medium to high: the recruiter's "push on commercials", and F3's figure invites it | Know what you can and cannot say about the count; say plainly where you do not know |
| Pressure | Ross challenging, possibly time-boxed | Medium: "push" suggests challenge, not necessarily interruption | Pause, restate, hold the quoted position through two follow-ups, concede specifically |
| Conversational | An opening "walk me through your journey" | Low to medium: an opener, but scored | A 90-second arc built from the quotes, not from the shape of a good story |
| Peer Evaluator | Not banked | Neither panellist is a peer in the recruiter's description | If the panel adds a peer, ask me to add the bank |

## 6. Question banks

### A. Case/Strategist (five questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How would you decide which operators to go deeper with, and what do you need to know first?" | CASE | [generic] | Clarify first: what "deeper" means to Kelverton and who decides. Then the objective, how you would group operators by your own criteria, the approach, the measures, the risks. Challenge one premise politely. The question needs no claim about your past, so the guidance makes none | Deepa's likeliest live problem is the POV's first decision; CASE because it scores structure, `[generic]` because no strategy brief is in hand |
| A2 | "If you could fund one bet in the next 18 months, what is it and what do you stop?" | CASE | [generic] | One bet, one stop, one concession, in that order. Use your chosen thesis and anti-pick from Section 4; the pack names none for you | Forces the POV's choice and its anti-pick; CASE because it scores prioritisation |
| A3 | "Where would you go differently from what the market report points to?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Say what you took from the report in its own wording, then your departure and why, then what you would need to see to be wrong. The pack has not seen the report and names no item. Never recite it | The report is shared with the panel, so departure with reasons scores as judgement; CO because it tests current strategy fluency |
| A4 | "What from running the ISV channel would you carry into operator partnerships, and what would you leave behind?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Story-mapped on F1: the ISV channel, and the 6 to 40, which are the beats the quote states; tell them in your own words. Say plainly what the payments setting does not share with rail; your material says channel work, not operator partnerships. Answer slot: say which part of the 6 to 40 was yours and which was shared; if you do not know how it was counted, or it was not your part, say so plainly and stay with the channel | F1 is the evidence for the POV requirement and the likeliest bridge to be tested; EXP because it tests what carries and what was yours |
| A5 | "An operator tells you the partnership is a nice-to-have. What do you do in the first 30 days?" | CASE | [generic] | Ask what would make it a priority for them before proposing anything; then what you would test, who you would involve, and what you would stop doing if it did not matter to them. End on what it means for that operator | A live problem set in the role, aimed at the "what it means for operators" close; CASE because it needs no past |

### B. Skeptic (four questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail and you've never carried a direct quota. Why should we believe you can move our operator partnerships?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | The highest-ROI prep in this pack: this question will arrive in some form. Concede first, in the exact words the quote carries: "I've never sold into rail specifically, and I've never carried a direct quota, only influenced revenue." Then hold only what the quotes carry: nine years in partnerships, the ISV channel at a payments company, and five years in bus and light rail network planning. Follow-up one, "payments is not rail": return to the channel at its own scope and concede nothing further. Follow-up two, "influenced is not sold": say influenced revenue is what you have, and never swap in "generated" or "closed". Follow-up three, "so what do you do in the first 90 days?": give a plan in your own words, naming what you would learn from operators first; a plan, never a past. Limit, said before it is asked for: your material says bus and light rail network planning, not train operating companies, so do not say you know how train operators work. Answer slot: if the consulting put you in front of operator teams, say who and what your part was; if it did not, or it was not yours, say so plainly and stay with the network planning | F3 and F4 are where the panel's scoring presses hardest, and F2 is the only operator-side evidence; JD because it scores the stated job against its gaps |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Name the one weakness that is truest, plainly, then a plan in your own words for the first 90 days. The nearest one your material carries is that you have not sold into rail. If a different gap is truer for you, use that one. If no weakness comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F4 is the likeliest honest answer; JD because it scores self-assessment against the role |
| B3 | "Why leave payments for rail-tech, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Three parts: why leaving, why here, why now. Your reasons are yours and the pack supplies none. Answer slot: if the transport consulting years figure in your reason, say how in your own words; if they do not, say so plainly and give the reason that does | The standard motivation probe; EXP because it tests whether your story is consistent across F1 and F2 |
| B4 | "What would make your own POV wrong?" | CASE | [generic] | Name the weakest assumption in your own thesis aloud before they do, then what you would watch for and when you would change course. Use the concession already chosen in Section 4 | Converts a gotcha into credibility; CASE because it is a reasoning problem on your own proposal |

### C. Data-Driven Prober (four questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say roughly £4M of influenced revenue. Walk me through how that number was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Keep "roughly" and "influenced" exactly. Answer slot: say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly and stay with the figure as you gave it. Never describe a method you did not use | F3's figure is Ross's most likely target; EXP because it tests whether the number survives |
| C2 | "In the move from 6 partners to 40, what counted as a partner?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say what counted, in your own words, and which part of the growth was yours; if the definition was not yours or you do not know it, say so plainly and stay with the quote as written | The count is the other figure in F1 and a prober pairs it with C1; EXP because it tests attribution |
| C3 | "You've told us you've never carried a direct quota. How would you hold yourself to a number here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Acknowledge in the quote's own terms: "I've never carried a direct quota, only influenced revenue." Then what you would ask to agree in the first 30 days: what the number counts, who else affects it, and which operator outcome it reflects. These are things you would ask, not things you have done | The recruiter's "push on commercials" makes this likely from Ross; F3 is the row it rests on; JD because it scores the commercial end of the role |
| C4 | "How would you make the commercial case for a partnership investment to this table?" | CASE | [generic] | Structure it: the cost, what it would have to return, the early indicators, what would make you stop. Name your weakest assumption and ask Ross to challenge it. No claim about your past is needed | Ross's likeliest live problem; CASE because it scores reasoning, `[generic]` because no commercial data is in hand |

### D. Pressure (three questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Pause and restate the question. Concede the stated gap in one sentence: "I've never sold into rail specifically." Then hold what the quotes carry: nine years in partnerships, the ISV channel, the 6 to 40. Claim no hidden edge | The pressure form of B1; EXP because it tests whether you hold without inflating |
| D2 | "That roughly £4M of influenced revenue: how much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold the sentence as written through two follow-ups. Answer slot: say which part was yours, in your own words, and where it was shared; if you do not know how the figure was counted, say so plainly. Concede the specific limit, not the whole claim | F1's headline figure under pressure; EXP because it tests attribution |
| D3 | "You have ninety seconds left and haven't got to the operators. Land it." | CASE | [generic] | Rehearse your last 90 seconds from Section 4: what an operator notices early, what changes by month 18, what they stop having to do. Stop; do not add a new thesis | Tests composure and the requested close; CASE because it is a live problem |

### E. Conversational (two questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc with the beats the quotes state: five years in transport consulting, in bus and light rail network planning; then nine years in partnerships, the last four running the ISV channel at a payments company; then why Kelverton, in your own words. Answer slot: the earlier years of the nine in partnerships are not in your material; if asked, say what they were in your own words | The warm-up is still scored; F1 and F2 give its beats; EXP because it tests whether the CV story is coherent |
| E2 | "What struck you in the market report?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | One item in its own wording, one line on what it means for an operator, and stop; the full divergence belongs to A3. The pack has not seen the report, so it names no item | A casual question on a hot topic; CO because it tests whether you read it |

### Requirement coverage

| Stated requirement (recruiter's email) | Questions |
|---|---|
| A POV on operator partnerships for the next 18 months | A1, A2, A3, A5, B4, D3, Section 4 |
| Land on what it means for the operators themselves | A5, D3, Section 4 |
| Ross pushes on commercials | C1 to C4, D2 |
| Spoken, no slides | D3, Section 4 |
| JD requirements | none, and why: no JD was supplied; see the upgrade menu |
| VAL | none, and why: no values source and no values round in the recruiter's email |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would make the first 90 days a success, in terms the operators themselves would notice?" | It carries the close you were asked to land into the Q&A |
| 2 | "How are operator partnerships measured today, and which measure are you least sure of?" | It shows you think in measures, which Ross will weigh |
| 3 | "Is this role expected to carry a number, and if so, what does it count?" | It meets the quota gap in F3 directly and on your terms |
| 4 | "Which operator relationship would you most like to be different in 18 months, and why?" | It invites Deepa to say what she wants moved |
| 5 | "What have you tried in partnerships that did not work, and what did you take from it?" | It invites candour and shows you will not repeat it |
| 6 | "What in the market report does your own team disagree about?" | It shows you read it and lets the panel argue, which reveals priorities |

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a direct quota, or sold the roughly £4M | Negative you stated, F3 | The plain acknowledgment: "I've never carried a direct quota, only influenced revenue." No slot |
| Has sold into rail | Negative you stated, F3 and F4 | The plain acknowledgment: "I've never sold into rail specifically." No slot |
| Personally signed or onboarded the additional partners | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says took it from 6 partners to 40, not who found, signed or onboarded each. A4 and C2 ask only which part was yours |
| Knows how train operating companies work, or has worked with them | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The limit is the pack's observation: your material does not say train operating companies. B1's slot stays inside the consulting work |

## 9. Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report the recruiter attached did not reach this conversation; nothing in the pack draws on its content. No dossier was present.

Searches sent, every one refused ("Claude requested permissions to use WebSearch, but you haven't granted it yet"), none retried:

- `Kelverton Rail values` — refused
- `Kelverton Rail strategy news train operating companies scheduling software` — refused
- `Deepa VP Partnerships Kelverton Rail` — refused
- `Ross Commercial Director Kelverton Rail` — refused
- `Senior Partnerships Manager rail technology software job description train operators` — refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Every call refused. Published value names would have themed VAL questions; a values sheet would still need a values round documented, which the recruiter's email does not name |
| 2. `Kelverton Rail interview process` | skipped | The recruiter's email already fixes the session count, the panel and the format, which settle the persona weights |
| 3. `Kelverton Rail strategy` and recent news | unavailable | Every call refused, and the report's text is not in hand. It would have grounded A3, E2 and the POV's one consensus item |
| 4. `Deepa` and `Ross` at Kelverton Rail | unavailable | Both calls refused. An interviewer read and a reverse question tied to each path are absent |
| 5. Representative `Senior Partnerships Manager` JD | unavailable | Refused. Requirement rows would have quoted a representative posting, labelled `[inferred]` |

## 10. Upgrade menu

- The market report's text, or its headline findings pasted in → a grounding brief, A3 and E2 become `[grounded]` on its own vocabulary, and the POV build can name its one consensus item and your departure
- The JD text → F4's requirement becomes a quoted line, and JD-tagged questions are added for any requirement not already covered
- Permission to search, which was refused this session → the five lookups above run; a deeper pass would add up to 6 more searches and 2 more fetches, at several more minutes
- Deepa's and Ross's surnames, or their profile links → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each path
- Your answers to the slots in A4, B1, C1 and C2 → rows F1 to F3 upgrade from the quotes to your own detail, and the matching guidance is rewritten around it
- The partner programme report or the revenue-attribution report behind "roughly £4M of influenced revenue", if one exists → F1 and F3 can move from `medium` towards `high`, since it is the artifact this field keeps
- A `tuesday-dossier.md`, if you have one → verified evidence and constraints would replace this pack's inferred ones
