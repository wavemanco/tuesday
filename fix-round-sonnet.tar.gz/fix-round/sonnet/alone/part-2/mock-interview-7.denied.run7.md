I'll read the reference files the skill points to before building the pack.
I'm checking the saved pack for one problem I spotted: the Peer bank's IDs (F1, F2) collide with the fit-snapshot row IDs. I'll rename the bank to G and then verify the formatting.
Shell approval is needed for that combined command, so I'll make the renames with the Edit tool instead.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-denied-f606def3/saltmarsh-games_live-operations-producer_interview_pack.md`.

I built it for a hiring-manager round with Tobias, since your note didn't say how he relates to the role. Web search was refused in this session, so nothing in the pack comes from outside what you told me. That means no values, no interview-loop structure, no strategy or product detail and no read on Tobias. The sections that depend on those are dropped or marked `[generic]`, and the upgrade menu says what pasting them in would add.

- **Pack:** 20 questions across six interviewer styles, plus a table mapping each JD requirement to the questions that cover it.
- **Highest-ROI prep:** A2, the in-app-purchase KPI question. It is the objection most likely to come up, and it targets the gap you named.
- **Next most likely:** A3 and A4, on never having led a team and on a content-drop calendar versus a live-events calendar across two titles.
- **Answer slots:** several rows (F1, F2, F3, F5, F8) are open slots rather than story maps, because your background doesn't say whether the puzzle title was live-service or who defined the retention numbers. Decide those answers before Friday.

Say the word and I'll play the Skeptic on A2 so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and has the recruiter said anything about the format or a task to prepare? Either answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager, because your note did not say. Every persona weight below rests on that assumption.
**Interview:** 60 minutes, Friday.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Every question carries both a persona (its bank letter) and a type tag.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether the claims in your background survive scrutiny, and what was actually yours |
| JD | A stated responsibility or requirement in the job description |
| CO | Knowledge of the company, its strategy and its products |
| CASE | A live problem from the role, reasoned through aloud |

Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did. Where a cell says "Answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours or did not exist.

**Highest-ROI prep: A2.** It is the objection most likely to be put to you in some form, and it is aimed at the place your material is thinnest.

## Prep triage

| Order | Do | Where |
|---|---|---|
| 1 | Say A2 aloud three times, taking the follow-ups, until the plain acknowledgment sounds ordinary | A2 |
| 2 | Write one honest sentence for each answer slot in F1, F2, F3, F5 and F8. Those sentences decide how A3, A4, A5, C1, C3 and D3 go | Fit snapshot |
| 3 | Run A3 and E2 aloud, holding to your own quoted sentences and conceding the rest | A3, E2 |
| 4 | Walk B1 and B2 aloud once each, saying the structure before the content | B1, B2 |
| 5 | Find the two Saltmarsh titles and play them, so D2 has a real answer | D2 |
| 6 | Pick three reverse questions and say them aloud | Reverse questions |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title. It does not say events, and it does not say a second title, so the words stay at the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's calendar line makes a probe on what the calendar held likely. If any of what you dropped was one-off or time-limited, say which and what part was yours; if none was, say so plainly. Expect a probe on how many titles your work covered too; say what it covered, in your own words, and if it was the main title only, say so plainly |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message, "Never led a team, and never worked on a game with in-app purchases" — your message | low | [inferred] | discovery | The calendar quote touches this requirement without showing whether it reached other disciplines, and you have stated you have not led a team. Plain acknowledgment, from your own sentence: "I haven't led a team." Answer slot: the JD's four disciplines make a probe on how updates got made likely. If the drops needed input from other disciplines, say which and what part of the coordination was yours; if they did not, or someone else handled it, say so plainly and return to the calendar quote |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the numbers; it does not say you defined them or ran a review. The words stay at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's ownership wording makes a probe on who defined the numbers and whether a review followed likely. If any of that was yours, say which part and how you decided, in your own words; if the numbers were defined by others, or no review followed, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Lead with the quote in its own terms: you wrote it, and your QA team still uses it. Your material does not say how it is run from release to release, so the words stay at having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material gives the four years and does not say whether any title in them was live-service. Answer slot: the JD's live-service wording makes a probe likely. If a title you worked on was updated on a continuing basis and you produced for it, say how, in your own words; if none was, or those years were not on such a title, say so plainly and stay with the four years as an associate producer at a puzzle-game studio |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a background line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you ran it, weekly, for the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but expect a probe on how the numbers were counted. Lead with the quote's own terms: "I presented the monthly retention numbers to the studio head." C1 rehearses the probe |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A written artifact exists in your material, but it does not show what else you have written or how it was received. Answer slot: the JD's written-communication line makes a request for an example likely. If there is a piece of your writing you can point to, say which; if the checklist is the only one, say so plainly |
| F9 | Familiarity with monetized live games, a role-family reading with no JD line behind it | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

Loop structure is not established: no source for Saltmarsh's interview process could be read. The weights rest on the hiring-manager prior, not on a documented Saltmarsh process, and they assume Tobias is that manager.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet, persistent probing of the gaps | High. The hiring-manager prior puts it first, and your own message states two gaps (F2, F9) while F5 does not show live-service work | Rehearse A2 until it is boring. Bridge only from your quoted sentences, say the limit plainly, then give a plan as a plan |
| Case / Strategist (bank B) | Live problems from the actual role | High. The hiring-manager prior puts it first, and the JD's duties (F1, F3, F4) are planning and diagnosing tasks | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise |
| Data-Driven Prober (bank C) | Asks how a number was counted | Medium. F3 and F7 both rest on "retention numbers" and the JD asks for comfort with them. No interviewer profile shows an analytics-heavy style | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| Conversational (bank D) | Friendly openers that are still scored | Medium. An opening biography question is common in any loop, and the structure here is unknown | A 90-second arc built only from your four quoted sentences. Treat casual questions about live events as scored |
| Pressure (bank E) | Time-boxed challenges, attribution probes | Low. Not part of the hiring-manager prior, though your stated gaps give an interviewer material for it | Pause, restate, hold the quoted claim through two follow-ups, concede specifically |
| Peer (bank G) | Seam-splitting between teams | Low. Tobias is assumed to be your manager, but the JD's coordination line (F2) means a design or engineering colleague could join | Offer seam principles rather than pretending to know the seam; show spine and tact together |
| Values / Behavioral | Scenarios mapped to published values | Low, no bank. No source for Saltmarsh's values or a values-style round was read, so none is detected | A1, E1 and G2 carry the behavioural ground at this weight |

## Question banks

### Bank A: Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Pick one gap and name it plainly in your own sentence: "I haven't worked on a game with in-app purchases." Then the plan, as a plan: what you would ask for and from whom in your first weeks. Do not pick a gap you cannot say plainly, and do not use the answer to list every gap | F9 and F2 are the stated gaps; JD because it scores fit against the posting, Skeptic because the interviewer is invited to find the weakness |
| A2 | "You've told us you haven't worked on a game with in-app purchases. How would you approach the KPIs this role reports on a title where purchases matter?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" and "Presented the monthly retention numbers to the studio head" | The deepest rehearsal in the pack. Beats: (1) the acknowledgment, said once: "I haven't worked on a game with in-app purchases." (2) What your material does carry, at its own scope: "I presented the monthly retention numbers to the studio head." (3) The plan: what you would ask first, such as which numbers each title already reports, how each is defined and who owns the definitions. (4) The concession, specific: this is the part you would be learning, and you would rather say so than guess. Follow-up 1, "how soon would you be useful?": give a commitment you would actually make, not a figure chosen to please. Follow-up 2, "doesn't that matter more than your calendar work?": concede that it is a gap, hold the quoted sentence at its scope, add nothing to it. Follow-up 3, "who would you lean on?": say you would ask who owns those numbers today, which is a plan and not a claim | F9 is the gap you stated, aimed at the KPI work in F3, in a role where the KPIs are reported. This is the pack's inference about the likeliest objection; JD because it scores the KPI requirement |
| A3 | "You've told us you haven't led a team, and this role coordinates four disciplines on every update. What makes you think you can get design, art, engineering and community aligned?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" and "Never led a team, and never worked on a game with in-app purchases" | Open with the acknowledgment: "I haven't led a team." Then the quoted ground: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if the drops needed input from other disciplines, say which and what part of the coordination was yours, in your own words; if they did not, or someone else handled it, say so plainly and return to the calendar. Hold through two follow-ups by returning to the quote, never by adding to it | F2 is where the JD's coordination line meets a stated negative; JD because it scores that line |
| A4 | "You ran the weekly content-drop calendar for your main title. This role plans and runs live events across two titles. What's different about that job?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say what you ran, in those words, then say what you would ask first about the difference rather than claiming you have already done it. Answer slot: if any of what you dropped was one-off or time-limited, say which and what part was yours; if none was, say so plainly. If your work covered the main title only, say so plainly. Do not describe a second calendar you did not run | F1 is the likeliest place to be probed on scale; JD because it scores the calendar line |
| A5 | "You have four years as an associate producer at a puzzle-game studio. Which of that was live-service work, and why this move now?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Part one is F5's slot. If a title you worked on was updated on a continuing basis and you produced for it, say how, in your own words; if none was, say so plainly and stay with the four years. Part two is yours alone: say what pulled you toward live operations, tied to the JD's own wording (the calendar, the KPIs, the release checklist). If you have played the Saltmarsh titles, say one thing you noticed; if you have not, say so plainly | F5 is the row the 3+ years requirement rests on; JD because it scores that requirement, with the motivation probe a Skeptic adds |

### Bank B: Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch the calendar for the next quarter on a mobile title that's already live. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what the title needs from the quarter, what is already committed, what each discipline can take on, and how much lead time QA needs. Then objective, shape of the quarter, risks, and how you would know it worked. Challenge one premise politely. The question needs no claim about your past, so the guidance makes none | F1's requirement set live; CASE because it scores structure on a problem from the role |
| B2 | "Retention dipped 20 percent after an update shipped. Diagnose it." | CASE | [generic] | Clarify what the metric is, which players, over what window. Separate the update from anything else that changed in the period, and say what data you would ask for and from whom. Name the hypotheses before the data, and what would change your mind. No claim about your past | F7's requirement as a live problem; CASE because it scores diagnostic structure, not a right answer |
| B3 | "An event is two days from launch and QA finds a blocking bug. Engineering says the fix takes a week. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Lay out the facts you need, then the options (hold, ship reduced, ship later), who decides, what the players are told and what goes in the review afterwards. You may point to the checklist at its own scope: "I wrote the release checklist our QA team still uses." Do not say it covered this situation | F4's requirement under pressure; CASE because it is a live decision, with JD content |
| B4 | "Two titles, one community team, and two events landing the same week. How do you decide?" | CASE | [generic] | Name what each event is for, what each costs the shared team, what slipping either costs, and who owns the call. Offer a principle for the tie-break rather than a verdict, and say what you would ask the two title owners. No claim about your past | F1 and F2 meet here: two titles and several disciplines; CASE because it scores trade-off reasoning |
| B5 | "After an event ends, what goes in the post-event review, and which KPIs does it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you would want agreed before the event runs and what the review should decide afterwards; name the numbers you would ask about rather than asserting what the studio uses. Your material touches this at one point: "I presented the monthly retention numbers to the studio head." Answer slot: if any drop was reviewed afterwards and you had a part in it, say what; if none was, say so plainly | F3 is the requirement's evidence, at its own scope; JD because it scores the post-event review line, with CASE delivery |

### Bank C: Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. Which ones, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start with the sentence: "I presented the monthly retention numbers to the studio head." Answer slots, each in your own words: which measures they were; how they were counted; which assumption behind them you would defend least; which part was yours, whether producing them, choosing them or presenting them. "I don't know how it was counted" is an honest branch. Do not name a method you cannot repeat under a second question | F7 and F3 both rest on this sentence, so it is the likeliest place a prober digs |
| C2 | "Tell me about a time a retention number surprised you." | JD | [grounded] "Presented the monthly retention numbers to the studio head" | An open prompt. Pick one instance where a number moved in a way you did not expect and say what you checked and what you concluded. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I presented the monthly retention numbers to the studio head." | F7's requirement, asked as a story; JD because the JD raises comfort with retention metrics |
| C3 | "Walk me through the release checklist you wrote. What is it for, and how does QA use it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Start with the sentence: "I wrote the release checklist our QA team still uses." Say what it contains and what it is for, in your own words. Answer slot: expect a probe on how the checklist gets used; say how, in your own words; if you were not part of its use after you wrote it, say so plainly and stay with having written it. If you have changed it since, say what and why; if not, say so | F4's requirement and the sentence a QA-minded interviewer will test; EXP because it scores what was actually yours |

### Bank D: Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses" and "Presented the monthly retention numbers to the studio head" | A 90-second arc, one beat per quoted sentence: the four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the main title for the last two years, the release checklist your QA team still uses, the monthly retention numbers presented to the studio head. Close on what draws you to live operations, in your own words. Do not add a beat the sentences do not state | F5, F6, F4 and F7 are the spine of your background; EXP because it opens the scrutiny of the claims |
| D2 | "What are you actually playing these days, and what do you notice about how they run their events?" | CO | [generic] | Name one live mobile game you actually play and one thing about its event rhythm you can describe from playing it. If you play none, say so plainly and name the nearest thing you do play. Do not name a game you have not played. Play the two Saltmarsh titles before Friday so you can speak about them | A casual question about the role's core topic, which is still scored; CO because it tests homework, `[generic]` because no Saltmarsh title could be researched |
| D3 | "Tell me about a time you had to explain a number or a decision in writing to people who did not have the context." | JD | [grounded] "Wrote the release checklist our QA team still uses" | An open prompt. Pick one piece of writing someone else actually used, say who it was for, what they needed and what you wrote. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I wrote the release checklist our QA team still uses." | F8's requirement as a story; JD because the JD raises written communication |

### Bank E: Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you over a candidate who has led a team and shipped games with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years", "Presented the monthly retention numbers to the studio head" and "Never led a team, and never worked on a game with in-app purchases" | Pause and restate the question. Hold on what you have said: "I ran the weekly content-drop calendar for our main title for the last two years", and "I presented the monthly retention numbers to the studio head." Then concede specifically: "I haven't led a team, and I haven't worked on a game with in-app purchases." Do not claim you learn fast or that retention work covers monetization | F2 and F9 are the stated gaps; JD because it scores fit against the posting under time pressure |
| E2 | "That calendar you ran: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the sentence: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: which decisions about the calendar were yours, and which were made by others, in your own words; if the content was chosen by others and you ran the schedule, say so plainly. Hold through two follow-ups by returning to the sentence, never by adding to it | F1 and F6 rest on one sentence, and attribution is what a pressure probe tests |

### Bank G: Peer (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design wants a drop to slip a week and community has already announced it. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Offer seam principles instead of a verdict: who owns the call, how the cost of slipping and of shipping is made visible to both sides, and how the change is communicated. Say what you would bring the other team, not only what you need. No claim about your past | F2's coordination requirement as a collegial problem; CASE because it scores reasoning on a seam |
| G2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | An open prompt. Pick one piece of work that spanned teams, say what you contributed using "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I wrote the release checklist our QA team still uses." | F2 and F4 touch cross-team work; VAL because it scores behaviour with equals |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, B1, B4 |
| Coordinate design, art, engineering and community teams on each update | A3, B4, G1, G2 |
| Own the post-event review and the KPIs it reports | A2, B5, C2 |
| Manage the release checklist with QA | C3, B3 |
| 3+ years producing live-service games or apps | A5, D1 |
| Experience running a content calendar | A4, E2 |
| Comfortable with player-retention metrics | B2, C1, C2 |
| Clear written communication | D3, C3 |
| Familiarity with monetized live games (role-family reading, no JD line) | A1, A2, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which two titles would I run, and where is each in its life? What does each one's event rhythm look like today?" | It shows you want specifics, and the answer tells you what F1's calendar would really hold |
| 2 | "How does the team define success for a live event, and who owns that definition today?" | It goes straight at the KPI line (F3) and tells you whether the role defines the numbers or inherits them |
| 3 | "How are revenue numbers handled on the two titles, and where would this role plug into them?" | It turns your stated gap (F9) into diligence and shows you are already working out how to learn it |
| 4 | "How does the release checklist work with QA today, and where would you want it to change?" | It connects the checklist you wrote (F4) to the team's real process without claiming you know it |
| 5 | "How are design, art, engineering and community kept aligned on an update today, and what would you want a new producer to do differently?" | It asks how coordination works before assuming (F2), and it signals respect for the people already doing it |
| 6 | "What would make this hire a success at 90 days, and what is the first thing you'd want me to learn?" | It invites Tobias to name the ramp, which is where your gaps (F9, F2) will be weighed |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: your material says content drops for the main title, not events and not a second title |
| Led the design, art, engineering and community teams | Negative you stated, F2: "Never led a team, and never worked on a game with in-app purchases" | The plain acknowledgment: "I haven't led a team." No slot |
| Owned the KPIs or the post-event review | Inflated form of F3 | F3's quote at its own scope: "I presented the monthly retention numbers to the studio head." The limit is the pack's observation: your material says presented, not owned |
| Has in-app-purchase or monetization experience | Negative you stated, F9: "Never led a team, and never worked on a game with in-app purchases" | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope: "I wrote the release checklist our QA team still uses." The limit is the pack's observation: your material says wrote, not managed |

## Sources

**Provided documents:** the job description text and the background you gave in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Every search was sent and refused, so nothing from outside your message is used in this pack. Company values, loop structure, strategy and the interviewer's background are therefore not established, and the sections that depend on them are dropped or `[generic]`.

| Query sent | Outcome |
|---|---|
| Saltmarsh Games mobile studio company values | refused |
| Saltmarsh Games interview process Live Operations Producer | refused |
| Saltmarsh Games strategy news mobile titles | refused |
| Tobias Wrenfield Saltmarsh Games Head of Live Operations | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet and VAL questions if a values-style round was found; neither is in this pack |
| 2. `Saltmarsh Games interview process Live Operations Producer` | unavailable | Would have fixed the loop and the persona weights; the weights rest on the hiring-manager prior instead |
| 3. `Saltmarsh Games strategy news mobile titles` | unavailable | Would have grounded D2 and the CO side of the case bank; D2 is `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` | unavailable | Would have fed an interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is your future manager, and anything the recruiter said about format or a task to prepare: persona weights are reweighted, and any announced deliverable gets its own build section
- The company's values page and any interview-process page, pasted: a values cheat sheet if a values-style round shows up, and a loop that replaces the hiring-manager assumption
- Tobias Wrenfield's public profile, talks or posts, pasted: an interviewer read, tuned persona weights and a reverse question tied to his own career path
- The names of the two Saltmarsh titles and their store pages, pasted: D2 and the case bank become grounded in the actual products
- Your honest answers to the slots in F1, F2, F3, F5 and F8: those rows move from slots to story maps, and A3, A4, A5, C1, C3 and D3 are regenerated from your words
- The release checklist itself, and one of the monthly retention decks: F4, F3 and F7 can rise from `medium` toward `high`, since a checklist and a deck are the artifacts a producer's work leaves
- Search access: a deeper research pass is available, with up to 6 more searches and 2 more fetches and several more minutes, if you want the strategy brief and the interviewer's public footprint run
- A `tuesday-dossier.md` from job-underwriter: verified evidence, ranked weak-area strategies and an underwriter-named objection would replace this pack's inferred ones
- How many hours you have before Friday: the prep triage is resized to them
