I'll read the reference files the skill points to before building the pack.
Web search was refused, so I'm building the pack from your message alone and marking the research targets accordingly. I'm writing the file now.
Your prep pack for all three rounds is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-6-denied-f374bfdc/larkfield-systems_engineering-manager_interview_pack.md`.

It has a shared fit snapshot, a persona-weighted question bank for each round (33 questions in all), reverse questions per round and a list of claims it won't coach. I built it on the assumption that your message is the whole job description and the whole of your background. Web search was refused, so nothing in it comes from outside your message. That means there's no values cheat sheet for the Monday round and no company-strategy questions yet.

The objection to rehearse hardest is R1A2, your missing hardware-roadmap ownership. Say the limit before the Director presses on it, then hold on what you did do and concede specifically.

Say the word and I'll play the Director on R1A2 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to Word.

1. Has the recruiter said anything about what each round will assess, or whether the panel has a task such as a design exercise? A declared deliverable would add a build section.
2. Can you paste the full job description and any extra background? Whether you've worked alongside hardware or firmware teams, grown anyone on your team, or how the "about 40 interviews" were counted would upgrade rows that are currently thin.
3. Would you grant search access so I can check Larkfield's published values and recent strategy? A deeper pass would add up to 6 searches and 2 fetches and take several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Company: Larkfield Systems (industrial IoT, about 600 people). Role: Engineering Manager, two squads building device-management services, 11 engineers.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel; names not known |
| 3 | The following Monday | VP Engineering | 30 min | Skip-level; recruiter's description: "values and leadership philosophy" |

Built on one assumption: the role description in your message is the whole of the JD, and your message is the whole of your background (no CV). Rows resting on thin material say so.

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. The guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and leadership philosophy, not generic virtue |
| EXP | Whether what you say about your own work survives follow-up; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

Where guidance says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that it was not yours or did not exist. Neither branch is a failure.

## Prep triage

1. Before Tuesday: say R1A2 aloud until it is boring. It is the highest-ROI prep in this pack. Then R1A3 and R1D1.
2. Before Tuesday: answer the slots on R1B3 and R2B1 in your own words. The 60% figure appears in all three rounds, so settle how you will talk about it once.
3. Between Tuesday and Thursday: R2A1, R2A4, R2B2, R2B3. Staff engineers will probe the technical and hiring content.
4. Before Monday: draft the one-sentence leadership philosophy for R3A1 in your own words, then R3A2 and R3C1.
5. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements quote your role description. Evidence quotes only your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your role description | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says one team of six, not two squads, and nothing in it covers the device-management domain: your message says you are at a payments company. Words stay at that scope: three years as a team lead of six. Answer slot: the role names two squads, so expect a probe on leading more than one team at once. If any of your work spanned more than the six you led, say what and how, in your own words; if none did, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" — your role description (hiring) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | presentation | Lead with the loop in the quote's own terms: you run it, for backend roles. The quote does not say who makes the hire decision, and the pack does not either. The figure raises the defend-the-number slots: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words, or say plainly you do not know how it was counted |
| F3 | "own delivery, hiring and growth for 11 engineers" — your role description (delivery) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote is a reliability quarter, not ownership of a delivery roadmap, and the words stay at its scope: the burden dropped after you pushed the quarter through. The quote says after, and the pack does not turn it into because. The 60% raises the same four defend-the-number slots as F2's figure. Answer slot: the role's delivery line makes a probe on what the quarter displaced likely. If something was deferred, say what and who agreed, in your own words; if nothing was, or that call was not yours, say so plainly and stay with the quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" — your role description (growth) | none given | none | [grounded] | discovery | Your material does not show anything on growing engineers. Answer slot: the role names growth, so expect a probe on how you develop people. If you have grown anyone, say who and how, in your own words; if it was not part of what you did, say so plainly and return to the team of six you led |
| F5 | "partner with hardware and product on roadmap" — your role description (hardware) | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The pack's own observation: your material says owned, and is silent on working alongside hardware teams, which the upgrade menu asks about |
| F6 | "partner with hardware and product on roadmap" — your role description (product) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | discovery | The quote touches roadmap tension without showing who the pressure came from. Answer slot: the role names product partnership, so expect a probe on a roadmap disagreement. If someone specific pressed and you made the case for the quarter, say who and how it was agreed, in your own words; if the pressure was general, or there was no particular counterpart, say so plainly and stay with the quarter |

Your message also says "I've never managed managers". The role description does not say whether the squads have leads, so this is carried as a prohibited claim and a reverse question rather than a row.

## Prohibited claims (not coached)

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated | "I've never managed managers" — your message. No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | "I've never owned a hardware-adjacent roadmap." No slot |
| Has led two squads or multiple teams | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation: your material says one team of six |
| Owns hiring decisions or headcount | Inflated form of F2 | F2's quote at its own scope: "I run our hiring loop for backend roles". Your material says the loop, not who decides |
| Personally conducted or hired from the 40 interviews | Inflated form of F2's figure | The quote at its own scope: "about 40 interviews last year". Slots ask only how it was counted and which part was yours |
| The reliability quarter caused the 60% drop; owned team delivery | Inflated form of F3 | F3's quote at its own scope: the burden dropped after you pushed the quarter through |

## Persona weights by round

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 | Skeptic | Probes the two gaps you named: hardware roadmap, managing managers | High. A hiring manager is derisking gaps (relationship prior), and you named both gaps yourself | Rehearse R1A2 until boring; say the limit before they ask; ramp plan as a plan |
| 1 | Case/Strategist | Live problems from the squads' actual work | High. Hiring-manager prior; the role is device-management services | Clarify, objective, options, decision, risks; challenge one premise |
| 1 | Conversational | Opening biography; hiring-loop chat | Medium. 45 minutes with your future boss opens casually and is still scored | 90-second arc from your own quotes |
| 1 | Pressure | Short-clock challenge on the gaps and the 60% | Low. Prior for a hiring manager, not for a Director meeting a would-be report | Hold-then-concede, anchored in your quotes |
| 2 | Peer Evaluator | Seam questions between squads, staff engineers and product; what you need from them | High. Staff engineers and a PM are pricing what you cost and add to their work. Panel rule: blend each member's top two personas. Names unknown, so assigned by role | Reciprocity; principles over pretending to know the seam |
| 2 | Data-Driven Prober | Staff engineers probe the 60% and 40 figures and what the quarter changed | High. Technical staff reading your claims closely | Name how each figure was counted, or say you do not know |
| 2 | Case/Strategist | Prioritization and rewrite-versus-roadmap problems | Medium. Live problems fit a 60-minute panel | Same structure as round 1 |
| 2 | Values/Behavioral | PM asks about disagreement with product | Medium. Cross-functional prior | Story from your quote or the honest branch |
| 3 | Values/Behavioral | Leadership philosophy, hiring and growth questions | High. Recruiter's description of the round: "values and leadership philosophy" | Philosophy in one sentence of your own, then examples at their own scope |
| 3 | Pressure | Time-boxed risk and fit questions | Medium. Skip-level prior; only 30 minutes | Pause, answer in thirty seconds, hold then concede |
| 3 | Case/Strategist | One altitude question on org shape | Medium. Executive prior | Think aloud; ask what you would need to know first |
| 3 | Conversational | Closing questions about the next three years | Low | Short, honest, no claims |

The loop is established by your own words: three sessions, who runs each, and their lengths. No archetype fallback was used.

## Round 1: Director of Engineering (45 min)

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1A1 | "You'd lead two squads and 11 engineers. What's the biggest step up from where you are now?" | JD | [grounded] "3 as a team lead of 6" | Name the step in the quote's terms: three years as a team lead of six, now two squads. Answer slot: if any of your work spanned more than the six, say what and how; if none did, say so plainly and stay with the team of six. Then one sentence on how you would ramp, said as a plan | F1 is the gap on the headline requirement; JD because it scores the stated scope, Skeptic delivery because it asks you to name your own weak point |
| R1A2 | "You haven't owned a hardware-adjacent roadmap, and partnering with hardware is half this job. Why should I trust you with it?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | **Highest-ROI prep in the pack.** Open by saying the limit before they press: "I've never owned a hardware-adjacent roadmap." Follow-up 1, "Then why you?": hold on what your material carries, "I run our hiring loop for backend roles" and three years as a team lead of six, and let them draw the inference. Follow-up 2, "What will you get wrong in the first 90 days?": concede one specific thing in your own words; the pack will not name it. Follow-up 3, "We could hire someone who's done it": concede it is a fair alternative, do not argue it, and return to your plan: name the first two or three things you would learn about how the hardware side plans, and who you would ask | F5 is a stated negative on the role's central partnership, and a hiring manager for industrial IoT will ask this in some form. JD because it scores a stated requirement; it gets the deepest rehearsal because its answer is mostly candor |
| R1A3 | "You haven't managed managers. How would you work with whoever leads each squad?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Plain acknowledgment first: "I've never managed managers." Then ask before assuming: how the two squads are led today and what is expected of you versus them. That clarifying move needs no claim about your past. Do not describe a leadership structure you have not seen | Stated negative; the role description does not say whether the squads have leads, so the question stays open and ends in a clarifying move |
| R1A4 | "Why industrial IoT, and why leave payments?" | JD | [grounded] "currently at a payments company" | Your own reasons, specific to device management. Selection criteria: one concrete thing about the work that pulls you, and one about the current job that is not a complaint. If no strong pull comes to mind, say so plainly and describe what you want to find out. Do not claim an interest in hardware you cannot back with a next step | Motivation consistency is what Skeptic personas score; F1's domain gap makes it likely |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1B1 | "A hardware release date just moved up six weeks and both squads feed it. Walk me through your first week." | CASE | [generic] | Clarify first: what is fixed, firmware or cloud side; what the release truly needs. Then objective, options with costs, a decision you would make and what you would tell each squad, risks. Challenge one premise out loud. The question needs no claim about your past, so the guidance makes none | Live problem from the role's roadmap partnership (F5, F6); generic because it is a pattern, not a fact about Larkfield |
| R1B2 | "A fleet of devices in the field goes offline after a service update and your on-call is already worn out. How do you structure the response, and what changes afterward?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure: stabilize, communicate to affected teams, find cause, prevent recurrence. If you reach for your reliability quarter, say it at its scope: the burden dropped after you pushed the quarter through. Do not add what the quarter contained | Device-management is the role's domain; F3 is the only reliability evidence, so it is offered at its own scope |
| R1B3 | "Walk me through the reliability quarter." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Beats the quote states: you pushed a reliability quarter through; there was roadmap pressure; the burden dropped 60% after. Answer slots: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, which part was yours; the role's delivery line also makes a probe on what the quarter displaced likely. If something was deferred, say what and who agreed; if nothing was, or that call was not yours, say so plainly. "I don't know how it was counted" is an honest branch | F3 and F6 carry your headline figure and your only roadmap-pressure story; EXP because it tests what was actually yours |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with three beats the quote states: nine years in engineering, three as a team lead of six, currently at a payments company. Then your own words on why this role. Do not add a fourth beat | Opening questions are scored; F1 and F3 supply the beats |
| R1C2 | "Tell me about your hiring loop." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say what the quote says: you run it, for backend roles. Answer slots: how the 40 was counted, what it is sensitive to, the assumption you would defend least, which part was yours. If you designed the loop's structure, say how; if you inherited it, or there was no set structure, say so plainly and describe how you run it | F2 is your clearest match to the role's hiring line, so it is the most likely place a hiring manager spends time |
| R1C3 | "What are you actually playing with around device management these days?" | JD | [grounded] | Answer slot: the role is device-management services, so a casual question here is scored. If you have read, built or tried anything around it, name it in your own words; if not, say so plainly and name what you would read first | The role description's device-management line raises the topic; casual register, scored anyway |

### Bank D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1D1 | "Sixty seconds: why you over a candidate who has managed managers and owned a hardware roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Pause, restate the question. Concede both plainly in your own words: you have not managed managers and have not owned a hardware-adjacent roadmap. Hold on only what your quotes carry: three years as a team lead of six ("3 as a team lead of 6"), and "I run our hiring loop for backend roles". Do not claim to be stronger; let them judge | F5 and the stated managers negative combined into one time-boxed challenge |
| R1D2 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold: you pushed the quarter through. Concede specifically: the quote says the burden dropped after, and what else contributed is yours to say. Answer slot: which part was yours, in your own words; if you cannot separate it, say so plainly | Attribution probe on F3's figure; hold-then-concede |

## Round 2: panel, two staff engineers and a product manager (60 min)

### Bank A: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2A1 | "A staff engineer thinks a platform fix should jump the queue and product disagrees. What do you do, and what happens when we disagree in front of the team?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Offer principles, not a pretended knowledge of their seam: how the decision gets made, who owns the call, what you give each side, how you disagree privately first. If your reliability quarter applies, say it at its scope: you pushed it through against roadmap pressure. Answer slot: if you made that case to a particular counterpart, say who and how it was agreed; if not, say so plainly | F6 is your nearest roadmap-tension evidence; CASE because it is a live scenario |
| R2A2 | "What do you need from staff engineers, and what do we get from you?" | JD | [grounded] "3 as a team lead of 6" | Reciprocity: put "what you bring" before "what I need". What you bring, in quote terms: three years as a team lead of six. Your needs, in your own words: what would make it easy for them to tell you early. Do not claim to have worked with staff engineers; the quote does not say | Peer Evaluator prices the hire's cost to their load; F1 supplies the only role evidence |
| R2A3 | "How do you handle credit and ownership when work spans squads?" | VAL | [generic] | Selection scaffold: pick a time credit or ownership was contested; it needs a named stake and a clean outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stem from the Peer Evaluator persona; two squads makes it a role-live question |
| R2A4 | "Product wants a date, engineering says it is not safe. How do you decide?" | CASE | [generic] | Clarify the risk and what safe means here; options with costs; a decision rule you would use and who must agree; what you would say to each side. The question needs no claim about your past, so the guidance makes none | Role requires partnering with product on roadmap (F6) |

### Bank B: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2B1 | "Walk us through how the on-call burden number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slots: how it was counted, what it is sensitive to, the assumption you would defend least. Name the weakest assumption before they do; if you do not know how it was counted, say so plainly | F3's headline figure; Prober reads CV figures line by line |
| R2B2 | "What did you actually do in that reliability quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The quote says you pushed it through. Answer slot: what the quarter covered and which parts were yours and which were your team's, in your own words. If you set direction and others did the engineering, say so plainly | Staff engineers will test the technical content behind F3 |
| R2B3 | "How is your hiring loop for backend roles structured?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say you run it, for backend roles. Answer slot: if you set its structure, say how you did it; if you inherited it, or there was no fixed structure, say so plainly and describe how you run it. The 40 raises the four number slots | F2 is the hiring evidence, and staff engineers help hire |
| R2B4 | "Device-management services mean fleets, updates, flaky connectivity. What background do you bring to that?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say what the quote says: nine years of engineering, currently at a payments company. Answer slot: if you have built anything involving devices or fleets, say what; if not, say so plainly and say what you would learn first. Do not pull payments experience forward as if it covered devices | F1's domain gap; JD because it scores the role's technical context |

### Bank C: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2C1 | "A fleet service's load has doubled. The squad wants a rewrite; product says no. How do you decide?" | CASE | [generic] | Clarify what is breaking and what a rewrite buys; options (patch, partial rewrite, full); how you would get evidence; who decides and by when. No claim about your past | Live problem on delivery ownership (F3) |
| R2C2 | "One headcount, two candidates: a strong generalist and a firmware-fluent specialist. How do you choose?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Structure: what the squads lack now, what each hire changes, how you would test each. Where you mention your loop, say it at its scope: you run it, for backend roles. Where your own judgment about firmware is limited, say so | Links the hiring (F2) and hardware (F5) gaps in one scenario |

### Bank D: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2D1 | "Tell me about a time you disagreed with a product partner and how it ended." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The role's "partner with hardware and product on roadmap" raises it. Story map: the reliability quarter, the roadmap pressure, the burden dropping after. Answer slot: who pressed and how it ended, in your own words; if the pressure was not from a product partner, say so plainly and use the nearest thing you have. If no such time comes to mind, say so plainly, then describe how you would handle it | F6 is the only roadmap-tension evidence |
| R2D2 | "What would your engineers say about working for you?" | VAL | [grounded] "3 as a team lead of 6" | Answer slot: if you have had direct feedback, say what and from whom, in your own words; if not, say so plainly and describe how you would want to be described. Only the team of six is yours | Cross-functional panels ask this; F4 shows nothing on growth |

## Round 3: VP Engineering (30 min)

### Bank A: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3A1 | "What's your leadership philosophy, in a few sentences?" | VAL | [grounded] "3 as a team lead of 6" | The recruiter's description of this round is the raising source. Structure: one principle in your own words; what it looks like when you lead; one example at its own scope, such as three years as a team lead of six. Do not borrow a vocabulary from the role description | Round is described as "values and leadership philosophy"; F1 is the evidence base |
| R3A2 | "Tell me about a time you held a line against roadmap pressure." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story map: you pushed a reliability quarter through; there was roadmap pressure; the burden dropped after. Answer slot: what it cost and who pressed, in your own words; if it cost nothing you can name, say so plainly. Say what landed only as far as the quote does | Theme from the role's roadmap line; F3 and F6 |
| R3A3 | "How do you decide who joins your team?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | You run the loop for backend roles. Answer slot: if you decide, say how; if the call was shared or not yours, say so plainly and describe what you weigh | The role owns hiring (F2); VP asks philosophy through hiring |
| R3A4 | "How do you develop engineers, especially those who want to outgrow you?" | VAL | [generic] | Selection scaffold: pick someone you helped develop; it needs a named change, your part, and their part. If no such time comes to mind, say so plainly, then describe how you would approach it | F4 is silent; a VP asks growth as philosophy |

### Bank B: Case/Strategist and CO

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3B1 | "You inherit two squads: one ships fast and breaks things, one is cautious and slow. First 90 days?" | CASE | [generic] | Clarify what each squad is rewarded for; listen before changing; one shared standard, not a merged culture; early signals you would watch. No claim about your past | Live problem on the role's two-squad scope (F1) |
| R3B2 | "What would you want to understand about Larkfield before setting direction?" | CO | [generic] | Research on Larkfield could not run (see Sources), so this stays generic. Your questions: how hardware release cadence constrains the services, how success is measured, where the squads' dependencies are. Ask, do not assert | Executive altitude; generic until a strategy brief or search access lets it ground |

### Bank C: Pressure and Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3C1 | "Thirty seconds: the biggest risk in hiring you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Pause, then name both plainly in your own words: you have not managed managers and have not owned a hardware-adjacent roadmap. Then one sentence on how you would close each, as a plan. Hold: do not shrink either gap; concede nothing beyond them | F5 plus the managers negative, in executive form |
| R3C2 | "Why would an industrial IoT business want someone from payments?" | JD | [grounded] "currently at a payments company" | Answer slot: say what from your work you would bring, in your own words; if you are unsure how payments carries over, say so plainly and say what you would learn first. The pack does not tell you what payments taught you | Skeptic domain probe from F1 |
| R3C3 | "What do you want your next three years to look like?" | JD | [generic] | Your own words; tie to the role without claiming experience you lack. Keep it under a minute | Closing question; low weight |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Lead two squads building device-management services" | R1A1, R1B1, R2A1, R2B4, R3B1 |
| Device-management domain | R1B2, R1C3, R2B4, R2C1 |
| "own delivery" | R1B3, R1D2, R2B1, R2B2, R2C1, R3A2 |
| "hiring" | R1C2, R2B3, R2C2, R3A3 |
| "growth" | R2D2, R3A4 |
| "partner with hardware" | R1A2, R1D1, R2C2, R3C1 |
| "partner with product on roadmap" | R1B1, R2A1, R2A4, R2D1, R3A2 |

## Reverse questions

Round 1

| Question | Why it lands |
|---|---|
| "How are the two squads led today, and what would you expect of me versus whoever leads them?" | Turns the managers gap into a structural question and shows you want the setup before assuming |
| "How often do hardware dates and service releases collide, and how is that resolved?" | Goes to the hardware partnership the role names, as a learner |
| "What would success look like at 90 days and at a year?" | Gives you a standard to be held to |
| "What is the biggest delivery risk across the two squads today?" | Shows you think about delivery before arriving (F3) |
| "What is the on-call and reliability picture for these services?" | Connects to the reliability quarter you led (F3) without asserting more than it says |

Round 2

| Question | Why it lands |
|---|---|
| "What could a new engineering manager do in the first month that would genuinely help you?" | Reciprocity question for peers |
| "Where do staff engineers sit in roadmap decisions today?" | Probes the seam you were asked about |
| "How does product learn about hardware or firmware constraints early?" | Speaks to the PM and shows you are mapping the partnership |
| "What is one recent decision the squads made that I should understand?" | Invites a story and shows interest in how they decide |
| "Where do engineering and product usually disagree here, and how does it usually resolve?" | Names the tension without claiming a view of it |

Round 3

| Question | Why it lands |
|---|---|
| "What does good leadership look like here in your words, and where is the organisation still growing toward it?" | Matches the round's stated purpose and invites candor |
| "How do engineering managers here grow, from managing engineers toward managing managers?" | Addresses the managers gap as a path, not an excuse |
| "What is the hardest hardware-versus-software timeline trade-off you have had to make recently?" | Shows you want the real constraint |
| "What would make you say in a year that this hire was a mistake?" | Asks for the bar and signals you can take the answer |
| "How do the company's values show up in a decision, not just on a wall?" | Turns values into practice, ready for whatever they say |

## Sources

Provided documents: your message (role description, the three rounds, your background). No dossier was present.

Searches sent, both refused: "Larkfield Systems industrial IoT company values" (refused); "Larkfield Systems industrial IoT device management strategy news" (refused). No fetches. Nothing from outside your message is used in this pack.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | The search was refused. It would have fed the values cheat sheet, which is dropped for want of published values in hand; VAL questions are themed from the recruiter's "values and leadership philosophy" and the role description |
| 2. Larkfield Systems interview process, engineering manager | skipped | Your own words fix the loop: three sessions, who runs each, their lengths. Persona weights follow them, with no archetype fallback |
| 3. Larkfield Systems strategy and recent news | unavailable | The search was refused. It would have grounded R3B2 and a Grounding brief; both stay generic or are dropped |
| 4. Interviewer name and company | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. Representative Engineering Manager JD | skipped | The role description you gave fixes the fit rows and JD-tagged questions |

## Upgrade menu

- Full JD text: the role-description rows become quoted JD lines, and any term such as location, travel or on-site lab time would surface as a gate.
- A fuller CV or a few more details in your own words: F4 (growth) would move from none given; F5 (whether you have worked alongside hardware or firmware teams); F6 (who pressed on the roadmap and how it was agreed); F2 (how the 40 interviews were counted and who decides hires). An inspectable artifact for management work, such as the reliability quarter's plan or an on-call dashboard export, would lift F3 from medium to high.
- The Director's, staff engineers', PM's or VP's names: a public-footprint interviewer read, a reverse question tied to each one's path, and per-person persona weights in round 2.
- The recruiter's answers on what each round assesses, and whether the panel has a deliverable such as a design exercise: graded-deliverable build sections, and firmer persona weights.
- Larkfield's published values pasted in, or search access granted: a values cheat sheet with a story per value, and CO questions grounded in current strategy.
- A tuesday-dossier.md from an earlier evaluation of this role: verified evidence, allowed strategies per weak area and an evidence-derived top objection, none of which this pack has.
