I'll read the reference files the skill requires before writing the pack.
Web search was refused in this session, so the pack will rest on the JD and your background only. I'm writing it now.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-2-denied-1c2329e7/atlas-freight_operations-manager_interview_pack.md`. It has 20 questions across six interviewer styles, a fit snapshot, reverse questions and a requirement-coverage table. I built it for a hiring-manager round, since your note didn't say who you're meeting.

Web search was refused in this session. The pack therefore uses only the JD and your background, with nothing on Atlas Freight's values, interview process or strategy, and the case questions are generic. The Sources section lists the three refused searches.

The pack names the Skeptic question B1 as your highest-ROI prep. You're over 3 supervisors and the JD asks for 12 across four sites. B1 gives you the line to hold, the exact concession wording, and a ramp plan. The other gaps it prepares you for are the Power BI gap, which you named yourself, and the years-of-leadership and terminal-experience probes.

Several answers say "answer slot". That means I didn't have enough from you to script it, so you answer from your own experience or say plainly it wasn't yours.

Say the word and I'll play the Skeptic on B1 live.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting, such as the future manager, HR or someone from another team, and did the recruiter mention any focus areas? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

- Role: Operations Manager, Atlas Freight (regional logistics, 800 employees), per the JD you pasted
- Interviewer: not known. Round type and relationship not stated, so this pack assumes a hiring-manager round
- Research: company searches were refused in this session, so nothing here is drawn from the web (see Sources)

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment against the company's published values |
| EXP | Work-experience deep-dive: does the claim survive scrutiny, and what was actually yours |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Hypothetical or live problem from the role |

No VAL or CO questions appear because no published values or strategy material was in hand. Provenance labels: `[grounded]` traces to your message or the JD, `[inferred]` is a derivation, `[generic]` is a role-family pattern that makes no claim about you or Atlas Freight. Where a cell says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly the practice was not yours.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives seven years in operations and a current supervisory role, and does not show how many of those years were spent leading people. Answer slot: the JD marks 5+ years of operations leadership as required, so expect a probe on how the seven years split. If five or more were spent leading people, say which roles and for how long, in your own words; if fewer, say so plainly and say what the other years covered |
| F2 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The words stay at the quote's scope: "I'm currently a senior shift manager over 3 supervisors." The pack's observation is that your material says 3, and the JD says 12. Answer slot: if any decision about those three supervisors' work was yours to make, say which and how you decided; if none was, say so plainly and stay with the three you are over |
| F3 | "Own daily terminal operations across 4 sites" — JD | "ran the site's peak-season surge plan two years running" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The words stay at the quote's scope: "I ran the site's peak-season surge plan two years running." The pack's observation is that your material names one site and warehouse and distribution work, not terminal operations or four sites. Answer slot: the JD's terminal and four-site wording makes a probe likely. If any of your work touched terminal operations or more than one site, say which and how, in your own words; if none did, say so plainly and stay with the site you know |
| F4 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The words stay at the quote's scope: "I cut mis-pick rate 40% by redesigning the pick path." The pack's observation is that this is a mis-pick result, and your material does not mention on-time performance or cost per shipment. Answer slot: if either of those moved with this work or any other, say which and how it was counted; if neither was tracked, or it was not yours, say so plainly and stay with the mis-pick result |
| F5 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel, never used Power BI" — your message | medium | [grounded] | discovery | Your material says Excel skill, and does not show reporting built with it. Answer slot: the JD says build reporting, so expect a probe on what you built. If you built reports or tracking views in Excel, say what they showed and who used them, in your own words; if you did not, or they were not yours, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" — JD (Power BI half) | "solid Excel, never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past: for example, building the first reports in Excel, where you are solid, and moving them across as you learn the tool. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap on the Six Sigma half: lead with "green belt certified" in the quote's own terms. The pack's observation is that your material states the certification, not what it was applied to, and says nothing about Lean by name. Answer slot: expect a probe on application. If any belt method was used in your work, say which and what it did, in your own words; if the certification was not applied to a project, say so plainly |

## Persona table

Weights rest on the hiring-manager prior (assumed, since the round type was not stated), adjusted for what the fit snapshot exposes. The loop is not established by any source, so the fallback archetype is Generic, which adds no tilt. No interviewer information exists, so no signal adjustments apply. If you know something I don't, recalibrate.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A, 5 questions) | Live problems from the role: diagnose on-time, cost, a surge, a first 30 days | High: the hiring-manager prior puts it first, and the JD is a list of operating problems | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B, 5 questions) | Quiet probing of scale, years, terminal background and the Power BI gap | High: the hiring-manager prior puts it second, and F1 to F6 give it several seams to press | Rehearse B1 until it is boring: hold the quoted fact, concede the scale gap in plain words, then give a ramp plan |
| Data-Driven Prober (C, 3 questions) | Line-by-line probing of the 40% figure and of how you track your shift | Medium: a headline metric is a magnet for this style, but the prior does not put it first | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Pressure / Stress (D, 3 questions) | Time-boxed challenges on why you, how much was you, and terminal depth | Medium: the gaps invite it, but it is not the prior for this round type | Pause, restate, hold the quoted position through two follow-ups, then concede the specific limit |
| Conversational (E, 2 questions) | Friendly walk-through of the journey; casual questions about Lean | Low: the prior does not favor it, but casual questions are still scored | Prepare a 90-second arc; treat casual JD-topic questions as scored |
| Peer Evaluator (F, 2 questions) | Seam and credit questions from an adjacent leader | Low: no sign a peer is in the loop, and an operations role makes it plausible later | Offer seam principles instead of pretending to know the seam; reciprocity framing |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one of your four sites drops over a fortnight while the other three hold. What do you need to know first, and how would you diagnose it?" | CASE | [generic] | Clarify before structuring: how on-time is defined and measured, what changed, over what window. Then segment (by lane, shift, time of day, customer) and say which cut you would pull first and why. Name the metric that would tell you the fix worked and one risk of acting too early. Think aloud; no claim about your past is needed | The JD asks you to drive on-time performance (F4), and a live diagnosis shows structure rather than a rehearsed story. CASE because it scores reasoning on a problem from the role |
| A2 | "Cost per shipment has crept up over a quarter while volume is flat. Where do you look, in what order?" | CASE | [generic] | State the objective first, then the components you would split cost into and the order you would test them in, cheapest check first. Say which numbers you would need and who owns them, and name the assumption you would trust least before you have the data. No claim about your past | The JD names cost-per-shipment (F4), which your material does not mention, so this is the likeliest place to be asked to reason without a story. CASE because it is a live problem |
| A3 | "You inherit twelve supervisors across four sites and can only meet a few in week one. What do your first thirty days look like?" | CASE | [generic] | Structure by what you learn, what you hold steady and what you change: who you meet first and why, which numbers you read before opinions, what you promise to leave alone for now. A ramp plan is a plan, so say it as one. No claim about your past | The scale gap in F2 and F3 is the likeliest objection, and a credible plan is the honest answer to it. CASE with JD content because it scores the stated team size |
| A4 | "We want one weekly operations view across the four sites, ideally in Power BI. How do you decide what goes on it, and how do you get there?" | CASE | [grounded] "solid Excel, never used Power BI" | Start from decisions, not charts: a small set of measures each site agrees the definition of, with on-time performance and cost per shipment first. Then the plan: prototype in the tool you know, per "solid Excel", and say plainly "never used Power BI", with how you would learn it and by when you would trust it. Answer slot: if you have built a recurring report before, say what it showed and who used it, in your own words; if you have not, say so plainly and stay with the plan | F5 and F6 are where the JD's tooling line meets your stated gap, so this converts it into a plan. CASE with JD content because the question is the stated reporting requirement |
| A5 | "A surge hits all four sites in the same week and you have labor for three. How do you allocate it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: what you protect, what you let slip, what triggers a change, who decides. Then the connection, at the quote's scope: "I ran the site's peak-season surge plan two years running." Answer slot: if any decision inside that plan was yours to make, say which and how you decided, in your own words; if none was, say so plainly and describe how you ran it | The surge plan is your most relevant quoted experience for a multi-site operations role (F3), and the hypothetical stretches it past one site. CASE because it is a live allocation problem |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your material has you over 3 supervisors. This role has 12 across four sites. What do you expect to be the hardest part of that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Name the scale difference yourself before they do. Hold: "I'm currently a senior shift manager over 3 supervisors." Concede in these words: "Twelve is more than the 3 supervisors I'm over today." Then the ramp plan, said as a plan. Follow-up 1, "what tells me you can lead at that scale": return to the quote and the F2 answer slot, never add to it. Follow-up 2, "how would you lead people you don't see every day": a plan, naming one or two routines you would set up. Follow-up 3, "and if it doesn't work": say what you would watch and when you would ask for help. If you do not know yet, say so | F2 is the objection most likely to arrive in some form, and a calm, specific answer changes the interview. JD because it scores the stated team size; deepest rehearsal means the most follow-up levels |
| B2 | "The JD requires 5+ years of operations leadership. How many of your 7 years were spent leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: say how many years were in a role leading others and which roles, in your own words; if fewer than five, say so plainly and say what the other years covered. Do not round up, and do not call the seven years leadership unless they were | F1 is a required item the JD states, and a years figure is easy to test against a timeline. JD because it scores a stated requirement |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick one real gap and name it plainly: "I've never used Power BI" is the stated one, so say it in those words, then the plan for closing it. Calibrated candor beats listing every gap. If you pick scale instead, hold to the B1 wording and do not add to it | F6 is the one gap you stated, so it is the safest to name without inflating anything. JD because it scores a self-assessment against the listed requirements |
| B4 | "This role is measured on on-time performance and cost per shipment. Which, if either, have you worked on?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if either moved with your work, say which and how it was counted, in your own words; if neither was tracked, or it was not yours, say so plainly and return to "cut mis-pick rate 40% by redesigning the pick path". Do not claim an effect on delivery or cost that you did not measure | F4 is adjacent work, and the interviewer's wording lets the premise be false. EXP because it tests what was actually yours |
| B5 | "Why this role, why leave your current one, and why now?" | JD | [generic] | A selection scaffold: pick the real reason, tie it to something in the JD (scope, sites, supervisors), and keep it forward-looking, with nothing negative about your current employer. If no single reason stands out, say so plainly and give the one that is truest. Research was unavailable, so make no claim about Atlas Freight beyond the JD | Motivation consistency is a standing Skeptic check, and your material does not say why you are looking. JD because it scores fit with the stated role |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the sentence as you stated it. Answer slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Never explain a method you cannot repeat under a second question | The 40% is the headline figure (F4) and the first thing a prober tests. EXP because it tests whether the number survives scrutiny |
| C2 | "Over what period was the 40% measured, and what would move it?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: give the period if you know it; if you do not, say so plainly. Say what you think would move the figure, in your own words, and name the assumption you would defend least before they do. Do not supply a baseline or a timeline you cannot stand behind | The second level of the same probe, because probers go two levels deeper than the answer. EXP because it tests knowledge of your own assumptions |
| C3 | "What, if anything, do you track regularly to know how your shift is performing?" | EXP | [grounded] "solid Excel, never used Power BI" | Answer slot: if you built or kept a regular report or view, say what it showed and who saw it, in your own words, tying it to "solid Excel". If tracking was set by others, or there was none, say so plainly and say what you would track first. Do not describe a dashboard you did not build | F5 is thin on what Excel was used for, and this is how a prober asks. EXP because it tests what the reporting skill actually produced |

### D. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who already runs several sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, restate, then hold on the quotes only: seven years in warehouse and distribution operations, the surge plan you ran two years running, and the green belt. Concede the specific limit in these words: "Twelve is more than the 3 supervisors I'm over today." Do not claim multi-site experience, and do not rank yourself above the other candidate | F1, F2 and F3 are where this challenge lands. JD because it scores the requirements against a rival; hold-then-concede because composure is the point |
| D2 | "The 40% — how much of that was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence you stated. Answer slot: say which parts of the redesign were yours and who else was involved, if anyone, in your own words; if it was shared, or partly handed to you, say so plainly and return to the quote. Hold through two follow-ups, then concede only a specific, true limit | Attribution probes exist to catch inflation, and F4 is the figure they aim at. EXP because it tests what was the candidate's |
| D3 | "This is terminal operations. How much of your background is terminal work rather than warehouse and distribution?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: if any of those years involved terminal work, say what, in your own words; if none did, say so plainly and return to "7 years in warehouse and distribution ops". Then say, as a plan, what you would learn first about terminal operations. Do not call warehouse work terminal work | F3 is the seam between your quoted work and the JD's terminal wording. JD because it scores a stated requirement; pressure delivery because the question is blunt |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc built only from these five quotes, in the order that is true for you. Close with why this role, in your own words. Do not add roles, dates or outcomes the quotes do not carry | The opening question is always asked, and a prepared arc is the cheapest rehearsal (F1 to F4, F7). EXP because it tests your account of your own path |
| E2 | "Where does Lean or Six Sigma show up in your work these days, if it does?" | JD | [grounded] "green belt certified" | Lead with "green belt certified". Answer slot: if any belt method is in use in your current work, say which and what it does, in your own words; if nothing at present does, say so plainly and say what you would apply it to first, as a plan. Do not describe projects the certification did not lead to | F7 is the plus the JD names, and casual questions are still scored. JD because it scores a stated plus |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you disagreed with another team about a priority." | EXP | [generic] | A selection scaffold: pick a time with a named stake, a position you held, and a working relationship intact afterward; "we" for context, "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer-style question asked in a collegial register; your material carries no disagreement story, so it is a scaffold. EXP because it tests what you actually did |
| F2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | State your principle in your own words. Answer slot: if anyone else contributed to the pick-path redesign, say who and how you credited them; if it was yours alone, say so plainly. Never present shared work as yours | A standing peer stem, and F4's figure is the work most likely to be shared. EXP because it tests attribution honesty |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, A5, D3 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, B4 |
| "lead a team of 12 supervisors" | A3, B1, D1 |
| "build reporting in Excel/Power BI" | A4, B3, C3 |
| "5+ years operations leadership required" | B2, D1 |
| "Lean/Six Sigma a plus" | E2 |
| Headline metric: the 40% mis-pick figure | C1, C2, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How are on-time performance and cost per shipment defined and measured today, and where do the four sites differ most?" | It shows you ask for definitions before acting, which is the posture A1 and A2 rehearse, and it tells you what you would inherit |
| 2 | "What does the reporting setup look like today, and where does Power BI sit relative to Excel?" | It turns the stated gap (F6) into a conversation about the real setup rather than a confession |
| 3 | "What does the team of twelve supervisors look like, and what would you want changed in the first ninety days?" | It addresses the scale step (F2) directly and invites the interviewer to describe their own expectation |
| 4 | "How are decisions split between the sites and this role, and how much of the job is on-site versus across sites?" | It clarifies what owning terminal operations across four sites means day to day (F3) |
| 5 | "What would make you say in six months that this hire was a clear success?" | It names the scorecard in the interviewer's own terms, and the answer tells you what to rehearse next |
| 6 | "What is the biggest operational risk you see between now and the next peak?" | It signals peak planning is a live concern for you, and it invites a specific answer rather than a polished one |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team of 12 supervisors | Inflated form of F2 | F2's quote at its own scope: "currently a senior shift manager over 3 supervisors". The limit is the pack's observation: your material says 3, not 12. B1's slot stays inside the three you are over |
| Has owned operations across multiple sites, or terminal operations | Inflated form of F3 | F3's quote at its own scope: "ran the site's peak-season surge plan two years running". The limit is the pack's observation: your material names one site and warehouse and distribution work. D3's slot asks only what your years involved |
| Has improved on-time performance or cost per shipment | Inflated form of F4 | F4's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path". B4's slot asks only whether either was tracked |
| Has 5+ years of operations leadership | Inflated form of F1 | F1's quotes at their own scope: "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors". B2's slot asks only how the years split |
| Has built reports or dashboards | Inflated form of F5 | F5's quote at its own scope: "solid Excel, never used Power BI". C3's slot asks only what was tracked |
| Has used Power BI | Negative the candidate stated, F6 | The plain acknowledgment: "never used Power BI". No slot |
| Has led Lean or Six Sigma projects | Inflated form of F7 | F7's quote at its own scope: "green belt certified". E2's slot asks only whether any belt method is in use |

## Sources

Provided documents: the job description text and background you pasted into your message. No dossier, CV file, interviewer profile or recruiter guidance was provided.

Searches sent (all refused, none returned results):

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Every call was refused. It would have fed VAL questions and a values cheat sheet if a values-style round exists |
| 2. Interview process, role family | unavailable | Every call was refused. It would have fixed the loop and the persona weights, which now rest on the hiring-manager prior and the Generic archetype |
| 3. Company strategy and recent news | unavailable | Every call was refused. It would have supplied CO questions and a grounding brief, so the CASE bank is generic |
| 4. Interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting (name or title) → reweighted persona banks, an interviewer read, and a reverse question tied to their path
- The recruiter's prep email or stated focus areas → coverage of any announced deliverable or focus topic, in place of round-type priors
- Atlas Freight's published values, interview process and strategy, pasted in or fetched in a session where search is allowed → persona weights and CASE questions grounded in the company's own materials, and a values cheat sheet if a values round exists
- A deeper research pass (L2) → a grounding brief and CO questions, at up to 6 further searches and 2 further fetches and several more minutes, offered once and run only on your say-so
- Your answers to the slots on F1, F3, F4 and F5 (how many of the seven years were leading people, whether any work touched more than one site, whether on-time or cost moved, what you built in Excel) → those rows move from slot to quoted evidence and the matching bank cells become story-mapped
- A site KPI report or shift scorecard behind the 40% result, and the green belt certificate → F4 and F7 can move from `medium` toward `high`
- A tuesday-dossier.md from an earlier evaluation → user-confirmed evidence and a named top objection in place of the inferred one
