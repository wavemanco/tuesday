I'll read the reference files before building the pack.
I'm building the prep pack now. The research gave me Saltmarsh's published values, its one-session interview format, and a public talk by Tobias, so I'm writing the pack from those.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-canned-79e8cff5/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 22 questions across six interviewer styles, plus a fit snapshot, a values cheat sheet, six reverse questions and a prep schedule up to Friday.

I built it on one assumption: that Tobias runs your hour as the hiring manager. Saltmarsh's own interviewing page says every loop is one 60-minute interview with the hiring manager. That is a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home.

- **Highest-ROI prep:** C1, the in-app-purchases gap. You told me you've never worked on a game with in-app purchases. Saltmarsh's Project Larkspur post (September 2026) moves both titles to a season-pass model from February 2027, so expect this question. The pack coaches a plain concession, then only what you've actually said you did, then a plan for learning it.
- **The tabletop:** bank A rehearses it. The scenarios are stand-ins for the format, not Saltmarsh's real ones.
- **Values:** Saltmarsh publishes three: Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. Your release checklist is the only one of your sentences that maps to a value (Leave the Build Greener). The other two get selection scaffolds with an honest "nothing comes to mind" branch.
- **Tobias's own footprint:** his GDC 2026 talk is "Patch Notes Are a Promise", and he was previously a QA lead. Your release checklist is natural common ground, so say it plainly if QA comes up. Both facts come from search snippets, not the full pages.
- **Gaps you didn't state:** where your background says nothing (which teams you worked with, what the four years covered, other writing you've done), the pack gives answer slots, not invented answers. Each slot lets you say "that wasn't mine" or "that didn't exist".

Say the word and I'll play Tobias on C1, or run the Outage Hour tabletop (A1), with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the hiring manager running your Outage Hour, and has the recruiter said anything about what the scenario will cover? A "no" or a specific scenario would reweight the banks.
Do you want a deeper research pass on Saltmarsh's strategy, Tobias's talks and recent org changes, using up to 6 more searches and 2 more fetches over several more minutes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager. Saltmarsh's own interviewing page says its loop is a recruiter call, then one 60-minute interview with the hiring manager. This pack assumes Tobias is that person, which is unconfirmed.
**Candidate:** Femi
**Round:** the "Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation. The page gives no split of the hour between the two.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the job as listed, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` is traceable to your message, the JD or cited research. `[inferred]` is derived from an adjacent source, with the derivation named. `[generic]` is a role-family pattern with no claim about you or Saltmarsh.

Answer slots (marked "Answer slot") are instructions for what to say in the interview, with an honest branch if the practice was not yours or never existed. They are not questions to me.

## Prep triage

You have until Friday: Wednesday evening, Thursday, Friday morning. Do these in order.

1. Wednesday evening: rehearse C1 aloud until it is boring. It is the highest-ROI prep in this pack.
2. Wednesday evening: run the tabletop (A1, then A5) out loud twice, saying your structure first. Time yourself.
3. Thursday: decide which true episode you would use for B1, B2, B3 and B4, or settle on the honest branch for each. B3 already has a quoted sentence behind it.
4. Thursday: write down, from your own records, what you know and do not know about how the retention numbers were counted (D1), and what was yours to decide on the calendar (D2).
5. Friday morning: read the Project Larkspur post, the values page and the talk listing once more (Sources). Then A2 and the reverse questions.

Everything else in this pack is insurance.

## Fit snapshot

Evidence cells hold your own words only, quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly calendar for your main title, with nothing inspected behind it. The words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's scope line makes a probe on breadth likely. If you ran any other calendar alongside it, say what, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | No quote speaks to working with other teams, and silence is not an absence. Answer slot: the JD names four teams, so expect a probe on who you worked with. If you worked with any of design, art, engineering or community, say which and what you needed from each, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a review or the figures behind it. Words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's line makes a probe on what sat behind the numbers likely. If you had a part in what the numbers were used for after you presented them, say what and how; if not, or it was not yours, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you wrote it, and your QA team still uses it. The pack's observation is that your material does not say who ran it release to release; D3 carries that probe |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The quotes give the years and the title, and do not show whether the game was live-service; the pack does not supply that. Answer slot: the JD's years line makes a probe on what the four years covered likely. Say in your own words what the work was across them; if some of those years differed from the calendar work, say so plainly and return to the two years of the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a self-reported line, so expect a probe on what was yours to decide. Lead in the quote's own terms: you ran the weekly content-drop calendar, for your main title, for the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | Lead with "I presented the monthly retention numbers to the studio head." The quote says presented; how the numbers were counted is not in your material, and D1 carries those slots |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written checklist touches the requirement without showing whether it reaches it. Answer slot: the JD's line makes a request to describe something you wrote likely. If there is other written material you could describe, say what, in your own words; if not, say so plainly and stay with the checklist you wrote |
| F9 | No JD line on purchases; Saltmarsh's news post says two titles move to a "season-pass model" — Project Larkspur post, search result | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to purchase or season-pass work, and nothing added to make the gap feel smaller |
| F10 | Leading people: no JD line asks for it; the JD's coordination line (F2) makes it a likely probe | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." Then stay with what your quotes carry. Never turn working with other teams into leading them |

## Reading the interviewer

Public professional footprint only. Both facts below come from a search-result snippet of a GDC 2026 talk listing; the page itself was not fetched.

| Observation | Source | Provenance | What it implies for you |
|---|---|---|---|
| Tobias Wrenfield is Head of Live Operations at Saltmarsh Games and was previously a QA lead at a console studio | GDC 2026 talk listing | [grounded] | Release checking is native ground for him, and F4 is the natural point of contact. Say it plainly if QA comes up and do not stretch it |
| His talk, "Patch Notes Are a Promise", argues a live team is judged by how often its patch notes describe what actually shipped | GDC 2026 talk listing | [grounded] | Expect your own claims to be tested against what you actually did, and expect the tabletop to reward saying only what is built and known. It matches the second Saltmarsh value (see the values cheat sheet) |
| Shared professional ground: his QA-lead background and F4, "Wrote the release checklist our QA team still uses." — your message | GDC 2026 talk listing, your message | [grounded] | Offer F4 in its own words and let him draw the connection. Do not claim a QA background |

## Persona table

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A, 5 questions) | The tabletop: a simulated outage during a live event | Highest. Saltmarsh's interviewing page documents the tabletop, and the hiring-manager prior tilts to Case and Skeptic. The persona is the delivery of a documented part of the hour | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Values/Behavioral (bank B, 5) | The values conversation after the tabletop | Guaranteed in this session: the same page documents a values conversation, and the values page names three values. Its share of the hour is not stated | One story or an honest branch per value; "we" for context, "I" for contribution; choose stories where the hard truth landed |
| Skeptic (bank C, 4) | Probing F9 and F10, and the scope gap in F1 and F5 | High. Hiring-manager prior, plus two negatives you stated | Rehearse the objection until it is boring; concede plainly, hold what your quotes carry, then a plan |
| Data-Driven Prober (bank D, 3) | Line-by-line on the calendar, the numbers and the checklist | Medium. Inference: his published argument concerns claims versus what shipped, so claims get checked. The page does not say he probes this way | Know what you can and cannot say about each figure; say plainly when you do not know |
| Pressure (bank E, 2) | Time-boxed moments inside the tabletop | Low to medium. Inference: a live-incident tabletop plausibly includes time pressure; the page does not say so | Pause, restate, answer inside the box, concede specifically without folding |
| Conversational (bank F, 2) | The opening of the hour | Low to medium. The page does not show an opening, but a casual opener is still scored | A pre-built 90-second arc from your quoted sentences |
| Peer Evaluator | Not included | The loop source names one interview with the hiring manager and no peer | n/a |

## Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| Live-events calendar for two titles | C3, A2, A3, D2 | JD-tagged: C3 |
| Coordinate design, art, engineering and community | C2, A1 | JD-tagged: C2 |
| Post-event review and the KPIs it reports | A4, D1 | JD-tagged: A4 |
| Release checklist with QA | D3, A5, B3 | JD-tagged: D3 |
| 3+ years producing live-service games or apps | C3, F1 | JD-tagged: C3 |
| Running a content calendar | D2, F1, A3 | JD-tagged: C3 |
| Player-retention metrics | A4, D1 | JD-tagged: A4 |
| Clear written communication | E2 | JD-tagged: E2 |

## Question banks

### Bank A: Case/Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event has just gone out and players on one platform report that rewards aren't arriving. You have the whole team on a call — walk me through your first hour." | CASE | [inferred] | Say your structure aloud first. Clarify before acting: what exactly is failing, for whom, since when, and whether anything shipped just before. Objective: protect players and stop it growing. Then call containment aloud — pause the event, roll back, or fix forward — and name what would change your mind. Say who you pull in and what you need from each: engineering for cause and fix, QA for what to re-check before anything ships again, community for what players are seeing, design and art only if the content itself is implicated. Say what players are told and when they hear next, using only what is built and known. Close with what you would capture for the review. Challenge one premise respectfully, such as whether the first hour is for fixing or for containing. The question asks nothing about your past, so the guidance makes none | Derived from the interviewing page's description of a live-incident tabletop. The scenario is a stand-in for the format, not Saltmarsh's actual scenario. CASE because it scores structure, and it touches the coordination line behind F2 |
| A2 | "From February 2027 the two titles share one events calendar and the per-title event teams become one live-ops group. What do you need to know first, and how would you sequence the first quarter?" | CO | [grounded] | Say you are working from the public announcement and may be missing internal detail. Clarify: what changes for events in practice, which events are already booked past February, how the two player bases differ, what a shared calendar means for collisions. State the objective, then an approach that inventories before it sequences and makes the fewest moves first. Name what you would watch and the main risk, such as losing per-title knowledge. Tie the tie-breaker to Players Before Plans. Do not recite the post; reason from it. No claim about your past is made | The strategy question the research supports. Grounded in the Project Larkspur search result, not the full post. CO because it tests current strategy at Tobias's altitude, with CASE delivery |
| A3 | "Two events want the same week on the shared calendar, and engineering says one of them won't be ready. How do you decide?" | CASE | [generic] | Clarify what is not ready (scope or date), what each event is tied to, and what moving either costs. State a decision rule aloud, and say where the players' interest breaks a tie. Say who decides and who you consult, what you tell the teams affected, and what you record. The question needs no claim about your past, so the guidance makes none | A live calendar problem from the role's core line, behind F1 and F6. CASE; generic because it is a pattern, not a fact about Saltmarsh |
| A4 | "An event has ended and the players who joined it came back less than after the last one. How do you run the review, and what goes in your report?" | JD | [generic] | Clarify what "less" means: against which event, which players, over what window. Before blaming the event, say what else changed in that period. Say what the numbers cannot tell you. Name the assumption you would defend least before they do. Say what the report contains: what you found, how sure you are, and the decision it supports. Report what is known, not what is hoped. No claim about your past is made | Scores the review-and-KPI line behind F3 and F7 as a live problem rather than a claim. JD content, CASE delivery; generic because it is a pattern |
| A5 | "QA finds a blocker two hours before an event is due to go live, and the calendar says go. What happens?" | CASE | [generic] | Ask what the blocker is, who it affects, and how severe. Lay out the options: hold, ship without the affected piece, or ship with a known issue players are told about. Say what your go or no-go criteria are, who decides, what the other teams are told, and what you would record so the checklist is better afterwards. Let Players Before Plans break the tie. No claim about your past is made | Combines the QA line behind F4 with the first and third values. CASE |

### Bank B: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and what the players wanted pulled apart — what did you do?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. Pick a time you can name: the stake, what you chose, and what happened to the plan. Tell it in your own words, "we" for context and "I" for what was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years.", or how you would handle it, using A3's structure | Players Before Plans, from the values page. The prompt's theme is that value's own wording. VAL because it scores past behavior against a published value. F6 is the only calendar evidence |
| B2 | "Tell me about a time you had to say what was actually built rather than what you hoped would be." | VAL | [grounded] | Selection scaffold. Pick a time what was said was larger than what was done and it was corrected: what was claimed, what was built, who was told, how it landed. If no such time comes to mind, say so plainly, then say how you would handle it: what is built is announced, what is hoped is not | Ship the Patch Not the Promise, and the theme of Tobias's talk. VAL; the pack has no quote carrying this story, so it is a scaffold |
| B3 | "Tell me about a time you left a process or a checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4, with only the beats the sentence states: you wrote the checklist, and your QA team still uses it. Tell those in your own words. Answer slot: the value says every release leaves the checklist better, so expect a probe on whether anything changed after you wrote it. If you changed it, say what and why; if it stayed as written, or someone else changed it, or it was not yours to change, say so plainly and stay with having written it and QA still using it | Leave the Build Greener. F4 is the one row that carries a story for this value. VAL |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold. Pick a time a number said something people did not want to hear: what the number was, who heard it, what they did, whether the relationship held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "Presented the monthly retention numbers to the studio head.", or how you would handle it. The quote says presented; it does not say the news was unwelcome | A persona stem on the Players Before Plans and Ship the Patch themes, and the quote is the closest your material has. VAL; the quote does not carry the hard-truth ending, so none is supplied. F3 |
| B5 | "Which of our three values would you find hardest to live by, and why?" | VAL | [grounded] | Pick one honestly and name the concrete tension, for example a value pulling against a deadline. Say what you would do about it. If none feels hard, say which one you have tested least, plainly. No claim about your past is made | Scores honest self-assessment against the three published values. VAL |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases, and both our titles are moving to a season pass. How do you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." "Wrote the release checklist our QA team still uses." | The highest-ROI rehearsal in this pack. Pause and restate it in one sentence. Concede first, plainly: "I haven't worked on a game with in-app purchases." Then hold only what your quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years.", "Presented the monthly retention numbers to the studio head.", "Wrote the release checklist our QA team still uses." Follow-up one, "so how would you learn it": answer as a plan, not a past — what you would learn first and from whom. Follow-up two, "why not hire someone who has": return to the same three sentences, concede the point again, add nothing. The limit to say before it is asked: those three sentences do not reach purchases. Never describe purchases as something your work was similar to | F9 is the stated gap, and the season-pass move makes it the likeliest objection. JD because it scores a stated gap against the role. Hold-then-concede is the type bar for a pressure question |
| C2 | "You haven't led a team, and this role coordinates four disciplines. How do you get design, art, engineering and community to move on your calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say "I haven't led a team." Answer slot: expect a probe on who you worked with. If you worked with any of those disciplines on the calendar, say which and what you needed from each; if you did not, or it was not yours, say so plainly and stay with the calendar you ran. Then say how you would earn agreement without authority, as a plan. Never call working with a team leading it | F10 and F2. JD because it scores the coordination line |
| C3 | "Your calendar was weekly content drops for your main title. We run live events across two titles — what changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "4 years as an associate producer at a puzzle-game studio." | Hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you ran any other calendar alongside it, or anything beyond content drops, say what, in your own words; if not, say so plainly and stay with that calendar. If the four years come up, say in your own words what the work was across them; if some years differed, say so. Then say what you would ask first about the two titles' differences, as a plan | F1 and F5, the scope gap |
| C4 | "Why this role, why a mobile studio of this size, and why now?" | CO | [grounded] | Selection scaffold. Pick a reason that is true and tie it to something in the JD or in Saltmarsh's own published material, such as its values or its live-ops structure. Say it in your own words. If no reason beyond "it's the next step" comes to mind, say so plainly, then say what you would want to learn in the role | Motivation consistency. CO because it scores company knowledge. F5 is why the "why now" has an edge |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented to the studio head — how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold the quote: "I presented the monthly retention numbers to the studio head." Answer slot (defend the number): say how the numbers were counted, what they are sensitive to, the assumption you would defend least, and which part was yours, each in your own words. If you do not know how a figure was counted, say so plainly. If the counting was someone else's, say so and return to the presentation. Name your weakest assumption before they do | F7 and F3. EXP because it tests whether the claim survives scrutiny |
| D2 | "On the weekly content-drop calendar you ran — what was yours to decide, and what was handed to you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say what you decided, in your own words. If some calls were set for you, or no such decisions were yours, say so plainly and stay with having run it | F6. The attribution probe, "how much of that was actually you" |
| D3 | "On a release day, who ran the checklist you wrote, and what was your part alongside QA?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Hold the quote: "Wrote the release checklist our QA team still uses." Answer slot: the JD's QA line makes this likely. If you took part when it was used on release days, say how, in your own words; if QA used it without you, or there was no release-day step you took part in, say so plainly and stay with having written it | F4. The JD's QA line is the raising source |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events with purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." "Wrote the release checklist our QA team still uses." | Pause and restate. Then one concession and three facts, and stop: "I haven't worked on a game with in-app purchases." followed by the calendar, the retention numbers and the checklist, each in its quoted words. Hold through a second push by repeating the concession and the same facts. Do not disparage others and do not add facts | F9 under time pressure; it scores composure rather than content. Companion to C1 |
| E2 | "You have sixty seconds. Say the notice players see right now for an outage you can't yet explain." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Say it as you would write it: what players are experiencing, what you know, what you do not know yet, when the next update comes, and nothing promised that is not built. Short sentences. If asked about your own writing, point to what you wrote: the checklist | The JD's written-communication line, F8, delivered as a time-boxed task. The Ship the Patch value is the standard. JD with CASE delivery |

### Bank F: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats, in your own words, each only as far as its sentence goes: the four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for your main title, the checklist your QA team still uses, the monthly retention numbers you presented. Say associate producer, not producer. End on a reason for this role that is true; if none beyond "next step" comes to mind, say so plainly | F5, F6, F4, F7 in order. A casual opener is still scored |
| F2 | "Tell me about a live event in a game you've played that you thought was run well — what made it work?" | JD | [grounded] | Selection scaffold. Pick one you can describe from the player's side: what was announced, what was delivered, how problems were communicated. If none comes to mind, say so plainly, then say how you would judge whether an event was run well | The JD's live-events line asked casually; scored for genuine interest |

## Values cheat sheet

A values-style round is documented: the interviewing page names a values conversation.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold (B1): pick a time the two pulled apart, naming the stake, your choice and the result. If none comes to mind, say so plainly and use A3's structure |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold (B2): pick a time what was claimed was larger than what was built. If none comes to mind, say so plainly and say how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." — your message. B3's slot carries the rest |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Your GDC talk argues a live team is judged by how often its patch notes describe what actually shipped. How does your team measure that internally?" | Ties to his own published argument (GDC listing, search result) and to the second value. It shows you read him, not just the company |
| 2 | "You came into live ops from QA. What did that change about how you run a release, and what should a producer on your team take from it?" | Ties to his career path (GDC listing). It turns the F4 overlap into a conversation rather than a claim |
| 3 | "Project Larkspur merges the per-title event teams into one live-ops group. How will this producer role differ before and after February?" | Shows homework on a recent move (Larkspur search result) and gets at what the role really is |
| 4 | "How are post-event reviews used today? What is one decision a review has changed?" | Shows you care about the review line in the JD and about decisions, not documents |
| 5 | "What would you want me to have learned about how the titles earn by day thirty?" | Turns the stated purchases gap (F9) into a ramp plan he can answer, without you pretending to know |
| 6 | "What separates the people who do well in the Outage Hour from the people who don't?" | Invites him to tell you how the tabletop is scored |

## Prohibited claims

Not coached in this pack. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation is that your material says the weekly calendar for your main title. C3's slot stays inside the calendar |
| Owned the post-event review and the KPIs it reports | Inflated form of F3 | F3's quote at its own scope. The material says presented monthly retention numbers; D1's slots ask only how they were counted and which part was yours |
| Managed the release checklist with QA release to release | Inflated form of F4 | F4's quote at its own scope: you wrote it and QA still uses it. D3's slot stays inside that |
| Four years of live-service production | Inflated form of F5 | F5's quotes at their own scope. The material says associate producer at a puzzle-game studio and does not say whether it was live-service |
| Has led a team | Negative you stated, F10 | The plain acknowledgment: "I haven't led a team." No slot |
| Has worked on in-app purchases, monetization or a season pass | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |

F2 and F8 are silence in your material, not inflated forms, so they are answer slots rather than entries here.

## Sources

Provided: the job description and your background, both pasted in your message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches run:

- "Saltmarsh Games values" returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games mobile studio news strategy" returned https://saltmarshgames.com/news/project-larkspur (snippet only; page not fetched)
- "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only; page not fetched)

Fetches run: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and bank B: the three values by official name |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure (one hiring-manager hour: tabletop, then values); persona weights follow it |
| 3. `Saltmarsh Games strategy` / recent news | yes | A2 and C4; F9's season-pass framing. From a search snippet only |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, reverse questions 1 and 2, the talk-theme link to bank D. From a search snippet only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The recruiter's note on the Outage Hour (any announced scenario focus, the titles involved, the split of the hour) → coverage assumed from the page is replaced by what they actually said, and bank A is retuned
- Confirmation that Tobias is the hiring manager running your hour → persona weights are reweighted if he is a different relationship, such as a skip-level
- Your answers to the slots in F1, F2, F3, F5 and F8 (what else you calendared, which teams you worked with, what sat behind the numbers, what the four years covered, what else you have written) → those rows move from discovery or transferability to quoted evidence and the matching banks regenerate
- How the retention numbers you presented were counted → D1 becomes a grounded defend-the-number answer instead of slots
- The full Project Larkspur post and the talk's slides or summary, pasted → A2 and the interviewer read rest on the pages rather than on snippets
- A tuesday-dossier.md from an earlier evaluation → the highest-ROI objection would be evidence-derived rather than inferred, and prohibited claims would arrive from it
