I'll read the reference files first.
The pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-denied-760f6a48/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as three round-by-round mini-packs, since the recruiter's email fixes all three rounds. It has 26 questions. Round 3 also carries the values cheat sheet, because the panel scores against the four values. I didn't run any web research. Everything it needed came from what you pasted. The interviewers haven't been assigned, so there's no interviewer read.

**Highest-ROI prep: R2-B1.** The JD says "branches and the contact centre", and your own material says you've never worked in a contact centre. Your future manager will ask about it in some form. The pack has you concede it plainly, hold at what you actually did with the branch complaints log and the teller training, and say a plan for learning the contact-centre side. It also gives three follow-ups to rehearse. Presenting above regional level is the second-biggest gap and gets the same concede-and-plan treatment (R1-B3, R2-B2).

**Where I held back.**
- **Slots instead of answers.** Where your material doesn't say something, the pack gives you an answer slot instead of an answer. Examples are what your spreadsheet showed, whether the complaints log followed external rules, and whether you ever coached supervisors. Fill those in for yourself. Sending them to me lets me turn the rows into real evidence.
- **Values stories.** I couldn't map a story for Members First, Plain Words or Neighbours, Not Numbers from what you gave me, so those are selection prompts. Own the Fix is the exception, with a partial setting from your complaints-log line.

I can play the Skeptic on R2-B1 live, with follow-ups that react to what you actually say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview pack for Dara

Three rounds on 20 November 2026, built in loop mode because the recruiter's email fixes all three: 30 minutes with the recruiter; 45 minutes with the Head of Member Services (your future manager), mostly behavioural; 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case, scored against the four published values. Interviewer names beyond those roles are not assigned yet, so there is no interviewer read. Prepared 11 November 2026.

## How to use this pack

Personas are how a question arrives; types are what is being scored. The five type tags:

- VAL: whether past behaviour shows a published value
- EXP: whether a claim in your background survives scrutiny, and what was actually yours
- JD: a requirement the job description states
- CO: company and strategy knowledge
- CASE: a live problem from the role

Answer guidance is scaffolding, not a script. Where it says "answer slot", it is an instruction for the interview, not a question for now: answer from your own experience, or say plainly the practice was not yours. If you write out your slot answers and send them, the pack regenerates around them (see the upgrade menu).

Question IDs are by round and persona: R1-A1 is round 1, persona A, question 1.

## Prep triage (nine days to 20 November)

1. Days 1 to 3: say R2-B1 aloud until the concession and the hold come out in your own words. It is the highest-ROI prep in this pack: the contact centre is half of the JD's scope and your own material says you have not worked in one.
2. Days 3 to 5: write your answer to each answer slot in F1, F3, F4 and F7, then R3-A4. These rows are where an interviewer's second question lands.
3. Days 5 to 7: run the R3-B1 case twice against a 20-minute clock, thinking aloud.
4. Days 7 to 8: choose one story per value for R3-A1 to R3-A4, from your own experience, using the selection criteria.
5. Day 9: R1-A1 at 90 seconds, then the two concessions in R1-B3 and R2-B2. Then stop.

Everything else in the pack is insurance.

## Fit snapshot (shared across the three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not a process across branches, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on where your part of a complaint began and ended likely. If a complaint ever stayed with you from first contact to closure, say what you did, in your own words; if your part was narrower than that, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence says a monthly complaints spreadsheet your regional manager uses, with nothing inspected behind it, and does not say what it counted. Words stay at: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's volumes and resolution times make a probe on what the spreadsheet showed likely. If it showed either, say which and how it was worked out, in your own words; if it showed something else, say so plainly and stay with the spreadsheet |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and an escalation script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD names supervisors, so expect a probe on whether you coached people at your own level. If you ever took a supervisor or manager through a live escalation, say what happened and what part was yours; if you did not, say so plainly and stay with the tellers and the script |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not mention digital work either way. Answer slot: if you have worked with a digital team, an app or a website on anything members use themselves, say what it was and what you did, in your own words; if you have not, say so plainly and say what you would ask a digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap in the quote's own terms. Lead with it as you said it: six years in retail banking, the last three as a branch supervisor. A CV line alone has nothing inspected behind it, so expect a probe, and answer it from what F1 and F4 carry, no further |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [grounded] | discovery | The sentence says a formal complaints log and does not say what rules, if any, sat behind it. Answer slot: if the log followed rules or deadlines set from outside the organisation, say which, in your own words; if it followed only internal policy, or you do not know what sat behind it, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for a first senior audience, said as a plan and never as a past. Never a claim of confidence the material does not carry |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [grounded] | discovery | The sentence says spreadsheet, not which tool. Answer slot: if it was built in Excel, say so and say what it did, in your own words; if it was another tool, say so plainly and stay with what you built |

None of the nine rows is a gate in the sense of a licence, credential or legal bar, so none carries a gate gap type.

## Grounding brief (shared)

This is built from the four points you relayed from the July 2026 strategy brief, not from the brief itself. Paste the brief for more (see the upgrade menu).

| Item | What it says, as you relayed it | Where it is likely to land | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | R2-C1 and R1-A3. The JD's digital-teams line and the complaints remit both touch it, so it is the likeliest strategy question | [grounded] |
| Hubs | "consolidate eight branches into five hubs over 2027" | R3-B2. The round-3 panel is branch managers, so this lands closest to them | [grounded] |
| Small-business lending | "launch a small-business lending product in Q1 2027" | R3-B3. A new product is a new complaints surface to ask about | [grounded] |
| Competitive pressure | "the main competitive pressure is app-only banks" | R1-A3 and R2-C1. Use it to frame why plain, fast resolution matters, as your own view | [grounded] |

Vocabulary to use: member service (not customer service), digital channels, hubs, self-service journeys.

## Round 1: recruiter screen (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly opener, motivation, what you know about Ashgrove | Highest. The recruiter screen prior is Conversational plus a light Skeptic; the recruiter's email calls it 30 minutes with them and says nothing about scoring, which is the cue to treat casual questions as scored | A 90-second arc ready for the biography question (R1-A1); a three-sentence view of the strategy (R1-A3) |
| B. Skeptic, light | Knockout checks on the JD's hard-to-evidence lines in a friendly register | Medium. F2, F7 and F8 are where your own material is thinnest, and a screen is where those checks run | Concede first, hold at the quote's scope, then say the plan (R1-B1 to R1-B3) |
| C. Prober, CV-level | Reads the CV lines and asks what is behind them | Low. The screen is short, but the spreadsheet line is the one most likely to be picked up | Know what the spreadsheet showed and what it was built in (R1-C1, R1-C2) |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in three beats, each a clause from the quotes: six years in retail banking, the last three as a branch supervisor; handled the branch's formal complaints log and trained new tellers on the escalation script; built the monthly complaints spreadsheet the regional manager uses. Keep those verbs: handled, trained, built. Close with one sentence on why this role, in your own words; the pack does not supply your reason. Stop at 90 seconds and let the recruiter lead | The Conversational persona's standard opener. F6 is the tenure line it rests on, with F1, F3 and F4 as the beats. EXP because it tests whether the story you tell matches what is written about you |
| R1-A2 | "What is pulling you toward a member-owned credit union?" | CO | [grounded] | Selection scaffold: give the real reason in one or two sentences. If it is true for you, you can tie it to Ashgrove's own words: "we decide from the member's side of the counter." If the reason is mostly the role and not the member-owned model, say so plainly, then say what in the role you want to do. Nothing in your material says what drew you; it is yours to state | Motivation consistency is the Conversational persona's real scoring. The theme comes from the JD's "member-owned" and the published values; CO because it tests whether you understand the model, not only the job |
| R1-A3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Name the moves in the brief's own terms: 40% of member service to digital channels by 2028; eight branches consolidated into five hubs over 2027; a small-business lending product in Q1 2027; app-only banks as the main competitive pressure. Pick the one closest to the role and say what you would want to know about it. Mark any link to complaints as your view ("my read is"), not as fact. Do not recite all four | The recruiter sent you the brief, so it is fair game. It is the grounding-brief row most likely to be asked cold, and the one a prepared candidate can answer in 30 seconds |
| R1-B1 | "The role covers the contact centre as well as branches. Where does that leave you?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Concede first, then hold at scope, then plan, in three short sentences. Concede: "I've never worked in a contact centre." Hold: "I handled the branch's formal complaints log." Plan, in your own words: what you would learn first about how complaints reach the contact centre before changing anything. Do not say your branch experience equals contact-centre experience | F2 is the stated gap and F1 the nearest thing the material carries. JD because it scores the stated scope; the light Skeptic register is why it is kept to three sentences, with R2-B1 as the deep version |
| R1-B2 | "Have you handled regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start at the quote's scope: "I handled the branch's formal complaints log." Answer slot: the JD asks for regulated complaints, so expect a probe on what rules the log followed. If it followed rules or deadlines set from outside the organisation, say which, in your own words; if it followed only internal policy, or you do not know what sat behind it, say so plainly and stay with the log | F7 is a low-confidence row: the quote says formal, not regulated. JD because the requirement is stated; the slot lets the premise be false |
| R1-B3 | "How comfortable are you presenting to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses." | Concede plainly in the quote's own terms: "I've never presented to anyone above regional level." Then what you did build: "I built the monthly complaints spreadsheet our regional manager uses." Then a plan, in your own words, for preparing a first senior audience. Do not describe yourself as confident presenting; the quotes do not say it | F8 is a stated gap with a hard-to-bridge JD line. The plan carries the answer, not the adjective. JD because the line is a stated requirement |
| R1-C1 | "Tell me about the monthly complaints spreadsheet. What did it show?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Open with the sentence as you said it. Answer slot: the JD asks for monthly volumes and resolution times, so expect a probe on whether the spreadsheet showed those. If it showed either, say which and how it was worked out; if it showed something else, say so plainly and stay with the spreadsheet. Your material has no figures, so there is no number to defend | F3 is the row the reporting requirement rests on and a medium-confidence one, since nothing inspectable sits behind it. EXP because it tests what you built |
| R1-C2 | "How comfortable are you in Excel for reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the sentence. Answer slot: the sentence says spreadsheet and not which tool. If it was built in Excel, say so and say what it did, in your own words; if it was another tool, say so plainly and stay with what you built. Do not rate yourself; describe what you built | F9 is low confidence for the same reason. JD because "comfortable with Excel reporting" is a stated requirement, asked here as a quick check |

### Reverse questions

| Question | Why it lands |
|---|---|
| "Can you tell me who is on each panel, and what the 20-minute case will look like?" | The interviewers are not yet assigned; names unlock an interviewer read and sharper questions, and asking is normal for a recruiter screen |
| "How is complaints work split today between branches and the contact centre?" | It tests your reading of the JD's scope and lets you hear how much of the role sits in the part you have not done |
| "What does round two weigh most, given it is mostly behavioural?" | It shows you read the email carefully and lets you aim the stories |
| "Which of the four values do hires tend to find hardest to evidence?" | The panel scores against them, so it is the round where the answer changes your preparation |
| "What are the next steps and timing after round three?" | A logistics close; it stops the call ending on a generic note |

## Round 2: Head of Member Services (45 minutes, your future manager)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Values / Behavioural | Open "tell me about a time" prompts, mostly behavioural | Highest. The recruiter's email says "mostly behavioural", which overrides the hiring-manager prior of Case plus Skeptic | One story per prompt from your own experience; "we" for context, "I" for your part; choose stories where the hard truth landed |
| B. Skeptic | Quiet probing of the contact-centre and senior-presenting gaps by the person who would manage you | High. A future manager is derisking gaps, and F2 and F8 are stated gaps | Rehearse R2-B1 until it is boring: concede, hold at scope, say the plan |
| C. Case / Strategist | One live strategy question | Low to medium. The hiring-manager prior includes it and the strategy brief gives it a subject; the round is mostly behavioural, so one question | Clarify, objective, segmentation, approach, metrics, risks, thinking aloud |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-A1 | "Tell me about a time you had to deliver an unpopular truth to a senior person." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship that was intact afterwards. Say "we" for context and "I" for what you did. Choose one where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values persona's standard stem. Nothing in your material carries this story, so the pack maps none. VAL because it tests behaviour; it also rehearses the "tell the manager what they do not want to hear" part of Own the Fix |
| R2-A2 | "Tell me about a time you put a member ahead of an internal metric." | VAL | [grounded] | Selection scaffold tied to "Members First, Always": pick a decision where the member's side and the branch's side pulled apart, what you chose, and what it cost. Use "I" for the decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values persona's second standard stem, and the published value gives it a theme. Nothing in your material carries the story, so it is a scaffold |
| R2-A3 | "Tell me about a time you coached someone through an escalation." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story map, with the beats the sentence states: new tellers, and the escalation script, told in your own words. Answer slot: the JD says supervisors, so expect a probe on whether you coached people at your own level. If you ever took a supervisor or manager through a live escalation, say what happened and what part was yours; if you did not, say so plainly and stay with the tellers and the script | F4 is the evidence for the coaching requirement. EXP because it tests what was actually yours; the open prompt's theme comes from the JD's coaching line |
| R2-A4 | "Tell me about a time you worked with a team outside your branch to fix something members kept running into." | JD | [grounded] | Selection scaffold, with the JD's digital-teams line as the theme: pick a time with a named team, a problem members were hitting, and what changed. Say what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5 has no evidence either way, so the pack asks for a selection and not a story. JD because the digital-teams requirement is stated and the interviewer will be its manager |
| R2-B1 | "Much of what you would own runs through the contact centre, and you have not worked in one. Where would you start?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Level 1: concede first, in your words: "I've never worked in a contact centre." Then hold at scope: "I handled the branch's formal complaints log." Then a plan, said as a plan: what you would learn first about how complaints arrive and move there, in your own words. Follow-up 1, asking why branch instincts would transfer: do not claim they do; say what you would check before changing anything. Follow-up 2, a contact-centre lead disagreeing with you: say whose expertise you would lean on and how you would decide. Follow-up 3, why you over someone who has run a contact centre: hold the same two quotes, name the limit once yourself, and stop. Never fill the silence by adding to the quotes | F1 and F2 together are the biggest gap against the JD's "branches and the contact centre"; a future manager will ask it in some form, which is why it carries the deepest rehearsal and the most follow-up levels. JD because it scores the stated scope; the limit is named before it is asked for |
| R2-B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Pick the one that is true for you. Your material carries two stated gaps, the contact centre and presenting above regional level. Name yours in the quote's own words, then say how you would close it as a plan, with a timeframe of your choosing. If neither is your real answer, say what is; do not pick the safer-sounding one | A direct stem for the Skeptic. F2 and F8 are the two rows it can land on. JD because it scores honest self-assessment against the stated requirements |
| R2-B3 | "Why this move, and why now?" | JD | [generic] | Selection scaffold: one sentence on what you want to do that your current post does not let you, one on why Ashgrove, one on why now. All three are yours; the pack does not supply any of them. If one is thin, say so plainly and lead with the strongest | The Skeptic's motivation-consistency check, a standard stem. Generic because it is a pattern and not a fact about this employer; JD because the move is into the role described |
| R2-C1 | "We plan to move 40% of member service to digital channels by 2028. What does that mean for how complaints are handled, and what would you need to know first?" | CASE | [grounded] | Structure aloud: clarify first (what counts as digital, which journeys move, which complaint types arrive digitally today); objective (a member should not have to explain a complaint twice, which is Plain Words); segmentation (by complaint type and channel); approach; metrics (volumes and resolution times, the JD's own measures); risks (members who cannot or will not move, and the 2027 hub consolidation changing where complaints arrive). Challenge one premise respectfully. No claim about your past is needed | The one strategy case in a mostly behavioural round, built from the brief's digital line. CASE because it scores structure and reasoning; it uses the company's own vocabulary |

### Reverse questions

| Question | Why it lands |
|---|---|
| "Where does a complaint most often lose time today, between branch and contact centre or somewhere else?" | It uses the JD's resolution-time measure and shows Own the Fix in the question itself |
| "How should the monthly report reach senior leaders, and who presents it?" | It surfaces the presenting expectation openly, which turns F8 from a surprise into a plan |
| "Who in the digital team would I work with first on self-service journeys?" | It tests F5's requirement for real detail and shows you expect to start there |
| "What would you want to be different about complaints at Ashgrove in twelve months?" | It invites your future manager to state the outcome they are buying |
| "With the move to five hubs in 2027, how do you see supervisors' escalation load changing?" | It ties the strategy brief to the role you would coach in, and invites a candid answer |

## Round 3: panel of two branch managers (60 minutes, including a 20-minute case; the values round)

The recruiter's email says this panel scores against the four values, so a values-style round is detected.

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Values / Behavioural | Scenario probes mapped to the four published values | Highest. The email says the panel scores against the four values | One story per value, chosen in advance; harmony stories where the hard truth landed |
| B. Case / Strategist | The 20-minute complaint-escalation case, plus a strategy question or two | High. The email names the case, a third of the hour | Clarify, objective, first actions, follow-through, measures, risks; think aloud |
| C. Peer Evaluator | Seam questions between branches and the contact centre; what you would need from them | Medium. A judgment, since no names are assigned: the JD has you coaching branch supervisors, so partnership with branch managers is what they would be living with | Reciprocity first; propose seam principles, not a seam you cannot know |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-A1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold for "Members First, Always": a decision where the member's view and the easier path differed, what you chose, and what happened. Use "I" for the decision. Choose one where the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's own words give the theme. Nothing in your material carries the story, so it is a scaffold. VAL because it tests behaviour against the published value |
| R3-A2 | "Tell me about a time something you explained or wrote needed saying again because it had not landed." | VAL | [grounded] | Selection scaffold for "Plain Words": the value says that if a member needs it explained twice, "we wrote it wrong". Pick a case where you owned that, what you changed, and how you checked it worked. Say it plainly, including what you got wrong. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's wording sets the test: owning the failure to explain. Nothing in your material carries the story, so it is a scaffold. VAL because it tests behaviour against the value |
| R3-A3 | "Tell me about a time you protected a branch's place in its town, or a local relationship, when a number pointed elsewhere." | VAL | [grounded] | Selection scaffold for "Neighbours, Not Numbers": a named branch or local relationship, the number that pointed the other way, what you did, and what it cost. Use "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Two branch managers are likely to weigh this value, and the 2027 hub plan sharpens it. Your material has a branch background but no story, so it is a scaffold. VAL because it tests behaviour against the value |
| R3-A4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story map: the setting is the quote, "I handled the branch's formal complaints log", and no further beat is carried. Answer slot: "Own the Fix" says whoever finds the problem keeps hold of it until it is solved, so expect a probe on a problem you kept hold of. If one stayed with you to the end, say what it was and what you did, in your own words; if none did, or it passed out of your hands, say so plainly and stay with the log | F1 is the only row that could carry this value and it carries the setting only. VAL because the value is the scoring axis; the slot lets the premise be false |
| R3-B1 | "A member's formal complaint was raised at a branch, was passed to the contact centre, and the member is now calling both and says nobody owns it. The branch supervisor has escalated to you. Walk us through it." | CASE | [generic] | Structure aloud. Clarify first: what the complaint is, what the member has been told, and whether any deadline applies. Objective: one owner now, and the member does not explain twice. First actions: take ownership, give the member one contact and plain-words update, find where it stalled, record it. Coach the supervisor in the moment, not after. Then look for the pattern across branches and the contact centre, and name the measures you would report: volumes and resolution times. Risks: a handover that loses the history; a promise you cannot keep. Challenge one premise respectfully, such as who owns it right now. Expect follow-ups: the supervisor disagrees with your call; the member says they will go outside the organisation. No claim about your past is needed | The email says the case is a complaint escalation, and this one is a rehearsal scenario, not the panel's. It is the case that tests the JD's end-to-end and coaching lines together. CASE because it scores structure and reasoning; generic because it is a pattern |
| R3-B2 | "Eight branches become five hubs over 2027. What happens to the complaints process, and what would you watch?" | CO | [grounded] | Clarify first: what is decided and what is open, and what happens to a closed branch's members. Then principles: where complaints arrive may change, one owner follows the member wherever they go, and the measures stay comparable across the change. What to watch: volumes and resolution times by branch before and after, and members who say they feel unheard. Frame each as what you would look at, not as a known effect | The hub plan lands closest to branch managers, so a CO question here is likely. It also ties to "Neighbours, Not Numbers". CO because it tests strategy fluency |
| R3-B3 | "A small-business lending product launches in Q1 2027. What complaints would you expect, and how would you prepare the process?" | CASE | [grounded] | Clarify first: what the product is, which channels sell and service it, and who handles problems. Objective: members get a clear path from day one. Approach: agree complaint categories and escalation routes before launch, write the member-facing words in plain language, and brief supervisors early. Metrics: the volumes and resolution times in the first period. Risk: a new product arriving in channels that are still changing. Frame expectations as questions you would ask, not as predictions | A new product is a new complaints surface; the brief gives the date. CASE because it scores structure and uses the company's own vocabulary |
| R3-C1 | "Branches and the contact centre both take complaints. Where is the seam between them and your call, and what happens when a branch manager disagrees with you?" | JD | [generic] | Offer seam principles, not a seam you cannot know: one owner at a time, a clear handover, and a shared record. Say what you would ask the branch managers first about how complaints reach them today. For disagreement, show spine and tact together: say how you would decide whose call it is, and what you would do to keep the member's complaint moving in the meantime. No claim about your past is needed | The Peer persona's seam stem, with the JD's "across branches and the contact centre" as the raising source. JD because it scores the stated scope |
| R3-C2 | "What would you need from us in your first month?" | JD | [generic] | Reciprocity first: what you would bring them, then what you would ask. Offer a plan in your own words, such as time with their supervisors on how escalations reach them today. Keep the ask small and specific | The Peer persona's partnership check; reciprocity framing counts for more than the list of needs. JD because the job coaches their supervisors |
| R3-C3 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work was shared, say who did what, and say what you did with credit. "We" for context, "I" for your part, and name what was theirs. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer persona's standard stem. EXP because it tests attribution honesty; nothing in your material carries the story |

### Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side, not the organisation's | No quote carries a story. Selection scaffold R3-A1: a decision where the member's view and the easier path differed, what you chose, what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member has to be told twice, the fault is in how it was written or said | No quote carries a story. Selection scaffold R3-A2: a case where you owned an explanation that did not land. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Each branch matters to its town, over and above what a figure says | No quote carries a story. Selection scaffold R3-A3: a branch or local relationship, a number pointing elsewhere, what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The quote carries the setting only; the slot in R3-A4 covers any further beat |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What do your supervisors find hardest about escalating a complaint today?" | The panel are the people your coaching would serve; the answer tells you what to ask them first |
| "What would a new complaints lead do in the first month that would genuinely help your branches?" | The reciprocity question: it asks what you could do for them |
| "How do you see the move to hubs changing what members bring to the counter?" | It ties the strategy brief to their daily work and to Neighbours, Not Numbers |
| "Where do the four values show up in a branch on an ordinary day?" | It shows you take the scoring axes seriously and gives you a concrete picture for later answers |
| "What would make you say, a year from now, that this hire got it right?" | A close that invites them to state the outcome, in their words |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | R1-B1, R2-B1, R3-B1, R3-C1 |
| "report monthly on complaint volumes and resolution times" | R1-C1, R2-C1, R3-B1 |
| "coach branch supervisors on escalations" | R2-A3, R3-B1, R3-C1 |
| "work with digital teams on self-service journeys" | R2-A4, R2-C1 |
| "4+ years in financial-services customer operations" | R1-A1 |
| "experience handling regulated complaints" | R1-B2 |
| "confident presenting to senior leaders" | R1-B3, R2-B2 |
| "comfortable with Excel reporting" | R1-C2 |

No headline metric in your material, so there is no defend-the-number question: the only figures are the six years and the last three, which R1-A1 carries. Salary and notice questions are not rehearsed because your material and the email say nothing on them.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log, not a process across branches. The slots stay inside the log |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders, or is confident doing so | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." The slot in R2-A3 asks only what you did with tellers and the script |
| Reported complaint volumes and resolution times to leadership each month | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The slot asks only what the spreadsheet showed |
| Handled regulated complaints under a named rule or regime | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." The slot asks only what sat behind the log |
| Built the complaints reporting in Excel | Inflated form of F9 | F9's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The slot asks only which tool |

## Sources

Provided documents: the job description; the four published values, copied by you on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the three rounds; the four points of the July 2026 strategy brief as you relayed them; your background as you wrote it. No tuesday-dossier.md was present.

No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text is in hand and fixes the values cheat sheet and the VAL bank |
| 2. Ashgrove interview process, member service roles | skipped | The recruiter's email fixes all three rounds, who runs each and the case format, so persona weights follow named rounds |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief points you supplied fix the CO and CASE questions; the brief is under six months old |
| 4. Interviewer name and Ashgrove | n/a | No names are assigned, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your written answers to the answer slots in F1, F3, F4, F5, F7 and F9 and R3-A4 → those discovery rows become quoted evidence and the pack regenerates around them; a redacted extract of the complaints log or of the monthly spreadsheet would lift F3 and F9 from medium or low toward high, since that is the artifact this work keeps
- Which country or regulator's rules the formal complaints log followed → F7 becomes answerable in specifics, and R1-B2 can be narrowed
- Interviewer names as soon as they are assigned → an interviewer read, persona weights tuned to each person's public career pattern, and one reverse question tied to their own path
- The full strategy brief → the grounding brief grows beyond four points, and the CO and CASE questions can use its figures and its own vocabulary
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → recent leadership and organisation context and loop reports for comparable roles; say the word and I will run it
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and any prohibited claims would replace the ones this pack derived locally
