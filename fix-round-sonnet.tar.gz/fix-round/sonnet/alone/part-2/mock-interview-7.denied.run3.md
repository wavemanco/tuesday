I'll read the reference files the skill points to before building the pack.
Saving is done, so I'm now handing over the pack with what to know about it.

Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-denied-7c9adf50/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 22 questions, a fit snapshot, a requirement-coverage table, reverse questions and a two-day prep triage.

I built it as a hiring-manager round, on the assumption that Tobias is your future boss. All four web searches (values, loop, news, Tobias) were refused by the host. So there is no company research, no interviewer read and no values cheat sheet, and the Sources section says so. Everything company-specific is generic or absent, not guessed.

The pack's highest-ROI prep is B2, "Have you worked on a game with in-app purchases?" That is the gap you named yourself, and none of your own sentences covers it. The pack picks it on that reasoning, since the JD doesn't say how much weight it carries. Next in line are B1 (weakest part of the JD on day one) and A2/A3 (the calendar and retention case questions).

Say the word and I'll run a live drill as Tobias on B2, with follow-ups and feedback against the pack's guidance for it.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, and did the recruiter mention any focus areas or a take-home? The answer reweights every bank.
If you enable web search, want a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Prepared for Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: 60 minutes. Relationship assumed to be hiring manager, not confirmed. Built from the JD and your background as you gave them; no company research was available, so every company-specific section is absent rather than guessed (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and rehearse only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your background claims survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

"Answer slot" lines are instructions for what to say in the interview if the probe arrives. Each has two honest branches; either one is a good answer.

## Prep triage

Time assumed: two days (today is Wednesday 11 November, the interview is Friday).

1. B2, then B1: say each aloud three times. B2 is the highest-ROI prep in this pack.
2. A3 and A2: say the structure aloud, thinking out loud, with the clarifying questions first.
3. D1: a 90-second arc from your own sentences. If you can, spend half an hour in the studio's two live titles for D2.
4. C1: write down what you know and do not know about how the monthly retention numbers were counted.
5. Choose three reverse questions from section 11.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, nothing inspected behind it; the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD says live events and two titles, so expect a probe on both. If the calendar you ran carried events as well as drops, say how they were scheduled, in your own words; if it held drops only, say so plainly and stay with the calendar you ran. If you ever planned for a title beyond your main one, say what that was; if not, say so plainly |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The quote touches the requirement without showing which teams you worked with. Answer slot: expect a probe on which of the four named teams you worked with on a drop. If you worked with any, say which and what you did, in your own words; if none, or it was not your part, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers to the studio head, and the words stay there. Answer slot: the JD pairs the review with the KPIs it reports, so expect a probe on who chose the KPIs. If you had any say in which numbers were reported, say how you decided, in your own words; if they were set by someone else, or no event review existed, say so plainly and stay with presenting the numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: you wrote the checklist, and your QA team still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your quotes show four years as an associate producer and two years running the calendar; they do not show whether the other two years involved live content. Answer slot: expect the interviewer to count years. If the earlier years also involved live content, say how, in your own words; if they did not, say so plainly and stay with the two years running the calendar. The JD's phrase "live-service" is theirs, not yours; keep your own words |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it. Lead with it as written: weekly, your main title, the last two years. A named record beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but expect a probe on the numbers behind it. Lead with it as written: monthly, to the studio head. Answer slot: if you know how the numbers were counted, say so in your own words; if you do not, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | One written item touches the requirement; nothing shows whether it reaches it. Answer slot: if you have written anything else for others to act on, say what, in your own words; if not, say so plainly and stay with the checklist you wrote |
| F9 | Experience with in-app purchases: role-family expectation for a mobile title, not stated in the JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap your own words state. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |
| F10 | Leading a team: not stated in the JD, which says coordinate | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap your own words state. Words: "I haven't led a team." The JD says coordinate, not lead; the coordination part is F2 |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the job: plan this, diagnose that | High. The hiring-manager prior is Case/Strategist plus Skeptic, and the JD's calendar, coordination and KPI lines each convert easily into a live problem | Clarify, then objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the gaps | High. Same prior; you have stated two gaps yourself (F9, F10) and F1, F3 and F5 each stop short of the JD's wording | Rehearse the most predictable objection (B2) until it is boring; concede in plain words, then give a plan in the future tense |
| Data-Driven Prober | Reads your lines closely; asks how numbers were counted | Medium. The JD names retention metrics and you presented them monthly; no interviewer profile was available to raise or lower it | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational/Rapport | Friendly opener, casual questions that are still scored | Medium. Any 60-minute round opens somewhere; the arc is cheap to prepare | A 90-second arc from your own sentences; treat casual questions about live events as scored |
| Pressure | Time-boxed, devil's advocate, "how much was you" | Low to medium. Nothing in the inputs signals it, but E2 is a standard attribution probe | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |
| Values/Behavioral | Scenario probes on behavior | Low. Your note describes one session with the Head of Live Operations and names no values round | Where no story of yours fits, use the selection scaffold and its honest branch |
| Peer Evaluator | Seam-splitting, credit and disagreement | Low. Tobias leads the function you would join, so he is not a peer; the cross-team lines in the JD still make a seam question plausible | Propose seam principles rather than pretending to know the seam; reciprocity framing |

Weights used for the banks: Case 5, Skeptic 5, Prober 3, Conversational 3, Pressure 2, Values 2, Peer 2.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "An event goes live in three weeks and engineering tells you the build will be a week late. What do you do?" | CASE | [generic] | Structure it aloud: what you would ask first (what slipped, what else depends on it, what is locked), the options (cut scope, move the date, ship in stages), who needs to hear what and in what order across design, art, engineering and community, who decides, and what you would write down afterwards. The question needs no claim about your past, so the guidance makes none | The JD's coordination and release lines (F2, F4) turned into a decision. CASE because it scores structure under a live constraint. Generic because it is a pattern for the problem, not a fact about this employer |
| A2 | "You're building the live-events calendar for two titles that draw on the same design, art and engineering teams. How do you build it, and what do you need to know first?" | CASE | [generic] | Clarify first: the goal for each title, what each team can take on and when, what cannot move. Then structure: fixed dates against flexible ones, a check for collisions across the two titles, a review point after each event. Say the plan in the future tense. The question needs no claim about your past, so the guidance makes none | F1's requirement stretched to two titles, which is where your material is thinnest. CASE because it scores clarify-then-structure |
| A3 | "Day-7 retention for the latest event cohort is below the previous event's. Diagnose it." | CASE | [generic] | Clarify the metric and the cohort definition before anything else. Then compare against a baseline, split the cohort, check what else changed in the same window (release, bug, another event, a collision on the calendar), state two or three hypotheses, say what you would ask each team, and what you would decide. Name the assumption in your approach you would defend least | F7's requirement as a live problem, the persona stem for the Case/Strategist. CASE with metric content; generic because it is a pattern |
| A4 | "Walk me through how you would run a post-event review: who is in it, what gets reported, what happens next." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Start from what your material carries: "I presented the monthly retention numbers to the studio head." Then structure the hypothetical in the future tense: the objective set before the event, the KPIs agreed before it, results against a baseline, what to repeat and what to change, an owner and a date for each action, and a written summary. Answer slot: the JD pairs the review with the KPIs it reports, so expect a probe on who chose them. If you had any say in which numbers were reported, say how you decided; if not, say so plainly and stay with presenting them | F3 is the evidence for the review-and-KPI requirement and a likely probe. JD because it scores the stated responsibility; the delivery is CASE-like, but the tag follows what is scored |
| A5 | "Design, art and engineering all want different things from the next update. How would you decide what goes in?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | A hypothetical, so answer in the future tense: ask what the goal of the update is, state the criteria aloud before ranking anything, say who decides and when it escalates, and record why. Answer slot: the JD names four teams, so expect a probe on which you have worked with. If you worked with any of them on a drop, say which and what you did, in your own words; if none, or it was not your part, say so plainly and stay with the calendar you ran | F2's requirement as a decision. JD because it scores coordination; the premise is the JD's, and the guidance does not adopt it as your history |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick one honestly, and pick one your own words already stop short of: "I haven't worked on a game with in-app purchases." Then give the ramp as a plan in the future tense: what you would ask for first, who you would sit with, what you would read before your first event. Do not describe the plan as something you have done. If a different row feels weaker to you, F1 and F3 are the other places your quotes stop short of the JD's wording | The standard skeptic opener, and the one where choosing the weakness yourself reads as self-awareness. JD because it scores the listed job including its gaps; F9 is the source of the plain acknowledgment |
| B2 | "Our titles are mobile. Have you worked on a game with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Open with the plain answer, short: "I haven't worked on a game with in-app purchases." Hold the structure through four follow-ups. First, "How would that show up on day one?": say what you would ask and who you would learn from, as a plan. Second, "Why should we take that on?": return to what your quotes carry, "I ran the weekly content-drop calendar for our main title for the last two years." Third, "What would you do in your first month?": a concrete ramp, in the future tense. Fourth, "What if it is bigger than you expect?": say plainly what you would not yet be able to judge, and who you would check with. The concession is the plain sentence; never fold on the calendar quote to restore harmony, and never add to it | The one objection the pack expects in some form, chosen as the gap you stated yourself and the one no quote of yours carries; this is the pack's inference, since the JD does not say how much weight it carries. EXP because the probe is about what you did, and a stated negative gets the plain acknowledgment F9 allows |
| B3 | "You ran the calendar for your main title. This role covers two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold it at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Then think aloud on what changes, in the future tense: collisions across the two, shared teams, one review per title or one for both. Answer slot: if you ever planned for a title beyond your main one, say what that was and what part was yours; if not, say so plainly and stay with the calendar you ran. Concede only what the slot's second branch says | F1 is where the JD presses hardest on the calendar. JD because it scores the stated requirement; the premise is your own quote's scope and the JD's two titles |
| B4 | "Why live operations, why here, and why now?" | JD | [generic] | No sentence of yours states a motive, so this is a selection scaffold. Pick what drew you to running live content, in your own words; add one thing from the JD you actually want to do, for example the post-event review; say why now. Nothing in this pack knows Saltmarsh's own plans, so do not borrow any: ask the recruiter or Tobias. If no reason comes to mind, say so plainly, then say what you would want to find out | The motivation probe every skeptic runs. JD because it scores fit with the listed role; generic because the pack has nothing of yours to quote and no company research |
| B5 | "Have you led a team before?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Wrote the release checklist our QA team still uses." | Plain answer first: "I haven't led a team." Then stay with what the JD asks, which is coordination (the pack's observation, from the JD's wording). Answer slot: if you worked with design, art, engineering or community on any drop, say which and what you did, in your own words; if not, say so plainly and stay with the one thing your quotes carry: you wrote the checklist your QA team still uses | F10 is a stated negative and F2 is where the JD's real ask sits. EXP because it scores whether your background claim holds; the second quote is the nearest working relationship your material carries |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers. Walk me through how they were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start with the quote at its scope. Answer slot: if you know how the figures were counted, what they are sensitive to, and which assumption you would defend least, say so in your own words; if you do not know any of these, say so plainly. Say which part was yours: the quote says you presented them. Do not name a definition or a method you cannot repeat under a second question | F7 is the evidence for the retention requirement, and the Prober's whole job is to find where it stops. EXP because it is an attribution and defend-the-number probe |
| C2 | "Which retention measures would you look at first when judging a live event, and what can each not tell you?" | JD | [generic] | A conceptual answer, in the future tense: name one or two measures you would start with and define them in your own words, then say what each can mislead on. State a baseline before you state a result. Claim no experience beyond what C1 lets you say. If you already track a measure in your current work, say which and how you read it; if you do not, say so plainly | The JD's retention line asked as judgment rather than history. JD because it scores the stated skill; generic because it is a pattern |
| C3 | "A stakeholder says an event worked because sessions went up. What do you ask?" | CASE | [generic] | Ask what the baseline was, which cohort, whether sessions rose while retention stayed flat, and what else changed that week. Then say what you would report and what you would hold back until more data arrives. No claim about your past | A small live problem in the Prober's register. CASE because it scores reasoning about a number; generic because it is a pattern |

### D. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with exactly these four beats, in this order, each as you wrote it. Then one sentence on why this role. Answer slot: if you can say in your own words why you want live operations, say it; if no reason comes to mind, say so plainly and say what you would want to find out. Leave out anything your four sentences do not carry | The opener most likely to be asked in a casual register and still scored. EXP because it tests whether the biography matches your documents |
| D2 | "What are you actually playing these days, and what do you make of how it runs its events?" | JD | [generic] | A selection scaffold: pick one live game you actually play, one event you noticed in it, and one thing you would have scheduled or communicated differently. Keep to what you saw as a player. If you do not play live games at the moment, say so plainly and name the one you have looked at most closely | The persona stem asked about the JD's plus-skill, live events. JD because it scores interest in the listed work; generic because it asks for no claim about your past |
| D3 | "Tell me about the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say it at its scope: you wrote it, and your QA team still uses it. Answer slot: the JD says manage the checklist with QA, so expect a probe on how you and QA used it. If you updated it with QA or ran releases against it, say how, in your own words; if you did not, or it was not yours, say so plainly and stay with having written it | F4 is the cleanest row in your snapshot and the one a friendly interviewer will pull on. EXP because it tests what was actually yours |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold: the three things you have, each as written. Concede in plain words: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to the same three sentences, never adding to them. Do not claim the comparison; let them draw it | The stress stem, aimed at F9, the one gap you stated. JD because it scores fit against the listed role; the held position is only what the quotes carry |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold the quote's own verb: "I wrote it." Answer slot: if QA or anyone else shaped it, say what they did and what was yours; if you wrote it alone, say so; if you do not remember who did what, say so plainly. Never upgrade or shrink the verb under pressure | The attribution probe the Pressure persona runs on any strong line. EXP because it scores precise attribution |

### F. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unwelcome truth to leadership." | VAL | [generic] | A selection scaffold. Pick a time you told a senior person something they did not want to hear; it needs a named stake, what you said, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "Presented the monthly retention numbers to the studio head.", or how you would handle it | The persona stem; no company values were researched, so this is generic behavioral rehearsal. VAL because it scores past behavior; low weight because no values round is named |
| F2 | "When did you put the players' experience ahead of an internal number?" | VAL | [generic] | A selection scaffold. Pick a decision where the number said one thing and the player experience said another; it needs the decision, what you gave up, and what happened. If no such decision comes to mind, say so plainly, then say how you would weigh it | The persona stem, adapted to the JD's community and retention themes. VAL because it scores behavior; generic for the same reason as F1 |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Live operations sits next to design, engineering and community. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles instead of claiming to know the seam: who owns the date, who owns the content, who owns the player message, and who breaks a tie. Add what you bring them, not only what you need. No claim about your past | The JD's four named teams as a collaboration probe. CASE because it asks for a structure; low weight because Tobias is not a peer |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold. Pick a piece of work that spanned teams; use "we" for context and "I" for your contribution. If no such work comes to mind, say so plainly, then say how you would handle it | The persona stem. VAL because it scores collaboration behavior; low weight, kept so no style is met for the first time live |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A2, B3, D2 |
| "coordinate design, art, engineering and community teams on each update" | A1, A5, B5, G1 |
| "own the post-event review and the KPIs it reports" | A3, A4, C1, C2 |
| "manage the release checklist with QA" | A1, D3, E2 |
| "3+ years producing live-service games or apps" | B1, D1, E1 |
| "experience running a content calendar" | A2, B3 |
| "comfortable with player-retention metrics" | A3, C1, C2, C3 |
| "clear written communication" | none, and why: it is a spoken interview and no question is built on it; A4 and D3 touch the written items your material carries |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do the two titles share design, art and engineering time, and who settles a collision?" | Shows you are already thinking about the cross-title calendar, which is where your material is thinnest, and gets you the real answer |
| R2 | "What does a good post-event review look like here, who reads it, and what has changed because of one?" | Ties to the JD's review line and tells you whether the review is a ritual or a decision tool |
| R3 | "Which KPIs does this role report, and who chose them?" | Surfaces whether you would own the KPIs or inherit them, which is the exact line F3 stops short of |
| R4 | "What would you want a new producer to have shipped or learned by day 60?" | Hands you a concrete target and signals you plan to ramp |
| R5 | "How do new producers get up to speed on the two titles?" | Lets you ask about the ramp without apologizing for the in-app-purchase gap |
| R6 | "Where does the producer's work end and the community team's begin?" | A seam question that shows you respect the neighbouring teams |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title. B3's slot stays inside the calendar |
| Owned the post-event review or the KPIs | Inflated form of F3 | F3's quote at its own scope. A4's slot asks only who chose the numbers presented |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist your QA team still uses. D3's slot stays with the checklist |
| Four years producing live-service games | Inflated form of F5 | F5's two quotes at their own scope: four years as an associate producer, two of them running the calendar. The limit is the pack's observation; F5's slot asks only whether the earlier years involved live content |

## Sources

Provided documents: the JD text and your background, both pasted in your message. No dossier.

Searches sent, all refused by the host (no permission was granted), none returned anything:

- `Saltmarsh Games mobile studio values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games news strategy mobile titles` — refused
- `Tobias Wrenfield Saltmarsh Games` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have named the studio's published values for a cheat sheet and themed the VAL questions; no values round is detected from your note, so section 10 is absent and F1 and F2 in the Values bank are generic |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have documented the loop; persona weights rest on your note (one 60-minute session with the Head of Live Operations) and the hiring-manager prior |
| 3. `Saltmarsh Games news strategy mobile titles` | unavailable | Would have fed company-strategy CO questions; none are in the banks, and the CASE questions are generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have fed the interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A research pass, if your host grants search: the studio's values page, loop and recent news, so the Values bank can map to published values, the CO and CASE questions can use the studio's own vocabulary, and the research rows above stop reading unavailable
- Tobias's public talks, posts or profile, pasted: an interviewer read, tuned persona weights, and a reverse question tied to his own path
- Confirmation that Tobias is the hiring manager, plus anything the recruiter said about focus areas or a take-home: persona reweighting and, if a deliverable was named, its own build section
- A line on whether your weekly drops included timed events, and whether the earlier years at your studio were also live: F1 and F5 upgrade, and A5, B3 and F5's slot tighten
- One line on who chose the retention numbers you presented and whether you know how they were counted: F3 and F7 upgrade, and C1 becomes a story-mapped answer
- The two titles' names and what you have noticed in them: D2 becomes specific
- One line on any teams you worked with on a drop: F2 upgrades and A5 and B5 become story-mapped
- A past `tuesday-dossier.md`, if you have one: a sharper highest-ROI objection and stricter limits on what the guidance may say
