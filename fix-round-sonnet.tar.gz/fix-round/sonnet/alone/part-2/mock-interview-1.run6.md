I'll read the reference files the skill requires before writing anything.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-1-denied-d7840aeb/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 21 questions across six personas, each tagged by type with answer guidance, provenance and rationale. It also has the fit snapshot, a reading of Dan, a persona table that shows its weighting, a requirement-coverage table, reverse questions, the claims it won't coach, sources and an upgrade menu.

I built it as a peer round: one 60-minute conversation with Dan, who reports to the same VP. The persona weights are the Prober and Peer Evaluator first, then the Skeptic, Case, Conversational and Pressure. Web searches were refused, so nothing in it comes from research. Northwind's priorities and Dan's profile are used exactly as you described them, unchecked, and the Sources section says so.

The highest-ROI prep is C1: "I don't see classic sales-ops or quota-setting experience in your background." The gap sits inside Dan's own function. The guidance is a four-level hold-then-concede that returns to what Priya's notes actually say. It keeps "annual volume targets" from being relabelled as quotas.

Several answers can only come from Priya. Her notes don't show whether any past work covered whitespace, an independent SQL/Tableau analysis, partner-motion design, or how the ~$400M was counted. Those are marked as answer slots, with an honest second branch if the practice wasn't hers.

I can run a live drill with me as Dan, starting with C1 or A1, if you say the word. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer reporting to the same VP. **Format:** one 60-minute conversation.

Built from the coach's notes alone: a JD summary rather than full JD text, a one-paragraph candidate summary rather than a CV, a description of Dan's profile, and a short research note on Northwind's priorities. Web searches were attempted and refused, so nothing here comes from research (see Sources).

## How to use this pack

- **Personas are how a question arrives; types are what it scores.** Bank A is the Data-Driven Prober, B the Peer Evaluator, C the Skeptic, D the Case/Strategist, E the Conversational / Rapport Builder, P the Pressure interviewer. Fit-snapshot rows are F1 to F7, question IDs are A to E and P, so the two never collide.
- **Type key.** VAL: whether past behavior shows the company's published values. EXP: whether your claims survive scrutiny and what was actually yours. JD: whether you can do the listed job, gaps included. CO: homework depth on the company's strategy. CASE: structure and reasoning on a live problem.
- **Guidance is scaffolding, not a script.** Every statement about your past in a guidance cell rests on a sentence quoted in that row's Provenance column. Anything the quotes do not carry is an **answer slot**: an instruction for what to say in the interview, answered from your own experience, with an honest second branch if the practice was not yours or never existed.
- **The quotes are one-line summaries from the coach's notes, not CV lines.** Treat each as a claim with nothing inspected behind it and expect a probe.
- **You will not be asked all 21 questions in 60 minutes.** The top of each bank is the priority; the most important single item is C1.

## Fit snapshot

Requirements are the JD highlights as the coach supplied them. Evidence cells hold only the notes' own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm" — the coach's notes; "9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops work and a proposed change, not a GTM launch, and the words stay at that scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." These are notes lines with nothing inspected behind them, so expect a probe on the figure (A1, A2, P2). Answer slot: the JD's new-product-lines wording makes a probe on whether your work reached a launch likely. Say, in your own words, what your product strategy and ops work covered at the point a product reached customers; if it never reached that point, or that stage was not yours, say so plainly and stay with the roles you held |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | none given | none | [grounded] | discovery | Your material shows no work along these stages, and it does not say there was none either. Answer slot: the JD's lifecycle line makes a probe on past whitespace work likely. If any past work looked for under-served customers or revenue along stages like these, say what it found and what part was yours, in your own words; if none did, or it was not yours, say so plainly and say how you would start (D2 rehearses that as a live problem) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | low | [grounded] | discovery | The line names the tools and no analysis, and at low confidence it is a lead, not a claim, so no speakable sentence is proposed from it. Answer slot: the JD's analysis wording makes a probe likely. Say what you have used the tools for and what part of that was yours alone, in your own words; if the work was a team's, or you have not used them that way, say so plainly and stay with what you can describe |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." It does not say how the carriers related to Northwind-style partner motions. Answer slot: the JD's partner-motion requirement makes a probe on the model's place in the negotiations likely. Say what the model was used for there and which part of that was yours, in your own words; if the model fed the negotiations and nothing more of the relationship was yours, say so plainly and stay with the model and the negotiations |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a notes line with nothing inspected behind it, so expect a probe on how the consensus formed (B2). Lead with the quote's own terms: you set annual volume targets, with cross-org consensus. Keep the word targets; F7 is why it must not become quotas |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | Your material says use of AI tools, not work on AI products, and the words stay there: "I use AI tools daily." Answer slot: the JD's AI line and Compass launch make a probe on what the tools are used for likely. Say which tools and for what, and how you check what they give you, in your own words; if none of the use touches work like this role's, or you do not check systematically, say so plainly and stay with the line |
| F7 | Sales-operations and quota-setting work — not among the JD highlights; the coach named it as the exposed area against this interviewer's function | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the candidate's material says so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller, and F5's targets stay targets |

No row is a `hard_gate`: nothing in the material is a term the candidate meets or does not, such as authorization, location or a credential.

## Reading the interviewer

Everything about Dan below is the coach's description of his profile, not something verified; the searches that could have checked it were refused. Public professional footprint only.

| Signal | Source | What it means for prep | Provenance |
|---|---|---|---|
| Profile calls himself "relentlessly data-driven" | the coach's description | Every figure you give is likely to be taken to its assumptions. Prepare A1, A2 and A4 first, and say plainly when you do not know how a number was counted | [grounded] |
| Career spine in pricing and monetization roles | the coach's description | Case questions tilt toward pricing, packaging and unit economics, his native vocabulary: D1, D3 | [grounded] |
| One early-stage-startup chapter | the coach's description | Expect a probe on working without large-company machinery (C4). No shared jump is offered: no row carries a candidate side of that chapter | [grounded] |
| Peer, same VP as the new hire | the coach's description | Seam, credit and reciprocity questions: B1, B3, B4. He is pricing what you cost and add to his work | [grounded] |
| Mirror opportunity, shared vocabulary: monetization | his path above beside F4's "built a partner-level revenue model used in carrier negotiations" | Use the word revenue where you speak of the model, at its own scope: the quote says a revenue model, not pricing work, so do not borrow his term for it | [grounded] |

## Persona table

Weights are built in three passes: relationship prior (peer: Peer Evaluator and Prober), interviewer signals, then the loop. The loop is one 60-minute conversation with Dan, established by the coach's own words; no values-style round is detected in it.

| Persona (bank) | How it shows up in this round | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A) | Dan reads the numbers line by line and goes two levels deep on each | 5. Peer prior, raised by the "relentlessly data-driven" self-description | Know what you can and cannot say about how each figure was counted; say plainly when you do not know; name the weakest assumption before he does (A1, A2) |
| Peer Evaluator (B) | Seam-splitting between his team and the new role, credit, what you would need from him | 5. Peer prior; same-VP relationship makes the seam the live issue | Reciprocity framing; propose seam principles rather than pretend to know the seam; disagree with spine and tact (B1, B4) |
| Skeptic (C) | The gap against his own function, plus pace without large-company machinery | 4. The stated sales-ops and quota gap sits inside his function, and a startup chapter raises the pace probe | Rehearse C1 until it is boring: plain acknowledgment first, then only what the quoted sentences carry, then a plan |
| Case/Strategist (D) | Live problems on Compass, whitespace and bundling | 3. Peer prior is secondary; his pricing spine tilts cases to packaging and pricing | Clarify, objective, segmentation, approach, metrics, risks; state a hypothesis early; challenge one premise |
| Conversational / Rapport Builder (E) | The biography opener and a casual AI question | 2. Opening of a 60-minute conversation is usually this register, but it is not the peer prior | Prepared 90-second arc; treat the casual AI question as scored |
| Pressure (P) | Time-boxed challenges to the gap and the headline figure | 2. Not a peer prior and no signal for it, but both of the pack's biggest exposures lend themselves to it | Pause, restate, hold two follow-ups, concede specifically |
| Values/Behavioral | Not run as a bank | No values-style round is detected and no published values could be retrieved. Cross-functional behavior is covered in B2 and B3 | Not applicable |

## Question banks

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F1, with the three beats the quote states: you proposed the change; the uplift was credited to it; the figure is about $400M, tilde kept. Then four answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say that plainly and return to the quote. Never name a method, baseline or attribution model you cannot repeat under a second question | F1 holds the pack's only headline figure, so it is the likeliest first probe from a data-driven peer. EXP because it tests counting and attribution |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name, in your own words, the assumption you would defend least before he does. If you cannot name one, say plainly that you do not know how the figure was counted and say what you would check first to find out. Stay at the quote's scope: you proposed the change, and the credit is attached to it | The second level of A1; naming the weak point first converts a gotcha into a credibility gain. EXP because it scores attribution honesty |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau, from the question to the answer." | JD | [grounded] "skilled in SQL/Tableau" | F3 is low confidence, so no story is mapped. Selection scaffold: pick an analysis where the question was clear, you wrote the queries or built the view, and you can say what you would defend least about the result; walk it question, data, method, result. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, that you are skilled in SQL/Tableau, and say how you would approach one | The JD names SQL and Tableau and the word independent, and Dan's self-description makes this the line he is most likely to test. JD because it scores a stated requirement; an open prompt with its theme from the JD |
| A4 | "Walk me through the partner-level revenue model. What was it for in the carrier negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4, with the two beats the quote states: you built a partner-level revenue model; it was used in carrier negotiations. Answer slot: the JD's analysis line makes a probe on which parts you built yourself likely. Say which parts of the model were yours and how you built them, in your own words; if someone else supplied or built any of it, or none of it was in SQL or Tableau, say so plainly and return to the model and the negotiations | F4 and F3 meet here: it is the only quoted work that is both analytical and partner-facing. EXP because it asks what the candidate actually did |
| A5 | "A product line has six months of usage and billing data. Which metrics tell you whether it is landing, and which would you distrust first?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify the product's objective and customers first; choose a small set of metrics across land, adopt, expand and renew; for each, say how it can mislead; name the one you would distrust first and why; say which cuts you would make before believing any of them. Say your weakest assumption aloud | Gives Dan the measurement conversation he is likely to enjoy, on F2's ground and F3's tools, without requiring any past. CASE because it is a live problem; `[generic]` because it is a pattern, not a fact about Northwind |

### B. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between what you would own and what I own, and what happens when we disagree?" | JD | [grounded] | You do not know Northwind's current seam, so propose principles rather than a map: one agreed definition for any number both teams use; disagree about the numbers before the positions; agree in advance what goes to the VP and what does not. Then ask Dan where the seam sits today. The same-VP fact comes from the coach's notes. The question needs no claim about your past | The same-VP relationship makes the seam the live question for this round. JD because it scores the cross-functional requirement (F5) as it applies to this actual pairing |
| B2 | "Tell me about a time you needed agreement from teams that did not report to you." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5, with the two beats the quote states: you set annual volume targets; the consensus was cross-org. Answer slot: the JD's influence wording makes a probe on how the consensus formed likely. If the orgs disagreed, say about what, what moved them and what part was yours, in your own words; if they did not, or the consensus came from someone else's work, say so plainly and stay with the targets and the consensus. Keep the word targets | F5 is the evidence for the influence requirement and the likeliest place to be probed. EXP because it tests which part was the candidate's |
| B3 | "When work spans teams, how do you handle credit?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Selection scaffold: pick a time work spanned teams, with a named teammate, what each side contributed, and how credit was said aloud. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you proposed a store-surface change credited with a ~$400M ARR uplift, and say how you would handle credit in a case like it. Never replace "proposed" with a stronger verb | A peer probes credit because it signals whether the hire adds to or reduces his load. F1's wording is the one place where credit is already in the material. EXP because it tests attribution habits |
| B4 | "What would you need from my team in your first 90 days, and what would my team get from you?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Reciprocity framing. The need, as questions, not assumptions: how Sales Strategy defines the lifecycle stages and which numbers the VP reads. The give, at the quotes' scopes: you built a partner-level revenue model used in carrier negotiations; you set annual volume targets with cross-org consensus. Plans for the first 90 days are plans, said as such | Peers weight what the hire adds to their work. JD because the role's scope (F1) is what the answer defines; F4 and F5 are what the give rests on |
| B5 | "Compass is launching while a much larger platform vendor bundles against us. Where would your work and mine collide?" | CO | [grounded] | Frame on the three priorities from the coach's research note: enterprise expansion, the Compass launch, profitability, with bundling as the main threat. State a hypothesis early: say which priority you think the two roles share most and why, then ask Dan whether that matches how it looks from sales strategy. The note is unverified, so claim no Northwind internal facts. No claim about your past | The only CO question grounded in Northwind's stated priorities. CO because it tests altitude on strategy; peer delivery because the collision is the seam |

### C. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting experience in your background. How would you handle that in this role?" | EXP | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus" | **Highest-ROI prep in the pack.** Four levels. 1) Plain acknowledgment first, in these words: "I don't have classic sales-ops or quota-setting experience." No softener, no padding. 2) Then what the material carries, at its scope: "I set annual volume targets with cross-org consensus." Keep targets as targets. 3) If he asks whether that is the same thing, hold the distinction you can actually draw; if you cannot say how they differ from direct experience, say so plainly and ask how his team draws the line. 4) If he asks whether he would be teaching you his job, concede specifically: the quota mechanics are what you would learn from his team, offered as a plan (what you would ask for and read first), never as a past. Return to the two sentences each time; never add to them | The gap sits inside Dan's own function and the candidate has stated it, so this question will arrive in some form. F7 is the source of the negative and F5 of the nearest work. EXP because it tests what the candidate's material carries; first in the bank because it is the most predictable objection |
| C2 | "You have set annual volume targets. How is that different from setting a quota?" | EXP | [grounded] "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience." | Keep two parts apart. What you did, at the sentence's scope: you set annual volume targets with cross-org consensus. The difference: give it as you understand it, and say aloud which part you know from doing and which from reading or hearing. If you cannot draw it, say so plainly and ask Dan how he draws it. The pack deliberately supplies no definition, since one you cannot defend is worse than none | F5 and F7 meet here, and a Director of Sales Strategy is the person most likely to test the line. EXP because it probes a notes sentence |
| C3 | "The role calls for partner-motion design experience. What do you bring there?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: you built a partner-level revenue model; it was used in carrier negotiations. Answer slot: say what the model was used for in those negotiations and which part of that was yours, in your own words; if the model fed the negotiations and nothing more of the relationship was yours, say so plainly and stay with the model and the negotiations. Hold through one follow-up by returning to the model, never by adding to it | The JD marks it required and F4 is a stretch of it, so the objection is predictable. JD because it scores a stated requirement |
| C4 | "You have spent most of your career inside a large company. Our two new lines are early. How do you work when the machinery is not there yet?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Selection scaffold: pick a time you worked without the usual tooling or support, with a named gap, what you did about it, and how you knew it worked. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: your years in product strategy and ops at a large consumer-tech company, and how you would approach an early line. Do not claim scrappiness the material does not show | Dan's early-stage chapter makes a big-company-pace probe likely. F1 is the only row about the candidate's setting. EXP because it tests what the career history shows |

### D. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Compass is a new AI copilot going to enterprise customers. How would you approach its pricing and packaging, and what do you need to know first?" | CASE | [grounded] | Say the framework aloud. Clarify: who buys, what it replaces, what the larger vendor's bundle includes. Objective: your note lists enterprise expansion and profitability as priorities, so say which one you would optimise and why. Then segmentation, two or three packaging options with the trade-off of each, metrics, risks, and challenge one premise, for example whether to price against the bundle at all. No claim about your past | Dan's pricing and monetization spine tilts cases toward this ground. CASE because it is a live problem from the actual role; it also exercises F1 |
| D2 | "Say you owned whitespace for one of the new lines. How would you find it across land, adopt, expand and renew?" | JD | [generic] | Clarify the line and the data that exists; define what whitespace means at each stage; say what cut you would make in SQL and what view you would put in Tableau; name the assumption you would trust least. The question needs no claim about your past, so the guidance makes none | F2 has no evidence, so this is rehearsed as a live problem instead of a story. JD content with CASE delivery; `[generic]` because it is a pattern, not a fact about Northwind |
| D3 | "A much larger platform vendor starts giving away a capability that overlaps ours. What changes in the GTM for the new lines?" | CASE | [grounded] | Clarify the overlap and which line is exposed. Offer two or three hypotheses, such as differentiate, narrow the segment, or reach buyers through partners, each with its trade-off and a metric. Challenge the premise that matching free is the goal. Present any partner idea as a hypothesis, not as experience. No claim about your past | Bundling is the main competitive threat in the coach's research note. CASE because it asks for structure on a live problem |

### E. Conversational / Rapport Builder (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey: consulting, then consumer tech, and now here." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | A 90-second arc. Beat one: the two stretches, at the sentences' scope. Beat two: one piece of work from the second, either the revenue model used in carrier negotiations or the volume targets set with cross-org consensus. Beat three, answer slot: say in your own words why GTM at a B2B data-infrastructure company and why now; if you do not yet have a clear reason, say so plainly and name what you want to find out. The pack does not supply your motive | The opener of a 60-minute conversation is usually this register, and it is scored. EXP because it tests whether the history is told accurately; F1 is the row it draws on |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it at that scope: you use AI tools daily. Answer slot: say which tools and what for, in your own words. Because Dan describes himself as data-driven, expect "how do you check what it gives you"; say how you check outputs if you do, and if you do not check systematically, say so plainly. If none of the use touches work like this role's, say so plainly. Do not describe building AI features | F6 is a plus in the JD and Compass is a launch priority, so a casual AI question is scored. JD because it scores a stated plus |

### P. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you, rather than someone who has run sales ops and quotas?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience." | Pause, then restate the question aloud. Open with the plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Then the two sentences, in your own words: you built a partner-level revenue model used in carrier negotiations; you set annual volume targets with cross-org consensus. Hold through two follow-ups by returning to them, never by adding to them; concede that the quota mechanics are what you would need to learn. Do not say what the work proves | Pressure tests composure on the pack's biggest exposure. JD because the question is a version of "can you do the job, gaps included"; F7 is the gap |
| P2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold, then concede. Restate the question. What you can say at the sentence's scope: you proposed the change, and the uplift was credited to it. Answer slot: if you know what share was yours and how you know it, say so in your own words; if you do not know how it was counted, say that plainly. Never use "drove", "delivered" or "owned" | Attribution is the probe this stem exists for, and F1 is the only headline figure. EXP because it tests what was actually the candidate's |

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| F1 own GTM strategy for two new product lines | B4, B5, D1, D3, C4, E1 |
| F2 whitespace across land/adopt/expand/renew | D2, A5 |
| F3 independent analysis in SQL and Tableau | A3, A4, A5, D2 |
| F4 partner-motion design experience | C3, A4 |
| F5 cross-functional influence | B1, B2, B3, B4 |
| F6 AI experience | E2 |
| F7 sales-ops and quota-setting (not in the JD highlights) | C1, C2, P1 |
| Values-style questions | none: no values-style round is detected and no published values were retrieved, so VAL is unused |

The JD highlights are a summary; mid-list requirements in the full text may be uncovered until it is supplied.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your background includes pricing and monetization roles and an early-stage chapter. What from either do you use most in Sales Strategy here?" | Ties to his own path, so it turns the slot into a peer conversation and shows you read his profile |
| R2 | "What could a new person on my side do in the first month that would genuinely help your team?" | The reciprocity question for a peer: it asks what the hire can add, not only what you need |
| R3 | "Who owns the definitions for land, adopt, expand and renew today, and where do they differ between Sales Strategy and the product lines?" | A data-driven peer will care about definitions; it also tests the seam from B1 |
| R4 | "How do disagreements between Sales Strategy and a product-line owner usually get resolved here?" | Surfaces how the VP and the two roles actually work, and shows you take the seam seriously |
| R5 | "With Compass launching and a larger vendor bundling, which is more likely to constrain the pricing and packaging conversation: margin goals or competitive pressure?" | Uses the three priorities in the research note and invites his pricing view |
| R6 | "What would make you say, a year from now, that this hire had made your work easier?" | Gives him room to name what he is pricing in; it also tells you what to prioritise in the first 90 days |

## Prohibited claims

Built from the fit snapshot before the banks were written. None of these is coached, and no slot, hold, bridge or rationale asserts or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led GTM strategy for new product lines | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material says product strategy and ops work and a proposed change, not a GTM launch |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F1 | "Proposed a store-surface change credited with a ~$400M ARR uplift", at that scope. The material says proposed, with the credit stated on the change, and nothing on who counted it |
| Has designed partner motions or managed channel partners | Inflated form of F4 | F4's quote at its own scope: a revenue model used in carrier negotiations. The material does not say the carriers were partners of that kind |
| Has set quotas or has sales-ops experience, or that the volume targets were quotas | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." F5's quote stays as volume targets. No slot |
| Runs analyses independently in SQL and Tableau | Inflated form of F3 | F3's quote at its own scope, as a lead. The material names the tools and shows no analysis |
| Has built or launched AI products or features | Inflated form of F6 | F6's quote at its own scope: use of AI tools. The material shows use, not building |

## Sources

**Provided documents:** the coach's message, which supplied the role and company, the JD highlights, the candidate summary, a description of Dan's profile, and a research note (three priorities and the main competitive threat). The note and the profile description are used as given and could not be checked.

**Searches sent:**

| Query | Outcome |
|---|---|
| Northwind Data company values principles | refused |
| Dan Kovac Director Sales Strategy Northwind Data | refused |
| Northwind Data strategy Compass AI copilot enterprise expansion | refused |

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The one search was refused. It would have supplied value names as raising sources for VAL questions; none are used |
| 2. Northwind Data interview process, role family | skipped | The coach's own words fix the loop: one 60-minute conversation with a peer. Persona weights follow from that |
| 3. Northwind Data strategy, recent news | unavailable | The one search was refused. It would have checked the research note and refreshed B5, D1 and D3; they rest on the note as given |
| 4. Dan Kovac, Northwind Data | unavailable | The one search was refused. It would have checked the profile description and added published themes to the interviewer read and the reverse questions |
| 5. representative role JD | skipped | The JD highlights fix the fit-snapshot rows and the JD-tagged questions; full text would add mid-list items |

## Upgrade menu

- Full JD text → the six highlight rows quote the JD itself rather than a summary, and any mid-list requirement gets a question or a stated reason it does not
- The recruiter's note on what the conversation with Dan will cover, or any pre-declared deliverable → coverage of a graded deliverable if one exists and reweighting of the banks; usually one email to the recruiter
- The candidate's own CV lines in place of the coach's summary → F1 to F6 quote the CV, and confidence can rise where an artifact is named: the model file or negotiation deck behind the revenue model, the readout or finance document behind the ARR figure, a query or Tableau view she authored
- The candidate's own answers to the slots in F1, F2, F3, F4 and F6 → those rows move from discovery toward grounded story maps, and A1, A3, A4, C3 and E2 regenerate with real beats
- Search access, then a deeper research pass (up to 6 further searches and 2 further fetches, several more minutes) → the values and strategy checks, Dan's public talks and writing, and a grounding brief; offered once
- A working-style assessment, if the candidate has one → a delivery-coaching section keyed to question IDs
- Dan's profile text or any talks he has given, pasted in → a sharper interviewer read and a second reverse question tied to his path
- A tuesday-dossier.md from the job-underwriter skill → verified evidence, a constraint on each weak area, and an evidence-derived top objection in place of the inferred one
