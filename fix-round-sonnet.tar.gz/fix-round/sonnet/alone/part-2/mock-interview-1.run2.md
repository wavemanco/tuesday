I'll read the reference files the skill requires before building the pack.
The pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-1-denied-8c00623a/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. It has 22 questions across seven personas, weighted for a peer round with Dan: Peer Evaluator and Data-Driven Prober first, then Skeptic and Case. It also has a fit snapshot, an interviewer read, a requirement-coverage table, seven reverse questions and a list of claims the pack won't coach.

I built it from your message only. The two web searches (Northwind's values and Dan's public footprint) were refused. So there is no values cheat sheet, and the interviewer read rests on the profile you gave me. Anything about Priya that your message didn't state is an answer slot, not a supplied story.

The pack's highest-ROI prep is C1, the sales-ops and quota-setting objection. Dan runs sales strategy, so that gap sits on his home ground. It is rehearsed as an acknowledgment, then the nearest thing she actually has (annual volume targets with cross-org consensus), then a learning plan. It deliberately doesn't blur "targets" into "quotas". The second priority is B1, the ~$400M figure.

Say the word and I'll play Dan on C1 or B1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for carrying into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.
One further option: a one-page seam map between sales strategy and this role, which Priya could use as a discussion prop with Dan. I'll build it only if you approve.

Can you paste the full JD and Priya's CV, or tell me to proceed without them? Either way the pack stands, but the CV would turn several scaffolds into story-mapped answers.
Did the recruiter say anything about what Dan's session will focus on, or about a prep deliverable?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Mock interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya  
**Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind Data. Peer: both report to the same VP.  
**Round:** one 60-minute conversation with Dan.  
**Built from:** your message only (JD highlights, a summary of Priya, Dan's profile, your research note). No CV, no full JD, and web search was not granted, so nothing here comes from outside what you pasted.

## How to use this pack

- **Personas describe how a question arrives; types describe what it scores.** Rehearse both: the same fit question can come as a friendly aside, a collegial seam probe, or a challenge.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer from your own experience in your own words, or say plainly that the practice was not yours or never existed.
- The sentences quoted in the Provenance column are everything this pack knows about Priya. Anything beyond them is hers to supply.

| Type | What it scores |
|---|---|
| VAL | Behavior that shows values or working style, not generic virtue |
| EXP | Whether the experience claims survive scrutiny; attribution honesty |
| JD | Can she do the listed job, gaps included |
| CO | Company and strategy knowledge, thinking at Northwind's altitude |
| CASE | Structure and reasoning on a live problem from the role |

**Highest-ROI prep in the pack: C1**, the sales-ops and quota-setting objection. Dan runs sales strategy, so this gap sits on his home ground, and it will be asked in some form. Second: B1, the ~$400M number.

## Fit snapshot

Requirements are quoted from the JD highlights in your message. Evidence is quoted from your message. F7 is not a JD line; it is the pack's reading of the peer seam, so its requirement is plain prose.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | low | [inferred] | transferability | Product strategy and ops is adjacent to GTM strategy, and the words stay at the quote: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's GTM line makes a probe on whether any of that work was go-to-market work likely. If any was, say which part and what was yours, in your own words; if none was, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | Words at the quote: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." The material shows a proposal and a credited figure, not an analysis across customer lifecycle stages. Answer slot: the JD's whitespace line makes a probe on how the opportunity was found likely. If you found it by analysis, say how, in your own words; if it came from elsewhere, or no analysis step was yours, say so plainly and stay with the proposal. Confirmed, limited inspectable proof, so expect a probe on the figure |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — your message | medium | [grounded] | discovery | Words at the quote: "I'm skilled in SQL and Tableau." The material names the tools, not an analysis. Answer slot: the JD's independent-analysis line makes a probe on a specific analysis likely. If you ran one yourself, say what the question was and what you did, in your own words; if the work was done with or for others, or none comes to mind, say so plainly and stay with the skill. Confirmed, limited inspectable proof |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Words at the quote: "I built a partner-level revenue model that was used in carrier negotiations." The material shows a model, not a motion. Answer slot: the JD's partner-motion line makes a probe on what the model fed into likely. If any of the partner work went beyond the model, say what and how, in your own words; if the model was the whole of it, or the rest was not yours, say so plainly and stay with the model. This is a stated requirement, not a gate, so it is bridged on adjacent work and its limit |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | Words at the quote: "I set annual volume targets with cross-org consensus." The sentence says consensus, not how it was reached, and it does not say quota. Answer slot: if a probe asks how the consensus came about, say how, in your own words; if it came about differently or was not yours, say so plainly and stay with the targets |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — your message | low | [inferred] | discovery | Evidence is use, not more. Answer slot: the JD's AI line makes a probe on what you actually do with AI likely. Say which tools and for what, in your own words; if it is everyday use and nothing beyond that, say so plainly. Never presented as familiarity with Northwind's copilot |
| F7 | Sales-ops and quota-setting fluency; not a JD line, the pack's reading of the seam with a Director of Sales Strategy | "No classic sales-ops or quota-setting experience" — your message | none | [grounded] | capability | A gap wording cannot close, and it was stated. Words: "I have no classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. The pack does not bridge F5's volume targets into this; the sentence says targets, and the pack leaves it there |

## Reading the interviewer

Public professional footprint only, taken from the profile in your message. A web search for Dan was refused, so nothing below comes from his talks or writing.

| Signal | Source | What it means for the conversation | Where it shows up |
|---|---|---|---|
| Self-described "relentlessly data-driven" | your message | Every number is likely probed to its assumptions; name the weakest assumption before he does and say plainly what you do not know | B1, B2, B5, F1 |
| Career spine in pricing and monetization | your message | Cases will likely tilt to pricing, packaging and unit economics, his native language; ask him which levers he has seen move rather than performing expertise | D2, D3, R2 |
| One early-stage-startup chapter | your message | Expect a probe on how you work with less structure and a new line with no history; builder stories land well, and F1 to F7 carry none, so do not borrow one | C3, B4, R1 |
| Peer: same VP | your message | He is pricing what this hire costs and adds to his own work; reciprocity framing, seam principles instead of a pretended seam | A1, A3, A5, R3 |

**Mirror opportunity (shared vocabulary, not a shared jump):** his public path is pricing and monetization; the sentence from F4 that sits beside it is "built a partner-level revenue model used in carrier negotiations". Use it for fluency in revenue language only. It is not pricing experience, and his startup chapter has no counterpart in the candidate's quoted material, so it is not offered as a mirror.

## Persona table

Weights start from the peer relationship prior (Peer Evaluator and Data-Driven Prober dominant), then move on Dan's profile. The loop is documented only by your words: one session, no values-style round named, so Values stays low.

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy (a rehearsal method, not a claim) | Questions |
|---|---|---|---|---|
| Peer Evaluator (A) | Seam-splitting between his team and this role, what you need from him, credit and disagreement | High: the peer prior, and the JD asks for cross-functional influence | Reciprocity framing; propose seam principles, not a pretended seam | A1 to A5 |
| Data-Driven Prober (B) | Defend-the-number, a SQL walkthrough, "how was that counted" | High: peer prior plus his self-description as data-driven | Say how each number was counted, or plainly that you do not know; name the weakest assumption first | B1 to B5 |
| Skeptic (C) | The sales-ops gap, weakest part of the JD, why leave a large company | Medium: his team's home ground is where the stated gap sits | Rehearse C1 until it is boring; calibrated candor over bluffing a competency he owns | C1 to C3 |
| Case/Strategist (D) | Live problems on the new lines, bundling, pricing a copilot | Medium: a strategy role, and a pricing spine tilts cases toward packaging | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully | D1 to D3 |
| Conversational (E) | Opening biography, "what are you playing with in AI" | Low to medium: a 60-minute session opens conversationally, but the register is not his profile's | A short arc built only from quoted facts; treat casual AI questions as scored | E1, E2 |
| Pressure (F) | Time-boxed "why you", "how much was actually you" | Low: nothing in the profile suggests it, but attribution probes can arrive sharply from a data-driven peer | Pause, restate, hold the quoted position through two follow-ups, concede specifically | F1, F2 |
| Values/Behavioral (G) | Unpopular truth, data changing your mind | Low: no values round is documented, and his self-description raises the data theme only | Pick stories where the hard truth landed; otherwise say so plainly | G1, G2 |

## Question banks

### A. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side — where's the seam between sales strategy and this role, and what happens when we disagree?" | JD | [grounded] "skilled in SQL/Tableau" | Do not pretend to know the seam: ask where he sees it today and where it has been contested. Then offer principles, as proposals: agree definitions of land, adopt, expand and renew before any number is argued; one named owner per metric; when we disagree, put both readings against the same data and ask what would change each of our minds. Reciprocity, kept to the sentence: "I'm skilled in SQL and Tableau." | F5 is the evidence row for the cross-functional line, and a peer's first concern is the seam; JD because it scores the stated influence requirement, with peer delivery |
| A2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold: pick shared work where credit could have gone to more than one team; it needs a piece that was yours, a piece that was another team's, and an intact relationship at the end. "We" for context, "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, in its words: "I set annual volume targets with cross-org consensus", or how you would handle credit | A peer evaluator checks whether the hire adds to or reduces his load; F5 is the only row that touches shared work. VAL because it scores behavior toward equals, not a skill |
| A3 | "What would you need from me in your first thirty days, and what would I get from you?" | JD | [grounded] "skilled in SQL/Tableau" | Asks, as proposals: his team's definitions and the data you may query directly, plus how targets are set today. Gives, at the quote's scope: analysis you can run yourself, "I'm skilled in SQL and Tableau." Keep the ask short and the offer specific | The reciprocity question; F3 is the only row that offers him something concrete. JD because it scores the independent-analysis line through a collegial frame |
| A4 | "Tell me about a time you disagreed with a peer about a number, and how it ended." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold: it needs the number, the two positions, what evidence each side had, what moved, and the relationship at the end. For Dan, end on the evidence, not on who won. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, in its words: "I set annual volume targets with cross-org consensus", or how you would handle it | Disagreement with equals is a peer scoring item, and the JD raises influence; F5 is the nearest row but does not show a disagreement, so the guidance gives a scaffold, not a story |
| A5 | "Suppose your whitespace analysis flags an account a rep on my team is already working. What do you do?" | CASE | [generic] | Structure it aloud: ask who holds the account relationship and what the opportunity is (another line, or more of one already sold); state the objective; options (rep-led, joint, hold); who decides and how it is recorded; how the data stays shared. Concede that his team's view of the account comes first | A live seam problem from the whitespace line (F2's requirement), delivered collegially; CASE because it scores structure under a peer's turf concern, and it makes no claim about the candidate's past |

### B. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start at the quote's scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Then four slots, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least, named before he asks; which part was yours. If you do not know how it was counted, say so plainly. If there is an analysis you did yourself, offer to walk it end to end; if there was none, say so | F2 is the headline figure, and a self-described data-driven peer will go straight to it; EXP because it scores attribution and counting |
| B2 | "Walk me through the revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: you built it, it was partner-level, it was used in carrier negotiations; tell them in your own words. Answer slot: the JD's partner-motion line makes a probe on what the model fed into likely. If any of the partner work went beyond the model, say what and how; if the model was the whole of it, or the rest was not yours, say so plainly and stay with the model | F4 is the only evidence for partner work, and the probe on its edge is predictable; EXP because it tests what was actually built, JD content underneath |
| B3 | "Tell me about an analysis you ran yourself in SQL and Tableau, from the question to the chart." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: choose an analysis where you wrote the query yourself; it needs a named question, the data you used, what you found, and which parts were done by others. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, in its words: "I'm skilled in SQL and Tableau", or how you would approach one | The JD names independent analysis in SQL and Tableau, and F3 shows the tools only; JD because it is a stated requirement, with Prober delivery |
| B4 | "For a product with no history, which numbers would you pull first to find whitespace across land, adopt, expand and renew?" | CASE | [generic] | Say the structure aloud: define each stage and what counts as adoption; name the denominators for each; segment (enterprise against the rest, since expansion is a stated priority per your research note); compare with adjacent lines only if any exist, so ask; say which numbers you would distrust at small volume; then metrics and risks | The JD's whitespace line (F2's requirement) as a live problem; CASE because it scores whether denominators and definitions come before conclusions, which is exactly what a data-driven peer scores |
| B5 | "Walk me through how you reached cross-org consensus on the annual volume targets." | EXP | [grounded] "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience" | Beats the quote states: you set annual volume targets, with cross-org consensus; tell them in your own words. Answer slot: how the consensus was reached, in your own words; if it came about differently or was not yours, say so plainly and stay with the targets. Keep the word "targets": Dan will likely hear "quotas", so if he asks, the plain acknowledgment is "I have no classic sales-ops or quota-setting experience" | F5 is the cross-functional evidence and sits nearest to Dan's territory, so the probe is likely; F7 is why the wording is held; EXP because it scores what was actually done |

### C. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see sales-ops or quota-setting in your background. How would you work with my team on land, expand and renew without it?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau" | **Highest-ROI rehearsal.** Three beats, said until they are boring. (1) Plain acknowledgment: "I have no classic sales-ops or quota-setting experience." (2) The nearest thing, at its scope: "I set annual volume targets with cross-org consensus." The pack's observation: that is not quota-setting, and this guidance does not bridge it. (3) A plan, never a past: learn how targets are set today and what they rest on before offering a view; offer analysis, "I'm skilled in SQL and Tableau." Follow-up 1, "what do you do in your first thirty days": ask and learn before opining. Follow-up 2, "which of our assumptions would you challenge first": "I wouldn't know until I've seen them, and I would rather ask than guess." Follow-up 3, "so you'd be learning on my team's time": concede specifically, "On quota mechanics, yes, I'd be learning from your team", then offer the analysis. Hold by returning to the quotes, never by adding to them | F7 is the biggest stated gap and Dan's home turf, so it arrives in some form, collegially or sharply; JD because it scores the role's seam with sales strategy, Skeptic delivery |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Choose one rather than saying none, in your own view of yourself. If it is the partner line, say what your material carries, "I built a partner-level revenue model that was used in carrier negotiations", and how you would close the rest as a plan. If it is a different line, say that plainly and why. Answer slot: if any of the partner work went beyond the model, say what and how | A persona stem for the Skeptic. F4 and F1 are the thinnest JD rows; JD because it scores honest self-assessment against the stated list |
| C3 | "Why leave a large consumer-tech company for a B2B data-infrastructure business of around three thousand people?" | CO | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Selection scaffold for the reasons: one about the work (two new lines, land to renew), one tied to a stated priority from your research note, one about you; all in your own words, and none may be one you do not hold. If no reason tied to the company comes to mind, say so plainly, then give the one you do hold. Likely follow-up on pace and support: answer slot, in your own words; if you have not worked in a smaller or earlier-stage setting, say so plainly | The why-leave, why-here, why-now question sits with the Skeptic; F1 is the career record it rests on. CO because it scores whether the answer is anchored in Northwind's own priorities, with JD secondary |

### D. Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Take one of the two new lines. A much larger platform vendor is bundling something close to it. Where do you look for whitespace first, and what do you need to know before you start?" | CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" | Clarify first: which of the two lines, and whether it is close to Compass. Objective; segment by lifecycle stage (land, adopt, expand, renew) and by enterprise against the rest; approach: where a bundle is weakest and where it is strongest; metrics; risks, including unit economics, since profitability is a stated priority. Challenge one premise respectfully, such as whether bundling bites at land or at renew | The CO and CASE question grounded in Northwind's stated competitive threat; F1 is the role-ownership requirement it tests. CASE because it scores structure, with the company's own vocabulary |
| D2 | "How would you think about pricing and packaging an AI copilot against a larger vendor's bundle?" | CASE | [grounded] "an AI copilot launch ('Compass')" | Clarify: who buys, what the bundle includes, what customers do today without it, how value shows up, what it costs to serve (profitability is a stated priority). Then structure, then metrics. Say that pricing is his native ground and ask which levers he has seen move; you only know from your research note that the launch is a stated priority | Dan's pricing spine tilts the case here; F6 is the AI row it touches, but the question asks about no past. CASE because it scores structure on his home vocabulary |
| D3 | "Enterprise expansion is a stated priority. For a new line, how would you decide whether growth should come from new logos or from existing customers?" | CASE | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Clarify the line's maturity and what is known about current customers; objective; segment; compare the economics of each route (cost to win against cost to expand), what you would need to see, risks. Name the one assumption you would test first | A stated priority turned into a live question; F2's requirement is the whitespace it tests. CASE because the answer is a method, CO because it rests on Northwind's own priority |

### E. Conversational (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | A 90-second arc made of quoted clauses: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops; one or two of the quoted pieces of work, at their scope. Answer slot: why this role, why now, in your own words | The biography opener is scored even when it feels casual; F1, F4 and F5 are the quoted pieces. EXP because it scores whether the story survives a CV read |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say which tools and what for, in your own words. If it is everyday use and nothing beyond that, say so plainly rather than stretching it. Do not claim familiarity with Compass; you know from your research note only that the launch is a stated priority | A persona stem for a casual register, asked about the JD's plus; F6 is the evidence. JD because the AI line is stated, even if only as a plus |

### F. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ~$400M — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate. Hold the quoted position through two follow-ups: "I proposed the change; it was credited with a ~$400M ARR uplift." Return to those words each time and never add verbs. Then concede specifically: if you do not know how the credit was attributed, say so plainly. Never fold on the proposal itself to restore harmony | The attribution probe exists to catch inflation (F2); EXP because it scores precise honesty under pressure |
| F2 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau" | Pause, restate, answer in sixty seconds in your own words. Draw only on the quoted pieces: the partner-level revenue model used in carrier negotiations, and SQL and Tableau. Do not claim sales-ops depth. Answer slot: the reason you hold most strongly, in your own words | A persona stem; F4 and F3 are the rows a short answer can honestly rest on. JD because it scores fit to the listed role |

### G. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: it needs the truth, the audience, the evidence, what happened to the decision, and an intact relationship. Choose a story where the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. No quoted sentence carries this story, so none is supplied | A persona stem. No values round is documented and no published values were retrieved, so this is a generic rehearsal. VAL because it scores behavior, not a skill |
| G2 | "Tell me about a time the data changed your own mind." | VAL | [generic] | Selection scaffold: it needs your first view, the number or analysis that moved you, what you did differently, and what it cost to say so. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | His self-description as data-driven raises this theme. VAL because it scores a working style, and no quoted sentence carries the story |

## Requirement coverage

The JD supplied is the six highlights in your message, so this covers those and not the full posting.

| Requirement (JD highlights) | Questions |
|---|---|
| "own GTM strategy for two new product lines" | C2, C3, D1, D2, D3, F2 |
| "identify whitespace across land/adopt/expand/renew" | A5, B4, D1, D3 |
| "run independent analysis in SQL and Tableau" | A3, B3, C1 |
| "partner-motion design experience required" | B2, C2 |
| "strong cross-functional influence" | A1, A2, A4, B5 |
| "AI experience a plus" | D2, E2 |

## Reverse questions

| # | Question to ask Dan | Why it lands |
|---|---|---|
| R1 | "Your career has been in pricing and monetization, with an early-stage chapter along the way. What did that chapter change about how you approach sales strategy at Northwind's scale?" | Ties to his own path and invites a story; it shows you researched him |
| R2 | "Where does pricing sit in the GTM for the two new lines, and where does it hand off to this role?" | Pricing is his native ground, and it surfaces the seam without pretending to know it |
| R3 | "What could a new person on my side do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it signals you are thinking about his load |
| R4 | "Are the two new lines connected to Compass, or separate from it?" | Fills a fact the material does not give and stops you assuming the answer |
| R5 | "With a much larger vendor bundling, where are the two lines most exposed (land, expand or renew), and what are you tracking to know?" | Uses the stated competitive threat and puts a metric in front of a data-driven peer |
| R6 | "How does the profitability priority change what a good first year looks like for a new line?" | Ties to a stated priority and asks for a definition of good, which a data-driven peer cares about |
| R7 | "Which of land, adopt, expand and renew does your team own today, and where has the seam been contested?" | Gets the real boundary in his words and tests your seam principles from A1 |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has done sales ops or set sales quotas, or that the annual volume targets were quota-setting | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I have no classic sales-ops or quota-setting experience." Then F5's quote at its own scope: "set annual volume targets with cross-org consensus". No slot |
| Owned or led GTM strategy | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not GTM strategy. C2's slot stays inside the quote |
| Designed or ran a partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a revenue model used in carrier negotiations. B2's slot asks only what the model fed into |
| Drove, owned or delivered the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed, and credited with. B1 and F1 ask only the counting and attribution slots |
| Ran independent analyses end to end in SQL and Tableau | Inflated form of F3 | F3's quote at its own scope: skilled in the tools. B3's scaffold ends in its honest branch |
| Built or shipped AI products, or has familiarity with Compass | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily. E2's slot stays at use |

## Sources

**Provided documents:** your message only, containing the role and JD highlights, a summary of the candidate, Dan's profile, and your research note on Northwind's priorities and competitive threat. No dossier was present. No CV, full JD or recruiter guidance was supplied.

**Searches sent:**

| Query | Outcome |
|---|---|
| Northwind Data company values data infrastructure | refused |
| Dan Kovac Director of Sales Strategy Northwind Data | refused |

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The one search sent was refused. It would have given the official value names for VAL themes; the values cheat sheet is not built in any case, because no values-style round is detected from your words |
| 2. `Northwind Data interview process, strategy and sales strategy roles` | skipped | Your words fix the loop: one 60-minute conversation with a peer. Persona weights follow from it |
| 3. `Northwind Data strategy` and recent news | skipped | Your research note supplies the three priorities and the competitive threat the CO and CASE questions draw on; recent news was not checked, so those facts are as of your note |
| 4. `Dan Kovac Northwind Data` | unavailable | The one search sent was refused. It would have added his talks and writing to the interviewer read and to R1 |
| 5. representative `Senior GTM Strategy Lead, Emerging Products` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Allow web search → values names, recent news and Dan's public talks or writing for the interviewer read; and, if you want a deeper pass once, up to 6 further searches and 2 further fetches, several more minutes, giving a grounding brief and sharper strategy cases for D1 to D3
- The full JD text → the six highlight rows become the whole requirement list, and any mid-list requirement the highlights omitted gets a question
- Priya's CV → F1 to F6 draw on her own sentences instead of your summary, and the story-mapped answers in A2, A4, B3, G1 and G2 replace selection scaffolds where a sentence carries them
- Her answers to the answer slots in F1 to F6, said outside a drill → those rows are regenerated on her own words and the matching guidance cells upgrade
- The artifact behind the ~$400M credit (the readout or attribution note) and the revenue model's summary or deck → F2 and F4 can rise from medium; the inspectable proof for strategy and ops work is the document itself
- The recruiter's guidance on what Dan's session will focus on, or any prep deliverable → coverage beyond round-type priors, and a build section for any announced deliverable; usually one email
- A tuesday-dossier.md from job-underwriter → verified evidence and strategy limits per weak area, and a named top objection in place of the one inferred here
