I'll read the reference files the skill points to before building the pack.
Shell edits need approval, so I'll use the Edit tool.
Your prep pack is saved at /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-denied-1e8f7012/ashgrove-credit-union_member-experience-lead_interview_pack.md. I built it as a three-round loop for 20 November. There are no interviewer names yet, so there is no interviewer read. I ran no searches, because what you pasted already covered the values, loop, strategy and JD.

I can play the Head of Member Services on D1, the contact-centre question the pack names as your highest-ROI prep. Say the word and we'll start.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Prepared 11 November 2026 for three rounds on 20 November 2026.

| Round | Who | Length | What the recruiter's email says it holds |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | "30 minutes with me" |
| 2 | Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 minutes | "a 20-minute case on a complaint escalation"; "The panel is also the values round — they score against the four values." |

No interviewer names are assigned yet, so there is no interviewer read. This is a loop-mode pack: one shared fit snapshot, then a mini-pack per round.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether the claims about your background survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on Ashgrove's strategy and how it touches the role |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. It names what an interviewer is likely to probe and gives two honest branches. Either branch is a good answer. Answering from your own experience, or saying plainly that the practice was not yours, both pass.

The single highest-ROI rehearsal in the pack is **D1**, the contact-centre question in Round 2. It is the objection most likely to be asked in some form, and your own message states the gap behind it.

## Fit snapshot (shared across all rounds)

Requirements are quoted from the JD you pasted. Evidence is your own words from your message. The snapshot found no gate requirement: the 4+ years is a length-of-experience line, so it is graded like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's complaints-process line makes a probe on what happened to a complaint once it was in the log likely. If any step after the log was yours, say which and what you did, in your own words; if the log was where your part ended, or those steps were not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn that side, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your material says a monthly complaints spreadsheet your regional manager uses, which you built, and the words stay there: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's monthly-reporting line makes a probe on what the sheet counted likely. If it tracked how many complaints came in or how long they took to resolve, say which and how each was counted, in your own words; if it held something else, say so plainly and describe what it held |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how that training ran likely. If you shaped how the tellers learned the script, say how, in your own words; if you delivered it as it was handed to you, or it was informal, say so plainly and stay with the tellers and the script |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the JD's digital-teams line makes a probe likely. If you have worked with a digital or product team on anything members use themselves, say what it was and what part was yours, in your own words; if you have not, say so plainly and say what you would ask the digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence already reaches the requirement in other terms: it says retail banking, not customer operations. Say it in its own terms: "I have six years in retail banking, the last three as a branch supervisor." Let the interviewer decide how it maps, and expect a probe on whether branch work counts; stay with the sentence's own words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | Your sentence says formal complaints and does not say what rules governed them. Words: "I handled the branch's formal complaints log." Answer slot: the JD's regulated-complaints line makes a probe on what rules or timescales applied likely. If the log was kept under a regulator's rules or timescales, say which and what that meant for how you handled entries, in your own words; if it was not, or you do not know which rules applied, say so plainly and stay with the formal log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare for a first senior presentation, said as a plan and never as a past. Never a claim to senior-leader presenting |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says a spreadsheet, not which tool, and the pack does not fill that in. Answer slot: the JD's Excel line makes a probe on what you built it in likely. If it was Excel, say so and what you built in it, in your own words; if it was another tool, or you are less sure of Excel than the JD asks, say so plainly and say what you used |

## Grounding brief: Ashgrove in its own words

This section rests on the 2026 strategy brief the recruiter sent (published July 2026, so about four months old on 11 November 2026) and on the JD. Learn the vocabulary. Do not recite it: any prepared candidate has read the same brief.

| Fact | Source | Provenance | Where it may surface |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief, July 2026 | [grounded] | A2, A5, E1 |
| Consolidate eight branches into five hubs over 2027 | 2026 strategy brief, July 2026 | [grounded] | E2, F3, R3 reverse questions |
| Launch a small-business lending product in Q1 2027 | 2026 strategy brief, July 2026 | [grounded] | A2 only if useful; the brief gives it no complaints angle, so do not force one |
| Main competitive pressure is app-only banks | 2026 strategy brief, July 2026 | [grounded] | A2, E1 |
| Member-owned, about 900 staff | JD | [grounded] | A2 |

Note for E1: the brief says "member service", and it does not say whether complaints are inside that 40%. That is a fair clarifying question, not a correction to offer an interviewer.

## Requirement coverage

| JD requirement | Questions that cover it | Rows |
|---|---|---|
| Own the member complaints process end to end across branches and the contact centre | A3, B1, D1, D3, G1 | F1, F2 |
| Report monthly on complaint volumes and resolution times | A4, G3 | F3 |
| Coach branch supervisors on escalations | C2, G2, H1 | F4 |
| Work with digital teams on self-service journeys | A5, E1 | F5 |
| 4+ years in financial-services customer operations | A1, B3, D3 | F6 |
| Experience handling regulated complaints | A3, G1 | F7 |
| Confident presenting to senior leaders | B2, C3, D2 | F8 |
| Comfortable with Excel reporting | A4, G3 | F9 |

Your material gives no headline figure beyond the six years and the three, so there is no defend-the-number question. Each of the four published values has a VAL question: F1 to F4 in Round 3.

---

# Round 1 — Recruiter, 30 minutes

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured opener; casual questions about the role | High. The email gives this round as "30 minutes with me", and the relationship prior for a recruiter screen is conversational with a light Skeptic. That prior is a generic pattern, not a fact about Ashgrove | A pre-scripted 90-second arc for the biography question; treat casual questions about JD topics as scored; use the reverse-question slot |
| Skeptic (light) | Quick checks on the gaps a screen would note | Medium. Two JD rows, F2 and F8, carry absences your own message states, which a screen would be likely to touch | Plain acknowledgment plus a plan, short; D1 and D2 carry the depth |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey. How did you get to where you are now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc on three sentences, in this order: six years in retail banking, the last three as a branch supervisor; handling the branch's formal complaints log and training new tellers on the escalation script; building the monthly complaints spreadsheet the regional manager uses. Tell each at that scope. Close with your own reason for this role, in your own words | The opener of a recruiter screen, and the arc the later rounds will check. F6, F1 and F3 supply its sentences. EXP because it tests whether the background holds up when said aloud |
| A2 | "Why Ashgrove, and why this role now?" | CO | [grounded] | Use Ashgrove's published words rather than slogans: member-owned, "Members First, Always" from the values page, and one fact from the July 2026 brief, either 40% of member service moving to digital by 2028 or eight branches becoming five hubs over 2027. Put what it means for complaints as a question you would want answered, not a prediction. Your reason for "why now" is yours to give in your own words; the pack supplies none | Motivation and homework in one question, asked in a friendly register. CO rather than VAL because it scores whether you know where Ashgrove is heading |
| A3 | "What experience do you have handling regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open with the sentence at its own scope: "I handled the branch's formal complaints log." Answer slot: if the log was kept under a regulator's rules or timescales, say which and what that meant for how you handled entries, in your own words; if it was not, or you do not know which rules applied, say so plainly and stay with the formal log you handled | The JD asks for this directly and F7 is where your material is silent on the rules. JD because it scores a stated requirement; a recruiter often asks it as a knockout |
| A4 | "Tell me about the monthly complaints spreadsheet you built. What did it show, and what did you build it in?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Three beats, all in the sentence: you built it, it is monthly, your regional manager uses it. Answer slot: the JD asks for monthly reporting on complaint volumes and resolution times and for Excel comfort, so expect a probe on what it counted and what tool it was in. If it tracked either, say which and how it was counted; if it was in Excel, say so; if it held something else or was in another tool, say so plainly and describe it. Say which part was yours | F3 and F9 both rest on this one sentence, so it is where a probe on reporting starts. EXP because it tests what was actually yours |
| A5 | "Have you worked with digital teams on anything members use themselves?" | JD | [grounded] | Answer slot: if you have, say what it was and what part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first. The brief's 40% digital target is a reason to be curious here, not a claim to experience | F5 has no evidence in your material, so the honest answer has to be ready before the probe. JD because the digital-teams line is a stated responsibility |
| B1 | "This role covers the contact centre as well as branches, and you haven't worked in a contact centre. How would you approach that side?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Thirty seconds. First the plain acknowledgment: "I haven't worked in a contact centre." Then a plan in your own words: the first things you would ask, and of whom. Say nothing about how contact centres run unless you know it first-hand. D1 holds the full rehearsal | The light version of the pack's highest-ROI objection. F2 is where the screen would note a gap. JD because it scores a stated requirement |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose the one of your two stated absences you would truthfully name, the contact centre or presenting above regional level, say it plainly, then give one ramp step in your own words. Do not name a gap your material does not state | A standard screen question, and F2 and F8 are the two rows where your own words state the answer. JD because it scores self-assessment against the listed requirements |
| B3 | "You're a branch supervisor now. Why move into this role?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Answer slot, in your own words, with nothing supplied by the pack: what draws you to complaints and to this role. Keep it to the work and to Ashgrove, not to your current employer. If no single reason comes to mind, say so plainly and give the nearest thing you actually feel | Motivation consistency is what a recruiter screens for. F6 gives the branch-supervisor fact the question presupposes. JD because it scores role fit |

## Reverse questions for Round 1

| # | Question | Why it lands |
|---|---|---|
| RA1 | "For the panel round, is each branch manager scoring all four values, or are they split between them?" | Your recruiter's email says the panel scores against the four values; asking shows you read it and tells you how to spread your stories |
| RA2 | "Will the escalation case come as a brief in advance, or on the day?" | It tells you how to prepare the 20 minutes, and it is an ordinary question to put to a recruiter |
| RA3 | "How is the complaints process split today between branches and the contact centre?" | It uses the JD's own words and shows you are already thinking in the role's terms |
| RA4 | "What is the hiring team hoping the first person in this role changes?" | It surfaces a success measure before Round 2 |
| RA5 | "What is the timeline after the panel, and who makes the decision?" | A practical close that also shows interest |

---

# Round 2 — Head of Member Services, 45 minutes

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario prompts, STAR-shaped stories | High. The email calls this round "mostly behavioural" | Pick an instance first; "we" for context, "I" for your contribution; where nothing comes to mind, use the honest branch |
| Skeptic | Quiet, persistent probing of the gaps | High. The email says this person "would be your manager", the relationship prior for a hiring manager is derisking gaps, and F2 and F8 carry absences your message states | Rehearse D1 until it is boring: plain acknowledgment, hold at the sentence's scope, concede only what the sentence says |
| Case / Strategist | A live problem from the role's roadmap | Medium to low. The hiring-manager prior says live problems, but the email says "mostly behavioural", so two questions and not four | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you had to explain a complaint outcome to someone who was unhappy with it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold, because the sentence does not carry an explaining story. Pick one instance from the complaints you handled: it needs a named stake, what you actually said, and how the member or colleague left it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would handle it | The JD's complaints line and the Plain Words value both raise this theme. F1 is the nearest evidence. VAL because it scores behaviour against a published value |
| C2 | "Tell me about a time you helped someone through a tricky escalation." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The sentence carries two beats: you trained new tellers, and the subject was your escalation script. Tell those at that scope. Answer slot: the JD asks about coaching supervisors, so expect a probe on how the training worked. If you shaped it, say how; if you delivered it as handed to you, or it was informal, say so plainly and stay with the tellers and the script | F4 is the only row about coaching, and it is at teller level. EXP because it tests what the training was and whose it was |
| C3 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | A selection scaffold: pick a moment with a named stake, a point where you did not soften it, and the relationship at the end. Choose one where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Stands in for the JD's senior-leaders line while F8 has no senior-presenting evidence. VAL because it scores candour; labelled generic because it is a pattern for the type of question, not a fact about Ashgrove |
| D1 | "This role owns complaints in the contact centre as well as in branches, and you haven't worked in a contact centre. Why should I believe you can own that side?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI rehearsal in the pack.** Level 0, first words: "I haven't worked in a contact centre." Level 1, hold at the sentence's scope: "I handled the branch's formal complaints log." Stop there; do not claim it transfers and let the interviewer draw the line. Then a plan in your own words: what you would ask first and of whom. Follow-up one, "A branch log isn't a contact-centre queue. What's different?": say the differences you actually know of; if you know none, say so plainly and say what you would ask to find out. Follow-up two, "Would you want that side under someone who has done it?": concede the one fact your sentence states, that you have not worked in one, and hold on your willingness to learn it. Never add anything about contact-centre work your sentences do not carry | The objection is built from F2, where your own message states the absence, and the JD puts the contact centre in the first line of the role. Deepest rehearsal means the most follow-up levels and the limit named before it is asked for. JD because it scores a stated requirement; Skeptic delivery |
| D2 | "You haven't presented above regional level, and this role reports monthly to senior leaders. How do you walk into that room?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | First the plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan in your own words for the first monthly report. Answer slot: if you have presented to your regional manager or at a regional meeting, say what and to whom; if not, say so plainly and stay with what you built: "I built the monthly complaints spreadsheet our regional manager uses." Do not describe that as presenting | F8 is a stated absence, and the monthly-report line makes this the natural place for it. JD because it scores the senior-leaders requirement |
| D3 | "That complaints log. How much of it was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold on the sentence: "I handled the branch's formal complaints log." Say in your own words which parts were yours, and where anyone else was involved, say so plainly. Hold through two follow-ups by returning to the sentence, never by adding to it. Concede what the sentence does not say, specifically, rather than folding on what it does | A Pressure stem, and the first thing a manager checks on a CV line. F1 and F6 are the rows it tests. EXP because it scores attribution honesty |
| E1 | "Ashgrove wants 40% of member service on digital channels by 2028. Which complaints would you want to move to self-service, and which would you keep with a person?" | CASE | [grounded] | Clarify first: does the 40% include complaints, which complaint types exist, what members use today, and what rules apply to each type. Then objective, segments, approach, metrics, risks. Challenge one premise respectfully: the brief says "member service", so ask whether complaints are in scope. Use Plain Words as a test for any journey: could a member follow it without it being explained twice | The JD's digital-teams line and the brief's 40% target meet here. F5 has no evidence, so this case is also where you show you can think about the work. CASE with a CO base; the pack makes no claim about your past |
| E2 | "Eight branches are becoming five hubs over 2027. What happens to the complaints process during that year?" | CASE | [grounded] | Clarify what changes for a member, where open complaints sit when a branch closes, and who owns each one through the move. Then structure: objective, who is affected, approach, measures, risks. Name Own the Fix as the principle: one named owner who keeps hold until it is solved. Challenge one premise, such as whether the process or only the building is changing | The brief's consolidation sits directly on the complaints process and on the Neighbours, Not Numbers value. CASE because it is a live problem from the role; the pack makes no claim about your past |

## Reverse questions for Round 2

| # | Question | Why it lands |
|---|---|---|
| RB1 | "What would you want complaints to look like in six months: volumes, resolution times, or something else?" | It reaches the JD's monthly-reporting line and invites your future manager to set the measure |
| RB2 | "Where does complaints ownership sit today between branches and the contact centre, and where does it fall between them?" | It names the contact-centre side openly rather than waiting for it to be raised |
| RB3 | "Which self-service journeys do you most want improved, and what do complaints tell you about them today?" | It joins the JD's digital-teams line to the brief's 40% target |
| RB4 | "How do you want to hear about a problem early? What does a good escalation to you look like?" | A manager-facing question that echoes Own the Fix |
| RB5 | "How will five hubs change what branch supervisors need from this role?" | It uses the brief's consolidation at the altitude of the role |

---

# Round 3 — Panel of two branch managers, 60 minutes

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Each of the four values probed with a behaviour question | Highest. The email says "The panel is also the values round — they score against the four values." | A story for each value where a sentence of yours carries one, a selection scaffold ending in its honest branch where none does; land the hard truth |
| Case / Strategist | A live escalation, asked for 20 minutes | High. The email names "a 20-minute case on a complaint escalation" | Clarify, objective, stakeholders, approach, measures, risks; think aloud; use Ashgrove's words |
| Peer Evaluator | Seam questions and what the hire would add to a branch manager's load | Low. This is my inference, not a documented fact: the JD says the role coaches branch supervisors, and these are branch managers. Two names are not assigned, so no per-member split | Reciprocity framing; propose seam principles rather than pretending to know the seam |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Members First, Always: we decide from the member's side of the counter. Tell me about a time you decided something from the member's side." | VAL | [grounded] | A selection scaffold, because no sentence of yours carries a member-side decision. Pick an instance with a named stake, what the member's side of it was, what you decided and what it cost. If it cost the branch something, say so. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The first published value, quoted from the page you pasted. VAL because it scores behaviour against that value |
| F2 | "Plain Words: if a member needs it explained twice, we wrote it wrong. Tell me about something you wrote or explained that had to be explained again." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The nearest sentence is "I trained new tellers on our escalation script", and it carries no instance of something unclear, so this is a scaffold: pick a time your wording needed redoing, what you changed and why. Answer slot: if you wrote or revised any wording of the script, say what and why; if you only trained others on it, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The second value; F4 is the only row about explaining something to others. VAL because it scores behaviour against a published value |
| F3 | "Neighbours, Not Numbers: every branch is part of its town. Tell me about a time you put a branch's community ahead of a number." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | A scaffold: pick an instance with a named stake, the number at issue, who in the town it affected and what you did. The brief's eight-into-five hubs makes this value likely to be probed with consolidation in mind. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The third value, and the one the brief's consolidation touches. F6 gives the three branch-supervisor years as context only. VAL because it scores behaviour against a published value |
| F4 | "Own the Fix: whoever finds the problem keeps hold of it until it is solved. Tell me about a problem you found and kept hold of." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A scaffold: pick a problem you found, what keeping hold of it meant, and how it ended. Nothing in your sentence says a problem was found or how one ended, so do not borrow the log for it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would handle it | The fourth value, and the JD's complaints-process line makes it the natural pairing. F1 is the nearest evidence. VAL because it scores behaviour against a published value |
| G1 | "A member's formal complaint has been passed from a branch to the contact centre and back twice. They say they will leave. What do you do this hour, and what do you do this month?" | CASE | [generic] | Structure aloud. Clarify first: what the member was told, what they want, which rules or timescales apply and where the clock stands. Objective: the member's problem solved, not the file closed. Stakeholders. Approach: one named owner who keeps hold, a plain-words call to the member, a root-cause look at the two hand-offs. Measures, risks. Challenge one premise: why it went round twice | The 20-minute case the email names, built from the JD's complaints-process line. F1, F2 and F7 are the rows it exercises, with no claim about your past. CASE; labelled generic because it is a pattern for the problem, not a fact about Ashgrove |
| G2 | "Three branches keep escalating the same kind of complaint. How would you coach their supervisors?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Clarify what "the same kind" means and what supervisors do now. Objective, approach built on the complaints data and on what supervisors say they find hard, measures, risks. If asked what you have done before, say it at its scope: "I trained new tellers on our escalation script." Do not offer it as coaching supervisors | The JD's coaching line as a live problem. F4 is the evidence, and it is at teller level. CASE because it is asked as a decision |
| G3 | "Resolution times are getting longer. Where do you look first, and what do you tell the Head of Member Services?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Clarify how resolution time is counted before reading any trend, and name the assumption about it you would defend least. Then segment by channel, complaint type and branch, say what you would report and to whom, and what you would not conclude yet. Answer slot: if your own sheet tracked resolution time, say how it was counted; if not, say so plainly and stay with the sheet you built | The JD's reporting line and Excel line as a live problem. F3 and F9 are the rows it tests. CASE because it asks for structure |
| H1 | "Our supervisors are stretched. How would you coach them without adding to their load?" | CASE | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Reciprocity first: what you would ask them they want, what a clear route for a complaint gives them, and how you would keep sessions short. You may say you spent the last three years as a branch supervisor, at that scope, and nothing about knowing their load | The panel is two branch managers, and the JD says this role coaches branch supervisors; the link is my inference. F4 and F6 are the rows. CASE with Peer delivery |
| H2 | "Where is the seam between your role and a branch manager's, and what happens when we disagree?" | CASE | [generic] | Offer principles, not a map you do not know: who owns the member's outcome, who owns branch staff, one named owner for each complaint, and disagreement settled on the member's facts and taken to the Head of Member Services if it is not. Ask where they see the seam | A standard Peer stem. Labelled generic because it makes no claim about Ashgrove's structure beyond the Head being your manager, which the email states |

## Values cheat sheet

Published value names are quoted from the page you pasted on 11 November 2026 (ashgrovecu.org/about/values). The panel scores against them, per the recruiter's email.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No row of yours carries a story. Selection scaffold: an instance with a named stake and a cost; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording was wrong | Nearest sentence, F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." It carries no instance of unclear wording. Scaffold: a time you redid a wording; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | Context only, F6: "6 years in retail banking, the last 3 as a branch supervisor." No row carries a story. Scaffold: a time a community mattered more than a number; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Nearest sentence, F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." It carries no problem found or solved. Scaffold: a problem you found and kept hold of; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |

## Reverse questions for Round 3

| # | Question | Why it lands |
|---|---|---|
| RC1 | "What do your supervisors find hardest about escalations today?" | It asks branch managers about their own world and sets up the coaching line |
| RC2 | "When a complaint leaves your branch, how do you want to be kept informed?" | It is Own the Fix from the branch's side |
| RC3 | "What do members in your town notice first when a branch moves into a hub?" | It puts Neighbours, Not Numbers into a practical question |
| RC4 | "What would help your branch most from this role in its first month?" | A reciprocity question: it asks what you can add rather than what you need |
| RC5 | "Which complaint outcome here would you point to as handled well, and what made it so?" | It invites a story in their own plain words |

---

## Prohibited claims

These are the claims this pack will not coach. Each is built from the fit snapshot, before the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The limit is the pack's observation: your material says one branch's log, not a process across branches. The slot in F1 stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: your material says new tellers, not supervisors. The slot in F4 stays with the tellers and the script |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot on the senior part; D2's slot stays at regional level |

## Sources

Provided documents: the JD you pasted; the four published values you copied on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; the 2026 strategy brief the recruiter sent (July 2026); your background as you described it. No dossier was present. No searches or fetches were sent.

Loop source: the recruiter's email establishes the loop, with one session per round and who runs each. It documents a values round, so section Values cheat sheet applies.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text is in hand from your paste, which fixes the cheat sheet and F1 to F4 |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email fixes all three sessions and who runs each, which fixes persona weights and the values-round detection |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief you pasted supplies current priorities and the competitive frame, which fixes the grounding brief and E1 and E2 |
| 4. Interviewer name and Ashgrove | n/a | No name was given, only roles, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names, once assigned (Head of Member Services and the two branch managers) → an interviewer read, persona weights tuned to their public footprint, and reverse questions tied to their own paths
- What your complaints spreadsheet actually counted, and what tool it was in → F3 and F9 move from discovery rows with slots to grounded rows, and A4 and G3 become story-mapped
- Whether your formal complaints log was kept under a regulator's rules or timescales → F7 stops being a slot, and A3 and G1 get a story-mapped hold
- Any presenting you have done at regional level, and to whom → F8's plan gets a quoted starting point, and D2's slot closes
- Any work with a digital or product team on member self-service → F5 moves off "none given", and A5 and E1 become story-mapped
- Any further escalation training or guidance you have given, and to whom → F4 gets a quoted sentence beyond the tellers
- Whether the escalation case comes as a brief in advance (ask the recruiter, RA2) → G1 to G3 can be tuned to the real format
- A CV, if you have one → more rows can quote it, and the six-years line can be checked against it
- Deep research: up to 6 further searches and 2 further fetches, several more minutes, on Ashgrove's strategy and competitors, interviewer talks and writing, loop reports for this role family, and recent organisation news. Say yes and I will run it; it adds depth to the grounding brief and to E1 and E2
- A `tuesday-dossier.md` from a job-underwriter pass → verified evidence and prohibited claims arrive ready-made, and the highest-ROI objection comes from evidence instead of being inferred
- Your prep time before 20 November → a prioritised schedule of which questions to rehearse first
