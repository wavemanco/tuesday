I'll read the skill's reference files before building the pack.
The pack is written and saved. Next is the summary message.

Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-4-denied-99fc1b54/quartzline_product-manager-platform-apis_interview_pack.md`. It has 20 questions across six personas, built for a hiring-manager round from your dossier. I didn't need to ask you for anything.

- **Highest-ROI prep:** A1, the "never held the PM title or owned a roadmap" objection. The underwriter named it, so it gets the deepest rehearsal, with the concessions sourced to the dossier's `prohibited_claims`.
- **A gap the dossier leaves open:** R2, "Shipped API or platform products", is a must-have, but the dossier grades no evidence or strategy for it. A3 rehearses it with an answer slot. The slot has two branches: say what you shipped, or say plainly that you didn't.
- **Research didn't run:** my three searches on Quartzline's values, interview process and strategy were refused. Persona weights rest on the hiring-manager prior, and the case bank is labeled generic. There are no company-strategy or values questions.

Say the word and I'll play the Skeptic on A1 so you can rehearse it live.
I can also save a `tuesday-dossier.md` update recording what this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: 45-minute conversation with the hiring manager (name not given). Session mode, built from your dossier plus your note. No source documents the Quartzline loop, so persona weights rest on the hiring-manager prior, not on Quartzline's process.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did. Question IDs are lettered by persona and skip F, so they cannot be confused with the fit-snapshot rows F1 to F6.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether a claim about your experience survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

This pack has no VAL or CO questions: no values-style round is detected, and the research that would have fed CO questions did not run (see Sources).

## Fit snapshot

Requirement text is the dossier's `role_profile` text. Evidence cells quote the dossier's `verified_candidate_evidence` entries and nothing else. The dossier grades R1 and R5 in `uncertain_or_weak_areas` but leaves R2, R3 and R4 ungraded, so the rows for those three are this pack's own derivation.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence, entry 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence, entry 3 | low | [grounded] | transferability | The dossier's strategy is bridge, and its condition is that the bridge is positioned as adjacent and never as PM experience. The limit, as the pack's observation: your material shows integration leadership and sessions feeding client evidence to product, not a PM title or a roadmap. Acknowledge first, sourced to `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title or role." Then the quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: R1's wording makes a probe on the integrations' own decisions likely. If any of the scoping and requirements decisions on an integration were yours to make, say which and how you decided, in your own words; if none were, or they sat with someone else, say so plainly and stay with the integrations you led |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities, with the sub-claim "Owning a roadmap and prioritization authority (R1 sub-claim)" from uncertain_or_weak_areas | none given | none | [grounded] | capability | The dossier records this as `acknowledge_gap` and lists `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`. Words: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan said as a plan and never as a past: what you would learn first about how roadmap calls are made across the two squads. No bridge from the roadmap-input sessions and no answer slot, because the underwriter looked and found nothing to bridge |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence, entry 1 | low | [inferred] | discovery | The dossier lists R2 as a high-priority requirement and grades no evidence or strategy for it. The pack's observation: the quote says integrations of the vendor's REST APIs, which is not the same as shipping an API or platform product. Words stay at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the JD's "Shipped API or platform products" makes a probe on that line likely. If you shipped an API or platform product, say what it was and your part in it, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence, entry 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence, entry 2 | low | [inferred] | discovery | The dossier grades no strategy for R3. The pack's observation: the quotes name REST APIs, architecture and a playbook, and neither says API docs or schemas. Answer slot: the JD names API docs and schemas, so expect a probe on which docs or schemas you worked from. If you worked from or wrote any, say which, in your own words; if you did not, say so plainly and stay with the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence, entry 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence, entry 3 | medium | [inferred] | discovery | Entry 3 is confirmed with limited inspectable proof, so expect a probe on it. The pack's observation: the quotes carry clients and product, and show neither engineering nor sales. Words stay at the quotes: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: the JD names engineering and sales. If you worked with either in those integrations or sessions, say who and for what; if you did not, say so plainly and stay with the clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy is clarify: nothing quoted speaks to this. Answer slot: the JD's "Agile delivery experience" is the interviewer's likely probe. If you have worked in agile delivery, say where and in what role; if you have not, or it was called something else, say so plainly, and say what you would want to confirm about how this team defines it |

## Persona table

Likelihood is shown with its reasoning so you can recalibrate. Weights rest on the hiring-manager prior; no loop source or interviewer profile adjusted them.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic (bank A) | Quiet, persistent probing of the title and roadmap gap | high | The hiring-manager prior puts Skeptic first, and the dossier names the exact objection this persona will raise (A1) | Rehearse A1 until it is boring; concede the sourced negatives plainly; bridge only at the quotes' scope with the limit named |
| Case and Strategist (bank B) | Live problems from the role: partner discovery, squad trade-offs, adoption metrics | high | The hiring-manager prior puts Case next, and the role's listed responsibilities are all live-problem material | Clarify, then objective, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Data-Driven Prober (bank C) | Line-by-line probing of the 30+ figure and the playbook | medium | The 30+ figure is a headline number and prober territory; no interviewer signal says this person is analytic | Know how the figure was counted or say plainly you do not; name the assumption you would defend least before they do |
| Conversational (bank D) | Friendly opener, then casual questions that are still scored | medium | A 45-minute conversation opens with a biography question, and the motivation probe usually arrives in this register | Prepare a 90-second arc from your quoted sentences; treat the casual agile question as scored |
| Pressure (bank E) | Time-boxed, devil's-advocate versions of the A1 objection | low | Nothing in the dossier or the round type points to a stress style; it is the Skeptic's objection in a harder register | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator (bank G) | Seam-splitting with the two squad leads | low | The relationship is a hiring manager, not a peer; the squad-authority unknown makes the seam question likely to surface inside other questions | Offer seam principles and ask who decides what, rather than pretending to know the seam |

The single highest-ROI rehearsal in this pack is A1. The underwriter named that objection from evidence you confirmed, so it is theirs and not an inference from a document read cold.

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The deepest rehearsal in the pack. Concede first, plainly, sourced to `prohibited_claims`: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then one bridge at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs", and name the limit before they do: this is adjacent to the job, not the job. Add the sessions only as quoted: "I ran quarterly roadmap-input sessions feeding client evidence to product." The dossier grades that one medium, confirmed with limited inspectable proof. Answer slot: if anything from those sessions can be shown or checked, say what; if nothing can, say so plainly and stay with the integrations. Follow-up one, why is that transferable: describe what you did and let them draw the inference; do not tell them what it proves. Follow-up two, a PM with three years has done the job: concede it specifically, "That's true, and I'm not claiming otherwise", and return to the integrations you led without adding to them. Follow-up three, what would be weakest: the roadmap and prioritization, as in A2 | The underwriter named this objection, and F1 and F2 are the rows it presses on. JD because it scores the requirement; its negatives rest on the dossier's `prohibited_claims` and `acknowledge_gap` fields, so none is the pack's guess |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] `acknowledge_gap` area: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it before they do: owning the roadmap and prioritization. Words, sourced to `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't owned a roadmap, and I haven't set prioritization for an engineering squad." Then a plan said as a plan: first learn how roadmap calls are made today across the two squads, who decides what, and where you would need the squad leads. Do not bridge to the sessions here and do not add an example from the past | F2 is the largest gap and the one the dossier says to acknowledge. JD because it scores the stated responsibility; the stem is the Skeptic's standard opener |
| A3 | "Tell me about an API or platform product you've shipped." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | An open prompt, so you choose the instance. The one sentence near it says integrations, so stay at that scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: R2 is a must-have, so expect a probe on whether you shipped an API or platform product. If you did, say what it was and your part in it, in your own words; if not, or it was not yours, say so plainly and stay with the integrations you led. Do not describe the integrations as the product | F3 is a must-have the dossier leaves ungraded, so this is the question most likely to arrive unrehearsed. JD because it scores R2 directly |
| A4 | "Tell me about the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on F5 and F1, using only the beats the sentence states: the sessions were quarterly, they were roadmap-input sessions, what went in was client evidence, and it went to product. Tell those in your own words. Volunteer the limit before it is extracted: the dossier grades this medium, so say plainly what can be shown of the sessions. Answer slot: if you can say what came back from product after a session, say what and which part was yours; if nothing came back, or you never saw what was done with it, say so plainly and stay with the sessions you ran. Do not describe the sessions as shaping the roadmap | The dossier flags this entry as the one to expect a probe on. EXP because it tests what was actually yours |
| A5 | "How comfortable are you with API docs and schemas?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Say what the sentences carry and no more: you led the integrations, and you wrote the integration playbook your team uses. Answer slot: if you worked from or wrote API docs or schemas, say which and how, in your own words; if you did not, say so plainly and stay with the playbook and the integrations. The playbook is the one artifact the dossier says can be inspected, so be ready to open it | F4 is an important requirement with nothing quoted that names docs or schemas. JD because it scores R3 |

### Bank B: Case and Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner tells you your API's auth flow is why their go-live slipped three weeks. What do you want to know first, and what do you do this week?" | CASE | [generic] | Structure aloud: clarify first (which partner, which flow, what exactly slipped, what evidence), then the objective (restore this partner and learn whether it is one partner or a pattern), then your approach, the metric you would watch, and the risks. Challenge one premise respectfully, for example that auth is the cause. The question needs no claim about your past, so the guidance makes none | The role includes running discovery with integration partners; the problem sets that in a live case. CASE because it scores structure |
| B2 | "Two squads disagree about next quarter: one wants webhooks, the other wants versioning. You have a day to recommend. Walk me through it." | CASE | [generic] | Clarify who decides before anything else, since decision authority is an open risk in the dossier. Then your criteria, what partner evidence you would pull, the cost to each squad, a recommendation, and what would change your mind. Use no example from your past: setting prioritization for a squad is on the prohibited list | The role drives delivery with two squads and owns the roadmap; this tests the exact seam the dossier leaves unresolved. CASE because it is a live decision |
| B3 | "How would you define and track adoption for a partner API platform, and what would you want to know before trusting your own numbers?" | CASE | [generic] | State the objective, a small set of adoption measures, and the baseline you would ask for first, since the dossier records no stated baseline. Name the assumption you would defend least in your own proposal. Claim no past measurement | Adoption metrics are a listed responsibility with no baseline stated. CASE because it asks for a design, with the weakest-assumption move built in |
| B4 | "You inherit a roadmap you did not build. What do your first thirty days look like?" | CASE | [generic] | This is the ramp plan F2 needs, said as a plan: who you would talk to and in what order, what you would read, what you would ask the squad leads, and what you would hold off deciding. It is the honest answer to the roadmap gap, so make it concrete and make no past claim | F2 is an acknowledged gap, so this question is its natural follow-on. CASE because it is a live planning problem |
| B5 | "A top partner asks for a custom endpoint the other partners do not need, and sales is pushing hard. What do you do?" | CASE | [generic] | Clarify the ask and the commercial stake, separate the partner's underlying need from the proposed solution, weigh it against the platform's other partners, say who you would involve in engineering and sales, and say what you would tell the partner. Claim no past experience | F5's requirement names engineering, sales and customers together; this puts all three in one problem. CASE because it scores trade-off reasoning |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure counts integrations, so keep it on that noun. Answer slot, in your own words: how the count was made, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. The pack supplies no counting method, baseline or definition | The figure is the headline number, which F1 and F3 both lean on. EXP because it tests whether the claim survives scrutiny |
| C2 | "What does end-to-end cover on one of these integrations?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The sentence states five stages: scoping, requirements, architecture, UAT, go-live, and states that you led. Tell those in your own words. Answer slot: if any stage was run by someone else on an integration, say which; if all five were yours to lead, say so; if the stages varied by integration, say that plainly. Add no stage the sentence does not list | A prober presses on "end-to-end" because it is a scope claim. EXP because it tests attribution |
| C3 | "Tell me about the integration playbook. How do you know it is used?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats the sentence states: you wrote it, it is internal, and your team uses it. Say it as "I wrote the internal integration playbook my team uses." Answer slot: if anything shows it is used, say what; if nothing does, say so plainly and stay with having written it. Offer to walk through it end to end, since it is the one inspectable artifact the dossier names. Do not say what it improved | The dossier grades this entry high because the playbook can be inspected, which makes it the safest place to be probed. EXP because it tests a claim against an artifact |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built only from the three sentences: you led the integrations, you wrote the playbook, you ran the sessions. Answer slot: say how long you have done this work and in what roles, in your own words, since the verified entries carry no tenure and the pack supplies none. End on why this role, in your own words, and let them draw the conclusion | The biography question is almost certain in this register. EXP because it tests whether the story matches the evidence |
| D2 | "What's pulling you from integration work toward the product side?" | JD | [generic] | Selection scaffold, because no quoted sentence states a reason for the move. Pick a specific thing you did that made you want the product side; it needs a named moment and a reason that is yours. If no such moment comes to mind, say so plainly, then say what you want from this role and how you would go about learning it. The pack supplies no motivation for you | The Skeptic's why-here-why-now probe often arrives in this friendlier form. JD because it scores fit with the role, and the guidance stays a scaffold because F1's material is silent on motivation |
| D3 | "How have you worked with agile delivery, if at all?" | JD | [grounded] | Clarify strategy, with no quote to lean on. Answer slot: the JD's "Agile delivery experience" is the probe's wording. If you have worked in agile delivery, say where and in what role; if you have not, or it was called something else, say so plainly, and say what you would want to confirm about how this team defines it. It is a preferred requirement, so keep it short | F6 is the dossier's clarify area. JD because it scores a stated requirement, asked casually |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years in the seat?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | A time-boxed A1. Pause, restate, then three beats: the plain concession sourced to `prohibited_claims: "Having held a product manager title or role"`, "I haven't held a product manager title or role"; the quote at its own scope, "I led 30+ end-to-end client integrations of the vendor's REST APIs"; and the limit, that this is adjacent. Hold through two follow-ups by returning to the quote, and concede specifically that the title holder has done the job and you have not. Never fold on the quote | The same objection as A1 in its hardest register. JD because the substance is the requirement; Pressure is only the delivery |
| E2 | "That integration count — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold on the sentence's own attribution: you led them. Answer slot: if any part of an integration was someone else's, say which part, plainly and without apology; if you are unsure how a share was divided, say that. Never widen "led" and never shrink it to please them | The Pressure stem for attribution, aimed at F1's headline sentence. EXP because it tests precise attribution |

### Bank G: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You'd sit alongside two squad leads — where is the seam between you and them, and what happens when you disagree?" | JD | [generic] | Offer principles, not a seam you cannot know: agree early who decides what, bring partner evidence to the squad leads rather than around them, and settle a disagreement on the criteria you agreed in advance. Then ask who decides what today, since the dossier lists squad authority as unevidenced. Claim no past example of setting a squad's priorities | The role's authority against the two squads is the dossier's first open risk. JD because it scores the stated delivery responsibility |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | An open prompt, so you choose the instance. Selection criteria: a time work crossed teams, with a clear line between what was yours and what was not, said with "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then say how you would handle it | The Peer Evaluator's collegial credit probe, a cousin of E2. VAL because it scores working behavior, and no company value is cited |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| R1 3+ years product management experience | A1, A2, D2, E1 | F1, bridged and positioned as adjacent |
| R1 sub-claim, roadmap and prioritization | A2, B2, B4, G1 | F2, acknowledged with a ramp plan |
| R2 Shipped API or platform products | A3, C1 | F3 |
| R3 Technical fluency: API docs, schemas | A5, C3 | F4 |
| R4 Stakeholder management | A4, B5, G1, G2 | F5 |
| R5 Agile delivery experience | D3 | F6 |
| Responsibility: partner discovery | B1 | |
| Responsibility: adoption metrics | B3 | |
| Company and strategy knowledge | none, and why | Strategy research did not run, so a CO question would be generic |
| Published values | none, and why | No values-style round is detected |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's risk is that decision authority versus the two squad leads is asserted in the JD but not evidenced; the answer settles what you would own, and it reads as diligence |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's risk is that adoption metrics are named as a responsibility with no baseline stated; you need the baseline before accepting, and asking it shows you think in measures |
| 3 | "How does partner feedback reach the roadmap today: who brings it, and in what form?" | It tests whether the partner-evidence channel you would feed exists, and invites the interviewer to describe the gap you can speak to without claiming it |
| 4 | "Where do the two squads pull against each other most, and how does the PM usually get drawn in?" | It surfaces the seam from the first risk in a concrete form and tells you what the first month would hold |
| 5 | "What would I need to have shown you by the end of month three for you to be confident in the hire?" | It turns the title objection into a defined bar, and your next answer can address it directly |
| 6 | "Which part of this role has been hardest to hire for, and why?" | It lets the interviewer name the capability they most want, which tells you how to weight the rest of your answers |

## Prohibited claims

Built before the banks and binding on every cell above. The first three are the dossier's `prohibited_claims`; the rest are inflated forms this pack built from your quoted sentences.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | F1's quote at its own scope, with the plain acknowledgment "I haven't held a product manager title or role", sourced to that field |
| Having owned a product roadmap | Dossier `prohibited_claims` and the `acknowledge_gap` area for F2 | The plain acknowledgment "I haven't owned a product roadmap", sourced to those fields, then a ramp plan said as a plan. No slot and no bridge |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | The plain acknowledgment "I haven't set prioritization for an engineering squad", sourced to that field. No slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says integrations of the vendor's REST APIs. A3's slot stays on whether the product was yours |
| Wrote API documentation or schemas | Inflated form of F4 | F4's quotes at their own scope. The limit is the pack's observation: the material says a playbook, not docs or schemas. A5's slot stays on what you worked from |
| Managed engineering and sales stakeholders | Inflated form of F5 | F5's quotes at their own scope: clients and product. The limit is the pack's observation that engineering and sales are not shown |
| Shaped the roadmap through the input sessions | Inflated form of F5, and brushes the roadmap line above | The sessions quote at its own scope, with the medium-confidence limit volunteered. A4's slot asks only what came back from product |

## Sources

Provided documents: `tuesday-dossier.md`, dossier_version 1.1, generated by the job-underwriter skill on 2026-08-14. Sections consumed: `role_profile` (the JD tier), `handoff_to_mock_interview` (`verified_candidate_evidence`, `uncertain_or_weak_areas`, `likely_interviewer_objections`, `opportunity_risks_to_validate`, `questions_for_employer`, `prohibited_claims`) and `decision` (context only). The dossier carries no `evidence_map`, `evidence_state` or `risk_register`, so the grading of F3 to F5 is this pack's own derivation. Everything on the candidate's side rests on your confirmed entries; everything else is inference from them.

Searches sent, all refused by the host's permission setting, none returned results:

- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline strategy partner API platform news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions; none is built |
| 2. Quartzline interview process, product manager | unavailable | Every call was refused. It would have set the loop structure and persona weights; weights rest on the hiring-manager prior and the Generic archetype, so a values-style round is not assumed |
| 3. Quartzline strategy and recent news | unavailable | Every call was refused. It would have fed a CO question grounded in current strategy; the CASE bank is labeled generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Product Manager, Platform APIs JD | skipped | The dossier's `role_profile` already fixes the requirements and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep note → focus areas and any pre-declared deliverable, which would add a build section and reweight the banks
- Search permission for the refused research, plus the optional deeper tier (up to 6 more searches and 2 more fetches, several more minutes) → Quartzline's published values, a documented loop, a strategy brief and a grounding section, and a CO question that is no longer generic
- Your answers to the slots in F3, F4, F5 and F6 → those rows move from `discovery` toward grounded stories, and A3, A5, D3 and the banks that draw on them become story-mapped
- An inspectable artifact for the roadmap-input sessions, such as agendas or the notes you shared with product → entry 3 moves from medium toward high, and A4 loses its probe risk
- The raw CV behind the confirmed claims, including dates and tenure → D1's tenure slot closes and F1 to F5 can quote dated lines
