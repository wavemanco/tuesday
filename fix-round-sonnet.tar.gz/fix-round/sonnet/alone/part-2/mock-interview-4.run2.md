I'll start by reading the reference files the skill points to.
The pack is written. I'm running one quick check on the file for stray brackets and pipe characters, then I'll send it.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-4-denied-e0889d9e/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for the 45-minute hiring-manager conversation from your dossier alone. It has 20 questions across six interviewer styles, with the most weight on the Skeptic and the Case/Strategist.

- **Research didn't run.** Both Quartzline searches (values, strategy) were refused. Nothing in the pack rests on the company's own values or strategy, so it has no company-knowledge questions and the values questions are generic. The Sources table lists the refused searches.
- **Highest-ROI prep is A1**, the objection the dossier names: "never held the PM title or owned a roadmap, why you over a PM with three years of the job?" It's built to concede first, in the dossier's own words, then give your integration leadership as adjacent and never as PM experience, and end on a ramp plan. It has four follow-up levels.
- **The roadmap gap gets no bridge.** The dossier marks it acknowledge-gap, so the pack coaches a plain acknowledgment and a ramp plan. Your roadmap-input sessions come up only if probed, at their own scope. Say up front that they're confirmed but have little inspectable proof.
- **Prohibited claims are fixed.** The pack never has you claim a PM title, an owned roadmap, or squad prioritization authority. It also lists "shipped API products" as a stretch of your integration work. The R2 and R3 rows (API products, API docs and schemas) are my own grading, because the dossier didn't grade them. Where your material is silent, the guidance is a slot for you to answer from your real experience, or to say plainly that it wasn't yours.
- **Reverse questions.** The first two are the dossier's own open items: which roadmap decisions the PM makes alone versus the squad leads, and how adoption is measured today and its baseline.
- **Dossier date.** The dossier was generated 2026-08-14, so check that the role hasn't changed since.

I left out the prep schedule because I don't know how many hours you have. The upgrade menu at the end of the pack lists what would unlock it and the other missing pieces.

Say the word and I'll play the Skeptic on A1, live, with follow-ups.
I can also save your `tuesday-dossier.md` with a record of the gaps this prep exposed, so you can carry it into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday. Interviewer name not given, so there is no interviewer read. Built on the dossier you carried (conditional_go). Company research was not available (see Sources), so nothing here rests on Quartzline's own values or strategy.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script: where a quoted sentence of yours carries a story, the guidance names its beats; where none does, you get an answer slot or a selection scaffold.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows how you work with people, in the company's published terms where known |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge (no CO question in this pack, because research did not run) |
| CASE | A live problem from the role, scored on structure and reasoning |

A1 is the highest-ROI prep in this pack. The underwriting named that objection from evidence you confirmed (likely_interviewer_objections), so it gets the deepest rehearsal.

## Fit snapshot

Requirements are the JD lines in the dossier's role_profile. Evidence is your own sentences from the dossier's verified_candidate_evidence. The dossier grades R1, the roadmap sub-claim and R5 only; every other row's grade is this pack's own derivation and is labeled that way.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | transferability | Adjacent, positioned as adjacent and never as PM experience. The pack's observation: your material carries integration leadership and roadmap-input sessions, and no product-management work. Words: the first quote at its own scope, then the plain acknowledgment "I haven't held a product manager title or role" (prohibited_claims: "Having held a product manager title or role"). The second quote is confirmed with limited inspectable proof, so volunteer that limit before a probe finds it |
| F2 | "Shipped API or platform products" — JD (dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | The dossier does not grade this row, so the grade is the pack's derivation. Your material says integrations of the vendor's REST APIs, not shipping an API product, and the words stay at the integrations. Answer slot: the JD's second requirement makes a probe on how far your integration work reached into the API itself likely. If any integration led to a change in the API or its documentation, say what and what part was yours, in your own words; if none did, or that side was someone else's, say so plainly and return to the integrations you led |
| F3 | "Technical fluency: API docs, schemas" — JD (dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote touches the APIs and lists architecture among its stages, without showing whether you worked from docs or schemas. Answer slot: the JD's technical-fluency line makes a probe on what you read or wrote likely. If you worked from the API's docs or schemas, say which and what you did with them, in your own words; if those were someone else's to read, or you worked from other material, say so plainly and return to the integrations |
| F4 | "Stakeholder management across engineering, sales, customers" — JD (dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quotes carry clients and product; they do not name engineering or sales, which the requirement does. Words: both quotes at their own scope. Answer slot: the JD's line names engineering and sales, so expect a probe on who else you worked with. If you worked with engineers or sales on any of those integrations or sessions, say who and what part was yours; if not, say so plainly and stay with the clients and product. Volunteer the limit on the second quote: confirmed, limited inspectable proof |
| F5 | "Agile delivery experience" — JD (dossier role_profile, preferred) | none given | low | [grounded] | discovery | No sentence of yours speaks to this requirement, so nothing about your past goes in the answer. Answer slot: the JD's agile line makes a probe on how you worked with a delivery team likely. If you worked that way, say how and what your part was, in your own words; if you did not, or it was not yours, say so plainly. Then say what you would want to confirm about how this team defines it |
| F6 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile) | none given | none | [grounded] | capability | A gap wording cannot close, and the dossier records it: the uncertain_or_weak_areas entry for the roadmap sub-claim carries the strategy acknowledge_gap. Words: "I haven't owned a product roadmap" (prohibited_claims: "Having owned a product roadmap") and "I haven't set prioritization for an engineering squad" (prohibited_claims: "Having set prioritization for an engineering squad"). Then how you would learn it, said as a plan and never as a past: ask which roadmap decisions are yours and which stay with the squad leads, and what the adoption baseline is. No bridge and no slot |

## Persona table

No interviewer information exists, so weights come from the round type. Your own words establish the loop as one 45-minute hiring-manager conversation, so no archetype fallback is used.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic (bank A) | Quiet, persistent probing of the title and roadmap gap, motivation, and weakest area | high | Hiring-manager prior is Case plus Skeptic; the dossier names a specific objection and three weak areas; the squad-authority and adoption-baseline unknowns sit nearby | Rehearse A1 until it is boring; concede the roadmap gap plainly; bridge only from adjacent evidence with its limit named |
| Case/Strategist (bank B) | Live problems from the role: roadmap choices, flat adoption, squad conflict, partner requests | high | Hiring-manager prior; the JD's own responsibilities are roadmap, discovery, specs, adoption metrics | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (bank C) | Line-by-line probing of what you wrote and led | medium | The 30+ figure is the one number in your evidence, and one sentence is confirmed with limited inspectable proof | Know what you can and cannot say about how the figure was counted; say plainly where you do not know |
| Conversational (bank D) | Friendly opener and a casual values question that is still scored | medium | A 45-minute conversation usually opens loosely | Prepare a 90-second arc and treat casual questions as scored |
| Pressure (bank E) | The A1 objection arrives time-boxed or as an attribution challenge | low | No signal of a stress style; the objection could still arrive compressed | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator (bank F) | A collaboration scenario about the two squad leads | low | The JD names two squads and the dossier lists squad authority as an open unknown, but the person across the table is the manager | Propose seam principles rather than pretending to know the seam |
| Values/Behavioral | Not banked beyond D2 and F2 | low | No values-style round was detected: no loop source names one, and no published values were read | Selection scaffolds in D2 and F2 cover the likely casual version |

## Question banks

### Bank A: Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | Deepest rehearsal in the pack. Concede first, in the sourced words, before the interviewer extracts it: "I haven't held a product manager title or role" and "I haven't owned a product roadmap". Then the adjacent case at its own scope, positioned as adjacent and never as PM experience: the beats are the ones the quote states, which are 30+ end-to-end client integrations of the vendor's REST APIs, led, from scoping through go-live; tell them in your own words and stop, because the inference is the interviewer's to draw. Name the limit yourself: this is integration leadership, not product management. Ramp plan, said as a plan: ask which roadmap decisions are yours and which stay with the squad leads, and what the adoption baseline is. Follow-up 1, what would be weakest on day one: return to the roadmap acknowledgment, no bridge. Follow-up 2, why you over someone who has done the job: do not claim better; hold the sentence at its scope and concede that the roadmap work is the part you would be learning. Follow-up 3, did you set priorities for engineers: "I haven't set prioritization for an engineering squad". Follow-up 4, any contact with a roadmap: give the sessions at their own scope, "Ran quarterly roadmap-input sessions feeding client evidence to product", never as roadmap ownership, and volunteer that this one is confirmed but with limited inspectable proof | The underwriting named this objection from evidence you confirmed, and it is aimed at F1 and F6. JD because it scores the 3+ years requirement and the roadmap responsibility; the question is asked as the underwriter wrote it because its negatives are sourced to prohibited_claims and the acknowledge_gap area |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; the uncertain_or_weak_areas entry for the roadmap sub-claim, strategy acknowledge_gap | Pick one weakness and say it: "I haven't owned a product roadmap". Then the ramp plan as a plan: ask which roadmap decisions are yours and which stay with the squad leads, then how adoption is measured today and what its baseline is. No bridge and no slot here, because the underwriting found no evidence to bridge from. Do not spread the answer across the JD to look balanced | F6 is the row with no evidence, so this is the question that arrives when the interviewer wants candor; JD because it scores the stated responsibility |
| A3 | "Why product management, and why this role?" | JD | [generic] | Selection scaffold with no claim about your past: choose the reason you can describe concretely and tie it to a line of the JD you can quote back, such as "Run discovery with integration partners". Say what you want to learn as well as what you want to move toward. No company research ran, so use only what the JD says about the role. If no reason comes to mind beyond wanting a next step, say so plainly, then give the nearest thing your material does carry, or how you would handle the transition | Motivation consistency is the Skeptic's second probe after the gap in F1; JD because it tests fit with the stated role, and generic because no Quartzline source was read |
| A4 | "We list agile delivery experience as preferred. Where does that stand for you?" | JD | [grounded] | No sentence of yours speaks to this requirement, so this answer makes no claim about your past. Answer slot: the JD's agile line makes a probe on how you worked with a delivery team likely. If you worked that way, say how and what your part was, in your own words; if you did not, or it was not yours, say so plainly. Then say what you would want to confirm about how this team defines it | F5 is the dossier's clarify area, so the answer is question-shaped; JD because R5 is a stated requirement, preferred rather than must-have |
| A5 | "You led client integrations of the vendor's REST APIs. This role asks for shipped API or platform products. Where is the line between the two in your experience?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote carries: the integrations, 30+, of the vendor's REST APIs, from scoping through go-live, in your own words. Answer slot: expect a probe on how far your integration work reached into the API itself. If any integration led to a change in the API or its documentation, say what and what part was yours; if none did, or that side was someone else's, say so plainly and return to the integrations you led. Do not describe the work as building or shipping the API | F2 is a must-have row the underwriting did not grade, so a hiring manager has reason to probe it directly; JD because it scores R2 |

### Bank B: Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would decide the first three things on this platform's roadmap. What do you need to know first?" | CASE | [generic] | No claim about your past is needed and none is made. Clarify first: which partners and at what stage, what the adoption baseline is, what capacity the two squads have, and which decisions are yours. Then objective, segmentation of partners, how you would rank candidate items and on what evidence, the metrics, and the risks. Say aloud which calls you would not make alone. Frame it as how you would approach the work, not as something you have done | The JD makes the roadmap the first responsibility and the hiring manager owns that roadmap; CASE because it is a live problem, and generic because no Quartzline source was read |
| B2 | "Partner API adoption has gone flat. Diagnose it." | CASE | [generic] | Clarify what adoption means here and how it is measured today, since the baseline is an open item. Then structure: where partners drop out between first contact and live use, by partner segment; what you would check first and what each result would change; the one metric you would track and its weakest assumption; the risks. Think aloud and say what you do not know | The JD lists adoption metrics as a responsibility and the dossier lists the baseline as unevidenced; CASE because it is a diagnosis problem |
| B3 | "Two squads want different things next quarter: one wants a partner-requested endpoint, the other wants reliability work. How do you decide?" | CASE | [generic] | Ask first who decides, since decision authority versus the squad leads is an open item. Then the criteria you would use, the evidence you would want from partners and from each squad, how you would handle a disagreement that does not resolve, and when you would escalate. Make no claim that you have settled this before | The JD has the PM drive delivery with two squads; CASE because it tests reasoning under shared authority |
| B4 | "A large partner asks for an API change that mainly helps them. Walk me through what you would put in the spec and what you would decide first." | CASE | [generic] | Clarify how many other partners have the same need and what the change costs the squads to keep. Then the spec skeleton: the problem, who it is for, the success measure, what is out of scope, and the open questions for the squad leads. Name who decides as one of the open items and say you would confirm it. No claim about your past | The JD has the PM write specs; CASE because it asks for a spec outline on a live request |
| B5 | "You have a first week with the integration partners. What do you ask them?" | CASE | [generic] | Say what you want to learn: what stops a partner reaching live use, what they work around, what they would pay attention to if it changed. Say how you would record it and bring it back to the squads, and what you would not promise partners. Keep it a plan; it makes no claim about discovery you have run | The JD's discovery responsibility; CASE because it is a plan problem. Your own sessions are rehearsed separately in C4 |

### Bank C: Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what you led, in the quote's words: 30+ end-to-end client integrations of the vendor's REST APIs. The figure counts integrations; do not let it slide onto clients or APIs. Answer slot for the four things a figure raises, each in your own words: how the 30+ was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | F1 and F2 both lean on the figure in this row's quote, so a prober starts here; EXP because it tests whether the number survives a second question |
| C2 | "Walk me through the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats are the ones the quote states: you wrote it, it is internal, your team uses it. The dossier records this as your one inspectable artifact, so offer to walk through it end to end. Describe what is in it from the document itself, not from memory of what such playbooks contain | It is the strongest-evidenced item in the dossier, so the Prober can verify it; EXP because it tests what you wrote versus what your team did with it |
| C3 | "This role asks for fluency with API docs and schemas. What has your experience with them been?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The quote carries the integrations of the vendor's REST APIs, with architecture among the stages you led; say that at its scope. Answer slot: if you worked from the API's docs or schemas, say which and what you did with them, in your own words; if those were someone else's to read, or you worked from other material, say so plainly and return to the integrations | F3 is a discovery row: the evidence may exist and the material does not show it; JD because R3 is a stated requirement |
| C4 | "Tell me about a time you took partner or client feedback to a product team." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on the sessions: quarterly, roadmap-input, client evidence going to product; tell it in your own words with those beats and no others. Volunteer the limit before it is extracted: this is confirmed, with limited inspectable proof, and you can describe the sessions but may have nothing to show. Answer slot: the JD's discovery line makes a probe on what came of the sessions likely. If anything product did changed because of what you brought, say what and what part was yours; if nothing did, or you do not know, say so plainly and return to the sessions themselves | The dossier grades this sentence medium and expects a probe; EXP because it tests what was yours versus product's |

### Bank D: Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built only from these three sentences: the integrations you led, the playbook you wrote, the roadmap-input sessions. The quotes give no order or dates, so use the order you actually lived and add no dates. Position it as adjacent to product work and never as product work, then land on why this role, using the A3 scaffold. Treat the sessions at their own scope and keep the limit in mind: confirmed, limited inspectable proof | The opener is scored even when it feels casual; EXP because it is a walkthrough of what the quotes carry |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use "we" for context and "I" for what you did | A standard values stem from the Values persona, included because the Conversational interviewer can ask it casually; VAL because it scores behavior, generic because no published Quartzline values were read |

### Bank E: Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | Hold-then-concede in sixty seconds. Pause and restate the question. Concede: "I haven't held a product manager title or role". Hold only what the quote carries, at its scope: the 30+ client integrations of the vendor's REST APIs, led, from scoping through go-live. Close with the ramp plan: ask which roadmap decisions are yours and which stay with the squad leads. Hold through two follow-ups by returning to the sentence, never by adding to it, and do not claim to be better | A1 compressed and time-boxed; JD because it scores R1 |
| E2 | "Those 30+ integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the sentence: you led them. Answer slot: the quote lists scoping, requirements, architecture, UAT and go-live, so expect a probe on which of those you did yourself and which your team did; say which, in your own words, and if a stage was someone else's, say so plainly. Concede specifically, and do not fold on the core claim to restore harmony | Attribution challenge on the one figure in the evidence (F1); EXP because it tests candor about what was actually yours |

### Bank F: Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "You would work alongside two squad leads. Where is the seam between your calls and theirs, and what happens when you disagree?" | CASE | [generic] prohibited_claims: "Having set prioritization for an engineering squad" | Propose seam principles rather than pretending to know the seam, and say that how it works here is an open question you would settle first. Concede plainly: "I haven't set prioritization for an engineering squad". Then how you would disagree: bring the partner evidence, hear the squad's constraint, decide who owns the call before the next one arrives, and record it. Frame it as how you would work, not as how you have worked | Decision authority versus the squad leads is the dossier's named unknown; CASE because it is a collaboration scenario set in the role |
| F2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Wrote the internal integration playbook her team uses" | Use the sentence's own split: you wrote it, your team uses it. Say that with "I" for what you wrote and "we" for the team's use. If shared work comes to mind from the integrations, say who did what in your own words; if none does, say so plainly and return to the playbook | A Peer stem about credit; VAL because it scores how you share ownership, and the playbook is the one sentence that already draws the line |

## Requirement coverage

| Requirement or responsibility | Questions | Note |
|---|---|---|
| R1 "3+ years product management experience" | A1, A2, A3, E1 | Deepest rehearsal on A1 |
| R2 "Shipped API or platform products" | A5, C1 | |
| R3 "Technical fluency: API docs, schemas" | C3 | |
| R4 "Stakeholder management across engineering, sales, customers" | C4, B3, F1, F2 | |
| R5 "Agile delivery experience" | A4 | |
| "Own the roadmap for the partner-facing API platform" | A1, A2, B1 | |
| "Run discovery with integration partners" | B5, C4 | |
| "Write specs and drive delivery with two engineering squads" | B3, B4, F1 | |
| "Define and track adoption metrics" | B2 | Baseline is an open item; see reverse question 2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier flags decision authority as asserted in the JD and not evidenced. It reads as diligence, and you need the answer before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier flags that adoption metrics are a named responsibility with no stated baseline. It shows you think in measures, and it tells you what you would be judged on |
| 3 | "If you wrote the first ninety days for your new PM, what would be on it?" | It turns the gap in F1 and F6 into a conversation about ramp, with the interviewer defining the ramp |
| 4 | "How do the two squads take partner feedback into their plans today, and where does it get stuck?" | It surfaces how discovery actually flows, and it gives you a natural opening if the interviewer wants to hear about the sessions in F4 |
| 5 | "What would make you say at six months that this hire was the right call?" | It asks for the success measure in the interviewer's words and leaves nothing generic in the closing slot |

## Prohibited claims

Built before the banks. Three entries come from the dossier's prohibited_claims, and one is built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | The plain acknowledgment "I haven't held a product manager title or role", then F1's first quote at its own scope, positioned as adjacent |
| Having owned a product roadmap | Dossier prohibited_claims, and the uncertain_or_weak_areas entry with strategy acknowledge_gap | The plain acknowledgment "I haven't owned a product roadmap", then the ramp plan said as a plan. No bridge and no slot. The roadmap-input sentence is given only at its own scope when a probe asks, never as a substitute |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | The plain acknowledgment "I haven't set prioritization for an engineering squad". No slot |
| Shipped API or platform products | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says integrations of the vendor's REST APIs, not shipping an API product. A5's slot stays inside the integrations |

## Sources

Provided documents: tuesday-dossier.md, dossier_version 1.1, generated 2026-08-14. Sections consumed: role_profile (it stands as the JD), handoff_to_mock_interview (verified_candidate_evidence, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims), and decision as context only. The dossier carried no evidence_map, evidence_state or risk_register, so those did not feed the pack.

Searches sent:

- "Quartzline company values" — refused
- "Quartzline API platform strategy news" — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have named published values for VAL themes; D2 and F2 are generic instead |
| 2. `Quartzline interview process product manager` | skipped | Your own words fix the loop as one 45-minute hiring-manager conversation, which fixes the persona weights |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have supported a CO question grounded in current strategy; none is in this pack |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile supplies the requirements and fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's note on format or focus areas → coverage of anything pre-declared, such as a case or a presentation
- Hours you have before Thursday → a prioritized prep schedule sized to them
- Permission to run searches → Quartzline's published values and recent strategy, which would add CO questions and replace the generic VAL rows; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief after that
- Your answers to the slots in A4, A5, C1, C3, C4 and E2 → rows F2, F3, F4 and F5 upgrade from slots to quoted evidence
- A roadmap-input session agenda or notes → raises the medium band on the sessions sentence toward high
- An excerpt of an API doc or schema you worked from → raises F3 from low
