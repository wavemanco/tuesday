I'll read the reference files the skill points to before building the pack.
The pack is written. This last message presents it.

Your prep pack is saved as `atlas-freight_operations-manager_interview_pack.md`. It's built for a hiring-manager round, since I don't know who you're meeting. The weights lean toward live cases and skeptical probing of scope and tools.

My three web searches about Atlas Freight were refused in this session. Nothing in the pack is researched about the company, and the Sources section shows what each search would have moved. The company-knowledge questions (A5 and E2) rest only on your JD text.

The pack names B1 as the highest-ROI prep. It sets four sites and twelve supervisors against your current scope. The Power BI gap (B2) and the 5+ years count (B3) are rehearsed with plain, honest wording.

Say the word and I'll play the Skeptic on B1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting, and in what kind of round (hiring manager, peer, someone senior, HR or a panel)? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees), per the JD you pasted
- **Interviewer and relationship:** not known. This pack is built on the assumption of a hiring-manager conversation, and the persona weights below say what that assumption does
- **Research:** none ran. My searches about Atlas Freight were refused in this session, so nothing here is researched about the company. Section "Sources" shows what was sent and what each target would have moved

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for your own words, not a script: where it quotes you, those are the only sentences about your past it rests on, and where it has an answer slot, the slot is an instruction for the interview, answered from your real experience.

Type key:

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values: does your past behavior show the behavior asked about |
| EXP | Work-experience deep-dive: does what you said survive scrutiny, and what was actually yours |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company knowledge: homework depth |
| CASE | Live problem from the role: structure and reasoning |

Highest-ROI prep in this pack: **B1**. It is the question your background most predictably draws (the JD's scope set against yours), and it gets the most follow-up levels and the most exact concession wording.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift manager and a site surge plan, and shows no terminal work and nothing beyond the one site, with nothing inspected behind it. The words stay there: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's daily-operations line makes a probe on what running a day involved likely. Say which decisions on a shift were yours to make and how you made them, in your own words; if the daily running was set elsewhere, or there was no such decision, say so plainly and stay with the shift and the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate is the measure your material carries, and the JD names two others. The words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's two measures make a probe on what else you tracked likely. If you tracked anything besides mis-pick rate, say what it was and what it showed; if you tracked only mis-pick rate, say so plainly and stay there |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The JD's team is larger than the one your material states, and that difference is the pack's observation, not words for you. The words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: expect a probe on how you lead supervisors. If you set how your supervisors worked day to day, say how, in your own words; if you did not, or it was set elsewhere, say so plainly and describe what you do with them |
| F4 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" says a skill, not what was built in it, so the JD's word "build" is not yet reached. Answer slot: if you built any report or tracker in Excel, say what it showed and who used it, in your own words; if none was built, say so plainly and say what you would build first |
| F5 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would get to working use, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The first quote gives seven years in operations and does not show how they break down by role. The words: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's count makes a probe on how the years break down likely. Say how they break down by role, in your own words; if you do not know how to count them, say so plainly and give the roles you held |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but one line with nothing inspected behind it, so expect a probe on it. Say it in the quote's own terms: "I'm green belt certified." If asked, say who certified you and what it covered, in your own words; if you do not recall the details, say so plainly |

No row is a gate: the JD's one length-of-experience requirement (F6) is graded like any other, and nothing in the JD or your message states a licence, location, schedule or travel term.

## Persona table

The loop is not established by any source I could read, so the weights rest on a round-type pattern, not on this company's documented process. Assumption: hiring-manager round.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: slipping on-time, rising cost, a volume spike, a reporting design | High. The hiring-manager prior puts it first, and the JD's measures (on-time, cost per shipment) are natural case material | Clarify, then objective, then segmentation, then approach, metrics and risks, aloud; challenge one premise respectfully per case |
| Skeptic | Quiet probing of scope, tools and the experience count | High. The hiring-manager prior puts it second, and F1, F3, F5 and F6 are where the JD and your material are furthest apart | Rehearse B1 until it is boring: hold the quoted words, then the slot answers, never more |
| Data-Driven Prober | Reads the CV line by line and asks how the 40% was counted | Medium. F2's figure is the one number in your material, and a figure is where probers start | Know what you can and cannot say about how the figure was counted, and say plainly where you do not know |
| Pressure | Time-boxes and asks how much of a result was actually you | Medium. Unknown round type keeps it plausible, and F2 and F3 are natural pressure targets | Pause, restate, anchor in what you said, hold through two follow-ups, then concede specifically |
| Conversational | A friendly walk-through of your journey that is still scored | Medium. Often the opening of any round, and the pack cannot rule it out | A 90-second arc built only from your own sentences |
| Values/Behavioral | Scenario probes on leading supervisors | Low to unknown. No source documents a values round, and the generic fallback does not assume one | A story where one of your sentences carries it, otherwise the selection scaffold and its honest branch |
| Peer Evaluator | Seam-splitting with an adjacent team lead | Low. Applies only if the round is with a peer, which the material does not say | Reciprocity framing; propose seam principles rather than claiming to know the seam |

Depth follows weight: 5, 5, 3, 3, 2, 2, 2.

## Question banks

Requirement coverage, JD requirement to question IDs:

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B1, B4, C3 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, C1 |
| "lead a team of 12 supervisors" | B1, D2, V1, V2 |
| "build reporting in Excel/Power BI" | A4, B2 |
| "5+ years operations leadership required" | B3 |
| "Lean/Six Sigma a plus" | D3 |
| "regional logistics" (company context) | A5, E2 |

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You take over four sites and on-time performance has slipped at two of them. Walk me through your first two weeks." | CASE | [generic] | Structure it aloud: what you would ask first (how on-time is defined, where in the day it slips, what data exists), the objective, a segmentation (site, shift, lane, customer, day of week), your approach (compare the two slipping sites with the two holding, and go and see), the metrics you would watch, and the risks. Challenge one premise politely. The question needs no claim about your past, so the guidance makes none | The JD's on-time requirement (F2) asked as a decision rather than a record. CASE because it scores structure; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "Cost per shipment has crept up over two quarters and nobody agrees why. How do you break it down?" | CASE | [generic] | Decompose before diagnosing: the numerator (labor, overtime, equipment, fuel, claims) against the denominator (volume, shipment mix and size). Say what you would ask for first, how you would separate what a site controls from what it does not, and how you would know a fix worked. Makes no claim about your past | The JD's cost-per-shipment requirement (F2) as a live problem; CASE because the score is the decomposition |
| A3 | "Volume across your four sites jumps well above plan next week. What do you do in the first 24 hours?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: scale and duration, the constraint that binds first at each site, what you would protect, and who you would call. If asked how this compares with your own surge work, the sentence is "I ran the site's peak-season surge plan two years running." Answer slot: the question's setting makes a probe on which parts of that plan were yours likely. Say which parts you set and how you decided, in your own words; if it was set elsewhere, or you carried it out, say so plainly and stay with the plan you ran | The surge plan in F1 is the nearest evidence for this problem, and the question tests whether the structure holds when the setting is bigger. CASE because it is a live problem; the plan quote is used only at its own scope |
| A4 | "We want a daily performance report that the 12 supervisors actually use. What goes on it, and how would you build it?" | CASE | [grounded] "solid Excel"; "never used Power BI" | Start from the decisions a supervisor makes in a shift and what they need to see at which hour; keep the measures few; separate what is leading from what is lagging; pilot before rolling out; plan for adoption. On tools, use your own words from the sources: "solid Excel", and "I've never used Power BI." Say how you would get to working use as a plan, never as a past. Answer slot: if you have built a report or tracker in Excel, say what it showed and who used it; if you have not, say so plainly and describe what you would build first | The JD's reporting requirement (F4, F5) as a design problem, which lets you show judgment where the tool gap is real. CASE because the score is the design reasoning |
| A5 | "Why would a customer pick a regional carrier over a national one, and what does operations have to get right to keep them?" | CO | [generic] | No Atlas-specific facts are in this pack, because the research could not run, so do not state any as fact. Reason from the question: what a regional operator can offer a shipper, and what in operations protects it. Where you are unsure about Atlas, ask the interviewer what their customers value most, and say what you have read from the JD | A company-altitude question for a role in regional logistics. CO because it scores whether you can think at the company's level; `[generic]` because the company research is absent |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role covers four sites and twelve supervisors. Set that against where you are today." | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | The highest-ROI rehearsal in this pack. Level 1, hold: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Level 2, the follow-up "what changes": answer slot: say what is the same and what is bigger, in your own words; if you have not held a scope of this size, say so plainly and say what you would do first. Level 3, "how do you lead people you do not see every day": answer slot: if you set how your supervisors worked day to day, say how, in your own words; if you did not, say so plainly and describe what you do with them. Level 4, "why are you ready now": return to the two quoted sentences and add nothing. Concede only the limit F1 and F3 name; never fold on the quoted words | F1 and F3 are where the role's scope presses hardest on your material, so this objection arrives in some form. JD because it scores the stated requirement; the limit is named in those rows, before it is asked for |
| B2 | "The role builds reporting in Excel and Power BI. Where are you on Power BI?" | JD | [grounded] "never used Power BI"; "solid Excel" | Say it plainly and early: "I've never used Power BI." Then say, as a plan, what you would learn first and how you would know it was working. Do not bluff and do not over-apologize; the concession should take about twenty seconds. On Excel, the quoted words are "solid Excel". Answer slot: if you built a report or tracker in Excel, say what it showed and who used it; if none was built, say so plainly and say what you would build first | F5 is a gap you stated, and F4 is where the Excel half is thin; the honest answer is rehearsed so it comes out unhurried. JD because it scores a named tool requirement |
| B3 | "The posting requires 5+ years of operations leadership. Talk me through how your seven years break down." | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Say the words your material carries: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: say how the years break down by role, in your own words, with approximate dates only if you know them; if you do not know how to count them against the posting, say so plainly and give the roles you held | F6 is graded as a requirement and not a gate, and your material does not show how the years divide. JD because it scores a stated qualification |
| B4 | "This is terminal operations across regional sites. What would be different from where you work now?" | JD | [grounded] "7 years in warehouse and distribution ops" | Make no claim about terminal work. Answer slot: say which parts of your current work you expect to carry over and which you do not yet know; if you do not know what differs, say so plainly and say how you would find out in your first weeks. Name two or three things you would ask before changing anything | F1's requirement uses the word terminal where your material uses warehouse and distribution, and the question tests how you handle that seam. JD because it scores the listed responsibility |
| B5 | "Why leave a senior role where you are for this one, and why now?" | JD | [generic] | Selection scaffold, no claim about your past: give the real reason in one or two sentences, tie it to something in the role you can name from the JD, and keep it forward-looking rather than a complaint. If no specific reason comes to mind, say so plainly, then give the nearest honest thing you would want from the role | The standard motivation probe the Skeptic persona uses. JD because it tests fit with the role, and `[generic]` because the pack has no source for your reasons |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Start with the sentence: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say in your own words how the 40% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly; that is an honest branch. Never describe a method you did not use | F2's figure is the one number in your material, and a figure is where probers start. EXP because it scores whether the claim survives scrutiny |
| C2 | "You redesigned the pick path. What was yours in that, and what was done by others?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence. Answer slot: say which parts of the redesign were yours, in your own words; if it was done with others, or you carried out a design set elsewhere, say so plainly and describe your part | The attribution probe on F2. EXP because it tests what was actually yours |
| C3 | "Walk me through the surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Tell it with the beats the sentence states: the site, peak season, and two years running, in your own words. Answer slot: the JD's daily-operations line makes a probe on your part in it likely. Say which parts you set and how you decided; if it was set elsewhere, or you carried it out, say so plainly and stay with the plan you ran | F1's surge-plan quote is your strongest operations-leadership evidence and the likeliest place for a follow-up. EXP because it tests what was yours |

### D. Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Hold the sentence through two follow-ups. Answer slot: say which part was yours and which was not, in your own words; if you do not know how to split it, say so plainly. Concede specifically, never on the whole claim | The Pressure form of C2 on F2. EXP because the scored quality is composure on attribution |
| D2 | "Sixty seconds: you're over three supervisors today and this job has twelve. Why you?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Pause, restate, then use the quote: "I'm currently a senior shift manager over 3 supervisors." Answer slot: say how you lead them, in your own words; if you did not set how they work, say so plainly and describe what you do with them. Concede the scale difference specifically, then say what you would do first. Do not claim the larger team's experience | F3's scope gap in a time-boxed delivery. JD because the scored content is the leadership requirement |
| D3 | "Lean and Six Sigma are a plus here. Why should I care that you're green belt certified?" | JD | [grounded] "green belt certified" | Say it in the quote's terms: "I'm green belt certified." Answer slot: say who certified you and what it covered, in your own words; if you do not recall the details, say so plainly. Do not attach the certification to any result your sentences do not connect it to | F7 reads as a plus, and a pressure interviewer tests whether a certification carries weight. JD because it scores the listed plus |

### E. Conversational/Rapport (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc in your own words, using only the beats the sentences state: seven years in warehouse and distribution ops, now a senior shift manager over three supervisors, the pick-path redesign, the surge plan, the green belt. End with why this role, in your own words; if no reason comes to mind, say so plainly and name the nearest honest thing you want from it | The biography question is scored even when it feels casual, and every beat here comes from F1, F2, F6 and F7. EXP because it tests whether the story holds together |
| E2 | "What do you know about us?" | CO | [grounded] "regional logistics, 800 employees" — the JD | This pack has no researched facts about Atlas Freight, so say only what you have read yourself. The JD gives you this much: regional logistics, 800 employees, four sites, twelve supervisors. Before the interview, read their own site, and say what you read and what you would ask. Do not state a fact you cannot point to | Casual company questions are scored, and with no research the safe version is what you can source. CO because it scores homework depth |

### P. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | VAL | [generic] | Offer seam principles rather than claiming to know the seam: who owns the customer outcome, who owns the resource, how a disagreement gets decided and by when. Reciprocity framing: what you would bring them, then what you would need. Makes no claim about your past | Applies only if the round is with a peer, so it is low weight. VAL because it scores disagreement style with equals |
| P2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams, with a named piece that was yours, a named piece that was theirs, and credit that was shared out loud. If no such time comes to mind, say so plainly, then say how you would handle it | The credit probe is the peer's version of C2's attribution question. VAL because it scores behavior with equals |

### V. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: choose a time with a named stake, a moment you did not soften it, and a relationship intact at the end, using "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard values-round stem. Included because the pack cannot rule out a behavioral round and no source here documents one. VAL because it scores behavior, not content |
| V2 | "Tell me about a time you had to hold one of your supervisors to a standard they did not like." | VAL | [generic] | Selection scaffold: pick a time with a specific standard, a specific conversation, and what changed afterward. Say what you actually did and what you did not. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The JD's leadership line (F3) as a behavioral prompt. VAL because it scores how you act with direct reports |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four sites today, and which site is furthest from where you want it?" | Uses the JD's own measure and shows you think in it. The answer tells you what the first ninety days are |
| R2 | "Tell me about the twelve supervisors: how experienced is the group, and what would you want me to do with them in the first month?" | Turns the scope gap in F3 into a forward conversation and shows you are thinking about the team, not only the role |
| R3 | "What does reporting look like today, and where is the biggest gap?" | Lets you hear the real tool state without bluffing on F5, and shows you ask before you build |
| R4 | "How will you judge whether this hire is working at six months?" | Gets the real success measures out in the open |
| R5 | "What has changed in the network over the past year that shapes this role?" | Fills the gap left by the missing company research, and signals you want current context |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question, useful whoever the interviewer turns out to be |

## Prohibited claims

What this pack will not coach, with the basis and the honest form. The banks above were written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says a shift manager and a site surge plan. The slots stay inside the shift and the plan |
| Led a team of twelve supervisors | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors". The slots ask only how you lead the supervisors you have |
| Improved on-time performance or lowered cost per shipment | Inflated form of F2 | F2's quote at its own scope. The slot asks only what else you tracked |
| Has 5+ years of operations leadership | Inflated form of F6 | F6's quote at its own scope. The slot asks only how the years break down |
| Built reporting or dashboards in Power BI | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Built operational reports in Excel | Inflated form of F4 | "solid Excel" at its own scope. The slot asks what was built, with the second branch allowing that nothing was |
| Used Lean or Six Sigma methods to get the mis-pick result | Inflated form of F7 and F2 | F7's quote at its own scope; your material does not connect the certification to the redesign |
| The surge plan met service or cost targets | Inflated form of F1's surge-plan quote | The quote at its own scope; the slot asks only which parts of the plan were yours |

## Sources

Provided documents: the JD text and the background you wrote in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Search refused. Would have moved: a values cheat sheet if a values round were documented, and VAL wording by the company's own value names |
| 2. Atlas Freight interview process, operations manager | unavailable | Search refused. Would have moved: persona weights by named rounds, and the assumed hiring-manager round |
| 3. Atlas Freight strategy and recent news | unavailable | Search refused. Would have moved: A5 and E2, and a grounding brief |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent, all refused: "Atlas Freight regional logistics company values"; "Atlas Freight interview process operations manager"; "Atlas Freight regional logistics strategy news".

## Upgrade menu

- Who you are meeting and the round type (hiring manager, peer, senior, HR, panel) → persona weights recomputed from the real round, not the hiring-manager assumption
- The interviewer's name → an interviewer read and one reverse question tied to their own path
- The recruiter's prep notes (focus areas, any case, presentation or take-home) → coverage for what was announced, and a build section for any deliverable
- Search access for Atlas Freight → its values, loop structure and recent news; CO questions A5 and E2 would become grounded, and a values cheat sheet if a values round is documented. A deeper pass of 6 more searches and 2 more fetches is available after that, only if you want it
- Your own answers to the slots in F1, F2, F3, F4, F6 and F7, written outside any drill → those rows get your sentences as evidence and the guidance regenerates from them
- The before-and-after mis-pick report, or the pick-path layout drawing → F2 could move from medium confidence toward high
- A report or tracker you built in Excel → F4 could move from low confidence
- Hours you have available before the interview → a prioritized prep schedule
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and the objections already found, folded into the rows above
