I'll read the reference files first.
I've finished the research (4 searches, 2 page fetches) and I'm now writing the prep pack to a file.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-canned-2ce36441/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for the format Saltmarsh's careers page describes. That is a recruiter call, then one 60-minute session with the hiring manager: a live-incident tabletop on a simulated outage, then a values conversation, with no take-home. I assumed Tobias is that hiring manager.

The pack has 19 questions across six interviewer styles. It also has a fit map of your background against the JD, notes on Tobias's public footprint, a values cheat sheet, reverse questions, and a list of claims the pack won't coach. The question I'd rehearse most is C1: how to answer "what's your experience running events for a monetized game?" Saltmarsh's Project Larkspur announcement moves its titles to a season-pass model from February 2027, so your "no in-app purchases" gap is the likeliest objection.

Say the word and I'll play Tobias on C1, then run the tabletop (A1).
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter say anything about the Outage Hour's scenario or focus, and is Tobias definitely the person running it? The answer would tighten the tabletop questions and the persona weights.
Do you want a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) for a strategy brief and a closer read of Tobias's GDC talk?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: the hiring manager. Saltmarsh's careers page describes one 60-minute session with the hiring manager, and you named Tobias as your interviewer.
**Round:** the 60-minute interview on Friday. The careers page calls it the Outage Hour: a live-incident tabletop on a simulated outage during a live event, then a values conversation. It also says there is no take-home.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: **VAL** is values alignment with Saltmarsh's published values. **EXP** is a deep-dive on your own experience. **JD** is a question scoring a stated JD requirement. **CO** is company and strategy knowledge. **CASE** is a live problem set in the role.
- Answer guidance is scaffolding, not a script. Say things in your own words, and say only what you actually did.
- An answer slot is an instruction for the interview, not a question for you now. It tells you where to say what was truly yours, or to say plainly that it was not.
- Highest-ROI prep in this pack: **C1**. It is the objection most likely to land on your material, and it gets the deepest rehearsal. **A1** is second, because the tabletop is the format of the hour.
- The fit snapshot shows where your material is strongest (F3, F6, F7, F8) and where it is silent or states a gap (F4, F9, F10). The pack names those gaps rather than bridging them.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer at a puzzle-game studio and does not show whether that title was run as a live service. Words: "I was an associate producer at a puzzle-game studio for four years." Answer slot: the JD asks for years producing live-service games or apps, so expect a probe on what those years covered. If the title was run as a live service and your role covered it, say how in your own words; if it was not, or your role covered only part of it, say so plainly and stay with the years you had |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says the weekly content-drop calendar for your main title, one title, with nothing inspected behind it. Words: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on the scope of your calendar likely. Say which parts of that weekly calendar were yours to set, in your own words; if none were, or it was not yours, say so plainly and describe how you ran it |
| F3 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you ran it, weekly, for the main title, over the last two years |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this requirement either way. Answer slot: the JD names four teams, so expect a probe on who you worked with on an update. If you worked with any of them, say which and what your part was, in your own words; if none, or it was not you coordinating, say so plainly and describe what you would do in your first release cycle here |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the numbers, which is adjacent to this line and short of it. Words: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on who chose the figures that were presented. Say which were yours to choose, in your own words; if someone else chose them, say so plainly and stay with the presenting |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on how the numbers were counted. Lead with the quote's own terms: monthly, retention, to the studio head. D1 rehearses the probe |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote the checklist, and your QA team still uses it. Words: "I wrote the release checklist our QA team still uses." Nothing is added to it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote is a written artifact other people use, which reaches the requirement in other terms. Words: "I wrote the release checklist our QA team still uses." Nothing is added to it |
| F9 | In-app purchase experience. Not a JD line; added here because you raised it | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The pack's observation: Saltmarsh's Project Larkspur announcement (see Sources) moves two titles to a season-pass model from February 2027, so this can come up although the JD does not name it |
| F10 | Leading a team. Not a JD line; added here because you raised it | "Never led a team" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." The JD asks for coordination across four teams (F4), not for leading them, and the plan for that is in C3 |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The tabletop: a simulated outage during a live event, then follow-on decisions | High. The careers page says the session opens with a live-incident tabletop, so a live problem is documented rather than guessed | Clarify before structuring, then objective, who decides, what players are told. Think aloud and name one premise you are challenging |
| B. Values / Behavioral | The second half of the hour, mapped to the three published values | High. The careers page says a values conversation is part of the same session, so one is documented | Map each value to a story only where your quoted sentences carry one; otherwise pick by the criteria in the bank and use the honest branch |
| C. Skeptic | Quiet, persistent probing of the gaps: in-app purchases, no team led, two titles | High. F9 and F10 are stated gaps, and the Larkspur announcement makes monetization current. This is the likeliest objection in the hour | Rehearse C1 until it is boring. Acknowledge the gap in one plain sentence, hold what your quotes carry, then give the ramp plan as a plan |
| D. Data-Driven Prober | Line-by-line probing of your own claims: the retention numbers, the checklist, the calendar | Medium. The interviewer's public talk is about patch notes matching what shipped, and he previously led QA, so precision about your own claims is a likely lens | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| E. Pressure / Stress | A tabletop pace with interruptions, or a blunt "why you" challenge | Medium-low. A tabletop can carry time pressure, but no source describes a stress style | Pause, restate, hold the position through two follow-ups, concede specifically |
| F. Conversational | The opener ("walk me through the journey") and a casual strategy question | Medium-low. Every hour opens somewhere; this is the safe-feeling part that is still scored | A 90-second arc built only from your own sentences |

Peer Evaluator is dropped: the careers page describes one session with the hiring manager, so no peer round is documented. If Tobias is not the hiring manager the page describes, say so and the weights change.

## Reading the interviewer

| Public fact | Source | What it means for the hour | Provenance |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games | GDC 2026 talk listing (Sources, search 4) | He owns the function you would join, so expect answers to be judged by someone who runs the calendar daily | [grounded] |
| Previously a QA lead at a console studio | Same listing | Release checklists and QA hand-offs are native territory for him, so expect close questions on D2 | [grounded] |
| GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | Same listing | Precision about your own claims is the theme he cares about publicly. It echoes the published value "Ship the Patch Not the Promise" | [grounded] |

Mirror opportunity, shared vocabulary: his QA background and your F7 evidence. The sentence is yours: "I wrote the release checklist our QA team still uses." Say it as stated and let him ask. It is public professional footprint only, and nothing here assumes a shared personal background.

## Question banks

### A. Case / Strategist (the Outage Hour tabletop), 5 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's mid-event and players report the event reward isn't arriving; support tickets are climbing. You're the producer on call. Walk me through your first fifteen minutes." | CASE | [generic] | Structure it aloud. Clarify first: is it confirmed or only reported, one title or both, since when, can the event be paused. Then the objective (stop the damage to players, keep them informed), who you pull in from the JD's own list of design, art, engineering and community, who decides, and what is recorded for the post-event review. The question needs no claim about your past, so the guidance makes none | The careers page describes a live-incident tabletop on a simulated outage, so some version of this is the likeliest question in the hour. CASE because it scores structure, with the coordination requirement of F4 inside it |
| A2 | "Project Larkspur puts your titles on one shared events calendar from February 2027. What do you need to know before you lay out the first quarter?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify before structuring: how events run today in each title, season length under the season-pass model, lead times each discipline needs, QA windows, which dates are fixed. Then the objective, principles for placing events, and what you would check after the first quarter. Your own experience only at the quote's scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: say which parts of that calendar were yours to set, in your own words; if none were, or it was not yours, say so plainly and describe how you ran it | The Larkspur announcement (Sources) makes the calendar a live strategy question. JD because it scores the calendar line (F2, F3), CASE in delivery, CO in its premise. F2 is where the calendar claim is thinnest |
| A3 | "QA flags a blocker the day before a scheduled drop. Ship, slip, or ship less? Walk me through the call." | JD | [grounded] "Wrote the release checklist our QA team still uses" | Structure the call: what exactly is blocked and how it touches players, the options (ship less, slip, fix forward) and what each costs, who decides and who must be told, what players are told (only what is built). Your own experience only at the quote: "I wrote the release checklist our QA team still uses." Answer slot: say which parts of the checklist were yours to write, and what QA had a hand in, in your own words; if QA wrote most of it, or you did not work with them on it, say so plainly | Scores the release-checklist-with-QA line (F7) as a live decision. The interviewer's QA background makes the ship-or-slip framing likely |
| A4 | "The event is over. How would you run the review, and which one or two numbers would you lead with?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Structure: what the review is for (what was promised against what shipped, what players did, what to change), which one or two numbers you would lead with and what decision each informs, who attends, what is written down. Name the assumption you would defend least behind whichever number you lead with, before the interviewer does. Your own experience only at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: say which of those figures were yours to choose, in your own words; if someone else chose them, or there was no review, say so plainly and stay with the presenting | The JD makes the post-event review and its KPIs (F5, F6) a headline responsibility. JD content, CASE delivery |
| A5 | "Write me the first player notice for that outage. Three sentences, now." | JD | [generic] | Say only what is confirmed, what players should do, and when the next update comes. Do not promise a fix time you cannot confirm; it echoes the published value "Ship the Patch Not the Promise". The question needs no claim about your past, so the guidance makes none | The JD requires clear written communication (F8), and a tabletop is the natural place to score it. JD because it scores that line live |

### B. Values / Behavioral (the second half of the hour), 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] | Selection scaffold for "Players Before Plans". Pick a time with a named stake: a date you held to or moved, who was affected, what you decided, and what you would do again. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme is the published value's own wording, so the question is likely whichever stories you bring. VAL because it scores past behavior against that value. Your material carries no disagreement, so this is a scaffold, not a story |
| B2 | "When have you had to correct something you had told people was coming?" | VAL | [grounded] | Selection scaffold for "Ship the Patch Not the Promise". Pick a time with a named stake: what was said, what changed, how and when you corrected it, and what you changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The interviewer's public talk is about patch notes matching what shipped, so this value gets the hardest push. Your material carries no correction, so this is a scaffold |
| B3 | "When has a release taught you something that changed how you work?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F7: the checklist you wrote, and that your QA team still uses it, which are the beats the quote states; tell them in your own words. Answer slot: the value "Leave the Build Greener" speaks of leaving the checklist better after a release. If a release led to a change in the checklist, say what changed and what part was yours; if it did not, or the change was not yours, say so plainly and stay with the checklist you wrote | F7 is your one sentence that touches this value. The probe is on what improved, which is where the quote stops |
| B4 | "Tell me about a time you delivered an unwelcome number to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F6: you presented the numbers, monthly, to the studio head, which are the beats the quote states. Answer slot: if any month's numbers were unwelcome, say what you said and what happened, in your own words; if none were, or you did not choose what was shown, say so plainly and stay with presenting them monthly | A stock behavioral prompt that fits the "Players Before Plans" value, because the numbers speak for the players. A hard truth that actually landed is the bar; the material does not show one, so the slot leaves room for none |

### C. Skeptic (highest weight on your gaps), 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our titles are moving to a season pass. What's your experience running events for a monetized game?" | JD | [grounded] "never worked on a game with in-app purchases" "I ran the weekly content-drop calendar for our main title for the last two years" | **Highest-ROI prep in the pack.** Hold-then-concede. First, one plain sentence: "I haven't worked on a game with in-app purchases." Then hold what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Then the ramp plan, said as a plan and never as a past: who you would ask to walk you through how the season-pass numbers are counted, what you would read before the first event, which decisions you would take to the owner of monetization rather than make alone. Follow-up 1, likely: "What would you do in your first thirty days?" Answer with the plan. Follow-up 2: "That's a real gap for these titles." Do not argue it and do not add a substitute experience; concede specifically what you would lean on others for. Follow-up 3: "What's the first thing you'd get wrong?" Name what you do not yet know and how you would catch it | F9 is a stated gap, and the Larkspur announcement (Sources) makes it current. JD because it scores a gap against the role; it is the most predictable objection in the hour |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team" | Pick one honestly and say what you would do about it first, as a plan. Answer slot: the pack's reading is that your material carries least for the four-team coordination line (F4) and for owning the review and its KPIs (F5); say which you would pick, in your own words, and if it is something else, say that. If the probe turns to leading people: "I haven't led a team." | A standard Skeptic stem, and it will land on F4, F5 or F9. The honest pick is the point, and the answer should be ready before the question |
| C3 | "You haven't led a team, and this role coordinates design, art, engineering and community on every update. Why would they follow your calendar?" | JD | [grounded] "Never led a team" "I ran the weekly content-drop calendar for our main title for the last two years" | Hold-then-concede. First: "I haven't led a team." Hold what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Then the method as a plan: the calendar visible to everyone, a named decision-owner per item, dates agreed before they are announced. Answer slot: if on any update you worked with people from those four disciplines, say who and what your part was, in your own words; if not, say so plainly. Concede that you would earn trust over the first release cycle rather than assume it | F10 and F4 together. The JD asks for coordination, not leadership, and the question tests whether you can say the difference without sounding defensive |

### D. Data-Driven Prober, 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F6: you presented the numbers, monthly, to the studio head. Defend-the-number slots, each in your own words: how it was counted, what it was sensitive to, the assumption you would defend least (name it before he does), and which part was yours. If you do not know how it was counted, say so plainly. Never describe a method you did not use | A headline metric on the material is a magnet for probers. EXP because it tests attribution and the weakest-assumption move |
| D2 | "Walk me through the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F7: you wrote it, and your QA team still uses it, which are the beats the quote states. Answer slot: say which parts of the checklist were yours, and what QA had a hand in, in your own words; if it was written to a template or QA wrote parts, say so plainly | The interviewer previously led QA (Reading the interviewer), so this is a probe he can judge closely. EXP because it tests what was actually yours |
| D3 | "Take me through a typical week of the content-drop calendar you ran." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F2 and F3: weekly, the main title, the last two years, told in your own words. Answer slot: say which parts of a week's calendar were yours to set; if the dates or contents were set by someone else, say so plainly and describe how you kept the calendar | The calendar is the claim the rest of the hour leans on. EXP because the probe is how much of it was yours |

### E. Pressure / Stress, 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run events on a monetized live game?" | JD | [grounded] "never worked on a game with in-app purchases" "I ran the weekly content-drop calendar for our main title for the last two years" | Hold-then-concede in sixty seconds. Concede the gap plainly: "I haven't worked on a game with in-app purchases." Hold what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Then your plan for closing the gap. Do not claim you are better than the other candidate; hold the position through two follow-ups by returning to the quote | F9 in its sharpest form. JD because it scores the gap, with a pressure delivery |
| E2 | "That calendar you ran. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | The quote carries "I ran", at its own scope. Answer slot: say which parts of the calendar were yours alone and which were shared or set by others, in your own words; if others set parts, say so plainly. Hold through two follow-ups by returning to the quote, never by adding to it | The stock attribution probe, aimed at F2 and F3. EXP because it scores attribution honesty |

### F. Conversational / Rapport Builder, 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you get here, and why Saltmarsh, why now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years" "Wrote the release checklist our QA team still uses" "Presented the monthly retention numbers to the studio head" | A 90-second arc with one clause per sentence you wrote: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the main title over the last two years, the release checklist your QA team still uses, the monthly retention numbers to the studio head. Answer slot: say why Saltmarsh and why now in your own words; if nothing in the values page or the Larkspur announcement drew you, say what did | The opener is scored for economy. F1 through F6 supply the arc, and the "why here" part is yours to say |
| F2 | "What do you make of Project Larkspur?" | CO | [grounded] | Say what the announcement states: Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027, and one live-ops group replaces per-title event teams. Then one view with its limit, and say where you do not know. Read the full announcement before Friday: this pack read only its search snippet | The strategy question most candidates cannot touch. CO because it scores whether you can think at the company's altitude |

## Values cheat sheet

Published values, from the careers-side values page the pack fetched.

| Value | Working meaning, paraphrased | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold, B1: pick a time with a named stake, a date held or moved, who was affected, what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold, B2: pick a time something you had said was coming changed, and how you corrected it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F7: "Wrote the release checklist our QA team still uses". The beats are the checklist you wrote and that QA still uses it; B3 holds the slot on what improved |

## Reverse questions

| # | Question | Why it lands | Basis |
|---|---|---|---|
| R1 | "You moved from leading QA to running live ops. What did the QA years teach you about how a live team should run?" | Ties to his own path and invites a peer conversation rather than an interrogation | The talk listing's bio (Reading the interviewer) |
| R2 | "Your GDC talk argues a live team is judged by how often its patch notes describe what shipped. How does this team measure that today?" | Shows you engaged with his stated argument, and asks for the real measure | The talk listing (Reading the interviewer) |
| R3 | "Project Larkspur retires per-title event teams in favour of one live-ops group. How does this role sit in that group, and does it cover the two titles in the posting?" | Tests the strategy reading from F2 and finds out what you would actually own | The Larkspur announcement (Sources) |
| R4 | "What would success look like at ninety days, and what would you want to see in the first post-event review I would own?" | Turns the review and KPI line (F5) into a shared definition of done | The JD |
| R5 | "With a season pass coming, who would walk a new producer through how the monetization numbers are read?" | Turns the F9 gap into a ramp plan, and tells you whether the team expects to teach it | The Larkspur announcement and F9 |
| R6 | "What does the strongest candidate for this role usually do differently after the Outage Hour?" | Signals you are thinking past the interview, and may surface what the hour is really scoring | Generic |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "3+ years producing live-service games or apps" | C2, D3, F1 |
| "Plan and run the live-events calendar for two of our mobile titles" | A2, D3, E2 |
| "coordinate design, art, engineering and community teams on each update" | A1, C3 |
| "own the post-event review and the KPIs it reports" | A4, D1 |
| "manage the release checklist with QA" | A3, D2, B3 |
| "experience running a content calendar" | A2, D3, E2 |
| "comfortable with player-retention metrics" | A4, D1, B4 |
| "clear written communication" | A5 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked on a game with in-app purchases, or has monetization experience | Negative the candidate stated, F9 | "I haven't worked on a game with in-app purchases." No slot |
| Has led a team | Negative the candidate stated, F10 | "I haven't led a team." No slot |
| Ran a live-events calendar for two titles | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says the weekly content-drop calendar for one main title. The slot stays inside that calendar |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says you presented the numbers. The slot stays inside the presenting |
| Managed the release checklist with QA | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says you wrote it and QA still uses it. The slot stays inside the writing |

## Sources

Provided: the JD text and your background message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches sent:

- "Saltmarsh Games values": returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer": returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games strategy news mobile": returned https://saltmarshgames.com/news/project-larkspur (search snippet only; the page itself was not fetched)
- "Tobias Wrenfield Saltmarsh Games": returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; the page itself was not fetched)

Fetches sent: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both returned.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and bank B: the three value names and their wording |
| 2. `Saltmarsh Games interview process live operations producer` | yes | The loop: one 60-minute hiring-manager session with a tabletop then a values conversation, no take-home. It sets persona weights and bank A |
| 3. `Saltmarsh Games strategy news mobile` | yes | A2, F2 and R3 rest on the Project Larkspur snippet; the full announcement was not read |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer, R1 and R2, from the talk listing snippet |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The recruiter's note on the Outage Hour (any named scenario, tools or focus) → the tabletop bank (A1 to A5) replaces its `[generic]` scenarios with the real one
- Confirmation that Tobias is the hiring manager the careers page describes → persona weights stop resting on an assumption
- Answers to the slots in F1, F2, F4 and F5 (what the puzzle title's live operation covered, which parts of the calendar you set, who you worked with on an update, who chose the retention figures) → those rows gain quoted evidence and the matching banks gain stories
- A copy of the content calendar or the release checklist you mention → F2, F3 and F7 move from medium to high confidence
- The full text of the Project Larkspur announcement → A2, F2 and R3 move from snippet-grounded to fully grounded
- A deeper research pass, if you accept it in the message that presents this pack → a strategy brief section and a deeper read of Tobias's talk
- A `tuesday-dossier.md` from a job-underwriter pass → the highest-ROI objection would come from verified evidence rather than inference, and weak areas would carry stated strategy
