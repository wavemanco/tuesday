I'll read the reference files first.
I'm checking the saved pack for formatting slips (stray brackets, question marks inside answer slots), then I'll present it.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-canned-c04496a3/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 19 questions across six personas, built for the format Saltmarsh's interviewing page describes: a recruiter call, then one 60-minute "Outage Hour" with the hiring manager. That hour is a live-incident tabletop on a simulated outage, followed by a values conversation. I assumed Tobias is that hiring manager.

- **Highest-ROI prep:** question C1. It is the in-app-purchases gap, which now matters because Saltmarsh's September announcement (Project Larkspur) moves both titles to a season pass. The answer is a plain "I haven't worked on a game with in-app purchases", then what you do have, then a plan.
- **Your strongest lines:** your calendar, your release checklist and your monthly retention presentations all map to the JD. Tobias previously led QA, so the checklist is your best shared vocabulary with him.
- **Gaps the pack won't cover for you:** leading a team and purchase experience are stated gaps, so the pack coaches plain acknowledgments for them. Where your material is silent, such as which disciplines you coordinated on each drop, the pack leaves answer slots for you to fill from your own experience.
- **Larkspur and the talk:** I saw only search snippets of the Larkspur announcement and Tobias's GDC talk. Read both in full before Friday.

Say the word and I'll play Tobias in the tabletop on A1, then the Skeptic on C1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias the hiring manager you would report to? If he isn't, the persona weights change.
2. Did your recruiter say anything about the Outage Hour scenario, such as which title, who else is in the room, or whether you present or discuss?
3. Do you want a deeper research pass? It is up to 6 more searches and 2 more fetches, takes several more minutes, and would add a company-strategy brief.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager (basis in the persona table and Sources). Friday, 60 minutes.
**Built on that assumption.** If Tobias is not your hiring manager, the persona weights change; the upgrade menu says how.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Every question carries both, so you can see coverage at a glance. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your background claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its current strategy |
| CASE | Structure and reasoning on a live problem from the role |

Bank letters skip F so that fit-snapshot rows (F1 to F9) are never confused with questions. An answer slot is an instruction for the interview, not a question for you now: answer it from your own experience, or say plainly the practice was not yours.

## Prep triage

Interview is Friday; today and Thursday are the prep window. Do these in order.

| Order | Do | Where |
|---|---|---|
| 1 | Rehearse the in-person answer to the objection most likely to be asked, out loud, until it is boring: plain acknowledgment, what your material does carry, a plan | C1 |
| 2 | Run the tabletop twice aloud, saying your framework before you use it, including the two sentences you would post to players | A1, A2 |
| 3 | For each of the three published values, settle one story or the honest branch | B1 to B4 |
| 4 | Read the Project Larkspur announcement in full and Tobias's GDC talk (I saw only search snippets of each) | A3, reverse questions |
| 5 | Say the sixty-second answer on leading without having led | C2, E2 |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, over two years; the JD says live events and two titles, and the words stay at your scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on running more than one title likely. If you ever ran a calendar across more than one title, or any drop was a time-limited event, say which and how, in your own words; if not, say so plainly and stay with the main title |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams you worked with on a drop. Answer slot: the JD names four disciplines, so expect a probe on each. Say which of them you worked with on the weekly drops and how you got each to the date, in your own words; if you worked with fewer, or the calendar did not require that, say so plainly and say how you would approach the others |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | The quote says you presented the numbers monthly to the studio head, and nothing in your material shows who defined them or whether a review followed any event. Answer slot: if you produced or defined any of those numbers, or wrote a review after a drop, say what it covered; if you presented numbers someone else produced, or no such review existed, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: you wrote it, and QA still uses it. Your material says wrote, not ran each release against it, and the words stay there |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years and the studio are stated; whether the title was a live-service game is not. Answer slot: the JD says live-service, so expect that word to be tested. If the puzzle game was live-service, say so in the studio's own terms; if it was not, say so plainly and describe the weekly calendar as it ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it. Lead with the quote in its own terms: weekly, content drops, your main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but no figure or method is stated, so expect a probe on how the numbers were counted (D1). Lead with the quote in its own terms: monthly, retention numbers, the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | discovery | A checklist is writing, and the quote does not show whether it was clear or what else you wrote. Answer slot: if you wrote anything else others relied on, name it and say what it was for; if the checklist is the main piece, say so plainly and point to it |
| F9 | Operating events inside a season-pass model: not in the JD; derived from the September 2026 Project Larkspur announcement (search result only, see Sources) and the pack's reading that a season pass is tied to purchases | "never worked on a game with in-app purchases" — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The link from season pass to purchases is this pack's derivation; the JD does not mention purchases |

## Reading the interviewer

Public professional footprint only.

| Item | What the public footprint says | Provenance | What it means for you |
|---|---|---|---|
| Role | Head of Live Operations at Saltmarsh Games | [grounded] | He owns the function you would join; expect questions in his own vocabulary |
| Prior path | Previously a QA lead at a console studio | [grounded] | Release and QA vocabulary is native to him; lead with F4 in its own terms |
| Published talk | GDC 2026, "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | [grounded] | Expect the theme that what you announce must match what is built; B2, A2 and the reverse questions use it |
| Mirror opportunity | Release and QA vocabulary: his QA background and your row F4 | [inferred] | Say it in your own words: "Wrote the release checklist our QA team still uses." That is shared vocabulary, not a shared career path, and it is not offered as one |

Do not build on shared background of any kind other than professional vocabulary. I saw only a search snippet of the talk; read or watch it before Friday.

## Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop: a simulated outage during a live event | Highest. The Saltmarsh interviewing page (Sources 2) describes a live-incident tabletop on a simulated outage during a live event as the first part of the hour; the hiring-manager prior also leans Case. Five questions | Say your framework aloud, clarify before structuring, name who decides what, and write the first two sentences you would tell players. A1, A2, A5 |
| Values / Behavioral | The second part of the hour: a values conversation | Highest. The same page describes a values conversation after the tabletop, and the values page (Sources 1) names three values, so Values is documented, not assumed. Four questions | One story or one honest branch per published value, with "we" for context and "I" for contribution. B1 to B4 |
| Skeptic | Probing the gaps: purchases, leading without having led, why live ops | Mid. The hiring-manager prior includes the Skeptic, and you have stated two negatives of your own (F9 and the gap behind C2). Three questions | Rehearse C1 until it is boring; bridge only from your stated material; say limits plainly and add a plan |
| Data-Driven Prober | Line-by-line on the retention numbers and the post-event review | Low-mid. JD names retention metrics and the post-event KPIs; no interviewer signal suggests heavy probing. Two questions | Say what you can and cannot say about how the numbers were counted, and say plainly where you do not know. D1, D2 |
| Pressure | Time-boxed and attribution probes inside the tabletop or after it | Low-mid. A simulated outage implies time pressure, but the page does not say the interviewer interrupts, so this is inferred from the format. Two questions | Pause, restate, hold the position the quote carries through two follow-ups, concede specifically. E1, E2 |
| Conversational | The opening: "walk me through your background" | Low-mid. Every interview opens somewhere; the page documents no separate rapport round. Three questions | A prepared 90-second arc from your own sentences; treat casual topics as scored. G1 to G3 |
| Peer Evaluator | Not applicable | Not applicable: the loop page documents a hiring-manager interview, and no peer is named, so no bank is written | If a peer turns out to be in the room, tell me and the pack reweights |

## Question banks

### A. Case / Strategist (highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a live event. A bug means players are not receiving the event reward and support tickets are climbing, with a scheduled push in fifteen minutes. Walk me through your first moves." | CASE | [generic] | Say your framework first, then run it. What you need to know: who is affected, what players have been told, whether QA can reproduce it, whether a hotfix or a pause is possible, who is on call. Objective: players first, then the event's integrity. Options and what each costs. Then write the first two sentences you would post to players: only what is confirmed, and when you will update them. Name the one decision you cannot make alone and who makes it. The question needs no claim about your past, so the guidance makes none | The page describing the loop (Sources 2) names a live-incident tabletop as the first half of the hour, so this is the most certain question type; CASE because it is live reasoning. The player-notice drafting also tests F8's requirement in the same breath |
| A2 | "Same event, last evening before it ends. Players lost access for three hours. Community wants to announce an extension now; engineering has no fix estimate. What do you do." | CASE | [generic] | Separate what is known from what is hoped. Propose a holding statement that says only what is confirmed and names the time of the next update. Make the extension decision depend on a fix QA has verified, and name who owns that decision. Close with what you would record for the post-event review. The question needs no claim about your past, so the guidance makes none | Tests the announce-only-what-is-built theme (the values page, Sources 1, and the interviewer's published talk, Sources 4); CASE because the decision is live. Generic because the scenario shape is not from a source |
| A3 | "In September we announced that Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027. If you were running that calendar, what would you need to know first, and what would you protect." | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first: what stays title-specific and what is shared, what the season pass changes about event timing, and who sits in the single live-ops group. Then objective, segments of players, approach to one shared calendar with a conflict rule for when both titles want a date, metrics, risks. Challenge one premise respectfully, for example whether both titles' players want the same cadence. Start from what you have, in your words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the question raises a calendar shared across titles. If any of your calendar was shared with, or affected by, another title, say how; if not, say so plainly and reason from the principles above | The announcement (Sources 3, search snippet only) is the current strategy item, which F1's two-title requirement runs straight into, so expect it. CO because it is company altitude; CASE in delivery. Verify the announcement text before Friday |
| A4 | "Day-7 retention for players who joined during last weekend's event is below the previous event's cohort. Diagnose it." | JD | [generic] | Clarify definitions and comparability first: same cohort definition, same acquisition mix and platform split, same app version, whether an outage fell inside the window. Check the data before the hypotheses. Segment, rank hypotheses, say who you would ask in analytics, and say what you would report with what caveat. Name the weakest assumption in your own diagnosis before they do. The question needs no claim about your past, so the guidance makes none | F7 and F3 are the rows this tests; JD because it scores the retention and KPI requirements, CASE in delivery. Generic because the metric is a pattern, not from a source |
| A5 | "Design wants Tuesday's event live. QA has not signed off the build and art needs two more days. You own the calendar and the release checklist with QA. What do you do." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: what is actually blocked, the checklist as the gate, the options (slip, cut scope, ship in parts), who decides, what community is told and when. Players before the date, and nothing announced that is not built. The checklist you can speak to is the one in your words: "Wrote the release checklist our QA team still uses." Answer slot: if you ran releases against that checklist alongside QA, say how a blocked release was handled; if you wrote it and others ran releases against it, or no release was ever blocked, say so plainly and describe what you would do | The JD's calendar, coordination and QA-checklist requirements meet here (F1, F2, F4, F6); JD primary because it scores the stated requirements, CASE in delivery |

### B. Values / Behavioral (highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold for the published value Players Before Plans: pick a time a date you owned collided with what players needed. It needs a named stake, the decision you made at the time and what you did about the date. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years.", or how you would handle it with players first | F1 is the nearest evidence but carries no disagreement, so it is a scaffold; VAL because it scores a published value, named in the values page (Sources 1) |
| B2 | "Tell me about a time you announced something and had to be sure it was already built." | VAL | [grounded] | Selection scaffold for the published value Ship the Patch Not the Promise: pick a time what you said to players or colleagues was checked against what was actually in the build. It needs what was said, how you checked, and what changed because of the check. If no such time comes to mind, say so plainly, then describe how you would handle it: confirm with QA that it is built before the words go out. The question needs no claim about your past, so the guidance makes none | No quoted sentence carries an announcement, so this is a scaffold; VAL for the second published value and the interviewer's own published theme (Sources 4) |
| B3 | "Tell me about a time you left a release process or checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the checklist, and QA still uses it, which are the beats the quote states; tell them in your own words. Answer slot: if the checklist changed after a release, say what changed and whose call it was; if it did not, or the changes were not yours, say so plainly and stay with the checklist as you wrote it | The third published value, Leave the Build Greener, names the checklist; F4 is the only row that carries one |
| B4 | "Tell me about a time you told someone senior something they did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Beats the quote states: the numbers were monthly and the audience was the studio head. Answer slot: if any month's numbers were unwelcome, say what you said and what followed, in your own words; if none were, or you only presented numbers, say so plainly and describe how you present a result that disappoints | A standard values stem from the persona model; F3 is the nearest row and carries no unwelcome message, so the ending is not supplied |

### C. Skeptic (mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases, and our titles are moving to a season pass. How does that change how you'd run a calendar here." | JD | [inferred] "never worked on a game with in-app purchases" ; "I ran the weekly content-drop calendar for our main title for the last two years." ; "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Hold, then concede, in three levels. Level one, plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what your material does carry, at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." and "Presented the monthly retention numbers to the studio head." Do not offer retention as a substitute for purchase metrics: your material shows no revenue or purchase numbers, and saying so first is the limit named before it is asked. Level two, the follow-up "isn't that a big gap": concede it is a real gap, in one specific sentence, and return to the calendar. Level three, "what would you do in week one": a plan, not a past: ask who owns the purchase side, read the existing post-event reviews for how events relate to purchases, and not schedule a purchase-linked event until you understand it. Never fold on the calendar sentence just to restore harmony | F9 is the widest gap against the strategy the company has announced; it is stated by you, so the Question may presuppose it, and the season-pass premise is the announcement's (Sources 3). JD because it scores the role as it will be; Skeptic delivery |
| C2 | "The JD has you coordinating design, art, engineering and community on every update. You haven't led a team. How do you get an engineer to move for your calendar." | JD | [grounded] "Never led a team" ; "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first: "I haven't led a team." Then the point the quote carries: you ran the weekly calendar. Answer slot: if any weekly drop required getting design, art, engineering or community to your date, say which and how, in your own words; if the calendar ran without that, or it was not yours to do, say so plainly and describe what you would do. Principles you can offer as a plan, not a past: one shared source of truth for dates, the release checklist as the common gate, and raising a risk early to the person who owns it | F2 is a discovery gap and your stated negative makes the Question lawful; JD because it scores the coordination requirement |
| C3 | "Why live ops, why Saltmarsh, and why now." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Four beats, in your words: where you have been ("4 years as an associate producer at a puzzle-game studio."), what you want next, why this company (one of the three published values and one thing you read), what you would bring (a sentence from your quotes at its scope). Answer slot: your material does not say why you want this role; say it plainly in your own words, because the pack will not supply a motive | The Skeptic's motivation probe; EXP because it tests whether the story hangs together. Nothing here supplies a reason you did not give |

### D. Data-Driven Prober (low-mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the retention numbers you presented to your studio head each month. Which metrics, and how were they counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Beats the quote states: monthly, retention numbers, the studio head. Answer slot: the JD asks you to own the KPIs a review reports, so expect these probes. Say which retention measures, how each was counted, which assumption behind them you would defend least, and which part was yours; if you presented numbers someone else produced or defined, say so plainly and say what you did with them | F7 is the row a prober checks first. EXP because it tests attribution; the figure itself is not stated, so the slots are the defend-the-number ones only |
| D2 | "What would a post-event review from you contain, and how do you separate what an event did from what else changed that week." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure it from principle: what you set out to change and the measure it was judged on, what happened, what else moved in the same window, what you would do differently, what you would write down for the checklist. Name the weakest assumption in your own method. Answer slot: if you wrote reviews after drops, say what they covered; if you did not, or the monthly presentation was the closest thing, say so plainly and say what you would build first | The JD says you own the review and its KPIs (F3); JD because it scores that requirement |

### E. Pressure (low-mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You say you ran that calendar. How much of it was actually you." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the position the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups by returning to the sentence, never by adding to it. Answer slot: if some of the dates or content were set by others, say which and say plainly what you decided; if you decided all of it, say that and stop. Concede specifically, once | Attribution is the standard pressure probe (F1); EXP because it tests what was yours |
| E2 | "Sixty seconds: why should we hire an associate producer who has not led a team into a role coordinating four disciplines." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." ; "Never led a team" ; "Wrote the release checklist our QA team still uses." | Sixty seconds, four beats. The fact: "4 years as an associate producer at a puzzle-game studio." The plain acknowledgment: "I haven't led a team." What your material carries: "Wrote the release checklist our QA team still uses." Then a ramp plan, said as a plan: learn each of the four disciplines' constraints in the first weeks and use the checklist as the shared gate. Do not claim you have coordinated the four | The time-boxed form of F2 and F5; JD because it scores the requirement and the seniority gap |

### G. Conversational (low-mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey so far." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." ; "I ran the weekly content-drop calendar for our main title for the last two years." ; "Wrote the release checklist our QA team still uses." ; "Presented the monthly retention numbers to the studio head." | A 90-second arc made of those four sentences in order, in your own words, at their own scope. Answer slot: end on why this role; your material does not say, so say it plainly in your own words | The opening is scored even when casual; F5, F6, F4 and F7 are the sentences it uses. EXP because it tests whether the background holds together |
| G2 | "What live games or apps do you follow, and what are they doing with events that you'd steal." | CO | [generic] | Selection scaffold: pick one live game or app, one thing its calendar does well, one thing it gets wrong, and tie one point to a published value. Playing Tidepool Tactics and Lantern Row before Friday gives you a live example. If no such game comes to mind, say so plainly and name the closest one you know well | A casual question about the role's craft, scored; CO because it tests homework on the company's own titles (named in Sources 3). Generic because it is a pattern |
| G3 | "What makes a written update clear, and what is a piece of your own writing you'd point me to." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Point to the checklist in its own terms: you wrote it, and QA still uses it. A clear update is one nobody needs to ask a follow-up about; say what you would check before sending one. Answer slot: if you wrote anything else others relied on, name it and say what it was for; if the checklist is the main piece, say so plainly | F8's requirement. JD because it scores the written-communication line |

### Requirement coverage

| JD requirement | Questions | JD-tagged |
|---|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, A5, E1, G1 | A5 |
| "coordinate design, art, engineering and community teams on each update" | C2, A5, E2 | C2 |
| "own the post-event review and the KPIs it reports" | D1, D2, A4, B4 | D2 |
| "manage the release checklist with QA" | A5, B3 | A5 |
| "3+ years producing live-service games or apps" | E2, G1, C3 | E2 |
| "experience running a content calendar" | A5, E1, G1 | A5 |
| "comfortable with player-retention metrics" | A4, D1 | A4 |
| "clear written communication" | G3, A1 | G3 |
| Season-pass and purchases context (F9) | C1, A3 | C1 |

No headline figure appears in your material, so there is no separate defend-the-number question beyond D1.

## Values cheat sheet

The three published values, by official name, from the values page (Sources 1). The loop page documents a values conversation as the second half of the hour (Sources 2).

| Value | Working meaning, paraphrased | Mapped story | 
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold on B1, ending in its honest branch. Nearest row F1: "I ran the weekly content-drop calendar for our main title for the last two years." — your message. It carries a calendar and no disagreement, so the pack does not supply one. If no such time comes to mind, say so plainly, then give that sentence or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold on B2: pick a time you checked what was said against what was in the build. If no such time comes to mind, say so plainly, then describe how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." — your message. B3 holds the beats and the answer slot |

## Reverse questions

| # | Ask | Why it lands |
|---|---|---|
| R1 | "You came to live operations from QA. What did that change about how you run a release?" | Tied to his own path (Reading the interviewer); it turns a checklist into a peer conversation and invites his release vocabulary |
| R2 | "Your GDC talk argued that a live team is judged by whether its patch notes match what shipped. How do you see that on the team today?" | Shows you read his published work and connects to a published value; ask it only after reading the talk |
| R3 | "Project Larkspur describes one shared calendar and a single live-ops group. How does the two-title calendar in this role map onto that?" | Shows current awareness and surfaces how the role may change, which also tells you what you would actually do |
| R4 | "What does a strong tabletop response look like to you, and what do people usually miss." | Treats the format as the job; invites unguarded feedback on the hour you just did |
| R5 | "What should a new producer understand about how events and purchases interact in your titles by day 60." | Turns the biggest gap into a forward-looking question without adding a claim |
| R6 | "What does the post-event review look like today, who reads it, and what decision has it changed recently." | Probes the review the JD gives the role and shows you think about decisions, not documents |
| R7 | "Who would I coordinate with on each update, and where does the calendar owner's authority end." | Surfaces the coordination boundary behind C2 before it is a problem |

## Prohibited claims

What this pack will not coach, built from the snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title, not live events across two titles. C1 and A3's slots stay inside the calendar you ran |
| Led or managed the design, art, engineering and community teams | Negative you stated: "Never led a team" | The plain acknowledgment: "I haven't led a team." No slot |
| Has experience with in-app purchases or monetization | Negative you stated: "never worked on a game with in-app purchases" | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, never a past |
| Owned or defined the KPIs and post-event reviews | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers to the studio head. D1 and D2's slots ask only what the numbers covered and whose they were |
| Ran the release process end to end | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist, and QA still uses it. The pack's observation: your material says wrote, not ran |
| Four years of live-service producing | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer at a puzzle-game studio, and the weekly calendar for the last two. F5's slot asks only whether the title was live-service |

## Sources

Provided: the JD you pasted and your background, both in your message.

Searches sent:

1. "Saltmarsh Games values": returned https://saltmarshgames.com/values
2. "Saltmarsh Games interview process live operations producer": returned https://saltmarshgames.com/careers/interviewing
3. "Saltmarsh Games strategy news mobile": returned https://saltmarshgames.com/news/project-larkspur (search snippet only, page not fetched in full)
4. "Tobias Wrenfield Saltmarsh Games": returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only, page not fetched in full)

Fetches sent:

1. https://saltmarshgames.com/values: returned the page text
2. https://saltmarshgames.com/careers/interviewing: returned the page text

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet; B1 to B3 name the three published values |
| 2. Saltmarsh Games interview process, live operations | yes | The documented loop: a recruiter call, then one 60-minute interview with the hiring manager, a tabletop and then a values conversation; persona weights and the values-round decision follow it |
| 3. Saltmarsh Games strategy and recent news | yes | A3, C1, R3: Project Larkspur, from the search snippet only |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Reading the interviewer, R1, R2, B2: role, prior QA role and the GDC 2026 talk, from the search snippet only |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias is your hiring manager → persona weights firm up; if he is a skip-level or another round type, the weights are recomputed and a different bank leads
- The recruiter's note on the Outage Hour (the scenario, which title, who else is in the room, whether you talk or present) → A1 and A2 become the real scenario shape instead of generic ones
- The full Project Larkspur announcement and the GDC talk, pasted or linked → A3 and R2 to R3 rest on the full documents rather than search snippets, and more of the pack becomes grounded
- Your answers to the answer slots on F1, F2, F3, F5 and F8 → those rows regenerate with your own words quoted into the evidence column, and the stories they carry are mapped
- An inspectable artifact: a retention deck you presented, the checklist document itself, or a post-event review you wrote → F3, F4 and F7 can move from medium to high
- A tuesday-dossier.md from a prior job evaluation → verified evidence and prohibited claims arrive pre-graded instead of built locally
