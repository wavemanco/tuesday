I'll read the reference files the skill requires before writing anything.
The pack is written and saved. I'm presenting it now.

Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-1-denied-436743e4/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 21 questions across six personas, each tagged by type, with answer guidance and a rationale. It also has a fit snapshot, an interviewer read, requirement coverage, six reverse questions, a prohibited-claims list and an upgrade menu.

I built it as a peer round with Dan, using the JD highlights and candidate summary you gave me rather than the full documents. Web search was refused in this session, so the Northwind values, any documented interview loop, and Dan's public footprint are not established. The company facts in the pack (the three priorities and the bundling threat) come from your research note and are unchecked. The persona weights rest on your description of a single 60-minute conversation.

The highest-ROI rehearsal is C1: "You haven't done classic sales-ops or quota-setting work. How would you handle that in this role?" That gap sits in Dan's own function. B1 and B2, on the ~$400M figure, come next.

Say the word and I'll play Dan as the Skeptic on C1 so Priya can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy — a peer; Dan and Priya would report to the same VP. **Format:** one 60-minute conversation (your message).

**Built on:** the JD highlights and candidate summary you gave me, not the full JD or CV. Web search was refused in this session, so Northwind's published values, any documented loop, and Dan's public footprint are not established. Everything about Northwind below comes from your research note, and I could not check it against a source.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Rehearse by persona (delivery) and check coverage by type (content). Guidance is scaffolding, not a script: say it in your own words, and never say anything you could not defend on a second question.

Question IDs run A to E, then G. The letter F is skipped so question IDs never collide with the fit-snapshot rows F1 to F7.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. Not used here: no published values were read and no values round is documented, so no VAL question exists |
| EXP | Whether your claims survive scrutiny and attribution is exact |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Northwind's altitude on its strategy |
| CASE | Structure and reasoning on a live problem from the role |

## The fit snapshot

Requirements are quoted from the JD highlights in your message. Evidence is quoted from your candidate summary in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market for new lines, and the words stay there: "For nine years I was in product strategy and ops at a large consumer-tech company." Answer slot: the JD's new-product-lines line makes a probe likely on which of that work involved taking something to customers. If any did, say which part and what was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the product strategy and ops you did |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | low | [inferred] | discovery | The sentence says a proposal and a credited uplift; it does not say how the opportunity was found or which lifecycle stage it sat in, so no bridge to land, adopt, expand or renew is drawn. Answer slot: expect a probe on how whitespace gets found. If you found the opportunity yourself, say how, in your own words; if someone else found it, or there was no search for it, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | No gap in terms, but an adjective with nothing inspected behind it, and Dan's self-description as "relentlessly data-driven" (your message) makes a probe likely. Lead with it in the quote's own terms, because a named analysis beats an adjective. Answer slot: if there is an analysis you ran yourself in those tools, offer to walk through it end to end; if the work was mostly someone else's, say so plainly |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not the design of a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe likely on whether you shaped how partners were engaged beyond the model. If any of that was yours to design, say which part and how you decided; if none was, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | none | No gap in terms, but a line with nothing inspected behind it, so expect a probe. Lead with it as written: you set annual volume targets, with consensus across orgs. Answer slot: expect a probe on where the orgs disagreed. If they did, say what about and what part was yours; if they did not, say so plainly and stay with the targets and the consensus |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | none | The quote reaches the plus at the level of use, and the words stay there: "I use AI tools daily." Answer slot: say which tools and for what tasks, in your own words; if most of it is general use rather than analysis or GTM work, say so plainly |
| F7 | Sales-ops and quota-setting fluency — not a JD line; the function of your interviewer, Director of Sales Strategy (your message) | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't done classic sales-ops or quota-setting work." Then how you would learn it, said as a plan and never as a past. F5's quote says volume targets with consensus, and it stays at that scope; it is not offered as quota-setting |

## Reading the interviewer

Everything in this table is Dan's profile as you relayed it. Public footprint is public professional information only; none could be searched this session.

| Signal | Source | What it changes in the pack | Questions |
|---|---|---|---|
| Self-described "relentlessly data-driven" | your message | Every number gets probed to its assumptions; the ~$400M and the revenue model are the likeliest targets | B1, B2, B3, G2 |
| Career spine in pricing and monetization | your message | Case questions lean to packaging, pricing and unit economics. Shared vocabulary: describe F4's model as the sentence does, "a partner-level revenue model used in carrier negotiations", and let Dan decide how close it sits to their work. It is not offered as pricing work | D1, D2, B5 |
| One early-stage-startup chapter | your message | Expect a probe on big-company pace and habits. No row's evidence carries your side of a startup or 0-to-1 jump, so none is offered as a mirror | C4 |
| Peer, same VP | your message | Reciprocity framing: what you bring Dan's team as well as what you need; propose seam principles rather than pretending to know the seam | A1 to A5, reverse question 2 |
| Director of Sales Strategy | your message | The competency F7 says you lack is Dan's own; candor beats a bluff | C1, G1 |
| Public talks or posts | not established, search refused | No recurring themes read; if you have a link, paste it | none |

## Persona table

The loop is one 60-minute conversation with Dan, from your message, so weights rest on that and not on an archetype.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between Dan's team and yours, "what would you need from me", credit and disagreement | High. The peer relationship makes this and the Prober dominant, and a shared VP makes the seam live | Reciprocity framing and seam principles; disagreement shown with spine and tact. Bank A |
| Data-Driven Prober | Line-by-line probing of numbers and analysis | High. The peer prior plus the "relentlessly data-driven" self-description moves it up | Know how each number was counted, say plainly where you do not know, name the weakest assumption first. Bank B |
| Skeptic | Quiet probing of the sales-ops gap, motivation and pace | Medium, raised from its prior because F7 sits in Dan's own function | Rehearse C1 until it is boring: plain acknowledgment, then the quote at its scope, then a ramp plan. Bank C |
| Case/Strategist | Live GTM, whitespace and bundling problems | Medium. Low as a peer prior, raised by the pricing spine and the JD's GTM remit | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise. Bank D |
| Conversational | Opening walk-through, a casual AI question | Low as a share of the hour, but the opener sets the frame and the casual AI question is still scored | A 90-second arc built from your own sentences. Bank E |
| Pressure | Time-boxed "why you" and "how much was you" | Low. Nothing in the material signals a stress style; kept for attribution on the largest number | Hold through two follow-ups, then concede specifically. Bank G |
| Values/Behavioral | Scenarios mapped to published values | Not banked. No loop source documents a values round and no published values were read | Upgrade menu |

## Question banks

**Highest-ROI prep in this pack: C1.** The stated gap in sales-ops and quota-setting sits in the interviewer's own function, so some form of it is very likely. B1 and B2 are next: the ~$400M figure is the single number Dan can probe to its assumptions.

### Bank A — Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where do you see the seam between emerging-products GTM and sales strategy, and what happens when we disagree?" | JD | [generic] | Do not pretend to know the seam. Offer principles: ask what Dan's team already owns before proposing anything; separate who sets targets from who designs motions; settle disagreements by agreeing first what evidence would change each side's mind. Then ask Dan where the seam hurts today | The peer prior puts seam questions first, and F5's requirement is where it presses; JD because it scores cross-functional influence, with Peer delivery |
| A2 | "Tell me about a time you needed several organizations to agree on a plan." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the annual volume targets and the consensus across orgs are the beats the quote states; tell them in your own words. Answer slot: the JD's cross-functional line makes a probe on where the orgs disagreed likely. If they did, say what about and what part was yours; if they did not, or it was settled by someone else, say so plainly and stay with the targets and the consensus. Do not call the targets quotas | F5 is the evidence for the influence requirement; EXP because it tests what was actually the candidate's. An open prompt, so it supplies no event |
| A3 | "How do you handle credit when work spans two teams?" | JD | [generic] | Method, not history: name each team's contribution explicitly and early, share the data behind a result so it can be checked, and agree before launch who presents what. Keep it short; the point is that you reduce Dan's load rather than add to it | Persona stem for the Peer Evaluator; JD because it scores the cross-functional requirement, and it carries no claim about your past |
| A4 | "What would you need from me in your first sixty days, and what would you bring my team?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with reciprocity. Offer what the quote carries, in its own terms: "I'm skilled in SQL/Tableau", and ask which analyses on Dan's side are queued that you could take. Then give the needs as questions about how Dan's team sets targets and runs the sales motion. Answer slot: if there is a specific analysis you could name, name it; if not, say so plainly and ask which would help | F3 is the evidence for the analysis requirement; JD because it scores partnership fit against that requirement |
| A5 | "Suppose you design a partner motion and my team says it is not working in the field. How do you handle that conversation?" | CASE | [generic] | Structure it aloud: first agree what evidence would show it is not working; ask where my team sees the break; separate a design flaw from an execution flaw using the data; own the redesign where the data points to the design; concede what you cannot know until you see the field. Makes no claim about your past | A hypothetical on the partner-motion requirement in F4, in Peer delivery; CASE because it asks about no past |

### Bank B — Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the sentence says at its scope: you proposed the change, and the uplift was credited to it. Use the word "credited"; do not upgrade it. Answer slots: how the figure was counted, in your own words; if you do not know how it was counted, say so plainly. Which part of the result was yours. Who did the crediting, if you know | A headline metric is a magnet for this persona (F2). EXP because it tests how exactly the figure is held |
| B2 | "Which assumption behind that number would you defend least, and what is it most sensitive to?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name, before Dan does, the assumption behind the figure you would defend least. The pack does not name one. Answer slot: if you know what the uplift is sensitive to, say so in your own words; if you do not, say so plainly and say what you would want to check. Naming it first converts a gotcha into credibility | The standard second-level follow-up from this persona on F2; EXP, with the weakest-assumption move the type bar requires |
| B3 | "Tell me about an analysis you ran yourself in SQL or Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | The quote carries no story, so use a selection scaffold. Pick an analysis where you can state the question, where the data came from, what you did in SQL or Tableau, and what decision it fed. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry: "I'm skilled in SQL/Tableau", or how you would approach one. Offer to walk it through end to end | F3's requirement is stated as independent analysis, and this persona tests it hardest; JD content in Prober delivery |
| B4 | "Walk me through the revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: a revenue model, partner-level, built by you, used in carrier negotiations; those are the beats, in your own words. Answer slot: the JD's partner-motion line makes a probe on whether you designed any of how partners were engaged beyond the model likely. If you did, say which part and how you decided; if not, or it was not yours, say so plainly and stay with the model | F4 is the evidence for the partner-motion requirement and its likeliest probe; EXP because it tests what the candidate actually built |
| B5 | "Where would you start looking for whitespace across land, adopt, expand and renew, and what data would you need first?" | CASE | [generic] | Clarify first: which product line, which customer segments, what data exists. Then objective, segmentation by lifecycle stage, an approach per stage, the metric you would watch, the risk that the data is thin. Challenge one premise respectfully, for example whether the stages share one definition of an account. Makes no claim about your past | The JD's lifecycle line (F2), asked as a live problem; CASE because it scores structure, with Prober delivery |

### Bank C — Skeptic (weight: medium, raised)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't done classic sales-ops or quota-setting work. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | The deepest rehearsal in this pack. Hold-then-concede. Open with the plain acknowledgment: "I haven't done classic sales-ops or quota-setting work." Hold only what the quotes carry: "set annual volume targets with cross-org consensus" at its own scope, without calling it quota-setting; let Dan decide how close it sits. Concede specifically: you do not know how Dan's team sets quotas and would want to learn it first. Give the ramp as a plan, not a past: name two or three things you would ask Dan's team to teach you in the first month, your choice. Hold through two follow-ups by returning to the same sentences, never by adding to them | F7 is the biggest gap and sits in Dan's own function, so this is asked in some form. JD because it scores a stated gap, Skeptic because the interviewer probes it quietly. The negative has a source in F7 |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [inferred] | Selection scaffold: the thinnest rows in the fit snapshot are F1, F2 and F4; pick the one you can describe most honestly, say plainly why it is thin, then give the plan to close it. The pack does not choose for you. If none seems thin to you, say so plainly and name the one where you would ask for the most help | A persona stem for the Skeptic that every candidate gets; derived from the snapshot's gap types, not from any claim about you |
| C3 | "Why B2B data infrastructure, and why now?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | The reasons are yours; the pack does not supply them. Structure: why this kind of company, why this role's lines, why now. Test each reason by asking whether it would still hold for a competitor. Own the difference in background in one sentence, "I spent nine years in product strategy and ops at a large consumer-tech company", and move on. Answer slot: if there is a specific piece of the JD that draws you, say which; if the pull is broader, say so plainly | The motivation probe for a consumer-to-B2B move (F1); JD because it scores role fit, Skeptic because it tests consistency under cross-examination |
| C4 | "You spent nine of your eleven years at one large consumer-tech company. What would you have to unlearn to work here?" | EXP | [grounded] "11 years" "9 at a large consumer-tech company in product strategy & ops" | The quotes carry the tenure and the setting, so stay there. Selection scaffold: pick one habit that setting rewards and this role would not, with a stake and what you would do instead. If no such habit comes to mind, say so plainly, then say how you would find out in the first month | Dan's startup chapter makes a pace probe likely (interviewer read); EXP because it tests self-knowledge about the history in F1 |

### Bank D — Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Suppose a new B2B data product is launching into an installed base. Sketch the land and expand motion. What do you need to know first?" | CASE | [generic] | Clarify first: the buyer, the existing relationship, what the product replaces, the price point. Then objective, segmentation of the base, a land path and an expand path with the metric for each, and the risk that expansion cannibalizes an existing product. Use pricing and packaging language; Dan's spine is there. State your hypothesis early | The JD's two-new-product-lines line (F1), in the interviewer's native vocabulary; CASE |
| D2 | "A much larger platform vendor starts bundling a feature that competes with a new product, at no extra charge. What do you do in the next ninety days?" | CASE | [grounded] | Your research note names bundling by a much larger platform vendor as the main competitive threat; I could not check it, so say "as I understand it" if you cite it. Clarify what is bundled and for which segments. Segment where good-enough wins from where depth wins; choose a pricing and packaging response and a partner angle; name the metric and the risk. Make no claim about how Northwind handles it today | The one question the research note makes specific; CASE with a CO payoff, because it scores structure and strategy fluency together |
| D3 | "Northwind's priorities are enterprise expansion, the Compass launch and profitability. Which two pull hardest against each other for an emerging product?" | CO | [grounded] | The three priorities come from your research note, unchecked. Take a position: pick the pair you see in tension, say what you would need to know to change your mind, and concede that you see Northwind from outside. Do not claim to know Compass's roadmap or margins; ask Dan how the two product lines relate to Compass | The CO question grounded in current strategy; CO because it scores altitude, and it is a peer-level exchange of views, not a quiz |

### Bank E — Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" "9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc whose beats are the quotes, each at its own scope: two years in strategy consulting, nine in product strategy and ops, then the model, the targets and the proposal. Close on why this role, in your words. Answer slot: if the move to B2B has a specific trigger, say it; if it does not, say so plainly and say what the JD offers | The biography question opens a conversational hour and sets the frame; EXP because it is the CV's claims told in sequence (F1, F4, F5, F2) |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | The quote carries use, so say use: "I use AI tools daily." Answer slot: name the tools and the tasks, in your own words; if most of it is general use rather than analysis or GTM work, say so plainly and say what you would try on Compass-style questions. Do not describe building or deploying anything | The JD's AI plus (F6), asked casually and still scored; JD with Conversational delivery |

### Bank G — Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has run sales strategy for years?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "skilled in SQL/Tableau" "No classic sales-ops or quota-setting experience." | Pause, restate, then hold-then-concede. Hold with the three quotes at their scope and nothing wider. Concede specifically: "I haven't done classic sales-ops or quota-setting work." Do not claim to be better; say what you would add and what you would learn. Hold through the second push by repeating the same sentences | Covers F7 under time pressure; JD because it scores fit including the gap, Pressure because the format is a time-box |
| G2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold-then-concede on the sentence as written: you proposed the change; the uplift was credited to it. Concede what the sentence does not say. Answer slot: if anything beyond the proposal was yours, say what; if nothing was, say so plainly and stay with the proposal. Hold through two follow-ups without adding anything | The persona stem for attribution, on F2's figure; EXP because it tests exact attribution |

### Requirement coverage

| Requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | D1, D2, D3, C2, C3 |
| identify whitespace across land/adopt/expand/renew | B5, D1, C2 |
| run independent analysis in SQL and Tableau | B3, A4 |
| partner-motion design experience required | B4, A5, C2 |
| strong cross-functional influence | A1, A2, A3 |
| AI experience a plus | E2, D3 |
| Sales-ops and quota-setting (not a JD line) | C1, G1 |
| The ~$400M figure | B1, B2, G2 |

## Reverse questions

| # | Question | Why it lands | Tied to |
|---|---|---|---|
| 1 | "Your background is in pricing and monetization. How does that shape where you want emerging-product GTM to hand off to sales strategy?" | It asks about their path and the seam in one move, and invites the vocabulary they know best | Dan's path |
| 2 | "What could a new person on my side do in the first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are pricing what you cost them | Peer relationship |
| 3 | "Which two product lines does the role cover, and where does Compass sit relative to them?" | It shows you read the priorities and avoids assuming how the lines relate | Research note |
| 4 | "You also spent time at an early-stage company. What did you bring back to a company this size?" | A peer conversation about a jump they made, which is the opposite of an interrogation about yours | Dan's path |
| 5 | "When a bundled offer from a larger platform vendor appears in a deal, where does that show up in your data today?" | It lets Dan show how data-driven they are, on the competitive threat your note names | Research note |
| 6 | "How will you and I decide whether the whitespace work was right?" | It asks for the scoring system in a data-driven peer's own terms | Peer relationship |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Set quotas, ran sales ops, or called the annual volume targets quotas | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't done classic sales-ops or quota-setting work." F5's quote stays at its own scope. No slot |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: you proposed the change and the uplift was credited to it. The limit is the pack's observation, not words for you: the material says proposed and credited, not measured or delivered. G2's slot stays inside the proposal |
| Designed the partner motion or partner GTM | Inflated form of F4 | F4's quote at its own scope: a revenue model used in carrier negotiations. The limit is the pack's observation: the material says the model, not the motion. B4's slot stays inside the model |
| Owned GTM strategy for new products | Inflated form of F1 | F1's quote at its own scope: product strategy and ops at a large consumer-tech company. The limit is the pack's observation: the material does not say go-to-market for new lines |
| Built or deployed AI products | Inflated form of F6 | F6's quote at its own scope: use of AI tools daily. E2's slot stays inside use |

## Sources

**Provided documents:** your message: the JD highlights, the candidate summary, Dan's profile as you relayed it, and your research note (three stated priorities and the competitive threat). No dossier was supplied. The research note's currency could not be checked against a source.

**Calls sent (all refused):**

- `Northwind Data company values principles` — refused
- `Northwind Data interview process strategy operations GTM` — refused
- `Dan Kovac Northwind Data Director of Sales Strategy` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Search refused. Would have moved VAL coverage and any values cheat sheet; none is built and no VAL question exists |
| 2. `Northwind Data interview process` | unavailable | Search refused. Would have moved persona weights if it documented more rounds or a values round; weights rest on your words about one conversation with Dan |
| 3. `Northwind Data strategy` | skipped | Your research note already supplies the priorities and the competitive threat that feed D2 and D3, so a search could not have moved them |
| 4. `Dan Kovac Northwind Data` | unavailable | Search refused. Would have moved the interviewer read and the reverse question tied to Dan's path, which now rest only on your relay of their profile |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the seven fit rows would be re-quoted from the complete JD, and mid-list requirements the highlights left out would get their own questions in the coverage table
- Full CV → each quote gains a CV origin, and rows F1 to F6 may gain evidence the summary omits; a revenue-model summary, the proposal behind the store-surface change, or an analysis example in SQL or Tableau would be the inspectable artifacts that raise a medium row toward high
- Your answers to the slots in F1, F2, F4 and F5, and how the ~$400M was counted → those rows and B1, B2, G2 upgrade from slots to story maps
- The recruiter's stated focus areas, or any pre-declared deliverable → coverage beyond the round-type priors, and a build section if a deliverable exists
- Search access, then a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → Northwind's published values and documented loop, Dan's talks and writing, recent org context; a values round, if one exists, would add a VAL bank and cheat sheet
- A link or paste of Dan's talks or posts → their recurring themes become questions and reverse-question material
- Which two product lines the role covers, and whether Compass is one → D1 to D3 and reverse question 3 become specific
- An evidence-recovery dossier from an earlier pass, if you have one → verified claims and objections would carry into the banks and the prohibited list
