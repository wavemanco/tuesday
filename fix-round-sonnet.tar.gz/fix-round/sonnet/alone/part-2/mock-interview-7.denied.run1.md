I'll read the reference files the skill points to before building the pack.
Running the L1 research targets in parallel: values, interview process, strategy and news, and the interviewer's public footprint.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-denied-bcb14253/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say whether Tobias is your future manager. It has 18 questions across five interviewer styles, a fit table of the JD against your own sentences, and a list of claims it won't coach.

Web search was refused, so the pack has no company values, strategy or loop details, and nothing on Tobias beyond his title. Because of that it has no values or company-strategy questions, and the reverse questions are generic rather than tied to his career.

The question to rehearse hardest is B1, "Which part of this JD would you be weakest at on day one?" You told me you've never led a team and never worked on a game with in-app purchases. The pack has you say both plainly before he asks, then hold on what your own sentences carry: the weekly content-drop calendar, the release checklist, the monthly retention numbers.

Say the word and I'll play Tobias on B1, with follow-ups, then give you feedback. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for later sessions. If you want the pack as a Word document, I'll convert it.

Is Tobias the person you'd report to, and did the recruiter mention any focus areas or anything to prepare? Either answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Format: 60 minutes, Friday. Relationship assumed: hiring manager. Your note did not say whether he is the person you would report to, so persona weights follow the hiring-manager prior and the persona table shows the reasoning.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Every question carries one type tag:

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your stated experience survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, solved aloud |

This pack has no VAL or CO questions: no published values or strategy material was in hand (see Sources). Guidance is scaffolding, not a script; say it in your own words. An answer slot is an instruction for the interview, not a question for me: answer whichever branch is true. Saying plainly that a practice was not yours is a valid answer.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says weekly content drops for one title, not events and not two titles, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's events wording makes a probe on whether any drops were timed events likely. If any were, say which and what they involved, in your own words; if none were, say so plainly and stay with the weekly drops. For the two-title part, speak as a plan (A1), never as a past |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams, if any, the weekly drops involved. Answer slot: the JD's coordination line makes a probe on this likely. If coordinating with design, art, engineering or community was part of running the calendar, say which and how, in your own words; if it was not, or one of those teams was never involved, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says presenting the monthly numbers, not owning a review or defining KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's review-and-KPIs line makes a probe on what was reported likely. Say which of those figures, if any, were yours to define; if none were, or no post-event review existed, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says wrote, with QA still using it, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's QA line makes a probe on the checklist likely. Say what it covered and which parts of its contents were yours to set; if you did not set them, or QA used it without your involvement, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer at a puzzle-game studio and does not say whether the main title was a live-service game. Answer slot: the JD's live-service wording makes a probe on this likely. If it was, say how you describe it in the studio's own terms; if it was not, or you are unsure, say so plainly and stay with the weekly calendar |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in wording, but a line with nothing inspected behind it. Lead with the monthly retention numbers and the studio head in the quote's own terms, because a named audience beats an adjective. It says presented, so expect a probe on how the numbers were counted (C1, C2) |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist is written work, and your material does not show whether anything else you wrote reached a wider audience. Answer slot: the JD asks for clear writing, so expect a probe, and E3 tests it live. If any written update or summary of yours went to people outside producing, say which, in your own words; if none did, say so plainly and stay with the checklist |
| F8 | Experience with in-app purchases (role-family expectation; the JD does not state it) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I have never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F9 | Leading people (role-family expectation; the JD asks for coordination and mentions no reports) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I have never led a team." Then how you would get agreement across disciplines without that, said as a plan and never as a past. The JD's coordination line is F2's slot, kept separate |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: plan the calendar, handle a release-day blocker, diagnose a retention drop | Highest. The hiring-manager prior is Case plus Skeptic, and the JD is built from responsibilities (plan, coordinate, review, checklist) that turn directly into live problems | Clarify, then objective, segments, approach, metrics, risks; think aloud; challenge one premise per case (A1 to A5) |
| Skeptic | Quiet, persistent probing of the gaps | Highest, tied with Case. F8 and F9 are limits you stated, F1 and F3 stretch to reach the JD's wording, and the Skeptic prior sits beside Case for a hiring manager | Rehearse B1 until it is boring; state the limit before it is asked for; hold on what your quoted sentences carry; give a plan, never a past, for what you have not done |
| Data-Driven Prober | Reads the retention line closely and asks how the number was counted | Medium. The JD asks for comfort with retention metrics (F6), but nothing in the material says Tobias is analytics-heavy | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know (C1, C2) |
| Conversational / Rapport | Friendly open prompts: the journey, what you are playing, why this role | Medium. No source says how the conversation opens, and every plausible style is still worth touching once | Pre-script a 90-second arc from your own sentences; treat casual questions as scored (D1 to D3) |
| Pressure | Time-boxed, devil's advocate, attribution probes | Low. The prior puts Pressure with skip-level and executive rounds; if Tobias is skip-level, this rises | Pause, restate, hold through two follow-ups, concede one specific limit (E1, E2) |

## Question banks

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for a month of live events across two titles. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify before structuring: what each title's cadence and audience are today, what is already fixed, what each team's capacity is, what the month is meant to move. Then objective, segmentation by title and event type, sequencing, the metrics each event reports, risks. Challenge one premise aloud, such as whether the two titles should share a cadence. Your own experience stays at its own words: "I ran the weekly content-drop calendar for our main title for the last two years." For the two-title part, answer as a plan, not a past | JD's first responsibility, and F1 is where your material is closest but not identical; CASE because it scores structure on a live problem |
| A2 | "Four hours before an event goes live, QA flags a bug and engineering says a hotfix is risky. Art says moving the date breaks the schedule. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Decide aloud: what you need to know first (who is affected, what can be switched off, what players were told), the options (ship, delay, ship reduced), the criteria for choosing, who has to agree, what you record and what you tell the community. Anchor your experience at its own scope: "I wrote the release checklist our QA team still uses." Answer slot: say what the checklist covered and which parts were yours to set; if you did not set them, or QA used it without your involvement, say so plainly and stay with having written it | JD's QA and coordination lines; F4 is the evidence and F2 the silent part, so this is where both get tested together |
| A3 | "Players who joined during last week's event are leaving faster than other new players. Diagnose it." | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Define first: which retention window, which cohorts, compared against whom. Segment by acquisition source, platform, time since install. Hypotheses to rank, the data you would pull first, what you would tell the team before you know. Name the weakest assumption yourself: that the two groups are comparable. Answer slot: if you chose how retention was cut for the monthly numbers, say how; if the cuts were set by someone else, say so plainly and stay with presenting them | JD's retention line; F6 and F3 carry the evidence; CASE because the interviewer scores diagnosis, not recall |
| A4 | "How would you run a post-event review, and which KPIs go in its headline?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Frame the review as a decision tool: what it decides (repeat, change, drop), what goes in (planned against actual, participation, retention against a baseline, issues, follow-ups with owners). If asked which KPIs the titles use, ask instead of assuming. Answer slot: if any review followed your calendar's drops, say how it was run and what was yours; if there was no formal review, say so plainly and stay with the monthly numbers you presented | The JD says own the review and its KPIs, the likeliest place F3 is stretched; tagged JD because it scores the stated responsibility, with CASE delivery |
| A5 | "Two titles want the same engineering and community capacity in the same week. How do you decide?" | CASE | [grounded] | Clarify what is fixed and what can move. Name criteria (player impact, commitments already made, cost of delay, reversibility), who must agree, how you communicate the decision, how you stop it recurring. The question needs no claim about your past, so the guidance makes none | The JD's coordination line and the two-title scope, with F2 and F9 as the silent parts; the problem is hypothetical, so nothing about your history is presupposed |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Name your own limit before it is pulled out of you, in plain words: "I have never worked on a game with in-app purchases" and "I have never led a team." Then hold on what your quotes carry, at their own scope: the weekly calendar for the main title, the checklist you wrote, the monthly retention numbers you presented. Follow-up 1, "What would you do in your first 30 days to close that?": a plan in your own words, never a past. Follow-up 2, "What if the gap is bigger than you think?": concede specifically what you do not yet know, and do not fold on the quoted work. Follow-up 3, "Why not a candidate who has it?": restate what you bring at its own scope, with no comparison claim. Answer slot: if there is a part of the JD you would rank weaker than these, say which and why; if not, say so plainly | The interviewer's most predictable question, and F8 and F9 are limits you stated, so it will arrive in some form; JD because it scores the stated requirements, Skeptic because it asks for honest self-assessment |
| B2 | "You haven't led a team, and this role coordinates four disciplines. Where does your influence come from?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "Wrote the release checklist our QA team still uses." | Say the limit first: "I have never led a team." Then what the role asks, per the JD's own words: coordinating design, art, engineering and community, which is F2's slot. Answer slot: if coordinating those teams was part of running the weekly calendar, say which and how you got agreement; if it was not, or someone else did it, say so plainly and stay with the checklist you wrote and the calendar you ran. Hold through two follow-ups by returning to what you wrote and ran, never by adding to it | F9 states the limit and F2 is silent on coordination; the question presupposes only what the quoted sentence says |
| B3 | "You ran weekly content drops for one title. This role runs a live-events calendar across two. What transfers and what doesn't?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | What transfers is only what the sentence states: a calendar, a weekly rhythm, two years, one title. Say what you do not yet know about events and two-title planning, then how you would learn it. Answer slot: if any of your drops were timed events, say how they differed from ordinary drops; if none were, say so plainly and stay with the weekly drops | F1 is a transferability row: the sentence reaches the calendar, not the events or the second title |
| B4 | "The JD asks for three years producing live-service games. Your title was associate producer. How do you see your years against that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | State the facts at their own words: "4 years as an associate producer at a puzzle-game studio." Then what you ran inside those years, from F1, F3 and F4, at their own scope. Answer slot: if the main title was a live-service game, say so in the studio's own terms; if it was not, or you are unsure, say so plainly and stay with the weekly calendar | F5 is discovery: the years are stated, the live-service nature is not; JD because it scores a stated requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention number was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The slots a reported figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer slot: if you know how it was counted, say so; if you do not, or the counting was done by someone else, say so plainly and stay with presenting it | F6 is a line with nothing inspected behind it, so probers go here first |
| C2 | "Which assumption behind your retention reporting would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The weakest-assumption move: name, before they do, the assumption you know of that you would defend least. Answer slot: if you can name one, say it and what it changes; if you cannot, say plainly that you do not know how the figure was counted, which is an honest branch, and say what you would check first | Converts a gotcha into a credibility gain; the pack does not name the assumption because no quote does |
| C3 | "An event hit its participation target but retention is flat. What do you tell the team?" | CASE | [generic] | Separate what the event was designed to move from what it did move. Say what you would check before drawing a conclusion (comparison group, timing, what else changed that week), and what you would recommend about repeating it. The question asks about no past, so the guidance makes no claim | JD's retention and review lines (F3, F6) as a live problem; generic because it is a pattern for the problem, not a fact about this employer |

### D. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc with only the beats those sentences state: four years as an associate producer at a puzzle-game studio, the weekly calendar for the main title, the checklist you wrote, the monthly retention numbers you presented. Tell it in your own words and end on why you want to run live events, which is yours to say | Casual register, still scored; the arc is built so nothing in it goes beyond F1, F3, F4 and F5 |
| D2 | "What are you actually playing with in live ops these days?" | JD | [generic] | Selection scaffold: pick a live event in a mobile game you have followed closely and say what you noticed about its calendar and what you would have asked the team. If no such event comes to mind, say so plainly, then say how you would study one. The guidance makes no claim about your past | Rapport interviewers ask about the plus-skill casually; generic because it is a pattern |
| D3 | "What draws you to running events across two mobile titles?" | JD | [grounded] | Use the JD's own line, "Plan and run the live-events calendar for two of our mobile titles", and say what about it is true for you, in your own words. If something draws you that is not in the JD, say that plainly. No claim about your past is needed | Motivation consistency; JD because it scores interest in the stated responsibility |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run events for a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pause, restate. Hold on what your quotes carry (the weekly calendar, the checklist, the monthly retention numbers), then concede one specific limit once: "I have never worked on a game with in-app purchases." Give a plan for closing it. Do not compare yourself to anyone | Time-boxed; F8 is the limit being tested and the hold is only what F1, F3 and F4 carry |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you decided which content went into each week, say how; if the content was decided elsewhere, or there was no such decision, say so plainly and stay with running the calendar | The attribution probe the stem names; F1 is the evidence |
| E3 | "The event date just moved by a day. You have two minutes: give me the first three lines of the message to design, art, engineering and community." | CASE | [grounded] | Lead with what changed and the new date, then what it means for each team in one line each, then what you need back and by when. Short sentences, one ask per team. The guidance makes no claim about your past | Tests the JD's clear-written-communication requirement live (F7); the pressure is the time box |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "3+ years producing live-service games or apps" | B4, D1 |
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A5, B3, E2 |
| "coordinate design, art, engineering and community teams on each update" | A2, A5, B2, E3 |
| "own the post-event review and the KPIs it reports" | A3, A4, C3 |
| "manage the release checklist with QA" | A2 |
| "experience running a content calendar" | A1, B3, E2 |
| "comfortable with player-retention metrics" | A3, C1, C2, C3 |
| "clear written communication" | E3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do you judge whether a live event worked, and which numbers does the post-event review report?" | The JD makes the review and its KPIs mine to own, so this asks for the definition rather than assuming one |
| R2 | "What does the release checklist look like today, and where does it rub?" | Shows you think about the checklist as a working tool with QA, which is the JD's own pairing |
| R3 | "On an update, which relationship between design, art, engineering and community is hardest to keep in step?" | Tells you where the coordination line bites and signals you are already thinking about the seams |
| R4 | "How do the two titles differ in how they run events, and how much of the calendar is shared?" | The two-title scope is the largest step from one title's weekly drops; this asks where it really is |
| R5 | "What would you want a new producer to learn first about how your titles earn?" | Lets you show you know where your ramp is without making a claim about experience you do not have |
| R6 | "What would a strong first 90 days look like in this seat?" | A concrete bar to plan against, and the answer shows what the team weights |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F9 | The sentence you wrote: "Never led a team, and never worked on a game with in-app purchases." Plain words: "I have never led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F8 | Same sentence. Plain words: "I have never worked on a game with in-app purchases." No slot |
| Owned the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says weekly drops for one title, not events and not two titles |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says presenting the monthly numbers, not owning a review or defining KPIs |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says wrote, not managed |

## Sources

Provided documents: the Live Operations Producer JD text and your background message. No dossier was present.

Searches sent, all refused by the host before returning anything:

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games mobile studio news strategy": refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have fed a values cheat sheet and VAL questions; none built, so the pack has no VAL bank |
| 2. Saltmarsh Games interview process, live operations | unavailable | Would have shown whether the loop has a values round; persona weights rest on the hiring-manager prior and your note that this is one 60-minute session with Tobias |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have fed CO questions grounded in current strategy; none written |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have fed an interviewer read and a reverse question tied to his path; the section is absent and reverse questions are role-generic |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Permission for web search in this session → values cheat sheet and VAL bank, CO questions from current strategy, an interviewer read for Tobias with a reverse question tied to his path, and a documented loop; a deeper pass would add up to 6 more searches and 2 more fetches and several more minutes
- Whether Tobias is your future manager, a skip-level, or a peer → every bank reweighted; skip-level raises Pressure, peer adds a seam-and-reciprocity bank
- The recruiter's prep email (focus areas, any exercise or presentation) → coverage of any pre-declared deliverable and a focused version of the banks
- Which teams, if any, your weekly drops involved → F2 moves from discovery to a story-mapped row and B2 and A5 get real evidence
- Whether the main title was live-service, and whether any drops were timed events → F5 and F1 slots resolve
- How the monthly retention numbers were counted, and which figures you defined → C1, C2 and F3 get answers in your own words
- A written update, summary or checklist excerpt you can show → F7 moves from low confidence toward medium
- The full CV → rows now resting on your message become CV-quoted, and gaps the CV closes drop out
