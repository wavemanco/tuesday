I'll read the skill's reference files before building the pack.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-2-denied-369fb9e2/atlas-freight_operations-manager_interview_pack.md`.

I built it from your message alone, with a flat persona mix tilted toward Skeptic and Case, because the round type and interviewer are unknown. My three Atlas Freight searches were refused, so anything about the company beyond the JD's own words is generic.

**The objection to prepare for most (A1):** the JD asks for 12 supervisors across 4 sites, and you lead 3 at one site. Practice answering it by stating both numbers plainly and describing what you actually did, without claiming more. A3 (how many of your 7 years were leading people) and A4 (Power BI) are the next two.

**Fill in the answer slots:** the pack can't supply facts only you have, so it leaves slots in A1, A3, A4, C1 and C4. Answer them in your own words. If the honest answer is "that wasn't mine" or "that didn't exist", say that.

Say the word and I'll play the Skeptic on A1 so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is this a recruiter screen, a hiring-manager round, or a panel, and did the recruiter name any focus areas or ask you to prepare anything? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees) — from the JD you pasted
- **Interviewer and relationship:** not known; round type not known
- **Built on:** your message only. Persona weights are flat-with-a-tilt (see Persona table), and nothing here is specific to Atlas beyond the JD's own words

## How to use this pack

Personas are how a question is asked; types are what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did. Where a cell says "Answer slot", it is an instruction for the interview, not a question for you now: answer it from your own experience, in either branch, and if the honest branch is "that wasn't mine" or "that didn't exist", say that plainly.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show what the company says it values |
| EXP | Work-experience deep-dive: does what you claimed survive follow-up, and what exactly was yours |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth |
| CASE | Hypothetical or live problem from the actual role: structure and reasoning |

## Prep triage

Sized to an interview about a week out; your daily hours were not stated, so this is an order, not a timetable.

1. Say A1 aloud until the answer is boring, then A3 and A4. These are the three questions this pack expects in some form (see Persona table and the fit snapshot rows F3, F5, F6).
2. Write your own answers to the answer slots in A1, A3, A4, C1 and C4. Only you have those facts; the pack does not.
3. Speak B1, B2 and B3 aloud once each, using clarify, then structure, then approach, then metrics, then risks.
4. Build the 90-second arc in D1 from your own sentences.
5. Do the homework B4 asks for, because the pack could not research Atlas.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution work, a current shift-manager role, and the site's surge plan, with nothing inspected behind it; it does not say terminal operations or more than the site, and the words stay at that scope: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's word terminal and its four sites make a probe on scope likely. If any of your work covered more than the site and shifts you run, or ran on a terminal-style flow, say which part and what was yours, in your own words; if none did, say so plainly and stay with the site you work in |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The sentence is about mis-picks, not on-time performance or cost per shipment, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names both measures, so expect a probe on what you tracked. If on-time performance or cost per shipment was something you tracked or moved, say which, how it was counted and what was yours; if neither was, or it was not yours, say so plainly and return to the mis-pick work |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The JD says twelve and your sentence says three, and the words stay at three: "I'm currently a senior shift manager over 3 supervisors." Answer slot: expect a probe on the step from three to twelve. If you have ever led more than three supervisors, say how many and in what role; if not, say so plainly and stay with the three |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" touches the requirement without saying what was built or for whom, so the bridge is an answer slot and not a claim. Answer slot: the JD asks about building reporting, so expect "show me one". If you built a report or workbook that others used, say what it showed and who used it, in your own words; if you used Excel for your own working and not for reports, say so plainly and say what you used it for |
| F5 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material shows seven years in the field and a current people-leading role; it does not show how many of the seven years were spent leading. Answer slot: the JD states a minimum, so expect the count. If you can say how many years you have held a role with direct reports, give the number and the title, in your own words; if the number is below the JD's, say it as a number and not an adjective; if you can't say, say that plainly |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap in the words, but a line with nothing inspected behind it, so expect a probe on it. Say it as you wrote it: "I'm green belt certified." Answer slot: if you can say which certification it is and whether a project went with it, say so in your own words; if no project did, say so plainly. Your pick-path sentence and your belt are two separate sentences, and the material does not connect them |

No row in the JD is a gate in the sense of a licence, location, travel or credential term, so no row asks whether one is met. The 5+ years line is graded as experience (F6), not as a gate.

## Persona table

No loop source was read, so the loop falls back to the Generic archetype: flat weights, said plainly. The tilt below comes from the fit snapshot, not from any knowledge of this company's process. A values-style round is not assumed.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of scale, background mismatch and tools | High: F1, F3 and F5 sit against the JD's most explicit lines (four sites, twelve supervisors, Power BI), so the gaps are where a skeptical reader of this JD and this background starts | Rehearse the scale-jump objection (A1) until it is boring; bridges only from your quoted sentences; the limit said plainly; a ramp plan stated as a plan |
| B. Case / Strategist | Live problems from the role: an on-time dip, rising cost per shipment, a volume surge | High: the JD's responsibilities (daily operations, on-time performance, cost per shipment) are things a live problem can test, and none needs a claim about your past | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C. Data-Driven Prober | Line-by-line on the 40% figure and on reporting | Medium: you gave a headline figure (F2) and a reporting line with two tools (F4, F5), which are the things this style checks | Know what you can and cannot say about how the figure was counted and say plainly where you do not know; name the assumption you would defend least before they do |
| D. Conversational / Rapport | Friendly opener, "walk me through the journey" | Medium: a first conversation of almost any kind opens this way, and casual questions here are still scored | A 90-second arc built from your own sentences; treat casual questions about the JD's plus-skill as scored |
| E. Pressure | Interrupts, time-boxes, asks how much was really you | Low to medium: nothing in the material signals this style; it is kept because attribution probes on F2 and the scale jump on F3 arrive in this register when they arrive | Pause, restate, hold through two follow-ups, then concede specifically |
| F. Values / Behavioral | "Tell me about a time" prompts | Low: no values-style round is known, and Atlas's published values were not retrieved, so these are rehearsal only | Pick stories from your own work; the honest branch if none comes to mind |
| G. Peer Evaluator | Seam between neighbouring sites, credit across teams | Low: a peer interviewer is possible in a four-site role, but nothing says one is in this round | Seam principles rather than pretending to know the seam; reciprocity framing |

## Question banks

Highest-ROI prep in this pack: A1, the scale-jump objection (three supervisors against twelve, one site against four), then A3 and A4 behind it. A1 carries the deepest follow-up ladder and the exact concession wording.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You'd lead twelve supervisors across four sites, and you're over three today. Why should we believe you can make that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running" | Hold: say what you run in the quote's own words, "I'm currently a senior shift manager over 3 supervisors." Concede by putting the numbers side by side and leaving them there: the role is twelve supervisors across four sites, and you are over three today. Then name only what your sentences carry: seven years in warehouse and distribution ops, and the site's peak-season surge plan, run two years running; describe it and let them draw the inference. Answer slot: if you have ever led more than three supervisors, or supervised across more than your own site, say how many and in what role, in your own words; if not, say so plainly and stay with the three. Follow-up ladder, each a plan and not a past: "What breaks first at four times the span?" and "How would you decide where to spend your first week across four sites?" For both, pick two or three things you would actually do first and say why, in your own words. Hold through both; do not add to what you run today | F3 is the widest gap against a numeric line in the JD and F1 compounds it, so this objection is the likeliest in any loop. JD because it scores the stated requirement; the Skeptic delivery is why it is first |
| A2 | "Our work is terminal operations. How does warehouse and distribution work carry over, and where doesn't it?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Describe the work at its own scope, "7 years in warehouse and distribution ops", the pick-path redesign and the surge plan, and let the interviewer draw the inference rather than asserting what it proves. Answer slot: the JD says terminal operations, so expect a probe on what of your work was like that. If some of it was, say which part and what was yours, in your own words; if none was, say so plainly and stay with warehouse and distribution | F1 is where the JD's wording and your material differ in kind of site, and a Skeptic opens on that difference. JD because the requirement is stated; the question is about fit, not a hypothetical |
| A3 | "The role asks for 5+ years of operations leadership. Of your seven years, how many were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | The question counts years, so the answer is a number and a title. Answer slot: if you can say how many of the seven years were in a role with direct reports, give the number and the role in your own words; if the number is below five, say it as a number and not an adjective; if you can't say exactly, say that plainly and say what you can point to. Do not stretch the seven years of field experience into a count of leadership years | F6 shows seven years in the field and a current people-leading role, not the split. JD because a stated minimum is being scored; asked as a count because that is how a stated minimum gets checked |
| A4 | "The JD lists Excel and Power BI. Where are you with Power BI?" | JD | [grounded] "never used Power BI"; "solid Excel" | Plain and short: "I've never used Power BI." Then the plan, stated as a plan: what you would build first and what you would learn first, in your own words, and how fast you expect to get useful. If you do a small hands-on before the interview, you may say only what you actually did. Then turn to the Excel half of the line: "solid Excel", at that scope. Answer slot: if you built a report or workbook that others used, say what it showed and who used it; if you used Excel for your own working and not for reports, say so plainly | F5 is a stated gap and F4 is thin, so the tool line is a free miss unless the plan is rehearsed. JD because the tool is a stated requirement |
| A5 | "Why this role, and why now?" | JD | [generic] | The reasons are yours; the pack has none to supply. Selection criteria: pick one reason tied to something in the JD (the four sites, the supervisor team, on-time performance and cost per shipment) and not to what Atlas could give you, and one that does not rest on criticizing your current employer. If no single reason comes to mind, say so plainly, then give the nearest honest one | F3 and F1 make the step-up the natural opening for a Skeptic, and a motive that sounds borrowed from the JD weakens the rest. JD because the motive is scored against the role as posted |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our terminals has dropped sharply over two weeks. Walk me through your first 48 hours." | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: how on-time is defined and measured here, and against what target. Objective: contain, then find cause. Segment: by shift, by inbound versus outbound, by customer, by cause code if there are any. Approach: pull the data before the hypotheses, talk to the supervisors on the affected shifts, separate a one-off from a trend. Metrics and risks: which two numbers prove it is fixed, and what you would not touch yet | A live problem from the JD's on-time performance line. CASE because it scores structure; generic because the pack has no Atlas-specific facts |
| B2 | "Cost per shipment has crept up for two quarters while volume is flat. Where do you look first?" | CASE | [generic] | Clarify what is in the cost and what the denominator is. Segment: labor, transport, handling, rework and claims, and mix shifts that move the average without anything getting worse. Say which you would check first and why, and challenge one premise respectfully, for example whether flat volume means flat mix. Name the trade-off with on-time performance before they do | The JD pairs cost per shipment with on-time performance, so a case that makes them pull against each other is likely. CASE; generic because it carries no claim about you |
| B3 | "A major customer tells you volume will be well above plan for the next six weeks at two terminals. What do you do this week?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure as a plan: confirm the numbers and the timing, find the constraint at each terminal, decide what gets added and what gets protected, tell the supervisors what changes on day one, and say what you would watch daily. You may say you ran the site's peak-season surge plan two years running, at that scope, and describe what you did in your own words. Answer slot: the JD's four sites make a probe on scaling the plan across sites likely. If your plan's reach went beyond your own site, say how; if it did not, say so plainly and say how you would extend it | F1 is the nearest evidence for the daily-operations line, and this case lets the surge plan be used honestly. CASE because it scores structure; the quote is the only part about your past |
| B4 | "What do you know about Atlas Freight, and what would you want to learn in your first two weeks?" | CO | [grounded] JD: "Operations Manager, Atlas Freight (regional logistics, 800 employees)" | The pack could not research Atlas, so the only company facts here are the JD's: regional logistics, 800 employees, four sites. Do the homework before the interview (their website, service area, any recent news, their careers page) and say only what you found. Then answer the second half as a plan: the first two weeks as listening and mapping the four sites before changing anything, in your own words. If you found nothing beyond the JD, say so plainly and put the weight on the learning plan | An interviewer at the company's altitude asks this almost regardless of round. CO because it tests homework; the pack's honesty about what it could not retrieve is part of the answer |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick figure was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Start with the sentence as it stands: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot, four parts, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Name the weakest assumption before they do; "I don't know how it was counted" is an honest answer, and the pack supplies no method, baseline or period | F2 is the only figure in your material, so it is the magnet for this style. EXP because it tests whether the claim survives scrutiny |
| C2 | "Could anything other than the pick-path redesign have moved that rate?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you know of anything else that could have moved the rate, say what it was and how you separated it out; if you do not know, or nothing else was in play, say so plainly. Return to the sentence: you cut the rate by redesigning the pick path. Do not add a cause, a control or a test you did not run | A follow-up that goes two levels deep on F2 is how this style checks attribution. EXP because it tests attribution, not the number itself |
| C3 | "What would you want on a daily dashboard for one terminal, and why those?" | JD | [generic] | Principles, not a past: a handful of measures and not twenty; what is leading and what is lagging; a clear link to the JD's two measures, on-time performance and cost per shipment; who sees it and how often it is reviewed. You may add that you would start in Excel, which you describe as "solid Excel", while you pick up Power BI; keep it as a plan | The JD's reporting line (F4, F5) invites a design question that tests judgment without needing the tool. JD because it scores the reporting requirement; generic because it makes no claim about your past |
| C4 | "Show me a report you've built in Excel that other people relied on." | JD | [grounded] "solid Excel" | The sentence you have is "solid Excel", and it carries no report. Answer slot: if you built a report or workbook that others used, say what it showed, who used it and how often, in your own words; if you did not, or it was not for others, say so plainly and say what you did use Excel for. Never describe a report you did not build | The JD's reporting line raises exactly this probe, and F4 is thin. JD because the question scores a stated requirement; the row's evidence is one phrase |

### D. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc whose beats are your own sentences at their own scope: seven years in warehouse and distribution ops; currently a senior shift manager over 3 supervisors; the pick-path redesign; the surge plan; the green belt. Employers, titles, dates and why you moved are yours to add; the pack has none of them. End on why this role, in one sentence of your own | The opener of almost any conversational round and the easiest one to waste. EXP because it asks you to account for your own history; F1 to F7 are the beats it can draw on |
| D2 | "What are you actually playing with in continuous improvement these days?" | JD | [grounded] "green belt certified" | Say what is true, at the scope of the sentence: "I'm green belt certified." Answer slot: if you are working on something now, or did a project with the belt, say what, in your own words; if not, say so plainly and say what you would pick up first. Do not describe a project you did not run | F7 is a plus in the JD, and casual questions about a plus are still scored. JD because the topic is the JD's plus-skill |
| D3 | "Tell me about the peak-season surge plan." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Tell it with the beats the sentence states: the plan was for the site's peak season, you ran it, and you ran it two years running. Say the rest only as you can stand behind it; the pack adds no results, numbers or specifics. If the next question asks what changed between the two years, answer from what you know, or say plainly that you would have to check | F1 gives this as the nearest daily-operations story. EXP because it checks what you actually ran |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, then hold on your own sentence: "I cut mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups by returning to it. Then concede specifically. Answer slot: if others contributed, say who and what, in your own words; if it was your design and no one else's, say so plainly. Never add a contribution the sentence does not carry | F2 is the line an attribution probe aims at. EXP because it tests precision about what was yours; Pressure is the delivery |
| E2 | "Sixty seconds: why you over a candidate who already runs several terminals?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | Do not claim to be better at multi-site work. Hold on what your sentences carry: seven years in warehouse and distribution ops, the pick-path redesign and the green belt. Concede the comparison in a clause: you are currently a senior shift manager over 3 supervisors, and the other candidate may run more. Then say in a sentence what you would do for the first month, as a plan | F1 and F3 make the comparison with a wider candidate the pressure line most likely to come. JD because it scores fit against the posted role; hold-then-concede is the type's bar |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | None of your quoted sentences carries this story, so this is a selection scaffold: pick a time that has a named stake, a moment you did not fold, and a working relationship intact at the end; say what was said and what happened, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Atlas's published values were not retrieved, so this uses the persona's standard prompt. VAL because the prompt asks for past behavior |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold: pick a time when the customer's need and a number you were measured on pulled apart, with a named decision and a named result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A customer-versus-metric tension is a natural fit for a role that owns on-time performance and cost per shipment. VAL because it asks for past behavior |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our terminal managers at neighbouring sites depend on each other. Where would you draw the line between your call and theirs, and what happens when you disagree?" | CASE | [generic] | Offer seam principles rather than pretending to know the seam: what is decided locally, what needs agreement across sites, and who breaks a tie. Then reciprocity: what you would bring to their sites, not only what you would need. This asks about no past, so it carries no claim | The JD's four sites imply neighbours, and a peer asks this. CASE because it is a live collaboration problem |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold: pick a time when the work crossed a team boundary and credit could have gone either way, say what you did about it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer probe. VAL because it asks for past behavior toward colleagues |

### Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| "Own daily terminal operations across 4 sites" | A2, B1, B3, B4, E2, G1 | F1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C3 | F2; C1 and C2 cover the one figure you gave |
| "lead a team of 12 supervisors" | A1, E2, G2 | F3 |
| "build reporting in Excel/Power BI" | A4, C3, C4 | F4, F5 |
| "5+ years operations leadership required" | A3, D1 | F6 |
| "Lean/Six Sigma a plus" | D2 | F7 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance defined here, and which of the four terminals is furthest from target today?" | It shows you would measure before acting, and the answer tells you the scorecard you would inherit |
| R2 | "How do the twelve supervisors report today, and what lives in Excel versus other tools?" | It puts the reporting stack on the table honestly, which is where your Power BI gap is, and tells you how steep the ramp is |
| R3 | "What would a good first ninety days look like, and a good first year?" | It makes the interviewer state the scorecard, which is what the rest of your answers are being held against |
| R4 | "How are the four sites different from each other?" | It signals multi-site thinking, which is the JD's heaviest line for you |
| R5 | "Where is the current team strongest, and where do you want this role to change things?" | It invites the interviewer to name the real brief, and turns the interview toward the work |
| R6 | "What support does a new operations manager get for learning the reporting tools and the sites?" | It addresses the Power BI gap as a plan rather than a defence |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or owned a team of twelve supervisors, or multi-site leadership | Inflated form of F3 and F1 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors". The limit is the pack's observation: your material says three, not twelve. The slot in A1 stays inside the three |
| Owned terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope, including "ran the site's peak-season surge plan two years running". The material says warehouse and distribution work and the site's surge plan |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path". The slot in the F2 row stays inside what you tracked |
| Has Power BI experience, including "familiar with" or "some exposure" | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Built reporting in Excel for others | Inflated form of F4 | F4's quote at its own scope: "solid Excel". The slot in C4 asks only what you built, and allows that there was nothing |
| Seven years of operations leadership | Inflated form of F6 | F6's quote at its own scope: "7 years in warehouse and distribution ops". The material shows the seven years, not how many were leading |
| The pick-path redesign was a Lean or Six Sigma project | Inflated form of F7 and F2 | The two sentences at their own scope, kept separate: "green belt certified" and "cut mis-pick rate 40% by redesigning the pick path" |

## Sources

Provided documents: the JD text and the background you wrote in your message. No dossier was present.

Searches sent, all refused by the host:

- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight regional logistics terminals news strategy` — refused

Fetches sent: none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have fed a values cheat sheet and the VAL bank; F1 and F2 in the VAL bank are generic instead |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have set persona weights from the actual loop; the Generic archetype fallback was used and the weights are flat with a tilt from the fit snapshot |
| 3. `Atlas Freight regional logistics terminals news strategy` | unavailable | Every call was refused. It would have grounded a CO and a CASE question in current priorities; B4 and the CASE bank are generic as a result |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The round type and who is interviewing you (hiring manager, panel, a site peer, recruiter) → reweighted personas, banks added or dropped, and a reverse question tied to the interviewer's own path if you have a name
- The recruiter's prep email, if there was one → coverage of any announced focus area, and a build section for any announced deliverable
- Your CV, or dates, titles and employers for the seven years → F1, F3 and F6 evidence graded on more than one sentence, and the answer slots in A1 and A3 closer to answers
- Your answers to the slots in A1, A3, A4, C1 and C4, in your own words → the fit rows F2, F3, F4 and F6 regenerated from what you said
- Your green belt certificate and project, if one went with it → F7 from medium to high
- Permission to search, or Atlas's careers page and values page pasted in → a values cheat sheet, Atlas-specific CO and CASE questions, and persona weights from the real loop; a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and recent organization context
- A tuesday-dossier.md from an earlier evidence review, if you have one → verified evidence, absolute do-not-claim items and a named top objection, instead of the ones this pack inferred
