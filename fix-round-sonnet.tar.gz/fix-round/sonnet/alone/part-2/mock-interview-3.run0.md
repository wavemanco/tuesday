I'll start by reading the reference files the skill points to.
Fixing a garbled row in the coverage table, then I'll present the pack.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-3-denied-8d866915/stripe_product-operations-manager_interview_pack.md`. It has 21 questions across seven interviewer styles, six reverse questions and an upgrade menu.

I built it from only the role, the company and "final round". I had no JD, CV or interviewer details, so the pack is generic.

I also couldn't research Stripe. All four web searches I tried were refused, so the pack states nothing about Stripe's values, interview loop or strategy. The research-dependent sections are missing, and the upgrade menu lists what they need.

The highest-priority prep is B1, "Which part of this role would you be weakest at on day one?" It comes with a fill-in-the-blank structure for answering it honestly.

Say the word and I'll play the Skeptic on B1, so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you know who you're meeting and in what role (hiring manager, peer, cross-functional), and has the recruiter said anything about focus areas or a deliverable? The answer reweights every question bank.
2. Can you paste the JD and your CV, or tell me to carry on without them? With them, the generic rows become real stories, and the answers get tied to your own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round. **Interviewer(s):** not given. **Relationship:** not given, so persona weights are flat-ish and the pack covers every plausible style. **Built from:** the role title, the company name and the round type only. No JD, CV, interviewer profile or recruiter guidance was supplied, and web research was not permitted in this session, so every question is `[generic]` and the fit snapshot is a worksheet. Nothing in this pack asserts a fact about Stripe or about you.

## How to use this pack

Personas describe how a question arrives (who is asking, in what register). Types describe what is being scored. Every question carries one of five tags:

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually you |
| JD | Role-driven: can you do the listed job, including its gaps |
| CO | Company and strategy knowledge: homework depth and altitude |
| CASE | Live problem from the role: structure and reasoning |

Guidance is scaffolding, not a script. Where a cell says to pick a story, the story has to be one you actually lived and can defend through three follow-ups. Question IDs run by persona in weight order (A to E, then G and H); the letter F is skipped so IDs never collide with fit-snapshot rows F1 to F6.

## Fit snapshot (worksheet)

No requirements text and no background were supplied, so every evidence cell reads `none given`. The requirements below are role-family prose with no source, labeled `[generic]`; they raise no answer slots. Paste the JD and CV and these rows become quoted and graded.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating cross-functional launches and programs (role-family, unsourced) | none given | none | [generic] | discovery | Strong evidence is a named launch or program, who was involved, and what part was yours. Selection scaffold: pick one program with a named stake and a date; if no such program comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F2 | Running planning cadences and operating rhythms (role-family, unsourced) | none given | none | [generic] | discovery | Strong evidence is a recurring review or planning process, how often it ran, and whether it was yours to design or yours to run. Selection scaffold: pick a recurring process you ran or changed; if none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F3 | Defining and tracking product or launch-health metrics (role-family, unsourced) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: how it was counted, what it is sensitive to, which part was yours. Selection scaffold: pick one figure you can defend; if none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F4 | Influencing product, engineering and go-to-market partners without direct authority (role-family, unsourced) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a partner team, what you did, and how the relationship stood afterwards. Selection scaffold: pick a real disagreement where you had no authority; if none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F5 | Designing and scaling processes and tooling (role-family, unsourced) | none given | none | [generic] | discovery | Strong evidence is a process you changed, what it replaced, and how you know it helped. Selection scaffold: pick one process change; if none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F6 | Clear written and verbal communication to leadership (role-family, unsourced) | none given | none | [generic] | discovery | Strong evidence is a brief, update or recommendation you wrote and who acted on it. Selection scaffold: pick one written artifact you can describe; if none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: launch readiness, metric diagnosis, operating-rhythm design | Medium-high. Reasoning: a manager-level operations role is usually scored on structure, and a hiring manager is a likely voice in a final round. The relationship is not given, so this is a prior, not a finding | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the gap between your background and the role, and of why here and why now | Medium-high. Reasoning: finals are where remaining doubts get tested, and with no CV the pack cannot yet say where yours sit | Rehearse the single most predictable objection until it is boring (B1); bridge only from experience you actually have; give a concrete ramp plan |
| Values/Behavioral | Scenario probes mapped to published values, in STAR shape | Medium. Reasoning: values and loop structure could not be researched, so whether a dedicated values round exists is unknown. Prepare stories either way | Choose real stories; "we" for context, "I" for contribution; pick stories where the hard truth actually landed |
| Peer Evaluator | Seam-splitting between product ops and adjacent teams, credit-sharing, collaboration | Medium. Reasoning: product ops sits between teams, so a peer-style conversation is plausible in any multi-session final | Reciprocity framing: what you bring their team; propose seam principles rather than claiming to know the seam |
| Data-Driven Prober | Line-by-line probing of any figure you cite | Medium. Reasoning: any figure you mention can be probed, and no CV is in hand to say which | Know what you can and cannot say about how each number was counted; say plainly when you do not know |
| Conversational/Rapport | Friendly openers, biography walk-through | Medium-low, but near-certain to occur in some form as an opener | Pre-script a 90-second arc; treat casual questions as scored |
| Pressure/Stress | Interruptions, time-boxing, challenge to motives | Low-medium. Reasoning: nothing in the inputs signals a stress style; included so you do not meet it cold | Pause, restate, hold a challenged position through two follow-ups before conceding anything real |

Depth follows weight: 4 questions for the two top personas, 3 for the mid group, 2 for the lowest. No loop source established how many sessions your final holds or who runs each, so these weights rest on a generic pattern, not on Stripe's documented process.

## Question banks

**Highest-ROI prep in this pack: B1.** The "weakest on day one" question is asked in some form in nearly every final, and it is where a rehearsed, non-defensive answer changes the interview. It is aimed at exactly the places this pack cannot see yet, so the guidance is a structure you fill in honestly.

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 cross-functional launches | A1, D1, G2 |
| F2 planning cadences | A1, A3, H2 |
| F3 metrics | A2, E1, E2, E3 |
| F4 influence without authority | B3, C3, D1, D2, D3 |
| F5 process and tooling | A3, B3 |
| F6 communication to leadership | A1, C1, C2 |

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A major launch is two weeks out and three teams each say they are not ready. What do you do first, and what do you need to know?" | CASE | [generic] | Clarify before structuring: what does ready mean, who decides, what is the cost of slipping versus shipping. Then structure: the real blockers per team, a single owner and date per blocker, a go or no-go rule agreed in advance, and a short written update to leadership. Challenge one premise aloud, such as whether all three blockers are equally launch-critical. The question needs no claim about your past, so the guidance makes none | Tests F1, F2 and F6 as a live problem; CASE because it scores structure, not history |
| A2 | "A key adoption metric for a recently launched product dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Clarify first: how the metric is defined, whether the data pipeline changed, the time window, the segments. Then split into measurement problem, mix shift, real behavior change, and external cause, and say which you would rule out first and why. Close with the next check and who you would tell | Tests F3; a classic ops diagnosis that rewards ruling out instrumentation before inventing a story |
| A3 | "Design the operating rhythm for a product org that has just doubled in size. What goes in first, and what would you deliberately leave out?" | CASE | [generic] | State the objective (fewer surprises, faster decisions), name two or three rituals with purpose and owner, and name what you would refuse to add because it costs more attention than it returns. Say how you would know it was working after a quarter | Tests F2 and F5; the "leave out" half checks that you treat process as a cost |
| A4 | "What is one thing about how this company ships products that you would protect, and one you would want to change?" | CO | [generic] | Web research was not available, so this pack cannot supply facts about Stripe. Do the homework yourself from the company's own public materials, say which are public facts and which are your inference, and be ready to say what you would need to learn before changing anything. Do not state a view of internal practice as fact | Slot for a differentiator question; stays generic and labeled as such until research runs |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Deepest rehearsal. Structure: name the real weak spot (a specific part of the role, not a virtue in disguise); say what is true about your current position on it; give a dated ramp plan for the first 30 days; and name who you would ask. Concession wording to fill in: "The part I would be weakest at on day one is ___. What I would do about it is ___." Hold the answer through two follow-ups by returning to the plan, never by adding experience you do not have. Answer slot for the weak spot: choose it from the JD once you have it; if you cannot name one honestly, say so plainly and name the part where you have least to point to | Likely in some form in the final round; the first thing a skeptic probes. Everything F1 to F6 asks is a candidate for the answer |
| B2 | "Why product operations, why here, and why now?" | JD | [generic] | Three beats in your own words: what pulled you toward product operations specifically, what about this company's public work interests you (from your own research, labeled as yours), and why the timing makes sense. Keep each beat to something you can be asked a second question on | Motivation consistency is the Skeptic's main scoring axis |
| B3 | "Product ops can be seen as overhead that slows teams down. How would you convince a skeptical engineering lead you are not that?" | JD | [generic] | Name what they would fear (meetings, reporting burden), then what you would do first (take work off their plate before adding any), and how you would show it: one lightweight mechanism, a clear opt-out, and a check at 30 days on whether they felt a difference. No claim about a past engineering partner is needed | Tests F4 and F5; JD because it scores a stated tension of the role |
| B4 | "Pick the part of your background furthest from this role. How does it transfer?" | EXP | [generic] | Selection scaffold: choose the experience that looks least related, state what you did in it in plain terms, then the one skill that carries over and the limit of the transfer. If no experience seems far from the role, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | The objection from any mismatch between background and role; the honest limit is part of the answer |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship still intact at the end. STAR shape; "we" for context, "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Persona stem; supports F6. Stripe's published values could not be fetched, so theme-matching them is left to the upgrade menu |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two actually pulled apart, what you gave up, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Persona stem; a customer-over-metric story is a standard values probe |
| C3 | "When did you deliver an unpopular truth to a peer team rather than to leadership?" | VAL | [generic] | Selection scaffold: pick a case where you had no authority over the peer team, what you said, how you said it, and what the relationship looked like afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Variation of the unpopular-truth stem aimed at influence without authority, F4 |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product ops and the product managers, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who owns the decision, who owns the process, how disagreements are escalated. Say what you would need to learn about how they work today before drawing any line | Tests F1 and F4; seam principles avoid claiming knowledge of a team you have not worked on |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a real shared piece of work, say what was yours and what was theirs, and how credit was named. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Persona stem; collaboration and attribution honesty, F4 |
| D3 | "What would you need from me in your first month, and what could you do that reduces my load?" | CASE | [generic] | Reciprocity first: two things you would do for their team in the first month, then a short list of what you would need, framed as questions you would bring. No claim about their load is needed | Peer evaluators price what the hire costs and gives them, F4 |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a number you are proud of from your work and walk me through how it was counted." | EXP | [generic] | Selection scaffold, four slots in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly and say what you would check. If no such figure comes to mind, say so plainly | Any figure you cite will be probed; F3 |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | The weakest-assumption move: name it before they do, in your own words, then say what you would do to test it. Do not name an assumption you did not actually make | Natural follow-up to E1; converts a gotcha into a credibility gain |
| E3 | "Which three metrics would you put on a launch-health view, and which would you refuse to track?" | CASE | [generic] | State the decision each metric serves, pair a leading with a lagging measure, and name one popular metric you would drop and why. Name what you would need to know about the product before finalizing | Tests F3 as a design question with no premise about your past |

### G. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Pre-script a 90-second arc in three beats: where you started, the one or two turning points, why this role. Use only things that are true and that you are ready to be asked a second question on | Casual openers are still scored; economy and coherence |
| G2 | "What would you want your first 90 days to look like here?" | JD | [generic] | Learn, then earn trust, then change one thing: who you would meet, what you would read, what small win you would look for, and what you would not change yet. Say the plan is a hypothesis to test with them | A casual-register question that scores role fit and humility, F1 and F2 |

### H. Pressure/Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over an internal candidate?" | EXP | [generic] | Pause, restate, then three beats you can back with something true: what you bring, what you would do first, and why the outside view helps. Do not disparage the alternative. If challenged, hold through two follow-ups, then concede specifically what you cannot yet know | Persona stem; tests composure |
| H2 | "Pick an outcome from your past. How much of it was actually you?" | EXP | [generic] | Selection scaffold: choose an outcome, say plainly which parts were yours, which were the team's, and which were luck or timing. Hold your account through two follow-ups; concede specifics explicitly rather than folding. If no outcome comes to mind, say so plainly | Attribution honesty under pressure; supports F2 and F5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does the team decide what product ops should not take on?" | Shows you think about scope as a cost, which suits a role that can sprawl |
| R2 | "What does a strong first 90 days look like, and how would you know at day 90 that it was working?" | Ties your plan to their definition of success |
| R3 | "Where do product and operational teams disagree most about process today, and how is that resolved?" | Opens the seam conversation on your terms and surfaces real tension |
| R4 | "Is there something the team tried that did not stick, and what did you learn?" | Invites candor and signals you expect to learn from failures |
| R5 | "How is the impact of product ops measured here, and who decides?" | Shows metric discipline; their answer tells you how the role is judged |
| R6 | "What would you want a new person to challenge?" | Signals independence with tact; a rapport-style interviewer weights this slot heavily |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your past that you cannot defend through three follow-ups | No background was supplied, so there are no sentences of yours to inflate and none is listed | Every story slot above is yours to fill from real experience, each with an honest branch for when no such time comes to mind |
| Any statement of fact about Stripe's values, strategy, loop or internal practice | Research could not run and none of it was provided | A claim you have read in Stripe's own public materials, labeled as yours, or a question you would ask |

## Sources

Provided documents: none.

Searches sent, all refused by the host (no permission granted), so no results were returned:

- Stripe operating principles values
- Stripe interview process product operations manager final round
- Stripe strategy 2026 annual letter
- Stripe Product Operations manager job description responsibilities qualifications

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Search refused. Would have produced the values cheat sheet and VAL theming by named value |
| 2. `Stripe interview process product operations` | unavailable | Search refused. Would have set persona weights from documented rounds |
| 3. `Stripe strategy` / recent news | unavailable | Search refused. Would have grounded A4 and a CO bank in current priorities |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Search refused. Would have turned F1 to F6 into quoted `[inferred]` rows |

## Upgrade menu

- JD text (or a link) → the six `[generic]` rows become quoted `[grounded]` rows, every JD requirement gets a covering question, and any gate such as location or work authorization surfaces
- Your CV or a few lines of background → the worksheet becomes a graded fit snapshot, selection scaffolds become story maps, and the prohibited list gets real entries
- Allowing web search → Stripe's published values, documented loop and current strategy, unlocking the values cheat sheet, loop-based persona weights and strategy-grounded CO questions
- Interviewer names and roles → an interviewer read and a reverse question tied to their path
- The recruiter's prep email → coverage of any pre-declared deliverable or focus area
- If your final is several sessions, send the schedule → per-session mini-packs with their own weights
- Prep time available → a prioritized triage schedule
- A `tuesday-dossier.md` from an earlier evaluation → verified evidence and a named top objection in place of the inferred one
