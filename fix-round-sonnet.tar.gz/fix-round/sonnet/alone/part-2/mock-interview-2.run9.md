I'll read the skill's reference files before building the pack.
Your prep pack is written, and I'm presenting it now. It's saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-2-denied-b650808e/atlas-freight_operations-manager_interview_pack.md`.

I didn't know the round type or who's interviewing you, so every persona (skeptic, case, prober, pressure, rapport, peer, behavioral) gets equal weight. That makes it a weaker pack than it could be. It has 22 questions, a fit snapshot against each JD line, reverse questions, and a list of claims I won't coach.

The web searches for Atlas Freight's values, interview process and strategy were all refused, so nothing in the pack about the company comes from outside your JD. That means no company-strategy or values questions. The pack's Sources section lists the three refused searches.

The pack calls A1 the highest-ROI prep. The question is "This role covers four sites and twelve supervisors. How does your current scope get you there?" It's the likeliest objection, because your material says 3 supervisors and one site's surge plan. The Power BI gap is covered separately in A3 and D3.

Say the word and I'll play the skeptic or the pressure interviewer on A1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting (hiring manager, a peer or site lead, skip-level, recruiter), and did the recruiter mention any focus areas or an exercise to prepare? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer and relationship: not known. Round type: not known. Built as a full-loop pack with flat persona weights, which is the weaker form; the upgrade menu says what would sharpen it.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Past behavior against the company's published values (none were available to this pack, so no question carries this tag) |
| EXP | Whether your claims survive scrutiny; what was actually yours |
| JD | A stated responsibility or qualification in the posting, gaps included |
| CO | Knowledge of the company's strategy (none: company research did not run, see Sources) |
| CASE | A live problem from the role, scored on structure |

An answer slot is an instruction for the interview, not a question for you here: answer whichever branch is true, from your own experience.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "ran the site's peak-season surge plan two years running" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says a shift manager over 3 supervisors and the site's surge plan; it says nothing about the number of sites or about terminals, and the words stay at that scope. Answer slot: the JD's "4 sites" makes a probe on scope likely. If anything you were responsible for sat outside the shift and the supervisors you have named, say what and in what capacity, in your own words; if nothing did, say so plainly and stay with the surge plan and the supervisors |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is a mis-pick rate, not on-time performance or cost-per-shipment, and the words stay there: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot, the four a figure raises: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours; if you do not know how it was counted, say so plainly. Second slot: if the mis-pick change showed up in any other measure your site tracks, say which; if it did not, or none was tracked, say so plainly and stay with the mis-pick rate |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The number in your material is 3, and the words keep it: say 3 supervisors as it is. Answer slot: the JD's 12 makes a probe on scale likely. If your role covered anyone beyond those 3 supervisors, say who and in what capacity; if it did not, say so plainly and stay with the 3. A plan for the larger team is said as a plan, never as a past |
| F4 | "build reporting in Excel/Power BI" — JD, the Excel half | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" does not show whether reporting is part of it, and no absence was stated. Answer slot: the JD's "build reporting" makes a probe on what you produce in Excel likely. Say what you use Excel for in your own words; if it includes work other people rely on, say what; if it is analysis for your own use, or nothing of that kind, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD, the Power BI half | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI or any BI tool, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Graded as an ordinary requirement, not a gate. Your material says 7 years in operations, and leadership only as your current role, with nothing on since when. Answer slot: expect a probe on which of the 7 years were leading others. Name each role and when it began, in your own words; if the years spent leading others are fewer than the JD's five, say the number plainly and stay with what you did in those years |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but nothing inspected stands behind the line (a certificate would raise it), so expect a probe. Lead with the quote's own terms: "I'm green belt certified." The quote does not name the body or the method, so say neither unless your certificate does |

## Persona table

Weights are flat because the round and the interviewer are unknown. Skeptic carries one extra question because its objection comes from the snapshot, not from the round.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of scope: four sites, twelve supervisors, reporting tools, years of leadership | Flat weight, extra depth. F1, F3, F5 and F6 are the rows where the material is thinnest, so these objections arrive from any interviewer | Rehearse A1 until it is boring: state your scope in your own words, hold, never enlarge |
| Case / Strategist (B) | Live problems from the role: diagnose on-time performance, cost-per-shipment, a new team | Flat weight. The JD's headline duties are operational, so cases on them are the natural test | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Data-Driven Prober (C) | Reads your lines closely and asks how the 40% was counted | Flat weight. F2's figure is the one quantified claim in the material, so it is a magnet | Know what you can and cannot say about the count; say plainly when you do not know |
| Pressure (D) | Time-boxed challenges on why you, how much was you, the Power BI gap | Flat weight. F2 and F5 give it direct material | Pause, restate, hold two follow-ups, concede only what is true and specific |
| Conversational (E) | A friendly biography question and a walk through the surge plan | Flat weight. Casual questions are still scored | Pre-script a 90-second arc from your own sentences |
| Peer (P) | Seam and credit questions between teams | Flat weight; likelier if you meet a site lead or another function | Offer seam principles, not claimed knowledge of their seam; reciprocity framing |
| Values / Behavioral (V) | Scenario prompts about unpopular truths, pushback, customers | Flat weight. No values-style round is documented: no company source was read | Pick stories where the hard truth landed; where none comes to mind, say so plainly |

## Question banks

Highest-ROI prep: A1. The scope jump from your current role to the JD's four sites and twelve supervisors will be raised in some form by any interviewer.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role covers four sites and twelve supervisors. How does your current scope get you there?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | Open with the two facts at their scope: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Say the numbers as they are and let the interviewer make the comparison. Hold by returning to those two facts, never by enlarging them. Follow-up 1, what has sat outside your shift and supervisors: answer slot, if anything did, say what and in what capacity; if nothing did, say so plainly. Follow-up 2, what you would learn first about the other sites: a plan, said as a plan. Follow-up 3, where you would be weakest on day one: name the one you would defend least, in your own words, then how you would close it | F1 and F3 are the widest distance between the JD's scope and the material, so this objection is the likeliest. JD because it scores a stated requirement; it gets the deepest rehearsal because the thinness is exactly where a stretched answer breaks |
| A2 | "Twelve supervisors is a bigger team than the one you lead now. What changes in how you lead?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Start from the quote: 3 supervisors. Answer slot: say in your own words what you do with those supervisors that would hold at twelve and what would not; if you have not thought it through at that scale, say so plainly and say what you would want to find out first. If your role covered anyone beyond those 3 supervisors, say who; if not, say so plainly | F3 is the scale gap. The question lets the candidate show judgment about scale without claiming it |
| A3 | "The role builds reporting in Excel and Power BI. What do you do with Excel today?" | JD | [grounded] "solid Excel"; "never used Power BI" | Say it in the quote's terms: "I'm solid in Excel." Answer slot: say what you use it for; if it includes work other people rely on, say what; if it is analysis for your own use, or nothing of that kind, say so plainly. If Power BI comes up, go straight to D3's acknowledgment and plan | F4 is thin and F5 is a stated gap. JD because it is the reporting requirement; asked gently here so D3 can rehearse it under pressure |
| A4 | "The role asks for five-plus years of operations leadership. Walk me through your seven years: what were your roles?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Tell the seven years as roles and dates, in your own words, from your own memory; the pack does not supply them. Answer slot: if the years spent leading others are fewer than the JD's five, say the number plainly and stay with what you did in those years, without relabeling them. If the leading years reach five, say which they were | F6 is a discovery gap: the material shows 7 years in operations but not how many were leadership. JD because it is a required line; asked as a walk-through because that is how it is probed |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four sites slipped last month. What do you need to know first, and how do you diagnose it?" | CASE | [generic] | Clarify before structuring: how on-time is defined and by whom, which lanes and days, since when, and whether the slip is beyond normal variation. Then objective, segments (inbound and outbound, by shift, by lane or customer, by dock), hypotheses, the measure that would confirm each, and risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's first headline duty (F2's requirement) asked as a live problem; CASE because it scores structure. Generic because it is a pattern, not a fact about this employer |
| B2 | "Cost-per-shipment is up. Where do you look?" | CASE | [generic] | Split the ratio first: total cost against shipments, and ask whether volume or cost moved. Then segment by site, by cost type and by shipment mix, separate controllable from not, and pick the one test to run first and say what result would change your mind. No claim about your past | F2's second measure, as a live problem. CASE because the scoring is the structure, not the answer |
| B3 | "You inherit twelve supervisors and two sites are lagging. What do your first thirty days look like?" | CASE | [generic] | Structure: what you ask first, what you observe before changing anything, which standards you would confirm, how you would split time across sites, and what you would report back. Said as a plan. No claim about your past | F3's requirement as a hypothetical, so the scale gap is answered with reasoning rather than a claimed history |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the figure in the quote's words. Answer slot: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly. Naming the weakest assumption yourself before they do is a credibility gain. Never supply a baseline or method you cannot repeat under a second question | F2's figure is the pack's one quantified claim. EXP because it tests attribution and counting |
| C2 | "Tell me about the metrics you're held to in your current role." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Choose an instance from your own work; the one the material carries is the mis-pick figure, said in the quote's words. Answer slot: expect a probe on the two measures the JD names; if either was part of your site's reporting, say which and how it was defined; if neither was, say so plainly and stay with the mis-pick rate | F2 is the evidence; the JD's measures raise the probe. EXP because it asks what you were actually accountable for |
| C3 | "Where have you applied your green belt?" | JD | [grounded] "green belt certified" | Start with the quote: "I'm green belt certified." Answer slot: if you applied it on a particular project, say which and what you did, in your own words; if the certification was not applied on a project, say so plainly and stay with the certification. Do not name a method or body the certificate does not | F7 is closed on the surface, with nothing inspected, so the probe goes to application. JD because "Lean/Six Sigma a plus" is a stated line |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who already runs several sites?" | JD | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | Three beats, one per quote, at their scope; sixty seconds is about three sentences. Hold through two follow-ups by returning to them. Concede one thing specifically: name, in your own words, the JD requirement you would have to grow into. Do not fold on the beats to restore harmony | F1 and F3 are the rows a rival with wider scope beats you on. JD because it scores fit to the stated role; the pressure is delivery |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence as it stands: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: which part was yours and which part others', in your own words; if others contributed, say who and what; if it was yours throughout, say so plainly. Concede only what you actually do not know, such as how it was counted | F2's figure under an attribution probe. EXP because it tests what was yours; pressure is the register |
| D3 | "You've never used Power BI and this job is built on reporting. Why should we take the risk?" | JD | [grounded] "never used Power BI"; "solid Excel" | Acknowledge it plainly: "I've never used Power BI." Then "I'm solid in Excel," at that scope. Then how you would learn it, said as a plan and never as exposure you have had. Hold through two follow-ups by returning to the plan | F5 is a stated gap. JD because it is a stated requirement; the honest acknowledgment is the rehearsal |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc with four beats, one per quote, in that order or yours, at their scope. The pack does not supply the links between them: no promotions, moves or reasons. Say those from memory or leave them out | The biography question is scored even when it feels casual. F1, F2, F3 and F6 supply the beats |
| E2 | "Walk me through the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The beats the sentence states: the plan, the site's, two years running. What the plan contained is not in the material, so rehearse it from your own memory; the pack does not supply it. Say what was yours and what was others' | F1's strongest line, and the likeliest follow-up to A1. EXP because it tests what you actually ran |
| E3 | "Why this role, and why now?" | JD | [generic] | Pick one line from the JD that draws you and say why in your own words, then why now. Say only what the JD tells you about Atlas (regional logistics, four sites, twelve supervisors); the pack could not verify more | The skeptic's motivation stem arrives casually as well. Generic because it makes no claim about the candidate |

### P. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Offer seam principles rather than pretending to know the seam: who owns the outcome, who owns the decision, and how a disagreement is escalated. Ask which teams touch yours. Say how you disagree, in a sentence that shows spine and tact | The seam probe is the peer's standard. Generic because it makes no claim about your past |
| P2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Use the sentence as it stands. Answer slot: if others contributed to the redesign, say who and what; if not, say so plainly. Credit naming others reads as precision, not weakness | F2 is the one story in the material that could involve other teams. EXP because it tests attribution style |
| P3 | "What would you need from me to succeed here?" | CASE | [generic] | Reciprocity first: what you would bring to their work, then two things you need, such as how they measure the sites and what they want flagged early. Ask rather than assume | A peer prices what a hire adds to their load. Generic because it makes no claim about your past |

### V. Values / Behavioral

No company values were available to this pack, so none of these is tagged VAL; they use the persona's own stems.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Choose an instance from your own work with a named stake, a moment you did not soften it, and a relationship still intact after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A behavioral stem; the pack has no story for it, so it gives selection criteria, not a story |
| V2 | "Tell me about a time a supervisor pushed back on a standard you set." | EXP | [generic] | Choose an instance from your own work: the standard, what the pushback was, what you held, what you conceded. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's supervisor-leadership line (F3's requirement) raises it. Selection scaffold because no quoted sentence carries it |
| V3 | "Tell me about a time you put a customer ahead of an internal metric." | EXP | [generic] | Choose an instance from your own work where the customer outcome and the internal number pulled apart, and say which you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A behavioral stem fitting a freight operation; scaffold only |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, B1, D1, E1, E2 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C1, C2 |
| "lead a team of 12 supervisors" | A1, A2, B3, D1, V2 |
| "build reporting in Excel/Power BI" | A3, D3 |
| "5+ years operations leadership required" | A4, E1 |
| "Lean/Six Sigma a plus" | C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four sites today, and which is hardest to move?" | Shows you think about the network, and the answer tells you whether the job is fixing or sustaining |
| R2 | "How is cost-per-shipment defined here, and who owns each part of it?" | Definitions decide what you would be accountable for; asking signals you will not quote a number without one |
| R3 | "What does the reporting setup look like today: what is in Excel, what is in Power BI, and who maintains it?" | Puts your Power BI gap on your terms and tells you the size of the ramp |
| R4 | "What would you want to have seen from me by day thirty and day ninety?" | Turns the interview into a plan and shows you are already thinking in outcomes |
| R5 | "How would you describe the supervisor team today: where is it strongest, and where do you want the next person to invest?" | Answers the scale question from F3 on their ground and shows you lead with the team |
| R6 | "Which site would you want me to spend my first weeks at, and why?" | Shows you plan to learn the sites before changing them, which is the honest answer to A1 |
| R7 | "What could a new person in this role do in their first month that would genuinely help your team?" | The reciprocity question for a peer or a site lead |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owns or has run operations across several sites or terminals | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material says a shift manager over 3 supervisors and the site's surge plan, not several sites. A1's slot stays inside the shift and the supervisors you named |
| Leads a large supervisor team, or a team of twelve | Inflated form of F3 | "currently a senior shift manager over 3 supervisors" at its own scope. A2's slot asks only who else your role covered |
| Drove on-time performance or cost-per-shipment down | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path" at its own scope: a mis-pick rate. C2's slot asks only whether the JD's measures were in your site's reporting |
| Built reporting or dashboards in Excel | Inflated form of F4 | "solid Excel" at its own scope. A3's slot asks only what you use Excel for |
| Has Power BI or other BI-tool experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Has five or more years of operations leadership | Inflated form of F6 | "7 years in warehouse and distribution ops" at its own scope. A4's slot asks only for your roles and dates |
| Holds a certification beyond a green belt, or one in a named method | Inflated form of F7 | "green belt certified" at its own scope; C3's slot asks only where it was applied |

## Sources

Provided documents: the job description text and your background summary, both in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused by the host before any result returned:

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight regional logistics terminals news strategy": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Search refused. Would have moved a values cheat sheet and VAL questions if a values round was documented; with nothing read, none is detected and no section was added |
| 2. `Atlas Freight interview process operations manager` | unavailable | Search refused. Would have moved the loop structure and the persona weights; no loop source establishes the loop, so weights are flat |
| 3. `Atlas Freight strategy` / recent news | unavailable | Search refused. Would have moved a CO question and a grounding brief; none was written |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Every fact about Atlas Freight in this pack comes from the JD text you gave.

## Upgrade menu

- Round type and who you are meeting (hiring manager, peer, site lead, skip-level, recruiter) → persona weights move off flat, banks are reordered and retuned
- The interviewer's name → an interviewer read, persona adjustments from their public footprint, and a reverse question tied to their path
- Anything the recruiter said about focus areas, a presentation or an exercise → coverage for it, and a build section if a deliverable was announced
- Company research (the values page, a strategy brief, or search access so it can run) → a CO question and grounding brief, and a values sheet if a values round is documented
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes; it needs search access to run
- Your own answers to the slots in F1, F2, F3, F4 and F6 (scope beyond your shift, other measures tracked, who else you led, what you use Excel for, which years were leadership), stated outside rehearsal → those rows regenerate on your words and some move off `discovery`
- A green belt certificate, or a sample of a report you built → F7 and F4 could move toward `high` confidence
- A `tuesday-dossier.md` from job-underwriter, if you have one → verified-evidence grading and a prohibited-claims list from the underwriter; never required
