I'll read the reference files the skill requires before building the pack.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-3-denied-38f8efc4/stripe_product-operations-manager_interview_pack.md`. I built it without a CV, a job description or an interviewer. I also assumed a hiring-manager-style final round with flat persona weights.

Web search was refused in this session, so the pack has no Stripe-specific content. It has no principles by name, loop structure or strategy. I didn't fill those in from memory. The pack has 20 questions, mostly live cases and open "tell me about a time" prompts. Each answer is a scaffold that ends with an honest fallback branch, because I have no sentences of yours to build on. The one I'd rehearse first is B1, "Which part of this role would you be weakest at on day one?" That choice rests on common patterns, not on evidence about you.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in this final round (future manager, peer, skip-level, cross-functional), and has the recruiter named any focus areas or a deliverable? Either answer reweights every bank.
Can you paste the job description and a CV, or a few lines on the work you'd lean on? Without them I'll keep going on the generic version.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager: final-round interview pack

Interviewer: not given. Relationship: not given, so this is a full-loop pack with flat persona weights. It is noticeably weaker than a pack built on a known relationship, and it is built from no CV, no JD and no research (web search was refused in this session), so almost everything below is `[generic]` rehearsal structure rather than Stripe-specific content.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge, and why this company |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Where a question asks about your past, the pack has no sentence of yours to build on, so each such answer is a selection scaffold that ends in an honest branch. Choose the instance yourself, in your own words.

## Fit snapshot (worksheet variant)

No CV and no JD were provided, so the evidence column is empty and the requirements are role-family prose, not quotes. The bridge column says what strong evidence would look like. None of these rows is a gate, because no term (location, authorization, schedule) was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating cross-functional launches or releases across product, engineering and go-to-market teams (role-family) | none given | none | `[generic]` | discovery | Strong evidence names one launch or release, the teams involved, and exactly which part was yours. Selection scaffold: pick one such instance from your own history; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run one |
| F2 | Using data and metrics to diagnose problems and prioritize (role-family) | none given | none | `[generic]` | discovery | Strong evidence names a metric you reported or analysed, how it was counted, and what it was sensitive to. Selection scaffold: pick one such metric; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F3 | Designing or improving processes and internal tooling for product teams (role-family) | none given | none | `[generic]` | discovery | Strong evidence names one process, what it replaced or fixed, and who adopted it. Selection scaffold: pick one such process; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would design one |
| F4 | Influencing senior stakeholders without formal authority (role-family) | none given | none | `[generic]` | discovery | Strong evidence names a disagreement, the stakeholder's position, and what moved. Selection scaffold: pick one such instance; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F5 | Clear written and verbal communication of priorities and trade-offs (role-family) | none given | none | `[generic]` | discovery | Strong evidence is a document or update other people acted on. Selection scaffold: pick one such piece of communication; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would structure one |

## Persona table

The loop is not established by any source (none was provided or readable), so the generic archetype applies: flat weights, said plainly. The three highest weights below come from the relationship prior for a final round, not from anything known about this loop.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live problems from the role: plan a launch, diagnose a metric | High: a final round for an operating role usually probes live reasoning, and the relationship is unknown so a hiring-manager prior is the safest assumption | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet probing of gaps and motivation | High: final rounds derisk gaps, and the fit snapshot has no evidence yet, so every row is a potential probe | Rehearse the most predictable objection until it is boring; say the limit plainly |
| Values / Behavioral (C) | Scenario prompts scored on behavior | Medium: no source says whether a dedicated values round exists, so it is not assumed | Pick stories your material actually carries; "we" for context, "I" for contribution |
| Data-Driven Prober (D) | Follows one claim two levels deep | Medium: operations roles lean on metrics, and probers read closely in later rounds | Know what you can and cannot say about how a number was counted, and say plainly when you do not know |
| Conversational (E) | Friendly, unstructured, still scored | Medium: casual openers occur in nearly every loop | A 90-second arc for "walk me through your journey"; treat casual questions as scored |
| Pressure (F) | Interrupts, time-boxes, tests composure | Low-medium: no signal of a stress style | Pause, restate, hold a position through two follow-ups before conceding anything real |
| Peer (G) | Seam-splitting, collaboration scenarios | Low-medium: depends on who the final-round panel is | Reciprocity framing; propose seam principles, not a pretended seam |

Highest-ROI prep: B1. This is chosen on role-family pattern, not on evidence about you, because no material about your background was given. Once you supply a CV or answers, the pack will name the objection your material actually raises.

## Question banks

Every row is `[generic]`: none of these questions rests on a fact about you, and none presupposes one.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks out and three teams give conflicting readiness signals. What do you need to know first, and what do you do?" | CASE | `[generic]` | Clarify before structuring: what each team means by ready, what the launch cannot slip on, who decides. Then lay out how you would reconcile the signals, what you would put in front of the decision-maker, and what you would track daily. Name one premise of the question you would test | A live problem from the role family (F1); CASE because it scores structure, not history |
| A2 | "A key adoption metric for a recently shipped feature drops 20 percent week over week. Diagnose it." | CASE | `[generic]` | Clarify: definition, instrumentation, time window, segments. Separate data problems from real change, then test product, seasonality and release causes in order. End with what you would report and when | Stem from the Case persona; covers F2 |
| A3 | "Design how product teams and go-to-market teams learn about roadmap changes. What do you ask first?" | CASE | `[generic]` | Ask who needs what, how fast, and what breaks today. Propose a minimal cadence and a single source of truth, then say how you would know it works and what you would cut if no one used it | Process-design problem; covers F3 and F5 |
| A4 | "Product teams say a process you own adds friction, but the data suggests it prevents errors. What do you do?" | CASE | `[generic]` | Hold the data question open: how errors were counted and what the process costs. Then split the options into keep, simplify or remove, and say how you would decide with the teams, not for them | Tests judgment and influence together; covers F3 and F4 |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | `[generic]` | Pick the area where your material is thinnest and say so plainly, then give a concrete ramp plan for the first weeks. Do not claim a competency you cannot defend on a second question, and do not volunteer a weakness you do not have | Highest-ROI prep: this question or a close variant is asked in most final rounds, and a calm, specific answer changes the tone of the interview |
| B2 | "Why product operations, and why now?" | JD | `[generic]` | Give your own reasons in order: what draws you to the function, what changed, what you want next. Keep it to the real motive; a rehearsed motive that contradicts your history is the one that breaks | Motivation consistency is the Skeptic's main score |
| B3 | "Why Stripe, specifically?" | CO | `[generic]` | Use only reasons you can personally stand behind and have checked. This pack holds no Stripe facts, so no company detail is supplied here; add two or three from Stripe's own pages once you have read them | CO because it scores homework; generic because research was unavailable |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | `[generic]` | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stem from the Values persona; covers F4 |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | `[generic]` | Selection scaffold: a specific decision, who the customer was, what the metric cost, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stem from the Values persona |
| C3 | "Tell me about a time you had to get several teams to change how they worked." | VAL | `[generic]` | Selection scaffold: what the teams had to give up, how you learned their constraints, what you did when someone resisted, and what stuck. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | Covers F1, F3 and F4 |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number you have reported. Walk me through how it was counted." | EXP | `[generic]` | Choose one you can defend. Say how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours. If you do not know how part of it was counted, say that plainly | Defend-the-number move; covers F2. The pack cannot name your assumption, so it is yours to find |
| D2 | "Tell me about an analysis you ran yourself, start to finish." | EXP | `[generic]` | Selection scaffold: the question, the data, the method, the answer, and what changed because of it. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run one | Prober stem; covers F2 |
| D3 | "A dashboard you rely on disagrees with a team's own numbers. How do you resolve it?" | CASE | `[generic]` | Clarify definitions and sources first, reconcile a sample by hand, then agree one definition with both owners. Say what you would not do, which is pick a winner before knowing why they differ | Live problem; no claim about your past |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | `[generic]` | Build a 90-second arc from your own history: where you started, two or three turns, and why this role is the next one. Keep to what you can talk about for two minutes if asked | Stem from the Conversational persona; scored despite the casual register |
| E2 | "What are you working on or learning at the moment?" | JD | `[generic]` | Name something real, and be ready for a follow-up on it. If nothing comes to mind, say so plainly and name what you would pick up first in this role | Casual questions about role-relevant topics are scored |
| E3 | "What would you most want to get done in your first ninety days?" | JD | `[generic]` | Frame it as learning first, then one or two small wins, and say what you would need from others. Avoid promising specifics about a team you have not seen | Tests realism about the role; covers F1 and F5 |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | `[generic]` | Hold-then-concede: state what you bring in your own words and hold it through two follow-ups, concede specifically what an internal candidate knows that you do not, and never fold the core claim to restore harmony | Stem from the Pressure persona |
| F2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | `[generic]` | Choose a result you can attribute precisely. Say what you did, what others did, and where the line sits. Honest, specific attribution holds up better than a large claim | Attribution probe; covers F1 |

### G. Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | CASE | `[generic]` | Propose seam principles instead of pretending to know the seam: who owns the decision, who is consulted, how you escalate. Offer what you would bring to their team, not only what you need | Stem from the Peer persona |
| G2 | "How do you handle credit when work spans teams?" | VAL | `[generic]` | Selection scaffold: an instance where credit was shared, what you did to make it visible, and how the other team responded. If no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stem from the Peer persona |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 cross-functional launches | A1, C3, E3, F2 |
| F2 data and metrics | A2, D1, D2, D3 |
| F3 process and tooling | A3, A4, C3 |
| F4 senior stakeholders | A4, C1, C3 |
| F5 communication | A3, E3 |
| Motivation and fit | B1, B2, B3, E1, F1 |
| Defend-the-number on CV metrics | none, because no CV was given; D1 is the generic form |

## Reverse questions

No interviewer information was given, so all of these are role-generic.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first six months look like for this role, and how will you know?" | Shows you think in outcomes, and gives you the scoring criteria |
| R2 | "Which teams does this role work with most, and where is the working relationship hardest today?" | Signals you expect friction and want to find it early |
| R3 | "What is a process or decision here that you wish worked better than it does?" | Invites a candid answer and shows operator instincts |
| R4 | "How does the team decide what product operations should and should not take on?" | Tests scope discipline, which this kind of role usually needs |
| R5 | "What is something you have changed your mind about since joining?" | Turns the interview into a conversation and tells you how the team thinks |

## Prohibited claims

Nothing about your background was provided, so there is no wording of yours to inflate and nothing to list as an inflated form. The two standing limits are these.

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your past experience, results or ownership | No CV or answers were provided, so no sentence of yours exists to support one | Selection scaffolds and answer-in-your-own-words instructions only. Once you give material, it enters the fit snapshot verbatim and the rows regenerate |
| Specific Stripe facts: principles by name, loop structure, strategy or figures | Research was refused in this session and model memory is not a source for these | Left out. B3 is a scaffold that asks for reasons you have checked yourself |

## Sources

Provided documents: none.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values or operating principles | unavailable | Search refused. Would have supplied official value names for a values cheat sheet and VAL mapping |
| 2. Stripe interview process, product operations | unavailable | Search refused. Would have supplied documented loop structure and persona weights |
| 3. Stripe strategy and recent news | unavailable | Search refused. Would have grounded the CO and CASE bank in current priorities |
| 4. Interviewer name and Stripe | n/a | No name was given |
| 5. Representative Product Operations Manager JD | unavailable | Search refused. Would have turned the role-family requirements into quoted, inferred JD rows |

Queries sent, all refused: "Stripe operating principles values"; "Stripe interview process Product Operations Manager"; "Stripe strategy news 2026"; "Stripe Product Operations Manager job description responsibilities".

## Upgrade menu

- The job description text → the five role-family rows become quoted requirements, JD-tagged questions are re-aimed at its own lines, and any gate (location, authorization, schedule) gets surfaced
- Your CV or a few sentences about relevant work → every fit-snapshot row gets your own words, story-mapped guidance replaces the selection scaffolds, and the highest-ROI objection is chosen from your evidence
- Who you meet and in what role (manager, peer, skip-level, cross-functional) → persona weights and banks restructure
- The recruiter's prep email, including any pre-declared deliverable → coverage of what is graded; usually one email to the recruiter
- The interviewer's name → an interviewer read and a reverse question tied to their path
- Permission to search the web, or pasted text from Stripe's principles page and interview guidance → values cheat sheet, grounded CO and CASE questions, loop-based persona weights; a deeper pass would add up to 6 more searches and 2 more fetches and take several more minutes
- Prep time available → a prioritized schedule
- A prior `tuesday-dossier.md`, if you have one → verified evidence and constraints carried in; not required
