I'll read the reference files the workflow requires before writing anything.
Web search was refused all three times, so I'm building the pack from the JD and your background alone and labelling what that costs. Writing it now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-2-denied-0f0d0a13/atlas-freight_operations-manager_interview_pack.md`. It has 20 questions, a fit snapshot mapped to the JD, and a list of claims it won't coach.

I built it without knowing the round or who you're meeting, so the persona weights are flat. That makes it weaker than a pack built for a known round. My three web searches on Atlas were refused, so everything about Atlas comes from the JD alone. Your answers to the Atlas questions will be thinner as a result.

The pack's top rehearsal is A1. It covers the jump from 3 supervisors to 12 and will come up in some form whoever is asking. The other two places the JD outruns your background are Power BI and how many of your 7 years were in a leadership role. Those need honest, short answers settled before the interview.

Say the word and I'll play the Skeptic on A1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Do you know whether you're meeting your future manager, a peer, or a recruiter, and did the recruiter mention any focus areas or a task to prepare? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack — Operations Manager, Atlas Freight

Interviewer: unknown. Relationship and round type: unknown, so this is a full-loop pack with flat persona weights, which is noticeably weaker than a pack built for a known round. Nothing here about Atlas beyond what the posting itself says: the web searches were refused (see Sources).

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Rehearse aloud. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your background survives scrutiny; what was actually yours |
| JD | A stated requirement in the posting, including where you are thin |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem from the actual role, reasoned aloud |

An answer slot is an instruction for the interview, not a question for this chat. It gives two honest branches: say what you did, or say plainly it was not yours or did not exist, and return to what your own words already carry.

## Prep triage (interview next week)

1. A1, until the answer is boring. It is the pack's highest-ROI prep.
2. A3 and A4: settle your true answers on leadership years and on Power BI, and say them aloud twice.
3. C1 and D2: how the 40% was counted and which part was yours.
4. B1 to B4: say each case aloud once, thinking out loud, clarifying first.
5. E1: the 90-second walk-through of your background.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says a shift manager over 3 supervisors and 7 years in warehouse and distribution ops; it says nothing about terminals or a number of sites, and the words stay there: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's 4 sites makes a probe on multi-site scope likely. If any of your responsibility reaches beyond the shift you manage, say what, in your own words; if none does, say so plainly and stay with the shift and the 3 supervisors |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The quote is a surge plan, not an on-time result, and your material does not show whether on-time was measured. Answer slot: the JD's on-time line makes a probe on that likely. If on-time was part of how the plan was judged, say how it was defined and what it showed, in your own words; if it was not, say so plainly and stay with the plan: "I ran the site's peak-season surge plan two years running." |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | The quote is a mis-pick rate, not a cost result, and your material shows no cost figure. Answer slot: the JD's cost-per-shipment line makes a probe on cost likely. If any cost figure was attached to the pick-path change, say what it counted and how it was counted, in your own words; if none was, say so plainly, stay with the mis-pick rate, and say what you would measure first |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors; the posting says 12. The words stay at the quote: "senior shift manager over 3 supervisors." The limit is the pack's observation, not words for you. Answer slot: if any supervisors beyond those 3 reported to you or were coordinated by you in some capacity, say who and in what capacity; if none were, say so plainly and stay with the 3 |
| F5 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a skill statement, and your material does not show reporting built. Answer slot: if you built any reporting in Excel, say what it showed and who used it, in your own words; if you used Excel for other work, say that; if no reporting was built, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives 7 years in ops and a current supervisory role, and does not show how many of the 7 years were in leadership. Answer slot: say which of those 7 years were in a management or supervisory role and under what title, in your own words; if some were not, say so plainly. Give the number as it is; do not round it up |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it, so expect a probe. Lead with it in its own words: "green belt certified." Your material does not show which body issued it or whether the pick-path work used it. Answer slot: if the pick-path redesign used any of what the training covered, say which tools and how; if the two were separate, say so plainly |

No requirement in the posting is a gate as defined for this pack: F7's five years is a length-of-experience line, graded as an ordinary row.

## Persona table

Weights are flat: no relationship or round type was given, and no loop source establishes the loop, so the fallback archetype is Generic (screen, hiring manager, panel) and its flat weights apply. The reasoning is shown so you can recalibrate if you know who is asking.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the distance between the posting and your background | High: the posting's 12 supervisors and 4 sites against F4 and F1, and its Power BI line against F6, are visible to anyone who reads both. Five questions | Rehearse A1 until it is boring; name your limit before they do; bridge only with what your own sentences carry |
| Case / Strategist | Live operations problems from the posting's own lines | High: "own daily terminal operations" and "drive on-time performance and cost-per-shipment down" are live-problem material for any interviewer. Four questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Goes line by line through your numbers | Medium: the 40% mis-pick figure is the one quantified result in your background. Three questions | Know what you can and cannot say about how it was counted; say plainly when you do not know |
| Pressure | Interrupts, time-boxes, asks how much was actually you | Low: no signal either way; three questions as insurance | Pause, restate, anchor in what you said, hold through two follow-ups before conceding anything real |
| Conversational | Friendly walk-through-your-journey and what-do-you-know questions | Medium: possible if a recruiter or HR screen is in the loop; unknown. Three questions | A 90-second arc built from your own sentences; treat casual questions about Lean and the company as scored |
| Peer | Seam-splitting between sites, credit, collaboration | Low: the posting names 4 sites, so a peer site lead in the loop is possible; nothing confirms it. Two questions | Reciprocity framing; propose seam principles rather than pretending to know the seam |

No values-style round is detected: no loop source was read and the Generic archetype assumes none. D3 carries one behavioral item as insurance.

## Question banks

Highest-ROI prep: A1. The 3-to-12 supervisor jump is visible from the posting and your background alone, so it will be asked in some form whoever is in the room.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role leads 12 supervisors across four sites, and you're a senior shift manager over 3 supervisors. What makes you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The deepest rehearsal in the pack. Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Name the difference in scope yourself, before they do: 3 today, 12 in the posting, in those terms and without apology. Then give a plan for the first weeks, said as a plan: what you would ask each site's supervisors, what you would watch first. Answer slot: if any supervisors beyond those 3 reported to you or were coordinated by you in some capacity, say who and in what capacity; if none were, say so plainly and stay with the 3. Hold through two follow-ups by returning to the 3, never by adding to them | F4 is the widest gap between the posting and the material and the likeliest first objection; JD because it scores the stated team-size requirement |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "7 years in warehouse and distribution ops", "never used Power BI", "currently a senior shift manager over 3 supervisors" | Choose one weakness you can speak to honestly and name it first. Your material shows three places the posting reaches past it: Power BI, 12 supervisors, and terminal operations across 4 sites. If Power BI: "I've never used Power BI." If scale: "I'm currently a senior shift manager over 3 supervisors." Then a ramp plan, as a plan. Answer slot: if any of your 7 years touched terminal work, say what; if none did, say so plainly and stay with "7 years in warehouse and distribution ops" | F1, F4 and F6 are the three rows where the material stops short, and a Skeptic asks you to pick; JD because it scores the posting's own requirements |
| A3 | "The posting asks for five-plus years of operations leadership. How many of your seven years were in a leadership role?" | JD | [grounded] "7 years in warehouse and distribution ops" | Open with the quote: "I have 7 years in warehouse and distribution ops." Answer slot: say which of those years were in a management or supervisory role and under what title, in your own words; if some were not, say so plainly. Give the number as it is, not rounded up; the interviewer will do the arithmetic whatever you say | F7 is a required line whose evidence does not show the split between roles; JD because it scores a stated qualification |
| A4 | "Power BI is in the posting. Have you used it?" | JD | [grounded] "never used Power BI", "solid Excel" | Plain acknowledgment first: "I've never used Power BI." Then Excel in its own words: "solid Excel." Answer slot: if you built any reporting in Excel, say what it showed and who used it; if none, say so plainly and stay with "solid Excel". Close with a plan for learning Power BI. If you spend time with it before the interview, you may say what you did and only that | F6 is a stated gap and F5 the only adjacent evidence; JD because it scores the reporting requirement |
| A5 | "Why this role, and why now?" | JD | [generic] | Selection scaffold. Pick the reason that is actually yours, and tie it to a specific line of the posting (the four sites, the 12 supervisors, on-time, cost per shipment) rather than to the title. Say what you know about Atlas only from the posting; no research on the company ran. If your honest reason is mostly "the next step", say that plainly, then say what you want from the role | Motivation consistency is the Skeptic's standard probe; JD because the answer should land on the posting's own lines; generic because it carries no claim about you or Atlas |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four sites has slipped over the past month. Walk me through your first 48 hours." | CASE | [generic] | Clarify before structuring: what on-time means here and how it is measured, since when, and what changed. Then objective, segmentation (by shift, by lane, by inbound versus outbound, by day), approach, the daily numbers you would want, and the risks of acting too fast. Think aloud and say the structure before using it. The question needs no claim about your past, so the guidance makes none | The JD's on-time line (F2's requirement) as a live problem rather than a record; generic because it is a pattern for the problem, not a fact about Atlas |
| B2 | "Peak volume will exceed capacity at two of your four sites next quarter. Sketch the plan." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Use your own sentence once, as it stands: "I ran the site's peak-season surge plan two years running." Then solve this case as a structure, not a memory: clarify the constraint, set trigger points, decide what gets protected first, plan how supervisors across sites are briefed, define the review. Challenge one premise, such as whether the two sites are the only ones at risk. Do not import details of your own plan beyond the sentence; describe what you did in your own words | F2's quote is the nearest evidence for a capacity case; CASE because it is a hypothetical at four sites, which the quote does not cover |
| B3 | "Cost per shipment is rising and on-time is flat. Where do you look first?" | CASE | [generic] | Define the denominator first: what counts as a shipment and which costs are in the figure. Then break the figure into components, check whether the shipment mix changed, and decide which one comparison across sites would be fastest to run. Say what you would want to see before acting. No claim about your past | The JD's cost-per-shipment line (F3's requirement) as a live problem; generic because it is a role-family pattern |
| B4 | "You're handed reporting for four sites. What do you build first, and what do you look at every day?" | CASE | [grounded] "solid Excel", "never used Power BI" | Say what you would define before building anything: the measures, their definitions and who reads them. Say where you would start, as a plan: "I'd start in Excel, which I know" (your words: "solid Excel"), and where you would learn Power BI: you have "never used Power BI," so the plan is a plan. Choose the daily measures from the posting's own lines: on-time and cost per shipment | F5 and F6 together: the posting's reporting line is answered as a plan from the one adjacent strength; CASE because it asks for a design, not a history |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the figure in your own sentence: "cut mis-pick rate 40% by redesigning the pick path." Answer slot, in your own words: how the rate was counted, what the figure is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F3's quote is the one quantified result in the material and the natural target of a prober; EXP because it tests whether the number survives |
| C2 | "Did the pick-path change show up in cost, and if so how?" | EXP | [inferred] "cut mis-pick rate 40% by redesigning the pick path" | Stay with the quote: "cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's cost-per-shipment line makes this probe likely. If any cost figure was attached, say what it counted and how it was counted; if none was, say so plainly and say what you would measure first. Do not tell them what the quote is evidence of; describe what you did and let them draw the inference | F3's thin bridge, rehearsed so the honest answer is ready; EXP because it tests what the number does and does not reach |
| C3 | "Was on-time performance part of how you judged the surge plan?" | EXP | [inferred] "ran the site's peak-season surge plan two years running" | Open with the quote: "I ran the site's peak-season surge plan two years running." Answer slot: if on-time was part of how it was judged, say how it was defined and what it showed; if it was not, say so plainly, say what was watched if anything, and stay with the plan | F2's quote touches the JD's on-time line without showing it; EXP because it separates what was measured from what was run |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "7 years in warehouse and distribution ops", "ran the site's peak-season surge plan two years running", "cut mis-pick rate 40% by redesigning the pick path", "green belt certified", "currently a senior shift manager over 3 supervisors" | Pause, restate the question, then two of your own sentences in their own words, and one specific concession on scope: 3 supervisors today against the posting's 12. Then one sentence on what you would do first, as a plan. Stop. Hold through two follow-ups without adding to the quotes; concede only what is true and specific | F4 and F7 are where a time-boxed challenge lands; JD because the answer is scored against the posting; Pressure because the format is the test |
| D2 | "That mis-pick result — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold: "cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which part of the redesign was yours, in your own words; if others did parts, or the work was shared, say so plainly. Precise attribution held calmly beats a bigger claim defended badly | F3's quote carries the verb "redesigning", and the first follow-up tests whose redesign it was; EXP because it scores attribution |
| D3 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Selection scaffold, under a time-box: pick an occasion with a named stake, a moment you said the hard thing, and what happened afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not borrow an ending your own account does not have | Behavioral insurance in a pressure register; EXP because it scores your past behavior, with no published values to map; generic because no claim about you is made |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path", "ran the site's peak-season surge plan two years running", "green belt certified" | A 90-second arc using only those sentences' beats: the 7 years, the current role, the two results as stated, the certification. End on why this role, from A5's honest answer, in your own words. Nothing added between the beats | The biography question is scored even when it feels casual; EXP because it tests whether your account matches your background |
| E2 | "You're green belt certified. Where has that shown up in your work?" | JD | [grounded] "green belt certified", "cut mis-pick rate 40% by redesigning the pick path" | Say it as it stands: "green belt certified." Answer slot: if the pick-path redesign used any of what the training covered, say which tools and how, in your own words; if the certification and that work were separate, or it has not shown up in your work, say so plainly | F8 is the posting's plus; JD because it scores a stated preferred qualification |
| E3 | "What do you know about Atlas so far?" | CO | [grounded] | No research on Atlas ran, so this pack holds only what the posting says: "regional logistics, 800 employees", four sites, a team of 12 supervisors. Say those, say where they come from, and say plainly what else you have read, if anything, and where. Do not guess at strategy, customers or news | The only company-knowledge question the pack can support; grounded in the JD alone, and thin because of it |

### G. Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites sit side by side — where's the seam between mine and yours, and what happens when we disagree?" | CASE | [generic] | Propose principles instead of pretending to know the seam: who owns what at the boundary, how shared capacity gets decided, what gets escalated and when. Reciprocity: what you would bring their site, not only what you would need. No claim about your past | The posting names 4 sites, so a seam question is plausible if a peer is in the loop; generic because nothing is known about Atlas's sites |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick an occasion where work crossed teams, where you can say who did what, and where the credit was visibly shared. "We" for context, "I" for your contribution. If no such time comes to mind, say so plainly, then say how you would handle it | Credit probes appear in peer conversations; EXP because it scores your account of shared work |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites | A2, B1, B2, G1 |
| Drive on-time performance | B1, C3 |
| Cost-per-shipment down | B3, C2 |
| Lead a team of 12 supervisors | A1, D1 |
| Build reporting in Excel/Power BI | A4, B4 |
| 5+ years operations leadership | A3, D1, E1 |
| Lean/Six Sigma a plus | E2 |
| Company and strategy knowledge | E3 — thin: no research ran |
| The 40% mis-pick figure (headline metric) | C1, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance mean here — which measure — and how do the four sites compare today?" | It defines the metric before trying to move it, and the posting's on-time line makes it the natural first thing to ask |
| R2 | "What does the supervisor team look like across the sites — where is it strongest, and where does it need the most support?" | The posting says 12 supervisors; asking about them is the honest way to address the jump from your own team |
| R3 | "What reporting exists today, and what would you want rebuilt in the first six months?" | It addresses the Excel and Power BI line as a question about the job, and invites them to say what level of Power BI they expect |
| R4 | "What would a strong first 90 days look like, and how would you and I know?" | It turns the interview into a shared definition of success and shows you are already planning |
| R5 | "Where do the four sites differ most in how they run?" | Handles the four-site scope by asking, not by claiming |
| R6 | "What is the biggest operational problem you want solved that isn't in the posting?" | It invites what the posting leaves out and shows you are listening for the real brief |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Used or built anything in Power BI | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never used Power BI." No slot |
| Led or ran 12 supervisors | Inflated form of F4 | F4's quote at its own scope: "senior shift manager over 3 supervisors." The limit is the pack's observation: your material says 3, the posting says 12 |
| Owned terminal operations or ran multiple sites | Inflated form of F1 | F1's quote at its own scope: "currently a senior shift manager over 3 supervisors." Your material says warehouse and distribution, not terminals |
| Drove on-time performance | Inflated form of F2 | F2's quote at its own scope: "ran the site's peak-season surge plan two years running." C3's slot asks only what the plan was judged on |
| Cut cost per shipment | Inflated form of F3 | F3's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path." C2's slot asks only what was counted |
| Led Six Sigma projects, or holds a belt beyond the one stated | Inflated form of F8 | F8's quote at its own scope: "green belt certified." E2's slot asks only whether the training showed up in the pick-path work |
| Has five or more years of operations leadership | Inflated form of F7 | F7's quote at its own scope: "7 years in warehouse and distribution ops." The limit is the pack's observation: your material does not show how many of those years were leadership; A3's slot asks for the split in your own words |

## Sources

Provided documents: the JD text as pasted, and your background as described in your message. No CV, no interviewer information, no recruiter guidance, no dossier.

Searches sent, all refused by the host before returning anything:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy recent news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call refused. Would have moved: a values cheat sheet, if the company's published values and a values-style round were found |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call refused. Would have moved: loop structure and persona weights, which now rest on the Generic archetype |
| 3. `Atlas Freight regional logistics strategy recent news` | unavailable | Every call refused. Would have moved: E3 and a strategy-grounded CASE question, which stay thin and generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting and the round type → personas reweighted from flat to the real relationship, and a tailored reverse question
- The recruiter's prep email, if there is one → coverage of any stated focus areas or a task to prepare
- Your full CV → the fit snapshot's evidence cells quoted from CV lines instead of your message; F8 and F7 can rise from medium once there is a certificate or a dated role history to point to, such as the green belt certificate or the dated shift manager appointment
- Your own words for the answer slots in F1 to F5 and F7 → those rows become quoted material and the affected questions regenerate
- Web search access for Atlas → a values page, documented loop structure, and recent strategy, which would upgrade E3 and the CASE bank; a deeper pass would add up to 6 more searches and 2 more fetches, several more minutes
- A `tuesday-dossier.md` from the job-underwriter → verified evidence per requirement, a sourced list of prohibited claims, and a named top objection, instead of ones inferred here
