I'll read the reference files the skill requires before writing anything.
Saving is done; I'm running a quick formatting check on the pack file (stray brackets, pipes inside cells) before presenting it.
Your prep pack for Priya's conversation with Dan is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-1-denied-31a69558/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. I built it as a single peer conversation with no announced deliverable or focus areas, since your note named none.

- **What's in it:** 23 questions across six personas (data-driven prober, peer evaluator, skeptic, case/strategist, conversational, pressure). Each has a type tag, answer guidance and a rationale. The pack also has a fit snapshot, a reading of Dan, requirement coverage, six reverse questions, a not-to-claim list and sources.
- **Highest-ROI prep:** C1, the "no classic sales-ops or quota-setting experience" objection from a Sales Strategy peer. A1, the ~$400M figure, is the question most certain to come.
- **No values questions:** no values-style round is detected and I couldn't get Northwind's published values, so behavioral probes are tagged EXP.
- **Search was refused:** both lookups (Northwind's values and Dan's public footprint) were denied in this session. The interviewer read rests only on the profile you gave me, and the strategy section rests only on your research note, whose date I don't have.
- **Quotes and gaps:** the answer guidance quotes only your descriptions of Priya, and where those don't cover a probe it leaves an answer slot for her to fill in her own words. The gaps most likely to be probed are partner-motion design, GTM ownership and the independent SQL/Tableau work.

Say the word and I'll play Dan as the skeptic on C1, or as the prober on A1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Did the recruiter say anything about focus areas, format or an announced case or deliverable? Any of those would reweight the banks.
2. Can you paste the JD and Priya's CV as written? That would turn the paraphrased requirement and evidence quotes into verbatim ones, or say skip and I'll keep them as they are.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer who reports to the same VP. **Round:** one 60-minute conversation.

Built from the coach's summaries: JD highlights, a candidate summary, an interviewer profile summary and a research note. No full JD text, no CV text and no recruiter guidance were supplied. Every quote below is from those summaries, and "the coach's notes" names them as the origin.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. The guidance cells are scaffolding for a spoken answer, not a script: say the quoted facts in your own words and fill each answer slot truthfully, including the branch where the practice was not yours or never existed.

| Tag | Name | What it scores | Questions in this pack |
|---|---|---|---|
| VAL | Behavioral / values alignment | Past behavior against the company's published values | none: no published values were obtainable and no values round is detected, so behavioral probes sit under EXP |
| EXP | Work-experience deep-dive | Whether the claims survive scrutiny, and what was actually yours | A1, A2, B2, B3, B5, C5, E1, F1 (8) |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included | A3, A4, B1, B4, C1, C2, C3, E2, F2 (9) |
| CO | Company and strategy knowledge | Homework depth and strategic altitude | C4, D4 (2) |
| CASE | Hypothetical / live problem | Structure and reasoning on a live problem | A5, D1, D2, D3 (4) |

Each question carries one primary tag; a second angle, where there is one, is in the rationale.

## Fit snapshot

No row below is a gate: the JD highlights contain no term that is met or not met, and "experience required" in F4 is a length-of-experience style requirement, not a credential.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights in the coach's notes | "set annual volume targets with cross-org consensus" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The material shows targets set and a change proposed, not a GTM strategy and not a new product line, and nothing inspected sits behind either line. Words stay at the quotes' scope: "I set annual volume targets with cross-org consensus" and "I proposed a store-surface change, and the ARR uplift was credited to it." Answer slot: the JD's two new product lines make a probe on launching something new likely. If either the targets or the proposal concerned a product that was new when you worked on it, say which and what part was yours; if neither did, say so plainly and stay with the targets and the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights in the coach's notes | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | The quote touches revenue uplift and does not show whether the proposal came from finding an unserved stage or segment. Answer slot: the lifecycle wording makes a probe on how the opportunity was found likely. If the proposal rested on analysis you ran, say what you examined and what was yours; if it did not, or the analysis was someone else's, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights in the coach's notes | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | discovery | A self-described skill with no artifact behind it, and it does not show whether analysis was run independently. Words: "I'm skilled in SQL and Tableau." Answer slot: expect a probe on one analysis you did yourself. If you wrote the queries or built the dashboards behind any analysis, name one and say which parts; if that work was done by others, say so plainly and say what you did do |
| F4 | "partner-motion design experience required" — JD highlights in the coach's notes | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The quote is a model and its use in negotiations; the material does not show the design of a partner motion, and the pack does not bridge to it. Words at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: say which parts of the model you built yourself and whether you were in the negotiations; if parts were others' or you were not in the room, say so plainly and return to the model |
| F5 | "strong cross-functional influence" — JD highlights in the coach's notes | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a line from the coach's notes with nothing inspected behind it, so expect a probe on how consensus was reached. Lead with the quote's own terms: annual volume targets, set with cross-org consensus. Answer slot: if any org disagreed, say which and what moved the outcome; if none did, say so plainly and stay with the quote |
| F6 | "AI experience a plus" — JD highlights in the coach's notes | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | The quote gives frequency and says nothing about what the tools are used for, so it is a lead and never a claim of AI product or GTM experience. Words: "I use AI tools daily." Answer slot: say what you use them for and what you check yourself; if the use is general rather than part of analysis or strategy work, say so plainly |
| F7 | Fluency in how a sales organisation sets and carries targets, which a Sales Strategy peer is likely to assume; no JD line supplies it, so it is the pack's role-family reading of the interviewer's function | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap the coach's notes state outright. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. F5's quote concerns annual volume targets, which the pack does not equate with quota-setting. No slot and nothing added to make the gap smaller |
| F8 | "Senior GTM Strategy Lead, Emerging Products" — role title in the coach's notes | "2 years strategy consulting at a top firm" — the coach's notes; "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The quotes show consulting and product strategy and ops in consumer tech; the material does not show a go-to-market role. Words at their scope: "two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops." Answer slot: the title's GTM wording makes a probe on which of your work touched going to market likely. If any did, say which part and what was yours; if none did, say so plainly and stay with the strategy and ops work |

## Grounding brief

Compact, from the coach's research note only. The note's date and sources were not given, and the lookups meant to check currency were refused, so treat currency as unverified. Use this for vocabulary; do not correct Dan with it.

| Topic | What the note says | Provenance | How to use it |
|---|---|---|---|
| Priority 1 | Enterprise expansion | [grounded] | Use "expand" in the JD's land/adopt/expand/renew language when answering D1 and D3 |
| Priority 2 | An AI copilot launch, named Compass | [grounded] | Name it as Compass; frame E2 and D1 around it without claiming you have shipped a copilot |
| Priority 3 | Reaching profitability | [grounded] | Make capacity and pricing trade-offs explicit in D3 and D2 |
| Competitive threat | Bundling by a much larger platform vendor | [grounded] | The premise of D2; ask Dan how it shows up in deals rather than asserting detail |

## Reading the interviewer

Public footprint was not retrieved (lookup refused); this read uses only the profile summary in the coach's notes.

| Observation | Source | Provenance | Implication |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | interviewer profile summary in the coach's notes | [grounded] | Expect every figure to be probed to its assumptions; rehearse A1 and F1, and say plainly where you do not know how a number was counted |
| Career spine is pricing and monetization roles | interviewer profile summary in the coach's notes | [grounded] | Case questions arrive in pricing, packaging and unit-economics terms (D2, D3). Mirror opportunity, shared vocabulary only: pair his monetization path with "built a partner-level revenue model used in carrier negotiations" (F4), told at that scope and without claiming pricing work |
| One early-stage-startup chapter | interviewer profile summary in the coach's notes | [grounded] | A probe on working with thin resources and no playbook is plausible (C5). No mirror opportunity is offered, since no snapshot row carries your side of a startup jump |
| A peer reporting to the same VP | the coach's notes | [grounded] | He is pricing what you add to or take from his work (B1, B4); bring reciprocity, not only needs |

## Persona table

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Data-Driven Prober | Line-by-line probing of the ARR figure and the revenue model, then analytical hypotheticals | High. The peer relationship prior pairs Peer Evaluator with Prober, and a self-description of "relentlessly data-driven" moves the Prober up | Know what you can and cannot say about how each figure was counted; name the weakest assumption you know of before he does; say plainly when you do not know | A (5) |
| Peer Evaluator | Seam-splitting between GTM and Sales Strategy, "what do you need from me", credit and disagreement | High. He is a peer under the same VP, which is the relationship prior | Reciprocity framing; propose seam principles rather than pretending to know the seam | B (5) |
| Skeptic | Quiet probing of the missing sales-ops and quota experience, partner-motion depth, and why B2B | High. F7 is a stated gap and F4 is adjacent to a requirement marked required, and a Sales Strategy peer owns the territory F7 concerns | Rehearse C1 until it is boring; build bridges only from the quotes; calibrated candor, not bluffing a competency he owns | C (5) |
| Case / Strategist | Live GTM, pricing and packaging problems on the stated priorities | Medium. His pricing and monetization spine tilts cases toward pricing angles, and the JD asks for GTM ownership, but a single peer conversation is less case-led than a hiring-manager round | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case | D (4) |
| Conversational / Rapport | An opener such as "walk me through the journey", casual AI question | Low as a style, but E1 is close to certain as a question; casual questions are still scored | A 90-second arc built only from the quoted career facts; treat the AI question as scored | E (2) |
| Pressure / Stress | A time-boxed "why you" and an attribution challenge | Low. Peer rounds are collegial, and nothing in the profile summary signals interruption or stress style | Pause, restate, hold through two follow-ups, concede specifically | F (2) |
| Values / Behavioral | Not a separate style here | None detected: your words establish a single conversation with Dan, no loop source documents a values round, and no published values are in hand | Behavioral probes arrive inside B2, B3 and B5 as open prompts | none |

## Question banks

The highest-ROI prep in the pack is C1. F7 is a stated gap, it sits in the interviewer's own function, and F1 and F4 are adjacent rather than direct, so some form of C1 is the most predictable objection. A1 is the most certain question given Dan's self-description. No rationale below restates your history; each refers to snapshot rows.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're credited with a ~$400M ARR uplift from a store-surface change you proposed. How was that number counted?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the quote says, in your own words: you proposed the change and the uplift was credited to it. Hold that scope. Answer slots, each in your own words: how the figure was counted; what it is most sensitive to; the assumption behind it you would defend least; which part was yours beyond the proposal. If you do not know how it was counted, say so plainly, which is an honest answer. If the part beyond proposing was someone else's, say so plainly and return to the proposal. Naming the weak assumption before Dan does turns the probe into credibility | F1 and F2 carry the figure, and a data-driven peer goes to the headline number first. EXP because it tests attribution and counting, not the JD |
| A2 | "Walk me through the partner-level revenue model you built and how it was used in the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Describe the model at the quote's scope: you built it and it was used in carrier negotiations. Answer slot: expect a probe on what you built yourself; say which parts of the model were yours and how you built them, in your own words, and if inputs or logic came from others, say so plainly and name what was yours. Answer slot: say whether you were in the negotiations; if you were not, say so plainly and describe what you know of how the model was used. Hold through two follow-ups by returning to the model, never by adding to it | F4 is the nearest evidence to the partner requirement and F3 to the independent-analysis requirement, so this probe tests both. EXP because it checks what was actually yours; the JD angle is secondary |
| A3 | "Pick one analysis you're proud of and tell me how you did it, tool by tool." | JD | [grounded] "skilled in SQL/Tableau" | Say the skill at its own scope: "I'm skilled in SQL and Tableau." Then choose an instance with a named question, the data you worked from, what you found and what changed as a result; it should be one where you wrote the queries or built the dashboards yourself. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry or how you would do it. Never describe tooling you did not use | F3 is a self-description with nothing inspected, and the JD names SQL and Tableau for independent analysis, so a data-driven peer will test it. JD because it scores the stated requirement; open prompt so the guidance is a scaffold, not a story |
| A4 | "What does whitespace across land, adopt, expand and renew mean to you, and how would you measure it for a new product line?" | JD | [grounded] | Make no claim about your past. Define each of the four stages in the JD's order, say what you would want to count at each and what data you would need, then ask Dan which stage he sees leaking most today. State your hypothesis early and name one assumption you would test first | F2 is the requirement; the lifecycle words are the JD's, so the answer should use them. JD with CASE delivery, because it is scored as a structured definition |
| A5 | "An expansion number is up 15 percent quarter on quarter. What do you want to see before you believe it?" | CASE | [generic] | A hypothetical, so no claim about your past. Clarify first: what is counted, over what base, and what changed in the period. Then check definition changes, mix shift, a few large accounts, timing and seasonality, and say which two checks you would run first and why. Ask where the data lives | A self-described data-driven peer is likely to test skepticism toward a number, and F3 is where this tests the claimed skill. CASE because it is a live diagnosis; generic because it is a pattern |

### B. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your GTM work and my Sales Strategy work, and what happens when we disagree?" | JD | [grounded] | No claim about your past. Propose seam principles rather than pretending to know the seam: who owns the customer motion, who owns the targets, who decides trade-offs, and how disagreements escalate to the shared VP. Ask Dan where the seam sits today. Say how you would disagree: with data first, in private, with a named decision owner | F5 is the requirement and F7 is the territory he owns, so the seam question is where both meet. JD because the cross-functional line is the JD's; the peer persona sets its tone |
| B2 | "Tell me about a time you got several orgs behind a number." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the targets were annual volume targets and consensus was cross-org, which are the beats the quote states; tell them in your own words. Answer slot: the JD's influence line makes a probe on where orgs disagreed likely; if some did, say which and what moved the outcome, and if none did, say so plainly and stay with the quote. Do not add a conflict or a resolution you did not describe | F5 is the evidence for the influence requirement. EXP because it tests what was yours; an open prompt from the JD's own line |
| B3 | "How do you handle credit when work spans teams?" | EXP | [generic] | Select one instance where work spanned teams. It needs a named stake, what was yours and what was others', and how credit was recorded. If no such time comes to mind, say so plainly and describe how you would handle it. Link it to how you would answer A1 and F1: say what was yours precisely, which signals you are safe to partner with | A peer evaluator checks whether you will share credit. EXP because it asks for a past instance; generic because the stem is a pattern and the guidance is a scaffold |
| B4 | "What would you need from me and my team in your first ninety days, and what would you give us?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau" | Reciprocity framing. What you need: a walkthrough of how targets and coverage work today and access to the data. What you offer, at the quotes' scope: you built a partner-level revenue model that was used in carrier negotiations and you are skilled in SQL and Tableau; ask what his team would use. Do not offer more than that | Peers weigh what the hire adds to their load. F7 makes asking for a walkthrough natural, and F3 and F4 supply the offer. JD because it scores the cross-functional requirement |
| B5 | "Tell me about a time a peer team showed you something your analysis had missed." | EXP | [generic] | Select an instance with a named stake: what you believed, what the other team showed you, and what you changed. If no such time comes to mind, say so plainly and describe how you would respond. The point scored is whether you reduce or add to a peer's load when you are wrong | Disagreement style with equals is what a peer evaluator scores. EXP because it asks for a past instance; generic because the pack holds no quote for it, so the guidance is a scaffold |

### C. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You don't have classic sales-ops or quota-setting experience. How do you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus" | The highest-ROI rehearsal in this pack, with the most follow-up levels. Level 0: say the plain acknowledgment first, in your own words: "I don't have classic sales-ops or quota-setting experience." Then the quote at its scope: "I set annual volume targets with cross-org consensus." Then a ramp plan said as a plan: ask Dan's team to walk you through how targets and coverage work, and learn that before proposing anything. Follow-up 1, "So what makes you credible with sellers?": hold by returning to the quote, without adding a sales claim. Follow-up 2, "Isn't that a big gap for a GTM lead?": concede specifically that this is the part you would learn from his side first, and do not fold on what the quote carries. Follow-up 3, "What would you want from me?": ask for the walkthrough and offer what B4 offers. Never imply that volume targets were quotas | F7 is a stated gap in a peer's own function, and F1 and F4 are adjacent rather than direct, so this is the most predictable objection. JD because it probes a requirement gap; the Skeptic persona sets the delivery |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | You may name the stated gap in your own words: "I don't have classic sales-ops or quota-setting experience." If a different requirement is weaker in your own view, name that instead and say plainly what you have not done. Follow with how you would close it as a plan. Pick one; naming three reads as listing | F7 is the likeliest answer, but the honest weakest point is yours to choose. JD because it scores the requirement list; a quieter variant of C1 |
| C3 | "The role requires partner-motion design experience. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: say which parts of the model were yours and whether you were in the negotiations; if parts were others' or you were not in the room, say so plainly and return to the model. If Dan presses on the motion itself, return to the model and its use, and say you would want to learn how his side runs partner motion. Hold through two follow-ups; concede what you do not know | F4 is adjacent to a requirement marked required, so this is the second likeliest objection. JD because it is the stated requirement; the question's premise is the JD's, and the guidance does not adopt it |
| C4 | "Why this role, why Northwind, why now, and why leave consumer tech for B2B data infrastructure?" | CO | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Your reasons are yours; the pack does not know them. Answer slot: say what you are moving toward and why, in your own words; if you are still testing something, say plainly what. Anchor Northwind in what the note supports: the enterprise expansion, Compass and profitability priorities, and the bundling threat, and say these as what you understand, open to correction. Say the nine years at their own scope: nine years at a large consumer-tech company in product strategy and ops. Do not claim GTM experience to explain the move | A career change from consumer tech to B2B data is the standard motivation probe. CO first because it needs company knowledge; JD second because it tests fit with the role. F8 is the background it presses on |
| C5 | "You've spent nine years inside a large company. Emerging products here means ambiguity and thin resources. How do you work without a playbook?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Select one instance from your own material where you proposed or set something without a ready template; it needs a named stake, what you did, what you could not do yourself, and what happened. The quote "proposed a store-surface change credited with a ~$400M ARR uplift" says you proposed it, and the pack adds no missing playbook to it. If no such time comes to mind, say so plainly and describe how you would work with thin resources | The interviewer read notes a startup chapter that makes a pace and resourcing probe plausible. F8 is the evidence the premise rests on. EXP because it asks for a past instance |

### D. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Compass is launching. Sketch the GTM: who do you sell it to first, how is it packaged, and what do you need to know first?" | CASE | [grounded] | No claim about your past. Clarify first: is it sold standalone, as an add-on or inside existing plans, who the first segment is, and what the success measure is. Then objective, segments, motion across land, adopt, expand and renew, pricing and packaging, metrics, risks, including the bundling threat. Challenge one premise respectfully. Say what you would ask Dan's team for | The note names the Compass launch as a priority, and F2 and F6 are the requirements it tests. CASE because it is a live problem on the stated roadmap; the premise is the note's, and the pack does not add facts about Compass |
| D2 | "A much larger platform vendor starts bundling a competing capability into what customers already pay for. How does that change pricing and packaging for the new product lines?" | CASE | [grounded] | Hypothetical, in Dan's pricing language. Clarify what is bundled and for whom. Then hypotheses: where the bundle cannot match, which segments are most exposed, how to position price against a bundled one, what to package differently, and what you would stop doing. State one assumption you would test with data. Take a position and concede one cost of it | The note names bundling as the main competitive threat, and Dan's pricing spine makes this his native ground. CASE because it is live; CO second because it tests the strategic frame |
| D3 | "Two new product lines, limited sales capacity, and a profitability target. How do you decide where to point sellers first?" | CASE | [grounded] | Hypothetical. Clarify capacity, margin per line and what sellers already carry. Frame the choice by expected value per unit of seller time, with stage in land, adopt, expand or renew as one axis. Say what data you would pull and what you would test first. Ask Dan how coverage is set today, since that is his territory | F1 and F7 meet here: GTM strategy for two lines, in a space where sales capacity is Dan's. The profitability priority comes from the note. CASE because it is a live allocation problem |
| D4 | "Enterprise expansion, the Compass launch and profitability: which pulls hardest against the others in GTM, and where do you land?" | CO | [grounded] | Pick one tension and name it, say where you land and what it costs you, and say it is a hypothesis you would correct with Dan's data. Do not claim inside knowledge of Northwind's plans. Concede one thing the other priorities would lose under your position | The three priorities are from the note, and a peer at the same VP can check whether you think at the company's altitude. CO because it tests strategy knowledge; CASE second because it asks for a position under trade-offs |

### E. Conversational / Rapport Builder (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc built only from the quotes: two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Add the three pieces of work at their own scope, each in one sentence: the revenue model used in carrier negotiations, the annual volume targets set with cross-org consensus, the store-surface change you proposed. Answer slot: why this role, in your own words. Add no transition or motive the pack has not been given | Almost certain in some form in a 60-minute conversation, and it sets the frame for every probe after it. F8 is the evidence. EXP because it checks that the story survives; the conversational register is the delivery |
| E2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Say the quote at its scope: "I use AI tools daily." Answer slot: say what you use them for, what the tool did and what you checked yourself; if the use is general rather than part of analysis or strategy work, say so plainly. Do not suggest you have built or launched an AI product. If Compass comes up, ask what the team is learning about how customers use it | F6 is a low-confidence lead, so it is coached as a question-shaped answer. JD because the plus-skill is the JD's; asked casually, it is still scored |

### F. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate the question, then hold the quote: "I proposed the change, and the uplift was credited to it." Hold through two follow-ups by returning to the proposal, never by adding to it. Concede specifically: answer slot, say which parts after the proposal were yours; if none were, say so plainly. Say also what you do not know about how the figure was counted, if that is true | The attribution probe is the standard stress stem and F1 and F2 carry the figure. EXP because it tests attribution; Pressure sets the delivery |
| F2 | "Sixty seconds: why you over someone who has carried a quota?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | Concede first, plainly: "I don't have classic sales-ops or quota-setting experience." Then two facts at their scope: you set annual volume targets with cross-org consensus, and you built a partner-level revenue model used in carrier negotiations. Do not say what that proves; let Dan draw the inference. Close with what you would ask his team for in the first weeks | A time-boxed version of C1 in the pressure register. JD because it scores fit against the requirements; F7 is the gap it presses on |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1: own GTM strategy for two new product lines | D1, D2, D3 |
| F2: identify whitespace across land/adopt/expand/renew | A4, D1 |
| F3: run independent analysis in SQL and Tableau | A2, A3, B4 |
| F4: partner-motion design experience required | C3, A2 |
| F5: strong cross-functional influence | B1, B2, B3, B4, B5 |
| F6: AI experience a plus | E2, D1 |
| F7: sales-organisation target fluency (role-family reading) | C1, C2, F2 |
| F8: Senior GTM Strategy Lead, Emerging Products | E1, C4, C5 |

## Reverse questions

| # | Question | Why it lands | Basis |
|---|---|---|---|
| R1 | "Your path runs through pricing and monetization roles, with an early-stage chapter. When a new product line is priced and packaged, where does Sales Strategy's view end and the GTM lead's begin?" | Ties to his own career and turns the seam question into a peer conversation | [grounded] |
| R2 | "What could a new person in this seat do in the first month that would genuinely help your team?" | The reciprocity question for a peer; it signals you are thinking about his load | [generic] |
| R3 | "Where do Sales Strategy and the emerging-products seat disagree most often today, and how does the VP settle it?" | Shows you expect a seam and have a view on resolving it | [grounded] |
| R4 | "What would success look like at six months for this role: adoption, expansion, or something on the profitability side?" | Maps to the three priorities in the note and shows you are scoping the job | [grounded] |
| R5 | "How are you seeing bundling by larger vendors show up in deals, and what is it changing in how you price?" | Asks a data-driven pricing person for his view of the stated competitive threat | [grounded] |
| R6 | "What data would I have access to on day one, and where are the gaps you would most like closed?" | A data-driven peer weights this slot, and it shows the SQL and Tableau work is real to you | [generic] |

## Prohibited claims

Claims this pack will not coach, built from the snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has set sales quotas or has quota-setting experience | Negative the coach's notes state, F7 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." No slot |
| The annual volume targets were quotas | Contradicted by the F7 quote | The F7 quote alone; nothing is added to it |
| Owned or delivered the ~$400M ARR uplift | Inflated form of F1 and F2 | The quote at its own scope: proposed the change, and the uplift was credited to it. The limit is the pack's observation: the material says proposed and credited, not delivered or measured. A1 and F1 slots stay inside the proposal |
| Owned GTM strategy for a product line, or launched a product | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material shows targets and a proposal, not a launch |
| Designed a partner motion or owned a partner program | Inflated form of F4 | F4's quote at its own scope: a model, and its use in negotiations. A2 and C3 slots stay inside the model |
| Led or ran the carrier negotiations | Inflated form of F4 | F4's quote: the model was used in negotiations; whether you were in them is the slot in A2 and C3 |
| Runs independent end-to-end analysis in SQL and Tableau | Inflated form of F3 | F3's quote: "skilled in SQL/Tableau". A3 stays a scaffold |
| Has AI product or AI GTM experience | Inflated form of F6 | F6's quote: uses AI tools daily. E2's slot asks only what for |
| Has go-to-market experience from the consumer-tech years | Inflated form of F8 | F8's quotes at their scope: product strategy and ops. The limit is the pack's observation |

## Sources

**Provided:** the coach's message, containing JD highlights, a candidate summary, an interviewer profile summary and a research note. No full JD, CV text, recruiter guidance or dossier was supplied; no dossier was consumed.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Query or call | Outcome |
|---|---|
| Northwind Data company values | refused |
| Dan Kovac Northwind Data Director of Sales Strategy | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have supplied published value names, which could theme VAL questions and could change the values-round finding; no VAL questions were written |
| 2. `Northwind Data interview process` for the role family | skipped | Your words fix the loop as one 60-minute conversation with a peer, which fixes the persona weights and the session structure |
| 3. `Northwind Data strategy` and recent news | skipped | The research note supplies current priorities and the competitive frame for the grounding brief and the CO and CASE questions; its age was not given |
| 4. `Dan Kovac` at Northwind Data | unavailable | The search was refused. It would have supplied talks and writing for the interviewer read and a sharper reverse question |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights supplied fix the fit snapshot and the JD-tagged questions; only highlights, so the upgrade menu asks for the full text |

## Upgrade menu

- Full JD text → the F1 to F6 requirement quotes become verbatim, and any mid-list requirement the highlights omit gets a question and a coverage row
- CV text as written → evidence cells quote it directly; a document, dashboard or review in which the ~$400M figure was recorded, or the revenue model itself, would raise F1, F2 and F4 from medium toward high
- Your own answers to the slots in F1 to F4 and F6 → those discovery and transferability rows are regenerated from your words, and A1, A2, A3, C3 and E2 become story-mapped
- Anything the recruiter said about focus areas or a deliverable → coverage for a pre-declared deliverable, and a reweighting if a case is announced
- Permission for web search → the values and interviewer lookups refused here run, giving a real interviewer read and a tailored reverse question; the same grant would also allow one deeper research pass, up to 6 further searches and 2 further fetches and several more minutes, to build a fuller strategy brief for the CO and CASE banks
- The research note's date and sources → the grounding brief can be checked for currency
- A tuesday-dossier.md from an earlier evidence pass, if you have one → verified evidence, per-area strategy limits and a named top objection replace the inferred ones
