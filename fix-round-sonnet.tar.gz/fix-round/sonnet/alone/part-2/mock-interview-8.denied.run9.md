I'll read the reference files before building the pack.
Your prep pack is saved as /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-denied-d8121be6/ashgrove-credit-union_member-experience-lead_interview_pack.md. It has one mini-pack per round, each with its own question bank, persona weights and reverse questions. I built it from your pasted material only and sent no searches. Your note didn't name the interviewers, so there is no interviewer read.

Say the word and I'll play the Skeptic on C1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Built 11 November 2026 for three rounds on 20 November 2026 (loop mode).

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Conversation about the process |
| 2 | Head of Member Services, your would-be manager | 45 minutes | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; "the values round", scored against the four values |

Interviewer names are not assigned yet, so there is no interviewer read. Persona weights rest on each round's relationship and on the recruiter's own description of it.

## How to use this pack

- Personas are how a question is asked. Types are what is being scored. Every question carries one of each.
- Type key: VAL is values alignment against Ashgrove's published values. EXP is a deep-dive on your own experience. JD is a stated role requirement. CO is company and strategy knowledge. CASE is a live problem.
- Guidance is scaffolding, not a script. Say it in your own words.
- An answer slot is an instruction for the interview, not a question for this chat. Where the pack cannot know what you did, it gives two branches: say what you did, or say plainly that it was not yours or did not exist, then return to what your own sentences carry. Either branch is a good answer.
- Provenance labels: grounded means traceable to something you supplied. Inferred means derived, with the derivation named. Generic means a pattern with no claim about you or Ashgrove.

## Prep triage

Nine days between today and 20 November. In this order:

1. C1 and I1, aloud, until both plain acknowledgments (section "Prohibited claims", first two rows) sound boring. This is the highest-ROI prep in the pack: C1 is the question most likely to be asked in some form.
2. Write down your true answers to the answer slots in F2, F3, F5, F6, F7 and F9, then send them to me and I will regenerate those rows.
3. G1 and G2 aloud with the structure given, since round 3 is the longest and holds the case.
4. One story each for F1 to F4 in round 3, from the scaffolds.
5. A1, your 90-second arc.

Everything else is insurance.

## Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap in the words, but a self-report with nothing inspected behind it, so expect a probe on what the supervisor years covered. Lead in the quote's own terms: six years in retail banking, the last three as a branch supervisor |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | The sentence says a formal complaints log you handled; it does not say what governed how those complaints were handled. Answer slot: the JD's regulated-complaints line makes a probe on that likely. If rules from outside the branch governed it, say which and what part was yours, in your own words; if none did, or the part was not yours, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD, branch half | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how far your part of a complaint's handling went likely. Say which parts of handling a complaint in that log were yours to decide, in your own words; if none were, or it was not yours, say so plainly and stay with the log you handled |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD, contact-centre half | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence says a monthly complaints spreadsheet your regional manager uses; it does not say what it tracked. Answer slot: the JD's reporting line makes a probe on that likely. Say what it tracked, in your own words; if it did not track what the JD names, say so plainly and say what you would add first |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence says spreadsheet, not which tool. Answer slot: the JD's Excel line makes a probe on the tool likely. Say which tool it was built in and what you are comfortable doing in it, in your own words; if it was not Excel, say so plainly and say what you would need to learn |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, and the words stay there: "trained new tellers on our escalation script." Answer slot: the JD names supervisors, so a probe on whether you have guided supervisors is likely. If you have guided supervisors on escalations, say how, in your own words; if not, or it was not yours, say so plainly and stay with the tellers you trained |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." The sentence says nothing about what you have presented, and the pack adds nothing to it. Then how you would prepare for senior audiences, said as a plan and never as a past |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing on this. Answer slot: the JD's digital line makes a probe likely. If you have worked with a digital team on anything members use, say what and what part was yours; if you have not, say so plainly and say how you would begin with them |

## Grounding brief (from the strategy brief you were sent)

What the brief says, as you gave it to me:

| Item | Statement | Provenance |
|---|---|---|
| Digital | "move 40% of member service to digital channels by 2028" | [grounded] |
| Branches | "consolidate eight branches into five hubs over 2027" | [grounded] |
| Lending | "launch a small-business lending product in Q1 2027" | [grounded] |
| Competition | "the main competitive pressure is app-only banks" | [grounded] |
| Currency | Published July 2026, about four months before 11 November 2026; no search was run to check for later changes | [grounded] |

How each may surface in these rounds:

| Item | Likely use | Provenance |
|---|---|---|
| Digital | A CO or CASE question on what moving service online does to complaints; the JD's self-service line points the same way (G3, B3) | [inferred] |
| Branches | Branch managers on the round 3 panel may raise how complaint handling works across hubs; ask rather than assume how it affects them (H1) | [inferred] |
| Lending | A new product brings a new kind of member and complaint to route; usable as a one-sentence aside, not a centrepiece | [inferred] |
| Competition | A member threatening to leave for an app-only bank is a natural case setting (G1) | [inferred] |

## Round 1: recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured; the biography question; scored anyway | High: a recruiter screen is a conversational round, and the email gives a plain 30 minutes | A pre-scripted 90-second arc (A1); treat casual questions on the JD's hot topics as scored |
| Skeptic, light | Knockout-style checks on the contact-centre and senior-presenting lines | Medium: your own message names two limits against this JD (F4, F8), and a screen is where they surface first | Say each limit once, plainly, with a plan; never bluff past it |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in only the beats the sentences state, in your own words: six years in retail banking; the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close with your own reason for the role. Answer slot: say what draws you to member complaints work, in your own words; if it is the scope of the role, say that. Add no result or scale the sentences do not state | The opener of a screen, and the arc A3 and A4 then probe. F1, F2 and F5 carry the beats. EXP because it tests whether your account matches your material |
| A2 | "What draws you to Ashgrove?" | CO | [grounded] | Pick one published line and say why it matters to you, for example "Members First, Always — we decide from the member's side of the counter" or "Plain Words". Use one strategy fact as context, such as the move of 40% of member service to digital channels by 2028. Answer slot: if a value or priority matches something that matters to you in your own work, say which and why, in your own words; if nothing in particular does, say plainly what does draw you. Do not recite the page | A screen checks homework and motivation. The values page and strategy brief you supplied are the raising sources, so CO. No row, because it asks about no past |
| A3 | "Tell me about the formal complaints log you handled." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Tell the beat the sentence states: the branch's formal complaints log, which you handled, in your own words. Answer slot: the JD's regulated-complaints line makes a probe on what governed how those complaints were handled likely. If rules from outside the branch governed it, say which and what part was yours; if none did, or the part was not yours, say so plainly and stay with the log you handled | F2 is the row where the JD presses on your one complaints sentence. EXP because it tests what was yours |
| A4 | "Tell me about the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the sentence states: you built it, it is monthly, your regional manager uses it. Answer slot: the JD's reporting and Excel lines make a probe on what it tracked and which tool it was in likely. Say both in your own words; name the part of it you would trust least before the interviewer asks; if you are not sure how something in it was counted, say so plainly | F5 and F6 are discovery rows, so this is where the answer slots get met. EXP, with the defend-the-detail move |
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Your material holds two limits in your own words, and you choose which to name. Say it in one plain sentence, then a ramp plan in your own words: who you would sit with and what you would learn first. A plan, not a past. Do not name a different weakness to dodge these two | A Skeptic stem. F4 and F8 are the two limits you have stated, so this is likely. JD because it scores the stated requirements |
| B2 | "The role covers the contact centre as well as the branches. How do you feel about that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open with the plain acknowledgment your own sentence supports: "I haven't worked in a contact centre." Then a plan said as a plan, your own choices of what to learn first and from whom. Then return to the branch side your sentence does carry: the log you handled and the tellers you trained. Do not describe contact-centre work as though you had seen it | F4 against the JD's first responsibility. The recruiter is the first person to hear it, so it is rehearsed here before round 2 |
| B3 | "The role works with digital teams on self-service journeys. What have you worked on there?" | JD | [grounded] | No sentence of yours reaches this, so the guidance is the F9 slot. If you have worked with a digital team on anything members use, say what and what part was yours; if you have not, say so plainly and say how you would begin with them, as a plan | F9 is silence in your material, so this is discovery, not a gap you have stated. JD because it scores a listed responsibility |
| B4 | "Have you coached people on escalations?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the sentence says: you trained new tellers on your escalation script. Answer slot: the JD names supervisors, so expect a probe on whether you have guided supervisors. If you have, say how, in your own words; if not, or it was not yours, say so plainly and stay with the tellers you trained | F7 is adjacent evidence at the tellers' level. JD because it scores the coaching responsibility |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Is the 20-minute case in round 3 built on a real past escalation, and is there anything I should read beforehand?" | Shows you are preparing for the scored part and gets the format in the recruiter's own words |
| R1.2 | "How is complaint handling split today between the branches and the contact centre, and who holds it end to end?" | Turns the JD's first line into a question about the present, and gets you facts for round 2 |
| R1.3 | "Which of the four values do candidates usually find hardest to evidence?" | Shows you are taking the values round seriously and asks for the panel's likely sticking point |
| R1.4 | "How will this role sit alongside the move from eight branches to five hubs?" | Uses the brief to show you read it, without claiming to know the plan |
| R1.5 | "What happens after the 20th, and when do you expect to decide?" | A plain process question that closes the conversation on the next step |

## Round 2: Head of Member Services, 45 minutes, mostly behavioural

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the two stated limits and of how far one branch's log carries | High: a manager is buying capability and derisking gaps, and F3, F4 and F8 are where the material is thinnest | Rehearse C1 until it is boring; hold, then concede exactly |
| Values or behavioural | "Tell me about a time…" probes | High: the recruiter's email calls the round "mostly behavioural" | A selection scaffold per question, each ending in its honest branch |
| Data-driven prober | Reads the reporting claim closely | Medium: your manager would receive the monthly reporting, and F5 and F6 are open slots | Say what the spreadsheet tracked and what you trust least in it before they ask |
| Case or strategist | One live problem on the reporting | Low: the recruiter describes this round as behavioural, and the escalation case sits in round 3; E2 touches it | Clarify, then structure, then answer, aloud |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role owns complaints across every branch and the contact centre. What part of that have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Hold only what the sentence carries: "I handled the branch's formal complaints log." Follow-up 1, "that is one branch": hold the log and say plainly that the contact centre was not yours — "I haven't worked in a contact centre." Follow-up 2, "how do you get from one branch to all of them?": a plan in your own words, what you would look at first and who you would ask; a plan, not a past. Follow-up 3, "so what is actually missing?": concede the two limits exactly as stated, and do not fold on the log. Answer slot: say which parts of handling a complaint in that log were yours to decide, in your own words; if none were, say so plainly and describe how you handled the log | F3 and F4 are where the JD's first responsibility presses hardest, so some form of this arrives. JD because it scores the headline requirement |
| C2 | "You would be coaching branch supervisors, a role you have done yourself. What is different about coaching people at that level?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from what the sentences carry: the last three years as a branch supervisor, and training new tellers on your escalation script. Answer slot: the JD names supervisors, so expect a probe on whether you have guided supervisors. If you have, say how it differed from training tellers, in your own words; if not, or it was not yours, say so plainly and say what you would ask a supervisor first | F7 is tellers, not supervisors. The question is premised only on your own supervisor years. JD because it scores the coaching responsibility |
| C3 | "This role presents monthly to senior leaders. How do you feel about that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment first, from your own sentence: "I've never presented to anyone above regional level." Add nothing about what you have presented. Then how you would prepare, as a plan in your own words: what you would ask for first and who you would rehearse with. Do not claim a comfort you have not tested | F8 is a stated limit, so a manager who will sit in the room will test it. JD because it scores the senior-leaders line |
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] | A selection scaffold: pick an occasion with a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it. Do not borrow an ending you have not lived | The Values persona stem, and the likeliest behavioural prompt for a manager. No sentence of yours carries a story, so a scaffold |
| D2 | "Tell me about an escalation that did not go the way you wanted." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold with the sentence as your nearest material: pick an occasion with a named member issue, your part in it, what you did next, and what you would do differently. If no such time comes to mind, say so plainly, then stay with the log you handled and the tellers you trained, or say how you would handle one. Name no incident the sentence does not carry | The JD's coaching-on-escalations line is the raising source. EXP because it tests your own account |
| D3 | "Tell me about training new tellers on your escalation script." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beats the sentence states: you trained new tellers; the script was your branch's. Answer slot: if you had a hand in writing or changing the script, say what; if it was given to you, say so plainly and stay with training the tellers. Say, in your own words, what a teller needed to be able to do afterwards only if you know it | F7 at its own scope. EXP because it is the one coaching sentence you hold, and a manager will want its edges |
| E1 | "Walk me through the monthly complaints spreadsheet. What went in and what came out?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the sentence states: you built it, monthly, used by your regional manager. Answer slot: say what went in and what came out, in your own words; if some of it came from elsewhere and you do not know how it was counted, say so plainly. Name the part you would trust least before they ask | F5 and F6, probed by the person who would receive the next one. EXP, with the weakest-assumption move |
| E2 | "If you were reporting monthly to our senior leaders, what would be on page one?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Structure it aloud: who reads it and what they must decide; the few measures the JD names, complaint volumes and resolution times, with one line on how each is counted; one change worth their attention; one caveat on the data. Your spreadsheet is the starting point you would build from, said at its own scope. Answer slot: if your spreadsheet already tracked any of those measures, say which; if not, say so plainly and say what you would add first | The JD's reporting line as a live problem. CASE delivery, JD content, since it asks nothing about your past beyond the quote |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would a strong first 90 days look like in this role?" | Asks the manager for the scoring sheet and shows you plan to start |
| R2.2 | "How does complaints data reach you today, and what do you wish it showed?" | Connects directly to the monthly reporting line and to your spreadsheet |
| R2.3 | "Where do branch supervisors struggle most with escalations at the moment?" | Shows you are thinking about the coaching task before you hold it |
| R2.4 | "As eight branches become five hubs, which complaints do you expect to change most?" | Uses the brief and invites the manager's view |
| R2.5 | "Is there anything in my background you would want me to address before the panel?" | Invites the manager to name a concern, and gives you a chance to rehearse C1 live |

## Round 3: panel of two branch managers, 60 minutes, including a 20-minute case

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values or behavioural | One question per published value | High: the recruiter's email says the panel "is also the values round" and that they "score against the four values" | A scaffold per value, each ending in its honest branch |
| Case or strategist | The 20-minute escalation case | High: the email names a 20-minute case on a complaint escalation | Clarify, objective, segment, approach, metrics, risks; challenge one premise respectfully |
| Peer evaluator | Seam-splitting between your role and theirs | Medium: branch managers run the places you would work across, so where your role stops and theirs starts is likely | Propose seam principles, not a pretended map; say what you bring them |
| Pressure | A time-boxed "why should we trust you" | Low: no source says this panel presses, but a composure question is common in a panel; one item rehearses it | Pause, restate, hold, then concede exactly |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold for Members First, Always: a named decision, whose side you took, what it cost someone internally, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — the log you handled, the tellers you trained — or how you would handle it. Do not describe a decision the sentence does not state | The published value is the raising source. No sentence of yours carries a decision, so a scaffold |
| F2 | "Tell me about a time something you said or wrote had to be explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold for Plain Words: the thing, who needed it explained again, what you changed, how you knew it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. Answer slot: if a teller needed your escalation script explained twice, say what you changed; if none did, say so plainly and stay with the training | The value says "if a member needs it explained twice, we wrote it wrong". The question carries the theme without presupposing an event |
| F3 | "Tell me about a time you weighed what one branch needed against a number you were measured on." | VAL | [grounded] | A selection scaffold for Neighbours, Not Numbers: the branch and its need, the number, what you chose, the result for the town. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. Say nothing that treats a branch as only a figure | The value is the raising source, and the hub plan makes it likely to be probed. No sentence of yours carries a trade-off |
| F4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the one beat the sentence states: you handled the branch's formal complaints log. Answer slot: the value says "whoever finds the problem keeps hold of it until it is solved". If a particular complaint stayed with you until it was solved, say which, what you did and what part was yours; if none did, or it passed to someone else, say so plainly and stay with the log you handled | Own the Fix is the value your one complaints sentence is closest to. VAL because it scores the published value |
| G1 | "A member has complained twice about the same fee. A supervisor told them it was policy, and now the member says they are moving to an app-only bank. What do you do, and in what order?" | CASE | [generic] | Structure aloud. Clarify first: what exactly was complained about, what has already been said, what the formal process requires here. Objective: the member's side of the counter, and a reply in plain words. Ownership: who keeps hold of it until it is solved. Approach: the member first, then whether others have the same issue, then the supervisor. Metrics: resolution time and repeat complaints on this fee. Risks: a policy answer that is correct and still wrong for the member. Challenge one premise respectfully, for example whether "policy" is the end of the answer. The case asks about no past, so the guidance makes no claim | The email names a 20-minute case on a complaint escalation, so this rehearses the shape, not the real case. Generic because the actual case is not known. CASE because it is a live problem |
| G2 | "The supervisor followed the escalation script and the member still left unhappy. How do you coach them without blaming them?" | CASE | [generic] | Structure aloud. Ask the supervisor first what they saw and what they would try again. Separate "followed the script" from "met the member's need". Agree one change, and how you will check it with them later. Say the coaching conversation in plain words. Keep it at the level of how you would do it; do not claim to have done it | The JD's coaching-on-escalations line as a live problem. Generic because it is a pattern for the problem. CASE because it asks for reasoning, not a story |
| G3 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that do to complaints, and what would you want from self-service?" | CO | [grounded] | Structure aloud. Which complaints can be solved in self-service and which need a person quickly. What self-service wording must do to meet Plain Words. How you would measure it: volumes and resolution times by channel. The risk to name: a member in difficulty who cannot reach a person, which cuts against Members First, Always. App-only banks are the context, not a thing to correct the panel about. Answer slot: if you have worked with a digital team on anything members use, say what and what part was yours; if not, say so plainly and say how you would begin with them | The brief you supplied makes this the likeliest strategy question. F9 is the open row it touches. CO because it asks for company-level thinking |
| H1 | "As eight branches become five hubs over 2027, where does your role stop and a branch manager's start?" | JD | [grounded] | Offer seam principles, not a pretended map. One member's complaint has one owner until it is solved. You would own the process, the reporting and the coaching; they would own their people and their town. Name how you would settle a disagreement: who decides, how fast, and what is recorded. Then say what you bring them, not only what you need from them. Ask how they see it; do not assume how the hub plan affects them | A peer stem on the seam, with the brief you supplied as the raising source. JD because it scores the role's scope |
| H2 | "A supervisor in one of our branches disagrees with how you have told them to handle an escalation. What happens?" | CASE | [generic] | Structure aloud. Listen to the reason first. Separate the member's outcome from the method. Say what you would hold and what you would change, with the reason. Say how you would tell the branch manager. Show spine and tact together without claiming a past | A peer evaluator's disagreement probe, set in the role. Generic because it is a pattern. CASE because it is a live problem |
| I1 | "Sixty seconds: you have never worked in a contact centre and never presented above regional level. Why should we trust you with this role?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause, restate, hold. Hold what the sentences carry: six years in retail banking, the last three as a branch supervisor, and the log and the tellers. Concede the two limits exactly: "I haven't worked in a contact centre" and "I've never presented to anyone above regional level." Then one plan in your own words for each. Do not fold on what you did carry, and do not add what you did not | A Pressure item built from F4 and F8, both stated by you, so the premise has a source. JD because it scores the stated requirements |

### Values cheat sheet (the panel scores against these four)

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1, a selection scaffold. No sentence of yours carries a decision; if none comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it |
| Plain Words | If a member needs something explained twice, it was written wrong | F2, a selection scaffold. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | F3, a selection scaffold. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3 row: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beat: the log you handled. The rest is the F4 answer slot |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could a new complaints lead do in their first month that would genuinely help your branches?" | A reciprocity question for the branch managers, who would work beside the role |
| R3.2 | "Which complaint did your branch find hardest to close this year, and why?" | Invites a real story and shows you are thinking about the work |
| R3.3 | "How do your supervisors feel about escalations today?" | Gets at the coaching task from the people who would receive it |
| R3.4 | "As the hubs form, what do you most want to protect about your town's branch?" | Connects Neighbours, Not Numbers to their own view without presuming it |
| R3.5 | "What would make you say this role had worked well a year in?" | Asks the panel for its own scoring sheet |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | A3, B2, C1, G1, I1 |
| "report monthly on complaint volumes and resolution times" | A4, E1, E2, G3 |
| "coach branch supervisors on escalations" | B4, C2, D2, D3, G2 |
| "work with digital teams on self-service journeys" | B3, G3 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | A3 |
| "confident presenting to senior leaders" | C3, E2, I1 |
| "comfortable with Excel reporting" | A4, E1 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in a contact centre | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log, not the process across branches. The slot stays inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says a formal complaints log, not what governed it. The slot asks only what governed how they were handled |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: new tellers and the escalation script. The slot asks only whether you have guided supervisors |
| Reported monthly on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope. The slot asks only what the spreadsheet tracked |
| Built Excel reporting | Inflated form of F6 | F6's quote at its own scope: a spreadsheet. The slot asks only which tool it was built in |

## Sources

Provided documents: the JD text you pasted; Ashgrove's four values, copied by you on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; the 2026 strategy brief the recruiter sent, as you summarised it; your own background notes. No dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values you pasted fix the values cheat sheet and the VAL bank |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email states three sessions, who runs each and what each holds, so the round structure and persona weights are fixed |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief you supplied fixes the grounding brief and the CO questions |
| 4. Interviewer name and Ashgrove | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Interviewer names for each round → an interviewer read, persona weights from their public footprint, and a reverse question tied to their own path
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a checked, current strategy and org-context brief, and any published account of Ashgrove's process
- The real format of the 20-minute case, asked of the recruiter in round 1 (R1.1) → G1 and G2 move from generic to grounded
- Your true answers to the slots in F2, F3, F5, F6, F7 and F9 → those rows are regenerated on your own words, and confidence can rise from medium once an artifact backs them, such as the spreadsheet's layout with member data removed, or the script you trained tellers on
- A dossier from a prior evidence review, if you have one → verified evidence and constraints that sharpen the prohibited list; never a prerequisite
