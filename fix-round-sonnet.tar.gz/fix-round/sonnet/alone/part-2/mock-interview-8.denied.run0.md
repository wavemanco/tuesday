I'll read the reference files the skill requires before building the pack.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-denied-021c113c/Ashgrove_member-experience-lead_interview_pack.md`. The recruiter's email fixes all three rounds, so I built it as a loop pack. It has one shared fit snapshot and a mini-pack per round, with 30 questions in total (9, 10 and 11). The values sheet sits with the panel round. The pack makes no use of the interviewers' names, since none are assigned yet.

I ran no searches. Your pasted values, strategy summary, JD and the recruiter's email already covered every research target, and the Sources section shows each one.

The pack names C1 as your highest-ROI prep: one branch's complaints log and no contact centre, set against a role that owns the process across both. It is rehearsed with follow-up levels and a concession worded in advance.

Say the word and I'll play the Head of Member Services on C1 and drill it with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

- **Candidate:** Dara
- **Built:** 11 November 2026, as a loop pack for the three rounds on 20 November 2026 in the recruiter's email
- **Round 1:** 30 minutes with the recruiter
- **Round 2:** 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural
- **Round 3:** 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case; the panel is also the values round, scored against the four published values
- **Interviewers:** only roles are known, no names, so there is no interviewer read

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, in about 90 to 120 seconds.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values |
| EXP | Whether what you have said about your work survives follow-up questions |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | A live problem from the role: structure and reasoning |

Question IDs: A and B are Round 1, C to F are Round 2, G to I are Round 3.

An **Answer slot** is an instruction for the interview, not something to answer here. Answer it from your own experience. If the practice it names was not yours, or never existed, say so plainly and go back to what you did.

**Highest-ROI prep in the whole pack: C1.** It is the objection most likely to reach you in some form: one branch's complaints log and no contact centre, set against a role that owns the process across both.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Words stay at the quote's scope: "I handled the branch's formal complaints log." Your material says one branch's log, not a process across branches. Answer slot: the JD's "end to end" makes a probe on how far your part went likely. If any part of a complaint's life beyond the log was yours, say which, in your own words; if the log was the whole of it, or the rest was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you stated, and wording cannot close it. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past: who you would learn from and what you would look at first. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote shows a monthly complaints spreadsheet that you built and your regional manager uses; it does not show what the spreadsheet counted. Words stay there: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on what it counted each month and how. If you can say what each line measured and how it was counted, say so in your own words; if you cannot, say so plainly and stay with the fact that you built it |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Words: "I trained new tellers on our escalation script." Your material says tellers, not supervisors, and "our" script, not one you wrote. Answer slot: the JD's coaching line makes a probe on coaching at supervisor level likely. If you have coached any supervisor, or colleagues at your own level, say who and on what, in your own words; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the JD's line makes a probe on your contact with digital or app colleagues likely. If you have worked with any, say who and on what, in your own words; if not, say so plainly, then say how you would start, as a plan and never as a past |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on the numbers, but a message line with nothing inspected behind it. Lead with the quote's own terms: six years in retail banking, the last three as a branch supervisor. Expect a probe on whether that matches the JD's phrase "customer operations", given F2. Describe the work in your own terms rather than adopting the JD's label for it |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your material says formal complaints; it does not say what governed them. Words stay at the quote: "I handled the branch's formal complaints log." Answer slot: expect a probe on what governed the complaints in that log, including whether any rules or timescales came from outside your branch. If any did, say which, in your own words; if none did, or you do not know, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A limit you stated. Words: "I haven't presented to anyone above regional level." Then a plan, said as a plan: how you would prepare for a first leadership presentation. The JD does not say who counts as senior leaders, and the recruiter can (Round 1 reverse question 1) |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The quote says spreadsheet, not which tool. Lead with it as written: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on the tool and how you built it. Name the tool as it was; if it was not Excel, say so plainly and stay with what you built |

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B2, C1, D2, H1 |
| Report monthly on complaint volumes and resolution times | D1, F1 |
| Coach branch supervisors on escalations | D3, H2, I1 |
| Work with digital teams on self-service journeys | A4, F2, H3 |
| 4+ years in financial-services customer operations | A1, B1 |
| Experience handling regulated complaints | B5, D2 |
| Confident presenting to senior leaders | B3, C2, C3 |
| Comfortable with Excel reporting | D1, F1 |

Your material holds no figure about the log or the spreadsheet, so there is no defend-the-number question. The upgrade menu says what supplying one would unlock.

## Grounding brief

From your summary of the July 2026 strategy brief and the JD. The pack has not read the brief itself, so these rows are only as complete as your summary.

| # | Item | Provenance | Reading (inferred): where it surfaces in this loop |
|---|---|---|---|
| S1 | Move 40% of member service to digital channels by 2028 | [grounded] | Raises the digital line that F5 is silent on. The likeliest strategy hook in A4, F2 and H3 |
| S2 | Consolidate eight branches into five hubs over 2027 | [grounded] | The panel are branch managers, so this is the likeliest strategy question in Round 3 (G4). Whether it touches their own branches is not in your material |
| S3 | Launch a small-business lending product in Q1 2027 | [grounded] | Nothing in the JD ties complaints to it, so no question is built on it. Treat it as vocabulary if it comes up |
| S4 | The main competitive pressure is app-only banks | [grounded] | Gives the digital line its urgency in Ashgrove's own frame. Mention it as context; do not lecture the panel on competitors |
| S5 | Member-owned, about 900 staff | [grounded] | From the JD. "Member-owned" is the frame for the why-a-credit-union question (A2) |

# Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly walk through your background and motivation; casual questions about hot JD topics | Highest. A recruiter screen is a conversational round by prior, and 30 minutes leaves time for several questions in a chatty register | Prepare a 90-second arc for the biography question; treat casual JD-topic questions as scored; never answer "I think you've covered everything" at the reverse-question slot |
| Skeptic (light) | Knockout checks of the JD's requirements against your background, asked pleasantly | Medium. The prior is a light Skeptic, and you have stated two gaps (F2, F8) that a screener can check against the JD in one question each | Say the plain acknowledgment, add a one-sentence plan, then move on; do not defend or over-explain |
| Pressure | Interrupting, time-boxing | Low. Nothing in the recruiter's email points to it | No separate rehearsal; the Round 2 bank covers composure |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your journey in banking so far, and what's drawing you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Story-mapped on F6: the two beats the quote states, six years in retail banking and the last three as a branch supervisor, told in your own words in about 90 seconds. The last beat, what draws you to this role, is yours: pick one line of the JD or one of the four published values you actually care about and say why. Stop at those beats and add no roles, dates or moves the quote does not carry | F6 is what a screener checks first, and the journey stem is the Conversational persona's standard opener. EXP because it tests the claim; the motivation half is JD content |
| A2 | "What do you know about Ashgrove, and why a credit union?" | CO | [grounded] | Use only what is in hand: member-owned and about 900 staff (the JD), the four values by name, and from your summary of the 2026 brief the 40% digital target by 2028, eight branches into five hubs over 2027, the Q1 2027 small-business lending launch, and app-only banks as the main pressure. Pick one or two and say what they mean for member complaints; do not recite the list. Why a credit union is yours to say, and the pack has no basis to supply it | S1 to S5 are in hand because the recruiter sent the brief. CO because it tests homework depth at the company's altitude |
| A3 | "Tell me about your most recent role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F6, F1 and F3, each beat at its quote's scope: you were a branch supervisor for the last three years, you handled the branch's formal complaints log, and you built the monthly complaints spreadsheet your regional manager uses. Say those and stop. Anything beyond them is an answer slot, covered in D1 and D2, so do not open it here unless asked | The recruiter will read F1 and F3 against the JD's first two lines. EXP because it checks the CV claims, kept light for a screen |
| A4 | "The role works with the digital teams on self-service journeys. How do you use or think about digital channels today?" | JD | [grounded] | Answer slot: say what contact you have had with digital or app colleagues, in your own words; if none, say so plainly, then say how you would start working with them, as a plan and never as a past. The 40% digital target (S1) is context for why the question is likely, not a claim to build your answer on | F5 has no evidence, and S1 makes the topic likelier. JD because it scores a stated responsibility |
| B1 | "The role asks for 4+ years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say the quote at its own scope: six years in retail banking, the last three as a branch supervisor. Let the numbers speak, and describe the work in your own terms rather than repeating the JD's phrase for it. If they press on the phrase, say plainly what your six years were and let them judge the match | F6 is the requirement a screener checks first, and the contact-centre gap (F2) makes a probe on the label likely. JD because it scores the stated requirement |
| B2 | "You haven't worked in a contact centre. How will you get up to speed on one?" | JD | [grounded] "Never worked in a contact centre" | The hold is only the quote: "I haven't worked in a contact centre." Then a plan, said as a plan: who you would spend your first weeks with and what you would want to learn first, in your own words. Do not describe contact-centre work as something you have seen or done | F2 is the largest gap against "across branches and the contact centre". This is the light version for a screen; C1 is the deep rehearsal |
| B3 | "The role needs confidence presenting to senior leaders. Have you presented at that level?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan in your own words for how you would prepare a first leadership presentation. Do not offer comfort as a track record. Ask the recruiter who the senior leaders are (reverse question 1) so you are answering the real audience | F8 is a stated limit, and a screener can test it in one line. JD because it scores a stated requirement |
| B4 | "What are you looking for in your next role, and what are your pay expectations and timing?" | JD | [generic] | Have your own numbers and dates ready before the call; the pack has no source for the pay band or your notice period. If you do not know the band, ask the recruiter for it before giving a figure. For what you are looking for, use the JD's own lines and your own reasons | Logistics and knockout checks are standard in a screen. `[generic]` because the material holds nothing about pay or timing; JD because it tests fit with the role as advertised |
| B5 | "The role needs experience handling regulated complaints. What complaints experience do you have?" | JD | [inferred] "I handled the branch's formal complaints log" | Say the quote at its own scope: "I handled the branch's formal complaints log." Answer slot: expect a probe on what governed the complaints in that log, including whether any rules or timescales came from outside your branch. If any did, say which, in your own words; if none did, or you do not know, say so plainly and stay with the log | F7 is low-confidence and its gap is discovery, so a screener's first question here is the likeliest place the log gets probed. JD because it scores a stated requirement |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Who are the senior leaders this role reports to each month?" | It sizes the audience behind F8 against the real one rather than the JD's phrase, and shows you are already thinking about the reporting line |
| 2 | "Who will be on the panel, and can you tell me anything about how the 20-minute case will run?" | Names unlock an interviewer read and the case format retunes Round 3's case bank (H1 to H3); it is also a normal question at this stage |
| 3 | "How does the role work with the contact centre team day to day, and who would I be working with there?" | It treats F2 as something you intend to close, and the answer tells you whom to learn from first |
| 4 | "How is the move from eight branches to five hubs expected to affect the complaints process?" | It shows you read the strategy brief at the level of the role, and if the recruiter does not know, who does is useful to learn |
| 5 | "Is there anything in my background you would like me to say more about before I meet the Head of Member Services?" | It invites the recruiter's own read of your gaps, which no research can supply, and signals you can take a steer |

# Round 2: the Head of Member Services (45 minutes, your future manager, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the distance between your background and the role | Highest. The prior for the person who would manage you is to derisk gaps, and F2 and F8 are gaps you have stated yourself | Rehearse C1 until it is boring: hold what the quotes carry, concede the rest specifically, add a plan |
| Data-Driven Prober | "Walk me through it" on your log, your spreadsheet and your script, with follow-ups going a level deeper | High. The recruiter calls the round mostly behavioural, which tends to mean experience stories followed up closely, and your three quoted facts are the whole of the material to probe | Know what you can and cannot say about each, and say plainly when you do not know |
| Values / Behavioural | "Tell me about a time" prompts, likely mapped to the published values | Medium. Behavioural is the stated format, but the panel round is the one the recruiter says scores against the values | Choose stories where the hard truth landed; if the material shows none, say so rather than supply an ending |
| Case / Strategist | A live problem on the role's own roadmap | Lower than the manager prior, because the recruiter's note says behavioural; two questions still, because the live case in Round 3 comes from the same function | Clarify, structure, then answer; challenge one premise respectfully |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role owns complaints across the branches and the contact centre. You've handled your own branch's complaints log and you haven't worked in a contact centre. How do you close that distance?" | JD | [grounded] "I handled the branch's formal complaints log" "Never worked in a contact centre" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: "I handled the branch's formal complaints log, and I haven't worked in a contact centre." Follow-up 1, expect "what part of end to end was yours?": if any part beyond the log was yours, say which; if the log was the whole of it, or the rest was not yours, say so plainly and return to the log. Follow-up 2, expect a probe on where your branch's complaints came from and where they went next: if any passed between your branch and a contact centre or another team, say how, in your own words; if none did, or you do not know, say so plainly. Then concede before they ask: that is the distance, and you would rather name it than talk around it, followed by your plan for what you would learn first and from whom. Never close the distance by adding to the log | F1 and F2 are the distance the JD's "end to end across branches and the contact centre" presses, and the person who would manage you is the one derisking it. JD because it scores the stated requirement. Deepest means three follow-up levels, the concession worded in advance and the limit named before it is asked for |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level." | The quotes carry two candidates and the pack does not pick for you. Choose the one that is truest and say it first, plainly: "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level." Then one sentence of plan in your own words. Do not offer a gap as a gambit, and do not dress a strength up as a weakness | F2 and F8 are the stated gaps, and "weakest on day one" is the Skeptic's standard stem. JD because it scores the whole list of requirements |
| C3 | "The role asks for confidence presenting to senior leaders. You haven't presented above regional level. How will you handle the step up?" | JD | [grounded] "I've never presented to anyone above regional level." | Acknowledge first: "I haven't presented to anyone above regional level." Then the plan, in your own words: how you would prepare for your first leadership presentation, and what you would ask this manager about the audience and format. Hold the plan, not a claim of ease; if asked "so are you confident?", answer what is true for you now, because the pack cannot supply it | F8 is a stated limit and this interviewer is the person you would present to. JD because it scores a stated requirement |
| D1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 at the quote's scope: you built it; it is monthly; it is a complaints spreadsheet; your regional manager uses it. Answer slot: expect a probe on what it counted each month and how. If you can say what each line measured and how it was counted, say it in your own words, including the assumption you would defend least; if you cannot, say so plainly and stay with the fact that you built it. If asked how much was you, "I built it" is the quote; add no collaborators and no other users | F3 is the only evidence for the reporting line and F9's tool question. EXP because it tests what was actually yours; there is no figure in the material, so the defend-the-number rehearsal is the slot |
| D2 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: you handled the branch's formal complaints log, and that is all the quote states. Answer slot: the JD's "end to end" makes a probe on how far your part went likely. If any part of a complaint's life beyond the log was yours, say which and what you decided; if the log was the whole of it, or the rest was not yours, say so plainly and describe how you handled the log. Hold through follow-ups by returning to the log, never by adding to it | F1 and F7 both rest on this one sentence, so it is where a close reader presses. EXP because it tests what was the candidate's |
| D3 | "Tell me about training new tellers on your escalation script." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: new tellers; "our escalation script"; you trained them. Say "our", never "my", because the quote does not say you wrote it. Answer slot: the JD's coaching line makes a step-up probe likely. If you have coached any supervisor, or colleagues at your own level, say who and on what; if not, say so plainly and stay with the tellers | F4 is the only evidence for the coaching requirement. EXP because it tests the claim; the JD coverage for coaching sits in H2 and I1 |
| E1 | "When did you put a member ahead of an internal metric?" | VAL | [generic] | Selection scaffold, no quoted sentence of yours carries this story: pick a time when what a member needed and what was easy or set by a target pulled apart and you made the call. It needs a named stake, what you chose, what it cost and how it ended, including whether the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it. The same story can serve G1 | A persona stem for the behavioural round, and the closest published value is Members First, Always. VAL because it scores behaviour against a value |
| E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. Leadership can mean the leaders you have actually worked with, so choose within your experience. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | This is the Values persona's standard stem and it sits beside F8's limit, because delivering a hard message upward is part of the reporting job. VAL because it scores behaviour, not knowledge |
| F1 | "If you were building the first monthly complaints report for our leadership team, what would you want to know first, and what would it show?" | CASE | [grounded] | Think aloud, in order. Clarify: who reads it, what decisions it feeds, where complaint data sits across branches and the contact centre, and whether a complaint is counted the same way in both. Objective. Cuts: by branch, channel and type. Approach and measures: volumes and resolution times are the JD's named ones, so ask what else leaders look at. Risks: figures that do not line up across channels, and small numbers. Challenge one premise respectfully, for example whether a time-to-resolve figure means much without knowing what was resolved. No claim about your past is needed | It is a live problem from the JD's reporting line. CASE because it scores structure and clarifying, and it rehearses the part of the job where F3's slot and F8's limit meet |
| F2 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that mean for complaints?" | CO | [grounded] | The question asks for reasoning, so think aloud and claim nothing about Ashgrove you were not told. What would you want to track as service moves online: where members who start in self-service end up, and whether anyone has to explain something twice, which is the Plain Words line. Who you would work with: the digital teams in the JD. What could go wrong. Do not recite the 40% as a slogan; use it once and then reason | S1 makes this the strategy-grounded question in this round. CO because it tests thinking at the company's altitude, with F5's silence behind it |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Where does complaints ownership sit today across the branches and the contact centre, and which part is hardest to own?" | It goes straight at the end-to-end line in the JD and shows you read it as a problem to solve, not a title |
| 2 | "How do complaint themes reach you today, and what would you want to see more of?" | It asks what the person you would report to wants from the role's reporting, which is the practical form of F3 |
| 3 | "How would you want me to brief you and senior leaders, and what do they read?" | It answers F8's limit with curiosity about the audience, and it is a question a candidate who intends to prepare asks |
| 4 | "How will the digital team's self-service plans and the complaints work meet, and who sets priorities between them?" | It ties the digital line (S1) to your own role and tells you where F5 would matter first |
| 5 | "What would make you say in a year that hiring me was the right call?" | It asks for the manager's own success measure, which is the clearest guide for your first months |

# Round 3: the panel of two branch managers (60 minutes, including the 20-minute complaint-escalation case, and the values round)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Prompts mapped to the four published values, scored against them | Highest. The recruiter states the panel is the values round and scores against the four values | Map a story to each value where your own sentences carry one, and a selection scaffold ending in the honest branch where none does; "we" for context, "I" for what you did |
| Case / Strategist | The 20-minute complaint-escalation case, with follow-ups | High. The recruiter's email puts 20 of the 60 minutes on it | Clarify first, then structure, then answer; think aloud; challenge one premise respectfully |
| Peer Evaluator | Seam questions: where you and a branch manager meet, and what happens when you disagree | Medium. The JD has you coaching branch supervisors, so branch managers are the people whose teams you would work with. Names are unknown, so this is a blend rather than a per-person read | Reciprocity: what you bring their branches; propose seam principles rather than pretending to know the seam |
| Skeptic / Pressure | Probing the contact-centre and senior-presenting gaps, or time-boxing the case | Low. Round 2 is where those gaps are likeliest to be probed, and nothing about the panel points to pressure | C1 covers the objection; keep the case answers moving so a time-box does not catch you mid-structure |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Members First, Always. Selection scaffold: pick a time when what a member needed and what was easy or set by a rule pulled apart and you made the call. Name what the member needed, what you chose and how it ended, and say whether the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log," at that scope, or how you would handle it | The value's own wording is the raising source, and F1 is the nearest evidence. VAL because it scores a published value |
| G2 | "Tell me about a time you made something complicated clear to a member or a colleague." | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words. Selection scaffold: pick a time when a first explanation did not land and you changed the wording rather than repeating it; name what you changed and what happened. The quote carries only the training, "I trained new tellers on our escalation script," and does not say whether anything had to be explained twice. If no such time comes to mind, say so plainly, then stay with the tellers at that scope or say how you would handle it | The value says that if a member needs it explained twice, Ashgrove wrote it wrong, so this is the likeliest framing. F4 is the nearest evidence. VAL because it scores a published value |
| G3 | "Tell me about a time you weighed a number against what mattered to your branch's members." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Neighbours, Not Numbers. Selection scaffold: the quote gives you the setting, a branch you supervised for three years, and no story. Pick a time when a figure or a target pointed one way and what your branch's members needed pointed another; name the decision, what it cost and how it ended. Do not claim town or community ties the material does not state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | The value is the one the hub plan tests most (S2), and F6 is the only setting the material gives. VAL because it scores a published value |
| G4 | "Ashgrove plans to bring eight branches into five hubs over 2027. How does that sit with 'Neighbours, Not Numbers'?" | CO | [grounded] | No claim about your past is needed. Do not defend or attack the plan. Name the tension plainly: this is the kind of change where the value gets tested. Then give your angle as the person who would own complaints: you would want to know how the change shows up in what members say, and what hubs keep for the towns that lose a branch. You will not know whose branches are affected, so stay respectful and do not guess | S2 and the value are both published, and the panel are branch managers. CO because it tests homework at the company's altitude; the VAL link is in the rationale, not the tag |
| G5 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix. Story-mapped on F1 at its scope: you handled the branch's formal complaints log. Answer slot: the value's wording makes a probe on one complaint you stayed with likely. If there was one, say what you did and where it ended, in your own words, including what was not solved; if none comes to mind, or the log was only a record, say so plainly and stay with the log | F1 is the only evidence that touches complaints, and the value is the closest match to the role's core. VAL because it scores a published value |
| H1 | "A member's complaint has been passed between the branch and the contact centre, each saying it belongs to the other. It is the member's third contact. Walk us through what you do." | CASE | [generic] | Think aloud, in order. Clarify: what the complaint is, what has been promised, what time limits apply and who has it now. Objective: the member's problem solved, not the handover. Approach: one owner agreed now, one plain message to the member, and you keep hold of it until it is solved, which is the Own the Fix line used inside the case. Afterwards: why it bounced, and fix the handover without blaming a team. Measure: repeat contacts. Challenge the premise respectfully: whose complaint it is does not matter; it is the member's | The scenario is invented for rehearsal and the real case may differ. CASE because it scores structure; `[generic]` because it is a pattern for the problem, not a fact about Ashgrove |
| H2 | "A branch supervisor sends you nearly every complaint as an escalation, including ones they could settle at the counter. What do you do?" | CASE | [generic] | Clarify: what the escalation path says, whether the supervisor is unsure of it, whether this is one supervisor or several, and what the data shows. Objective: members' complaints settled at the right level without anyone being afraid to escalate. Approach: a coaching conversation that starts by asking why they escalate, then looks at a few together and agrees what they can settle. Risks: leaving a member waiting while you coach; taking the case away in front of the supervisor's team. Report on escalations by branch as a number to watch | It covers the JD's coaching line as a live problem, aimed at the people the panel manages. CASE because it scores structure and judgement; `[generic]` because the scenario is invented |
| H3 | "Members keep calling the contact centre about something the app is meant to let them do themselves, and complaints are now mentioning it. How do you work with the digital team?" | CASE | [inferred] | Clarify: what the task is, where members get stuck, how many, and what they are told. Approach: take the digital team the members' own words and a handful of examples, agree what a fix looks like in plain words, and agree who keeps hold of it until it is fixed. Measure and report: contacts and complaints about that task over time. Risks: fixing the app and not the wording. If you have worked with digital colleagues, F5's slot applies and you say so; if not, do not borrow the case as your history | Built from S1 and the JD's digital line, so `[inferred]`; the scenario is invented. CASE because it scores structure; F5's silence is why it needs rehearsing |
| I1 | "You'd be coaching our supervisors on escalations. How would you go about it?" | JD | [grounded] "trained new tellers on our escalation script" | Lead with your approach as a plan: start by listening to how each branch handles escalations today, agree a small number of changes with each supervisor, and follow up. Anchor it with the quote at its own scope, "I trained new tellers on our escalation script." Answer slot: if you have coached any supervisor, or colleagues at your own level, say who and on what; if not, say so plainly and stay with the tellers | F4 is the evidence and the requirement is the JD's own line. JD because it scores a stated responsibility |
| I2 | "Where is the seam between your role and ours, and what happens when we disagree about a complaint?" | JD | [generic] | Offer seam principles, not a map: you would say you do not yet know where the seam sits and would ask. Principles: whoever finds the problem keeps hold of it until it is solved, decisions inside a branch stay with the branch, and you own the process and the reporting. On disagreement: start from the member's side of the counter, say your reasoning, and agree in advance who decides | A Peer Evaluator stem. JD because it scores how the role works beside the people it coaches |
| I3 | "Tell me about a time you disagreed with a colleague and how it ended." | VAL | [generic] | Selection scaffold: pick a time with a real disagreement between equals, where you showed spine and tact together and the relationship was intact at the end. Say what you argued, what you conceded, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | The Peer persona's collegial packaging of the Skeptic's questions. VAL because it scores behaviour toward a peer |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How do your supervisors handle escalations today, and where would you most want the Lead's help?" | It asks the people the role coaches what they need, which is the part of the JD you have the least direct evidence for (F4) |
| 2 | "What could a new person do in their first month that would genuinely help your branch?" | The reciprocity question: it shows you are thinking about what you bring their teams |
| 3 | "What should the complaints Lead understand about how the hub plan feels from a branch?" | It treats the plan as something that is lived, not a slide, and invites a candid answer in a values round |
| 4 | "Which of the four values is hardest to live in practice, and what does that look like at your branch?" | It shows you took the values seriously enough to expect them to be tested |
| 5 | "What does the handover between a branch and the contact centre look like today?" | It goes to F2's gap as a question, and the answer is the context H1 rehearses |

### Values cheat sheet (the panel round is the values round)

Names are Ashgrove's, from the page you pasted on 11 November 2026. Meanings are paraphrased.

| Value | Working meaning | Your mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide as the member would experience it, even when another path is easier for the organisation | Selection scaffold (G1, E1): no quoted sentence of yours carries a decision from the member's side. Nearest thing is F1, "I handled the branch's formal complaints log", at that scope; if no time comes to mind, say so plainly |
| Plain Words | Wording that works the first time; needing a second explanation means Ashgrove wrote it wrong | Selection scaffold (G2): F4's quote is "trained new tellers on our escalation script" and does not say whether anything was explained twice. Pick a time you reworded something that did not land; if none, say so plainly |
| Neighbours, Not Numbers | Each branch is part of its town, and decisions are not read from figures alone | Selection scaffold (G3, G4): F6's quote, "6 years in retail banking, the last 3 as a branch supervisor.", gives the setting and no story. Pick a time a figure and your branch's members pulled apart; if none, say so plainly |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | Story-mapped (G5, H1) on F1: "I handled the branch's formal complaints log". Beyond that sentence the slot is yours to answer, including the honest branch |

# Prohibited claims (shared by all three rounds)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope, "I handled the branch's formal complaints log". The pack's observation is that your material says one branch's log, not a process across branches. The slots in C1 and D2 stay inside the log |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The pack's observation is that your material says formal complaints, not what governed them. B5's slot asks only what governed the log |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope, "I built the monthly complaints spreadsheet our regional manager uses." D1's slot asks only what the spreadsheet counted |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope, "I trained new tellers on our escalation script." The pack's observation is that your material says tellers, not supervisors |
| Wrote the escalation script | Inflated form of F4 | "our escalation script" as quoted; ambiguity resolves downward |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." A plan, never a past |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." A plan, never a past |

# Sources

Provided documents: the JD you pasted; the four values copied on 11 November 2026 from ashgrovecu.org/about/values (pasted text, not fetched); the recruiter's email about the process; your summary of the July 2026 strategy brief (the brief itself was not provided); your background as you wrote it. No `tuesday-dossier.md` was present.

Searches and fetches: none were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Your pasted values text fixes the four value names, the values cheat sheet and G1 to G5, so no page was fetched |
| 2. Ashgrove interview process, member-experience role family | skipped | The recruiter's email names three sessions on 20 November, who runs each and what each holds, which fixes the loop and the persona weights |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief, under six months old, fixes the grounding brief and the CO and CASE questions |
| 4. Interviewer names at Ashgrove | n/a | Only roles are known (recruiter, Head of Member Services, two branch managers), so no query could be formed; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

# Upgrade menu

- Panel names and roles, once assigned → an interviewer read, persona weights from their public professional footprint, and a reverse question tied to each person's path
- The recruiter's detail on how the 20-minute case runs, and anything to prepare → H1 to H3 retuned to the real format; a pre-declared deliverable would add a graded-deliverable section
- Who counts as the senior leaders in the monthly reporting (the recruiter can say) → F8 and C3 rewritten against the real audience
- The strategy brief itself, pasted → the grounding brief rows move from your summary to the brief's own wording, and S1 to S4 gain whatever the summary left out
- Any figure from your complaints log or spreadsheet, such as what each line counted or how it was counted, and which tool the spreadsheet was built in → D1 gains a defend-the-number rehearsal, and F3, F7 and F9 can move from a slot to quoted evidence
- Any answer to the slots in F1, F4 or F5, such as a part of a complaint beyond the log that was yours, coaching beyond tellers, or contact with digital colleagues → those rows and the questions that rest on them (C1, D2, D3, A4, H3, I1) regenerate on your own words
- Hours you have before the 20th → a prioritised prep schedule sized to them
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and an objection ranked from it, replacing this pack's inference about C1
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports and recent organisation context for Ashgrove; nothing in your inputs depended on it
