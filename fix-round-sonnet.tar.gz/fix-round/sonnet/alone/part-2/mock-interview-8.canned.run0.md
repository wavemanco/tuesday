I'll read the reference files before writing anything.
I'll use the Edit tool instead.
Dara, your prep pack is saved as ashgrove-credit-union_member-experience-lead_interview_pack.md. It covers all three rounds on 20 November, with a bank of questions for each round. It's built from the JD, the four values, the recruiter's email and the four strategy points you pasted. I ran no web searches, because those already covered everything a search would have fed. Interviewer names aren't assigned yet, so the persona weights come from each round's role.

The pack names D1 as your highest-ROI prep. It's the question on scope across branches and the contact centre, and it comes with follow-ups and the exact wording for conceding the gap. G1, the practice escalation case for the panel, is second.

Say the word and I'll play a persona on D1, or on G1 as the branch-manager panel.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead — Ashgrove Credit Union — interview loop pack

**Candidate:** Dara. **Mode:** loop, three rounds on 20 November 2026, built on 11 November 2026.

| Round | Length | Who | Relationship | Pack letters |
|---|---|---|---|---|
| 1 | 30 min | The recruiter | Recruiter screen | A, B |
| 2 | 45 min | Head of Member Services | Your would-be manager; mostly behavioural | C, D, E |
| 3 | 60 min | Panel of two branch managers; includes a 20-minute case on a complaint escalation | Panel, and the values round: they score against the four published values | J, G, H |

Interviewer names are not yet assigned, so there is no interviewer read; persona weights come from each round's relationship and from the recruiter's description of it. The loop is established by the recruiter's email, so no archetype fallback is used.

## How to use this pack

- **Personas describe how a question is asked; types describe what is scored.** Every question carries one type tag:
  - VAL: past behaviour measured against Ashgrove's published values.
  - EXP: whether your own account of your background survives follow-up questions.
  - JD: a stated responsibility or requirement in the job description.
  - CO: knowledge of Ashgrove's strategy and competitive position.
  - CASE: a live problem set in the role, scored on structure.
- **Guidance is scaffolding, not a script.** Say it in your own words, in 90 to 120 seconds.
- **Answer slots** are instructions for the interview itself. They are not questions to me and need no reply here. Where the material does not show something, the slot gives two honest branches, and either is a good answer.
- **Provenance** is `[grounded]` (traceable to something you or Ashgrove supplied), `[inferred]` (derived from an adjacent source) or `[generic]` (a pattern with no claim about you or Ashgrove). Quotes beside a label are the only sentences of yours the guidance rests on.
- **Highest-ROI prep in the pack: D1.** It is the objection most likely to be put to you in some form, and it is the one a rehearsed, non-defensive answer changes most. G1, the practice escalation case, is second.

## Fit snapshot (shared by all three rounds)

None of the JD's requirements is a gate in the sense of a licence, authorisation, location or similar term, so there are no gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length. It is a self-reported line with nothing inspected behind it, so expect a probe on what the work covered. Lead in the quote's own terms: six years in retail banking, the last three as a branch supervisor |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal complaints log and does not show what governed it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's wording makes a probe on what governed the log likely. If it ran to external rules, say which and how they shaped what you did, in your own words; if it was an internal process, or you do not know what governed it, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | The quote is the branch's log; the JD's scope is the whole process across branches. Words: "I handled the branch's formal complaints log." Answer slot: the JD's scope makes a probe on what lay before and after the log likely. If any step beyond the log was yours, say which and what you did; if the log was the part you held, or you did not see the rest, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing from the branch is offered as contact-centre work |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote shows a monthly complaints spreadsheet your regional manager uses and does not show what it held. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's reporting line makes a probe on what the sheet showed likely. Say what it held and how it was used, in your own words; if it held less than the JD's line asks, or you do not know how a figure on it was counted, say so plainly and stay with the sheet |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The quote is new tellers and a script. Words: "I trained new tellers on our escalation script." Answer slot: if any of that training reached people beyond new tellers, say who and what you did; if none did, say so plainly and stay with the tellers and the script |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing here. Answer slot: if you have worked with a digital, online or app team on anything members used themselves, say what and what your part was; if you have not, say so plainly and say what you would ask a digital team first, as a plan |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated limit. Words: "I've never presented to anyone above regional level." The quote says nothing about what presenting you have done, and nothing is added. Then how you will get ready, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet and does not say which tool. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say which tool the sheet was built in and what you did in it, in your own words; if it was not the tool the JD names, say so plainly and say which it was |

## Grounding brief: Ashgrove's 2026 strategy

Source: the strategy brief Ashgrove published in July 2026, as relayed in your message. Only the four points below were supplied; the full brief was not read.

| Brief item | Provenance | Questions it raises for this role | Used in |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] | What the 40% counts, and whether complaints are inside it. The JD's digital line sits directly beneath it | A3, D3, R2-4 |
| Consolidate eight branches into five hubs over 2027 | [grounded] | How complaints from affected branches are tracked through the change. It sits beside the value "Neighbours, Not Numbers", and the round 3 panel is branch managers | A3, J3, G3, R3-3 |
| Launch a small-business lending product in Q1 2027 | [grounded] | Whether a new product brings a new kind of complaint, and whether this role would own it. The brief as relayed does not say | A3, R2-5 |
| Main competitive pressure: app-only banks | [grounded] | What a complaint journey should feel like to a member who could leave through an app; a view worth having | A3, D3 |

Use the vocabulary the brief uses (digital channels, hubs). Do not offer a figure beyond the four items above.

# Round 1 — recruiter, 30 minutes

## Persona table

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational | Friendly, unstructured; casual questions that are still scored | high | The recruiter screen prior is conversational plus a light skeptic, and the email describes this as 30 minutes with the recruiter | A 90-second arc built only from your quoted sentences (A1); treat "what stood out" as scored (A3); use the reverse questions below at the close |
| Skeptic (light) | Quiet knockout checks on the gaps | medium | The recruiter prior includes knockout checks, and F4 and F8 are limits you have stated yourself, so they are the cheapest to probe | State the limit plainly, then a plan (B1, B2) |
| Others | No separate bank | none | Nothing in the recruiter's description points to them | The drill can supply them if you want |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Three beats, each a clause the quotes state: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log you handled; the monthly complaints spreadsheet you built, which your regional manager uses. Tell them in your own words in about 90 seconds, then say in one sentence why this role, in your own words. Nothing is added between the beats | F1, F2 and F5 are the sentences a recruiter checks against the JD. EXP because it tests whether the account is yours; the delivery is casual and still scored |
| A2 | "What draws you to a member-owned credit union?" | VAL | [generic] | A selection scaffold, since nothing in your material speaks to this. Choose one specific thing about member ownership that matters to you and say it in a sentence; if it fits, tie it to "we decide from the member's side of the counter". If nothing about the ownership model in particular draws you, say so plainly and say what about this role does | The premise is the JD's own description of Ashgrove; VAL because the answer should echo a published value rather than generic virtue. `[generic]` because it is a pattern for the question |
| A3 | "We sent you the strategy brief — what stood out to you?" | CO | [grounded] | Choose one of the four items in the grounding brief, say what it changes for complaints work in your own view, and name one thing you would want to know. Do not recite the list. The grounding brief's third column gives the questions each item raises. No claim about your past is needed | Differentiator question from the brief the recruiter sent. CO because it tests altitude at the company's own level of strategy |
| A4 | "From the member's side, what does a good complaints process look like?" | JD | [generic] | A view, not a past claim: what the member should experience from first contact, such as being heard, being told what happens next, and being told the outcome in words they do not need explained twice (the Plain Words value). Add one thing you would measure. Say nothing about what you did | The complaints process is the heart of the JD; the recruiter asks it casually. `[generic]` because the answer is a pattern for the problem |
| A5 | "Tell me about the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | In the quote's terms: you built it, it is monthly, your regional manager uses it. Answer slot: the JD's reporting line makes a probe on what it showed likely; say what it held and how it was used, in your own words; if it held less than the JD's line asks, or you do not know how a figure on it was counted, say so plainly and stay with the sheet. Second slot: say which tool it was built in; if it was not the tool the JD names, say so plainly | F5 and F9 are the rows most likely to be probed. EXP because it tests the claim itself |
| B1 | "You haven't worked in a contact centre, and this role spans branches and the contact centre. How would you get up to speed?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment first, in your words: "I haven't worked in a contact centre." Then a plan, said as a plan: what you would want to see in your first weeks and whom you would ask, in your own words. Do not offer branch work as contact-centre work. Do not apologise past the one sentence | F4 is a stated limit and the most visible one, so a recruiter screening for knockouts will reach it. JD because it scores a stated requirement |
| B2 | "The role presents to senior leaders. How do you feel about that?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment in the quote's words: "I've never presented to anyone above regional level." Then a plan for how you will prepare and whom you would rehearse with, in your own words. Do not describe a confidence you cannot point to | F8 is the second stated limit. The recruiter round is the cheapest place to say it plainly, and D2 returns to it harder |
| B3 | "To confirm for the file: do you have four-plus years in financial-services customer operations?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Answer in the quote's terms: six years in retail banking, the last three as a branch supervisor. If asked which parts match "customer operations" in the JD's sense, answer from your own record and not from an estimate | F1 is the knockout the recruiter is paid to confirm. JD because it is a stated requirement |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "How is the contact-centre side of this role set up today, and who would the role work with there?" | It converts the stated gap into a plan and shows you are already thinking about the half of the role you have not worked in |
| R1-2 | "Is the 20-minute case on 20 November built from a scenario you can describe, and who will be on the panel?" | Logistics a recruiter can answer in one email; it also removes an unknown from round 3 |
| R1-3 | "Which of the JD's requirements does the hiring team treat as non-negotiable?" | Tells you where to spend the remaining prep, and a recruiter can often answer it |
| R1-4 | "Which of the four priorities in the strategy brief does this role depend on most?" | Shows the brief was read for the role, not for the headlines |
| R1-5 | "What happens after the 20th, and when would you expect to come back to me?" | Practical close; leaves the screen on a forward note |

# Round 2 — Head of Member Services, 45 minutes

## Persona table

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | Open "tell me about a time" prompts in a behavioural register | high | The recruiter calls this round mostly behavioural, which lifts the prior beyond the usual hiring-manager mix | Choose stories where the hard truth actually landed; "we" for context, "I" for your own part; where nothing comes to mind, say so plainly (C1 to C3) |
| Skeptic | Persistent probing of the gaps, as the person who would carry the risk | high | A hiring manager is buying capability and derisking gaps; F3, F4 and F8 are where the JD's scope outruns your material | One objection rehearsed until it is boring (D1); calibrated candor instead of bluffing a competency |
| Data-Driven Prober | Reads your account line by line and asks about the reporting | medium | The role reports monthly on complaints, and the spreadsheet is the one reporting artifact you have named (F5, F9) | Say what you can and cannot say about the sheet and the log; say plainly when you do not know (E1 to E3) |
| Case/Strategist | Live problems from the manager's own roadmap | low | The recruiter placed the 20-minute case in round 3, so a full case here is less likely; D3 and E3 cover the lighter form | Clarify before structuring; say the structure aloud |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You handled the branch's formal complaints log and you haven't worked in a contact centre. This role owns the whole process across branches and the contact centre. Why should we think you can?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre"; "6 years in retail banking, the last 3 as a branch supervisor" | **The highest-ROI rehearsal in this pack.** Level 1, concede first, then hold only what the quotes carry: "I haven't worked in a contact centre. What I handled was the branch's formal complaints log, in six years of retail banking, the last three as a branch supervisor." Then a plan for the rest, said as a plan: the first two things you would want to learn and from whom, in your own words. Follow-up 1, "What in that log carries over to a process this wide?": answer slot: if handling the log showed you where complaints came from or went next, say what, in your own words; if it did not, or that was not yours to see, say so plainly and return to the log. Follow-up 2, "So why not someone who has worked in a contact centre?": hold, do not argue you are better; concede: "That's a fair comparison. I haven't worked in a contact centre. What I can offer is the log I handled and a plan for learning the rest." The limit, named before it is asked for: your material is the branch's log, not the process across sites, and the wording never widens it. Never fold the core claim to restore harmony, and never add a thing you did | F3 and F4 are where the JD's scope presses hardest against your quotes, so this objection arrives in some form from a hiring manager. JD because it scores the stated scope; it carries the most follow-up levels and the exact concession wording because it is the likeliest question |
| D2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose between the two limits you have stated and say which you would rank weakest and why, in your own words. For each, the plain acknowledgment ("I haven't worked in a contact centre"; "I've never presented to anyone above regional level") and then a plan for closing it, said as a plan. Do not answer "nothing". The digital line is one your material is silent on; see D3 | F4 and F8 are the two limits already on the table, and the question asks you to rank them, which is the honest-self-assessment test a skeptic is running. JD because it scores the listed requirements |
| D3 | "The brief aims to move 40% of member service to digital channels by 2028. What would you bring to the self-service side of this role?" | CO | [grounded] | Answer slot: if you have worked with a digital, online or app team on anything members used themselves, say what and what your part was, in your own words; if you have not, say so plainly and say what you would ask a digital team first, as a plan. Use the brief's own vocabulary; do not offer a number beyond the 40% | F7 has no evidence in your material and is the JD line most likely to be left unrehearsed. CO because the question is set against the strategy brief; the JD's digital line is the raising source |
| C1 | "Tell me about a time you delivered an unpopular truth to someone more senior." | VAL | [generic] | A selection scaffold, since no quoted sentence carries it. Pick an occasion with a named stake, a moment you did not fold, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Where the truth landed, say so; where it did not, say that too | A standard behavioural stem, and the round is mostly behavioural. F6 and F8 make seniority a likely theme. VAL because it scores behaviour against honesty and member-first values rather than generic virtue |
| C2 | "When did you put a member ahead of a branch target or an internal measure?" | VAL | [generic] | A selection scaffold. Pick an occasion where the member's interest and an internal interest pulled apart, say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First is the first published value, and a manager who works under it will test it early. VAL |
| C3 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "trained new tellers on our escalation script" | The quote is new tellers and a script: say it at that scope. Answer slot: if any of that training reached people beyond new tellers, say who and what you did, in your own words; if none did, say so plainly and stay with the tellers and the script. If no occasion of coaching through a live escalation comes to mind, say so plainly and describe how you would coach one | F6 is the JD's coaching line, and the nearest evidence is the tellers. JD because it scores the stated coaching responsibility |
| E1 | "Take me through the monthly complaints spreadsheet — what is on it and who reads it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The reader is in the quote: your regional manager. Answer slot: say what the sheet held in your own words; if you do not know how a figure on it was counted, say so plainly and say what you do know. Stay with the sheet and do not describe reporting you did not build | The Prober reads the one reporting artifact you have named (F5, F9). EXP because it tests what is actually yours |
| E2 | "Walk me through the branch's formal complaints log. What rules did it have to follow?" | EXP | [grounded] "I handled the branch's formal complaints log" | The quote supports the log and your handling of it. Answer slot: the JD's wording makes a probe on what governed the log likely; if it ran to external rules, say which and how they shaped what you did; if it was an internal process, or you do not know what governed it, say so plainly and describe how the log worked | F2 is where the JD names the requirement and your quote names only the log. EXP because it checks the claim; the second branch lets the premise be false |
| E3 | "If I gave you complaints data from every branch and the contact centre, how would you set up a monthly report on volumes and resolution times?" | CASE | [generic] | Say your structure aloud and state a hypothesis early. Clarify first: what counts as a complaint, how it is counted the same way in branches and the contact centre, and where the clock starts and stops. Then who reads it and what they must decide, one view for volumes and one for resolution times with a trend, and what would make a figure untrustworthy. A method for the problem, so no claim about your past | The JD's reporting line (F5) asked as a decision. CASE because it scores structure and clarifying questions; `[generic]` because it is a pattern for the problem |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would a good first 90 days look like in this role, and what would you want to have seen by then?" | Asked of your future manager, it turns the round into planning and shows you are thinking about the first three months |
| R2-2 | "Who receives the monthly complaints report today, and what do they do with it?" | Ties to the reporting line and tells you what the report is for |
| R2-3 | "Are complaint volumes and resolution times measured the same way across branches and the contact centre today?" | Shows the E3 thinking in live form and surfaces whether the process really is shared |
| R2-4 | "In the brief's 40% digital target, what counts as the 40%, and are complaints in it?" | Uses the brief's own number and asks what the relayed text does not say |
| R2-5 | "With the small-business lending product launching in Q1 2027, would complaints on it come to this role?" | Shows the brief was read for what it adds to the role's scope |

# Round 3 — panel of two branch managers, 60 minutes

## Persona table

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | Scenario prompts, each scored against one of the four published values | highest | The recruiter states the panel is the values round and scores against the four values | One story per value where one of your quoted sentences carries it, a selection scaffold ending in its honest branch where none does (J1 to J4) |
| Case/Strategist | A live escalation problem, 20 minutes | high | Stated in the recruiter's email as part of this round | Clarify, objective, owner, approach, measure, risk; say it aloud (G1 to G3) |
| Peer Evaluator | "What would you need from me", where your role ends and ours begins | medium | The role coaches branch supervisors, so branch managers are people it works beside; this is an inference from the JD and the recruiter's description, not from a profile | Propose principles for the seam instead of pretending to know it; reciprocity framing (H1 to H3) |
| Pressure | Time-boxing during the case | low | A 20-minute case may be time-boxed; nothing else points to stress tactics | Pause, restate, hold a position through two follow-ups |

## Values cheat sheet (the values round)

Official names and wording are from the values page you copied on 11 November 2026.

| Value | Working meaning | Your mapped story or scaffold |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | No quoted sentence carries a story. Scaffold: pick a decision where the member's interest and a branch or process interest pulled apart, what you chose, and what it cost; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (J1) |
| Plain Words | If a member needs it explained twice, the writer got it wrong | F6: "trained new tellers on our escalation script" — your message. The script is words; the slot in J2 below asks whether the wording was ever yours to change |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Scaffold: pick a time local knowledge of a community around a branch changed how you handled something; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (J3). The branch-to-hub change makes this the value most likely to be tested live |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2: "I handled the branch's formal complaints log" — your message. The slot in J4 asks whether any complaint stayed with you to the end |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | A selection scaffold, since no quoted sentence carries it. Pick a decision where the member's interest and an internal interest pulled apart, say what you chose and what it cost, and let the panel draw the inference. Use the value's own words only if they fit naturally. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First is a published value and the panel scores against it. VAL because it tests specific past behaviour. `[generic]` because it is a selection pattern |
| J2 | "Tell me about a time something you explained didn't land the first time." | VAL | [grounded] "trained new tellers on our escalation script" | The beats the quote states: you trained new tellers, and the thing you taught was a script. Answer slot: the value is about wording, so expect a probe on whether the script's wording ever needed to change; if you changed or flagged wording, say what and why; if you did not, or it was not yours to change, say so plainly and say how you trained them on it | Plain Words is a published value, and the script is the one wording artifact your quotes name (F6). VAL |
| J3 | "Tell me about a time local knowledge of the community around a branch changed how you handled something." | VAL | [generic] | A selection scaffold. Pick one occasion where something specific about the people or place around a branch shaped what you did, and say what it was. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not claim knowledge of a town you cannot back with a specific | Neighbours, Not Numbers is a published value, and branch managers are the audience most likely to test it. VAL |
| J4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | The quote supports the log you handled. Answer slot: if a complaint or problem stayed with you to the end, say what it was and what you did, including if it was not solved; if none did, say so plainly and stay with the log you handled | Own the Fix is a published value, and the log is the nearest story your quotes carry (F2). VAL |
| G1 | "Practice case, ours and not theirs: a member has complained three times about the same fee. The branch says it is resolved; the member says it is not, and it has now reached the contact centre. Walk us through what you would do." | CASE | [generic] | Clarify first: what the member was told each time, who holds it now, and what clock or rules apply. State the objective aloud: the member knows who owns it and what happens next, in words they do not need explained twice. Name one owner (Own the Fix), decide what needs fixing today and what is learned afterwards, say what you would record, and name how you would know it worked. Challenge one premise respectfully. A pattern for the problem, so no claim about your past | The recruiter says a 20-minute case on a complaint escalation is part of this round (F3). CASE because it scores structure and clarifying. The scenario is a practice invention; the real case is not known |
| G2 | "A branch supervisor you coach keeps escalating complaints they could have settled. How do you handle that conversation?" | CASE | [generic] | Say the structure: find out what makes escalating feel safer to them, agree what they can settle without sign-off, agree how you will check, and say what you would do if it continues. Do not describe a coaching practice as something you have done; this is how you would approach it | The coaching line (F6) as a live problem for the people who manage the supervisors. CASE |
| G3 | "Eight branches become five hubs over 2027. A member in a town losing its branch says nobody local is listening to their complaint. What do you do, and what would you measure?" | CO | [grounded] | Clarify what has been decided and what is still open, and what the member needs now. Own the fix, and say it in plain words; keep Neighbours, Not Numbers in view. For measurement, name how you would see complaints rise or fall around the change: by area, over time. The brief says the consolidation is planned; do not speak as if you know details it does not give | Grounded in the brief's consolidation line. CO because it needs strategy fluency, and the panel are branch managers who may have been affected; whether they are is not known |
| H1 | "Our supervisors are busy. Where does your role end and mine begin when a complaint escalates?" | JD | [generic] | Propose principles for the seam instead of claiming to know it: who owns the member's outcome, who owns the learning, when you step in and when you step back. Add what you would want from them, and what they could expect from you. No claim about how you have shared work before | The role coaches branch supervisors (F6), so the seam with their managers is a live question. JD; reciprocity framing |
| H2 | "Tell me about a disagreement with a colleague over how to handle a complaint." | VAL | [generic] | A selection scaffold. Pick one disagreement where you held a view and still worked together afterwards; say what you held to and what you conceded. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Disagreement with equals is a standard peer probe, set in the JD's own subject. VAL |
| H3 | "What would you need from us in your first three months, and what could we expect from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | What you need: access to the process and the people in it, in your own words. What they could expect: you were a branch supervisor for three years, said at that scope. Do not claim more than the supervisor role; no coaching claim | Reciprocity framing for a peer-style panel. The only fact about you it uses is the quote in F1. JD |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What does an escalation from your branch look like when it goes well, and when it goes badly?" | Branch managers know this first-hand, and asking shows you are listening to their side of the counter |
| R3-2 | "What could a new person in this role do in the first month that would genuinely help your branch?" | The reciprocity question for a panel that will work beside the role |
| R3-3 | "How will the move to five hubs change what branch supervisors need from this role?" | Uses the brief and asks where Neighbours, Not Numbers is tested in practice |
| R3-4 | "Which of the four values is most tested when a complaint comes in, and what does that look like?" | Shows you treat the values as working tools and not as slogans |
| R3-5 | "Where do your supervisors most need support on escalations today?" | Speaks to the coaching line directly and invites the panel to describe the problem themselves |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A1, B3 |
| Experience handling regulated complaints | E2, D1, G1 |
| Own the member complaints process end to end across branches and the contact centre | D1, B1, G1, G3 |
| Report monthly on complaint volumes and resolution times | A5, E1, E3 |
| Coach branch supervisors on escalations | C3, G2, H1 |
| Work with digital teams on self-service journeys | D3, A3 |
| Confident presenting to senior leaders | B2, D2 |
| Comfortable with Excel reporting | A5, E1 |
| Four published values | J1 (Members First), J2 (Plain Words), J3 (Neighbours, Not Numbers), J4 (Own the Fix) |

## Prohibited claims

The pack will not coach these. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says the branch's log, not the process across sites. The slot in F3 stays inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The pack's observation: your material says a formal log, and does not show what governed it |
| Has contact-centre experience | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders or executives | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: new tellers and a script |
| Reported monthly on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: a monthly complaints spreadsheet your regional manager uses |
| Built reporting in Excel | Inflated form of F9 | F9's quote at its own scope: a spreadsheet; the tool is not stated |

## Sources

**Provided documents:** the job description as pasted; the four published values as pasted (copied on 11 November 2026 from the values page on ashgrovecu.org); the recruiter's email on the process; the four strategy-brief points as relayed from the July 2026 brief; your background as written in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values, with their names and wordings, fix the values cheat sheet and the VAL bank |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email already gives three sessions with who runs each and what each holds, which fixes the loop and the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The four brief points in hand fix the grounding brief, A3, D3 and G3 |
| 4. Interviewer name and Ashgrove | n/a | Only job titles were given, so there is no name to form a query from; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names, once assigned → a reading of each person's public professional footprint, persona weights tuned per person, and a reverse question tied to their own path
- The recruiter's description of the 20-minute case, or its materials → G1 to G3 become a rehearsal of the real format instead of a practice scenario
- The full July 2026 strategy brief → the grounding brief and A3, D3, G3 gain the brief's own numbers and definitions, such as what the 40% digital target counts
- Your answers to the slots in F2, F3, F5, F6, F7 and F9, in your own words → those rows move from discovery or transferability toward presentation or none, and the matching bank cells become story-mapped
- A template of the monthly complaints spreadsheet with no member data in it, or the branch's complaints-handling procedure → F2, F5 and F9 move from medium toward high, because the artifact can be inspected
- Hours you have per day before 20 November → a prep triage section: the few things done well, in order
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports and recent organisational context for Ashgrove
- A `tuesday-dossier.md` from an evidence-recovery pass on your background → verified evidence and the objection worth deepest rehearsal arrive from the dossier rather than being inferred, and each weak area gets an allowed strategy
