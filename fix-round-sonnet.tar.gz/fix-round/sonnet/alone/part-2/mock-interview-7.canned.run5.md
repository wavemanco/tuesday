I'll read the reference files the skill requires before writing anything.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-canned-adc39aba/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 21 questions across six interviewer styles.

I built it on one assumption: that Tobias is the hiring manager for Saltmarsh's "Outage Hour". Their careers page describes it as a single 60-minute interview with no take-home. It starts with a tabletop on a simulated outage during a live event, then moves to a values conversation. The pack also draws on Saltmarsh's three published values, the Project Larkspur announcement, and Tobias's GDC talk "Patch Notes Are a Promise". Larkspur and the talk came only from search-result summaries, so I couldn't check them in full.

The question to rehearse first is C1, the in-app-purchase question. You haven't worked on a game with in-app purchases, and Larkspur moves two titles to a season pass from February. It comes with three follow-ups. Your release checklist is your strongest common ground with Tobias, who was previously a QA lead.

Say the word and I'll play the skeptical hiring manager on C1, with live follow-ups and feedback against the pack's guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Did your recruiter say what the Outage Hour will cover, or which two titles the role supports? The answer would sharpen the tabletop scenarios and the Larkspur questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations, taken here as the hiring manager for the "Outage Hour" (a single 60-minute interview: a live-incident tabletop on a simulated outage during a live event, then a values conversation; no take-home). Built on one assumption: that Tobias is the hiring manager the careers page describes. Friday's session is one round, so this is a session-mode pack.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Every question carries one type tag:

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your own claims survive scrutiny and attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, recent moves |
| CASE | A live problem from the actual role, scored on structure and reasoning |

Guidance is scaffolding, not a script. Where guidance quotes your own sentence, say it in your own words at that scope and no wider. Where it gives an answer slot, the slot is an instruction for the interview, not a question for now: answer whichever branch is true, and either branch is a good answer.

The single highest-ROI rehearsal in this pack is C1 (the in-app-purchase question), with its follow-up ladder. Rehearse it until it is boring.

## Prep triage

Order, not hours. Everything not listed is insurance.

| Step | Do this | Where |
|---|---|---|
| 1 | Say the C1 answer aloud, including all three follow-ups, until the concession comes out without flinching | C1 |
| 2 | Run the tabletop aloud twice against a timer: clarify first, then who you pull in, then the two-sentence player notice | A1, E2 |
| 3 | Pick one real story per value, or settle on the honest branch for each | B1, B2, B3, values cheat sheet |
| 4 | Write down what you actually know about how the monthly retention numbers were counted, and what you do not | D1 |
| 5 | Build the 90-second journey arc from your four sentences | F1 |

Everything else is insurance.

## Fit snapshot

Evidence quotes are your own words, nothing summarized. The JD's "3+ years" line is an experience requirement, not a gate, so no row is a hard gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events line makes a probe on what a typical week's drop contained and who decided it likely. If you set the contents or the order of the drops, say how you decided; if you did not, or there was no such decision, say so plainly and describe the calendar as you ran it |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | The calendar sentence touches this requirement without showing whether it reached those four disciplines. Words you can say: "I haven't led a team." Answer slot: if you worked with any of design, art, engineering or community on a drop, say which and what part was yours; if the calendar did not put you in contact with them, or that coordination was not yours, say so plainly and return to the calendar as you ran it |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the monthly numbers, and the words stay there: "Presented the monthly retention numbers to the studio head." Answer slot: expect a probe on those numbers. Say how they were counted, what they are sensitive to, the assumption behind them you would defend least, and which part was yours; "I don't know how that was counted" is an honest branch |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on what is on the checklist. Lead in the sentence's own terms: you wrote it, and QA still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Hold your title as you stated it: "4 years as an associate producer at a puzzle-game studio." Answer slot: the JD says live-service; if your main title kept receiving new content over those years, say so in your own words and for how long; if it did not, say so plainly and describe the title as it was |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with the sentence in its own terms: weekly, your main title, two years. Expect a probe on the calendar's content, which F1's slot covers |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect the defend-the-number probe in D1. Lead with the sentence in its own terms |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The sentence already says a written document, in use by another team. Reword only that: "I wrote the release checklist our QA team still uses." Add nothing to it |
| F9 | "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" — Project Larkspur announcement, September 2026 | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The page I read does not say the role works on these titles, or that the season pass involves purchases; that is not established, so ask rather than assume |

## Reading the interviewer

Public professional footprint only. From a conference talk listing: Tobias Wrenfield is Head of Live Operations at Saltmarsh Games and was previously a QA lead at a console studio. His GDC 2026 talk, "Patch Notes Are a Promise", argues that a live team is judged by how often its patch notes describe what actually shipped.

| Observation | Practical implication |
|---|---|
| His published argument is about whether announcements match what shipped | Precision about what was shipped and what was yours is the register he is likely to value; the pack's honesty-first answers fit it |
| His earlier path was QA | The release checklist is native vocabulary for him; F4 is your strongest shared ground |
| The company's own value reads "we announce what is built, not what is hoped" | In the tabletop, state what is confirmed and mark estimates as estimates |
| The loop is a tabletop and then values, both with him | Expect the second half to test whether your first-half composure was real |

Mirror opportunity, vocabulary only: his public path runs through QA, and F4's evidence reads "Wrote the release checklist our QA team still uses." Use the checklist as common working language; do not build on anything beyond the work. Reverse question 2 uses this.

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A) | The tabletop: a simulated outage during a live event, plus questions on the Larkspur calendar | High. The careers page documents the tabletop as the first half of the interview, and a hiring manager prior points the same way | Clarify, then structure, then answer; think aloud; challenge one premise respectfully |
| Values/Behavioral (bank B) | The second half, on the three published values | High. The careers page documents a values conversation | Map a story only where your own sentence carries one; otherwise choose by criteria and use the honest branch |
| Skeptic (bank C) | Probing the stated gaps: in-app purchases, team leadership, one title versus two | High. The hiring-manager prior derisks gaps, and two of yours are stated in your own message | Rehearse C1 until boring; concede in your own plain words, hold what your sentences carry |
| Data-Driven Prober (bank D) | Retention numbers and what actually shipped | Medium. The retention sentence invites it, and his talk's theme is accuracy of what is claimed | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Pressure (bank E) | The tabletop gets time-boxed or interrupted | Low to medium. No source says he interrupts; a simulated outage makes it plausible | Pause, restate, hold through two follow-ups, concede only what is real |
| Conversational (bank F) | The opener and the motivation question | Medium. Unscripted openers appear in most interviews and are still scored | A 90-second arc built only from your four sentences |
| Peer Evaluator | No bank | Low. A hiring-manager round is not a peer round, and no source names a peer | Not rehearsed; if the relationship turns out differently, the pack gets reweighted |

## Question banks

### A. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a live event and a reward is not granting for some players; support tickets are climbing. You have the first hour. Walk me through it." | CASE | [generic] | Clarify first, aloud: what is broken, for whom, is the event still live, what engineering can confirm and by when, what is known versus guessed. Then who you pull in: the JD names design, art, engineering and community, and QA owns the checklist. Then the decision, with what you would need to know to make it. Say the two-sentence player notice aloud, limited to what is confirmed, as the published value has it: "we announce what is built, not what is hoped". Close with what goes into the review afterward. The question needs no claim about your past, so the guidance makes none | The careers page documents the tabletop format, so this is the likeliest opening; the scenario itself is a pattern. CASE because it scores structure under time pressure; it also exercises F2's coordination and F8's written communication |
| A2 | "From February, two of our titles share one events calendar under a season pass, and the per-title event teams become one live-ops group. What do you need to know first to plan that calendar?" | CO | [grounded] | Clarify, then structure: what the season pass must deliver and by when; whether each title's events must fit shared slots; who arbitrates when the two collide; how QA capacity and one checklist stretch across both; how success is measured across both. Challenge one premise politely, such as whether one calendar means one cadence. You have read an announcement summary, not the plan, so say what you are inferring. If monetization comes up, say it plainly: "I haven't worked on a game with in-app purchases" | The announcement is the freshest company move I could find, and it reshapes the role's calendar, so CO. F9 is why the monetization concession must be ready here |
| A3 | "Two events from different titles want the same weekend and the same QA window. How do you decide?" | CASE | [generic] | Criteria said aloud: what is ready and verifiable against the checklist; player impact if each one slips; what has already been announced to players; what you would need from QA and engineering. Use the published value to rank when criteria tie: "when the calendar and the players disagree, the players win". Then how you would tell both teams. The question needs no claim about your past, so the guidance makes none | Tests the calendar requirement F1 as a live decision rather than a record; a pattern, hence generic. CASE because the answer is structure, not experience |
| A4 | "An event has just ended, and retention for the players who joined during it looks lower than the previous event. How do you structure the post-event review, and what do you report?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Clarify before concluding: is the comparison like for like (length, rewards, platform, where players came from), how big each cohort is, what else changed. Then segments, then what you would report, and what you would say you cannot yet tell. The one real thing your material carries here is the sentence "Presented the monthly retention numbers to the studio head."; say it at that scope and let the interviewer draw the inference | The JD's KPI ownership line is the likeliest place a case lands on the post-event requirement F3. CASE because it scores how you reason about a drop in a metric, not what you have owned |
| A5 | "Walk me through the release checklist you wrote: what's on it, and how did QA use it?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Two beats the sentence states: you wrote it, and QA still uses it; tell them in your own words. Say what is on it only as far as you actually remember it. Answer slot: the published value says every release leaves "the checklist better than it found them", so expect a probe on whether it changed after you wrote it. If it did, say what changed and what part was yours; if it did not, or the changes were not yours, or you do not know, say so plainly and describe the checklist as you wrote it | F4 is the requirement with the strongest evidence and the shared vocabulary with the interviewer, so it will be tested for depth. JD because it scores the stated checklist requirement directly |

### B. Values/Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] | Selection scaffold for "Players Before Plans": pick a time a planned date or drop conflicted with what players needed or experienced. It needs a named stake, the decision you made, and what happened to the calendar after. Use "we" for context and "I" for your own decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide; the published value is your ranking rule | The first published value, raised verbatim on the company's own page; the scaffold is selection-based because no sentence of yours carries this story |
| B2 | "Tell me about a time you held back an announcement because the work wasn't built yet." | VAL | [grounded] | Selection scaffold for "Ship the Patch Not the Promise": a time a date, feature or fix was ready to be announced before it was ready to ship. It needs what you held back, who pushed, and how you handled that. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second published value; its connection to Tobias's public theme makes it the likeliest values question |
| B3 | "When have you left a process or a checklist better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the checklist, and QA still uses it; those are the two beats. Answer slot: if there was something in its place before, say what and why you wrote it; if there was nothing, or starting it was not yours, say so plainly and tell the checklist as you wrote it. Do not say what it improved unless you know | The third published value, and the only one where one of your sentences carries a story. VAL because the question tests the value, not the job |
| B4 | "Tell me about a time you told someone senior something they did not want to hear about a date or a number." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact afterward. Your sentence carries the audience, not the hard truth: "Presented the monthly retention numbers to the studio head." If no such time comes to mind, say so plainly, then give that sentence at its own scope, or how you would deliver the message | A persona stem applied to your one sentence with a senior audience; VAL because it scores behavior rather than knowledge |
| B5 | "Sometimes the player-first call costs us a day of an event's revenue under a season pass. Where do you land?" | VAL | [grounded] "Never led a team, and never worked on a game with in-app purchases." | State the value-based answer first: the company's own ranking is players over the calendar. Then be exact about the limit: "I haven't worked on a game with in-app purchases." Say who you would want in the room for the revenue side, as a plan | Tests whether the published value survives its commercial cost, which is Larkspur's natural pressure point; F9 is why the concession has to be accurate |

### C. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases, and this studio's calendar is moving to a season pass. What's your plan for getting up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | **Highest-ROI rehearsal in the pack.** Concede first, in your own plain words: "I haven't worked on a game with in-app purchases." Hold only what your sentences carry: "I ran the weekly content-drop calendar for our main title for the last two years." and "Presented the monthly retention numbers to the studio head."; let the interviewer decide how far they carry. The plan is a plan, never a past: what you would ask to see first, whom you would learn from, and how you would show you had got it. Follow-up 1, "What would you look at first?": answer in plan form. Follow-up 2, "So you couldn't tell me how an event is priced today?": hold to the concession and the plan, and add nothing you would have to defend. Follow-up 3, "Why take the risk?": say what your sentences show, and stop. Limit named before it is asked for: do not claim retention work as revenue work | F9 is the biggest stated gap and the one the company's own announcement makes most visible, so it will be asked in some form. JD because it scores a stated gap; the premise is sourced to your own message |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose the answer that is honestly yours, name it plainly, and give a plan, in that order. Your message states two candidates; where you are unsure about others, you may name those instead. Do not offer a false weakness. Do not guess at gaps you cannot judge | A standard Skeptic stem; the pack cannot choose your answer, only make you ready to give a real one |
| C3 | "You've never led a team, and on each update this role coordinates design, art, engineering and community. Where does your influence come from?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Concede first: "I haven't led a team." Hold the calendar sentence at its scope. Answer slot: the JD's coordination line makes a probe on which of those disciplines you worked with on a drop likely. If you worked with any of them, say which and what part you set or decided; if the calendar did not put you in contact with them, or the coordination was not yours, say so plainly and return to the calendar as you ran it. Then a plan for how you would run an update kickoff | F2 is the thinnest of the JD's own requirements, and the stated negative sources the premise. JD because it scores the coordination line |
| C4 | "You ran the calendar for your main title. This role runs two titles' calendars. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you ran in the sentence's words. Answer slot: if a second title's calendar was also yours, say which and what part; if not, say so plainly and stay with your main title. Then what you would ask first about the second title, as a plan | F1 is where the JD's two-title scope outruns the sentence. JD because it scores a stated requirement |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start with the sentence: what you presented, and to whom. Answer slot: say how they were counted, what they are sensitive to, the assumption you would defend least, and which part was yours. Name the weakest assumption before the interviewer does. "I don't know how that was counted" is an honest branch; say it plainly and say what you would ask | The only metrics claim in your material, so a prober will go here; F3 and F7 both rest on it. EXP because the question tests attribution and understanding |
| D2 | "Which retention measures would you put in a post-event review, and which would you distrust?" | JD | [generic] | Name the measures you would choose and why; for each, say what it cannot tell you (comparability across events, new versus returning players, overlapping events). Name one you would distrust and why. The question needs no claim about your past, so the guidance makes none | Covers the "comfortable with player-retention metrics" line in the JD as reasoning rather than history; a pattern, hence generic |
| D3 | "How would you verify that what our patch notes say matches what actually shipped?" | CASE | [grounded] | Structure: what the source of truth is for the build, who confirms, when, and what you do on a mismatch (announce what is built). The published value is your anchor: "we announce what is built, not what is hoped". Answer slot: if a step in the checklist you wrote compared notes against the build, say which; if it had no such step, or you do not know, say so plainly and say what you would add, as a plan | The talk's theme and the second published value both point here. CASE because it scores a method, not a record |

### E. Pressure (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, rather than a producer who has run live events on a monetized game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Pause, restate. Hold: those two sentences, at their scope. Concede: "I haven't worked on a game with in-app purchases." Do not compare yourself with the other person and do not claim more to stay in the game. Hold through two follow-ups ("So you're the weaker candidate?", "Why risk it?") by returning to the sentences, never adding to them | The pressure form of C1; pressure questions are scored on composure, so the same honest content has to survive an interruption |
| E2 | "Stop. Engineering says the fix is four hours out and the event ends in two. What do you tell players, and when?" | CASE | [generic] | Pause and restate it. Say what is confirmed and what is an estimate. Give the two or three options you would weigh and what you would ask engineering. Put the player first, per the published value, and announce only what is built. Hold your choice through two follow-ups; concede what you do not know. The question needs no claim about your past, so the guidance makes none | The tabletop gets interrupted in the stress form of A1; scored on composure rather than the right answer |

### F. Conversational (weight: medium to low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc, built only from those four sentences, in that order: the studio and your title, the calendar, the checklist, the numbers. Tell each at its own scope. Answer slot: the JD says live-service; if your main title kept receiving new content, say so and for how long; if it did not, say so plainly. Close with why live operations, in your own words | The opener is scored even when it feels casual; F5 and F6 are covered here. EXP because it tests whether your arc survives a follow-up on any sentence |
| F2 | "Why Saltmarsh, and why live operations?" | CO | [grounded] | Selection scaffold: pick one concrete thing you actually find compelling from the published values or the Larkspur announcement and say why, in your own words. If you have really read or watched "Patch Notes Are a Promise", you may say so; if you have not, do not. If no concrete thing comes to mind, say so plainly and say what does draw you. Do not build on anything shared beyond the work | Motivation is asked in every loop, and this one has real published material to anchor it. CO because it tests homework depth |

## Values / principles cheat sheet

The careers page documents a values conversation, so every published value gets a mapped story or a selection scaffold. Value names are exact, from the company's values page.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | None of your sentences carries a story here, so use the B1 selection scaffold, ending in its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | None of your sentences carries a story here, so use the B2 selection scaffold, ending in its honest branch; F4's "Wrote the release checklist our QA team still uses." is the nearest material, at its own scope |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Told at that scope; what it improved is B3's slot |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Your GDC talk argues a live team is judged by how often its patch notes describe what actually shipped. Where does that measure slip on this team today?" Ask only if you have read or watched it | Ties to his own public argument and invites a real answer; asking it without having read it would be caught |
| 2 | "You came to live operations through QA. How did that shape what you want producers to do differently with QA?" | Ties to his path, and sits where F4 is your strongest ground |
| 3 | "Project Larkspur folds the per-title event teams into one group from February. What does the first quarter look like for the person in this role?" | Shows you read the announcement and think about the role's real first months |
| 4 | "What does a good post-event review look like here, and which KPIs does the team hold itself to?" | Turns F3's thin evidence into a question about the standard rather than a claim |
| 5 | "What would you want this person to have changed after 90 days, and after six months?" | A direct way to learn the bar you are being measured against |
| 6 | "I haven't worked on in-app purchases. What is the fastest way for someone to get fluent in how events are monetized here?" Ask only if C1 or C2 came up | Converts the stated gap into a plan of your own |

## Prohibited claims

What this pack will not coach, and why. Built before the banks and binding on every cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar | Inflated form of F1 | F1's sentence at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's sentence at its own scope. The limit is the pack's observation: your material says you presented the monthly numbers |
| Led design, art, engineering and community teams | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't led a team." No slot for leading |
| Has worked on in-app purchases | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |

## Sources

Provided: the job description you pasted, and your background in your message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches sent:

- "Saltmarsh Games values" returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games mobile studio news strategy" returned https://saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise

Fetches sent: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing.

The Larkspur announcement and the talk listing were read as search-result text only, not fetched in full; details beyond those lines are not established.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | The values cheat sheet and B1 to B3: three values by official name |
| 2. Saltmarsh Games interview process, live ops | yes | Persona weights, the tabletop in A1 and E2, no deliverable section |
| 3. Saltmarsh Games strategy and recent news | yes | A2, B5, F2, reverse question 3, F9: one search; summary text only |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Reading the interviewer, D3, reverse questions 1 and 2 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

| Requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, C4, F1 |
| Coordinate design, art, engineering and community teams on each update | A1, C3 |
| Own the post-event review and the KPIs it reports | A4, D2 |
| Manage the release checklist with QA | A5, B3, D3 |
| 3+ years producing live-service games or apps | F1, C2 |
| Experience running a content calendar | A3, C4, F1 |
| Comfortable with player-retention metrics | D1, D2, A4 |
| Clear written communication | A1, E2 (the player notice), B2 |

## Upgrade menu

- Whether Tobias is the person the role reports to, and anything your recruiter said about the Outage Hour → persona weights confirmed or reweighted, and the scenario in A1 sharpened
- Which two titles the role supports → A2, A3 and F9 become specific rather than inferred
- Your answers to the F1, F2, F3 and F5 slots (what a drop contained, which disciplines you worked with, how the numbers were counted, whether the title kept receiving content) → those rows move from discovery or transferability to quoted stories, and the banks regenerate
- The artifact that would raise a medium row to high: your content-drop calendar, a sample release checklist, or the monthly retention deck → F1, F3, F4 and F7 gain an inspectable proof point
- A written sample, such as the checklist itself → F8 gets something to point at
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the studio's strategy, the full Larkspur announcement, Tobias's talks, and recent org context
- A prior evaluation of this role saved as a tuesday-dossier.md → the highest-ROI objection and prohibited claims would come from verified evidence rather than being inferred here
