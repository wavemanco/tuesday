I'll read the skill's reference files before writing anything.
I've written the prep pack and am running a quick format check before I hand it over.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-4-denied-c9f6b7d0/quartzline_product-manager-platform-apis_interview_pack.md`. It's built for your 45-minute hiring-manager conversation, on your dossier's evidence and prohibited claims. It has 19 questions across Skeptic, Case, Conversational, Pressure, Prober and Values, plus six questions for you to ask. The weights lean Skeptic and Case, since you didn't name the interviewer.

The three web searches I tried (values, interview process, strategy) were refused. Nothing in the pack comes from outside research, so it has no company-strategy questions and the two values questions are generic.

The highest-value rehearsal is A1, the objection your dossier named: you've never held the PM title or owned a roadmap, so why you over a PM with three years in the seat. The pack has you concede that first, then offer your integration work as adjacent, never as PM experience. The dossier also raised the squad-authority condition, and I turned that into questions B1 and E3 and your first question to ask.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Role:** Product Manager, Platform APIs, Quartzline
- **Round:** one 45-minute conversation with the hiring manager (named in your message; the interviewer's name was not given)
- **Built on:** tuesday-dossier.md, dossier version 1.1, decision `conditional_go`. The conditions it carries: the bridge is positioned as adjacent and never as product-manager experience, and decision authority over the two squad leads gets verified in the interview.
- **Highest-ROI prep in this pack:** A1. The underwriter named that objection from evidence you confirmed, and it gets the deepest rehearsal below.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows the company's published values |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny and attribution |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth. No CO question is in this pack, because no company research ran (see Sources) |
| CASE | Hypothetical or live problem from the actual role |

Where a guidance cell says "answer slot", it is an instruction for the interview, not a question for you now. It names what the interviewer is likely to probe, then gives two honest branches: say how it went if it was yours, or say plainly that it was not. Both branches are good answers.

## Fit snapshot

Requirement text is quoted from the dossier's `role_profile`. Evidence is quoted from the dossier's `verified_candidate_evidence`, without the confidence notes, which sit in the Confidence column and the bridge.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | A title-years line is graded as a requirement, not a gate. The underwriter's strategy is bridge: adjacent, never product-management experience. Words at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I ran quarterly roadmap-input sessions feeding client evidence to product". The second is medium confidence with limited inspectable proof, so name it as input to product before a probe does. The limit is the pack's observation: your material places this work on the integration side of the vendor's APIs, not in a product-management role. Plain acknowledgment, sourced to prohibited_claims "Having held a product manager title or role": "I haven't held a product manager title." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The underwriter's strategy is acknowledge_gap, so there is no bridge and no slot. The words come from the dossier area acknowledge_gap "Owning a roadmap and prioritization authority (R1 sub-claim)" and from prohibited_claims "Having owned a product roadmap": "I haven't owned a roadmap." Then a plan, said as a plan and never as a past: what you would find out first about which decisions are yours and how the two squad leads work, taken from the dossier's open risk on decision authority. F1's roadmap-input sessions are not a bridge to ownership |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [grounded] | transferability | The dossier lists R2 as a high-priority requirement but names no allowed strategy for it, so this row follows the routing rule: adjacent work, limit named. Words at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I wrote the internal integration playbook". The pack's observation: the quotes say integrations of the vendor's APIs and a playbook, not shipping the platform. Answer slot: the requirement's wording makes a probe on what you shipped likely. If any of this work reached the vendor's product itself, say what and which part was yours; if none did, or none of it was yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [grounded] | discovery | The quotes touch REST APIs, architecture and a playbook without showing whether API docs or schemas were part of the work. Answer slot: the requirement's wording makes a probe on API docs and schemas likely. If you read or wrote them in this work, say which and how, in your own words; if you did not, say so plainly and stay with "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I wrote the internal integration playbook" |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | discovery | The quotes show client-facing integration work and client evidence going to product. They do not show engineering or sales. The second quote is medium confidence, confirmed with limited inspectable proof, so name its limit before a probe does. Answer slot: the requirement names engineering and sales alongside customers, so expect a probe on each. If you worked with engineering or sales in this work, say how, in your own words; if you did not, say so plainly and stay with "I ran quarterly roadmap-input sessions feeding client evidence to product" and the client integrations you led |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | No verified entry speaks to this requirement. The underwriter's strategy is clarify, so the words are an answer slot. The requirement's own wording is the likely probe. If you have worked in an agile delivery cadence, say how, in your own words; if you never worked that way, say so plainly, and add what you would want to confirm about how Quartzline defines it |

No row is a gate: the dossier records `hard_gates` as empty, and the 3+ years line is a length-of-experience requirement, which is not a gate.

## Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title and roadmap gap, and the squad-authority question | 5 questions. The hiring-manager prior puts Skeptic first, and the dossier names the objection this persona asks (A1) | Rehearse A1 until it is boring: concede the limit first, then say only what the quotes carry, then give the ramp plan |
| Case/Strategist | Live problems from the role: two squads and one quarter, stalled adoption, a spec | 4 questions. The hiring-manager prior puts Case second, and the JD's responsibilities (roadmap, specs with two squads, adoption metrics) are all case-able | Clarify, then objective, segmentation, approach, metrics, risks. Ask which calls are yours before deciding, since decision authority is an open unknown |
| Conversational | The opener ("walk me through the journey"), casual questions about the JD's hot topics | 3 questions. A 45-minute conversation usually opens here, and casual questions are still scored | A 90-second arc built only from your three quoted sentences; treat every casual JD question as scored |
| Pressure | Time-boxed "why you over a PM with the actual years" and attribution probes | 3 questions. Not a stated prior for this round; weighted mid because the objection invites it | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |
| Data-Driven Prober | Reads the evidence line by line; asks for the denominator on "30+" and what the playbook contained | 2 questions. No interviewer signals were available to raise it, and your quantified claim and playbook are the natural targets | Know what you can say about how the figure was counted, and say plainly where you do not know |
| Values/Behavioral | Two stock behavioral prompts | 2 questions. Your message names one hiring-manager conversation and no values-style round, so no round of this kind is detected; the questions are generic rehearsal | Selection scaffolds with honest branches |
| Peer Evaluator | Seam-splitting between adjacent teams | 0 questions. The interviewer is the hiring manager, not a peer; the seam with the squad leads is covered in B1 and E3 | n/a |

The weights rest on the relationship prior and on your message establishing one session, not on this company's documented process: no loop source beyond your own words was available.

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap"; acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | The deepest rehearsal in the pack, asked as the underwriter wrote it because each negative in it has a source named in the Provenance cell. Level 0, the limit before it is asked: concede plainly, "I haven't held a product manager title and I haven't owned a roadmap." Level 1, the adjacent case at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs", "I wrote the internal integration playbook", and "I ran quarterly roadmap-input sessions feeding client evidence to product". The last is medium confidence with limited inspectable proof, so say it was input to product and nothing more. Offer all three as adjacent, never as product-manager experience. Follow-up 1, "so why you over three real years in the seat?": hold by returning to the quotes, and concede that you cannot match time in the seat. Follow-up 2, "what would you get wrong in month one?": concede specifically that roadmap calls and priority calls with the squads are the ones you have not made before. Close each answer with the ramp plan: you would first find out which decisions are yours and what the adoption baseline is. Do not describe your work as proof you can do the role; let the interviewer draw that inference | The underwriter named this as the likely objection, derived from evidence you confirmed rather than from a cold read of the posting. F1 and F2 are where it presses. JD because it scores the stated title-years requirement |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)"; prohibited_claims: "Having owned a product roadmap" | Answer with the area the underwriter marked acknowledge_gap, plainly and first: "I haven't owned a roadmap." Then the plan, said as a plan: on day one you would ask which roadmap decisions are yours and which belong to the two squad leads. Do not pick a different weakness to look safer, and do not offer a strength as the answer | F2 is the biggest gap and the Skeptic's stock question aims straight at it. A plain acknowledgment with a ramp plan is the strategy the dossier allows for it. JD because it scores fit against the stated responsibilities |
| A3 | "What part of an API or platform product have you shipped yourself?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Story-mapped on F3 at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I wrote the internal integration playbook". Answer slot: the requirement's wording makes a probe on what you shipped likely. If any of this work reached the vendor's product itself, say what and which part was yours; if none did, or none of it was yours, say so plainly and stay with the integrations you led and the playbook. Do not say you shipped the platform; section 13 lists that wording as not coached. The honest branch is a limit, not a confession | R2 is a must-have, and F3 is where it is probed. JD because it scores the stated requirement |
| A4 | "You've led client integrations of the vendor's APIs — why move to product?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Your reason is not in any source the pack holds, so it is yours to state. Selection criteria: one reason that is specific, forward-looking, and consistent with the adjacent case you have claimed. The thing in your material that touches product, at its own scope, is "I ran quarterly roadmap-input sessions feeding client evidence to product". If no clear reason comes to mind, say so plainly, then give the nearest thing the quote carries, or what you would want to learn in the role. Do not claim an earlier ambition to be a product manager unless it is true | The Skeptic's "why leave, why here, why now" is motivation consistency, and F1's gap makes it sharper. EXP because it tests whether your own move is explained by your own work |
| A5 | "Walk me through how those roadmap-input sessions worked." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on this sentence and nothing further: quarterly, roadmap input, client evidence going to product. Tell the beats in your own words. This claim is confirmed with limited inspectable proof, so volunteer the limit: it was input to product, and you did not own the roadmap (prohibited_claims: "Having owned a product roadmap"). Answer slot: the JD's discovery-with-integration-partners line makes a probe on how the client evidence was gathered likely. If you gathered it yourself, say how; if it came from elsewhere, or there was no gathering step, say so plainly and stay with the sessions you ran. Never supply an outcome you cannot stand behind | The underwriter graded this claim medium and warned to expect a probe. It is the evidence closest to roadmap work, so a prober will test whether it is more than it says. F1 and F5 draw on it. EXP because it tests attribution |

### B. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two squads each want the same quarter for their own item and you can fund one. Talk me through how you'd decide, and what you'd want to know first." | CASE | [generic] | Clarify first: the objective for the quarter, the evidence behind each ask (partner demand, adoption data), and which of these calls are yours and which belong to the squad leads, since the dossier lists decision authority as unknown. Then criteria, the options (fund one, split, sequence), the risk each squad carries, and how you would take the decision to both leads. Think aloud and challenge one premise respectfully, for example whether scope can shrink. The question needs no claim about your past, so the guidance makes none | F2's requirement tested live: a case lets you show prioritization reasoning without claiming to have set priorities. Asking who decides is itself the verification the dossier's condition calls for. CASE because it is a live problem from the JD's two-squad setup |
| B2 | "Partner API adoption has stalled. Diagnose it." | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify first: how adoption is defined and measured today, the baseline, the period, which partners (the dossier carries how adoption is measured as an unknown). Then segment, hypotheses, the data to check, and a first action. The stages in your own sentence, scoping, requirements, architecture, UAT and go-live, are a ready way to name funnel stages aloud; offer them as a hypothesis to test, not as something you observed. Answer slot: the JD's adoption-metrics line makes a probe on where integrations stall likely. If you saw integrations stall at a stage, say which and what you saw; if you did not track where they stalled, say so plainly and say how you would find out | The JD names defining and tracking adoption metrics as a responsibility, and no baseline is stated. CASE because it is a diagnosis delivered live |
| B3 | "A partner asks for a change to an endpoint your two squads own. What goes in the first page of your spec?" | CASE | [generic] | Problem and partner evidence first, who is affected, scope and explicit non-goals, the success measure tied to adoption, compatibility questions for the squads, and the open questions you would take to each squad lead. Say how you would check delivery against the spec with them. The question needs no claim about your past, so the guidance makes none | Covers the JD's spec-writing and delivery-with-squads responsibility and R3's technical fluency. CASE because it is a live artifact problem |
| B4 | "How would you run discovery with integration partners in your first 60 days?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A plan, so it claims nothing about your past beyond the quotes: who you would talk to first, what you would ask, what you would bring back to the squads. Where your own sentences start it: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I ran quarterly roadmap-input sessions feeding client evidence to product". Name what you do not yet know, how Quartzline's partners are segmented and how adoption is measured today, and say you would ask | Discovery with integration partners is a stated responsibility, and F1 and F5 hold the nearest evidence. JD because it scores the stated responsibility |

### C. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc from these three sentences and nothing else: "I led 30+ end-to-end client integrations of the vendor's REST APIs", "I wrote the internal integration playbook", "I ran quarterly roadmap-input sessions feeding client evidence to product". The quotes carry no order or dates, so tell them in whichever order is true and add no timeline. Say the adjacent limit once, plainly, before you are asked: this is integration-side experience. Close on the turn you want to make, in your own words, using A4's criteria | The biography question opens most conversations and is scored. It is the first place the dossier's positioning condition is tested. EXP because it tests whether the story matches the evidence |
| C2 | "Tell me about a time you had to explain a technical trade-off to someone in sales or a customer." | JD | [generic] | Selection criteria: a named trade-off, the person you explained it to, and what they did with it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack does not choose the story for you | R4 names engineering, sales and customers, and F5 shows only the customer side in the evidence. The theme comes from that requirement line. JD because it scores the stated stakeholder requirement |
| C3 | "Tell me about a time you worked within an agile delivery team." | JD | [grounded] | No verified entry speaks to this requirement, so nothing about your past goes into the answer unless you say it. Answer slot: the requirement's own wording, agile delivery experience, is the likely probe. If you worked that way, say how, in your own words; if you never worked that way, say so plainly, then say what you would want to confirm about how Quartzline defines it | F6 is a discovery gap with the clarify strategy. JD because it scores the stated requirement, preferred rather than must-have |

### D. Data-Driven Prober (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You say you led 30+ client integrations — how was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the figure counts: client integrations of the vendor's REST APIs, not clients, and not projects. Answer slot, in your own words: how the figure was counted, what it is most sensitive to, which assumption behind it you would defend least, and which part of it was yours. If you do not know how it was counted, say so plainly. Never describe a counting method you cannot repeat under a second question | The headline figure in F1 and F3 is the prober's first target. EXP because it tests the claim's attribution and denominator |
| D2 | "Walk me through the playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Story-mapped on the sentence: you wrote it, it is the internal integration playbook, and your team uses it. Say it in your own words. Answer slot: the JD's API docs line makes a probe on what the playbook covered likely. If it covered documentation of the APIs, say how; if it did not, or none of it was yours, say so plainly and stay with the playbook you wrote. The underwriter marks this claim inspectable, so if you are asked for proof, offer the playbook itself | F3 and F4 draw on it, and it is the evidence an interviewer can most easily ask to see. EXP because it tests what you actually produced |

### E. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; prohibited_claims: "Having held a product manager title or role" | A1 compressed to a minute. Concede first, sourced to the prohibited_claims item: "I haven't held a product manager title." Hold the adjacent case at its quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I wrote the internal integration playbook". Hold it through two follow-ups by returning to those sentences, never by adding to them. Concede specifically that you cannot offer time in the seat. Never fold the adjacent case just to restore harmony | The same objection as A1 in a time-boxed register, because the Pressure persona delivers it that way. F1 is the row it presses. JD because it scores the title-years requirement |
| E2 | "The 30+ integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the sentence at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs". Do not widen "led" to "built" or "owned". Answer slot, the part of the figure that was yours: say which of the 30+ you led and, in your own words, where others carried the work; if you cannot separate them, say so plainly. Concede only what you can state specifically | The stem is the Pressure persona's attribution probe, aimed at F1's strongest evidence. EXP because it tests attribution |
| E3 | "Why would our two squad leads work with someone who hasn't set priorities for an engineering squad?" | JD | [grounded] prohibited_claims: "Having set prioritization for an engineering squad"; acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Concede plainly first, sourced to the fields named in Provenance: "I haven't set priorities for an engineering squad." Hold a working method, not a record: you would agree with each lead how decisions between the squads get made before changing anything, and you would start by asking which decisions are the PM's. If pressed on what happens when the leads disagree with you, concede that you do not yet know how these leads settle disagreements, since the dossier lists decision authority as unknown, and say how you would find out. Never imply that authority over the squads exists | The dossier's second condition, squad authority, arrives as a pressure question. F2 is the row it presses. JD because it scores the responsibility to drive delivery with two squads |

### V. Values/Behavioral (2)

No published Quartzline values were in hand, so these are generic rehearsal of two stock prompts.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, what you said, how it landed, and a relationship intact at the end. Choose a story where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stock behavioral stem that a hiring manager can use in any conversation. Generic because no values were researched. VAL because it tests behavior, though not against published values |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: the customer's need, the internal metric at stake, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A second stock stem; client-facing work makes it plausible, but no quoted sentence carries a story for it. VAL for the same reason as V1 |

### Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1 3+ years product management experience | A1, A2, A4, E1, E3 |
| R1 sub-claim, owning the roadmap | A1, A2, B1, E3 |
| R2 Shipped API or platform products | A3, D1 |
| R3 Technical fluency: API docs, schemas | B3, D2 |
| R4 Stakeholder management across engineering, sales, customers | A5, B1, C2 |
| R5 Agile delivery experience | C3 |
| Run discovery with integration partners | A5, B4 |
| Write specs and drive delivery with two engineering squads | B3, E3 |
| Define and track adoption metrics | B2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's first open risk: decision authority over the two squad leads is asserted in the JD but not evidenced. It reads as diligence, and the answer tells you what you would be accepting. It also sets up A2, B1 and E3 |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second open risk: adoption metrics are named as a responsibility with no baseline stated. The answer shapes your B2 answer and tells you what success is measured against |
| RQ3 | "When the two squads' priorities compete, how is that settled today?" | Probes the seam the role sits in. You hear whether the PM is the arbiter, a facilitator or neither, which RQ1 may leave open |
| RQ4 | "How does partner feedback reach the roadmap today?" | Opens the topic F1's and F5's second quote sit on without asserting more than they say, and shows you whether that route exists here |
| RQ5 | "What would you want a new PM here to have done by day 90?" | Scopes the ramp plan you offer in A2, E3 and B4, and shows you the real expectations behind a role the posting describes in general terms |
| RQ6 | "What do partners find hardest about integrating today?" | Draws on the integration vantage in F1 and F3 and gives you live discovery material for B4, in a register that invites the hiring manager to teach |

## Prohibited claims

Built from the dossier. The first three are the dossier's `prohibited_claims`, absolute; the fourth is an inflated form built from F3.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | prohibited_claims, dossier | The plain acknowledgment, sourced to that field: "I haven't held a product manager title." Then "I led 30+ end-to-end client integrations of the vendor's REST APIs" at its own scope, positioned as adjacent |
| Having owned a product roadmap | prohibited_claims, and the acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" | The plain acknowledgment: "I haven't owned a roadmap." The quote that limits it, at its own scope: "I ran quarterly roadmap-input sessions feeding client evidence to product", which is input to product and medium confidence |
| Having set prioritization for an engineering squad | prohibited_claims, and the acknowledge_gap area named above | The plain acknowledgment: "I haven't set priorities for an engineering squad." Then the plan: ask which decisions are the PM's. No bridge |
| Shipped an API or platform product | Inflated form of F3 | F3's quotes at their own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I wrote the internal integration playbook". The limit is the pack's observation: your material says integrations of the vendor's APIs and a playbook, not shipping the platform. A3's slot stays inside that scope |

## Sources

**Provided documents.** tuesday-dossier.md, dossier version 1.1, generated by job-underwriter on 2026-08-14, decision `conditional_go`. It supplied `role_profile` (the requirement and responsibility lines in the fit snapshot, standing as the JD), `handoff_to_mock_interview` (verified evidence, weak areas with their allowed strategies, the objection in A1, open risks and employer questions for the reverse bank, and the prohibited claims), and `decision` (context only). The pasted dossier carried no `evidence_map`, `evidence_state` or `risk_register`, so none was used. Your message supplied the round: one 45-minute conversation with the hiring manager.

**Searches sent.** All three were refused, and nothing in this pack comes from them.

- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline partner API platform strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have fed a values cheat sheet, section 10, only if a loop source also named a values round; none did, so V1 and V2 stay generic |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. It would have fed loop structure and persona weights; the weights here rest on your message and the hiring-manager prior |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have fed the CO bank and a grounding brief, so the pack has no CO question and no company vocabulary section |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access for company research → a Quartzline values page, the documented loop, and recent strategy would turn the generic V1 and V2 into values-mapped questions if a values round is documented, add CO questions, and give you current vocabulary. A deeper research pass is also possible, up to 6 more searches and 2 more fetches and several more minutes, which adds a strategy brief and recent org context
- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep email → focus areas and any pre-declared deliverable, which would get its own build section
- The current posting text, since the dossier dates from 2026-08-14 → confirms the requirement lines still match, and any change would rewrite the affected rows
- The integration list behind "30+", such as a tracker export or go-live records → would raise F1 and D1 from a stated figure to an inspectable one, which is the artifact that raises that band
- The notes or invitations from the roadmap-input sessions → would raise the medium-confidence claim in F1, F5 and A5, which currently has limited inspectable proof
- Your answers to the slots in F3, F4, F5 and F6 → would move those rows from slot-shaped bridges to quoted evidence and sharpen A3, B2, C3 and D2
- How many hours you have before Thursday → a prioritized prep schedule, since none could be sized without it
