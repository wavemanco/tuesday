Running the L1 research searches on Kelverton Rail now: values, interview process, strategy, the two interviewers, and a representative JD.
Search was refused on all six calls, so the pack has no web research in it. I'm writing it from your message and the recruiter's email as you quoted it.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-5-denied-a989ebe7/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

I couldn't run any web research because all six searches were refused. I also don't have the market report text or a job description. So the pack rests on your message and the recruiter's email as you quoted it, and everything about Kelverton is labeled generic.

- **Biggest risk:** the objection that you haven't sold into rail and haven't carried a quota (B1). It gets the deepest rehearsal, and Ross's challenge on the £4M figure (C1) comes second.
- **The POV:** the pack has a 13-minute run of show, three thesis options, each with a concession, and an operator-focused close. It treats the market report as the answer every prepared candidate will bring, so it builds a move that accepts one item, challenges one, and declines one.
- **Your four hours:** the pack has a weekend schedule that puts the POV and the B1/C1 objection work first.
- **Questions:** there are 19, across five interviewer styles, plus five reverse questions.

I can play Ross on D1 or C1, or Deepa on B1, and push back on what you actually say. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to a Word document if you want one.

Can you paste the market report and the job description, or the parts you'd build on? The report would replace the pack's generic placeholder for the item you accept, the one you challenge and the one you decline with the report's actual items, and the JD would add the requirements the recruiter's email doesn't mention.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday, 60 minutes. Panel of two: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: you present a short POV on where you would take Kelverton's operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. The rest is Q&A, and Ross will push on commercials.

**Built on:** your message and the recruiter's email as you quoted it. No job description, no text of the market report, and no company research were available, so every company-specific part is labeled `[generic]` and the upgrade menu says what would replace it.

## How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Past behavior against the company's published values (no bank here: no values-style round is established by your material) |
| EXP | Whether your claims survive scrutiny; what was actually yours |
| JD | The stated role and its gaps |
| CO | Company and market knowledge |
| CASE | A live problem from the role, reasoned aloud |

An answer slot is an instruction for the interview, not a question for this conversation: say your real answer in your own words, and if the practice was not yours or never existed, say that plainly.

## Prep triage (four hours, over the weekend)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 90 min | Build the 15-minute POV aloud, twice, timed | Graded deliverable section |
| 2 | 60 min | Rehearse the highest-ROI objection and the £4M figure until both are boring | B1, C1, D1, D2 |
| 3 | 45 min | Re-read the market report with the consensus-then-divergence lens; pick one item to accept, one to challenge, one to decline | Graded deliverable section, A4 |
| 4 | 30 min | Write your reasons for the move and your reverse questions | B3, Reverse questions |
| 5 | 15 min | One full timed run: POV, then B1 and C1 cold | All of the above |

Everything else in this pack is insurance.

## Fit snapshot

Requirements are the recruiter's words as you quoted them, because no JD was supplied. No requirement here is a gate (right to work, location, travel, pay and the like are not in the material), so there are no gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The words stay at the quotes' scope: a partner channel in payments, 6 partners to 40. Your material carries no view of Kelverton's operator partnerships or of rail, so the POV's rail-facing content is hypothesis (see the graded deliverable section), never past experience. Answer slot: 6 to 40 is a figure, so expect which part was yours. Say which part in your own words; if you cannot separate your part from others', say so plainly and stay with the quote |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email, quoted in your message | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The quote says bus and light rail network planning. The pack's observation: your material does not say heavy rail or train operating companies, and does not say which side "the other side" was. Answer slot: if any of that work touched train operators or heavy rail, say which and how, in your own words; if none did, say so plainly and stay with bus and light rail network planning, and say which side you were on |
| F3 | "Ross will push on commercials" — recruiter's email, quoted in your message | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | A figure with nothing inspected behind it. Answer slots, in your own words: how the £4M was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how some part was counted, say so plainly |
| F4 | "Ross will push on commercials" — recruiter's email, quoted in your message | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically, and I haven't carried a direct quota; what I've had is influenced revenue." Then how you would learn it, said as a plan and never as a past |

## Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. The brief you quoted: where you would take operator partnerships over 18 months, no slides, land on what it means for operators.

**Grounded facts you may build on** (each quoted from its fit-snapshot row; nothing else about your past goes in the POV):

- F1: "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message
- F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message
- F4: "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message

**Rules for the build.**

- Say nothing as fact about Kelverton's current partners, customers, products or numbers unless it is in the market report you read. Frame everything else as "what I would test", and ask.
- Open by stating your reading of "operator partnerships" in one sentence and inviting correction. The phrase could mean several things and your material does not say which Kelverton means.
- Differentiate from the report; never recite it. The recruiter attached it, so the panel and every other prepared candidate have it. Bring one consensus item to prove you read it, then one thesis-driven divergence, then one anti-pick: something you would decline to do in 18 months, with the reason and what would change your mind. Choose the anti-pick from the item that looks best on paper and is hardest to tie to a benefit the operator can see. This pack has not seen the report, so it cannot pick for you.
- Close on operators, as asked: what changes for an operator at month 1, month 6 and month 18 if your plan works, stated as hypotheses, plus the one thing you would ask operators to confirm.

**Thesis options** (pick two, lead with the first; each carries a mandatory concession):

| Thesis | The argument | Mandatory concession | What it means for operators, as a hypothesis | Provenance |
|---|---|---|---|---|
| T1 | Deepen a few operator partnerships around an outcome the operator already measures | Fewer partnerships means slower breadth and more dependence on a few operators; you cannot choose the outcome without Kelverton's customer data | A named outcome the operator already tracks improves, rather than another vendor relationship to manage | [generic] |
| T2 | Make operator feedback a standing input to the product through a small set of structured partnerships | It can pull the roadmap toward the loudest operator, so it needs a stated rule for saying no | Operators' planners see their needs reach the product on a known path | [generic] |
| T3 | Open the product to third parties through a partner ecosystem | Your channel was in payments, and F4 says "Never sold into rail specifically and never carried a direct quota, only influenced revenue." A payments channel is not a rail playbook, and operators may not want more vendors | More of what an operator already uses connects to the product without operator-side work | [generic] |

Which to lead with is a judgment, not a finding: T3 is the answer your own channel background makes most predictable, so treat it as the supporting thesis, and lead with T1 or T2, which start from the operator as you were asked to.

**Run of show** (aim for 13 minutes so the panel can interrupt):

| Minutes | Beat |
|---|---|
| 0 to 1 | Your reading of "operator partnerships", invite correction |
| 1 to 3 | One consensus item from the report, accepted, with why |
| 3 to 9 | Lead thesis, then second thesis, each with its concession |
| 9 to 11 | T3 as supporting, with its concession from F4 |
| 11 to 12 | The anti-pick |
| 12 to 13 | What it means for operators: month 1, month 6, month 18, and what you would ask them to confirm |

## Persona table

Weights start from relationship priors, adjusted by the recruiter's words as you quoted them. The loop is established by those words: one 60-minute panel session. These are priors for the roles, not reads of the two people.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The POV itself, then live problems on operator partnerships | Highest. The first 15 minutes are a strategy POV (recruiter's email) and a future manager's relationship prior is Case/Strategist plus Skeptic | Clarify, objective, segmentation, approach, metrics, risks; say your reading aloud; challenge one premise respectfully |
| Skeptic | Probes on rail and on quota, probably from Deepa | High. F4 states both gaps, and a hiring manager is derisking gaps | Rehearse B1 until boring; bridge only from what your quotes carry; a ramp plan said as a plan |
| Data-Driven Prober | Ross on the £4M and on commercial outcomes | High. "Ross will push on commercials" and F3 is a figure | Know what you can and cannot say about how the figure was counted; name your weakest assumption first |
| Pressure | Time-boxed or interrupting challenge on "why you", from the Commercial Director's seat | Medium. An executive relationship prior, strengthened by "push" in the recruiter's wording | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational | The opening minutes of Q&A, perhaps the biography question | Low to medium. A warmer register is plausible from a future manager, but nothing in your material says so | A 90-second arc built only from your quotes; treat casual questions as scored |
| Values/Behavioral | No bank | Low. No values-style round is named in what you quoted and no company values were retrieved | If asked, use the selection scaffolds in B3 and E1 |
| Peer Evaluator | No bank | Low. Neither panelist is a peer on the team | None needed |

## Question banks

Highest-ROI prep in the pack: **B1**, the rail-and-quota objection. A second deep rehearsal is C1, the £4M figure. With no research, no question is grounded in Kelverton's current strategy; the CO and CASE rows are `[generic]`, which is the honest cost.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you take our operator partnerships over the next 18 months?" | JD | [grounded] | This is the POV. Build and time it from the graded deliverable section: state your reading first, close on operators. It makes no claim about your past beyond that section's quotes | The recruiter named this as the first 15 minutes; JD because it scores the announced deliverable |
| A2 | "Which operators would you start with, and why those?" | CASE | [generic] | Give selection criteria, not names: what makes an operator a good first partner (the problem it has, how ready it is, what it can validate), then say what you would need from Kelverton to choose. Name no operator or customer as fact | A live problem from the POV's own logic; `[generic]` because the pack holds no Kelverton customer data |
| A3 | "An operator's planners tell you our scheduling product doesn't fit how they actually work. What do you do in your first week?" | CASE | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Structure it: what you would ask, of whom, what you would promise nothing on yet, who inside Kelverton you would pull in. Answer slot: if your network planning work put you in a room with operators' planners, say which and what you saw, at bus and light rail scope; if it did not, say so plainly and stay with the structure | Tests the "what it means for operators" close under pressure; F2 is the only evidence on the operator side |
| A4 | "What in the market report would you challenge, and what wouldn't you?" | CO | [generic] | Use the consensus-then-divergence move: one item you accept and why, one you would test and the evidence that would change your mind, one you cannot judge from outside. Name items only from the report you read; the pack has not seen it. Concede what only an insider could know | The report is equally available to every candidate, so departing from it with reasons is the differentiator; CO because it tests homework depth |
| A5 | "How would you decide which operator partnerships to deepen and which to leave alone?" | CASE | [generic] | Objective, segmentation criteria, measures, risks; then one thing you would say no to and why. Name no figures for Kelverton | The anti-pick, asked as a decision; saying no is part of a senior partnerships role |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail and you haven't carried a quota. Why should we think you can do this job?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Deepest rehearsal. Level 1: say the negatives first in your own terms: "I haven't sold into rail specifically, and I haven't carried a direct quota; what I've had is influenced revenue." Level 2: only what the quotes carry, each at its own scope: the channel going from 6 partners to 40 with roughly £4M of influenced revenue, and bus and light rail network planning in consulting. Stop there. Level 3: a ramp plan, said as a plan: who you would meet and what you would learn in the first 90 days; the contents are yours to write. Follow-ups to expect: what influence leaves out compared with a quota, and which part of rail's commercial terms you would be slowest on. Hold by returning to the quotes, never by adding to them. Concede specifically: "I haven't had that number on my own head, and I'd ask you to test how I'd get there." Limit, as the pack's observation: your material shows no rail commercial work | F4 is the likeliest objection and the place where this material is thinnest, which is why it gets the most levels; JD because it scores fit against the role's gaps |
| B2 | "Your background is bus and light rail. Heavy rail operators are a different world, so what do you actually know about them?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say what the quote says, at its scope: bus and light rail network planning. Answer slot: "the other side" invites which side; say which in your own words. If any of that work touched train operators or heavy rail, say how; if none did, say so plainly and say what you would read or ask first | F2 is exactly as wide as it is, and this question presses on its edge; EXP because it tests what was actually yours |
| B3 | "Why leave payments for rail-tech, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | The quote gives where you have been, not why you are moving. Answer slot: give your real reason in one or two sentences, in your own words, specific to Kelverton's operator work; if part of the reason is simply wanting to be closer to transport again, say that plainly rather than polishing it | Motivation consistency is what the Skeptic scores; F1 is the career spine the story must be consistent with |
| B4 | "How much of a payments partner ecosystem carries over to operators buying scheduling software?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Name one thing that carries over and one that does not; the second is your concession. Keep the claim at the quote's scope: a channel in payments. Answer slot: say which thing carries over in your own words; if you are not sure, say so plainly and say how you would find out | F1 is the bridge from your background to this role and the transfer is its weakest joint; JD because it scores the stated role against the background |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Defend-the-number slots, all in your own words: how it was counted; what it is sensitive to; the assumption you would defend least, named before Ross does; which part was yours. If you do not know how some part was counted, say so plainly. Never describe a counting method you did not use | F3 is a headline figure with nothing inspected behind it, so it is a magnet target; EXP because it tests attribution honesty |
| C2 | "If we put a number on you here, what's the gap between your influenced revenue and a number you'd carry?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Say it plainly: "I've never carried a direct quota; what I've had is influenced revenue." Then say how you would want to be measured in year one, as a view and not a past. Answer slot: say the assumption in your influenced figure you would defend least, in your own words | F4 is a stated gap that a commercial reader will press; JD because it scores the quota side of the role |
| C3 | "What would a good commercial outcome from operator partnerships look like at month 18?" | CASE | [generic] | State the kinds of measure you would use, tied to what the operator sees, as a hypothesis. Name which Kelverton numbers you would need before committing, and commit to a direction anyway. Invent no Kelverton figures | Ross pushing on commercials makes an 18-month outcome question likely; CASE because it asks you to reason from nothing but the role |
| C4 | "Partnerships often get credit for revenue sales would have closed anyway. How do you stop that?" | CASE | [generic] | Plan, not past: the attribution rules you would agree with the commercial side before the first deal, and what you would report even when it flatters nobody. For your own past, C1's slots apply | A standard commercial challenge to a partnerships claim; the guidance makes no claim about your history |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause, restate. Hold: the two facts the quotes carry, in their own words (the channel from 6 partners to 40, and bus and light rail network planning). Hold through two follow-ups by returning to those, never by adding. Concede specifically: "I haven't sold into rail specifically." Do not claim to beat the other candidate on anything the quotes do not carry | The Pressure persona tests whether you hold without defensiveness; F4 and F2 are the material the challenge presses on |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say which part was yours in your own words; if you cannot separate your part from others', say so plainly and stay with the quote. Hold the quote through two follow-ups; concede exactly what you cannot separate | F3 returns here in its pressure form; EXP because the question is attribution |
| D3 | "Your POV was general. What would you have to know from us before any of it holds?" | CASE | [generic] | Name two or three things you cannot know from outside, say how each would change the plan, and still commit to a position. Hold it through one follow-up and concede only what you truly cannot know | The POV is built without Kelverton's internal data, so this challenge is predictable; the guidance makes no claim about your past |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc from the two quotes: the consulting years, then partnerships, with the last four in the payments ISV channel. Answer slot: how you moved from consulting into partnerships is not in your material; say it in your own words, and if it was circumstance rather than plan, say that. End with your reason for Kelverton (B3) | F1 and F2 are the two halves of the arc; EXP because it tests whether the story is consistent |
| E2 | "What are you following in scheduling and planning for operators these days?" | CO | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer slot: if you have been following something in operator scheduling or planning, say what and why it caught your attention; if you have not, say so plainly, then say what in the market report you would look at first. Keep any claim about your own planning work to the quote's bus and light rail scope | A casual question on the company's own subject is still scored; CO because it tests current interest |
| E3 | "What would you like to know about how we work with operators?" | CO | [generic] | Use the reverse questions below; never answer "I think you've covered everything" | The reverse-question slot arrives in conversational form and is weighed as a preparation signal |

### Requirement coverage

| Requirement (source) | Questions |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | A1, A2, A4, A5, D3 |
| "Please land on what it means for the operators themselves" — recruiter's email | A1, A3, E2 |
| "Ross will push on commercials" — recruiter's email | C1, C2, C3, C4, D1, D2 |
| Gaps you stated (rail, quota) | B1, B2, B4, C2, D1 |
| Any JD requirement | — none, and why: no JD was supplied, so mid-list requirements are unknown and uncovered |

## Reverse questions

No interviewer profile was available, so none is tied to a career path; these are tied to the roles you were given.

| # | Question | Why it lands |
|---|---|---|
| R1 | "At month 18, what would have to be true for you to say this hire changed your operator partnerships?" | Gets Deepa's definition of success, which is the target your POV aimed at, and shows you think in outcomes |
| R2 | "Where does an operator partnership end and a commercial negotiation begin, and who holds the pen on terms?" | Goes to Ross; the Partnerships and Commercial seam is the one he is likely to care about |
| R3 | "What would make you hesitate about hiring someone who hasn't sold into rail?" | Puts the objection in the open once, so the B1 answer you rehearsed is heard instead of guessed at |
| R4 | "Which part of the market report does the team agree on least?" | Signals you read it as an argument, not a brochure; invites them to correct your reading |
| R5 | "How do operators themselves tell you a partnership is working?" | Lands in the operator close you were asked to make and shows you are listening for the customer's measure |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated: "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | The plain acknowledgment: "I haven't sold into rail specifically." No slot |
| Carried a quota, or owned or closed the £4M | Negative you stated (same quote) | "I haven't carried a direct quota; what I've had is influenced revenue." No slot |
| Knows train operating companies from the inside | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says bus and light rail network planning, not train operating companies. B2's slot stays inside bus and light rail |
| Designed or built the partner programme that grew the channel | Inflated form of F1 | F1's quote at its own scope: "took it from 6 partners to 40, roughly £4M of influenced revenue". The limit is the pack's observation: the quote says the growth, not the practices behind it. D2's slot asks only which part was yours |
| The £4M is revenue you sourced or closed | Inflated form of F3 | The quote's own word, "influenced". C1's slots ask only how it was counted, what it is sensitive to, the weakest assumption, and which part was yours |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. Not in hand: the market report (you described it, it was not pasted) and a job description.

Searches sent, all refused, none returned anything:

- "Kelverton Rail company values": refused
- "Kelverton Rail interview process partnerships manager": refused
- "Kelverton Rail scheduling software train operating companies news strategy": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused
- "Senior Partnerships Manager Kelverton Rail job description": refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have supplied published value names for VAL questions and a values cheat sheet; none is built |
| 2. Kelverton Rail interview process, partnerships | unavailable | Moved nothing for this session, since the recruiter's email establishes the round; would have documented other rounds and confirmed the panel format |
| 3. Kelverton Rail strategy and recent news | unavailable | Would have grounded the CO and CASE banks and a grounding brief; those rows are `[generic]` instead |
| 4. Deepa and Ross, Kelverton Rail | unavailable | Two calls refused; would have supplied the interviewer read and a reverse question tied to their paths; both are absent |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have supplied requirements beyond the recruiter's words; the fit snapshot rests on those words alone |

## Upgrade menu

- The job description text → the fit rows become JD-quoted, mid-list requirements get questions, and any gate (right to work, location, travel, pay) is checked
- The text of the market report, or the pages you would build on → the consensus-then-divergence move names real items, A4 becomes grounded, and a grounding brief can be written
- Deepa's and Ross's public profile text, pasted → an interviewer read and a reverse question tied to their career paths
- Permission for web search → company values, strategy news, and the interview process; a deeper pass is also available once, up to 6 more searches and 2 more fetches, several more minutes
- How the £4M was counted, from the partner-revenue report or equivalent record you used → F3 moves from medium to high and C1 becomes a story instead of a set of slots
- A tuesday-dossier.md from the job-underwriter → verified evidence and a named top objection in place of the inferred one
