I'll read the reference files before building the pack.
Your prep pack is saved as /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-canned-b15dfd27/ashgrove_member-experience-lead_interview_pack.md. I built it as a loop with one mini-pack per round and 28 questions across the three. Round 1 is the recruiter, round 2 the Head of Member Services (behavioural, plus probing of your gaps), and round 3 the branch-manager panel (the four values plus the 20-minute escalation case). I did no web research, because your JD, values text, recruiter email and the strategy points you gave already fixed what a search would have fed.

- **Biggest objection:** you handled one branch's formal complaints log, and the role owns the process across branches and the contact centre. B5 rehearses that three follow-ups deep, so start there.
- **Your two stated gaps** are handled with plain acknowledgments in your own words, plus a plan: "I haven't worked in a contact centre" and "I haven't presented to anyone above regional level".
- **The pack does not supply anything you didn't tell me.** Where an interviewer's likely probe goes past your words, the cell is an answer slot with an honest second branch. The slots cover decisions on log entries, what the spreadsheet showed and whether it was Excel, supervisor coaching, which rules the complaints sat under, and digital-team work.
- **The strategy cases need care in round 3.** The panel are branch managers, and the plan consolidates eight branches into five hubs. D6 and the round 3 reverse questions say to ask about it rather than assume whose branches are affected.

Say the word and I'll play the Skeptic on B5 so you can rehearse it live.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Prepared:** 11 November 2026. **Mode:** loop, three rounds on 20 November 2026, one mini-pack each.

| Round | Who | Length | Format, in the recruiter's words |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | "30 minutes with me" |
| 2 | Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | A panel of two branch managers | 60 minutes | "including a 20-minute case on a complaint escalation"; "The panel is also the values round — they score against the four values" |

Interviewers beyond their roles have not been assigned, so there is no interviewer read. The recruiter's email says the three rounds fall on 20 November; it does not say whether they run back to back.

## How to use this pack

- **Personas are how a question arrives; types are what it scores.** Rounds are separate mini-packs, each with its own persona weights, bank and reverse questions.
- **Persona key:** A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Peer Evaluator, P Data-Driven Prober.
- **Type key:** VAL = does past behaviour show the published values. EXP = does what you said about your own work survive scrutiny. JD = can you do the listed job, gaps included. CO = do you know the company and its strategy. CASE = a live problem from the role.
- **Guidance is scaffolding, not a script.** Say it in your own words, and only what you actually did.
- **"Answer slot" is an instruction for the interview, not a question for me.** Where the pack cannot know what you did, it says so and gives two honest branches. If you send me your answers in this chat, I will quote them into the fit snapshot and regenerate the rows they touch.
- **Highest-ROI prep: B5.** The most predictable objection to this candidacy is the scope gap between the branch's formal complaints log and a role that owns the process across branches and the contact centre (F1 and F2). B5 rehearses it three follow-ups deep, with the limit named before the interviewer asks for it. Rehearse it aloud until it is boring.

## Fit snapshot (shared across all three rounds)

Every candidate quote is your own words from your message. Nothing inside quotation marks in the Evidence column is paraphrased.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on decisions about entries in that log likely. If any decision about an entry was yours, say which and how you decided, in your own words; if none was, or it was not yours, say so plainly and describe how you handled the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past, in your own words. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet your regional manager uses; it does not show what the spreadsheet held. Answer slot: the JD names volumes and resolution times. If the spreadsheet showed either, say which and in what form, in your own words; if it showed something else, or neither, say so plainly and describe what it did hold |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The JD says Excel; your sentence says spreadsheet. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was built in Excel, say so and say in your own words what you did in it; if it was another tool, say so plainly and say which |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and an escalation script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coach-supervisors line makes a probe on whether you have guided anyone in the supervisor seat likely. If you have helped any supervisor with an escalation, say what and how, in your own words; if you have not, say so plainly and stay with the tellers |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Derivation: "formal" in your sentence read against "regulated" in the JD. Your material says formal complaints; "regulated" is the JD's word, not yours. Answer slot: if the formal complaints you handled followed a regulator's rules, say which rules and which part you handled, in your own words; if you do not know which rules applied, or the log was not tied to any, say so plainly and stay with "I handled the branch's formal complaints log." |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap in the terms: six years in retail banking, the last three as a branch supervisor. It is a self-reported line with nothing inspected behind it, so expect a probe on what those years held. Lead with the quote's own terms |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare for a first one, said as a plan and never as a past. Nothing added |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the JD names digital teams and self-service journeys. If you have worked with a digital or product team on anything members do for themselves, say what and which part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first |

## Grounding brief

The 2026 strategy brief itself was not in hand; these are the four points you gave me from it, plus the JD's own description of the organisation. As of 11 November 2026 the Q1 2027 launch is still ahead.

| # | Item, as supplied | Source | Provenance | Where it surfaces |
|---|---|---|---|---|
| G1 | "move 40% of member service to digital channels by 2028" | 2026 strategy brief (July 2026), as you summarised it | [grounded] | A2, D1, round 2 reverse questions |
| G2 | "consolidate eight branches into five hubs over 2027" | 2026 strategy brief (July 2026), as you summarised it | [grounded] | A2, D6, round 3 reverse questions |
| G3 | "launch a small-business lending product in Q1 2027" | 2026 strategy brief (July 2026), as you summarised it | [grounded] | A2 |
| G4 | "the main competitive pressure is app-only banks" | 2026 strategy brief (July 2026), as you summarised it | [grounded] | A2, D1 |
| G5 | "member-owned, about 900 staff" | JD | [grounded] | A2 |

Vocabulary to use aloud: "member" never "customer", "hubs", "self-service journeys", and the four values by their exact names.

---

# Round 1: the recruiter (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Conversational | A friendly walk through your background and motivation; still scored | High. The relationship prior for a recruiter screen is Conversational plus a light Skeptic; the recruiter's email gives only the length, so there are no interviewer signals to adjust it | A 90-second arc for the biography question; treat every casual question about a JD topic as scored |
| B Skeptic (light) | Knockout checks on the JD's musts in a friendly register | Medium. Same prior; the JD lines on regulated complaints, the contact centre and presenting to senior leaders are the ones your message either flags (F2, F8) or leaves open (F6) | Plain acknowledgment where you have stated the absence, then a plan; rehearse until it is boring |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your career so far, and why this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | A 90-second arc on the beats that sentence states: six years in retail banking, the last three as a branch supervisor. Then your own reason for this role, which the material does not give: say it only if it is true for you, and end on the role rather than the past | F7 is the only career-arc evidence. EXP because it checks what the career actually was, and a recruiter's opener is still scored |
| A2 | "What do you know about Ashgrove, and why a credit union?" | CO | [inferred] | Pick one point from the brief, in its own words: 40% of member service to digital by 2028, eight branches into five hubs over 2027, a small-business lending product in Q1 2027, or app-only banks as the main pressure. Say what it could mean for how complaints are handled, as your view and not as a fact. Bring "member-owned" into your own reason for a credit union | Derivation: G1 to G5 read against the JD's complaints remit. CO because it tests homework at the company's altitude; no claim about your past |
| A3 | "Have you worked with digital or product teams before?" | JD | [grounded] | Answer slot: the JD names digital teams and self-service journeys, and your material is silent. If you have worked with a digital or product team on anything members do for themselves, say what and which part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first | F9 is `discovery`, and a recruiter screens JD lines directly. JD because it scores a stated responsibility |
| A4 | "Tell me about the complaints side of your current role." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 and F5: the log you handled and the tellers you trained on the escalation script, the two beats the sentence states, in your own words. Answer slot: the JD's end-to-end line makes a probe on decisions about entries in the log likely. If any such decision was yours, say which and how you decided; if none was, or it was not yours, say so plainly and describe how you handled the log | The opener a recruiter uses to test the complaints lines of the JD. F1 and F5 are the evidence; EXP because it checks what was actually yours |
| B1 | "Tell me about your experience with regulated complaints." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what you handled in the sentence's own terms: "I handled the branch's formal complaints log." Answer slot: "regulated" is the JD's word. If the formal complaints you handled followed a regulator's rules, say which rules and which part you handled, in your own words; if you do not know which rules applied, or the log was not tied to any, say so plainly and stay with the log | F6 is `discovery`: the material says formal, not regulated, so this is the likeliest knockout probe. JD because it scores a hard requirement |
| B2 | "The role covers the contact centre as well as branches. How would you get to grips with it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment first, in these words: "I haven't worked in a contact centre." Then your plan, as a plan: what you would want to learn first, from whom, and where you would start. Do not describe contact-centre work as though you had seen it | F2 is a stated absence, so the honest form is the acknowledgment plus a plan. JD because the contact centre is in the role's first line |
| B3 | "Part of the role is presenting to senior leaders. How do you feel about that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then how you would prepare for a first one, in your own words, as a plan. Do not describe a presentation you have not given | F8 is a stated absence, so there is no slot. JD because the line is a stated requirement |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose by your own judgement between the two absences you stated, say it in the plain-acknowledgment words from B2 or B3, then give the plan. Do not offer a weakness that is really a strength | A standard Skeptic stem, and F2 and F8 are the two places it lands. JD because it scores honest self-assessment against the listed requirements |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What would a strong first six months look like to your hiring team?" | Gets the scorecard in the recruiter's own words, which you can use in the next two rounds |
| R1.2 | "Do you know yet who will be on the panel, and which branches they manage?" | The interviewers are unassigned; this asks for exactly what the pack's interviewer read needs |
| R1.3 | "For the 20-minute case, should I expect a written scenario or a spoken one?" | The case format is unknown, and the answer changes how D4 is rehearsed |
| R1.4 | "Which complaint rules does the team work to, so I can read up before the 20th?" | Turns the F6 gap into visible homework and tells you where to read |
| R1.5 | "How is complaints work organised in the contact centre today, and who would I work with there?" | Faces the F2 gap directly and moves it toward learning |

---

# Round 2: the Head of Member Services (45 minutes, your would-be manager)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | "Tell me about a time" prompts, STAR-shaped | High. The hiring-manager prior leans Case and Skeptic; the recruiter's "mostly behavioural" moves this up | Where a quote carries a story, map it; where none does, pick an instance by the scaffold and use the honest branch. "We" for context, "I" for contribution |
| B Skeptic | Persistent probing of the scope gap | High. The prior for a hiring manager is derisking gaps; F1 and F2 are the widest in the snapshot | Hold what the quote carries through two follow-ups, concede the stated absences plainly, never fold on the core |
| P Data-Driven Prober | Walks the monthly reporting line by line | Medium. The JD names monthly reporting and Excel (F3, F4), and both are `discovery` | Know what you can and cannot say about how each figure was counted; name the assumption you would defend least; say plainly when you do not know |
| D Case/Strategist | Short live problems on the role | Low. The prior is high for a hiring manager; "mostly behavioural" moves it down, so these are the short versions | Clarify, then objective, approach, metrics, risks; think aloud |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one instance with a named person, what they struggled with, what you did, and how it ended. Answer slot: the JD's coach-supervisors line makes a probe on whether that person was a supervisor likely. If a supervisor was among those you helped, say so and what you did; if not, say so plainly and stay with the tellers. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the training of new tellers on the escalation script, or how you would coach | F5 carries training, not coaching, so the scaffold plus slot keeps the answer inside the sentence. JD because the question is the stated coaching duty asked behaviourally |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | JD | [generic] | Selection scaffold: a named stake, a moment you did not soften it, and a relationship intact at the end; the hard truth must actually have landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No quote carries this, so it is a scaffold. JD because the role reports to leaders and has to say unwelcome things in monthly numbers; the stem is the Values persona's |
| C3 | "Tell me about a time a complaint went further than the branch and you had a part in it." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the beat the sentence states: the log you handled, in your own words. Answer slot: if a complaint in the log went further up than the branch, say what happened and which part was yours; if none did, or it was not yours, say so plainly and describe how you handled the log. If no time comes to mind, say so plainly, then give the nearest thing your material does carry | F1 and F6 are where the JD's escalation and regulated-complaint lines meet your evidence. EXP because it checks the part that was actually yours |
| B5 | "The role owns the process end to end, across branches and the contact centre. What part of that have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI rehearsal in this pack.** Level one, hold only what the sentence carries: "I handled the branch's formal complaints log." Level two, the likely follow-up on who decided what happened to an entry. Answer slot: if any such decision was yours, say which and how you decided; if none was, or it was not yours, say so plainly and return to the log. Level three, the contact centre: "I haven't worked in a contact centre," then your plan as a plan. Hold by returning to the log, never by adding to it; the honest branch is a limit, not a confession | F1 and F2 together are the widest gap in the snapshot and the objection this loop is most likely to press. JD because it scores the headline requirement |
| B6 | "Sixty seconds: why you rather than someone who has run complaints in a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold-then-concede. Hold with what you said: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log. Through two follow-ups, return to those facts and add nothing. Concede plainly: "I haven't worked in a contact centre." Do not claim you would do it better | F7, F1 and F2 give the facts to hold and the absence to concede. JD because it tests the stated requirement against a stronger imagined rival; the stem is the Pressure persona's |
| P1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the sentence's own terms: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes, resolution times and Excel. If it showed either figure, say which, how each was counted, and the assumption behind it you would defend least; if it showed something else, or you do not know how a figure was counted, say so plainly and describe what it held; if it was not in Excel, say which tool | F3 and F4 are `discovery`, and a manager who will own the monthly report will go here. EXP because it checks what you actually built and how well you know it |
| P2 | "How would you make sure resolution times are counted the same way across every branch and the contact centre?" | JD | [generic] | A forward-looking structure, no claim about your past: what starts and stops the clock, agreed in writing; where the data is captured; how differences between channels are shown; who checks. Say aloud that you would first ask what is counted today | F3 is `discovery`, so this scores the reporting duty without resting on a claim. JD because it is the JD's monthly-reporting line asked as a method |
| D1 | "40% of member service moves to digital channels by 2028. What happens to the complaints process?" | CO | [inferred] | Structure as hypotheses: where complaints arise in a self-service journey, what a member needs at the point it fails, how a digital team would hear about it, and what you would ask that team first. Name app-only banks as the pressure behind the move | Derivation: G1 and G4 read against the JD's self-service line. CO because it asks for the company's own vocabulary at its own altitude |
| D2 | "How would you present the monthly complaints report to a room of senior leaders?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Structure: the answer first, the two or three things that moved, what you are doing about them, what you need from the room, in plain words. If asked directly whether you have done this: "I haven't presented to anyone above regional level," then the plan | F8 is a stated absence and F3 the reporting duty. CASE because it is a live problem from the role |
| D3 | "What would you do in your first 90 days?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | A plan, not a past: learn first, starting where you have said you have not worked, the contact centre; map the process end to end; fix how the monthly numbers are defined; agree what the digital teams need from you. Say what you would ask before what you would change | F2 is the natural place for a learning plan to start. CASE because a manager uses it to see how you sequence |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What do you want the monthly complaints report to change in how leaders decide things?" | Shows you see reporting as a means; ties to F3 |
| R2.2 | "Where does the complaints process fail members most today, in your view?" | Invites candour and fits "Own the Fix", the value about keeping hold of a problem until it is solved |
| R2.3 | "How will moving 40% of member service to digital by 2028 change what you need from this role?" | Uses G1 and asks the manager for their reading rather than offering yours |
| R2.4 | "Where do the contact centre and the branches work well together, and where not?" | Approaches the F2 gap as a learner |
| R2.5 | "Since I have not worked in a contact centre, what would help me most to learn in my first month?" | A plain, sourced acknowledgment (F2) followed by a request for their help, so the gap becomes a working plan |

---

# Round 3: the panel of two branch managers (60 minutes, including the 20-minute case)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | One scored prompt per value | High. The recruiter says the panel "is also the values round" and scores "against the four values" | Map a story where a quote carries one, use a scaffold with its honest branch where none does; land the hard truth |
| D Case/Strategist | The 20-minute complaint escalation case | High. The recruiter names it | Clarify, objective, owner, fix for the member, pattern, then record; challenge one premise respectfully |
| E Peer Evaluator | Seams between a branch and your role; what you need from them | Medium. The panel is branch managers, the role coaches branch supervisors and reports across branches; this rests on their titles only, since there are no profiles | Reciprocity: what you bring their branches, not only what you need; offer seam principles, not a claim to know the seam |
| B Skeptic | Gaps returning in collegial form | Low. It appears inside the other banks rather than as its own | Same plain acknowledgments as rounds 1 and 2 |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C4 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Value: Members First, Always. Selection scaffold: a decision where the member's side and the easier internal route differed, what you weighed, what you did, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's own words are the raising source. VAL because the panel scores against the value; no quote carries a decision of this kind, so it is a scaffold |
| C5 | "Tell me about a time you made something clearer for a member." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Plain Words. Answer slot: the value makes a probe on the wording of the escalation script likely, since you trained tellers on it. If any part of how it read to members or staff was yours to change, say what and why; if the script was fixed and you trained on it, say so plainly and describe how you taught it. If no time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5 is the only place the sentence touches wording, and a script is the likeliest thing the value will test it against. VAL because it scores the value |
| C6 | "When did you put a member, or a branch's town, ahead of a number?" | VAL | [grounded] | Value: Neighbours, Not Numbers. Selection scaffold: a named person or place, the number you did not chase, what you did instead, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. E2 rehearses the harder version of this for someone who built a reporting spreadsheet | The value's own words are the raising source; the stem is the Values persona's. VAL because it scores the value |
| C7 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Own the Fix. Story-mapped only on the beat the sentence states: the log you handled. Answer slot: the value makes a probe on whether you followed an entry through to its solution likely. If you did, say which one and what you did, in your own words; if the log was a record and others solved the problem, or no entry reached a solution on your watch, say so plainly and describe how you handled the log. If no time comes to mind, say so plainly, then give the nearest thing your material does carry | F1 is the nearest evidence and the likeliest place the value gets probed. VAL because it scores the value |
| D4 | "A member's complaint reached the contact centre, was passed to a branch, and three weeks later is back with the member unresolved. The supervisor says it is the contact centre's; the contact centre says it is the branch's. What do you do, starting now?" | CASE | [generic] | Say your structure aloud. Clarify first: what the member was told, what has been promised, and which rules and timeframes the credit union works to, asked and not stated. Objective: the member's problem solved and explained in plain words. Owner: name who holds it from today, in the spirit of "Own the Fix". Then the fix for the member, then the pattern: what you record, what you report, and the conversation you have with the supervisor. Challenge one premise respectfully. No claim about your past | A live problem on the role's own seam, written as a practice case because the recruiter gave only the topic. CASE because the panel's 20 minutes are a case on a complaint escalation |
| D5 | "A new branch supervisor escalates every complaint upward rather than trying to settle any. How would you coach them?" | CASE | [generic] | Structure: ask what they are worried about; separate what must be escalated from what can be settled at the branch; check that the escalation script reads in plain words; agree a next step and a follow-up date. Link it to "Own the Fix": coaching an escalation should not become handing the problem on. No claim about your past | The JD's coach-supervisors line (F5) as a live problem, and the one place the role's escalation duty sits beside a value about keeping hold. CASE because it is a problem from the role |
| D6 | "Eight branches become five hubs over 2027. What happens to complaints in the towns that lose a branch?" | CO | [inferred] | Hypotheses and questions, not claims: how members in those towns would reach you, what they would need in plain words, and how the number of complaints would be read against the move. Link it to "Neighbours, Not Numbers". You do not know whose branches are in scope; ask rather than assume | Derivation: G2 read against the Neighbours value. CO because it is a strategy question at the company's altitude, and the panel are branch managers |
| E1 | "When a complaint comes in at my branch, where is the seam between my team and your role, and what happens when we disagree?" | CASE | [generic] | Offer seam principles, not a claim to know the seam: the member's problem has one owner at a time, the branch keeps what it can settle, and you take over what needs the wider view. On disagreement: say what you would want to hear from them first and how you would settle it | The Peer persona's own stem. CASE because it is a live collaboration problem |
| E2 | "This role reports monthly on complaint volumes and resolution times. How do you keep the figures from standing in for the branch?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The JD's monthly-reporting line meets the value "Neighbours, Not Numbers". Say what you said: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if anything you did alongside the spreadsheet gave a branch's complaints context, say what and why; if nothing did, say so plainly, and say what you would put beside the figures in this role | F3 is the evidence, and it is where a branch manager will test whether you see a branch or a row. JD because it scores the reporting duty |
| E3 | "What do you need from branch managers for escalations to work?" | JD | [generic] | Reciprocity first: what you would bring their branches, such as an escalation route that reads in plain words and a way of telling them what happened next. Then what you would ask of them. No claim about your past | The Peer persona's collaboration stem. JD because the role's coaching duty (F5) depends on branch managers |

## Values cheat sheet (published values, as pasted from ashgrovecu.org/about/values on 11 November 2026)

| Value (official name) | Working meaning (paraphrased) | Mapped story or scaffold | Questions |
|---|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | Selection scaffold: a decision where the member's side and the easier internal route differed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script.") or how you would handle it | C4 |
| Plain Words | If a member needs something explained twice, the wording was wrong | Selection scaffold: a time you made something clearer for a member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script.") or how you would handle it | C5 |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold: a time you put a person or a place ahead of a number. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (F7: "6 years in retail banking, the last 3 as a branch supervisor.") or how you would handle it | C6, D6, E2 |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | Story map on F1 only for the log you handled, with the answer slot in C7 for what followed | C7, D4, D5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "From your side of the counter, what works and what does not in the complaints process today?" | Uses the Members First phrase and asks for the panel's own view |
| R3.2 | "What would you want a new person in this role to do in their first month that would genuinely help your branches?" | The reciprocity question for a peer panel |
| R3.3 | "How will the move from eight branches to five hubs change how complaints reach your teams?" | Uses G2 and asks rather than assumes whose branches are affected |
| R3.4 | "When a complaint has gone between a branch and the contact centre, what has helped it get fixed?" | Echoes the D4 case and shows you want their experience before your answer |
| R3.5 | "Which of the four values do you see tested hardest in complaints work?" | Shows you took the values seriously, which the recruiter says this round scores |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | A4, B2, B5, B6, C3, D4, E1 |
| "report monthly on complaint volumes and resolution times" | P1, P2, D2, E2 |
| "coach branch supervisors on escalations" | C1, D5, E3 |
| "work with digital teams on self-service journeys" | A3, D1 |
| "4+ years in financial-services customer operations" | A1, B6 |
| "experience handling regulated complaints" | B1, C3 |
| "confident presenting to senior leaders" | B3, D2 |
| "comfortable with Excel reporting" | P1 |

Type coverage across the loop: VAL C4 to C7; EXP A1, A4, C3, P1; JD A3, B1 to B6, C1, C2, P2, E2, E3; CO A2, D1, D6; CASE D2 to D5, E1.

## Prohibited claims

Built from the fit snapshot before the banks were written. None of these appears in any guidance, slot, bridge or rationale as something you did.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: the material says the branch's log, not the process across branches. B5's slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: the material says new tellers, not supervisors. C1's slot stays with the tellers |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to anyone above regional level | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |

## Sources

**Provided documents:** the job description; the values text you copied from ashgrovecu.org/about/values on 11 November 2026 (pasted, not fetched); the recruiter's email on the three rounds; the four points you gave from the July 2026 strategy brief (the brief itself was not in hand); your background in your message. No `tuesday-dossier.md` was present.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the values cheat sheet and the four VAL questions |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email fixes the three rounds, who runs each, their lengths and the case; persona weights follow it, so no fallback archetype was used |
| 3. `Ashgrove Credit Union strategy` | skipped | The four brief points you gave fix the CO questions A2, D1 and D6; a fuller brief would add depth but not change those rows |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No names were given; there is no interviewer read and the upgrade menu says what a name would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- **Interviewer names for rounds 2 and 3** → an interviewer read, persona weights adjusted from their public professional footprint, and a reverse question tied to each one's own path
- **The recruiter's answers on the 20-minute case format and which complaint rules the team works to** → D4 and B1 rest on those facts instead of a practice case written from the topic alone
- **Your answers to the answer slots in F1, F3, F4, F5, F6 and F9, sent in this chat** → those rows move from `discovery` or `transferability` to quoted evidence, and the questions that rest on them (A3, A4, B1, B5, C1, C3, C7, P1, E2) are regenerated
- **A de-identified extract of the monthly complaints spreadsheet, with member details removed** → F3 and F4 can rise from `medium` toward `high`, since a report is the inspectable artifact in this field
- **The full text of the 2026 strategy brief** → the grounding brief rows come from the document instead of your summary
- **How many hours you have before 20 November** → a prioritised prep schedule sized to it
- **Deeper research (L2): up to 6 more searches and 2 more fetches, several more minutes** → recent organisational context and role-family loop reports for the grounding brief; run only if you say so
- **A `tuesday-dossier.md` from job-underwriter** → verified evidence and constraints per weak area, in place of the pack's inferred objection
