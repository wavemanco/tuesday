I'll read the skill's reference files before building the pack.
Search permission was declined, so I'm building the pack from what you've told me. Everything that would have come from research is labeled `[generic]` and listed in the upgrade menu.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-3-denied-0bb1ab2f/stripe_product-operations-manager_interview_pack.md`.

I built it without a JD, a CV or any research, because the search permission was declined. Every question is therefore a general Product Ops pattern, not Stripe-specific. It has 22 questions across seven interviewer styles, built for a blended final round since I don't know who you're meeting. The one to rehearse first is B1, "Which part of this role would you be weakest at on day one?"

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is on your final-round schedule (names, roles, one session or several), and did the recruiter mention focus areas or a take-home?
Can you paste the JD and your CV, or tell me to stay with the worksheet version?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Final round. Interviewer(s) and relationship: not given. Built from the role title, the company and the round type alone: no JD, no CV, no research. Every question and requirement below is a pattern for the role, labeled `[generic]`, and the pack makes no claim about your past or about Stripe.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Each question carries one of each.
- Type key:
  - VAL: whether past behavior shows values, not generic virtue.
  - EXP: whether the claims in your background survive scrutiny, including what was actually you.
  - JD: whether you can do the listed job, gaps included.
  - CO: homework on the company, its strategy and its moves.
  - CASE: structure and reasoning on a live problem from the role.
- Provenance labels: `[grounded]` traces to a document you provided or to cited research. `[inferred]` is derived from an adjacent source. `[generic]` is a role-family pattern with no claim about you or Stripe. Nothing here is `[grounded]` or `[inferred]`, because nothing was supplied or fetched.
- Guidance is scaffolding, not a script. Where it says to pick an example, the example has to come from your own history, in your own words.
- Where the guidance says "if no such time comes to mind, say so plainly", that is a real branch. An honest "I haven't done that, here is how I would approach it" beats an example you cannot defend on the second follow-up.

## Fit snapshot

No JD or CV was supplied, so this is the worksheet variant. The requirements are role-family patterns written as plain prose, not quotes from a posting, and each evidence cell is empty until you fill it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate cross-functional product launches across engineering, go-to-market and support teams (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a launch or release you helped land, with the teams involved and your part named. Selection scaffold: pick a launch where several teams had to move together, with a named date and a moment of disagreement. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define, track and report product or operating metrics, and turn them into decisions (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a metric you defined or tracked, with how it was counted and what decision it changed. Selection scaffold: pick a metric you can explain end to end, including its weakest assumption. If no such metric comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set one up |
| F3 | Design and run operating cadences, planning or review processes that teams follow (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed, with who used it and what changed because of it. Selection scaffold: pick a process other people relied on, noting whether you built it, changed it or only ran it. If no such process comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Write clearly and influence stakeholders without formal authority (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a case where you moved a decision or a team you did not manage, with the stake named. Selection scaffold: pick a time you were accountable for an outcome that depended on people outside your reporting line. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritize and make progress under ambiguity, including with senior stakeholders (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a decision about what not to do, with the trade-off and who you told. Selection scaffold: pick a time capacity was short and you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Get up to speed quickly on a technical product domain and its customers (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a domain you learned fast, with how you did it and what you could do afterwards that you could not before. Selection scaffold: pick a domain that was new to you at the time. If no such domain comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

Your material does not establish any of F1 to F6, because none was supplied. Paste a CV and the rows with a matching sentence upgrade, and the banks below regenerate against those sentences.

## Persona table

The weights rest on relationship priors blended across the relationships a final round can contain (hiring manager, skip-level, peer, cross-functional). They do not rest on a documented Stripe loop, because none was established. They are flatter and less reliable than a pack with the schedule behind it. Change them if you know who you are meeting.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | A live problem from the role: a launch conflict, a metric diagnosis, a prioritization call | Highest. Hiring-manager and skip-level priors both tilt toward it, and the role is operational, so problems drawn from the work itself are a natural format | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic (B) | Quiet, persistent probing of the weakest area and of motivation: why this role, why now | High. Hiring-manager priors put it second, and every candidate has a thinnest requirement | Rehearse the single most predictable objection until it is boring. Say the limit plainly, then give a concrete ramp plan |
| Peer Evaluator (D) | Seam-splitting with adjacent teams, credit, disagreement | Medium. A final round commonly includes a peer, but nothing here says one is in yours | Reciprocity framing. Propose seam principles instead of pretending to know the seam |
| Pressure (E) | Time-boxed challenges and attribution probes | Medium. Skip-level priors raise it, and attribution probes are common in any final | Pause, restate, hold through two follow-ups, then concede specifically |
| Data-Driven Prober (F) | Follows a metric or analysis two levels down | Medium. Metrics are central to the role family, and a peer or specialist would probe them | Know how any number you cite was counted. Name its weakest assumption before they do |
| Values / Behavioral (C) | Scenario probes mapped to published values | Low to medium. No loop source was read, so a dedicated values round is not established. Behavioral stems still appear in every persona | Pick stories where the hard truth actually landed. If your material shows none, say so rather than supplying an ending |
| Conversational (G) | Friendly openers such as the journey question and why this company | Low to medium. It sets the opening register, and it is still scored | A rehearsed 90-second arc. Never answer the reverse-question slot with "I think you've covered everything" |

Highest-ROI prep: B1, "Which part of this role would you be weakest at on day one?" The pack cannot see your background, so it cannot name your specific biggest gap. B1 is the question that surfaces that gap in some form for every candidate. Rehearse it first and deepest.

## Question banks

All rows are `[generic]`: none rests on a sentence of yours, so none makes a claim about your past. Where a question asks you to pick an example, the guidance is a selection scaffold ending in the honest branch.

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A major launch is two weeks out. Engineering says it is ready, support says it is not, and sales wants the date held. What do you do first?" | CASE | [generic] | Clarify first: what ready means to each team, what was committed and to whom, and the cost of slipping versus shipping with known gaps. Then name who decides and how. Lay out the options: hold the date with mitigations, a staged rollout, or move the date. Say what you would tell each team and what you would record. Challenge one premise aloud. No claim about your past is needed or made | The F1 requirement as a live decision under conflict. CASE because it scores structure, not a past launch |
| A2 | "Adoption of a recently shipped feature is 20 percent below plan. Diagnose it." | CASE | [generic] | Ask how adoption is defined and how the plan was set before diagnosing. Segment by who, where and when. Separate measurement problems, product problems and rollout or awareness problems. Say which you would check first and why, and what you could not yet conclude | F2 in diagnostic form. CASE because the answer is the reasoning, not the cause |
| A3 | "Teams keep routing around a planning process you have been asked to own. How do you find out why, and what do you change?" | CASE | [generic] | Diagnose before redesigning: talk to the people who use the process, find where it costs them and what it was for. Make the smallest change that removes the cost. Say how you would tell whether it was adopted, and what you would retire | F3 as a live problem. CASE with some JD content, because it tests whether you fix a process or replace it |
| A4 | "You have operational support for three of ten upcoming launches. How do you choose?" | CASE | [generic] | Criteria first (customer impact, risk, dependencies, reversibility). Then who agrees the criteria, how the seven teams not chosen are told and helped, and when the choice is revisited | F5 and F1 together. CASE because it scores a trade-off made visible |
| A5 | "What do you think makes product operations at a company like Stripe different from product operations elsewhere?" | CO | [generic] | Say only what you have verified yourself from Stripe's own materials or from using its products, and say how you know it. Where you do not know, say so and ask what the interviewer would want you to understand first. The pack supplies no Stripe facts, because none were researched | F6 and company homework. CO tag, but generic until research runs, which is the honest cost of no search |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Choose the requirement from F1 to F6 where your own material is thinnest; only you can see which. Say the limit in one plain sentence, then a ramp plan: what you would do in the first weeks and whom you would ask. Do not offer a disguised strength. Hold through two follow-ups by returning to what you can truthfully say, and concede the specific limit, not the whole case | Every candidate gets this in some form. JD because it scores the listed job including its gaps |
| B2 | "Why product operations rather than product management or program management?" | EXP | [generic] | Say in your own words what draws you to this work. Tie it to something you actually did or enjoyed, if one comes to mind. If none does, say so plainly, then say what you want to learn. Keep it forward-looking and free of disparagement | Motivation consistency is what the Skeptic scores. EXP because the answer has to be consistent with your background |
| B3 | "How do you handle being accountable for an outcome that depends on teams you do not manage?" | JD | [generic] | Structure: align on the outcome, make the dependencies and owners visible, agree what each team gets from the arrangement, escalate early and plainly. If a real instance comes to mind, tell it in your own words; if not, say so and give how you would run it | F4. JD because this is the role's central working condition |
| B4 | "Why this move, and why now?" | EXP | [generic] | One reason about the work you want and one about this role, both true. Avoid a reason you would not repeat to your current manager. If the timing is not tidy, say so plainly | The Skeptic's stem on motivation. EXP because it must fit the rest of your story |

### C. Values / Behavioral

Stripe's published values were not researched, so nothing here maps a story to a named value.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you chose to say it, and a relationship still intact afterwards. Use "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem. VAL because it scores behavior, and the ending has to be real |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two pulled apart, with what you gave up and who noticed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard stem. VAL, with F5 trade-off content |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between us, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a claimed boundary: who owns the decision, who owns the follow-through, who is informed. Say how you would settle a disagreement with an equal: facts first, then a named decider, then a record. Ask what the seam looks like today | F4. JD because it scores how the role meets adjacent teams |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick work that spanned teams, saying "we" for the group and "I" for your own part. If no such work comes to mind, say so plainly, then say how you would handle credit | Peer stem. EXP because credit probes test honest attribution |
| D3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Needs: context, access, the right introductions. Offers: take a named, small piece of operational load off the team. Keep the offer to what the role can actually do | Reciprocity framing, F4 and F6 |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then one thing you can truthfully bring, chosen from the F row where your material is strongest. Concede what an internal candidate has, which is context, and say how you would close that. Hold the one claim through two follow-ups | Standard pressure stem. JD because it scores fit against the role |
| E2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Say what you did in your own words and who did what else. Hold through two follow-ups by returning to what you did, never by adding to it. Concede specifically what you do not know or what was others'. If no result comes to mind, say so plainly | Attribution probe. EXP because it scores precision about what was yours |
| E3 | "Make the case in two minutes that this role can work without authority over the teams it depends on." | JD | [generic] | Position: influence follows shared outcomes, visible dependencies and trust built by being useful. Concede the cost, which is that it is slower when interests diverge. Hold the position, not the details of any past | F4 under challenge. JD, delivered as Pressure |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Pick a metric you have owned or tracked. Walk me through how it was counted and which assumption behind it you would defend least." | EXP | [generic] | Say how it was counted in your own words. Name the assumption you would defend least before the interviewer does. If you do not know how a figure was counted, say so plainly. Never state a figure you cannot rebuild. If no metric comes to mind, say so plainly, then say how you would set one up | F2. EXP because it scores whether a number survives scrutiny |
| F2 | "Pick an analysis you did yourself and walk me through it end to end." | EXP | [generic] | Question, data source, method, what it showed, what it changed, what you would do differently. Mark the parts that were yours and the parts that were not. If no analysis comes to mind, say so plainly, then give the nearest thing your material does carry | F2. EXP because it is the Prober's end-to-end test |
| F3 | "A weekly metric moves 8 percent in one week with no release. How do you decide whether it is real?" | CASE | [generic] | Data integrity first: definition changes, instrumentation, backfills, seasonality. Then segmentation, then business causes. Say what you would check first and why, and what you could not conclude | F2 as a live problem. CASE because it scores order of reasoning |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc of three beats: where you started, the thread that connects your moves, and why this role is next. Each beat must be something you could expand if asked. The pack cannot draft the arc without your CV | Opens most conversations, and the casual register is still scored |
| G2 | "Why Stripe, and why this role?" | CO | [generic] | Name something you have used, read or noticed yourself, and say how you know it. Connect it to what the role does day to day. Do not borrow company facts from this pack, which has none | CO because it scores genuine interest. Generic until research runs |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Cross-functional launches | A1, A4 |
| F2 Metrics and decisions | A2, F1, F2, F3 |
| F3 Cadences and processes | A3 |
| F4 Writing and influence without authority | B3, D1, D2, D3, E3 |
| F5 Prioritization under ambiguity | A4, B1, C1, C2 |
| F6 Learning a technical domain | A5, B1, G2 |
| Motivation and fit (not a requirement) | B2, B4, G1, G2 |

## Reverse questions

The interviewer is unknown, so none is tied to a career path. Ask the ones that suit whoever is in the room.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a great first 90 days look like in this role, and how will you know it is going well?" | It turns vague expectations into success criteria and shows you think in outcomes |
| R2 | "Where does this role's remit end and the product teams' begin, and where has that line been contested?" | It surfaces the seam directly and signals you expect friction and plan for it |
| R3 | "Which operating routine do teams here trust most, and which do they quietly route around?" | It shows you would diagnose before redesigning |
| R4 | "What is something the job description does not say about this role?" | It invites the unwritten expectations, and any gap is a useful answer |
| R5 | "How do the teams this function serves judge whether it is working?" | It shows you care about the customer of the role, not only the role |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer. It reframes the exchange from what you need to what you bring |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No sentence of yours was supplied, so there is no stretched wording to list and no stated negative. Every requirement is silence, so each is a selection scaffold | The banks claim nothing about your past. When you paste a CV, this section is rebuilt against it |

## Sources

Provided documents: none. The request named only the company, the role and the round.

Searches sent, all refused, each returning nothing:
- "Stripe operating principles values": refused
- "Stripe interview process Product Operations Manager": refused
- "Stripe Product Operations Manager job posting responsibilities requirements": refused
- "Stripe strategy news 2026 annual letter": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search refused. It would have moved the values cheat sheet, which is dropped, and the VAL mapping, which is generic |
| 2. Stripe interview process, product operations | unavailable | Search refused. It would have moved the loop structure and the persona weights, which now rest on relationship priors |
| 3. Stripe strategy and recent news | unavailable | Search refused. It would have moved the grounding brief, which is dropped, and CO questions A5 and G2, which are generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Search refused. It would have turned the fit snapshot's requirements into quoted `[inferred]` rows and given JD-tagged questions a source |

## Upgrade menu

- The JD text: F1 to F6 become quoted `[grounded]` requirements, and any term-style requirement such as location or work authorization is checked as a gate.
- Your CV or a few lines of background: the evidence cells fill, the fit snapshot gains real confidence bands, the selection scaffolds become story maps, and the prohibited list is built against your wording.
- The interviewer names and roles: persona weights are re-read from their public footprint, and one reverse question is tied to their own path. If your final is several sessions, send the schedule and I can build per-session mini-packs.
- The recruiter's prep email: any focus areas or announced deliverable (a presentation, a case, a take-home) get their own build section, and the coverage assumptions come off.
- Search permission: the values cheat sheet with Stripe's published values by name, the documented loop, and CO and CASE questions grounded in current strategy. A deeper pass adds up to 6 more searches and 2 more fetches and takes several more minutes.
- Your prep time: a prioritized schedule sized to it.
- A tuesday-dossier.md from earlier evidence work, if you have one: verified evidence and pre-set limits on what you can claim replace the inferred ones.
