I've saved the pack and I'm now doing a last check on the file for stray brackets and formatting before I hand it over.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-canned-d9a2b7a4/ashgrove_member-experience-lead_interview_pack.md`.

I built it as a three-round loop for 20 November, using the roles in the recruiter's email. No interviewer names have been assigned, so personas are weighted on the round types. Each round has its own persona weights, 8 to 10 questions and reverse questions, and the values sheet sits with the panel round. The pack also has a shared fit snapshot, a requirement-coverage table, a grounding brief from the four strategy points you pasted, and a 9-day prep schedule.

The biggest item is B2, the contact-centre question. You told me you've never worked in a contact centre, and the JD puts the contact centre in the first duty. It will probably come up in all three rounds, so the pack gives it a four-rung follow-up ladder.

I ran no searches. Your pasted values, the recruiter's email, the July brief points and the JD already settled the pack's content. The L2 research pass is offered in the upgrade menu.

Your answers to the answer slots on the complaints log, the monthly spreadsheet, the escalation script and any digital-team work would upgrade the thinnest rows.

Say the word and I'll play the Skeptic on B2 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Built 11 November 2026. Mode: loop, three rounds on 20 November 2026.

| Round | Who | Length | Format, from the recruiter's email |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Conversation |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewer names beyond these roles have not been assigned, so there is no interviewer read and personas are weighted on the roles and on what the recruiter said about each round.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values |
| EXP | Whether what you say about your work survives follow-up questions |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you understand Ashgrove's strategy and can think at its altitude |
| CASE | A live problem from the role: structure and reasoning |

- Question IDs are lettered by persona: A Conversational, B Skeptic, C Values/Behavioral, D Data-Driven Prober, E Case/Strategist, F Peer Evaluator. Each round lists the IDs it is likeliest to use.
- Guidance is scaffolding, not a script. Say it in your own words.
- An answer slot is an instruction for the interview, not a question for you now. Either honest branch is a good answer: say what you did, or say plainly that it was not yours or did not exist, and stay with what your own sentences say.
- Every question carries a provenance label: grounded means traceable to a document you gave me, inferred means derived from an adjacent source, generic means a pattern for the role with no claim about Ashgrove or you.

## Prep triage

Nine days. The few things to do well, in order.

| When | Do this | Where |
|---|---|---|
| 11 to 12 November | Say the contact-centre answer aloud three times, then the four-rung ladder under it | B2 and its ladder |
| 13 to 14 November | Write your own answers to the answer slots on the complaints log, the monthly spreadsheet and the escalation script, then tell me them so the pack can use them | F1, F3, F4, F5, F9; A4, D1, D2 |
| 15 to 16 November | Time your 90-second journey arc; pick one real story each for Own the Fix and Plain Words | A1, C5, C7 |
| 17 to 18 November | Run the 20-minute case aloud, with a timer and someone interrupting | E2, E3, E4 |
| 19 November | Rehearse the senior-leaders and coaching answers; choose two reverse questions per round | B3, B4, B5 |

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint after it was logged likely. If any later step was yours, say which and what you did, in your own words; if the log was where your part ended, or none of it was yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | low | [grounded] | discovery | Your material says a formal complaints log; it does not show what governed the complaints in it, and the bridge should not be stretched. Answer slot: expect a probe on what governed the complaints you logged. If you know, say what, in your own words; if you do not know, or none of it was yours to track, say so plainly and stay with the log |
| F4 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says a monthly spreadsheet your regional manager uses, and does not show what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet showed and how each figure was counted. Say what it showed and how it was counted, in your own words; if you do not know how a figure was counted, or it showed something else, say so plainly and stay with the spreadsheet you built |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says tellers, not supervisors, and the words stay there: "trained new tellers on our escalation script." Answer slot: the JD's supervisors line makes a probe on coaching people at your own level likely. If you have advised or coached another supervisor on an escalation, say what you did, in your own words; if you have not, say so plainly and stay with the tellers |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not mention digital teams or self-service. Answer slot: the JD's line raises it. If you have worked with a digital or product team in any form, say what you did, in your own words; if you have not, say so plainly, and say how you would begin |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on the years: the quote carries them. Lead with its own terms, six years in retail banking and the last three as a branch supervisor, because a stated length beats an adjective. Not a gate: it is an experience length, not a credential |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Never a claim to senior presentations, and nothing added to make the gap feel smaller |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [grounded] | discovery | Your material says spreadsheet, not Excel. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names Excel, so expect a probe on what you built it in and what it did. If it was Excel, say what it did, in your own words; if it was another tool, or it did little, say so plainly and stay with the spreadsheet |

No requirement in the JD is a gate.

### Requirement coverage

| JD requirement | Covered by | Fit rows |
|---|---|---|
| Own the complaints process end to end across branches and the contact centre | A4, B2, C7, E2 | F1, F2 |
| Report monthly on volumes and resolution times | A5, D1, D2 | F4 |
| Coach branch supervisors on escalations | B3, E3, C3 | F5 |
| Work with digital teams on self-service journeys | B5, E4 | F6 |
| 4+ years in financial-services customer operations | A1, B1 | F7 |
| Experience handling regulated complaints | A4, E2 | F3 |
| Confident presenting to senior leaders | B4 | F8 |
| Comfortable with Excel reporting | A5, D1 | F9 |

## Grounding brief

Built from the four strategy points you pasted from the July 2026 brief and the recruiter's email. I have not seen the full brief.

| Fact | Source | Provenance | Where it is likeliest to surface |
|---|---|---|---|
| "move 40% of member service to digital channels by 2028" | strategy brief, your summary | [grounded] | A2, B5, E4 |
| "consolidate eight branches into five hubs over 2027" | strategy brief, your summary | [grounded] | C8; the panel's reverse questions |
| "launch a small-business lending product in Q1 2027" | strategy brief, your summary | [grounded] | A2 only; the JD has no line that touches it |
| "the main competitive pressure is app-only banks" | strategy brief, your summary | [grounded] | E1 |
| Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | values page you copied on 11 November 2026 | [grounded] | Round 3, scored by the panel |
| The panel is the values round and scores against the four values | recruiter's email | [grounded] | Round 3 |
| A branch consolidation may touch the panel members' own branches | derived from two branch managers on the panel and the consolidation point; no source says which branches | [inferred] | C8, and how you hear the panel's answers |

The brief is dated July 2026; read anything it dates (Q1 2027, the 2027 consolidation) as the plan as published then, and the recruiter's reverse question 4 in Round 1 is where to check whether it has moved.

---

## Round 1: the recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly walk through your background and the role; still scored | High. The relationship prior for a recruiter screen is Conversational plus a light Skeptic, and the email gives one 30-minute conversation | A pre-scripted 90-second arc (A1); treat casual JD questions as scored |
| Skeptic, light | Knockout checks and motivation: why this move, the contact-centre half of the role | Medium. Same prior; F2 and F8 are your stated gaps and a screen is where they are checked cheaply | The 30-second form of B2: plain acknowledgment, then one first step |
| All others | Pressure, Prober, Case, Peer | Low. The prior for this relationship names only the two above | None needed beyond the above |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped, 90 seconds. Beats are what the quotes state, at their scope: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Answer slot: say in your own words what draws you to member complaints work; the pack supplies no reason. If there is no settled reason yet, say what you want to learn | The opening question of a screen, and the arc carries F7, F1 and F4. EXP because it tests whether the CV's claims are the ones you tell |
| A2 | "What do you know about Ashgrove, and why us?" | CO | [grounded] | Pick one published value and one strategy fact you can speak to in your own words, and join one of them to the remit, for example the digital target to the self-service line of the JD. Do not recite the list. Answer slot: why Ashgrove is your own reason, in your own words; the pack supplies none | A recruiter screen is where "why us" is asked casually and scored, and the pasted brief makes it answerable. CO because it tests homework, not experience |
| A3 | "Tell me what you understand the role to do day to day." | JD | [grounded] | Restate the JD's four duties in your own words: the complaints process across branches and the contact centre; monthly reporting on volumes and resolution times; coaching branch supervisors on escalations; working with digital teams on self-service journeys. Then say which of the four you would most want to learn about first, which is your own answer | Shows the JD was read as a whole, including the contact-centre and digital lines that F2 and F6 sit under. JD because it scores the stated duties |
| A4 | "You handled the branch's formal complaints log. Tell me about that." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Say it at the quote's scope: you handled the branch's formal complaints log, and you trained new tellers on the escalation script. Answer slot: expect a probe on what happened to a complaint after it was logged, and on what governed the complaints in the log. If you know, say what, in your own words; if the log was where your part ended, or you do not know what governed them, say so plainly and stay with the log | F1 and F3 are the likeliest places to be probed, and this is the question that opens them. EXP because it tests what was actually yours |
| A5 | "The role reports monthly and the JD says Excel. How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the quote says: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it was in Excel, say what it did, in your own words; if it was another tool, or it did little, say so plainly and stay with the spreadsheet you built | F9 is the thinnest of the JD's tool lines and a recruiter can tick it in one answer. JD because it scores a stated requirement |
| A6 | "What are you looking for on salary, and what is your notice period?" | JD | [generic] | Give your own figures and dates; the pack has none and supplies none. If you do not have a number yet, say what you would need to know about the role first | The relationship prior for a recruiter screen includes logistics and knockout checks. JD because it tests fit with the offer, and generic because it is a pattern for any screen |

### Bank B, light: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why move from a branch supervisor role into this one, and why now?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Your own reasons, in your own words; the pack supplies none. Criteria for them: it names something in this role that draws you and not only something you are leaving, and it would survive being repeated unchanged to the Head of Member Services in Round 2. If the honest reason is mixed, say so plainly | A recruiter checks motivation consistency before passing you on. JD with a Skeptic stem because it probes why-leave, why-here, why-now |
| B2 | "This role owns complaints in the contact centre as well as the branches, and you haven't worked in a contact centre. How do you see that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | **The highest-ROI prep in this pack.** Hold-then-concede, 90 seconds. First, the plain acknowledgment: "I haven't worked in a contact centre." No hedge. Second, stay inside what the quote carries: you handled the branch's formal complaints log. Third, a plan in the future tense with only steps you would really take, for example: look at the contact centre's own complaint figures before forming a view; spend time with the people who take the calls; ask where branch and phone complaints differ. Never say you know how a contact centre handles complaints | F2 is half of the JD's first duty and a gap you stated, so the question will come in some form in all three rounds. JD with a Skeptic delivery; deepest rehearsal because the likeliest objection is aimed where the material is thinnest |

**B2 follow-up ladder.** The recruiter is likeliest to stop at rung 1; the manager in Round 2 is likelier to reach rungs 3 and 4.

| Rung | The interviewer pushes | Hold, then concede |
|---|---|---|
| 1 | "So how do you feel about that part of the role?" | The acknowledgment, the log, one first step. Thirty seconds |
| 2 | "How would you earn the contact-centre team's trust when you haven't done their job?" | Hold: you will start by listening and asking, not by instructing. Concede: you cannot yet say what their day is like |
| 3 | "What if the figures showed the contact centre handling complaints worse than the branches?" | Hold: you would want to see how each was counted before saying anything. Concede: you cannot say from experience which is right. Own the Fix applies here as a plan: whoever finds the problem keeps hold of it |
| 4 | "We might prefer someone who has done contact-centre work. What would you say?" | Concede it is a fair preference: "I haven't worked in a contact centre, and I would rather say that than claim it." Then what you do bring, the quote's own scope, and stop |

### Reverse questions: recruiter

| # | Question | Why it lands |
|---|---|---|
| 1 | "How does the contact-centre half of this role report into Member Services today?" | Turns the F2 gap into a request for information, which shows you are thinking about the contact-centre half and not hiding from it |
| 2 | "The panel round includes a 20-minute case on a complaint escalation. Is there anything on its format, or anything I would be given beforehand?" | The email names the case and not its form; a recruiter can often answer in one line, and it tunes E2 to E4 |
| 3 | "Do you know yet who will sit on the panel? Names would help me prepare." | Interviewer names are the one input that would add an interviewer read; asking is cheap |
| 4 | "How did this role come about, and what has changed since the July strategy was published?" | Ties the role to the strategy brief and may surface news that has moved since |
| 5 | "What happens after the three rounds, and when would you expect a decision?" | Closes the process loop and shows you are planning, not only performing |

---

## Round 2: Head of Member Services (your future manager), 45 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: contact centre, senior presentations, coaching supervisors, digital | High. The prior for a hiring manager is Case/Strategist plus Skeptic, and a manager is buying capability and weighing gaps; F2, F5, F6 and F8 are where yours are | The B2 ladder; bridges only from your own quoted sentences; a concrete ramp plan |
| Values/Behavioral | Scenario probes: unpopular truths, members over numbers, escalations | High. The recruiter calls this round mostly behavioural, which lifts it above the prior | Stories from your quoted sentences where one carries it; a selection scaffold ending in its honest branch where none does |
| Data-Driven Prober | Reads the spreadsheet line by line: what is in it, how it was counted, which part was yours | Medium. The manager would own the monthly reporting line, and F4 is a reporting claim | Say what you can and cannot say about how each figure was counted; say plainly when you do not know |
| Case/Strategist | One strategy question about competition or digital | Low. The prior would put it high; the recruiter assigns the live case to the panel round | Clarify, then structure, then challenge one premise |
| Pressure | Interruptions, "how much was actually you" | Low. No signal in the email | Pause, restate, hold through two follow-ups |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B3 | "The role means coaching branch supervisors on escalations. You trained new tellers on your escalation script. How would you coach someone at your own level?" | JD | [grounded] "trained new tellers on our escalation script"; "6 years in retail banking, the last 3 as a branch supervisor" | Say what the quote says: you trained new tellers on the escalation script. Answer slot: if you have advised or coached another supervisor on an escalation, say what you did, in your own words; if you have not, say so plainly and stay with the tellers. Then how you would go about it, as a plan in the future tense with only steps you would really take | F5 stops at tellers and the JD says supervisors; the manager will see the step. JD because it scores a stated duty, Skeptic because it presses on a stretch |
| B4 | "This role presents to senior leaders. I don't see presentations above regional level in your background. How do you expect that to go?" | JD | [grounded] "I've never presented to anyone above regional level" | Hold-then-concede. The acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare, as a plan in the future tense: who you would ask for the format senior leaders prefer, how you would rehearse, what you would want checked before the first one. Concrete steps only; no claim to presentations you have not given. Concession wording: "That is a step up for me, and I would want help early" | F8 is a stated gap against a JD line, so a manager will test it. JD with a Skeptic delivery |
| B5 | "The strategy moves 40% of member service to digital by 2028, and this role works with digital teams on self-service journeys. What would you want to understand first?" | CO | [grounded] | Answer slot: the JD's digital line raises a probe on whether you have worked with a digital or product team. If you have, say what you did, in your own words; if you have not, say so plainly. Then structure: which members and which complaints, which suit self-service and which need a person, what a member should not have to be told twice, and how a complaint passes from the app to a person. State the app-only banks as the brief's competitive pressure and make no claim about them beyond that | F6 has no evidence and the strategy puts digital at the centre, so this lands. CO because it asks for the company's altitude, with a JD stem |

### Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, a moment you did not soften it, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem, likely in a mostly behavioural round; it also lets the manager weigh the F8 gap against how you handle senior people. VAL because it scores behaviour |
| C2 | "When did you put a member ahead of an internal number?" | VAL | [grounded] | Selection scaffold. Name the number, what the member needed, and what it cost you; choose a story where the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first of the four published values is Members First, Always, so this is the stem the manager can borrow from it. VAL because it tests that value by name |
| C3 | "Tell me about a complaint that escalated, and what you did." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: pick a complaint where you can say who held it at each step, how it ended, and what you would change. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is that you trained new tellers on the escalation script, or how you would handle it | The JD's escalation line raises the theme, and no quote carries a particular escalation, so this is the scaffold case for F5's area. VAL because it asks for behaviour, EXP in delivery |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly complaints spreadsheet you built. What is in it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the quote says: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: the JD names volumes and resolution times. If it showed them, say how each was counted and which count you would trust least; if it showed something else, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet you built | F4 is the line a reporting manager will test hardest. EXP because it tests whether the claim survives scrutiny |
| D2 | "Which part of that was yours, and which was your regional manager's?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold: you built it; your regional manager uses it. Answer slot: if you chose what went into it, say what and why; if your regional manager or someone else set that, say so plainly. Never add a share the quote does not state | An attribution probe on F4. EXP because it tests what was actually yours |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "App-only banks are our main competitive pressure. What does complaint handling have to do with that?" | CO | [grounded] | Clarify what is meant by pressure, then say in your own words one thing a member-owned credit union with branches can do in a complaint that you would defend, and one place an app does it better. Make no claim about any competitor beyond the brief's sentence | Takes the brief's competitive point into the complaints remit, which is the altitude the manager can score. CO with a strategist delivery |

### Reverse questions: Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| 1 | "Where does the complaints process work well today, and where do complaints get stuck between branches and the contact centre?" | Speaks to the end-to-end line of the JD and invites the manager to name the problem you would be hired to own |
| 2 | "Which numbers do senior leaders look at each month on complaints, and who builds that report today?" | Goes straight at the reporting line and tells you what you would inherit |
| 3 | "How do you see self-service and complaints fitting together on the way to 40% of member service being digital?" | Ties the role to the brief's own number, without asserting anything about the plan |
| 4 | "As eight branches become five hubs, how does that change who I would be coaching, and when?" | Shows you have read the consolidation point and connects it to the coaching duty |
| 5 | "How do senior leaders like to receive complaints reporting, and who could help me learn that format early?" | Turns the F8 gap into a plan the manager can help with; it names the gap only through the ask |

---

## Round 3: panel of two branch managers, 60 minutes

### Persona weights

The panel's two members are unnamed, so personas are blended across the round rather than assigned per member.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | A scored conversation against the four values, by managers outside your remit | High. The recruiter says the panel is the values round and scores against the four values | One story or scaffold per value (see the values sheet); "we" for context, "I" for contribution |
| Case/Strategist | The 20-minute complaint-escalation case | High. The email says so directly | Clarify, then structure, then name one premise to test; think aloud |
| Peer Evaluator | The seam between a branch manager and this role; credit when work spans teams | Medium. Two branch managers are the people this role would work across; the JD puts coaching branch supervisors and branches in the remit | Reciprocity: what you bring their branch; seam principles, not pretended knowledge of their seam |
| Skeptic | The tension between Neighbours, Not Numbers and the branch consolidation | Medium. Derived: two branch managers on a panel and the consolidation point in the brief; no source says whose branches are affected | Do not resolve the tension falsely; name both sides |
| Pressure | Time-boxed challenges inside the case | Low. No signal in the email | Pause, restate, hold through two follow-ups |

### Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C7 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on the one beat the quote states: you handled the branch's formal complaints log. Answer slot: if you followed a complaint from the log to its end, say what it was, who else held it at each step, and how it ended; if you did not, or the log ended your part, say so plainly and say what you would hold if it were yours now | Own the Fix is the value this evidence sits closest to (F1). VAL because it scores that value by name |
| C5 | "Tell me about a time you made something clearer for a member." | VAL | [grounded] "trained new tellers on our escalation script" | Say what the quote says: you trained new tellers on the escalation script. Answer slot: if you ever changed wording, of the script, a letter or a call, because a member needed it explained twice, say what changed and why; if you did not, say so plainly and stay with the training. Say the answer itself in plain words; it is scored on that | Plain Words is the value most visibly tested by how you speak. F5 is the only sentence that touches it. VAL with a delivery check |
| C4 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold. Pick a decision where the member's side and an easier side pulled apart; say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always, scored by the panel as the first value. No quote carries a decision of this kind, so it is the scaffold case |
| C6 | "When did the town around your branch shape how you handled something?" | VAL | [grounded] | Selection scaffold. Pick a case where who the members were, or what mattered locally, changed your approach. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Neighbours, Not Numbers; two branch managers are the likeliest people to ask it with feeling. No quote carries it |
| C8 | "We are moving from eight branches to five hubs over 2027. How does Neighbours, Not Numbers sit with that, from where you stand?" | CO | [grounded] | Do not resolve the tension in one clause. Say in your own words what each side is: hubs and towns. Then what you would want to know first: which towns, what members there use, how a complaint from a town that loses a branch would still be heard. Concede you do not know the plan beyond what was published. If it is your own view, say it as your view | Derived from the brief and the values; whether the panel's own branches are affected is unknown, so listen before assuming. CO with a Skeptic delivery |

### Case/Strategist

The real case has not been shared. These three practice cases cover the usual shapes of a complaint-escalation case and are generic.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E2 | "A member has complained three times about the same unresolved issue. It is now with a branch and with the contact centre, and nobody is sure who holds it. Walk us through what you would do." | CASE | [generic] | Think aloud. Clarify first: what the issue is, what the member has been told, where the complaint sits now, and what time limits apply, asked and not assumed. Objective: the member is heard and the complaint closed properly. Name one owner today, which is the Own the Fix point. Reply to the member in plain words. Say what you would record and what the report would show. Test one premise: that nobody knows who holds it is itself a finding. If a panel member asks what you need from their branch, answer in one sentence | The case the recruiter named, in its likeliest shape. CASE because it scores structure, not the right answer, and it is where all four values can be shown at once |
| E3 | "A branch supervisor tells you the escalation steps slow them down and they would rather settle complaints at the counter. What do you do?" | CASE | [generic] | Listen first and ask which complaints they mean. Separate what can be settled at the counter from what must be logged and escalated, asking what the rules say and not assuming. Coach by asking how they would handle it before telling them. Hold: do not undercut the supervisor in front of others. Concede: if a step is slow, that is a finding for you. Concession wording: "If the step is slowing them down, that is useful to know" | Tests the JD's coaching line live, in front of branch managers who work with supervisors. CASE because it is a live problem |
| E4 | "A member cannot find how to complain in the app. What would you want to know before sketching a self-service complaints journey?" | CASE | [generic] | Clarify: who the members are, which complaints suit self-service, what a member must see, where it goes next, who holds it, and what measure shows it works. Apply the Plain Words test: if a member needs it explained twice, it was written wrong. Test one premise: should every complaint be self-service? Name where a person must take over | The digital line, set in the strategy's 40% target. CASE with a CO edge |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where is the seam between a branch manager and this role when a complaint goes wrong, and what happens when we disagree?" | JD | [generic] | Propose principles and not a seam you cannot know: at any moment one named owner; the branch hears first and the role sees across branches; disagreements go to the evidence in the reporting and not to rank. Reciprocity: what you bring their branch, a view across branches. Ask them where it breaks today | Peer panels weigh whether the hire adds to or reduces their load. JD because the role is defined across branches |
| F2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | "We" for context and "I" for contribution: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if others contributed to it or shaped it, say who and how; if it was yours alone, say so plainly | The Peer Evaluator's credit probe, set against F4. EXP because it tests attribution |

### Values sheet

| Value | Working meaning, paraphrased | Mapped story |
|---|---|---|
| Members First, Always | Decisions are made by asking what the member needs on their side of the counter | No quote carries one. Selection scaffold at C4, ending in its honest branch |
| Plain Words | The credit union's own writing should be clear enough that a member never needs it explained twice | F5: "trained new tellers on our escalation script". The only beat the sentence states; whether anything was ever reworded is an answer slot at C5 |
| Neighbours, Not Numbers | Each branch is treated as part of its town and not as a line in a total | No quote carries one. Selection scaffold at C6, ending in its honest branch |
| Own the Fix | The person who finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log". The one beat the sentence states; what happened after the log is an answer slot at C7 |

### Reverse questions: panel

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new person in this role do in their first month that would genuinely help your branch?" | Reciprocity: shows you think about what you bring a branch, not only what you need |
| 2 | "When a complaint at your branch needs help from outside it, what has worked and what has not?" | Invites their experience of the seam and shows Own the Fix is your frame |
| 3 | "As eight branches become five hubs over 2027, what do you most want kept from your branch's way of handling members' complaints?" | Opens the consolidation on their terms; the panel scores against Neighbours, Not Numbers |
| 4 | "When something changes in how complaints are escalated, how does it reach supervisors?" | Ties to the JD's coaching line without claiming a practice |
| 5 | "How would you like to hear when the new reporting shows a problem in your branch?" | Tests the seam in the open and makes you the colleague who tells them first |

---

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns, or has owned, the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says one branch's log. The slots at A4 and C7 stay inside the log |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has handled complaints under a regulatory regime | Inflated form of F3 | F3's quote at its own scope: a formal complaints log. The limit is the pack's observation: the material does not show what governed the complaints in it. A4's slot asks only what governed them |
| Reported on complaint volumes and resolution times | Inflated form of F4 | F4's quote at its own scope: a monthly spreadsheet your regional manager uses. D1's slot asks only what it showed and how it was counted |
| Has coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: "trained new tellers on our escalation script." B3's slot stays with tellers |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Built the reporting in Excel | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. A5's slot asks only what it was built in |

## Sources

Provided documents: the JD; the values page you copied on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; four points you pasted from Ashgrove's July 2026 strategy brief (the full brief was not seen); your background in your own message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page already supplies all four names and wordings, so the values sheet and the VAL bank are fixed |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email states three rounds, their lengths and who runs each, so the loop and persona weights are fixed |
| 3. Ashgrove strategy and recent news | skipped | The four pasted strategy points fix the grounding brief and the CO questions; the brief is four months old |
| 4. Interviewer name and Ashgrove | n/a | No names were given, only roles, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- The names of the recruiter, the Head of Member Services and the two panel branch managers → an interviewer read from their public professional footprint, persona weights per panel member, and a reverse question tied to each person's own path
- The recruiter's answer on the 20-minute case: written or spoken, any materials beforehand → E2 to E4 retuned to the real format; one email
- Your own answers to the slots on the complaints log, the monthly spreadsheet, the escalation script and any digital-team work, said outside a drill → F1, F3, F4, F5, F6 and F9 move from thin to quoted stories, and the matching bank rows regenerate
- An anonymised extract of the monthly complaints spreadsheet, columns only and no member data → F4 and F9 move from medium and low toward high, since the spreadsheet is the artifact this field keeps
- The full July 2026 strategy brief → the grounding brief is built from four points; the full text could replace them with specifics and may change the CO questions
- A deeper research pass, up to 6 further searches and 2 further fetches, several more minutes → recent organisation context, loop reports for this role family and, once names exist, interviewer footprints; offered once
- A tuesday-dossier.md from an earlier evidence pass → a verified evidence base, a named top objection and a prohibited-claims list from that pass in place of the ones built here; this pack was built without one
