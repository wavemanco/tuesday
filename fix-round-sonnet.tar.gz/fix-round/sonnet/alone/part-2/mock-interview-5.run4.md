I'm reading the skill's reference files and now running the company research, then I'll build your prep pack.
Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md` in the working directory. I built it for a panel round using the recruiter's email and your background summary. There was no JD, and the web searches I sent were refused. I also couldn't read the market report. Nothing in the pack rests on outside research, and the interviewer read, the company grounding section and the values sheet are left out.

**What the pack found**
- The objection to rehearse most is "you've never sold into rail and you've never carried a quota." You stated both gaps yourself. The pack coaches you to concede them plainly, then hold only what your own sentences carry. That is B1 (with D1 as the 60-second version).
- Ross's "push on commercials" most likely lands on your £4M of influenced revenue and the 6-to-40 partner count. C1, C2 and D2 rehearse "how was it counted" and "how much was you." The pack never supplies a method for you, and "I don't know how it was counted" is an allowed answer.
- The POV section gives three thesis options, each with a concession. It recommends leading with "operator outcomes as the unit of partnership," which suits the recruiter's ask to land on operators. It also covers a 15-minute timing plan and an anti-pick. Because the report is their own strategy team's work, cite one item from it and then depart from it. Don't recite it.
- The four-hour prep triage runs 90 minutes on the POV, 60 on the objection, 45 on commercial drills and 30 on your biography arc and reverse questions.

Say the word and I'll play Ross on B1, the pack's highest-ROI question. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you'd like.

Do you have the JD text? It would turn the two role-family rows (F5 and F6) into quoted requirements and would surface any location or right-to-work conditions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack — Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday. 60 minutes, panel of two: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your spoken POV, no slides. Rest: Q&A, where "Ross will push on commercials" (all from the recruiter's email, quoted in your message).

**Built on:** the recruiter's email and your own background summary only. No JD was supplied, the market report's content is not in hand, and the research searches were refused, so nothing here rests on web research.

## How to use this pack

- **Personas** describe how a question will arrive (who asks, in what style). **Types** describe what is being scored.
- Type key: **VAL** values and behaviour (not expected as a round here); **EXP** your experience under scrutiny; **JD** the role's stated requirements; **CO** company and strategy knowledge; **CASE** a live problem.
- Guidance is scaffolding, not a script. Every line about your past rests on a sentence you wrote, quoted next to it. Where the material does not carry a detail, the cell says "answer slot": answer from your own experience, or say plainly it was not yours or you do not know.
- All proposed wording in this pack is pending your approval; say it only if it is true in your own words.

## Prep triage (about four hours, across the weekend)

| Order | Block | Time | Where in this pack |
|---|---|---|---|
| 1 | Build and time the 15-minute POV: pick a thesis, write the concession and the operator close, say it aloud twice with a timer | 90 min | POV section; A1 |
| 2 | Rehearse the one objection you will certainly face, out loud, through two follow-ups | 60 min | B1 (highest-ROI), D1 |
| 3 | Commercial pressure drills: the 6-to-40 count, the influenced-revenue figure, the quota question | 45 min | C1, C2, D2, D3, C3 |
| 4 | Biography arc, reverse questions, and a re-read of the market report to choose one item to cite and one place to depart | 30 min | E1, reverse questions |

Everything else in this pack is insurance.

## Fit snapshot (proposed wording, pending your approval)

Requirements are the recruiter's own words, quoted, except F5 and F6, which are role-family expectations written in plain prose because no JD was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material shows a channel grown, not a forward view of Kelverton's operator partnerships; the words stay at the quote's scope: "I took the ISV channel from 6 partners to 40." Answer slot: expect a probe on how the growth came about; say which part was yours, in your own words, and if you do not know how it was counted or it was not all yours, say so plainly and stay with that sentence |
| F2 | "land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The pack observes that the quote says bus and light rail, not train operating companies, and the words stay at that scope. Answer slot: the recruiter's close on operators makes a probe on how train operators differ from the ones you planned for likely; if you can say where they differ from your own work, say it in your own words, and if you cannot, say so plainly and stay with the planning work |
| F3 | "Ross will push on commercials" — recruiter's email | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't carried a direct quota." Then how you would approach a number as a plan, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F4 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure is yours but the material does not show how it was counted. Answer slots, in your own words: how it was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly; that is an honest branch |
| F5 | Grow and run a partner channel for a software vendor (role-family expectation, no JD supplied) | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [generic] | none | The sentences already speak to the expectation in role-relevant terms; lead with them as written. Expect the count to be probed because nothing inspected stands behind it |
| F6 | Credibility selling or partnering into rail (role-family expectation, no JD supplied) | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then a ramp plan, said as a plan. Nothing offered as rail selling experience |

## Graded deliverable: the 15-minute POV (proposed wording, pending your approval)

The recruiter asked for "a short POV on where you'd take our operator partnerships over the next 18 months", landing on "what it means for the operators themselves". It is graded.

**Facts to build on**

| Fact | Row | Sentence, quoted from that row |
|---|---|---|
| The channel you ran and grew | F1 | "took it from 6 partners to 40, roughly £4M of influenced revenue" |
| Your operator-side vantage | F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" |
| The limits you will be probed on | F3, F6 | Held in the prohibited claims section; concede them plainly if the POV invites the question |

**Theses.** Each is a hypothesis to test against the market report, not a claim about Kelverton's current partnerships.

| Thesis | The argument | What it means for operators | Mandatory concession | Basis |
|---|---|---|---|---|
| T1 Depth over breadth | Make fewer operator partnerships do more, rather than adding partnerships | Operators get a partnership with shared outcomes they can hold Kelverton to | Depth narrows the base, and if one operator's priorities shift the plan is exposed | [generic] |
| T2 Operator outcomes as the unit | Agree with each partner operator the operational results the partnership exists for, and plan the 18 months backwards from them | Operators can see what the partnership is for in their own terms, not Kelverton's | Which results matter is for operators to say, not for you to assume, and the results depend on changes Kelverton does not control. Your vantage is F2's quote at its scope | [inferred] derived from the recruiter's ask and F2 |
| T3 Extend through third-party partners | Add channel partners around the operator relationship, the motion in F1 and F5 | Operators get more of what they need alongside the core product without running the integrations themselves | Your channel history is in payments, whether rail needs this motion is an assumption to test, and it could add partners faster than operators want them | [inferred] derived from F1 and F5 |

**Recommendation.** Lead with T2: the recruiter's close is the operators, and F2 is your strongest quoted vantage. Use T3 only as a named option you considered, because it leans on a payments motion and sits beside the F6 gap.

**Differentiation from the report.** The report is your interviewers' own strategy team's work, so it is the most shared source in the room. Do not recite it. Bring one item from it, to show you read it; then one place where your thesis departs from it, with your reasons; then the anti-pick.

**Anti-pick.** Say what you would decline: making partner count the headline measure. Give it as a choice you would test, not a verdict on the current programme, and name what you give up: a count is easy to report. Reason to offer, as a hypothesis to check against the report: operators' time may be scarcer than Kelverton's partner list. Basis: [generic]. If you say it, "I took the channel from 6 partners to 40" stays at that scope.

**The close, as the recruiter asked.** Finish on three plain statements about operators at month 18: what they could do or see that they cannot now, what they would be asked to commit, and what they could stop doing. Answer slot: if you can say where each comes from in your own planning work, say it; if it comes from reading rather than work, say so plainly.

**Timing for 15 minutes.** 1 minute: your thesis in one sentence. 2: the one item you cite from the report. 6: the thesis and its concession. 2: the departure from the report and the anti-pick. 3: the operator close. 1: spare.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (weight highest) | Deepa pushing on the POV live: what you would need to know, where you would start, what you would not do | High. A hiring manager's prior is Case/Strategist plus Skeptic, Deepa is your future manager, and 15 of the 60 minutes are a strategy POV | Clarify, state the objective, structure, name risks; use Kelverton's own vocabulary from the report |
| Skeptic | Both panelists on the gaps you have named yourself: rail selling, quota | High. Hiring-manager prior, and F3 and F6 are stated negatives, so this objection will be asked in some form | Rehearse B1 until it is boring: concede first, hold only what the quotes carry, give a ramp plan |
| Data-Driven Prober | Ross on the 6-to-40 count and the influenced-revenue figure | Medium-high. "Ross will push on commercials" stands in for his relationship prior, which is not given, and F4 is a figure with nothing inspected behind it | For each figure: how it was counted, what it is sensitive to, the assumption you would defend least; say plainly when you do not know |
| Pressure | Ross time-boxing or challenging the commercial answers | Medium. Plausible from "push", but the recruiter gave no sign of style, so this is a prior and not a finding | Pause, restate the question, hold through two follow-ups, concede specifically |
| Conversational / Rapport | The opener and the closing "any questions" | Low-medium. 60 minutes with 15 taken by the POV leaves a short Q&A | A 90-second arc built from your quoted sentences; real reverse questions |
| Peer Evaluator | Partnerships and Commercial seam questions between the two panelists | Low-medium. [inferred] from the two titles the recruiter gave | Offer principles for the seam, not a claim to know it; reciprocity framing |
| Values / Behavioral | Scenario probes against published values | Low. The recruiter named no values round, so none is detected and no bank is written | If a values prompt arrives, pick a time from your own work and, if none comes to mind, say so plainly |

## Question banks

### A. Case / Strategist (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | The POV section is the build; this is the live version, so open with your thesis in one sentence, then its concession. If your own past comes in, keep it to "I took the ISV channel from 6 partners to 40" and leave it there. Answer slot: if asked how that count was reached, say how in your own words; if you do not know, or it was not all yours, say so plainly | F1 is the evidence, and this is the question the recruiter pre-announced; CASE because it is a live strategy problem |
| A2 | "What would you need to know before committing to a plan for operator partnerships?" | CASE | [generic] | Clarify before you structure: what an operator partnership currently is, which operators and why, how success is measured today, what constraints apply, what the report is silent on. Then state the objective you would plan against. The question needs no claim about your past, so the guidance makes none | The Case persona scores clarifying before structuring; [generic] because it is a pattern for the problem |
| A3 | "Operators are customers and partners at once. How do you stop those two relationships pulling against each other?" | CASE | [generic] | Separate what is commercial from what is collaborative, say how you would decide which applies, and say how a disagreement is resolved and by whom. Name what you do not know about how Kelverton handles this today | The F2 requirement is about the operators' view, and this tests it as a decision; the guidance makes no claim about your past |
| A4 | "Name one operator problem scheduling software does not solve today, and what a partner could do about it." | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Name the problem from the operator's side, say your planning background is bus and light rail, and say what you would check to see whether it holds for train operators. Answer slot: if the problem comes from work you did, say how; if it comes from reading, say so plainly | F2 is the only operator-side evidence, and the quote's limit decides how it is framed |
| A5 | "If you could do one thing in your first 90 days, what would it be, and what would you not do?" | CASE | [generic] | Pick one, tie it to your POV thesis, and say the anti-pick from the POV section as a choice. Makes no claim about your past | Previews the anti-pick, which the POV is likely to be probed on |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail and you've never carried a quota. Why should we trust you with this?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | The highest-ROI rehearsal in this pack. Concede first, in the sentence's own words: "That's right: I've never sold into rail specifically, and I've never carried a direct quota." Then hold only what the quotes carry: the channel at "6 partners to 40", and the operator-side vantage at bus and light rail. Limit, named before it is asked: the quote says bus and light rail, not train operators, and "influenced" stays "influenced". Follow-up 1, "influenced isn't sold": agree the figure is influenced revenue and go no further. Follow-up 2, "bus isn't rail": agree the difference, restate the scope, then give a ramp plan as a plan: what you would learn first and from whom. Never claim rail selling or quota experience | Stated gaps in F3 and F6 make this objection near-certain; JD because it scores the role's fit, and it is the deepest rehearsal so it gets the most follow-up levels |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Choose from your own stated gaps, say it plainly, then the ramp plan as a plan. Answer slot: if a different weakness is the real one, say that instead; do not substitute a polished gap for a true one | The Skeptic stem for gaps; F3 and F6 are the evidence |
| B3 | "Why leave payments for rail, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Two chapters in the quotes' own terms: transport consulting, partnerships, most recently the ISV channel. Answer slot: your reason for moving now is not in the material; give it in your own words, and if it is not a tidy story, say that plainly rather than shaping it | Motivation consistency is what the Skeptic scores; EXP because it tests the career story |
| B4 | "You ran an ISV channel in payments. Why would that carry over to operators who buy scheduling software?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold "running the ISV channel" at that scope, concede the sector difference plainly. Answer slot: if you can say which parts of the motion apply here and why, say so in your own words; if you do not yet know, say so and say how you would find out in the first 90 days | F1 and F5 are the evidence, and the transfer probe follows from the sector change |

### C. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said roughly £4M of influenced revenue. Walk me through how that was counted." | EXP | [grounded] "roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | Say what the figure is, "roughly £4M of influenced revenue", and what it is not: a quota carried. Answer slots, each in your own words: how it was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Do not offer a method or attribution model you did not use | F4 is the headline number, so a defend-the-number question is certain; EXP because it tests attribution |
| C2 | "On the 6 to 40 partners: what counted as a partner, and how did you count?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say the count as you said it, "took it from 6 partners to 40". Answer slots in your own words: what counted, how it was counted, what the figure is sensitive to, the assumption you would defend least, and which part was yours. If any of that is not known to you, say so plainly | The second headline figure on F1; EXP for the same reason as C1 |
| C3 | "How would you think about the commercial model for an operator partnership: who pays whom, for what?" | CASE | [generic] | Clarify first: what is being exchanged and what Kelverton's models are today. Then a framework you would apply, labelled as a framework. Answer slot: if you have set commercial terms with partners before, say what and which part was yours; if you have not, or it was not yours, say so plainly and walk the reasoning as a plan | The recruiter said Ross will push on commercials, which is a raising source; CASE because it is a live problem, and the guidance makes no claim about your past |

### D. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause, restate the question. Concede first: "I've never sold into rail specifically." Hold two things at their scope: the channel at "6 partners to 40" and the bus and light rail planning vantage. Do not claim to be better than the other candidate. Hold through two follow-ups; concede the specific limit, never the core claim | The Pressure stem aimed at F6; JD because it scores the fit |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | Hold the word "influenced". Answer slot: say which part was yours in your own words; if you do not know how it was split, or it was not mostly yours, say so plainly. Concede the specific limit, then return to the sentence | The Pressure stem, on the figure in F4 and the stated limit in F3 |
| D3 | "What commercial number would you let us hold you to in your first twelve months, and why that one?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Acknowledge plainly: "I haven't carried a direct quota." Then reason as a plan: ask what the number attaches to, whether influenced or direct, and say you would agree it with Deepa before committing. Do not name a figure you cannot defend | Commercials is the recruiter's flagged area and F3 is the stated gap; the question is asked as a decision, so it presupposes nothing about your past |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc, two chapters in the quotes' own terms: transport consulting, then partnerships, the last four years on the ISV channel. Answer slot: why this role is in your own words; if that is still being worked out, say so | The casual opener is still scored, and F1 and F2 give the only sentences |
| E2 | "What is it about our operator partnerships that interests you?" | CO | [generic] | Be specific from the report, not the website; name one thing you would want to understand better. Makes no claim about your past | A CO question that goes generic without the report in hand; this pack could not read it |

### P. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Partnerships and Commercial sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [inferred] derived from the recruiter's titles for the two panelists, not from any document on how the teams work | Propose seam principles instead of pretending to know it: who owns the operator relationship day to day, who owns the commercial terms, how disagreements are escalated. Reciprocity: what you would bring Ross's team. Makes no claim about your past | The Peer stem on the seam; both panelists are from adjacent functions |
| P2 | "How do you handle credit when a deal spans partnerships and sales?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" | Say plainly that your figure is influenced revenue, not quota. Answer slot: if there was an agreed way credit was split with sales, say what it was and what part was yours; if there was none, or you do not know how it was done, say so plainly and say what you would propose here | The Peer stem on credit; F3 is the stated limit it presses on |

## Requirement coverage

| Row | Requirement | Questions covering it |
|---|---|---|
| F1 | The 18-month POV | A1, A2, A5, E2, B4, plus the POV section |
| F2 | The close on operators | A3, A4, B1, plus the POV section |
| F3 | Commercials: quota | B1, B2, D1, D3, P2 |
| F4 | Commercials: the £4M figure | C1, C2, D2 |
| F5 | Run a partner channel | B3, B4, E1, C2 |
| F6 | Credibility in rail | B1, B2, B3, D1 |
| none | Values round | — none, because the recruiter named no values round |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | To Deepa: "What does a good first six months look like for this role, and what would you want changed by month 18?" | It hands you the measure you will be held to and shows you plan against the horizon she set |
| 2 | To Ross: "Where do operator partnerships show up in the commercial numbers today, and where would you like them to?" | It goes to the topic the recruiter said he will push on and invites his view instead of answering his challenge |
| 3 | "Is success in this role measured on influenced revenue, direct quota, or something else?" | It puts the quota question on the table on your terms, which is where F3 would otherwise be found |
| 4 | "Which operator relationship should a new person learn first, and why?" | It starts you from operators, which is where the recruiter said to land |
| 5 | "Which part of the strategy team's report is driving most of your planning right now?" | It shows you read it and tells you which items your POV should not merely repeat |
| 6 | "How do Partnerships and Commercial split credit on an operator deal today?" | It tests the seam P1 and P2 probe, and lets you ask rather than guess |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried or owned a revenue number, or sold £4M | You stated "never carried a direct quota, only influenced revenue" (F3) | The figure at its own words, "roughly £4M of influenced revenue" (F4), plus the plain acknowledgment: "I haven't carried a direct quota." No slot |
| Rail selling experience | You stated "Never sold into rail specifically" (F6) | The plain acknowledgment: "I've never sold into rail specifically." Then a ramp plan, as a plan. No slot |
| Insider knowledge of train operating companies | Inflated form of F2's quote | The quote at its own scope: bus and light rail network planning, "the operator world from the other side". The limit is the pack's observation: your material says bus and light rail, not train operators. A4's slot stays inside the planning work |

## Sources

Provided documents: your message (your background, and the recruiter's email quoted); the market report the recruiter attached, which is not in my hands and was not read. No dossier was present.

Searches sent, all refused, returning nothing:

- "Kelverton Rail values" — refused
- "Kelverton Rail interview process partnerships manager" — refused
- "Kelverton Rail strategy train operating companies scheduling software news" — refused
- "Deepa VP Partnerships Kelverton Rail" — refused
- "Senior Partnerships Manager rail technology job description train operating companies" — refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Every call was refused. It would have fed a values cheat sheet; none is written because no values-style round is detected from the recruiter's words |
| 2. Interview process, partnerships role | unavailable | Every call was refused. The recruiter's words fix this session's structure, so the persona weights stand; any wider loop information is not established |
| 3. Strategy and recent news | unavailable | Every call was refused, and the report's content is not in hand. It would have fed the grounding brief and made A4 and E2 grounded rather than generic |
| 4. Interviewer public footprint | unavailable | The one call, for Deepa, was refused; Ross was not searched. It would have fed an interviewer read and a reverse question tied to their paths |
| 5. Representative JD | unavailable | Every call was refused. It would have turned F5 and F6 into quoted requirements and set which questions are JD-tagged |

## Upgrade menu

- The market report's text, pasted or its key pages → a grounding brief in its own vocabulary; the POV's cited item and departure become specific; A4 and E2 move from generic toward grounded
- The JD text → F5 and F6 become quoted requirements, JD-tagged questions are re-checked against its list, and any gate such as location, authorization or travel is surfaced
- Search access, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → company values, loop details, and the interviewers' public footprint, giving a Reading the interviewer section and a reverse question tied to their paths
- Deepa's and Ross's surnames or profile links → persona weights read from their public professional footprint
- A partner list or channel report from your payments role, or your own answers to the C1 and C2 slots → F1, F4 and F5 are raised from medium and the answer-slot cells become story-mapped
- A verified-evidence dossier (tuesday-dossier.md) → verified claims and prohibited claims arrive from an evidence review rather than from this pack's own reading
