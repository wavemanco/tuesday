I'll read the reference files the skill requires before building the pack.
Here's where things stand: I've finished the company research (values, loop structure, strategy news, Tobias's public footprint) and I'm now writing your prep pack to a file.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-canned-925e459e/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 21 questions, a fit snapshot against the JD, an interviewer read, a values cheat sheet and six reverse questions.

I built it on the assumption that Tobias is your hiring manager. Saltmarsh's careers page says every loop is a recruiter call, then the "Outage Hour": a 60-minute interview with the hiring manager, made up of a live-incident tabletop on a simulated outage, then a values conversation. So the pack leans on the tabletop, the three published values (Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener) and the objections to your gaps.

**Most important prep:** question C1, "you've never worked on a game with in-app purchases". The pack says what to concede, what to hold, and how to state a plan without claiming experience. It also asks about leading a team, since you've said you haven't, and about one calendar versus two. The tabletop scenarios in the pack are my invention, because Saltmarsh's real one isn't public, so rehearse the structure and not the content.

The research read two things only as search snippets, not full pages. Check the Project Larkspur announcement and the listing for Tobias's GDC talk (*Patch Notes Are a Promise*) yourself before relying on them.

Say the word and I'll play Tobias for a live drill, starting with C1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, or someone more senior? The answer reweights every bank.
Did your recruiter say anything about what the tabletop will cover?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Built as your hiring manager: the careers page says the Outage Hour is held with the hiring manager (confirm that Tobias is yours).
**Round:** the Outage Hour — one 60-minute interview: a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows Saltmarsh's published values |
| EXP | Whether what you told them survives follow-up; what was actually you |
| JD | A stated requirement in the posting, gaps included |
| CO | Whether you have done homework on the company and can think at its altitude |
| CASE | A live problem from the role, reasoned out loud |

An answer slot is an instruction for the interview, not a question for this conversation. It marks a place where the pack does not know what is true of you, so it offers two honest branches. Take whichever one is true.

## Prep triage

You have two days. Do these in order; everything else is insurance.

1. Today: say C1 aloud five times, concession first (it is the highest-ROI prep in the pack). Then C2.
2. Today: build your 90-second arc from F1 in the question bank, using only the four sentences it quotes.
3. Thursday: run A1 to A5 aloud, timed, saying your structure before your answer. Then B3 and B1.
4. Thursday: read the two Saltmarsh pages in Sources (values and the Project Larkspur announcement) so A5, F2 and reverse questions R3 and R4 are in your own words.
5. Friday morning: reverse questions only, and the watch-out below.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, and the words stay there: "For two years I ran the weekly content-drop calendar for our main title." The JD says live events and two titles. Answer slot: if you ever ran anything on that calendar beyond the weekly drops, or a calendar for another title, say what; if you did not, say so plainly and stay with the weekly calendar for the main title |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: weekly, the main title, two years |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team, and never worked on a game with in-app purchases" — your message | low | [inferred] | discovery | Your material does not show which disciplines touched a drop. Answer slot: the JD names four teams, so expect a probe on which of them your drops involved; say which, and what part was yours, in your own words; if a team was not involved, or the coordination was not yours, say so plainly and stay with the calendar. Plain acknowledgment from your own sentence: "I haven't led a team." Then how you would get work moving, said as a plan and never as a past |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD says own the review and its KPIs, so expect a probe on who produced the numbers and whether anything was reviewed after a release; if you prepared the numbers or reviewed a release, say what and whose part; if the numbers came from someone else, or there was no such review, say so plainly and stay with presenting them |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it. Lead with the quote's own terms: you wrote it, and QA still uses it. Your material says wrote, not maintained or managed, so the upkeep is an answer slot in E2 |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | discovery | Your material gives four years as an associate producer and two years on the calendar, and does not show which years were on a game updated live. The JD's 3+ is not a hard gate; it is graded on evidence. Answer slot: say which years were on a game that was being updated on a live basis; if only the last two were, or you cannot say, say so plainly and stay with the two years on the calendar |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but nothing inspected behind it. Lead with the quote: monthly, retention numbers, the studio head. Expect a probe on how the numbers were counted; that is an answer slot in E1 |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The one written artifact in your material is the checklist; word it as the quote does: "I wrote the release checklist our QA team still uses." Nothing else is added to it. A written sample would raise this row (upgrade menu) |
| F9 | Familiarity with the purchase side of Saltmarsh's titles — derived from the Project Larkspur announcement (season-pass model for two titles, per a search result), not stated in the JD | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to purchase-side work, and nothing added to make the gap feel smaller |

## Graded deliverables and grounding brief

Not included. No deliverable was declared and the careers page says there is no take-home. No L2 research ran, so there is no grounding brief.

## Reading the interviewer

| Observation | Source | Provenance | What it means for you |
|---|---|---|---|
| I1: Tobias Wrenfield is Head of Live Operations at Saltmarsh | GDC 2026 talk listing, search result 4 in Sources | [grounded] | He sets the standard the role is judged against, so expect the interview to test judgment, not trivia |
| I2: The listing says he was previously a QA lead at a console studio | same listing | [grounded] | Release checklists and QA hand-offs will be a familiar subject to him. Expect depth on F5 (E2, A3). Your sentence for that ground: "Wrote the release checklist our QA team still uses" (F5). It is a shared subject, not a shared story; do not claim kinship |
| I3: His 2026 GDC talk is titled Patch Notes Are a Promise, and the listing describes its argument as judging a live team by whether patch notes match what shipped | same listing | [grounded] | The theme matches the published value Ship the Patch Not the Promise. Expect questions on what you tell players and when (A2, B2). I read the listing, not the talk |

Public footprint only. Nothing here goes beyond what the listing says.

## Persona table

What the weights rest on:

| Fact | Source | Provenance |
|---|---|---|
| Loop: recruiter call, then the Outage Hour — "a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." | saltmarshgames.com/careers/interviewing, fetched | [grounded] |
| Three published values: Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener | saltmarshgames.com/values, fetched | [grounded] |
| Project Larkspur: season-pass model and one shared events calendar for two titles from February 2027, per-title event teams retired in favour of one live-ops group (read as a search snippet, page not fetched) | saltmarshgames.com/news/project-larkspur, search result | [grounded] |

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The tabletop: a simulated outage during a live event | Highest. The loop source names the tabletop as the first part, and the hiring-manager prior is Case plus Skeptic | Clarify, then impact, then first action, then player message, then what you record. Think aloud. A1 to A5 |
| Values/Behavioral | The values conversation, on the three published values | High. The loop source names a values conversation as the second part | Map each value to a quoted sentence where one carries a story; use the selection scaffold where none does. B1 to B4 and the cheat sheet |
| Skeptic | Quiet probing of the two things you told me you have not done, and of one title versus two | High. Hiring-manager prior, and F3 and F9 carry your own stated negatives | Rehearse C1 until it is boring: concession, hold, plan. C1 to C4 |
| Pressure | Interrupting the tabletop, time-boxing | Medium. Pack inference only: a live scenario makes interruption plausible, and the loop source does not say it is adversarial | Pause, restate, pick one action first. D1 to D3 |
| Data-Driven Prober | Line-by-line on the checklist and the retention numbers | Medium. I2 (QA background) and the JD's checklist and KPI lines point here | Say what you know about how things were counted, and say plainly where you do not. E1 to E3 |
| Conversational | The opener, probably: "walk me through your journey" | Lower, but the opener is scored. Pack inference from the loop's shape | A 90-second arc built from your quoted sentences. F1 and F2 |
| Peer Evaluator | Not weighted | The loop source puts the hiring manager in the room, so no bank | None |

## Question banks

### A. Case/Strategist — the tabletop (weight highest)

The scenarios below are invented by this pack. Saltmarsh's real scenario is unknown, so rehearse the structure, not the content.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's the first day of a weekend event. Players can't log in and the event timer is still running. What do you do in the first ten minutes?" | CASE | [generic] | Say your structure first: what is broken and since when, who is affected, whether the timer is running. Then your first action and who you pull in (engineering, community, QA). Then what players hear and when they hear next, and what you would record for the review. State the assumption you are least sure of. Makes no claim about your past | The loop source names a live-incident tabletop on a simulated outage during a live event. CASE because it scores structure under time pressure; `[generic]` because it is a pattern, not Saltmarsh's scenario |
| A2 | "Give me the first message players see, aloud, in two sentences." | CASE | [grounded] | What is known, what is not yet known, when the next update comes. Announce only what is confirmed; the published value reads "we announce what is built, not what is hoped". Do not promise a fix time you cannot back. Makes no claim about your past | Covers the JD's written-communication line (F8) in a live form, and the value and the interviewer's talk theme (I3) point the same way. CASE delivery, JD content |
| A3 | "Engineering has a hotfix. QA says one item on the release checklist is not signed off. What do you do?" | CASE | [generic] | Ask what exactly is unsigned and what shipping versus waiting costs players. Say who owns the call. Then pick one option out loud, with the condition that would change your mind, and say what you would record. The published value "when the calendar and the players disagree, the players win" is the frame. Makes no claim about your past | JD line on the checklist with QA (F5), asked as a decision. A hiring manager with a QA background (I2) will like this one. CASE because it is a live trade-off |
| A4 | "The incident is over. What goes in the post-event review, and which numbers do you report?" | CASE | [generic] | Structure it: what happened, how players were affected, what the numbers say, what changes next time. Name two or three numbers you would look at first and say what each would and would not tell you. Say who gets the review. Makes no claim about your past | JD line on the post-event review and its KPIs (F4), asked as a decision. CASE because it is reasoning, not recall |
| A5 | "Project Larkspur puts both titles on one shared events calendar from February 2027. A launch for one title collides with a big event on the other. How do you decide?" | CASE | [grounded] | Clarify first: which dates are fixed, which can move, what the collision costs each title's players. Rank by player impact, then propose a rule for future collisions. Say what you would ask the team. Do not assert how Saltmarsh will actually run the shared calendar; you have read one announcement. Makes no claim about your past | The strategy question: current, specific, and untouchable without research. CASE because it is a live problem; the premise comes from the Larkspur announcement (search snippet, page unread) |

### B. Values/Behavioral — the values conversation (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the plan and the players pulled in different directions. What did you do?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Value: Players Before Plans. The plan you can speak to is the calendar: the weekly calendar, the main title, two years. Answer slot: if a drop was moved, held or changed because of how players were affected, say what happened and what part of the decision was yours, in your own words; if none comes to mind, or it was not yours, say so plainly, then give the nearest thing your material carries, which is the calendar, or how you would decide | The value's own wording sets the theme. F2 is the only row that carries a plan to put the players against; VAL because it scores behavior against a named value |
| B2 | "When have you had to decide what to say about something that was not built yet?" | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Value: Ship the Patch Not the Promise. Selection criteria: a named decision, what you chose to say, and what was true when you said it. The nearest sentence you have is the monthly presentation of retention numbers; say that in its own words. Answer slot: if any month's numbers fell short of what had been hoped, say what you said and what part was yours; if none did, say so plainly and stay with the presentation, or say how you would decide | The value's own wording sets the theme, and it matches the interviewer's talk (I3). F7 is the closest row to a truth-telling story; VAL because it scores a decision against a value |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Value: Leave the Build Greener. The story has the beats the quote states: you wrote the checklist, and the QA team still uses it. Answer slot: if there was an earlier version or a problem it fixed, say what changed and why; if there was no earlier version, or you do not know what changed, say so plainly and stay with the checklist | The strongest value-to-story fit in your material (F5), so rehearse it first. VAL because it scores behavior against a named value |
| B4 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Persona stem for the unpopular-truth probe. Selection criteria: the news, who it was for, what you said, and whether the relationship held. Answer slot: if any month's numbers were bad news, say what you said and how it landed; if none were, say so plainly and stay with the monthly presentation, or say how you would handle it | The studio head is the most senior audience your material names (F7); VAL because it scores whether the hard truth landed |

### C. Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our titles are heading to a season-pass model, and you have never worked on a game with in-app purchases. What do you do about that in your first month?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | **Highest-ROI prep in this pack.** Limit first: your material says nothing about the purchase side, so anything you say about it is a plan, not a past. Say the concession first: "I haven't worked on a game with in-app purchases." Then hold what the quotes carry, no more: "I ran the weekly content-drop calendar for our main title for the last two years, and I wrote the release checklist our QA team still uses." Then the plan, future tense only: the first two things you would ask about how event plans and the game's purchases relate, and who you would ask. The list is yours; the pack does not supply it. Follow-ups to rehearse: (1) why take the risk, by returning to the two quoted sentences and adding nothing; (2) how you would know an event helped or hurt a purchase offer, by saying plainly you do not know yet and how you would find out; (3) six weeks in and you still cannot read the numbers, by saying who you would ask and by when | The loop's first-hand risk for this candidate: F9 is a stated gap, and Larkspur makes the purchase side visible. JD because it scores whether the candidate can do the listed job; deepest rehearsal because it is the one question nearly certain to arrive |
| C2 | "You have said you have not led a team. This role coordinates design, art, engineering and community on each update. How do you get four disciplines moving on a date?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Concede plainly: "I haven't led a team." Then the role as written says coordinate, not lead (F3). Answer slot: if you got work from other disciplines moving on the weekly calendar, say how and what part was yours, in your own words; if the calendar did not involve that, say so plainly and stay with the calendar. Then a plan, in future tense: how you would run the first update | F3's gap and your stated negative; the JD line says coordinate. JD because it scores the listed responsibility |
| C3 | "The role runs events for two titles. Tell me how the calendar you ran would change at two." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the sentence: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you ever ran anything beyond the weekly drops, or a calendar for another title, say what; if you did not, say so plainly and stay with the weekly calendar. Then what you would want to know first about the two titles, said as a plan | F1 is where the JD's two titles and live events press hardest. JD because it scores the listed responsibility; the Larkspur shared calendar makes it likelier |
| C4 | "The posting asks for 3+ years producing live-service games. Which of your four years count?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years" | Say what your quotes say: four years as an associate producer at a puzzle-game studio, two of them on the weekly content-drop calendar for the main title. Answer slot: if you can say which years were on a game updated on a live basis, say which and from when; if only the last two were, or you cannot say, say so plainly. Do not label the years yourself. Let the interviewer decide what counts | F6 is a discovery row, and the JD's years are a requirement the posting states. JD because it scores a listed qualification |

### D. Pressure (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds. Why should we hire you over someone who has run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" "Wrote the release checklist our QA team still uses" "Never led a team, and never worked on a game with in-app purchases" | Pause and restate the question. Hold what the quotes carry: the weekly calendar for the main title for two years, and the checklist QA still uses. Concede once, plainly: "I haven't worked on a game with in-app purchases." Do not say what those things prove, and do not claim to be better at anything; let them draw the inference. Hold through two follow-ups by returning to the two quoted sentences | F1, F5 and F9 together are the case for and against you. JD content, Pressure delivery; hold-then-concede is the bar |
| D2 | "You presented the monthly retention numbers. How much of that was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold: "I presented the monthly retention numbers to the studio head." Answer slot: if you prepared the numbers, or chose what to show, say which and how, in your own words; if they came from someone else, say so plainly and stay with presenting them | F4's thin bridge, asked as an attribution probe. EXP because it scores what was actually the candidate's |
| D3 | "Stop. You have given me three actions. Which one is first, and what do you do if it fails?" | CASE | [generic] | Pick one, say why it is first, say what you will see if it worked, and name the fallback. Do not add a fourth. Makes no claim about your past | The tabletop under interruption. CASE because it scores reasoning, `[generic]` because it is a pattern |

### E. Data-Driven Prober (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how those monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The sentence gives you the monthly presentation and its audience. Answer slot: how the numbers were counted, what they are sensitive to, which assumption behind them you would defend least, and which part was yours, each in your own words; if you do not know how something was counted, say so plainly | F7's figure raises exactly these four slots and no more. EXP because it scores whether the claim survives a second question |
| E2 | "Walk me through the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Tell it in your own words: what you wrote, who uses it. Answer slot: what changed in how QA worked once they used it; if you do not know, say so plainly. Answer slot: the JD says manage the checklist with QA, so expect a probe on who keeps it current; if you and QA did, say how; if QA or someone else did, or it was not revised, say so plainly and stay with having written it | F5 is the likeliest place to be probed, and I2 makes it likelier. EXP because it scores what was actually yours |
| E3 | "Walk me through one week's content drop, from plan to live." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | The sentence gives you the weekly calendar for the main title. Answer slot: which teams and steps a drop involved and which were yours, in your own words; if a step belonged to someone else, say so plainly and stay with the calendar | F2 and F3 meet here: the JD's four disciplines raise the probe. EXP because it scores what was actually yours |

### F. Conversational (weight lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years" "Wrote the release checklist our QA team still uses" "Presented the monthly retention numbers to the studio head" | A 90-second arc with the beats the four sentences state, in order: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for two years; the checklist QA still uses; the monthly retention numbers for the studio head. End on why Saltmarsh, in your own words (F2). Use your title as you wrote it; do not promote it | The opener is scored even when it sounds casual. EXP because it scores whether the arc matches the record |
| F2 | "Why Saltmarsh, and why live operations here?" | CO | [grounded] | Three pieces, all yours: one tied to a published value you actually hold (name it), one tied to what the Larkspur announcement says about the shared events calendar (read the page first), and the personal reason, in your own words. Makes no claim about your past beyond what you say yourself | Homework you can show: the values page and the news. CO because it scores whether you can talk at the company's altitude |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two titles | C3, A5, E3 |
| Coordinate design, art, engineering and community on each update | C2, E3, A1 |
| Own the post-event review and the KPIs it reports | A4, D2, E1 |
| Manage the release checklist with QA | E2, A3, B3 |
| 3+ years producing live-service games or apps | C4, F1 |
| Experience running a content calendar | E3, B1, F1 |
| Comfortable with player-retention metrics | E1, D2 |
| Clear written communication | A2, B3 |

## Values cheat sheet

A values-style round is detected: the loop source names a values conversation.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | If the schedule and the players disagree, change the schedule | B1 on F2: "I ran the weekly content-drop calendar for our main title for the last two years". No quote carries a conflict, so use the answer slot in B1 |
| Ship the Patch Not the Promise | Announce what has been built, not what is hoped | B2 on F7: "Presented the monthly retention numbers to the studio head". No quote carries a case of saying less than hoped; use the selection scaffold in B2, ending in its honest branch |
| Leave the Build Greener | Each release should leave the code and the checklist in better shape | B3 on F5: "Wrote the release checklist our QA team still uses" |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You were a QA lead before this role. What did the release side teach you that you would want a new producer to learn early?" | Tied to his own path (I2). It turns a probe on your checklist into a conversation | [grounded] |
| R2 | "Your talk argues that patch notes are a promise. How does the team check that what is announced matches what shipped?" | Shows you read the topic he chose (I3); it asks for process, not praise. Say so only if you have read more than the listing | [grounded] |
| R3 | "With Larkspur retiring per-title event teams for one live-ops group, how will producers be organized, and what would a first quarter on the shared calendar look like?" | Shows homework on current strategy and asks about your own first quarter | [grounded] |
| R4 | "How do event plans and the season-pass plans get reconciled day to day, and who has the final say?" | Turns your stated gap (F9) into a learning question rather than a hidden one | [inferred] |
| R5 | "What does a good post-event review look like here, and which numbers does the team trust most?" | Maps to the JD's review and KPI line (F4) and lets you hear what they measure | [generic] |
| R6 | "What would make you say, six months in, that this hire worked?" | Gives you a target to carry back into your follow-up | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated: "Never led a team, and never worked on a game with in-app purchases" | The plain acknowledgment: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases, or on its offers or purchase-side events | Negative you stated, same sentence | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, in future tense |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for the main title. C3's slot stays inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of F4 | F4's quote at its own scope: you presented the monthly retention numbers. D2's slot asks only which part was yours |
| Managed the release checklist with QA | Inflated form of F5 | F5's quote at its own scope: you wrote it and QA still uses it. E2's slot asks only who keeps it current |
| Coordinated design, art, engineering and community on every update | Inflated form of F3 | F3's quote at its own scope. E3's slot asks only which teams a drop involved and which steps were yours |
| Has 3+ years producing live-service games | Inflated form of F6 | F6's quotes at their own scope: four years as an associate producer, two on the weekly calendar. C4's slot asks only which years were updated on a live basis |

## Sources

**Provided:** the job description and your background, both in your message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches:

1. `Saltmarsh Games values` — returned saltmarshgames.com/values
2. `Saltmarsh Games interview process live operations producer` — returned saltmarshgames.com/careers/interviewing
3. `Saltmarsh Games mobile studio strategy news` — returned saltmarshgames.com/news/project-larkspur (search snippet only; the page was not fetched)
4. `Tobias Wrenfield Saltmarsh Games` — returned talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; the page was not fetched)

Fetches: saltmarshgames.com/values and saltmarshgames.com/careers/interviewing.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Values cheat sheet; the three values by official name; B1 to B3 |
| 2. `{company} interview process {role family}` | yes | The loop (tabletop, then values conversation); persona weights; bank A and bank B |
| 3. `{company} strategy` / recent news | yes | A5, F2, R3, R4 and the C1 premise. Read as a search snippet only |
| 4. `{interviewer name} {company}` | yes | The interviewer read (I1 to I3) and R1, R2. Read as a search snippet only |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias is your hiring manager, or any note from your recruiter on the Outage Hour (topics, whether the scenario is shared in advance) → persona weights and bank A firm up, and bank D may change
- Answers to the answer slots in F1, F3, F4, F6 and F7 (for example, which years were on a live game, which part of the monthly numbers were yours) → those rows move from a slot to your own quoted words, and the matching bank guidance gets concrete
- The release checklist you wrote (redacted), or a monthly retention deck → F5 and F7 move from medium to high, because an inspectable artifact is what raises the band in this field
- Something written for players, such as a drop announcement or a patch note, or a write-up of a release → F8 moves from a worded bridge to a real sample
- The GDC talk itself or its transcript → a deeper interviewer read than the listing alone gives (I3), and sharper R2
- The Project Larkspur page itself (only a search snippet was read) → confirms the A5 and C1 premises and R3 and R4
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on strategy and recent organization changes, and sharper CO questions
- A `tuesday-dossier.md` from the job-underwriter skill, if you have one → verified evidence per row and a named objection list, so the highest-ROI prep is evidence-derived rather than inferred
