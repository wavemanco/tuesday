I'll read the reference files the skill requires before building the pack.
I've read the skill's rules and I'm now running the research: Stripe's values, its interview process for this role, recent strategy, and a representative Product Operations Manager JD.
Web search was refused, so I'm not going to retry it. I'll build the pack from your request alone and label everything Stripe-specific as unresearched, not fill it in from memory.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-3-denied-2fb86efe/stripe_product-operations-manager_interview_pack.md`.

I built it from your request alone. I assumed an unknown round type and relationship, so the persona weights are blended, and I had no CV or job description, so the fit snapshot is a worksheet and every question is generic. The four web searches I tried (Stripe's values, its interview process, recent strategy, a sample job description) were refused. The pack therefore holds no Stripe-specific facts, and the Sources section records that.

The pack has 22 questions across seven interviewer styles. The "weakest on day one" pair, B1 and B3, is the prep I'd start with, because every candidate is asked it and your CV would let me sharpen it.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposes, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is your final round with, and did the recruiter name any focus areas or ask you to prepare something? The answer reweights every bank.
Can you paste the job description and your CV, or tell me to proceed without them? Either one turns the worksheet rows into rows quoted from your own material.
Are you able to meet the role's location and work-authorization terms? The pack surfaces this as a gate it can't resolve from what you've given me.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack — Product Operations Manager, Stripe

- Role: Product Operations Manager
- Company: Stripe
- Round: final round; the number of sessions and who runs each are not known
- Interviewer: not named; relationship to you not known
- Built from: your request only (no CV, no JD, no recruiter guidance, no web research). The pack is a worksheet and a rehearsal bank, not a tailored answer set. Every question is labeled `[generic]` and every Stripe-specific fact is absent, because none could be sourced.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: the stories have to be yours, in your own words, and nothing in this pack supplies one.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually you |
| JD | Role-driven: can you do the listed job, including its gaps |
| CO | Company and strategy knowledge: homework depth and altitude |
| CASE | A live problem set in the role: structure and reasoning |

The highest-ROI prep in this pack is B1 and B3, the "weakest on day one" pair. Every candidate is asked some version of it. Without your CV the pack cannot name the objection that is specific to you, so rehearse these two until the answer is boring, and see the upgrade menu for what would sharpen it.

## Fit snapshot (worksheet)

No CV, JD or recruiter words were supplied, so this is the worksheet variant: every evidence cell reads `none given`. The requirements are role-family patterns, written as plain prose and labeled `[generic]`. They are not quotes from a Stripe posting. Each row says what strong evidence looks like and gives a selection scaffold to fill from your own history.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or releases across product, engineering and go-to-market teams — role-family pattern, no JD supplied | none given | none | [generic] | discovery | Strong evidence is a named launch, your specific part in it, and who you worked across. Selection scaffold: pick a time you kept several teams moving to one date; it needs a named stake, your own part stated precisely, and an outcome you can describe. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Run operating cadences such as planning, reviews and status reporting — role-family pattern, no JD supplied | none given | none | [generic] | discovery | Strong evidence is a recurring forum you set up or ran, who attended, and what it changed. Selection scaffold: pick a recurring meeting or report you owned or improved, and be ready to say what was yours and what was inherited. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Define and track product or launch metrics and use them to find problems — role-family pattern, no JD supplied | none given | none | [generic] | discovery | Strong evidence is one figure you can defend end to end: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Selection scaffold: pick the one number you know best. If no such number comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Improve or build processes and tools that scale across teams — role-family pattern, no JD supplied | none given | none | [generic] | discovery | Strong evidence is a process you changed, what it replaced, and who used it afterwards. Selection scaffold: pick a process change where you can separate what you designed from what you only rolled out. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence senior stakeholders and peers without formal authority — role-family pattern, no JD supplied | none given | none | [generic] | discovery | Strong evidence is a disagreement with someone senior or a peer team, what you did, and the state of the relationship afterwards. Selection scaffold: pick one where you held a position and the relationship survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | The role's location and work-authorization terms — role-family pattern, no JD supplied | none given | none | [generic] | hard_gate | Your material does not establish whether you meet these terms. This row is surfaced and not bridged: no wording changes it, and the pack asks nothing here. The one question that applies, whether you meet them, is in the message that delivered this pack |

## Persona table

No loop source was read, and "final round" alone does not say how many sessions there are or who runs them. The weights below therefore rest on the generic archetype (screen, hiring manager, panel, flat weights), not on Stripe's documented process. They blend the priors for a hiring manager, a cross-functional interviewer and a peer, because the relationship is unknown.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems set in the role: launches, metrics, cadences | High. A hiring manager is the prior for a final round, and that relationship leans on live problems. Questions A1 to A5 | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully per case |
| B. Skeptic | Quiet probing of gaps, motivation and ramp | High. The same hiring-manager prior, and a gap probe is asked of every candidate. B1 to B4 | Rehearse the weakest-on-day-one answer until it is boring. Use only adjacent evidence you can state, say the limit plainly, and bring a concrete ramp plan |
| C. Values / Behavioral | Scenario probes, often from outside the function | Medium. A cross-functional session is plausible in a final round, but no source says Stripe runs one. C1 to C3 | Pick a story where the hard truth actually landed. Use "we" for context and "I" for your contribution |
| D. Peer Evaluator | Seam-splitting, "what would you need from me", credit | Medium. A peer may sit on a final-round loop. D1 to D3 | Reciprocity: say what you bring their team. Propose seam principles and do not pretend to know the seam |
| E. Data-Driven Prober | Inputs, denominators, assumptions behind figures | Medium. Metrics are a standard topic for this role family, and probers follow whatever number you give. E1 to E3 | Know how each of your numbers was counted, say plainly when you do not know, and name the assumption you would defend least before they do |
| F. Pressure | Time-boxed answers, interruptions, "how much was you" | Low. It shows up as a style within other sessions more than as a session. F1, F2 | Pause, restate, hold the position through two follow-ups, then concede specifically and never on the core claim |
| G. Conversational | Friendly, unstructured, still scored | Low to medium. Openers are near-certain. G1, G2 | A 90-second arc for the biography question. Treat casual questions as scored |

## Question banks

No claim about your past appears in any guidance cell, because nothing was supplied to quote. Where a question asks you to choose a story, the guidance is a selection scaffold ending in its honest branch.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A cross-functional launch is two weeks out and engineering, sales and support each report a different readiness status. What do you do first?" | CASE | [generic] | Clarify before structuring: what "ready" means to each team, who owns the go or no-go, and the cost of a slip. State the objective, then segment by team and by risk. Name the metric that would settle the argument, and the risk that your approach hides a real problem. Challenge one premise aloud, for example whether the statuses disagree because the definitions differ | A launch-coordination problem is the role family's core situation (F1). CASE because it asks for structure on a live problem and nothing about your past |
| A2 | "A metric the product team reviews every week drops 20%. Diagnose it." | CASE | [generic] | Check definition and instrumentation first, then segment, then recent changes, then ranked hypotheses with the cheapest test for each. Say which hypothesis you would be least surprised by and why. Close with what you would tell the team today versus after more data | Tests the metrics requirement (F3) in a live form. CASE because the diagnosis structure is what is scored |
| A3 | "Design the operating cadence for a product organization of several teams that ship every week. What is in it and what is deliberately left out?" | CASE | [generic] | Start from the decisions the cadence has to support, then forums, owners and inputs. Make the concession explicit: every added forum costs team time, so say what you would cut first and what would make you add one back | Covers cadences and scalable process (F2, F4). CASE because the scoring is on design reasoning and the trade-off you name |
| A4 | "Four teams each ask your team for launch support this quarter and you can serve two. How do you decide?" | CASE | [generic] | State the prioritization rule before applying it, and name what it cannot see. Say what information you would ask for first, how you would tell the two teams you turned down, and what would make you revisit the call mid-quarter | Prioritization is a standard hiring-manager probe for this role family (F1, F4). CASE because there is no past claim, only reasoning |
| A5 | "What do you understand a product operations function to do at a company like Stripe, and where would it not belong?" | CO | [generic] | This pack could not research Stripe, so it supplies no facts about the company. Before the interview, read Stripe's own pages and prepare only what you have verified. In the answer, give your definition of the function, then one concrete boundary, such as a decision that belongs to product management and not to operations. Do not quote figures from memory | Tests company altitude. CO because it asks for company-level understanding. It stays generic until the upgrade menu's research item is done |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Highest-ROI prep. Choose the real answer from F1 to F5, not a disguised strength. Say the limit plainly in one sentence, name the nearest thing your own material carries, and give a concrete first-30-days step to close it. Hold through two follow-ups by returning to what you can state, and never by adding to it | The question is asked of every candidate and is aimed at wherever the material is thinnest, which the F rows cannot yet show. JD because it scores fit against the role's requirements |
| B2 | "Why product operations, why Stripe, and why now?" | EXP | [generic] | Three short beats: what pulled you toward the function, what about the company you have verified yourself, and why this timing. Use only reasons you actually hold. If one beat has no real answer, say so plainly and give the beats you do have | Motivation consistency is what a skeptic scores. EXP because the answer has to be consistent with your own history |
| B3 | "Name the one requirement of this role your background shows least, and tell me how you would close it." | JD | [generic] | Pair with B1 and rehearse them together. Choose from F1 to F5 honestly. State the limit, then a ramp plan with a first concrete step. Do not claim adjacent work you cannot describe in detail | Same objection as B1 in a second form, so a rehearsed answer survives rewording. JD because it scores a requirement gap |
| B4 | "Walk me through your first 30, 60 and 90 days." | JD | [generic] | Structure by what you would learn, who you would meet, and what you would decide not to change yet. Ask what you would need to be true for the plan to work. Keep it a plan, said as future, and never as something you have done | A ramp plan is the standard answer to a skeptic's gap probe. JD because it scores whether you can do the listed job |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you did not soften it, and a relationship intact afterwards. Use "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard behavioral probe for influence without authority (F5). VAL because it asks for past behavior. Stripe's published values were not read, so it cannot yet be tied to one by name |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a real tension between the two, a decision that was yours, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values probe. VAL because it asks for a decision under conflict |
| C3 | "A customer-facing team asks you to hold a launch you believe is ready. What do you do?" | VAL | [generic] | A live problem, so no claim about your past is needed. Ask what the team has seen that you have not, separate the evidence from the worry, and say what would change your mind. Say how you would record the decision either way | Tests judgment under cross-team pressure (F1, F5). VAL because it reveals values in action, with CASE delivery |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Do not pretend to know the seam. Propose principles for drawing it, such as who owns the decision and who owns the follow-through, and say how you would handle a disagreement with an equal. Ask how they see it today | Peer evaluators price how the hire affects their own work (F1, F5). JD because it scores the role's boundaries |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Describe your approach in one or two sentences, then a short example only if you have a real one where you can say exactly what was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A credit-sharing probe is a peer staple (F5). VAL because it shows collaboration values |
| D3 | "What would you need from me in your first month, and what could you give my team?" | JD | [generic] | Reciprocity: lead with what you bring the peer's team, then name the one or two things you would need. Keep both concrete and in the future tense | Tests partnership fit and whether you add to or reduce the peer's load. JD because it scores how you would work in the role |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which metrics would you use to judge whether product operations is working, and which assumption behind them would you defend least?" | JD | [generic] | Pick two or three measures, say what each cannot tell you, and name the weakest assumption yourself before they do. Distinguish measures of activity from measures of effect | Metrics requirement (F3). JD because it scores the stated responsibility, with the weakest-assumption move built in |
| E2 | "How would you define and count launch readiness so two teams cannot argue about the number?" | CASE | [generic] | Clarify what decision the number supports, define each component, say who owns the data, and name where the count could be gamed or go stale. Say what you would do when the number and the teams' judgment disagree | Probers go two levels deep on any definition (F3). CASE because it asks for a live design |
| E3 | "Pick the number from your own work you are proudest of. How was it counted, and which assumption behind it would you defend least?" | EXP | [generic] | Defend-the-number slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Never explain a method you did not use | Every headline figure is a probe target (F3). EXP because it tests whether your claim survives scrutiny |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate the question. Give two reasons you can back from your own record, and say plainly what an internal candidate may know that you do not. Hold the position through the follow-up, then concede the specific point and not the core | Tests composure, not content. JD because it scores fit to the role |
| F2 | "Pick the result you are proudest of. How much of it was actually you?" | EXP | [generic] | Hold-then-concede. State your part precisely and in the first person, name who else contributed, and hold it through two follow-ups. Concede specifically if asked about a part that was not yours, and do not enlarge your role to recover | Attribution probes are where inflated stories fail (F3, F5). EXP because it tests what was actually yours |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, two or three turns in order, and why this role is the next one. Every turn comes from your own history and nothing is added to make it land. Rehearse it aloud with a timer | The biography opener is near-certain. EXP because it is your history told as one story |
| G2 | "What have you been following about Stripe lately that you found interesting?" | CO | [generic] | Name one thing you have read yourself and say why it interested you, in two sentences. This pack could not research Stripe, so do that reading before the interview. Say only what you have verified | A casual question about the company is still scored, and a vague answer reads as thin homework. CO because it tests current company knowledge |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch coordination | A1, A4, C3, D1, D3 |
| F2 Operating cadences | A3, B4 |
| F3 Metrics | A2, E1, E2, E3, F2 |
| F4 Process and tools at scale | A3, A4 |
| F5 Influence without authority | C1, C2, C3, D1, D2 |
| F6 Location and work authorization | none, and why: it is a term you meet or do not, so wording cannot help and no question rehearses it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a strong first 90 days look like in this role, and what would tell you at 30 days that it was going off track?" | It shows you think in ramp plans and gives you the interviewer's own success criteria |
| 2 | "Which decisions does this role own outright, and which does it only influence?" | It puts the seam on the table early, so you can aim your later answers at it |
| 3 | "How does the team know product operations is working?" | It connects to the metrics probe (E1) and shows you think about effect and not activity |
| 4 | "What is the hardest cross-team seam this role will sit on right now?" | It invites a specific answer, which also tells you what you are walking into |
| 5 | "What separates the people who do well in this role from the people who struggle?" | It asks for the real bar, which you can address in your close |
| 6 | "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question, strongest if the interviewer turns out to be a peer |
| 7 | "Is there anything about my background you would like me to address before we finish?" | It gives the interviewer room to voice a doubt while you can still answer it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| none | No candidate material was supplied, so there is no quoted sentence to inflate and no stated negative to protect | Once a CV or your own account is supplied, this list is rebuilt from it before any story is mapped |

## Sources

Provided documents: none. The only input was the request to prepare for a final-round Product Operations Manager interview at Stripe. No `tuesday-dossier.md` was present.

Searches sent, all refused by the host, so nothing returned:

- "Stripe operating principles values" — refused
- "Stripe interview process Product Operations Manager final round" — refused
- "Stripe strategy news 2026" — refused
- "Stripe Product Operations Manager job description" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have fed a values cheat sheet and values-themed VAL questions. Neither is in this pack |
| 2. Stripe interview process, product operations | unavailable | Would have fixed the loop structure and persona weights. The weights rest on the generic archetype instead |
| 3. Stripe strategy and recent news | unavailable | Would have grounded CO and CASE questions in current priorities. A5 and G2 stay generic |
| 4. Interviewer name and Stripe | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have made the requirement rows `[inferred]` quotes from a real posting. They are `[generic]` prose instead |

## Upgrade menu

- Your CV, or your own account of your background → the F1 to F5 rows move from `none given` to quoted evidence, story-mapped guidance replaces the selection scaffolds, the pack names your real highest-ROI objection, and a prohibited-claims list is built from it
- The job description text → the requirement rows become quoted `[grounded]` lines, and every JD-tagged question is checked against the posting's own list
- Who the round is with, and whether it is one session or several, with the schedule if you have it → persona weights are recomputed from the real relationship, and per-session mini-packs become possible
- The recruiter's prep note, including any focus areas or a pre-declared deliverable → a build section for any graded deliverable, and coverage that is no longer assumed
- The interviewer's name → an interviewer read from their public professional footprint and a reverse question tied to their own path
- Permission for web search, with a deeper research pass offered once (up to 6 more searches and 2 more fetches, several more minutes) → Stripe's published values and a values cheat sheet, documented loop structure, a current strategy brief for CO and CASE questions, and a representative posting
- Whether you meet the role's location and work-authorization terms → F6 either closes or stays a surfaced risk
- A `tuesday-dossier.md` from the job-underwriter, if you have run it → verified evidence and the objection worth the deepest rehearsal arrive pre-sorted
