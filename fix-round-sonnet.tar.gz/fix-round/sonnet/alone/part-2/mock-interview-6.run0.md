I'll read the reference files before building the pack.
I've written the pack file and I'm running a quick format check on it before I present it.
Your prep pack is saved as `larkfield-systems_engineering-manager_interview_pack.md`. It's a loop-mode pack: one shared fit snapshot, then a mini-pack for each of the three rounds, each with its own persona weights, nine questions and reverse questions. I didn't get to run my final formatting check on the file because the command needed approval.

The web searches were refused in this session, so none of the company research ran. As a result the pack has no values cheat sheet, no company-strategy question and no interviewer read. The persona weights rest on your own description of the rounds.

The prep that pays off most is the question about your lack of hardware-adjacent roadmap ownership (B1). I expect it in some form in all three rounds. Your "never managed managers" gap (B2, E3) is next, and the pack gives plain acknowledgments for both. The 60% on-call figure and the "about 40 interviews" figure each get a defend-the-number question (D1, D2), and the pack doesn't explain how either was counted.

Say the word and I'll play the Skeptic on B1 for Tuesday's round.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two things would change the pack:
- Can you paste the full job description and your CV, or tell me to go without them? Either would turn the rows built on your one-line description into quoted requirements and add evidence to the fit snapshot.
- Can you paste Larkfield's published values page, or allow web search? That would add a values cheat sheet for Monday's VP round.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (loop of three rounds)

Candidate: Yusuf. Mode: loop, three scheduled rounds.

| Round | When | Who | Relationship | Length |
|---|---|---|---|---|
| Round 1 | Tuesday | Director of Engineering | Hiring manager, your would-be boss | 45 min |
| Round 2 | The Thursday after | Two staff engineers and a product manager | Panel | 60 min |
| Round 3 | The following Monday | VP Engineering | Skip-level, described by the recruiter as "values and leadership philosophy" | 30 min |

Built on this assumption: the only role text supplied is your one-line description, not a full JD, and you gave no CV, so the fit snapshot quotes your message and nothing else. No names are known, so there is no interviewer read. Larkfield's published values and loop were not researched (see Sources), so there is no values cheat sheet and no company-strategy question.

## How to use this pack

- Personas describe how a question arrives; types describe what is being scored. Rehearse both: the same question lands differently from a friendly aside and from a time-boxed challenge.
- Guidance is scaffolding, not a script. Say it in your own words, and only what you actually did.
- An answer slot is an instruction for the interview, not a question for you now. Each has two honest branches: say how it went, or say plainly there was no such step or it was not yours, then return to what your own sentences carry. The second branch is never a confession.
- IDs run by persona letter: A Case/Strategist, B Skeptic, C Peer Evaluator, D Data-Driven Prober, E Values/Behavioral, G Conversational, P Pressure.

Type key:

| Tag | What it scores |
|---|---|
| VAL | Whether past behavior shows how you lead and what you value |
| EXP | Whether your own claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none written: company research was unavailable) |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

Two weeks, three rounds. In order:

1. Before Tuesday: B1 until it is boring. It is the highest-ROI prep in the pack, because the hardware gap is yours to name first and will be asked in some form in every round. Then B2, A3, A4.
2. Before Tuesday: say A1 and A2 out loud twice each, thinking aloud.
3. Between Tuesday and Thursday: D1 and D2 (your two figures), then C1 and C2.
4. Before Monday: E2, E3, P1, P2. Thirty minutes holds only a few questions, so these five matter most.

Everything else is insurance.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from your description of the role, or from the recruiter's words as you reported them. Evidence is your own sentences only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | Words at the quote's scope: "Three of my nine years in engineering have been as a team lead of six." Plain acknowledgment, from your own sentence: "I've never managed managers." The pack's observation: the role description says two squads and 11 engineers, and does not say whether leads sit between you and the engineers. Answer slot: the two squads make a probe likely on how that differs from a team of six. If any part of your lead work crossed more than one group, say what; if none did, say so plainly and stay with the team of six |
| F2 | "building device-management services" — role description, your message | none given | none | [grounded] | discovery | Your material does not show whether anything you have built touches this domain. Answer slot: if any service you worked on managed or updated remote clients or devices, say which and what part was yours; if none did, say so plainly and say what you would read first |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence carries a reliability push against roadmap pressure, and says "after", not "because". It does not say who owned delivery dates. Answer slot: the delivery line makes a probe likely on dates and commitments. If dates or commitments were yours, say how you handled them; if they were not, or there were none, say so plainly and stay with the quarter. The 60% raises the figure slots: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description, your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap on the loop, but a line with nothing inspected behind it, so expect a probe. Lead with the sentence's own terms: you run the loop, for backend roles, about 40 interviews last year. The pack's observation: the sentence says the loop, not headcount or offers, and not hiring for these squads |
| F5 | "own delivery, hiring and growth for 11 engineers" — role description, your message | none given | none | [grounded] | discovery | Your material does not show whether you have grown anyone. Answer slot: if you helped an engineer grow, say what you did and what changed, without names; if you did not, or it was not yours, say so plainly and say what you would do |
| F6 | "partner with hardware and product on roadmap" — role description, your message | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The pack's observation: your sentence is about owning, and the role says partner |
| F7 | "partner with hardware and product on roadmap" — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The sentence mentions roadmap pressure and not who applied it. Answer slot: if the pressure came from product, say how you worked it through; if it came from elsewhere, or there was no one to work it through with, say so plainly and stay with the quarter |
| F8 | "values and leadership philosophy" — the recruiter's description of Round 3, via your message | none given | none | [grounded] | discovery | Strong evidence here is a named decision where you held a position on how a team should work and the relationship was intact afterwards. Selection scaffold: pick one time you did that; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

No requirement in your description is a gate (authorization, location, travel, schedule, pay), so none is graded `hard_gate`.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Lead two squads | A2, B2, E3 |
| F2 Device-management services | G2, D3 |
| F3 Own delivery | A1, A4, D1, P2 |
| F4 Hiring | A3, D2, A8 |
| F5 Growth for 11 engineers | E1, A2, A8 |
| F6 Hardware partnership | B1, A5, P1 |
| F7 Product partnership | C1, C2, A6 |
| F8 Values and leadership philosophy | E1, E2, E3, E4, C4, P1, P2, P3 |

---

# Round 1: Director of Engineering, Tuesday, 45 minutes

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (4 questions) | Live problems from the two squads and the hardware roadmap | High. The hiring-manager prior is Case/Strategist plus Skeptic, and your role description supplies the scenario material (two squads, hardware, product) | Clarify, objective, options, decision, risks, aloud. Challenge one premise politely per case. A1 and A2 |
| Skeptic (3 questions) | Quiet probing of the two gaps you named, and why this move now | High. Same prior, and the Director is buying capability and de-risking F1 and F6, both stated by you | Rehearse B1 until boring. Concede the stated gaps first, then the plan. Never bluff a competency |
| Conversational (2 questions) | The "walk me through your journey" opener and a casual domain question | Low to medium. Not in the hiring-manager prior; kept because casual openers are still scored and you should not meet the style first live | A 90-second arc, built only from your own sentences. G1 |

Loop basis: the rounds, who runs them and their lengths are your own words, which establish the loop; no archetype fallback was used.

## Bank: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Hardware asks for work that would pull both squads for a quarter, and product has already committed dates. How do you decide, and what do you need to know first?" | CASE | [generic] | Clarify before structuring: what on the hardware side is fixed and what is movable, what product has committed and to whom, what each squad is mid-way through. Then objective, options (sequence, split, reduce scope, ask hardware for a smaller slice), who must agree to the decision, how you tell both partners and your engineers, what you would watch, what you would do if the call proves wrong. Challenge one premise respectfully, for example whether the quarter really needs both squads. The question needs no claim about your past, so the guidance makes none | F6 and F7 are the requirement this scenario scores. CASE because it is a live problem on the role; generic because it is a pattern for the problem, not a fact about this team |
| A2 | "Walk me through your first sixty days with two squads, eleven engineers, and a roadmap you did not write." | CASE | [generic] | Structure by sequence: listen first (one-to-ones with every engineer, then each squad lead or senior engineer if there are any), learn the services and how they fail, meet the hardware and product counterparts, decide what you will not change early, and agree with your Director what good looks like at sixty days. Say what you would ask, not what you already know. No claim about your past | F1 and F5 are the requirement it scores; the eleven engineers and two squads are the role description's own. CASE because it is a plan built live |
| A3 | "You would own hiring for these squads. Tell me how you run a hiring loop." | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Open in the sentence's own terms: you run the hiring loop for backend roles, about 40 interviews last year. Answer slot: expect a probe on how that number was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, in your own words; if you do not know how it was counted, say so plainly. Answer slot: if you set the loop's stages, say how you decided; if the loop was set elsewhere and you ran it, or there was no such design step, say so plainly and describe how you ran it. Then, as a plan only, what you would keep and change for these squads | F4 is the evidence and a clean row, so the probe goes to the number and to what the sentence does not say. JD because it scores the stated hiring responsibility |
| A4 | "You would own delivery and hardware dates will move. Tell me about a time you protected a team's plan under pressure." | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F3, with only the beats the sentence states: you pushed a reliability quarter through, against roadmap pressure, and the team's on-call burden dropped 60% after. Tell it in your own words, with "after", not "because". Answer slot: if the pressure came from product or hardware, say which and how you responded; if it came from elsewhere, or there was nothing to respond to, say so plainly and stay with the quarter. Answer slot: if asked about the 60%, say how it was counted if you know; if you do not, say so plainly | F3 and F7 are the nearest evidence for the delivery requirement, and its limit is the pack's observation, not words for you. JD because it scores a stated responsibility; the open prompt's theme comes from the role description's delivery line |

## Bank: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never owned a hardware-adjacent roadmap, and this role partners with hardware on ours. Why should I be comfortable?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Hold only what the sentence carries and open with the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." The role says partner, not own, so then say what you would do first, in the future tense: which conversations with hardware counterparts you would ask for and what you would ask them. Answer slot: the partnering line makes a probe likely on whether you have worked beside hardware-facing teams in any form; if you have, say what and what part was yours; if you have not, or it was not yours, say so plainly and stay with the plan. Hold through two follow-ups by returning to the acknowledgment and the plan, never by adding to your past. Concede any specific you cannot answer: "I don't know that yet, and here is how I would find out" | F6 is a gap you stated, so this objection is certain in some form and arrives again in Rounds 2 and 3. JD because it scores the stated partnering responsibility |
| B2 | "You have never managed managers. What do you expect to find hardest about two squads?" | JD | [grounded] "I've never managed managers"; "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Acknowledge first: "I've never managed managers." Then at the quote's scope: "Three of my nine years in engineering have been as a team lead of six." The role description does not say whether leads sit between you and the engineers, so the first reverse question below asks. Then what you would want to learn in the first month, as a plan. Answer slot: the two squads and eleven engineers make a probe likely on how that differs from a team of six; if any of your lead work crossed more than one group, say what; if none did, say so plainly and stay with the team of six | F1 is the evidence and its limit is the pack's observation. JD because it scores the stated lead responsibility |
| B3 | "Why leave a payments company for industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Selection scaffold, not a script: your actual reasons, in your own words. Name one thing in the role description's own lines that draws you (device-management services, partnering with hardware and product, leading two squads) and say whether you are moving toward it or away from something. Do not describe Larkfield beyond the role description, since its mission and strategy were not researched. If no honest reason beyond the role itself comes to mind, say so plainly | F1 and F2 are where a motivation probe will aim. JD because it scores fit with the stated role; the skeptic stem is "why leave, why here, why now" |

## Bank: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with three beats, each one the sentence states: nine years in engineering, three of them as a team lead of six, and now at a payments company. Tell them in your own words. Close on why this role, in a sentence of your own drawn from the role description's lines. Any further beat, such as why you moved into leading, is yours to add only if you did it; leave it out otherwise | F1 is the whole of the biography evidence. EXP because it tests whether your arc matches what you did; a casual opener is still scored |
| G2 | "What is your experience with device-management services, and what are you still learning?" | JD | [grounded] | Answer slot: if any service you worked on managed or updated remote clients or devices, say which and what part was yours; if none did, say so plainly and say what you would read first and why. The second half of the question is an invitation: name one specific thing you do not know yet. No claim about your past beyond the slot | F2 is a row where your material is silent, and the role description puts the domain in its first line. JD because it scores the stated domain |

## Round 1 reverse questions

| Question to ask | Why it lands |
|---|---|
| "What would success look like for these two squads by the end of my first six months, and how would you and I know?" | It asks for the Director's own scoring bar, which turns the F3 delivery line into something concrete |
| "Do the two squads have leads or senior engineers who carry day-to-day direction, and how do you see my role with them?" | It settles whether F1's stated gap applies, without raising it yourself |
| "Where does the hardware roadmap meet these squads today, and where does it hurt?" | It brings the F6 conversation to a concrete place instead of leaving it as a worry |
| "What has been hardest about this scope so far, for you or for the squads?" | A boss describing the hard part shows what they will want from the first ninety days |
| "Based on what you have seen of my background, is there anything you would want me to address?" | It invites the objection directly, which is easier to answer with B1 and B2 rehearsed |

---

# Round 2: panel, two staff engineers and a product manager, Thursday, 60 minutes

## Persona weights

Assumption, shown so you can correct it: the staff engineers are read as senior technical peers and the product manager as a cross-functional partner on the roadmap. If you know their remits, the weights move.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (4 questions) | Seams between teams, what you need from them, credit and disagreement | High. The panel prior blends each member's top two; both staff engineers and the product manager sit beside the squads, and the role description's partnering line points the same way | Reciprocity framing: what you bring their work. Propose seam principles, not specifics you do not know. C1 to C4 |
| Data-Driven Prober (3 questions) | Your two figures, taken to their assumptions; technical trust | High. The staff engineers' relationship adds Prober, and you gave two figures | Know what you can and cannot say about how each was counted, and say plainly when you do not know. D1 and D2 |
| Case/Strategist (2 questions) | A roadmap collision put to you live, likely from the product manager | Medium. The cross-functional prior would be Values and Conversational, but the role description's roadmap line makes live trade-offs more likely, and Round 3 carries values | Clarify first, then structure, aloud. A5 and A6 |

## Bank: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our services and your squads' roadmap will collide at some point. Where is the seam, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Propose principles, not a seam you do not know: ownership follows who carries the outcome and the pager, the escalation path is agreed before the disagreement, disagreement happens on the record and everyone commits after the decision. Add what you bring their team, as a plan: visible capacity and dates they can plan against. Answer slot: if the roadmap pressure in your reliability quarter came from people you disagreed with, say how it went; if it was not a disagreement, say so plainly and use the principles | F6 and F7 are the requirement; F7's limit is that the sentence does not say who applied the pressure. JD because it scores the stated partnering line |
| C2 | "Product wants a feature this quarter and your engineers say reliability work has to come first. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Clarify first: what the feature is committed to, what the reliability risk is costing now, what splitting would cost each side. Then decision criteria, who decides, how you tell product, and what you would offer them in return. Your sentence touches this tension at its own scope: you pushed a reliability quarter through, against roadmap pressure, and on-call burden dropped 60% after. Answer slot: if the pressure came from product and you worked it through with them, say how; if not, say so plainly and stay with the quarter. Do not say the reliability quarter was right here, since the sentence does not say what it cost the roadmap | F7 is the nearest evidence for this collision. CASE because it is a live trade-off, with the story as the one grounded point of contact |
| C3 | "How do you work with staff engineers? What do you want from us, and what should we expect from you?" | JD | [generic] | Two short columns, each as principles: from them, technical direction on the hardest problems, honest estimates, early warning; from you, protection of their focus time, decisions made and explained, clear priorities. Ask them what they want rather than assuming. Reciprocity beats a speech: end by asking what has frustrated them about managers before. No claim about your past | F1's limit applies: you have never managed managers, so this is a plan, never a track record. JD because it scores the working relationship the role needs |
| C4 | "Tell me about a time you shared credit for work that spanned teams." | VAL | [generic] | Selection scaffold: pick one piece of work with a named other team, say what you did so the credit was visibly shared, and say what the other team said or did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you handle credit in principle | F8's values and leadership theme, delivered by a peer. VAL because it scores behavior; the open prompt's theme is the peer persona's credit-sharing stem |

## Bank: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said on-call burden dropped 60% after the reliability quarter. How was that counted, and what part of it was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the sentence at its own scope: the team's on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. Say "after", not "because". Name, in your own words, the assumption behind the figure you would defend least before they ask. Answer slot: how it was counted; what it is sensitive to; which part was yours. If you do not know how it was counted, say so plainly; that is a credibility gain, not a loss. If most of the work was the team's, say so plainly | F3 holds the figure. EXP because a headline number is a magnet for probes on attribution |
| D2 | "You mentioned about 40 interviews last year. How was that counted, and how many did you conduct yourself?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say what the sentence says: you run the hiring loop for backend roles, about 40 interviews last year. The number is attached to interviews, so keep it there. Answer slot: whether the 40 are interviews you conducted or interviews through the loop; how it was counted; what it is sensitive to; the assumption behind it you would defend least. If you do not know any of these, say so plainly | F4 holds the figure, and the sentence leaves open whose interviews the 40 are. EXP because it tests the attribution |
| D3 | "What would you need to understand about these services before you would trust a delivery date from either squad?" | CASE | [generic] | Answer with questions you would ask, not knowledge you do not claim: what is in flight and what depends on hardware, what happens when a rollout fails and how it is undone, what the on-call picture is, what the squads' last few dates did. If a device-management term comes up you do not know, say so plainly and ask. The staff engineers are scoring whether you ask rather than pretend. No claim about your past | F2 is silent and F3's limit is that delivery ownership is not shown. CASE because it is a live technical judgment with no claim in it |

## Bank: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A5 | "Hardware slips a firmware date by six weeks and product has already told a customer about a feature that depends on it. What do you do this week?" | CASE | [generic] | Clarify first: what is contractual and what is expectation, what the slip does to which dependent work, what hardware can give back. Then options (reduce scope, resequence, partial delivery, a firm new date), who owns the customer message, what you tell the squads and your Director, what you watch. Do not pretend to know hardware's constraints: your material says you have never owned a hardware-adjacent roadmap, so ask for theirs. No claim about your past | F6 and F7 are the requirement. CASE because it is a live problem from the role; the scenario is invented for rehearsal |
| A6 | "How would you tell a product partner no, and keep the relationship?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure: say what you are saying yes to first, make the trade-off visible, offer the date or the condition under which it changes, then commit together after the decision. Answer slot: if telling someone no was part of your reliability quarter, say how it landed; if it was not, say so plainly and use the structure as your approach. Never describe a conversation you did not have | F7 is the nearest evidence and is thin. JD because it scores the stated partnering line |

## Round 2 reverse questions

| Question to ask | Why it lands |
|---|---|
| "What could a new manager do in the first month that would genuinely help you and your engineers?" (reciprocity, to a staff engineer) | It prices what you cost them and what you contribute, which is what a peer evaluator is scoring |
| "Where do roadmap decisions between product, hardware and your services get stuck most often?" | It asks for the seam from their side, which answers F6 and F7 without claiming knowledge |
| "How do product and engineering decide when reliability work competes with a roadmap commitment here?" (to the product manager) | It lets the product manager describe the trade-off in their own terms, which is the conversation C2 rehearses |
| "Is there a technical decision in these services you would want a manager never to override without asking?" (to a staff engineer) | It shows you intend to protect technical judgment, and learns where the lines are |
| "What do you want a manager to protect you from, and what do you want them to push on?" | It gives each panelist an easy, specific answer and tells you what they expect of the role |

---

# Round 3: VP Engineering, Monday, 30 minutes

The recruiter described this round as "values and leadership philosophy". Larkfield's published values were not in hand, so there is no cheat sheet: the VAL questions below are themed from the recruiter's words and the role description, not from the company's own value names.

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (4 questions) | Leadership philosophy, growth, a time you held a line, a time you got it wrong | High. The skip-level prior is Case plus Pressure, but the recruiter's words about this round move Values to the top | Stories only where one of your sentences carries them; otherwise a selection scaffold with its honest branch. "We" for context, "I" for contribution. E1 to E4 |
| Pressure (3 questions) | Time-boxed challenges on why you, on attribution, on what would make you fail | Medium to high. Skip-level prior, and thirty minutes rewards short answers; your two stated gaps give a pressure interviewer an easy opening | Pause, restate the question, hold through two follow-ups, concede specifically. P1 to P3 |
| Case/Strategist (2 questions) | Live leadership problems at the altitude of two squads | Medium. The skip-level prior, tempered by the values framing | Clarify, structure, aloud. A7 and A8 |

Thirty minutes holds few questions: E1 to E3 and P1 and P2 come first.

## Bank: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How do you think about growing engineers, and what do you do when someone is not growing?" | VAL | [grounded] | Selection scaffold in your own words: one engineer you helped grow, no names, what you did and what changed. Answer slot: the role gives you growth for eleven engineers, so expect the probe; if you did help someone grow, say what you did and what changed; if you did not, or it was not yours, say so plainly and say what you would do. State one principle you actually hold, and only that. No claim about your past beyond the slot | F5 is silent in your material, so the guidance asks rather than says. VAL because it scores how you lead |
| E2 | "Tell me about a time you held a line your team or leadership did not want." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F3, with only the beats the sentence states: you pushed a reliability quarter through, against roadmap pressure, and the team's on-call burden dropped 60% after. Tell it in your own words with "I" for what you did and "we" for context. Answer slot: what the pressure was, what you said, and how the relationship stood afterwards, if you remember; if it was not a conversation, or the relationship was not tested, say so plainly and stay with the quarter | F8's hard-truth theme; F3 is the one sentence that touches it. VAL because it scores behavior under pressure |
| E3 | "What do you think changes when you lead leaders rather than a team?" | VAL | [grounded] "I've never managed managers"; "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Acknowledge first: "I've never managed managers." Then at the quote's scope: "Three of my nine years in engineering have been as a team lead of six." Then give one thing you expect to change and one thing you would ask the VP about in your first months, as expectations, not as experience. Answer slot: if you have a leadership principle you actually hold, say it in your own words; if you have not framed one yet, say so plainly and say what you would want to find out | F1's stated gap, put by someone who leads leaders. VAL because it scores how you think about leadership |
| E4 | "Tell me about a time you got something wrong as a lead." | VAL | [generic] | Selection scaffold: one real instance with a named cost, what you did when you saw it, and what changed after. Own it in the first person; no "we" for the mistake. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you handle being wrong. Do not supply a mistake you did not make | F8's values theme; no sentence of yours carries a mistake. VAL because it scores candor |

## Bank: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you, over a manager who has already led leaders and owned a hardware roadmap?" | JD | [grounded] "I've never managed managers"; "never owned a hardware-adjacent roadmap"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause and restate. Concede in one breath: "I've never managed managers and I've never owned a hardware-adjacent roadmap." Hold with what your sentences carry, each at its own scope: you run the hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Do not compare yourself to the other manager. If pushed twice, return to the same two sentences and do not add to them | F1 and F6 are stated gaps and F3 and F4 are the held ground. JD because it scores the case for the hire |
| P2 | "That 60%: how much of that was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the first person where your sentence has it: "I pushed a reliability quarter through." Concede specifically on the rest. Answer slot: which part of the drop was yours and which part was the team's; if most of the work was the team's, say so plainly. Say "after", not "because". If you do not know how the figure was counted, say so plainly | F3 holds the figure. EXP because attribution is what a pressure interviewer is testing |
| P3 | "What is the most likely reason you would fail in this role in your first six months?" | JD | [grounded] "I've never managed managers"; "never owned a hardware-adjacent roadmap" | Name the real risk plainly, in your own judgment of which of your two stated gaps is the bigger one: "I've never managed managers" or "I've never owned a hardware-adjacent roadmap". Then the plan against it, said as a plan: what you would ask for in the first month and who you would ask. Do not name a risk you do not hold, and do not turn it into a strength | F1 and F6 are the stated gaps, so this question is predictable. JD because it scores honest self-assessment against the role |

## Bank: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A7 | "Delivery is slipping on both squads, the business wants a date, and your engineers are tired. What do you do this week?" | CASE | [generic] | Clarify first: how far, since when, what is driving the slip, who is asking. Then separate what you can fix this week (scope, sequencing, a decision someone is waiting on) from what needs a conversation with your Director, say what you tell the business and when, and how you protect the engineers without hiding the problem. No claim about your past | F3 is the delivery requirement this scores. CASE because it is a live problem at the VP's altitude |
| A8 | "In your second month one of your squad's most senior engineers tells you they are leaving. What do you do?" | CASE | [generic] | Listen first and learn the reason before any counter. Then what the departure does to delivery, what you tell the squad and your Director, whether to try to retain, and the backfill plan, including how you would run the hiring for it. No claim about your past | F4 and F5 are the hiring and growth requirements; the scenario is invented for rehearsal. CASE because it is a live problem |

## Round 3 reverse questions

| Question to ask | Why it lands |
|---|---|
| "What does good engineering leadership look like at Larkfield in practice, in your own words?" | The published values were not in hand, so it asks the VP for the philosophy the round is about |
| "What do you most want to be different about engineering leadership here in two years?" | It shows you are thinking at the VP's altitude |
| "How are engineering managers developed here, especially someone new to leading leaders?" | It raises F1 as a question about growth, not as a confession |
| "How does engineering work with hardware at the leadership level, and where would you want it to improve?" | It makes F6 a shared problem you want to understand |
| "What is the most common reason managers at this level struggle here?" | It asks for the failure pattern, which shows you want to avoid it |

---

## Prohibited claims

Not coached in any round. The list was built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 | The plain acknowledgment F1 gives: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never owned a hardware-adjacent roadmap." Then a plan, never a past. No slot |
| Led two squads, or led eleven engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a team lead of six |
| Owned delivery for a roadmap | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the sentence carries a reliability push, not delivery ownership. B2 and A4 hold slots inside the quarter |
| The reliability quarter caused the 60% drop | Inflated form of F3 | F3's quote at its own scope: the drop came "after", and the sentence does not say "because". D1 and P2 hold the figure slots |
| Owns hiring decisions, headcount or offers | Inflated form of F4 | F4's quote at its own scope: you run the loop for backend roles. A3 and D2 hold slots on the loop and on the number |

## Sources

Provided documents: your message (the role description, the three rounds with who runs them and their lengths, the recruiter's description of Round 3, and your background). No JD text, CV, interviewer names or company materials were provided. The loop is established by your own words, so no archetype fallback was used. No dossier was present.

Searches sent, each refused (web search was not permitted in this session):

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems device management strategy news" — refused
- "Engineering Manager device management IoT job description squads hiring growth roadmap hardware product" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | All calls refused. It would have supplied the official value names for a values cheat sheet; none is in the pack |
| 2. Larkfield Systems interview process, engineering manager | unavailable | All calls refused. It would have documented the round formats beyond what you reported; persona weights rest on your own description of the rounds |
| 3. Larkfield Systems strategy or recent news | unavailable | All calls refused. It would have grounded at least one CO or CASE question in current strategy; none is written |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative engineering manager JD | unavailable | All calls refused. It would have supplied `[inferred]` requirement rows beyond your one-line description |

## Upgrade menu

- Larkfield's published values, pasted, or web search permitted → a values cheat sheet for Round 3, with each value mapped to a story one of your sentences carries or a selection scaffold, and VAL questions in the company's own terms
- A deeper research pass, offered once (up to 6 more searches and 2 more fetches, several more minutes, and only if search is permitted) → a company-strategy brief, so at least one CO or CASE question rests on Larkfield's current priorities
- Full JD text → F1 to F8 gain the requirements your one-line description does not carry, and the banks are rechecked against the JD's own list
- Your CV → more quoted evidence for F1, F3 and F4, and a chance to upgrade F2 and F5 from `discovery`
- Your answers to the answer slots on F2, F3, F5 and F7, stated outside a drill → each becomes quoted material and the rows that draw on it are regenerated
- The interviewers' names (Director, both staff engineers, the product manager, the VP) → an interviewer read per round, persona weights adjusted from their public footprint, and a reverse question tied to each path
- The recruiter's prep note, or one email to them → the panel's focus and format, whether any deliverable is expected, and the staff engineers' and product manager's remits
- Hours available per day → the prep triage resized to them
- A tuesday-dossier.md → verified evidence and any prohibited claims carried in; the pack stands without it
