I'll read the skill's reference files first.
Your prep pack is written and saved. I'm sending the summary now.

Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-denied-720744a2/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 19 questions across six interviewer styles, a fit table mapping each JD line to your own words, a prep order for the two days you have, and reverse questions.

I built it for a hiring-manager round with Tobias, since your note gave his title but not how he relates to the role.

My web searches were refused, so nothing about Saltmarsh's values, interview process, strategy or Tobias's background is researched. Those sections are dropped, and the company questions are labeled generic.

The question to rehearse most is B1: "You've presented retention numbers, so what have you owned, as opposed to presented?" The JD wants you to own the post-event review and its KPIs, and your material says you presented the monthly numbers. The pack coaches you to hold that claim at its real size and concede forward-looking, not to stretch it.

The pack deliberately won't coach:
- **No team lead:** claiming you led a team.
- **No in-app purchases:** claiming you worked on a game with in-app purchases.
- **Overstated scope:** claiming you owned the KPIs, ran two titles' calendars, or managed releases with QA.

Say the word and I'll play the Skeptic on B1 and follow up on what you actually say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and has the recruiter said what the hour will cover or asked you to prepare anything? Either answer reweights the question banks.
Can I run the research if you allow web search, or would you rather have a deeper pass (up to 6 more searches and 2 more page fetches, several more minutes)? Either way I'd update only the sections it affects.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager, because your note names his title and not how he relates to the role; a 60-minute conversation on Friday.
- **Built on:** the JD and background you pasted. Web research was refused in this session, so nothing here about Saltmarsh's values, interview loop, strategy or Tobias's public footprint is researched; those sections are dropped or labeled `[generic]`, and the Sources section says exactly what ran.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Past behavior against the company's published values |
| EXP | Whether your background survives scrutiny: what was actually yours |
| JD | A stated responsibility or requirement, including its gaps |
| CO | Company and strategy knowledge, homework depth |
| CASE | A live problem from the actual role, reasoned aloud |

An answer slot is an instruction for the interview, not a question for you. Either branch of a slot is a good answer; the branch that says "that wasn't mine" or "that didn't exist" is a limit, not a confession.

## Prep triage

Interview is Friday, so two days. Do these in order; each is worth more than the one after it.

1. B1 aloud, three times, with someone interrupting. It is the highest-ROI prep in this pack: the most predictable objection, and the one where a stretched answer does the most damage.
2. B2, B3 and B4 once each. They are the three gaps most likely to follow B1.
3. E1 and D1: your sixty-second answer and your ninety-second arc, built from the same four quoted sentences.
4. A1 to A3 once each, thinking aloud. Structure matters more than the answer.
5. C1: decide before Friday what you do and do not know about how the monthly retention numbers were counted.
6. Spend the remaining time on A5 and D3: look at both of Saltmarsh's titles as a player.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives the years, the associate-producer role and a weekly content-drop calendar; it does not say whether the main title ran as a live service. Words: "For four years I was an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-service wording makes a probe on this likely. If the title ran as a live service, say so in your own terms; if it did not, or you are unsure, say so plainly and stay with the weekly drops |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you ran the weekly content-drop calendar for your main title, for the last two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title; the JD's line is a live-events calendar across two titles, and the words stay at your scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if any of your drops were timed events, or ran beside another title's schedule, say so and what your part was; if not, say so plainly and stay with the main title's weekly drops |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which of these teams you worked with. Answer slot: the JD names four teams, so expect a probe on each. If you worked with any of them on the drops, say which and what you did with them, in your own words; if you did not, or the calendar did not involve them, say so plainly and describe the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers to the studio head; the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event-review line makes a probe on what happened after the numbers were presented likely. If you took part in any review of them, say what your part was; if there was no such review, or it was not yours, say so plainly and stay with presenting them |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in kind, but a self-reported line with nothing inspected behind it. Lead with it as written: you presented the monthly retention numbers to the studio head. Expect a probe on how those numbers were counted, which C1 rehearses |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and your QA team still uses it; the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's release-checklist line makes a probe on how releases were run against it likely. If you ran releases against it with QA, say how; if you did not, or that was someone else's, say so plainly and stay with having written it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist is writing, but the material does not show who read it or what else you wrote. Derived from the one quote, so held at low. Answer slot: if other writing was yours, say what it was and who relied on it; if none, say so plainly and stay with the checklist |
| F9 | Familiarity with in-app purchases: not a line of the supplied JD, included because your message names it | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | Leading a team: not a line of the supplied JD, included because your message names it | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." Then how you would work with people you do not manage, said as an approach and never as a past |

## Persona table

Weights start from the hiring-manager prior in the persona model and are adjusted by the JD. The loop itself is not established by any source I could read, so the archetype fallback is Generic and no persona is zeroed.

| Persona | Bank | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | A | Live problems from the role: plan a calendar, diagnose a retention drop, handle a release risk | High. The hiring-manager prior favors it, and the JD's headline duties (F3, F5, F7) are all things a case can be built from | Clarify, objective, segmentation, approach, metrics, risks; think aloud and challenge one premise per case |
| Skeptic | B | Quiet, persistent probing of F3, F5, F9 and F10 | High. The hiring-manager prior favors it, and two of the four gaps are ones you named yourself | Rehearse B1 until it is boring; hold what the quotes say, concede forward-looking, never bluff |
| Data-Driven Prober | C | Line-by-line reading of the retention numbers and the checklist | Medium. The JD names retention metrics and KPIs, and your background has monthly retention numbers (F6), which a prober goes straight to | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational / Rapport | D | The journey question, then casual questions about the games | Medium. Casual questions are scored too, and the cost of rehearsing the opener is low | A ninety-second arc built from your four quoted sentences; treat "what have you been playing" as scored |
| Pressure | E | Time-boxed "why you" and "how much was actually you" | Low. No signal in the material that Tobias runs a stress style | Pause, restate, hold the quoted claim through two follow-ups, concede specifically and forward-looking |
| Peer Evaluator | F | Seam-splitting between your calendar and design, art, engineering or community | Low. It matters only if people from those teams sit in the conversation, which your material does not say | Offer seam principles, do not pretend to know the seam, reciprocity framing |

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "An event on one title and a major update on the other land in the same week. Walk me through how you'd plan the calendar — what do you need to know first?" | CASE | [generic] | Clarify first: what each is meant to achieve, which teams and which QA time each needs, what is fixed and what can move, what happens if one slips. Then the objective, two or three sequencing options, the trade-off between them, the risk you would watch, and one premise you would challenge, for example whether both must really land that week. Think aloud; the question needs no claim about your past, so this makes none | The JD's two-title calendar line (F3) is its headline duty, so a live version of it is likely. CASE because it scores structure; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "Retention drops after an event ends on one title. Diagnose it." | CASE | [generic] | Clarify: which retention measure, which cohort, against what baseline, which platform and version, and whether the drop coincides with an update. Segment: new against returning players, by version. Give two or three hypotheses, each with the data that would confirm or kill it, and say what you cannot know without the data. Make no claim about analyses you have run | Retention metrics (F6) and the post-event review (F5) are both in the JD. CASE with a metrics flavor; `[generic]` because the problem is a pattern | 
| A3 | "Two days before a release, QA flags an open critical bug. What do you do?" | CASE | [generic] | Ask first: how severe, who is affected, how long a fix takes, whether there is a workaround. Then the options: slip, cut the affected piece, or ship with a limit that the people who own it agree to. Name who decides, bring them the options and your recommendation, tell the affected teams what changed and why, and record the decision against the checklist | The JD's release-checklist line (F7) makes a release-risk scenario natural. CASE because it asks for a decision under pressure, not a record |
| A4 | "What does a good post-event review look like to you, and what would it report?" | CASE | [generic] | A structure: the event's goal set before it runs, the metrics tied to that goal, a baseline to compare against, what happened, what you would change. Written so someone who was not in the room can read it. Say you would start from the team's existing KPI definitions before proposing new ones | The JD's post-event-review line (F5) and written-communication line (F8). CASE because it asks you to design the artifact the role owns, so it needs no claim about your past |
| A5 | "What have you seen of our two titles so far?" | CO | [generic] | Selection scaffold: pick one concrete thing you noticed in each title's live events, such as what was running, how it was announced or how long it ran, and frame it as a question for the team rather than a criticism. If you have not played them yet, say so plainly, then say what you did look at. Research on Saltmarsh was not run for this pack, so this question carries no company facts; the upgrade menu says what would change that | The JD names two of Saltmarsh's mobile titles (F3), so homework on them is a natural check. CO because it scores whether you can think at the studio's level; `[generic]` because no company research ran |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role owns the post-event review and the KPIs it reports. You've presented retention numbers — what have you owned, as opposed to presented?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | **Highest-ROI prep in this pack.** Level 1, the hold: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event-review line makes a probe on what happened after the numbers were presented likely. If you took part in any review of them, say what your part was; if there was no such review, or it was not yours, say so plainly and stay with presenting them. Level 2, "so someone else owned them?": return to the quote and say, in your own words, which part was yours; do not add to it. Level 3, "what would you do in the first review you owned here?": answer as a plan, not a history. Start from the team's existing KPI definitions and ask what decisions the review feeds. The concession, said specifically: "I'd want to learn how this team defines and reviews its KPIs before I said how I'd change anything." Never say you owned or defined them | F5 is where the JD presses hardest against the thinnest part of your material, so this objection arrives in some form. JD because it scores the stated requirement; Skeptic because it probes the gap |
| B2 | "You haven't worked on a game with in-app purchases. How would you get up to speed on that side of the job?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: what you would read and ask in the first weeks, and who you would sit with to understand how purchases are tracked and how events relate to them. If pressed on whether retention work is enough, say what the retention work was at its own scope and do not call it equivalent. No answer slot, since the absence is stated | F9 is the gap you named yourself. It is asked in some form if Saltmarsh's titles use purchases, which your material does not tell us; if you can see from the store pages that they do not, this question recedes. JD because the role sits on mobile titles; Skeptic because it probes a stated gap |
| B3 | "You ran the content-drop calendar for your main title. This role covers the live-events calendars of two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Restate it at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if any of your drops were timed events, or ran beside another title's schedule, say so and what your part was; if not, say so plainly and stay with the main title's weekly drops. Then answer what changes as reasoning, not history: shared team capacity, collisions between the two titles, different cadences, and how you would see conflicts early | F3 and F2: the quote carries one title's weekly calendar and the JD asks for two titles' live-events calendars. JD because it scores the stated requirement |
| B4 | "You've never led a team, and this role coordinates design, art, engineering and community on every update. How do you move four disciplines without being anyone's boss?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Open with the plain acknowledgment: "I haven't led a team." Answer slot: the JD names four teams, so expect a probe on each. If you worked with any of them on your drops, say which and what you did with them, in your own words; if you did not, or the calendar did not involve them, say so plainly. Then your approach as an approach: one calendar everyone can see, dates and owners agreed early, conflicts raised as soon as you see them, and a written update after any change | F10 is a gap you stated, and F4 is a JD line your material is silent on. JD because it scores the coordination line; Skeptic because it asks you to work without authority |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented in the quote's words. Answer slot: if you know how the numbers were counted, say it in your own words and name the assumption you would defend least before they ask; if you do not know how they were counted, or someone else prepared them, say so plainly and stay with presenting them. Say which part of them was yours, in your own words. Do not explain a counting method you could not repeat under a second question | F6: a probe on how the numbers were counted is where a prober goes first. EXP because it scores whether you know your own numbers |
| C2 | "When you presented those numbers to the studio head, what did you tell them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Tell it in your own words: what you presented and what you said about it. Answer slot: the JD's KPI line makes a probe on what followed likely. If anything was decided from the numbers, say what and what part was yours; if nothing was, or you do not know, say so plainly and stay with presenting them | F5 and F6: the second level of a prober's follow-up. EXP because it tests what was actually yours |
| C3 | "Tell me about the release checklist your QA team still uses." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The beats the quote states: you wrote it, and your QA team still uses it. Answer slot: the JD's release-checklist line makes a probe on how releases were run against it likely. If you ran releases against it with QA, say how; if you did not, or that was someone else's, say so plainly and stay with having written it. Name checklist items only if you actually remember them being on it | F7 and F8: the one artifact your material names, so a prober will open it. EXP because it scores what you actually did |

### D. Conversational / Rapport Builder (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years." | A ninety-second arc with the beats the quotes state: four years as an associate producer at a puzzle-game studio, and for the last two years the weekly content-drop calendar for your main title. Answer slot: what draws you to live events for two mobile titles, in your own words, not scripted. Answer slot: the JD's live-service wording; if the main title ran as a live service, say so in your terms, and if it did not, say so plainly and stay with the weekly drops | F1 and F2. EXP because it is the biography question; a casual register does not make it unscored |
| D2 | "Tell me about something you wrote that other people relied on." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on what the quote states: you wrote the release checklist, and your QA team still uses it. Answer slot: if other writing was yours, say what it was and who relied on it; if none, say so plainly and stay with the checklist | F8: the JD asks for clear written communication, which this open prompt scores. EXP because it asks for a real instance |
| D3 | "What live event or update in a mobile game has stuck with you lately?" | CO | [generic] | Selection scaffold: pick one you have actually seen. Say what it did, and one thing you would ask the team that built it. If nothing comes to mind, say so plainly, then name something from a game you play | F3: a casual question about the job's subject, which a rapport-style interviewer scores. CO because it tests interest and homework; `[generic]` because it asks nothing about your past |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, with four years as an associate producer, for this role?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Pause, restate the question, then the four sentences in their own terms and nothing added. Hold through two follow-ups by returning to the same four. Concede forward-looking and specific: "What I'd want to learn is how this team defines its KPIs and runs its two titles' numbers." Do not call yourself ready or equivalent | F1 and F2, F5 to F7. JD because it scores fit against the title; Pressure because the time-box tests composure |
| E2 | "How much of that calendar was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours to decide and which were set by others, in your own words; if you cannot separate them, or others set most of it, say so plainly and return to the quote. Hold through the second follow-up; concede only what is true | F2 and F3: the attribution probe the persona model names. EXP because it scores precise attribution |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side — where's the seam between your calendar and ours, and what happens when we disagree?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Offer seam principles and do not pretend to know the seam: who sets dates, who signs off readiness, how a conflict gets raised. Answer slot: the JD's coordination line makes a probe on a past disagreement likely. If a date on your calendar and a team's readiness ever disagreed, say what happened and what you did; if not, or it was not yours, say so plainly and stay with the principles | F4: the coordination line, asked collegially. JD because it scores the stated duty; Peer because it asks where the seam is |
| F2 | "How do you handle credit when work spans teams?" | JD | [generic] | Selection scaffold: pick a time work spanned teams and you can name your own part. Say "we" for context and "I" for what you did, and credit others' parts by name. If no such time comes to mind, say so plainly, then say how you would handle it | F4: the coordination line again, through credit. JD because it scores cross-team work; `[generic]` because it is a pattern for the problem |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A5, B3, D3 |
| "coordinate design, art, engineering and community teams on each update" | B4, F1, F2 |
| "own the post-event review and the KPIs it reports" | A2, A4, B1, C2 |
| "manage the release checklist with QA" | A3, C3 |
| "3+ years producing live-service games or apps" | D1, E1 |
| "experience running a content calendar" | B3, D1, E2 |
| "comfortable with player-retention metrics" | A2, C1, C2 |
| "clear written communication" | A4, C3, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first ninety days look like for this role across the two titles?" | Shows you are thinking about the job, not just the interview, and gets the first real priorities out of him |
| R2 | "How is the live-events calendar set, and who can change it once it's set?" | Goes straight at the seam between your calendar and every team in the JD's coordination line (F4) |
| R3 | "Which post-event KPIs matter most to you, and where do the numbers get reviewed?" | Ties to the JD's KPI line (F5), and tells you what you would be expected to own |
| R4 | "What would you most want improved about how releases run with QA today?" | Ties to the checklist line (F7) and lets you listen before you offer anything |
| R5 | "How would you help a new producer get up to speed on the titles' business metrics?" | Turns the gaps you named (F9) into a ramp-up conversation instead of a defense |
| R6 | "What would make you say, six months in, that this hire was a clear success?" | A close that is about outcomes, and a chance to hear the real bar |

No reverse question is tied to Tobias's own career path, because his public footprint was not researched.

## Prohibited claims

What this pack will not coach, because your material does not carry it.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated, F10 | "I haven't led a team." The plain acknowledgment comes from your message: "Never led a team, and never worked on a game with in-app purchases." No slot |
| Worked on a game with in-app purchases | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." The plan to learn it is said as a plan |
| Owned the post-event review and defined the KPIs | Inflated form of F5 | F5's quote at its own scope: you presented the monthly retention numbers to the studio head. The limit is the pack's observation: your material says presenting, not owning. B1's slot stays inside presenting |
| Ran a live-events calendar for two titles | Inflated form of F3 | F3's quote at its own scope: the weekly content-drop calendar for your main title. B3's slot stays inside that calendar |
| Managed releases with QA | Inflated form of F7 | F7's quote at its own scope: you wrote the release checklist, and your QA team still uses it. C3's slot stays inside having written it |
| Spent three or more years producing live-service games | Inflated form of F1 | F1's quote at its own scope: four years as an associate producer at a puzzle-game studio. The limit is the pack's observation: your material does not say the title was a live service. D1's slot stays inside the main title's weekly drops |

## Sources

Provided documents: the job description you pasted, and the background in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, each refused by the host permissions, so none returned a result:

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games strategy news mobile": refused
- "Tobias Wrenfield Saltmarsh Games": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions, so both are dropped |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Every call was refused. It would have established the loop and the persona weights; the weights rest on the hiring-manager prior and the Generic archetype instead |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Every call was refused. It would have grounded the CO questions in the studio's current priorities, so A5 and D3 are `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Every call was refused. It would have supplied an interviewer read and a reverse question tied to his path, so both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, or the pages pasted in: the official values page would add a values cheat sheet and VAL questions; the interview-process page would settle the persona weights; a recent-news sweep would turn A5 and D3 into questions grounded in the studio's current priorities
- Tobias's public talks or posts, or his profile pasted in: an interviewer read, persona weights adjusted from his own signals, and a reverse question tied to his career path
- The recruiter's reply on what the hour will cover and whether anything is to be prepared: coverage by focus area, and a build section for any pre-declared deliverable
- Your answers to the slots in F1, F3, F4, F5, F7 and F8: each answer you give outside a drill enters the fit snapshot verbatim and upgrades those rows from silence to quoted evidence
- The artifacts themselves, redacted as needed: the release checklist, a content-calendar export, or a retention deck would let F6 and F7 move from medium toward high, since a document someone can read is the proof a producer's field keeps
- A `tuesday-dossier.md` from earlier work, if you have one: the highest-ROI objection would come from verified evidence instead of from this pack's reading, and prohibited claims would arrive already built
