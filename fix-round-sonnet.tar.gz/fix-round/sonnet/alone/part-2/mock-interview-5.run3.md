Reading is done. I'm now running the pack's research pass (up to 6 searches) on Kelverton Rail, the panel's public footprint, and a representative JD, before I write the pack.
Web search was refused all six times, so the pack runs on your message alone and I'll say so in its Sources. Writing it now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-5-denied-9dd6a077/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It has 19 questions, a 15-minute POV build, reverse questions and a four-hour prep schedule.

Web research was refused on all six searches, so the pack rests only on your message. It has no Kelverton facts, no interviewer read and no JD-based rows. It also contains nothing from the market report, because I haven't seen it.

- **Highest-ROI prep:** B1, the "you've not sold into rail and you've not carried a quota" objection. Work that first.
- **Persona weights:** Deepa gets the Strategist and Skeptic questions, and Ross gets the Prober and Pressure ones. I based this on the recruiter's wording, so reweight it if you know better.
- **The POV:** it opens by defining "operator partnerships" in your own words, since the email doesn't define it. It also asks you to bring one idea from the report, then diverge from it. Your anti-pick is something you'd do last or decline, and it's yours to choose because I can't see the report.
- **A gap to fix before Tuesday:** your message doesn't say whether the five consulting years sit inside the nine years in partnerships. E1 flags it, and they may ask.

Say the word and I'll play Ross on B1 and its two follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Can you paste the JD text and the CV you applied with, whichever you have? It would turn the requirement column into the JD's own words and could restructure the JD-tagged questions. If you don't have them, the pack stands as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one 60-minute panel on Tuesday. **Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). **Shape, per the recruiter's email as you quoted it:** a 15-minute spoken POV on operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves; then Q&A, where Ross will push on commercials.

**Built on this assumption:** you have not pasted the JD, your CV, or the market report, and web research was refused, so every row below rests on your message alone. Anything about Kelverton, its operators or the report is absent on purpose, not forgotten.

## 1. How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Past behaviour against published company values. None in this pack: no values-style round is documented and no published values are in hand |
| EXP | Whether claims about your experience survive a follow-up |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

Answer slots (lines beginning "Answer slot") are instructions for the interview, not questions for you to answer here. Each has two honest branches; either one is a good answer.

## 2. Prep triage (about 4 hours)

| Block | Time | Do this | Where |
|---|---|---|---|
| 1 | 75 min | Re-skim the report for one item to agree with, one divergence, one thing you would sequence last. Pick your thesis and write five bullets. Speak it aloud once, timed | Section 3, A2 |
| 2 | 45 min | Rehearse the rail-and-quota objection until it is boring: the plain acknowledgment, what you did carry, then the two follow-ups. This is the highest-ROI prep in the pack | B1, then B2, B4 |
| 3 | 45 min | Ross's ground: the £4M and the 6-to-40, in your own words, including what you do not know about how they were counted | C1, C2, C3, D2 |
| 4 | 45 min | Two full aloud run-throughs of the POV, recorded, 12 to 13 minutes each so you finish inside 15 | Section 3 |
| 5 | 20 min | Your 90-second journey arc, and pick three reverse questions | E1, section 6 |
| 6 | 10 min | Tuesday morning: the first minute of the POV and B1's opening line only | Section 3, B1 |

Everything else is insurance.

## 3. Fit snapshot

Requirements are quoted from the recruiter's email as you quoted it to me. No JD was supplied, so JD-derived rows are absent. No requirement here is a gate: the material names no term such as a licence, location or schedule.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, as quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your quote carries a partner channel and its growth, nothing inspected behind it. The pack's observation: ISV partners and train operators are different counterparties, and the quote does not show an operator-side partnership. Words at the quote's scope: "For four years I ran the ISV channel at a payments company, and it went from 6 partners to 40." Answer slot: the POV ask makes a probe on how much of that growth was yours likely. Say how the count was made and which part was yours, in your own words; if you do not know how a part was counted, or it was not yours, say so plainly and stay with running the channel |
| F2 | "land on what it means for the operators themselves" — recruiter's email, as quoted in your message | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | The quote carries bus and light rail network planning, and the words stay there: "Before that I spent 5 years in transport consulting, doing bus and light rail network planning." The pack's observation: the material says bus and light rail, not train operations, so "the operator world" is your summary of that work and should not be carried over to train operators. Answer slot: if that work put you in front of an operator's own staff, say who and what you did; if it did not, say so plainly and stay with the planning work |
| F3 | "Ross will push on commercials" — recruiter's email, as quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | You stated the limit, so the words are yours: "I've never carried a direct quota; my number is influenced revenue." The figure raises the defend-the-number slots and only those. Answer slot: say how the £4M was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, in your own words; where you do not know how a part was counted, say so plainly |
| F4 | Selling or partnering within the rail sector. No supplied source states this as a requirement; you raised it | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Never a claim to rail sales, and nothing added to make the gap feel smaller |
| F5 | "Senior Partnerships Manager" — role title, your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | none | No gap against the title, but a CV-level line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: nine years in partnerships, the last four running the ISV channel. The pack's observation: your message does not say whether the consulting years sit inside the nine; E1 holds the slot for that |

## 4. Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. Targets 12 to 13 minutes spoken so you finish inside 15. Everything about you below is a row of the fit snapshot; everything about Kelverton is missing because the report and the JD were not provided.

**Facts to build on**

| Row | Sentence, quoted exactly from the row's evidence cell |
|---|---|
| F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." |
| F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." |
| F3 / F4 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." |

**Shape**

| Minutes | Beat |
|---|---|
| 0 to 1 | Say what you take "operator partnerships" to mean, in one sentence, and say it is your reading. The email does not define it, and a wrong reading costs the whole 15 minutes |
| 1 to 3 | One item from the report you agree with, to show you read it. Then say your view departs from it in one place |
| 3 to 10 | One thesis, three moves, phased across the 18 months. Name the first move and what you need to learn before the second |
| 10 to 13 | Land on the operators: the close below |
| 13 to 15 | Your concession, then stop. Leave the two minutes |

**Thesis options.** Pick one. Each carries the concession you must say aloud.

| Thesis | One-sentence version | What it rests on in your material | Mandatory concession | Provenance |
|---|---|---|---|---|
| T1 Outcomes first | Define each operator partnership by an outcome the operator's own planners would recognise, agreed jointly, before widening commercially | F2 at its scope: network planning in bus and light rail. The outcomes themselves are your proposal | Ross will ask how that becomes revenue, and you have no rail sales figure to offer (F4). Say so, and offer the first operator pilots as the test | [generic] |
| T2 Programme, not one-offs | Replace account-by-account effort with a structured programme: tiers, joint plans, shared measures | F1 at its scope: you ran a channel that went from 6 partners to 40 | That pattern was built for many partners, and the pack does not know how many operators Kelverton works with. Check, and say that the structure only fits if the count does | [generic] |
| T3 Depth before breadth | Pick a small number of operators, go deep, and make them the reference for the rest | None from your quotes; this is a proposal | Concentration risk and slower coverage. Say what you would watch to know it was working | [generic] |

**Differentiate; do not recite.** The report is equally available to every prepared candidate and to the panel who wrote or read it. Bring one consensus item to prove grounding, then your divergence with reasons. Give one anti-pick: the item you would do last or decline in 18 months, with a reason stated in operators' terms. The pack cannot name it because it has not seen the report. Frame it as sequencing, never as the strategy team getting something wrong.

**The close the recruiter asked for: what it means for the operators.** Three beats, then one limit.

1. What an operator's own staff would experience differently by month 18. Name something concrete you chose.
2. What the operator is asked to commit in return. Say the cost honestly.
3. How you would know the operator benefited: one operator-side measure, not a Kelverton revenue line.
4. The limit, in your words: "I've never sold into rail specifically, so I'd test this with operators before committing."

## 5. Persona table

The loop is established by the recruiter's own words: one session, a two-person panel, 15 minutes of presentation, then Q&A. No archetype fallback applies. No values-style round is documented, so no values bank. With no interviewer profile, each panelist's tilt rests on the role the recruiter gave them.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Case / Strategist | Deepa and Ross picking at the POV: what first, what you need to know, how you would sequence | High. A hiring manager's prior is Case plus Skeptic, an executive's is Case plus Pressure, and 15 of 60 minutes is a presentation they will follow up | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case | A (5) |
| Skeptic | Deepa, your future manager, probing rail and quota gaps | High. You told me you have not sold into rail or carried a direct quota, and a hiring manager is derisking exactly that | Rehearse the one objection until boring; adjacent evidence at its own scope; a ramp plan said as a plan | B (5) |
| Data-Driven Prober | Ross on the £4M and the 6-to-40 | Medium to high. The recruiter said Ross will push on commercials and your message carries two headline figures | Know what you can and cannot say about how each figure was counted; say plainly when you do not know | C (4) |
| Pressure | Ross interrupting, time-boxing, challenging motive | Medium. "Push" in the recruiter's email could mean a hard but fair probe or a stress style; an executive prior adds Pressure | Pause, restate, anchor in what you said, hold through two follow-ups before conceding anything real | D (3) |
| Conversational | A light opener or a warm closing question | Low to medium. The POV opens the session, so a biography question may be short or skipped, but still scored | A 90-second arc; treat casual questions about rail as scored | E (2) |
| Values / Behavioral | Not banked | Low. No loop source documents a values round and no published values are in hand | None | none |
| Peer Evaluator | Not banked | Low. Neither panelist is a peer; Deepa is your future manager | None | none |

## 6. Question banks

Provenance quotes: Q1 is the F1 sentence, Q2 is the F2 sentence, Q3 is the F4 sentence, Q4 is the sentence about the report. Each is quoted in full where used.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Pick the first move in your plan. What do you need to know before you commit to it?" | CASE | [generic] | Say the objective first, then the two or three things you need to learn and from whom, then what you would do if the answer went each way. Ask one clarifying question of the panel before structuring. The question needs no claim about your past, so the guidance makes none | The natural follow-up to any POV; CASE because it scores clarifying before answering, per the persona's bar |
| A2 | "You've read the report. Where do you disagree with it?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | You have read it, per your message. Name one agreement, then one divergence with a reason stated in operators' terms, then your anti-pick from section 4. Do not recite its list. The pack has not seen the report and supplies none of its content. Answer slot: if you disagree with nothing, say so plainly and say what you would sequence differently | A shared report is the consensus answer, so departing from it with reasons is what scores. CO because it tests altitude. F-row not needed; it makes no claim about your past beyond the quote |
| A3 | "An operator tells you our scheduling product doesn't fit how they plan, and asks for a roadmap commitment we can't give. What do you do?" | CASE | [generic] | Structure it aloud: ask what specifically does not fit; separate what they must have from what they would like; find who owns the roadmap decision and bring them in; say what can honestly be offered, including a no and a date for an answer; keep the relationship intact. Never promise what you cannot commit | A live problem from the "operators themselves" ask (F2's requirement), asked as a decision; generic because it is a pattern, not a fact about this company |
| A4 | "How would you choose which operators to put first over the next 18 months?" | CASE | [generic] | Ask first how many operators there are and which already work with Kelverton. Then criteria, said aloud: what the operator needs, how ready it is, what it would be worth, whether it would be a reference for others. Then say how you would test the choice early. Offer criteria as a proposal | Where a strategist presses on a POV's sequencing; CASE because the structure is the score |
| A5 | "How would you know in month nine that it was working?" | CASE | [generic] | Name an operator-side measure, a partnership-activity measure, and a commercial measure, and say which you would trust first and why. Propose them; do not describe measures you have used. Say who would need to agree them before the year starts | Bridges the POV to Ross's commercial lens (F3's requirement); CASE because it asks for a defined measure, not a past |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've not sold into rail and you've not carried a quota. Why should we believe you can do this job?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | **Highest-ROI prep in the pack.** Hold, then concede. Open with the acknowledgment: "I've never sold into rail specifically, and I've never carried a direct quota; my number is influenced revenue." Then what you do carry, at its scope: running the ISV channel as it went from 6 partners to 40, and bus and light rail network planning. Then a ramp plan said as a plan, with your own first steps and dates. Answer slot: name the one thing about operators you would least expect to know yet; if none comes to mind, say so and say how you would find out in the first month. Follow-up 1, probably that bus and light rail differ from train operations: say plainly what you did and where it stops, and return to it. Follow-up 2, probably that Ross carries a quota and you do not: repeat the acknowledgment, say how the £4M was counted if you know, and offer how you would want a number defined (C4). Never add to a quote under pressure | The objection is aimed at F4 and F3, and it will arrive in some form; JD because it scores the listed job including its gaps |
| B2 | "Your consulting years were bus and light rail. What transfers to train operators and what doesn't?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Describe the work as the quote does: bus and light rail network planning. Answer slot: if you know a difference between those operators and train operators that mattered, name it; if you cannot name one, say so plainly and say what you would test first. Do not say you know how train operators work | F2's limit is where this probe lands; EXP because it tests what your consulting years actually carry |
| B3 | "Your last four years were payments. What draws you back to transport?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Your reason has to be your own and specific: about the work, checkable, and consistent with what you did. If no specific reason comes to mind, say so plainly, then say what you want to be doing in 18 months and why this role. Avoid "an exciting opportunity". The pack supplies no reason | The motivation probe a hiring manager runs on any sector move; EXP because the career line in F2 and F1 is what is tested |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Choose from your own material: the limit you stated is the natural pick. Say it plainly, then the first thing you would do about it and by when. Answer slot: if you rank another part as weaker, say which and why, in your own words | The standard Skeptic stem; JD because it scores honest self-assessment against the role |
| B5 | "In payments you worked with ISVs. Operators are customers, not ISVs. What does a partnership with a customer look like to you?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | State what you ran at its scope: the ISV channel. The pack's observation: ISV partners and operators are different counterparties, so do not say the experience is the same. Answer as a proposal tied to your one-sentence definition from the POV. Answer slot: if you have run a partnership with a customer rather than an ISV, say what it was and your part; if not, say so plainly and answer as a proposal | The relationship gap in F1, asked as a definition; JD because the role is operator partnerships |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Say it is influenced revenue. Answer slot: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, in your own words; if you do not know how a part was counted, say so plainly. Name the weakest assumption before they do. The pack supplies no method | F3's headline figure, the magnet target for a prober; EXP because it tests attribution |
| C2 | "Influenced isn't closed. Where is the line?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Agree with the distinction and repeat the acknowledgment: "I've never carried a direct quota; my number is influenced revenue." Answer slot: say what "influenced" meant in your role and who set the definition; if you do not know, or it was not yours, say so plainly and say what definition you would propose | The probe sits on the quote's own wording; EXP because it tests whether you can say what the figure is and is not |
| C3 | "Six to forty partners. How many of those were really active?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say what counted as a partner, how many were meaningful if you know, and which part of the growth was yours, in your own words; if you do not know the active number, say so plainly and stay with running the channel. Do not offer a number you cannot repeat under a second question | The second headline figure on F1; a prober asks for the denominator |
| C4 | "If we gave you a number for operator partnerships, how would you want it defined, and what would you refuse to be measured on?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Start with the acknowledgment from your quote. Then propose: separate an operator outcome, partnership pipeline, and revenue; agree how credit is attributed before the year begins; refuse a target that depends on something you do not control without an agreed rule. Present it as a proposal, not as something you have done | Turns F3's limit into a design discussion Ross can engage with; JD because it scores the commercial side of the role |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause, restate the question, then three beats: what you ran, at its scope; the plain acknowledgment from your quote; one thing you would bring, in your words. Answer slot: name the strongest thing from your own material; if nothing comparative comes to mind, say what you would do in the first 90 days. Do not claim to be better than the unseen candidate | The time-boxed pressure stem aimed at F4; JD because it scores the same gap as B1 under time pressure |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold: it is influenced revenue, which by its nature is shared. Concede specifically. Answer slot: say which part was yours, in your own words; if it was not separable, or you do not know how it was split, say so plainly and return to running the channel. Do not raise the share under a second push | The pressure-persona version of C1; EXP because it tests attribution without a number |
| D3 | "Partnership revenue is slow. Why not put the money behind direct sales instead?" | CASE | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Hold your thesis through two follow-ups. Concede the one thing the quote supports: you have not carried a direct quota, so you cannot argue from direct-sales numbers. Then propose how to test: a small, time-boxed pilot with a measure agreed up front. Do not state a figure about partnership timelines | Ross's likely framing; CASE because it is a live argument, and the concession is the hold-then-concede bar |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc in your own words: the consulting years at their scope, the partnerships years with the last four on the ISV channel, then why this role. Answer slot: your message does not say whether the consulting years sit inside the nine or alongside them, and an interviewer may ask; say how the years fit, in your own words. Your reason for this role is yours to give | The opener most likely to be short; EXP because it is where F5's timeline is probed |
| E2 | "What are you actually thinking about in rail these days?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Answer from the report you read and from the POV you built, in your own words. Answer slot: if you have nothing beyond the report, say so plainly and say what you would ask operators first. Do not bluff rail knowledge | A casual question on a hot topic is still scored; CO because it tests whether you can speak at the company's altitude |

### Requirement coverage

| Requirement | Questions |
|---|---|
| POV on operator partnerships over 18 months | Section 4, A1, A2, A4, A5, D3 |
| Land on what it means for operators | Section 4 close, A3, B2, B5 |
| Commercials (Ross) | C1, C2, C3, C4, D2, D3, B1 |
| Rail-sector gap (stated by you) | B1, B2, B4, D1 |
| Senior Partnerships Manager title | E1, B3, B5 |
| JD requirements | none: no JD was supplied, so none can be mapped |

## 7. Reverse questions

No interviewer profile exists, so none is tied to a career path.

| # | Ask | Why it lands |
|---|---|---|
| R1 | To Deepa: "Which of today's operator relationships do you call partnerships, and which are still supplier relationships? What separates them?" | Tests the definition your POV opened with, and your future manager's answer shows how she scopes the role |
| R2 | To Ross: "How would you want a partnerships hire's contribution to show up in the commercial plan?" | The recruiter said he will push on commercials; asking for his definition turns the quota question into a design conversation |
| R3 | To both: "Where did the report land differently from what you hear in operator conversations?" | Shows you read it and treat it as a view, not a script |
| R4 | To Deepa: "What would have to be true by month six for you to say the direction was right?" | Gives you a measure to work to, and she is the person who will judge it |
| R5 | To both: "When an operator's priority and our roadmap conflict, who decides, and how fast?" | Surfaces how much a partnerships role can commit on its own, which bears on A3 |
| R6 | To Deepa: "What do you expect a new hire in this role to underestimate?" | Invites her to name the risk you would otherwise have to guess at |

## 8. Prohibited claims

Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail, or has rail sales experience | Negative you stated, F4 | "I've never sold into rail specifically." Your sentence: "Never sold into rail specifically and never carried a direct quota, only influenced revenue." Then a plan said as a plan. No slot |
| Carried a quota, or closed the £4M | Negative you stated, F3 | "I've never carried a direct quota; my number is influenced revenue." Your sentence: "Never sold into rail specifically and never carried a direct quota, only influenced revenue." |
| Personally recruited or onboarded the partners the channel gained | Inflated form of F1 | F1's quote at its own scope: "running the ISV channel — took it from 6 partners to 40". The limit is the pack's observation: the material says you ran the channel and it grew, not who recruited each partner. The C3 slot stays inside how the count was made and which part was yours |
| Knows how train operators plan or schedule, or "knows the operator world" | Inflated form of F2 | F2's quote at its own scope: "bus and light rail network planning". The limit is the pack's observation: the material says bus and light rail, not train operations. B2's slot stays inside that work |

## 9. Sources

**Provided:** your message (your background, and the recruiter's email as you quoted it). **Not in the pack's hands:** the market report you read, the JD, your CV, and any interviewer profile.

**Searches sent, all refused** (the host did not grant search permission, so nothing returned):

- `Kelverton Rail company values` — refused
- `Kelverton Rail interview process partnerships` — refused
- `Kelverton Rail strategy news train operating companies scheduling software` — refused
- `Deepa VP Partnerships Kelverton Rail` — refused
- `Ross Commercial Director Kelverton Rail` — refused
- `Senior Partnerships Manager rail technology job description train operating companies` — refused

No fetches were sent. No dossier was in context.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Every call refused. Would have fed a values cheat sheet; none is built, since no values-style round is documented either way |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Every call refused. The loop rests on the recruiter's own words instead, so persona weights are unchanged in kind |
| 3. `Kelverton Rail strategy news` | unavailable | Every call refused, and the report is not in hand. CO questions A2 and E2 stay generic about Kelverton, and no grounding brief is built |
| 4. interviewer name with company | unavailable | Both calls refused. No interviewer read and no path-tied reverse question |
| 5. representative `Senior Partnerships Manager` JD | unavailable | The call was refused. The fit snapshot uses the recruiter's words; JD-tagged questions are marked grounded on those and your message only |

## 10. Upgrade menu

- The JD text → the fit snapshot's requirement column quotes the JD's own words, and JD questions cover each listed requirement
- Your CV text → F1, F2 and F5 gain a second source, and the timeline question in E1 may close
- The report's headline points, or its section titles, if you are free to share them → a grounding brief, A2 and E2 become grounded, and section 4 names the consensus item and the anti-pick instead of asking you to choose
- Search access → the five targets in the table above re-run; Kelverton's published values, any documented loop, and recent strategy news can then move the CO questions
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → company strategy brief and recent org context, worth it only once search is granted
- Deepa's and Ross's surnames or public profile text → an interviewer read, and a reverse question tied to a career path
- One line to the recruiter on what "operator partnerships" covers in this role → closes the definition risk in the first minute of the POV
- A partner-sourced or influenced revenue report from your CRM, showing how influence was defined → F1 and F3 could rise from medium to high and C1 to C3 become story-mapped
- Your own answers to the slots in F1, F2 and F3 → those rows regenerate with your words quoted in
- A tuesday-dossier.md from an earlier evaluation, if you have one → verified evidence and a prohibited-claims list that would replace the locally built one
