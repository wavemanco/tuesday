I'll read the reference files the skill requires before writing anything.
Your prep pack for the Saltmarsh Games Live Operations Producer interview is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-7-denied-f8cc53d4/saltmarsh-games_live-operations-producer_interview_pack.md`.

I couldn't research Saltmarsh Games, because the web searches were refused in this session. The pack rests only on your JD and what you told me, and I labeled anything that would have needed research `[generic]`. Your message didn't say who Tobias is relative to the role, so I built it for a hiring-manager round, assuming the job reports to him.

- **Where to start:** the highest-ROI rehearsal is B1, the in-app purchases question. You've said you've never worked on a game with in-app purchases, and a mobile live-ops interviewer is very likely to press on it. B2 and G1 reuse the same answer.
- **Other gaps:** your material shows you presented the retention numbers, not that you owned the post-event review or KPIs. It also shows one title and weekly content drops, where the JD says two titles and live events. The pack has answer slots for these, so you fill them in from what you actually did.
- **What's in it:** 20 questions across six interviewer styles, with answer guidance and rationale for each. It also has a fit snapshot against the JD, six claims it won't coach, reverse questions, and a prep triage sized to Friday.

Say the word and I'll play Tobias on B1 as a live drill, with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person the role reports to, a skip-level, or more of a peer conversation, and did the recruiter mention any format, focus areas or a task? The answer reweights every question bank.

If you can allow web search, want me to run a deeper research pass on the company's values, process and strategy, using up to 6 more searches and 2 more fetches and taking several more minutes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** one 60-minute interview, built as a hiring-manager round. The assumption is that the role reports to him; your note did not say.
**Research:** web search was refused in this session, so company values, process and strategy are not researched. Everything about Saltmarsh Games comes from your JD, and every question that would have needed research is labeled `[generic]`.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each question has a persona (its bank) and one type tag.
- **Type key:**
  - **EXP** — work-experience deep-dive: do your claims survive scrutiny, and what was actually you.
  - **JD** — role-driven: can you do the listed job, gaps included.
  - **CO** — company and domain knowledge: homework depth.
  - **CASE** — a live problem from the role: structure and reasoning.
  - **VAL** — values alignment. There is no VAL bank, because nothing documents a values round (see the persona table).
- **Guidance is scaffolding, not a script.** It names the beats your own sentences carry. Anything beyond them is an answer slot: an instruction to answer from your real experience, or to say plainly that it was not yours.
- **IDs.** Fit-snapshot rows are F1 to F9. Question banks are lettered A to E and G, skipping F so the letters do not collide with the fit rows.

## Prep triage

You have until Friday. In order:

1. Say B1 aloud three times, with its follow-ups. It is the highest-ROI rehearsal in this pack. B2 and G1 reuse the same plain acknowledgment, so they come for free.
2. Time the D1 arc to 90 seconds.
3. Write one honest line for each answer slot in F1, F2, F3, F4 and F7. Those lines are for you, and they decide what you can say under a probe.
4. Say A1 to A4 once each aloud, using the structure in the guidance. For A5, look at the studio's two titles before Friday, and name only what you actually looked at.
5. Choose three reverse questions from section 11. R1, R3 and R4 are the best fit for the gaps below.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material gives the years and the associate title. It does not say whether the title was a live-service game, or on mobile, and nothing inspected sits behind it, so the words stay at "4 years as an associate producer at a puzzle-game studio." Answer slot: the JD's live-service line makes a probe on what the title was likely. If it was a live-service game, or on mobile, say so in your own words; if it was not, or you are unsure how to describe it, say so plainly and stay with the weekly content-drop calendar you ran |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one title and content drops, where the JD says two titles and live events, and the words stay at the quote's scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: expect a probe on both differences. If the calendar ever covered a second title, or included events beyond drops, say how, in your own words; if not, say so plainly and stay with the one title's weekly calendar |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams your calendar work touched. Answer slot: the JD names four teams, so expect a probe on each. If you worked with any of design, art, engineering or community on a drop, say which and what your part was, in your own words; if you did not, or the work was not yours, say so plainly and return to the part of the work you did carry |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presenting the monthly retention numbers, with nothing about reviewing an event or owning the KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD raises the review, so expect a probe on it. If you ran or contributed to any review after a release or event, say what it covered and what part was yours; if there was no such review, or it was not yours, say so plainly and stay with the monthly presentation |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap on the checklist itself, but a line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: "I wrote the release checklist our QA team still uses." The quote says wrote, and the JD's verb is manage, so keep to wrote; the probe will come at that verb |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms, so lead with it: "I presented the monthly retention numbers to the studio head." Nothing inspected sits behind it, so expect a probe on how the figures were counted, which C1 rehearses |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A checklist a team still uses touches written work and does not show it reaches the JD's line, so this is the pack's derivation and only a lead. The words stay at "I wrote the release checklist our QA team still uses." Answer slot: expect a request for an example of your writing. If other written work was yours, say which, in your own words; if none was, say so plainly and stay with the checklist |
| F8 | Familiarity with in-app-purchase-driven live events — not in the JD; role-family expectation | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |
| F9 | Leading a team — not asked for in the JD, which says coordinate; role-family expectation | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never led a team." Then what the JD does ask, which is coordination, answered through F3's slot and never as a past you have not described |

## Persona table

The loop is one 60-minute session with Tobias, from your own words, so this is session mode and no archetype fallback is needed. No loop source documents a values-style round, so no VAL bank is built. Weights start from the hiring-manager prior (Case/Strategist and Skeptic). No interviewer information beyond a name and title exists, so nothing adjusts them.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: calendar clashes, a retention dip, a weak event review | High. The hiring-manager prior puts it first, and the JD is planning and coordination work that is natural to test as a live problem (F2, F3, F4). Bank A, 5 questions | Clarify, then objective, options, risks, metrics. Think aloud, challenge one premise respectfully, and make no claim about a past you have not described |
| Skeptic | Quiet, persistent probing of the gaps: purchases, team leadership, the associate title, the one-title calendar | High. The hiring-manager prior puts it second, and your own material states two gaps (F8, F9) and the associate title and one-title scope sit beside the JD (F1, F2). Bank B, 5 questions. B1 is the highest-ROI prep in the pack | Rehearse B1 until it is boring. Use bridges only from your own sentences, keep the limit in plain words, and give a concrete ramp plan |
| Data-Driven Prober | Reads the retention line closely and asks how the numbers were counted | Mid. The JD names retention metrics and KPIs (F4, F6), but nothing about the interviewer says he is analytics-led. Bank C, 3 questions | Say what you know about how the numbers were counted, and say plainly where you do not. Name the assumption you would defend least before he does |
| Conversational | A friendly opener such as "walk me through the journey", casual questions about the domain | Mid. A 60-minute manager conversation usually opens this way, and casual questions are still scored. Bank D, 3 questions | A 90-second arc built from your own sentences, and treat casual questions about live events as scored |
| Peer Evaluator | Seam questions between design, art, engineering and community | Low. He is assumed to be your manager, not a peer, but the JD's four-team coordination makes a seam question plausible (F3). Bank E, 2 questions | Reciprocity framing, and seam principles rather than a pretended knowledge of their seam |
| Pressure | Time-boxed or interrupting challenges aimed at the gaps | Low. Nothing signals a stress style, but one pressed probe on F8 or F9 is likely whatever the register. Bank G, 2 questions | Hold the position your sentences carry through two follow-ups, concede the specific gap plainly, never fold on what you did say |
| Values/Behavioral | Scenarios mapped to published values | Not detected. No loop source documents a values round and the values page was not researched. No bank | Upgrade menu: the recruiter's note or the values page would change this |

## Question banks

### Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A3, A5, B3, D1 |
| "coordinate design, art, engineering and community teams on each update" | A1, E1, E2, G2 |
| "own the post-event review and the KPIs it reports" | A4, C3, B2 |
| "manage the release checklist with QA" | B4 |
| "3+ years producing live-service games or apps" | B3, D1, G1 |
| "experience running a content calendar" | A3, B3, D1 |
| "comfortable with player-retention metrics" | A2, C1, C2, C3 |
| "clear written communication" | D3 |
| Not in the JD, likely asked: purchases and team leadership | B1, B2, G1, G2 |

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two weeks before an update ships, community tells you players are asking for an event design hasn't scoped. How do you decide whether it goes on the calendar?" | CASE | [generic] | Say your structure aloud. Clarify first: what the event is meant to move, what it would displace, which dates are fixed, what engineering and art would need. Then options (add it, defer it, a smaller version), who has to agree, the risk if it slips, and how you tell design and community. Challenge one premise respectfully, for example whether the player request is representative. End on the decision and the one thing you would check afterwards. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's calendar and update-coordination lines (F2, F3), asked as a decision. CASE because it scores structure; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "A live event ends and day-7 retention is down against the previous cohort. What do you want to know first, and how do you diagnose it?" | CASE | [generic] | Clarify before diagnosing: how day-7 is defined, which cohort it is compared with, whether the player mix and the period are comparable. Then segment, list the hypotheses (event design, a technical fault, a calendar clash, something outside the game) and say which data would separate them. State what you would refuse to conclude from one cohort, and name the assumption you would defend least. The guidance makes no claim about your past | Delivers the JD's retention line (F6) as a live problem, in the "diagnose the dip" shape a hiring manager uses. CASE because it scores structure and the weakest-assumption move, not a recalled fact |
| A3 | "You run the calendar for two titles. Both want a big event the same week and engineering can support one. How do you decide, and how do you tell the team that loses?" | CASE | [generic] | Clarify: what each event is meant to move, the fixed dates, what engineering needs, whether either can shift. State your criteria up front (player impact, readiness, risk, recoverability), and say who decides and who you recommend to, without claiming authority you have not been given. Tell the other team early, with reasons and a new slot, and write the decision down. The guidance makes no claim about your past | F2 is where the JD's two-title scope presses hardest. CASE because the scoring is the structure and the way you handle the team that loses |
| A4 | "An event finishes with half the participation the team forecast. Walk me through the review you would run and what you would report." | CASE | [generic] | Answer it as a plan, in the future tense, and say it is a plan: your material says presenting numbers, not reviewing events. Facts first (what was forecast and how, what happened), then causes (design, comms, timing, technical), what to keep and what to change, the few KPIs you would report and who reads them, and a written follow-up | The JD's post-event-review line is a requirement where F4's evidence reaches only the presenting. CASE with JD content, asked as a live problem so the honest answer is a plan |
| A5 | "What do you already know about our two titles, and what would you want to find out first?" | CO | [generic] | Name only what you have actually looked at before Friday, in your own words. If you have not looked, say so plainly and move to what you would want to learn: the event history and results, the release cadence, the fixed constraints, how each KPI is defined, who signs off. Do not claim to have played a title you have not | Homework depth is the point, and research was refused here, so the pack cannot supply facts about the titles. F2's two-title scope is why the question is likely. CO because it scores knowledge of the company and the questions you would ask |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A lot of mobile live-ops events sit alongside in-app purchase offers. Have you worked on that side of a game?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | **The highest-ROI rehearsal in this pack.** Open with the plain answer: "I've never worked on a game with in-app purchases." Then say what you did run: "For the last two years I ran the weekly content-drop calendar for our main title." Then the plan, said as a plan: in the first weeks you would ask for past event results, ask how offers are structured and who owns them, and ask how purchases are reported beside retention. Follow-up level 2, "How would you read an event's results without that background?": say you would not call a purchase result on your own yet, and who you would ask. Follow-up level 3, "Is that a dealbreaker?": concede that you cannot make the gap go away, then repeat what you would do first. Hold by returning to those sentences, never by adding to them | F8 is your own stated gap and the likeliest place a mobile live-ops interviewer presses; F2's mobile-title scope sharpens it. JD because it scores fit with the role's setting, although the JD itself does not name purchases |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head" | Choose one from your own material and say it plainly. Two are available: "I've never worked on a game with in-app purchases", or the review and KPI ownership, where your material says "I presented the monthly retention numbers to the studio head," which is presenting, not owning. Then what you would do in week one, as a plan. Do not dress a strength up as a weakness. If you choose purchases, keep it identical to B1 | The Skeptic stem, aimed at the rows where the evidence is thinnest (F4, F8). JD because it asks you to rank the listed duties against your own gaps |
| B3 | "You have been an associate producer. This job is a producer running two titles. Why is this the right next step?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say the beats your sentences carry, in your own words: four years as an associate producer at a puzzle-game studio, and for the last two years the weekly content-drop calendar for your main title. Answer slot: the JD says two titles, so expect a probe. If the calendar ever covered a second title, say how; if not, say so plainly and stay with the one title. Why you want the step is yours to say in your own words. Describe what you did and let the interviewer draw the inference | F1's title and F2's two-title scope are the two seams in this question. JD because it scores the stated years and calendar requirements |
| B4 | "You wrote the release checklist your QA team still uses. How much of it was yours?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold the quote at its scope: "I wrote the release checklist our QA team still uses." Then which parts were yours and which came from QA or others, said plainly in your own words. Answer slot: the JD says manage the checklist with QA, so expect a probe on running it at each release. If you did, say how; if you wrote it and others ran it, or there was no such routine, say so plainly and stay with having written it | F5 is a line with nothing inspected behind it, and the JD's verb is manage. EXP because it tests attribution |
| B5 | "Why this move, why here, why now?" | JD | [generic] | Three short parts, all in your own words: what you want to keep doing, what you want to do that you have not yet, and why this studio specifically. The pack supplies no reasons. Choose ones that are true and specific, and that you could only give after looking at the studio. If one part is still open, say so plainly | The Skeptic's motivation stem. `[generic]` because it carries no claim about your past or this employer; the JD tag is for role fit |

### C. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what the quote carries: you presented the monthly retention numbers to the studio head. Then the defend-the-number moves, each in your own words: how the figures were counted, what they were sensitive to, the assumption behind them you would defend least, and which part was yours. Where you do not know how something was counted, say so plainly rather than guess. Answer slot: the JD wants comfort with retention metrics, so if you built or defined any of the numbers, say how; if they came from someone else's reporting, say so and stay with presenting them | F6 and F4 rest on this one sentence, so it is the likeliest EXP probe. EXP because it tests how a figure you presented survives the follow-up |
| C2 | "Day-1 retention is up after a drop but day-7 is down. How do you read that?" | CASE | [generic] | Confirm the definitions and that the cohorts are comparable. Name the readings that fit (the event pulled people in and then ended, a change in the player mix, a fault) and the check that would separate each. Say what you would not conclude from one data point, and name your weakest assumption aloud. The guidance makes no claim about your past | Prober delivery of the JD's retention line (F6) as a live problem. CASE because it scores clarifying, structure and the weakest-assumption move |
| C3 | "Which KPIs would you put on a post-event review, and what would each one change?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Pick a few you can explain. For each, say the decision it informs and its limit, and say which ones you would ask the team to define first. The one place you have presented numbers is "I presented the monthly retention numbers to the studio head"; do not describe choosing KPIs unless you did. Answer slot: if you chose any KPIs for a review, say which and why; if none, answer as a plan and say it is a plan | The JD's KPI line sits on F4, where the material reaches only presenting. JD because it scores the stated KPI duty |

### D. Conversational (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc with four beats, each in your own words: four years as an associate producer at a puzzle-game studio; the last two years running the weekly content-drop calendar for your main title; writing the release checklist your QA team still uses; presenting the monthly retention numbers to the studio head. Close with why this role, in your own words. Add no "which taught me" line the sentences do not carry | The opener is scored whatever the register, and it is the one place all of F1 to F6 can be set out without being probed yet. EXP because it tests whether the CV's claims are told at their real scope |
| D2 | "What live events in other games have caught your eye lately?" | CO | [generic] | Choose one or two from games you actually play: what the event was meant to do, and what you would copy or not. If you do not play games with live events, say so plainly and name what you have looked at instead. Never name a title you have not seen | A casual domain question that is still scored. CO because it tests domain awareness; `[generic]` because it makes no claim about this employer |
| D3 | "How do you write an update for people who were not in the room?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Say what a good one holds, in your own words: the decision, what changed, who is affected, what happens next. For your past, the sentence is "I wrote the release checklist our QA team still uses." Answer slot: the JD wants clear written communication, so if other written work was yours, say which; if none was, say so plainly and stay with the checklist | The JD's written-communication line (F7) is the only requirement with no direct evidence, so it is likely to be asked casually. JD because it scores that requirement |

### E. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Engineering says an event is too big for the window; design says it can't be cut. Where is the seam, and what do you do?" | CASE | [generic] | Offer seam principles rather than pretending to know their seam: one shared definition of done for the event, a named owner for scope versus date, a smaller-version option, an escalation threshold, and the decision written down. Reciprocity framing: say what you bring each side, such as clear dates, options and a written decision, as well as what you need from them | The JD's four-team coordination (F3) as a seam problem. CASE because it scores how you split responsibility, and the guidance claims nothing about your past |
| E2 | "Tell me about a time work spanned several teams and the credit was not straightforward." | EXP | [generic] | Selection scaffold: pick a time with named teams, a moment where credit or blame was unclear, what you did, and how it ended. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A credit-sharing probe in the peer register, and F3's four teams make it likely. EXP because it asks you to choose a real instance; no sentence of yours carries a story for it, so the guidance is a scaffold |

### G. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why should we pick you over a producer who has already run live events on a mobile title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team, and never worked on a game with in-app purchases" | Pause and restate the question. Hold on what your sentences carry: "For the last two years I ran the weekly content-drop calendar for our main title, and I wrote the release checklist our QA team still uses." Concede the specific gap: "I've never worked on a game with in-app purchases," then what you would do first. Hold through two follow-ups by returning to those sentences; do not argue that you are better and do not add to them | The pressure version of B1, with the same limits (F2, F5, F8). JD because it scores your case against the listed role |
| G2 | "You have never led a team, and this role coordinates four. Convince me." | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Concede plainly: "I've never led a team." Then say what the JD asks, which is to coordinate those four teams. Answer slot: if you coordinated work with any of design, art, engineering or community, say which and what your part was; if not, say so plainly. Hold through two follow-ups without describing leadership in other words | F9 is your own stated gap, and F3 is where the JD presses on it. JD because it tests the coordination duty |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first quarter look like for this role, and how would you know I was on track?" | Turns the interview towards what success looks like to him, and gives you the ramp plan B1 and B2 depend on |
| R2 | "When two events want the same week, who has the final say today?" | Echoes the calendar duty in the JD (F2) and tells you where your authority would start |
| R3 | "Which KPIs does a post-event review report today, and what did the last one change?" | Shows the review duty (F4) is something you want to own properly, and learns how the KPIs are defined |
| R4 | "How does this role work with whoever owns offers and pricing on the two titles?" | Converts the purchases gap (F8) into a forward-looking question and shows you know where you need to learn |
| R5 | "Where do events most often get stuck between design, art, engineering and community?" | Echoes the JD's four teams (F3) and shows you think about the seams |
| R6 | "What would make you regret this hire in six months?" | Invites him to name his own doubts, which lets you answer them live |

## Prohibited claims

Not coached in any cell of this pack, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| Producer for four years, without the associate title | Inflated form of F1 | F1's quote at its own scope: "4 years as an associate producer at a puzzle-game studio." The limit is the pack's observation: the material says associate producer, and says nothing about live-service or mobile |
| Ran live events for two titles | Inflated form of F2 | F2's quote at its own scope. The material says one title and content drops; B3's slot stays inside that |
| Owned the post-event review and its KPIs | Inflated form of F4 | F4's quote at its own scope. The material says presenting the monthly retention numbers; A4 and C3 are answered as plans |
| Managed the release process with QA | Inflated form of F5 | F5's quote: "I wrote the release checklist our QA team still uses." The material says wrote; B4's slot stays inside that |
| Has worked on a game with in-app purchases | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never worked on a game with in-app purchases." No slot |
| Has led a team | Negative you stated, F9 | The plain acknowledgment F9 gives: "I've never led a team." No slot |

## Sources

Provided documents: the JD pasted in your message, and your background as written in your message. No dossier was present.

Searches sent, all refused (no result returned):

- `Saltmarsh Games values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games mobile studio strategy news` — refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Every call was refused. Would have moved the published values, and so whether a VAL bank and a values cheat sheet apply |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Every call was refused. Would have moved the loop structure and so the persona weights; they now rest on your words and the hiring-manager prior |
| 3. `Saltmarsh Games mobile studio strategy news` | unavailable | Every call was refused. Would have moved A5 and D2 from `[generic]` to a grounded company question |
| 4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` | unavailable | Every call was refused. Would have moved the interviewer read, the persona adjustments and an interviewer-tied reverse question, none of which exist in this pack |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search access, or the studio's published values page and any careers or interview page pasted in → the values question (whether a values round exists), the loop structure, and A5 and D2 moving from `[generic]` to a grounded company question
- A pasted summary of Tobias's public talks or writing, if any exists → a Reading-the-interviewer section, persona adjustments, and a reverse question tied to his own path
- The recruiter's note on format, focus areas or any task → coverage assumptions replaced by what they said, and a build section for any announced deliverable
- Your answers to the slots in F1, F2, F3, F4 and F7 → those rows move from `discovery` or `transferability` to evidence-backed rows, and their bank questions get story maps
- A redacted calendar, release checklist or retention deck → F2, F5 and F6 from `medium` towards `high`
- A short writing sample, for example a redacted update note → F7 from `low` towards `medium`
- A `tuesday-dossier.md` from earlier job-evaluation work → verified evidence and an evidence-derived objection to replace the pack's own inference; never a prerequisite
