I'll read the reference files the skill requires before drafting.
I've read the reference files. I'm building this as a three-round loop pack from the recruiter's email and saving it as a file.
Dara, your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-denied-79d93ffc/ashgrove_member-experience-lead_interview_pack.md`.

I built it as a three-round loop from the recruiter's email. Each round has its own persona weights, question bank and reverse questions. Interviewer names aren't assigned yet, so there's no interviewer read. I didn't search the web, because your pasted material already covered every research target. I have only the four points of the strategy brief as you summarised them, not the full document.

Your contact-centre gap is the likeliest objection, and C1 is the question to rehearse hardest. The guidance uses only your own sentences and gives you plain wording for the gaps you stated. The four values questions (G1 to G4) are scaffolds, not stories, because your message doesn't carry an episode for any of them yet. Real episodes from your work would fill them in; the upgrade menu says what to send.

Say the word and I'll play the Head of Member Services as the Skeptic on C1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Prepared:** 11 November 2026. **Mode:** loop, three rounds on 20 November 2026.

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 min | The first conversation |
| 2 | Head of Member Services (your future manager) | 45 min | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | Includes a 20-minute case on a complaint escalation; the panel also scores against the four published values |

Interviewer names are not assigned yet, so there is no interviewer read; each round is weighted from its role alone.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each round has its own persona weights, its own question bank and its own reverse questions. The fit snapshot, values sheet and prohibited list are shared.
- **Type key.** VAL: past behaviour against the published values. EXP: whether your own account of your work survives follow-ups. JD: the listed duties and requirements. CO: knowledge of Ashgrove's strategy. CASE: a live problem from the role.
- **Provenance labels.** `[grounded]` is traceable to something you or Ashgrove supplied. `[inferred]` is this pack's derivation from adjacent material. `[generic]` is a pattern with no claim about you or Ashgrove.
- **Guidance is scaffolding, not a script.** It uses only your own sentences, quoted in the Provenance column. An **answer slot** is an instruction for the interview, not a question to me: it names what an interviewer is likely to probe and gives two honest branches. If you did the thing, say how, in your own words. If there was no such step, or it was not yours, say so plainly and go back to what your sentences do say.
- Question IDs are letters plus a number. F is kept for fit-snapshot rows.

## Prep triage (nine days: 11 to 20 November)

| When | Do this | Tied to |
|---|---|---|
| 11 to 13 Nov | Rehearse the contact-centre objection aloud until it is boring. This is the highest-ROI prep in the pack | C1, B1, F2 |
| 11 to 13 Nov | Find real episodes for each value from your own work and write one plain sentence of what happened for each. No pack row can do this for you | G1 to G4, values sheet |
| 14 to 16 Nov | Practise the 20-minute case out loud, timed, with the structure in H1 | H1, H2 |
| 14 to 16 Nov | Settle your honest answers to the slots on the complaints log, the spreadsheet and the regulated-complaints probe | F4, F5, F6, D3, D4 |
| 17 to 19 Nov | Say the 90-second arc and the two plain acknowledgments (contact centre, presenting) until they are steady | A1, B1, B2 |
| 19 Nov | Choose your reverse questions for each round | Reverse questions |

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

No row is a gate: the JD's years requirement is experience, not a credential, so every row below carries a gap type from the ordinary six.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened around the log likely. If any stage beyond the log was yours to set, say which and how you decided, in your own words; if there was no such stage, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller. The pack's observation: the JD's requirements list does not name contact-centre experience, while its responsibilities line names the contact centre |
| F3 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Say it in the sentence's own terms: six years in retail banking, the last three as a branch supervisor. Your material does not say what the first three years held, so the bridge goes no further. Expect a probe on whether retail banking counts as customer operations; answer with the roles as they were |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Derived from the log being called formal; your material says a formal complaints log, not which rules governed it. Answer slot: the JD's regulated-complaints line makes a probe on how the log was governed likely. If anything beyond your own branch's wording, such as deadlines, a required response or a report to someone outside, governed how an entry was handled, say what, in your own words; if nothing did, or you did not know, say so plainly and stay with the log |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The monthly spreadsheet touches the JD's reporting line, and your material does not show what it counted. Answer slot: if asked what the spreadsheet counted, say, in your own words; if you do not know how a figure in it was counted, say so plainly and stay with the spreadsheet you built |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your material says a spreadsheet, not which tool. Answer slot: if asked which tool it was built in, name it; if it was not Excel, say so plainly and stay with what you built |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers, trained on a script, not supervisors coached on escalations, and the words stay there: "trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how the training landed likely. If you checked whether the tellers handled escalations differently afterwards, say what you saw; if you did not, say so plainly and stay with the training you gave |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare for a first leadership presentation, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here, and the strategy brief's 40% digital target makes the topic live. Answer slot: if you have worked alongside a digital or product team on anything members use, say what and which part was yours, in your own words; if not, say so plainly and answer as a plan |

## Grounding brief (from the strategy brief you supplied)

Only the four points in your message were available to me, not the full brief. It is dated July 2026, about four months old.

| Item | What the brief says | Provenance | How to use it |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | The anchor for E1, E2 and A3. Frame it as a question about what happens to complaints, not a prediction |
| Branch consolidation | Eight branches into five hubs over 2027 | [grounded] | Live for the branch-manager panel. Handle with care; see J2 and the Neighbours, Not Numbers value |
| New product | Small-business lending product in Q1 2027 | [grounded] | Not yet launched. Safe to mention once in A3; no complaints angle is in your material |
| Competition | Main competitive pressure is app-only banks | [grounded] | Gives H1 its stakes: a member with a bad experience has an easy way out |

## Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly opener; hot JD topics (Excel, the contact centre) asked casually | High. Recruiter screens start Conversational, and the email gives this round no format beyond "30 minutes with me" | A 90-second arc (A1); treat casual JD questions as scored; bring real reverse questions |
| Skeptic (light) | Knockout checks on the gaps you have stated: contact centre, presenting, years | Medium. Your message states two absences (F2, F8) and the JD names both areas | Plain acknowledgment, then a plan, in one breath; do not apologise and do not pad |

### Question bank, Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey in banking so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc whose first three beats are your sentences' own: six years in retail banking, the last three as a branch supervisor; the formal complaints log and the training on the escalation script; the monthly spreadsheet your regional manager uses. Tell them in your own words, with "I" only for what the sentences say you did. Beat four is an answer slot: why this role and why now. Say it in your own words, tied to something in the JD you want to do more of; if no single reason comes to mind, say so plainly and give the nearest true one | F3 is the years check and F1 holds the complaints work; EXP because a recruiter tests whether the CV story holds together aloud |
| A2 | "What drew you to a member-owned credit union?" | CO | [grounded] | The pack has no claim about you here, so the guidance makes none. Answer slot: say what draws you, in your own words. If you can honestly tie it to Ashgrove's published line "we decide from the member's side of the counter", do; if the member-owned model is not what drew you, say what did | A casual motivation question about the employer's own model, scored by a recruiter for genuine interest; CO because it tests what you know of Ashgrove, not what you did |
| A3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | About 60 seconds. Bring one item from the brief, not all four: the 40% digital target by 2028, or the eight-into-five hub plan over 2027. Then one question that is yours, such as what the shift means for how complaints reach the team. Frame it as a question, not a prediction, and hold it only if you hold it. Reciting all four reads as homework; one item plus a question reads as judgment | The grounding brief is the same source any prepared candidate has, so the pack steers to one item plus a divergence; CO because it tests company knowledge |
| A4 | "How are you with Excel these days? What are you building?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you built in the sentence's own words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if asked what the spreadsheet tracked or which tool it was built in, say, in your own words; if you do not know, or it was not something you did, say so plainly and stay with the spreadsheet you built | F5 and F6 are discovery rows: the quote touches the requirement and does not show how far it reaches. JD because it is the JD's Excel line, asked casually |

### Question bank, Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches. Where does your background sit against that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Plain acknowledgment first: "I haven't worked in a contact centre." Then what your material carries, at its own scope: "I handled the branch's formal complaints log." Then a plan in your own words, as intent and never as past: choose one or two first steps you would genuinely take, for example listening to live calls or reading closed contact-centre complaints. Do not say you have contact-centre experience or imply it | F2 is the stated absence and the likeliest knockout in a screen; the deep rehearsal sits at C1. JD because it scores the JD's own contact-centre wording |
| B2 | "Have you presented to senior leaders before?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan in your own words, such as asking what decision the leaders need the report to support and rehearsing it with someone beforehand. Say it once and stop. Do not suggest an earlier occasion that your sentence does not carry | F8 is a stated absence of a requirement the JD names; JD because it scores that requirement directly |
| B3 | "The role asks for four-plus years in financial-services customer operations. How does your time line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Use the sentence's own terms: six years in retail banking, the last three as a branch supervisor. Answer slot: if asked what the first three years involved, say in your own words; if you are unsure how your roles map to "customer operations", say so plainly and give the roles as they were | F3 is a presentation row: the evidence is there, in other terms. JD because it is the JD's first requirement |
| B4 | "Why this role, and why now?" | JD | [grounded] | No claim about your past is needed, so the guidance makes none. Selection scaffold: pick the one reason that is genuinely yours. Tie it to the JD's own wording (own the complaints process end to end; coach branch supervisors on escalations) and say why a credit union rather than a bank. If no single reason comes to mind, say so plainly and give the nearest true one | The motivation check a recruiter runs on every candidate; JD because the strongest answer sits in the role's stated duties |

### Reverse questions, Round 1

| Question | Why it lands |
|---|---|
| "For the panel, is the 20-minute case a scenario given in the room, or will there be material beforehand?" | The email does not say, and it changes how you prepare. A recruiter can answer it in one line |
| "The panel scores against the four values. Is there anything on how they score that I should know?" | Shows you read the email closely; the answer tells you whether to bring stories or just examples |
| "Who is on the panel, and are their names confirmed yet?" | Interviewer names are not assigned, so this is the one item that would sharpen the pack |

## Round 2: the Head of Member Services, your future manager (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the contact centre and the branch-to-process gap | High. A manager buying capability derisks gaps first, and your message states the contact-centre absence (F2) | Rehearse C1 until it is boring; calibrated candor, no bluff |
| Values / Behavioral | "Tell me about a time" prompts drawn from the JD's duties | High. The email says the round is "mostly behavioural" | Story-map from your quoted sentences where they carry a story; otherwise a scaffold with the honest branch |
| Case / Strategist | A live problem on the role's actual roadmap | Medium. The manager relationship favours it, and the email's "mostly behavioural" lowers it | Clarify, structure, think aloud, challenge one premise respectfully |

### Question bank, Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see a contact centre in your background. How would you handle the contact centre in this role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI rehearsal in this pack.** Hold: "I haven't worked in a contact centre." Then what your material carries, at its own scope: "I handled the branch's formal complaints log." Name the limit before it is asked for, in your own words, then a plan: choose two or three first steps you would genuinely take and say them as intent. Follow-up one, "What would you do in your first month?": give those steps and stop. Follow-up two, "Isn't this a requirement?": do not argue; the JD's requirements list names financial-services customer operations and regulated complaints, and you can leave that unsaid. Return to the plain acknowledgment and the log. Hold through both follow-ups by returning to the sentences, never by adding to them | F2 is the largest gap in the JD's headline duty and is stated in your own message, so this objection arrives in some form. JD because it scores the stated duty; the Skeptic delivery is how it is most likely asked |
| C2 | "You handled a branch's complaints log. This role owns the whole process across branches. What part of that have you owned yourself?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold only what the sentence carries: "I handled the branch's formal complaints log." Answer slot: if any stage beyond the log was yours to set, say which and how you decided, in your own words; if there was no such stage, or it was not yours, say so plainly and describe how you handled the log. Hold through two follow-ups by returning to the log, never by adding to it | F1 is where the JD's end-to-end wording presses hardest against your evidence; EXP because it tests attribution |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of the two gaps you have already stated and say it in one plain sentence: "I haven't worked in a contact centre." or "I haven't presented to anyone above regional level." Then the first thing you would do about it, as a plan. Do not invent a third weakness to look balanced, and do not say you have none | F2 and F8 are the stated absences; JD because the question is a read of the JD against you |

### Question bank, Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you helped someone handle an escalation they found hard." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The sentence carries two beats: new tellers, and the escalation script. Tell them in your own words. If a specific moment comes to mind, tell it and separate your part from theirs; if none does, say so plainly and describe how you trained the tellers on the script. Answer slot: the JD's coaching line makes a probe on how the training landed likely. If you checked whether the tellers handled escalations differently afterwards, say what you saw; if you did not, say so plainly and stay with the training you gave | F7 is the nearest evidence to the JD's coaching duty; EXP because it tests what was actually yours |
| D2 | "Tell me about a time you had to give someone more senior than you news they did not want." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Selection scaffold: pick a time with a named stake, a moment you did not fold and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I built the monthly complaints spreadsheet our regional manager uses.", at its own scope, or how you would handle it | F8 raises presenting to senior leaders, and your material has no sentence for this story, so the pack gives a scaffold; JD with behavioural delivery |
| D3 | "Tell me about the monthly complaints spreadsheet. What did it show, and who used it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The sentence carries three beats: monthly, complaints, and the regional manager as its user. Tell them in your own words. Answer slot: what the spreadsheet counted, how a figure in it was counted, which assumption you would defend least, and what part was yours. If you do not know how a figure was counted, say so plainly and stay with the spreadsheet you built | F5 and F6 are discovery rows; a prober will go straight to what was counted, and "I don't know how that figure was counted" is an honest branch |
| D4 | "Tell me about a complaint where the rules mattered. What did you do?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt: choose the instance. The sentence carries one beat, the formal complaints log, so tell that in your own words. Answer slot: if anything beyond your own branch's wording, such as deadlines, a required response or a report to someone outside, governed how a complaint was handled, say what, in your own words; if nothing did, or you did not know, say so plainly and stay with the log | F4 is a discovery row: the JD says regulated complaints and the quote says formal complaints log. JD because it scores that requirement |

### Question bank, Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We want 40% of member service on digital channels by 2028. What happens to complaints as that shifts? What would you want to know first?" | CASE | [grounded] | No claim about your past is needed, so the guidance makes none. Clarify first, as questions: where complaints arrive today by channel; what counts as resolved; who holds a case when a member moves from self-service to a person. Then objective, segmentation, approach, metrics, risks. Say the structure aloud before using it, and challenge one premise respectfully, such as whether a falling count of digital complaints means members are happier | The brief's 40% target is the live strategy item for this manager; CASE because it asks for structure on a real roadmap question, with CO content |
| E2 | "How would you work with the digital teams on a self-service complaint journey?" | JD | [grounded] | Answer as a plan, in plain words: what you would bring (what members actually complain about) and what you would ask of them. Answer slot: if you have worked alongside a digital or product team on anything members use, say what and which part was yours, in your own words; if not, say so plainly and answer as a plan | F9 has no evidence given, and the brief's digital target makes the probe likely; JD because it is the JD's digital-teams line |

### Reverse questions, Round 2

| Question | Why it lands |
|---|---|
| "What would a good first 90 days look like, especially on the contact-centre side where I would be starting from outside?" | Turns the stated gap into a plan conversation instead of leaving it for them to raise |
| "How do complaints travel between branches and the contact centre today, and where do they tend to stall?" | Shows you think in process terms and gives you the real picture of F1's "end to end" |
| "With 40% of member service moving to digital by 2028, what should the complaints process look like in three years?" | Ties your question to the published strategy and invites their view rather than reciting the brief |
| "Who are the digital counterparts I would work with on self-service journeys, and what is already in flight?" | Names the F9 area directly and asks what the real starting point is |
| "What does the monthly complaints report look like now, and who reads it?" | Tells you what F5 and F6 will mean in practice, and who the senior audience is (F8) |

## Round 3: the panel of two branch managers (60 minutes, including a 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Prompts mapped to the four published values | Highest. The email says the panel scores against the four values | One real story per value where your sentences carry one; a scaffold with the honest branch where they do not |
| Case / Strategist | The 20-minute complaint-escalation case | High. The email documents the case | Clarify, structure, think aloud, use the values as your vocabulary |
| Peer Evaluator | Where your job meets a branch manager's; credit; disagreement | Medium. Branch managers sit beside a role that coaches branch supervisors; this rests on the JD's coaching line and the relationship, not on anything about these two people | Propose seam principles instead of pretending to know the seam; reciprocity framing |
| Conversational | Warm opener and close | Low. It is a scored round, so the opener is brief | A short arc (A1) and real reverse questions |

Per-member personas are not assigned because names are not known; the bank blends the top personas for the round.

### Question bank, Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Members First, Always. Selection scaffold: pick a time with a named member situation (no identifying details), the easier option, what you chose, what it cost and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the formal complaints log, at its own scope, or how you would handle it | The published value is the raising source; the material has no sentence carrying a member-side decision, so this is a scaffold. VAL because it scores the first value |
| G2 | "Tell me about a time something you or your branch wrote or said had to be explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Plain Words. One beat is the sentence's own: training new tellers on the escalation script. Answer slot: if you ever changed the wording of the script, or of anything a member read, because it needed explaining twice, say what and what changed; if you did not write it or never changed it, say so plainly and stay with the training you gave | F7 is the nearest evidence; the quote shows the script and the tellers, not any change of wording. VAL because it scores Plain Words |
| G3 | "Tell me about a time you weighed what the numbers said against what one branch or town needed." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Neighbours, Not Numbers. Selection scaffold: a named branch or community, the number that pointed one way, what you weighed, what you did and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the formal complaints log, at its own scope, or how you would weigh it. Tone matters with branch managers; do not set branches against numbers | The brief's hub plan makes this value live for a branch-manager panel; the material has no sentence for it, so it is a scaffold |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Own the Fix. Selection scaffold: a named problem, the point you could have passed it on, what you did, how it ended and how you know it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log.", at its own scope, or how you would keep hold of one | The JD's end-to-end duty and the value are the same idea, so this is likely; scaffold because the log sentence shows no problem followed through |

### Question bank, Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member's complaint has gone between the branch and the contact centre twice and they are talking about moving to an app-only bank. Walk us through what you do." | CASE | [generic] | No claim about your past, so the guidance makes none. You have 20 minutes, so spend the first few asking: what the complaint is about; how long it has run; what the member has been told; whether any formal deadline is running; who holds it now. Then objective: the member's problem solved, with one named owner. Segment: service failure, product problem or misunderstanding. Approach: take it today, in plain words, confirm what happens next and by when, bring the branch supervisor in rather than taking the case away. Metrics: time to resolve, repeat contacts. Risk: what the formal clock requires. Close the loop with the member. The actual case may differ; the structure transfers | The panel case is documented in the email and the actual scenario is unknown; CASE because it asks for structure on a live problem |
| H2 | "The same complaint shows up in three branches in one month. What do you do?" | CASE | [generic] | No claim about your past. Separate the single case from the pattern. Clarify: the same product, process or branch? Who needs to know? Then what you would count and report, how you would coach the supervisors involved, and what you would hand to the digital team as a self-service fix. Challenge one premise respectfully: is this a pattern or one bad week? | A natural second variant of H1 that exercises the JD's reporting, coaching and digital duties together; CASE |

### Question bank, Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You would coach our branch supervisors on escalations. Where is the line between your job and ours, and what happens when we disagree?" | JD | [grounded] | Propose seam principles, in your own voice, as how you would want to work; use only those you would stand behind. Options: a complaint has one named owner at a time; day-to-day calls on the member stay with the branch unless escalated; you coach, report and chase and do not take cases away. Answer slot: if you have disagreed with a peer or manager over an escalation, say what and how it ended, in your own words; if not, say so plainly and say how you would handle it | The JD's coaching duty puts you beside branch managers; JD with peer delivery |
| J2 | "We are going from eight branches to five hubs next year. What do you think that does to complaints, and to our supervisors?" | CO | [grounded] | Do not claim to know. Ask: who holds the open complaints at a branch that merges; how supervisors will be supported through the change. Tie it to Neighbours, Not Numbers, and avoid sounding as if you are measuring branches. Offer to listen first, then propose one thing you would check | The brief's consolidation plan is the strategy item closest to a branch panel's work; CO because it asks for fluency at Ashgrove's altitude, handled with care |
| J3 | "You built the monthly spreadsheet your regional manager uses. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if others contributed data, design or requests, say who did what; if it was only yours, say so plainly. Hold through two follow-ups by returning to the sentence, never by adding to it | A peer attribution probe on the one deliverable your material names; EXP because it tests what was yours |

### Reverse questions, Round 3

| Question | Why it lands |
|---|---|
| "What could a new complaints lead do in their first month that would genuinely help your branch?" | The reciprocity question: it shows what you would bring them, not only what you need |
| "As branches move into hubs, what do you most want the complaints process to protect?" | Invites their view on the change with respect and ties to Neighbours, Not Numbers |
| "When an escalation from your branch has gone well, what made the difference?" | Asks for their best case rather than a complaint; useful material for H1 and J1 |
| "What would you want a complaints lead to tell you that a spreadsheet would not?" | Signals you see past the report (F5) to the member's side |
| "What does keeping hold of a complaint look like when it crosses your branch and the contact centre?" | Uses Own the Fix as your vocabulary and surfaces the contact-centre seam |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B1, C1, C2, H1 |
| The contact-centre side specifically | B1, C1, C3 |
| Report monthly on complaint volumes and resolution times | D3, H2 |
| Coach branch supervisors on escalations | D1, J1 |
| Work with digital teams on self-service journeys | E1, E2 |
| 4+ years in financial-services customer operations | A1, B3 |
| Experience handling regulated complaints | D4, H1 |
| Confident presenting to senior leaders | B2, C3, D2 |
| Comfortable with Excel reporting | A4, D3 |

## Values cheat sheet

A values-style round is detected: the recruiter's email says the panel scores against the four values. Names are as published on ashgrovecu.org/about/values.

| Value | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No story carried. Scaffold at G1, ending in its honest branch |
| Plain Words | If a member needs it explained twice, the wording is wrong | F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." One beat, the tellers and the script, then the answer slot at G2 |
| Neighbours, Not Numbers | Every branch is part of its town | No story carried. Scaffold at G3, ending in its honest branch |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No story carried. Scaffold at G4, ending in its honest branch |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says one branch's log, not a process across branches. C2's slot stays inside the log |
| Has worked in a contact centre, or handled contact-centre complaints | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." Then a plan. No slot |
| Handled regulated complaints to an external standard | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a formal complaints log, not which rules governed it. D4's slot asks only how the log was governed |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: "trained new tellers on our escalation script." D1's slot asks only how the training landed |
| Reported complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." D3's slot asks only what the spreadsheet counted |
| Presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan. No slot |

Not listed: digital-team work (F9) and the spreadsheet's tool (F6). Your material is silent on both, so they are answer slots rather than prohibited claims.

## Sources

Provided documents: the JD as pasted; the values text copied on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; the four points of the July 2026 strategy brief as summarised in your message; your background as described in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted fixes the values sheet and the VAL bank |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the sessions, who runs each and what each holds, so it fixes the persona weights and the loop |
| 3. `Ashgrove Credit Union strategy` | skipped | The brief's four points, about four months old, fix the grounding brief and the CO and CASE questions |
| 4. interviewer name and company | n/a | No names have been assigned, so there is no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

No searches or fetches were sent.

## Upgrade menu

- Interviewer names once assigned: an interviewer read, persona weights tuned from their public professional footprint, and a reverse question tied to their own path
- One real episode from your own work for each of the four values, in a sentence or two (what happened, what you did, how it ended): G1 to G4 move from scaffolds to story-mapped rows, and the values sheet fills in
- What your branch's complaints log was governed by, and what the monthly spreadsheet counted and was built in: F4, F5 and F6 firm up, and D3 and D4 become sharper rehearsals
- Whether you have worked alongside a digital or product team: F9 and E2
- Whether you have presented at regional level or below, and what that was: F8 and B2 get more honest context
- The recruiter's answer on how the 20-minute case is given, and whether there is material beforehand: H1 matches the real format
- The full text of the July 2026 strategy brief: the grounding brief moves from four points to the document, and E1, J2 and A3 sharpen
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): current context on app-only competition, recent organisational news, and reports on similar loops
- A `tuesday-dossier.md` from an earlier evidence review, if you have one: verified evidence, graded gaps and prohibited claims that would tighten every guidance cell
