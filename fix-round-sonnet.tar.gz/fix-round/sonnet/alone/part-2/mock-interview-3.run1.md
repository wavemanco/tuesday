I'll read the skill's reference files before building the pack.
Quick status: the web searches I tried were denied, so I'm building the pack from what you've told me and labeling anything I couldn't verify. I'm writing the pack file now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-3-denied-769de0cb/stripe_product-operations-manager_interview_pack.md`.

It is built on three assumptions, so treat it as a rough first version:
- **No research.** My four web searches were denied, so nothing in it is verified about Stripe. That means no Stripe values cheat sheet, no documented interview loop and no strategy facts.
- **No JD or CV.** The fit rows are blank worksheet rows with selection scaffolds, not your quoted experience.
- **Unknown interviewer.** I assumed the final round mixes conversation styles, so the persona weights are broad rather than tuned.

It has 21 practice questions across seven interviewer styles (case, skeptic, values, data-prober, peer, pressure, conversational). It also has reverse questions, a requirement-coverage table and an upgrade menu. If you only rehearse one thing, rehearse B1, "Which part of this role would you be weakest at on day one?" The pack can't see your gaps yet, so it can't name your specific weak spot.

Say the word and I'll play the Skeptic on B1 live, then give you feedback.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in this round (hiring manager, peer, cross-functional, skip-level), and did the recruiter mention focus areas or something to prepare in advance? This reweights every question bank.
2. Can you paste the job description and a few lines of your background, or would you rather I proceed without them? Either would turn the worksheet into real answer maps.
3. Do you meet the role's work-authorization and location requirements? The pack flags this as a gate it can't assess from what I have.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager: final-round interview pack

Company: Stripe. Role: Product Operations Manager. Round: final round. Interviewer and relationship: not given. Built on the assumption that the final round blends more than one conversation style, so persona weights are broad rather than tuned. No JD, no CV and no research results were available, so every fit row is a worksheet row and every question is a rehearsal pattern, not a claim about Stripe or about you.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, worked aloud |

Provenance labels: `[grounded]` traces to something you provided or to cited research, `[inferred]` is a derivation from a representative source, `[generic]` is a role-family pattern with no claim about Stripe or about you. Everything in this pack is `[generic]`, because the only inputs were the company, the role title and the round.

## Fit snapshot (worksheet variant)

No CV or background was provided, so every evidence cell reads `none given`. No JD was provided and the research that would have fetched a representative one did not run, so the requirements below are role-family prose, not quotations. Each row holds what strong evidence would look like, then a selection scaffold that ends in its honest branch.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Work authorization and location or in-office schedule for the role's base office (role-family term, no source) | none given | none | [generic] | hard_gate | Your material does not establish this. It is a term you meet or do not, so no wording changes it and this pack coaches nothing on it. The message presenting this pack asks whether it is met |
| F2 | Coordinating launches or programs across product, engineering and go-to-market teams (role-family prose) | none given | none | [generic] | discovery | Strong evidence would be a named launch or program, the teams involved, what you personally coordinated and what you left to others. Selection scaffold: pick a time several teams had to land one thing together; it needs a named stake, a point where it could have slipped, and your own part stated precisely. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Designing and running operating rhythms such as planning, reviews and launch-readiness checks (role-family prose) | none given | none | [generic] | discovery | Strong evidence would be a recurring process, who used it, and what changed because of it. Selection scaffold: pick a process you set up or improved; it needs what was broken, what you changed, and how you knew it helped. If no such process comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Defining and tracking product or launch health metrics (role-family prose) | none given | none | [generic] | discovery | Strong evidence would be a metric you defined or reported, how it was counted, and a decision it informed. Selection scaffold: pick a metric you were accountable for; it needs how it was counted, what it is sensitive to, and the assumption you would defend least. If no such metric comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Clear written and executive-level communication of status and tradeoffs (role-family prose) | none given | none | [generic] | discovery | Strong evidence would be a document or update you wrote and the audience that acted on it. Selection scaffold: pick one piece of writing for senior readers; it needs the decision it supported and what you cut. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Turning customer, sales and support feedback into product input (role-family prose) | none given | none | [generic] | discovery | Strong evidence would be a feedback channel you used or built and one product decision it touched. Selection scaffold: pick a time feedback from outside the product team reached it; it needs the source, the path it took, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Influencing teams you do not manage and working through ambiguity (role-family prose) | none given | none | [generic] | discovery | Strong evidence would be a case where you moved a group without authority over it. Selection scaffold: pick a time you needed agreement from people who did not report to you; it needs the stake, the mechanism you used, and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 work authorization and location | — none, and why: it is a gate the candidate meets or does not, so it is surfaced and not rehearsed |
| F2 cross-team coordination | A1, B3, C3, E1 |
| F3 operating rhythms | A2, E1 |
| F4 metrics | A3, D1, D2, D3 |
| F5 written and executive communication | C1, C3 |
| F6 feedback loops | A4, C2 |
| F7 influence and ambiguity | B3, E2, E3 |
| Motivation and company interest | B1, B2, B4, F1, F2, G1, G2 |

## Persona table

No loop source established this company's rounds, so the weights rest on a generic pattern and not on Stripe's documented process. The relationship to each interviewer is unknown, which makes every weight a prior.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems: plan this launch, diagnose that metric | Higher. The hiring-manager relationship prior tilts here, and this is the round-type prior only, not a fact about Stripe's loop | Clarify, then objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of gaps and motivation | Higher. Same hiring-manager prior; a final round is where gaps get tested | Rehearse the one predictable objection until it is boring; bridge only from what you actually did; give a ramp plan |
| Data-Driven Prober | Line-by-line scrutiny of any number | Medium. A peer or specialist conversation brings it; metrics are a core part of the role | Know how each figure you cite was counted, and say plainly when you do not know |
| Values / Behavioral | Stories scored against the company's principles | Medium. Cross-functional interviewers bring it; Stripe's published principles were not retrievable, so these questions use stock themes | Choose stories where the hard truth landed; say so where your material shows none |
| Peer Evaluator | Seam-splitting, credit, collaboration | Medium. Likely if one session is with a teammate | Propose seam principles; frame what you bring their team |
| Pressure | Interruptions, time-boxing, motive questions | Lower. A skip-level or executive slot brings it | Pause, restate, hold through two follow-ups before conceding anything real |
| Conversational | Friendly but scored | Lower. Present in some form in any round | Prepared 90-second arc; treat casual questions as scored |

## Question banks

Every question below is a rehearsal pattern. None presupposes anything about your past; where a question asks for a story, the guidance is a selection scaffold with its honest branch.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A cross-team launch is two weeks out. Three teams each report green, but the team that will support it has not seen the materials. What do you do in the first 48 hours?" | CASE | [generic] | Clarify first: what green means for each team, who is accountable for support readiness, which date is fixed and which is flexible. Then objective, the readiness dimensions as segments, the actions in order, the signals you would check daily, and the risks. Challenge one premise aloud, for instance whether green is defined the same way across the three teams. Makes no claim about your past | Tests the coordination core of F2 in a live form; CASE because it scores structure, not history |
| A2 | "Design the operating rhythm for a product organization with many teams shipping at once. What would you set up, and what would you deliberately not create?" | CASE | [generic] | State the goal of the rhythm before any meeting or document; name two or three artifacts at most; give the test you would use to retire one. The not-create half is where judgment shows, so give one real example and its reason. Makes no claim about your past | F3 is the requirement most specific to this role family; the not-create half tests restraint |
| A3 | "A key adoption metric for a recently launched feature drops 20 percent week over week. Diagnose it." | CASE | [generic] | Clarify definition, time window and segments first; check instrumentation and counting before real-world causes; then separate internal changes from external ones; end with what you would tell stakeholders today and what you would not yet claim. Makes no claim about your past | Persona stem for the Case style; scores F4 under time pressure |
| A4 | "Sketch how you would turn customer and sales feedback into product decisions. What do you need to know first?" | CASE | [generic] | Ask what feedback exists today, who reads it, and what decisions it should change; then propose a loop with an owner, a cadence and one measure of whether it works. Name one risk, for example volume drowning signal. Makes no claim about your past | F6 in live form; the clarify step is what is scored |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Pick the F row where your own material is thinnest, name it in one sentence, then give a concrete ramp plan: who you would learn from, what you would read, what you would deliver in the first weeks. Hold the answer through two follow-ups; concede specifically what you do not yet know and do not retreat to a different strength. Say only what is true of you | The pack cannot see your gaps, so it cannot name your particular objection; this question is the form that objection takes in some wording. Rehearsing it until it is boring is the single highest-return prep |
| B2 | "Why Stripe, why product operations, and why now?" | EXP | [generic] | Three short beats, each from your own reasons: what draws you to this company, what draws you to this kind of work, and what makes the timing right. Each beat should be something you can back with a specific you actually read, used or did. If a beat is thin, say so plainly and give the part that is true | Motivation consistency is the Skeptic's main scoring axis; no research ran, so the pack supplies no company facts for you |
| B3 | "Product operations does not own the roadmap. Why would a team listen to you?" | JD | [generic] | Selection scaffold for F7: pick a time you needed agreement from people who did not report to you; it needs the stake, the mechanism you used, and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Then name one principle you would use, such as making decisions easier for the teams | Influence without authority is the part of F7 a skeptic doubts most |
| B4 | "I don't see experience with a specific part of this role in your background. How would you handle it here?" | JD | [generic] | The honest structure: name the part in your own words, say what you do bring that is adjacent and what you do not, then give a ramp plan. Never claim experience you cannot walk through. Only say you lack something if that is actually true | Persona stem; tests whether your story survives cross-examination |

### C. Values / Behavioral

Stripe's published principles were not retrievable in this run, so these questions use stock themes and the pack does not map them to named values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the news was unwelcome; it needs who the audience was, what you said and how, and what happened to the relationship. Use we for context and I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; also touches F5 |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time the customer's need and a team's number pulled apart; it needs the tradeoff, the call, and the cost you accepted. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; links to F6 |
| C3 | "A senior leader asks you to report a launch as on track when your data says it is not. What do you do?" | VAL | [generic] | A live problem, so no past is claimed. Structure: what you would check first about your own data, how you would raise it and to whom, what you would offer instead of a bare no, and the line you would not cross. Hold your position through a push | Tests candor under pressure in a scenario rather than a story; touches F2 and F5 |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "If you have reported a headline number in past work, walk me through how it was counted." | EXP | [generic] | Answer slot: say how it was counted, what it is sensitive to, and which part was yours, in your own words; if you do not know how it was counted, or it was not yours, say so plainly and return to what you do know | Defend-the-number slots for F4; the honest branch is a limit and not a confession |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption in your own words before being pushed; converting a gotcha into a credibility gain. If you do not know the assumption, say so plainly. Asked as the follow-up to D1 | The weakest-assumption move; EXP because it tests attribution honesty |
| D3 | "How would you know whether product operations is working at all?" | JD | [generic] | Name one outcome the function should change, one leading signal, one lagging signal, and the failure mode of each metric. Say what you would not measure and why. Makes no claim about your past | F4 as a design question; the failure mode is where the Prober pushes |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a map you cannot know: who decides, who is consulted, how a disagreement gets escalated. Ask what the current seam is before proposing one. Makes no claim about your past | Persona stem; touches F2 and F3 |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a piece of shared work; it needs who contributed what, how credit was named, and your part stated precisely. If no such work comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; F7 |
| E3 | "What could you do in your first month that would actually reduce my team's load?" | JD | [generic] | Reciprocity framing: lead with what you would take off their plate and how you would learn the work first, not with what you need. Name one concrete first-month deliverable you could stand behind | Peer interviewers price what a hire costs them; F7 |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | EXP | [generic] | Pause, restate the question, then give two things you can back with specifics you actually have; do not disparage an unseen candidate. Time yourself at under 60 seconds | Persona stem; scores composure |
| F2 | "Whichever result you lead with today, how much of it was actually you?" | EXP | [generic] | Hold-then-concede: state your part precisely, hold it through two follow-ups, concede specifically what others did. If a figure is involved, the slots are how it was counted and which part was yours. Say only what is true | Persona stem; attribution honesty |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in your own words: where you started, the move that made product operations the logical next step, and why this role now. Build it from sentences you can back; rehearse it aloud twice | Persona stem; the opening biography is scored for economy |
| G2 | "What have you been using or reading about our products lately?" | CO | [generic] | Say only what you actually used or read, and what struck you. This pack ran no research, so it supplies no company facts; add your own homework here before the interview. If you have done none, say so plainly and ask what the interviewer would point you to | Casual questions on hot topics are scored; no strategy research ran, so this CO question is generic |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would success look like in the first 90 days for the person in this seat, and how would you know?" | Shows you think in outcomes and sets up how you will be measured |
| R2 | "Where is the line between what this role owns and what it only influences?" | Surfaces the influence-without-authority reality directly |
| R3 | "What part of this role is least well defined right now?" | Signals comfort with ambiguity and tells you where you would start |
| R4 | "What would the best version of this role have changed over the last year?" | Gets the interviewer to describe the real problem the role exists to solve |
| R5 | "Which team's work would you most like product operations to make easier?" | Shows you think of the role as service to other teams |
| R6 | "If you are a peer: what could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer interviewer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No CV sentences exist to inflate, you have stated no negatives, and no dossier was present; a requirement your material is silent on is an answer slot, not a prohibition | Every answer in this pack is a scaffold you fill from what you actually did |

## Sources

Provided documents: your message (company, role title, final round). No dossier, JD or CV was provided.

Searches sent, all refused by the host permission setting, none returned anything:

- "Stripe operating principles values" — refused
- "Stripe interview process product operations manager" — refused
- "Stripe strategy 2026 annual letter news" — refused
- "Stripe Product Operations Manager job description" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have fed the values cheat sheet (section 10) and named principles for VAL questions; the cheat sheet is dropped and C1 to C3 use stock themes |
| 2. Stripe interview process, product operations | unavailable | Would have fixed the loop and the persona weights; weights now rest on a generic pattern |
| 3. Stripe strategy and recent news | unavailable | Would have grounded the CO and CASE bank and a grounding brief; both stay generic |
| 4. Interviewer name | n/a | No name was given, so no query could be formed; no interviewer read |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the role-family rows into quoted, inferred requirements |

## Upgrade menu

- Job description text → F2 to F7 become quoted requirements and the JD-tagged questions become `[grounded]`
- Your CV or a few lines on your background → the worksheet becomes a real fit snapshot with your sentences quoted, and the scaffolds become story-mapped answers
- Round type, interviewer names and the schedule, plus anything the recruiter said about focus areas or a deliverable → persona weights tuned to each session, a Reading the interviewer section, a reverse question tied to their path, and a build section for any announced deliverable
- Whether you meet the role's work-authorization and location terms → settles F1
- Permission to search the web → Stripe's published principles, the documented loop, recent strategy and a representative JD replace the generic rows; a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, would add a strategy brief and loop reports
- A tuesday-dossier.md from earlier evidence work, if you have one → verified claims and prohibited-claims constraints on every answer
