I'll read the reference files before building the pack.
Status: the pack is written and saved. I'm fixing one awkward line in A2, then I'll send it to you.
Yusuf, your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-6-denied-3de66a92/larkfield-systems_engineering-manager_interview_pack.md`.

It is built as a three-round loop: one shared fit snapshot, then a mini-pack for each round. Each mini-pack has its own persona weights, 10–11 questions and 5 reverse questions.

- **Built on:** the role description and the four sentences about yourself that you wrote. I haven't seen the full job description or your CV.
- **Research:** the three web searches I tried were refused, so nothing in the pack is a fact about Larkfield beyond what you told me. That means no values cheat sheet, and the company-strategy question (J1) is generic. I didn't retry.
- **Highest-ROI prep:** A2, the "you've never owned a hardware-adjacent roadmap" objection, rehearsed through three follow-ups. Do that first.
- **Tuesday:** a Skeptic plus live-problem Director, with your two stated gaps and your two numbers (the 60% on-call drop and the ~40 interviews) as the likeliest targets.
- **Thursday:** the staff engineers will mostly be Peer and Prober, and the PM will probe pushback and partnership.
- **Monday:** a values round for the VP, anchored on your reliability quarter, with "unpopular truth" and "leadership philosophy" questions.

Say the word and I'll run a live drill, with me playing the Director on A2 or any other question you pick.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, I'll convert it.

1. Has the recruiter given any focus areas or a take-home or presentation for Tuesday or Thursday, and do you know the panelists' names or titles?
2. Can you paste the full JD and your CV? I can go on without them, but with them the weaker snapshot rows (F2, F4, F6) could gain real evidence.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack (loop mode): Engineering Manager, Larkfield Systems

Candidate: Yusuf. Three scheduled rounds, one shared fit snapshot, one mini-pack per round.

| Round | Slot | Who and what you told me | Relationship |
|---|---|---|---|
| 1 | Tuesday, 45 min | Hiring manager, a Director of Engineering, your would-be boss | Manager |
| 2 | The Thursday after, 60 min | Panel: two staff engineers and a product manager | Panel (peers and cross-functional) |
| 3 | The following Monday, 30 min | VP Engineering; the recruiter's description: "values and leadership philosophy" | Skip-level, values-style |

Built on this assumption: the role description you pasted is the whole of what I know of the JD, and the four sentences you wrote about yourself are the whole of what I know of your background. Research searches were refused in this session (see Sources), so nothing here rests on facts about Larkfield beyond what you told me.

## How to use this pack

- Personas describe how a question arrives; types describe what it scores. Rehearse both.
- Type key: VAL = behavioral or values alignment; EXP = work-experience deep-dive; JD = role and JD-driven; CO = company and strategy knowledge; CASE = hypothetical or live problem.
- Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- An "answer slot" is an instruction for the live interview, not a question to me: it names where the interviewer will probably probe and gives you two honest branches. Fill it from your own experience, or say plainly it was not yours.
- Highest-ROI prep in the whole pack: **A2**, the hardware-adjacent roadmap objection. It is asked in some form by almost any interviewer on this role, you have already named it as a gap yourself, and the JD names hardware partnership explicitly. It gets the deepest rehearsal below (three follow-up levels). Rehearse it first and rehearse it until it is boring.

## Shared fit snapshot

Requirements are quoted from the role description you pasted (a summary, not the full JD). Evidence is your own sentences, verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message (role description) | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material says team lead of 6, not two squads, and the pack observes that it does not say whether the six reported to you or what the domain was beyond payments. Words stay at that scope: "For three years I was a team lead of 6." On managers, the plain acknowledgment you gave is usable if asked: "I've never managed managers." Answer slot: the role says two squads, so expect a probe on what being team lead of 6 covered. Say which parts were yours, in your own words; if some were not yours, or the role did not include them, say so plainly and stay with the team lead of 6 |
| F2 | "own delivery, hiring and growth for 11 engineers" (delivery strand) — your message (role description) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | A reliability quarter pushed through is not the same as owning a team's delivery, and your material does not show which. Answer slot: if you were accountable for your team's delivery, say what that covered, in your own words; if you were not, or it was shared, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (hiring strand) — your message (role description) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap on the requirement's own words, but a self-reported line with nothing inspected behind it, so expect a probe on the number. Lead with the loop in the quote's terms: you run the hiring loop for backend roles. The number raises the defend-the-number slots: how the 40 was counted, what it is sensitive to, the assumption you would defend least, and how many of those interviews were yours |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth strand) — your message (role description) | none given | none | [grounded] | discovery | Your material does not show anything about growing engineers, and that is silence, not a stated absence. Answer slot: if any part of a colleague's growth was yours to support, say which part and how you went about it, in your own words; if none was, or it was not your role, say so plainly and move to the hiring loop you run |
| F5 | "partner with hardware and product on roadmap" (hardware strand) — your message (role description) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." The pack observes the sentence speaks to owning such a roadmap and does not say whether you have worked alongside hardware teams, and that stays an open fact for you, not a claim here. Then the ramp as a plan, said as a plan and never as a past |
| F6 | "partner with hardware and product on roadmap" (product strand) — your message (role description) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The closest adjacent work you gave. Words stay at that scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the role asks for partnering with product on roadmap, so expect a probe on where the pressure came from. If it came from product, say how that conversation went and what part was yours; if it did not, or you did not have that conversation, say so plainly and stay with the reliability quarter |

## Round 1: Tuesday, Director of Engineering (hiring manager, 45 min)

### Persona weights

The loop is established by your own words (three sessions, who runs each), so the weights below rest on the round type, not on a fallback archetype.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the gaps: scope step, hardware, "why us, why now" | High. The hiring-manager prior is Case/Strategist plus Skeptic, since they are buying capability and derisking gaps. You volunteered two of the gaps yourself (F1, F5), so they are on the table | Rehearse A2 until boring; plain acknowledgment, then a ramp plan said as a plan; hold what your sentences carry, concede the rest (see A2) |
| Case/Strategist (B) | Live problems from the actual role: hardware dependency, roadmap conflicts, hiring a squad | High. Same prior; the role description is a ready-made source of problems (F2, F5, F6) | Clarify, then objective, then approach, then metrics, then risks; think aloud; challenge one premise respectfully |
| Conversational (C) | Opening "walk me through the journey", motivation, domain curiosity | Medium. A 45-minute first conversation with your would-be boss will open somewhere casual; casual questions are still scored | A 90-second arc built only from your first sentence in F1; say what draws you, in your own words |
| Prober (D) | The 60% and the "about 40 interviews" are the two numbers on your side of the table | Low to medium. A Director reads these figures but the hiring-manager prior does not put probing first; it still takes two questions because figures are magnet targets (F2, F3, F6) | Say how each number was counted or say plainly you do not know; name the assumption you would defend least before they do |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Name the gap you stated, plainly: "I've never owned a hardware-adjacent roadmap." Then give it a shape as a plan: whom you would sit with first and what you would ask. Do not rank the gap as small or large; say it and move on. Do not volunteer the managers sentence unless the role needs it | The standard Skeptic opener; F5 is your stated gap and the role names hardware partnership, so it is the likeliest honest answer. JD because it scores the stated requirement |
| A2 | "You've never owned a hardware-adjacent roadmap. How would you handle that in this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | **Highest-ROI prep.** Level 0: the plain acknowledgment, "I've never owned a hardware-adjacent roadmap", then the plan: in the first weeks, sit with hardware and learn where their dates constrain the services roadmap. Follow-up 1 (how would you learn it): keep to the plan, and name what you do not yet know instead of guessing. Follow-up 2 (hardware dates do not flex like software ones): concede that you cannot judge those constraints yet and say what you would ask. Follow-up 3 (why not someone who has done it): hold only what your sentences carry, the reliability quarter at its scope, "I pushed a reliability quarter through against roadmap pressure", and concede the hardware gap without adding to it. Answer slot: if you have worked alongside hardware teams in any way, say how, in your own words; if you have not, say so plainly and return to the reliability quarter. Limit named before they ask: your quote speaks to owning the roadmap, not to partnering | F5 is a stated capability gap and the role's roadmap clause makes it the objection most likely to be asked, in some form, by every interviewer on this loop. JD because it scores the stated requirement; the question's negative is sourced from your own sentence |
| A3 | "You led a team of six. This role is two squads and eleven engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Say what is true at its scope: "For three years I was a team lead of 6." Then what changes, as reasoning and not as a past: more people, more dependencies, less time spent hands-on. Answer slot: if the six were your direct responsibility in a way that covered growth, say how it worked, in your own words; if it was lighter than that, say so plainly and stay with the team lead of 6 | F1 is the scale step the Director must be comfortable with. JD because it scores "lead two squads"; the premise is your own sentence plus the role's number |
| B1 | "A squad building device-management services tells you its roadmap is blocked because a hardware release slipped. Walk me through your first week." | CASE | [generic] | Clarify before structuring: what exactly is blocked, by whom, with what date confidence. Then objective: protect the squad's output and the commitments made to product. Then options: re-sequence, decouple the dependency, reset expectations. Close with what you would tell product and when. Challenge one premise out loud, for example whether the dependency is as hard as stated. The question needs no claim about your past, so the guidance makes none | A live problem straight from the role description's hardware-and-product line (F5, F6). CASE; generic because it is a pattern for the problem, not a fact about this employer |
| B2 | "Two squads, one hardware dependency, and a product ask that competes with reliability work. How do you decide what ships?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure first: objective, the cost of each option, who decides, how you say no. You may point to the reliability quarter at its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if the pressure came from product and you negotiated it, say what you said and what was yours; if it was not like that, say so plainly and answer the case from the structure alone | The reliability-against-roadmap tension is the one place F6 and the role's roadmap clause meet. CASE with an EXP edge; the case needs no claim about the past, only the quote does |
| B3 | "How would you know whether the two squads are healthy and delivering?" | CASE | [generic] | Offer a small set of measures, clarifying what the squads are accountable for first. Include a delivery measure, a quality or reliability measure and a people measure, and say what each can hide. Do not name figures you have not seen; ask what exists today | The role says to own delivery (F2); this is the delivery question asked as design. CASE; generic because it states no history |
| B4 | "If you were building out one squad's team, who would you hire first and how would you assess them?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Structure: what the squad lacks, the profile that fills it, how you would assess it. You may anchor in the quote: you run the hiring loop for backend roles. Answer slot: the role gives you hiring for eleven engineers, so expect a probe on what your loop screens for; if you set or shaped that, say how, in your own words; if the loop was set by others, or there is no fixed screen, say so plainly and say what you would look for first | F3 against the role's hiring strand. CASE delivery with an experience tie |
| C1 | "Walk me through the journey. Why this role, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Arc in the quote's own beats: nine years in engineering, three of them as team lead of 6, currently at a payments company. Then, in your own words, what draws you to device management and to a hardware-adjacent setting. Answer slot: if it is the domain that draws you, say so; if it is mainly the management scope, say that plainly instead. About 90 seconds | The biography question arrives in every first conversation with a would-be boss, in a casual register that is still scored (F1). EXP because it tests the CV's own arc |
| C2 | "What draws you to device-management work?" | JD | [generic] | Say what is true for you, briefly and specifically. If it is curiosity about the domain, say what you have read or watched; if you have not had exposure, say that plainly and say what you would want to learn first. Never claim hands-on device-management experience that you did not state | A casual question on the role's own domain; a flat answer here reads as lack of interest. JD; generic because it makes no claim about your past |
| D1 | "That 60% on-call drop: walk me through how it was counted, and over what period." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the sentence as written: the burden "dropped 60% after" the quarter, not "because of" it, and say that distinction yourself. Answer slots: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours; answer each in your own words, and where you do not know how it was counted, say so plainly | Your headline figure (F6) is the CV line any Director probes first. EXP because it tests attribution and the number |
| D2 | "The forty interviews: how was that counted, and how many were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what the sentence says: you run the hiring loop for backend roles. Answer slots: what the 40 counts (candidates, sessions, interviews you conducted), what it is sensitive to, the assumption you would defend least, and how many were yours; if you do not know how it was counted, say so plainly | F3's number is the second figure on your side of the table. EXP; the premise is your own sentence, and the sentence does not say whose interviews they were |

### Reverse questions: Round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What would success look like for this role at 90 days and at a year?" | Gives you the Director's own scoring sheet, and tells you what they would call a miss |
| R1.2 | "Where do hardware and product pull the roadmap apart today, and who arbitrates?" | Turns the hardware gap (F5) into diligence; their answer shows what the partnership really costs |
| R1.3 | "Is this role a backfill or new headcount, and how settled is the line between the two squads?" | A would-be boss answers honestly about team state, and it tells you what you inherit |
| R1.4 | "What does the on-call and reliability picture look like for these services today?" | Signals you look at operational health first; their answer shows where reliability sits against delivery |
| R1.5 | "What is the biggest unresolved risk in this role that you would want me to know before I accept?" | Invites candor from the person you would work for, and gives you something to weigh |

## Round 2: Thursday, panel of two staff engineers and a product manager (60 min)

### Persona weights

No panelist names were given, so personas cannot be assigned per member. The panel prior blends the top two personas of each member's relationship: staff engineers (peers and technical depth), a product manager (cross-functional).

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (E) | Where the EM and staff engineers meet: technical direction, disagreement, credit | High. Two of the three seats are staff engineers, whose question is what you would add to or take from their work | Reciprocity framing; propose seam principles instead of pretending to know the seam; disagreement stories with spine and tact |
| Prober, technical depth (F) | Attribution, numbers, and whether an EM can follow the design talk | High. Same two seats; F6 and F3 give them figures to test | Know what you can and cannot say about each number; say plainly where your technical depth stops |
| Case/Strategist (H) | Roadmap and dependency problems from the PM seat | Medium. The PM owns the roadmap side of the role's clause, and the role names hardware and product partnership (F5, F6) | Clarify before structuring; use the structure from B1 to B3 |
| Values/Behavioral (G) | Scenario probes on partnership and pushback | Medium. Cross-functional prior from the PM seat; no published values are in hand, so the themes come from the role's partnership clause | Selection criteria with an honest branch; "we" for context, "I" for contribution |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Staff engineers own technical direction and you own delivery. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Offer principles instead of a map you cannot yet draw: who decides which kind of question, how disagreement is surfaced early, what a tie-break looks like. Add what you would want to hear from them, and what you would bring them: clear priorities and cover from roadmap pressure. The question needs no claim about your past, so the guidance makes none | The peer question this panel exists to ask; the role's delivery clause (F2) sits right on this seam. CASE; generic because it is a pattern for the problem |
| E2 | "Tell me about a time you disagreed with someone at your level or above about a technical call, and how it resolved." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Open prompt; pick the instance. The nearest sentence you gave is the reliability quarter, at its scope: you pushed it through against roadmap pressure. Answer slot: if that involved a disagreement with a peer or senior person, say who, what you said and how it ended; if it did not, say so plainly and use a different time or say how you would handle it. Show spine and tact together | Disagreement stories are the peer persona's core probe (F6 is the nearest quoted material). VAL; the theme comes from the peer persona's stem |
| E3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection criteria: pick a time work crossed team lines; it needs a named other party, a moment where credit could have gone either way, and an intact working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A stem the peer persona uses; generic because nothing in your sentences carries a cross-team credit story |
| F1 | "That 60% result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the position the sentence carries and no more: "I pushed a reliability quarter through against roadmap pressure." Hold through two follow-ups by returning to it, never by adding to it. Answer slot: which parts were yours, in your own words; if much of the work was others', say so plainly and say what the pushing consisted of. Concede specifically, and do not fold on the core sentence | The attribution probe the staff-engineer seats are likeliest to run on F6. EXP; the hold-then-concede structure applies |
| F2 | "How do you stay technically credible with a team of engineers when you are not the one deciding?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | The sentence you gave is nine years of engineering and three as team lead of 6; say that, then how you intend to stay close to the technical conversation as a plan. Do not claim recent hands-on work you did not state. Where your technical depth in device management stops, say so plainly | The staff engineers will test whether an EM can follow the design talk (F1, F5). JD because it scores leading squads that build technical services |
| F3 | "What would you need us to teach you in your first month?" | JD | [generic] | A short, specific list of what you would ask to learn: how the services fit the devices, where the failures come from, how releases reach the field. Do not pretend to know the answers; show how you would learn and what you would do with it. The question needs no claim about your past | Turns the hardware and domain gap into a collaborative opening for the peer seats (F5). JD; generic because it states no history |
| G1 | "Tell me about a time you pushed back on product about timeline or scope." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Open prompt; the role's partnering-with-product clause is the theme. Use the reliability quarter at its scope: you pushed it through against roadmap pressure. Answer slot: where the pressure came from, what you said and what part was yours; if the pressure was not from product, or you did not push back on them, say so plainly and use another time, or say how you would handle it | F6 against the PM's seat; the likeliest behavioral probe from product. VAL; open prompt |
| G2 | "When have you changed your mind about a roadmap priority because a partner told you something you did not know?" | VAL | [generic] | Selection criteria: a named partner, a fact they supplied, a priority that actually moved, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The PM's counterpart to G1: tests whether you listen to hardware and product as partners (F5, F6). VAL; generic because no sentence carries such a story |
| H1 | "Product wants a customer-facing feature next release. Hardware says the device firmware cannot support it for two quarters. What do you do?" | CASE | [generic] | Clarify what "cannot support" means and for which devices. Objective: what the customer needs and by when. Options: interim version, re-sequence, expectation reset. Say what you would tell product, in what order. Challenge one premise out loud. No claim about your past | The roadmap tension at the center of the role description (F5, F6). CASE |
| H2 | "How would you run roadmap planning across two squads, with hardware and product both in the room? What do you need to know first?" | CASE | [generic] | Start with what you need to know: current commitments, dependency map, how decisions are made today. Then a small structure for the process: shared inputs, an owner for each trade-off, a cadence. Say what could go wrong with your own plan | The PM seat will ask you to run the process they live in (F2, F5, F6). CASE |

### Reverse questions: Round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What could a new engineering manager do in their first month that would genuinely help your work?" | The reciprocity question: it flips the panel's question and shows you are pricing what you add, not only what you take |
| R2.2 | "Where does today's planning process cost you the most time?" | Staff engineers name real friction; it gives you a first-month target |
| R2.3 | "How do technical decisions get made here, and where does the engineering manager sit in that?" | Shows you respect the seam and want it explicit |
| R2.4 | "How does the roadmap get negotiated between product and hardware, and what has been hardest about it?" | Aimed at the PM; it addresses the partnership clause head on (F5, F6) |
| R2.5 | "What do you wish engineering management did differently?" | An invitation to candor from the people who work with the role daily; their answer is your day-one brief |

## Round 3: Monday, VP Engineering ("values and leadership philosophy", 30 min)

### Persona weights

The recruiter's words are a loop source that documents a values-style round, so Values/Behavioral is guaranteed here. Larkfield's published values are not in hand (searches were refused), so the questions are themed from the recruiter's description and the role's own clauses, and no values cheat sheet is built.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (I) | Stories about unpopular truths, trade-offs, growing people, how you lead | High. The recruiter's description is exactly this; the role's hiring and growth clause (F3, F4) gives themes | Map a story where one of your sentences carries one; selection criteria where none does; land the hard truth honestly |
| Case/Strategist (J) | Altitude: where the org should worry, what you build in 90 days | Medium. Skip-level prior is strategy-heavy; a values-framed 30 minutes leaves less room for it | Clarify before structuring; use the company's vocabulary only once you have read it |
| Pressure (K) | Time-boxed challenges: "why you over a hardware-experienced candidate", "you have not managed managers" | Medium. Skip-level prior; your two stated gaps (F1, F5) are the obvious material in 30 minutes | Pause, restate, hold the position your sentences carry through two follow-ups, concede specifically |
| Conversational (L) | Open "how would others describe your leadership" | Low. A short values round leaves little unstructured time | A 20-second answer in your own words |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Open prompt; pick the instance. The nearest sentence is the reliability quarter, at its scope: you pushed it through against roadmap pressure. Answer slot: whether the pressure came from leadership and what truth you told them, in your own words; if the pressure was not from leadership, or no hard message was delivered, say so plainly and pick another time or say how you would handle it. Pick the version where the message landed, only if it did | A stem the values persona uses; F6 is your nearest quoted material and does not show who was told what. VAL |
| I2 | "When did you put the reliability work ahead of what the roadmap asked for?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Premised on your own sentence, so the beats are the sentence's: a reliability quarter, pushed through, against roadmap pressure, on-call burden down 60% afterwards. Tell it in your own words; say "after", not "because". Answer slot: how the 60% was counted and which part was yours; if you do not know how it was counted, say so plainly | The most direct match for a values round; F6. VAL; the premise is your own sentence |
| I3 | "What does good leadership of engineers look like to you, and where have you fallen short of it?" | VAL | [generic] | Name two or three principles in your own words, then one real shortfall you can describe without defensiveness and say what you changed. Selection criteria: a named stake, a moment you recognised it, an action afterwards. If no shortfall comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The recruiter's "leadership philosophy" is this question by another name. VAL; generic because no sentence carries it |
| I4 | "What do you look for in an engineer you hire, and how do you know?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Open with the sentence: you run the hiring loop for backend roles. Answer slot: the role gives you hiring for eleven engineers, so expect a probe on what the loop screens for; if you set or shaped that, say how, in your own words; if it was set by others, or there is no fixed screen, say so plainly and say what you would look for | The VP's version of F3 at values altitude. VAL |
| I5 | "Tell me about someone you helped grow." | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Open prompt; the role's growth clause is the theme and no sentence of yours carries a growth story, so this is a selection scaffold: pick a person, a specific gap they had, what you did, and where they ended up, only from what actually happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the team lead of 6, or how you would handle it | F4 is a silence, and growth is one of the three strands the role names; the VP is likely to probe it. VAL |
| J1 | "What do you understand about where we sit in industrial IoT, and what would you want to learn in your first month?" | CO | [generic] | No research reached this pack, so do not recite anything about Larkfield you have not read yourself. Say what you have read, if anything, and say where you would start learning: customers, fleet scale, release cadence. A candid, specific learning list beats a confident vague answer | The company-altitude question a VP asks; generic because the search that would ground it was refused (see upgrade menu). CO |
| J2 | "You have two squads, eleven engineers, and hardware and product pulling on the roadmap. What do you build first as a leader in 90 days?" | CASE | [generic] | Clarify what exists. Then: understand the people and the commitments first, establish a delivery rhythm and a shared roadmap input, then address the largest risk. Say what you would not change in the first month. No claim about your past | The role description as a case (F1, F2, F5, F6). CASE |
| K1 | "Sixty seconds: why you over a manager who has run hardware-adjacent teams?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause, restate the question. Hold: what your sentences carry, "I pushed a reliability quarter through against roadmap pressure." Concede the stated gap in one clause: "I've never owned a hardware-adjacent roadmap." Then the plan for it. Do not claim the competitor's strengths are unimportant, and do not add to your own record | A skip-level pressure stem aimed at F5. JD; hold-then-concede applies |
| K2 | "You've never managed managers. How do you think about the step up in scope?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I've never managed managers." Then how you would approach a step up in scope, as reasoning and as a plan, never as a past. The role description does not say it requires managing managers, so answer the scope question you are asked, not a harder one | Your own stated gap (F1), asked at the altitude where it matters. JD; the negative is sourced from your sentence |
| L1 | "How would the people you work with describe how you lead?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Keep it to one sentence of your own, with the quote's scope: team lead of 6. Answer slot: if you have heard feedback on how you lead, say what it was in the words used; if you have not, say so plainly and say what you would want them to say | A low-weight rapport question that is still scored (F1). EXP |

### Reverse questions: Round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does leadership look like in your organisation when something goes wrong?" | A values-round reverse question that gets their leadership philosophy in their own words |
| R3.2 | "Which of the company's values is hardest to hold under delivery pressure here?" | Shows you take values as trade-offs, not slogans, and tells you where the tension lives |
| R3.3 | "How do you develop first-time engineering managers here, and what comes after that?" | Addresses your step-up honestly without making it a confession (F1) |
| R3.4 | "What do you hope a new engineering manager for these squads would change in the first six months?" | Gives you the VP's expectation to test against Tuesday's and Thursday's answers |
| R3.5 | "What is the biggest bet engineering is making this year, and what would make you regret it?" | A strategy-altitude question that shows interest and gives you the live context the pack could not research (J1) |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran two squads, or managed eleven engineers | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation, not words for you: the material says team lead of 6 and does not show whether the six reported to you |
| Line-managed the six, or was responsible for their growth | Inflated form of F1 and F4 | The same quote at its own scope. A3's and I5's slots stay inside what the team lead role covered, in your own words |
| Has managed managers | Negative you stated, F1 | The plain acknowledgment you gave: "I've never managed managers." No slot |
| Owned or led a hardware-adjacent roadmap, or shipped hardware products | Negative you stated, F5 | The plain acknowledgment you gave: "I've never owned a hardware-adjacent roadmap." No slot |
| The reliability quarter caused the 60% drop, or won the roadmap argument, or designed the fixes | Inflated form of F6 | F6's quote at its own scope: the burden "dropped 60% after I pushed a reliability quarter through against roadmap pressure". The pack's observation: the sentence says "after", and does not say how the figure was counted or which parts were yours; the defend-the-number slots ask only those |
| Personally conducted the forty interviews, or hired people | Inflated form of F3 | F3's quote at its own scope: you run the hiring loop for backend roles, about 40 interviews last year. The sentence does not say whose interviews they were |

## Requirement coverage

| Requirement (role description) | Questions |
|---|---|
| "Lead two squads building device-management services" | A3, B1, B3, C1, C2, F2, F3, J1, J2, K2, L1 |
| "own delivery" | B2, B3, E1, H2, J2 |
| "hiring" for 11 engineers | B4, D2, I4 |
| "growth" for 11 engineers | I3, I5 |
| "partner with hardware and product on roadmap" | A1, A2, B1, B2, E2, G1, G2, H1, H2, K1 |

## Sources

Provided documents: your message (the role description, the three round descriptions, your four background sentences). No JD file, CV, interviewer profile or dossier was provided.

Searches sent, all refused (search permission was not granted in this session):

- `Larkfield Systems industrial IoT company values` — refused
- `Larkfield Systems interview process engineering manager` — refused
- `Larkfield Systems strategy news device management` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Every call refused. Would have moved the values cheat sheet (section 10), which is therefore dropped, and the VAL mapping in round 3 |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Every call refused. Would have confirmed the loop; the three sessions and who runs each rest on your own words, so persona weights are unaffected |
| 3. `Larkfield Systems strategy news device management` | unavailable | Every call refused. Would have grounded the CO and CASE questions; J1 is labelled generic as a result |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Engineering Manager JD | skipped | The role description you pasted supplies the requirements the snapshot quotes; a full JD is in the upgrade menu |

## Upgrade menu

- Search permission, or a pasted values page: the published values become a round-3 cheat sheet with a mapped story or selection scaffold per value, and I1 to I5 become grounded in them
- A pasted strategy brief or search permission: J1 and the CO and CASE questions in rounds 1 and 3 become grounded in current strategy instead of generic
- A deeper research pass (needs search permission; up to 6 more searches and 2 more fetches, several more minutes): interviewer talks, loop reports from candidates in this role family and recent org context
- The full JD text: the six snapshot rows quote the JD's own lines instead of your summary, and any requirement not in the summary gets a question
- Your CV: rows F2, F4 and F6 can gain evidence beyond the four sentences you wrote, and scaffolds such as E3, G2 and I5 can become story-mapped answers
- The recruiter's focus areas or any pre-declared deliverable for rounds 1 and 2 (usually one email): coverage assumed from round-type priors becomes coverage confirmed, and any graded deliverable gets its own build section
- The interviewers' names or titles, especially the two staff engineers and the product manager: an interviewer read, persona assignment per panel member and a reverse question tied to each person's path
- Your own answers to the slots in F1 (what team lead of 6 covered), F2 (what delivery you were accountable for), F3 (how the forty was counted), F4 (any support of growth) and F6 (where the pressure came from): each gets regenerated from your words
- A tuesday-dossier.md from an earlier underwriting pass: would add verified evidence, a named top objection and any prohibited claims it holds
