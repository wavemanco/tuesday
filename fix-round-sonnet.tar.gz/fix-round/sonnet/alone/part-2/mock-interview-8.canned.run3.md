I'll read the reference files the skill requires before writing anything.
Everything the pack needs is already in your message, so I'm building it now with no clarifying questions.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-canned-19085933/ashgrove_member-experience-lead_interview_pack.md`.

I built it as a three-round loop from what you pasted. The panel round is treated as the values round, per the recruiter's email. It has 30 questions across the rounds. No searches were needed, because your JD, values, recruiter email and strategy brief already covered every research target. None of the JD's requirements is a hard gate, so I asked you nothing. There is no interviewer read yet, because no names are assigned.

Your two stated gaps shape most of the pack. You said you have never worked in a contact centre and have never presented above regional level. The pack coaches you to say each plainly and then give a plan. It does not coach you to say you have done either.

D1 is the highest-ROI prep: the contact-centre objection, with the full opening and three follow-ups. It will most likely come from the Head of Member Services in round 2.

Your background doesn't yet carry a story for any of the four values, so those four answers are selection scaffolds rather than story maps. The pack has answer slots where your own facts would help. They cover what your spreadsheet counted, whether it was Excel, whether the complaints in your log fell under external rules, any digital work, and any coaching beyond new tellers. Give me those, or one story per value, and I'll regenerate the affected rows.

Say the word and I'll play the Skeptic on D1, drilling it with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop on 20 November, three rounds, run as loop mode: a shared fit snapshot, then one mini-pack per round.

| Round | Who | Length | Shape, from the recruiter's email |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Conversation |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewer names are not assigned yet, so there is no interviewer read.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores.
- Type key: `VAL` is behaviour that shows a published value. `EXP` is whether a claim from your background survives scrutiny. `JD` is a stated requirement of the role. `CO` is knowledge of Ashgrove's strategy. `CASE` is a live problem from the role.
- Guidance is scaffolding, not a script. Say it in your own words. Where a cell says "Answer slot", the honest answer is yours to give, and "no, that was not me" is a valid answer.
- The highest-ROI prep in this pack is D1, the contact-centre objection. It will come up in some form, probably in round 2.

## Prep triage

Nine days from today (11 November) to 20 November.

| Order | Do | Where |
|---|---|---|
| 1 | Say the D1 answer aloud until it is boring: the opening plus all three follow-ups. B2 is its short version for round 1 | D1, B2 |
| 2 | Write your own one-or-two-sentence answers to each answer slot, including the plain "no such step" version where that is true | Answer slots on F1, F3, F4, F5, F7, F8 |
| 3 | Run the 20-minute case aloud against a timer, twice | H1, H2, H3 |
| 4 | For each of the four values, find one story that is really yours, or note that you do not have one yet | G1 to G4, C2 |
| 5 | Say the A1 arc in 90 seconds, then the plain acknowledgments (B1, D2) in one breath each | A1, B1, D2 |

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log, not the process end to end and not beyond the branch. The words stay at that scope: "I handled the branch's formal complaints log". Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any step beyond the log was yours, say which and what you did, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller. The JD names the contact centre in its first line, so expect this early |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence says a monthly complaints spreadsheet you built that your regional manager uses; it does not say what it counted. Lead with it at that scope. Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet counted. If it counted either, say how each was counted and which assumption you would defend least; if it counted something else, say what; if you do not know how a figure was counted, say so plainly |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The sentence says new tellers and your escalation script; the JD says branch supervisors. Stay at scope: "trained new tellers on our escalation script". Answer slot: if you have coached anyone beyond new tellers on escalations, say who and what you did; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on digital teams. Answer slot: the JD names self-service journeys, so expect a probe on any time your complaints work touched a digital channel. If it did, say what, and what part was yours, in your own words; if it did not, say so plainly and answer digital questions as a plan, using the brief's 40% digital target as context |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on the years: the sentence gives six years against the JD's four-plus. Lead with it in your own terms, the six years and then the last three as a branch supervisor, and do not relabel it in the JD's phrase. It is a stated span with nothing inspected behind it, so expect a probe |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | The sentence says a formal complaints log; it does not say whether those complaints fell under external rules. Words stay at scope: "I handled the branch's formal complaints log". Answer slot: if the complaints in the log fell under external rules or deadlines, say what those were and what you did, in your own words; if you do not know, or they did not, say so plainly and stay with the log |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel; the tool is this pack's inference from the JD's wording. Answer slot: if the spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, say so plainly and say how you would come up to speed on Excel, as a plan |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare to present, said as a plan and never as a past. Your material says nothing about presenting at or below regional level, so the pack claims nothing there |

## Grounding brief

From the 2026 strategy brief the recruiter sent (July 2026) and the JD.

| Item | In the source's words | Provenance | Used in |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] | A2, E1, E3 |
| Branch network | "consolidate eight branches into five hubs over 2027" | [grounded] | A2, J2 |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] | Not banked: no complaints question rests on it; mention only if the interviewer raises it |
| Competition | "the main competitive pressure is app-only banks" | [grounded] | E3 |
| Organisation | "member-owned, about 900 staff" — JD | [grounded] | Tone of all CO answers |

The brief is about four months old, so confirm no update has been published before round 2.

---

# Round 1: recruiter, 30 minutes

## Persona table, round 1

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured: "walk me through your background", "why us?" | High. The recruiter-screen prior is Conversational plus a light Skeptic, and the email gives this round 30 minutes with the recruiter alone | A pre-scripted 90-second arc (A1). Treat casual questions on JD topics as scored |
| Skeptic (light) | Knockout-style checks on the gaps and on motivation: weakest area, why now | Medium. The recruiter-screen prior includes a light Skeptic, and the JD names the contact centre and senior presenting, the two things your message says you lack (F2, F9) | Say each stated gap plainly, bridge only to what your sentences carry, then give a plan |

## Question bank, round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role asks for four-plus years in financial-services customer operations. Walk me through your background." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F6, F1, F4 and F3. Tell it in the order the sentences give it: six years in retail banking; the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. Use "I" for those two, in your own words and at those scopes. Do not relabel retail banking in the JD's phrase. Close with why Ashgrove, in your own reason; the pack supplies none | F6 is the years requirement and the recruiter's first check. JD because it scores a stated requirement. F1, F3 and F4 are what the arc rests on |
| A2 | "What do you know about Ashgrove, and why this role?" | CO | [inferred] Derived from the brief's digital and hub targets and the JD's scope | Use the brief's own words for two items: 40% of member service to digital channels by 2028, and eight branches into five hubs over 2027. Then give a view, labelled as a view, on what that could mean for where complaints arrive and what you would want to learn about it. Do not state how Ashgrove's complaints work today. Finish with your own reason for wanting the role; the pack supplies none | A recruiter screen checks that motivation is specific. CO because it scores homework on the strategy; the angle is this pack's derivation, so it stays a view |
| A3 | "The role owns the complaints process end to end across branches and the contact centre. What part of a complaint's journey have you handled yourself?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 at its scope: "I handled the branch's formal complaints log". Answer slot: if any step beyond the log was yours, say which and what you did, in your own words; if there was no such step, or it was not yours, say so plainly and describe how you handled the log. Hold through a follow-up by returning to the log, never by widening it | F1 is where the JD's scope presses hardest. JD because it scores the headline responsibility |
| A4 | "Tell me about the escalation script you trained new tellers on." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beats are the ones the sentence states: new tellers, your escalation script, and that you trained them. Answer slot: the JD asks you to coach branch supervisors on escalations, so expect a probe on who else you have coached. If anyone beyond new tellers, say who and what you did; if not, say so plainly and stay with the tellers | F4 is the evidence for the coaching requirement and sits at tellers, not supervisors. EXP because it tests what was actually yours |
| A5 | "The role reports monthly on complaint volumes and resolution times. Tell me about the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Beats from the sentence: you built it; it is monthly; it is about complaints; your regional manager uses it. Answer slot: if it counted volumes or resolution times, say how each was counted and which assumption you would defend least; if it counted something else, say what; if you do not know how a figure was counted, say so plainly. Name no figure you cannot explain | F3 is the reporting evidence, and a monthly spreadsheet you built invites the defend-the-number probe. JD because the question quotes the requirement |
| A6 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from F8 at its scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was Excel, say what you did in it, in your own words; if it was another tool, say so plainly and say how you would come up to speed on Excel, as a plan. Do not describe a technique you did not use | F8 is the only row where the tool itself is unconfirmed, so a short factual question is the likely form. JD because Excel is a stated requirement |
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Choose from the two gaps your message states and say it plainly: "I haven't worked in a contact centre." or "I haven't presented to anyone above regional level." Then give a plan for it, in your own words, said as a plan and never as a past. Stop there rather than padding with adjacent claims | F2 and F9 are the two stated gaps, and a recruiter screen checks candour. JD because it scores the requirement list, including its gaps |
| B2 | "The role covers the contact centre as well as the branches, and I don't see that in your background. How would you handle it?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Plain acknowledgment first: "I haven't worked in a contact centre." Then what your material carries, at its scope: "I handled the branch's formal complaints log". Then a plan for learning the contact-centre side. Keep it to about 60 seconds; D1 is the long version | F2 is the largest stated gap, and the recruiter version is the lighter rehearsal of D1. JD because it scores the contact-centre part of the responsibility |
| B3 | "What is behind the move, and why now?" | JD | [generic] | Selection scaffold: give one reason pulling you toward this role, tied to the scope the JD describes, and one reason about timing that is true for you. Do not criticise your current branch. If your honest reason is only that the role is a step up, say that plainly and say what in it you want to learn | Recruiters check motivation consistency. JD because it scores fit with the stated role; the pack supplies no reason, because none was given |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "In the panel round, how do the two branch managers score against the four values: is there a shared question set or rubric?" | The email says the panel scores against the values, so you are asking about the process it described |
| 2 | "For the 20-minute complaint-escalation case, is there any material I should expect beforehand, or is it given on the day?" | The email names the case but not its format; this settles preparation |
| 3 | "Is the Member Experience Lead a new role, or does it replace an existing one?" | It shows you are weighing the scope the JD describes |
| 4 | "How does this role connect to the plan to move 40% of member service to digital channels by 2028?" | It uses the brief's own target and invites the recruiter's reading of it |
| 5 | "What is the Head of Member Services most hoping to see from this hire in the first three months?" | It gives you language for the next round, which is with that person |

---

# Round 2: Head of Member Services, 45 minutes, mostly behavioural

## Persona table, round 2

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the contact centre and senior presenting | High. The hiring-manager prior is Case/Strategist plus Skeptic, and this person would be your manager, buying capability and derisking the gaps your message states (F2, F9) | Rehearse D1 until it is boring. Plain acknowledgment, your sentence at its scope, then a plan |
| Values / Behavioral | "Tell me about a time" scenarios on coaching, escalation, bad news | High. The recruiter's email calls this round mostly behavioural | Where one of your sentences carries a story, tell only what it states; otherwise use the selection scaffold and its honest branch |
| Case / Strategist | Live problems on digital journeys, rising volumes, the strategy | Medium. The hiring-manager prior includes cases, but the email says mostly behavioural and puts the 20-minute case in round 3 | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |

## Question bank, round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4 at its scope: "trained new tellers on our escalation script". The beats are new tellers, the script, the training. Answer slot: if there was a moment where a teller's handling of an escalation changed, say what you saw and what part was yours; if there was none you can point to, or you did not coach beyond the training, say so plainly and stay with the training. If nothing in your experience fits "difficult escalation", say that, then say how you would coach a supervisor through one | F4 is the evidence for the coaching requirement and stops at tellers. JD because the open prompt takes its theme from the JD's coaching line |
| C2 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Pick a time a problem was yours to keep hold of: it needs a named stake, what you did each time it stalled, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", at that scope, or say how you would keep hold of a complaint. The log sentence does not show you kept hold of any one case, so do not present it as that | This is the Own the Fix value in manager clothing, and the manager may use it because the round is behavioural. VAL because it scores a published value |
| C3 | "Tell me about a time you gave unwelcome news to someone more senior than you." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." "I've never presented to anyone above regional level" | Selection scaffold: a named stake, what you said, how it was received, the relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I built the monthly complaints spreadsheet our regional manager uses", at that scope. It does not show you gave unwelcome news, so do not present it as that. If the question turns to presenting, the plain words are "I haven't presented to anyone above regional level" | F9 is the senior-audience requirement, and a behavioural round tests it through a story rather than asking directly. JD because the theme comes from the JD's senior-leaders line |
| C4 | "Tell me about a time you worked with another team to fix something." | JD | [generic] | Selection scaffold: pick a time you needed another team's work to fix something; name the stake, what you asked of them, how it ended. If no such time comes to mind, say so plainly, then say how you would work with a digital team on a self-service journey. Answer slot: if any of your complaints work touched an app or web journey, say what and what part was yours; if none did, say so plainly | F5 is silent on digital teams, and the JD names them. JD because it scores that responsibility; the pack carries no story for it |
| D1 | "You haven't worked in a contact centre, and this role owns complaints there too. Convince me." | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI rehearsal in this pack.** Opening, about 60 seconds: the plain acknowledgment, "I haven't worked in a contact centre." Then your sentence at its scope: "I handled the branch's formal complaints log". Then a plan: two or three things you would do first to learn the contact-centre side, your own choices; the pack picks none. Name the limit before it is asked for: you are not saying the branch log and the contact centre are the same work. Follow-up 1, "Branch complaints are not contact-centre complaints; why would yours transfer?": hold that you are not claiming they transfer whole; concede that you do not yet know how the contact centre's process runs, and say what you would ask to be shown first. Follow-up 2, "What if the team there knows more than you?": answer as a plan, who you would learn from and what you would keep hold of yourself. Follow-up 3, "Would you take the role if the contact centre were most of it?": concede the uncertainty specifically, but do not fold on the core: you are applying, and you are not claiming experience you have not had. Never add a claim to make the gap feel smaller | F2 is the largest stated gap and the JD names the contact centre in its opening line. The Head of Member Services is the manager who would carry that risk, so this arrives in some form in this round. JD because it scores the stated scope, and the depth follows the persona weight |
| D2 | "I don't see presenting to senior leaders in your background. How will you handle that part of the role?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan for how you would prepare your first presentation, in your own steps; the pack supplies none. Hold through a follow-up such as "what if you freeze?" by returning to preparation; concede that you cannot know how you will feel in the room. Do not claim presenting at or below regional level, because your material does not say | F9 is a stated gap against a stated requirement. JD because it scores the requirement directly |
| D3 | "How does the regional manager use the spreadsheet you built?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats are: you built it, it is monthly, it is about complaints, your regional manager uses it. Answer slot: if you know what the regional manager did with it, say what, in your own words; if you do not know, or it was only looked at, say so plainly and stay with what you built | F3 shows the use but not the content. EXP because it tests what was actually yours and what was not |
| D4 | "What experience do you have handling regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start at F7's scope: "I handled the branch's formal complaints log". Answer slot: if the complaints in the log fell under external rules or deadlines, say what those were and what you did; if you do not know, or they did not, say so plainly and stay with the log | F7 is the requirement your one sentence touches without showing. JD because regulated complaints is a stated requirement |
| E1 | "Suppose a member starts a complaint in the app and ends up at a branch counter. Plan the journey with the digital team: what do you need to know first?" | CASE | [grounded] The JD's "work with digital teams on self-service journeys" and the brief's "move 40% of member service to digital channels by 2028" | Structure aloud: clarify (what the member is trying to do, where they drop out, what the digital team can measure); objective, from the member's side, in plain words; segmentation (complaints a member can resolve alone versus ones that need a person); approach with the digital team; metrics, using the JD's own, complaint volumes and resolution times; risks, including what self-service could hide. Challenge one premise respectfully, such as whether every complaint belongs in self-service. Answer slot: if your complaints work ever touched a digital journey, say what and what was yours; if it did not, say so plainly and take the case as a plan | The brief makes digital the largest stated shift and F5 is silent on it. CASE because it is a live problem from the role, scored on structure |
| E2 | "Complaint volumes on one product rose sharply last month. What do you look at first, and who do you tell?" | CASE | [generic] | Clarify first: how the volumes are counted, whether the rise is real or a change in how complaints are logged, where it sits (one branch, the contact centre, everywhere). Then diagnose, then say how it goes in the monthly report. Name which part of the count you would trust least before they do. This claims nothing about your past | The JD's reporting line makes a volumes question likely, and the weakest-assumption move turns a gotcha into credibility. CASE because the problem is live and the pack claims nothing about you |
| E3 | "Our brief names app-only banks as the main competitive pressure. What does that mean for how we handle complaints?" | CO | [grounded] The brief's "the main competitive pressure is app-only banks" | Use the brief's words, then reason from the member's side: how quickly and how plainly a complaint is answered, and whether a person stays reachable. Give it as a view. Do not assert facts about how app-only banks handle complaints; you have no source for that in this pack | The competitive frame is the strategy item most candidates leave untouched. CO because it scores thinking at Ashgrove's altitude |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good first 90 days look like, and how would you judge it at the end?" | A manager can answer it concretely, and it shows you think about results |
| 2 | "How is the complaints process split between the branches and the contact centre today, and where does it work least well?" | It goes to the scope the JD opens with, which is also your largest gap |
| 3 | "Which will change the complaints process first, the digital shift or the move to hubs?" | It uses two items from the brief and invites the manager's own view |
| 4 | "What does the monthly report on complaint volumes and resolution times look like today, and who reads it?" | It takes the JD's reporting line at face value and surfaces the audience |
| 5 | "Which senior audiences would I be presenting to, and how often?" | It asks the practical form of the senior-presenting requirement |

---

# Round 3: panel of two branch managers, 60 minutes, including a 20-minute case; also the values round

## Persona table, round 3

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes scored against Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | High. The email says the panel is also the values round and scores against the four values | One story per value where one of your sentences carries it, a selection scaffold with its honest branch where none does; "we" for context, "I" for what you did |
| Case / Strategist | The 20-minute complaint-escalation case | High. The email gives it 20 of the 60 minutes | Clarify, objective, approach, the next hour, afterwards, reporting; think aloud; challenge one premise |
| Peer Evaluator | Seam questions: what the branch decides and what the role takes, and what hubs mean for towns | Medium. The email does not state the panel's relationship to the role; the JD has the role coaching branch supervisors, which makes seam questions plausible. This is an assumption: if the relationship differs, reweight | Propose seam principles instead of pretending to know the seam; say what you would bring them as a plan |

## Question bank, round 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Members First, Always. Pick a decision where the member's interest and something else pulled apart; name the stake, what you chose, and what the member saw. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", at that scope, or say how you would decide from the member's side. That sentence does not show a decision, so do not present it as one | The values round scores each published value. VAL because it scores the named value, not generic virtue |
| G2 | "Tell me about a time you changed how something was explained so it landed first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Plain Words: pick an explanation that did not land and what you changed; name what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "trained new tellers on our escalation script", at that scope. Answer slot: if you had a hand in how the script was worded, say what you changed and why; if it was set for you and you taught it, say so plainly and stay with the training | The value says if a member needs it explained twice, it was written wrong, so a script-training sentence is the nearest material. VAL because it scores the named value |
| G3 | "Tell me about a time you thought about your branch as part of its town." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold for Neighbours, Not Numbers: pick a moment where the town, not only the target, shaped what you did; name what you did and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "the last 3 as a branch supervisor", at that scope, or say how you would keep a branch tied to its town. That sentence says a role, not a story | The value is about each branch belonging to its town, and the panel are branch managers. VAL because it scores the named value |
| G4 | "Own the Fix says whoever finds the problem keeps hold of it until it is solved. Tell me about a time you did that." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Own the Fix: pick a problem you found, what you did each time it stalled, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", at that scope. It does not show you kept hold of one case to the end, so do not present it as that. If C2 gave you a true story, this is the same story in a values room | The value is also the likeliest to be tested in a complaints role. VAL because it scores the named value |
| H1 | "A member complained at a branch counter three weeks ago. It went to the contact centre. The member has now come back to the branch, angry that nobody has called, and the supervisor wants to hand it back to the contact centre. You are the Member Experience Lead: what do you do in the next hour, and what do you change afterwards?" | CASE | [generic] | A practice scenario; the real case will differ. Structure aloud in about 20 minutes: clarify first (what the member was told, what stage it is at, what deadlines or rules apply: ask the panel, do not state them); objective, from the member's side; the next hour, speak to the member in plain words and name who keeps hold until it is solved; afterwards, why the hand-offs failed between branch and contact centre, and what you would change; how it would show in the monthly report; how you would coach the supervisor. Challenge one premise respectfully, such as whether handing it back is the right move. Land the four values through the structure, not by reciting them. This claims nothing about your past | The email gives 20 minutes to a case on a complaint escalation, and the role is built on escalations. CASE because it scores structure and reasoning on a live problem |
| H2 | "The supervisor escalated late. How do you coach them?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Structure aloud: ask why it was late before assuming; restate what you expect from an escalation; practise one together; say how you would check it worked. Answer slot: if you have coached anyone beyond new tellers on escalations, say who and what you did; if not, say so plainly and stay with "trained new tellers on our escalation script" | F4 stops at tellers, and the JD says supervisors. CASE because it is a live follow-up inside the case |
| H3 | "What goes into the monthly report after a case like this?" | CASE | [generic] | The JD's own terms, complaint volumes and resolution times, then what else a senior reader needs, then what you would trust least in the count and say so first. Practise a two-minute spoken version in plain words; the Plain Words value says a reader should not need it twice. This claims nothing about your past | The JD's reporting line and the senior-presenting gap meet here, and the case invites it. CASE because it is a live reporting problem |
| J1 | "Our supervisors will escalate to you. Where is the line between what we decide in the branch and what you take?" | JD | [generic] | Propose principles, not the seam: whoever finds a complaint stays involved until it is solved (the Own the Fix wording), the owner is clear to the member at every stage, and escalation is a hand-over, not a hand-off. Ask how they work today. Say what you would offer them as a plan, never as a track record | A branch manager prices what this hire costs and adds to their branch. JD because the question scopes the role's responsibility |
| J2 | "The brief brings eight branches into five hubs over 2027. What does Neighbours, Not Numbers mean for complaints when branches consolidate?" | CO | [grounded] The brief's "consolidate eight branches into five hubs over 2027" and the value "Neighbours, Not Numbers" | Do not take a side on the strategy. Say each town's situation differs and ask what the panel sees; then offer a principle, such as a member never needing to know which hub holds their complaint. Give it as a view. These are branch managers, so assume it touches their own towns | The brief and the value meet exactly here, in front of the people most affected. CO because it scores the strategy; the values link is why it sits in this round |
| J3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold: pick a piece of work others also touched; "we" for the whole, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I built the monthly complaints spreadsheet our regional manager uses", at that scope. Answer slot: if others contributed to the spreadsheet, say what was theirs and what was yours; if none did, say so plainly | The stem tests attribution honesty, and F3's "I built" is the sentence a probe goes to. EXP because it tests what was actually yours |

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side, every time | None of F1 to F9 carries a decision from the member's side; selection scaffold in G1, ending in its honest branch |
| Plain Words | If a member needs a second explanation, the writer failed | None of F1 to F9 carries a story; selection scaffold in G2, with an answer slot on how the script was worded |
| Neighbours, Not Numbers | Each branch belongs to its town | None of F1 to F9 carries a story; selection scaffold in G3, and J2 for the hub plan |
| Own the Fix | The person who finds the problem keeps hold of it until it is solved | None of F1 to F9 carries a story; selection scaffold in G4 and C2, the same story if you have one |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which complaints reach your branch from the contact centre, and where does the hand-off feel weakest from the branch?" | It asks the people who live at the seam about the seam |
| 2 | "How are your branches thinking about the move to hubs, and how should complaints be handled during it?" | It ties to the brief and to Neighbours, Not Numbers |
| 3 | "What could a new Member Experience Lead do in the first month that would genuinely help your branch?" | A reciprocity question, in case the panel are peers of the role |
| 4 | "Which of the four values is most tested in a complaint, and when?" | It shows you take the values as practice, not slogans |
| 5 | "How do your supervisors currently learn escalation, and what would you change about it?" | It goes to the coaching line the JD gives the role |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end" | A3, D1, H1 |
| "across branches and the contact centre" | B2, D1, H1 |
| "report monthly on complaint volumes and resolution times" | A5, D3, E2, H3 |
| "coach branch supervisors on escalations" | A4, C1, H2, J1 |
| "work with digital teams on self-service journeys" | C4, E1 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | D4 |
| "confident presenting to senior leaders" | C3, D2 |
| "comfortable with Excel reporting" | A6 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says the branch log, not the process beyond it. A3's slot stays inside the log |
| Handled complaints in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says a monthly complaints spreadsheet your regional manager uses, not what it counted. A5's slot asks only what it counted |
| Coached branch supervisors | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script". C1's slot stays at tellers |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log". D4's slot asks only whether those complaints fell under external rules |
| Advanced Excel reporting skills | Inflated form of F8 | F8's quote at its own scope. The limit is the pack's observation: the material says spreadsheet, not Excel. A6's slot asks only which tool |
| Presented to senior leaders | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD; the four published values, as pasted (copied on 11 November 2026 from ashgrovecu.org/about/values); the recruiter's email about the three rounds; the 2026 strategy brief Ashgrove published in July 2026, as sent by the recruiter; your background message. No dossier was present.

Searches and fetches: none sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the values cheat sheet and the VAL bank |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email already gives the three sessions, who runs each and what each holds, which fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief you pasted fixes the grounding brief and the CO questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names are assigned yet, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names, once assigned: an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their path
- Your own written answers to the answer slots on F1, F3, F4, F5, F7 and F8: those rows move from slot to quoted material, and the banks that rest on them regenerate
- The monthly complaints spreadsheet's layout, or a description of its columns, and the complaints log's categories: these are the inspectable artifacts for F3, F7 and F8, and would raise their confidence
- A true story you can tell for each of the four values, or a plain "I have none yet": G1 to G4 and C2 become story-mapped
- One email to the recruiter: the panel's names and roles, whether the case material comes beforehand, whether the 20 minutes include reading time, and which rules the role's complaints fall under, which would make F7's slot specific
- A deeper research pass (L2), offered once: up to 6 more searches and 2 more fetches, several more minutes, for strategy context newer than the July brief, the interviewers' public footprint once named, and loop reports for this role family
- A tuesday-dossier.md from an earlier evidence review, if you have one: verified claims and prohibited-claim guardrails would replace this pack's locally built list; the pack stands without it
