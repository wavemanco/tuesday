Web search was refused, so I'm building the pack from your message and the recruiter's email only. I'll record the refused searches in Sources.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-5-denied-c28a5d4c/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

The web searches were refused, so the pack has no Kelverton research behind it. It is built from your message and the recruiter's email, and I couldn't see the market report. The 21 questions and the POV build all rest on those inputs. Nothing Kelverton-specific comes from outside them.

The pack names two things as most worth your four hours:
- **C1, the highest-ROI prep:** the "never sold into rail, never carried a direct quota" objection, rehearsed through four follow-up levels.
- **B1 to B3 and D3:** the questions where Ross will pick apart the roughly £4M and the 6 to 40.

Say the word and I'll play Deepa or Ross on C1.
I can also save a tuesday-dossier.md recording what this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the JD text and the CV you applied with to paste? They would replace the recruiter-wording requirements with JD quotes and add a question for each JD requirement; if not, the pack stands as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your POV on where you would take Kelverton's operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. The rest is Q&A, and Ross will push on commercials.

**Built from:** your message and the recruiter's email as you quoted it. No JD text, no CV text, no text of the market report, no web research (all five searches were refused). Every Kelverton-specific fact in this pack is one the recruiter's email gave you; everything else is labeled.

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script. Where a cell says answer slot, it is an instruction for the interview, not a question for me: answer it from your own experience, or say plainly that the practice was not yours.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (none banked here: no values-style round is documented in what you gave me) |
| EXP | Whether your claims survive scrutiny and attribution |
| JD | Whether you can do the job as described, gaps included |
| CO | Company and market knowledge, thinking at the company's altitude |
| CASE | A live problem from the actual role |

Bank letters follow personas: A Case/Strategist, B Data-Driven Prober, C Skeptic, D Pressure, E Peer Evaluator, G Conversational. The letter F is skipped so question IDs never collide with fit-snapshot rows F1 to F5. Each question carries one type tag, so a dual-purpose question is tagged by what it mainly scores and the rationale says the rest.

## Prep triage

Four hours across the weekend, in this order. Each block names where it lives.

| Block | Time | What to do | Where |
|---|---|---|---|
| 1 | 60 min | Re-read the market report with three marks: one item you would bring as shared ground, one you would diverge from and why, one change an operator's own people would notice. Choose one thesis and write bullets, not a script | POV build, T1 to T3 |
| 2 | 50 min | Say C1 aloud through all four levels and record it; then D2 with a friend or timer cutting you off. This is the highest-ROI prep in the pack | C1, D2, C2 |
| 3 | 45 min | Write, in your own words, what you can and cannot say about how the roughly £4M and the 6 to 40 were counted; if you do not know, write that | B1, B2, B3, D3 |
| 4 | 45 min | Deliver the POV aloud at 15 minutes twice, then once cut to 10 minutes in case you are interrupted | POV build, A1 |
| 5 | 25 min | Choose three reverse questions; read E1 and A5 through once | Reverse questions, E1, A5 |
| 6 | 15 min | Ask me to drill C1 live | C1 |

Everything else in this pack is insurance.

## Fit snapshot

No JD was supplied, so the requirements are the recruiter's own words, quoted from your message, plus the one domain line you gave about Kelverton. No row is a hard gate: none of the supplied wording states a term such as location, pay, authorization or travel.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says an ISV channel in payments, not operator partnerships, and nothing inspected sits behind it. The words stay at that scope: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the recruiter's wording asks where you would take the partnerships, so expect a probe on how you choose. If any part of the channel's growth was a choice of yours about which partners to pursue, say what and how you decided; if there was no such choice, or it was not yours, say so plainly and return to the six to forty |
| F2 | "Ross will push on commercials" — recruiter's email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | Your message gives the figure and calls it influenced; it does not show how it was counted. The words stay at the figure's scope: "roughly £4M of influenced revenue." Answer slot: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly and stop there |
| F3 | "Ross will push on commercials" — recruiter's email | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so; this is split from F2 because it holds a stated absence, not a thin figure. Words: "I've never carried a direct quota." Then what you would want to be measured on, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F4 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The quote carries bus and light rail network planning; your material does not say train operating companies, which operators you dealt with, or what the other side was. The words stay at the quote: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: if the consulting work put you in direct contact with operators, say who they were and what you saw; if it did not, say so plainly and stay with the network planning |
| F5 | "they sell scheduling software to train operating companies" — your message | "Never sold into rail specifically" — your message | none | [grounded] | capability | No supplied source says selling into rail is required; this is the gap you named, and it is the one the quote states. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |

## Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. This section is the build.

**The brief, in the recruiter's words**

| Element | Wording | Provenance |
|---|---|---|
| Length and form | "First 15 minutes" and "no slides needed, just talk us through it" — recruiter's email | [grounded] |
| Scope | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | [grounded] |
| Required close | "Please land on what it means for the operators themselves" — recruiter's email | [grounded] |
| Scope ambiguity | The email does not say whether operator partnerships means partnerships with operators or partnerships built around them. Say your reading in one sentence at the start and invite correction | [inferred] |

**What you may build on from your own material**

| Row | Quote | How to use it |
|---|---|---|
| F1 | "took it from 6 partners to 40, roughly £4M of influenced revenue" | A reference point for how you think about partner programmes, said at its own scope. It is adjacent evidence, so the POV is your view, not a record |
| F4 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Where your operator-side framing comes from, said at its own scope; do not widen it to train operating companies |

**Three theses, each with the concession you must make**

You have seen the market report and I have not. Choose the thesis the report does not already lead with; each is a pattern for partnership strategy, not a claim about Kelverton.

| ID | Thesis | Mandatory concession | Provenance |
|---|---|---|---|
| T1 | Concentrate: choose a small number of operators and build partnerships around a shared outcome, not coverage | Concentrating means saying no to some operators and depending on a few relationships; if one stalls, the plan feels it | [generic] |
| T2 | Operator outcome first: name the change an operator's own people would notice, then choose partnership types by whether they produce it | Operator-outcome measures are harder to tie to revenue, and Ross will ask for the number; have your answer for how Kelverton would know it was working | [generic] |
| T3 | Repeatable before bigger: a standard way to start, run and review a partnership so each one takes less bespoke effort | Standardising risks treating operators as alike; the operator lens has to come first, or it reads as a channel playbook carried over from another sector | [generic] |

**Differentiation and the anti-pick**

| Move | What to do | Provenance |
|---|---|---|
| Ground, then depart | The report is equally available to both interviewers and to any rival candidate. Bring one item it already says, to show you read it, then one divergence with your reason. Reciting its shortlist scores as homework; departing from it with reasons scores as judgment. The pack has not seen the report, so you pick both | [generic] |
| Anti-pick | Say one thing you would deliberately not do in 18 months, and why. Where the role is to decide where partnerships go, a plan with no no in it is a wish list. If your own headline figure is a partner count, consider saying that you would not lead with a count here | [generic] |
| Concede unprompted | Name one limit of your own thesis before anyone asks. It is the cheapest credibility in the 15 minutes | [generic] |

**Talk shape (scaffolding, 15 minutes)**

| Minutes | Beat | Note |
|---|---|---|
| 0 to 1 | Your reading of operator partnerships, in one sentence; your thesis in one line | Invite correction once, then move on |
| 1 to 4 | The one item you share with the report | Say it is from the report |
| 4 to 9 | Your divergence and why, with its concession | Expect Ross to cut in here; rehearse resuming |
| 9 to 12 | What you would do first, and what you would not do | The anti-pick lives here |
| 12 to 15 | What it means for the operators: one change in their terms, how Kelverton would know it was working | The recruiter asked for this close; do not shorten it when you run over |

## Persona table

Weights are a shown judgment from the recruiter's words and the two roles on the panel; the per-member assignment is a prior from role titles, not from anything public about Deepa or Ross. Recalibrate if you know something I do not.

| Persona | Bank | How it shows up | Weight and reasoning | Basis | Counter-strategy |
|---|---|---|---|---|---|
| Case/Strategist | A | Live plan questions on operators and the 18 months, mainly from Deepa | High. The first quarter of the hour is a strategy talk, and the Q&A will test the same altitude | "present a short POV on where you'd take our operator partnerships over the next 18 months" | Clarify, objective, segmentation, approach, measures, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | B | Your two headline figures taken apart, mainly from Ross | High. The recruiter named commercials as where Ross will push, and your numbers are the first commercial material he has | "Ross will push on commercials" | Know what you can and cannot say about how each figure was counted; say plainly when you do not know; name your weakest assumption before he does |
| Skeptic | C | Quiet, persistent probing of the rail and quota gaps, mainly from Deepa as your future manager | High. Both gaps are stated by you and sit against the role as described | your message: "Never sold into rail specifically" | Rehearse C1 until it is boring: concede the facts plainly, hold only what the quotes carry, give a plan |
| Pressure | D | Time-boxed, interrupting versions of the same gaps and figures, from Ross | Mid. Commercial pushing is not the same as stress testing; this is the same material in a faster register | "Ross will push on commercials" | Pause, restate the question, hold through two follow-ups, concede specifically |
| Peer Evaluator | E | The seam between partnerships and commercial; credit and ownership | Mid. A VP Partnerships and a Commercial Director on one panel suggests the seam is a live topic, but nothing in the email says so | "Deepa (VP Partnerships, your future manager) and Ross (Commercial Director)" | Offer seam principles rather than pretending to know the seam; lead with what you would give, then what you need |
| Conversational | G | The opening biography and a casual topical question | Low. Sixty minutes with a 15-minute set piece leaves little room, but the opener is nearly certain | "60 minutes" | A 90-second arc; treat casual questions as scored |
| Values/Behavioral | none | Not banked | Not plausible here: the email names a POV and Q&A, and no published values were available to me | none in the email | If one arrives, use the open-prompt scaffold in E2 |

## Question banks

Provenance leads with one label; quotes in it are your own sentences from your message.

### A. Case/Strategist (high), 5 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've got fifteen minutes. Where would you take our operator partnerships over the next 18 months, and what does it mean for the operators?" | CASE | [grounded] | This is the deliverable, built in the POV section above, not a question to improvise. Open with your reading of operator partnerships in one sentence and invite correction; one thesis; one concession said unprompted; finish on the operators. Present it as your view, not as a record | The recruiter announced it, so it is graded; CASE because it is a live plan. F1 is the row an interviewer will use to test whether the view has a past behind it |
| A2 | "Which operators would you start with, and which would you deliberately leave alone for now?" | CASE | [generic] | Clarify first: say what you would need to know to choose, including what the current partnership map looks like, which you do not hold. Then give two criteria in your own terms, choose, and name one operator or kind you would leave alone and why. Do not describe any operator's situation unless the report does | The leave-alone half drills the anti-pick; CASE because it asks for a constructed choice. F1 is thin on choosing, so this is where that thinness would show |
| A3 | "Eighteen months from now a partnership is working. What's different for the operator, in their terms, not ours?" | CASE | [generic] | Answer from the operator's side first: one change an operator's own people would notice, then how Kelverton would know. Choose the change from the report, not from this pack, which does not know the operators' current constraints. If you cannot name one, say what you would ask an operator to find out | The recruiter asked for the close to land on operators; F4 is the row used to test whether that lens is real. CASE rather than CO because it asks for a constructed answer |
| A4 | "What's the biggest risk to our operator partnerships over the next 18 months?" | CO | [generic] | Pick one risk from your reading of the report and say why it outranks the others; separate what the report says from what you are inferring. Concede plainly what only an insider would know. Do not recite the report's list | CO because it tests company-altitude thinking; generic because no research ran and the report was not available to this pack |
| A5 | "Sketch how you'd structure the commercial side of a partnership with an operator. What do you need to know first?" | CASE | [generic] | Clarify (are operators customers, partners, or both here), then what each side puts in and gets, how it is measured, the risks. Where a term or a figure matters, ask rather than propose a market rate; the pack gives none | Ross will push on commercials, so they arrive as a live problem as well as a CV probe. F3 is why the answer stays a structure and not a record |

### B. Data-Driven Prober (high), 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that £4M of influenced revenue was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say the figure at its own scope: roughly £4M of influenced revenue. Answer slot: say how it was counted, in your own words; if you do not know how it was counted, say so plainly. Do not describe a method you could not repeat under a second question | F2 is the first commercial material Ross has; EXP because it tests whether the claim survives |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Name, before he does, the assumption you know of that you would defend least, in your own words; naming it turns a gotcha into credibility. If you do not know of one, say you do not know how the figure was built and what you would check. The pack names no assumption for you | The weakest-assumption move for F2; EXP because it tests whether you know your own number |
| B3 | "Six to forty partners. What counts as a partner in that number?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say the numbers as the sentence has them: from 6 partners to 40. Answer slot: say what counted as a partner, in your own words; if it was not tracked consistently or you do not know, say so plainly. Keep the count attached to partners: it counts partners, not revenue and not operators | The count is the second headline figure after the revenue, and the denominator is the first follow-up on it; F1 holds the quote |
| B4 | "Our partnerships team will be accountable for commercial outcomes. What would you want to be measured on in your first year, and why?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | A plan, not a past. If it comes up, the plain words are "I've never carried a direct quota." Then name two or three measures in your own words, what each would tell you and what it could not tell you, and say you would first ask what the team is measured on today | F3 turned forward: Ross cannot test a past that the material says does not exist, so he tests judgment. JD because it scores the commercial requirement |

### C. Skeptic (high), 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't sold into rail and you haven't carried a direct quota. Convince me that isn't a problem in this role." | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue"; "last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The highest-ROI prep in this pack: this question will arrive in some form. Hold-then-concede, four levels. Limit first, as the pack's observation: your material says an ISV channel in payments, not rail; bus and light rail, not train operating companies; influenced revenue, not direct. Level 1: concede plainly, "I've never sold into rail specifically, and I've never carried a direct quota"; then hold only what the quotes carry: "For four years I ran the ISV channel at a payments company and took it from 6 partners to 40. Earlier, I spent five years in transport consulting on bus and light rail network planning." Stop; do not argue what that proves. Level 2, "so nothing shows you can carry a number?": "The revenue figure I can give you is influenced revenue, roughly £4M of it", and concede it is not a direct quota; never call it equivalent. Level 3, "what would your first 90 days look like?": a plan in your own words, what you would learn first and from whom. Level 4, "and if you can't close the gap?": say how you would know, and who you would ask to tell you. Never fold on the core to restore harmony, and never add to the quotes to win a round | F3 and F5 are the stated negatives and the likeliest first objection from a future manager; Deepa asks it quietly, Ross asks it as a number in D2. JD because both gaps sit against the role as described |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | Choose the weakness yourself and say it first; your material already gives you one, in your own words: "I've never sold into rail specifically." Then say what you would do about it in the first weeks, as a plan. One weakness, not a list | F5; the stem is the Skeptic's standard, and JD because it scores your self-assessment against the role |
| C3 | "Bus and light rail planning isn't train operations. What would you expect to be different?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | State your scope in the quote's terms: five years in transport consulting on bus and light rail network planning. Then answer as expectation, not experience: what you expect differs and what you would check first. Answer slot: if the consulting work put you in direct contact with operators, say who and what you saw; if it did not, say so plainly and stay with network planning. Do not use "I know the operator world" for more than the sentence says | F4 is the evidence for the operator lens, and the limit is the row's. EXP because it tests what those years actually were |
| C4 | "Why leave payments for rail-tech, and why now?" | EXP | [grounded] "last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The two quotes are the facts of the path and say nothing about why. Answer slot: say your actual reason for this move and its timing, in your own words; if part of it concerns the transport background, say how, and if it does not, do not add it. The pack supplies no reason | Motivation consistency under cross-examination; F1 and F4 are the two ends of the path. EXP because it is the career story under challenge |

### D. Pressure (mid), 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's already sold into train operating companies?" | JD | [grounded] "Never sold into rail specifically"; "last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause and restate the question in your own words. Concede first: "I've never sold into rail specifically." Hold what the quotes carry: you ran the ISV channel at a payments company for four years and took it from 6 partners to 40. Do not compare yourself to the hypothetical person; say what you would bring and what you would need to learn, and stop at sixty seconds | The Pressure stem applied to F5 in Ross's likely register. JD because it scores fit against the role |
| D2 | "You've never carried a quota. Why would we hand you commercial targets?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Hold-then-concede. Restate; plain acknowledgment: "I've never carried a direct quota." Hold: the figure you have is influenced revenue. Then how you would want targets set, as a plan. Do not call influenced revenue effectively the same as a quota; that equating is the move that loses the second follow-up | F3 under the commercial push; the same limit as C1 in a faster register |
| D3 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "last 4 at a payments company running the ISV channel" | Answer slot: say which part was yours and which was others', in your own words; if you cannot separate it, say so plainly and say what you would need to look at to know. Hold on the sentence as written and never describe your share as larger than it says | The attribution probe on F2 in Pressure's register; EXP because it exists to catch inflation |

### E. Peer Evaluator (mid), 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and commercial sit side by side. Where's the seam, and what happens when we disagree about who owns a deal a partner brought in?" | CASE | [generic] | Propose seam principles, not a claim to know Kelverton's seam: who decides, what gets recorded, how a dispute escalates. Ask how it works today before proposing. Say what you would want to agree with Ross in the first month | Both functions are on the panel; Peer evaluators price what the hire does to their own work. Asked collegially; presupposes nothing about your past |
| E2 | "How do you handle credit when the work spans teams?" | EXP | [generic] | Selection scaffold: pick a time credit for a result was shared across teams; it needs a named result, who else was involved, and how it was divided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. For your headline figure, use B1 to B3 and D3, not a story built here | The Peer stem; EXP because it asks for a chosen instance, which only you can supply |
| E3 | "What do you need from commercial in your first month, and what can you give us?" | CASE | [generic] | Two parts in this order: what you would give, named in your own words, and if you cannot yet, what you would find out first; then what you would need. Reciprocity beats a shopping list | The reciprocity question for a peer-level interviewer; CASE because it asks for a first-month plan |

### G. Conversational (low), 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Ninety seconds in three beats, each a clause the quotes state: five years in transport consulting on bus and light rail network planning; nine years in partnerships; the last four of those running the ISV channel at a payments company, taking it from 6 partners to 40. Leave the revenue figure out of the arc unless asked, because Ross will open it; give it only at its scope, roughly £4M of influenced revenue. End on why this role: answer slot, your actual reason in your own words, as in C4 | The near-certain opener; F4 and F1 supply the beats. EXP because it is your own record in sequence |
| G2 | "What have you been thinking about lately in how operators and software suppliers work together?" | CO | [generic] | Casual register, still scored. Have one view ready, say if it comes from the report, and add one thing you would want to test. Do not claim to have worked on it | A casual question on the topic of the POV. CO because it tests current thinking; generic because no research ran and the report was not seen by this pack |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: POV on operator partnerships over 18 months | A1, A2, A3, A4, G2, and the POV build |
| F2: commercials, the headline figures | B1, B2, B3, D3 |
| F3: commercials, no direct quota | A5, B4, C1, D2, E1, E3 |
| F4: the operators' side | A3, C3, C4, G1 |
| F5: selling into rail | C1, C2, D1 |
| JD requirements | none, and why: no JD was supplied; the upgrade menu says what one adds |

## Reverse questions

| # | Question | To | Why it lands |
|---|---|---|---|
| R1 | "How do you define success for an operator partnership twelve months in, in the operator's terms and in ours?" | Deepa | It returns to the brief's own close and asks the person who will manage you for the measure you will be held to |
| R2 | "Where do you want partnerships and commercial to draw the line on who owns a partner-sourced deal, and what has worked at that seam so far?" | Ross | It turns his commercial push into a joint design question and shows you think about his function's side |
| R3 | "What did the strategy team's report get right that you would most want me to push on, and what would you challenge in it?" | Deepa | It shows you read it without reciting it, and invites the panel's own view of its limits |
| R4 | "What would you want to see from me in the first 90 days to know the hire was right?" | Deepa | It brings the rail and quota concerns into the open on your terms and gets the scoring criteria stated |
| R5 | "Which operators engage most deeply with Kelverton today, and what do they do differently?" | Deepa | It asks for evidence about the operators themselves, which is the lens the recruiter asked you to land on |
| R6 | "What could a new person in this role do in the first month that would genuinely help your team?" | Ross | The reciprocity question: it asks what the hire gives his team, not what it takes |
| R7 | "Is there anything in my background you would want to test further that we haven't covered?" | Both | It surfaces any remaining doubt while you can still answer it; rehearse it after C1 so the answer is ready |

## Prohibited claims

What this pack will not coach, and why. Built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail or into train operating companies | Negative you stated, F5 | The plain acknowledgment: "I've never sold into rail specifically." Then a plan, never a past |
| Has carried a quota or closed revenue directly | Negative you stated, F3 | The plain acknowledgment: "I've never carried a direct quota." Influenced revenue stays at its own scope |
| The £4M as won, closed or owned revenue | Inflated form of F2 | F2's quote at its own scope: roughly £4M of influenced revenue. The limit is the pack's observation: your material says influenced, not who closed it. The slots ask only how it was counted and which part was yours |
| Knows train operating companies from inside, or has worked with them | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says bus and light rail network planning, not train operating companies. C3's slot stays inside the consulting work |
| Designed or built the partner programme, or set partner terms | Inflated form of F1 | F1's quote at its own scope: ran the ISV channel and took it from 6 partners to 40. The limit is the pack's observation: the material says running the channel, not designing it. F1's slot asks only about choices of yours |

## Sources

Provided: your message, including the recruiter's email as you quoted it. Named by you but not available to this pack: the market report the recruiter attached; nothing in this pack is drawn from it. No dossier was present. No grounding brief is included: no research ran and no strategy brief text was in hand. No interviewer read is included: no public footprint was available.

Queries sent, all refused (the search permission was declined, so none returned anything):

- `Kelverton Rail company values` — refused
- `Kelverton Rail interview process partnerships manager` — refused
- `Kelverton Rail scheduling software train operating companies strategy news` — refused
- `Deepa VP Partnerships Kelverton Rail; Ross Commercial Director Kelverton Rail` — refused
- `Senior Partnerships Manager job description rail technology software train operators` — refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have fed the values cheat sheet and VAL themes; no values-style round is detected in your material, so that section is dropped either way |
| 2. Kelverton Rail interview process, partnerships | unavailable | Would have shown whether other rounds follow this panel and whether any is values-style; the recruiter's words already fix this session's panel, form and length, so this session's persona weights stand |
| 3. Kelverton Rail strategy and recent news | unavailable | Would have moved the CO questions A4 and G2 from generic to grounded and enabled a grounding brief |
| 4. Deepa and Ross at Kelverton Rail | unavailable | Would have moved the interviewer read, persona weights per member, and a reverse question tied to an interviewer's own path |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have turned F1 to F5's recruiter-wording requirements into quoted JD lines labeled inferred, and added JD-tagged questions |

## Upgrade menu

- The JD text → F1 to F5 requirement cells become JD quotes, every JD requirement gets a question, and the coverage table's last row closes
- The CV you applied with → evidence cells quote CV lines beyond your message; F1 and F2 can reach high confidence if paired with an inspectable artifact such as a partner-sourced revenue report or the partner count by quarter
- The market report pasted in → a grounding brief, differentiation in the POV build set against its actual shortlist, and A2 to A4 and G2 grounded instead of generic
- Web search permission → the five targets above, then the interviewers' public footprint (a tailored reverse question and persona weights per member); a deeper pass, up to 6 more searches and 2 more fetches, several more minutes, is available once search is allowed
- One email to the recruiter asking whether operator partnerships means partnerships with operators or around them → the POV's scope sentence and A1 rest on a fact instead of a reading
- The round's other sessions, if the loop has more → per-round mini-packs
- A tuesday-dossier.md from an earlier evidence pass → verified evidence and a fixed list of prohibited claims, so the highest-ROI objection comes from evidence rather than inference
