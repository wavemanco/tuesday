I'll read the reference files the skill requires before building the pack.
Dara, your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/alone/part-2/rooms/case-8-canned-c80a5164/ashgrove_credit_union_member_experience_lead_interview_pack.md`. I built it in loop mode for your three rounds on 20 November. It has 28 questions across the three rounds, with a nine-day prep plan at the top.

I used only what you pasted: no web searches, because your values, the recruiter's email, the JD and the strategy summary already settled everything a search would have fed.

The question to rehearse first is D1, the Head of Member Services asking what makes you ready to own complaints across every branch and the contact centre, when you've handled one branch's log and haven't worked in a contact centre. The coaching on it only uses sentences you wrote. Several rows in the pack end in "answer slots" where I don't know the true answer, such as what your spreadsheet counted and whether it was in Excel. Fill those in your own words, including a plain "no" where that's the truth.

Say the word and I'll play the Skeptic on D1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_credit_union_member_experience_lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Date of loop:** 20 November 2026 (pack built 11 November 2026, nine days out).
**Mode:** loop, three scheduled rounds, one shared fit snapshot, a mini-pack per round.

| Round | Who | Format (recruiter's words) |
|---|---|---|
| Round 1 | Recruiter | "30 minutes with me" |
| Round 2 | Head of Member Services, your future manager | "45 minutes ... mostly behavioural" |
| Round 3 | Panel of two branch managers | "60 minutes ... including a 20-minute case on a complaint escalation ... the panel is also the values round — they score against the four values" |

Interviewer names are not assigned yet beyond these roles, so there is no interviewer read in this pack.

## How to use this pack

- Personas are how a question is asked. Types are what it scores. Every question carries one persona (its bank) and one type tag.
- Type key: **VAL** whether your past behaviour shows Ashgrove's published values; **EXP** whether what you said about your work survives follow-ups; **JD** a stated responsibility or requirement; **CO** whether you know where Ashgrove is heading; **CASE** a live problem from the role.
- Provenance: `[grounded]` traces to something you or Ashgrove supplied; `[inferred]` is this pack's derivation, named; `[generic]` is a pattern with no claim about you or Ashgrove. Where guidance rests on something you said, your exact sentence sits beside the label.
- Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: say which branch is true for you in your own words. Both branches are acceptable, and "that was not mine" is a complete answer.
- Question IDs run by persona across the pack (A to I) so you can name one when you want a drill.

## Prep triage (nine days)

1. **By 12 November:** write your own answers to the slots on F2, F3, F5, F6, F8 and F9, including a plain "no" where that is the truth. They feed A3, D1, E2, C1 and D3. If you send them to me, the pack regenerates with them as quoted material.
2. **13 to 15 November:** say D1 out loud three times, including its follow-ups. It is the highest-ROI rehearsal in the pack. Then B1 and D2, which use the same acknowledge-then-plan structure.
3. **16 to 17 November:** H1 timed at 20 minutes, then H2. Draft one true story per value for G1 to G4, or the honest branch where none comes to mind.
4. **18 to 19 November:** A1 timed to 90 seconds; decide your salary range and start date for A4; pick one strategy item for A5; choose two reverse questions per round.
5. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your sentence already reaches the requirement in other terms, so lead with it in its own terms: "Six years in retail banking, the last three as a branch supervisor." It has nothing inspected behind it, so expect a probe on what those years held; the pack adds nothing to the sentence |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [inferred] | discovery | The sentence shows a formal log; your material does not show whether the complaints on it fell under regulatory rules or deadlines. Answer slot: if they did, say which and how you worked to them, in your own words; if they did not, or you do not know, say so plainly and stay with "I handled the branch's formal complaints log" |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your sentence says one branch's log, and your material does not show a part beyond it. The words stay at its scope. Answer slot: a probe is likely on how far your part of a complaint went. Say where a complaint on the log came to you from and where it went afterwards, in your own words; if your part started and ended at the log, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing that calls the log or the branch equivalent |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | The sentence says you built a monthly complaints spreadsheet your regional manager uses; it does not say what the sheet counted. Answer slot: if it counted volumes or resolution times, say how each was counted and which count you would defend least; if it counted something else, or you do not know how a count was made, say so plainly and stay with "I built the monthly complaints spreadsheet our regional manager uses" |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | The sentence says spreadsheet, not which program. Answer slot: if it was built in Excel, say so in your own words; if it was another program, say so plainly and stay with the sentence |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented above regional level." Then how you would prepare for a senior audience, said as a plan. Your material does not say whether you presented at regional level, so the pack does not say it either |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your sentence says new tellers and the escalation script, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe likely on how you trained them. Say how you took the tellers through the script, in your own words; if it was a walk-through of the script as given, say so plainly, and return to the sentence |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you have worked with a digital team on anything, say what it was and which part was yours; if you have not, say so plainly, then say how you would approach it as a plan |

## Grounding brief (from the strategy summary you supplied)

| Fact | Provenance | Where it bites |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] "2026 strategy brief Ashgrove published in July 2026" — your message | A5, E1, D3 |
| Consolidate eight branches into five hubs over 2027 | [grounded] same source | A5, G3, H3 |
| Launch a small-business lending product in Q1 2027 | [grounded] same source | H4 |
| Main competitive pressure is app-only banks | [grounded] same source | E1 (a premise to test, not a claim to make) |

The brief is four months old as of today. You supplied a four-point summary rather than the document, so nothing beyond those four facts is claimed.

---

# ROUND 1: Recruiter (30 minutes)

## Persona table, Round 1

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (5 questions) | Friendly walk through your background, motivation, logistics, a casual "what do you know about us" | High. The recruiter-screen prior is conversational, and the risk is treating it as unscored | A 90-second arc (A1), figures and dates decided in advance (A4), the casual strategy question treated as scored (A5), reverse questions ready |
| Skeptic, light (3 questions) | Knock-out checks on the gaps, asked kindly | Medium. The two gaps your own message states, F4 and F7, are what a screen checks first | Acknowledge in one sentence, bridge only from your sentences, give a plan (B1, B3); the full version is D1 |

Case and Pressure are not plausible in 30 minutes with a recruiter, so they carry no bank here.

## Question bank, Round 1

### A. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Three beats, each a clause your sentences state, in your own words: six years in retail banking, the last three as a branch supervisor; handled the branch's formal complaints log and trained new tellers on the escalation script; built the monthly complaints spreadsheet your regional manager uses. Finish on your own reason for wanting this role. The pack does not know it and does not supply one; if it is not clear yet, say so plainly and name what about the role draws you. Keep to 90 seconds | F1, F3, F5 and F8 are the rows this arc carries, so the biography question is where they are first heard. EXP because it tests whether the arc matches what the CV-level facts say |
| A2 | "Why a credit union, rather than another bank?" | CO | [grounded] | Answer from your own reason; the pack does not know it. The JD calls Ashgrove "member-owned", and the first value says "we decide from the member's side of the counter". If your reason connects to either, say how in your own words; if it does not, say so plainly and give the reason you do have. Do not say anything about credit unions in general that you could not defend | Motivation consistency is what a screen scores, and the question reads the JD's ownership wording and the first value. CO because it tests whether you chose this employer knowingly |
| A3 | "You mention the branch's formal complaints log. What did handling it involve?" | EXP | [grounded] "I handled the branch's formal complaints log" | Describe the log in the sentence's own terms, then stop. Answer slot: if the complaints on the log fell under regulatory rules or deadlines, say which and how you worked to them, in your own words; if they did not, or you do not know, say so plainly and stay with the log | F2 is the row where the JD's requirement and your sentence are furthest apart in precision, and a recruiter checks it first. EXP because it tests what was actually yours |
| A4 | "Before we go further — what are you hoping for on salary, and when could you start?" | JD | [generic] | This question needs no claim about your past, and the pack does not know your figure or your dates. Decide both before 20 November: a range you can stand behind and a start date that allows for any notice. Say them plainly. If you have not decided, say so and ask for the band first | The JD as supplied gives no pay, so a screen is where it comes up. JD because it is a stated term of the role; `[generic]` because it is a pattern for the round |
| A5 | "What have you picked up about where Ashgrove is heading?" | CO | [grounded] | Choose one item from the strategy summary: moving 40% of member service to digital channels by 2028, or consolidating eight branches into five hubs over 2027. Say what question it raises for complaints, phrased as a question you would want answered, not a view on how Ashgrove should run it. One item and your question, not a recital | Casual questions on hot topics are scored. The brief is shared with interviewers, so a recital scores as homework and a question scores as judgment. CO because it tests homework depth |

### B. Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches, and I don't see contact-centre work in your background. How do you see that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Acknowledge first and briefly: "I haven't worked in a contact centre." Then what your sentence carries, at its scope: "I handled the branch's formal complaints log." Do not call that equivalent. Then a plan, said as a plan: how you would learn the contact centre's handling in your first weeks, who you would sit with, what you would ask, in your own words. This is the light version of D1; rehearse D1 first | F4 is a gap you stated, so it is the knock-out a screen checks. JD because it scores a stated requirement, and the Skeptic persona because it is asked as a quiet gap probe |
| B2 | "Why this move, and why now?" | JD | [generic] | Selection criteria: pick the true reason; it should name something specific about the role (the JD's complaints responsibility, or the member-owned model) and be one you would repeat unchanged to the Head of Member Services. If your reason is mostly about leaving something, say that plainly, then say what you are moving toward. The pack supplies no reason | A screen scores whether the story you tell now will match the story you tell in round 2. JD because it tests fit to the role's content; `[generic]` because the pack knows none of your reasons |
| B3 | "What is the most senior audience you've presented to?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Acknowledge plainly: "I haven't presented above regional level." Answer slot: if you have walked your regional manager through the spreadsheet or what it showed, say how it went, in your own words; if you only sent it, or have not presented at all, say so plainly and stay with "I built the monthly complaints spreadsheet our regional manager uses". Then how you would prepare for a senior audience, as a plan | F7 is the second gap you stated. The question is open, so the honest answer is available without a premise. JD because it scores the requirement |

## Reverse questions, Round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Is contact-centre experience something the team sees as essential for this role, or something the role would teach?" | It raises F4 yourself, in the recruiter's frame, and the answer tells you how to weight D1 |
| R1.2 | "For the panel's 20-minute case, is it built around a branch complaint, a contact-centre one, or both, and is there anything to read beforehand?" | Shows you are preparing for the scored part of the day; the answer reshapes H1 |
| R1.3 | "When the two interviewers for the panel are assigned, could I have their names and roles?" | The recruiter said they are unassigned; asking now unlocks the interviewer read |
| R1.4 | "Which branches and teams would this role cover once the 2027 hub consolidation starts?" | Connects the role to the brief you were sent, and signals you read it |
| R1.5 | "What does the Head of Member Services most want the person in this role to have done by the end of their first three months?" | Gives you round 2's success criterion before you are in the room |

---

# ROUND 2: Head of Member Services (45 minutes, your future manager)

## Persona table, Round 2

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (3 questions) | Scenario probes: coaching, hard conversations, hard complaints | High. The hiring-manager prior is Case plus Skeptic, but the recruiter says this round is "mostly behavioural", so Values/Behavioral moves up | Pick stories before the day; "we" for context, "I" for what was yours; for each, the honest branch if none comes to mind (C1 to C3) |
| Skeptic (3 questions) | Calm, persistent probing of the scope jump, senior presenting, digital work | High. A manager who will own your results is derisking the gaps; F3, F4, F7 and F9 are the likely targets | Rehearse D1 until it is boring: hold what your sentences carry, concede what you stated, give a plan (D1 to D3) |
| Case / Strategist (3 questions) | Live problem on Ashgrove's actual roadmap, a first-90-days plan, a prober's walk through the spreadsheet | Medium. The hiring-manager prior includes live problems, trimmed by the recruiter's "mostly behavioural" | Clarify, structure, think aloud, challenge one premise respectfully (E1 to E3) |

Pressure and Peer Evaluator are not weighted here: nothing in the recruiter's description signals either from your future manager.

## Question bank, Round 2

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story map on F8: whom (new tellers) and what (the escalation script), the beats your sentence states, in your own words. Answer slot: say how you took the tellers through the script; if it was a walk-through of the script as given, say so plainly, and return to the sentence. Do not describe a particular teller's difficulty unless it happened and you can say it | F8 is the one row that touches the coaching responsibility, so this is where it is tested. JD because it scores the stated responsibility; the Values/Behavioral persona because it arrives as "tell me about a time" |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you did not soften it, a leader who heard it, and a relationship intact at the end, and where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack names no event because none of your sentences carries one | Your future manager will present results upward and needs someone who says what the numbers show. VAL because it tests behaviour, not knowledge |
| C3 | "Tell me about a complaint that was hard to resolve and what you did." | EXP | [grounded] | Choose one you can tell in 90 seconds: what made it hard, what you personally did, how it ended, what changed. Say what was yours and what was someone else's. If no such complaint comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's complaints responsibility raises this theme. EXP because it tests attribution; the pack supplies no incident |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns complaints across every branch and the contact centre. You've handled one branch's formal complaints log and you haven't worked in a contact centre. What makes you ready for that scope?" | JD | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses"; "Never worked in a contact centre" | **Highest-ROI prep in this pack.** Name the limit before they press it: "I haven't worked in a contact centre." Hold what your sentences carry, at their scope: you handled the branch's formal complaints log, trained new tellers on the escalation script, and built the monthly complaints spreadsheet your regional manager uses. Answer slot: say how far your part of a complaint went beyond your own branch, in your own words; if it did not go beyond it, say so plainly and stay with the three sentences. Then a plan, as a plan: what you would learn first and from whom. Follow-ups to rehearse: (1) "How is one branch's log different from this?"; hold, then concede the difference plainly. (2) "What do you do in week one with a team whose work you haven't done?"; plan only. (3) "So you're not ready?"; hold: you would be learning one part, with a plan; concede: the contact centre is new to you. Never add a duty to any of the three sentences | F3 and F4 together are the likeliest objection to this candidate in any form and in any round, from the recruiter's B1 to the panel's. JD because it scores the headline responsibility; the Skeptic persona because it is a gap probe, and the question holds only negatives you stated |
| D2 | "Monthly results go to senior leaders, and your experience of presenting stops at regional level. How would you prepare?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Acknowledge plainly: "I haven't presented above regional level." What you hold is the material, not the presenting: "I built the monthly complaints spreadsheet our regional manager uses." Say it that way. Then your plan in your own words: what the leaders need to decide, how short you would make it, who you would rehearse with. If pushed with "so you can't do it?", hold: you would prepare for it; concede: it is the first time at that level | F7 is the second stated gap and is a listed requirement. JD because it scores the requirement; Skeptic because it presses on the stated limit |
| D3 | "Have you worked with a digital team on anything?" | JD | [grounded] | Answer slot: if you have worked with a digital team on anything, say what it was and which part was yours, in your own words; if you have not, say so plainly. Then your approach as a plan: what complaint themes you would bring a digital team and what you would ask them first | F9 is silent in your material and the strategy puts digital at the centre of the role. JD because it scores a stated responsibility |

### E. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We want 40% of member service on digital channels by 2028. What does that mean for complaints?" | CASE | [grounded] | Clarify first: whether complaints are inside the 40%. Then objective (the member's side of the counter), segments (by channel and by kind of complaint), approach (how one record follows a member from app to contact centre to branch), metrics (the two the JD names, volumes and resolution times), risks. Challenge one premise as a question: whether every kind of complaint suits a digital-first route. Say that as a question, not a verdict. Use the 2028 target and the hub plan as stated | The brief sets the role's context, and a manager scores whether you can think at its altitude. CASE because it is a live problem; CO because it uses the company's own target |
| E2 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Beats your sentence states: you built it; it is monthly; your regional manager uses it. Answer slots: if it counted volumes or resolution times, say how each was counted and which count you would defend least, before they ask; if you do not know how a count was made, say so plainly. If it was built in Excel, say so; if it was another program, say that plainly. Do not describe columns, formulas or findings you cannot repeat under a second question | F5 and F6 both rest on this one sentence, and a prober will test it. EXP because it tests what was yours; the JD's reporting and Excel lines are why it is asked |
| E3 | "What would your first 90 days look like?" | CASE | [generic] | A structure, not claims: learn before you change; the contact centre, the branches and the current monthly numbers first; one early thing you would deliver; who you would meet. Concede F4 inside it as a plan: that the contact centre is where you would start. Do not promise changes before seeing the data | A future manager uses this to see how you would handle the gaps. CASE because it is a live planning problem; `[generic]` because it needs no claim about the past |

## Reverse questions, Round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What does a good first six months look like in this role, and what would worry you at three?" | Lets the manager name the failure they are afraid of, which is the objection to rehearse |
| R2.2 | "How is complaint handling organised today between the branches and the contact centre, and where do the two meet?" | Shows you are thinking about the seam you do not yet know, without claiming to |
| R2.3 | "With eight branches becoming five hubs over 2027, how do you see complaint handling changing, and what should the role prepare for?" | Uses the brief and treats the change as the manager's context, not your view |
| R2.4 | "Which senior forum does the monthly complaints report go to, and what decision does it usually support?" | Turns the presenting gap into curiosity about the audience |
| R2.5 | "What support would the role have for building contact-centre knowledge in the first weeks?" | Names F4 as your plan, and the answer shows how seriously the team treats it |
| R2.6 | "With a small-business lending product planned for Q1 2027, who will own complaints about it before launch?" | Uses a brief fact as a question, not a claim, and signals you read it |

---

# ROUND 3: Panel of two branch managers (60 minutes, 20 of them a complaint-escalation case; scored against the four values)

## Persona table, Round 3

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (4 questions) | One scenario per published value, STAR-shaped | High. The recruiter says the panel "score against the four values" | One true story per value, or the honest branch; hard truth that actually landed (G1 to G4) |
| Case / Strategist (4 questions) | The 20-minute escalation case, then follow-ups | High. The recruiter names a "20-minute case on a complaint escalation", a third of the round | Clarify, structure, think aloud; name what you do not know; use the values' words for Ashgrove only (H1 to H4) |
| Peer Evaluator (3 questions) | Seam-splitting: whose supervisors you would coach and what happens when you disagree | Medium. Branch managers are the people whose supervisors the role coaches, and the panel is built from them | Propose seam principles rather than pretending to know the seam; reciprocity (I1 to I3) |
| Skeptic (no bank) | The D1 and D2 objections return in collegial packaging | Medium-low. Branch managers may ask the same gap questions more gently | Reuse D1 and D2 unchanged; no new material |
| Pressure (no bank) | Time-boxing the case | Low. Nothing in the recruiter's description signals it beyond the 20-minute box | Pause, restate the question, keep to the structure |

## Question bank, Round 3

### G. Values / Behavioral (one per published value)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection criteria: a decision with a cost to you or your branch, what you did, and how the member's side shaped it. Tell it in the words it happened in, and use "member" only for Ashgrove. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack names no event because none of your sentences carries one | Value 1 is "Members First, Always — we decide from the member's side of the counter". VAL because it scores behaviour against a published value |
| G2 | "Tell me about a time a customer needed something explained twice, and what you did about it." | VAL | [grounded] "trained new tellers on our escalation script" | Selection criteria: what was unclear, what you changed, who it was clear to afterwards. If nothing comes to mind, the nearest thing your material carries is the script you trained new tellers on; your sentence says you trained them on it, not that anyone found it unclear, so say only what you saw. If no such time comes to mind, say so plainly, then say how you would handle it | Value 2 is "Plain Words — if a member needs it explained twice, we wrote it wrong". VAL because it scores behaviour against a published value |
| G3 | "Tell me about a time you thought about what a decision meant for one particular branch or community." | VAL | [grounded] | Selection criteria: a specific place, a decision made elsewhere, and what you did about its effect on that place. Do not speculate about whose branch the 2027 consolidation affects; if the hub question is raised, ask what they are hearing. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Value 3 is "Neighbours, Not Numbers — every branch is part of its town", and the panel is branch managers while the brief names a consolidation. VAL because it scores behaviour against a published value |
| G4 | "Tell me about a problem you found that wasn't yours to solve, and what you did about it." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection criteria: the problem, why it was not yours, what you kept hold of, and how it ended. Your sentence says you handled the log; whether any item on it ran until solved is yours to say, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Value 4 is "Own the Fix — whoever finds the problem keeps hold of it until it is solved", and the role is complaints ownership. VAL because it scores behaviour against a published value |

### H. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member comes into a branch about a fee they say was charged in error. They've already raised it twice through the contact centre and nobody called back. The supervisor asks what to do. Take us through it." | CASE | [generic] | **Highest-ROI practice for this round.** Clarify first: what is recorded, when it was first raised, what the member has been told, and which rules or deadlines apply, asked rather than assumed. Objective: the member's side, and someone keeps hold of it until it is solved. Today: acknowledge, record, a named owner, a date to call back. Then the supervisor: what you would coach after. Then the process question: why two contacts did not meet one record. Metrics: volumes and resolution times. Risk: do not blame the contact centre before you see the record. Say what you do not know aloud | The recruiter announced the 20-minute case on a complaint escalation but not its content, so this is a pattern for it. CASE because it is a live problem; `[generic]` because the actual case is unknown |
| H2 | "The supervisor thinks you're wrong, in front of the team. What do you do?" | CASE | [generic] | Structure: do not win the moment; find out what they are seeing; agree one thing now and take the rest aside; hold your position on the member's outcome while conceding on how it was said. Say what you would want to learn from them | The role coaches supervisors, and a branch manager scores how you disagree. CASE because it is a live problem |
| H3 | "Members of a branch scheduled to close into a hub are complaining about the change. How do you handle those complaints?" | CASE | [grounded] | Clarify: whether they are complaining about the change, the service, or both, and whether the decision is one the complaint process can change. Record the themes and feed them to whoever owns the decision; do not argue the decision. Tell the members plainly what happens to their complaint, in words that need no second explanation. Ask what the panel is hearing | The brief names the consolidation and value 3 names the town. CASE because it is a live problem; CO because it uses the company's plan |
| H4 | "A small-business lending product launches in Q1 2027. What would you want in place for complaints before it does?" | CASE | [grounded] | Clarify: who will handle those complaints, and which rules apply to them. Then a plain route for members, a script that needs no second explanation, a record that follows the member, and how it will be reported monthly. Say what you would ask before launch rather than what you would decide | The brief names the launch. CASE because it is a live problem; CO because it uses the company's plan |

### I. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "You'd be coaching our supervisors on escalations. Where's the line between your role and mine, and what happens when we disagree?" | JD | [generic] | Propose principles, not a map you do not have: the branch manager stays accountable for the branch; you agree who tells whom; disagreement goes to the member's outcome first. Ask how they handle it now. Offer what you bring their branch, not only what you need | Branch managers are peers on the seam, and the role's coaching line is aimed at their supervisors. JD because it tests the responsibility; `[generic]` because the pack does not know how Ashgrove draws the line |
| I2 | "Tell me about a time work spanned teams and credit had to be shared." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection criteria: who else was involved, what each person did, what you said about it. Your sentence says you built the spreadsheet; whether anyone else contributed is yours to say. If others contributed, say what and how you credited them; if no one did, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer Evaluator persona probes credit-sharing. EXP because it tests attribution |
| I3 | "From a supervisor's seat, what do you think is hardest about escalations?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | Answer from your seat: the last three years as a branch supervisor, and training new tellers on the escalation script. What you saw is your own and the pack names none; say what you saw. If you did not see a pattern, say so plainly and ask what they see in their branches | Branch managers want to know whether the role understands their supervisors. EXP because it tests what you actually saw; a reciprocity move because it ends in a question |

## Values / principles cheat sheet (Round 3, the values-style round)

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's side | None of your sentences carries a story for it, so use G1's selection scaffold and its honest branch |
| Plain Words | Wording that needs no second explanation | F8: "trained new tellers on our escalation script" touches it only as the thing you trained on; the sentence shows no unclear wording, so use G2's scaffold |
| Neighbours, Not Numbers | Each branch matters to its own town | None of your sentences carries a story for it, so use G3's scaffold and its honest branch |
| Own the Fix | The person who finds the problem keeps it until it is solved | F3: "I handled the branch's formal complaints log" touches it but does not show a problem kept until solved, so use G4's scaffold |

## Reverse questions, Round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "Which escalations cause your supervisors the most trouble, and what would you want this role to change for them?" | Reciprocity: asks what you could do for their branches |
| R3.2 | "How would you want to hear about a complaint at your branch, when and from whom?" | Tests the seam in I1 from their side |
| R3.3 | "How are the hub plans being talked about in your branches, and where do you see complaints being affected?" | Shows value 3 in practice and asks for their view before offering yours |
| R3.4 | "Which of the four values do you see tested most in a normal week, and what does it look like when it's missed?" | Hands the panel their own scoring language |
| R3.5 | "What could a new person in this role do in the first month that would genuinely help your branches?" | Reciprocity question for a peer panel |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches" | A3, C3, D1, G4, H1 |
| "and the contact centre" | B1, D1, E3, H1 |
| "report monthly on complaint volumes and resolution times" | E1, E2, H1, H4 |
| "coach branch supervisors on escalations" | C1, H2, I1, I3 |
| "work with digital teams on self-service journeys" | D3, E1 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | A3 |
| "confident presenting to senior leaders" | B3, C2, D2 |
| "comfortable with Excel reporting" | E2 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: your material says one branch's log. D1's slot stays inside it |
| Coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope: "trained new tellers on our escalation script." The limit is the pack's observation: your material says new tellers. C1's slot stays inside it |
| Has contact-centre experience, or equivalent | Negative you stated, F4 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Presents to senior leaders, or is confident doing so | Negative you stated, F7 | The plain acknowledgment: "I haven't presented above regional level." No slot |

## Sources

Provided documents: the job description; the four published values, pasted and described as copied from ashgrovecu.org/about/values on 11 November 2026; the recruiter's email on the three rounds; your four-point summary of the 2026 strategy brief published July 2026; your background in your message. No dossier was present. No assessment was provided.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet: your pasted page already supplies all four values by name and definition |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email already fixes three rounds, who runs each, the 20-minute case and the panel's scoring against the four values |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO bank: your summary of the July 2026 brief supplies the priorities and the competitive frame |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer has been assigned, so there was no name to query; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names once assigned → an interviewer read per round, persona weights from their public footprint, and one reverse question tied to each person's own path
- Your own answers to the slots on F2, F3, F5, F6, F8 and F9 → those rows become quoted evidence, and the discovery rows can become story-mapped answers
- A redacted copy of the monthly complaints spreadsheet, with no member data → F5 and F6 can rise from medium to high confidence, and E2 can be tightened to what the sheet shows
- The strategy brief itself, not the four-point summary → a fuller grounding brief and sharper CO and CASE questions
- The recruiter's answer on what the 20-minute case is built around (one email) → H1 to H4 tuned to its actual shape
- Which rules Ashgrove's complaints are handled under → A3 and H1 sharpened on the regulatory side
- A CV or fuller work history → more rows can move from discovery to grounded
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → loop reports for similar roles and recent organisation context; offered once
- A `tuesday-dossier.md` from the job-underwriter → an evidence-derived ranking of objections and strategy constraints per weak area; the pack stands without one
