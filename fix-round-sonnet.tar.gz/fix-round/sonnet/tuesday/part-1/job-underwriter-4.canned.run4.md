Running the L1 research now: the employer, a salary and scope check for this role, and Odile Varga's public profile.
The careers page conflicts with your JD: it says Leeds, four days a week, and your posting says fully remote. I'm fetching that page to confirm.
**Short answer:** your background fits, but don't put effort into it until you've pinned down where the job is based. Your posting says fully remote, and Brindlemoor's own careers page says something different.

## Decision snapshot

**Yes, on substance: R2, R3, R4, R5 and R6, the must-haves, all read `direct`. Hold the application until the work pattern is settled (R1). Status: `hold_pending_answers`.** Never having done pet insurance is not a gap the posting asks about: the JD names only "insurance experience a plus" (R9 `direct`).

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: direct: R7a · unclear: R7b (Recommendations to product)
- `preferred`: direct: R9

R1: the posting and the careers page disagree on the work pattern; R6: how much of the test design was yours is yours to confirm; R7b: product-side recommendations aren't evidenced yet.

**Opportunity ledger.** Substantively sound and led by a pricing specialist (RR5), but the work pattern is contradicted between sources (RR1), pay is withheld (RR2), direct reports are unstated (RR3), and I found no independent footprint beyond the careers page (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** the awaited answer is which work pattern is true (RR1) and whether it works for you (G1). If it's fully remote, or Leeds four days works for you, this becomes `conditional_go` with RR2 and RR3 verified in the loop. If you need remote and it's Leeds, it becomes `no_go` on R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; the role is live on its own careers page, brindlemoor.co.uk/careers/senior-pricing-analyst. Stage, size and funding are not established | `[grounded]` JD and careers page fetched; the company-level search returned no results |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Work pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both quoted; which is current is unresolved |
| Reporting line | The Director of Pricing, Odile Varga | `[grounded]` JD and careers page |
| Line management | The JD lists no direct reports or management requirement | `[grounded]` JD silence |
| Scope read | "Own pricing analytics" for one product under one named director suggests a small pricing function, possibly a sole analytics owner | `[inferred]` from the JD's "own" wording and single-product scope |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. The posting withholds pay, so this is what to expect, never Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 pay survey (search snippet only); `[grounded]` JD, for the withheld pay |
| Unknowns | Pay; true work pattern; direct reports; company stage and size | — |
| Contradictions | JD against careers page on the work pattern | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You haven't stated a location or office-days constraint, so there is no claim to grade. Fit is unclear because the JD and the careers page give different terms | `[grounded]` JD and careers page; no candidate constraint given | G1; get the work pattern in writing |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in motor pricing analytics, self-reported, no inspectable artifact yet. A length-of-experience requirement is graded on fit, not treated as a gate | `[grounded]` your background as stated | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use, self-reported and specific; limited inspectable proof | `[grounded]` your background as stated | none |
| R4 | GLM experience, including building and monitoring rating models | must_have | direct | medium | none | You built and maintained the young-driver GLM, which covers building. What you monitored and how drift was caught is a probe topic. Odile Varga's published talk is on monitoring rating models, so `[inferred]` that it will come up | `[grounded]` your background as stated; `[inferred]` from her talk | Prepare a monitoring example |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting; confirmed and specific, no artifact | `[grounded]` your background as stated | none |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You "ran 14 price tests with the underwriting team". Running them could mean designing, reading, or both, so I take the lower reading until you say which parts were yours | `[grounded]` your background as stated | G2 |
| R7a | Recommendations to underwriting | important | direct | medium | none | Your test work with underwriting and the quarterly review both feed underwriting decisions | `[grounded]` your background as stated | none |
| R7b | Recommendations to product | important | unclear | low | discovery | Nothing you've said involves a product team; the quarterly review may touch it, unconfirmed | `[inferred]` from the pricing review, no product link stated | G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance is insurance; the JD does not ask for pet specifically | `[grounded]` JD and your background as stated | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Work pattern (R1, hard_gate) | hard_gate | The JD says fully remote; the careers page says Leeds four days a week; you've stated no location constraint | A gate the inputs don't settle; it decides between `no_go` and `conditional_go` | Not experience: your own position on a Leeds office four days a week | Written confirmation of the work pattern from the recruiter or Odile Varga | `[grounded]` the two quoted sources; `[inferred]` that the answer decides the status |
| G2 | Price-test ownership (R6, must_have) | discovery | 14 tests run with underwriting; the split between designing, reading and deciding isn't stated | Design is named in the JD, and an interviewer can probe it | Choosing the test and control split, setting sample size or duration, writing the read-out, recommending roll-out or rollback | A sanitized test read-out or a pricing review slide | `[grounded]` your "ran 14 price tests"; `[generic]` that pricing interviews probe ownership of the test design |
| G3 | Product recommendations (R7b, important) | discovery | Underwriting work is evidenced; product-side work isn't | An important responsibility with no evidence yet | A rate or cover-option change you took to a product owner; a proposition or competitor-pricing review | A short paper or deck for a product audience | `[grounded]` no product work stated; `[generic]` that pricing roles often serve product as well as underwriting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Work pattern contradicted | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The posting copy or the careers page may be stale, or the terms may have changed | `[grounded]` both quotes; `[inferred]` that one is outdated | Is this role fully remote, or office-based in Leeds four days a week, and which is current? | unresolved |
| RR2 | Pay withheld | unknown | — | JD gives no salary | The figure may sit anywhere in the survey band, or the company may not publish salaries | `[grounded]` JD silence; `[generic]` band from the pay survey snippet | What salary range is budgeted for this post? | unresolved |
| RR3 | Direct reports unstated | unknown | — | "Own pricing analytics"; the JD lists no reports | The role may be a sole contributor or may expect some people management | `[grounded]` JD silence; `[inferred]` from "own" | Does this role have direct reports now or planned? | unresolved |
| RR4 | No independent footprint found | unknown | — | "insurtech", pet-insurance product | The company may be new or small, or the search terms missed it | `[grounded]` company search returned nothing, careers page found; `[generic]` that small insurtechs often have thin footprints | Can you tell me the company's stage, size and funding? | unresolved |
| RR5 | Pricing specialist as manager | positive_signal | — | "reports to the Director of Pricing" | Your work would be read by someone who has built pricing analytics before: Odile Varga's profile gives six years as head of pricing analytics at Calloway Re and a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors" | `[grounded]` careers page and her profile (search snippet) | Which monitoring problems is the team working on right now? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Get the work pattern confirmed in writing before investing in the application | see R1, RR1 | `[grounded]` register | pending your approval |
| P1 | If you apply, lead with: built and maintained the GLM rating model for the young-driver book; ran 14 price tests last year with underwriting; present the quarterly pricing review to the head of underwriting. Say pet insurance is a new product for you, and don't claim "designed" tests until G2 is answered | see R4, R5, R6, R9 | `[grounded]` each clause traces to your own sentence | pending your approval |
| P2 | Prepare one monitoring example from the young-driver model for the conversation with Odile Varga | see R4 | `[grounded]` her talk topic; `[inferred]` that it will come up | pending your approval |
| Q1 | Ask the verification questions of RR1 to RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results, so company stage and size are not established) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved role reality's work pattern and contradictions rows, R1, RR1 and RR4 |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet only. Moved market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read as a snippet only. Moved RR5, P2 and R4's reasoning |

I can write this up as a `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**

- Your CV, or an inspectable pricing artifact (a model documentation pack, a sanitized test read-out, a quarterly review deck) → R4 and R6 can rise to `high`, and P1 can become real CV edits.
- Your answer on the work pattern → R1 and RR1 close and the status resolves.
- Your pay floor and any other non-negotiables → hard-gate rows for them get checked against the band and the posting.
- Recruiter or Odile Varga's answer on pay and reports → RR2 and RR3 close.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) → RR4 gets a real answer. Say the word and it runs.

**Questions**

G1: The posting says fully remote (UK), but the careers page says Leeds office four days a week. Does that work for you, or do you need it fully remote?

G2: Of the 14 price tests, which parts were personally yours: choosing the test and control design, sizing and duration, the read-out, or the roll-out decision?

G3: Have you taken a recommendation to a product team or owner, not just underwriting, such as a rate change that affected cover options? What was yours, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.