## Decision snapshot

**No, this posting isn't worth pursuing. R1 and R2, both hard gates, fail on your own constraints. Status: `no_go`.** Your fit on paper is real, and the gates are what stop it.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in Austin, 5 days a week), R2 (Base pay $70–85k)
- `must_have` — direct: R3a, R4, R5 · unclear: R3b (Years in leadership roles)
- `important` — unclear: R6 (SEO and content), R7 (Brand and PR), R8 (Partnerships), R9 (Sales ops), R10 (Running growth as a team of one)

R1, R2 — location and pay conflict with your stated terms; R3a, R4, R5 — the paid and lifecycle core matches your stated history; R3b, R6, R7, R8, R9, R10 — unresolved, and moot while the gates stand.

**Opportunity ledger.** The two gate conflicts are filed as RR1 and RR2. The posting's own shape adds RR3 (seven functions in one title, no bench), RR4 (always-on language), RR5 (metrics left undefined) and RR6 (employer unverified, because research was refused). RR7 runs the other way: the pay range is stated.

- **Hard gates:** failed: R1 (On-site in Austin, 5 days a week), R2 (Base pay $70–85k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the role would have to be remote from Portland and pay a base of at least $150k. Your two constraints are joined by "and", so both would have to change.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header; the funding and profitability claims are unverified (RR6) |
| Mandate | Own all revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, dotted line to the board | `[grounded]` posting |
| Team and resources | A team of one to start; no budget, tools or hiring plan stated | `[grounded]` posting for "team of one"; `[inferred]` that no budget or hiring plan exists, from the posting's silence |
| Success metrics | None stated; "will evolve as we learn" | `[grounded]` posting |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity figure, percentage or vesting terms | `[grounded]` posting |
| Scope read | Several full-time specializations bundled into one title with no support | `[inferred]` from the seven listed functions against "team of one" |
| Market calibration | Not established. The role-family sweep was refused, so no band is stated and none is borrowed from memory | `[grounded]` the refusal; see evidence status |
| Unknowns | Whether the employer exists as described; the equity terms; the budget; who the buyer is | `[grounded]` posting silence |
| Contradictions | "Report to the CEO with a dotted line to the board" and "players who don't need a bench" sit beside a title that implies a function lead | `[inferred]` from the posting's own language |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement of the limit (Portland, remote-only, not relocating), which is specific and your own. The fit fails because the posting rules out any remote work. | `[grounded]` JD quote and your stated constraint | Only the employer changing terms or you revising the constraint resolves it |
| R2 | Base pay $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k floor. The fit fails because the top of the posted range is $65k below the floor. Equity is unquantified, so it can't be counted against the gap. | `[grounded]` JD quote and your stated constraint | Only a changed salary or a revised floor resolves it |
| R3a | 8+ years in growth | must_have | direct | medium | none | You state 9 years in growth, a prose self-report with no inspectable artifact yet. | `[grounded]` your stated background | none |
| R3b | 8+ years of growth leadership specifically | must_have | unclear | low | discovery | You moved from growth lead to Head of Growth, but you haven't said how many of the 9 years were in lead or head roles. Resolving that downward, the leadership years are unestablished. | `[grounded]` your stated titles; years per title not given | One question, if you ever revisit the role: years in lead and head roles |
| R4 | Paid acquisition | must_have | direct | medium | none | You say you owned paid. The $8M to $40M ARR growth is company-level, so it isn't evidence about paid specifically. | `[grounded]` your stated background | A channel dashboard or budget summary would raise it to `high` |
| R5 | Lifecycle and CRM | must_have | direct | medium | none | You say you owned lifecycle and have deep Braze experience. | `[grounded]` your stated background | A sanitized lifecycle program summary would raise it to `high` |
| R6 | SEO and content | important | unclear | none | discovery | Nothing you've stated covers SEO or content. | `[grounded]` silence in your background | See G1 |
| R7 | Brand and PR | important | unclear | none | discovery | Nothing you've stated covers brand or PR. | `[grounded]` silence in your background | See G1 |
| R8 | Partnerships | important | unclear | none | discovery | Nothing you've stated covers partnerships. | `[grounded]` silence in your background | See G1 |
| R9 | Sales ops | important | unclear | none | discovery | Nothing you've stated covers sales ops. An e-commerce enablement company probably sells to merchants, which would make this a different motion from B2C subscription. | `[grounded]` silence in your background; `[inferred]` the buyer type from the company description | See G2 |
| R10 | Running growth as a team of one | important | unclear | low | discovery | You managed teams of 3–7, which says little about executing every function solo. | `[grounded]` your team sizes; `[inferred]` the difference from the posting's wording | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content, brand and PR, partnerships (R6, R7, R8; important) | discovery | Your background covers paid, lifecycle and experimentation, and is silent on these three | They are three of the seven functions you would own alone | Content or SEO programs you directed; press or launch work; affiliate or integration partners you signed | Traffic reports, a partner list, press coverage | `[grounded]` background silence |
| G2 | Sales ops and solo execution (R9, R10; important) | discovery | Nothing states a hands-on, single-person scope or a sales-pipeline motion | They define how different this role is from the ones you have held | Building a CRM pipeline or lead routing; stretches before your teams existed when you ran everything yourself | A pipeline report or tooling setup note | `[grounded]` background silence; `[inferred]` that they differ from your history |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site 5 days a week conflicts with your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The employer won't flex on location, as stated | `[grounded]` JD wording and your constraint | Is any remote or Portland-based arrangement possible for this role? | unresolved |
| RR2 | Pay conflicts with your floor, and may also sit low for the scope (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The base is $65k below your floor at its top. Equity is unquantified, so it can't close that gap. | `[grounded]` the figures; `[inferred]` the scope mismatch from 8+ years, all revenue functions and a CEO report, unconfirmed because the market sweep was refused | What is the equity grant, its percentage, strike and vesting, and is the base negotiable? | unresolved |
| RR3 | Bundled specializations with no bench | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one" | One person is expected to cover roles that usually need several, without resources stated | `[inferred]` from the list against the staffing line | What budget, tools and first hires are committed to this role? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine rather than exceptional | `[inferred]` from "just who we are" | In the last quarter, how many evenings and weekends did the team work? | unresolved |
| RR5 | Success undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be accountable for revenue with no agreed definition of success | `[inferred]` from the wording | What would success look like at 90 days and at 12 months, and who sets it? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The research that would have checked this was refused, so existence, stage and live posting are unverified | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I interview with? | unresolved |
| RR7 | Pay range is stated | positive_signal | — | "$70–85k base" | The employer is transparent about base pay | `[grounded]` JD | What is the range for the equity component? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Do not apply to this posting as written | See R1, R2 | `[grounded]` the failed gates | pending your approval |
| A2 | If you want to test the terms, ask the recruiter or CEO about both location and base before any application work. A change on one alone leaves a failed gate. | See R1, R2 | `[inferred]` from the posting's "no exceptions" and stated range that the likely answer is no | pending your approval |
| A3 | If you proceed anyway, ask RR3, RR4, RR5 and RR6's questions verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: R1 and R2, which are your own statements of your constraints, not claims about the role. The other rows rest on your self-reported background, which is a lead and not proof. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Novaline e-commerce enablement startup Austin Series A" was refused because search permission wasn't granted. It would have moved the organization row and RR6 (is Novaline real, and is the posting live). |
| 2. Role-family sweep | unavailable | The search "Head of Growth salary Series A startup 8+ years experience base compensation" was refused. It would have moved the market calibration row and RR2's seniority-pay comparison. |
| 3. Hiring manager's public footprint | n/a | No name was given, only "the CEO", so there is no query to form. |

I didn't retry the refused searches. Nothing here depends on them for the decision, since the two failed gates come from the posting's own text and your constraints.

I can save this as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Permission to search, or a link to the live posting and company page, would close RR6, and the sweep would put a band on RR2.
- The CEO's name would sharpen the scope read in role reality.
- The employer's equity terms would show whether RR2 could ever close.
- A channel dashboard or lifecycle summary would raise R4 and R5 to `high`, and examples for G1 and G2 would settle R6 through R10; both matter only if the gates change.

No questions this turn. R1 and R2 settle the decision, and no answer you could give would move it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.