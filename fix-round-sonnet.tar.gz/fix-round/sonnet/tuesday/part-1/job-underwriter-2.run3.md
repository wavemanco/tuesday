Web search was declined, so this runs on your resume and the JD alone.

## Decision snapshot

**No, you are not wasting your time. R3 and R4a are `direct`, and R1a and R2 are `adjacent`. R1b (titled PM years) is `absent`, so this is `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1a (3+ years PM work), R2 (Shipped API or platform products) · unclear: R4b (Sales and support launch coordination), R5 (Agile delivery) · absent: R1b (3+ years titled PM role)
- `important`: adjacent: R6 (Roadmap and partner discovery), R7 (Specs and squad delivery) · unclear: R8 (Adoption metrics)

R1b — the missing PM title; R2 — integrating an API is not shipping one; R4b, R5, R8 — the resume is silent.

**Opportunity ledger.** The mandate is clearly scoped (RR3). The employer is not yet verified (RR1). Pay, level and location are withheld (RR2), and authority over the roadmap is unstated (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting verifies as live on Quartzline's own careers page (RR1); (2) the hiring side confirms it will consider adjacent, non-titled experience for R1b; (3) R2, R5 and R8 are framed as adjacent unless your answers confirm more.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Existence not checked | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform, run partner discovery, write specs, drive two engineering squads, define and track adoption metrics, coordinate launches with sales and support | `[grounded]` JD |
| Scope read | A single-product PM post, bounded by two squads and a 3+ year bar | `[inferred]` from the squad count and the years requirement |
| Compensation | Not stated; the posting withholds it. Worth one question | `[grounded]` JD silent |
| Market calibration | Not established, because no role-family sweep ran | `[grounded]` research tier line below |
| Unknowns | Pay, level, location or remote, reporting line, whether adoption metrics already exist | `[grounded]` JD silent on each |
| Contradictions | None between the JD and your resume. JD against the careers page not checked | `[grounded]` the two documents |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience — the work itself | must_have | adjacent | medium | transferability | Your roadmap-input sessions, requirements documents and coordination with PMs are PM-adjacent work. Limit: the resume shows you feeding product, not owning prioritization | `[grounded]` resume | G1 |
| R1b | 3+ years PM experience — a PM role held | must_have | absent | none | discovery | No PM title in seven years; you said so. Nothing says whether you held PM decision rights without the title. A years requirement is a screening risk, not a gate | `[grounded]` your statement; `[generic]` that screens often apply titled-years bars literally | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the internal integration playbook. Limit: that is the consumer and implementer side, with no evidence of owning API design, versioning or release | `[grounded]` resume | G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture, stated with no inspectable artifact yet. Expect a probe | `[grounded]` resume | none |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs across 30+ integrations. Sales is not part of this row | `[grounded]` resume | none |
| R4b | Launch coordination with sales and support | must_have | unclear | low | discovery | The resume names neither sales nor support | `[grounded]` resume silence | ask if budget allows; otherwise carried as a minor risk |
| R5 | Agile delivery | must_have | unclear | low | discovery | The resume does not name sprint or backlog practice. Custom builds with engineers are indirect context | `[grounded]` resume silence | G3 |
| R6 | Roadmap ownership and partner discovery | important | adjacent | medium | transferability | You ran quarterly sessions collecting client feedback for product. Limit: input into someone else's roadmap, not ownership of it | `[grounded]` resume | G1 |
| R7 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated engineers on custom builds. Limit: client-project specs, not a product backlog owned over time | `[grounded]` resume | G1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | SQL and go-live and UAT work are indirect context; no metric is named | `[grounded]` resume silence | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM decision rights without the title (R1a, R1b, R6, R7; must_have) | discovery | Roadmap-input sessions and requirements documents, but nothing on who decided what reached product | R1b is the one `absent` must-have row, and this is the only thing that could move it | Choosing which client requests to escalate to product and defending that choice; a spec an engineering team built from; saying no to a custom build; running a client beta | A sanitized requirements doc, a roadmap-input summary, a release note you contributed to | `[grounded]` resume scope; `[generic]` that titled-years bars are the likeliest early cut |
| G2 | Shipping a product, not integrating one (R2; must_have) | transferability | Bridge: 30+ integrations give you the partner's view of an API. Limit: no evidence you owned API design, versioning or release | R2 is a must-have, and the bridge narrows the objection | An internal tool others adopted; the playbook as something the team depends on; owning a client-facing deliverable from spec to go-live. A prior conversation hinted at an internal request-triage tool that support agents adopted; that is unconfirmed | A tool README or demo, a usage count, the playbook's table of contents | `[grounded]` resume; unconfirmed memory lead, a prompt only |
| G3 | Agile delivery (R5; must_have) | discovery | The resume is silent on sprint or backlog practice | A must-have that is probably cheap to close | Sprint planning with a client's squad; backlog grooming on custom builds; standups during UAT | A Jira board screenshot, sprint notes | `[grounded]` resume silence |
| G4 | Adoption metrics (R8; important) | discovery | No metric is named | JD asks you to define and track adoption metrics | Time to first successful call, integrations live, UAT pass rate, go-live duration across the 30+ integrations | A SQL query or a tracking sheet | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay, level and location not stated | unknown | — | "Product Manager, Platform APIs" (no figure or location given) | The posting may withhold terms the candidate cares about | `[inferred]` from the JD's silence on each term | What is the budgeted salary and level, and where is the team based? | unresolved |
| RR3 | Mandate and team clearly stated | positive_signal | — | "two engineering squads" | The scope appears defined, not vague | `[grounded]` JD | Who owns the adoption metrics today? | noted |
| RR4 | Roadmap authority against sales and partner commitments unstated | unknown | — | "Own the roadmap" | The role may own the roadmap in name while sales commitments set it | `[inferred]` from "own the roadmap" beside "coordinate launches with sales" | Which roadmap decisions does this role make alone, and which need sign-off from sales or leadership? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Quartzline's own careers page before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Apply openly as an adjacent-experience candidate: say plainly you have no PM title, and lead with the 30+ integrations, the playbook and the roadmap-input sessions in your own wording | see R1a, R1b, R2, R6 | `[grounded]` resume | pending your approval |
| A3 | Look for a referral or a direct note to the hiring side, because a titled-years bar is often applied before a person reads the file | see R1b | `[generic]` role-family pattern | pending your approval |
| A4 | Ask RR2 and RR4 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Offer a one-page adoption-metrics outline built from your integration data, if G4 confirms the data exists | see R8 | `[inferred]` from G4 | pending your approval |

Every row above, and the positioning advice in it, is proposed and pending your approval. Nothing is final until you confirm.

## Evidence status

Verified: none yet. Unverified leads: a prior-conversation mention of an internal request-triage tool that support agents adopted. It is unconfirmed and prompts a question only. Rejected inferences: none. Stage assumed: evaluating.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Quartzline logistics technology company careers Product Manager Platform APIs" was refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | The search "Product Manager API platform B2B SaaS Series B salary requirements years experience solutions engineer to product manager" was refused. It would have moved market calibration and the pay checks in RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can offer a dossier file (`tuesday-dossier.md`) of this assessment whenever you want it.

**Upgrade menu**

- Search access → targets 1 and 2 run, which could clear RR1 and add a pay band.
- Your non-negotiables (location, pay floor, remote or office) → hard-gate rows replace the "constraints not given" flag.
- The hiring manager's name → role reality's scope read and which story to lead with.
- A sanitized requirements doc or a roadmap-input summary → R1a, R6 and R7 can rise toward `high`.
- A tool README or usage count → R2's bridge narrows.

**Questions**

G1 — Was there a case where you personally decided which client request went to product, or shaped what engineering built? What did you own, who was involved, and what happened?

G2 — Did you build an internal request-triage tool that support agents used? If so, what did you own, how many people used it, and is there a README or demo?

G3 — Have you worked in sprints or a backlog with a client's or your own engineers, and in what role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.