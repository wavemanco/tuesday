Checking the careers page now. It says the role is in a Leeds office four days a week, but your JD says fully remote. I'm fetching the page to confirm.
**Probably yes on fit, but not yet.** R1, a hard gate on where you would work, is unresolved because the posting and the employer's own careers page disagree. Status: `hold_pending_answers`.

The careers page I fetched says the role is "Leeds office four days a week". Your JD says "Fully remote (UK)". You haven't told me your location constraints, so I can't say whether that is a dealbreaker for you.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6a, R7a, R8 · adjacent: R6b (monitor rating models) · unclear: R7b (design price tests)
- `preferred` — direct: R9

R1 — location terms conflict between the posting and the employer's page; R6b — monitoring is nearer to your "maintained" than to anything you stated; R7b — design of the tests is not stated alongside running them.

**Opportunity ledger.** The scope and reporting line are clear (RR4), but location conflicts (RR1), the salary is withheld (RR2), the pet-insurance domain is new to you (RR3), the employer has little public footprint beyond the careers page (RR5), and the JD is silent on direct reports (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the hold waits on R1. If the role is confirmed remote, I'd expect `conditional_go`, with R6b and R7b as the open points. If it is Leeds four days and that doesn't work for you, it becomes `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; `[grounded]` the careers page confirms the role is live. A search for the company's pet product returned nothing (RR5) |
| Mandate | Own pricing analytics for the pet product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD and careers page |
| Reports to | Director of Pricing, Odile Varga | `[grounded]` JD and careers page |
| Working pattern | Conflict: the JD says fully remote (UK); the careers page says Leeds office four days a week | `[grounded]` both texts. Which one is current is not established (RR1) |
| People management | Not required in the JD. Direct reports are not mentioned either way | `[grounded]` JD silence (RR6) |
| Hiring manager | Director of Pricing; spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books; previously head of pricing analytics at Calloway Re for six years | `[grounded]` public profile, search result text only |
| Scope read | The JD pairs "build and monitor rating models" with a hiring manager who has spoken publicly on monitoring in small books, so monitoring is likely a live concern for this hire | `[inferred]` from the JD's wording against the profile |
| Market calibration | UK senior pricing analysts at insurers and insurtechs have a median base of £58,400 and an interquartile range of £52,100 to £64,900. The posting states no salary, so this is the band to expect, never Brindlemoor's offer | `[generic]` Pricewell 2026 pay survey (n=612), from one search result; page not fetched |
| Unknowns | Salary; working pattern; direct reports; how large the pet book is | — |
| Contradictions | JD "fully remote" against careers page "Leeds office four days a week" | `[grounded]` fetched page |

## Evidence map

Your background is typed prose, so it counts as self-report. `medium` is the ceiling until something inspectable is shown.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD and the employer's page conflict, and you have not stated a location constraint, so there is no statement of yours to grade | `[grounded]` JD and fetched careers page | Ask the employer which is current (RR1); I need your constraint (question closing) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Self-reported, no artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You state daily use. Self-reported; expect a technical probe | `[grounded]` your background | A sanitized query or notebook would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, but no model documentation inspected | `[grounded]` your background | A sanitized model documentation pack would raise to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Underwriting side confirmed; actuarial audience not stated | `[grounded]` your background | A sanitized review deck would raise to high |
| R6a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM | `[grounded]` your background | see R4 |
| R6b | Monitor rating models | must_have | adjacent | low | discovery | "Maintained" is near monitoring but does not say it. The lower band is taken because monitoring is not stated | `[grounded]` your wording; `[inferred]` that maintenance usually includes some monitoring | Ask G2 |
| R7a | Run and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team | `[grounded]` your background | A sanitized test readout would raise to high |
| R7b | Design price tests | must_have | unclear | low | discovery | "Ran" does not say whether you chose the design, sizing or success measure; it resolves downward until you say | `[grounded]` your wording | Ask G1 |
| R8 | Turn results into recommendations for underwriting and product | must_have | direct | medium | none | The underwriting side is confirmed by the quarterly review. A product-side audience is not stated | `[grounded]` your background | Mention any product-team audience if it exists |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Designing price tests (R7b, must_have) | discovery | You ran 14 tests with underwriting; the design role is not stated | "Design and read price tests" is named in the JD, so which half is yours changes how you present R7a | Choosing control and test groups; sizing a test or setting how long it runs; agreeing the success measure and guardrails with underwriting; deciding what not to test | A test plan or sanitized readout | `[grounded]` your wording; `[generic]` that roles like this tend to probe test design |
| G2 | Monitoring rating models (R6b, must_have) | discovery | You maintained the young-driver GLM; monitoring is not stated | The JD pairs building with monitoring, and the hiring manager has spoken on it publicly | Tracking actual-versus-expected on the model; setting drift or retrain triggers; a periodic model-performance pack for underwriting | A sanitized monitoring report or dashboard screenshot | `[grounded]` your wording and the profile text; `[inferred]` that monitoring will be probed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern conflict (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One copy may be stale, the JD may have come via a recruiter or aggregator, or terms may have changed | `[grounded]` the two texts conflict; `[inferred]` the causes | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | JD gives no figure | The offer may sit anywhere in the role-family band, or the firm may not publish ranges | `[generic]` band; `[grounded]` JD silence | What salary range is budgeted for this role? | unresolved |
| RR3 | New product domain | risk_signal | low | "Own pricing analytics for our pet-insurance product" | Pet pricing uses different rating factors from motor (such as breed, age and pre-existing conditions), so expect a ramp-up. The JD does not require pet experience | `[generic]` pattern, not a claim about Brindlemoor | How do you expect an analyst from another line to ramp up on pet, and what support exists? | unresolved |
| RR4 | Clear ownership and reporting line | positive_signal | — | "Own pricing analytics… reports to the Director of Pricing" | The scope and reporting line are defined | `[grounded]` careers page | What does success look like in the first year? | noted |
| RR5 | Thin employer footprint | risk_signal | low | A search for "Brindlemoor pet insurance" returned no results; the careers page exists | The company may be small or new, which is common for insurtechs | `[generic]` pattern for companies of this size, not a claim about this one | How long have you written pet policies, and how large is the book? | unresolved |
| RR6 | Direct reports not mentioned | unknown | — | JD is silent | The role may be an individual contributor or may grow a team | `[grounded]` JD silence | Does this role have, or expect to have, direct reports? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before spending effort, ask the recruiter or Odile whether the role is remote or Leeds four days | see R1, RR1 | `[grounded]` register | pending your approval |
| E1 | Order the CV so the first lines are your own sentences: "built and maintained the GLM rating model for the young-driver book", "ran 14 price tests last year with the underwriting team", "present the quarterly pricing review to the head of underwriting". Keep "ran", "maintained" and "present". Don't write "designed" or "monitored" until G1 and G2 are answered | see R4, R7a, R5, R6b, R7b | `[grounded]` your sentences | `resume_edits_pending_approval` |
| P1 | On pet insurance, say your GLM and test work carry over and that you haven't rated pet before. The limit is that you haven't worked with pet-specific factors. A short note on how you'd approach that rating would narrow the limit | see RR3 | `[inferred]` bridge from your motor work; `[generic]` that pet rating factors differ | pending your approval |
| Q1 | Ask the register questions, RR1 to RR6, in the loop, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance" (no results) and "Brindlemoor Senior Pricing Analyst careers"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved role reality's working-pattern and contradictions rows, R1 and RR1. The pet-insurance query establishing nothing moved RR5 |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as search-result text only. Moved the market calibration and RR2. No search was sent for scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read as search-result text only. Moved the hiring-manager and scope-read rows in role reality |

I can save this as a `tuesday-dossier.md` for you to reuse if you'd like.

## Upgrade menu

- Brindlemoor's answer on working pattern → R1 and RR1 close, and the decision resolves to `conditional_go` or `no_go`.
- Your own location and pay constraints (days in an office, a pay floor) → R1 and the salary check run against your terms rather than staying unknown.
- A sanitized test plan or readout → R7a to `high`, and R7b is answered.
- A sanitized model documentation pack or monitoring report → R4, R6a and R6b rise.
- A sanitized quarterly review deck → R5 and R8 rise.
- The salary range → RR2 closes against the band.
- A deeper research pass on Brindlemoor (funding, leadership changes, news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

R1 — Can you do the role if it's Leeds office four days a week, or do you need it fully remote? Do you have a pay floor?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G1 — On the 14 price tests, which parts did you personally own: who chose the test and control groups, how long a test ran, and what counted as success?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — After the young-driver GLM went live, how did you track whether it was still performing, and what triggered a refit?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.