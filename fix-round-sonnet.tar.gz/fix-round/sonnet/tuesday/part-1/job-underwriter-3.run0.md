Search permission was declined, so I'm running this from your posting and your message only. Here's the assessment.

## Decision snapshot

**No, this isn't worth pursuing. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R3 (Evenings and weekends); hard_gate_fail: R1 (On-site Austin, 5 days), R2 (Base $70–85k)
- `must_have` — direct: R4, R6 · adjacent: R5 (End-to-end revenue ownership)
- `important` — direct: R7 · unclear: R8 (SEO and content), R9 (Brand and PR), R10 (Partnerships and sales ops)

R1 — on-site Austin rules out your remote-only constraint; R2 — the stated base sits below your floor; R4, R6, R7 — your paid and lifecycle record meets these; R5, R8, R9, R10 — scope breadth beyond what you've shown.

**Opportunity ledger.** The role is weak on its own terms before your constraints are counted. The scope is bundled with no committed budget (RR3), there's an always-on expectation (RR4), success metrics are undefined (RR5), and I couldn't verify the employer (RR6). The profitability and reporting-line claims come from the posting alone (RR7). Your two constraints are the red flags for you (RR1, RR2).

- **Hard gates:** failed: R1 (On-site Austin, 5 days a week, no exceptions), R2 (Base $70–85k against your $150k floor); unconfirmed: R3 (Evenings and weekends when it matters).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** Novaline would have to accept a remote hire in Portland (R1) and put base at or above $150k (R2). Neither is something wording or fit elsewhere can fix.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting; not independently verified |
| Mandate | All revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and reporting | Team of one to start; reports to the CEO, dotted line to the board | `[grounded]` posting |
| Location and schedule | Austin on-site 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside"; equity terms unstated | `[grounded]` posting |
| Success metrics | "Will evolve as we learn"; no first-90-day or first-year outcomes stated | `[grounded]` posting |
| Scope read | Seven functions folded into one title and one person | `[inferred]` from the responsibility list against "team of one" |
| Market calibration | Not established. The role-family search was refused, so no market band is given | — |
| Unknowns | Equity terms; marketing budget; headcount plans; who Novaline sells to | — |
| Contradictions | A "Head of" title with 8+ years of leadership required, against a team of one and a $70–85k base | `[inferred]` from the posting's own terms set against each other |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, no exceptions (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint. The fit fails because the posting rules out exceptions | `[grounded]` posting quote and your stated constraint | Surface only; only Novaline changing terms, or you changing your constraint, resolves it |
| R2 | Base $70–85k (your constraint: at least $150k) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The top of the range is $65k below it | `[grounded]` posting figure and your stated floor | Surface only; same as R1 |
| R3 | Evenings and weekends "when it matters" | hard_gate | unclear | none | hard_gate | You stated no schedule limit and the posting's wording is soft, so it's unsettled. It's moot while R1 and R2 stand | `[grounded]` posting wording; no stated constraint from you | If R1 and R2 ever move, state your limit then |
| R4 | 8+ years growth leadership | must_have | direct | medium | none | 9 years, growth lead then Head of Growth at two B2C subscription companies, with teams of 3–7. This is self-report with no artifact inspected | `[grounded]` your message | none |
| R5 | Own all revenue growth end to end | must_have | adjacent | medium | transferability | You took one company from $8M to $40M ARR over three years with a budget you controlled, owning paid, lifecycle and experimentation. Limit: the posting adds functions you haven't stated, and it doesn't say whether Novaline sells to consumers or merchants | `[grounded]` your message; `[grounded]` posting silent on the customer | A dashboard or board-deck excerpt would raise it |
| R6 | Paid acquisition | must_have | direct | medium | none | Owned paid at both companies by your account; no artifact inspected | `[grounded]` your message | none |
| R7 | Lifecycle/CRM | important | direct | medium | none | Owned lifecycle and works deeply in Braze, by your account | `[grounded]` your message | none |
| R8 | SEO/content | important | unclear | none | discovery | You didn't mention it, so the evidence is inconclusive | `[grounded]` your message silent | See G1 |
| R9 | Brand and PR | important | unclear | none | discovery | Same | `[grounded]` your message silent | See G1 |
| R10 | Partnerships and sales ops | important | unclear | none | discovery | Same | `[grounded]` your message silent | See G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand, PR, partnerships, sales ops (R8, R9, R10, important) | discovery | Your message covers paid, lifecycle and experimentation, and is silent on these five | They'd only matter if the hard gates ever moved | Owning an organic or content program; running a launch with press or a partner; co-marketing or reseller deals; building sales-handoff reporting | A channel report, content calendar, press-coverage list, partner agreement | `[grounded]` your message silent; `[inferred]` that the gaps are moot while R1 and R2 stand |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site 5 days vs remote-only (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The term is stated as inflexible, so a remote arrangement is unlikely | `[grounded]` the posting's own wording | Is the on-site requirement open to a remote hire based in Portland, or is it fixed? | unresolved |
| RR2 | Base far below your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The range may be fixed. Equity is the only stated offset and its terms are unstated | `[grounded]` posting figure against your stated floor | Is there budget above $85k base, and what are the equity terms? | unresolved |
| RR3 | Responsibility without resources, bundled specializations | risk_signal | medium | "team of one to start — we believe in players who don't need a bench" | Seven functions with no stated budget or headcount may be several roles priced as one | `[inferred]` from the responsibility list against the silence on resources | What marketing budget and headcount are committed this year? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be the norm, not the exception | `[generic]` pattern for postings with this phrasing, not a claim about Novaline | How many evenings or weekends did the team work last quarter? | unresolved |
| RR5 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may be undefined while the scope is total | `[inferred]` from the mandate against the absent metrics | What revenue outcome is expected in the first 12 months, and who decides? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be new, small or unlisted, or the posting may not reflect a live role | `[generic]` pattern for companies of this size, not a claim about this one | Can you share the role as listed on your own careers page, and who I'd interview with? | unresolved |
| RR7 | Profitable since day one; reports to the CEO with a board line | positive_signal | — | "profitable since day one"; "Report to the CEO with a dotted line to the board" | If true, the company is stable and the role has senior access | `[grounded]` posting states both; neither is verified | What is the current revenue and runway? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pass on this posting as written | See R1, R2 | `[grounded]` R1 and R2 rows | pending your approval |
| A2 | Only if you want to test whether the terms are real: one short note asking whether the role could be remote from Portland and whether base goes above $85k. No draft until you say so | See RR1, RR2 | `[grounded]` register | pending your approval |

## Evidence status

Verified: R1 and R2 claims (your stated constraints; verified is about the claim, and both rows' fit is `hard_gate_fail`). Your experience claims (R4–R7) are unverified self-report.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Head of Growth"; the call was refused and returned nothing. It would have moved whether Novaline exists as described (RR6) |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary startup Series A base salary range 2026"; the call was refused and returned nothing. It would have moved the market-calibration row and the severity read on RR2 and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given |

No questions this turn: no answer could change the status.

If you'd like a record of this, I can write it up as `tuesday-dossier.md`; no pressure.

**Upgrade menu**
- Search permission would let the employer check and the market-band comparison run (RR6, role reality). A deeper pass after that is available once on request, up to 5 more searches and 2 more fetches.
- A link to the role on Novaline's own careers page, or the recruiter's email domain, would close RR6.
- The marketing budget, headcount plans and equity terms would settle RR2, RR3 and the scope read.
- A channel report, content calendar, press-coverage list or partner agreement would move R8, R9 and R10 from `none`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.