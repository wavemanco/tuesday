I'm assembling the assessment now. Web access was refused in this session, so the checks on the company and posting couldn't run and everything below rests on what you pasted.

## Decision snapshot

**Yes, this is worth applying to, on conditions. Status: `conditional_go`.** The must-have tier (R3, R4, R5, R6, R7) is `direct`. What stays open is your own location and pay floor (R1, R2) and the employer check that couldn't run here (RR1).

**Fit ledger.**

- `hard_gate`: unclear: R1 (Location: remote US or Denver), R2 (Pay $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R8: a credible bridge with its limit named; R9, R10: named responsibilities your background doesn't yet speak to.

**Opportunity ledger.** The posting states its pay, and the figure sits in the market band (RR2). The open items are the unverified employer (RR1), the unquantified equity (RR3), and the unstated team and reporting line (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Location: remote US or Denver), R2 (Pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and pay floor clear R1 and R2; (2) the posting is confirmed live and the company confirmed as described (RR1); (3) the Snowflake-to-BigQuery bridge is framed as adjacent, never as BigQuery experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; Denver; founded 2016; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not independently checked (RR1) |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Location | Remote (US) or the Denver office | `[grounded]` JD |
| Pay | $148,000–$166,000 plus equity | `[grounded]` JD |
| Scope read | Three layers (ingestion, modelling, contracts) for one platform's reporting. Whether that is one domain's pipelines or a wider mandate depends on team size, which the posting does not state | `[inferred]` from the JD's three named layers and its silence on team |
| Market calibration | Datawright 2026 (n=2,310), Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500; "Senior" typically 5–8 years; typical scope is one domain's pipelines, no direct reports. The posting's range runs from $3,000 under that median to $2,500 above the IQR's upper edge. Your 6 years sits inside the 5–8 range, and a Series C company sits inside the B–D cohort. The band is the market's, never this employer's offer | `[generic]` the recruiter-supplied report as pasted, not independently fetched; `[grounded]` JD figures and company stage |
| Unknowns | Hiring manager; team size; on-call; equity terms | `[grounded]` the posting names none of these |
| Contradictions | None found between the JD and the about text you pasted; the live careers page was not read | `[grounded]` pasted text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: "Remote (US) or our Denver office" | hard_gate | unclear | none | hard_gate | You haven't said where you are based or whether either option works, so there is no statement of a constraint to grade | `[grounded]` JD; intake silent | Q1 |
| R2 | Pay: "$148,000–$166,000 plus equity" | hard_gate | unclear | none | hard_gate | Pay is a term; your floor wasn't given, so the check against it is unknown | `[grounded]` JD; intake silent | Q2 |
| R3 | "5+ years data engineering" | must_have | direct | medium | none | 6 years stated at a B2B payroll company; prose self-report, so `medium`, nothing inspected | `[grounded]` intake message | CV with dates would firm it |
| R4 | "Strong SQL and Python" | must_have | direct | medium | none | Daily use is stated. "Strong" is the JD's word and depth isn't shown | `[grounded]` intake message | A sanitized SQL or Python sample would raise to `high` |
| R5 | "dbt and a cloud warehouse" | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake | `[grounded]` intake message | A dbt docs lineage screenshot or model excerpt would raise to `high` |
| R6 | "Orchestration with Airflow or similar" | must_have | direct | medium | none | "Airflow for orchestration" is stated. Your part in writing DAGs isn't, so no ownership beyond use is claimed | `[grounded]` intake message | Say your part when answering Q3 |
| R7 | "Experience with data quality testing" | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` intake message | The suite config would raise to `high` |
| R8 | BigQuery warehouse (from "a dbt-modelled warehouse in BigQuery") | important | adjacent | medium | transferability | The dbt and warehouse practice carries over. Limit: you've never used BigQuery. BigQuery has its own partitioning, clustering and scan-based cost mechanics you haven't exercised | `[grounded]` intake message; `[generic]` BigQuery mechanics | See G5; work sample W1 |
| R9 | "Ingestion from our app and CRM" | important | unclear | low | discovery | Nothing says what sources you ingested. A payroll platform's pipelines imply some ingestion, but that is a derivation | `[inferred]` from the payroll context | Q3 |
| R10 | "Data contracts our analysts depend on" | important | unclear | low | discovery | The Great Expectations suite is adjacent context, but nothing says you agreed schemas or SLAs with analysts | `[inferred]` from the GE suite | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location (R1, hard_gate) | hard_gate | The posting offers remote (US) or Denver; your location is not given | A gate that stays unknown keeps the status at `conditional_go` | n/a | n/a | `[grounded]` intake silence |
| G2 | Pay floor (R2, hard_gate) | hard_gate | The range is stated; your floor is not | Same as G1 | n/a | n/a | `[grounded]` intake silence |
| G3 | Ingestion from app and CRM (R9, important) | discovery | Background names no source systems | The first responsibility the JD lists | Pulling from a payroll or HR system's API; product event streams; a CRM sync into the warehouse via a tool or custom Python; change capture from an application database | A sanitized DAG, an architecture diagram, or an ingestion runbook | `[grounded]` CV-equivalent silence; `[generic]` that ingestion sits first in this role family |
| G4 | Data contracts (R10, important) | discovery | A test suite exists; no analyst-facing agreement is stated | A named deliverable in the JD | Agreed schemas or freshness SLAs with analysts; enforced dbt model contracts; a change or deprecation process for shared tables | A contract doc, a dbt `contract` config, or an SLA page | `[grounded]` background silence; `[generic]` that contracts are verified by examples like these |
| G5 | BigQuery (R8, important) | transferability | Snowflake plus dbt at 180-model scale | The stack difference most likely to be probed | The bridge: warehouse modelling and dbt practice. The limit: no BigQuery mechanics used. The strengthener: a small dbt-on-BigQuery project you build yourself | The project repo | `[inferred]` bridge from the intake; `[generic]` probe likelihood |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The text is the company's own claim; liveness of the posting and the funding were not independently confirmed in this run | `[generic]` pattern for any unverified employer, not a claim about this one | Is this role currently open, and where is it listed on your careers site? | unresolved |
| RR2 | Stated pay sits in the market band | positive_signal | — | "$148,000–$166,000 plus equity" | No pay-versus-seniority mismatch is visible against the pasted report | `[grounded]` JD figures against the pasted report; `[generic]` the band | Where in the range would an offer land for 6 years' experience? | noted |
| RR3 | Equity unquantified | unknown | — | "plus equity" | Size, vesting and valuation basis are unstated | `[grounded]` JD silence | What is the equity grant for this level, and what is the vesting schedule? | unresolved |
| RR4 | Team, reporting line and on-call unstated | unknown | — | "Build and run the pipelines" | "Build and run" could mean a sole owner or a slice of a team; the posting doesn't say | `[inferred]` from the JD's silence against the report's typical one-domain scope | Who would I report to, how many data engineers and analysts are on the team, and who is on call for pipeline failures? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live and who the contact is, via the recruiter or the careers page | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Positioning to lead with: "Six years of data engineering at a B2B payroll company; built the dbt project, about 180 models, on Snowflake; set up the Great Expectations test suite; Airflow for orchestration; Python and SQL daily." Then say plainly that BigQuery is new to you | see R3, R5, R6, R7, R8 | `[grounded]` your own sentences | pending your approval |
| W1 | Build a small dbt project on BigQuery with tests; it is a sample, never production experience | see R8, G5 | `[generic]` BigQuery offers a no-cost sandbox tier | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR4 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning Denver online tutoring K-12 Series C" and tried to fetch pellucidlearning.com/careers/senior-data-engineer; both were refused, so nothing was read. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | skipped | The pasted Datawright report already fixes the market calibration line and the RR2 comparison |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

## Dossier offer

If you want, I can save this as a `tuesday-dossier.md` so the work carries forward.

## Upgrade menu

- Your location and pay floor → R1 and R2 close; the status can move to `go`, or to `no_go` if a gate fails.
- Web access allowed, or a link to the live posting and the careers page → RR1 resolves and the cap on the decision lifts.
- A dbt docs lineage screenshot, a Great Expectations suite config, or a sanitized DAG → R5, R7, R6 can rise to `high`.
- An answer to Q3 → R9 and R10 move off `unclear`.
- Your resume → bullet-level edit proposals in this plan.
- The recruiter's answers on team, on-call and equity → RR3 and RR4 close.
- A hiring manager's name → role reality's scope read.
- A deeper pass on Pellucid Learning (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs, once search is permitted.

## Questions

G1 — Where are you based, and would you take this remote (US) or in the Denver office?

G2 — What base salary would you need for this role to be worth taking?

G3, G4 — Think of one pipeline you owned from source system to analyst-facing table. Which sources fed it, and did you agree schemas or freshness SLAs with the analysts who used it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.