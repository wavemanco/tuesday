Search access was denied, so I ran this on your message alone, with no employer research.

## Decision snapshot

**Yes, apply. Your core requirements line up directly (R2, R3, R4, R5, R6a, R7), and the open items are checkable. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (Monitor rating models)
- `important` — direct: R8a · adjacent: R9 (Own pricing analytics for the product) · unclear: R8b (Recommendations for product)
- `preferred` — direct: R10 · adjacent: R11 (Pet insurance)

R6b — monitoring is not yet evidenced; R8b — the product audience is not yet evidenced; R9 — one book's ownership set against the whole product; R11 — a motor-to-pet bridge with its limit named.

**Opportunity ledger.** The role is concrete as written but unverified. The employer is not established because no research ran (RR1), and pay and team shape are unstated (RR2, RR3). First-year outcomes are also unstated (RR4). One entry runs the other way: the requirements and the hiring manager's title are specific (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the posting verify as real and live (RR1); (2) your UK location and remote fit are confirmed (R1); (3) the salary clears your floor (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; the product is pet insurance | `[grounded]` JD header; existence not verified |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Hiring manager is Odile Varga, Director of Pricing | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| People management | The JD lists no line-management or direct-report requirement | `[grounded]` JD silent |
| Scope read | One product's pricing analytics, end to end, as the title "Senior" and the verb "Own" suggest | `[inferred]` from the JD's responsibility list |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Compensation | Not stated in what you pasted; no market band offered, since none was researched | `[grounded]` JD silent |
| Unknowns | Team size and who else prices; decision rights; pay; tooling; whether anyone reports in | — |
| Contradictions | None between the JD and your background; JD against the employer's own careers page was not checked | `[grounded]` the two texts compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | low | hard_gate | No location or right-to-work statement from you; a UK motor insurer is indirect context only. Confidence grades your side of the constraint | `[inferred]` from "UK motor insurer" in your background | Question R1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer; self-reported, not yet inspected. A length-of-experience requirement, not a gate | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is your claim. "Strong" is the JD's level, and no artifact has been inspected | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book" is specific. It is limited to one book, and an expert reader may probe the model design | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Underwriting is named in the JD; actuarial is not evidenced and is not needed | `[grounded]` your background | none |
| R6a | Build rating models | must_have | direct | medium | none | Same GLM claim as R4, read for "build" | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained", which is adjacent to monitoring; what was tracked after launch, how often, and who acted is not stated. Taking the lower reading | `[grounded]` your wording; `[generic]` that rating-model ownership routinely includes monitoring | Question G1 |
| R7 | Design and read price tests | must_have | direct | medium | discovery | You "ran 14 price tests last year with the underwriting team". Whether you designed them and read the results is not stated | `[grounded]` your background | Confirm which parts you owned, when preparing interview stories |
| R8a | Recommendations for underwriting | important | direct | medium | none | The tests and the quarterly review were both with underwriting | `[grounded]` your background | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing in your background touches a product audience | `[grounded]` background silent | Question G2 |
| R9 | Own pricing analytics for the product | important | adjacent | low | discovery | Ownership of one book's model sits next to owning a whole product's pricing analytics. Breadth is the limit | `[inferred]` from the JD's verb "Own" against your single-book scope | Later question on end-to-end cycle ownership |
| R10 | Insurance experience | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R11 | Pet-insurance familiarity (the product domain; the JD asks only for insurance experience) | preferred | adjacent | low | transferability | Motor pricing carries over in method; no pet product exposure. Pet rating likely uses different factors | `[inferred]` from the product named in the JD; `[generic]` on how pet rating differs | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R6b, must_have) | discovery | You built and maintained the model; post-launch tracking, cadence and actions are unstated | A must-have that could move from unclear to direct | Tracking actual against expected claims by segment; stability checks on rating factors; a refit prompted by what monitoring showed | A redacted monitoring pack, a refit note, or a model-governance summary | `[grounded]` background silent; `[generic]` that monitoring is the usual second half of model ownership |
| G2 | Product-side recommendations (R8b, important) | discovery | Recommendations are evidenced for underwriting only | The JD names product as a second audience | A test result that changed a product feature or a rating-factor decision made outside underwriting; a pricing paper for a commercial or product lead | A sanitized readout or a pricing paper | `[grounded]` background silent |
| G3 | Pet-insurance bridge (R11, preferred) | transferability | Adjacent: a GLM rating model, price tests and a pricing review, all in motor. Limit: no exposure to a pet product's rating factors or claims patterns | The posting asks for insurance experience, not pet specifically, so this is a framing and credibility point | Strengthener: a short outline, labelled as hypothetical, of how you would structure a pet rating model | A one-page outline | `[grounded]` the JD's wording; `[generic]` that pet rating differs from motor |
| G4 | Whole-product ownership (R9, important) | discovery | One book's model against a whole product's analytics | "Own" is the JD's headline verb | Setting priorities across rating, tests and reporting, not only running them | A scope description of your own role | `[inferred]` from "Own" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small for a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | No figure in the pasted JD | The posting may omit pay, or the pasted text may have dropped it | `[grounded]` JD silent | What salary range is budgeted for this role? | unresolved |
| RR3 | Team and decision rights unstated | unknown | — | "Own pricing analytics" | The role may be the only analyst, or it may sit inside a team | `[inferred]` from the JD's silence on team and authority | Who else works on pricing, and which pricing decisions does this role make rather than recommend? | unresolved |
| RR4 | First-year outcomes unstated | unknown | — | "turn the results into recommendations" | Success may be defined only at interview | `[inferred]` from the JD listing duties and no outcomes | What would a successful first year look like? | unresolved |
| RR5 | Requirements and manager named specifically | positive_signal | — | "GLM experience; experience presenting to underwriting or actuarial leads"; "Odile Varga, Director of Pricing" | Scope and audience are genuinely defined | `[grounded]` JD | Who owns the pricing roadmap today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the role on Brindlemoor's own careers page, and the recruiter's email domain, before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | CV summary leads with three of your own claims: the GLM rating model for the young-driver book, the 14 price tests last year with underwriting, and the quarterly pricing review presented to the head of underwriting. Every clause traces to your sentences; no new facts. `resume_edits_pending_approval` | R4, R6a, R7, R5 | `[grounded]` your background | pending your approval |
| P1 | Frame pet insurance as adjacent, with its limit stated: your method carries over and you have not priced a pet product. A one-page hypothetical outline of a pet rating model could back it, labelled as an outline and never as experience | R11, G3 | `[grounded]` R11 row | pending your approval |
| M1 | If asked about management, say you have not line-managed anyone. The JD as pasted lists no management requirement | Your background; the JD silent | `[grounded]` JD silent | pending your approval |
| Q1 | Ask the register's verification questions verbatim with the recruiter or Odile | RR1–RR5 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none recalled from prior context.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers"; the call was refused (permission not granted). It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary remote"; the call was refused. It would have moved the market calibration, which is absent, and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have moved the scope read and which story the plan leads with |

I can save all of this as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Search permission → I run the three L1 targets above; that would verify the employer (RR1), add a salary band (RR2), and set Odile's public work against the plan.
- A redacted monitoring pack, refit note or model-governance summary → R6b toward direct, and R4 toward `high`.
- A sanitized test design note or results readout → R7 toward `high`.
- A pricing paper or readout for a product or commercial reader → R8b.
- Your salary floor and location constraints → R1 and pay checks run against your terms.

R1 — Are you UK-based, and is working fully remote from the UK fine for you?

G1 — After you launched the young-driver GLM, what did you track on it, how often, and what did you change as a result?

G2 — Did any price-test result go to a product or commercial team rather than underwriting, and what did they do with it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.