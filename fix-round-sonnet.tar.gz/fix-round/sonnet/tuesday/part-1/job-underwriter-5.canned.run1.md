Research is done: I checked the live careers page and the company page. Here is the assessment.

## Decision snapshot

**Yes, worth applying to, once R1 and R2 (your location and pay floor) check out against your own terms. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Pay $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (dbt warehouse in BigQuery) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R8 (`medium`) — a bridge from your Snowflake dbt work, with its limit named; R9, R10 — your account is silent, so these are open questions, not shortfalls; R1, R2 — your own location and pay floor settle them.

**Opportunity ledger.** Sound but under-specified. The pay range's midpoint sits above the report's median (RR1) and the employer checks out as described (RR5). The equity terms (RR2), the team and ownership picture (RR3) and the success measures (RR4) are unstated.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 met by where you can work; (2) R2 met by your pay floor; (3) RR3's ownership picture confirmed in the loop; (4) R8 framed honestly as adjacent, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company about page |
| Posting status | Live, "Accepting applications"; wording, salary and location identical to what you pasted | `[grounded]` careers page fetched |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Scope read | Looks like ownership of one reporting domain's pipelines, matching the report's typical senior scope (one domain, no direct reports). The JD mentions no direct reports | `[grounded]` report's typical scope and JD silence on reports; `[inferred]` that the JD matches it |
| First-year outcomes | None stated | `[grounded]` JD silence |
| Market calibration | Datawright 2026, Senior Data Engineer at Series B–D, n=2,310: median $151,000, IQR $139,000–$163,500, "Senior" typically 5–8 years. The posted range's floor is $3,000 under the median, its midpoint $157,000 is above it, and its top is $2,500 above the IQR's upper end. This is a market band, never this employer's offer | `[generic]` band from the report your recruiter sent, no search run; `[grounded]` posted range |
| Unknowns | Team size and reporting line; hiring manager (unnamed); equity terms; success measures; new post or backfill | `[grounded]` JD silence |
| Contradictions | None between your pasted JD and the live page, or between your pasted company facts and the about page. The Series C figure is the company's own statement, not independently confirmed | `[grounded]` pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The posting states the terms. Where you can work isn't in what you sent, so nothing settles it. Confidence grades your own statement of the constraint, and there isn't one yet | `[grounded]` JD; you were silent on constraints | Answer G1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The range is stated; your floor isn't known, so whether it clears is unsettled. Equity is unquantified (RR2) | `[grounded]` JD; you were silent on constraints | Answer G2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, your own account. Specific, but no CV or artifact inspected yet, so `medium` with the caveat named. The report puts "Senior" at 5–8 years, so six sits inside it | `[grounded]` your stated background; `[generic]` report's band | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is your account. "Strong" is a self-rating with nothing inspected, so expect a technical screen | `[grounded]` your stated background; `[generic]` that such roles screen technically | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. The JD asks for "a cloud warehouse", which Snowflake is; BigQuery is a separate row (R8) | `[grounded]` your stated background | A sanitized dbt docs lineage graph or repo would raise to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration" is your account. What you owned in it (writing DAGs versus running the platform) isn't stated | `[grounded]` your stated background | Be ready to say what was yours; a sanitized DAG screenshot would raise it |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, in your words. Coverage and whether it gated pipeline runs aren't stated. The JD names no tool | `[grounded]` your stated background | A Data Docs report would raise it |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The Snowflake dbt work carries the modelling discipline. Limit: you have never used BigQuery (your words), so nothing about its table layout, cost model or dbt adapter is evidenced. The JD names BigQuery in the responsibilities, not in its requirements list | `[grounded]` JD and your statement; `[generic]` that dbt skills transfer between warehouses and warehouse-specific tuning doesn't | See G3 |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Your account names no source systems. This is silence, not absence | `[grounded]` silence in your background | G4, not asked this turn; prepare an example |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is indirect context, since it codifies expectations about data. A contract with analysts (agreed schema, owner, change notice) is different work, and you haven't claimed it | `[grounded]` the suite claim; `[inferred]` adjacency derived from it | Answer G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location (R1, hard_gate) | hard_gate | Terms stated; your situation unknown | A gate the inputs don't settle caps the decision at `conditional_go` | Not a recall item; your own situation settles it | None needed | `[grounded]` JD; you were silent |
| G2 | Pay floor (R2, hard_gate) | hard_gate | Range stated; your floor unknown | Same cap as G1 | Not a recall item | None needed | `[grounded]` JD; you were silent |
| G3 | BigQuery (R8, important) | transferability | Adjacent: dbt on Snowflake, about 180 models. Limit: no BigQuery use. Strengthener: a small dbt-on-BigQuery project | The one stack-specific point the JD names that you haven't touched | Any BigQuery exposure at all, such as a side project or a migration you were near | A repo or README from a small BigQuery project | `[grounded]` your statement; `[generic]` that stack-specific gaps are normally closed by a small sample |
| G4 | Ingestion from app and CRM (R9, important) | discovery | No source systems named | The JD lists it first among the responsibilities | Loading product events or a CRM export into the warehouse; owning a connector or an incremental load | A sanitized DAG or source list | `[grounded]` silence; `[generic]` that payroll-company pipelines often include such sources, so a plausible lead and nothing more |
| G5 | Data contracts (R10, important) | discovery | The Great Expectations suite exists; no agreement with analysts is claimed | The JD names contracts as what analysts depend on, and which story you lead with depends on the answer | Agreeing a schema, owner or freshness expectation with a consumer; a documented change process | A written schema agreement, a model contract config, a tests-plus-owners page | `[grounded]` CV-equivalent silence on contracts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay in line with market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range sits within the report's Series B–D band (floor $3,000 under the median, midpoint above it), so there is no seniority-pay mismatch | `[grounded]` posting and report figures; `[generic]` that the report band is a market pattern | Where in the range would an offer for this role land, and does it differ between the Remote (US) and Denver options? | noted |
| RR2 | Equity unquantified | unknown | — | "plus equity" | The grant could be small or substantial; its value can't be judged from the posting | `[grounded]` JD states nothing further | What is the equity: instrument, grant range for this level, vesting and the latest valuation? | unresolved |
| RR3 | Team and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The post may be a sole data engineer or one of a team. The responsibilities span ingestion, warehouse and contracts, which may be broader than the report's one-domain norm | `[inferred]` from the JD's responsibility span against its silence on team; `[grounded]` report's typical scope | Who is on the data team today, who does this role report to, and which of ingestion, the warehouse and the contracts would I own from day one? | unresolved |
| RR4 | No success measures or first-year outcomes | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Without stated outcomes, what good looks like is undefined | `[grounded]` JD silence | What would a successful first year look like, and what should analysts be able to do that they can't now? | unresolved |
| RR5 | Employer established; recent raise | positive_signal | — | "Series C ($52M, February 2026)" | The company exists as described and the posting is live. The raise suggests funded hiring | `[grounded]` about page and careers page fetched, figure self-reported; `[inferred]` funded hiring | Is this a new post or a backfill, and what did the raise change in the data team's plans? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your dbt work on Snowflake (about 180 models), your Airflow orchestration and the Great Expectations suite you set up, in your own words with the number attached to models | see R5, R6, R7 | `[grounded]` your stated background | pending your approval |
| P2 | Don't write BigQuery experience anywhere. Name Snowflake as what you used, and say BigQuery is new to you if asked | see R8 | `[grounded]` your statement | pending your approval |
| P3 | Optional: build a small dbt project on BigQuery as a work sample to narrow R8's limit | see R8, G3 | `[inferred]` adjacency derived from your Snowflake dbt work | pending your approval |
| P4 | Ask RR2, RR3, RR4 and RR5's questions verbatim in the loop | the register doubles as interview prep | `[grounded]` register | pending your approval |
| P5 | Ask where in the range an offer would land. Six years sits inside the report's typical 5–8 band for the title | see RR1, R3 | `[generic]` report pattern; `[grounded]` your six years | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report from your message, so `medium` is the ceiling on first pass. Unverified leads: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Searched "Pellucid Learning online tutoring K-12 Series C $52M", which returned "About Pellucid Learning" (pellucidlearning.com/about). Moved role reality's organization, posting-status and contradictions rows, and RR5. The employer is established, so no failed-attribution entry |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration line and RR1, the outputs this target feeds |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager |

I can save this as `tuesday-dossier.md` whenever you want it; just say so.

## Upgrade menu

- Your location and pay floor → R1 and R2 close, and the status can move to `go` or `no_go`.
- A sanitized dbt docs lineage graph or repo, a DAG screenshot, or a Great Expectations Data Docs report → R5, R6 and R7 can rise from `medium` toward `high`.
- A sanitized source list or ingestion DAG, or a written schema agreement with analysts → R9 and R10 firm up.
- The hiring manager's name, if your recruiter has it → role reality's scope read and which story the plan leads with for that reader.
- A deeper research pass on Pellucid Learning (funding and leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G1 — Are you able to work from within the US, remotely or in Denver?

G2 — Does $148,000–$166,000 clear your pay floor?

G5 — Did you ever agree a dataset's schema, owner or freshness with the analysts who used it? What did you own, and was it written down anywhere?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.