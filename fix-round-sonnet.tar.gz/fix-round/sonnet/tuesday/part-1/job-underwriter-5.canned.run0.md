Checking the posting is still live on Pellucid's careers page, since I'm following the job-underwriter playbook. After that I'll write the assessment.
**Yes, it's worth applying, with two things to confirm first (`conditional_go`). Your location and pay floor haven't been stated, and BigQuery is a gap you can name and close.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Pay $148–166k plus equity)
- `must_have`: direct: R3, R4, R5, R7, R8
- `important`: adjacent: R6 (BigQuery) · unclear: R9 (Data contracts), R10 (Ingestion from app and CRM)

What matters: R1, R2 stay open until you give your location and floor; R6 is a bridge with its limit named in G3; R9, R10 are things your background doesn't speak to either way.

**Opportunity ledger.** The posting is transparent on pay and work arrangement (RR1) and sits in the market band (RR2). Team shape, reporting line and success measures are unstated (RR3, RR4), and the equity terms are open (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Pay $148–166k plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you're in the US or can be in Denver (R1); (2) the range clears your floor (R2); (3) BigQuery is framed as adjacent, never as experience you have (R6, G3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page, fetched via search |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD, matches the live careers page |
| Seniority fit | Your 6 years sit inside the report's typical 5–8 for "Senior" | `[grounded]` your background; `[generic]` report's range |
| Market calibration | Report (Datawright 2026, US, n=2,310, Series B–D): base median $151,000, IQR $139,000–$163,500. The posted range starts just under the median and ends just above the upper quartile, and its midpoint ($157,000) is $6,000 above the median. Typical scope is one domain's pipelines, no direct reports. It is a pattern, not Pellucid's offer | `[generic]` pasted report; `[grounded]` posted range from JD |
| Contradictions | None between the JD you pasted and the live careers page | `[grounded]` careers page fetched |
| Unknowns | Team size, reporting line, whether you'd be the first or only data engineer, equity terms, on-call expectations | none stated in the JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or authorized to work, so no statement of yours exists to grade | `[grounded]` JD term; your location absent | Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Pay is a term. The range is stated, but I don't have your floor | `[grounded]` JD; floor not given | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, specific and plausible. Experience length is not a gate. No artifact inspected, so expect a probe | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use, with 180 dbt models as indirect context. Nothing inspected | `[grounded]` your stated background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | Built the dbt project, about 180 models, on Snowflake. Snowflake is a cloud warehouse, so the requirement as written is met | `[grounded]` your stated background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in the JD and in your background | `[grounded]` your stated background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. Your wording says "set up", so I assert setup, not ongoing ownership | `[grounded]` your stated background | none |
| R6 | BigQuery warehouse (named in the role description) | important | adjacent | medium | transferability | Snowflake and dbt carry over. Limit: you haven't used BigQuery, so its cost and performance mechanics are untested by your work | `[inferred]` adjacency from Snowflake and dbt work; `[generic]` that warehouse switches are common for dbt engineers | G3 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing in your background says either way whether you defined formal contracts or SLAs with downstream consumers | `[grounded]` background silent | G4 / Q3 |
| R10 | Ingestion from product app and CRM | important | unclear | low | discovery | Your sources at the payroll company aren't stated, so I can't tell whether app and CRM-style ingestion matches | `[grounded]` background silent | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location (R1, hard_gate) | hard_gate | Location and work authorization not stated | A failed gate would make this `no_go` whatever the fit | Being US-based, or able to work from Denver | None needed, your word is the evidence | `[grounded]` JD term vs your silence |
| G2 | Pay floor (R2, hard_gate) | hard_gate | Posted range known; floor not | Decides whether the range is acceptable | Your current base and target | None needed | `[grounded]` JD range |
| G3 | BigQuery (R6, important) | transferability | Snowflake and dbt are credible adjacent work | The hiring team will likely probe it, and a stated limit reads better than a gap found in interview | Adjacent: warehouse modelling, cost and performance tuning, SQL dialect porting. Limit: no BigQuery work, so none of its pricing model, partitioning or clustering. Strengthener: a small BigQuery project on public datasets, or a short dbt-bigquery run you can discuss | Repo, README or query-plan notes | `[inferred]` bridge; `[generic]` that BigQuery cost and performance mechanics differ from Snowflake's |
| G4 | Data contracts (R9, important) | discovery | Silence on contracts | Named in the JD as what analysts depend on | Schema or freshness agreements with analysts, GE checks that blocked bad data, a dbt contract or tests tied to a consumer's needs | A doc, dbt YAML excerpt or runbook | `[grounded]` background silent; `[generic]` that contracts often hide in tests and docs |
| G5 | App and CRM ingestion (R10, important) | discovery | Sources not stated | Core to the mandate | Pipelines from a product database, event stream or SaaS CRM API into the warehouse | An architecture diagram or DAG list | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay and arrangement disclosed | positive_signal | — | "Salary $148,000–$166,000 plus equity. Remote (US) or our Denver office." | The posting is transparent on the terms candidates most often have to chase | `[grounded]` JD | What does the equity grant typically look like at this level? | noted |
| RR2 | Posted range in the market band | positive_signal | — | "$148,000–$166,000" | The range is not a seniority-compensation mismatch against the report's median and IQR | `[generic]` pasted report vs `[grounded]` posted range | Where in the range does an offer for my experience usually sit? | noted |
| RR3 | Team shape and reporting line unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | I may be the only data engineer, or part of a team. The posting doesn't say | `[inferred]` from the JD's silence | How many data engineers are there, and who does this role report to? | unresolved |
| RR4 | No success measures on a "build and run" mandate | unknown | — | "Build and run the pipelines…" | What a good first year looks like is undefined | `[inferred]` from the JD's silence | What would a successful first 12 months look like? | unresolved |
| RR5 | Equity terms unstated | unknown | — | "plus equity" | Value and vesting are unknown, so the total package is too | `[inferred]` from the JD's silence | What are the equity amount, vesting and strike price? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the dbt project (about 180 models), the Airflow orchestration and the Great Expectations suite you set up. Say "Snowflake" plainly, with no BigQuery claim | see R3–R8 | `[grounded]` your stated background | pending your approval |
| E2 | In a cover note, state BigQuery as "new to me, with Snowflake and dbt experience that transfers", only if you accept the framing | see R6, G3 | `[inferred]` from the adjacency | pending your approval |
| W1 | A small BigQuery exercise, if you want to narrow the R6 limit before applying | see G3 | `[inferred]` | pending your approval |
| Q1 | Ask the verification questions in RR3–RR5 in your first screen | register doubles as interview preparation | `[grounded]` register | pending your approval |

All of the above is proposal-only. Nothing becomes resume or outreach text without your explicit approval.

## Evidence status

Verified: none yet. Everything about your background is your own statement, so nothing is inspected.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): live, "Accepting applications", text matches what you pasted. Moved: role reality's organization and contradictions rows; the employer-not-established entry isn't triggered |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration and the compensation comparison |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there's no query to form |

## Dossier offer

If you'd like this saved for later rounds, I can emit it as `tuesday-dossier.md`, entirely optional.

## Upgrade menu

- Your location and floor → R1 and R2 settle, and the decision likely resolves to `go` or `no_go`.
- Your answer on data contracts (G4) → R9 moves toward `direct`, or stays a named gap.
- A DAG list or architecture sketch showing your ingestion sources → R10 resolves.
- A dbt or Great Expectations excerpt, sanitized → R5 and R8 can rise to `high`.
- A BigQuery side project → narrows R6's limit.
- A hiring manager's name → scope read and which story to lead with.
- A deeper research pass on Pellucid (funding, leadership churn, candidate and employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

Q1 (R1) — Are you based in the US, authorized to work there, and either fine with remote or able to work from Denver?
Q2 (R2) — What base salary would you need for this to be worth it, against the $148,000–$166,000 range?
Q3 (R9) — Have you defined formal data agreements with analysts or other downstream users (schemas, freshness, SLAs), and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip. If you want help with the BigQuery gap or tailoring your resume, that is a separate step I can take once you've decided.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.