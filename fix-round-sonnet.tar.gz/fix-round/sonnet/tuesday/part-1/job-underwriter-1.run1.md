Running the two L1 research searches now: one on Harborlight Health itself, one on market norms for this role. Then I'll write the full assessment.
**Snapshot**

**Yes, apply. You're a fit on R1, R2, R3, R4 and R5, and R6 is the one to confirm. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · unclear: R6 (Define and maintain the metrics layer)
- `important` — direct: R7a · adjacent: R7b (Partnering with clinicians) · unclear: R8 (Mentoring two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R6 — metrics-layer ownership isn't stated in your background; R7b and R9 — healthcare is the bridge to build; R8 — mentoring isn't stated.

**Opportunity ledger.** The role is concretely scoped (RR5), but the employer is unverified (RR1), compensation is withheld (RR2), the work pattern is unstated (RR3), and the mandate is wide for one hire (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) compensation and work pattern prove acceptable to you (RR2, RR3); (3) metrics-layer ownership is confirmed as part of your background (R6, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, care-navigation app | `[grounded]` JD header (as stated, not verified) |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A senior individual contributor who also mentors, with a broad remit: metrics, experimentation and BI under one owner | `[inferred]` from the responsibility list against its silence on team size and reporting line |
| Market calibration | Not performed. Compensation is unstated, so there is no band to set against it | `[grounded]` JD silent on pay; research sweep not run (see Evidence status) |
| Unknowns | Compensation, location or remote policy, hiring manager, whether mentoring is formal line management, what the metrics layer is built in, how clinician partnership works day to day | — |
| Contradictions | None inside the JD itself | `[grounded]` JD read |

## Evidence map

Your background was typed in, so it counts as self-report like a CV. That caps every row at `medium` until you share something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a meal-kit subscription company; self-reported | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake. "Expert" is a level you haven't described beyond daily use, so expect a live-SQL probe | `[grounded]` your background | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift, at about 2M subscribers | `[grounded]` your background | offer: a sanitized test readout would raise to high |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the company's Looker instance from scratch, 40+ governed dashboards | `[grounded]` your background | offer: a screenshot or sanitized dashboard list would raise to high |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly metrics memo the exec team reads | `[grounded]` your background | offer: a sanitized memo would raise to high |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" suggests shared definitions, but you didn't say you owned metric definitions or a semantic layer. Nothing confirmed, so not asserted | `[inferred]` from "governed dashboards"; `[grounded]` background silent on definitions | G1 |
| R7a | Partner with product leadership to turn analysis into roadmap decisions | important | direct | medium | none | Presents monthly to the VP Product, and the pricing test drove a retention outcome. Day-to-day PM partnership isn't stated | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | adjacent | low | transferability | Cross-functional presenting is adjacent, but no clinician or other domain-expert partnership is stated | `[inferred]` adjacency from your stakeholder work | G2 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Mentoring isn't mentioned in your background | `[grounded]` background silent | G3 |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse consent-state model. Limit: none of that touched PHI, HIPAA rules or healthcare data | `[grounded]` your background; limit named | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, must_have) | discovery | Governed Looker dashboards, but no statement about who defined the metrics or where definitions lived | A must-have at `unclear`; resolving it is the main lever on the decision | Writing the canonical definition of churn or retention; LookML explores or a metric glossary; a dbt or semantic-layer model; settling a definitional dispute between teams | A metric dictionary, LookML excerpt, or definitions doc, sanitized | `[grounded]` background silent; `[inferred]` that it is the main lever |
| G2 | Healthcare and clinician bridge (R7b, R9) | transferability | Adjacent evidence: PII handling under GDPR/CCPA, the consent-state model, exec and VP communication. Limit: no PHI, no HIPAA safeguards, no clinician stakeholders. Strengthener: a short consent-model writeup showing how access and purpose were governed | The healthcare domain is the stretch in this application, and it is a plus rather than a requirement | Working with legal or privacy on data-use rules; analysis for a medical, nutrition or dietitian-adjacent team; a de-identification or access-control decision | A sanitized consent-model diagram or data-governance doc | `[grounded]` your background; `[generic]` that healthcare roles weigh data-handling judgment |
| G3 | Mentoring (R8, important) | discovery | No mention of coaching, reviewing or managing analysts | The JD names two juniors, so the answer shapes how the role is positioned | Reviewing others' SQL or test designs; onboarding a new analyst; running an analytics office hour | A review checklist or onboarding doc | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be unverifiable from here, or the posting may be stale or aggregated | `[generic]` pattern for unverified postings, not a claim about this company | Can you point me to this role on Harborlight's own careers page, and who would I interview with? | unresolved |
| RR2 | Compensation withheld | unknown | — | (no figure in the JD) | The band may not match a senior scope, or the company may simply not publish it | `[inferred]` from the JD's silence | What is the budgeted salary range for this role? | unresolved |
| RR3 | Work pattern unstated | unknown | — | (no location or remote policy in the JD) | The role may be on-site or hybrid | `[inferred]` from the JD's silence | Is the role remote, hybrid or on-site, and where? | unresolved |
| RR4 | Wide mandate for one hire | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards … mentor two junior analysts" | Metrics, experimentation, BI and mentoring may be several jobs under one title | `[inferred]` from the responsibility list | Which of these is the priority in the first six months, and what support does the role have? | unresolved |
| RR5 | Concretely scoped responsibilities and named stack | positive_signal | — | "Looker", "A/B tests", "two junior analysts" | The role looks specifically defined, with an existing team to lead | `[grounded]` JD names each | What does success look like at twelve months? | noted |

## Application plan

`resume_edits_pending_approval` — every row below is proposed language or strategy, and every row is pending your approval. Each proposed line traces to your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the experimentation bullet with: "Designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | See R3. It is your own claim, reordered | `[grounded]` your background | pending your approval |
| E2 | Add a consent line: "Handled GDPR/CCPA consumer PII; built the consent-state model for the company warehouse" | See R9. It is stated as adjacent and does not claim HIPAA or healthcare experience | `[grounded]` your background | pending your approval |
| E3 | State "no healthcare experience yet" plainly in the cover note, then point to E2 | See R9. Stating it first keeps the limit yours rather than the interviewer's | `[grounded]` your background | pending your approval |
| Q1 | Ask the RR1 to RR4 questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search permission was not granted, so nothing was returned. It would have moved RR1 and the Organization row |
| 2. Role-family sweep | unavailable | Same reason. It would have moved the Market calibration row and the RR2 comparison |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'll offer to turn this into a `tuesday-dossier.md` whenever you want one.

**Upgrade menu**

- Search access → targets 1 and 2 run: RR1 can clear, and the role gets a market-calibration row. A deeper pass on Harborlight (funding, leadership changes, employee reports; up to 5 more searches and 2 more fetches) runs only on your say-so.
- A sanitized metric dictionary or LookML excerpt → R6 resolves.
- A sanitized test readout, dashboard list or metrics memo → R3, R4, R5 move toward `high`.
- A sanitized consent-model writeup → R9's bridge strengthens.
- Your pay floor, location and authorization → hard-gate checks run against the role.
- The hiring manager's name → target 3 runs.

**Questions**

G1 — Who defined the core metrics (retention, churn, activation) at your company? Did you write the definitions, hold them somewhere like LookML or a glossary, and settle disputes over them?
G3 — Have you coached, reviewed or onboarded other analysts, and was it formal or informal?
C1 — Do you have a pay floor, location or remote requirement, or work-authorization constraint that I should check this role against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.