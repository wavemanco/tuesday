Search access wasn't granted, so this rests on your message and the JD alone. The labels show where that limits a claim.

## Decision snapshot

**Yes, worth applying to. R2, R3, R4, R5, R6a and R7 (`must_have`) are `direct`. Your two flagged gaps don't sit on a must-have: pet insurance is R10 (`preferred`, `adjacent`), and the JD names no line management at all. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6a, R7 · adjacent: R6b (Monitoring rating models)
- `important` — direct: R8a · unclear: R8b (Recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain knowledge)

R1 — a gate nothing in your message settles, not a conflict; R6b — monitoring was not stated, only "maintained"; R8b — product-facing work not yet evidenced; R10 (`medium`) — an adjacent bridge, its limit named.

**Opportunity ledger.** Unverified rather than troubling: the employer could not be checked (RR1), pay is not stated (RR2), and who signs off pricing changes, and whether anyone reports into the role, is open (RR3). One entry runs the other way: the JD's responsibilities are specific (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, via RR1 and A1; (2) R1 is confirmed; (3) pay falls in a range you would accept, via RR2 once you name a floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product; not independently checked (RR1) | `[grounded]` JD header |
| Title and reporting | Senior Pricing Analyst; hiring manager is Odile Varga, Director of Pricing | `[grounded]` JD and your message |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | An individual-contributor analytics seat; no people-management language appears | `[inferred]` from the JD's silence on reports or team leadership |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not established: the role-family sweep did not run, so no pay band or title norm is claimed | `[grounded]` Evidence status below |
| Unknowns | Salary; team size and sign-off rights; whether the post is new or a backfill; what claims and vet-cost data exist for the pet book | `[grounded]` JD silent on each |
| Contradictions | None inside the JD; there is no second source to compare it against | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You have not said where you live or your right to work. Working at a UK insurer is indirect context, not confirmation, so confidence is `low`: it grades a constraint you haven't stated. | `[inferred]` from your UK motor-insurer employment | Ask whether the gate is met (G1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years of pricing analytics at a UK motor insurer, stated by you; no document yet | `[grounded]` your background, prose | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated; "strong" is the JD's word and nothing inspectable backs it. Roles like this often add a technical exercise. | `[grounded]` your statement; `[generic]` on technical exercises | A sanitised query or notebook would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Direct on method; the book is motor, not pet. | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD says "underwriting or actuarial", so this meets it; no actuarial audience is stated. | `[grounded]` your background | none |
| R6a | Build rating models | must_have | direct | medium | none | "Built and maintained the GLM rating model" covers building. | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | adjacent | low | discovery | "Maintained" is not the same as "monitored", and ambiguity resolves downward. What tracking you ran after release is not stated. | `[grounded]` your wording; `[inferred]` that maintaining likely involved some monitoring | Recall prompt G3 |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with underwriting. Which parts you designed (structure, sizing) versus read is not stated, so keep to "ran" until confirmed. | `[grounded]` your background | A test readout would raise to `high` |
| R8a | Recommendations to underwriting | important | direct | medium | none | The tests were run with underwriting and you present the quarterly review to their head | `[grounded]` your background | none |
| R8b | Recommendations to product | important | unclear | low | discovery | Your background mentions underwriting only; product-facing work is neither shown nor ruled out | `[grounded]` silence on product | Recall prompt G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain knowledge (inferred from the product named in the JD) | preferred | adjacent | medium | transferability | You have never worked on pet insurance. The bridge is rating-model and test method from motor. The limit is that pet-specific rating factors and claims patterns were not exercised. | `[inferred]` from the JD's product line against your motor work; `[generic]` that rating method carries across personal lines | Bridge case G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK location and right to work (R1, hard_gate) | hard_gate | Nothing states where you are based or that you can work in the UK | A gate: it decides eligibility whatever the fit elsewhere | Your own statement is enough; no document is needed | None | `[grounded]` silence on location |
| G2 | Recommendations to product (R8b, important) | discovery | Underwriting audiences only | The JD names product as a recipient, so absence here is the likeliest probe on the second audience | A test result that changed a product feature, bundle or cover level; a pricing view presented to a product owner; a joint decision with a product manager | A test readout, deck or email thread, sanitised | `[grounded]` background silent; `[generic]` that roles naming two audiences probe both |
| G3 | Monitoring rating models (R6b, must_have) | discovery | "Maintained" is stated; the tracking you ran is not | A must-have at `adjacent`; the evidence may exist | Tracking actual versus expected after a release; refit triggers; drift or segment checks; a monitoring pack others used | A monitoring pack or model-review note, sanitised | `[grounded]` your wording |
| G4 | Pet-insurance domain (R10, preferred) | transferability | Method carries over; pet data and rating factors are untested | Preferred, so a minor risk, but it is the gap you flagged | Rating on age, breed or cover-level style factors; claims cost trends; severity modelling | A short sanitised note on how a young-driver factor set was chosen | `[inferred]` from your motor work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The employer may be new or small, the posting stale or aggregated, or the employer not real. Here it is unverified because search did not run. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (the JD as pasted carries no figure) | The posting may withhold pay, or the paste may have dropped it | `[grounded]` the pasted JD has no figure | What salary range is budgeted for this post? | unresolved |
| RR3 | Authority and team shape unstated | unknown | — | "Own pricing analytics" | The role may recommend while sign-off sits with underwriting or product; whether anyone reports in is unstated | `[inferred]` from "own" against silence on decision rights | Who signs off rating-model and price changes, and does this role have anyone reporting into it, now or planned? | unresolved |
| RR4 | Specific responsibilities | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is defined and maps closely onto the requirements | `[grounded]` JD | What would a good first year look like in this seat? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the employer and live posting (careers-page link or the recruiter's email domain) before spending effort | RR1, condition 1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the GLM rating model you built and maintained for the young-driver book (R4, R6a), the 14 price tests you ran with underwriting (R7), and the quarterly review you present to the head of underwriting (R5). Keep to "built and maintained" and "ran"; do not upgrade them to "designed" or "owned" unless you confirm that is accurate. | Those rows are your strongest | `[grounded]` your background | pending your approval |
| A3 | Say plainly that you have not worked on pet insurance, then point to R4 and R7 as the method you would bring | R10's limit stays visible | `[grounded]` your statement | pending your approval |
| A4 | Do not present lack of line management as a gap; ask RR3's question instead | The JD asks for none, and RR3 checks the post's shape | `[grounded]` JD | pending your approval |
| A5 | Ask RR1 to RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Optional extra (x): a one-page, sanitised note on how you would adapt your test design to a pet book would narrow R10's limit. It is built only if you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech" and "Brindlemoor Senior Pricing Analyst careers"; both refused. Would have moved role reality's organization and contradictions rows, and RR1. |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary remote"; refused. Would have moved the market calibration line and RR2. |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. Would have moved role reality's scope read and A2's positioning. |

I can offer to save this as a `tuesday-dossier.md` to carry forward, if you want it.

## Upgrade menu

- A link to the live posting or Brindlemoor's careers page (I can read a link you give me) → RR1 and the contradictions row; condition 1 could clear.
- Allowing search → targets 1 to 3 re-run, giving a pay band for RR2 and the employer check.
- Your location, right to work and any pay floor → R1 and RR2 checked against the post.
- A sanitised model-validation summary or price-test readout → R4, R6a and R7 toward `high`.
- A sanitised query or notebook → R3 toward `high`.
- An answer on the monitoring you ran (G3) → R6b.

Questions:

1. G1 — Does "fully remote (UK)" work for you: are you UK-based with the right to work there?
2. RR2 — Do you have a pay floor, or any other non-negotiable (hours, contract type, location), I should check this role against?
3. G2 — Have you ever taken a pricing or test result to a product team or owner, and what did you own in that decision?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.