Web search wasn't permitted, so this is built from the JD and your message only, and it says so wherever it matters.

## Decision snapshot

**Yes, apply. You fit on the must-have rows R1, R2, R3, R4 and R5, and healthcare (R9a) is a preferred-tier gap, not a barrier. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — direct: R7a · unclear: R6 (Define and maintain the metrics layer), R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9b (Sensitive-data handling, HIPAA-adjacent) · absent: R9a (Healthcare data experience)

R2 (`medium`) — SQL claim is confirmed by you, no sample yet; R6, R7b, R8 — your background is silent, so these are questions, not weaknesses; R9a — a capability gap on a preferred row, with R9b as the honest bridge.

**Opportunity ledger.** Clearly scoped, with a named tool, named partners and a roadmap-linked mandate (RR6). Pay and location are absent from what you pasted (RR1, RR2), the success measures are unstated (RR3), the scope is broad (RR4), and the employer is unverified (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify — RR5; (2) pay and location are checked against your own limits once you give them — RR1, RR2; (3) your answers on the metrics layer and mentoring land as real experience — R6, R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C; care-navigation app | `[grounded]` JD header; not checked externally |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, roadmap partnership with PMs and clinicians, mentoring | `[grounded]` JD |
| Scope read | Senior individual contributor with light lead duties: two juniors to mentor, no reports or line management stated | `[inferred]` from "mentor two junior analysts" with no management language |
| First-90-days outcomes | Not stated in the JD | `[grounded]` JD silence |
| Market calibration | None given. The role-family sweep did not run, and I won't state pay bands from memory | `[grounded]` run status |
| Unknowns | Pay, location or remote policy, success measures, the data stack beneath Looker, who owns data modeling | `[grounded]` JD silence |
| Contradictions | None in the JD as pasted; the careers page was not checked | `[grounded]` JD text |

## Evidence map

Your background is typed prose, so it counts as self-report and stays at `medium` at most until something inspectable backs it.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company. The posting counts years as a requirement, not a legal bar | `[grounded]` your message | CV or LinkedIn dates would raise it |
| R2 | Expert SQL | must_have | direct | medium | none | You state daily SQL on Snowflake. "Expert" is a self-grade with no sample behind it | `[grounded]` your message | A sanitized query or model sample would raise it |
| R3 | Experiment design at scale | must_have | direct | medium | none | You state 30+ A/B tests a year, plus the pricing test behind an 11% retention lift. The ~2M-subscriber base supports "at scale" | `[grounded]` your message | A write-up of the pricing test (sanitized) would raise it |
| R4 | Looker or similar BI | must_have | direct | medium | none | You state you built the Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your message | A dashboard screenshot or governance doc would raise it |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your message | A sanitized memo would raise it |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed dashboards" may imply metric definitions, but you did not say you owned them. Where the semantic layer lived is the open question | `[grounded]` your message does not state it; `[generic]` that many analyst roles consume metric definitions another team owns | Question G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | You present monthly to the VP Product and ran the pricing test. Whether you shaped roadmap choices, as opposed to presenting results, is untested | `[grounded]` your message | Expect a probe on which decisions you changed |
| R7b | Partner with clinicians | important | unclear | low | discovery | Nothing in your message mentions working with domain experts | `[grounded]` your message silent | Not in this round's questions; offer in menu |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | No mentoring or management evidence in your message | `[grounded]` your message silent | Question G2 |
| R9a | Healthcare data experience (a plus) | preferred | absent | none | capability | You have not worked in healthcare. Wording cannot close this | `[grounded]` your message | Carry as a known, minor gap |
| R9b | Careful handling of sensitive personal data (inferred from the HIPAA mention) | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for the warehouse. Limit: that is consumer PII, not health information. HIPAA has its own de-identification and access rules that you haven't used | `[grounded]` your message; `[generic]` that HIPAA rules differ from GDPR/CCPA | Frame as adjacent only, never as HIPAA experience |

R9b's requirement is inferred, not quoted: the JD names HIPAA experience as a plus, and I read it as the broader skill.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, important) | discovery | "Governed dashboards" without a stated owner of metric definitions | The JD lists the metrics layer first among its responsibilities | Writing LookML or semantic-layer definitions; a metric dictionary you maintained; settling a disputed definition such as "active subscriber" | A metric dictionary page, LookML excerpt, or governance doc (sanitized) | `[grounded]` your message's silence; `[generic]` that metric-definition ownership is commonly tested in interviews for this role family |
| G2 | Mentoring (R8, important) | discovery | No people-development evidence | The role carries two junior analysts | Onboarding an analyst, reviewing their SQL or experiment designs, running a team office hour, informal mentoring | A short description is enough | `[grounded]` your message's silence |
| G3 | Clinician or domain-expert partnership (R7b, important) | discovery | No domain-expert partnership mentioned | The JD names clinicians as partners | Working with nutritionists, culinary or operations specialists, or other non-analyst experts to shape a test | A short description | `[grounded]` your message's silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | no pay stated in the pasted JD | The posting may omit pay, or the pay line may not have been pasted | `[inferred]` from the pasted text's silence | What is the budgeted salary range for this role? | unresolved |
| RR2 | Location or remote policy not stated | unknown | — | no location in the pasted JD | Unknown whether the role is remote, hybrid or on-site | `[inferred]` from the pasted text's silence | Where is this role based, and what is the in-office expectation? | unresolved |
| RR3 | Success measures not stated | unknown | — | "turn analysis into roadmap decisions" | A demanding mandate with no defined outcomes | `[inferred]` from the JD's silence on outcomes | What would success look like at 6 and 12 months? | unresolved |
| RR4 | Several jobs folded into one | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards... mentor two junior analysts" | The role may combine analytics engineering, experimentation and a team-lead duty without a matching title or support. Severity is `low` because the JD names a mentoring duty and no reports | `[inferred]` from the length of the responsibility list | Who owns the data modeling beneath the metrics layer, and is there an analytics engineer? | unresolved |
| RR5 | Employer not established from attributable sources | risk_signal | low | "digital-health scale-up, ~400 people, Series C" | The posting is unchecked because the search was refused, not because it failed. This caps the decision at `conditional_go` | `[generic]` pattern for unchecked employers, not a claim about this one | Can you point me at the role on your own careers site, and who would I interview with? | unresolved |
| RR6 | Clear responsibilities, named tool and partners | positive_signal | — | "Looker or a similar BI tool"; "partner with product managers and clinicians" | Scope is concrete and tied to roadmap decisions | `[grounded]` JD | Which roadmap decision most recently changed because of this team's analysis? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the pricing test behind the 11% retention lift as your experiment story, with the claim kept as you stated it | R3, R7a | `[grounded]` your message | pending your approval |
| A2 | Position privacy work as adjacent: GDPR/CCPA plus the consent-state model, never as health-data or HIPAA experience | R9a, R9b | `[grounded]` your message | pending your approval |
| A3 | Say what you personally owned on the Looker build and the metrics, once G1 is answered | R4, R6 | `[grounded]` your message | pending your approval |
| A4 | Verify the posting is live on the company's own careers page before investing application time | RR5 | `[grounded]` register | pending your approval |
| A5 | Ask RR1, RR2 and RR3 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything above comes from your typed background, with no CV or artifacts supplied.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were requested and refused, one aimed at this target (the company and role). It would have moved the organization and contradictions rows and RR5 |
| 2. Role-family sweep | unavailable | One search was requested and refused. It would have moved market calibration and a pay check for RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can write all of this up as `tuesday-dossier.md` if you want to carry it forward.

## Upgrade menu

- Granting web search lets me run L1 (up to 5 searches and 2 fetches): RR5 and the organization row could close, and a pay band could be added.
- Your CV or LinkedIn dates → R1 toward `high`.
- A sanitized SQL sample → R2 toward `high`.
- A sanitized write-up of the pricing test → R3 toward `high`.
- A dashboard screenshot or governance doc → R4 toward `high`.
- A sanitized monthly memo → R5 toward `high`.
- An answer to G1 → R6 resolves or becomes a gap.
- An answer to G2 → R8 resolves or becomes a gap.
- Any example of partnering with non-analyst experts (G3) → R7b.
- The hiring manager's name → role reality's scope read.

## Questions

G1 — Did you personally define and maintain the shared metric definitions, in LookML or elsewhere, or did you consume definitions someone else owned? Name one metric you defined and what you did to it.

G2 — Have you mentored or managed other analysts, formally or informally? What was your role and for how long?

RR1, RR2 — What are your non-negotiables on pay, location or remote work, and anything else that would rule a role out?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.