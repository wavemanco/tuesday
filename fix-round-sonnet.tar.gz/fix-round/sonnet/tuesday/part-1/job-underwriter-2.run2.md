Web search was denied, so this assessment runs on your resume and the posting only.

## Decision snapshot

**No, you're not wasting your time. R3 and R4a are `direct`, and R1b, R2, R6, R7 and R9 are `adjacent`. But R1a, the titled-years requirement, is `absent` and may cost you screens. Status: `conditional_go`. Apply as a stretch, not a sure thing.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM-style work, no title), R2 (Shipped API or platform products) · unclear: R5 (Agile delivery) · absent: R1a (3+ years product management)
- `important` — adjacent: R6 (Discovery with integration partners), R7 (Specs and delivery with two squads), R9 (Own the roadmap) · unclear: R4b (Launches with sales and support), R8 (Adoption metrics)

R1a — titled years absent, the likeliest screen-out; R2 — the substantive gap, since you consumed APIs and did not ship one; R5, R8, R4b — the CV is silent, and each is answerable.

**Opportunity ledger.** The role looks real and close to your API background (RR5), but R1a may be screened literally (RR2). The employer, compensation and success baseline are unverified (RR1, RR3, RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live and the employer real, RR1; (2) the hiring side signals flexibility on the three years, RR2, R1a; (3) your bridge is framed as adjacent and never as PM tenure, R1b, R2, R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | B2B logistics-tech, about 150 people, Series B; not verified | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform, run partner discovery, write specs, drive two squads, track adoption, coordinate launches | `[grounded]` JD |
| Scope read | Real ownership of a platform with two squads, at a company small enough that titled-years rules may flex | `[inferred]` from the JD's scope against the stated size |
| First-year outcomes | None stated | `[grounded]` JD silent |
| Unknowns | Compensation, reporting line, seniority level, current adoption baseline, whether the three years are flexible | `[grounded]` JD silent on each |
| Contradictions | None within the JD | `[grounded]` JD only; no careers page checked |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, as titled | must_have | absent | none | discovery | You have never held a PM title. Titled years can't be recovered, but untitled PM work can (see R1b) | `[grounded]` your statement; `[generic]` that "must-have" years are often screened literally | G1 |
| R1b | PM-style work done without the title | must_have | adjacent | medium | transferability | Confirmed and specific: roadmap-input sessions for product, requirements documents, coordinating PMs and engineers. Limit: you fed the roadmap and did not own priorities or outcomes | `[grounded]` resume | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your vendor's REST APIs and wrote the integration playbook. Limit: no evidence you designed, versioned, documented or released an API | `[grounded]` resume; limit is `[inferred]` from the resume's silence | G2; a work sample would narrow it |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI and 30+ integrations are specific, but self-reported with no inspectable artifact yet | `[grounded]` resume | none |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran scoping workshops through UAT and go-live | `[grounded]` resume | none |
| R5 | Agile delivery experience | must_have | unclear | none | discovery | The resume doesn't mention sprints, backlogs or a delivery cadence | `[grounded]` resume silence | G3 |
| R4b | Coordinating launches with sales and support | important | unclear | none | discovery | Go-lives were client-facing; there's no mention of sales or support launch work | `[grounded]` resume silence | G4 |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Quarterly client roadmap-input sessions are close. Limit: you collected feedback and are not shown prioritizing it | `[grounded]` resume | G2 |
| R7 | Write specs, drive delivery with two squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated engineers on custom builds. Limit: not shown owning a squad's backlog | `[grounded]` resume | G1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Only an unconfirmed lead from a prior conversation, a possible internal request-triage tool, which can prompt a question and is not evidence | `[inferred]` from agent memory, unconfirmed | G1 |
| R9 | Own the roadmap | important | adjacent | medium | transferability | Roadmap input is not ownership. Limit stated as above | `[grounded]` resume | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product-owned outcomes (R1b, R7, R8) | discovery | Coordination and requirements work, but not who set priorities or measured results | Most movable must-have; it decides whether R1a reads as "no PM work" or "PM work without the title" | An internal tool or process others adopted; deciding what engineers built first; a spec a team built from; usage figures you tracked | A spec or PRD, a roadmap doc, a usage dashboard screenshot, release notes (sanitized) | `[grounded]` resume silence; `[generic]` that screens weigh owned outcomes |
| G2 | Client feedback changing a product (R2, R6, R9) | transferability | You collected feedback for product, and nothing shows what changed | It's the strongest bridge to R2, the substantive must-have gap | An endpoint, doc or release that changed because of your input; escalations you shaped into requirements | A feedback summary, changelog entry or ticket trail | `[grounded]` resume; `[inferred]` that this is the strongest bridge |
| G3 | Agile delivery (R5) | discovery | No cadence evidence | A named requirement with no evidence either way | Sprint ceremonies on custom builds; backlog grooming with engineers; working in Jira or similar | A sprint board export or retro note | `[grounded]` resume silence |
| G4 | Launches with sales and support (R4b) | discovery | Client go-lives only | Part of the role's launch coordination | Enablement for sales or support at go-lives; release comms | A launch checklist or enablement note | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified | unknown | — | "B2B logistics-tech, ~150 people, Series B" | Research was unavailable, so existence and posting status are open | `[grounded]` no check ran | Who does this role report to, and when was it opened? | unresolved |
| RR2 | Titled-years requirement may be screened literally | risk_signal | medium | "3+ years product management experience (must-have)" | Applicant screening may filter on titled PM years before a human reads the resume | `[generic]` pattern, not a claim about this employer | How flexible is the three-year requirement for seven years of API-integration delivery with product-facing work? | unresolved |
| RR3 | No success baseline stated | risk_signal | low | "define and track adoption metrics" | Metrics may be undefined, leaving accountability open | `[inferred]` from the JD's silence on baselines | What adoption metrics exist today, and what is the baseline? | unresolved |
| RR4 | Compensation unstated | unknown | — | the JD names none | Pay may not match a first PM title or the seniority implied | `[inferred]` from the JD's silence | What range is budgeted for this role? | unresolved |
| RR5 | Concrete partner-API mandate | positive_signal | — | "Own the roadmap for our partner-facing API platform" | Real scope that matches your integration background | `[grounded]` JD | Which partner integrations top the roadmap now? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move "Ran quarterly roadmap-input sessions collecting client feedback for product" and "Led 30+ client integrations of our REST APIs end to end" to the top; keep your own verbs and add no PM-owner language | R1b, R6, R2 | `[grounded]` resume | `resume_edits_pending_approval` |
| A1 | Verify the posting and reporting line with the recruiter first | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask RR2, RR3 and RR4 verbatim early in the first call; RR2 tells you whether the three years are firm | Register doubles as call prep | `[grounded]` register | pending your approval |
| A3 | Consider a one-page work sample from your own integration experience, with client details removed | Narrows the limit on R2 | `[grounded]` R2 row | pending your approval |
| A4 | Apply to a short list of similar platform or API PM roles, and ask about an internal PM transfer where you are | Technical fluency is often the harder half; titled years are often the gate | `[generic]` role-family pattern | pending your approval |

If you decide to apply, resume-tailor can turn E1 into a full edit ledger.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search permission was denied. It would have moved RR1 and the Organization row |
| 2. Role-family sweep | unavailable | Same denial. It would have moved a market calibration line and RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you want a portable record of this, I can write it to `tuesday-dossier.md`.

## Upgrade menu

- Search permission → re-runs targets 1 and 2: whether Quartzline and the posting are real, and a pay band for RR4.
- A sanitized spec, roadmap doc or usage view → R7, R8 and R9 rise toward `high`.
- Any details or artifact for an internal tool you built → R8 and R1b.
- A sprint board or retro example → R5.
- The hiring manager's name → the scope read and which story to lead with.
- A deeper pass (up to 5 more searches and 2 more fetches) → company funding, leadership and hiring patterns, once search is permitted.

**Questions**

G1 — Did you build or run anything where you decided what got built first, such as an internal tool, process or playbook that other teams adopted? What did you own, how many people used it, and how did you know it worked?

G2 — Did client feedback you collected ever change an endpoint, a doc or a release? What was your part in getting it there?

G3 — On custom builds, did you work in sprints or a backlog with the engineers? What was your role in the cadence?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.