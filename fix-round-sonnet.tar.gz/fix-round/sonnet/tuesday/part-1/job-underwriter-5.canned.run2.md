Checking that the posting and company are real and current, starting with the careers page.
**Yes, it's worth applying, on conditions. Status: `conditional_go`.** The five must-haves (R1, R2, R3, R4, R5) are all `direct` against your background. The conditions are that location, eligibility and pay get confirmed, and that the team shape holds up.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R9 (Remote (US) or Denver office), R10 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R6 (dbt-modelled warehouse in BigQuery) · unclear: R7 (data contracts analysts depend on), R8 (ingestion from app and CRM)

R6 (`medium`) is a Snowflake-to-BigQuery bridge with its limit named; R7, R8 are not spoken to by your background yet and have discovery questions pending; R9, R10 are gates the posting states and your message doesn't settle.

**Opportunity ledger.** Sound, with open questions on team shape. The pay is stated and sits inside the market band (RR1). The scope may be wider than the one-domain norm (RR2), the reporting line is unnamed (RR3), and the equity terms are unstated (RR4). The employer's own pages match the posting (RR5).

- **Hard gates:** none failed; unconfirmed: R9 (Remote (US) or Denver office), R10 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You are US-based or Denver-willing and authorized to work in the US (R9).
  2. The range clears your base-pay floor (R10).
  3. The team shape and your ownership verify in interviews (RR2, RR3).
  4. The BigQuery bridge is framed as adjacent to Snowflake, never as BigQuery experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company about page, fetched via search; these are the company's own figures, not independently confirmed |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD, matches the live careers page |
| Requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; equity size and terms not stated | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Seniority read | Your 6 years sit inside the report's typical 5–8 for "Senior" | `[grounded]` your background and the Datawright report you supplied |
| Scope read | Three named areas (ingestion, modelling, contracts) may be broader than the report's typical one-domain, no-reports remit | `[inferred]` JD scope list against the report's typical scope |
| Market calibration | The posted floor is $3,000 under the report's median ($151,000). The ceiling is $2,500 above the top of its interquartile range ($163,500). The report covers Series B–D companies in general, not this employer (RR1) | `[grounded]` posting and report figures; `[generic]` the report is a pattern, not a claim about Pellucid |
| Unknowns | Hiring manager and team size; equity terms; new role or backfill; posting date | `[grounded]` the posting names no manager; the others are not stated on the fetched page |
| Contradictions | None between your pasted JD and about text and the live pages | `[grounded]` careers page fetched, about page returned by search |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | 6 years stated against 5+. It is a typed self-report, so `medium` is the intake ceiling until something is inspectable | `[grounded]` your background message | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated, with no inspectable artifact yet | `[grounded]` your background message | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | A dbt project of about 180 models on Snowflake, which is a cloud warehouse. Confirmed and specific, limited proof | `[grounded]` your background message | a redacted dbt docs lineage graph would raise this to `high` |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration, with no artifact yet | `[grounded]` your background message | a redacted DAG sample would raise this to `high` |
| R5 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, with ownership stated and no artifact yet | `[grounded]` your background message | a redacted suite config would raise this to `high` |
| R6 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The dbt modelling carries over from Snowflake. The limit is that you have not used BigQuery, and its cost and table-layout model differs from Snowflake's | `[inferred]` adjacency from the Snowflake work; `[generic]` that BigQuery's cost and layout model differs | bridge case in G3 |
| R7 | Data contracts analysts depend on | important | unclear | low | discovery | Your background is silent on contracts. A Great Expectations suite is indirect context, not a stated contract practice | `[inferred]` from the suite you described; `[grounded]` background silent on contracts | Q2 |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Airflow work implies some ingestion, but your sources are unstated | `[inferred]` from the Airflow work; `[grounded]` sources not stated | Q3 |
| R9 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The posting states the terms. You have not said where you are based or whether you are US-authorized, so there is no candidate statement to grade | `[grounded]` JD; your message silent | Q1 |
| R10 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The terms are stated. You have not given a floor, so the fit can't be called | `[grounded]` JD; your message silent | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Data contracts (R7, important) | discovery | Great Expectations suite and daily analyst-facing work are plausible threads, but nothing says a contract existed | The posting names contracts as a core duty, so this decides whether R7 closes | Agreed schemas with analysts; a test suite that blocked bad loads; versioned model interfaces; schema-change notices | A redacted contract doc, a schema-change policy, or suite config | `[grounded]` background silent; `[generic]` that contract practice varies widely by team |
| G2 | App and CRM ingestion (R8, important) | discovery | Airflow orchestration is stated; source systems are not | Ingestion from product and CRM sources is the first-named duty | Loading from a SaaS API or CRM; event or app-database extracts; backfills and late-arriving data | A redacted DAG or source inventory | `[grounded]` background silent on sources |
| G3 | BigQuery (R6, important) | transferability | Dbt modelling on Snowflake carries over. BigQuery is unused | The posting names BigQuery as the warehouse. It's your most likely interview probe | The same modelling patterns, partitioning or clustering choices you made on Snowflake, cost tuning of heavy queries | A small BigQuery project on a public dataset | `[inferred]` bridge from Snowflake; `[generic]` that interviewers probe an unfamiliar warehouse |

The bridge for G3 has three parts. What carries over is the dbt modelling, testing and orchestration work. The limit is that none of it exercised BigQuery's cost model or table layout. The strengthener is a small BigQuery project (W1 below).

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and inside the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is credible for the level and not a seniority-pay mismatch | `[grounded]` posting and report figures; `[generic]` the report is a pattern across Series B–D | Where in the band does an offer for this level usually land? | noted |
| RR2 | Scope may exceed the one-domain norm | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | Ingestion, modelling and contracts together may mean a sole or near-sole engineer. The wording may just be a summary | `[inferred]` JD scope against the report's typical scope, itself `[generic]` | Which of ingestion, warehouse modelling and contracts would this role own end to end, and who owns the rest? | unresolved |
| RR3 | Reporting line and team unnamed | unknown | — | the posting names no hiring manager | Postings often omit the manager. This may be an omission and not a concern | `[generic]` pattern, not a claim about Pellucid | Who would this role report to, and how large is the data team? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Grant size, vesting and strike are not given, so the equity can't be weighed against the cash band | `[inferred]` from the JD's silence | What equity is offered at this level: number of options or percentage, vesting schedule and strike price? | unresolved |
| RR5 | Employer and posting match the description | positive_signal | — | "Series C ($52M, February 2026)" | The company exists as described and the posting is live. The figures are the company's own | `[grounded]` careers page showed "Accepting applications"; about page text matches; both are company-authored | Is this a new role or a backfill, and when did the search open? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the dbt project (about 180 models, Snowflake) and the Great Expectations suite you set up, in your own wording and scope | see R3, R5 | `[grounded]` your background message | pending your approval |
| W1 | Build a small dbt project on a BigQuery public dataset, with one partitioned table and a cost note | see R6, G3 | `[inferred]` strengthener for the R6 limit | pending your approval |
| Q1 | Ask the RR2, RR3 and RR4 questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the pay floor and your location and eligibility before investing in the loop | see R9, R10 | `[grounded]` R9, R10 rows | pending your approval |

If you decide to apply, resume-tailor can turn E1 into an approve-first edit ledger once you share your resume.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Both checked that your pasted text is current and genuine. The role reality contradictions row and RR5 now rest on the live pages, so the employer-not-established entry is not raised. These are the company's own statements, so funding and headcount are not independently confirmed |
| 2. Role-family sweep | skipped | The Datawright report you supplied is in hand and already fixes the market calibration line and RR1, so a further search could change nothing |
| 3. Hiring manager's public footprint | n/a | The posting names no manager, so there was no query to form |

I can save this as `tuesday-dossier.md` if you want to carry it into another session.

**Upgrade menu**

- Your resume, or a prior version, would let me check whether it buries or states R3, R4 and R5, and what it says on R7 and R8.
- A redacted dbt docs lineage graph, Airflow DAG sample or Great Expectations suite config would raise R3, R4 and R5 to `high`.
- Your answer on location, eligibility and pay floor would close R9 and R10.
- Your answers to G1 and G2 would move R7 and R8, and a small BigQuery project would narrow R6's limit.
- The hiring manager's name would sharpen the scope read in role reality and the positioning in the application plan.
- A deeper research pass on Pellucid, covering funding and leadership churn, employee reports and recent news (up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

- Q1 (R9, R10): Are you US-based (or willing to work from Denver) and authorized to work in the US, and what base salary is your floor?
- Q2 (R7): Have you agreed schemas, tests or change rules with the analysts who consume your models, and what did you own in that?
- Q3 (R8): What source systems fed your pipelines, for example SaaS APIs, a CRM or app-database extracts, and which did you build ingestion for?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.