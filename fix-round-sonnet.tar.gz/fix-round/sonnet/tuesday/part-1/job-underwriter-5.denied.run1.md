I'm checking that the posting is live and that the company matches its own "about" page, then I'll write the assessment.
Both page fetches were refused, so none of this has been checked against Pellucid's own site. The assessment runs on what you pasted, and the research table below says what that leaves open.

# Job Underwriting Assessment: Senior Data Engineer at Pellucid Learning

## Decision snapshot

**Yes, worth applying, on conditions: R1 and R2, both hard gates, are unconfirmed, because you haven't told me where you're based or what your pay floor is. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (US remote or Denver location), R2 (Salary $148,000–$166,000 against your floor)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery-modelled warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts analysts depend on)

R8: a credible bridge from Snowflake, with its limit named; R9 and R10: your account says nothing either way, so these are questions, not weaknesses.

**Opportunity ledger.** The stated pay sits across the market median (RR1). The posting names no hiring manager, team shape or first-year outcomes (RR2, RR4), and the employer and live posting went unchecked this session (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (US remote or Denver location), R2 (Salary $148,000–$166,000); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work remotely from the US or from Denver (R1); (2) the $148,000–$166,000 range clears your floor (R2); (3) the BigQuery gap is stated as adjacent, never as BigQuery experience (R8); (4) the team shape and who you report to are confirmed in the loop (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` the about-page text you pasted; not independently fetched |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Requirements stated | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity | `[grounded]` JD |
| Scope read | The posting names three layers (ingestion, warehouse, contracts) and no direct reports. The report's typical scope is one domain's pipelines with no reports, so this role may be broader than typical or may be the usual stack described end to end. The posting doesn't say which. | `[inferred]` posting's three layers set against the report's stated typical scope |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500; "Senior" typically means 5–8 years. The report is the basis, not a search I ran; it is a market band, never this employer's offer. | `[grounded]` Datawright 2026 Pay Report (n=2,310) as sent by your recruiter |
| Unknowns | Hiring manager; team size and whether you'd be the first or only data engineer; first-year outcomes; contract terms; equity details | `[grounded]` JD silence on each |
| Contradictions | None between the JD and the about text as you pasted them. Neither page was fetched, so this is a check of your two excerpts against each other only. | `[grounded]` the two pasted excerpts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or your work authorization. Confidence grades your statement of the constraint, and there is none yet. | `[grounded]` no constraint given | Ask whether this location term is met (question R1) |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given. For scale, the range's low end is $3,000 under the report's median and its top is $2,500 above the report's upper quartile. | `[grounded]` JD range and the report as provided | Ask your floor (question R2) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. Stated and specific, but intake prose is self-report and nothing inspectable is attached. The report's typical "Senior" span is 5–8 years. | `[grounded]` your prose; `[grounded]` the report | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. "Strong" is a judgement that a conversation or exercise would test, and no artifact has been inspected. | `[grounded]` your prose | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. That meets the requirement as the JD words it ("a cloud warehouse"). BigQuery specifically is R8. | `[grounded]` your prose | Offer: a sanitized model-lineage screenshot or project README would raise this to high |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration. | `[grounded]` your prose | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite. Nothing is claimed about dbt tests or other layers, because you didn't mention them. | `[grounded]` your prose | Offer: a sanitized suite config or a check report would raise this to high |
| R8 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The same dbt practice on a different warehouse is the adjacency. The limit: you've never used BigQuery, so nothing about its platform specifics has been exercised. The JD's requirement list says "a cloud warehouse", which is why this row is `important` and not `must_have`. | `[grounded]` your "never used BigQuery" and the JD's wording; `[inferred]` that the dbt practice carries over | See G1 |
| R9 | Ingestion from the app and the CRM | important | unclear | low | discovery | You mentioned Airflow orchestration but nothing about where data came from or how it was ingested. The row stays at low until you say. | `[grounded]` silence in your prose | See G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing in your account touches agreements with downstream consumers. The Great Expectations suite is adjacent evidence but doesn't establish contracts. | `[grounded]` silence in your prose | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Six years of dbt on Snowflake, about 180 models; no BigQuery use | The mandate names BigQuery directly, so expect it to come up in the loop. The bridge is credible but has a limit. | Any BigQuery touch: a migration, a vendor or client share, a side project, a dbt run against a BigQuery target | A small public dbt project on BigQuery, or a README with a lineage graph | `[grounded]` your background; `[generic]` that a named platform in a mandate is usually probed |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Airflow orchestration is stated; sources and ingestion method are not | The mandate lists ingestion first, and a clear answer could move R9 to `direct` | Airflow DAGs pulling from a product database or event stream; CRM API extracts; a load tool you configured or replaced | A DAG diagram, a source inventory, or a pipeline README (sanitized) | `[grounded]` silence on sources; `[generic]` that ingestion work is normally probed in detail |
| G3 | Data contracts (R10, important) | discovery | A Great Expectations suite exists; no consumer-facing agreements are described | The JD names contracts as something analysts depend on, so a concrete example would carry weight | Agreed schemas with analysts; tests enforced at a model boundary others query; a change-notice process for column changes | A sanitized schema agreement, a test config, or a changelog note | `[grounded]` your prose; `[inferred]` that the suite is only adjacent evidence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Stated pay sits at the market median | positive_signal | — | "$148,000–$166,000 plus equity" | The range straddles the report's $151,000 median and its top is past the $163,500 upper quartile, so it doesn't signal a seniority-pay mismatch | `[grounded]` JD range against the report as provided | What is the equity grant, and how is it vested? | noted |
| RR2 | Team shape and reporting line unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the only data engineer, or one of several; no hiring manager is named | `[grounded]` JD silence | Who would I report to, and how many people work on these pipelines today? | unresolved |
| RR3 | Employer and live posting not independently checked | unknown | — | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | Both fetches were refused; the company description rests on pasted excerpts alone | `[grounded]` the refused fetches | Is this role currently open, and is the careers page the same text? | unresolved |
| RR4 | No first-year outcomes or success measures | unknown | — | "Build and run the pipelines…" | A "build and run" mandate with no stated definition of success | `[grounded]` JD silence | What would a successful first year look like for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dbt project (about 180 models, on Snowflake), Airflow and the Great Expectations suite, each in the scope you gave | R3, R5, R6 and R7 are your strongest rows | `[grounded]` your prose | pending your approval |
| P2 | Say the gap plainly rather than let it surface: "I haven't used BigQuery; I built our dbt project on Snowflake." Each clause traces to a sentence you wrote. | R8's limit | `[grounded]` your prose | pending your approval |
| P3 | Build a small dbt-on-BigQuery sample project, described only for what it is, to narrow R8's limit | G1 | `[inferred]` from R8's limit | pending your approval |
| P4 | Ask RR1's, RR2's and RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P5 | Confirm R1 and R2 before investing application effort | Both gates are unconfirmed | `[grounded]` R1, R2 | pending your approval |

## Evidence status

Verified: none yet. Your background claims behind R3, R4, R5, R6 and R7 are self-reported prose and stay unverified until you confirm or attach something.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I tried to fetch the careers page (pellucidlearning.com/careers/senior-data-engineer) and the about page (pellucidlearning.com/about); both were refused. It would have moved the contradictions row, RR3, and whether the posting is live. |
| 2. Role-family sweep | skipped | The pay report you pasted fixes the market calibration line, RR1 and R2's comparison, so a search would change none of them. |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so no query can be formed. A name would sharpen the scope read and P1. |

## Closing

Dossier: I can save all of this as `tuesday-dossier.md` whenever you want it.

**Upgrade menu**

- Your location, work authorization and pay floor: R1 and R2 close, and the decision likely simplifies to `go` or `no_go`.
- A sanitized lineage screenshot or README from the dbt project, or a Great Expectations config: R5 and R7 move toward `high`.
- Any BigQuery touch, or a small sample project: G1's bridge strengthens and R8's limit narrows.
- Your resume: the claims behind R3 to R7 get cross-checked, and a later resume pass for this role is a separate step, resume-tailor.
- The hiring manager's name, once you have it: role reality's scope read and P1 get tuned to that reader.
- Permission to fetch the two pages (or a deeper pass; up to 5 more searches and 2 more fetches): RR3 closes and the posting's liveness is confirmed.

**Questions**

R1 — Are you based in the US (or willing to work from Denver or remotely from the US), and is there anything about location or work authorization that would block this?
R2 — What's your pay floor, and does the $148,000–$166,000 range clear it?
G3 — Have you ever set an agreement with the analysts or teams who query your models, for example agreed schemas, tests enforced at a boundary, or a process for announcing column changes? What did you own, and how did people use it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.