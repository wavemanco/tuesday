I'm checking whether Quartzline exists as the posting describes, and what the market says about PM roles at this level, then I'll write the assessment.
Search was refused, so the Quartzline posting is unchecked and everything below rests on your resume and the pasted JD.

## Decision snapshot

**No, you're not wasting your time applying, but R1a (3+ years in a PM title) is a miss the employer has to be willing to waive. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1b (PM-type work), R2a (Shipped API or platform products) · unclear: R2b (Shipped API or platform products, own-built) · absent: R1a (3+ years PM experience)
- `important` — direct: R4, R8 · unclear: R5 (Launches with sales and support), R6 (Adoption metrics), R7 (Agile delivery)

R1a — the titled years are missing; R1b, R2a — adjacent work with limits named; R3 (`medium`) — fluency is evidenced by your own account.

**Opportunity ledger.** The mandate reads concrete (RR3), but the employer is unverified (RR1), how strictly the PM-years line is applied is unknown (RR2), and pay is not stated (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify — RR1; (2) Quartzline will weigh equivalent product-ownership work without a PM title — R1a, RR2; (3) your work is framed as adjacent and never as a PM title you haven't held — R1b, R2a.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not independently verified |
| Mandate | Own the roadmap for the partner-facing API platform, run partner discovery, write specs, drive two engineering squads, track adoption, coordinate launches | `[grounded]` JD |
| Stated success measures | Adoption metrics are named; no first-year outcomes are stated | `[grounded]` JD |
| Scope read | A mid-level, single-product PM post: two squads and one platform, with 3+ years asked | `[inferred]` from the squad count and the years requirement |
| Market calibration | Not established: the role-family search was refused, so there is no pay band or title norm | `[grounded]` the search call was refused |
| Unknowns | Pay; contract basis; how strictly 3+ years is applied; decision rights over the roadmap beyond "own" | `[grounded]` JD silence |
| Contradictions | None visible within the JD | `[grounded]` JD read; no second source |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, as a titled PM | must_have | absent | none | capability | You said you have never held a PM title, so titled years are not there. A length-of-experience line is not a gate; it is graded on evidence, and the work near it is R1b. Postings often apply such lines literally at the screening stage | `[grounded]` your statement; `[generic]` how such lines are applied | Test the flexibility with the employer (RR2); no wording closes this |
| R1b | Product-manager work: roadmap, specs, delivery with engineers | must_have | adjacent | medium | transferability | Roadmap-input sessions, requirements documents and coordinating engineers and PMs on custom builds carry over. Limit: you fed other people's roadmaps and did not own one or prioritize against competing demands | `[grounded]` CV claims, limited inspectable proof | Offer: a sanitized requirements document or the roadmap-input summary would show the work |
| R2a | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs, so you shipped integrations of a platform. Limit: nothing says you owned the API product's scope, versioning or adoption | `[grounded]` CV | Gap queue G5 |
| R2b | Shipped an API or platform product you built yourself | must_have | unclear | low | discovery | A prior-conversation lead mentions an internal request-triage tool that support agents adopted. It is unconfirmed, and nothing in the CV supports it | `[inferred]` from the memory lead, unconfirmed | Ask G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture across many clients. Confirmed on intake only, so `medium`, and expect a probe | `[grounded]` CV | none |
| R4 | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated your own and clients' engineers and product managers. The sales half of the JD's list is not evidenced; see R5 | `[grounded]` CV | none |
| R5 | Launch coordination with sales and support | important | unclear | low | discovery | The CV is silent on sales or support involvement at go-live | `[grounded]` CV silence | Ask G3 |
| R6 | Define and track adoption metrics | important | unclear | low | discovery | The CV names no adoption or usage measures | `[grounded]` CV silence | Ask G2 |
| R7 | Agile delivery | important | unclear | low | discovery | The CV does not mention agile practice, though custom builds with engineers make it plausible | `[grounded]` CV silence; `[inferred]` plausibility from the custom-build work | Carried; not asked this turn |
| R8 | Discovery with integration partners | important | direct | medium | none | Scoping workshops and roadmap-input sessions with clients map to partner discovery. Clients of your vendor are not the same as an API platform's partners, which is a limit to name | `[grounded]` CV | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product you built and others adopted (R2b, must_have) | discovery | A lead about a triage tool, with nothing confirmed: scope, your role, adopters, outcome | It is the only candidate for a self-owned shipped product, so it could move R2b and strengthen R1b | Deciding what the tool did and for whom; prioritizing requests; tracking usage; iterating after agent feedback | A screenshot, a usage count, a one-page description, an agent quote | `[grounded]` CV silence; `[inferred]` that confirmation would move R2b |
| G2 | Adoption metrics (R6, important) | discovery | No measures of integration success are on the CV | The JD names adoption tracking as a duty | Time-to-go-live per client; integrations completed per quarter; error or support-ticket rates after go-live | A dashboard export or a playbook metric page | `[grounded]` CV silence |
| G3 | Launch work with sales and support (R5, important) | discovery | Go-lives are on the CV; the sales and support handoffs are not | The JD lists launch coordination as a duty | Handoff plans to support after go-live; briefing account teams on a new integration; training agents | A handoff checklist from the playbook | `[grounded]` CV silence |
| G4 | Agile delivery (R7, important) | discovery | Silent on process | A low-effort row to close later | Sprint participation, backlog grooming with squads, UAT inside sprints | A playbook section on delivery cadence | `[grounded]` CV silence |
| G5 | Ownership of API product decisions (R2a, must_have) | transferability | Integration delivery is clear; product-level decisions are not | This is the limit on the adjacency | Escalating client needs that changed the API; prioritizing a feature request; deprecation or versioning discussions | An example of a client request that reached the roadmap | `[inferred]` bridge from integration work; `[generic]` that this is the usual probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "B2B logistics-tech, ~150 people, Series B" | The check could not run, so the entity and the live posting are unconfirmed | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Strictness of the PM-years requirement unknown | unknown | — | "3+ years product management experience (must-have)" | It may be screened literally, or the team may accept equivalent product work | `[generic]` how such lines are applied | Would you consider equivalent product-ownership experience without a PM title, and what would count? | unresolved |
| RR3 | Concrete mandate and measures | positive_signal | — | "define and track adoption metrics" | Scope is specific: one platform, two squads, named metrics | `[grounded]` JD | Which adoption metrics are tracked today? | noted |
| RR4 | Pay not stated | unknown | — | no figure in the posting | The band cannot be set against market without a figure | `[grounded]` JD silence | What salary range is budgeted for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with your 30+ REST API integrations, the integration playbook and the roadmap-input sessions, in your own words and with no PM title claimed | See R1b, R2a, R3 | `[grounded]` CV | `resume_edits_pending_approval` |
| A1 | Ask a Quartzline contact or recruiter whether equivalent work counts for the 3+ years before investing in a full application | See R1a, RR2 | `[generic]` how hiring often works | pending your approval |
| A2 | Also look at roles titled technical product manager, API product owner or similar that do not gate on titled years, if Quartzline says no | Keeps the pivot moving | `[generic]` role-family pattern | pending your approval |
| Q1 | Ask the RR1, RR2 and RR4 questions verbatim at the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a prior-context mention of an internal request-triage tool adopted by support agents, unconfirmed, which prompts G1 and nothing more.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search for Quartzline's careers page was refused. It would have fed role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | One search for platform API PM requirements and pay was refused. It would have fed the market calibration row |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

I can offer to draft `tuesday-dossier.md` from this assessment whenever you want it.

## Upgrade menu

- Search access, so the two refused calls can run → role reality's market calibration row, and RR1 closes or stays open.
- The hiring manager's name → role reality's scope read and which story the plan leads with.
- A sanitized requirements document or roadmap-input summary → R1b toward `high`.
- A reply on G1–G3 → R2b, R6 and R5 can move, and the decision may firm up.
- Your constraints (pay floor, location, schedule) → the hard-gate checks run against Quartzline's terms.

**Questions** (at most three; answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

- G1 — Did you build the request-triage tool support agents used? What did you own, who used it, and what happened after it launched?
- G2 — How did you or your team measure whether a client integration went well, such as time to go-live or post-launch support tickets?
- G3 — At go-live, did you hand off to support or brief sales or account teams, and what did that look like?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.