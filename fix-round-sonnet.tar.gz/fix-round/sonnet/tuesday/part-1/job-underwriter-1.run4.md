I'm checking whether Harborlight Health exists as the posting describes it, and what the market norm is for this role. Then I'll write the assessment.
**Decision snapshot**

**Yes, apply. You're a fit on substance, and the status is `conditional_go`. It isn't a plain `go` because I couldn't verify that Harborlight exists as described (RR1).**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: direct: R7a · adjacent: R6 (Define and maintain the metrics layer) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience, HIPAA)

R6 — metrics-layer ownership not yet stated; R7b, R8 — nothing about clinicians or mentoring in what you gave me; R9 — a credible bridge via your GDPR/CCPA and consent-state work, with limits named.

**Opportunity ledger.** The employer is unverified (RR1), compensation and location are not stated (RR2), and success measures are absent (RR3). The scope is broad for one hire (RR4), while the responsibilities themselves are concrete (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR1; (2) pay, location and remote terms clear your own floor, see RR2; (3) the healthcare bridge is framed as adjacent, never as HIPAA experience, see R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C | `[grounded]` JD header; not independently verified |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker dashboards, partnering with PMs and clinicians, mentoring two juniors | `[grounded]` JD |
| First-year outcomes | Not stated in the posting | `[grounded]` JD silence |
| Scope read | Four jobs in one: metrics governance, experimentation, BI and mentoring. Wide for one hire, though "mentor" is not "manage" | `[inferred]` from the JD's responsibility list |
| Market calibration | Not calibrated: the search was not permitted, so I state no band and make no pay comparison | `[generic]` none run |
| Unknowns | Compensation, location or remote terms, reporting line, whether a metrics layer already exists, experiment volume, clinician access | `[grounded]` JD silence |
| Contradictions | None inside the JD; not checked against the company's careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated against five required. Self-reported with nothing inspected, so `medium` | `[grounded]` your background, prose | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is specific. "Expert" is unprobed, so expect a live SQL exercise | `[grounded]` your background; `[generic]` that analyst loops usually include one | none |
| R3 | Experiment design at scale | must_have | direct | medium | presentation | 30+ tests a year and a pricing test behind an 11% retention lift are specific. No artifact inspected, and "at scale" depends on Harborlight's traffic, which is unknown. Lead with the program you ran | `[grounded]` your background; `[inferred]` that scale will be probed, since Harborlight's traffic is unknown | Offer a sanitized test write-up or experiment-review doc to raise to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | Built the instance from scratch with 40+ governed dashboards. A screenshot or a LookML sample would be the inspectable artifact | `[grounded]` your background | Offer a sanitized dashboard screenshot |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | A monthly exec metrics memo and monthly VP Product presentations. A redacted memo would be the artifact | `[grounded]` your background | Offer a redacted memo |
| R6 | Define and maintain the metrics layer | important | adjacent | medium | discovery | "Governed dashboards" suggests defined metrics, but a semantic or metrics layer is not stated. Taking the lower band and the weaker fit | `[grounded]` your background says governed dashboards, not a metrics layer | See G1 |
| R7a | Partner with product managers | important | direct | medium | none | Monthly presentations to the VP Product, plus a roadmap-influencing pricing test | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | unclear | low | discovery | Nothing in your background touches clinical or domain-expert partners. Leaving the band at `low` until you answer | `[grounded]` your background silence | See G2 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | No mentoring or lead experience stated | `[grounded]` your background silence | See G3 |
| R9 | Healthcare data experience (HIPAA), a plus | preferred | adjacent | medium | transferability | Real privacy work: GDPR/CCPA consumer PII and a consent-state warehouse model. Limit: no PHI handling and no HIPAA | `[grounded]` your background; `[generic]` that healthcare employers weigh HIPAA familiarity | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, important) | discovery | Governed dashboards, but no stated semantic layer or metric-definition ownership | It is a headline responsibility, and a yes would move R6 toward `direct` | LookML or dbt metric definitions you wrote; a metric dictionary; settling a disputed KPI definition across teams | A sanitized metric dictionary or LookML excerpt | `[grounded]` background silence; `[inferred]` that a yes strengthens R6 |
| G2 | Clinician partnership (R7b, important) | discovery | No clinical or domain-expert collaboration stated | The JD names clinicians as partners, and healthcare analysis often needs clinical judgment | Working with ops, support or nutrition staff on metric meaning; a review where a domain expert changed your analysis | A brief or write-up showing the joint decision | `[grounded]` background silence; `[generic]` that clinical input shapes health-product metrics |
| G3 | Mentoring (R8, important) | discovery | No mentoring or lead experience stated | Mentoring two juniors is a named duty | Onboarding analysts, reviewing others' SQL, running office hours, informal coaching | None needed beyond a short description | `[grounded]` background silence |
| G4 | Healthcare data (R9, preferred) | transferability | Consent-state model and GDPR/CCPA handling, with no PHI or HIPAA | Preferred, not required; the limit decides how honestly it's framed | Access controls or de-identification you applied; privacy reviews you passed; a data-sharing agreement you worked within | A sanitized consent-model description | `[grounded]` background; `[inferred]` the limit from the absence of any healthcare mention |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation, location and remote terms unstated | unknown | — | (none: the posting is silent) | The pay may sit below your expectations, or the company may simply not publish it | `[inferred]` from the JD's silence | What is the budgeted salary range, and is the role remote or hybrid? | unresolved |
| RR3 | No success measures or first-year outcomes | unknown | — | "Own product analytics for our care-navigation app" | Accountability may be broad with no agreed definition of done | `[inferred]` from the JD's silence on outcomes | What should the first 90 days and first year deliver? | unresolved |
| RR4 | Four specializations in one senior seat | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker … mentor two junior analysts" | The seat may be underpriced or understaffed for its breadth. Severity is low because the JD names a team of juniors | `[inferred]` from the JD's responsibility list | Who owns the metrics layer today, and what does the analytics team look like? | unresolved |
| RR5 | Concrete responsibilities and named stack | positive_signal | — | "self-serve dashboards in Looker" | The role's tooling and duties are specific | `[grounded]` JD | Which experiments are running or planned right now? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on the company's own careers page before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead positioning with the experimentation program and the pricing test, ahead of dashboards | see R3 | `[grounded]` your background | pending your approval |
| A3 | Frame the healthcare bridge as privacy and consent-model work, explicitly not HIPAA or PHI experience | see R9, G4 | `[grounded]` your background | pending your approval |
| A4 | Ask the questions in RR2, RR3 and RR4 verbatim in the early conversations | the register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Prepare a sanitized artifact for R3 or R4 so the claims can be inspected | see R3, R4 | `[grounded]` R3, R4 rows | pending your approval |

Nothing above is final. It all needs your approval before it goes into any resume or message.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search permission was not granted, so nothing was confirmed. It would have settled RR1 and the organization row |
| 2. Role-family sweep | unavailable | Same refusal. It would have supplied the market calibration line and any pay-mismatch check (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'll offer to put this in a `tuesday-dossier.md` whenever you want one, and I'd suggest that after you've answered some of the questions below.

**Upgrade menu**

- Search permission → RR1 closes or sharpens, plus a market band for the role and a pay comparison against RR2.
- The posting URL or the recruiter's email domain → RR1 can be checked without a search.
- A sanitized test write-up or experiment-review doc → R3 to `high`.
- A sanitized dashboard screenshot or LookML sample → R4 and G1 strengthen.
- A redacted exec memo → R5 to `high`.
- The hiring manager's name → the scope read and which story to lead with.

**Questions**

C1 — What are your non-negotiables for this move (pay floor, location or remote, start date, anything else)? I can't check hard gates until I know them.
G1 — Have you personally written or owned metric definitions in a semantic layer (LookML, dbt or similar), and who signed them off?
G2 — Have you worked directly with domain experts such as clinicians, nutritionists or operations leads, and did they change an analysis or a decision?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.