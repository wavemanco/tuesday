**Decision snapshot**

**Yes, it's worth applying — on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Pay $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R8 — BigQuery is new to you; R9 and R10 — the JD's ingestion and data-contract duties aren't evidenced yet; R1 and R2 — location and pay need your answer.

**Opportunity ledger.** The pay is set against the market report you sent and sits inside its range (RR3). The unknowns are who you'd report to and the team's shape (RR2), the equity terms (RR4), and whether "run" means on-call (RR5). I couldn't check the posting is live (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your answers on R1 and R2 fit the posting's terms; (2) the posting is confirmed live on the company's own careers page (RR1); (3) the recruiter confirms the team and ownership picture (RR2, RR5); (4) R8 is presented as adjacent, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C of $52M in February 2026 | `[grounded]` the about-page text you pasted (not checked live) |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Seniority | The posting asks for 5+ years and the survey's "Senior" means 5–8, so your 6 years sits inside it | `[grounded]` JD and the Datawright report |
| Scope read | The duties span ingestion, warehouse modelling and contracts, which looks broader than the survey's one-domain norm, or a single reporting domain described widely. The JD names no reports | `[inferred]` from the JD's duty list against the survey's typical scope |
| Market calibration | The $148,000–$166,000 range runs from just under the survey median ($151,000) to just above the upper quartile ($163,500). Series C is within the survey's Series B–D group. This is the market's band, never this employer's offer | `[grounded]` JD and Datawright report as provided; `[generic]` what the band implies for this role |
| Unknowns | Hiring manager (none named), team size, equity terms, on-call expectations | `[grounded]` the posting is silent |
| Contradictions | None between the JD text and the about text as pasted. Neither was checked against the live site | `[grounded]` pasted material; live check unavailable |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or what you'll accept. The JD offers two arrangements | `[grounded]` no candidate constraint given | Question R1 below |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given, so I can't say whether the range meets it. The equity terms are not stated | `[grounded]` no candidate constraint given; JD range | Question R2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Your stated 6 years at a B2B payroll company is specific but self-reported with nothing inspectable | `[grounded]` your background as typed | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is a level claim not yet probed | `[grounded]` your background as typed | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models (your approximation). No artifact yet | `[grounded]` your background as typed | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. What you authored versus consumed isn't stated | `[grounded]` your background as typed | Be ready to say what you owned in the DAGs |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your background as typed | none |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The dbt modelling carries over. Limit: you've never used BigQuery, and warehouse-specific cost and layout choices differ between engines | `[grounded]` your Snowflake dbt work and no BigQuery; `[generic]` warehouses differ in those choices | Gap G1 |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background doesn't say what fed your pipelines | `[grounded]` silence in your background | Gap G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Setting up Great Expectations is related but is not stated as contracts with producers or consumers | `[inferred]` from the GE suite as adjacent context | Gap G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake dbt at about 180 models, no BigQuery | It's the named warehouse and your one visible tool gap | A small dbt project run against BigQuery rebuilding a slice of your Snowflake work | A public repo or write-up of that project | `[grounded]` your background; `[generic]` that a work sample is the usual way to narrow a tool gap |
| G2 | App and CRM ingestion (R9, important) | discovery | Nothing says what sources fed your pipelines | It's the first duty the JD lists | Loading product database or event data; syncing a CRM such as Salesforce or HubSpot; vendor file feeds | A pipeline diagram or a sanitized DAG | `[grounded]` silence in your background |
| G3 | Data contracts (R10, important) | discovery | A test suite exists; agreed schemas with producers or consumers aren't mentioned | The JD says analysts depend on contracts | Agreeing column definitions with an analyst team; schema-change alerts; tests that blocked a bad load | A sanitized test list or a change-notice example | `[inferred]` GE adjacency; `[grounded]` JD wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified live | risk_signal | low | "Series C ($52M, February 2026)" | The pasted pages may be stale or incomplete. Nothing in them looks off | `[generic]` pattern that pasted copies can be stale, not a claim about this company | Is this role still open, and who is the hiring manager? | unresolved |
| RR2 | Team and ownership not stated | unknown | — | "Build and run the pipelines" | The role may be a lone engineer across ingestion, modelling and contracts, or part of a team | `[inferred]` from the JD's wide duty list and no named manager | How many data engineers and analysts are on the team, and who owns modelling decisions? | unresolved |
| RR3 | Pay range inside the market range | positive_signal | — | "$148,000–$166,000 plus equity" | The range is competitive for the title and stage | `[grounded]` JD and Datawright report | Is the base range fixed for this level, or is there room in it? | noted |
| RR4 | Equity unspecified | unknown | — | "plus equity" | The grant could be small or standard. The posting doesn't say | `[grounded]` the posting gives no terms | What is the equity grant and its vesting schedule? | unresolved |
| RR5 | "Run" may mean on-call | unknown | — | "Build and run the pipelines" | Operating pipelines may carry out-of-hours duty | `[inferred]` from the verb "run" | Is there an on-call rotation for pipeline failures? | unresolved |

## Application plan

`resume_edits_pending_approval` — E1 and E2 are proposed wording, not applied.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line in your own words: "Built our dbt project on Snowflake, about 180 models". Say Snowflake plainly; never imply BigQuery | see R5, R8 | `[grounded]` your sentence | pending your approval |
| E2 | Resume line: "Set up our Great Expectations test suite" | see R7, R10 | `[grounded]` your sentence | pending your approval |
| W1 | A small dbt-on-BigQuery project as a work sample | see R8, G1 | `[generic]` common way to narrow a tool gap | pending your approval |
| Q1 | Ask the recruiter RR1, RR2, RR4 and RR5 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 1 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Fetches of the careers posting and the about page, and one funding search, were all refused by the host, so nothing was read. It would have checked RR1 and role reality's contradictions row |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market calibration line and RR3, so a further search would have changed nothing |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

Want me to turn this into a `tuesday-dossier.md` you can carry into later steps?

**Upgrade menu**

- Your location and base-pay floor → R1 and R2 close, and the decision likely moves to `go` or `no_go`.
- Web access, or the live careers page text pasted in → RR1 closes. After that, a deeper pass (funding, leadership changes, public reviews; up to 5 more searches and 2 more fetches) is available if you say the word.
- The recruiter's answers on team, equity and on-call → RR2, RR4 and RR5 close.
- A sanitized pipeline diagram or test list → R9 and R10 firm up.
- A small BigQuery dbt repo → R8 narrows.

R1 — Where are you based, and are you willing to work remote (US) or in Denver?
R2 — What is your minimum base salary?
G2 — What data sources fed your pipelines at the payroll company (app database, event streams, a CRM, vendor files), and what did you own in loading them?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.