Loading the research tools is done. Next I'm checking that the posting and company are real and current, then I'll write the assessment.
**Yes, worth applying, on conditions. Status: `conditional_go`.** The reasons are in the fit ledger below, and the conditions are listed under "Conditions for go".

# Job Underwriting: Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R8, R9
- `important`: adjacent: R7 (BigQuery warehouse) · unclear: R10 (App and CRM ingestion), R11 (Data contracts)

R7: a bridge from Snowflake, limit named in the map; R10, R11: what the posting names that your background does not yet show; R3 (`medium`): years self-reported, not yet inspected.

**Opportunity ledger.** Pay and scope are stated openly and the pay sits at or above the market median (RR3). The company's funding and size rest on its own pages (RR1). Team, manager and equity terms are unspecified (RR2, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you are US-based and can work there without sponsorship, or can be in Denver (R1); (2) the range clears your pay floor (R2); (3) BigQuery is presented as adjacent to your Snowflake work, never as experience you have (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` company About page, as you pasted and as found by search; not corroborated by any outside source (RR1) |
| Posting status | Live, marked "Accepting applications", text matching what you pasted | `[grounded]` careers page fetched |
| Mandate | Pipelines behind tutoring-platform reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or Denver | `[grounded]` JD |
| Scope read | The posting spans ingestion, modelling and contracts. The Datawright report describes typical scope at this level as one domain's pipelines with no direct reports, so this may be a broader end-to-end role | `[inferred]` JD scope set against the report's typical scope |
| Market calibration | Datawright 2026 (US, n=2,310), Senior Data Engineer at Series B–D: base median $151,000, interquartile range $139,000–$163,500, "Senior" typically 5–8 years. The posting's range starts just under the median and its top, $166,000, sits above the interquartile range's upper bound. Pellucid's stage and your six years both fall inside the report's cohort. This is the band to expect, not this employer's offer to you | `[grounded]` figures from the report your recruiter sent; `[inferred]` the comparison |
| Unknowns | Hiring manager (not named), team size, equity terms, whether BigQuery is established or being adopted | `[grounded]` JD silent |
| Contradictions | None between the pasted JD and the live careers page | `[grounded]` page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not said where you are or your work authorization, so the gate is not settled. Confidence is `none` because there is no statement of yours to grade | `[grounded]` JD term; no candidate statement | Closing question R1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Pay is stated, but your floor is not given, so whether it clears is not established | `[grounded]` JD term; no candidate statement | Tell me your floor (upgrade menu) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Confirmed prose, no inspectable artifact yet. A years requirement is not a gate | `[grounded]` your background as stated | A CV or LinkedIn dates would raise it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated; no artifact seen | `[grounded]` your background as stated | Optional: a repo or code sample |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models; no project view yet | `[grounded]` your background as stated | Sanitized model lineage screenshot would raise it |
| R6 | A cloud warehouse | must_have | direct | medium | none | The JD asks for "a cloud warehouse"; your stated warehouse is Snowflake, which is one | `[grounded]` your background as stated | none |
| R7 | BigQuery-based dbt warehouse (JD names it in the mandate) | important | adjacent | low | transferability | Snowflake plus dbt is the nearest work. Limit: you have never used BigQuery, so its cost model, partitioning and clustering are untested. Low is the lower of medium for the Snowflake work and none for BigQuery itself | `[grounded]` your stated gap; `[generic]` that dbt skills carry across warehouses while performance tuning differs | Work sample on BigQuery (plan P2) |
| R8 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow stated; no artifact seen | `[grounded]` your background as stated | none |
| R9 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite; coverage and scale unknown | `[grounded]` your background as stated | Optional: a sanitized suite summary |
| R10 | Ingestion from app and CRM | important | unclear | none | discovery | Nothing stated about ingestion sources or tooling | `[grounded]` background silent | Closing question G1 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Great Expectations testing is related, but contracts (agreed schemas and ownership between producers and consumers) are not shown | `[grounded]` GE setup stated; `[generic]` that testing and contracts are distinct practices | Closing question G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | App and CRM ingestion (R10, important) | discovery | Payroll data engineering is stated, but not which source systems fed the warehouse | Ingestion is the first thing the posting's mandate names | Pulling data from a product database or event stream; syncing a CRM such as Salesforce or HubSpot; third-party API loaders; CDC or batch extracts | A pipeline diagram, DAG screenshot or ingestion README | `[grounded]` background silent; `[inferred]` that it is a core part of the mandate from the JD's first-listed responsibility |
| G2 | Data contracts (R11, important) | discovery | A Great Expectations suite exists; no stated agreement with downstream consumers | The mandate names contracts analysts depend on | Agreeing schemas or SLAs with analysts; versioned model interfaces; dbt contracts or tests tied to a consumer; breaking-change process | A contract doc, dbt YAML with contract enforcement, a schema-change policy | `[grounded]` background silent on contracts |
| G3 | BigQuery (R7, important) | transferability | Snowflake and dbt, no BigQuery | The stack is named in the mandate | Not recall-based; a small build closes it | A dbt model run on BigQuery's free sandbox | `[grounded]` your stated gap; `[generic]` that a small hands-on build is the usual way to narrow a warehouse gap |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Company facts rest on its own pages | unknown | — | "Series C ($52M, February 2026)" | The figures may be accurate but were not corroborated by an outside source in one search | `[grounded]` search returned only company-owned pages | Who led the Series C, and how is the data function budgeted within it? | unresolved |
| RR2 | No manager, team size or scope boundary | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Could be one of several data engineers or the sole one; scope looks wider than typical one-domain ownership | `[inferred]` JD scope against the report's typical scope | Who would I report to, and how many people work on data today? | unresolved |
| RR3 | Pay stated and in market range | positive_signal | — | "Salary $148,000–$166,000 plus equity" | No seniority-pay mismatch visible; the range straddles the median | `[grounded]` JD and the report's figures | What decides where in the range an offer lands? | noted |
| RR4 | Equity undefined | unknown | — | "plus equity" | Type, size and vesting are unstated, so total compensation cannot be assessed | `[grounded]` JD silent | What is the equity grant: type, vesting schedule, and typical size for this level? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with "built our dbt project on Snowflake, about 180 models" and "set up our Great Expectations test suite", in your own wording | See R5, R9 | `[grounded]` your sentences | pending your approval |
| P2 | Build a small dbt model on BigQuery's free sandbox as a work sample, and say plainly in the screen that BigQuery is new to you and Snowflake is your warehouse | See R7, G3 | `[grounded]` R7 row | pending your approval |
| P3 | Ask RR1, RR2 and RR4 verbatim in the recruiter screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P4 | Settle R1 and R2 before investing application time | Both gates are unconfirmed | `[grounded]` map | pending your approval |

If you go ahead, resume-tailor can turn P1 into CV edits.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring Denver Series C $52M", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Role reality: the posting is live and matches what you pasted. The funding and size figures stay on company pages only, so RR1 stays unknown |
| 2. Role-family sweep | skipped | The Datawright figures are in hand and fix the market calibration line and the pay comparison in RR3 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

I can save this as `tuesday-dossier.md` if you want it for later steps.

## Upgrade menu

- Your CV or dated role history → R3 to a stronger band, plus CV edits for P1.
- Your location, work authorization and pay floor → R1 and R2 close, and the decision moves to `go` or `no_go`.
- A sanitized ingestion diagram or contract document → R10 and R11 resolve.
- A BigQuery work sample → R7's limit narrows.
- The hiring manager's name → role reality's scope read and which story the plan leads with.
- A deeper pass on Pellucid (funding corroboration, leadership changes, news; up to 5 more searches and 2 more fetches) → RR1 closes. Say the word and it runs.

G1: Which source systems fed your payroll warehouse (product database, events, a CRM, outside APIs), and which parts of those loads did you build yourself?
G2: Have you agreed schemas, SLAs or breaking-change rules with the analysts who used your models, and how were they enforced?
R1: Are you US-based and able to work there without sponsorship, or able to be in Denver?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.