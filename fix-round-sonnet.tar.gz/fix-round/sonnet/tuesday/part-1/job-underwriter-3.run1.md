Posting check for Tomás, Head of Growth at Novaline. The two searches I tried (company check and pay band) were refused, so the employer and market-pay checks below are not established.

## Decision snapshot

**No. R1 and R2, both hard gates, fail, so don't pursue this as posted. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site Austin 5 days a week), R2 ($70–85k base)
- `must_have`: direct: R3, R4, R5 · unclear: R6 (SEO/content)
- `important`: unclear: R7 (Brand, PR, partnerships), R8 (Sales ops), R9 (Team of one)

R3, R4, R5 (`medium` each) — your growth core matches; R1 — Portland remote-only against 5 on-site days in Austin; R2 — even the top of the band is $65k under your floor; R6, R7, R8, R9 — the posting asks for breadth your background doesn't yet show.

**Opportunity ledger.** The role looks over-bundled and thinly resourced (RR3, RR7), with pay and success metrics both soft (RR4, RR6) and always-on language (RR5). The employer is unverified (RR8). RR1 and RR2 are R1 and R2 seen from the role's side. One entry runs the other way: the CEO reporting line (RR9). Your sense that something is off is borne out by RR3–RR7.

- **Hard gates:** failed: R1 (On-site Austin 5 days a week), R2 ($70–85k base against your $150k floor).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the posting's own terms would have to read differently, with a remote-eligible role (R1) and a base at or above $150k (R2). The posting says "no exceptions" on location and states its pay band.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header, claim as stated and unverified (target 1 unavailable) |
| Mandate | Own all revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Resources | Team of one to start; no budget, tooling or hiring plan stated | `[grounded]` JD, for "team of one"; the silence is RR7 |
| Reporting | CEO, dotted line to the board | `[grounded]` JD |
| Working pattern | Evenings and weekends "when it matters"; on-site Austin, 5 days, "no exceptions" | `[grounded]` JD |
| Compensation | $70–85k base plus unquantified equity | `[grounded]` JD |
| Scope read | Seven functions under one title, with one person doing them, reads as several roles folded into one | `[inferred]` from the JD's function list against "team of one" |
| Market calibration | Not established: both searches were refused, so no band is given and the posting's figure is not compared to a market band | `[generic]` none used; upgrade menu |
| Unknowns | Budget, tools, equity size and terms, success metrics, who the team is "to start" | — |
| Contradictions | JD not checked against a careers page (target 1 unavailable) | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin, 5 days a week, "no exceptions" (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint, which is specific and confirmed. Fit fails because the JD rules out any remote arrangement | `[grounded]` JD quote and your statement | None; the terms conflict |
| R2 | Base $70–85k (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. Fit fails because the top of the posted band is below it | `[grounded]` JD quote and your statement | None; the terms conflict |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years in growth, as lead then Head of Growth at two B2C subscription companies. It is self-reported with no artifact, and how many of the 9 years were leadership is not itemized | `[grounded]` your prose background | None for this decision |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid with a budget you controlled, while scaling one company from $8M to $40M ARR over three years. Confirmed prose, no inspectable proof yet | `[grounded]` your prose background | None for this decision |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and are deep in Braze, SQL and GA4. The claim is specific, with no artifact | `[grounded]` your prose background | None for this decision |
| R6 | SEO/content | must_have | unclear | low | discovery | Your background doesn't mention SEO or content ownership, so it is unclear rather than absent | `[grounded]` silence in your background | See G1 |
| R7 | Brand, PR, partnerships | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` silence in your background | See G2 |
| R8 | Sales ops | important | unclear | low | discovery | Not mentioned in your background. A B2B sales motion would be a different kind of work from B2C subscription growth | `[grounded]` silence in your background; `[inferred]` B2B reading of "e-commerce enablement" | See G2 |
| R9 | Operate as a team of one | important | unclear | low | discovery | You built and managed teams of 3–7, so solo execution across seven functions is not shown either way | `[grounded]` your prose background | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | Nothing in your background on SEO or content ownership | A `must_have` row, but both hard gates fail, so no answer moves the decision | Owning organic acquisition, a content programme, or technical SEO work with measured traffic | A traffic or organic-revenue report | `[grounded]` silence; `[generic]` that it can't offset a failed gate |
| G2 | Breadth beyond paid and lifecycle (R7, R8, R9, important) | discovery | Brand, PR, partnerships, sales ops and solo execution are not shown | Rows tiered `important`; none can offset the failed gates | Running a partnership channel, owning a sales-ops or CRM-to-pipeline process, or working as the only growth hire | A partnership agreement, a funnel or pipeline report | `[grounded]` silence; `[generic]` that it can't offset a failed gate |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site rigidity against your remote-only constraint (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | Direct conflict with your stated non-negotiable, however well you fit | `[grounded]` JD quote against your statement | Is any remote or hybrid arrangement possible for this role? | confirmed |
| RR2 | Base pay below your floor (R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The band doesn't reach your floor, and the equity is unquantified | `[grounded]` JD figure against your floor | What is the equity grant, vesting and strike, and is the base band negotiable? | confirmed |
| RR3 | Bundled specializations on one person | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one" | Several full roles folded into one title | `[inferred]` from the function list against the stated headcount | Which of these functions would I own personally, and which get contractors or hires, and when? | unresolved |
| RR4 | Seniority and pay may not match the mandate | risk_signal | medium | "8+ years growth leadership required… $70–85k" | The band may sit below what this seniority commands, with the market band uncalibrated | `[inferred]` from the JD's own terms; `[generic]` that the title may be priced for a junior profile, since the sweep was refused | How was this band set, and what comparable roles anchor it? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Overtime may be routine, not exceptional | `[inferred]` from the JD's phrasing | In the last quarter, how many evenings and weekends did the team work? | unresolved |
| RR6 | Success metrics undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for all revenue without a fixed definition of success | `[inferred]` from the JD's scope against its silence on targets | What revenue or pipeline target would define success at 6 and 12 months? | unresolved |
| RR7 | Budget, tooling and hiring plan unstated | unknown | — | "a team of one to start" | Responsibility may exceed the resources committed | `[inferred]` from the JD's silence | What budget and tooling are committed, and what is the hiring plan? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Not checked because the searches were refused; "profitable since day one" is a claim from the posting alone | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and at what the profitability claim rests on? | unresolved |
| RR9 | Reports to the CEO with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board" | Access to decision-makers is real if the line is honored | `[grounded]` JD states it | How often does this role meet the CEO and the board? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort on this posting as written | R1, R2 | `[grounded]` map rows | pending your approval |
| A2 | If you proceed anyway, ask the verification questions in RR1–RR8 verbatim before investing in a loop | The register doubles as interview prep | `[grounded]` register | pending your approval |

No resume edits are proposed, and none could change the outcome.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A"; the call was refused. It would have fed role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary startup Series A 2026 base compensation"; the call was refused. It would have fed the market calibration row and RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can save this as `tuesday-dossier.md` if you want it for later.

## Upgrade menu

- Search access to the company's site and careers page → RR8 resolves and the contradictions row fills.
- A role-family pay sweep → market calibration fills and RR4 is judged against a band.
- Any SEO, brand, PR or partnerships work with an artifact → G1 and G2 move, which would matter only if the gates changed.
- A deeper research pass on Novaline (funding, leadership churn, candidate reports; up to 5 more searches and 2 more fetches) → run on your say-so, and it can sharpen RR8 and RR5.

No questions this turn: both gates are settled by the posting's own words and yours, so no answer would change the decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.