Working from your pasted documents only: my web lookups weren't permitted, so the employer isn't independently checked.

## Decision snapshot

**Yes, this is worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts analysts depend on)

R8 — a Snowflake-to-BigQuery bridge with its limit named; R9, R10 — your background is silent on these so far.

**Opportunity ledger.** The pay sits at or above the market band you sent (RR3). The hiring manager is unnamed (RR1), the employer is unverified from my side (RR2), and the equity terms (RR4) and the "run" duty (RR5) are unspecified.

- **Hard gates:** none failed; unconfirmed: R1 (Remote or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 confirmed against where you live and your pay floor; (2) RR2 cleared by confirming the posting is live on the company's own careers page; (3) the BigQuery gap (R8) is framed honestly as Snowflake and dbt experience, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted (the company's own words, not independently checked) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Terms | Remote (US) or Denver office; $148,000–$166,000 plus equity | `[grounded]` JD |
| Scope read | One reporting domain's pipeline estate; the JD names no direct reports | `[inferred]` from the JD's mandate and its silence on reports, against the pay report's typical scope |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, interquartile range $139,000–$163,500, typically 5–8 years, one domain's pipelines, no direct reports; a Series C company falls inside that group | `[generic]` the Datawright report you sent (n=2,310); `[grounded]` the JD's figure and the company's stage |
| Unknowns | Hiring manager and team size; equity terms; on-call expectations; whether the posting is live | `[grounded]` the posting names no manager; the rest is not stated in the JD |
| Contradictions | None between the JD and the about text as pasted | `[grounded]` the two pasted texts; neither was read live |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The posting states the term; you haven't said where you live or can work. Not established, not failed | `[grounded]` JD; your message is silent | Closing question R1, R2 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The posting states the range; your pay floor wasn't given. Equity is unquantified (RR4) | `[grounded]` JD; your message is silent | Closing question R1, R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years stated. Prose self-report with no inspectable artifact yet, so `medium`. This is a years requirement, not a gate. Six sits inside the report's typical 5–8 for Senior | `[grounded]` your message; `[generic]` the report's typical span | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. Strength itself isn't evidenced beyond your word | `[grounded]` your message | Offer: a sanitized code or model sample would raise it to `high` |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | A dbt project of about 180 models on Snowflake, which you built. Snowflake is a cloud warehouse, so the requirement is met as written; BigQuery itself is R8 | `[grounded]` your message | Offer: a dbt docs site or repo excerpt would raise it to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named directly | `[grounded]` your message | Offer: a sanitized DAG file would raise it to `high` |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. Confirmed and specific, but nothing inspectable yet | `[grounded]` your message | Offer: Great Expectations data docs or a suite excerpt would raise it to `high` |
| R8 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt modelling carries across warehouses. Limit: you have never used BigQuery, so its platform-specific behaviour and cost model are unexercised | `[grounded]` your message; `[generic]` that warehouses differ in tuning and cost model | See G3 |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background doesn't mention ingestion sources. I'm not assuming Airflow work included it | `[grounded]` background silence | See G1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is indirect context. Nothing says analysts relied on defined schemas or checks | `[grounded]` background silence on contracts | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R9, important) | discovery | Airflow, dbt and testing are covered; where the data came from isn't | The JD lists it first among the responsibilities, and it could move R9 to `direct` | Loading a product database or event stream into the warehouse; syncing a CRM or billing system via API or a managed connector; handling schema changes or late data | A pipeline README, an architecture diagram, or a sanitized DAG | `[grounded]` background silence; `[inferred]` that it's central since the JD names it first |
| G2 | Data contracts (R10, important) | discovery | A test suite exists; no stated consumer-facing agreement | The JD names contracts as something analysts depend on | Agreed column definitions or freshness checks with analysts; alerting when a check failed; a documented schema others built reports on | Great Expectations data docs, dbt model documentation, or a schema agreement | `[grounded]` background silence; `[inferred]` from the JD wording |
| G3 | BigQuery (R8, important) | transferability | Strong dbt on Snowflake; no BigQuery use | The platform is named in the JD; a bridge narrows the likeliest objection | Adjacent: warehouse modelling, partitioning-style tuning and cost control on Snowflake. Limit: BigQuery's own mechanics are unexercised. Strengthener: a small dbt project run on BigQuery | A small public repo of that project | `[inferred]` bridge from your dbt work; `[generic]` that BigQuery is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring manager and team unnamed | unknown | — | "The posting names no hiring manager" | Reporting line and team size are unknown; scope could be narrower or broader than the report's typical one-domain remit | `[grounded]` your note on the posting; `[generic]` the report's typical scope | Who would this role report to, and how many data engineers and analysts are on the team today? | unresolved |
| RR2 | Employer not established from attributable sources | risk_signal | low | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | I couldn't check the company or posting independently; severity is low because the specifics come from its own about page | `[generic]` pattern for companies of this size, not a claim about this one | Is this role currently open, and who would I be interviewing with? | unresolved |
| RR3 | Pay at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The lower bound sits $3,000 below the report's median and the upper bound $2,500 above its 75th percentile, so no seniority-pay mismatch | `[inferred]` JD range against the `[generic]` report band | Is this range the base salary, and where in it would my experience place me? | noted |
| RR4 | Equity unquantified | unknown | — | "plus equity" | The value of the equity can't be set against the band | `[grounded]` JD silence | What equity is offered: instrument, grant size and vesting? | unresolved |
| RR5 | "Run" duty undefined | unknown | — | "Build and run the pipelines" | Running pipelines may carry an on-call or support duty | `[inferred]` from the JD's verb; `[generic]` that production pipeline ownership often includes support | Is there an on-call or pipeline-support rotation, and how often would I be on it? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check R1 and R2 against your own location and floor before spending effort | See R1, R2 | `[grounded]` the rows | pending your approval |
| A2 | Confirm the posting is live on the company's own careers page | See RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Lead with your dbt project (about 180 models, on Snowflake), your Airflow orchestration and your Great Expectations suite; say plainly that BigQuery is new to you | See R5, R6, R7, R8; each clause traces to your own message | `[grounded]` your background | pending your approval |
| A4 | Build a small dbt project run on BigQuery as a work sample | Narrows R8's limit | `[generic]` common way to close a platform gap | pending your approval |
| A5 | Ask RR1, RR3, RR4 and RR5's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A fetch of pellucidlearning.com/careers/senior-data-engineer and a search for the company were both refused, so nothing was used. A result would have moved RR2 and role reality's organization and contradictions rows |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration line, RR3 and the scope read |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form |

I can save this as `tuesday-dossier.md` if you want a portable record.

## Upgrade menu

- Your actual resume, as a document → rows built from prose rise on a real CV. Tailoring it to this role is resume-tailor's job once you decide to apply.
- A sanitized dbt docs site, DAG file or Great Expectations data docs → R4, R5, R6 and R7 can reach `high`.
- Answers to G1 and G2, or the artifacts named there → R9 and R10 close.
- Permission for web search and fetch, or a paste of the live careers page → RR2 clears. A deeper pass (funding, leadership churn, candidate reports; up to 5 more searches and 2 more fetches) would run on the same permission.
- The hiring manager's name from your recruiter → the scope read and which story to lead with.

R1, R2 — Do both of the posting's terms work for you: working remotely from the US or from Denver, and a base of $148,000–$166,000?

G1 — Have you owned ingestion from an application database or a CRM into your warehouse? Which sources, what did you build, and how did you know the loads were correct?

G2 — Have analysts or other teams relied on schemas or checks you defined? What did you own, what happened when they broke, and is there anything showing it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.