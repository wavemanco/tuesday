I've read the posting and the playbook. Now I'm running the company, salary and hiring-manager checks.
# Revenue Operations Lead at Quillfield: should you go for it?

## Decision snapshot

**Yes, apply. It's a stretch on forecast ownership (R6) and billing data (R7), not a mismatch. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3a, R4, R5a · adjacent: R6 (Owning a forecast) · unclear: R3b (At a B2B software company), R5b (Spreadsheet modelling) · absent: R7 (Working with finance on billing data)
- `important` — direct: R8

R6 — forecast ownership is covered by adjacent work only; R7 — no evidence of billing data work; R3b, R5b — settled by a sentence from you.

**Opportunity ledger.** Nothing severe. The posting isn't yet confirmed on Quillfield's own site (RR1), the split of forecast duty with the hiring manager is unclear (RR2), and the option terms are unstated (RR3). The stated salary is a positive signal against the pay band (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol hybrid and the pay band work for you — R1, R2; (2) the forecast split with Tamsin Achebe verifies as workable, and you present your forecast experience as adjacent — R6, RR2; (3) you go in open about billing data and the posting tolerates learning it — R7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025. This matches the posting's "invoicing software company" | `[grounded]` quillfield.co.uk/about |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Terms | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe's public profile lists Head of Revenue Operations at Quillfield, and previously four years as sales operations manager at Corvane Payments. That she is the hiring manager rests on the recruiter's word | `[grounded]` public profile result; `[grounded]` your recruiter's statement |
| Scope read | The Lead likely sits under the Head of Revenue Operations. The posting names no team size, no reports and no first-year outcomes | `[inferred]` from her title against the posting's silence |
| Market calibration | A 2026 UK pay guide puts revenue operations leads in UK B2B software at a median base of £64,200 (interquartile range £57,800–£70,400, n=438). The posted band sits inside that range, near the median. The figure is UK-wide, not Bristol-specific, and it's a market band, not Quillfield's offer | `[generic]` Ledgerline 2026 guide; `[grounded]` posting's figure |
| Unknowns | Team size; forecast split with the Head of RevOps; option terms; first-year outcomes; whether the role is live on Quillfield's own site | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the about page. The careers address I tried returned no page | `[grounded]` fetch result |

## Evidence map

Your background is prose you typed, which stands as self-report, so `medium` is the ceiling on a first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days | hard_gate | unclear | none | hard_gate | The posting states the terms. You haven't said where you're based or whether two office days work, so this is neither met nor failed | `[grounded]` posting; no statement from you | G5 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | The posting states the band. Your floor wasn't given | `[grounded]` posting; no statement from you | G5 |
| R3a | 4+ years in revenue operations, sales operations or similar analytics | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations for the UK team. Specific and plausible, with no inspectable record yet | `[grounded]` your description | A dated role history would raise it |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | You said "B2B payments company". Whether it sold software isn't stated. I took the reading that claims less | `[grounded]` your wording | Tell me what the company sells |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You are Salesforce admin certified. Specific, and a credential record could be inspected | `[grounded]` your description | A credential link would raise it to `high` |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly is stated. Frequency is not depth, hence `medium` | `[grounded]` your description | A sanitised query would raise it |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily is stated. Modelling, as opposed to reports and pivots, is not | `[grounded]` your description | G2 |
| R6 | Experience owning a forecast (run quarterly with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, and finance owned the forecast. The adjacent work is real. Limit: you haven't been accountable for forecast method, accuracy, or committing a number to a CFO | `[grounded]` your statements | G1 |
| R7 | Experience working with finance on billing or revenue data | must_have | absent | none | capability | You've never worked on billing data. The posting asks for it in two places: owning billing data, and working with finance on it | `[grounded]` your statement and posting | Closure path in G3 |
| R8 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them isn't stated | `[grounded]` your description | A sanitised dashboard screenshot would raise it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | Monthly pipeline review with your sales director; finance owned the forecast | The forecast is half of the role's named mandate, so how close your inputs came to it shapes how you pitch | Pipeline coverage or weighted pipeline numbers handed to finance; commit or best-case calls; renewal forecasts; tracking predicted against actual closes | A sanitised pipeline-review deck or a coverage report | `[grounded]` your statements; `[inferred]` that this is the likeliest objection, given the posting names forecast duty |
| G2 | Spreadsheet modelling (R5b, must_have) | discovery | Daily Excel use, with nothing on models | A forecast role leans on modelling | Bookings or renewal scenario models; quota or capacity models; commission calculators | A sanitised model or its structure | `[grounded]` your wording |
| G3 | Finance and billing data (R7, must_have) | capability | No evidence of billing data work, by your own account. Closure path: get working fluency in invoice-to-cash data (how invoices, payments and renewals reach CRM) and carry the gap openly | The posting names this duty twice, so it's the largest gap | None stated | None | `[grounded]` your statement; `[generic]` that invoice-to-cash fluency is the usual first thing to learn here |
| G4 | B2B software employer (R3b, must_have) | discovery | "B2B payments company" without a product description | A literal reading of the requirement could screen on it | What the company sold, and whether the product was software | Company product page | `[grounded]` your wording |
| G5 | Location and pay (R1, R2, hard_gate) | hard_gate | Terms stated by the posting, nothing from you | A failed gate would end this regardless of fit | None | None | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not confirmed on the employer's own site | unknown | — | "Revenue Operations Lead, Quillfield" | The posting may be live under another address, or may be an aggregator copy | `[grounded]` one guessed careers address returned nothing and a careers search found nothing | Is this role live on Quillfield's own careers page, and what is its reference? | unresolved |
| RR2 | Forecast ownership and reporting line unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The Lead may share the forecast with a Head of Revenue Operations, or present it for her | `[inferred]` from the posting's duty against the hiring manager's published title | Who owns the forecast number, and does the Lead present to the CFO directly? How large is the team? | unresolved |
| RR3 | Share option terms unstated | unknown | — | "plus share options" | The grant, vesting and strike price may differ greatly from market norms | `[grounded]` posting names options without terms | What is the option grant, vesting schedule and strike price? | unresolved |
| RR4 | Salary stated and inside the market band | positive_signal | — | "£61,500–£67,000" | The posting is transparent on pay, and the band is near the median in the sweep | `[grounded]` posting; `[generic]` band from the sweep | Where in the band would someone with my background sit? | noted |

## Application plan

Nothing here changes your CV yet. Each block below is a proposal.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the application with your rebuilt pipeline and renewal dashboards and the monthly pipeline review with your sales director, in your own words with no added claims | R8, R6 | `[grounded]` your description | pending your approval |
| A2 | Say plainly that finance owned the forecast. Describe only the forecast inputs you actually supplied, once G1 is answered, and never as owning it | R6 | `[grounded]` your statement | pending your approval |
| A3 | Name billing data as new to you, with a short note on how you'd close it, rather than letting an interviewer find it | R7 | `[grounded]` your statement | pending your approval |
| A4 | Ask the recruiter RR1's question now, and put RR2 and RR3 to Tamsin Achebe verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Stage assumed: evaluating. Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned "About Quillfield" (quillfield.co.uk/about), and "Quillfield careers Revenue Operations Lead", which returned nothing. Fetched quillfield.co.uk/careers, which had no page. Moved: role reality's organization row, which matches the posting. Whether the posting is live was not established, which became RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software UK", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved: role reality's hiring manager and scope rows, and RR2 |

I can save this as `tuesday-dossier.md` if you want to keep it; just say so.

## Upgrade menu

- A dated role history, plus a Salesforce credential link → R3a and R4 toward `high`. A sanitised dashboard screenshot → R8, and a sanitised SQL query → R5a.
- An answer to G1 → R6's bridge sharpens or is confirmed as thin.
- What your employer sold → R3b closes.
- The recruiter confirming the live posting and its reference → RR1 closes. The option terms → RR3 closes.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1 — Thinking of your monthly pipeline review, did any of your numbers (coverage, weighted pipeline, commit or best-case calls, renewal forecasts) feed finance's forecast or get tracked against what actually closed? What exactly was yours?

G5 — Do a Bristol-based hybrid role with two office days and a £61,500–£67,000 band work for you, or is there a limit on either?

G2 — When you say Excel daily, have you built models, such as scenario, quota or capacity models, or has it mostly been reports and pivots?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.