*Searches weren't permitted this session, so this runs on your JD and background only.*

## Decision snapshot

**Yes, apply. You fit the core of the role (R1, R2, R3, R4 and R7 are all `direct`). Status: `conditional_go`.**

**Fit ledger**

- `must_have` — direct: R1, R2, R3, R4, R7 · unclear: R5 (metrics layer)
- `important` — direct: R6a · adjacent: R6b (partner with clinicians) · unclear: R8 (mentor two junior analysts)
- `preferred` — adjacent: R9 (healthcare data experience, HIPAA)

R5 — metrics-layer ownership not yet evidenced; R8 — no mentoring evidence yet; R6b and R9 — adjacent bridges, limits named in the map.

**Opportunity ledger.** Open items are the unchecked employer (RR1), unstated pay (RR2) and a broad duty bundle without stated outcomes (RR3). RR4 runs the other way, because the posting names two juniors to mentor.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) you confirm you defined and maintained shared metric definitions (R5, G1); (2) the employer and live posting verify (RR1); (3) mentoring has a true answer you can give (R8, G2); (4) pay, once known, works for you (RR2)

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C. Not independently checked | `[grounded]` JD header |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians | `[grounded]` JD |
| Scope read | Individual-contributor seat with a mentoring duty. The JD says "mentor", not "manage" | `[inferred]` from the JD's wording |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not calibrated, because the role-family sweep did not run. The posting states no pay, so there is nothing to compare against a band | `[grounded]` JD silent on pay |
| Unknowns | Pay; reporting line; success measures; how much time goes to clinician-facing work; whether the employer and posting are live | `[grounded]` JD silence |
| Contradictions | None visible within the JD. The careers page could not be compared | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics, which is above the minimum. It is self-report with no inspectable artifact | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | You use SQL daily on Snowflake over six years. "Expert" is the employer's word and self-report. Roles like this commonly test SQL live | `[grounded]` your background; `[generic]` screening pattern | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You ran a 30+ tests-a-year program, including the pricing test behind an 11% retention lift, on ~2M subscribers. Whether the app's traffic and clinical constraints will differ is unknown | `[grounded]` your background; `[generic]` health products often add clinical-safety constraints | A sanitized test readout would raise this to `high` |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built Looker from scratch with 40+ governed dashboards. Nothing inspected | `[grounded]` your background | A sanitized dashboard screenshot would raise this to `high` |
| R5 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" and the warehouse consent-state model sit near this. Neither says you defined and maintained shared metric definitions | `[grounded]` background is silent on metric definitions | G1 |
| R6a | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | You present monthly to the VP Product, and the pricing test fed a decision. Day-to-day PM partnership isn't described | `[grounded]` your background | none |
| R6b | Partner with clinicians | important | adjacent | medium | transferability | Adjacent: you translate analysis for exec and product audiences. Limit: nothing shows work with clinical experts, who hold different standards of evidence | `[inferred]` bridge from your exec work; `[generic]` clinicians apply clinical evidence standards | G3 |
| R7 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads | `[grounded]` your background | A sanitized memo would raise this to `high` |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing provided on mentoring. The JD asks for mentorship, not line management | `[grounded]` background silent; JD wording | G2 |
| R9 | Healthcare data experience, HIPAA a plus | preferred | adjacent | medium | transferability | You have handled GDPR/CCPA consumer PII and built the consent-state model. Limit: no health data and no HIPAA-specific practice, and the regimes differ in shape | `[grounded]` your background; `[generic]` HIPAA differs from GDPR/CCPA | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | Governed dashboards and a consent-state model, with no mention of who defined shared metrics | The one `must_have` row below `adjacent`; closing it likely removes the main condition on the decision | Defining retention or conversion once and having every dashboard read it; LookML or semantic-layer modelling; a metric dictionary or change process | A sanitized metric dictionary, a model file excerpt, or an explore screenshot | `[grounded]` background silence; `[inferred]` that resolving it moves the status |
| G2 | Mentoring (R8, important) | discovery | No mention of mentoring or onboarding | The JD lists it as a duty, and interviewers can ask for specifics | Onboarding a new analyst; reviewing a junior's SQL or test designs; running a team analytics review | Any onboarding doc, review template or training material you wrote | `[grounded]` background silence; `[generic]` interviewers probe stated duties |
| G3 | Clinician partnership (R6b, important) | transferability | Exec-facing partnership only | Clinicians are named stakeholders in the JD | A time a domain expert challenged your analysis; legal or compliance partners on consent work | A consent-model design note showing who you worked with | `[inferred]` bridge; limit named in R6b |
| G4 | Healthcare/HIPAA (R9, preferred) | transferability | Adjacent privacy-data work | It is a plus, not a requirement | Consent-state modelling, access controls, de-identification or retention rules | The consent-state model write-up (sanitized) | `[grounded]` your privacy work; `[generic]` regimes differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | low | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Nothing contradicts the posting, but the check could not run this session. Severity stays low for that reason | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be working with? | unresolved |
| RR2 | Pay not stated | unknown | — | No compensation in the posting as given | The range may be withheld or left out of what you pasted | `[inferred]` from the JD's silence | What is the budgeted range for this role? | unresolved |
| RR3 | Broad duty bundle without outcomes | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker, partner with product managers and clinicians … mentor two junior analysts" | Several specialisms plus mentoring in one seat, with no stated success measures, may outrun one person's time | `[inferred]` from the duty list against silence on outcomes and resourcing | What are the top outcomes for this role in year one, and what does the analytics team look like around it? | unresolved |
| RR4 | Named team to mentor | positive_signal | — | "mentor two junior analysts" | A team already exists and the mentoring duty is bounded | `[grounded]` JD | Who do the two juniors report to, and what does mentoring involve day to day? | noted |

## Application plan

Every row is proposed. Nothing is applied until you approve it, and no resume edits are proposed yet.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the experimentation program (30+ A/B tests a year, including the pricing test behind an 11% retention lift) and the Looker build (40+ governed dashboards) | R3, R4 | `[grounded]` your background | pending your approval |
| A2 | Present the consent-state model and GDPR/CCPA PII handling as adjacent privacy work, never as HIPAA experience | R9; HIPAA experience is not evidenced | `[grounded]` your background | pending your approval |
| A3 | Prepare a mentoring answer only after G2 gives a true account; no wording until then | R8 | `[grounded]` R8 row | pending your approval |
| A4 | Take the RR1–RR4 verification questions to the recruiter screen verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Attach a sanitized test readout and a sanitized metrics memo | Would raise R3 and R7 | `[grounded]` R3, R7 rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search sent ("Harborlight Health care navigation app Series C") and refused, because permission was not granted. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | One search sent ("senior product analyst digital health salary range experimentation Looker") and refused. It would have moved market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as `tuesday-dossier.md` if you'd like to keep it. Say so and I'll emit it.

## Upgrade menu

- Search permission → targets 1 and 2 re-run: employer and posting confirmed or not (RR1), a pay band against RR2. A deeper pass (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) is also possible on your say-so.
- The live careers-page link, or the recruiter's email domain → RR1 closes without searching.
- A sanitized test readout → R3 to `high`.
- A sanitized dashboard screenshot → R4 to `high`.
- A sanitized monthly memo → R7 to `high`.
- A metric dictionary or model-file excerpt → R5 resolves (G1).
- Onboarding or review material → R8 moves (G2).
- Your non-negotiables (pay floor, location, work authorization) → the hard-gates line gets real checks.
- The hiring manager's name → role reality's scope read, and which story to lead with.

## Questions

G1 — Have you personally defined and maintained shared metric definitions (in LookML or a semantic layer) that other dashboards and analyses read from? What did you own, and who relied on it?

G2 — Have you mentored or onboarded other analysts, formally or informally? What did you do, for whom, and what happened?

C1 — Do you have non-negotiables for this role, such as a pay floor, remote or on-site, or work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.