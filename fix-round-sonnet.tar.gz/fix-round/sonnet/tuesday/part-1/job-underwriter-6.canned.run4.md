I've read the posting and run three searches (company site, pay band, hiring manager). The assessment follows.

## Decision snapshot

**Yes, worth applying — as long as Bristol two days a week and the pay work for you (R1, R2). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two days a week), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3, R4, R5a, R8 · adjacent: R5b (Spreadsheet modelling), R6 (Owning a forecast) · unclear: R7b (Revenue data with finance) · absent: R7a (Billing data with finance)

R6 — a bridge with its limit named; R7a — absent, no billing work on record; R1, R2 — gates your answers settle.

**Opportunity ledger.** Priced inside the market band and openly stated (RR5), but the scope bundles CRM, billing data, reporting and a CFO forecast into one role (RR1). Share-option terms (RR2), team structure and success measures (RR3), and the live posting on Quillfield's own site (RR4) are unconfirmed.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days a week), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days works for you — R1; (2) £61,500–£67,000 meets your floor — R2; (3) you present the forecast and billing gaps as they are (R6, R7a) and the interviews confirm the team tolerates them — RR1, RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants; founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe is Head of Revenue Operations at Quillfield, previously a sales operations manager at a payments company for four years | `[grounded]` one search result, her public profile; not read in full |
| Reporting line | This role likely sits under her | `[inferred]` from her title against the role's "Lead" title |
| Scope read | One person covers CRM, billing data, reporting and the forecast, with no stated team or outcomes | `[inferred]` from the posting's silence |
| Market calibration | UK B2B software revenue operations lead: median base £64,200, interquartile range £57,800–£70,400. The posted range sits inside it, near the median. This is the market band, never Quillfield's offer | `[generic]` Ledgerline 2026 UK pay guide, n=438; `[grounded]` posting for the range |
| Unknowns | Team size, what "own billing data" involves day to day, option terms, first-year outcomes | — |
| Contradictions | None found between the posting and the company page. The role was not seen on a Quillfield careers page (RR4) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You haven't stated where you are based or what you'll commute, so neither side of the gate is settled | `[grounded]` posting; nothing from you yet | Ask: does two office days in Bristol work? (closing question) |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor given. The range is mid-market, and the options carry no stated terms | `[grounded]` posting; `[generic]` band position | Ask: is this at or above your floor? (closing question) |
| R3 | 4+ years in revenue operations, sales operations or similar analytics at a B2B software company | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team, covers the years and function. Limit: whether a B2B payments company reads as "B2B software" is unconfirmed, and nothing has been inspected | `[grounded]` your background; `[inferred]` that a payments product counts as software | State plainly what the product was |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, with you rebuilding the pipeline and renewal dashboards | `[grounded]` your background, no document inspected | Certification record would raise to high |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly. "Strong" is not evidenced beyond frequency | `[grounded]` your background | A sanitized query or dashboard would raise it |
| R5b | Spreadsheet modelling | must_have | adjacent | low | discovery | Excel daily shows use. Building models, as opposed to reporting in Excel, is not stated | `[grounded]` your background; `[inferred]` that use is not modelling | See G4 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director, which is the input a forecast rests on. Limit: finance owned the company forecast, so you have never owned one or presented it to a CFO | `[grounded]` your own statement | See G2 |
| R7a | Experience working with finance on billing data | must_have | absent | none | capability | You have never worked on billing data. The role also owns it, so this is a duty as well as a requirement | `[grounded]` your own statement; posting says the role owns billing data | See G1 |
| R7b | Experience working with finance on revenue data | must_have | unclear | low | discovery | The posting says "billing or revenue data", so revenue data alone could meet the line. Your renewal dashboards touch revenue figures, but what finance did with them is unknown | `[grounded]` posting wording and your renewal dashboards; `[inferred]` that finance contact existed | Ask the closing question |
| R8 | Build the pipeline and renewal reporting sales and finance run on | must_have | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them is unstated | `[grounded]` your background | Say who used them |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Billing data (R7a, must_have) | capability | No billing work on record | The role owns billing data, so this is a duty from day one | Possibly nothing; closure path is to learn invoice-to-revenue reconciliation before interview, or accept it as a stated risk | None to attach yet | `[grounded]` your statement; `[generic]` that billing logic is learnable but interviewers probe it |
| G2 | Owning a forecast (R6, must_have) | transferability | Monthly pipeline review with the sales director; finance owned the forecast | Running the forecast with the CFO is a named duty | Preparing pipeline inputs for finance; defending a commit or coverage number in review; reconciling pipeline to booked revenue | A sanitized pipeline-review deck or coverage model | `[grounded]` your statement; `[generic]` that forecast ownership gets probed |
| G3 | Revenue data with finance (R7b, must_have) | discovery | Renewal dashboards; finance contact unknown | Could convert the unclear R7b to direct | Renewal or ARR figures finance reviewed; month-end reconciliations; a number finance corrected | A renewal dashboard screenshot with figures removed | `[grounded]` your renewal dashboards; `[inferred]` that finance contact existed |
| G4 | Spreadsheet modelling (R5b, must_have) | discovery | Daily Excel use, no model described | The forecast runs on spreadsheet models | A scenario or coverage model you built; a renewal forecast sheet | A sanitized model | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Several jobs bundled into one title | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting… run the quarterly revenue forecast with the CFO" | One person may carry admin, billing data, reporting and forecasting with no support. At a 96-person company this may simply be a small-company shape, so severity stays low | `[inferred]` from the posting's scope against its silence on team | What support does this role have, and who owns day-to-day CRM admin? | unresolved |
| RR2 | Share options with no terms | unknown | — | "plus share options" | The value of the options is unknowable from the posting. Options at a Series A company are common and uncertain | `[generic]` pattern for venture-backed companies, not a claim about Quillfield | What is the option grant for this level, and what are the vesting and strike terms? | unresolved |
| RR3 | No first-year outcomes or team structure stated | unknown | — | Posting lists duties, no outcomes | Success may be undefined | `[inferred]` from the posting's silence | What would success look like at twelve months, and who reports into or alongside this role? | unresolved |
| RR4 | Posting not seen on Quillfield's own careers page | unknown | — | Hosted on a job board | The role is probably live, but it was not confirmed on the company's own site | `[grounded]` company page found, role not seen there | Can you confirm the role is live, and who the interview panel will be? | unresolved |
| RR5 | Pay stated and within market | positive_signal | — | "£61,500–£67,000" | Transparent, credible pay for the title | `[grounded]` posting; `[generic]` band | Does the range have headroom for strong experience? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with Salesforce admin certification and the rebuilt pipeline and renewal dashboards | see R4, R8 | `[grounded]` your background | pending your approval |
| A2 | Describe the forecast as it was: you run the monthly pipeline review with the sales director, and finance owned the company forecast | see R6; never write ownership you don't hold | `[grounded]` your statement | pending your approval |
| A3 | State plainly that you haven't worked on billing data, and say how you'd close that | see R7a | `[grounded]` your statement | pending your approval |
| A4 | Optional work sample: a small spreadsheet bridge from pipeline to forecast on invented data | see R5b, R6 | `[generic]` that a sample narrows a transferability gap | pending your approval |
| A5 | Lead with sales-operations and pipeline-review work for this hiring manager, since her own path started in sales operations | see Role reality, hiring manager | `[grounded]` her public profile; `[inferred]` that it reads familiar | pending your approval |
| A6 | Ask the verification questions of RR1 to RR5 verbatim in interviews | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Revenue Operations Lead"; result "About Quillfield" (quillfield.co.uk/about). Role reality's organization row. No Quillfield careers page for the role was returned, which is RR4 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B SaaS Bristol"; result "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only. Role reality's hiring-manager and reporting-line rows, and A5 |

## Closing

If you'd like, I can save this as `tuesday-dossier.md` so you can carry it into later turns.

**Upgrade menu**
- Your answers on R1 and R2 → both gates settle, and the decision likely becomes `go` or `no_go`.
- An answer on revenue data with finance (R7b) → could move it to direct.
- A sanitized pipeline-review deck or coverage model → R6 and R5b strengthen.
- A sanitized dashboard screenshot or your Salesforce certification record → R4 and R8 toward `high`.
- A link to the role on Quillfield's careers page → RR4 closes.
- A deeper research pass on Quillfield (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

R1 — Does two days a week in a Bristol office work for you?

R2 — Is £61,500–£67,000 at or above your pay floor?

R7b — Have you built or checked any revenue or renewal figures that finance used or signed off, and what did you own versus what finance did?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.