**Yes, apply, but check the working pattern first.** Status: `conditional_go`. You fit every must-have: R2, R3, R4, R5, R6 and R7 are all `direct`. The one row that could change the answer is R1. The JD you have says fully remote, but Brindlemoor's own careers page says Leeds office four days a week.

I couldn't confirm that the page you saw is the same one I found.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK) working pattern)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — adjacent: R8 (Recommendations to underwriting and product)
- `preferred` — direct: R9; absent: R10 (Pet-insurance domain experience)

R1 — the one row that can flip the answer; R6 (`medium`) — monitoring not yet evidenced; R8 — product-side recommendations not yet evidenced; R10 — pet domain is new to you.

**Opportunity ledger.** The role is clearly owned and reports to the Director of Pricing (RR3). The working pattern conflicts between your posting and the employer's own page (RR1). The salary (RR2) and the first-year outcomes (RR4) are not stated.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK) working pattern); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is acceptable to you — R1, RR1; (2) the salary clears your floor — RR2; (3) the motor-to-pet bridge is framed as adjacent, never as pet-insurance experience — R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; a careers page lists this role and is live | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing | `[grounded]` careers page fetched |
| People management | The JD lists no line-management duty, so your having managed no one is not a requirement gap | `[grounded]` JD text as provided |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week". The two conflict and I'm not resolving it for you (RR1) | `[grounded]` JD and careers page fetched |
| Compensation | Not stated in the JD. Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. This is a market band, never this employer's offer (RR2) | `[generic]` 2026 pay survey, n=612; `[grounded]` JD silence |
| Hiring manager | Odile Varga, Director of Pricing. Spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors", on monitoring rating models in small books). Previously head of pricing analytics at Calloway Re for six years | `[grounded]` search-result snippet; page not fetched |
| Scope read | A single-product analytics ownership role, with no team mentioned | `[inferred]` from the JD's "own", against its silence on staff |
| First-year outcomes | Not stated (RR4) | `[grounded]` JD silence |
| Contradictions | Working pattern, above | `[grounded]` JD against careers page |

## Evidence map

Your background was typed into the chat, so it counts as self-report. That caps every row at `medium` until you share something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) working pattern | hard_gate | unclear | none | hard_gate | The JD says remote and the careers page says Leeds four days a week. You stated no location or remote constraint, so no band can be earned for your side | `[grounded]` JD and careers page | Ask whether Leeds four days a week is workable (question 1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years at a UK motor insurer, two as senior analyst; specific, but self-report | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated; no inspectable artifact | `[grounded]` your background | A sanitized query or notebook would raise it to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | A sanitized model spec or documentation would raise it to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD says "underwriting or actuarial", so underwriting meets it | `[grounded]` your background | A sanitized review deck would raise it to high |
| R6 | Build and monitor rating models | must_have | direct | medium | discovery | You built and maintained the model. Whether you ran ongoing monitoring (drift, actual-versus-expected, triggers) isn't stated, and I take the lower reading | `[grounded]` your background; monitoring not stated | G1 |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests with underwriting last year. Expect an interviewer to probe which parts you designed and which you executed | `[grounded]` your background | none |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | discovery | The underwriting side is evidenced through the price tests and the quarterly review. Recommendations to a product team aren't stated | `[grounded]` your background; product side silent | G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain (inferred from the product) | preferred | absent | none | capability | You've said you've never worked on pet insurance. The JD asks only for insurance experience as a plus, so this is a domain bridge, not a stated requirement | `[inferred]` from the product named in the JD; `[grounded]` your statement | Carry as a minor risk; frame as adjacent (plan row P2) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R6, must_have) | discovery | "Built and maintained" the young-driver GLM, but no stated monitoring cadence, metrics or triggers | The hiring manager's public talk is about monitoring rating models in small books, so this is where the conversation is likely to go | Actual-versus-expected tracking, drift checks, a periodic model review, a dashboard others used, a retrain decision you made | A monitoring dashboard screenshot (sanitized), a model-review note, a retrain memo | `[grounded]` your background silent on monitoring; `[inferred]` that the talk topic makes it salient |
| G2 | Recommendations to product (R8, important) | discovery | Underwriting-facing results are evidenced; product-facing ones aren't | The JD names both audiences | A test result that changed a rate, a product feature, or a segment decision; a write-up that went beyond underwriting | A sanitized test readout or recommendation memo | `[grounded]` your background silent on product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working-pattern contradiction (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The posting you have may be an older or different version than the employer's page. Severity is the lower of two readings because your own constraint isn't known | `[generic]` pattern of copies drifting from the source; `[grounded]` the discrepancy | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | JD gives no figure | The figure may sit anywhere in the market band or outside it; nothing here says which | `[inferred]` from JD silence, against the `[generic]` survey band | What is the salary range for this role? | unresolved |
| RR3 | Ownership and reporting line stated | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | Scope and reporting line are concrete | `[grounded]` careers page fetched | Which decisions does this role make, and which does the Director of Pricing make? | noted |
| RR4 | First-year outcomes not stated | unknown | — | JD lists duties, no outcomes | Success may not be defined yet | `[inferred]` from the JD's duty list against its silence on outcomes | What would a good first year look like for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the working pattern with the recruiter or Odile Varga's team before investing in the application | R1, RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with the GLM rating model you built and maintained for the young-driver book and the 14 price tests you ran with underwriting last year, in your own wording, with the quarterly review you present to the head of underwriting | R4, R6, R7, R5 | `[grounded]` your background | pending your approval |
| P2 | Present the motor-to-pet move as an adjacent bridge, and say plainly you have not worked on pet insurance. Expect a probe on how the rating factors and claims drivers differ | R10 | `[generic]` interview pattern for a domain change | pending your approval |
| P3 | Raise model monitoring only after you've settled what you actually did (G1), since the hiring manager has spoken publicly on it | G1 | `[grounded]` the talk, per the snippet | pending your approval |
| Q1 | Put the verification questions in RR1, RR2, RR3 and RR4 to the employer verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirms the employer and a live role, and it surfaced the working-pattern contradiction (R1, RR1) |
| 2. Role-family sweep | yes | Searched "Senior pricing analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read from its snippet only. It moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read from its snippet only. It moved the hiring-manager row and plan rows P1 and P3 |

I can offer one further layer of research, but only once, and it runs only if you say yes: up to 5 more searches and 2 more fetches on funding, leadership changes and recent news. I'd offer it only if the working pattern checks out.

I can save all of this as `tuesday-dossier.md` if you want a file to carry into later steps.

**Upgrade menu**

- Your location or remote requirement and your pay floor → R1 and RR2 resolve against it, and the decision likely settles to `go` or `no_go`.
- A sanitized model spec, query or notebook, or review deck → R3, R4 and R5 can rise from `medium` to `high`.
- A sanitized monitoring dashboard or model-review note → R6 and G1 close.
- A sanitized test readout or recommendation memo that reached product → R8 and G2 close.

**Questions**

1. R1 — Does working from the Leeds office four days a week work for you, or do you need to be fully remote?
2. G1 — Did you run ongoing monitoring on the young-driver GLM (actual versus expected, drift checks, retrain triggers)? If so, what did you personally do and what did it change?
3. G2 — Has a price-test result of yours gone to a product team, as opposed to underwriting? What did you recommend and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.