Checking that the Pellucid posting is live and the company matches its description, then I'll write the assessment.
**Yes, it's worth applying, Ines. Status: `conditional_go`.** R3, R4, R5, R6 and R7, the `must_have` rows, all land `direct`. The one real gap is BigQuery (R8), a credible bridge from Snowflake and not a blocker. The conditions are that your location, authorization and pay floor check out against R1 and R2, which you haven't told me yet.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (dbt-modelled warehouse in BigQuery); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R8 is a credible bridge with its limit named; R9, R10 are unclear because the background you gave me doesn't mention them.

**Opportunity ledger.** The pay range sits on the market median (RR1), the posting is live and matches the company's own pages (RR5), and the scope, team size and equity terms are not stated (RR2, RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 confirmed against your location, authorization and pay floor; (2) the BigQuery bridge (R8) framed honestly as adjacent, never as BigQuery experience; (3) scope and team size verified in interviews (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched via search result; the funding and headcount figures are the company's own claims and are not independently corroborated |
| Mandate | Pipelines behind tutoring-platform reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` posting |
| Seniority | 5+ years required; your 6 years sits inside the report's typical 5–8 years for "Senior" | `[grounded]` posting and your background, against the pay report's stated range |
| Location | Remote (US) or Denver office | `[grounded]` posting |
| Scope read | The posting spans ingestion, warehouse and contracts end to end. That may be broader than the report's typical single-domain ownership with no direct reports, but the posting is silent on team size, reports and domain count | `[inferred]` from the posting's three named responsibilities against the report's typical scope |
| Market calibration | Posting range $148,000–$166,000 against the report's base median $151,000 and interquartile range $139,000–$163,500. The bottom is $3,000 under the median and the top is $2,500 over the 75th percentile, so the range sits around the median with a high ceiling | `[grounded]` Datawright 2026 report (n=2,310, Series B–D, as sent by your recruiter; I haven't seen the report itself); `[inferred]` the comparison |
| Unknowns | Hiring manager, team size and structure, equity amount and terms, whether the role manages anyone | `[grounded]` posting is silent on each |
| Contradictions | None between the posting you pasted and the live careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization weren't given, so the gate can't be settled. Confidence is `none` because there's no statement of your constraint to grade | `[grounded]` posting; no candidate constraint given | Asked in question R1/R2 below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given. The range is stated, so only your floor is missing. Equity terms are unstated | `[grounded]` posting; no candidate constraint given | Asked in question R1/R2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, self-reported, with no inspectable artifact yet. `medium` is the intake ceiling | `[grounded]` your background, prose | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily, self-reported. Expect a technical screen to probe depth | `[grounded]` your background; `[generic]` that screens for this title test both | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | Built the dbt project, about 180 models, on Snowflake (a cloud warehouse). The posting says "a cloud warehouse", so Snowflake meets it; BigQuery is handled in R8 | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named directly in your background | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite, so the activity is yours. Confirmed scope is thin | `[grounded]` your background | none |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Carries over: dbt modelling in a cloud warehouse. Limit: you have not used BigQuery, so its cost model, partitioning and clustering are untested by your work. Strengthener: a small personal dbt-on-BigQuery project | `[grounded]` your background and your statement of no BigQuery use; `[generic]` that BigQuery-specific tuning is usually what a screen probes | Bridge case; the optional project is below |
| R9 | Ingestion from the app and the CRM | important | unclear | low | discovery | Your background doesn't say what sources you ingested from, so nothing confirms or rules this out | `[grounded]` background silent on sources | Asked as G1 below |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations work is nearby, but a test suite and a contract with downstream analysts are different things, and I have no evidence of the second | `[grounded]` background silent on contracts | Asked as G2 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R9, important) | discovery | Nothing on the sources you ingested from or how | One of the three named responsibilities, so a clear answer firms up the fit | Loading from a product database or event stream; syncing a CRM such as Salesforce or HubSpot; building or maintaining connectors | A pipeline diagram, DAG listing or README (sanitized) | `[grounded]` background silent; `[inferred]` that a payroll company would have had app and CRM-type sources, which is not a claim about you |
| G2 | Data contracts (R10, important) | discovery | The Great Expectations suite exists; no evidence of agreed schemas or SLAs with analysts | The posting names contracts as a core deliverable | Schema agreements with analyst teams; alerts that notified downstream owners; versioned model interfaces | A contract doc, schema-change policy or dbt model contracts config | `[grounded]` background silent; `[generic]` that interviewers for this role ask how you handled breaking changes |
| G3 | BigQuery (R8, important) | transferability | Snowflake and dbt carry over; BigQuery itself does not | The only requirement where you have no direct tool match | A small public dbt project on BigQuery's free tier, or a short write-up of how Snowflake concepts map to BigQuery's | A repo link | `[grounded]` your statement; `[inferred]` that a small project would narrow the limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted range centred on market median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The pay is stated and in line with the market for the title | `[grounded]` posting and Datawright report; `[inferred]` comparison | Where in the range would someone with my background land? | noted |
| RR2 | Scope and team size unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may cover three areas alone, which is broader than the report's typical one-domain scope | `[inferred]` from the posting's responsibilities against the report's typical scope | How many data engineers are on the team, and who owns ingestion today versus modelling? | unresolved |
| RR3 | Equity unspecified | unknown | — | "plus equity" | The equity may be material or token; the posting gives no amount or terms | `[grounded]` posting says "plus equity" and nothing more | What is the equity grant for this level, and what are the vesting and strike terms? | unresolved |
| RR4 | No hiring manager named | unknown | — | The posting names no hiring manager | The posting may be a pipeline hire or a pooled req | `[grounded]` posting names no one | Who would I report to, and who would I interview with? | unresolved |
| RR5 | Employer attributed and posting live | positive_signal | — | "Accepting applications" | The posting is current and matches the company's own description | `[grounded]` careers page fetched; About page returned by search | Which team does this role sit in, and is the hire to replace someone or to grow the team? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm remote or Denver eligibility and your pay floor before spending effort | see R1, R2 | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Optional: a small dbt-on-BigQuery project to narrow the R8 limit | see R8, G3 | `[inferred]` bridge | pending your approval |
| A3 | Ask RR2, RR3 and RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Resume edits are `resume_edits_pending_approval`; none are proposed yet because I haven't seen your CV.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer); searched "Pellucid Learning online tutoring Denver Series C 2026", which returned "About Pellucid Learning" (pellucidlearning.com/about). Role reality: the contradictions row (none) and RR5. The funding and headcount figures are the company's own claims, not corroborated elsewhere |
| 2. Role-family sweep | skipped | The Datawright report you provided already fixes the market calibration line and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

## Closing

I can write this up as `tuesday-dossier.md` if you want a file to carry into other steps.

**Upgrade menu**

- Your location, work authorization and pay floor → R1 and R2 settle, and the decision likely moves to `go` or `no_go`.
- Your CV → R3 to R7 firm up against actual wording, and I can propose resume edits.
- An inspectable artifact (a repo, DAG listing, dbt docs page or contract doc, sanitized) → R5, R6, R7 or R10 can rise toward `high`.
- A hiring manager's name → role reality's scope read and who to lead with in the application plan.
- A deeper research pass on Pellucid (funding, leadership changes, public employee reports; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

- R1/R2 — Where are you based, are you authorized to work in the US without sponsorship, and what is the lowest base salary you'd accept?
- G1 — What source systems fed your pipelines, and did you ingest from a product database or CRM?
- G2 — Did you agree schemas, freshness or breaking-change rules with the analysts who used your models, and what happened when something broke?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.