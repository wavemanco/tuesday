I've read the playbook and I'm now running the three research checks it calls for: Brindlemoor itself, pay norms for this role, and Odile Varga's public professional background.
The careers page snippet says Leeds office four days a week, which contradicts the JD's "fully remote". I'm fetching the page to confirm.
**Probably yes, but confirm the location first. R1 (fully remote, UK), a hard gate, is unconfirmed because the JD and Brindlemoor's own careers page disagree. Status: `hold_pending_answers`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — direct: R8a · unclear: R8b (Recommendations for product)
- `preferred` — direct: R9

What matters: R1 — the JD says fully remote and the careers page says Leeds four days a week; R8b — no evidence yet of recommendations that reached product; R9 — your insurance experience is motor, and the JD asks for insurance, not pet.

**Opportunity ledger.** The role has a clear remit and a reporting line to a named, pricing-experienced director (RR3). Its terms are shaky: location contradicts itself (RR1), salary is withheld (RR2), and team and decision rights are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** two answers decide it.
  - Brindlemoor's own answer on which location term is true (RR1).
  - Whether four days a week in Leeds works for you (R1).
  - If either is acceptable to you, this becomes `go` or `conditional_go`. If fully remote is essential and the office requirement stands, it becomes `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, a pet-insurance insurtech; the role is live and accepting applications on its own careers site | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing (Odile Varga) | `[grounded]` JD and careers page |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both sources |
| People management | The JD does not ask for it | `[grounded]` JD silent |
| Hiring manager's public footprint | 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books; previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result for her profile page (snippet only; I haven't read the talk) |
| Scope read | Model monitoring appears in both the JD's "build and monitor" and her talk's subject, so it is likely a live priority | `[inferred]` from the JD wording against the talk title |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. The JD states no salary, so this is the band to expect, never Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 survey (snippet only); `[grounded]` JD for the missing figure |
| Unknowns | Salary; true location terms; team size and decision rights; first-year outcomes | `[grounded]` JD silent on each |
| Contradictions | JD says fully remote; careers page says Leeds four days a week | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have stated no location constraint, so confidence has nothing to grade. Fit is unclear because the two Brindlemoor sources conflict | `[grounded]` JD and careers page | Closing question R1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer, two as senior analyst. Self-reported, nothing inspected yet | `[grounded]` your background as stated | Raise with the artifacts in the upgrade menu |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported. No sample or repository seen | `[grounded]` your background as stated | An anonymised code or query sample would raise it |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Confirmed and specific, no inspectable proof yet: expect a probe on factor selection and diagnostics | `[grounded]` your background as stated | A sanitised model-documentation extract would raise it |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers building. Monitoring is implied by maintenance but not stated, so any monitoring language must stay within what you did | `[grounded]` your background as stated | Confirm what monitoring you ran (plan row E2) |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests with underwriting last year. Ownership of design (hypothesis, split, sample size) is not stated: name that caveat wherever this is used | `[grounded]` your background as stated | An anonymised test design note and read-out would raise it |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Confirmed, nothing inspected | `[grounded]` your background as stated | A deck excerpt would raise it |
| R8a | Recommendations for underwriting | important | direct | medium | none | Your tests were run with underwriting and your review goes to its head. That a recommendation followed is implied, not stated | `[inferred]` from the tests and review you described | Fold into the plan's lead bullet (E1) |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing you described touches product. Whether product teams are more central at a single-product insurtech than at a motor insurer is a pattern, not a fact about Brindlemoor | `[grounded]` your background silent; `[generic]` the product-team point | Closing question G1 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance meets the JD's wording. It does not ask for pet, and you have none | `[grounded]` JD wording and your background | Frame pet honestly as new (plan row A2) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Recommendations for product (R8b, important) | discovery | Your underwriting-facing work is clear. Nothing yet shows a result that shaped a product decision | The role names product as a second audience, and this is the only row where the evidence is thin | A test result that changed a cover, an excess or a bundling option; a rating-factor change taken to a product owner; a pricing review item that led to a product change | A review-pack slide, a decision note, an email thread (sanitised) | `[grounded]` background silent on product; `[generic]` that single-product insurers lean on pricing for product calls |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location terms contradict each other | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The JD may be stale or aggregated, or the careers page may be out of date. Medium rather than high because the cause is unknown and one answer resolves it | `[inferred]` from the two sources disagreeing | Is this role fully remote, or office-based in Leeds four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | JD states no salary | The offer may sit inside or outside the market band in role reality, or the company may not publish salaries | `[inferred]` from the missing figure against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Named hiring manager with a pricing background and a clear remit | positive_signal | — | "reports to the Director of Pricing" | A pricing specialist as manager makes the work easier to scope and read | `[grounded]` careers page and her public profile (snippet) | What would success in this role look like at six months? | noted |
| RR4 | Ownership of pricing analytics, team and decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the only analyst or one of several, with recommendations ending at the Director | `[inferred]` from "own" against the JD's silence on team and authority | How big is the pricing team, and which rating or price changes does this role decide versus recommend? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the young-driver GLM model and the 14 price tests, worded as "ran" unless you confirm you designed them | see R4, R6 | `[grounded]` your background | pending your approval |
| E2 | Add monitoring of the rating model only in terms you can back with what you actually did | see R5 | `[grounded]` R5 row | pending your approval |
| A1 | Ask the recruiter which location term is correct before investing in the process | see RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Frame pet insurance as new: transferable pricing skills, stated honestly, with no implied pet experience | see R9 | `[grounded]` R9 row | pending your approval |
| A3 | Read what is published of Odile Varga's small-books monitoring talk before any conversation. I have seen only its title | see Role reality | `[grounded]` search result | pending your approval |
| Q1 | Ask the register questions of RR1, RR2 and RR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Role reality's working-pattern and contradictions rows and RR1: the employer and posting are real and live, and the location term conflicts |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary remote GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), snippet only. Market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. Role reality's scope-read row and plan row A3 |

I can turn this into `tuesday-dossier.md` if you want a saved record, with no obligation.

**Upgrade menu**
- A pay floor and any other non-negotiables (location, hours) → R1 and RR2 are settled against your terms rather than left unknown.
- A sanitised extract of the GLM model documentation (factor relativities and diagnostics) → R4 can move to `high`.
- An anonymised price-test design note and read-out → R6 can move to `high`, and it settles whether you designed the tests.
- An excerpt of the quarterly pricing review deck → R7 can move to `high`.
- A product-facing decision note → G1 and R8b close.
- A deeper research pass on Brindlemoor (funding, leadership changes, candidate and employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**
- R1 — Would Leeds four days a week be workable for you, or is fully remote essential? If it's essential, I'd confirm the true term with Brindlemoor before you invest in applying.
- G1 — Has a price-test result or a rating change of yours ever shaped a product decision (a cover, an excess, a bundle)? What did you own, who was involved, and what happened?
- RR2 — What is your pay floor, and is there any other term you would not bend on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.