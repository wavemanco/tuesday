**Yes, apply. This is a conditional go (`conditional_go`), and the conditions are below.** Nothing fails outright. R1 and R2, the two hard gates, are still unconfirmed. Two must-haves, R6 and R7, are stretches, and you've told me billing data is new to you (R8).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R4, R5a · adjacent: R3 (4+ years at a B2B software company), R5b (spreadsheet modelling), R6 (experience owning a forecast) · unclear: R7 (working with finance on billing or revenue data)
- `important` — direct: R9 · absent: R8 (Own CRM and billing data)

R6 — adjacent, since finance owned the forecast, not you; R7 — unclear, it rests on whether your renewal reporting involved finance; R8 — billing data is new ground; R1, R2 — gates your answer settles.

**Opportunity ledger.** The employer exists as described, and the stated pay sits inside the surveyed band (RR3). The posting is thin on team, reporting line and success measures (RR1, RR4, RR5), and the option terms are unknown (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the pay range both work for you — R1, R2; (2) you present the forecast work as adjacent, never as ownership — R6; (3) the loop confirms how the role is supported on billing data — R8, RR1; (4) your renewal reporting involved finance's revenue figures, or you accept R7 as a stretch — R7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` Quillfield "About" page, seen as a search result |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options; Ledgerline 2026 puts UK revenue operations leads in B2B software at a median of £64,200 (interquartile range £57,800–£70,400, n=438), so the posted range sits inside the band, just above the median. The survey is a market band, not Quillfield's offer | `[grounded]` posting figure; `[generic]` Ledgerline survey, from a search snippet |
| Hiring manager | Tamsin Achebe, listed as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. This matches what your recruiter told you | `[grounded]` public profile snippet and your recruiter's statement |
| Scope read | Four responsibilities in one post (CRM and billing data, reporting, forecast with the CFO). The post probably sits beside an existing revenue operations head rather than building the function from nothing | `[inferred]` from the posting's list against Tamsin's listed title |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Unknowns | Team size, reporting line, success measures, option terms, the CRM and billing systems in use | `[grounded]` posting silent |
| Contradictions | None found between your description and Quillfield's About page. The posting was not cross-checked on Quillfield's own careers page | `[grounded]` About page, search snippet only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't stated a location constraint, and your UK team role suggests you're UK-based but doesn't say where. Fit stays unclear until you answer | `[grounded]` posting term; your constraint not given | Q1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor stated by you. The range is inside the surveyed band, but whether it clears your floor is yours to say | `[grounded]` posting; `[generic]` survey band | Q1 |
| R3 | 4+ years in revenue operations, sales operations or a similar role at a B2B software company | must_have | adjacent | medium | discovery | Five years of sales operations, the last two in revenue operations, covers the years and role. Your employer is a B2B payments company, and you haven't said whether its product is software, so I read the sector clause downward | `[grounded]` your background statement | Confirm in the application how you describe your employer's product |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You're Salesforce admin certified and the posting accepts either system. This is self-reported, not inspected | `[grounded]` your statement | Link the certification to raise to `high` |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly is specific. The word "strong" is the employer's | `[grounded]` your statement | A query or dashboard sample would raise to `high` |
| R5b | Spreadsheet modelling | must_have | adjacent | low | discovery | Excel daily shows use, not modelling | `[grounded]` your statement | G3 |
| R6 | Experience owning a forecast; run the quarterly revenue forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, and finance owned the company forecast. The adjacency is credible. The limit is that you haven't owned a forecast or worked with a CFO on one | `[grounded]` your statement | Q2 |
| R7 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | You've never worked on billing data. The "or" leaves revenue data, and your renewal dashboards may count if finance's figures fed them. Nothing you've said settles that | `[grounded]` your statement; posting wording | Q3 |
| R8 | Own the CRM and billing data | important | absent | none | capability | You confirmed no billing data work. The CRM half is covered at R4 | `[grounded]` your statement | G5 |
| R9 | Build the pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them is unknown, and that feeds R7 | `[grounded]` your statement | A sanitized dashboard screenshot would raise to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | A monthly pipeline review you run, with finance owning the forecast. Nothing on forecast inputs or a CFO relationship | The posting says you'd run the forecast with the CFO, so this is the objection most likely to come up | Building a commit or best-case roll-up finance used; a renewal forecast; a bookings plan or quota-capacity model | A sanitized forecast roll-up or pipeline-review pack | `[grounded]` your statement; `[inferred]` that this is the likeliest objection, from the posting's CFO wording |
| G2 | Finance and revenue data (R7, must_have) | discovery | Renewal dashboards, with no detail on where their numbers came from or whether finance was involved | It decides whether R7 is a gap or a match, and it could move the decision | Reconciling dashboard figures against finance's; agreeing a renewal or ARR definition with finance; fixing a mismatch between CRM and finance numbers | A definitions doc, a reconciliation sheet or a renewal dashboard spec | `[grounded]` your statement; `[inferred]` the decision effect |
| G3 | Spreadsheet modelling (R5b, must_have) | discovery | Excel daily, with no model described | "Modelling" may mean forecasting or scenario work in a spreadsheet | A pipeline coverage model; a renewal churn scenario sheet; a capacity plan | A sanitized workbook | `[grounded]` your statement |
| G4 | Sector clause (R3, must_have) | discovery | A B2B payments company, with no statement on whether its product is software | The posting says "B2B software company" | Stating the product you supported (platform, API, subscription) in your own words | Your current CV's company line | `[grounded]` your statement |
| G5 | Billing data (R8, important) | capability | No evidence of any billing data work, confirmed by you | It's the first-named ownership item in the posting | Closure path: ask Quillfield to walk you through their billing data model in the loop, and read up on how invoice, subscription and credit note data fit together before the interview | The company's answer, not an artifact of yours | `[grounded]` your statement; `[generic]` that a billing data model is learnable on the job |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The forecast may be the CFO's, with this role supplying inputs, or the role may carry accountability | `[inferred]` from the posting's wording against its silence on ownership | Who owns the forecast model today, and what does "run it with the CFO" mean in practice? | unresolved |
| RR2 | Option terms unstated | unknown | — | "plus share options" | Value depends on grant size, vesting and strike, none of which are given | `[inferred]` from the posting's silence | What is the option grant for this role, and what are the vesting terms? | unresolved |
| RR3 | Pay stated and inside the surveyed band | positive_signal | — | "£61,500–£67,000" | A stated range is transparent, and it sits at or just above the survey median | `[grounded]` posting; `[generic]` Ledgerline band | What would move a candidate within that range? | noted |
| RR4 | Team, reporting line and success measures not stated | unknown | — | "You will own our CRM and billing data..." | The role may report to Tamsin as Head of Revenue Operations, and what supports it is unknown | `[inferred]` from Tamsin's listed title against the posting's silence | Who does this role report to, what team supports it, and what does success look like at twelve months? | unresolved |
| RR5 | Four responsibilities in one post | risk_signal | low | "CRM and billing data, pipeline and renewal reporting, quarterly revenue forecast" | Scope may be wider than one person can cover without support | `[inferred]` from the list length; taken at `low` because the breadth could be normal for a lead | Which of these areas is the first priority in the first ninety days? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm Bristol with two office days and the pay range work for you before investing further | see R1, R2 | `[grounded]` posting | pending your approval |
| A2 | Lead with the monthly pipeline review you run with your sales director and the pipeline and renewal dashboards you rebuilt, and say plainly that finance owned the company forecast | see R6, R9 | `[grounded]` your statement | pending your approval |
| A3 | Say plainly you haven't worked on billing data, and ask how the role is supported on it | see R8, G5 | `[grounded]` your statement | pending your approval |
| A4 | Ask the verification questions of RR1, RR2 and RR4 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Revenue Operations Lead Bristol" and reached "About Quillfield" (quillfield.co.uk/about). Confirmed the employer exists as described. It did not confirm the posting on Quillfield's own careers page, so the contradictions row says that |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol" and reached "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the pay row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" and reached "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Only the snippet was read. Moved the hiring manager row and RR4 |

I can package this as a `tuesday-dossier.md` for you to keep or reuse later, if you want it.

**Upgrade menu**

- A link to your Salesforce certification would raise R4 to `high`.
- A sanitized dashboard screenshot would raise R9 to `high`; a sanitized query or workbook would do the same for R5a and move R5b.
- Your answers to G1 and G2 would settle whether R6 and R7 are bridges or gaps.
- A link to the role on Quillfield's careers page would confirm the posting is live and consistent.
- A deeper research pass on Quillfield (funding, leadership changes, public candidate and employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

Q1 (R1, R2) — Do Bristol with two office days a week and a £61,500–£67,000 range both work for you?

Q2 (R6) — Have you built or maintained any input to the company forecast that finance used, such as a pipeline roll-up, a renewal forecast or a bookings plan, and what part was yours?

Q3 (R7) — Did your renewal reporting draw on finance's revenue figures, and did you work with finance to agree or reconcile them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.