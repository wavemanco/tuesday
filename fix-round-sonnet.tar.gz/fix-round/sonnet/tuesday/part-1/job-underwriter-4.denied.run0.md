Search access was denied, so this is underwritten from the JD and your background only, with nothing about Brindlemoor itself checked.

## Decision snapshot

**Yes, worth applying to, on conditions. Your fit is strong, but the posting is unverified (RR1) and your UK location is unconfirmed (R9). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R9 (Fully remote (UK))
- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — direct: R6a · unclear: R6b (Recommendations to product)
- `preferred` — direct: R7 · adjacent: R8 (Pet-insurance domain)

R8 — a bridge from motor, with its limit named; R6b — product-side recommendations not yet evidenced; R9 — UK location unconfirmed.

**Opportunity ledger.** The role is clearly scoped to work you have done (RR5). Four things are open: the employer is not yet verified (RR1), pay is unstated (RR2), and the team shape and any people-management expectation are unstated (RR3). Whether a rating model already exists is also unknown (RR4). The JD lists no people-management requirement, so never having managed anyone is not a row.

- **Hard gates:** none failed; unconfirmed: R9 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed on Brindlemoor's own careers site (RR1); (2) UK location confirmed (R9); (3) the pet gap is framed as adjacent and never as pet-insurance experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; not verified | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | The hiring manager is Odile Varga, Director of Pricing | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | An individual-contributor senior post under a Director of Pricing. No direct reports or line management are mentioned | `[inferred]` from the JD's wording against its silence on team |
| Market calibration | Not run, so there is no salary band and no title-norm comparison | `[grounded]` search refused |
| Unknowns | Salary; team size and mentoring duties; whether a rating model already exists; who "product" is | `[grounded]` JD silent |
| Contradictions | None inside the JD as supplied; not checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, 2 as senior analyst. Confirmed and specific, but nothing inspectable yet | `[grounded]` your intake message | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | You say you use both daily. Stated, with no artifact inspected | `[grounded]` your intake message | Be ready for a technical probe |
| R3 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. This also covers "build and monitor rating models" | `[grounded]` your intake message | A sanitized model document would raise it to high |
| R4 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your intake message | A sanitized review deck would raise it to high |
| R5 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with underwriting. "Ran" does not separate design from readout, so the row claims no more than that | `[grounded]` your intake message | Be ready to say which parts of design and readout were yours |
| R6a | Turn results into recommendations for underwriting | important | direct | medium | none | Quarterly review to the head of underwriting, plus the 14 tests run with that team | `[grounded]` your intake message | none |
| R6b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing in your background mentions a product audience | `[grounded]` background silent | See G2 |
| R7 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your intake message | none |
| R8 | Pet-insurance domain knowledge | preferred | adjacent | medium | transferability | Adjacency: personal-lines GLM rating and price testing carry over. Limit: you have not worked on pet insurance. Pet rating usually leans on factors like breed, age and condition history, which motor does not exercise | `[grounded]` you said you have no pet experience; `[generic]` pet rating factors; `[inferred]` requirement from the product named in the JD | See G1 |
| R9 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | Your location and constraints were not stated. A UK employer suggests UK-based but does not confirm it | `[grounded]` JD term; `[inferred]` UK location from your UK employer | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance domain (R8, preferred) | transferability | Motor GLM and price-test work; no pet exposure | Preferred-tier, but it is the one row at `adjacent`, so a stronger bridge narrows it | Renewal-pricing or elasticity work; claims-inflation monitoring; a book with a strong age curve, like young drivers | A sanitized model document, a price-test readout, the review deck | `[grounded]` background silent on pet; `[generic]` that these analogues carry over |
| G2 | Product-facing recommendations (R6b, important) | discovery | Your recommendations go to underwriting; no product audience is mentioned | The JD names product as an audience, and this is the only `important` row below `direct` | A test result that changed a product feature, a customer journey or a proposition; a pricing change planned with a product or commercial owner | A readout deck or a recommendation memo that names the product audience | `[grounded]` background silent |
| G3 | UK location and constraints (R9, hard_gate) | hard_gate | Location, pay floor and other constraints not stated | A gate the inputs do not settle is carried as `unclear` until answered | Not applicable; this is a term, not experience | None needed | `[grounded]` constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | low | "Brindlemoor (insurtech)" | The search that would confirm the company and the live posting did not run, so this says nothing about Brindlemoor. Most small firms are simply small, so severity stays at the lower value | `[generic]` pattern for companies of this size, not a claim about this one | Which team does this role sit in, and is Odile Varga the person I would report to? | unresolved |
| RR2 | Pay unstated | unknown | — | JD gives no salary | Cannot be set against a band, since no sweep ran | `[grounded]` JD silent; `[grounded]` no sweep ran | What salary range is budgeted for this post? | unresolved |
| RR3 | Team shape and people-management expectation unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Senior" may or may not carry mentoring or line duties | `[inferred]` from the title against the JD's silence | Does this role have direct reports or mentoring duties, and how big is the pricing team? | unresolved |
| RR4 | Rating-model starting point unknown | unknown | — | "build and monitor rating models" | An existing model to monitor and a build from scratch are different jobs | `[inferred]` from the JD's wording | Is there a live rating model today, or would I be building the first? | unresolved |
| RR5 | Responsibilities specific and map to real work | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The mandate is concrete, not a vague blend of roles | `[grounded]` JD | What would success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the GLM rating model you built and maintained for the young-driver book, then the 14 price tests you ran with underwriting | See R3, R5 | `[grounded]` your intake message | pending your approval |
| A2 | Name the pet gap yourself and plainly: you have not worked on pet insurance, and you have done personal-lines GLM pricing | See R8; saying less than you did is safe, saying more is not | `[grounded]` your intake message | pending your approval |
| A3 | If management comes up, say plainly that you have not managed anyone; the JD does not ask for it | See RR3 | `[grounded]` your intake message and the JD | pending your approval |
| A4 | Confirm the posting on Brindlemoor's own careers site before investing in an application | See RR1 | `[grounded]` register | pending your approval |
| A5 | Ask RR2, RR3 and RR4 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The call "Brindlemoor pet insurance insurtech" was refused. It would have moved role reality's Organization and Contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | The call "Senior Pricing Analyst pet insurance UK remote salary" was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | unavailable | The call "Odile Varga Director of Pricing" was refused. It would have moved role reality's scope read and which story the plan leads with |

If you want it, I can emit all of this as `tuesday-dossier.md` to carry into later steps.

## Upgrade menu

- Search access, so the three targets above can run: RR1, the market band, RR2 and the scope read. A deeper pass on top (up to 5 more searches and 2 more fetches) is optional.
- A link to the live posting on Brindlemoor's careers page: RR1.
- Sanitized artifacts (model documentation, a price-test readout, a quarterly review deck): R3, R4 and R5 to `high`, and G1 gets a stronger bridge.
- Your CV: your claims move from prose to a document. Once it is in, resume-tailor can turn it into an approve-first edit ledger for this role.
- Your answers to G2 and G3: R6b and R9 close.

Questions:

G1 — Have you worked on anything pet-like, such as claims inflation, renewal price walks or an age-driven rating curve, and which part was yours?
G2 — Did the recommendation from any of your 14 tests go to a product owner rather than underwriting, and what did you own?
G3 — Are you UK-based, and what hard constraints should I check Brindlemoor against (pay floor, anything else)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.