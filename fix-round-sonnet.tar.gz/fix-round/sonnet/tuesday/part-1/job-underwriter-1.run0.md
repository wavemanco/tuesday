I'm checking whether Harborlight Health is a real employer and what the market pays for this role. Then I'll write the full assessment.
## Decision snapshot

**Yes, apply. You are a fit on the core: R1, R2, R3, R4, R6 are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (metrics layer)
- `important` — direct: R7a · unclear: R7b (partnering with clinicians), R8 (mentoring two junior analysts)
- `preferred` — adjacent: R9 (healthcare data experience, HIPAA)

R5 — metrics-layer ownership not yet shown; R7b and R8 — nothing in your background either way; R9 — a bridge through your consent-state model, limit named.

**Opportunity ledger.** Plausible but unchecked: the employer and posting are unverified (RR1), pay and location are not stated (RR2), and success measures are not stated (RR3). One entry runs the other way: a named team and a named tool (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this (conditions for go):** (1) Harborlight and the live posting verify on its own careers site, RR1; (2) you can evidence metric-definition ownership, R5 and G1; (3) pay and location terms don't collide with your non-negotiables, RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, care-navigation app | `[grounded]` JD header; not independently verified (RR1) |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, turning analysis into roadmap decisions | `[grounded]` JD |
| Team | Mentor two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | A senior individual contributor with light mentoring duties, not a people-manager post | `[inferred]` from "mentor two junior analysts" with no management language |
| Market calibration | Not established. No search ran, so there is no pay band or norm for this title | `[generic]` role-family patterns only; upgrade menu says what research would add |
| Unknowns | Pay, location and working pattern, contract basis, success measures, how mature the metrics layer is | `[grounded]` JD silence |
| Contradictions | None visible inside the JD | `[grounded]` JD only; no second source checked |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics. Self-reported with no inspectable artifact, so `medium`. | `[grounded]` your background, typed intake | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is specific. "Expert" is your level to evidence, and no query or model has been inspected. | `[grounded]` your background | Offer a sanitized query or model sample to raise to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You describe designing and running a program of 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Specific, but expect a probe on what was yours versus the team's in that test. | `[grounded]` your background | Offer a sanitized test readout to raise to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. This is the same tool the JD names. | `[grounded]` your background | Offer a dashboard screenshot or sanitized LookML sample |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | "Governed dashboards" and a warehouse consent-state model are near this work. Nothing states that you wrote and maintained the metric definitions, so this is not claimed as direct. | `[grounded]` what your background does and does not say | See G1 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product. | `[grounded]` your background | Offer a sanitized memo to raise to `high` |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | Monthly presentation to the VP Product is partnership at a senior level. Whether decisions followed is not stated. | `[grounded]` your background | none |
| R7b | Partner with clinicians on that work | important | unclear | none | discovery | No clinical or domain-expert collaboration is mentioned. | `[grounded]` your background is silent | Upgrade menu names the example that would count |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Mentoring is not mentioned. | `[grounded]` your background is silent | See G3 |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model. Limit: this is not healthcare data and not HIPAA, so it is never to be called healthcare or HIPAA experience. | `[grounded]` your background; `[generic]` that regulated-data handling transfers only partly across regimes | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics-layer ownership (R5, must_have) | discovery | Governed dashboards and a consent-state model, but no statement that you defined and maintained metric definitions | It is the one `must_have` row below `direct`, and the JD lists it first among responsibilities | Writing LookML or semantic-layer definitions others reused; settling a dispute over how a core metric is defined; documenting metric definitions for non-analysts | A metrics dictionary, a sanitized LookML or dbt excerpt, a definitions doc | `[grounded]` background silent on definitions; `[inferred]` that this closing would move the status toward `go` |
| G2 | Clinician partnership (R7b, important) | discovery | Nothing about working with clinical or other domain experts | The JD names clinicians as a partner group | Analysis built with ops, medical or compliance experts whose judgment shaped the question or the readout | A project brief or readout naming the domain experts | `[grounded]` background silent |
| G3 | Mentoring (R8, important) | discovery | Nothing about mentoring or managing analysts | The JD makes mentoring two juniors part of the role | Onboarding analysts, reviewing their SQL or analyses, running a team's analytics standards | A mentoring plan or onboarding doc, or a named analyst you supported | `[grounded]` background silent |
| G4 | Healthcare and HIPAA (R9, preferred) | transferability | Adjacent: GDPR/CCPA PII and a consent-state model. Limit: none of it involved health data or HIPAA. Strengthener: a short description of how consent state gated data use in your warehouse | It is only a plus, so it is a minor gap, not a blocker | Access controls, data-minimization or audit practices you set up for regulated PII | A sanitized consent-model diagram or data-governance doc | `[grounded]` the consent-state model you described; `[generic]` that transfer is partial |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "digital-health scale-up, ~400 people, Series C" | The research check did not run, so this is an unchecked claim. The employer or posting may or may not be confirmable. | `[generic]` pattern for postings not yet checked, not a claim about this one | Is this role posted on Harborlight's own careers site, and who would I report to? | unresolved |
| RR2 | Pay, location and contract terms not stated | unknown | — | (none of these terms appear in the posting) | Pay may sit below what 6 years plus mentoring commands, or may simply be unpublished. | `[inferred]` from the posting's silence | What are the pay band, the location expectations and the contract basis for this role? | unresolved |
| RR3 | Success measures not stated for a demanding mandate | unknown | — | "turn analysis into roadmap decisions" | The role may be accountable for roadmap outcomes without defined measures of success. | `[inferred]` from the JD's scope language against its silence on outcomes | What would a strong first year look like, and which measures will this role be judged on? | unresolved |
| RR4 | Named team and named tooling | positive_signal | — | "mentor two junior analysts" … "Looker" | A named team and a named tool suggest a resourced, defined function. | `[inferred]` from the named team and tool | How is the analytics team organized, and who owns the metrics layer today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the employer and live posting on Harborlight's own careers site before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with experimentation: "30+ A/B tests a year, including the pricing test behind an 11% retention lift", in your own words from your background | see R3 | `[grounded]` your background | pending your approval |
| A3 | Position the consent-state model as the bridge for R9: "built the consent-state model for our warehouse; handled GDPR/CCPA consumer PII". Do not describe it as healthcare or HIPAA experience | see R9, G4 | `[grounded]` your background | pending your approval |
| A4 | Ask RR2, RR3 and RR4's verification questions verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

Every row above, and the wording quoted in it, is proposed and pending your approval. Nothing is final until you say so.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst". The call was refused because search permission was not granted. It would have moved role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range scope experimentation Looker". The call was refused for the same reason. It would have moved role reality's market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'd offer the dossier file, `tuesday-dossier.md`, whenever you want it. It saves this analysis so a later step can build on it.

**Upgrade menu**

- Search permission → the employer check and market band run (up to 5 searches and 2 fetches), which could clear RR1 and calibrate RR2.
- An answer to G1 → R5 moves toward `direct` and the main must-have gap closes.
- An example of analysis built with clinical or domain experts → R7b resolves.
- A sanitized test readout, query or model sample, dashboard screenshot, or monthly memo → R2, R3, R4, R6 can move from `medium` to `high`.
- Your non-negotiables → hard-gate checks run instead of showing as unknown.
- Stage: assumed to be evaluating. Tell me if you've already applied or have a call booked.

Questions:

- G1 — Did you define and maintain the metric definitions themselves, for example in LookML or a semantic layer? Who relied on them, and what happened when someone disputed a definition?
- G3 — Have you mentored or managed analysts, formally or informally? What exactly was your role?
- Constraints — What are your non-negotiables on pay floor, remote or office days, work authorization and schedule?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.