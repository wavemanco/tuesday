**Yes, go for it. It's a stretch on the forecast and billing side (R6, R7, R8), not a mismatch. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3a, R4 · adjacent: R5 (strong SQL and spreadsheet modelling), R6 (owning a forecast) · unclear: R3b (at a B2B software company), R7 (finance on billing or revenue data)
- `important`: direct: R9 · absent: R8 (own billing data)

R6 (`medium`) is adjacent through your pipeline review, with ownership not shown; R7, R8 are where the finance and billing stretch sits; R1, R2 are open because your constraints haven't been given yet.

**Opportunity ledger.** The pay is stated and sits inside the market band (RR2). The posting isn't yet matched to Quillfield's own site (RR1), who signs off the forecast is unclear (RR3), and the share-option terms are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the £61,500–£67,000 range both work for you (R1, R2). (2) The forecast split is clear, i.e. whether this role owns the number or supports it (RR3, R6). (3) You frame R6, R7 and R8 as adjacent or new, never as ownership. (4) The posting is confirmed on Quillfield's own site (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` "About Quillfield" (quillfield.co.uk/about), search snippet |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` JD |
| Compensation | £61,500–£67,000 plus share options; the range midpoint is £64,250. Band: median £64,200, interquartile range £57,800–£70,400 for UK B2B software revenue operations leads (n=438), which is not Bristol-specific and not this employer's offer | `[grounded]` JD figure; `[generic]` Ledgerline 2026 pay guide |
| Scope read | One post spans CRM, billing data, reporting and forecasting. That is wide but hangs together at a company of this size | `[inferred]` from the JD's scope against the 96-person headcount |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years. I read the search snippet, not the full profile | `[grounded]` search result (linkedin.example/in/tamsin-achebe) |
| Reporting line | Not stated. The hiring manager's title suggests this role sits beside or under her remit | `[inferred]` from her title against the JD's silence |
| Unknowns | First-year outcomes, who signs off the forecast, which billing system, option terms | `[grounded]` JD silent on each |
| Contradictions | The company matches the posting's description. The one careers path I tried (quillfield.co.uk/careers) returned no page, so the posting is not confirmed on their site | `[grounded]` about page; careers fetch returned nothing |

## Evidence map

Your background is self-reported and I haven't seen your CV, so nothing is above `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't stated a location constraint, so the term can't be checked | `[grounded]` JD term; no constraint given | Question R1/R2 below |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | No pay floor stated, so the range can't be checked against it | `[grounded]` JD figure; no floor given | Question R1/R2 below |
| R3a | 4+ years in revenue operations, sales operations or similar analytics | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team; self-reported, nothing inspectable yet | `[grounded]` your background | Share your CV |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | You described a B2B payments company; the posting says software. Taking the lower reading until the product is described | `[grounded]` your words against the JD | Describe the product in a line when you share your CV |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified and you rebuilt the dashboards. The JD says "own our CRM", so the scope of your admin role beyond the certification is worth confirming | `[grounded]` your background against the JD | A Trailhead credential link would raise to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show use, not modelling depth; no model has been described | `[grounded]` your background | A sanitized workbook or query would settle it |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director. The limit: finance owned the forecast, so you have not owned one | `[grounded]` your statements | See G1 |
| R7 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | Your renewal dashboards touch revenue data, but you haven't said finance was a working partner. You have not worked on billing data | `[grounded]` your statements | See G2 |
| R8 | Own billing data (responsibility) | important | absent | none | capability | You have not worked on billing data and no adjacent billing work has been described | `[grounded]` your statement; JD responsibility | See G3 |
| R9 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your team's pipeline and renewal dashboards; whether finance used them isn't stated | `[grounded]` your background | Share a dashboard screenshot |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | You run the monthly pipeline review with the sales director; finance owned the company forecast | The JD has you run the quarterly forecast with the CFO. How close your work sits to that decides how steep the climb is | Stage-conversion or weighted-pipeline views that finance used; a renewal forecast you built; variance explanations to the sales director | A sanitized pipeline-review deck or forecast workbook | `[grounded]` your statements; `[inferred]` that pipeline review sits near forecasting |
| G2 | Working with finance on revenue data (R7, must_have) | discovery | Renewal dashboards exist; the finance link is unstated | A must-have currently `unclear`, which a clear answer would settle | Renewal or ARR numbers reconciled with finance; a shared definition of "renewed"; month-end checks | A reconciliation sheet or dashboard spec | `[grounded]` your statements |
| G3 | Own billing data (R8, important) | capability | No billing-data work described | The posting makes billing data a core responsibility | Not applicable. This row is a stated gap, not a recall prompt | None | `[grounded]` your statement. The closure path is a handover or ramp with finance, to verify via RR3 and A5 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not matched on the employer's own site | risk_signal | low | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The path I tried may not be where Quillfield lists roles, or it may advertise only through the job board | `[inferred]` from one guessed path returning no page, while the company itself matched | Is this role listed on Quillfield's own careers page, and is it still open? | unresolved |
| RR2 | Stated pay sits inside the market band | positive_signal | — | "Salary £61,500–£67,000" | The range straddles the median for the role family | `[grounded]` JD figure; `[generic]` band, not Bristol-specific | Where in the range would someone with my background land? | noted |
| RR3 | Forecast ownership split unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The number may sit with the CFO or the Head of Revenue Operations, with this role supporting it | `[inferred]` from the JD's wording against the hiring manager's title | Who signs off the quarterly forecast, and where does this role sit relative to the Head of Revenue Operations? | unresolved |
| RR4 | Share-option terms unstated | unknown | — | "plus share options" | The grant size and vesting could change the offer's value either way | `[inferred]` from the posting's silence | What is the option grant, vesting schedule and strike price for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check that Bristol with two office days and the salary range suit you before investing time | See R1, R2 | `[grounded]` JD terms | pending your approval |
| A2 | Lead with the three things in your own words: two years running revenue operations for the UK team, the rebuilt pipeline and renewal dashboards, and the monthly pipeline review with your sales director | See R3a, R4, R9; each traces to your sentences | `[grounded]` your background | pending your approval |
| A3 | Say plainly that finance owned the forecast and that billing data is new to you, with the pipeline review as your closest work | See R6, R8; claims no ownership you don't have | `[grounded]` your statements | pending your approval |
| A4 | Put the verification questions in RR1, RR3 and RR4 to the recruiter or Tamsin verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Ask what billing system the role uses and what handover or ramp with finance it gets | See R8; this is the closure path | `[generic]` a new owner of unfamiliar data usually ramps with the previous owner or finance | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol careers" and found "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers and got no page. Moved the organization row, and RR1 because the posting is not matched on their site |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B SaaS" and found "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the compensation calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" and found "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only. Moved the hiring-manager and reporting-line rows and RR3 |

I can save this analysis as a `tuesday-dossier.md` file to carry forward if you want it.

**Upgrade menu**
- Your CV, or a link to a LinkedIn profile, would let me check R3a, R3b and R4 against a document and propose positioning edits for your approval.
- Your Trailhead credential link would raise R4 to `high`.
- A sanitized pipeline-review deck, forecast workbook or dashboard screenshot would firm up R5, R6, R7 and R9.
- Your location and pay constraints would settle R1 and R2.
- The recruiter's confirmation that the role is live on Quillfield's own careers page would close RR1.
- A deeper research pass on Quillfield (funding and leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) would run if you say the word.

**Questions**
- **R1, R2:** Does Bristol with two office days a week work for you, and what is the lowest salary you'd accept?
- **G1:** Have you built any pipeline view, such as weighted pipeline, stage conversion or a renewal forecast, that finance used in their forecast? What did you own, and what happened?
- **G2:** Did you reconcile renewal or revenue numbers with finance, and who defined what counted?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.