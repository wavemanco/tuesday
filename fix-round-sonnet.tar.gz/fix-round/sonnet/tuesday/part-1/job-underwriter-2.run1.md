I'm not wasting your time on this role, but the "3+ years" PM requirement is a real weak spot. My web searches were denied, so I ran this from the posting and your resume only. Nothing about Quartzline is verified.

## Decision snapshot

**No, this isn't a waste of your time. The weak point is R1b (3+ years PM experience, absent), which is a risk, not a gate. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1a (3+ years PM, adjacent work), R2 (Shipped API or platform products) · unclear: R4b (Stakeholders in sales) · absent: R1b (3+ years PM, held as a title)
- `important`: adjacent: R6 (Partner discovery and roadmap) · unclear: R5 (Agile delivery), R7 (Adoption metrics), R8 (Launches with sales and support)

R1b: the titled years are absent; R1a, R2: adjacent work, limits named; R4b, R7, R8: sales, metrics and launches not yet evidenced.

**Opportunity ledger.** The posting is under-specified rather than alarming. The employer is unverified (RR1), the strictness of the years requirement is unknown (RR2), and success measures, pay, level and location are unstated (RR3, RR4). The partner-facing scope is concrete (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The employer confirms product-adjacent work can meet the years requirement (R1a, R1b, RR2).
  2. The posting verifies as live on Quartzline's own careers site (RR1).
  3. Your adjacent work is framed as adjacent, with product owning the roadmap decisions (R1a, R2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Existence and live posting unchecked because search was refused | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform, run partner discovery, drive two engineering squads, track adoption, coordinate launches | `[grounded]` JD |
| Level | A mid-level PM post, judging by the 3+ year floor | `[inferred]` from the years requirement; the JD states no level |
| Outcomes | No first-90-day or first-year outcomes stated | `[grounded]` JD silent |
| Pay, location, work pattern | Not stated | `[grounded]` JD silent |
| Scope read | Platform ownership across two squads is a broad remit for a company this size | `[inferred]` from the scope against the stated headcount |
| Market calibration | The role-family sweep did not run. Postings of this kind often weigh API-product experience heavily, and customer-facing technical backgrounds are a common source of platform PMs. A pattern, not a claim about Quartzline | `[generic]` |
| Contradictions | None inside the JD. JD against careers page unchecked | `[grounded]` JD read; check not run |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience: adjacent work | must_have | adjacent | medium | transferability | Seven years of scoping workshops, requirements documents, coordinating engineers and PMs, and quarterly roadmap-input sessions. Limit: you fed product's roadmap rather than owning prioritization or trade-offs | `[grounded]` CV | RR2's question to the employer; G1 |
| R1b | 3+ years PM experience: held as a PM title | must_have | absent | none | capability | You stated you have never held a PM title. Closure comes from the employer accepting adjacent work, not from recovering evidence. Titled-years requirements are often screened literally | `[grounded]` your statement; `[generic]` on literal screening | Ask the employer (RR2); carry as a material risk |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the integration playbook. Limit: this is the integrating side, and shipping or owning an API product is not on the CV | `[grounded]` CV | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading stated, plus integration architecture work. CV-only, no artifact inspected | `[grounded]` CV | A sanitized playbook excerpt would raise this to high |
| R4a | Stakeholder management with engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran client workshops through go-live | `[grounded]` CV | none |
| R4b | Stakeholder management with sales | must_have | unclear | none | discovery | The CV never mentions sales | `[grounded]` CV silence | G2 |
| R5 | Agile delivery | important | unclear | none | discovery | The CV names no sprint, backlog or squad process | `[grounded]` CV silence | Ask on a later turn if it matters |
| R6 | Partner discovery and roadmap ownership | important | adjacent | medium | transferability | Scoping workshops are partner discovery. Limit: roadmap ownership is not claimed, only quarterly feedback sessions for product | `[grounded]` CV | G1 |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | The CV is silent. A prior-context note mentions an internal triage tool that support agents adopted, but it is unconfirmed | `[grounded]` CV silence; memory lead, unconfirmed | G1 |
| R8 | Coordinate launches with sales and support | important | unclear | none | discovery | Client go-lives are not the same as product launches, and no sales or support coordination is stated | `[grounded]` CV | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product ownership and adoption evidence (R1a, R2, R6, R7) | discovery | The CV shows integration work and feedback sessions. An earlier note mentions an internal triage tool, unconfirmed | It is the one lead toward owning something that others adopted, which several rows lack | Deciding what the tool did and left out; tracking usage or time saved; changing it from support feedback | Usage numbers, a rollout note, a short spec, a before/after comparison | `[grounded]` CV silence; `[inferred]` that confirming it could move R7 and R2 |
| G2 | Sales and support coordination (R4b, R8) | discovery | Go-lives are described with client and engineering partners only | Sales and support are named in the stakeholder requirement and the launch duty | Handoffs to your own sales or support before go-live; enablement material; escalation paths you defined | A handoff checklist or launch note, sanitized | `[grounded]` CV silence |
| G3 | Titled PM years (R1b) | capability | You have never held a PM title | A must-have as the posting words it, but a risk, not a gate | Closure paths: an employer that accepts adjacent work, or a lower-bar PM role as a stepping stone | none | `[generic]` closure paths; `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The search that would check this was refused, so existence and a live posting are unconfirmed. Companies of this size often have thin footprints | `[generic]` pattern for companies of this size, not a claim about this one | Is this role listed on Quartzline's own careers site, and who is the hiring manager? | unresolved |
| RR2 | Strictness of "3+ years PM experience" unknown | unknown | — | "3+ years product management experience (must-have)" | The label may mean titled PM years only, or may allow product-adjacent work | `[inferred]` from the JD's "must-have" label | Does the 3+ years need to be in a PM role, or can product-adjacent work count? | unresolved |
| RR3 | Success measures not stated | unknown | — | "define and track adoption metrics" | Adoption metrics are to be defined, so success may be undefined at the start | `[inferred]` from the JD's silence on outcomes | What does success look like at twelve months, and which adoption metrics exist today? | unresolved |
| RR4 | Pay, level and location absent | unknown | — | (the posting states no pay, level or location) | The terms may be withheld or simply not in the copy supplied | `[inferred]` from the posting's silence | What are the pay range, level and work location? | unresolved |
| RR5 | Concrete partner-facing scope and delivery structure | positive_signal | — | "drive delivery with two engineering squads" | The remit is defined, with named squads and a named partner audience | `[grounded]` JD | How are the two squads divided between platform and partner integrations? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on Quartzline's own careers site before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the recruiter early whether adjacent product work can meet the 3+ years | RR2, R1b | `[grounded]` RR2 | pending your approval |
| A3 | Lead with your own two lines: "Led 30+ client integrations of our REST APIs end to end" and "ran quarterly roadmap-input sessions collecting client feedback for product". Say plainly that product owned the roadmap decisions | Strongest-evidenced rows R2, R3, R4a, R6, and it keeps the limits visible | `[grounded]` your resume lines | pending your approval |
| A4 | Seek an introduction through someone at the company before applying cold | Pivot candidates often get read through a referral | `[generic]` hiring pattern, not a fact about Quartzline | pending your approval |

Rewording your resume for this role is resume-tailor's job. I have proposed no resume edits here.

## Evidence status

Verified: none yet. Unverified leads: the prior-context mention of an internal request-triage tool; it prompts a question and nothing else. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology partner API platform careers Product Manager"; refused (permission not granted). Would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "platform API product manager B2B SaaS salary requirements solutions engineer transition to product management"; refused. Would have moved market calibration and R1b's reasoning |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

## One-line offer

I can save this as `tuesday-dossier.md` for later turns whenever you say so.

## Upgrade menu

- A sanitized slice of your integration playbook, a requirements document, or a roadmap-input summary you sent to product: R3 and R4a toward `high`, and a clearer R2 and R6.
- Confirmation and numbers on the triage tool: R7 and R2 could move.
- Search permission, or a link to Quartzline's careers page: RR1 and role reality's organization row close.
- The hiring manager's name: the scope read, and which of your stories to lead with.
- The recruiter's answers on the years requirement, pay, level and location: RR2 and RR4 close.
- Your constraints (pay floor, location, remote): the hard-gate checks can then run.

## Questions

G1 — I have an earlier note, unconfirmed, about an internal request-triage tool that support agents adopted. Did you decide what it did, who used it, and how do you know it was adopted?

G2 — When a client went live, did you work with your own sales or support teams on handoff or communication, and what was yours to do?

Constraints — Do you have non-negotiables for this move (pay floor, location or remote, travel, start date)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.