Running the job-underwriter on this role. Web search was denied, so this runs on the JD and your resume only.

## Decision snapshot

**No, you are not wasting your time on the pivot, and this role is worth a conditional shot. But R1a (3+ years of PM experience) is `absent` as written. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM-type work in non-PM roles) · unclear: R2 (Shipped API or platform products), R4b (Stakeholder work with sales), R5 (Agile delivery) · absent: R1a (3+ years product management experience)
- `important` — adjacent: R6 (Own roadmap, partner discovery), R7 (Specs, drive delivery with squads), R9 (Launches with sales and support) · unclear: R8 (Adoption metrics)

R1a — years requirement unmet as titled; R1b, R6, R7, R9 — real adjacent work, limits named; R2, R8 — open until an unconfirmed lead from an earlier conversation is confirmed or dropped.

**Opportunity ledger.** The scope is concrete (RR2). The years requirement is a risk signal (RR1), the salary is withheld (RR3), and the employer has not been checked (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the request-triage tool lead is confirmed with your ownership and adoption evidence (R2, R8, G1, G2); (2) the employer answers RR1 in a way that counts solutions and integration work; (3) the posting and employer verify as live and real (RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; existence not checked (see RR4) |
| Mandate | Own the roadmap of a partner-facing API platform; run partner discovery; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD is silent |
| Scope read | One PM owning a platform surface end to end, with two squads and named adoption metrics | `[inferred]` from the responsibility list and the squad count |
| Why this niche suits you | API-platform PM is the PM niche where your integration depth (R3) and customer-facing work (R4a, R6) count most | `[inferred]` from the JD against the map |
| Market calibration | Not calibrated: the role-family search was refused, so no pay band or norm is offered | `[grounded]` search refused |
| Unknowns | Pay, location or remote policy, who you report to, how success is measured | `[grounded]` JD is silent |
| Contradictions | None inside the JD; it could not be compared with Quartzline's own careers page | `[grounded]` search refused |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience | must_have | absent | none | capability | You say you have never held a PM title, so the literal reading is unmet. Whether a recruiter reads it as titled years is RR1. Titled-years requirements are often screened literally. | `[grounded]` your statement; `[generic]` screening pattern | Ask RR1 before investing; see G5 |
| R1b | PM-type work done in non-PM roles | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions for product and coordinated engineers and PMs on custom builds. Limit: you fed a roadmap and did not own one or set priorities. | `[grounded]` CV | G4 bridge; work sample |
| R2 | Shipped API or platform products | must_have | unclear | low | discovery | The CV shows you integrating the vendor's REST APIs, not shipping an API product. The internal playbook is a document, not a product. A lead from earlier conversation (a request-triage tool) is unconfirmed. | `[grounded]` CV; `[inferred]` lead from memory | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus 30+ REST integrations, confirmed in prose. No inspectable artifact yet. Expect a probe. | `[grounded]` CV | none |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran scoping workshops and UAT with clients. | `[grounded]` CV | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | The CV does not mention sales. | `[grounded]` CV silence | G3 |
| R5 | Agile delivery experience | must_have | unclear | low | discovery | The CV describes workshops, UAT and go-live and does not mention sprints or backlogs. | `[grounded]` CV silence | G3 |
| R6 | Own the roadmap; run discovery with integration partners | important | adjacent | medium | transferability | Discovery is close: workshops and quarterly sessions with clients. Limit: you collected input and did not decide the roadmap. | `[grounded]` CV | G4 |
| R7 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | You wrote requirements documents and integration architecture for client builds. Limit: those were client implementations, not a product backlog for squads you steered. | `[grounded]` CV | G4 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Nothing in the CV on metrics. The triage tool lead might hold an adoption story. | `[grounded]` CV silence; `[inferred]` lead | G2 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | You ran go-live for client integrations. Limit: client go-lives are not product launches coordinated with sales and support. | `[grounded]` CV | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product (R2, must_have) | discovery | An unconfirmed lead that you built an internal request-triage tool support agents adopted; the CV is silent | It could turn R2 from `unclear` toward `adjacent` or `direct`, and it is the one must-have that could still move | Gathering requirements from support agents, choosing what went in v1, releasing it, watching whether people kept using it | A spec or one-pager, release note, usage screenshot or dashboard | `[grounded]` CV silence; `[inferred]` lead; `[generic]` that this role family probes shipped-versus-built |
| G2 | Adoption metrics (R8, important) | discovery | No metric appears anywhere in the CV | Adoption is named in the JD as a core duty | Counting active users, tickets handled before and after, repeat use over weeks | The same usage evidence as G1 | `[grounded]` CV silence |
| G3 | Agile delivery and sales or support coordination (R5, R4b, R9) | discovery | Delivery language is client-project language: workshops, UAT, go-live | Agile experience is a must-have, and the CV's wording may be hiding it | Sprint ceremonies with engineers, writing stories, prioritizing tickets, briefing sales or support before a go-live | A sanitized story or ticket, a launch checklist | `[grounded]` CV wording |
| G4 | PM-type ownership (R1b, R6, R7) | transferability | Adjacent work with named limits: input, not decisions | A bridge with a stated limit reads weaker and survives interviews | A decision you drove from client feedback into something engineering built | A one-page spec or roadmap memo on a partner API feature, written by you | `[inferred]` bridge from the CV |
| G5 | Titled PM years (R1a, must_have) | capability | No credible titled-years evidence | It is the requirement a literal screen checks first. A title cannot be added. | Closure paths: have the employer confirm equivalence (RR1), or target roles that welcome solutions-to-PM moves | The employer's answer to RR1 | `[grounded]` your statement; `[generic]` closure paths |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Years requirement may be firm | risk_signal | medium | "3+ years product management experience (must-have)" | It may be screened as titled years, which you cannot meet | `[generic]` pattern for how such requirements are applied, not a claim about this employer | Would you consider candidates whose product work happened in a solutions or implementation role, and how do you weigh that against a PM title? | unresolved |
| RR2 | Concrete mandate and named metrics | positive_signal | — | "define and track adoption metrics" | The role is defined, with squads, partners and a success measure | `[grounded]` JD | Which adoption metrics does the team track today, and who owns them? | noted |
| RR3 | Compensation not stated | unknown | — | JD has no pay figure | The posting withholds it; I could not calibrate a band | `[grounded]` JD silence | What is the budgeted range for this role? | unresolved |
| RR4 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Quartzline may be real and small, or the posting may be stale or aggregated; no check ran | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Put RR1 to the recruiter before investing in a full application | R1a, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Seek a referral or a direct note to the hiring manager, not a cold application | Literal screens on titled years are common | `[generic]` hiring pattern | pending your approval |
| E1 | Proposed summary line: "Solutions engineer and implementation lead with 7 years leading 30+ client integrations of REST APIs end to end, who ran quarterly roadmap-input sessions collecting client feedback for product." Each clause traces to a sentence you wrote; it claims no PM title and no roadmap ownership. | R3, R4a, R1b, R6 | `[grounded]` your resume | `resume_edits_pending_approval` |
| W1 | A one-page spec or roadmap memo for a partner-API feature, written by you | G4, R1b, R6, R7 | `[inferred]` strengthener for an adjacent bridge | pending your approval |
| Q1 | Ask the RR1 to RR4 questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

If you decide to apply, resume-tailor is the module that reworks your resume for this role.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics software Series B careers Product Manager Platform APIs"; the call was refused. It would have fed role reality's organization and contradictions rows and RR4 |
| 2. Role-family sweep | unavailable | Searched "API product manager hiring solutions engineer to product manager transition requirements salary"; the call was refused. It would have fed the market calibration line and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can save all of this as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- The triage tool's details and an artifact (a one-pager or spec, a release note, a usage dashboard or screenshot) → R2 and R8 could move up; `high` needs an inspectable artifact.
- A sanitized excerpt of your integration playbook, or a roadmap-input summary you gave product → R1b, R6 and R7 strengthen.
- Search permission → the employer check (RR4) and a pay band (RR3), up to 5 searches and 2 fetches.
- The hiring manager's name → the scope read and which story to lead with.
- Your pay floor, location and work-arrangement constraints → hard-gate rows replace the unknown.

G1 — Did you build the request-triage tool support agents adopted, and what did you personally own: the problem, the design, the release? Who used it, and how did you know it worked (any usage numbers)?

G3 — On the integrations and custom builds, did you work in sprints with engineers, write stories or prioritize tickets, or brief sales or support before a go-live? Say what was yours.

Orientation — What are your non-negotiables for a move: pay floor, location or remote, and would you take a pay cut to switch to PM?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.