Running the employer and pay-band checks the posting calls for, then I'll write up the verdict.
**No, not as posted.** R1 and R2, both hard gates, fail, so the status is `no_go`. Your sense that something is off holds up: the substance fits you, but the terms and scope don't.

## Decision snapshot

**Not worth applying to. R1 and R2, both hard gates, fail · `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in our Austin office 5 days a week), R2 ($70–85k base)
- `must_have`: direct: R4, R5, R6 · unclear: R3 (8+ years growth leadership)
- `important`: unclear: R7 (SEO/content), R8 (brand, PR, partnerships), R9 (sales ops)

R1, R2: both fail on the posting's own words; R4, R5, R6: substance matches your history; R3, R7, R8, R9: breadth not yet evidenced.

**Opportunity ledger.** The posting bundles seven functions into one person with no stated budget (RR2, RR5). It prices that at $70–85k against 8+ years of leadership required (RR1), expects evenings and weekends (RR3), and sets no success measure for owning all revenue (RR4). The employer itself is unchecked (RR6). One entry runs the other way: the terms are stated upfront (RR7).

- **Hard gates:** failed: R1 (On-site in our Austin office 5 days a week); R2 ($70–85k base).
- **Severe red flags:** none found.
- **What would change this:** the posting would have to allow remote work from Portland (R1) and put base at or above your $150k floor (R2). Both are the employer's to change, and the posting says "no exceptions" on location.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header; not independently checked (RR6) |
| Mandate | Own all revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Resourcing | "A team of one to start"; reports to the CEO, dotted line to the board; no budget or headcount stated | `[grounded]` posting |
| Working pattern | Austin office five days, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside" (unquantified) | `[grounded]` posting |
| Success measures | "Will evolve as we learn" | `[grounded]` posting |
| Scope read | Closer to a bundle of several specialist jobs than one head-of-function job | `[inferred]` from the seven-function list against "team of one" |
| Market calibration | Not run, because the search was refused. The stated pay is compared with your floor (R2, RR1), not with a market band | `[grounded]` posting figure |
| Contradictions | A head-level title and 8+ years required, set against a pay band and team size that read as a mid-level post | `[inferred]` from the posting's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin, 5 days, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint (remote-only, Portland, no relocation). The failure is because the posting rules out remote | `[grounded]` JD quote and your statement | None. Only the employer changing terms resolves it |
| R2 | $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | Your floor is $150k base, so the top of the band is $65k under it | `[grounded]` JD figure and your statement | None. Only the employer changing terms resolves it |
| R3 | 8+ years growth leadership | must_have | unclear | medium | discovery | Your 9 years in growth is specific but unprobed. The posting says "leadership", and you haven't said how many of the 9 years were lead or head roles | `[grounded]` your intake prose | See G1 |
| R4 | Own revenue growth end to end | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. No document inspected, so expect a probe | `[grounded]` your intake prose | None |
| R5 | Paid acquisition | must_have | direct | medium | none | You owned paid at two B2C subscription companies. Whether Novaline sells to merchants or consumers isn't stated | `[grounded]` your prose; `[inferred]` that a merchant-facing product changes the channel mix | None |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and have deep Braze experience, with no artifact yet | `[grounded]` your intake prose | None |
| R7 | SEO/content | important | unclear | low | discovery | Your background is silent on SEO | `[grounded]` silence in what you gave me | See G2 |
| R8 | Brand, PR, partnerships | important | unclear | low | discovery | Your background is silent on all three | `[grounded]` silence in what you gave me | See G3 |
| R9 | Sales ops | important | unclear | low | discovery | Your background is silent on sales ops, and a B2B sales motion would differ from B2C subscription | `[grounded]` silence; `[generic]` that merchant-facing products often run a sales motion | See G4 |

## Gap recovery queue

None of these gaps can move a `no_go`, so I'm asking nothing on them this turn.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leadership years (R3, must_have) | discovery | 9 years in growth, with a lead and then head title; the split isn't stated | Matters only if the gates ever clear | Years with direct reports or budget ownership | A resume with dated titles | `[grounded]` split not stated |
| G2 | SEO/content (R7, important) | discovery | No mention | An important row, but moot while R1 and R2 fail | Owning organic acquisition or a content calendar | Analytics export or traffic report | `[grounded]` silence |
| G3 | Brand, PR, partnerships (R8, important) | discovery | No mention | An important row, but moot while R1 and R2 fail | Affiliate or partner channels; press launches | Partner list or coverage links | `[grounded]` silence |
| G4 | Sales ops (R9, important) | discovery | No mention | An important row, but moot while R1 and R2 fail | CRM or pipeline reporting for a sales team | A pipeline dashboard | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Seniority-pay mismatch (see R2) | risk_signal | medium | "8+ years growth leadership required" / "$70–85k base" | The pay may reflect a mid-level post under a head-level title. Rated medium because no market band was checked | `[inferred]` from the posting's seniority ask against its figure | What is the budgeted band for this role, and who set it? | unresolved |
| RR2 | Bundled specializations | red_flag | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several full jobs folded into one title, priced low | `[inferred]` from the function list against "a team of one" | Which of these seven functions do you expect one person to execute personally in year one? | unresolved |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Overtime is part of the culture and not an exception | `[inferred]` from "just who we are" | How often did the last person in a comparable role work evenings or weekends, and who decided "when it matters"? | unresolved |
| RR4 | No success metrics on a total-revenue mandate | risk_signal | medium | "Own all revenue growth" / "success metrics will evolve as we learn" | You could be accountable for revenue with no agreed definition of success | `[inferred]` from the two phrases together | What will I be measured on at 90 days and at 12 months? | unresolved |
| RR5 | Authority and resources unstated | unknown | — | "Report to the CEO with a dotted line to the board" | Budget, tooling and hiring rights aren't mentioned | `[inferred]` from the posting's silence | What budget and hiring authority come with the role? | unresolved |
| RR6 | Employer not established | risk_signal | low | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint. Rated low because the check never ran | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your careers site, and who I'd interview with? | unresolved |
| RR7 | Terms stated upfront | positive_signal | — | "On-site in our Austin office 5 days a week — no exceptions" | Pay and location were disclosed, which lets you screen out before spending effort | `[grounded]` posting | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't spend application effort on this posting | R1 and R2 fail | `[grounded]` map | pending your approval |
| P2 | Re-open only if the employer revises both stated terms in writing. If you proceed anyway, RR1–RR5 are the questions to ask verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: your stated constraints behind R1 and R2 (remote-only from Portland, $150k base floor), which are user-confirmed. The experience claims behind R3–R6 are intake prose and unverified. No memory leads.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Head of Growth"; the call was refused. It would have moved RR6 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary range startup Series A base salary 2026"; the call was refused. It would have moved market calibration and RR1's severity |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can offer you `tuesday-dossier.md` to keep this analysis, whenever you want it.

## Upgrade menu

- Search permission, or a link to Novaline's own careers page → RR6 and the contradictions row resolve, and the pay band gets checked against the market.
- The recruiter's email domain → RR6 gets a second check on whether the posting is live and genuine.
- A resume with dated titles → R3 can be confirmed.
- Any SEO, partnership or sales-ops work you've done → R7–R9 move, though only if the gates change.
- A deeper pass (up to 5 more searches and 2 more fetches) is only worth running if the employer revises its terms.

No questions this turn: nothing I could ask would move a `no_go`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.