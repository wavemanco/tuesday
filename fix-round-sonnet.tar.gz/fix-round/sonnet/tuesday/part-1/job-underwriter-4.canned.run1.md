Status: I've run three of my five L1 searches. The Brindlemoor company search came back empty, so I'm trying once more for its careers page, then I'll write up the assessment.
**Yes. Apply, but first confirm whether the role is remote or Leeds-based. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important`: unclear: R8 (Recommendations for product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R5b: monitoring practice isn't stated yet; R8: the product side has no evidence; R10: a bridge from motor, limit named.

**Opportunity ledger.** The JD and the careers page disagree on working pattern (RR1), the salary is withheld (RR2), and authority to change prices is unstated (RR3). The live careers page, matching the JD's mandate and giving a direct line to the Director of Pricing, runs the other way (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed acceptable to you (R1, RR1); (2) you can evidence model monitoring (R5b); (3) the pet bridge is framed as adjacent, never as pet-insurance experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; its careers page is live on brindlemoor.co.uk. Stage and size were not established | `[grounded]` JD header and fetched careers page |
| Mandate | Own pricing analytics for the pet product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD; careers page repeats "own pricing analytics for our pet-insurance product" |
| Reporting line | The Director of Pricing, Odile Varga | `[grounded]` careers page |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` both sources; contradiction recorded, not resolved |
| People management | The JD lists no management requirement | `[grounded]` JD |
| Scope read | A senior individual-contributor post spanning models, tests and recommendations | `[inferred]` from the JD's responsibilities against its silence on reports |
| Hiring manager | Odile Varga spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books). She was previously head of pricing analytics at Calloway Re for six years | `[grounded]` search snippet of her profile page, not fetched |
| Market calibration | UK senior pricing analysts at insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. This is not Brindlemoor's offer, and it is a general band, not a pet-insurance one | `[generic]` Pricewell 2026 survey snippet; `[grounded]` JD withholds pay |
| Unknowns | Salary; who signs off price changes; first-year outcomes | `[grounded]` JD silence |

## Evidence map

Your background was given in prose, which is self-report, so `medium` is the ceiling for now.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You haven't stated a working-pattern constraint. The posting's two sources conflict, so nothing settles this gate. | `[grounded]` JD and careers page | G1 question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You stated 5 years at a UK motor insurer, 2 as senior analyst. No inspectable artifact yet. | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Confirmed and specific, with no inspectable artifact. | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book. Expect a probe on model structure. | `[grounded]` your background | offer: sanitized model documentation would raise to high |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver model. | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" doesn't establish monitoring practice, and I won't read monitoring into it. Monitoring in small books also appears to be the hiring manager's public topic. | `[grounded]` your wording; `[inferred]` from the manager's talk title | G2 question |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. | `[grounded]` your background | offer: a sanitized test readout would raise to high |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. | `[grounded]` your background | none |
| R8 | Turn results into recommendations for product | important | unclear | low | discovery | Underwriting recommendations are covered by R7. Product-side work isn't mentioned. | `[grounded]` your background silence | G3 question |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer. | `[grounded]` your background | none |
| R10 | Pet-insurance product knowledge (implied by the product) | preferred | adjacent | medium | transferability | Carries over: GLM rating and price testing in a motor book. Limit: you have never priced pet risks, and pet rating likely turns on factors motor doesn't have. | `[inferred]` requirement from the JD's product; `[generic]` pet rating differs from motor | G4 bridge |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The JD says remote; the careers page says Leeds four days | A gate: only you or the employer can settle it | Not applicable; the question is whether the gate is met | The recruiter's written confirmation of the working pattern | `[grounded]` both sources |
| G2 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" is all the background says | A must-have, and the one most likely to move `conditional_go` to `go` | Actual-versus-expected tracking, drift or relativity checks, a rating-factor review that triggered a change, a post-launch review of a rate change | A sanitized monitoring pack or dashboard screenshot | `[grounded]` your wording; `[generic]` that monitoring is likely probed given the manager's talk |
| G3 | Product-side recommendations (R8, important) | discovery | Only underwriting audiences are mentioned | Half of the JD's "recommendations for underwriting and product" | A price-test result you took to a product or proposition team; input to a product change | A sanitized recommendation deck | `[grounded]` your background silence |
| G4 | Pet domain (R10, preferred) | transferability | Motor GLM and tests, no pet work | A bridge with a stated limit reads stronger than silence | Rating factors you tested that behave like pet ones (age bands, claim-frequency drift) | A one-page note on how you would test a pet rating factor, if you want one | `[inferred]` bridge from motor work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern conflict | risk_signal | medium | JD "Fully remote (UK)" vs page "Leeds office four days a week" | One source may be stale, or the page may reflect the real expectation | `[inferred]` from the two sources disagreeing | Is this post fully remote, or based in Leeds four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | no figure in the JD | The pay may sit inside the band in role reality, or outside it | `[generic]` band, not an entity claim | What salary range is budgeted for this post? | unresolved |
| RR3 | Authority over price changes unstated | unknown | — | "turn the results into recommendations" | The post may recommend while underwriting decides | `[inferred]` from "recommendations" against silence on sign-off | Which rating or price changes does this role decide, and which does underwriting sign off? | unresolved |
| RR4 | Live posting matches the JD's mandate and names its reporting line | positive_signal | — | "reports to the Director of Pricing" | The role is real and has a senior pricing owner | `[grounded]` fetched careers page | What does success look like in this post's first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Get the working pattern confirmed in writing before investing in the loop | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | CV edit: open the summary with two of your own claims, unchanged in substance: "built and maintained the GLM rating model for our young-driver book" and the 14 price tests last year with the underwriting team | see R4, R6 | `[grounded]` your background | pending your approval |
| Q1 | Ask the questions in RR1, RR2, RR3 and RR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | Optional one-page note on how you would test a rating factor in a pet book, framed as an approach and never as pet experience | see R10, G4 | `[inferred]` from the bridge case | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech", which returned nothing, and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the posting is live and matches the mandate and reporting line, and it produced the working-pattern contradiction (R1, RR1). Company stage and size were not established |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet only. It set the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read as a snippet only. It informed the hiring-manager row and G2 |

I can also save this as `tuesday-dossier.md` if you want a file to carry forward.

## Upgrade menu

- Your pay floor and whether remote is a must: R1 becomes a real pass or fail, and RR2 gets set against your floor.
- The recruiter's answer on remote versus Leeds: R1 and RR1 close, and the decision likely simplifies to `go` or `no_go`.
- An answer to G2, or a sanitized monitoring pack: R5b firms up. A test readout would lift R6, and model documentation would lift R4.
- An answer to G3: R8 resolves.
- Your actual CV: the map is built from your prose summary, so bullets could be checked and repositioned.
- A deeper pass on Brindlemoor (funding, leadership, staff reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions:**

G1 — Is working remotely a requirement for you, or is four days a week in Leeds workable? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you personally monitored a rating model after launch, such as checking actual against expected or reviewing relativities, and did it ever lead to a change? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — Have you taken a price-test result to a product or proposition team, and what did you own in that? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.