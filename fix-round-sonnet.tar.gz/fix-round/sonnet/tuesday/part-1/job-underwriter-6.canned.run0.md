# Quillfield, Revenue Operations Lead: should you apply?

## Decision snapshot

**Yes, apply, as a stretch on R6 (forecast ownership) and R7a (billing data), provided the Bristol hybrid terms and the pay work for you (R1, R2). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol, hybrid two days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3a, R4 · adjacent: R5 (strong SQL and spreadsheet modelling), R6 (experience owning a forecast) · unclear: R3b (at a B2B software company), R7b (working with finance on revenue data) · absent: R7a (billing data)
- `important` — direct: R8

R6 — pipeline review and dashboards bridge to the forecast, but you never owned the number; R7a — no billing-data experience; R1, R2 — open only because your constraints weren't given.

**Opportunity ledger.** Quillfield checks out against its own About page (RR1), and the pay is disclosed and sits inside the survey band (RR2). Who owns the forecast number, whether the role has a team, the option terms and the first-year success measures are all unstated (RR3, RR4, RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid two days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R1 and R2 are confirmed against your own limits.
  2. The forecast bridge (R6) is told as adjacent, never as ownership.
  3. In the interview, Quillfield treats billing-data experience (R7a) as learnable, which RR3 and RR5 probe.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` "About Quillfield" (quillfield.co.uk/about) |
| Mandate | Own the CRM and billing data. Build the pipeline and renewal reporting that sales and finance run on. Run the quarterly revenue forecast with the CFO | `[grounded]` the posting |
| Terms | Bristol, hybrid, two office days a week. £61,500–£67,000 plus share options | `[grounded]` the posting |
| Stated requirements | 4+ years in revenue operations, sales operations or a similar analytics role at a B2B software company. HubSpot or Salesforce administration. Strong SQL and spreadsheet modelling. Experience owning a forecast. Experience working with finance on billing or revenue data | `[grounded]` the posting |
| Hiring manager | Tamsin Achebe is Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. The posting doesn't name her, so that she is hiring for this role comes from your recruiter | `[grounded]` profile page "Tamsin Achebe — Head of Revenue Operations, Quillfield"; `[grounded]` your recruiter's statement |
| Scope read | This is a step up in scope: from running RevOps for one UK team to the company's data, billing and forecast owner. It is reported as the same function, not a different one | `[inferred]` from the posting's three responsibilities against your described scope |
| Market calibration | The posted range straddles the survey median (£64,200) and sits inside its interquartile range (£57,800–£70,400). The survey covers base pay for UK B2B software revenue-operations leads (n=438), isn't Bristol-specific, and isn't this employer's offer | `[generic]` Ledgerline 2026 pay guide; `[grounded]` the posting's figure |
| Unknowns | Direct reports, who owns the forecast number, option terms, and first-year outcomes | `[grounded]` the posting is silent on each |
| Contradictions | None found. Whether the role is live on Quillfield's own careers page is unconfirmed: the one address I tried returned no page, and it was a guess (RR1) | `[grounded]` fetch result |

## Evidence map

Your background is typed prose with no CV, so it counts as self-report. That caps every candidate claim here at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You stated no location constraint, so confidence grades a statement that doesn't exist. Whether the terms fit you is not established | `[grounded]` posting; your message is silent | G1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor was given. The range is inside the survey band, which says nothing about your floor | `[grounded]` posting; `[generic]` survey band | G1 |
| R3a | 4+ years in revenue operations, sales operations or similar analytics | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations for the UK team. That is above the stated minimum, but unprobed | `[grounded]` your message | none |
| R3b | "At a B2B software company" | must_have | unclear | low | discovery | Your employer is a B2B payments company. Whether it reads as software to Quillfield isn't established | `[grounded]` your message | G5 |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, and you rebuilt the dashboards. The posting says "or", so Salesforce meets it. The certificate hasn't been inspected | `[grounded]` your message | a certification link would raise this to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show usage, not strength or modelling. No model, query or workbook has been described | `[grounded]` your message | G6 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You never owned the company forecast; finance did. You run the monthly pipeline review with your sales director and rebuilt the pipeline and renewal dashboards. Limits: you didn't own the number or its method, and no CFO-level forecast conversation is described. Pipeline data is usually a main input to a revenue forecast | `[grounded]` your message; `[generic]` forecast inputs | G2 |
| R7a | Billing data | must_have | absent | none | capability | Your own statement: you have never worked on billing data. The role is to "own our CRM and billing data" | `[grounded]` your message; posting | closure path in G3; carried as a material risk |
| R7b | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Renewal dashboards may count as revenue data. How you worked with finance, beyond finance owning the forecast, isn't described | `[grounded]` your message | G2 |
| R8 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your team's pipeline and renewal dashboards. Whether finance used them is not stated | `[grounded]` your message | a sanitized dashboard screenshot would raise this to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Bristol hybrid terms and pay (R1, R2, hard_gate) | hard_gate | No location or pay limits stated | A failed term would make this `no_go` however strong the fit | Not applicable: the question is whether the terms meet your own limits | Nothing to attach | `[grounded]` your message is silent |
| G2 | Forecast bridge and finance contact (R6, R7b, must_have) | transferability | Pipeline review, dashboards, finance owning the forecast | It decides whether R6 stays `adjacent` and R7b becomes real evidence | Pipeline figures finance took into its forecast; a regular call with a finance analyst; renewal numbers reconciled against finance's | A sanitized forecast input sheet or the renewal dashboard | `[grounded]` your message; `[inferred]` that finance used your reporting, unconfirmed |
| G3 | Billing data (R7a, must_have) | capability | No billing-data experience | The role owns billing data. This is the largest direct mismatch | Closure path: a small piece of work reconciling renewal or invoice exports with your finance team; learning the invoice, credit note and recurring revenue basics | A one-page sanitized reconciliation | `[generic]` closure path for the role family |
| G4 | Software employer (R3b, must_have) | discovery | "B2B payments company" | An automated or human screen may read the requirement literally | Product sold, whether it is software-delivered, subscription billing | Company product page | `[grounded]` your message |
| G5 | SQL and modelling depth (R5, must_have) | discovery | Usage frequency only | "Strong" and "modelling" are the posting's words | A renewal-forecast query; a model finance reused; a cohort or churn workbook | A sanitized query or workbook | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield" | The role may be listed under a different careers address, or only on the job board | `[generic]` pattern for small companies, not a claim about this one | Can you point me to this role on Quillfield's own site, and confirm Tamsin Achebe is the hiring manager? | unresolved |
| RR2 | Pay disclosed and inside the survey band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | Compensation is concrete rather than evasive | `[grounded]` posting figure; `[generic]` survey band | Where in this range would someone with my background sit? | noted |
| RR3 | Forecast ownership, team and authority unstated | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may own the forecast process but not the number, and may have no direct reports | `[inferred]` from three large responsibilities against silence on authority | Who owns the forecast number — this role, finance or the CFO — and does the role have direct reports? | unresolved |
| RR4 | Share option terms unstated | unknown | — | "plus share options" | Value depends on terms the posting doesn't give | `[grounded]` posting names options and nothing else | What are the option terms: quantity, strike price, vesting and exercise window? | unresolved |
| RR5 | First-year success measures unstated | unknown | — | "You will own our CRM and billing data, build the pipeline and renewal reporting..." | A broad mandate without stated first-year outcomes | `[inferred]` from the posting's silence on outcomes | What does success in the first year look like for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put your Salesforce admin certification, the rebuilt pipeline and renewal dashboards, and the monthly pipeline review with your sales director in the top third of your CV, worded as you described them | see R4, R8, R6 | `[grounded]` your message | `resume_edits_pending_approval` |
| E2 | Keep forecast ownership and billing-data experience off your CV and out of your pitch; state that finance owned the forecast. Add what your reporting fed into it only after G2 is answered | see R6, R7a | `[grounded]` your message | pending your approval |
| A1 | Confirm Bristol hybrid and the pay range against your own limits before investing effort | see R1, R2 | `[grounded]` gate rows | pending your approval |
| A2 | Ask the recruiter to confirm the role is live on Quillfield's own site | see RR1 | `[grounded]` register | pending your approval |
| W1 | One sanitized page reconciling renewal figures with finance's, built from your own data | see R7a, R6 | `[grounded]` G2, G3 | pending your approval |
| Q1 | Ask the verification questions of RR3, RR4 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is unconfirmed self-report, and no CV was provided. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Revenue Operations Lead" and "Quillfield invoicing software Bristol", which both returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Role reality's organization row is attributed, and RR1 carries the unconfirmed posting |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Pay band only; it moved the market calibration, R2 and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" and fetched "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Role reality's hiring-manager row; nothing about her preferences was sought |

I can save this as `tuesday-dossier.md` whenever you want it.

**Upgrade menu**

- Your location, pay floor and view on share options → R1 and R2 close, and the hard-gates line stops saying "constraints not given".
- An answer on G2 → R6 and R7b firm up, or stay adjacent and unclear with their limits named.
- A sanitized dashboard screenshot, query or workbook, and a link to your Salesforce certification → R4, R5 and R8 move toward `high`.
- Your CV → rows move from prose self-report to CV evidence, and any buried strengths show up as presentation gaps.
- The recruiter's answers on RR1, RR3, RR4 and RR5 → those entries close.
- A deeper research pass on Quillfield, covering leadership churn, funding and public employee reports (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 (R1, R2) — Do two office days a week in Bristol and a £61,500–£67,000 base meet your own limits?

G2 (R6, R7b) — In the forecast finance owned, did your pipeline reporting feed it? What did you supply, to whom in finance, and how often?

G3 (R3b) — How would you describe what your current company sells: software, payment services, or both?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.