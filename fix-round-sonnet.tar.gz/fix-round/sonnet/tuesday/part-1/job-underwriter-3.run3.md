Web search wasn't permitted in this session, so the employer and pay-band checks didn't run. This assessment rests on the posting and your message alone.

## Decision snapshot

**No, not worth pursuing as posted: R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin, 5 days a week), R2 (Base pay $70–85k)
- `must_have`: direct: R3, R4, R5, R6
- `important`: unclear: R7 (SEO and content), R8 (Brand, PR, partnerships), R9 (Sales ops), R10 (Team of one, no bench)

R1 and R2 — failed terms, not experience gaps; R3, R4, R5 and R6 — where your background lines up; R7, R8, R9 and R10 — breadth the posting asks of one person that your history doesn't show.

**Opportunity ledger.** The role is weak on its own terms before your constraints apply: a team of one covering many functions (RR4), no stated budget or authority (RR5), pay against 8+ years (RR3), always-on language (RR6), and success metrics that "will evolve" (RR7). The one positive, profitability, is a claim nobody has checked (RR9), and the employer itself is unverified (RR8).

- **Hard gates:** failed: R1 (On-site in Austin, 5 days a week), R2 (Base pay $70–85k)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** the posting's terms would have to differ, with remote or Portland-based work (R1) and a base of at least $150k (R2). The posting says "no exceptions" on location and gives no sign the pay band moves.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; existence and profitability unverified |
| Mandate | All revenue growth, end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | "A team of one to start"; reports to the CEO, dotted line to the board | `[grounded]` JD |
| Working pattern | On-site Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside"; no equity figures | `[grounded]` JD |
| Success metrics | None stated; "will evolve as we learn" | `[grounded]` JD |
| Scope read | Reads as several specialist roles under one title with no support staff | `[inferred]` from the function count against "team of one" |
| Market calibration | Not established: the role-family search was refused, so no band is quoted | `[generic]` no figure claimed |
| Unknowns | Marketing budget, who the customers are (merchants or consumers), revenue and runway, equity terms | `[grounded]` JD silence |
| Contradictions | A board-level dotted line sits beside a team of one and a pay band this low | `[inferred]` from the JD's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated limit (remote-only, Portland, not relocating), which is specific and yours. Fit fails because the posting rules remote work out | `[grounded]` JD quote and your statement | Surface only; the employer changing terms is the one resolution |
| R2 | Base pay $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k floor, which is specific and yours. Fit fails because the top of the band is below it | `[grounded]` JD quote and your statement | Surface only; the employer changing terms is the one resolution |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years, as growth lead then Head of Growth at two companies. Self-reported with nothing inspectable yet, so expect a probe | `[grounded]` your message | A resume or profile with dates and titles would raise to high |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at both companies. Confirmed and specific, but no artifact yet | `[grounded]` your message | A channel report or budget summary would raise to high |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. No artifact yet | `[grounded]` your message | A lifecycle program summary would raise to high |
| R6 | Own revenue growth end to end, with budget | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. The posting doesn't say whether buyers are merchants or consumers, so transfer from B2C subscription is unestablished | `[grounded]` your message; `[grounded]` JD silence on buyer type | A sanitized revenue-growth summary would raise to high |
| R7 | SEO/content | important | unclear | low | discovery | Your message names paid, lifecycle, experimentation, SQL, GA4 and Braze, and says nothing on SEO or content. Silence is not absence | `[grounded]` your message's silence | See G1 |
| R8 | Brand, PR, partnerships | important | unclear | low | discovery | Same silence across all three functions | `[grounded]` your message's silence | See G2 |
| R9 | Sales ops | important | unclear | low | discovery | Same silence | `[grounded]` your message's silence | See G2 |
| R10 | Working as a team of one, with no bench | important | unclear | low | discovery | You managed teams of 3–7; whether you also executed channels hands-on is not stated | `[grounded]` your message | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content (R7, important) | discovery | No mention of organic or content work | Moot while R1 and R2 stand; it would matter only if terms changed | Owning a content calendar, running technical SEO fixes, managing an agency for organic growth | Search Console export, a content calendar, an organic-traffic trend | `[grounded]` your message's silence |
| G2 | Brand, PR, partnerships, sales ops (R8, R9, important) | discovery | Nothing on these four | Moot while R1 and R2 stand; a candidate for the first thing dropped or hired out in a solo role | Launching a referral or affiliate partnership, handling press coverage, setting up CRM routing for a sales team | A partnership agreement, press links, a pipeline dashboard | `[grounded]` your message's silence |
| G3 | Hands-on solo execution (R10, important) | discovery | Team management shown, individual execution not | Moot while R1 and R2 stand | Periods running a channel yourself before or between hires | A before/after channel report from a period with no team | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site five days against remote-only (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | Incompatible with your stated constraint | `[grounded]` JD quote and your statement | Is five days on-site a fixed term for this role, as the posting says? | unresolved |
| RR2 | Base below your floor (R2) | red_flag | high | "$70–85k base" | Incompatible with your $150k floor | `[grounded]` JD quote and your statement | Is the $70–85k base a fixed range for this role? | unresolved |
| RR3 | Seniority–compensation mismatch | risk_signal | medium | "8+ years growth leadership required" with "$70–85k base" | The mandate may be priced as a junior or mid-level role. No market band was fetched, so medium, not high | `[inferred]` from the JD's years and scope against its stated band | How was this band set for an 8+ year role covering this many functions, and what does "meaningful equity" mean in percent, vesting and strike price? | unresolved |
| RR4 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several full roles folded into one title | `[inferred]` from the function count against "team of one" | Which of these functions matter most in the first six months, and who covers the rest? | unresolved |
| RR5 | Responsibility without stated resources | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench." | Accountability for revenue with no stated budget, hires or decision rights | `[inferred]` from the JD's silence on budget and authority | What marketing budget and hiring plan are committed, and who approves spend? | unresolved |
| RR6 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work is treated as a baseline, not an exception | `[inferred]` from the JD's wording | In the last quarter, how many evenings or weekends did the team work, and how is that time recovered? | unresolved |
| RR7 | No success definition on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be held to targets nobody wrote down | `[inferred]` from the JD's wording | What would "working" look like at 90 days and at 12 months? | unresolved |
| RR8 | Employer not established | risk_signal | low | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The employer check never ran, since search was refused. Low because that reflects the tooling, not evidence against the company | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Profitability claim | positive_signal | — | "profitable since day one" | If true, the company isn't dependent on its next raise | `[grounded]` JD states it; unverified | Can you share a revenue range and current runway? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Do not apply as posted | see R1, R2 | `[grounded]` the two failed gate rows | pending your approval |
| P2 | If you decide to proceed anyway, ask RR1 and RR2 verbatim before spending any application effort | The register's questions become essential if you proceed against `no_go` | `[grounded]` register | pending your approval |

No resume edits are proposed, so there is nothing under `resume_edits_pending_approval`.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search for Novaline's site and posting was refused. It would have moved role reality's organization row and RR8 |
| 2. Role-family sweep | unavailable | One search for Head of Growth pay bands was refused. It would have moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | The posting names no one beyond "the CEO", so there was no query to form |

## Upgrade menu

- Permission to run web searches: the employer check closes RR8 and a pay band firms up RR3.
- The posting's link on Novaline's own careers page: RR8 closes without a search.
- A resume or profile with dates and titles: R3 moves to `high`.
- A sanitized growth summary or channel reports: R4, R5 and R6 move to `high`.
- Any SEO, content, brand, partnership or sales-ops work you've done: G1 and G2 resolve R7, R8 and R9.
- The CEO's name: role reality's scope read and the plan's framing would sharpen.

I can save this as `tuesday-dossier.md` if you want a record to carry forward.

I'm asking no questions this turn: the decision rests on R1 and R2, which the posting fixes, so no answer you could give would move it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.