Web search was declined, so everything below rests on the JD and your summary alone.

## Decision snapshot

**Yes, apply, on conditions. Your must-have evidence (R2, R3, R4, R5, R6, R7a) is direct, and R1 (UK location) is unconfirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK-based)
- `must_have` — direct: R2, R3, R4, R5, R6, R7a
- `important` — unclear: R7b (Recommendations for product)
- `preferred` — direct: R8

R7b — product-facing recommendations are not yet evidenced; R6 — running the tests versus designing them is not settled; R8 — your insurance experience is motor, not pet.

**Opportunity ledger.** The mandate is concrete and sits under a Director of Pricing (RR4). Compensation is withheld (RR1), the employer could not be checked because research did not run (RR2), and team and resourcing are unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR2; (2) UK location and right to work are confirmed, see R1; (3) team size, resourcing and salary prove acceptable, see RR1 and RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Not verified: research did not run | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Line management | The JD lists none, so "never managed anyone" is not a stated gap | `[grounded]` JD silent |
| Scope read | A hands-on senior individual-contributor post spanning modelling, test design and stakeholder recommendations | `[inferred]` from the JD's verbs (own, build, monitor, design, read) |
| Market calibration | Not calibrated: the role-family sweep did not run and the posting gives no salary | `[grounded]` JD silent; sweep unavailable |
| Unknowns | Salary, team size, contract type, data maturity of the pet book, tooling stack | `[grounded]` JD silent on each |
| Contradictions | None between the JD and your summary. The employer-side check could not run | `[grounded]` the two inputs compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | The posting states the term. Your location and right to work are not stated. A UK motor insurer suggests UK-based but does not establish it | `[grounded]` JD; `[inferred]` UK-based from your UK employer | G3 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, the last two as senior analyst. Your own account, nothing inspected | `[grounded]` your summary | Upgrade menu: your CV |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. "Strong" is a level no artifact shows. Roles like this often include a technical exercise | `[grounded]` your summary; `[generic]` on the exercise | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Which parts were yours (variable selection, validation, deployment) is not stated | `[grounded]` your summary | none |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" is your wording. Monitoring practice (metrics, cadence) is not stated and not assumed | `[grounded]` your summary | none |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. "Ran" is kept as stated. Whether you designed them (hypothesis, split, sizing) is not stated | `[grounded]` your summary | G2 |
| R7a | Recommendations for underwriting | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting and ran the tests with the underwriting team | `[grounded]` your summary | none |
| R7b | Recommendations for product | important | unclear | low | discovery | Nothing in your summary touches a product team. The underwriting work is adjacent context only | `[grounded]` your summary silent | G1 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance is insurance experience. Pet-specific rating (breed, age, vet-cost trends) is not exercised, and risk factors differ from motor | `[grounded]` your summary; `[generic]` on pet versus motor | Prepare an honest bridge, see A3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product-facing recommendations (R7b, important) | discovery | Underwriting audience is clear; no product audience mentioned | The JD names product as a second audience for your recommendations | A pricing change taken to a product or propositions team; test results that shaped a feature, cover level or excess; a partner or distribution team asking for pricing input | A slide, a pricing-review excerpt, a decision note | `[grounded]` summary silent; `[inferred]` that this could lift R7b |
| G2 | Price-test design ownership (R6, must_have) | discovery | "Ran 14 price tests" with underwriting; design role not stated | Designing and reading tests is a named duty, and "ran" can mean either | Writing the hypothesis; setting test and control splits; sizing the sample; choosing the success measure and reading the result | A sanitized test readout or design template | `[grounded]` summary says "ran" only |
| G3 | UK location and right to work (R1, hard_gate) | hard_gate | Not stated | A gate the inputs do not settle | n/a, this is a term and not experience | None needed | `[grounded]` summary silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Compensation withheld | unknown | — | The JD states no salary | The figure may be below what the seniority commands, or may simply be unpublished | `[inferred]` from the posting's silence | What is the salary range for this post? | unresolved |
| RR2 | Employer not established from attributable sources | risk_signal | low | "Brindlemoor (insurtech)" | The company may be too new or small for a footprint, or the posting may be stale. Severity is low because research did not run, so nothing was found against it | `[generic]` pattern for companies of this size, not a claim about this one | Is this role live on your careers site, and who would I be interviewing with? | unresolved |
| RR3 | Team and resourcing unstated for an "own" mandate | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be the only pricing analyst, with data and tooling still to build | `[inferred]` from the JD's scope language against its silence on team | How big is the pricing team, and what data and tooling exist for the pet book? | unresolved |
| RR4 | Concrete duties and a Director-level reporting line | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is defined and the manager is senior | `[grounded]` JD, and the reporting line you gave | What does success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the GLM you built and maintained (R4), the 14 price tests you ran with underwriting (R6), and the quarterly review you present to the head of underwriting (R7a), in your own wording | These rows are direct | `[grounded]` R4, R6, R7a | pending your approval |
| A2 | Do not say you "designed" the tests until G2 is answered, and say nothing about product work until G1 is | Ambiguity resolves downward | `[grounded]` R6, R7b | pending your approval |
| A3 | Say plainly that your rating work was young-driver motor and that you are new to pet. Name what you would learn first | Honest adjacency reads stronger than a claimed fit | `[generic]` how interviewers probe domain gaps | pending your approval |
| A4 | Ask the RR1 to RR4 questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for Brindlemoor's careers and product was sent and refused. It would have moved the organization and contradictions rows and RR2 |
| 2. Role-family sweep | unavailable | A UK senior pricing analyst salary search was sent and refused. It would have moved market calibration and the RR1 comparison |
| 3. Hiring manager's public footprint | unavailable | A search on the name you gave was sent and refused. It would have moved the scope read and A1's positioning |

I'll save this as `tuesday-dossier.md` if you want to carry it into later steps.

**Upgrade menu**

- Your CV, plus a sanitized model-documentation page, a test readout or a pricing-review deck, would lift R4, R5, R6 and R7a toward `high`.
- Answers to G1 to G3 settle R1, R6 and R7b.
- Permission to search, or the Brindlemoor careers link pasted in, would run targets 1 to 3 and close RR2. A deeper pass (up to 5 more searches and 2 more fetches) is then available once.
- The salary range would close RR1.

**Questions**

G3 — Are you UK-based and able to work for a UK employer remotely without sponsorship?

G2 — Of the 14 price tests, which did you design yourself (hypothesis, test and control split, sample size, success measure), and which did you run from someone else's design?

G1 — Have you taken pricing results to a product or propositions team? What did you recommend, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.