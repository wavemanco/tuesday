Web search was declined, so this runs on your JD and background alone.

## Decision snapshot

**Yes, worth applying to, once two things check out: R1 (UK-based, fully remote) is unconfirmed and RR3 (employer not verified) is open. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R9 (Pet-insurance domain knowledge)
- `preferred`: direct: R8

R4 (`medium`): your GLM work is on motor, not pet; R9 (`medium`): a bridge with its limit named; R1: nothing stated yet.

**Opportunity ledger.** The remit is concrete (RR4). Salary is withheld (RR1), people-management scope is unstated (RR2), and the employer is unchecked because no research ran (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) employer and live posting verified, see RR3; (2) UK-based remote working confirmed, see R1; (3) pet insurance framed as adjacent, never as pet expertise, see R9; (4) no expectation to line-manage, see RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Not independently verified | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Hiring manager is Odile Varga, Director of Pricing | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| People management | The JD lists no direct reports and no management requirement; the title is Senior Analyst, not Manager | `[grounded]` JD silence; `[inferred]` that this is an individual-contributor post |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Market calibration | Not run. The role-family sweep was refused, so no band is offered. Salary is withheld (RR1) and your pay floor is unknown | `[grounded]` JD withholds salary |
| Contradictions | None visible inside the JD. It was not checked against a careers page | `[grounded]` JD only |
| Unknowns | Salary; team size and reports; who owns the product-side decisions; employer stage and funding | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | You work at a UK insurer, but your location, right to work and remote preference are not stated. Confidence grades your own statement, which is absent | `[grounded]` UK employer; `[inferred]` UK residence from it | Gap G2's question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, clear of the 4-year line. Self-reported background, nothing inspected | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" rests on your word, with no inspectable artifact | `[grounded]` your background | A sanitized query or notebook would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Limit: it is a motor model, not pet | `[grounded]` your background | none |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers building. Monitoring (drift, actual vs expected) is not stated separately, so the claim is read at its lower reading | `[grounded]` your background | Be ready to say what monitoring you ran yourself |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year, run with the underwriting team | `[grounded]` your background | A redacted test readout would raise it to `high` |
| R7 | Present to underwriting or actuarial leads; turn results into recommendations for underwriting and product | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Recommendations to a product team are not stated, which is the limit | `[grounded]` your background | Ask in the loop who the product counterpart is (RR4) |
| R8 | Insurance experience a plus | preferred | direct | medium | none | 5 years at a motor insurer. The JD asks for insurance, not pet | `[grounded]` JD and your background | none |
| R9 | Pet-insurance domain knowledge (not listed in the JD as a requirement) | important | adjacent | medium | transferability | Pricing method carries over. You have no pet-specific work, so the limit is the pet-specific rating drivers and claims patterns, which you have not worked with. The bridge is the 14 tests and the GLM build | `[inferred]` from the role's stated product against your motor-only history; `[generic]` that pet and motor differ in rating drivers | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance domain (R9, important) | transferability | Motor GLM and price-test work, no pet exposure stated | Likeliest objection from a pricing director hiring for a pet product | Renewal or retention pricing; claims-cost trend or inflation analysis; any non-motor or add-on product; work on a high-frequency, low-severity book | A redacted model document, a test readout, or a quarterly review deck extract | `[inferred]` bridge from your stated work; `[generic]` that domain fit is the usual objection |
| G2 | UK remote working (R1, hard_gate) | hard_gate | Nothing stated about location or right to work | A gate; the one question allowed is whether it is met | Not applicable, this is a fact | None needed | `[grounded]` input silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary withheld | unknown | — | JD gives no figure | May sit below what a senior pricing post pays, or simply be unpublished | `[inferred]` from the JD's silence | What salary range is budgeted for this role? | unresolved |
| RR2 | People-management scope unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" and "Senior" might carry direct reports later; the JD lists none | `[inferred]` from the title and the JD's silence on reports | Does this role have direct reports now or planned, and who does it report to? | unresolved |
| RR3 | Employer not established from attributable sources | risk_signal | low | "Brindlemoor (insurtech)" | No check ran, so nothing was found either way. The company may simply be new or small | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Brindlemoor's own careers site, and who would I be interviewing with? | unresolved |
| RR4 | Concrete remit: models, tests, recommendations | positive_signal | — | "build and monitor rating models, design and read price tests" | The work is defined and matches your recent work | `[grounded]` JD | Which decisions do your recommendations feed: underwriting, product, or both, and who signs off? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on Brindlemoor's own careers page, or ask the recruiter, before investing effort | see RR3 | `[grounded]` RR3 | pending your approval |
| P1 | Lead with these three facts, kept to your own wording: you built and maintained the GLM rating model for the young-driver book; you ran 14 price tests last year with the underwriting team; you present the quarterly pricing review to the head of underwriting. Frame pet as new to you, not as experience | see R4, R6, R7, R9 | `[grounded]` your three statements | pending your approval |
| Q1 | Ask RR1 to RR4's questions verbatim in the loop, including the reports question for RR2, since you have not managed anyone | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst". It would have moved role reality's organization and contradictions rows and RR3 |
| 2. Role-family sweep | unavailable | One search was refused: "senior pricing analyst pet insurance UK salary remote". It would have moved the market calibration row and RR1 |
| 3. Hiring manager's public footprint | unavailable | One search was refused: "Odile Varga Director of Pricing". It would have moved role reality's scope read and which story P1 leads with |

One-line offer: I can write a `tuesday-dossier.md` for this role if you want it kept.

## Upgrade menu

- Allow web search and I will run the three targets above, which would settle RR3 and add a salary band for RR1.
- A redacted query, model document or test readout → R3, R4 or R6 to `high`.
- Odile's reply on reports, salary and employer → RR1, RR2 and RR3 close.

Answers to these three would sharpen the call. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

- G2 — Are you UK-based with the right to work in the UK, and happy with fully remote?
- G1 — Have you touched renewal pricing, claims-cost trend work, or any non-motor product, and what did you personally own?
- RR1 — What salary floor or other non-negotiables should I check this role against?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.