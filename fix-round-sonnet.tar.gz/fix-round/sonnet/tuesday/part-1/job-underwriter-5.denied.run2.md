I'm loading the playbook's references, which I've now read. Next I'll run a quick live check that the Pellucid posting and company details are real and current, then deliver the assessment.
**Yes, this is worth applying to, on conditions. Status: `conditional_go`.**

I couldn't check the posting or company live, because my web fetch and search calls were refused. I worked from your pasted text and the recruiter's pay report, and labeled each derived statement accordingly.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R8, R9
- `important` — adjacent: R7 (BigQuery warehouse); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R3, R4, R5, R6, R8, R9 — your stated background meets each as worded; R7 (`medium`) — a Snowflake-to-BigQuery bridge with a named limit; R10, R11 — your summary is silent; R1, R2 — gates waiting on your answers.

**Opportunity ledger.** The pay is stated and sits around the market median (RR3). Four things are unknown or unverified: whether one person would own the whole stack (RR2), who the manager is (RR5), the equity terms (RR4), and the employer details, which I couldn't check independently (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) location and your pay floor confirmed as workable — R1, R2; (2) the posting confirmed live on the company's own careers page — RR1; (3) the scope and team confirmed in the screen — RR2, RR5; (4) BigQuery framed as adjacent experience, never as experience you have — R7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, Denver, founded 2016, 264 employees, Series C ($52M, February 2026) | `[grounded]` the About text you pasted; not independently checked (RR1) |
| Mandate | Build and run the pipelines behind tutoring-platform reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts rely on | `[grounded]` JD |
| Seniority | 5+ years, which sits inside the report's typical 5–8 years for "Senior"; your 6 years fall in the same range | `[grounded]` JD and the Datawright report |
| Pay calibration | The base of $148,000 is $3,000 below the report's $151,000 median for Series B–D Senior Data Engineers. The top of $166,000 is $2,500 above the interquartile range's $163,500. Series C is inside the report's cohort | `[grounded]` JD and the Datawright report; the report is your recruiter's, n=2,310, never this employer's offer |
| Scope read | Ingestion, modelling, quality and contracts together look broader than the report's typical "one domain's pipelines, no direct reports" | `[inferred]` from the JD's four named areas set against the report's typical scope |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Team size, reporting line, hiring manager (not named), equity size and vesting, contract basis | `[grounded]` JD silent on each |
| Contradictions | None found between the JD and the About text, but neither was checked against the live site | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you live or whether you'd relocate, so the gate can't be checked | `[grounded]` JD; your location not given | Closing question R1, R2 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The band is stated, but I don't have your minimum, and the equity terms are unstated | `[grounded]` JD; your floor not given | Closing question R1, R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company; confirmed and specific, with no inspectable artifact yet | `[grounded]` your background as you described it | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated. "Strong" is judged by depth, which a screen would probe | `[grounded]` your summary; `[generic]` that screens probe depth on this requirement | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. A sanitized project doc or lineage view would raise this to `high` | `[grounded]` your summary | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake meets "a cloud warehouse" as the requirements line words it. The BigQuery question sits in R7 | `[grounded]` JD wording and your Snowflake work | none |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated by name | `[grounded]` your summary | none |
| R9 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. Whether you own it day to day isn't stated | `[grounded]` your summary | none |
| R7 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Your dbt modelling carries over. The limit is that you have never used BigQuery, so its pricing, partitioning and nested-data behaviour are unexercised | `[grounded]` your summary; `[generic]` that BigQuery differs from Snowflake on those points | Gap G3 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your summary doesn't say what you ingested or from where | `[grounded]` your summary silent | Closing question G1 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing in your summary mentions contracts or SLAs with downstream analysts | `[grounded]` your summary silent | Closing question G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R10, important) | discovery | Pipelines and Airflow are stated, but not what the sources were | It is the first item in the mandate, and the answer would turn R10 from `unclear` to `direct` or `adjacent` | Event or product-database ingestion; a Salesforce or HubSpot-style sync; an ingestion tool or custom loaders you chose or built | A sanitized architecture diagram or DAG list | `[grounded]` your summary silent; `[inferred]` that the answer moves R10 |
| G2 | Data contracts (R11, important) | discovery | No mention of schema agreements, SLAs or consumer-facing guarantees | The JD names contracts as a deliverable analysts depend on | dbt contracts or tests that gate model changes; agreed schemas or freshness SLAs with analysts; a change-notification process | A sanitized contract spec, dbt YAML excerpt or runbook | `[grounded]` your summary silent; `[inferred]` from the JD's wording |
| G3 | BigQuery (R7, important) | transferability | Strong dbt and warehouse modelling on Snowflake; no BigQuery use | It is the stated platform; a visible bridge narrows the likeliest objection | A small dbt-on-BigQuery project, even a personal one, with partitioning and cost choices explained | A repo link or write-up | `[inferred]` bridge from Snowflake dbt work; `[generic]` that platform-specific probing is likely |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not independently verified | risk_signal | low | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The text came from the company's own site and describes a mid-sized company, so a footprint is likely. Severity is low because of that, but I couldn't confirm the posting is live | `[generic]` pattern: unverified postings are cheap to rule out, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope may exceed one domain | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | One person may own ingestion, modelling, quality and contracts. The report's typical senior scope is one domain with no reports | `[inferred]` from the JD's four areas against the report's typical scope | How many data engineers are on the team, and which of these areas does this role own alone? | unresolved |
| RR3 | Pay stated and near market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The stated band is a real signal of transparency, and sits around the report's median | `[grounded]` JD and Datawright report | Where in the band would my experience place me? | noted |
| RR4 | Equity unquantified | unknown | — | "plus equity" | The grant size, vesting and strike are unstated, so total pay can't be judged | `[grounded]` JD silent | What is the equity range at this level, and its vesting schedule? | unresolved |
| RR5 | No hiring manager named | unknown | — | The posting names no hiring manager | The reporting line and the manager's background are unknown | `[grounded]` posting silent | Who would I report to, and what is their data background? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| Q1 | Ask the RR1–RR5 questions verbatim in the screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | Build a small, honest dbt-on-BigQuery project and describe it as exactly that | See R7, G3; never claim BigQuery work experience | `[grounded]` R7 row | pending your approval |
| A1 | Confirm location and your pay floor against the posting before investing in an application | See R1, R2 | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Lead with the dbt project (about 180 models) and the Great Expectations suite, stated at the scope you described | See R5, R9 | `[grounded]` your summary | pending your approval |

Nothing here is final until you approve it, and that covers the advice as well as the table.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The fetch of the posting page and the company search were both refused, so the posting's currency and the company's details are unchecked. It would have moved RR1 and the contradictions row in role reality |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration and the pay mismatch check |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

## Closing

I can write this up as `tuesday-dossier.md` for later use if you want it.

**Upgrade menu**
- Your location and pay minimum → R1 and R2 close, and the decision likely moves to `go` or `no_go`.
- A sanitized dbt project doc and Great Expectations suite listing → R5 and R9 to `high`.
- Answers to G1 and G2 → R10 and R11 firm up.
- A BigQuery write-up or repo → G3 narrows.
- Web access, which this run's calls were refused → the live-posting and employer check; a deeper pass would add up to 5 more searches and 2 more fetches.
- The hiring manager's name, once known → role reality's scope read and which of your stories to lead with.

**Questions**
- R1, R2 — Do the posting's location terms (Remote US or Denver) and its $148,000–$166,000 base both work for you?
- G1 — What data sources did you ingest at the payroll company, and which parts did you own?
- G2 — Did you set any schema or freshness agreements with analysts or other consumers, and how were they enforced?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.