I'll read the references directly.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-canned-c0d56cc6/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It has a mini-pack for each of the three rounds on 20 November (27 questions), the four-values cheat sheet, and a prep schedule for the nine days.

I built it from your message as the only record of your history. No searches were run, because your pasted values, the recruiter's email, the strategy points and the JD already covered what research would have supplied.

- **Highest-ROI prep:** question 2B1. The Head of Member Services is the person most likely to press you on "you've never worked in a contact centre". The pack has you concede it plainly, name the limit before they ask, then give a plan.
- **Other stated gap:** question 1B3, presenting above regional level, gets the same concede-then-plan treatment.
- **Where your evidence is thin:** several of your requirements rest on one or two sentences of yours. They are the complaints log (regulated complaints, ownership across branches), the monthly spreadsheet (reporting and Excel) and the teller training (coaching supervisors). On these the pack gives answer slots rather than invented stories. Settle each from your own memory, including "that wasn't mine" where it's true.
- **Round 3 case:** the 20-minute escalation case is rehearsed at 3D1 to 3D3. The pack also notes that the 2027 plan to merge eight branches into five hubs will probably be in the room with two branch managers, so Neighbours, Not Numbers (3C3) is the value to prepare for that.

Say the word and I'll play the Skeptic on 2B1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Would you like to paste your CV, or just its complaints, reporting and training lines? I'd turn the slots in F2, F3 and F5 to F7 into quoted evidence; without it the pack stands as built.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds on 20 November 2026, prepared on 11 November 2026.

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter (name not given) | 30 minutes | "30 minutes with me" |
| 2 | Head of Member Services, your future manager (name not given) | 45 minutes | "mostly behavioural" |
| 3 | Panel of two branch managers (names not given) | 60 minutes | "including a 20-minute case on a complaint escalation"; "The panel is also the values round — they score against the four values" |

Built from your message as the only record of your history, with the JD, the four values as you copied them on 11 November 2026, the recruiter's email and the points you gave from the July 2026 strategy brief. No interviewer names exist yet, so there is no interviewer read.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows one of Ashgrove's published values |
| EXP | Whether what you say you did holds up, and what was actually yours |
| JD | The job as the posting states it, including its gaps |
| CO | How well you know Ashgrove's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. You choose the branch from your own memory. "Say so plainly" is always an allowed branch, and it is usually the stronger one under a second question.

## Prep triage (nine days: 11 to 19 November)

| Order | Do this | Where | When |
|---|---|---|---|
| 1 | Rehearse the contact-centre answer aloud until it is boring: concede, name the limit, give the plan | 2B1, with the short form at 1B1 | 11 to 13 Nov |
| 2 | Settle your answers to the slots in F2, F3, F5, F6 and F7 from your own memory, in your own words, including "that was not mine" where true | 1B2, 2B2, 2C1, 2C3, 3C4 | 11 to 14 Nov |
| 3 | Run the 20-minute case aloud against a timer: 3D1 twice, then 3D2 and 3D3 once each | Round 3 bank | 15 to 17 Nov |
| 4 | For each of the four values, pick one real instance or settle on the honest branch | 3C1 to 3C4 and the cheat sheet | 17 to 18 Nov |
| 5 | Say the senior-presenting acknowledgment and its plan aloud once | 1B3, 2C2 | 18 Nov |
| 6 | Read the reverse questions for the round the next day | Reverse questions in each round | 19 Nov |

Everything else is insurance.

## Fit snapshot

No row is a hard gate: the JD as you pasted it states no term such as a licence, location, schedule or pay. The one question that would change that is whether the JD has anything you did not paste.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on years: the quote states six against the JD's four. It is a message line with nothing inspected behind it, so expect a probe on what the years held. Say it in the quote's own terms, six years in retail banking and the last three as a branch supervisor, and leave the mapping to the JD's phrase to them |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal complaints log at one branch, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's wording makes a probe on which rules or timescales applied to the log likely. If outside rules or deadlines governed how it was kept, say which and what part you carried; if none did, or you kept a record rather than ran a process, say so plainly and stay with the log |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Adjacent work that does not reach the requirement: your material shows one branch's log, not the process around it and not other branches. The words stay at that scope: "I handled the branch's formal complaints log." Answer slot: if any part of the process before or after the log was yours to run, say which part and how you decided; if the log was the part you held, say so plainly and stay with it |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past: who you would sit with and what you would ask first. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote shows a monthly complaints spreadsheet you built that your regional manager uses; it does not show what the spreadsheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's reporting line makes a probe on what it counted likely. Say what it counted and how, in your own words; if what went into it was set by someone else, or it held nothing you would call a count, say so plainly and stay with the spreadsheet you built |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet. The pack resolves that downward and does not name the tool for you. Answer slot: say which tool you built it in and what you built in it, in your own words; if it was another tool, or part of it was built for you, say so plainly and stay with the spreadsheet you built |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Adjacent work that does not reach the requirement: the quote is new tellers and a script. The words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on who your training reached and what you taught likely. Say who it reached and what you taught, in your own words; if it reached only new tellers, say so plainly and stay with that |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this, which is not a stated absence. Answer slot: if you have worked with a digital or product team on anything members used to do for themselves, say what it was and what part was yours; if not, say so plainly, and say what you would ask a digital team first |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Nothing added to make the gap smaller |

## Prohibited claims

Built from the snapshot before the banks were written. No guidance cell, slot, hold, bridge or rationale in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: your material says a formal complaints log, not a regulated process. The slot at 1B2 stays inside the log |
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope. Your material says one branch's log. The slot at 2B2 stays inside the log |
| Has worked in a contact centre | Negative you stated, F4 | The plain acknowledgment F4 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment F9 gives: "I've never presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: new tellers and the escalation script. The slot at 2C1 stays inside the training |
| Reported on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: a monthly complaints spreadsheet your regional manager uses. The slot at 2C3 asks only what it counted |
| Built the reporting in Excel | Inflated form of F6 | F6's quote at its own scope: a spreadsheet. The tool is yours to name |

## Grounding brief

Only what you gave me from the July 2026 strategy brief, plus the JD's description of the organisation. I do not hold the brief's own text. Each line is a prompt for a question to ask, not a finding.

| Item | Source | How to use it |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | July 2026 strategy brief, as you gave it | Ask whether complaints sit inside that 40% (2D1, 2R3) |
| Consolidate eight branches into five hubs over 2027 | July 2026 strategy brief, as you gave it | Expect it in the room with branch managers (3D2, 3R3) |
| Launch a small-business lending product in Q1 2027 | July 2026 strategy brief, as you gave it | A new set of members for the complaints process (3D3) |
| Main competitive pressure is app-only banks | July 2026 strategy brief, as you gave it | The reason self-service journeys matter to this role; use it to frame 1A2 and 2D1, and do not assert more than the brief says |
| Member-owned, about 900 staff | JD | Use "member-owned" in your own motivation answer (1A2) |

The brief was four months old on 11 November 2026, so ask the recruiter whether anything in it has moved.

---

# Round 1: the recruiter (30 minutes)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | A friendly, unstructured chat that feels unscored | Dominant. The recruiter's email says "30 minutes with me", and the recruiter-screen prior is Conversational plus a light Skeptic | A 90-second arc rehearsed in advance; treat casual questions about JD topics as scored; never answer "I think you've covered everything" at the reverse-question slot |
| Skeptic | Quiet checks on the gaps: contact centre, the regulated-complaints wording, senior presenting | Light. Same prior; F4 and F9 are stated gaps that a screen checks first | Rehearse the plain acknowledgment and the plan until they are unremarkable |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in three beats, each a clause the quotes state: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you built the monthly complaints spreadsheet your regional manager uses. Add why this role, in your own words; the pack does not supply your reason. Stop at what the quotes say, since follow-ups are where detail belongs | Casual openers are scored. F1 gives the spine and F2 and F5 the two complaints clauses; EXP because it tests what the lines carry |
| 1A2 | "What drew you to Ashgrove specifically?" | CO | [grounded] | Use only what Ashgrove has published: the member-owned model the JD names, the four values by their official names, and one or two points from the strategy brief, such as digital service by 2028 or the move to five hubs. Say which one matters to you and why, in your own words; your reason is yours. Do not praise a value you cannot connect to something you have done | Recruiters score homework and motivation, and the values page and brief are the two provided sources for it. CO because it tests company knowledge |
| 1A3 | "What are you looking for in your next role, and why now?" | JD | [grounded] "I handled the branch's formal complaints log" | Move from what the quote states to what the JD offers: you handled the branch's formal complaints log, and this role is the member complaints process across branches and the contact centre. Say why now in your own words. Name the contact centre in the sentence yourself rather than leaving it to be raised | A motivation-consistency probe. F3 is the step the move covers, and F4 is why naming the contact centre first helps; JD because it tests fit with the stated role |
| 1A4 | "Where are you on salary expectations and notice period?" | JD | [generic] | Have your own figure and your own notice period ready; they are facts only you hold and the pack does not supply them. The JD text you gave states no range, so ask what the band is before you name a number, then answer from your own floor. Say the number once, plainly | Screens carry knockouts and this one is easy to treat as unscored. JD because it checks the terms of the role; generic because it is a pattern for the screen, not a fact about Ashgrove |
| 1A5 | "Give me the thirty-second version of your complaints experience." | JD | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses"; "trained new tellers on our escalation script" | Three clauses, each the quote's own: you handled the branch's formal complaints log; you built the monthly complaints spreadsheet your regional manager uses; you trained new tellers on our escalation script. Say them in that order and stop there, because a wider description is where probes begin | Three of the JD's requirements converge on this question; F2, F5 and F7 are the rows it draws on. JD because it scores stated responsibilities |
| 1B1 | "The JD has you covering the contact centre, and I understand you've not worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre" | The short form of the rehearsal built at 2B1. Say it first and plainly: "I've never worked in a contact centre." Then one sentence of plan, said as a plan. Leave the longer build for the manager's round | F4 is a stated gap a screen checks early; the full rehearsal sits at 2B1 because the manager is likelier to press it. JD because it tests a stated requirement |
| 1B2 | "The JD asks for experience handling regulated complaints. Where does your experience sit against that?" | JD | [grounded] "I handled the branch's formal complaints log" | Open with the quote at its scope: "I handled the branch's formal complaints log." Answer slot: the JD's wording makes a probe on which rules or timescales applied likely. If outside rules or deadlines governed how the log was kept, say which and what part you carried; if none did, or you kept a record rather than ran a process, say so plainly and stay with the log | F2 is the requirement's only evidence and the likeliest place to be pressed; JD because it scores a stated requirement |
| 1B3 | "This role presents to senior leaders. How comfortable are you with that?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment first, in your words: "I've never presented to anyone above regional level." Then how you would prepare, as a plan and never as a past: find out who will be in the room, what they need to decide and how long you have, and practise aloud with someone who will interrupt. Do not describe presentations you have not given | F9 is a stated gap; JD because it scores a stated requirement |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1R1 | "What does the 20-minute case start from: something sent beforehand, something read out on the day, or something I bring?" | The email says a case exists but not its format. If something arrives beforehand, it is an announced deliverable and earns its own build in this pack |
| 1R2 | "Who will be on the panel, and could you share their names or roles?" | One line to ask. If answered, the pack can read their public professional footprint and tune the round-three personas |
| 1R3 | "What does the Head of Member Services most want from this hire in the first quarter?" | It asks the one person in the loop who may have spoken to the hiring manager, and tells you what round two is listening for. If they cannot say, you have lost nothing |
| 1R4 | "Is there anything in my background you would want me to speak to before round two?" | Surfaces the objection one round early; F4 and F9 are where it will land |
| 1R5 | "What is the salary band, and what is the timeline for a decision after the 20th?" | Practical, and it supports your answer at 1A4 |

---

# Round 2: the Head of Member Services, your future manager (45 minutes)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes in "tell me about a time" form, expecting a specific story | Top. The email says "mostly behavioural", which lifts this above the hiring-manager prior of Case/Strategist plus Skeptic | "We" for context and "I" for what you did; where a quoted sentence carries a story, map it, and where none does, use the scaffold and its honest branch |
| Skeptic | Persistent probing of the gaps and "why you" | Mid. The hiring-manager prior includes it, and F4 is the most predictable objection in the whole loop | Rehearse the single most predictable objection until it is boring: concede, name the limit, then the plan |
| Case / Strategist | A live problem from the role, or a question on strategy | Low. The prior would put it first, but "mostly behavioural" lowers it; the digital target in the brief keeps two questions in | Clarify, then objective, segmentation, approach, metrics, risks; think aloud and challenge one premise respectfully |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "Tell me about a time you coached someone through a difficult escalation." | JD, EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on F7: the beats the quote states are that you trained new tellers on the escalation script; tell those in your own words. Answer slot: the JD's coaching line makes a probe on who your training reached and what a hard case looked like likely. Say who it reached and what you taught, and if a particular escalation came up, what it was and what you told them; if it reached only new tellers, or no particular case came up, say so plainly and stay with the training you gave | F7 is the nearest evidence for the coaching requirement. JD because the theme is the JD's coaching line; EXP because it tests what the quote carries |
| 2C2 | "Tell me about a time you delivered an unpopular truth to leadership." | JD | [generic] | A selection scaffold, since none of your sentences carries this story: pick a time you told someone more senior something they did not want to hear. It needs a named stake, what you actually said, and the relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it in this role, where a monthly report will sometimes carry bad news | F9's requirement presses here because the role reports to senior leaders. JD for that reason; the stem is the Values/Behavioral persona's |
| 2C3 | "Walk me through the monthly complaints spreadsheet you built." | EXP, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F5 and F6: you built it, it is monthly, it is about complaints, and your regional manager uses it. Answer slot: the JD's reporting and Excel lines make probes on what it counted, how, and which tool you built it in likely. Answer in your own words, and name the weakest assumption you know of in what it counted before they do; if you do not know how something in it was counted, or part of the build was someone else's, say so plainly and stay with what you built | F5 and F6 rest on this one sheet. EXP because a reader of your history goes line by line; JD because reporting and tool skill are stated requirements |
| 2C4 | "Tell me about a time you worked with a team outside the branch to fix something members kept running into." | JD | [grounded] | A selection scaffold, since your quotes do not carry this story (F8 holds nothing): pick one real occasion with a member-facing problem, who you worked with, what each of you owned and what changed. If none comes to mind, say so plainly, then say what you would ask a digital team first: what members do before they complain, where they give up, and what they can already do for themselves | The JD's self-service line meets a silence in the material (F8). JD because it scores that stated requirement |
| 2B1 | "This role covers the contact centre as well as branches, and you've not worked in one. Where does that leave you on day one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | **The highest-ROI prep in the pack.** Concede first, in your words: "I've never worked in a contact centre." Name the limit before it is asked for: what your material shows is the branch side, "I handled the branch's formal complaints log", and no more. Then the plan, said as a plan: before changing anything, sit with the people who run it, follow one complaint across both, and ask what they see that branches do not. Follow-up one will likely be about credibility with people who have done it for years; answer with what you would ask and learn, never a claim to equivalence. Follow-up two will likely be about what you would get wrong first; name a real limit, such as how the centre runs day to day, not a polished weakness. Hold through both; add nothing to the quotes to restore comfort | F4 is a stated gap in the role's scope and the most predictable objection in the loop, so it gets the deepest rehearsal: the most follow-up levels, the concession worded in advance and the limit named before it is asked for. JD because it scores a stated requirement |
| 2B2 | "The JD says own the member complaints process end to end across branches. Where does your experience sit against that?" | JD | [grounded] "I handled the branch's formal complaints log" | Say the quote at its scope: "I handled the branch's formal complaints log", which is one branch's log. The pack's observation is that your material does not show the process beyond the log or any branch but yours. Answer slot: if any part of the process before or after the log was yours to run, say which part and how you decided; if the log was the part you held, say so plainly and stay with it. Then your plan for the rest, said as a plan | F3 is a transferability row: adjacent work whose scope the JD's wording outruns, so this objection returns in a second form. JD because it scores the stated requirement |
| 2B3 | "What would you need from me in your first three months?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Ask for what your two stated gaps point to, as requests and not as excuses: time with the people who run the contact centre, and a clear view of what senior leaders want from the monthly report. Then say what you would bring back to them, as plans. The two requests come from your own sentences; do not add a third that the quotes do not point to | Honest self-assessment is scored here. F4 and F9 give the two asks; JD because it tests readiness for the stated role |
| 2D1 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that mean for complaints?" | CO, CASE | [grounded] | Clarify first: whether the 40% includes complaints at all, and where complaints start today across branch, contact centre and online; you do not know, so ask. Then objective, segmentation by where a complaint starts and what it is about, approach, measures (the JD names complaint volumes and resolution times) and risks. Challenge one premise respectfully: whether complaints should move at the same pace as other service. Use the brief's own words, 40% and 2028, and think aloud | The strategy-grounded question for this round. The digital target meets the JD's self-service line; CO because it tests the brief, CASE because it is delivered live |
| 2D2 | "A member has explained the same problem to the branch and again to the contact centre, and is now making a formal complaint. Where do you start?" | CASE | [inferred] derived from the Plain Words value, as supplied | Clarify: what the member has been told and by whom, what they want now, and whether any deadline applies and which one; find out rather than assume. Objective: one named owner, and the member does not explain it a third time. Approach: say what you would tell the member in plain words, fix or explain the cause, and record it for the process and not only the case. Measure: resolution time. Challenge one premise: whether the complaint is about the original problem or about being passed around | A live problem set in the JD's branch-and-centre scope and the Plain Words value. It asks nothing about your past; CASE because it scores structure |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 2R1 | "What would you want to be true of complaints at Ashgrove ninety days after I start?" | Asks the manager to define success, which also tells you how they will judge the first quarter |
| 2R2 | "Where does a complaint move from a branch to the contact centre today, and where do members tend to get stuck?" | Asks about the part you have not worked in (F4) as curiosity rather than defence |
| 2R3 | "As eight branches become five hubs, what changes for who handles complaints in the branches that remain?" | Shows you read the 2027 plan and connects it to the role |
| 2R4 | "Which complaints numbers do senior leaders look at now, and what do they do with them?" | Tied to the monthly report and to F9; it tells you what the first report must show |
| 2R5 | "How do member services and the digital teams work together on self-service today, and where would this role sit between them?" | Addresses F8 directly and shows you understand the seam before you are in it |

---

# Round 3: panel of two branch managers (60 minutes, including a 20-minute case)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes scored against the four values by name | Top. The recruiter's words: "The panel is also the values round — they score against the four values" | Map a story to each value where a quoted sentence carries one; use the scaffold and its honest branch where none does |
| Case / Strategist | The 20-minute complaint-escalation case | Mid. The recruiter's words give the case 20 of 60 minutes, so it is one third of the round | Clarify, objective, segmentation, approach, measures, risks; think aloud; challenge one premise respectfully |
| Peer Evaluator | Seam-splitting, "what would you need from me", credit | Mid. This is an assumption, not something the email says: the JD has the role coaching branch supervisors, and branch managers are plausibly the people those supervisors work under. Tell me if their relationship to the role is different and I will reweight | Reciprocity framing; propose seam principles instead of pretending to know the seam; disagreement stories that show spine and tact |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | A selection scaffold, since none of your sentences carries a member-side decision: pick a time the member's interest and a branch convenience or target pulled apart; it needs a named stake, what you decided, who disagreed and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log", at its scope, or how you would decide in this role. Do not claim a decision the log does not show | First published value by name, and the panel scores against it. F2 is the only quote near it; VAL because it scores a published value |
| 3C2 | "Tell me about a time you made something clearer for a member." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F7: the beats the quote states are that you trained new tellers on the escalation script. Answer slot: the value is about words members meet. If any wording in the script, or in what members were told, was changed because members needed it explained twice, say what you changed and how you knew; if the script was not yours to change, or nothing was reworded, say so plainly and stay with the training you gave | Plain Words by name. F7 is the nearest quote; VAL because it scores a published value |
| 3C3 | "Tell me about a time you put a branch's or a town's need ahead of a number." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | A selection scaffold: pick a time a local need and a figure or target disagreed, with a named stake, what you decided, who pushed back and what the figure did next. If none comes to mind, say so plainly, then give the nearest thing your material carries, three years as a branch supervisor, at that scope, or how you would weigh it in this role. Expect this to be pressed, since the brief consolidates eight branches into five hubs and you are talking to branch managers; say how you would weigh it without judging reasons you have not seen | Neighbours, Not Numbers by name, with the hub plan in the room. F1 gives only the supervisor tenure; VAL because it scores a published value |
| 3C4 | "When have you kept hold of a problem until it was solved?" | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F2: the beats the quote states are the branch's formal complaints log and that you handled it. Answer slot: pick one entry; if you stayed with it from first report to resolution, say what it was, what you did and what was someone else's; if others owned later steps, or the log only recorded it, say so plainly and stay with the log you handled. Say what you personally kept hold of, not what the branch did | Own the Fix by name. F2 is the only quote that touches it; VAL because it scores a published value |
| 3D1 | "A member's complaint has gone from a supervisor to a branch manager and the member says it is still not fixed. Take us through how you handle it." | CASE | [generic] | The 20-minute case, so think aloud. Clarify: what the complaint is about, how long it has been open, what the member has been told, and whether a deadline applies and which one; ask, do not assume. Objective: the member's problem fixed and the process kept. Segment into three tracks: the member, the process failure, and what the supervisor needs. Approach: one named owner, plain words to the member, a decision, a record, and a coaching conversation. Measures: resolution time, and whether the member comes back. Risk: contradicting what the branch has already told them. Challenge one premise: whether "not fixed" means unresolved or unexplained | The recruiter named a 20-minute case on a complaint escalation. A live problem that asks nothing about your past; generic because it is a pattern, not a fact about Ashgrove |
| 3D2 | "Over 2027 eight branches become five hubs. How would you expect that to show up in complaints, and what would you do about it?" | CASE, CO | [grounded] | Clarify: which branches, when members are told, and what is already planned for them; you do not know, so ask. Segment members of closing branches and members of hubs, and staff. Approach and measures: volumes and resolution times by branch, before and after. Risk: a town that feels it is losing its branch, which is where Neighbours, Not Numbers bites. Challenge the premise respectfully: "show up" presumes complaints rise, so say what would tell you whether they do | The brief's hub plan, put to the people it may affect most. CO because it tests the brief, CASE because it is delivered live |
| 3D3 | "A small-business lending product launches in Q1 2027. What would you set up in the complaints process before it does?" | CASE, CO | [grounded] | Clarify: who handles these members today and what is new about their complaints; say you do not know the first complaint types. Approach: a single named owner, a way to tag these complaints so reporting can separate them from the start, plain wording for business members, and an early check with the digital team. Measure: volumes and resolution times for the new product against the rest. Challenge one premise: whether business members' complaints belong in the same process | The brief's 2027 launch, and a CO question few candidates will prepare. Asks nothing about your past |
| 3F1 | "Our supervisors report to us, not to you. Where's the seam when you coach one of them on an escalation and I see it differently?" | JD | [grounded] "trained new tellers on our escalation script" | Propose seam principles and do not pretend to know the seam: the branch manager decides how the branch runs, the coaching covers how an escalation is handled, and where they differ you agree the member's outcome first. Reciprocity: say what you bring them, at its scope, "I trained new tellers on our escalation script". Answer slot: if you disagreed with a manager about an escalation, say how it was settled, in your own words; if no such disagreement arose, say so plainly and say how you would settle one | A Peer Evaluator pricing what the hire does to their load. F7 is the nearest quote; JD because it scores the coaching line |
| 3F2 | "How do you handle credit when a fix spans a branch and the contact centre?" | VAL | [grounded] | Build from the value's own words: whoever finds the problem keeps hold of it until it is solved. So the finder stays the named owner, credit is named for each part, and the member is told who has it. If a real instance comes to mind that you can tell without adding detail, use it; if not, say so plainly and stay with how you would handle it | Own the Fix tested through credit, a peer's favourite. VAL because it scores a published value |
| 3F3 | "What would you need from branch managers for a monthly complaints report to be trustworthy?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Reciprocity first: what each branch gets back, its own numbers, so the report is theirs as well as the leaders'. Then the asks, as plans: agree what counts as a complaint and when it starts and stops, one place entries go, and a date each month. Offer the quote at its scope, "I built the monthly complaints spreadsheet our regional manager uses", and do not describe what it counted unless you can say how, which is F5's slot | Reporting is a stated requirement and the data comes from their branches. F5 is the nearest quote; JD because it scores that requirement |

## Values and principles cheat sheet

Values are as you copied them from ashgrovecu.org/about/values on 11 November 2026. The panel scores against all four.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | When a decision could go two ways, start from what the member sees and needs | Selection scaffold at 3C1: pick a time a member's interest and a branch convenience pulled apart; if none comes to mind, say so plainly and give F2's "I handled the branch's formal complaints log" at its scope |
| Plain Words | If a member has to be told twice, the explanation failed, not the member | F7: "trained new tellers on our escalation script", with the slot at 3C2 |
| Neighbours, Not Numbers | Each branch belongs to its town, and a branch is more than its figures | Selection scaffold at 3C3: if none comes to mind, say so plainly and give F1's "6 years in retail banking, the last 3 as a branch supervisor" at that scope |
| Own the Fix | The person who finds a problem stays with it until it is solved | F2: "I handled the branch's formal complaints log", with the slot at 3C4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 3R1 | "What could a new person in this role do in their first month that would genuinely help your branch?" | The reciprocity question for people whose supervisors you would work with; it shows you are thinking about their load first |
| 3R2 | "What do your supervisors find hardest about escalating a complaint today?" | Asks from the supervisor's side, which is where the coaching line in the JD will start |
| 3R3 | "As eight branches become five hubs, what do you most want complaints handling to protect in your town?" | Joins Neighbours, Not Numbers to the 2027 plan without taking a view on the plan itself |
| 3R4 | "What would make you trust a monthly complaints report from this role?" | Turns the reporting requirement into a shared standard before you write the first report |
| 3R5 | "Which of the four values is hardest to live on a busy day in your branch, and what does it look like when it is done well?" | Shows you took the values seriously enough to ask how they work in practice, in front of the people scoring them |

---

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| "4+ years in financial-services customer operations" | 1A1, 1A5 |
| "experience handling regulated complaints" | 1B2 |
| "Own the member complaints process end to end across branches" | 2B2, 3C4 |
| "across branches and the contact centre" | 1B1, 2B1 |
| "report monthly on complaint volumes and resolution times" | 2C3, 3F3 |
| "comfortable with Excel reporting" | 2C3 |
| "coach branch supervisors on escalations" | 2C1, 3F1 |
| "work with digital teams on self-service journeys" | 2C4, 2D1 |
| "confident presenting to senior leaders" | 1B3, 2C2 |

## Sources

Provided documents: the JD as you pasted it; the four values as you copied them on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the process; the four points you gave from Ashgrove's July 2026 strategy brief, not the brief's own text; your message describing your background. No dossier was present.

No search or fetch was sent. The page you named as the source of the values text is where you copied it from, so it was not opened as a link.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the cheat sheet or the VAL questions: your copy of the values page, dated the morning of 11 November 2026, fixes both |
| 2. `Ashgrove Credit Union interview process member services` | skipped | Could not have moved the persona weights or round structure: the recruiter's email gives three rounds, who runs each and what each holds |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO and CASE questions: the points you gave from the July 2026 brief, four months old, already supply the priorities the questions use |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No interviewer has a name yet, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or just its complaints, reporting and training lines → the answer slots in F2, F3, F5, F6 and F7 can become quoted evidence, and the rows that rest on your message alone gain specifics
- Your own answers to the slots in F2, F3, F5, F6, F7 and F8, given outside a drill → those rows regenerate with your words, and the questions that draw on them (1B2, 2B2, 2C1, 2C3, 2C4) become story maps
- The names or roles of the Head of Member Services and the two branch managers → an interviewer read, persona weights tuned to their public professional footprint, and a reverse question tied to their own paths
- What the 20-minute case starts from, one question to the recruiter (1R1) → if a document or brief arrives beforehand, a build section for it
- The text of the July 2026 strategy brief → the grounding brief and the CO and CASE questions use its own language and numbers instead of your four points
- A deeper research pass, up to 6 further searches and 2 further fetches and several more minutes, covering the strategy, any named interviewers, reports of Ashgrove's loop and recent organisation context → fuller CO and CASE banks and an interviewer read where names exist
- A `tuesday-dossier.md` from an earlier fit assessment of this role → verified evidence in place of the message-only quotes, and an evidence-derived objection in place of the one inferred here
