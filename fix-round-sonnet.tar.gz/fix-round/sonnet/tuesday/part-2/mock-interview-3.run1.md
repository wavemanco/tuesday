I've read the mock-interview playbook and its rules. Next I'm loading the search tools to research Stripe's values, interview loop and strategy, then I'll build the pack.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-3-denied-5761b96e/stripe_product-operations-manager_interview_pack.md`.

- **Search was refused.** All four research searches were denied, so nothing in the pack is Stripe-specific. That means no values cheat sheet, no research-based view of how Stripe runs the final round, and no current-strategy questions. Every question is labeled generic.
- **Assumptions.** I had no job description, no CV and no interviewer details, so I used flat persona weights and a worksheet in place of a real fit snapshot. It has 22 questions across seven interviewer styles, plus reverse questions and the research accounting.
- **Highest-ROI prep.** B1 and B2: why product operations and why Stripe, and how the role differs from program or product management.

Say the word and I'll run a live drill on B1 and B2 in the Skeptic persona.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who will you meet in the final round (future manager, peer, skip-level, cross-functional, or a mix), and did the recruiter share any focus areas or an assignment?
Can you paste the job description and your CV, or say skip and I'll stay with the generic pack?
Do you already have the right to work in the role's location, or would it need sponsorship or relocation?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — final-round interview pack

Interviewer: not given. Relationship: not given, so persona weights are flat. Built from your request alone: no job description, no CV and no research results were available, so everything below is generic rehearsal for the role family and is labeled that way.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script. Nothing here states anything about your past: every answer you give should come from your own experience, and where none comes to mind, the guidance tells you to say so plainly.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows a company's published values, not generic virtue |
| EXP | Whether claims about your work survive scrutiny, including what was actually yours |
| JD | The stated responsibilities of the role, including where you are weakest |
| CO | Homework on the company: strategy, products, recent moves |
| CASE | Structure and reasoning on a live problem set in the role |

Highest-ROI prep: B1 and B2 together. Whatever the panel, someone will probe why product operations and why this company, and where the role differs from program management or product management. This is chosen without your CV, so it rests on the role family and not on a gap in your material; with your CV it is replaced by your actual most likely objection.

## Fit snapshot

This is the worksheet variant: no CV or job description was supplied, so every evidence cell reads none given. Requirements are role-family prose, labeled generic, and quote nothing.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Work authorization and a location the role can be performed from (role-family term, no posting seen) | none given | none | [generic] | hard_gate | Your material does not establish it. This pack asks nothing further and wording cannot close it |
| F2 | Run a cross-functional launch or program from kickoff to close | none given | none | [generic] | discovery | Strong evidence is one named launch or program, who was on it, what you owned and how you knew it landed. Selection scaffold: pick a time several teams needed to ship one thing together; it needs a named stake, your own role stated precisely and an outcome you can describe; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Define, track and report operating or product metrics | none given | none | [generic] | discovery | Strong evidence is one metric you reported, how it was counted and what it can miss. Selection scaffold: pick one figure you have reported to others; it needs a definition, a source and one assumption you would defend least; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Build or improve a process that several teams actually follow | none given | none | [generic] | discovery | Strong evidence is a process you introduced or changed and a sign that people used it. Selection scaffold: pick a process change that other teams had to adopt; it needs what was wrong, what you changed and what happened next; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritize competing requests from many stakeholders | none given | none | [generic] | discovery | Strong evidence is a moment you said no or not yet and kept the relationship. Selection scaffold: pick a time requests outnumbered your capacity; it needs the criteria you used and who was told what; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Communicate clearly in writing and to senior audiences | none given | none | [generic] | discovery | Strong evidence is a written update or a readout you gave that someone senior acted on. Selection scaffold: pick one such document or meeting; it needs the audience, the ask and the decision; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Understand technical or developer-facing products well enough to partner with engineering | none given | none | [generic] | discovery | Strong evidence is a technical product you learned and a decision you made with engineers about it. Selection scaffold: pick a product you had to learn fast; it needs how you learned it and what you did with it; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

No loop source established Stripe's final-round structure, so the pack falls back to the Generic archetype: screen, hiring manager, panel, flat weights. That is a pattern, not Stripe's documented process, and your relationship to the interviewers is unknown. Flat weights are noticeably weaker than weights set from a real round type, and the first question below would fix that.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems set in the role: plan a launch, diagnose a metric, prioritize requests | Highest. Product operations is judged on structure, and a final round usually includes at least one live problem (generic pattern) | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Why this role, why here, why now; how the role differs from neighbors | High. A final round tests motivation consistency, and the role sits next to program and product management | Rehearse the one predictable objection until it is boring; calibrated candor over bluffing |
| C. Values / Behavioral | Scenario probes, STAR-shaped stories | Medium. Stripe's published values were not retrieved, so these questions use generic themes only | Pick stories your own material carries; use we for context and I for contribution |
| D. Data-Driven Prober | Pushes on how any number was counted | Medium. Operations roles own metrics, so expect denominators | Know what you can and cannot say about how a number was counted; say plainly when you do not know |
| E. Peer Evaluator | Seam between product ops and product teams; credit; collaboration | Medium. The role lives at team seams | Reciprocity framing; propose seam principles without pretending to know the seam |
| F. Pressure / Stress | Time-boxed, interrupting, devil's advocate | Medium. Final rounds often add composure checks | Pause; restate; hold through two follow-ups; concede specifically, never fold on the core |
| G. Conversational | Friendly openers that are still scored | Lower in depth, but present in every round | A pre-scripted 90-second arc; treat casual questions as scored |

## Question banks

Every row is generic: none makes a claim about your past, so each Provenance cell holds the label alone. Open prompts ask you to choose your own instance, and each guidance ends in the honest branch.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product team plans to launch a major feature in six weeks and three functions disagree about readiness. What do you need to know first, and how do you run the next two weeks?" | CASE | [generic] | Clarify first: who owns the go decision, what readiness means to each function, what is already known to be at risk. Then objective, the segments of readiness (product, support, sales, compliance), an approach with owners and checkpoints, the metrics that would say it is ready, the risks. Think aloud; challenge one premise, such as whether six weeks is fixed | Covers F2. CASE because it is a live problem; likely because launch coordination is the role family's core work |
| A2 | "Weekly adoption of a recently launched product dropped 20%. Diagnose it." | CASE | [generic] | Clarify the metric definition and window, then check for a measurement change before a real change, then segment by customer type, region and channel, then compare against launches and incidents in the window. Say which two checks you would run first and why | Covers F3. Metric diagnosis is the standard Case stem for operations roles |
| A3 | "You inherit a planning process every team complains about. What do you do in your first 30 days?" | CASE | [generic] | Listen before changing: who the complaints come from and what each team needs from the process; pick one visible fix and one thing to leave alone; state how you will tell adoption from compliance. Challenge the premise that the process, and not its inputs, is the problem | Covers F4. JD-style content delivered as a case |
| A4 | "Fifteen requests reach you in a week from sales, support and engineering, and you can support four. How do you choose?" | CASE | [generic] | State the criteria aloud before choosing (impact, urgency, reversibility, who else can do it), say how you would tell the other eleven requesters, and name what you would want to know about the four that win. Show the decision and the communication, not only the ranking | Covers F5 |
| A5 | "Pick a Stripe product or recent launch and tell me what product operations would do around it, and why you chose it." | CO | [generic] | Choose a product you have actually read about or used, and name the source you used. If you have not used one closely, say so plainly and do the exercise with a product you know. The pack holds no current facts about Stripe, so no talking points are supplied: read Stripe's own current material before the interview | Covers F7 and the CO slot. Generic because research did not run; a grounded version needs the research listed in the upgrade menu |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why product operations, why Stripe, and why now?" | JD | [generic] | Three short parts in your own words: what draws you to the function, what draws you to this company, and why this is the moment. Each part should be something you could defend with a follow-up. Drop any reason you could not defend for two more questions | The highest-ROI prep. Motivation consistency is what a final round tests |
| B2 | "How is product operations different from program management or product management, in your own words?" | JD | [generic] | Give a two-sentence definition you believe. Then, if one example from your own experience illustrates the difference, tell it; if none comes to mind, say so plainly and describe how you would approach the difference in the first month | The second half of the highest-ROI prep; the role sits next to both |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one area honestly, state what you have actually done near it in your own words (or that you have not), and give a concrete ramp plan with a first step. Calibrated candor beats bluffing a competency the interviewer owns | Standard Skeptic stem; covers every requirement row F2 to F7 |
| B4 | "What would make this role the wrong move for you a year from now?" | JD | [generic] | Answer with a real condition, such as scope, pace or manager fit, then say what you would do about it before leaving. A flat nothing reads as unprepared | Tests motivation consistency and honest self-assessment |

### C. Values / Behavioral

Stripe's published values were not retrieved, so no value is named here and no values cheat sheet is included.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the message was unwelcome; it needs a named stake, what you said and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F6. Standard Values stem |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time the two pulled apart; it needs the metric, the customer need and the decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard Values stem; worth rehearsing for a developer-facing company, and swapped for the named values once those are in hand |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A team says a new internal process saved time. How would you measure that, and which assumption would you defend least?" | CASE | [generic] | Define the baseline and the unit, say who counts and when, then name the weakest assumption before the interviewer does. Naming it converts a gotcha into credibility | Covers F3 with the weakest-assumption move |
| D2 | "Which three metrics would you put on a launch scorecard, and what would each one miss?" | CASE | [generic] | Pick three that cover adoption, quality and cost of support, state each one's blind spot, and say what you would add if you could add a fourth | Covers F2 and F3 |
| D3 | "When you report a metric to others, how do you make sure it is counted the same way each time?" | EXP | [generic] | Describe your actual practice in your own words: where the definition is written, who can change it, how you notice drift. If you had no such step, or it was not yours, say so plainly and describe how you would set one up | Covers F3. EXP because it tests whether you know how your own numbers are made |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between product operations and a product team, and what happens when we disagree?" | JD | [generic] | Offer seam principles instead of pretending to know the seam (who owns the decision, who owns the follow-through, what escalates), and say how you would raise a disagreement privately before publicly | Covers F4 |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time the credit was shared; it needs who did what and how you made it visible. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard Peer stem |
| E3 | "What would you need from me in your first month?" | JD | [generic] | Pair what you need (context, access, introductions) with what you bring the peer's team, in the reciprocity framing, and keep both concrete | Reciprocity probe |

### F. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then three reasons you could defend. Hold through two follow-ups; concede specifically (what an internal candidate knows that you do not) without folding on your core reasons | Standard Pressure stem; tests composure |
| F2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Selection scaffold: pick a result you can split into your part and others' parts; say your part precisely and credit the rest by name. If no such result comes to mind, say so plainly, then give the nearest thing your material does carry. Hold through two follow-ups by returning to what you did, never by adding to it | Standard Pressure stem; attribution honesty |
| F3 | "Product operations sounds like overhead. Convince me this role earns its headcount." | JD | [generic] | Hold your position for two follow-ups, then concede one real limit (what the role cannot fix) in specific terms. Do not claim outcomes you cannot name | Pressure on the role itself, linked to B2 |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc you build from your own CV: where you started, what you moved toward, why this role. Each beat is something your material states, in your words. Treat it as scored | Covers F6; almost always the opener |
| G2 | "What are you actually playing with these days that relates to how product teams work?" | JD | [generic] | Name something real you have read, built or tried and what you took from it. If nothing comes to mind, say so plainly and say what you would explore first | Covers F7 and the casual register |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 work authorization and location | none, a gate: it asks nothing and no question can close it |
| F2 cross-functional launch | A1, D2, B3 |
| F3 metrics | A2, D1, D2, D3, B3 |
| F4 process change | A3, E1, B3 |
| F5 prioritization | A4, B3 |
| F6 senior and written communication | C1, G1, B3 |
| F7 technical product fluency | A5, G2, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for this role, and what would make it a miss?" | Shows you think in outcomes and gives you a bar to check yourself against |
| R2 | "Which product launches went best from an operations point of view, and what made them work?" | Moves the talk to real cases and shows you study how work gets done |
| R3 | "Where does product operations sit relative to product and engineering today, and where is the seam still being worked out?" | Signals you expect seams and want to help set them |
| R4 | "What is the hardest cross-team problem the team is dealing with now?" | Invites a real answer instead of a pitch |
| R5 | "How do you measure whether product operations is working?" | Shows metric discipline and surfaces how the role is judged |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question; useful whenever a peer is in the room |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Nothing listed | No candidate material was supplied, so there is no sentence to inflate and no stated negative to protect | Every answer comes from your own experience in your own words; where none comes to mind, the honest branch in each answer guidance applies |

## Sources

Provided documents: your request only. No dossier.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Queries sent, all refused when search permission was not granted: "Stripe operating principles values"; "Stripe interview process Product Operations Manager"; "Stripe strategy 2026 news stablecoins agentic commerce annual letter"; "Stripe Product Operations Manager job description". Nothing in this pack comes from a search result.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Every call was refused. Would have moved: the values cheat sheet and VAL questions keyed to named values |
| 2. Stripe interview process, product operations | unavailable | Every call was refused. Would have moved: the loop structure and the persona weights; the Generic archetype and flat weights stand in |
| 3. Stripe strategy and recent news | unavailable | Every call was refused. Would have moved: CO and CASE questions grounded in current strategy; A5 is generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative product operations JD | unavailable | Every call was refused. Would have moved: the fit snapshot requirements, now role-family prose labeled generic |

## Upgrade menu

- The job description text → the generic F2 to F7 rows become quoted requirements, and the coverage table is checked against the posting's own list
- Your CV or a short background paragraph → the worksheet becomes a real fit snapshot with story-mapped answers and a rebuilt highest-ROI objection
- Who you meet in the final round (manager, peer, skip-level, panel) → persona weights and the bank order are reset
- Interviewers' names → an interviewer read, mirror opportunities and a reverse question tied to each one's path
- The recruiter's description of formats, focus areas or any assignment → coverage of announced deliverables, usually one email
- Search permission, or Stripe's values page pasted → a values cheat sheet and VAL questions on named values
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once, needs search permission → a strategy-grounded CO and CASE bank
- Time available before the interview → a prioritized prep schedule
- A tuesday-dossier.md from an earlier underwriting pass, if you have one → verified evidence and a sharper objection list; not needed to use this pack
