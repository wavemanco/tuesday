Web search was refused, so I'm building the pack from your JD and background only. Before I draft it I'm checking for an existing dossier and reading the dossier handoff spec.
Your prep pack is saved as `Atlas-Freight_operations-manager_interview_pack.md`, with 21 questions across seven interviewer styles. I built it for an unknown round with equal weight on every interviewer style, since you don't know who you're meeting. My three web searches on Atlas Freight were refused, so the pack has no company facts, no values sheet and no company-strategy questions. It rests only on your JD and your background.

The pack names one question as your highest-ROI prep, A1: you lead 3 supervisors today and the JD asks for 12 across 4 sites. The other gap to settle before the interview is Power BI (A2, D3). I wrote that answer as "I haven't used Power BI" plus a plan, since you said you've never used it.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What does the invite or the recruiter's note say about the round (hiring manager, panel, site visit, recruiter call)? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas-Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Relationship and round type: not known. Built for a week out, with flat persona weights and no company research (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: every sentence it gives you for your own past is one you already wrote, and every place it cannot supply a detail is marked as an answer slot for you to fill, or to say plainly you cannot.

| Type | What it scores |
|---|---|
| VAL | Behavioral and values: whether past behavior shows the trait asked about |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny and what was actually you |
| JD | Role and JD requirements: whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: no company research could run) |
| CASE | A live problem set in the role, delivered on the spot |

## Prep triage

You have about a week, so the order matters more than the volume.

1. A1, then A3: the objection this pack names as the highest-ROI prep. Say the answers aloud until they are boring.
2. C1, C2, D1: the 40% figure. Before you rehearse, find out for yourself how it was counted and who else touched the redesign, because those are the follow-ups.
3. A2 and D3: the Power BI answer. Settle the plan (what you will learn first, with what, by when) so it is real before you say it.
4. F1 and F3: the 90-second journey and your leadership dates.
5. B1, B2, B3: structure each case aloud once, clarify first.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message. No gate rows: nothing in the JD is a licence, authorization, location or similar term, and the 5+ years line is an experience requirement, graded like the others.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops and a surge plan for the site, not terminal operations and not more than one site, with nothing inspected behind it. Words stay at that scope: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's scope line makes a probe on carry-over likely. Say what your 7 years were mostly spent on, in your own words, and which parts you think carry over and why; if you cannot say which, or none do, say so plainly and stay with the 7 years and the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says mis-pick rate, not on-time performance or cost per shipment, and the words stay there: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's performance lines make a probe on whether the lower mis-pick rate showed up in any other number likely. If it did, say which number and how you know; if it did not, or you do not track one, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors, and the pack's observation is that the JD's team is larger. Words stay at 3: "I'm a senior shift manager over 3 supervisors." Answer slot: the JD's team-size line makes a probe on how your way of leading would hold at that size likely. Say how you lead the 3 supervisors you have, in your own words; if you are unsure how it holds at a larger size, say so plainly and return to the 3 |
| F4 | "build reporting in Excel/Power BI" — JD, Excel half | "solid Excel" — your message | low | [inferred] | discovery | Inferred from the JD's reporting line set beside a skill claim: the quote says skill, not what was built, so the pack writes no claim of reports built. Answer slot: the JD's reporting line makes a probe on what you have produced likely. If you built reports others used, say what each showed and who read it; if you built none, or used Excel for your own analysis, say so plainly and say what you use it for |
| F5 | "build reporting in Excel/Power BI" — JD, Power BI half | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan with a first step and a date, never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Inferred from the JD's required-years line set beside two quotes that show 7 years in operations and a current supervisory role, and do not show how many of the 7 years involved leading people; the pack reads it downward. Answer slot: the JD's required-years line makes a probe on dates likely. Say the year you first led people and what that role was called, in your own words; if the years you led people are fewer than the JD's number, or you cannot date them, say so plainly and say what the other years held |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | discovery | Your material says the belt, not which program it was or what it was applied to, with no certificate inspected. Words: "I'm green belt certified." Answer slot: the JD's Lean and Six Sigma line makes a probe on the program likely. Say which program it was and one thing you applied from it, in your own words; if it has not been applied to your work, say so plainly and say what you would apply first |

## Persona table

No loop source established this company's rounds, so the weights rest on the Generic archetype (screen, hiring manager, panel) and are flat, said plainly. Flat weights are noticeably weaker than weights keyed to a known interviewer; the upgrade menu says what would sharpen them. No values-style round is assumed, so there is no values cheat sheet. Each persona gets three questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Skeptic | Quiet, persistent probing of the gaps | Equal weight: relationship unknown, and the JD's scale and tool lines leave obvious gaps for any interviewer to probe | Rehearse the most predictable objection (A1) until it is boring; calibrated candor over bluffing |
| B Case/Strategist | Live problems from the job | Equal weight: an operations role often gets a live problem, but nothing here says this loop has one | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| C Data-Driven Prober | Reads the numbers line by line | Equal weight: the 40% figure is the one number an interviewer can probe | Know how the figure was counted and say plainly where you do not |
| D Pressure | Interrupts, time-boxes, tests composure | Equal weight: round type unknown | Pause, restate, hold through two follow-ups, concede only what you can specify |
| E Values/Behavioral | Scenario stories, STAR-shaped | Equal weight: no published values were available, so themes come from the persona's stems and the JD | Selection scaffolds with an honest branch where your material has no story |
| F Conversational | Friendly, unstructured, still scored | Equal weight: a recruiter or rapport-style opener is common to every archetype | A 90-second arc; treat casual questions as scored |
| G Peer | Seam-splitting between sites, credit probes | Equal weight: the JD's four sites make a site-peer plausible | Reciprocity framing; propose seam principles rather than pretend to know the seam |

## Question banks

### A Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're over 3 supervisors today and this role has 12 across 4 sites. What changes for you on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I'm a senior shift manager over 3 supervisors." The concession is the number itself, said plainly and without apology. Answer slot: the JD's team-size line makes a probe on how your way of leading would hold at that size likely. Say how you lead the 3 supervisors you have, in your own words; if you are unsure how it holds at a larger size, say so plainly and return to the 3. Hold through two follow-ups by returning to the 3, never by adding to it; then say, as a plan and not a past, what you would find out first in your opening weeks | F3 is the widest gap between your sentence and the JD, so this objection arrives in some form; JD because it scores the stated team size, Skeptic because it is asked as a doubt |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick a weakness you can state honestly and stay with it. Your material gives one stated gap, so the words are the plain acknowledgment: "I haven't used Power BI." Then a plan, not a past: what you will learn first, with what, by when, each filled in by you. If another true gap comes to mind, say it the same way; do not offer one you do not hold | F5 is the one gap you stated, and this is the Skeptic's standard opener; JD because it scores the listed requirements |
| A3 | "Your background is warehouse and distribution operations; this role is terminal operations. What carries over?" | JD | [grounded] "7 years in warehouse and distribution ops" | Words at the quote's scope: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's terminal wording makes a probe on carry-over likely. Say what your 7 years were mostly spent on, in your own words, and which parts you think carry over and why; if you cannot say which, or none do, say so plainly and name what you would ask first to learn the difference | F1 is where the JD's terminal wording presses hardest; JD because it scores the stated scope, Skeptic because the doubt is the delivery |

### B Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance has slipped at one of your four sites over three weeks and cost per shipment is rising. Diagnose it." | CASE | [generic] | Clarify first: which site, which shifts or lanes, how on-time is defined and measured, what changed three weeks ago, what cost per shipment includes. Then objective, segmentation by site and shift, ranked hypotheses, the data you would pull, and the risk of acting on thin data. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem built from the JD's performance lines, which are F2's requirement; generic because it is a pattern for the problem, not a fact about this employer |
| B2 | "Sketch your first 30 days across four sites and 12 supervisors. What do you need to know first?" | CASE | [generic] | Structure it: what you would ask first about each site and each supervisor, the order you would visit, what you would want reported daily and to whom, one early measurable, and what you would leave alone while you listen. All of it is a plan, not a past, so the guidance makes no claim about your history | Puts the JD's sites, team and reporting lines (F1, F3, F4) into one live problem; generic because it is a pattern, not this employer's situation |
| B3 | "A peak-season week is forecast well above normal across the four sites. How do you plan it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure it live: clarify the forecast and constraints, set the objective, name the levers you would flex, the triggers and escalation points, the daily check-ins, the risks. Where you draw on your own surge plan, the words stay at the quote: "I ran the site's peak-season surge plan two years running." What the plan held is told in your own words with nothing added; if a follow-up asks for a detail you cannot give, say so plainly and return to the plan you ran | F1 holds the surge quote; CASE because it is a live problem, and the multi-site frame is the JD's, not a claim about your past |

### C Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Words at scope: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: the probe will be how the figure was counted. Say how, in your own words; if you do not know how it was counted, say so plainly and return to the redesign | F2 carries the one headline figure, which probers read first; EXP because it tests whether the claim survives scrutiny |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The weakest-assumption move: name, in your own words, the assumption you would defend least before the interviewer does; it turns a gotcha into a credibility gain, and the pack does not name one for you. Answer slot: if you know of one, say which and why; if you do not know of one, or never checked, say so plainly and return to the redesign | F2 again, from the angle a prober takes second; EXP because it tests whether you know your own number |
| C3 | "Tell me about a time you used a metric to change how your team worked." | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on the quote: the mis-pick rate, the 40% cut, the redesign of the pick path, which are the beats it states, told in your own words. Answer slot: the JD's performance lines make a probe on whether any other number you track moved likely. If the lower mis-pick rate showed up in another number, say which and how you know; if it did not, or you do not track one, say so plainly and stay with the mis-pick result | F2 is the nearest evidence to the JD's metric-driven wording; JD because the theme is the JD's, an open prompt rather than a premised question |

### D Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That mis-pick result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, then hold: "I cut the mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups by returning to that sentence, never adding to it. Answer slot: the probe will be who else touched the redesign. If others contributed, say who and what each did, in your own words; if it was yours alone, or someone else led part of it, say so plainly. Concede only what you can specify, and never fold on the core claim to restore harmony | F2 is the claim an attribution probe lands on; EXP because it tests what was actually yours |
| D2 | "Sixty seconds: why you over someone who already runs a multi-site network?" | JD | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | Time-box it to three sentences, each a quote at its scope: "I ran the site's peak-season surge plan two years running." "I cut the mis-pick rate 40% by redesigning the pick path." "I'm green belt certified." Describe what you did and let the interviewer draw the inference; do not say what the work proves. When pushed on scale, return to the sentences, never add to them | F1, F2 and F7 are the three rows with something concrete to say; JD because it scores fit to the role, Pressure because of the time box |
| D3 | "You haven't used Power BI, and reporting is in the JD. Why should we take that risk?" | JD | [grounded] "never used Power BI"; "solid Excel" | Hold, then concede specifically. Concede in the stated words: "I haven't used Power BI." Hold on what your quote carries: "My Excel is solid." Answer slot: the JD's reporting line makes a probe on what you have produced in Excel likely. If you built reports others used, say what each showed and who read it; if you built none, or used it for your own analysis, say so plainly. Then the plan: first step and date | F4 and F5 together are where the reporting line presses; JD because it scores a listed requirement |

### E Values/Behavioral

No company values were available, so these themes come from the persona's stems and the JD. Where your material has no story, the guidance is a selection scaffold.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what was at risk if you stayed quiet, what you said, and how the relationship stood afterward; choose one where the hard truth actually landed. Your material does not show such a time, so nothing here supplies one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the values round; generic because it is a pattern, and VAL because it scores behavior over content |
| E2 | "Tell me about a time you had to protect on-time performance under pressure." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Story-mapped on the quote: the site's peak-season surge plan, run two years running, which are the beats it states, told in your own words. The quote says you ran the plan and for how long; it says nothing about what the plan held or how it went, so tell only what you can stand behind, and if a follow-up asks for a result you cannot give, say so plainly and return to the plan you ran | F1 holds the surge quote; VAL-style delivery with an EXP tag because it tests whether that claim survives a follow-up |
| E3 | "Tell me about a time you got supervisors to change how they worked." | VAL | [generic] | Selection scaffold: pick a time a supervisor, or a group of them, changed a working habit. It needs what the change was, why they resisted, what you did, and what stuck. Your material shows the supervisory role, not a change, so nothing here supplies one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | The JD's team line (F3) makes this an open prompt; generic because the scaffold carries no claim about your past |

### F Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc, each beat one quote at its scope: "I have 7 years in warehouse and distribution ops." "I'm a senior shift manager over 3 supervisors." "I cut the mis-pick rate 40% by redesigning the pick path." "I ran the site's peak-season surge plan two years running." "I'm green belt certified." Join them with connective sentences that add no facts. Close with your own reason for this role; your material does not give one and the pack does not supply it | A casual biography question is still scored; the arc uses the rows with something concrete (F1, F2, F3, F7) |
| F2 | "Tell me about a time you used a Lean or Six Sigma tool on the job." | JD | [grounded] "green belt certified" | Words at scope: "I'm green belt certified." Answer slot: the JD's Lean and Six Sigma line makes a probe on the program and what you applied likely. Say the program and one thing you applied, in your own words; if the belt has not been applied to your work, say so plainly and say what you would apply first. Your material has no sentence joining the belt to the pick-path redesign, so the pack does not | F7 is the JD's plus-skill row; JD because the theme is the JD's, asked casually |
| F3 | "How long have you been leading people, and how did you get there?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | The quotes carry the 7 years and the current role: "I have 7 years in warehouse and distribution ops." "I'm a senior shift manager over 3 supervisors." Answer slot: the JD's required-years line makes a probe on dates likely. Say the year you first led people and what that role was called, in your own words; if the years you led people are fewer than the JD's number, or you cannot date them, say so plainly and say what the other years held | F6 is the one requirement the posting marks as required and your material does not date; JD because it scores that line |

### G Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites sit side by side. Where is the seam between your site and mine, and what happens when we disagree?" | CASE | [generic] | Propose seam principles rather than pretend to know the seam: who decides what, how handoffs between sites are measured, what escalates and when, a default when two sites need the same resource. For disagreement, state the interest, test it against data, agree a tiebreak in advance. The question needs no claim about your past, so the guidance makes none | Persona stem for the peer; the JD's four sites (F1) make it plausible; generic because it is a pattern |
| G2 | "How do you handle credit when a result spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Keep "we" for context and "I" for your contribution, and let your own sentence carry the contribution: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if other people or teams contributed to that result, say who and what, in your own words, and how you gave them credit; if it was yours alone, say so plainly | F2 is the only result in your material a credit probe can attach to; EXP because it tests attribution |
| G3 | "What would you need from the other sites' managers in your first month, and what could you offer them?" | CASE | [generic] | Reciprocity framing: lead with what you would bring a peer's site, then what you need. Propose principles, such as a shared view of handoffs and an agreed escalation path, not a list of demands. The question needs no claim about your past, so the guidance makes none | Peer questions return as collaboration scenarios; generic because it is a pattern |

## Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| "Own daily terminal operations across 4 sites" | A3, B1, B2, B3, D2, G1, G3 | |
| "drive on-time performance and cost-per-shipment down" | B1, C3, E2 | C1 and C2 defend the one figure |
| "lead a team of 12 supervisors" | A1, B2, E3 | |
| "build reporting in Excel/Power BI" | A2, B2, D3 | Excel half: D3; Power BI half: A2, D3 |
| "5+ years operations leadership required" | F1, F3 | |
| "Lean/Six Sigma a plus" | D2, F2 | |
| Company and strategy (CO) | none, and why | No company research could run, so a CO question would be generic and none was written |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is the team of 12 supervisors spread across the 4 sites today, and where is the bench strongest and thinnest?" | It uses the JD's own team and site lines and shows you think about span before you take it on |
| R2 | "How is on-time performance defined and measured here, and where does it stand against target?" | Definitions before improvement is how an operations lead frames the job; it also tells you what the number will be |
| R3 | "What reporting do the sites and supervisors produce today, and what would you want built first?" | It engages the JD's reporting line directly and lets you learn which tool the team actually uses |
| R4 | "What would success look like at 90 days and at one year?" | It asks for the scoring sheet, and the answer tells you whether the role is mostly stabilizing or mostly changing |
| R5 | "Where do the sites hand work to each other, and where does that most often go wrong?" | It goes to the seam any multi-site role lives on and signals you are thinking about the work between sites, not only within one |
| R6 | If a peer is on the panel: "What could a new person do in their first month that would genuinely help your site?" | A reciprocity question converts an evaluation into a working conversation; never answer "any questions" with "I think you've covered everything" |

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says warehouse and distribution ops and one surge plan, not terminal operations or more than one site |
| Brought on-time performance and cost per shipment down | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says mis-pick rate |
| Led a team of 12 supervisors | A claim one of your quotes contradicts, F3 | The contradicting quote and nothing more: "currently a senior shift manager over 3 supervisors" |
| Built reporting in Excel for the sites | Inflated form of F4 | F4's quote at its own scope: "solid Excel". The limit is the pack's observation: the quote says skill, not what was built |
| Has used Power BI | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't used Power BI." Then a plan, never a past. No slot |
| The pick-path redesign was a Lean or Six Sigma project | Inflated form of F2 and F7 together | The two quotes, each at its own scope. The limit is the pack's observation: no sentence in your material joins them |

## Sources

Provided documents: the JD text you typed into your message, and your background in the same message. No `tuesday-dossier.md` was present, so none was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Queries sent, every one refused by the host's permission check, so nothing came back:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have moved the values cheat sheet and the VAL themes; neither is in this pack |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have moved the loop structure and persona weights; they rest on the Generic archetype instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have moved the CO bank; no CO question was written |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Nothing in this pack states a fact about Atlas Freight beyond the JD's own lines.

## Upgrade menu

- Round type and who is interviewing, from the invite or recruiter → reweights every persona, drops banks that do not apply, adds an interviewer read and a reverse question tied to their path
- Permission for web search, or the company's values or careers page pasted in → a values cheat sheet if a values round is documented, the real loop, and CO questions; a deeper pass would be up to 6 further searches and 2 further fetches, several more minutes
- Your CV → evidence cells quote your CV instead of your message, and rows F1 to F7 can move up
- The recruiter's prep note, with focus areas or any pre-announced deliverable → coverage keyed to what will be graded
- Your answers to the slots in F1, F2, F4, F6 and F7 → those rows upgrade from discovery or transferability toward quoted evidence
- A `tuesday-dossier.md` from an earlier role assessment, if you have one → confirmed claims and a named objection replace what this pack infers
