Reading the playbook's required reference files directly.
I've built a prep pack for the Stripe Product Operations Manager final round, but it's generic. Web search was denied in this session and I didn't try another route, so nothing in it comes from Stripe's own materials. I also have no CV, job description, or interviewer details from you.

The pack is at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-3-denied-a063e123/stripe_product-operations-manager_interview_pack.md`. I built it assuming a mixed final round with no known interviewer, so all seven interview styles get equal weight.

- **Questions:** there are 21, spread evenly across live case problems, skeptical probes, behavioral prompts, peer questions, metric deep-dives, pressure questions, and casual conversation.
- **Your own experience:** the guidance for those questions doesn't say anything about your past, because it has no material to draw on. It gives you ways to pick a real story from your own history, with an honest fallback if none fits.
- **Highest-value prep:** rehearse B1, "Which part of this role would you be weakest at on day one?" It comes up in some form in nearly every final round.
- **Also in the pack:** six reverse questions for you to ask, and a table mapping each likely requirement to the questions that cover it.
- **Left out:** I didn't include Stripe's values, how its interview loop is structured, or its strategy, because I'd only have been guessing. The sources section lists the four searches that were refused.

I can run a live mock of any question as the interviewer, starting with B1 if you like. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

1. Who are you meeting in the final round (hiring manager, peer, skip-level), and is it one conversation or several? Did the recruiter say anything about focus areas or an assignment?
2. Can you paste the job description and your CV, or a few sentences about your background? If not, I'll stay generic.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer name and relationship: not given. Built on provided inputs only: the company, the role title and the round type. Nothing here is drawn from a CV, a job description or web research, and each section says so where it matters.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows good judgment and values, asked as a behavioral prompt |
| EXP | Whether your work experience survives scrutiny, including what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you have done your homework on the company |
| CASE | Structure and reasoning on a live problem |

## Fit snapshot

No CV or background was provided, so this is the worksheet variant. Every evidence cell is empty and every row is a place to fill in your own material. No job description was provided either, so the requirements below are role-family patterns, written as plain prose and not quoted from any posting. Treat them as a checklist to confirm against the real posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run launches or releases across several teams (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a launch or release you coordinated, with the teams involved and your part in it named. Selection scaffold: pick one coordination effort where you can say who did what; if no such effort comes to mind, say so plainly, then give the nearest work your material does carry, or how you would approach it |
| F2 | Define and track product or operational metrics (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a metric you used, with how it was counted and what you would defend least about it. Selection scaffold: pick one metric you can explain end to end; if none comes to mind, say so plainly, then give the nearest work your material does carry, or how you would set one up |
| F3 | Build or improve an operating rhythm, process or tool (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a process you changed, what it was before and what you saw afterwards. Selection scaffold: pick one change where you can state the before and after; if none comes to mind, say so plainly, then give the nearest work your material does carry, or how you would approach it |
| F4 | Influence product, engineering and business partners without direct authority (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a partner team and how it ended. Selection scaffold: pick one time you needed agreement you could not mandate; if none comes to mind, say so plainly, then give the nearest work your material does carry, or how you would handle it |
| F5 | Prioritize and structure ambiguous problems (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a problem you were handed unstructured and how you framed it. Selection scaffold: pick one unclear brief you can walk through; if none comes to mind, say so plainly, then give the nearest work your material does carry, or how you would handle it |
| F6 | Communicate clearly to senior audiences (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is an update or recommendation you gave a senior audience and what was decided. Selection scaffold: pick one such moment you can describe; if none comes to mind, say so plainly, then give the nearest work your material does carry, or how you would prepare one |

## Persona table

The loop is not established: no loop source was provided, and no search could run. The pack falls back to the generic archetype of screen, hiring manager, then panel, with flat weights. It does not assert how this company's final round is structured. Weighting is flat because your note did not say who you meet, and a final round at a company is often several sessions with different people, so all seven styles get equal depth.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems about the role: plan this, diagnose that | Flat weight. A final round for an operations role plausibly includes a live problem, and the generic archetype does not rule it out | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of gaps and motivation | Flat weight. Final rounds commonly test why this role and why now | Rehearse the most predictable objection until it is boring; say gaps plainly, with a ramp plan |
| Values / Behavioral | Scenario prompts, story-shaped answers | Flat weight. No values-style round is detected, so these are rehearsal for any behavioral prompt | One real story per theme, chosen from your own material, with "we" for context and "I" for what you did |
| Peer Evaluator | Seam-splitting, collaboration, credit | Flat weight. Cross-team work is the core of this kind of role | Reciprocity framing; propose seam principles without pretending to know the seam |
| Data-Driven Prober | Goes two levels deep on any number | Flat weight. Operations roles are metric-heavy | Know how each figure was counted, and say plainly when you do not know |
| Pressure | Interrupts, time-boxes, challenges motive | Flat weight. Final rounds sometimes test composure | Pause, restate, hold the position through two follow-ups, concede specifically |
| Conversational | Friendly and unstructured, still scored | Flat weight. Rapport rounds often open or close a loop | A 90-second arc for the biography question; treat casual questions as scored |

## Question banks

Every row is `[generic]`: no candidate material or role document was provided, so no guidance below says anything about your past. Where a question asks about your experience, the guidance is a selection scaffold that ends in an honest branch.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product team says launches keep slipping at the last minute. What do you need to know first, and how would you find the cause?" | CASE | [generic] | Clarify before structuring: slipping against what commitment, and who agreed to it. Then objective, segments of launches, approach, metrics, risks. Challenge one premise, for example whether the slips share a cause. The question needs no claim about your past, so the guidance makes none | F1 is the requirement this tests. CASE because it is a live problem asked as a decision |
| A2 | "You are asked to set up a weekly product-health review for senior leaders. What goes in it and what stays out?" | CASE | [generic] | Start with the decisions the audience makes, then the few metrics that inform them, each with a stated definition, and what you would deliberately leave out and why. Say aloud what you would confirm first | F2 and F6 are the requirements. CASE because it scores structure and judgment about an audience |
| A3 | "Two product teams each want your help first and you can support only one this quarter. How do you decide?" | CASE | [generic] | Name the criteria before the choice, say what you would ask each team, and how you would tell the team you did not pick. The question needs no claim about your past | F5 and F4 are the requirements. CASE because it scores prioritization and how you handle the disappointed party |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Selection scaffold: choose one real gap you already know about in your own experience, name it in one plain sentence, then give a concrete first-30-days plan to close it. Hold it calmly through two follow-ups. If no gap comes to mind, say so plainly, then say what you would verify in the first week | This question arrives in some form in nearly every final round, and no CV was provided to aim it more precisely. JD because it scores honest self-assessment against the role |
| B2 | "Why product operations, rather than product management or program management?" | JD | [generic] | Say what draws you to the work in the role's own terms, then what you would not want to do. Use only reasons that are true for you. If a clear reason has not formed yet, say so plainly, then say what you want to find out in the role | F1 and F3 are the work this contrasts with. JD because it tests motivation consistency |
| B3 | "Why this company, and why now?" | CO | [generic] | Build the answer from what you can source and state yourself, such as a product you have used or something you read, and name it specifically. This pack supplies no company facts because none were researched. If you cannot yet name a specific reason, say so plainly, then say what you would want to learn | CO because it tests homework. It stays generic until research is available, which the upgrade menu offers |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a working relationship intact afterwards. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 and F4 are the requirements. VAL because it scores behavior, not knowledge |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a visible tradeoff, what you chose, and what it cost. Say what you did, not what it proves. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2 is the requirement. VAL because it scores judgment under a metric tension |
| C3 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is the requirement. VAL because it scores spine and tact together |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles instead of pretending to know the seam, such as who decides, who is consulted, and how a disagreement gets escalated. Then say how you would test those with this team in the first month | F1 and F4 are the requirements. JD because it scores partnership fit |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say your practice in your own words and keep it to what you actually do. Selection scaffold for an example: pick a time credit was shared, and say what you did. If no such time comes to mind, say so plainly, then say how you would approach it | F4 is the requirement. VAL because it scores behavior with equals |
| D3 | "What would you need from me in your first month?" | JD | [generic] | Reciprocity first: what you would bring that reduces their load, then two or three specific things you would ask for. Keep both lists short and concrete | F1 and F3 are the requirements. JD because it scores whether the hire reduces or adds to a peer's load |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a metric you have used to judge a process. How was it counted, and which assumption behind it would you defend least?" | EXP | [generic] | Selection scaffold: pick a metric you can explain end to end, say how it was counted, what it is sensitive to, and the assumption you would defend least, in your own words and before the interviewer asks. If none comes to mind, or you do not know how a figure was counted, say so plainly, then describe how you would set one up | F2 is the requirement. EXP because it tests whether you know your own numbers |
| E2 | "Adoption of a new internal workflow is 40 percent below target. Diagnose it." | CASE | [generic] | A hypothetical, so no past is claimed. Clarify what target and what baseline, segment who is not adopting, form hypotheses, say which data would separate them, and what you would do first | F3 and F2 are the requirements. CASE because it is a live diagnosis |
| E3 | "How would you know a metric you were handed is wrong?" | CASE | [generic] | Name checks you would run: definition, source, sample, trend breaks, comparison with a second source. Say which you would run first and why | F2 is the requirement. CASE because it scores reasoning about data quality |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate. Give two reasons, each stated only from your own material. Hold through two follow-ups, then concede specifically, for example what an internal candidate knows that you would need to learn. Do not fold on the core claim to restore harmony | F5 and F4 are the requirements. JD because it scores fit against the role under time pressure |
| F2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Selection scaffold: pick one result and say precisely what you did and what others did, using "I" and "we" accurately. Hold the claim as stated and concede exactly what was not yours. If no result comes to mind, say so plainly, then give the nearest thing your material does carry | F1 and F3 are where this lands. EXP because it is the attribution probe |
| F3 | "Why should we believe you can do this without having done exactly this?" | JD | [generic] | The premise is the interviewer's, and the guidance does not adopt it. Say plainly what you have done that is adjacent, in your own words, then a concrete ramp plan. If you have done the work directly, say so plainly instead | B1 is the companion rehearsal. JD because it scores how you handle a gap challenge |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc of three beats: where you started, the turn that led to operations work, and why this role is next. Build each beat from your own history in your own words | G1 opens many rounds and is scored. EXP because it tests communication economy |
| G2 | "What is something you learned recently that changed how you work?" | VAL | [generic] | Pick something true and small, say what you changed and what you noticed. If nothing comes to mind, say so plainly, then name what you are currently trying to learn | VAL because casual questions reveal curiosity. It is scored even when it feels like small talk |
| G3 | "What are you looking for in your next team?" | JD | [generic] | Name two or three specifics that are true for you and connect to the work in B2. Do not describe the company's culture, which this pack did not research | JD because it tests motivation consistency with B2 and B3 |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 Run launches or releases across teams | A1, D1, D3, F2 |
| F2 Define and track metrics | A2, C2, E1, E2, E3 |
| F3 Build or improve an operating rhythm | D3, E2, F2 |
| F4 Influence without authority | A3, C1, C3, D1, D2, F1, F3 |
| F5 Prioritize and structure ambiguity | A3, B1, F1 |
| F6 Communicate to senior audiences | A2, C1 |
| Motivation and fit | B1, B2, B3, G1, G2, G3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like for this role, and how would you tell I was on track?" | It shows you are thinking about outcomes, and it gives you the interviewer's own success criteria |
| R2 | "Which decisions does this team own, and which does it only influence?" | It surfaces the seam directly and signals you understand influence without authority |
| R3 | "Where does the work this role touches most often get stuck today?" | It shows you are already looking for the problem, and the answer tells you what the job really is |
| R4 | "How does the team find out that a process it built has stopped working?" | It tests how the team measures itself, which is the core of the role |
| R5 | "What is the hardest tradeoff this team has faced recently, and how was it resolved?" | It invites a real story and shows interest in judgment over process |
| R6 | "What has changed about what this role is for since it was first opened?" | It surfaces scope drift and shows you read the role as a moving target |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No CV, message or dossier supplied candidate material, so there is no sentence for this pack to stretch | Every guidance cell is a selection scaffold or a hypothetical, and none states what you did. Add your material and this section is rebuilt against it |

## Sources

Provided documents: none. A dossier was not present.

Search attempts, all refused because web search was not permitted in this session:

- "Stripe operating principles values": refused
- "Stripe interview process Product Operations Manager": refused
- "Stripe strategy 2026 news priorities": refused
- "Product Operations Manager job description Stripe": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have moved the values cheat sheet, which is dropped, and the VAL themes, which are generic |
| 2. `Stripe interview process Product Operations Manager` | unavailable | Would have moved the loop structure and persona weights, which are flat on the generic archetype |
| 3. `Stripe strategy` / recent news | unavailable | Would have moved B3 and added company-specific CO and CASE questions |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Would have moved the fit snapshot requirements from role-family patterns to a quoted sample, and the JD-tagged questions |

## Upgrade menu

- Job description text → the six role-family rows in the fit snapshot become quoted requirements, and the JD-tagged questions are re-aimed at the posting
- Your CV, or a few sentences about your background → the fit snapshot gets real evidence, selection scaffolds become story maps, and the prohibited-claims section is built against your wording
- Who you meet and in what format, including any recruiter guidance on focus areas or a pre-declared deliverable → persona weights stop being flat, and a deliverable gets its own build section
- Web research, if you permit searches → Stripe's published values, loop structure and current strategy replace the generic rows, and a values cheat sheet is added if a values round is documented
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → strategy-brief and role-family loop material for CO and CASE questions
- The interviewers' names → an interviewer read and a reverse question tied to their own career path
- A tuesday-dossier.md, if you have one → verified evidence and the objection worth the deepest rehearsal
