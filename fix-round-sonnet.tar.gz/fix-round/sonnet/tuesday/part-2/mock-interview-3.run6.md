Reading the playbook is done. Now I'm running the default research pass on Stripe (values, interview process, strategy, a representative role posting), then I'll build the prep pack.
The web searches were refused, so no Stripe research ran. I'm building the pack from what you told me and labeling everything that would have needed research as generic.
Your Stripe prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-3-denied-c2564979/stripe_product-operations-manager_interview_pack.md`.

I built it as a final-round pack for an unknown interviewer, with flat persona weights. All four web searches were refused, so it contains no Stripe research. The company-specific questions and the fit snapshot are labeled generic, and the Sources section lists what each search would have changed. It has 21 questions across seven interviewer styles, a requirement-coverage table, six reverse questions and an upgrade menu.

B1 is the highest-ROI rehearsal: "Which part of this role would you be weakest at on day one?" It will be asked in some form whoever you meet.

Say the word and I'll play the Skeptic on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposes, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two answers would restructure it:
1. Who are you meeting, and is that person your future manager, a peer, or someone senior or cross-functional? If the recruiter gave focus areas or a presentation or take-home, include that too.
2. Can you paste the job description and your CV, or a few lines on your background? I can proceed without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer: not given. Relationship to you: not given. Built on the assumption that the final round is one conversation with an unknown interviewer, so persona weights are flat. No job description, CV or web research was available, so every row is a worksheet or a labeled generic pattern.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: it never says what you did, because this pack holds none of your sentences yet. Where a cell asks you to pick an example, it is yours to choose, and each ends with an honest branch for when none comes to mind.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claimed experience survives scrutiny; what was actually you |
| JD | The stated role: can you do the listed job, gaps included |
| CO | Company and strategy knowledge, and thinking at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

Each question carries one primary type tag. The rationale says when a second type applies.

## Fit snapshot

No job description, recruiter note or CV was supplied, so this is the worksheet variant. The requirements are role-family patterns written without a source, so they are plain prose, unquoted and labeled generic. Every evidence cell is empty because nothing about your past has been given.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate cross-functional work toward product launches or releases (role-family pattern, no source supplied) | none given | none | [generic] | discovery | Strong evidence is a named launch or release, who else was involved, and the part that was yours. Selection scaffold: pick one launch or release where you held a defined part, with a named date or stake and a moment something had to be unblocked; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Run or improve operating rhythms such as planning cycles and reviews (role-family pattern, no source supplied) | none given | none | [generic] | discovery | Strong evidence is a recurring process, how often it ran, who attended and what changed because of it. Selection scaffold: pick a recurring process you ran or changed, with a named before and after; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Use data and metrics to find problems and track outcomes (role-family pattern, no source supplied) | none given | none | [generic] | discovery | Strong evidence is a figure you reported, how it was counted, what it was sensitive to and which part of the result was yours. Selection scaffold: pick one figure you can explain end to end; if no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Design processes or tools that other teams actually adopt (role-family pattern, no source supplied) | none given | none | [generic] | discovery | Strong evidence is something you introduced, who was asked to use it and what happened to use over time. Selection scaffold: pick one process or tool you introduced, with a named group that had to change habits; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence and communicate across levels without direct authority (role-family pattern, no source supplied) | none given | none | [generic] | discovery | Strong evidence is a decision you shaped, who held the authority and how the relationship stood afterward. Selection scaffold: pick one time you moved a decision you did not own, with a named stake and an intact relationship at the end; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

Weights are flat. The relationship to the interviewer is not known, so the relationship priors give no tilt, and no loop source established how many sessions a Stripe final contains or who runs them, so the generic archetype applies: screen, hiring manager, panel, flat weights. Each persona therefore gets three questions. If you know who you are meeting, the weights change; say so and the banks are reweighted.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live problems from the role: plan this, diagnose that | Equal weight: relationship unknown, loop not established | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet, persistent probing of fit, motivation and weak spots | Equal weight: relationship unknown, loop not established | Rehearse the most predictable question until it is boring; build bridges only from your own stated material; say a limit plainly |
| Pressure (C) | Interrupts, time-boxes, questions motives | Equal weight: relationship unknown, loop not established | Pause, restate the question, anchor in what you actually did, hold through two follow-ups before conceding anything real |
| Data-Driven Prober (D) | Asks how each number was counted, goes two levels deeper | Equal weight: relationship unknown, loop not established | Know what you can and cannot say about how a figure was counted; say plainly when you do not know; name the weakest assumption first |
| Values / Behavioral (E) | Scenario probes, story-shaped answers | Equal weight: no loop source documents a values round, so none is assumed | One story per theme, we for context and I for contribution; choose stories where the hard truth actually landed |
| Conversational (F) | Friendly, unstructured, easy to under-prepare for | Equal weight: relationship unknown, loop not established | Pre-script a 90-second arc; treat casual questions as scored; have real reverse questions ready |
| Peer Evaluator (G) | Seam-splitting between teams, collaboration scenarios | Equal weight: relationship unknown, loop not established | Reciprocity framing; propose seam principles rather than pretending to know the seam; show spine and tact together |

## Question banks

Highest-ROI prep: B1. It is the Skeptic's standard opener and will be asked in some form whoever you meet. The pack cannot name a candidate-specific objection until it has your CV, and B1 is the question that objection will arrive through.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks out and three teams each believe a different team owns the go-live checklist. How do you get to a launch that is actually ready?" | CASE | [generic] | Clarify first: what ready means, who decides, what is fixed and what can slip. Then name the objective, split the problem into ownership, readiness and communication, pick an approach, say how you would track it, and name the risk you would watch. Challenge one premise, such as whether the date is fixed. The question needs no claim about your past, so the guidance makes none | Live problem from the role family (F1, F4); CASE because it scores structure, not the right answer |
| A2 | "Adoption of a recently shipped feature is 20 percent below plan. Diagnose it." | CASE | [generic] | Ask what plan and adoption mean and over what period. Segment by customer type, region and channel; list hypotheses from least to most expensive to test; say what data you would pull first; say what you would not conclude yet. Think aloud throughout | Metric-diagnosis stem from the Case persona (F3); CASE because the structure is scored |
| A3 | "What is your read on where Stripe is investing, and where would product operations matter most in that?" | CO | [generic] | This pack could not research Stripe, so it supplies no facts about it. Before the interview, read Stripe's own recent public material and pick one priority you can source; tie it to one operating problem; say where you are reasoning rather than reading. Never recite a framing you have not checked | Company-altitude question; the pack has no research behind it, so it stays generic until research runs. Also tests JD fit (F1, F2) |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Highest-ROI rehearsal. Pick the area where the honest answer is a real limit, not a disguised strength. Name it plainly in one sentence, then give a concrete ramp plan for the first 30, 60 and 90 days, said as a plan and not as a past. Hold through two follow-ups by returning to the plan. If no real limit comes to mind, say so plainly and name where you would need the most support | Persona stem for the Skeptic and the likeliest question for any candidate (F1 to F5); JD because it scores honest self-assessment against the role |
| B2 | "Why product operations, why Stripe, and why now?" | JD | [generic] | Three short parts. Each must rest on something you can source: why the function, from your own work; why Stripe, from Stripe's own published material you have read; why now, from your own situation. If one part is thin, say so and lead with the strongest. No part asserts anything this pack has not seen | Motivation-consistency probe the Skeptic persona uses; JD because it scores role intent, with CO overlap on the Stripe part |
| B3 | "What would make you decide this role is not the right next step for you?" | JD | [generic] | Name one or two real conditions in your own words, such as scope, pace or the kind of work. Keep them honest and non-adversarial. If you have not thought about it, say so and name what you want to learn from today's conversation | Tests whether motivation holds under cross-examination; JD because it scores role fit from your side |

### C. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over a candidate who is already doing product operations?" | JD | [generic] | Pause, restate the question in one line, then give two or three reasons that rest on your own material. Hold the position through two follow-ups, then concede one specific uncertainty plainly without folding on the core claim. The pack has none of your sentences, so choose the reasons only from what you can back under a second question | Time-boxed stem from the Pressure persona; JD because it scores the case for the role |
| C2 | "Pick one result you are proud of. How much of it was actually you?" | EXP | [generic] | Selection scaffold: pick a result with a clear before and after, where you can say which parts were yours and which were others. Say we for context and I for contribution. Hold the claim through two follow-ups; concede specifically what was a team effort. If no such result comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Attribution probe from the Pressure persona (F3, F5); EXP because it tests what was actually yours |
| C3 | "You have five minutes. A senior leader wants the planning review moved from monthly to quarterly. Argue against it, then argue for it." | CASE | [generic] | Restate the proposal, ask what problem it solves, then argue each side in two or three points. State which you would recommend and what would change your mind. Stay calm when interrupted and return to your structure | Time-boxed live problem (F2, F5); CASE because the reasoning under pressure is scored |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number you have reported in a past role and walk me through how it was counted." | EXP | [generic] | Selection scaffold: pick a figure you can explain end to end. Say in your own words how it was counted, what it was sensitive to, the assumption you would defend least and which part of the result was yours. If you do not know how it was counted, say so plainly. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Defend-the-number probe (F3); EXP because it tests whether the figure survives scrutiny |
| D2 | "What three metrics would you put on a dashboard to tell whether a launch process is working?" | CASE | [generic] | Ask what the process is for, then pick one leading and one lagging measure and one quality check. Define each in a sentence, and name the weakest assumption behind each before the interviewer does | Metrics design from the role family (F3, F4); CASE because the structure is scored |
| D3 | "Tell me about an analysis you did yourself, end to end, and the assumption in it you would defend least." | EXP | [generic] | Selection scaffold: pick an analysis where you did the pulling, the cleaning and the recommending, or say which parts you did not. Name the weakest assumption before they do. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Prober persona's stem and its offer to walk an analysis end to end (F3); EXP because it tests ownership |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold and a relationship intact at the end. Choose one where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard Values stem (F5); VAL because it scores behavior, not virtue. No Stripe value is named because none could be researched |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer cost and the metric cost were both real, and say what you gave up. Use I for the decision and we for context. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard Values stem; VAL because it scores a specific decision |
| E3 | "How do you earn trust with a team that is wary of a new operating process?" | VAL | [generic] | A forward-looking question, so structure it: listen first, find what the team is protecting, pilot small, share the data, adjust. It claims nothing about your past; if you have a real example, hold it ready as an optional illustration | Process-adoption theme (F4, F5); VAL because it scores working style with others |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Pre-script a 90-second arc: where you started, the thread that connects your roles, and why this role next. Every beat should be a sentence from your own CV, which this pack does not yet hold; add none you cannot back under a follow-up | Biography opener; EXP because the arc is the claim set they will probe |
| F2 | "What have you been thinking about lately in how teams run product work?" | JD | [generic] | Treat it as scored even though it sounds casual. Pick a topic you actually follow, say one thing you think about it and one thing you are unsure of. If nothing comes to mind, say so plainly and name what you would read first | Casual-register probe on role-family interest (F4); JD because it scores genuine interest |
| F3 | "What drew you to Stripe in particular?" | CO | [generic] | Rest it on what you have read in Stripe's own public material, which this pack could not fetch. Give two reasons you can source and one personal one. Never state a fact about Stripe you have not checked | Motivation and homework check; CO because it scores company knowledge |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam between us, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a claim to know the seam: who owns decisions, who owns inputs, how disagreements escalate and how you keep the relationship intact. Say what you would ask them first | Seam-splitting stem (F1, F5); JD because it scores partnership fit |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | State your principle in a sentence, such as naming contributions specifically and early. If you have a real example, hold it ready as optional; if none comes to mind, say so plainly and say how you would handle it | Credit-sharing probe (F5); VAL because it scores behavior with equals |
| G3 | "What would you need from me in your first month, and what could you offer my team?" | JD | [generic] | Reciprocity first: what you would bring, then what you would need. Keep both specific and modest; ask what their team is stretched on | Collaboration scenario; JD because it scores partnership fit |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 Coordinate cross-functional launches | A1, B1, G1 |
| F2 Run or improve operating rhythms | A3, C3 |
| F3 Use data and metrics | A2, C2, D1, D2, D3 |
| F4 Design processes or tools others adopt | A1, D2, E3, F2 |
| F5 Influence across levels without authority | C3, E1, E2, E3, G1, G2 |

B2, B3, C1, F1, F3 and G3 cover motivation, company fit and partnership rather than a single requirement.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first 90 days look like in this role, and how will you know?" | Gives you the yardstick your 30, 60 and 90 day plan in B1 should answer to |
| R2 | "Which operating processes around product work are working well today, and which are you least happy with?" | Shows where the role would start; lets you aim F2 and F4 stories at a real need |
| R3 | "How does product operations work with product management and engineering day to day, and where does that seam get tested?" | Prepares your G1 answer with their real version of the seam |
| R4 | "What is a decision the team recently changed its mind on, and what drove it?" | Reveals how the team uses evidence, which helps you pitch F3 material |
| R5 | "What does the strongest person you have seen in a role like this do differently?" | Gives a concrete standard to compare yourself against honestly |
| R6 | "If you are a peer on this team: what could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer interviewer; ask it only if that is who you meet |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Nothing listed | No candidate sentences were supplied, so there is no wording to widen and no stated negative to protect | Every guidance cell above is a scaffold or an answer slot; none states what you did. Adding your CV would let this list name the claims you are likely to reach for under pressure |

## Sources

Provided documents: your message (company, role, round).

No job description, CV, recruiter note or interviewer information was provided. No dossier was present.

Searches sent, all refused, so nothing came back and nothing from the web is used in this pack:

- "Stripe operating principles values": refused
- "Stripe interview process Product Operations Manager": refused
- "Stripe strategy 2026 news priorities": refused
- "Stripe Product Operations Manager job posting responsibilities": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have moved the values cheat sheet and the VAL questions, which stay generic; no values-style round is detected, so that section is dropped |
| 2. Stripe interview process, product operations | unavailable | Would have moved persona weights and the loop; the generic archetype with flat weights stands in |
| 3. Stripe strategy and recent news | unavailable | Would have moved the CO questions (A3, F3), which stay generic |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have moved the fit snapshot requirements from generic to inferred and the JD-tagged questions with them |

## Upgrade menu

- Allowing web search → fit-snapshot rows move from generic to inferred or grounded, CO questions A3 and F3 are rebuilt on current strategy, the loop replaces the generic archetype, and a values cheat sheet appears if a values-style round is documented
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief and role-family loop reports that strengthen the CO and CASE banks
- The job description text → the five generic requirement rows become quoted, grounded requirements and the JD-tagged questions are re-aimed at them
- Your CV or a few lines on your background → the worksheet becomes a story-mapped snapshot, defend-the-number questions are written against your real figures, and the prohibited list names the claims you are likely to reach for
- Who you are meeting and their relationship to you → persona weights tilt, depth follows weight, and a reverse question can be tied to their path if a name is given
- The schedule, if your final is several sessions → per-session mini-packs with their own persona weights
- Anything the recruiter said about focus areas or a pre-declared deliverable such as a presentation or take-home → a build section for that deliverable
- How much prep time you have → a prioritized schedule that does the few things that matter first
- A tuesday-dossier.md from an earlier job-underwriter run, if you have one → verified evidence and absolute prohibited claims carried into the banks
