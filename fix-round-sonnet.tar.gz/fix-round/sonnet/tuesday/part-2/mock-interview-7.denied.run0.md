The four searches were refused, so I'm building the pack from your JD and background alone and labeling anything company-specific as generic. Writing the file now.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-denied-e1b502ad/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say whether Tobias is your future manager. Web search was refused in this session, so I have no research on Saltmarsh's values, strategy or interview process, or on Tobias. Anything company-specific is labeled generic, and the Sources section lists the four refused searches.

The pack's highest-ROI prep is A1: "You haven't worked on a game with in-app purchases. How would you handle that in this role?" It's the objection your own background most predicts. Rehearse the flat acknowledgment and then a plan, and don't stretch your calendar or retention work to cover the gap.

Say the word and I'll play the Skeptic on A1, with live follow-ups and feedback.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did the recruiter say what he'll focus on or ask you to prepare anything? Either answer reweights the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations (title from your message). Relationship: assumed hiring manager, because your note did not say. Format: one 60-minute session on Friday. Built from the JD you pasted and your own summary of your background. Web research was not available, so nothing here rests on facts about the company or about Tobias beyond his name and title.

## How to use this pack

- Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored.
- Guidance is scaffolding, not a script. Where a quote appears in a Provenance cell, it is your own sentence from your message, and the guidance rests on that sentence at its own scope and no further.
- An answer slot is an instruction for the interview, not a question for this conversation. It marks a place where only you know the true answer, and it always allows the honest branch: you did it and can say how, or there was no such step or it was not yours.
- Provenance labels: `[grounded]` traces to a document you provided, `[inferred]` is this pack's derivation with the derivation named, `[generic]` is a role-family pattern with no claim about this employer or about you.
- Question IDs skip the letter F so they never collide with the fit-snapshot rows F1 to F8.

| Type | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the behavior asked about, not generic virtue |
| EXP | Work-experience deep-dive | Whether your stated experience survives scrutiny and is attributed precisely |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Homework depth and whether you can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

## Prep triage

You have until Friday. Do these in order; everything else is insurance.

| Order | Do | Tied to |
|---|---|---|
| 1 | Say A1 aloud three times, with its follow-ups, until the plain acknowledgment comes out flat and without apology | A1 |
| 2 | Write the 90-second journey from your four sentences and time it | D1 |
| 3 | For each answer slot in A3, A4, A5, B4, C1, E2 and G1, decide your honest branch and write it in your own words | F1 to F5 and F8 |
| 4 | Say B2 and B4 once each out loud, thinking aloud and structuring before answering | B2, B4 |
| 5 | Find out which two titles the role covers and play both; write down what each is running now | B5, D2, A5 |
| 6 | Pick three reverse questions you actually want answered | Reverse questions |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a content-drop calendar on one title, not events and not two titles, and says run, not plan. The words stay at the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's events and two-titles lines make a probe on both likely. If any of your drops were events, or you worked on a calendar for a second title, say what and how, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this. Strong evidence would be a named update, the teams you worked with on it and what you did with each. Answer slot: the JD names four teams, so expect a probe on which you worked with. If you worked with any of them on a drop, say which and what you did, in your own words; if you did not, or that was someone else's job, say so plainly and describe only the work that was yours |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a review or the KPIs it reports. The words stay at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event review line makes a probe on whether any review followed a drop or event likely. If one did and part of it was yours, say what and how, in your own words; if there was no such review, or it was not yours, say so plainly and stay with the monthly numbers you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that your QA team still uses it, not that you ran releases against it. The words stay at the quote: "I wrote the release checklist our QA team still uses." Answer slot: the JD's with-QA line makes a probe on how releases ran against it likely. If you worked through releases with QA using it, say how, in your own words; if you wrote it and others ran the releases, or there was no such step, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | Not a gate: a years line is graded on the evidence behind it. The title reads associate producer and the JD says producing, so expect a probe on whether the years count. Answer slot: the JD says live-service, so expect a probe on whether the game you worked on ran that way. If it did, say how in your own words; if it did not, or you cannot say, say so plainly and stay with the four years at a puzzle-game studio |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a CV-style line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you ran it, weekly, for two years, because a named cadence beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in the quote's terms: retention numbers, monthly, presented to the studio head. Nothing inspected stands behind it and the quote does not say how the numbers were counted, so expect a probe on that; C1 rehearses it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written checklist that a team still uses touches this requirement and does not show it is clear; reading it as writing evidence is this pack's derivation, so it is a lead and not your claim. Answer slot: the JD asks for clear writing, so expect a request for an example. If a piece of your writing is one others worked from and it is yours to show, say what it is and offer it; if there is none, say so plainly and stay with the checklist you wrote |

## Persona table

Three passes: relationship prior (hiring manager, assumed), interviewer signals (none: only a name and title are known), and the loop (one 60-minute session with Tobias, from your message; no loop source documents a values-style round).

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps and of the years | high: the hiring-manager prior is Case plus Skeptic, F2 and F8 are the thinnest rows, and the limits you stated are listed in section 13 | Rehearse the single most predictable objection until it is boring; bridge only from what you stated; concede plainly where the material stops | A |
| Case / Strategist | Live problems from the job: plan this, diagnose that | high: same prior; the JD's own lines on events, retention and review are live problems | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | B |
| Data-Driven Prober | Reads your lines closely and asks how a number was counted | medium: not in the hiring-manager prior, raised because the JD asks for comfort with retention metrics (F7) and your material has one metric line to probe | Say plainly what you can and cannot say about how a number was counted; name your weakest assumption before they do | C |
| Conversational / Rapport | Friendly, unstructured opener that is still scored | medium: not a prior for the round; included because an opening question arrives in some form and is scored | A pre-scripted 90-second arc; treat casual questions about hot JD topics as scored | D |
| Pressure / Stress | Interrupts, time-boxes, questions motives | low: not in the hiring-manager prior and no interviewer signal either way; touched because composure probes can arrive inside any bank | Pause, restate, anchor in what you actually stated, hold through two follow-ups before conceding anything real | E |
| Peer Evaluator | Seam-splitting between teams, credit and collaboration | medium: the JD names four teams to coordinate (F2); not the relationship of this session, so depth is mid | Reciprocity framing; propose seam principles, not a map of a seam you have not seen | G |
| Values / Behavioral | Scenario probes scored for behavior | low: one session per your message, no loop source documents a values round, and no published values were read | Choose stories where the hard truth actually landed; where none comes to mind, say so rather than supply an ending | H |

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked on a game with in-app purchases. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment, in your words: "I haven't worked on a game with in-app purchases." Say it flat and stop before the plan. Then the plan, as a plan and never as a past: name the first two or three things you would really do to learn how purchases and events fit together on a title you run, such as who on the team to ask, which numbers to read first, which title to play first. Then what your material carries, at its scope: you ran the weekly content-drop calendar for the main title and presented monthly retention numbers to the studio head; your material does not show purchase-related work, so do not stretch either sentence across that gap. Follow-up one will likely ask what you would look at first: answer from the plan. Follow-up two will likely ask how long until you are useful: name a time frame only if you can stand behind it. If pushed on why you and not someone who has done it, concede it plainly and return to the two sentences. Hold through every follow-up by returning to the acknowledgment and the plan, never by adding experience | Predicted from the limits you stated, recorded in section 13, and from F1 and F3, where the JD's events and KPI lines meet them; this is the pack's inference about what will be asked, not anything the employer has said. JD because it scores whether you can do the listed job with this gap |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] derived from the thinnest rows of the snapshot, F2 and F8 | Choose the answer you actually believe and give it in one sentence before any plan. Candidates for it are the rows where this snapshot shows the thinnest evidence, F2 and F8, and the limits you stated, listed in section 13. Say the weakness, say what you would do about it in the first weeks, and stop. Do not offer a weakness that is really a strength | Persona stem for the Skeptic; F2 and F8 are where an honest answer is easiest to defend. JD because it scores the stated requirements, including their gaps |
| A3 | "You haven't led a team. How would you get design, art, engineering and community to work to the calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment, in your words: "I haven't led a team." Then the JD's own line: it asks you to coordinate these teams, which is the JD's wording and not a claim about your past. Answer slot: if you coordinated any of design, art, engineering or community on a drop without leading them, say what you did, in your own words; if you did not, or that was someone else's job, say so plainly and describe how you would set up a working agreement with each team. Hold through two follow-ups by returning to the acknowledgment and the honest branch | F2 is the JD line this question presses on, and the limit comes from what you stated. JD because the requirement is the scoring sheet; Skeptic because the negative is the premise |
| A4 | "The role asks for three or more years producing live-service games, and your title was associate producer. How do those years line up?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Say it in the quote's own terms: four years, associate producer, a puzzle-game studio. Answer slot: the JD says live-service, so expect a follow-up on whether the game ran that way. If it did, say how in your own words; if it did not, or you cannot say, say so plainly and return to the four years. Do not rename the title: associate producer stays associate producer, and producing is the JD's word, not one you held | F5 is the row where the JD's years and your title sit side by side. JD because it tests a stated requirement directly |
| A5 | "You ran the calendar for your studio's main title, and this role covers two titles. How would you run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F1 and F6, with the beats the quote states: a calendar, weekly drops, the main title, two years. Tell them in your own words. Then the two-titles part is a live problem, so think aloud: what the two calendars would share, what could collide, how you would see a collision early. Answer slot: if you ever ran or fed a calendar for more than one title, say what and how; if not, say so plainly and answer this part as how you would do it | F1 is the JD's two-titles line against a one-title quote. JD content with CASE delivery, so the tag follows what is scored |

### B. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch the plan for next month's events across two titles. What do you need to know first?" | CASE | [generic] | Clarify before you structure: the goal of the month for each title, what is already fixed (releases, platform dates, team capacity), how each event is measured today, who signs off. Then objective, segmentation, approach, metrics, risks. Say the structure aloud, state one hypothesis early and challenge one premise respectfully. The question asks nothing about your past and the guidance makes no claim about it | The JD's events line (F1) as a live problem; the hiring-manager prior favors this style. Generic because it is a pattern for the problem, not a fact about this employer |
| B2 | "A retention number dropped 20% the week after an update. Diagnose it." | CASE | [generic] | Clarify first: which retention measure, which players, which title and platform, whether the drop is real or a change in how it is measured, what shipped that week. Then rank hypotheses, name the first check for each, and say who you would tell and when. Say what you would not conclude yet. The question asks nothing about your past | Persona stem for the Case persona, aimed at the JD's retention line (F7). Generic because the metric and numbers are the interviewer's to supply |
| B3 | "Design and engineering both want the same slot, and the engineering build for it will slip. What do you do?" | CASE | [generic] | Structure it: what is fixed and what slipping costs, the options (move, cut, split), who decides and on what information, what you tell the community team, what you record afterwards. The question asks nothing about your past | F2's coordination line as a decision under conflict. Generic because the guidance is a pattern, not a fact about this studio |
| B4 | "An event ended below its target. What goes in the post-event review, and who sees it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure it: what the target was and where it came from, what happened, what you can and cannot attribute to the event, what you would change, who decides. Answer slot: the JD's post-event review line makes a probe on whether one was part of your work likely. If a review of this kind was part of your work, say how it ran, in your own words; if there was no such review, or it was not yours, say so plainly, present this as how you would run one, and stay with the monthly numbers you presented to the studio head | F3 is the JD's review-and-KPI line against a presenting quote. JD content with CASE delivery |
| B5 | "What do you think our two titles' events do well, and what would you change?" | CO | [generic] | Before Friday, play both titles and write down what is running now. In the interview say only what you saw yourself. If you have not played one of them, say so plainly and say what you would look at first. Do not guess at numbers or at what is being tested internally; the question asks for observation, not knowledge you cannot have. The question asks nothing about your past | F1's two-titles line as a homework check. Generic because no research on the titles was available; adding their names would make it grounded |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented and to whom, in the quote's words. Then four answer slots, each in your own words: how the numbers were counted; what they were most sensitive to; the assumption behind them you would defend least; which part of producing them was yours. If you do not know how they were counted, say so plainly. If you presented numbers someone else produced, say so plainly and describe what you did with them. Name your weakest assumption before the interviewer does | F3 and F7 hold the only metric line in your material, which makes it the first thing a prober reads. EXP because it tests what was actually yours |
| C2 | "Which retention measures would you watch around an event, and why those?" | JD | [generic] | Name the measures you can actually explain and say what each would tell you, then say where your experience with them stops. For example: how many players return after a fixed number of days, how many play during the event window, how many take part in the event. Choose only the ones you can defend in a second question. The question asks nothing about your past | F7's JD line as a direct question. Generic because the measures that matter for these titles are the employer's to say |
| C3 | "During a live event, which number would you distrust first, and why?" | CASE | [generic] | Pick one number and name the assumption under it: how it is counted, what delays it, what would make it wrong. Naming a weakest assumption before being asked turns a probe into credibility. The question asks nothing about your past | A prober's weakest-assumption move applied to a live problem (F7). Generic for the same reason as C2 |

### D. Conversational / Rapport Builder (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc whose beats are your four sentences, at their own scope: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title, for two years; the release checklist your QA team still uses; the monthly retention numbers presented to the studio head. Tell them in your own words. Then one sentence on why live operations and why this studio, which is yours to write because the pack does not know it. End on the reason, not on a summary | The opener is where F1, F3, F4, F5 and F6 first appear in order. EXP because it is your history, told casually and scored anyway |
| D2 | "What mobile games do you play, and what do their live events do well?" | CO | [generic] | Choose one you really play or have studied this week and say one specific thing its events do, in your own words. If you do not play mobile games regularly, say so plainly and name the one you looked at for this interview. Avoid reciting a list | A casual question about the JD's hot topic (F1), asked in a rapport register. Generic because it asks for your observation, not a fact about this employer |

### E. Pressure / Stress Interviewer (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Pause, restate the question in one clause, then answer inside the time. Hold on two sentences only: "I ran the weekly content-drop calendar for our main title for the last two years" and "I wrote the release checklist our QA team still uses." Concede once, specifically: "I haven't worked on a game with in-app purchases." Do not fold on the held sentences to ease the room, and add nothing to them under pressure; if pushed twice, return to the same two sentences | A1's objection delivered as a time-boxed challenge (F1, F4). JD because the question scores fit against the listed job |
| E2 | "How much of that calendar was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Stay with the sentence: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: expect a probe on which parts you set and which others set. Say which were yours and which were not, in your own words; if part of it was someone else's, say which part. Hold through two follow-ups by returning to what you ran, never by adding to it; concede the split you name and stop | F1 and F6 rest on one sentence, which an attribution probe tests first. EXP because it scores precision about your own role |

### G. Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where does the content calendar end and the release checklist begin, and what should happen when they pull against each other?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Propose seam principles, not a map of a seam you have not seen: who decides what ships when a date and a checklist item conflict, what gets written down, who is told. Use your two sentences at their scope: you ran the weekly content-drop calendar for the main title and wrote the release checklist your QA team still uses. Answer slot: the JD names both, so expect a probe on whether the two ever pulled against each other in your work. If they did, say what happened and what you did, in your own words; if they did not, or the call was not yours, say so plainly and answer as a principle | F1, F4 and F6 meet at this seam. JD because the JD names both the calendar and the checklist |
| G2 | "How do you handle credit when an update spans design, art, engineering and community?" | JD | [generic] | Reciprocity framing: what you bring each team and not only what you need from them; credit named by contribution and said out loud in the review. If a real instance comes to mind, tell it in your own words; if none does, say so plainly and describe what you would do. The question presupposes no past | Persona stem for the Peer, tied to F2's four teams. Generic because it makes no claim about your history |
| G3 | "How would you write up an update plan so four teams read it the same way?" | JD | [inferred] derived from F8 as a lead: the checklist as a possible writing sample | Describe the document in your own design: what it opens with, what is decided and what is still open, who owns each line, what changed since last time. If you want to show writing, the checklist is the one thing your material names; offer it only if it is yours to share. Answer slot: if other writing of yours is something teams worked from, say what it was, in your own words; if there is none, say so plainly and stay with the checklist you wrote | F8 is the JD's writing line, scored by showing and not by claiming. JD with CASE delivery |

### H. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship still intact afterwards. Your material states presenting monthly retention numbers to the studio head and does not show one that carried unwelcome news, so that sentence is a place to look, not a story. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the Values persona, aimed at F7's reporting line. VAL because it scores behavior; no published values were read, so no value is named |
| H2 | "When did you put the player ahead of a schedule or a metric?" | VAL | [generic] | Selection scaffold: pick a decision with a named cost to the schedule or the number, what you chose, and what happened to the player. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the Values persona with the player in place of the customer. Generic because it asks you to choose an instance |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 live-events calendar for two titles | A5, B1, B5 |
| F2 coordinate design, art, engineering, community | A3, B3, G2 |
| F3 post-event review and KPIs | B4, C1 |
| F4 release checklist with QA | G1 |
| F5 3+ years producing live-service | A4 |
| F6 running a content calendar | A5, E2, G1 |
| F7 player-retention metrics | B2, C1, C2, C3 |
| F8 clear written communication | G3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like for the producer on these two titles?" | Shows you are planning to be useful and surfaces what he scores |
| R2 | "What is the hardest part of the live-events calendar for the two titles right now?" | Points you at the real problem you would inherit instead of a general one |
| R3 | "What does the post-event review need to answer for you, and who reads it?" | Ties to the JD's review line (F3) and shows you care about the decision it feeds |
| R4 | "How do design, art, engineering and community agree what goes into an update today, and where does that get stuck?" | Ties to the coordination line (F2) and invites him to describe the seam |
| R5 | "How do you and the producer split what each of you decides on the calendar?" | Makes the working relationship concrete before it starts |
| R6 | "I haven't worked on a game with in-app purchases. What would you most want me to understand about how events relate to them in your titles?" | Turns the gap into a ramp conversation; use it only if the topic has come up or he opens the door, since it names the gap in your own plain words |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." | The plain acknowledgment: "I haven't led a team." No slot for leading; A3's slot asks only about coordination, which is different |
| Worked on a game with in-app purchases, or owned purchase-related numbers | Negative you stated, same sentence | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran live events, or a live-events calendar | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says content drops, not events |
| Ran or planned calendars for two titles | Inflated form of F1 | F1's quote at its own scope: your material says the main title. A5's slot stays inside the calendar you ran |
| Owned the post-event review or its KPIs, or owned or improved retention | Inflated form of F3 and F7 | F3's quote at its own scope: your material says you presented the monthly numbers. B4's and C1's slots ask only how a review ran and how the numbers were counted |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope: your material says you wrote it and that your QA team still uses it. G1's slot asks only whether the calendar and the checklist ever pulled against each other |
| Spent three or more years producing live-service games | Inflated form of F5 | F5's quote at its own scope: your material says four years as an associate producer at a puzzle-game studio. A4's slot asks only whether the game ran as a live service |

## Sources

Provided documents: the JD you pasted, and your own summary of your background in your message (not a CV). No tuesday-dossier.md was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Query | Target | Outcome |
|---|---|---|
| Saltmarsh Games values | 1 | refused |
| Saltmarsh Games interview process live operations producer | 2 | refused |
| Saltmarsh Games mobile studio news strategy | 3 | refused |
| Tobias Wrenfield Saltmarsh Games Head of Live Operations | 4 | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions themed on published values; neither is in this pack |
| 2. Saltmarsh Games interview process, live operations | unavailable | Every call was refused. It would have fed loop structure and persona weights; the loop here rests on your own words, one 60-minute session with Tobias |
| 3. Saltmarsh Games strategy and recent news | unavailable | Every call was refused. It would have grounded the CO bank, B5 and D2, which are labeled generic |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Every call was refused. It would have fed an interviewer read and tuned persona weights and reverse questions; none is in this pack |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Web search access, which was not granted in this session → values, loop structure, strategy and Tobias's public footprint, so B5 and D2 become grounded, an interviewer read appears, and persona weights are reread from his public writing and talks. A deeper pass is also available once: up to 6 more searches and 2 more fetches, several more minutes
- The recruiter's note on what Tobias will focus on, or any exercise to prepare → coverage of a pre-declared deliverable and sharper persona weights
- The names of the two titles → B5, D2 and A5 become specific instead of generic
- Your CV as text → quotes in the evidence column come from the CV's own lines, and rows now resting on your summary can be regraded
- Your answers to the answer slots in A3, A4, A5, B4, C1, E2 and G1 → F1 to F5 and F8 gain quoted evidence and their guidance becomes story-mapped instead of slotted
- Something inspectable you can show, such as the release checklist itself, a monthly retention report, a content-calendar template or a post-event write-up → raises F3, F4, F6, F7 and F8 from medium or low toward high
- A tuesday-dossier.md from an earlier fit assessment → verified evidence, an objection list and a prohibited-claims list ready-made; this pack does not need one
