The prep pack is written and saved. Here is the summary.

I built it as a three-round loop pack, since the recruiter's email fixes all three sessions on 20 November. It rests only on what you sent: the JD, the values text, the recruiter's email, the four strategy points and your background in your own words. It has no CV text, and it has no interviewer names, because none are assigned yet. I ran no web research, because the values page, the loop and the strategy points were already in your message.

The saved file is `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-denied-b63fa4da/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It holds a shared fit snapshot, a bank for each round (8, 10 and 12 questions) with reverse questions, and the values cheat sheet for the panel round. It also has a requirement-coverage table, a list of claims the pack won't coach, and an upgrade menu.

The pack names the contact-centre gap as your highest-ROI prep (D1). You told me you've never worked in a contact centre, and the JD's first duty names it, so expect it in some form with your future manager. D1 rehearses naming the limit before they press, then holding through three follow-ups. The second stated gap is presenting above regional level, covered in D2.

Your material has no sentence for several JD lines, so those answers are slots only you can fill, in your own words:
- **Regulated complaints:** whether your complaints log was governed by rules or time limits.
- **Monthly report:** what your spreadsheet counted.
- **Coaching supervisors:** whether you've walked another supervisor through an escalation.
- **Digital self-service:** whether you've worked with a digital team.
- **Excel:** whether the spreadsheet was in Excel.

Tell me your answers and I'll fold them into the pack as your own words.

I can run a live drill with you now, playing the manager from round 2 on D1, the pack's top rehearsal. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to a Word document if you'd like.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds, all on 20 November 2026 (built 11 November 2026).

| Round | Length | Who | Relationship | Names |
|---|---|---|---|---|
| 1 | 30 min | The recruiter | Recruiter screen | Not given |
| 2 | 45 min | Head of Member Services | Your future manager, mostly behavioural | Not assigned yet |
| 3 | 60 min | Panel of two branch managers | Panel, includes a 20-minute case on a complaint escalation, and the values round, scored against the four values | Not assigned yet |

Built from your message alone: the JD, the values text you copied this morning, the recruiter's email, the four strategy points you relayed from the July 2026 brief, and your background in your own words. There is no CV text, so every statement about your past in this pack is one of your sentences from your message, quoted.

## How to use this pack

- Personas say how a question arrives. Types say what is being scored. Every question carries both a persona (its bank) and a type tag.
- Type key. VAL: whether your past shows the published values. EXP: whether what you said about your work survives scrutiny. JD: whether you can do the listed job, gaps included. CO: whether you can think at the company's altitude. CASE: a live problem from the role.
- Guidance is scaffolding, not a script. All wording offered for you to say is proposed, pending your approval, and nothing in it should be said unless it is true for you.
- An answer slot is an instruction for the interview, not a question for me. It has two honest branches, and the second always lets the answer be that it did not happen or was not yours.
- The 18 to 26 question total in session mode does not apply here; each round has its own bank (8, 10 and 12 questions).

## Prep triage (nine days, 11 to 19 November)

1. **11 to 12 Nov: fill the answer slots only you can fill.** F2, F5, F6, F7, F9 in the fit snapshot, then D2. Write two or three plain sentences each. Anything you tell me, I can fold into the pack as your own words.
2. **13 to 15 Nov: D1, then D2.** D1 is the highest-ROI prep in this pack. Say it aloud, with a friend or a recording, through all three follow-ups.
3. **16 to 17 Nov: round 3.** Choose one story per value for G1 to G4 (or the honest branch), then run H1 aloud against a 20-minute timer.
4. **18 to 19 Nov: A1 and the reverse questions for each round, then stop.** Three rounds in one day is a stamina problem as much as a content one.

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Proposed language below is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your sentence reaches the length and the sector in other terms, and the words stay in its terms: "I've spent six years in retail banking, the last three as a branch supervisor." Customer operations is the JD's phrase, not yours; leave the link to them. Self-reported, nothing inspected, so expect a probe |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says a formal complaints log, and the material does not show what governed it. Answer slot: the JD's complaints-handling line makes a probe on what governed your log likely. If any rules or time limits governed how you handled it, say what they were, in your own words; if none that you know of, say so plainly and stay with the log: "I handled the branch's formal complaints log." |
| F3 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Adjacent, not the same: your sentence carries one branch's log, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end wording makes a probe on what happened beyond your branch likely. If any of that was yours, say which part and how, in your own words; if the log was where your part ended, or none of it was yours, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I haven't worked in a contact centre." Then a plan, said as a plan and never as a past (see D1). The branches half of this requirement is carried by F3's evidence. Never a claim to contact-centre exposure, and nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet and does not say what it counted. Answer slot: the JD's monthly-reporting line makes a probe on what yours counted likely. If you know what it counted or measured, say so in your own words; if you do not, or that part was not yours, say so plainly and stay with the spreadsheet: "I built the monthly complaints spreadsheet our regional manager uses." |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Adjacent: new tellers and a script, not supervisors and live cases. Words at that scope: "I trained new tellers on our escalation script." Answer slot: if you ever walked another supervisor through an escalation, say what and which part was yours; if you never did, say so plainly and stay with the tellers. The pack's observation: your material has you in the supervisor seat for three years, and this role coaches people in it |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: if you ever worked with a digital or product team on anything members used themselves, say what and which part was yours; if you did not, say so plainly and stay with the complaints log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Words: "I haven't presented above regional level." The pack's observation: your sentence sets the limit at above regional level; it does not say what you have presented at regional level, and the recruiter's email does not say who sits above that level in these rounds. Never a claim to presenting to senior leaders, and never a claim to regional-level presenting your sentence does not make |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, not Excel. Answer slot: if a probe asks which tool, name it in your own words; if you do not remember, or it was not a tool you chose, say so plainly and stay with the spreadsheet you built |

## Round 1: the recruiter (30 minutes)

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, loose questions: your journey, why Ashgrove | 5 questions. Relationship prior for a recruiter screen; the recruiter's email calls round 1 a 30-minute conversation | Prepare a 90-second arc and treat casual questions about JD topics as scored |
| Skeptic (light) | Knockout-style checks on the gaps | 3 questions. Light weight by the recruiter-screen prior; the contact-centre and presenting limits you stated are the likeliest checks | Name the limit first, plainly, then what your sentences do carry |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with only the beats your sentences state: six years in retail banking, the last three as a branch supervisor; handled the branch's formal complaints log; trained new tellers on the escalation script; built the monthly complaints spreadsheet your regional manager uses. Answer slot: why this role and why now is yours to say, in your own words; the pack supplies no reason. Stop after the beats; do not add a fourth step | Opens almost every conversational screen, so it is the one answer to have word-perfect. EXP because it is where the F1 to F6 sentences first get tested |
| A2 | "What drew you to Ashgrove?" | VAL | [grounded] | Choose one or two of the published values by their exact names (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix) and say why it matters to you, in your own words. Do not say you have followed Ashgrove for years unless that is true | The recruiter's email says round 3 scores the four values, so round 1 is the first place the names should come out right. VAL because it tests alignment with published values, not generic virtue |
| A3 | "Tell me about anything you've done around self-service for members." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for F7: pick an occasion where a member used an app, a website or a form instead of staff, and you saw it work or fail; it needs what the member was trying to do, what you saw, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the complaints log you handled, or how you would approach it | The JD's digital line is F7, where your material is silent, and the open prompt lets the honest branch be the answer. JD because it scores a stated responsibility |
| A4 | "Tell me about the spreadsheet reporting you've done." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The hold is the sentence: "I built the monthly complaints spreadsheet our regional manager uses." Then the F5 and F9 slots: say what it counted and which tool it was, in your own words; where you do not know, or it was not yours, say so plainly and stay with the spreadsheet you built | F5 and F9 both rest on this one sentence, so a recruiter who asks once is asking twice. JD because Excel reporting and monthly reporting are both stated requirements |
| A5 | "What do you know about where Ashgrove is heading?" | CO | [inferred] | The four moves in the July 2026 brief, as you relayed them: 40% of member service to digital channels by 2028, eight branches into five hubs over 2027, a small-business lending product in Q1 2027, and app-only banks as the main competitive pressure. Then one sentence on what that could mean for complaints, which is yours to make; one line of reasoning you could argue is that more member service moving digital changes where a complaint starts. Say it as a view, not as something you have seen | Strategy fluency is the cheapest way to sound current in a screen. Inferred from the brief's first point; the link to complaints is this pack's derivation, and CO because it tests altitude |
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Pick the one that is true and say it first, plainly: "I haven't worked in a contact centre" or "I haven't presented above regional level." Then your plan for it, said as a plan. Do not offer both limits unprompted unless they ask for more | The stems of a screen's Skeptic probe the gap you would least like to name, and F4 and F8 are those gaps. JD because it scores the listed job including its gaps |
| B2 | "This role covers the contact centre as well as the branches, and you've never worked in a contact centre. Is that a problem?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The short form of D1: "I haven't worked in a contact centre." Then what your sentences carry, at their scope: "I handled the branch's formal complaints log." Then a one-line plan. Keep it to 30 seconds; the long version is for round 2 | F4 is the stated gap and the JD's first duty names the contact centre, so a recruiter screening for knockouts will reach it. JD because it scores a stated requirement |
| B3 | "What makes this the next step after branch supervisor?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Your reason is yours, in your own words; the pack supplies none. Keep it forward-looking and tie it to something from A2 or the strategy points, and stay inside what the sentence carries: three years as a branch supervisor | A recruiter's motivation-consistency check. EXP because it tests whether the career story hangs together |

### Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| RV1 | "What does the 20-minute case in the final round look like: written, spoken, any material beforehand?" | Your email gives its length but not its format; the answer lets you prepare the right way |
| RV2 | "Which complaint rules does this role work to day to day?" | Turns the F2 unknown into something you can answer in context, and shows you take the regulated part seriously |
| RV3 | "Are the three rounds back to back, and is there a break between them?" | Practical, and it shows you are planning the day |
| RV4 | "Which of the brief's changes, the digital move, the hubs or the small-business lending launch, will touch complaints first?" | Shows you read the July brief and connect it to the role |
| RV5 | "When will I know who I'm meeting in rounds two and three?" | Lets you research their public professional footprint and sharpen those rounds |

## Round 2: the Head of Member Services (45 minutes, your would-be manager)

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Past-behaviour probes, STAR-shaped | 3 questions. The recruiter's email says this round is mostly behavioural, which outranks the hiring-manager prior | "We" for context, "I" for contribution; choose stories where the hard truth landed, and say so where your material shows none |
| Skeptic | Quiet, persistent probing of the gaps | 3 questions. Hiring-manager prior, and your own stated limits (F4, F8) are exactly what a future manager would derisk | Rehearse the objection until it is boring: name the limit first, hold through two follow-ups |
| Case/Strategist | Live problems from the role's roadmap | 2 questions. Hiring-manager prior, reduced because the round is described as mostly behavioural | Clarify, objective, approach, metrics, risks; think aloud |
| Data-Driven Prober | Reads your claims line by line | 2 questions. The spreadsheet sentence is the one thing you built that can be walked through | Know what you can and cannot say about what it counted, and say plainly when you do not know |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a complaint that was hard to resolve." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, since your sentence carries the log and no particular complaint: pick one from the log with a named stake (no member names), a moment it was yours to decide or chase, and how it ended; tell it as situation, what you did, what happened. If no such complaint comes to mind, say so plainly, then give the nearest thing your material carries, handling the branch's formal complaints log, or how you would approach it | Complaint handling is the JD's heart and the one place your material has depth, so this is the likeliest behavioural opener. EXP because it tests what was actually yours |
| C2 | "Tell me about a time you trained or coached someone through something difficult." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F6: the beats the sentence states, new tellers and the escalation script, told in your own words. Answer slot: if a teller got stuck on the script and you changed how you taught it, say what happened and which part was yours; if that did not happen, say so plainly and stay with training new tellers on the script | F6 is your only coaching evidence and sits one step from the role's coaching duty. JD because it scores a stated responsibility |
| C3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told a manager something they did not want to hear; it needs a named stake, what you said, how it landed, and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. Keep to the manager level you have actually spoken to | Behavioural rounds probe candour, and F8 says you have not presented above regional level, so this tests what you have said upward. VAL because it tests behaviour against Plain Words and Own the Fix, not generic virtue |
| D1 | "You've never worked in a contact centre, and this role owns complaints across the branches and the contact centre. Where does that leave you on day one?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **Highest-ROI prep in the pack.** Open by naming the limit before they press: "I haven't worked in a contact centre." Then what your sentence carries, at its scope: "I handled the branch's formal complaints log." Then a plan, said as a plan (pick only what you would really do): spend time with the contact-centre team on live complaints; read the cases they have closed; ask their team leaders where I am getting their side wrong; keep hold of whatever I find until it is solved. Follow-up 1, "What do you actually know about how complaints move through the contact centre?": answer slot, if you know how complaints reach the branch from the contact centre, say what, in your own words; if you do not, say so plainly. Follow-up 2, "Would you want someone with contact-centre experience beside you?": hold that you can own the process, concede what you would want to learn from them, and answer truthfully. Follow-up 3, "Why should we take the risk on you?": hold only what your sentences carry (the six years, the log, the escalation script, the spreadsheet) and add nothing | F4 is the one gap you stated, the JD's first duty names the contact centre, and the recruiter's email makes the hiring manager the person who must derisk it, so this objection will arrive in some form. It gets the deepest rehearsal: the limit is named before it is asked for, with three levels of follow-up. JD because it scores a stated requirement |
| D2 | "The role presents to senior leaders. You've never presented above regional level. What's your plan for the first time?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses." | Plain acknowledgment first: "I haven't presented above regional level." Answer slot: if you have presented anything at regional level, say what and to whom, in your own words; if what the regional manager saw was the spreadsheet, or you never presented there, say so plainly and stay with: "I built the monthly complaints spreadsheet our regional manager uses." Then your plan, as a plan: ask what decision the audience needs from the page, lead with that, and bring one page | F8 is the second stated limit and the JD asks for confidence presenting. Hold through two follow-ups, concede what you have not done. JD because it scores a stated requirement |
| D3 | "Coaching branch supervisors means coaching people in a job you've held. What changes when you're the coach?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold what the sentences carry: three years as a branch supervisor, and "I trained new tellers on our escalation script." Answer slot: if you have walked another supervisor through an escalation, say what and which part was yours; if you have not, say so plainly and stay with the tellers. Then the shift as a plan: ask what the supervisor would do before offering what you would | F6's observation made into a question: the role reverses your seat. JD because it scores the coaching duty |
| E1 | "You've been asked to put a monthly complaints report in front of senior leaders for the first time. What do you need to know first, and what goes on the page?" | CASE | [generic] | Clarify: what decision the audience takes from it, what they already see, and which complaints count. Objective: one page that changes a decision. Approach: what moved and where (branches against the contact centre), trend not one-offs, and one member story beside the numbers, which is where Neighbours, Not Numbers matters. Risks: numbers that move for reasons the page cannot explain. Think aloud and challenge one premise respectfully | Live problem from the JD's monthly-reporting and presenting lines; it asks about no past, so it claims nothing about yours. CASE because it is delivered live |
| E2 | "Over 2027, eight branches become five hubs. A member's formal complaint reaches a branch that's about to close. Who holds it?" | CASE | [inferred] | Clarify: what stage it is at, what has been promised, and when the branch closes. Objective: the member never has to tell it twice (Plain Words). Approach: one named owner until it is solved (Own the Fix), a handover rule so a closing branch cannot drop it, and a plain update to the member at each change. Risk: complaints that fall between sites during the change. Inferred from the brief's consolidation point; the scenario is this pack's | Ties the strategy brief to the role and to two published values. CASE because it is a live problem |
| F1 | "Walk me through the monthly complaints spreadsheet you built. What did it show, and who used it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Beats the sentence states: monthly, complaints, a spreadsheet you built, used by your regional manager. Answer slots: name what it counted, in your own words; name the assumption in it you would defend least, in your own words; say which part was yours and which was not. Where you do not know how something was counted, say so plainly | Prober round: F5's gap is exactly where this lands. EXP because it tests what was actually yours |
| F2 | "What did your regional manager do with it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you know of any decision or action it fed, say what, in your own words; if you do not know, or none that you saw, say so plainly and stay with: "I built the monthly complaints spreadsheet our regional manager uses." Do not add a use you did not see | The follow-up a prober asks of any report; the honest answer may be that you do not know, and that is a good answer if it is true. EXP because it tests attribution |

### Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| RV1 | "Where do complaints get stuck today between the branches and the contact centre?" | Moves from interview to problem-solving, and echoes Own the Fix |
| RV2 | "How will complaint ownership work through the move from eight branches to five hubs?" | Connects the role to the 2027 plan and shows you read it |
| RV3 | "Which self-service journeys does the 40% digital target put first, and where do complaints sit among them?" | Brings F7 into the open from your side, as curiosity |
| RV4 | "What does the monthly report look like today, and what do leaders do with it?" | Tells you what F5 and F8 are really asking for |
| RV5 | "What support do new leads get when presenting to senior leaders in their first months?" | Names the F8 limit as a plan, in the form of a question |

## Round 3: the panel of two branch managers (60 minutes, includes the 20-minute case and the values round)

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes mapped to the four published values | 5 questions. The recruiter's email says the panel scores against the four values | Map one story per value where your sentences carry one, and a selection scaffold where none does |
| Case/Strategist | The 20-minute complaint escalation case | 4 questions. The email names the case, and 20 of 60 minutes is about a third of the round | Clarify, objective, approach, metrics, risks, thinking aloud |
| Peer Evaluator | Seam-splitting between branches and the role; "what would you need from us" | 3 questions. The panel are branch managers and the role coaches branch supervisors, so partnership fit is a likely probe (inference from the recruiter's email and the JD) | Reciprocity: what you bring their branch, not only what you need; propose seam principles |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Members First, Always: pick a complaint where what the member needed and what the process wanted pulled apart; it needs a named stake, a decision that was yours, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, handling the branch's formal complaints log, or how you would decide | The value's own words are the theme. VAL because it tests the published value |
| G2 | "Tell me about a time something had to be explained to a member twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on Plain Words only as far as the sentence goes: "trained new tellers on our escalation script" is the script work. Answer slot: if you ever changed how something was worded because it was not clear, say what and why, in your own words; if you did not, say so plainly and stay with training the tellers on the script | The value says if a member needs it explained twice, the writing is wrong. VAL because it tests that value |
| G3 | "Our values say every branch is part of its town. Tell me about a time your branch's local situation changed what you did." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Neighbours, Not Numbers: pick a time something particular to your branch's town changed a decision; it needs the local detail, what you did differently, and why. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the branch's complaints log, or how you would think about it | Branch managers will hold this value dear. VAL because it tests that value |
| G4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F2: "I handled the branch's formal complaints log." Answer slot for Own the Fix: if any complaint stayed with you from the log to its resolution, say which and what you did; if none did, or it passed to someone else, say so plainly and stay with the log you handled | The value's own words are the theme; it also sits beside the JD's escalation duty. VAL because it tests that value |
| G5 | "You'll report complaint numbers every month, and our values say Neighbours, Not Numbers. How do you report numbers without losing the member?" | VAL | [grounded] | Numbers say where; a member's story says why. Present one story beside each trend, say what the number cannot show, and keep the page short. Position yours and hold it through a follow-up, conceding what a page cannot capture | The JD's monthly report and the third value pull in opposite directions, which a values panel will notice. VAL because it asks how a value shapes the job |
| H1 | "A member's formal complaint has been open much longer than it should. It started at a branch, moved to the contact centre, and the member has now come back to the branch, angry. You're the Member Experience Lead. Walk us through your first 24 hours." | CASE | [generic] | Clarify first: what the member asked for and what has been promised, where the complaint sits and who holds it, what clock applies to it, whether anything has been said to the member more than once. Objective: the member hears it once and the fix has one owner. Approach: name the owner, call the member today in plain words, chase the contact-centre side, log each decision. Metrics: time to resolution and repeats. Concede what you do not know about the contact-centre side and say who you would ask | The panel's case, from the recruiter's email. CASE because it is delivered live; it asks about no past |
| H2 | "The supervisor who escalated it says she followed the script. How do you coach her?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Ask first what happened, in her words. Separate script from judgement; coach her to keep hold of the member after the escalation (Own the Fix); look at whether the script itself needs rewording (Plain Words). You may draw on your script work at its scope: "I trained new tellers on our escalation script." Answer slot: if you have walked a supervisor through something like this, say what and which part was yours; if not, say so plainly and stay with the tellers | F6 inside the case. CASE because it is a live problem; the quote only bounds what you may claim |
| H3 | "Same case: what would you tell senior leaders about it next month, in three lines?" | CASE | [generic] | The fact, the cause so far, and what is being done, in plain words. Say what you do not yet know. Resist adding a number you cannot defend | F5 and F8 again, in the case. CASE because it is delivered live |
| H4 | "One of us would escalate this to the Head of Member Services now, the other would keep it with the branch. Which is right?" | CASE | [generic] | Clarify what the decision turns on before choosing. Take a position, hold it through two follow-ups, and concede what you would want to know. A view you can defend: escalate the decision, and keep hold of the member | The panel may deliberately disagree to see how you hold a position. CASE because the pressure sits inside the case |
| I1 | "Our supervisors already have an escalation script. What would you change, and what would you leave alone?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Ask first what is working and what the supervisors find hard; do not pretend to know their script. Offer principles, not a rewrite: keep what members never have to say twice. Your own script work is at its scope: "I trained new tellers on our escalation script." | The role coaches on escalations. JD because it scores that responsibility |
| I2 | "Over 2027, eight branches become five hubs. What do you need from branch managers, and what do we get from you?" | CO | [grounded] | Reciprocity first: a single owner for every complaint, plain updates, and your time on the floor. Then what you would need: what they see that a report will not. The brief's consolidation point is the context; the panel may feel it personally (inference) | Partnership fit plus strategy fluency. CO because it tests the company's altitude |
| I3 | "How do you handle credit when a problem is solved across the branch and the contact centre?" | VAL | [generic] | Selection scaffold: pick a time a result depended on someone outside your branch; it needs who, what each did, and how the credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Persona stem for partnership. VAL because it tests behaviour with equals |

### Values and principles cheat sheet (round 3)

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's side | F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." carries no particular decision, so use G1's scaffold; if none comes to mind, say so plainly and give the log |
| Plain Words | Writing a member must read twice is the writer's fault | F6: "I trained new tellers on our escalation script." is the script work; G2's slot covers any rewording, and if there was none, say so plainly |
| Neighbours, Not Numbers | Each branch belongs to its town | F2: the branch's formal complaints log is the nearest your sentence carries; use G3's scaffold, and if no local story comes to mind, say so plainly |
| Own the Fix | The finder keeps the problem until it is solved | F2: "I handled the branch's formal complaints log" with G4's slot; if no complaint stayed with you to its end, say so plainly |

### Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| RV1 | "What do your supervisors find hardest about escalations today?" | It is their ground and gets them describing the problem you would coach |
| RV2 | "What would make you say the complaints lead understood your branch?" | Ties to Neighbours, Not Numbers and asks them for the measure |
| RV3 | "What could a new complaints lead do in their first month that would genuinely help your branch?" | The reciprocity question for a peer panel |
| RV4 | "How would you want to hear about a complaint moving from your branch to the contact centre?" | Practical, and your Own the Fix idea in their terms |
| RV5 | "Which of the four values is hardest to live in a branch day to day?" | Invites an honest answer rather than a performance |

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B2, D1, E2, H1, H4, I3 |
| "report monthly on complaint volumes and resolution times" | A4, E1, F1, F2, G5, H3 |
| "coach branch supervisors on escalations" | C2, D3, H2, I1 |
| "work with digital teams on self-service journeys" | A3, A5 |
| "4+ years in financial-services customer operations" | A1, B3 |
| "experience handling regulated complaints" | C1, G4 |
| "confident presenting to senior leaders" | C3, D2, E1, H3 |
| "comfortable with Excel reporting" | A4, F1 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says one branch's log, not the process end to end |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation: your material says formal, and does not say what governed them |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: "I trained new tellers on our escalation script." |
| Reported monthly on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The pack's observation: the material does not say what it counted |
| Excel reporting skill | Inflated form of F9 | F9's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The tool is an answer slot |
| Has contact-centre experience | Negative you stated, F4 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I haven't presented above regional level." No slot |

## Sources

Provided documents: the JD (your message); the values text copied on 11 November 2026 from ashgrovecu.org/about/values (your message); the recruiter's email on the three rounds (your message); the four points you relayed from the 2026 strategy brief Ashgrove published in July 2026 (your message; the brief itself is not in hand); your background (your message). No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the cheat sheet or A2: the values text you pasted this morning gives the four names and definitions |
| 2. `Ashgrove Credit Union interview process member services` | skipped | Could not have moved the persona weights: the recruiter's email gives the number of sessions, who runs each and what each holds |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Could not have moved the CO questions: the four brief points you relayed already supply the priorities and the competitive frame; the full brief would sharpen them, which the upgrade menu offers |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No name was given, only roles, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your own answers to the answer slots in F2, F3, F5, F6, F7, F9 and D2 → those rows' bridges and the banks that rest on them regenerate from your own words, and slots turn into stories
- The names of the Head of Member Services and the two panel members → an interviewer read from their public professional footprint, persona weights tuned to them, and one reverse question tied to their own path
- The full text of the July 2026 strategy brief → a grounding brief section and CO questions in the brief's own vocabulary
- The recruiter's answers to RV1, RV2 and RV3 for round 1 (case format, which complaint rules apply, breaks) → case preparation matched to the real format, and F2 answered in context
- A CV → more of your own sentences to quote, so some `discovery` rows may upgrade
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → strategy and recent-news context for the CO questions and the loop; say the word and I will run it
- A tuesday-dossier.md from an earlier pass over this role → verified evidence and prohibited claims arrive pre-graded
