The prep pack is written and saved. I'm now sending you the summary and the offers.

Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-canned-e3b417f1/ashgrove_credit_union_member_experience_lead_interview_pack.md`.

I built it as a three-round loop: recruiter, Head of Member Services, then the branch-manager panel. Each round has its own persona weights, question bank and reverse questions. It has 27 questions in total.

- **Fit snapshot:** it rests only on four sentences from your message. Two JD lines are gaps you stated yourself: contact-centre experience and presenting above regional level. They are marked as gaps and not bridged.
- **Highest-ROI prep:** question 2A1, the end-to-end, contact-centre objection from your future manager. I inferred it from the gap between the JD and your four sentences. The pack coaches you to name the limit first, hold at the scope of what you actually did, then give a ramp plan.
- **Values round:** none of your four sentences carries a story for the four values, so each one is a selection scaffold with an honest "if nothing comes to mind" branch. The first upgrade-menu line shows how to turn them into real stories.
- **Not covered:** I didn't coach pay or notice period, because they're your own facts. The pack also doesn't guess the content of the 20-minute escalation case. Question 3B1 is a stand-in until the recruiter says what it covers.
- **Research:** I ran no searches, because your pasted values, the recruiter's email, the strategy facts and the JD already settled every research target. The upgrade menu offers a deeper pass once.

Say the word and I'll play the Skeptic on 2A1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_credit_union_member_experience_lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode, three rounds on 20 November 2026 (prepared 11 November 2026).

| Round | Who | Length | Format, from the recruiter's email |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Conversation |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewer names are not assigned yet, so there is no interviewer read. Rounds 1 to 3 each have their own persona weights, bank and reverse questions below; the fit snapshot, prohibited claims, values sheet, coverage line, sources and upgrade menu are shared.

## How to use this pack

- Personas are how a question is asked; types are what it scores. Guidance is scaffolding for a spoken answer, not a script.
- Types: VAL is behavioural or values alignment; EXP is a work-experience deep-dive; JD is role and JD-driven; CO is company and strategy knowledge; CASE is a hypothetical or live problem.
- Every guidance cell, bridge and scaffold in this pack is proposed language, pending your approval. Rehearse only what you actually did, in your own words.
- An answer slot is an instruction for the interview, not a question for you now. Where your real answer would improve the pack, the upgrade menu says which rows it would upgrade.
- Question IDs are round, then persona letter, then number (1A1, 2B3, 3C2).

## Fit snapshot

Your evidence cells hold four sentences from your message, quoted exactly. Everything the pack says about your past rests on them and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on length, but a line in your message with nothing inspected behind it, so expect a probe on what the years consisted of. Lead with the sentence in its own terms: six years in retail banking, the last three as a branch supervisor |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log and training new tellers, not the process and not other branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end wording makes a probe on what sat outside your own branch likely. If any step beyond your branch's log passed through you, say which and what you did, in your own words; if none did, or it was not yours, say so plainly and stay with the log you handled |
| F3 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Formal is not the same word as regulated, and your sentence does not say what governed the log. Answer slot: the JD's wording makes a probe on this likely. If a regulatory requirement applied to the complaints in that log, say which and what part was yours, in your own words; if none did, or you do not know, say so plainly and stay with the formal log you handled |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says a monthly complaints spreadsheet your regional manager uses; it does not say what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet showed. If it counted either, say how, in your own words; if it counted something else, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet you built |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Adjacent work: your sentence says new tellers, not supervisors, and the words stay at tellers: "I trained new tellers on our escalation script." Answer slot: if you walked a fellow supervisor or a manager through an escalation, say what you did and how, in your own words; if you did not, say so plainly and stay with the tellers |
| F7 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material speaks to this. Answer slot: if you worked with a digital or IT team on something members or customers used, say what you needed from them and what changed, in your own words; if you did not, say so plainly and say how you would start |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says spreadsheet, not Excel. Answer slot: if it was built in Excel, say what you did in it, in your own words; if it was another tool, or you do not know, say so plainly and stay with the spreadsheet you built |

## Requirement coverage

| JD requirement | Fit row | Questions that cover it |
|---|---|---|
| 4+ years in financial-services customer operations | F1 | 1A1, 1B3 |
| Own the complaints process end to end | F2 | 2A1, 3B1 |
| Across branches and the contact centre | F3 | 1B1, 2A1 |
| Experience handling regulated complaints | F4 | 2A3 |
| Report monthly on volumes and resolution times | F5 | 1A3, 2A5, 2B3 |
| Coach branch supervisors on escalations | F6 | 2A4, 3B3, 3C1 |
| Confident presenting to senior leaders | F7 | 1B2, 2A2 |
| Work with digital teams on self-service journeys | F8 | 1A4, 2C1 |
| Comfortable with Excel reporting | F9 | 1A3, 2A5 |
| Complaint escalation case (recruiter's email) | none | 3B1, 3B3 |

## Prohibited claims

Built from the snapshot before any bank was written. No guidance, slot, bridge or drill feedback in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log, not the process. Slot 2A1 stays inside the log |
| Has handled regulated complaints | Inflated form of F4 | F4's quote at its own scope. The material says formal, not regulated. Slot 2A3 asks only what governed the log |
| Reported complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope. The material says a monthly spreadsheet, not what it counted. Slots 1A3 and 2A5 ask only what it showed |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: new tellers. Slot 2A4 stays with the tellers unless you say otherwise |
| Advanced Excel reporting | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. Slot 2A5 asks only which tool it was |
| Has worked in a contact centre | Negative you stated, F3 | The plain acknowledgment F3 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never presented to anyone above regional level." No slot |

## Grounding brief

Vocabulary and headline facts from the 2026 strategy brief the recruiter sent (published July 2026), as you gave them to me. Sound current; do not recite.

| Fact | Provenance | Where it shows up |
|---|---|---|
| 40% of member service to move to digital channels by 2028 | [grounded] | 1A4, 2C1 |
| Eight branches consolidate into five hubs over 2027 | [grounded] | 3A3, 3B2 |
| A small-business lending product launches in Q1 2027 | [grounded] | Reverse question 2R5 |
| The main competitive pressure is app-only banks | [grounded] | 2C2 |
| Members, not customers; the contact centre, not the call centre; hubs | [grounded] | Use their words for their organisation; yours for your own past |

## Values and principles cheat sheet

The panel scores against these four, as published on the values page you copied on 11 November 2026. None of your four sentences carries a story for any of them, so each row is a selection scaffold, and the pack supplies no ending.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | Selection scaffold for 3A1: pick a time you made a decision from the customer's side that cost something; it needs a named stake, what you chose, and what the customer saw. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs something explained twice, the fault is in the writing | Selection scaffold for 3A2: pick a time you reworded or re-explained something because someone did not follow it; it needs the original wording, what was unclear, and the version that worked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Each branch belongs to its town, not only to its figures | Selection scaffold for 3A3: pick a time you weighed a local need against a figure or a rule; it needs the figure, the local need, and the call you made. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | Selection scaffold for 3A4: pick a time you found a problem and stayed with it to the end; it needs the moment you found it, the point you could have passed it on, and how it closed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

# Round 1 — the recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly biography, motivation and logistics questions | Higher. The recruiter-screen prior is Conversational plus a light Skeptic; your email names a 30-minute conversation with the recruiter. Logistics such as notice and pay may come up; the pack coaches none because they are your own facts | A 90-second arc for the biography (1A1); treat casual questions as scored; never answer the reverse-question slot with "I think you've covered everything" |
| Skeptic (light) | Knockout-style checks on the gaps | Lower. Same prior; the JD's contact-centre and senior-leader lines are where F3 and F7 point | Say the limit plainly first, then the plan (1B1, 1B2) |

## Question bank

Proposed answer guidance, pending your approval.

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F1, F2 and F5: ninety seconds, three beats the quotes state, each in your own words: six years in retail banking, the last three as a branch supervisor; handling the branch's formal complaints log and training new tellers on the escalation script; building the monthly complaints spreadsheet your regional manager uses. Stop at the last beat and add no scope to any of them. Answer slot: the reason for this move is yours and nothing in the material supplies it, so give the one you would stand behind on a second question | F1, F2 and F5 are the most role-relevant sentences you have; EXP because the biography question tests what was actually yours, in a conversational register |
| 1A2 | "Why a member-owned credit union, and why now?" | CO | [grounded] | Name one of the four published values by its official name and say in your own words why it matters to you. Answer slot: if a sentence from your own work fits that value, use one you can stand behind and keep it to what it states; if none comes to mind, say so plainly and stay with why the value matters | A motivation check is near-certain in a recruiter screen; CO because it tests homework on the values page you supplied |
| 1A3 | "What does a good monthly complaints report look like to you?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Describe the report as its reader would want it: the JD names volumes and resolution times, so say what a leader should see in each and what they should do with it. For what you built, stay with the sentence: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it showed volumes or resolution times, say how a figure was counted, in your own words; if it showed something else, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet you built | F5 and F9; JD because the reporting line is a stated requirement, asked casually |
| 1A4 | "When have you worked with a digital or IT team on something members or customers used?" | JD | [grounded] | F8 has no quote, so this is a selection scaffold: pick one occasion with a named change, what you needed from the team, and what was different afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F8 is the one requirement your material does not touch; JD because the self-service line is stated, and the strategy's digital shift makes it a likely casual topic |
| 1A5 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Choose two of the four facts in the grounding brief and say them in plain words; connect one to complaints as your view, not as your past. Do not recite the brief. This asks nothing about your history, so the guidance makes no claim about it | CO; the strategy brief is the one document interviewers and rival candidates may both have read, so one fact plus one view of your own is what separates you |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1B1 | "The role covers the contact centre as well as the branches. What's your contact-centre background?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Plain acknowledgment first, in your own voice: "I've never worked in a contact centre." Then the nearest thing your material carries, at its own scope: "I handled the branch's formal complaints log." Then a ramp plan, said as a plan and not a past: what you would ask for and whom you would shadow in the first weeks, in your own words. Describe no contact-centre work you have not done | F3 is the stated gap and the JD names the contact centre; the light version of the pack's highest-ROI objection, which 2A1 rehearses in depth |
| 1B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Your own message states two limits, the contact centre and presenting above regional level. Pick the one you would name first, say it plainly, then what you would do about it. Do not name a weakness you do not have to sound modest, and do not hide one you have | F3 and F7; JD because it scores honest self-assessment against the listed requirements |
| 1B3 | "The role asks for 4+ years in financial-services customer operations. Where do your years sit?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say the sentence in its own terms: six years in retail banking, the last three as a branch supervisor. Answer slot: if asked what customer operations meant at your branch, describe the work you did in your own words; if part of it was not yours, say so plainly and stay with what was | F1 is the direct row, so this is a knockout-style confirmation; JD because it scores the stated years requirement |

### Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| 1R1 | "What will the 20-minute escalation case cover, and will I get any material beforehand?" | Your email gives its length and not its content; the recruiter can usually answer in one line, and it shows you plan to use the time |
| 1R2 | "Can you tell me who will be on the panel once it is assigned?" | Names unlock an interviewer read and reweighted personas; asking early reads as preparation |
| 1R3 | "What prompted the role: a new post, or a change to an existing one?" | Context that shapes how you frame yourself to the Head of Member Services |
| 1R4 | "What would a strong first ninety days look like to the Head of Member Services?" | Gives you the success measure before round 2 and shows you think in outcomes |
| 1R5 | "Is there anything in my background you would want me to be ready to address in the later rounds?" | Invites the contact-centre and senior-presentation gaps into the open on your terms |

# Round 2 — Head of Member Services (45 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Persistent probing of the distance between your material and the JD | Highest. The hiring-manager prior is Case plus Skeptic, and this person would be your manager, buying capability and weighing gaps; F2, F3 and F7 are the widest | Rehearse the single most predictable objection until it is boring (2A1); say the limit before they ask |
| Values and Behavioral | Scenario probes, STAR-shaped stories | Mid. Your email says the round is mostly behavioural, which lifts this above the prior | Selection scaffolds with an honest branch; "we" for context, "I" for what you did |
| Case and Strategist | Live questions on the role's own strategy | Lowest. The prior is Case plus Skeptic, but your email says mostly behavioural, so Case drops to two questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |

## Question bank

Proposed answer guidance, pending your approval.

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "This role owns the complaints process end to end across branches and the contact centre. Your experience is a branch's log. How do you close that distance?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Name the limit yourself in your first twenty seconds, in the quotes' own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script, and I've never worked in a contact centre." Hold there and do not stretch the log into the process. Likely follow-up one, on what you owned outside your branch. Answer slot: if any step beyond your branch's log passed through you, say which and what you did; if none did, or it was not yours, say so plainly and return to the log. Likely follow-up two, on why you think you can run both. Concede specifically, since end to end across the contact centre is new to you, then give a ramp plan as a plan: what you would ask first and whom you would shadow, in your own words. Never fold on what you did handle, and never add to it | F2 and F3 are the widest distance between the JD and your material, so this objection arrives in some form; it gets the most follow-up levels and the exact concession wording; JD because it scores the stated requirement |
| 2A2 | "The JD asks for confidence presenting to senior leaders. When have you presented to people more senior than you?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Plain acknowledgment: "I've never presented to anyone above regional level." Your sentence about the spreadsheet says your regional manager uses it; it does not say you presented it. Answer slot: if you have presented to your regional manager or someone at that level, say what and how it went, in your own words; if the spreadsheet was sent and not presented, or you did not present, say so plainly. Then a preparation plan, said as a plan: how you would rehearse and what you would ask the Head of Member Services about their expectations | F7 is a stated gap, and a monthly leadership report is part of the job; JD because it scores the stated requirement |
| 2A3 | "The JD asks for experience handling regulated complaints. What does that mean to you, and where have you met it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what formal meant at your branch in your own words: "I handled the branch's formal complaints log." Do not call those complaints regulated unless you can say what regulated them. Answer slot: if a regulatory requirement applied to the complaints in that log, say which and what part was yours; if none did, or you do not know, say so plainly and stay with the formal log | F4 rests on the gap between formal and regulated, which is the word the JD uses; JD because the requirement is stated |
| 2A4 | "Tell me about coaching a supervisor through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | Story-mapped at the quote's scope: you trained new tellers on the escalation script, and you were a branch supervisor for the last three of six years. Tell the training in your own words and use "I" for what you did. Answer slot: the JD asks about coaching supervisors; if you walked a fellow supervisor or a manager through an escalation, say what and how; if you did not, say so plainly and stay with the tellers | F6 is adjacent work, a step below the JD's line; JD because coaching supervisors is a listed responsibility |
| 2A5 | "Walk me through the monthly complaints spreadsheet you built. What is on it, and who reads it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on the two beats the quote states: you built it, and your regional manager uses it. Answer slot: the JD names volumes, resolution times and Excel, so expect probes on what it counted and which tool it was. If it counted either, say how; if it was built in Excel, say what you did in it; if it counted something else, was another tool, or you do not know how a figure was counted, say so plainly and stay with what you built | F5 and F9; EXP because the interviewer is testing what the spreadsheet was and what was yours |

### Values and Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, the truth in one sentence, and an intact relationship afterwards. Your material shows a report your regional manager uses, not an unwelcome message, so it carries no story for this. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role reports complaints to leaders, so unwelcome numbers are likely; VAL because it tests behaviour; `[generic]` because it is a stock behavioural pattern |
| 2B2 | "When did you put a member's interest ahead of an internal metric?" | VAL | [grounded] | Selection scaffold on the first published value: pick a time with the metric, the member's interest, and what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Maps to Members First, Always, which the panel scores in round 3; asking it here is rehearsal |
| 2B3 | "Tell me about a time something in your monthly reporting led someone to act." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on one beat: you built the spreadsheet your regional manager uses. Answer slot: if any figure in it led someone to act, say what and what part was yours; if nothing did, or you do not know, say so plainly and describe what the spreadsheet showed, in your own words | F5; JD because the JD's monthly reporting line asks what reporting is for |

### Case and Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "Ashgrove aims to move 40% of member service to digital channels by 2028. What does that do to complaints, and what would you want to know first?" | CO | [grounded] | This asks nothing about your past. Clarify first: what counts as digital, which services move first, where complaints start today. Objective: a member resolved without being explained to twice. Segments: complaints that start in digital against those that start in a branch. Approach: the same named owner whichever channel it started in. Metrics: the JD's own two, volumes and resolution times, split by channel. Risk: members who cannot or will not use digital. Challenge one premise: whether the share of service that moves tells you how many complaints move | F8 and the strategy's digital shift; CO because it needs the company's own target |
| 2C2 | "App-only banks are Ashgrove's main competitive pressure. What should a complaint experience look like to hold a member who could leave?" | CO | [grounded] | This asks nothing about your past. Clarify what a leaving member would actually point to; objective: the complaint ends with the member staying; approach: speed, plain words and one named owner; metric: resolution time; risk: speed bought at the cost of getting it right | CO; the competitive frame is the strategy's own, and complaints are where it shows |

### Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| 2R1 | "Where does a complaint hand over today between a branch and the contact centre, and which part do you most want fixed?" | Goes to the end-to-end seam the role owns and signals you will start from their problem |
| 2R2 | "How are volumes and resolution times reported today, and who reads the monthly report?" | Ties to the JD's reporting line and to who your audience would be |
| 2R3 | "How do you see the Lead working with the digital teams: who owns the journey when a member complains?" | Raises the self-service line on your terms and tests the ownership question |
| 2R4 | "With eight branches becoming five hubs, what changes for the supervisors the Lead would coach on escalations?" | Uses the strategy brief and the coaching line together |
| 2R5 | "With the small-business lending product launching in Q1 2027, who will own complaints for it?" | Shows you read the strategy to its next date, and the answer tells you how far the role's remit reaches |

# Round 3 — panel of two branch managers (60 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values and Behavioral | One scored scenario probe per published value | Highest. Your email says the panel is the values round, scored against the four values | A scaffold per value with its honest branch (the cheat sheet); "we" for context, "I" for contribution |
| Case and Strategist | The 20-minute complaint escalation case, plus strategy cases | Mid. Your email gives the case 20 of the 60 minutes | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely (3B1) |
| Peer Evaluator | Seam-splitting between the Lead and the branches | Lower. Branch managers run the branches the role serves, so the seam between them and the Lead is a natural probe | Reciprocity framing: what you bring the branches, not only what you need (3C1, 3C2) |

## Question bank

Proposed answer guidance, pending your approval.

### Values and Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold, as in the cheat sheet row for Members First, Always: a named stake, what you chose, what the customer saw. None of your four sentences carries this story. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value's own words; VAL because the panel scores it by name |
| 3A2 | "If a member needs it explained twice, we wrote it wrong. Tell me about a time you reworded or re-explained something because someone did not follow it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: the original wording, what was unclear, the version that worked. Your sentence says you trained new tellers on the escalation script; it does not say you wrote or changed it. Answer slot: if you reworded any part of the script or how it was explained, say what and why; if the script was given to you as it was, say so plainly and tell a different time or how you would handle it | Plain Words; VAL because it is scored by name, and the quote is the nearest sentence you have, used at its own scope |
| 3A3 | "Every branch is part of its town. Tell me about a time you weighed a local need against a figure or a rule." | VAL | [grounded] | Selection scaffold: the figure, the local need, the call you made. Expect the panel to link it to the plan to consolidate eight branches into five hubs; do not claim a view on that plan you do not hold. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Neighbours, Not Numbers; the strategy brief makes the hub plan a likely follow-up |
| 3A4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: the moment you found it, the point you could have passed it on, how it closed. Answer slot: your sentence says you handled the branch's log; if you kept a particular complaint open to its end, say what you did and who else was involved; if the log only recorded complaints others closed, say so plainly and tell a different time | Own the Fix; the log is the nearest material and is used at its own scope |

### Case and Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3B1 | "A member's complaint reaches you escalated from a branch supervisor. The member says two different people gave them two different answers. Where do you start?" | CASE | [generic] | This is a stand-in for the 20-minute case, whose content your email does not give, and asks nothing about your past. Clarify first: what the member wants, what each person said, which time limits apply to this complaint type. Objective: the member hears one clear answer, in plain words, from one named owner. Segments: the member, the branch, the contact centre, the cause. Approach: contact the member first, find where the answers diverged, fix the cause, record the case so the monthly figures show it. Metrics: resolution time and whether it recurs. Risks: a second contradicting answer, and a supervisor who feels overruled. Think aloud, challenge one premise (is this one complaint or a pattern), and keep to roughly twenty minutes | F2 and the recruiter's email; CASE because the round names a case; `[generic]` because the actual case is unknown |
| 3B2 | "Eight branches become five hubs over 2027. How should complaints handling change so no town's members feel like numbers?" | CASE | [grounded] | This asks nothing about your past. Clarify what changes for supervisors and for members in a town whose branch moves; objective: every town keeps a person who knows its members; approach: a named owner per complaint and plain-worded replies; metric: resolution time by town. Do not assert how Ashgrove plans the hubs beyond the one fact in the brief | CO and CASE; the hub plan and the value Neighbours, Not Numbers are the strategy's own |
| 3B3 | "The branch supervisor disagrees with your recommendation and says the member is wrong. What do you say?" | CASE | [generic] | This asks nothing about your past. Ask what the supervisor saw before anything else; hold the member's side through two follow-ups; concede specifically what the supervisor is right about; coach, do not override. Never fold on the core just to restore harmony | F6 and the pressure that comes with coaching; CASE because it is a live scenario |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3C1 | "Our supervisors hear most complaints first. Where is the seam between what stays in the branch and what comes to you, and what happens when we disagree?" | JD | [grounded] | This asks nothing about your past. Propose principles, not the seam itself, since you do not know Ashgrove's: the member is never passed around twice, the handover is agreed in advance, and a disagreement is settled with the member's outcome in front. Do not claim to know how it works now | F6 and the Own the Fix value pull in two directions here, so the seam is a likely probe |
| 3C2 | "What would you need from the branches in your first month, and what could you give them?" | JD | [grounded] | This asks nothing about your past. Reciprocity: say what you would ask for, then what you would offer. Offer only what you can stand behind: your own wording of what you would do, not a history | The JD's cross-branch scope; a collegial question that rewards a two-way answer |

### Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| 3R1 | "When a complaint comes to your branch, what do you wish the central side did differently?" | Invites the branch view the panel holds and shows you start from their side |
| 3R2 | "How do you see the hub change affecting how members in each town raise a complaint and get heard?" | Ties to Neighbours, Not Numbers and the strategy brief |
| 3R3 | "Can you give an example of Own the Fix working well in one of your branches?" | A values-round question that tells you how the value is lived and gives you language for it |
| 3R4 | "How do your supervisors tend to feel about escalating a complaint?" | Gives you the starting point for the coaching line |
| 3R5 | "What should a new Lead do in the first month to earn the branches' trust?" | The reciprocity question for a panel you would have to work with |

## Sources

Provided documents: the job description; the four published values, copied from ashgrovecu.org/about/values on 11 November 2026; the recruiter's email on the three rounds; the four facts from the 2026 strategy brief published in July 2026, as you gave them to me (I did not read the brief itself); your background, as you described it in your message. No dossier was present. No search or fetch was sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values you pasted fix the cheat sheet and the VAL questions; nothing a search could return would change either |
| 2. Ashgrove interview process, member services roles | skipped | The recruiter's email names the three rounds, who runs each, their lengths and the values-scoring panel, which fixes the loop and the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief's four facts fix the CO bank and the grounding brief |
| 4. Interviewer name and Ashgrove | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A sentence or two on one real situation for each of Members First, Always, Plain Words, Neighbours, Not Numbers and Own the Fix, outside your first answer → cheat sheet rows and 3A1 to 3A4 become story maps, and 2B1 and 2B2 can be mapped
- What governed the complaints in your branch's formal log, and what your monthly spreadsheet counted and was built in → F4, F5 and F9 move up from low confidence, and 2A3, 2A5 and 1A3 become story maps
- Whether you have worked with a digital or IT team → F8 and 1A4, 2C1 move from a scaffold toward a story map
- Whether you have presented your spreadsheet to your regional manager, and anything above that → 2A2's answer slot is answered
- Whether you ever coached a fellow supervisor or manager through an escalation → F6 and 2A4
- The Head of Member Services' and the two panelists' names → an interviewer read, per-person persona weights, and reverse questions tied to their careers
- The recruiter's answer on what the 20-minute case covers and whether materials come beforehand → 3B1 becomes the real case, not a stand-in
- Your CV text → more quoted sentences than the four from your message, and more rows moving off low confidence
- Hours you have before 20 November → a prep triage section sized to them
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → strategy detail beyond the four facts, interviewer public footprint once names exist, loop reports, recent organisation context
- A tuesday-dossier.md from earlier work on this role → verified evidence, a named objection and prohibited claims, which would sharpen the snapshot and 2A1
