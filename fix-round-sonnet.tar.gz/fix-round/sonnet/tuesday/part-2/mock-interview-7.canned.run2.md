Searches are back, and Saltmarsh's values, loop format, strategy news and Tobias's GDC talk all came up. I'm fetching the values and interviewing pages now so I quote them exactly.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-canned-f7976efe/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since your note doesn't say whether Tobias is the person the role reports to. It has 20 questions, a values cheat sheet, reverse questions for Tobias, and a prohibited-claims list.

- **Loop format:** Saltmarsh's careers page says the hour is a live-incident tabletop on a simulated outage, then a values conversation, with no take-home. About half the pack is tabletop and values prep.
- **Highest-ROI prep:** question C3 is a season-pass question that lands on your "never worked on a game with in-app purchases." Project Larkspur, Saltmarsh's September announcement, moves two titles to a season pass. Rehearse the plain concession and the three follow-ups out loud.
- **Interviewer:** Tobias was previously a QA lead and gave a GDC 2026 talk, "Patch Notes Are a Promise". Your release checklist is the sentence of yours that matches his background, so expect questions on it. I only saw search summaries of the Larkspur post and the talk, so read both in full before Friday.
- **Gaps:** your material doesn't show whether your drops needed work from design, art, engineering and community, whether the title ran as a live service, or whether you owned any post-event review. Those became "answer slots". Either honest answer works, but the words have to be yours.

Say the word and I'll play the Skeptic on C3, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the hiring manager this role would report to, and did your recruiter say anything about what the tabletop covers? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager. Saltmarsh's careers page describes its one 60-minute interview as run by the hiring manager, and your note does not say whether Tobias is that person.
**Round:** Friday, 60 minutes. Per Saltmarsh's published loop: a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values |
| EXP | Whether your background survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its current moves |
| CASE | Structure and reasoning on a live problem from the role |

Wherever you see "answer slot", the pack is telling you what the interviewer is likely to probe, and the answer has to come from you. Either honest branch is a good answer. "That part wasn't mine" or "I never did that" is a strong answer to a probe, delivered plainly.

## Prep triage

| Order | Do | Tied to | Why |
|---|---|---|---|
| 1 | Say the C3 concession and hold aloud, with all three follow-ups, until it is boring | C3 | The most predictable objection to your profile, and the one this pack names as highest-ROI |
| 2 | Run the tabletop structure out loud, timed: first thirty minutes, ship-or-wait, the two-minute player post | A1, A2, E3 | The loop's first half is a tabletop, and the structure is a skill that only transfers when spoken |
| 3 | Settle your answer to each slot you can answer truthfully | F1, F2, F3, F5, F8 | Each one is a probe the JD makes likely |
| 4 | Pick a story or an honest branch for each value | B1, B2, B3, section 10 | The loop's second half is a values conversation |
| 5 | Read the full Project Larkspur announcement and the talk page, then pick your reverse questions | A4, section 11 | This pack saw only a search summary of each |

Everything else is insurance.

## Fit snapshot

Requirements are the JD's own words. Evidence is only your own sentences, from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one main title's weekly content-drop calendar, not a live-events calendar across two titles, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD names two titles, so expect a probe on whether your calendar ever touched a second title or ran alongside other events. If it did, say how and which part was yours; if it was one title and content drops only, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the JD names four teams, so expect a probe on who your drops depended on. If your drops needed work from any of them, say which and what you did, in your own words; if they did not, or it was not you coordinating, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, which is not the same as owning a review or choosing its KPIs, and the words stay there: "Presented the monthly retention numbers to the studio head." Answer slot: if you also wrote or led any review of what a release did, say which and what you recommended; if the numbers were produced or chosen by someone else, or there was no per-release review, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap on the quote, but a line in your message with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you wrote it, and your QA team still uses it. The JD says manage and the quote says wrote, so the words stay at wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | A years requirement, not a gate. Your sentences give the four years and the weekly calendar but do not say whether the title ran as a live service. Answer slot: if it did, say what made it live, in your own words; if it did not, or you are unsure how your studio described it, say so plainly and stay with the four years and the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with the calendar in the quote's own terms: weekly, your main title, two years. Expect a probe because nothing is inspected behind the line |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap on the quote: you presented the numbers, monthly, to the studio head. Expect a probe on how those numbers were counted, since nothing inspected sits behind the line |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist your QA team still uses touches written communication without showing it. Answer slot: if you wrote anything else other people relied on, name it, in your own words; if the checklist is the main example, say so plainly and stay with it |
| F9 | in-app-purchase experience in a monetized title (role-family; the JD does not ask for it) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |
| F10 | leading a team (role-family; the JD asks you to coordinate teams, not lead one) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never led a team." Say it only if asked, then say what the JD does ask of you, at the scope of F2's slot |

## Reading the interviewer

Public professional footprint only.

| Fact | Source | What it means for the hour | Provenance |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games | The talk page for his GDC 2026 talk | He owns the calendar and KPIs you would be producing against, so F1, F3 and F7 are in his own territory | [grounded] |
| Previously a QA lead at a console studio | Same page | Expect close attention to the release checklist. Shared vocabulary: checklist and QA. The pairing is F4's sentence, "Wrote the release checklist our QA team still uses." — your message. Offer it at that scope and let him ask what he wants to know | [grounded] |
| Gave a GDC 2026 talk, "Patch Notes Are a Promise", arguing a live team is judged by how often its patch notes describe what actually shipped | Same page | Announcement honesty is his theme and also a Saltmarsh value. E3 and B2 rehearse it. This pack saw only a short summary of the talk, so read the talk before quoting it back to him | [grounded] |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The tabletop: a simulated outage during a live event, then follow-ups on your calls | Highest. Hiring-manager prior; the published loop names a tabletop; the page does not say how the hour is divided | Clarify, then objective, then who you pull in, then what players are told, then what you record; think aloud; challenge one premise |
| B. Values / Behavioral | The values conversation: stories against Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener | High. The published loop documents a values conversation, so this is guaranteed somewhere in the hour | Choose a story where the hard truth landed, or take the honest branch; "we" for context, "I" for what you did |
| C. Skeptic | Quiet probing of what your background does not show | High. Hiring-manager prior; F2, F9 and F10 are the places it presses | Rehearse the C3 concession until it is boring; build bridges only from what you said; a concrete ramp plan |
| D. Data-Driven Prober | How the retention numbers were counted; what a post-event review reports | Medium. F3 and F7 rest on one sentence; his published theme is announcements matching reality | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| E. Pressure | Time-boxed answers during the tabletop; "why you" in sixty seconds | Medium. Inferred from the simulated-outage format, not stated by Saltmarsh | Pause, restate, hold a position through two follow-ups, concede specifically |
| F. Conversational | Opening biography; "which live game do you admire" | Low to medium. Casual openers are common but the page describes a structured hour | A 90-second arc built from your own sentences; treat casual questions as scored |

No Peer Evaluator bank: the assumed relationship is hiring manager. If Tobias turns out to be a peer, say so and the weights change.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're a few hours into a live event. Players are reporting the reward they were promised isn't arriving, and community channels are filling up. You're the producer on call. Walk me through your first thirty minutes." | CASE | [grounded] | Say the structure aloud. Clarify first: what is broken, for whom, since when, still happening, what players have been told. Objective: stop the harm to players and stop it growing. Who you pull in: engineering for the fix, QA for the check, community for what players are seeing, design and art if content is involved. What players are told and when: only what is known, with a time for the next update, because Saltmarsh's own words are "we announce what is built, not what is hoped." What you record for the post-event review. Challenge one premise, such as whether the event should pause. The question needs no claim about your past, so the guidance makes none | The published loop opens with a tabletop of this shape, so this is the likeliest single question in the hour. CASE because it scores structure; it also touches F2's four teams and F8's writing | 
| A2 | "Engineering has a fix ready for the live event, but QA hasn't finished its pass and the event ends tonight. Do you ship?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Decide and say the condition that would change your mind: what the checklist says about a late fix, what shipping unverified risks, what waiting costs players, who has the call, what players are told either way, what gets recorded. Hold your decision through two follow-ups and concede a specific uncertainty. You may say you wrote the release checklist your QA team still uses, and no more than that. Answer slot: the JD's checklist-with-QA line makes a probe likely on whether a late fix ever put your checklist under pressure. If one did, say what happened and which part was yours; if none did, or it was never tested that way, say so plainly and answer as a decision you would make | F4 is the evidence for the checklist requirement, and his QA background makes this probe likely. CASE because it is a live decision; JD content, since the JD names the checklist |
| A3 | "Both titles have an event planned for the same weekend, and engineering can support only one release that weekend. How do you decide which moves?" | CASE | [generic] | Clarify first: is it really one release, what has been announced to players, what is each event's content readiness and QA capacity. Then state criteria in your own order, such as player impact and what has already been promised, and defend them. Say what you would tell the team whose event moves and what players are told. Hold the principle that when the calendar and the players disagree, the players win, which is Saltmarsh's own wording. The question needs no claim about your past, so the guidance makes none | The JD's two-title calendar is the stress point, and F1 is where your material is thinnest on it. CASE because it is a live scheduling problem |
| A4 | "We've announced Project Larkspur: a season-pass model and one shared events calendar for two of our titles from February. What would you want to know before you planned that calendar?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you have read, and only that: this pack saw a one-line summary of the announcement, so read the full post before Friday. Then ask what you would need: what the pass changes about event cadence, what players were told, which teams the single live-ops group draws from, how success will be measured. Separate what is public from what you do not know. Your side, at the quote's scope: you ran the weekly content-drop calendar for your main title for two years. Answer slot: if your calendar ever had to be coordinated with another title's or another team's, say how and which part was yours; if it was one title's calendar only, say so plainly and stay with it | The announcement is Saltmarsh's most recent public strategy move, which makes it the differentiating CO question. F1 is the evidence the answer rests on, and the question is CO with CASE delivery |
| A5 | "Players who joined during last week's event are coming back less often than players from the event before. Diagnose it." | CASE | [generic] | Clarify first: which retention measure, which cohorts, how large the gap is against ordinary variation, what else changed that week. Segment: new against returning players, platform, entry point. Rank hypotheses: the event itself, a technical issue, a change in who arrived. Say what you would check first and why, what you would report and what you would not claim yet. Name the assumption behind your leading hypothesis that you would defend least. The question needs no claim about your past, so the guidance makes none | F7 is retention evidence from your side, and the JD makes retention a named requirement. CASE because it is a live diagnosis; it also scores the weakest-assumption move |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans: tell me about a time the plan and the players pulled in different directions." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection criteria: a named plan, a specific signal from players, what you changed, who had to agree, and a relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you ran the weekly content-drop calendar for your main title for two years, or how you would handle it | The first of Saltmarsh's three published values, and the loop documents a values conversation. VAL because it scores behavior against a named value; F1 is the nearest evidence |
| B2 | "Ship the Patch Not the Promise: tell me about a time you had to correct something that had been said was coming." | VAL | [grounded] | Selection criteria: something announced, who you told first, what you said plainly, and what changed in how you announced things afterwards. If no such time comes to mind, say so plainly, then say how you would handle it. Do not borrow an incident that was not yours | This value matches the theme of the interviewer's own talk, so a story here is rehearsed twice: once as a value, once as a reverse-question bridge. VAL because it scores honesty about what was announced |
| B3 | "Leave the Build Greener: tell me about a time a release left your process better than it found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the release checklist, and your QA team still uses it. Those are the only beats the sentence carries. Answer slot: the value says each release leaves the checklist better, so expect a probe on what your checklist replaced or changed. If it replaced something or came out of a specific failure, say what and which part was yours; if it was the first checklist, or not prompted by a failure, say so plainly and stay with what you wrote and that your team still uses it | The third published value, and F4 is your strongest-quoted sentence. VAL because it scores a process improvement against the value; EXP in how it will be probed |
| B4 | "Tell me about a time design, art or engineering wanted something different from what you thought should ship." | VAL | [grounded] | Selection criteria: the disagreement stated in one sentence, what each side wanted, what you did, and whether the hard truth landed. If no such time comes to mind, say so plainly, then say how you would handle it. Use "we" for context and "I" only for what you did | The JD names the four teams you would coordinate, so cross-team disagreement is on the scoring sheet. F2 has nothing from your material, so a scaffold is all the pack can give |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick the weakest part from your material and say it plainly; do not bluff the one he owns. If it is monetization, the honest words are "I've never worked on a game with in-app purchases." If it is coordinating four disciplines, take F2's slot. Then give a ramp plan as a plan: name two things you would learn first and who you would ask. Say it as a plan and never as a past | The standard Skeptic stem; F9 and F2 are the places your material is thinnest. JD because it scores honest self-assessment against the listed job |
| C2 | "You'd be coordinating design, art, engineering and community on every update. What have you coordinated across that many disciplines?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: the JD's four teams raise this. If your drops needed work from any of those teams, say which and what you did, in your own words; if the work did not span them, or someone else did the coordinating, say so plainly and stay with the weekly calendar you ran for two years. Do not widen "ran the calendar" into coordinating teams | F2 has no evidence, F10 is the stated absence, and this question sits where they meet. JD because the coordination line is central to the role |
| C3 | "Two of our titles are moving to a season-pass model. What would you need to learn about running events in a game that sells a pass?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Say the limit before it is asked for: "I've never worked on a game with in-app purchases." Then hold what your material carries, at its scope: you ran the weekly content-drop calendar for your main title for two years, wrote the release checklist your QA team still uses, and presented the monthly retention numbers to the studio head. Then the plan: name two things you would learn first, and who you would ask. Follow-up 1: "So you'd learn on our players?" Hold, and say what you would do before the first event ships. Follow-up 2: "Why not hire someone who has done it?" Hold your quotes again; do not claim to be better. Follow-up 3: "What would worry you most?" Concede a specific thing you do not yet know. The question needs no claim beyond what these quotes carry | F9 is your own stated absence, and the Larkspur announcement makes a monetized calendar the center of the role. JD because it tests the role's new shape; Skeptic because it is aimed at exactly where F9 is thin |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented retention numbers monthly. Which measures were in them, and how was each counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: the JD raises retention, so expect this. Say which measures were in the numbers and how each was counted, in your own words. If you do not know how one was counted, say so plainly. If someone else produced the numbers and you presented them, say that, and stay with presenting them to the studio head. Name the assumption you would defend least before he does | F7 rests on one sentence, which is where a Prober goes. EXP because it tests what was actually yours |
| D2 | "If you owned the post-event review for an event, what goes in it and which KPIs would you report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Start at the quote's scope: you presented the monthly retention numbers to the studio head. Then the structure: what was planned against what shipped, what players did, what you would change next time, with the KPIs you would choose and the weakest assumption behind each. Answer slot: the JD's review line raises a probe on whether you have owned a review. If you did, say which and what you recommended; if someone else owned it, or there was no per-release review, say so plainly and stay with presenting the numbers | F3 is the transferability gap on the review requirement. JD because it asks about the job; the structure also scores honesty about what shipped |
| D3 | "Walk me through the release checklist you wrote. How does your QA team use it today?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4, with only the sentence's beats: you wrote it, and your QA team still uses it. Answer slot: if you can say what is on it and how QA uses it at a release, say so in your own words; if you do not know how QA uses it in detail, or it was one of several documents, say so plainly and stay with what you wrote | His public background is QA, which makes this the likeliest EXP probe. F4 is the evidence; EXP because it asks what was actually yours |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has already run live events on a game that sells a season pass?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | Hold, then concede. Open with what your material carries at its own scope: the weekly calendar you ran for two years, the checklist your QA team still uses, the monthly retention numbers you presented. Concede the limit plainly: "I've never worked on a game with in-app purchases." Close with what you would do first. Do not claim to be the better candidate; hold through two follow-ups by returning to the quotes | A time-boxed version of the C3 objection. JD because it scores fit against the role; the register is Pressure |
| E2 | "You ran the weekly calendar for two years. How much of what went into each drop was your call?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: you ran the calendar. Answer slot: the JD's plan-and-run line raises a probe on which decisions were yours. If you set what went into a drop, say which decisions and how you made them; if the contents came to you set by others, or only the schedule was yours, say so plainly and stay with running the calendar. Concede specifically and do not fold on the core sentence | The Pressure stem about attribution, aimed at F1 and F6. EXP because it tests what was actually yours |
| E3 | "Two minutes. The fix isn't ready, engineering wants another hour, and players are asking where their reward is. Write me the player post." | CASE | [grounded] | Say the post aloud: what is known, what is not yet known, what you are doing, and when the next update lands. Promise only what is built, in Saltmarsh's words "we announce what is built, not what is hoped." If pushed to give a fix time, hold the position that you will not promise one you cannot keep, and concede that you do not yet know the cause if that is true. The question needs no claim about your past, so the guidance makes none | The tabletop's written half, and it scores F8 directly. The interviewer's own talk argues patch notes are a promise, which makes this likely. CASE because it is a live task |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through how you got from where you are to this role." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats, each at its sentence's scope: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar you ran for your main title for the last two years; the release checklist your QA team still uses; the monthly retention numbers you presented to the studio head. The move itself, why now and why Saltmarsh, is yours to supply in your own words; nothing in your material says it | The casual opener is still scored, and F5 and F6 are the rows it carries. EXP because it checks the background against what you say |
| F2 | "Which live-service game's events do you think are done well, and why?" | CO | [generic] | Selection criteria: a game you actually play, one specific event, what it asked of players, and why it worked in your view. If no such game comes to mind, say so plainly, then say what you do play and what you notice about how it runs its calendar | A rapport-register question that scores genuine interest in the JD's own subject. CO because it tests how you think about the field; the delivery is conversational |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, A4, E2 |
| "coordinate design, art, engineering and community teams on each update" | A1, B4, C2 |
| "own the post-event review and the KPIs it reports" | D2, A5 |
| "manage the release checklist with QA" | A2, B3, D3 |
| "3+ years producing live-service games or apps" | F1, E1 |
| "experience running a content calendar" | E2, A4 |
| "comfortable with player-retention metrics" | D1, A5, D2 |
| "clear written communication" | E3, A1 |

## Values cheat sheet

Saltmarsh's published values, by name.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players disagree, the players win | Selection scaffold at B1, ending in its honest branch; nearest evidence F1: "I ran the weekly content-drop calendar for our main title for the last two years." — your message |
| Ship the Patch Not the Promise | Announce what has been built, not what is hoped for | Selection scaffold at B2, ending in its honest branch; rehearsed live at E3. No row of your evidence carries a story for it |
| Leave the Build Greener | Each release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." — your message. Beats and answer slot at B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argued a live team is judged by how often its patch notes describe what actually shipped. How does your team measure that today?" | Ties to his own public work and to a Saltmarsh value, and shows you read his material rather than only the company's |
| R2 | "You came to live ops from QA. What did that change about how you run a release checklist?" | Ties to his own path and to the one sentence you can offer, F4, without claiming more than it says |
| R3 | "With Project Larkspur moving to one live-ops group and a shared events calendar, where would this role sit in that group?" | Shows you read the announcement and asks the question that shapes the role |
| R4 | "How do events and the season pass interact when you plan the calendar?" | Turns the C3 limit into curiosity rather than an apology |
| R5 | "What does the post-event review look like at Saltmarsh today, and which KPIs does it report?" | The JD puts the review and its KPIs in the role, so asking shows you are already thinking about owning them |
| R6 | "What separates producers who do well here from those who struggle in the first few months?" | A generic but high-value close; it invites him to say what he actually looks for |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated, F10 | "I've never led a team." No slot |
| Has worked on in-app purchases | Negative you stated, F9 | "I've never worked on a game with in-app purchases." No slot |
| Owned the live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says one main title's content-drop calendar. The slot stays inside that calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The material says presenting the numbers. The slot asks only about what you wrote or recommended around them |
| Managed the release checklist at each release | Inflated form of F4 | F4's quote at its own scope: you wrote it, and your QA team still uses it |
| Produced a live-service game for four years | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer at a puzzle-game studio, and the weekly calendar. The slot asks only whether the title ran as a live service |

## Sources

Provided documents: the job description you pasted, and your background note.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Fetched the official values page. Moved the values cheat sheet and B1 to B3 |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Fetched the careers interviewing page. Moved persona weights, the tabletop questions, and the values-style round, which that page documents |
| 3. `Saltmarsh Games strategy news` | yes | Returned the Project Larkspur announcement as a search summary only; the fetch budget went to targets 1 and 2. Moved A4, C3, R3 and R4 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Returned the talk page for his GDC 2026 talk as a search summary only. Moved the interviewer read, D3, R1 and R2 |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

Queries and results:

- `Saltmarsh Games values` returned https://saltmarshgames.com/values, which was then fetched.
- `Saltmarsh Games interview process live operations producer` returned https://saltmarshgames.com/careers/interviewing, which was then fetched. It also describes the loop as a recruiter call followed by the hiring-manager interview; your note does not mention the recruiter call.
- `Saltmarsh Games strategy news` returned https://saltmarshgames.com/news/project-larkspur, read as a summary only.
- `Tobias Wrenfield Saltmarsh Games` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise, read as a summary only. Treat it as a lead to confirm: read the talk before quoting it to him.

## Upgrade menu

- A line from your recruiter confirming Tobias is the hiring manager, and what the tabletop covers → reweights every bank, and tightens A1 to A3 and E3
- Your answers to the slots, in your own words, for F1, F2, F3, F5 and F8 → those rows move from discovery toward grounded, and the matching banks become story-mapped instead of slotted
- A redacted copy of your release checklist, and a monthly retention deck excerpt → F4, F7 and F3 can move from medium toward high, since a checklist and a retention report are the artifacts a producer keeps
- The full Project Larkspur post and the full talk → A4, C3, R1 and R3 move from summary-level to quoted detail
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes, offered once → a strategy brief for the Larkspur questions and the interviewer's published themes. Say so and I will run it
- Hours available before Friday → the prep triage resized to fit
- A job-underwriter dossier, if you have one → a verified-evidence grading and an objection ranking in place of the ones inferred here
