Running the default research pass on Larkfield Systems: values, interview process, and strategy searches, all in parallel.
Web search was refused, so I'm building the pack from what you've told me and labeling the company-specific parts generic. Writing the pack file now.
Your prep pack for all three rounds is saved as `larkfield-systems_engineering-manager_interview_pack.md` in the working directory. I built it in loop mode: one shared fit snapshot, then a separate bank and set of reverse questions for each round. That gives 11 questions for Tuesday, 11 for the panel and 8 for the VP, with five reverse questions per round.

- **Web search was refused**, so nothing about Larkfield's values, interview process or strategy is researched. Everything company-specific is labeled generic. There is no values cheat sheet for the VP round, and the strategy question for Monday is generic.
- **Weights I assumed:** Tuesday leans Case/Strategist plus Skeptic. The panel leans Peer Evaluator plus Data-Driven Prober, on the guess that the staff engineers are peers or technical specialists. Monday leans Values/Behavioral, from the recruiter's "values and leadership philosophy" description.
- **Highest-ROI prep is T-B2, the hardware side of the role.** It's the gap you named yourself, and it comes back in every round in some form. The guidance for it holds only what you said, "I've never owned a hardware-adjacent roadmap", and then moves to a plan.
- **Your two figures** (the 60% on-call drop and the ~40 interviews) each get a "how was that counted" question in the panel bank. Your message doesn't say whether the 40 were interviews you conducted or the loop's total, so check that before Thursday.
- **Claims I won't coach:** managing managers, owning a hardware roadmap, leading two squads, owning delivery, claiming the quarter caused the whole 60% drop, and personally conducting the 40 interviews. The pack lists each with the honest form to use instead.

I can play the Skeptic on T-B2 as a live drill if you want to rehearse it. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

1. Can you paste the full job description, and your CV if you want your own sentences quoted instead of paraphrased? If not, I'll stay with what you've told me.
2. Did the recruiter say anything about the panel, such as a case, a presentation or a take-home, or who sits on it?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Larkfield Systems — Engineering Manager: three-round interview pack (loop mode)

Candidate: Yusuf. Rounds: Tuesday, hiring manager (Director of Engineering, 45 min); the Thursday after, panel (two staff engineers and a product manager, 60 min); the following Monday, VP Engineering (30 min, "values and leadership philosophy" per the recruiter). No interviewer names were given, so there is no interviewer read. Web research was refused in this session, so every company-specific claim here comes from your message; company-level material is labeled generic.

## How to use this pack

Personas describe how a question is asked. Types describe what is scored. Guidance is scaffolding, not a script: say it in your own words, and stop where your own sentences stop.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values and leadership philosophy asked about |
| EXP | Whether claims about your experience survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

IDs: T for Tuesday, P for the panel, V for the VP. The answer slots in the guidance are instructions for the interview, not questions for you now.

## Highest-ROI prep

T-B2, the hardware side of the role. It is the one objection your own material names, it is aimed at a line the role states outright, and it will come back in every round in some packaging (P-B3, P-B4, V-B2). Rehearse it until it is boring.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | Your material says a team lead of six at a payments company, not two squads and not device management; the words stay there: "For three years I was a team lead of six." The material does not say whether the two squads have their own leads, which decides whether "I've never managed managers" is live. That is a reverse question (T reverse 2). Answer slot: the two-squads line makes a probe on how you would split your attention likely; answer it as a plan, never as a past |
| F2 | "own delivery" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence is about a reliability quarter and an on-call figure, not about owning delivery, and the words stay at its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the own-delivery line makes a probe on how delivery was tracked likely; if you ran delivery for your team's roadmap, say how, in your own words; if delivery was owned elsewhere or there was no such process, say so plainly and stay with the reliability quarter |
| F3 | "hiring" — role description | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you run the loop for backend roles. The material does not say whether the 40 are interviews you conducted or the loop's total, or how many hires followed, and the words do not decide it for you |
| F4 | "growth for 11 engineers" — role description | none given | none | [grounded] | discovery | Nothing in the material speaks to growing engineers. Answer slot: the growth line makes a probe on your own experience likely; if you shaped anyone's growth, say what you did, in your own words; if that was not yours or has not happened, say so plainly and answer as a plan |
| F5 | "partner with hardware and product on roadmap" — role description (the hardware half) | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | Your material says you have never owned a hardware-adjacent roadmap; the role's line is partnering, which that sentence does not speak to. Words: "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked alongside hardware or firmware people, say where and what part was yours, in your own words; if you have not, say so plainly, then give the plan: who you would sit with first and what you would ask |
| F6 | "partner with hardware and product on roadmap" — role description (the product half) | "pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence names roadmap pressure and not who applied it, so the words stay at "I pushed a reliability quarter through against roadmap pressure." Answer slot: if the pressure came from a product counterpart and you worked it through with them, say how, in your own words; if it came from elsewhere or was settled above you, say so plainly and stay with the quote |

## Prohibited claims (shared)

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative the candidate stated, F1 | The plain acknowledgment: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative the candidate stated, F5 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot |
| Led two squads or a team of eleven | Inflated form of F1 | F1's quote at its own scope: a team lead of six. The limit is the pack's observation: the material says six, not two squads |
| Owned delivery for the engineering org | Inflated form of F2 | F2's quote at its own scope: you pushed a reliability quarter through. The limit is the pack's observation: the sentence is not about owning delivery |
| Cut on-call burden by 60% through the reliability quarter | Inflated form of F2 | The quote at its own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The limit is the pack's observation: the sentence says after, and does not say the quarter caused the whole drop |
| Personally conducted about 40 interviews, or made N hires | Inflated form of F3 | F3's quote at its own scope: you run the loop. The limit is the pack's observation: the material does not say whose interviews the 40 were, or any hire count |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "Lead two squads building device-management services" | T-A1, T-A2, T-A3, T-B3, P-A3, V-A1, V-B2, V-C1 |
| "own delivery" | T-A1, T-C2, P-B4 |
| "hiring" | T-A4, P-C2 |
| "growth for 11 engineers" | T-A5, V-A3 |
| "partner with hardware and product on roadmap" | T-A1, T-B1, T-B2, P-B3, P-B4 |
| Headline figures: 60% on-call drop, about 40 interviews | P-A1, P-A2 |

---

# Round 1 — Tuesday: hiring manager (Director of Engineering, 45 min)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on the squads' actual roadmap: what ships first, how you would respond to a fleet problem | High. The prior for a hiring manager is Case/Strategist plus Skeptic; this is also your would-be boss, so they are pricing how you would run the squads | Clarify, then objective, then options, then metrics, then risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the hardware side, the step from six to two squads, and why leave payments | High. Same prior; your own message names two gaps a skeptic would find | Rehearse the most predictable objection until it is boring; bridge only from what you have said; concede specifically |
| Conversational | The opening biography question, the reliability-quarter story told casually | Medium-low. Hiring managers often open warm, and casual questions are still scored | A 90-second arc built from your own sentences; treat casual questions as scored |
| Pressure | Interruptions, time-boxing | Low as a style, but the follow-ups inside T-B2 are pressure-shaped | Pause, restate, hold through two follow-ups |

## Question bank

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-A1 | "Hardware wants a change to land this quarter, product wants a customer-facing feature, and both need the same squad. How do you decide what ships, and what do you want to know first?" | CASE | [generic] | Clarify first: what each ask is worth, what slips if it waits, who can say no. Then objective, options, one metric you would watch, one risk named aloud. Challenge one premise respectfully. A live problem, so the guidance makes no claim about your past | The role's partner-with-hardware-and-product line (F5, F6) is where a live problem would be set; CASE because it scores structure over the answer |
| T-A2 | "Check-in failures across a customer's device fleet jump 20% after a release. What do you do in the first hour, and who do you pull in?" | CASE | [generic] | Confirm the signal, scope who is affected, separate stopping the damage from diagnosing it, decide who talks to the customer and to hardware and product, and say how you would run the response without taking the debugging from your engineers. Name the metric you would watch and the risk of acting too fast. No claim about your past | Tests running a device-management service as its manager (F1); CASE, since it asks for reasoning on a problem from the role |
| T-A3 | "You have thirty days with these two squads. What do you want to learn, and from whom?" | CASE | [generic] | A listening plan: engineers, staff engineers, product, hardware, in an order you can defend. Say what you would ask each, and what you would hold off changing. Include the hardware side early, as a plan | A first-month question is a standard hiring-manager test of judgment; it presses on F1 and F5 without presupposing anything about your past |
| T-A4 | "One of your squads needs to hire. How do you decide what the next hire is for?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Structure it: the squad's constraint, the profile that closes it, what the loop would test. If you bring in your own loop, use only the quote's words: "I run our hiring loop for backend roles." Answer slot: the hiring line makes a probe on how role profiles get decided likely; if you set or shaped them in your own loop, say how, in your own words; if that was set elsewhere or there was no such step, say so plainly and stay with running the loop | F3 is your strongest quoted evidence for a stated responsibility; CASE delivery on a JD topic |
| T-A5 | "One engineer wants to move toward staff-level work and another is struggling. You have time for one conversation this week. How do you choose, and what do you say?" | CASE | [generic] | Clarify the stakes and timelines first, then say how you would choose, what each conversation is for, and what you would follow up on. Answer slot: the growth line makes a probe on your own experience likely; if you shaped anyone's growth, say what you did, in your own words; if that was not yours or has not happened, say so plainly and answer as a plan | F4 has no evidence in your material, so this is where the growth requirement gets its rehearsal; CASE on a JD topic |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Pick the weakness that is true. Your material names one: say it in a sentence, "I've never owned a hardware-adjacent roadmap," and move straight to the plan, who you would sit with first and what you would ask them. Do not substitute a strength dressed as a weakness | A standard opener from this persona; F5 is the gap your material names |
| T-B2 | "I don't see a hardware-adjacent roadmap in your background. How would you handle the hardware side of this role?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I've never owned a hardware-adjacent roadmap." Say the limit plainly, once, without apology, then give the plan as a plan: who you would sit with in the first weeks and what you would ask. Answer slot: the hardware line makes a probe on any working contact with hardware people likely; if you have worked alongside them, say where and what part was yours, in your own words; if you have not, say so plainly and go to the plan. Rehearse three follow-ups: "So what would you do first?"; "What if hardware's ask and product's ask cannot both fit?"; "What would make you call this a mistake at six months?" Hold through the first two by returning to the plan, concede specifically on the third by naming what you do not yet know. Never bluff a competency the interviewer may own; the second branch is a limit, not a confession | F5 is the objection most likely to be asked, in some form, in this round and the next two; JD because it scores a stated requirement, delivered by the Skeptic |
| T-B3 | "You've led a team of six. This role is two squads and eleven engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers" | Open with the quote at its scope: "For three years I was a team lead of six." Answer as a plan for what you would do differently. If the squads have leads of their own, the plain acknowledgment is "I've never managed managers," and the plan says what you would learn first. Answer slot: the two-squads line makes a probe on whether you would manage leads or engineers directly likely; if you have a view on structure, give it as a plan and ask the interviewer which it is | F1 is the step-up the role is built around; JD because it scores a stated responsibility |
| T-B4 | "Why industrial IoT, and why leave a payments company now?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Selection scaffold: your material gives no reason, so the pack supplies none. Pick a reason that is true and specific, with a named pull toward this role rather than a push from your current job, and no disparagement. If no clear reason comes to mind, say so plainly, then say what you know so far and what you want to learn | The persona's standard motivation probe (why leave, why here, why now); VAL because it scores consistency of motive |

### C. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-C1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc whose beats are the quote's: nine years in engineering, three as a team lead of six, currently at a payments company. The turn toward this role is selection scaffold: pick the one reason you moved toward leading, in your own words; if none comes to mind, say so plainly and give the nearest thing you can stand behind | A friendly opener that is still scored; F1 supplies the beats |
| T-C2 | "I'd love to hear about the reliability quarter you pushed through." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F2 and F6: the beats are the quote's, a reliability quarter, roadmap pressure, pushed through, and an on-call burden that dropped 60% after. Tell them in your own words. Answer slot: the own-delivery line makes a probe on who applied the pressure and how it was settled likely; if you can say, say it in your own words; if the detail was not yours or there was no such moment, say so plainly and stay with the quote. How the 60% was counted is rehearsed in P-A1 | Your strongest quoted story and the likeliest casual probe; EXP because it tests what was yours |

## Reverse questions — Tuesday

| # | Question | Why it lands |
|---|---|---|
| T-R1 | "What would a successful first six months look like for the two squads, and what would make you say this hire was the right call?" | Puts the success criteria in the open and shows you think in outcomes |
| T-R2 | "Do the two squads have their own leads today, or would the eleven engineers report to me directly?" | Settles whether the manager-of-managers gap is live, before anyone raises it |
| T-R3 | "How do the hardware and product roadmaps meet today, and where does it strain?" | Treats the hardware gap as something you are mapping, and gets a real answer to plan against |
| T-R4 | "What is the biggest thing you would like to be different about these squads a year from now?" | Surfaces what the role is really for in the hiring manager's own words |
| T-R5 | "How do you want me to bring you problems, and how early?" | Signals how you would work with your boss, and gets the escalation norm |

---

# Round 2 — Thursday: panel (two staff engineers and a product manager, 60 min)

## Persona weights

Assumption: the panel members' relationships are not stated. I weighted the staff engineers as peer or technical-specialist and the product manager as cross-functional; if you know their names or reporting lines, the weights move.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | The seam between EM and staff engineers, how disagreements and credit are handled, what the product manager needs from you | High. The peer prior for both staff engineers and the product manager, and objections from Round 1 return in collegial packaging | Reciprocity framing; propose seam principles rather than pretending to know the seam; disagreement stories that show spine and tact |
| Data-Driven Prober | Your two figures, probed to their assumptions; technical depth on device-management services | High. The technical-specialist prior; both figures in your material are probe targets | Know how each figure was counted and say plainly when you do not; name the assumption you would defend least before they do |
| Values/Behavioral | Scored behavioral questions from the product manager | Medium. The cross-functional prior | A story where one of your sentences carries one; a scaffold ending in its honest branch where none does |
| Conversational | Friendly questions about how you like to work with product | Low-medium. The cross-functional prior's second persona | Treat casual questions as scored |

## Question bank

### A. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-A1 | "Your on-call burden dropped 60%. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number, four slots in your own words. How it was counted: say what you know, and if you do not know, say so plainly. What it is sensitive to. The assumption behind it you would defend least, named before they do. Which part was yours. The words that hold are the quote's: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Do not state a method or baseline you cannot repeat under a second question | F2 carries the figure; EXP because probers attack headline numbers first |
| P-A2 | "About forty interviews last year. How was that counted, and how many were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Defend-the-number again: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. The sentence says you run the loop and that there were about 40 interviews, and does not say whose; answer it in your own words. If the 40 are the loop's total and not yours, say so plainly | F3 holds the second figure; ambiguity in it resolves downward |
| P-A3 | "How do you stay technical enough to challenge an architecture proposal from your squad without becoming the bottleneck?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer as an approach: what you would ask, what you would leave to the proposer, when you would pull a staff engineer in. If you draw on your background, the words are the quote's: nine years in engineering. Answer slot: the device-management line makes a probe on systems that talk to fleets of devices likely; if you have worked on any, say where and what part was yours, in your own words; if not, say so plainly and say what you would read first | Staff engineers will test whether a manager can hold a technical conversation (F1); JD because it scores the role's technical surface |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-B1 | "Our teams sit side by side. Where is the seam between a staff engineer and the EM, and what happens when we disagree about a technical direction?" | JD | [generic] | Propose seam principles, who decides what and how it gets escalated, rather than pretending to know the seam here. For the disagreement, selection scaffold: pick a time you disagreed with a senior technical person, with a named stake and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The peer persona's native question; no claim about your past is made |
| P-B2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Scaffold: pick a case where credit was shared across teams and you handled it visibly; say "we" for context and "I" for what you did. If none comes to mind, say so plainly, then describe how you would handle it | A standard peer probe on credit-sharing; the pack makes no claim about your history here |
| P-B3 | "Where would product's and hardware's priorities collide for your squads, and how would you want us to bring that to you?" | JD | [generic] | Reciprocity: say what you would do on your side, a forum, an early flag, a rule for who decides, and what you need from the staff engineers and the product manager. Name the hardware side as the part you would learn fastest from them, as a plan | F5 and F6 again, in collegial packaging; no claim about your past |
| P-B4 | "Walk me through how you handled the roadmap pressure around that reliability quarter." | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" | Story-mapped on F6: the beats are the quote's, a reliability quarter, roadmap pressure, pushed through. Answer slot: the product line makes a probe on who applied the pressure and how it was resolved likely; if you negotiated it with a product counterpart, say how, in your own words; if the decision was made elsewhere or there was no such negotiation, say so plainly and stay with the quote. This is the room where the product manager is listening for how you treat partners | F6 is the evidence for partnering with product; EXP because it tests what was yours |

### C. Values/Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-C1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named stake, a customer-visible consequence, and a moment you held. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A cross-functional interviewer's standard values probe; no company values were in hand, so the theme comes from the persona stem |
| P-C2 | "Tell me about a hiring decision that was hard." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Selection scaffold: a decision with a named stake, where your judgment was tested and the reasoning is yours to state. If none comes to mind, say so plainly, then stay with what the quote carries: you run the loop. Do not add a split panel, a dissenter or an outcome the quote does not hold | The JD's hiring line raises it (F3); VAL because it scores how you decide |

### D. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-D1 | "What are you actually playing with in IoT or device fleets these days?" | JD | [generic] | Selection scaffold: if there is something you have actually explored, name it and what you learned; if there is not, say so plainly and say what you would read first | A casual question about the role's domain, still scored; no company facts assumed |
| P-D2 | "What makes a good working relationship between an EM and a product manager?" | VAL | [generic] | Say what you would want from the product manager and what you would offer them, as principles. No claim about your past is made | The product manager's likeliest friendly question, and a chance to show reciprocity |

## Reverse questions — Thursday

| # | Question | Why it lands |
|---|---|---|
| P-R1 | "What could a new EM do in their first month that would genuinely help the staff engineers?" | The reciprocity question: it asks what you can give, not only what you need |
| P-R2 | "Where do hardware constraints most often reshape what the squads can ship?" | Shows you are mapping the hardware side, and tells you where the real seams are |
| P-R3 | "When product and engineering disagree on a roadmap item, how does it get settled today, and what would you change?" | Draws out the real decision process for the product manager to describe |
| P-R4 | "What would you want an EM here to protect for the squads?" | Invites the staff engineers to say what they value, which is material for your first month |
| P-R5 | "What does the product manager need from engineering leadership that is hardest to get?" | Puts the product manager's needs first and gives you a concrete thing to ask about later |

---

# Round 3 — Monday: VP Engineering (30 min, "values and leadership philosophy")

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario and philosophy questions about how you lead | High. The recruiter described the round as "values and leadership philosophy", which is the one fact about this round | Where one of your sentences carries a story, map it; otherwise a scaffold ending in its honest branch; "we" for context, "I" for contribution |
| Pressure | Time-boxed answers, a challenge on the step up | Medium. The skip-level prior pairs Case/Strategist with Pressure, and thirty minutes forces time-boxing | Pause, restate, hold through two follow-ups, concede specifically |
| Case/Strategist | A short strategy or first-month question at the VP's altitude | Medium-low. Same prior; the round's stated focus is values, so this gets the fewest questions | Clarify, structure, answer; do not recite a shared source |

No Larkfield values page was in hand (search refused), so there is no values cheat sheet; the VAL questions use open prompts and scaffolds.

## Question bank

### A. Values/Behavioral (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-A1 | "What is your philosophy of leading engineers, and where has it shown up in how you run things?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "pushed a reliability quarter through against roadmap pressure" | State the philosophy in your own words first, then pick one of the two quoted sentences as the example and tell it at its scope: you run the hiring loop for backend roles, or you pushed a reliability quarter through against roadmap pressure. Describe what you did and let the VP draw the inference; do not say what it proves about you | The recruiter's "leadership philosophy" raises it; VAL because it scores whether practice matches stated belief |
| V-A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [inferred] "pushed a reliability quarter through against roadmap pressure" | Selection scaffold: it needs a named stake, a truth that actually landed, and an intact relationship. Your material does not say whether the reliability quarter involved telling leadership anything, so use it only if it did, at its own scope. If no such time comes to mind, say so plainly, then give the nearest thing you can stand behind or how you would handle it | The persona's own stem, and the likeliest values probe for this persona; F6 is the nearest quoted material and it is not a match by itself |
| V-A3 | "What does growing someone mean to you, and when have you done it well?" | VAL | [generic] | Say what growing someone means to you in a sentence or two. For "when have you", selection scaffold: pick a person and a specific change you contributed to; if none comes to mind, say so plainly, then answer as a plan. Do not claim a promotion or an outcome that you have not stated | The growth line raises it (F4); no evidence in your material, so a scaffold and an honest branch |
| V-A4 | "What do you want your engineers to say about working for you a year from now?" | VAL | [generic] | Answer in two or three specific behaviors you would want to be known for, not adjectives. No claim about your past is made | A leadership-philosophy question that needs no history, and a natural place for specifics |

### B. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-B1 | "Sixty seconds: why you for this role?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Pause, restate the question, then beats from the quote: nine years in engineering, three as a team lead of six. Add the reliability quarter only at its scope. If pressed on the gap, concede in a sentence and go to the plan | The persona's own stem; time-boxing is the test |
| V-B2 | "You haven't managed managers. Why should I trust you with two squads and eleven engineers?" | JD | [grounded] "I've never managed managers"; "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Hold-then-concede. The plain acknowledgment is "I've never managed managers." Then what the material carries: "For three years I was a team lead of six." Then a plan: what you would learn first and who you would ask. Hold through two follow-ups by returning to those words, and concede specifically what you have not done. Do not add a leadership scope your sentences do not state | F1 stated the gap; whether it is live depends on the squads' structure (T-R2) |

### C. Case/Strategist (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-C1 | "You join and find the two squads disagree about where the next two quarters should go. What do you do in your first month?" | CASE | [generic] | Clarify what the disagreement is actually about, hear each squad separately, find the shared constraint, decide who decides, and say what you would not change yet. No claim about your past | A short first-month case at the VP's altitude (F1) |
| V-C2 | "Where do you think industrial IoT device management is heading, and what should an engineering org like ours be betting on?" | CO | [generic] | No company research was available, so this stays generic: give a view you can defend and mark where you would want to learn more; do not state facts about Larkfield. If you have read anything about the field, name it and say what you took from it | The one strategy-altitude question, left generic because the research was refused |

## Reverse questions — Monday

| # | Question | Why it lands |
|---|---|---|
| V-R1 | "What does good leadership look like here when it is working, and what would you point to?" | Asks for concrete examples of the values the round is about |
| V-R2 | "What is a recent engineering decision you would want a new manager to understand the reasoning behind?" | Shows you want the why behind decisions, not only the outcome |
| V-R3 | "How do you see the EM and Director roles evolving as the organization grows?" | Gives the VP room to talk about the future of the role you are interviewing for |
| V-R4 | "What does a manager who is struggling in the first year look like here, and how early do you want to know?" | Shows you want early signal and are not defensive about being new to part of the job |
| V-R5 | "What support exists for managers stepping into a larger scope?" | A direct and honest question that fits your stated step-up |

---

## Sources

Provided documents: your message (the role description, the three rounds, and your background).

Searches sent, none returned anything:

- `Larkfield Systems industrial IoT company values` — refused
- `Larkfield Systems interview process engineering manager` — refused
- `Larkfield Systems industrial IoT device management strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have fed a values cheat sheet for Monday; none is built, and the VAL questions use scaffolds |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have named the loop's rounds; the loop here rests on your own words and the recruiter's, and the personas rest on relationship priors |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have grounded V-C2 and a Monday CO question; both stay generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form; there is no interviewer read |
| 5. representative Engineering Manager JD | skipped | The role description you gave fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full job description text → the six rows quoting a one-sentence role description become rows against the real requirements, and any mid-list requirement gets its own question
- Your CV → the evidence column gains your own sentences beyond the ones in your message, and more stories can be mapped instead of scaffolded
- Interviewer names, especially the three panel members and the Director → an interviewer read, persona weights adjusted from public footprint, and a reverse question tied to each person's path
- Anything the recruiter said about the panel, such as a case, a presentation or a take-home → a build section for each announced deliverable
- Larkfield's published values page, pasted → a values cheat sheet for Monday, mapping each value to a story where one of your sentences carries it
- Larkfield's own description of its interview process, pasted → a documented loop in place of relationship priors
- Search access → the research pass I could not run; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once search is allowed, and would ground the strategy questions
- Whether the two squads have their own leads → settles whether F1's manager-of-managers gap is live and sharpens T-B3 and V-B2
- Your answers to the answer slots, once you have worked them out aloud → the rows they touch (F1, F2, F4, F5, F6) are regenerated from your own words
- A `tuesday-dossier.md` from an earlier fit decision on this role → verified evidence and any prohibited claims it records would sharpen the guidance cells
