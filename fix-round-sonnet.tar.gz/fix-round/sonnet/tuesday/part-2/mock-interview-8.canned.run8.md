The pack is written and saved. I'll summarise it below.

Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-canned-c295e7d3/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it in loop mode around your three rounds on 20 November, with 29 questions in total: 8 for the recruiter, 11 for the Head of Member Services and 10 for the panel. It also has a fit snapshot, a values cheat sheet, and reverse questions for each round.

- **Sources:** I ran no searches. Your pasted JD, values, recruiter email and brief summary covered every research target. I worked from your four-point summary of the strategy brief, not its full text. Your background came from your message, since no CV was supplied.
- **Interviewers:** there is no interviewer read, because no names are assigned yet.
- **Highest-ROI prep:** the contact-centre objection, question D1. It comes up in some form in every round, so rehearse it until it is boring. Your other stated limit, presenting above regional level, is covered in B3 and D3.
- **Answer slots:** where your material is silent, such as what the spreadsheet counted, whether it was Excel, and what governed the complaints log, the guidance gives you an answer slot instead of an invented story. Your answers to those would upgrade the pack.

Say the word and I'll play the Skeptic on D1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Prepared for Dara on 11 November 2026, for three rounds on 20 November 2026. Loop mode: one shared fit snapshot, then a mini-pack per round. Interviewer names are not assigned yet, so there is no interviewer read; the upgrade menu says what names would add.

| Round | Who, as given | Length | What it holds | Provenance |
|---|---|---|---|---|
| 1 | The recruiter | 30 minutes | Not described beyond the slot | [grounded] "Three rounds on 20 November: 30 minutes with me" — recruiter's email |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" | [grounded] "45 minutes with the Head of Member Services, who would be your manager, mostly behavioural" — recruiter's email |
| 3 | A panel of two branch managers | 60 minutes | A 20-minute case on a complaint escalation; the panel also scores against the four values | [grounded] "60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation. The panel is also the values round — they score against the four values." — recruiter's email |

## How to use this pack

Personas describe how a question is asked; types describe what it is scored on. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral and values | Whether your past behaviour shows Ashgrove's published values |
| EXP | Work-experience deep-dive | Whether your CV claims survive scrutiny; what was actually you |
| JD | Role and JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Whether you can think at the credit union's altitude |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Where guidance says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours or did not exist. It is not a question for you now.

## Prep triage

Nine days to the interviews; hours per day were not stated, so this is ordered by priority, not scheduled.

1. D1, B1 and B3: say the two plain acknowledgments aloud until they are boring. D1 is the highest-ROI prep in the pack.
2. J1 to J3: run the 20-minute case once aloud against a timer, using the structure in J1.
3. H1 to H4 and the values cheat sheet: for each value, choose a real story or note honestly that none comes to mind.
4. The answer slots on F1, F3, F7 and F8: write down, for yourself, what the spreadsheet counted, what tool it was in, and what governed the complaints log. Sending those to me upgrades the pack.
5. Reverse questions: pick two per round.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's complaints log, not the process end to end, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages of handling a complaint likely. If any stage beyond the log was yours, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller. The pack's own observation: your quotes carry one branch's log, not several branches |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote carries a monthly complaints spreadsheet that your regional manager uses; it does not show what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's reporting line makes a probe on what the spreadsheet counted likely. If it counted any measure, say what and how, in your own words; if it counted something else, or no such measure, say so plainly and describe what it did show |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Adjacent work: training tellers on an escalation script. The words stay at "I trained new tellers on our escalation script." Answer slot: the JD's supervisor line makes a probe on whom you have trained likely. Say who was in those sessions and what the script covered, in your own words; if you did no coaching beyond those sessions, say so plainly and stay with the tellers you trained |
| F5 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated limit. Words: "I haven't presented above regional level." Then how you would prepare, said as a plan and never as a past. The pack's own observation: the quote is a ceiling, not a record of presenting at regional level, so no claim to regional presentations is made either |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length, but a one-line quote with nothing inspected behind it, so expect a probe. Lead with it in its own terms: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The quote says formal complaints; it does not show what, if anything, governed them. Words: "I handled the branch's formal complaints log." Answer slot: the JD's word regulated makes a probe on what governed the log you kept likely. If you know, say it in your own words; if the log was an internal record, or you do not know what governed it, say so plainly and stay with the log you handled |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet, not Excel. Answer slot: the JD names Excel, so expect a probe on the tool the spreadsheet was built in. If it was Excel, say what you built, in your own words; if it was another tool, say so plainly and describe the spreadsheet |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you have worked with a digital team or on a self-service journey, say what it was and what you did; if not, say so plainly, and say what you would want to learn first about where members' complaints begin |

## Grounding brief

What the pack can say about Ashgrove, from the documents you supplied. The brief reached me as your four-point summary, not the full text.

| Item | What it says | Provenance |
|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] "2026 strategy brief Ashgrove published in July 2026" — your message |
| Branch network | "consolidate eight branches into five hubs over 2027" | [grounded] "2026 strategy brief Ashgrove published in July 2026" — your message |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] "2026 strategy brief Ashgrove published in July 2026" — your message |
| Competitive pressure | "the main competitive pressure is app-only banks" | [grounded] "2026 strategy brief Ashgrove published in July 2026" — your message |
| Size and ownership | "member-owned, about 900 staff" | [grounded] the JD's first line — your message |
| Freshness | The brief is from July 2026, about four months before today, inside the six months the research rules allow for strategy | [grounded] dates in your message |

| Reading for this loop | Derived from | Provenance |
|---|---|---|
| The hub consolidation changes which branches and supervisors the role works with, so branch managers on the panel may ask about it | The eight-to-five line and the panel's makeup | [inferred] |
| As more service moves to digital channels, the complaints that reach a person may change in kind, which is why the JD pairs this role with digital teams | The 40% line and the JD's self-service line | [inferred] |
| The small-business lending launch is the least tied to complaints of the four items; no question here rests on it | The brief's four items against the JD | [inferred] |

## Round 1: the recruiter (30 minutes)

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured: the journey, why this job, a casual view on digital | High: the relationship prior for a recruiter screen, and the slot is short | A 90-second arc built only from the quote in A1; treat casual questions as scored; have a reverse question ready |
| Skeptic (light) | Quiet knockout checks on the gaps | Medium: the prior pairs a light Skeptic with recruiter screens, and the JD's contact-centre and senior-leader lines are the obvious targets | Name the stated limits plainly and early (B1, B3) |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | A 90-second arc with only the beats the quote states: six years in retail banking, the last three as a branch supervisor, in that order. Then your reason for wanting this role at Ashgrove. Answer slot: the reason is yours; say it in your own words, and name a published value only if it is true for you | F6 is the evidence the opening rests on; EXP because it tests how you tell your own history |
| A2 | "Ashgrove wants 40% of member service on digital channels by 2028. What do you make of that for complaints?" | CO | [grounded] | Clarify first: which services the 40% counts, and what a member does when self-service does not solve their problem. Then structure: the member's side of the counter, where a person must stay in the loop, what you would want to measure. Make no claim about your own digital work; F9 holds no quote, so say what you would want to learn | The strategy brief's digital line meets the JD's self-service line; CO because it tests thinking at the credit union's altitude |
| A3 | "Tell me about the formal complaints log you handled." | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: the log, handled by you, at the branch; tell it in your own words. Answer slot: the JD says regulated complaints, so expect a probe on what governed the log. If you know, say it; if the log was an internal record, or you do not know what governed it, say so plainly and stay with the log you handled | F1 and F7 are the evidence for the headline requirement and the regulated-complaints line; JD because it scores the stated requirement |
| A4 | "What did the monthly complaints spreadsheet show, and who used it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say it in the quote's words: you built it, monthly, for complaints, and your regional manager uses it. Answer slot: the JD names volumes, resolution times and Excel, so expect a probe on what it counted and the tool. If you know how a figure on it was counted, and the assumption you would defend least, say so; if you do not know, say that plainly; if it was not in Excel, or counted something else, say so and describe what it did | F3 and F8 are the reporting evidence; JD because reporting is a stated requirement, with the weakest-assumption move held in reserve for a counted figure |
| A5 | "You trained new tellers on your escalation script. How did you go about that?" | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: new tellers, the escalation script, the training; the beats the quote states. Answer slot: the JD's coaching line makes a probe on how you coached likely. If any of it went beyond the script itself, say what, in your own words; if it stayed with the script, say so plainly and stay with the tellers you trained | F4 is the only coaching evidence and sits one level below the JD's supervisors; JD because coaching on escalations is a stated duty |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick the one you would name first and say it in your stated words: "I haven't worked in a contact centre" or "I haven't presented above regional level". Then a plan, said as a plan in your own words: what you would do in your first weeks. The pack names no plan for you. Do not pile both on unless asked | F2 and F5 are your two stated absences; JD because it scores the listed duties, with Skeptic delivery |
| B2 | "Why leave a branch supervisor role for this one, and why now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say the one reason that is true for you, in your own words, and what you would gain, not what you are leaving. Tie it to a published value only if it is true. Do not argue that the move is a promotion unless you were told so | F6 is the history the motive question rests on; EXP because it tests motivation consistency |
| B3 | "This role presents to senior leaders. Where are you with that?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented above regional level." Then how you would prepare, as a plan in your own words. Claim nothing about presenting at regional level; the quote does not say you did. Hold the plain version through a follow-up rather than adding to it | F5 is a stated absence on an explicit requirement; JD because the line is stated |

### Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "How would the Head of Member Services describe a good first year in this seat, as far as you know?" | Gets the success definition before the manager round, and a recruiter can often answer it |
| 2 | "Can you tell me anything about the 20-minute case: whether it is given in advance or live, and whether I should bring anything?" | A recruiter holds process detail; the answer sharpens J1 to J3 |
| 3 | "Who are the two branch managers, and do you know which branches they run?" | Unlocks the interviewer read and a tailored reverse question for round 3 |
| 4 | "How are the three rounds weighed together, and who decides after the panel?" | Shows you are thinking about the whole loop and tells you where the panel's score lands |
| 5 | "How is the move from eight branches to five hubs affecting this role: is it a new seat or an existing one?" | Shows you read the brief, and the answer shapes how you talk about branches |

## Round 2: the Head of Member Services (45 minutes)

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" scenarios drawn from the JD's duties | Highest: the recruiter called the round "mostly behavioural" | Pick real stories from your own material; "we" for context, "I" for contribution; where none comes to mind, say so and give the nearest thing you did (C1 to C4) |
| Skeptic | Quiet, persistent probing of the gaps | High: the hiring-manager prior is to derisk gaps, and a manager owns the contact-centre and presenting questions most directly | Rehearse D1 until it is boring; the limit comes before the question (D1 to D3) |
| Data-Driven Prober | Line-by-line questions on the reporting claim | Medium: your quotes include a monthly spreadsheet, and the JD names reporting | Know what you can and cannot say about what it counted; say plainly when you do not know (E1, E2) |
| Case / Strategist | A live problem on the manager's own plan | Lower: the hiring-manager prior includes it, but the recruiter said mostly behavioural | Clarify, objective, segments, approach, measures, risks; think aloud (G1, G2) |

### Bank C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: pick a time with a named stake, the message you carried, who heard it, and an intact working relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: the spreadsheet, in the quote's words, with nothing added about what it showed | F3 and F5 are the nearest material to reporting upward; the theme is a persona stem; VAL because it scores behaviour, not the credential |
| C2 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: new tellers, the script, the training; the beats the quote states. Answer slot: the JD's coaching line makes a probe on a live case likely. If you worked through a real escalation with someone, say what it was and what you did; if the training stayed with the script, say so plainly and stay with the tellers you trained | F4 is the coaching evidence; JD because coaching on escalations is a stated duty |
| C3 | "Tell me about a hard complaint you handled." | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: the log is the quote's beat. Answer slot: pick the complaint, say what made it hard and what you did, in your own words. If the log was your part of it, or the complaint was handled by someone else, say so plainly and stay with the log you handled. Keep the member's side in view: what they needed, in the plain words you would have used | F1 and F7 are the complaints evidence; JD because complaints handling is the core duty |
| C4 | "Tell me about a time you worked with another team to improve something members used." | JD | [generic] | Selection scaffold: pick a named team, what you changed together and what members saw afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle working with a digital team. The pack supplies no digital work for you | F9 holds no quote, so this is the scaffold case; JD because the digital-team duty is stated |

### Bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You would own complaints across branches and the contact centre. I don't see contact-centre experience in your background. How would you do that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI rehearsal in this pack, because this objection returns in some form in every round. Put the limit before it is asked for: "I haven't worked in a contact centre." The only bridge your quotes carry, at its own scope: "I handled the branch's formal complaints log", which is a branch log, not contact-centre work, and you say that difference yourself. Then a first step as a plan, in your own words; the pack names none. Follow-up 1, "why would the contact centre follow someone from a branch": hold by returning to the log without adding to it. Follow-up 2, "what would you do in your first month with them": plan, not past. Follow-up 3, "what if you are wrong about how it works": concede plainly, "That is a real risk, and it is the first thing I would learn." Never fold on what you did say, never claim what you did not | F2 is the stated absence on the second half of the headline requirement and F1 is the nearest evidence; JD because it scores the listed duty, Skeptic because it probes the gap |
| D2 | "You are a branch supervisor yourself. Why would other supervisors take coaching from you on escalations?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | Say what you have: the last three years as a branch supervisor, and the tellers you trained on the script. Answer slot: the JD's coaching line makes a probe on working with other supervisors likely. If you have worked with other supervisors on escalations, say how; if you have not, say so plainly and stay with the tellers you trained. Hold: do not claim supervisors followed your lead | F4 is adjacent evidence; JD because the duty is stated, Skeptic because it tests credibility |
| D3 | "This role presents to senior leaders. You haven't presented above regional level. What changes for you?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented above regional level." Hold through two follow-ups by staying with what you will do, in your own words, to prepare: name your own preparation, since the pack names none. Claim nothing about presenting at regional level; the quote does not say you did. Concede specifically: "That is new for me" | F5 is a stated absence on an explicit requirement; JD because the line is stated, Skeptic because it presses the gap |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | In the quote's words: you built it, it is monthly, it is for complaints, your regional manager uses it. Answer slot: expect a probe on what it counted, how each figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer each in your own words; where you do not know how a figure was counted, say so plainly. If it was a team build, or the tool was not Excel, say so and describe what you did | F3 and F8 are the reporting evidence; EXP because it tests attribution, with the weakest-assumption move rehearsed |
| E2 | "How would you make sure a complaint count is right before it goes to leaders?" | JD | [generic] | A structure, with no claim about your past: what counts as a complaint, when a resolution clock starts and stops, where the figures come from, who checks them, and what you do when two sources disagree. Say it aloud in under two minutes. Where you have done this, say so in your own words; where you have not, say what you would do first | F3's requirement asks for volumes and resolution times; JD with a CASE delivery, because it asks about method, not your history |

### Bank G: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Ashgrove plans to consolidate eight branches into five hubs over 2027. What would that do to the complaints process, and what do you need to know first?" | CO | [grounded] | Clarify first: which branches, what changes for the people members see, and what changes for how complaints are recorded. Then objective, segments of members, approach, measures, risks. Challenge one premise respectfully. Use the brief's word, hubs, and the value's phrase, "every branch is part of its town". Claim no knowledge of Ashgrove's current complaints process; say what you would ask | The brief's consolidation line is the likeliest strategy case for a manager of the complaints process; CO because it tests the credit union's altitude |
| G2 | "Sketch how you would set up the first 90 days: what do you need to know first?" | CASE | [generic] | A persona stem applied to the role: clarify first, then objective, then what you would learn before changing anything, starting with the contact-centre side, and who you would ask. Make no claim about your past; F2 says why the first step is learning | F1 and F2 are the two halves of the headline requirement; CASE because it asks for structure, not a record |

### Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would you want to be true about complaints at Ashgrove at the end of this person's first year?" | A manager's answer defines success, and you can build D1 and G2 on it |
| 2 | "Where does the contact centre's complaint handling sit relative to this role: who would work alongside me, and who would report in?" | Raises the seam your gap exposes before they do, as diligence |
| 3 | "How do you see the 40% digital target changing which complaints reach a person?" | Shows you read the brief and ties to the self-service duty |
| 4 | "What does a good monthly complaints report look like to you today, and who reads it?" | Tells you the reporting bar and who you would present to |
| 5 | "How would you want to hear about a problem the process is not solving: in what form, and how often?" | The manager relationship in one question, and it echoes Own the Fix without naming it |

## Round 3: the panel of two branch managers (60 minutes)

The recruiter described 20 minutes of the hour; the other 40 are not described. The pack treats them as values questions because the recruiter said the panel scores against the four values.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes mapped to the four published values | Highest: the recruiter said the panel scores against the four values, so a values-style round is documented | One story or honest scaffold per value (H1 to H4); "we" for context, "I" for contribution |
| Case / Strategist | The 20-minute complaint-escalation case | High: stated in the recruiter's email | Clarify, objective, approach, measures, risks; think aloud; challenge one premise (J1 to J3) |
| Peer Evaluator | The seam between a branch manager's work and yours | Medium: two branch managers sit next to a role that works across branches, though this relationship is my inference | Reciprocity first: what you bring their branches; propose principles, not a claimed seam (K1, K2) |
| Conversational | Friendly, casual question on the strategy | Lower: one touch, since the round is scored | Treat it as scored; speak in plain words (L1) |

### Bank H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Selection scaffold for Members First, Always: pick a time when the easiest route for the branch and the better route for the member differed; a named stake, the choice you made and why, and what the member experienced afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | The theme is the value's own wording; no quote carries a decision of this kind, so this is the scaffold case; VAL because it scores behaviour |
| H2 | "Tell me about a time something you explained or wrote had to be explained a second time." | VAL | [generic] | Selection scaffold for Plain Words: pick one specific thing you said or wrote, why it did not land, and the wording you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would write it so it needed explaining once | The theme is the value's own wording; no quote carries it; VAL because it scores behaviour |
| H3 | "Tell me about a time you thought about what a decision meant for the town your branch sits in, not just the figures." | VAL | [generic] scaffold; [grounded] the eight-to-five hub consolidation is in the strategy brief | Selection scaffold for Neighbours, Not Numbers: a named decision, who in the town it touched, and what you did differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh it. The brief's hub consolidation may make this live for branch managers; ask what it means for their towns rather than telling them | The theme is the value's own wording; no quote carries it; VAL, with a CO edge from the brief |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1, for Own the Fix: the log is the quote's beat. Answer slot: if you kept hold of a particular problem until it was solved, say which, what it was and what you did; if the log was the extent, or the problem passed to someone else, say so plainly and stay with the log you handled | F1 is the only quote near this value; VAL because it scores behaviour |

### Bank J: Case / Strategist

These three are practice cases written for rehearsal, not Ashgrove's actual case, which the recruiter has not described.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member has complained three times, in two branches and by phone, about the same charge, and now says they will take it further. Where do you start?" | CASE | [generic] | Clarify first: what exactly was said and promised each time, what the member wants, and what time limits apply to a formal complaint. Objective: one owner who keeps hold of it until it is solved. Approach: one record across branch and contact centre, a plain-words reply, and what you tell the member and when. Measures and risks: what the case says about the process, and what you would record. Think aloud, challenge one premise. The question needs no claim about your past, so the guidance makes none | A live problem set from the JD's escalation and regulated-complaint lines (F1, F7); CASE because the recruiter named a 20-minute case |
| J2 | "The supervisor involved says the member is being unreasonable and will not change how they handled it. What do you do?" | CASE | [generic] | Structure: hear the supervisor first, look at the record together, agree what good looks like, then follow up. Hold on one point: the complaint stays with whoever found it until it is solved, and you do not take it over silently. Say what you would do if the supervisor still disagrees. No claim about your past | A coaching case from the JD's supervisor line (F4); CASE because it asks for structure |
| J3 | "At month end, how would you tell the leadership team what this case says about the process? You have two minutes." | CASE | [generic] | Lead with the one-sentence takeaway, then the one or two measures you would show, named in the JD's terms, then what you want from them. Say it aloud in two minutes. Claim no past presenting at senior level; F5 holds none | Combines the JD's reporting and senior-leader lines (F3, F5); CASE because it is time-boxed |

### Bank K: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Our branches and your role sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Reciprocity first: what you would bring their branches. Then principles in your own words for the seam, not a claimed seam: ask which decisions they expect to stay with branch managers. Describe how you would raise a disagreement in the plain words you would use with them. No claim about your past | F4 is the coaching evidence that this question tests; JD because the duty is stated, with Peer delivery |
| K2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | "We" for context, "I" for contribution. In the quote's words, you built the spreadsheet. Answer slot: if others contributed to it, say who and what; if you built it alone, say so plainly | F3 is the one quote where the contribution is stated; EXP because it tests attribution |

### Bank L: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "App-only banks are our main competitive pressure. What would a complaint feel like at a credit union that they cannot match?" | CO | [grounded] | Speak from the member's side of the counter, in plain words. Say what you would want to find out about how members experience complaints today rather than claiming knowledge of any competitor's process. No claim about your past | The brief's competitive-pressure line meets the values; CO because it tests the credit union's altitude |

### Values and principles cheat sheet

| Value (official name) | Working meaning | Mapped story | Provenance |
|---|---|---|---|
| Members First, Always | Decide by what the member sees at the counter | Scaffold at H1, ending in its honest branch; no quote carries it | [grounded] "we decide from the member's side of the counter" — values page, as you pasted it |
| Plain Words | If members need it twice, the wording is the problem | Scaffold at H2, ending in its honest branch; no quote carries it | [grounded] "if a member needs it explained twice, we wrote it wrong" — values page, as you pasted it |
| Neighbours, Not Numbers | A branch's place in its town counts alongside the figures | Scaffold at H3, ending in its honest branch; no quote carries it | [grounded] "every branch is part of its town" — values page, as you pasted it |
| Own the Fix | The person who finds a problem keeps it until it is solved | F1: "I handled the branch's formal complaints log" — your message; the slot at H4 asks what you kept hold of | [grounded] "whoever finds the problem keeps hold of it until it is solved" — values page, as you pasted it |

### Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which of the four values is hardest to keep in a busy branch, and what gets in the way?" | Speaks to a branch manager's reality and shows the values are not slogans to you |
| 2 | "When a complaint starts in a branch and ends up in the contact centre, or the other way round, who has had hold of it so far?" | Asks the seam question your gap exposes, and it is the Own the Fix question in practice |
| 3 | "How will the move from eight branches to five hubs change which supervisors this role would coach?" | The brief's consolidation touches these two people directly |
| 4 | "What would you want the first monthly complaints report to tell you that you cannot see today?" | Tells you what branch managers need from reporting |
| 5 | "What could someone in this role do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-style panel |

## Requirement coverage

| Requirement | Fit row | Covered by |
|---|---|---|
| Own the member complaints process end to end | F1 | A3, C3, G2, H4, J1 |
| Across branches and the contact centre | F2 | B1, D1, G2, J1 |
| Report monthly on complaint volumes and resolution times | F3 | A4, E1, E2, J3 |
| Coach branch supervisors on escalations | F4 | A5, C2, D2, J2, K1 |
| Work with digital teams on self-service journeys | F9 | A2, C4, G1 |
| Confident presenting to senior leaders | F5 | B1, B3, C1, D3, J3 |
| 4+ years in financial-services customer operations | F6 | A1, B2 |
| Experience handling regulated complaints | F7 | A3, C3, J1 |
| Comfortable with Excel reporting | F8 | A4, E1 |
| Published values, all four | | H1, H2, H3, H4 |
| Strategy-grounded CO or CASE | | A2, G1, L1 |

## Prohibited claims

What this pack will not coach, built from the fit snapshot before the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log, not the process end to end. A3, C3 and H4 stay inside the log |
| Worked across branches and the contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Presents to senior leaders | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't presented above regional level." No slot |
| Presented complaints reporting to your regional manager | Inflated form of F3 | F3's quote at its own scope: the spreadsheet is one your regional manager uses; the material does not say you presented it |
| Reported complaint volumes and resolution times each month | Inflated form of F3 | F3's quote at its own scope. A4 and E1 ask only what the spreadsheet counted |
| Built Excel reports | Inflated form of F8 | F8's quote at its own scope: a spreadsheet. A4 and E1 ask only which tool |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: formal complaints, in a log. A3 asks only what governed the log |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers, the escalation script. C2 and D2 stay inside it |

## Sources

Provided documents: the JD as you pasted it; the values page as you pasted it ("copied this morning (11 November 2026) from ashgrovecu.org/about/values"); the recruiter's email about the process; your summary of Ashgrove's July 2026 strategy brief, which is four points, not the full text; your background, as you described it in your message. No `tuesday-dossier.md` was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values page fixes the four names, the cheat sheet and the H bank |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the three rounds, who runs each and what each holds; persona weights and banks follow it |
| 3. `Ashgrove Credit Union strategy` and recent news | skipped | The July 2026 brief, about four months old, fixes A2, G1 and L1 and the grounding brief |
| 4. interviewer name and company | n/a | No name was given, only roles, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Your CV → the fit snapshot quotes your CV's own lines instead of your message, which can add specifics to F1, F3, F4, F7 and F8 and move some `medium` rows up
- A redacted view of the monthly complaints spreadsheet's column headings, with no member data → F3 and F8 can rise from `medium` to `high`, and A4 and E1 become story-mapped
- Your answers to the answer slots on F1, F3, F7, F8 and F9 (what the spreadsheet counted, what tool it was in, what governed the log, whether any stage beyond the log was yours, any digital-team work) → each becomes quoted evidence and those rows regenerate
- The two branch managers' names and titles when assigned → an interviewer read, reweighted personas for round 3 and a reverse question tied to their own path
- The full text of the July 2026 strategy brief → CO questions that use its own numbers and wording instead of the four points
- Anything the recruiter can share about the 20-minute case: scenario given in advance or live, and whether to bring anything → J1 to J3 become specific to that format
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering interviewer public footprint once names exist, role-family loop reports and recent organisation context → say "go deeper" and I will run it
- A `tuesday-dossier.md` from a role assessment, if you ever run one → verified evidence and an assessed gap strategy per requirement, which would tighten the objection rehearsal
