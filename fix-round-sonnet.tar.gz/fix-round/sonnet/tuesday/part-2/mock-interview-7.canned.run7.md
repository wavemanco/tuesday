Searches done (4 of 6). Fetching Saltmarsh's official values and interviewing pages next, so value names and loop structure come from the source.
Femi, your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-canned-39f07aa8/saltmarsh-games_live-operations-producer_interview_pack.md`.

I ran a standard research pass: 4 searches and 2 page fetches. Saltmarsh's own interviewing page says every loop ends in the "Outage Hour". That is a single 60-minute interview with the hiring manager, which opens with a live-incident tabletop on a simulated outage and then moves to a values conversation. The pack is built around that format, with 21 questions across six interviewer styles.

- **Highest-ROI prep:** C1, the in-app-purchases question. Saltmarsh's September 2026 "Project Larkspur" news (I only saw a search snippet) says both titles move to a season-pass model. Your honest answer is the plain acknowledgment plus a ramp plan, said as a plan and not as a past.
- **What you can lean on:** your weekly content-drop calendar, the release checklist QA still uses, and the retention presentations. The pack keeps each at exactly the scope you stated.
- **Tobias:** his GDC 2026 talk, "Patch Notes Are a Promise", argues a live team is judged by whether its patch notes match what shipped. That lines up with one of Saltmarsh's three published values, "Ship the Patch Not the Promise", so expect it in the tabletop and the values half. He's also listed as a former QA lead, so expect depth on your checklist.
- **A mismatch to ask about:** the JD says "two of our mobile titles", but Larkspur points to one shared calendar and one live-ops group. R2 in the reverse questions asks where this role sits.
- **Gaps with no honest bridge:** the pack does not coach any claim of having led a team, worked with in-app purchases, or owned the review KPIs. It lists each in the prohibited-claims section.
- **Slots to fill:** some rows end in "answer slots" where your material is silent. Say the true branch in your own words.

The Project Larkspur and GDC pages are search snippets only, so read them before Friday.

Say the word and I'll run the Outage Hour tabletop as a live drill, then the Skeptic on C1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the hiring manager you'd report to, and did the recruiter say anything about the tabletop, such as which titles or systems it uses? The answer reweights the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** the single 60-minute interview. Saltmarsh's own interviewing page describes it as the "Outage Hour" with the hiring manager: a live-incident tabletop on a simulated outage during a live event, then a values conversation. This pack assumes Tobias is that hiring manager, which is an inference from the page and your note, not something you told me.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and where a cell says "answer slot", the honest answer is whichever branch is true for you.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows Saltmarsh's published values |
| EXP | Whether what you said about your work survives follow-ups |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's current direction |
| CASE | Structure and reasoning on a live problem |

## 2. Prep triage

Do these in order. Everything else is insurance.

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse the in-app-purchases question out loud until the answer is calm and short | C1 |
| 2 | Talk through the tabletop questions aloud, one at a time, thinking aloud | A1, A2, A3, A4, E2 |
| 3 | Pick your story for each published value, or decide honestly that you have none | B1, B2, B3, B4 |
| 4 | Decide what you can and cannot say about how the retention numbers were counted | D1 |
| 5 | Choose three reverse questions | Section 8 |

Everything else is insurance.

## 3. Fit snapshot

Evidence cells hold your own words only. A "none given" means your material is silent, which is not the same as a gap you stated.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one title, with nothing inspected behind it, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD says two titles and live events, so expect a probe on both. If any drop on your calendar was a timed event, or you ever planned across more than one title, say how, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | low | [grounded] | discovery | Your sentence says you have not led a team; the JD says coordinate, and your material does not show whether you coordinated these disciplines. Words you can say about leading: "I haven't led a team." Answer slot: if you coordinated any of design, art, engineering or community on a drop, say which and what you did, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says presenting the monthly numbers, not owning a review or its KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you also chose or built the figures you presented, say what you did; if someone else produced them, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead with the quote in its own terms: you wrote the checklist, and QA still uses it. The pack does not say you managed releases, and the words stay at "wrote". Expect a probe, since nothing is inspected behind the line |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | An experience length is graded like any requirement, not treated as a gate. Your sentences give four years as an associate producer and a weekly calendar, and do not say whether the title was run as a live service. Answer slot: the JD's live-service wording makes a probe likely; if the main title was run as a live service, say how, in your own words; if it was not, or was run differently, say so plainly and stay with the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it as a named record: weekly, your main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but the line gives no figure or method, so expect a probe on how the numbers were counted (D1). Lead with the quote in its own terms |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | discovery | A checklist people still use is writing, and your material shows nothing more. Answer slot: if you wrote other things others relied on, such as event notes or reviews, name them; if you did not, say so plainly and stay with the checklist |
| F9 | Monetization context under a season-pass model: no JD line asks for it; the company's September 2026 news result makes it likely to come up — the pack's reading | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work, and nothing added to make the gap feel smaller |

## 4. Reading the interviewer

Public professional footprint only. Source: a search result for Tobias's GDC 2026 talk (Sources, target 4); the page itself was not fetched.

| Public fact | What it implies | Mirror opportunity |
|---|---|---|
| Head of Live Operations at Saltmarsh Games | Owns the function you would join | Ask about structure and success, not tactics |
| GDC 2026 talk "Patch Notes Are a Promise"; its argument as listed: a live team is judged by how often its patch notes describe what actually shipped | His own framing matches the published value Ship the Patch Not the Promise, so expect the tabletop's first player message (A2) and B2 to test announcing only what is built | Use plain, checkable wording in A2 and B2; do not recite his talk back to him |
| Listed as previously a QA lead at a console studio | He knows what a release checklist should and should not hold, so expect depth on F4 and B3 | Shared vocabulary: "Wrote the release checklist our QA team still uses." (F4). Say it in those terms and let him ask about it |

## 5. Persona table

Weights come from three passes: the hiring-manager prior, the loop Saltmarsh's interviewing page documents, and Tobias's public signals. Change them if you know something I do not.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The simulated-outage tabletop | Highest. The interviewing page says the hour opens with a live-incident tabletop, and the hiring-manager prior also leads with Case | Clarify, then objective, then who owns what, then approach, metrics, risks. Think aloud. Challenge one premise respectfully (A1 to A5, E2) |
| Values/Behavioral | The values conversation after the tabletop | High. The same page says a values conversation follows, and the three values are published | Map a story to a value only where your own sentence carries one (B3); otherwise choose by the scaffold's criteria and keep its honest branch (B1, B2, B4) |
| Skeptic | Quiet probing of the gaps | High. A hiring manager derisks, and your own message names two gaps: no team led, no in-app purchases | Rehearse C1 until it is boring. Plain acknowledgment plus a ramp plan said as a plan (C1 to C4) |
| Data-Driven Prober | Follow-ups on how a number was counted | Medium. Your retention-presentation line is the kind a prober reads closely; nothing public says Tobias is analytics-led, so it is not raised further | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know (D1 to D3) |
| Pressure | Time-boxed interruptions inside the tabletop | Medium. The tabletop is a simulated outage; no source says Tobias interrupts | Pause, restate, hold a decision through two follow-ups unless a new fact changes it (E1, E2) |
| Conversational | The opener and the company-direction chat | Medium. Every hour has one, and it is still scored | A 90-second arc and one prepared question about direction (F1, F2) |

A peer persona is not included: Tobias heads the function, so nothing supports a peer frame.

## 6. Question banks

### A. Case/Strategist (tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event has just opened, and within ten minutes players are being dropped from matches. Engineering, design and community are on a call with you. What do you do in the first fifteen minutes?" | CASE | [generic] | Clarify first: who is affected, since when, what engineering already knows. State the objective in one sentence, then say who owns what across design, art, engineering and community, and what players will be told and when. Think aloud and challenge one premise, such as whether the event should stay open. The question needs no claim about your past, so this guidance makes none | The Outage Hour opens with a tabletop (Sources, target 2). F2 is the JD line it scores; CASE because it is a live problem. The scenario is a pattern, not Saltmarsh's actual one |
| A2 | "Engineering says the fix is two hours away and community wants to know what to tell players. What goes in the first message, and what stays out?" | CASE | [grounded] | Say what is known, what is not, and when the next update comes. Keep hoped-for outcomes out, in line with the published value: we announce what is built, not what is hoped. Write it as two or three plain sentences you could read aloud. The question needs no claim about your past, so this guidance makes none | F8 is the written-communication line it scores, and the published value plus Tobias's talk theme (section 4) make it likely. CASE because it is a live problem |
| A3 | "The event ends tomorrow, the fix lands after it closes, and the calendar has a new drop the day after. What are your options for players and for the calendar?" | CASE | [grounded] | Lay out two or three options, such as extending, compensating or moving the next drop, with the cost of each to the teams involved. Recommend one. The published value says that when the calendar and the players disagree, the players win, so show you see the conflict before you resolve it. Challenge one premise. The question needs no claim about your past, so this guidance makes none | F1 is the calendar requirement it presses on, and the published value frames the trade-off. CASE because it is a live problem |
| A4 | "Once it is resolved, how would you run the post-event review, and what would you put in front of the team?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: timeline, player impact, cause, what changes, who owns each change. Where the checklist comes in, say only what the quote says: you wrote the release checklist, and QA still uses it. Answer slot: the published value says every release leaves the checklist better than it found it, so expect a probe on whether a review ever changed a checklist; if the checklist was ever changed after a release, say what changed and who decided; if it was not, or the change was not yours, say so plainly and stay with the checklist you wrote. For the numbers, see D2 | F3 is the post-event review requirement and F4 the checklist; JD because it scores the stated requirement, with CASE delivery |
| A5 | "Marketing wants to add a second event next week, and your calendar already has a drop that day. What do you need to know before you answer?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Open with what you can stand on: "I ran the weekly content-drop calendar for our main title for the last two years." Then clarify before answering: what each item commits the teams to, what can move, what players expect. Answer slot: the JD asks you to run the calendar for two titles, so expect a probe on clashes; if clashes came up on your calendar, say how one was resolved and what part was yours; if none did, or the call was not yours, say so plainly and stay with the calendar you ran | F1 and F6 are the calendar rows; JD because it scores the stated requirement, with CASE delivery |

### B. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the players and the plan pointed in different directions. What did you do?" | VAL | [grounded] | Selection scaffold, since none of your sentences carries this story: pick an instance with a named stake, a decision, and what players saw as a result, and say which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Raised by the published value Players Before Plans: when the calendar and the players disagree, the players win. VAL because it scores that value; no row of the snapshot carries the story |
| B2 | "Tell me about a time you had to decide what to tell players about something that was not finished." | VAL | [grounded] | Selection scaffold: pick an instance where what was announced and what was built were different things, say what was said and what you would say now, and say which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Raised by the published value Ship the Patch Not the Promise and by Tobias's public talk theme (section 4). VAL because it scores that value |
| B3 | "You wrote the release checklist your QA team still uses. Walk me through it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | The beats are the quote's: you wrote it, and QA still uses it; tell them in your own words. Answer slot: the published value says every release leaves the checklist better than it found it; if the checklist was revised after use, say what changed and why; if it was not, or the revisions were QA's, say so plainly and stay with the checklist you wrote | F4 is the evidence; Leave the Build Greener is the value it maps to. VAL because it scores that value, with EXP depth since Tobias's public background is QA (section 4) |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | The quote gives you a setting, presenting the monthly numbers to the studio head, and not what was in them. Answer slot: if any of those presentations carried a number the studio head did not want to hear, say what it was and how it landed, in your own words; if none did, say so plainly and stay with presenting the monthly numbers. Choose a story where the hard truth actually landed | F3 and F7 touch this row; VAL because it scores honest reporting upward |
| B5 | "Which of our three values would be hardest for you to live up to here, and why?" | VAL | [grounded] | Pick one honestly and give a reason from how you work, then what you would do about it, said as a plan. Do not choose the one you have rehearsed best. The question needs no claim about your past, so this guidance makes none | The three values are published; a values conversation often closes on self-assessment. VAL because it scores honest self-assessment against them |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Both titles are moving to a season-pass model, and you have never worked on a game with in-app purchases. How do you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI prep in this pack. Say the plain acknowledgment first: "I haven't worked on a game with in-app purchases." Then the ramp plan, said as a plan: whom you would sit with first and what you would ask before touching the calendar. Hold through two follow-ups by returning to the calendar quote, never by adding to it. If asked how you know it transfers, say what the quote says and no more. Concede specifically: the gap is in-app purchases, and your material shows nothing beyond the calendar. Answer slot: name, in your own words, the part you would least trust yourself on at first | F9 is the biggest stated gap and the company's direction makes it likely, so this arrives in some form; F1 is what you hold. JD because it scores the role's fit |
| C2 | "Your calendar was weekly content drops for one title. What is different about running live events for two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start from the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD says two titles and live events; if any drop on your calendar was a timed event, or you ever planned across more than one title, say how; if not, say so plainly and stay with the calendar you ran. Do not describe an event or a second title you did not run | F1 is the requirement and its limit is the one title. JD because it scores the stated requirement |
| C3 | "You have never led a team, and this role coordinates design, art, engineering and community on every update. Why would they follow your calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment: "I haven't led a team." The JD says coordinate, which is its own word; do not trade it for lead. Answer slot: if you coordinated any of those disciplines on a drop, say which and what you did, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar you ran | F2 is the row; the stated negative has its source in your message. JD because it scores the coordination requirement |
| C4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose one and be specific. Your own message names two gaps, so say the one you can speak to with a plan. Do not name a gap and then claim near-experience for it. The honest answer is a limit, not a confession | F9 and F2 are where your message already shows limits. JD because the JD is the scoring sheet |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say how the numbers were counted, what they were sensitive to, the assumption you would defend least, and which part was yours, each in your own words; if you do not know how a figure was counted, say so plainly. Nothing in this pack names a method for you | F7 is the likeliest line to be probed. EXP because it tests attribution and the figure's assumptions |
| D2 | "Which numbers would you put on the front page of a post-event review, and why those?" | JD | [grounded] | Pick a few. For each, say what decision it informs and what it cannot tell you, and name the assumption you would defend least. The question needs no claim about your past, so this guidance makes none | F3 is the KPI requirement; the JD line raises it. JD because it scores the stated requirement |
| D3 | "Retention dips the week after an event. How would you tell whether the event caused it?" | CASE | [generic] | Clarify which players and which week, then what else changed that week, such as a release or an outage. Say what you would compare against and which assumption would break the comparison. Think aloud. The question needs no claim about your past, so this guidance makes none | F7 is the requirement it presses on. CASE because it is a diagnosis problem |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Pause and restate. Hold only what the quotes carry: you ran the weekly content-drop calendar for your main title for the last two years, and you wrote the release checklist QA still uses. Concede in one line: "I haven't worked on a game with in-app purchases." Hold through two follow-ups, and do not say what those facts prove | F1, F4 and F9 are the three rows it weighs. JD because it scores fit against the stated requirements |
| E2 | "Stop. The event closes in an hour and engineering will not commit to a time. Decide now: extend or not?" | CASE | [grounded] | Pause, restate, give a decision and the one thing you would confirm first. Say explicitly what you do not know. Hold the decision through two follow-ups unless a new fact changes it, because pressure alone is not a fact. The published value puts players first when the calendar and the players disagree. The question needs no claim about your past, so this guidance makes none | An interruption inside the tabletop tests composure; F2's coordination line is what it scores. CASE because it is a live problem |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc of exactly four beats: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for your main title for the last two years; the release checklist QA still uses; presenting the monthly retention numbers to the studio head. Say them in your own words. Close with your own reason for this role and this studio; nothing in your material or this pack supplies it | F5 is the years row and the others feed the arc. EXP because it is the biography question |
| F2 | "What have you seen of where our live ops is heading?" | CO | [grounded] | Say only what you have read, after you read it: the pack had a search snippet of the September 2026 Project Larkspur announcement, not the page. The snippet says two titles move to a season-pass model with one shared events calendar from February 2027, and per-title event teams give way to a single live-ops group. Then ask one question instead of reciting. The JD speaks of two titles while the announcement points the other way, so ask about it and do not correct anyone. The question needs no claim about your past, so this guidance makes none | The one strategy-grounded CO question from L1 research. CO because it tests homework depth, in a casual register that is still scored |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, A5, C2 |
| Coordinate design, art, engineering and community teams on each update | A1, C3, E2 |
| Own the post-event review and the KPIs it reports | A4, D2, D3 |
| Manage the release checklist with QA | A4, B3 |
| 3+ years producing live-service games or apps | F1, E1 |
| Experience running a content calendar | A5, C2, F1 |
| Comfortable with player-retention metrics | D1, D2, D3 |
| Clear written communication | A2, A4 |

## 7. Values cheat sheet

Detected: Saltmarsh's interviewing page documents a values conversation. The value names are from the company's own values page.

| Value | Working meaning, paraphrased | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | None of your sentences carries this. Selection scaffold: see B1, ending in its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | None of your sentences carries this. Selection scaffold: see B2, ending in its honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Beats stop at the quote; whether it was improved over releases is B3's answer slot |

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argued that patch notes are a promise. How does this team check that what it announces matches what shipped?" | Tied to Tobias's public talk; it shows you read his argument and asks about the practice behind it |
| R2 | "Project Larkspur moves the two titles to one shared calendar and one live-ops group. Where does this role sit in that structure?" | The JD describes two titles while the announcement points to one group, so this settles what the job actually is |
| R3 | "How is monetization planned alongside the events calendar under the season-pass model, and who is in that conversation?" | Turns your stated gap into curiosity, and answers something you need before accepting |
| R4 | "How do QA and live operations share ownership of the release checklist today?" | Ties to Tobias's public QA background and to the one artifact you can speak to |
| R5 | "What would you want to be true about the events calendar ninety days after I start?" | Gets his success definition in his words |
| R6 | "In the Outage Hour, what separates the answers you remember?" | Signals preparation and asks for calibration |

## 9. Prohibited claims

Built before the banks. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative you stated, F2 | "I haven't led a team." No slot |
| Worked on a game with in-app purchases or monetization | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot; the ramp plan is a plan, never a past |
| Ran live events for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for one title |
| Owned the post-event review or its KPIs | Inflated form of F3 | F3's quote at its own scope: your material says presenting the monthly numbers |
| Managed releases or owned the release process | Inflated form of F4 | F4's quote at its own scope: your material says you wrote the checklist QA still uses |

## 10. Sources

Provided: the job description and your background, both in your message.

Searches sent, each by query with what came back:

- "Saltmarsh Games values": one result, saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer": one result, saltmarshgames.com/careers/interviewing
- "Saltmarsh Games mobile studio strategy news": one result, saltmarshgames.com/news/project-larkspur (search snippet only; the page was not fetched)
- "Tobias Wrenfield Saltmarsh Games": one result, talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; the page was not fetched)

Pages fetched: saltmarshgames.com/values and saltmarshgames.com/careers/interviewing.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, section 7: three values by name; B1, B2, B3 and B5 |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: the Outage Hour; persona weights, the A bank and the E2 interruption follow from it |
| 3. `Saltmarsh Games strategy` / recent news | yes | F9's reading, F2 and R2 and R3; the snippet only, so read the page before Friday |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Section 4 and R1, R4; the snippet only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- Confirmation that Tobias is the hiring manager for this role → persona weights firm up and the interviewer read stops being an inference
- What the recruiter said about the tabletop, such as which titles or systems → the A bank can match the real scenario instead of a pattern
- A retention figure you presented and how it was counted, or a calendar or report you can share → D1 becomes a defend-the-number answer, and F3, F6 and F7 can rise from medium
- Your answers to the slots in F1, F2, F3, F5, F8, A4, A5, C2 and C3 → those rows become quoted evidence and their guidance gets sharper
- Reading the Project Larkspur page and watching Tobias's talk yourself, since I had snippets only → F2, R1 and R2 become precise
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering a strategy brief, Tobias's other talks and writing, reports on this loop, and recent org context → a grounding brief and sharper CO questions
- A tuesday-dossier.md from an earlier role assessment, if you have one → verified evidence and prohibited claims arrive pre-graded
