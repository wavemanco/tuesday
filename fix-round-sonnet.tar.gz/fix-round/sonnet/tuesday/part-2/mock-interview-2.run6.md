Writing the prep pack now. Web research was denied, so it will rest on your JD text and background only.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-2-denied-36f552e2/Atlas-Freight_operations-manager_interview_pack.md`.

I built it for a hiring-manager round, since you don't know who is interviewing you. Web search was denied, so nothing in it is a claim about Atlas Freight. The company questions are labeled `[generic]`, and the file says so.

- **Strongest material:** the peak-season surge plan, the 40% mis-pick cut and the green belt all map cleanly to the JD.
- **Where you'll be probed hardest:** going from 3 supervisors to 12 and from one site to four, "warehouse and distribution" versus "terminal operations", and Power BI. The span-and-scope question (A1) is the highest-ROI prep in the pack. It has a full follow-up ladder.
- **What's in the file:**
  - a one-week prep triage
  - 22 questions across seven interviewer styles, each with answer guidance
  - a requirement-coverage table
  - six questions for you to ask them
  - a list of claims the pack won't coach
- **Answer slots:** where your background doesn't show something the interviewer will likely ask about, such as total supervisors you've led or whether you tracked on-time performance, the guidance gives an answer slot instead of inventing a story. The honest branch is always allowed, including "that wasn't mine".

Say the word and I'll play the Skeptic on A1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to a Word document if you'd like.

Do you know whether the first conversation is with your future manager, a peer, or HR, and did the recruiter mention any focus areas or something to prepare in advance? The answer would reweight every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas-Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: unknown. Round type: unknown, so this pack assumes a hiring-manager round, because that is the likeliest first serious conversation for this role. No loop source was available, so the loop falls back to the Generic archetype (screen, hiring manager, panel) and persona weights are the hiring-manager prior with nothing else to tilt them. Nothing in this pack is a claim about Atlas Freight itself: the research searches were refused, so company-level questions are labeled `[generic]`.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: where it quotes you, those are your own sentences from your message; where it says "answer slot", it is an instruction for the interview, and only you know the answer.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows what the question is after |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Live problem from the role, asked as a hypothetical |

## Prep triage

You said the interview is next week. In order, with everything else as insurance:

1. A1: rehearse the span-and-scope question until it is boring. It is the highest-ROI prep in this pack.
2. A2 and F5: settle your Power BI plan, in your own steps, and say it out loud twice.
3. C1, C2, E1: decide what you actually know about how the 40% was counted, and what you do not.
4. B1 and B2: talk through both cases aloud, once each.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows one shift and "the site's" surge plan, in warehouse and distribution work, not four sites and not terminals, and the words stay there: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on scope likely. If you were responsible for more than your own shift or site, say which and how many, in your own words; if not, say so plainly and stay with the shift and the site's surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is about mis-picks, not on-time performance or cost per shipment, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names both measures. If you tracked either, say which and how it was counted, in your own words; if you tracked neither, or it was not yours, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 and the JD says 12, and the number stays attached to what you said: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have supervised or coordinated more than 3, say who and when, in your own words; if you have not, or it was not yours, say so plainly and stay with the 3 supervisors |
| F4 | "build reporting in Excel/Power BI" — JD (Excel part) | "solid Excel" — your message | low | [inferred] | discovery | The quote says skill level, not whether reporting was built, so the bridge stays small: "My Excel is solid." Answer slot: if you have built reports in Excel, say what they showed and who used them; if you have not, or it was not yours, say so plainly and stay with solid Excel |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI part) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. No claim to dashboard work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The 7 years are in operations and the quote does not say how many of them were leadership, so the number stays on what you said. Answer slot: the JD's required-years line makes a probe likely. Say when you first led supervisors and for how long, in your own words; if the leadership years are fewer than the 7, or you cannot count them precisely, say so plainly and stay with the 7 years in ops and the current role |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a claim with nothing inspected behind it, so expect a probe. Lead in the quote's terms: "I'm green belt certified." Answer slot: if the pick-path redesign used green belt methods, say which steps, in your own words; if it did not, say so plainly and stay with the certification |

## Persona table

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of span, scope, tool gap and background fit | High | Hiring-manager prior puts Skeptic first; F1, F3, F5 and F6 are where the material is thinnest | Rehearse the single most predictable objection until it is boring; calibrated candor over bluffing |
| B. Case/Strategist | Live problems from the job: diagnose on-time, explain cost, plan a surge | High | Hiring-manager prior puts Case second; the JD's on-time, cost, reporting and surge lines map straight to problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| C. Data-Driven Prober | Line-by-line on the 40% and how you track supervisors | Medium | Flat Generic-archetype weight; kept at depth 3 because the mis-pick figure is a headline number | Know how the figure was counted and say plainly where you do not; name the weakest assumption first |
| D. Values/Behavioral | Tell-me-about-a-time probes on leadership | Medium | No loop source documents a values round and the fallback archetype reads no, so no values bank or cheat sheet; behavioral probes kept because the JD leads a 12-person supervisor team | Choose stories where the hard truth landed; "we" for context, "I" for contribution; say so plainly where no story comes to mind |
| E. Pressure | Interrupts, time-boxes, tests whether you fold | Low | Flat weight; strongest if the interviewer is senior | Pause, restate, hold through two follow-ups, then concede only what is true and specific |
| F. Conversational | Friendly opener, "walk me through the journey" | Low | Flat weight; the opener is scored even when it feels casual | A pre-scripted 90-second arc built from your own sentences |
| G. Peer Evaluator | Seam-splitting with adjacent site leads | Low | Applies only if a panel includes another site leader; unknown | Reciprocity framing; propose seam principles, not a pretended seam |

## Question banks

### A. Skeptic (depth 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role covers four sites and twelve supervisors. You're a senior shift manager over three supervisors. What makes you ready for that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Highest-ROI rehearsal in this pack. Say it in the quote's terms: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's four-site and 12-supervisor lines make a probe on span and scope likely. If you have led or covered more than 3 supervisors, or more than one site, say how many and in what role, in your own words; if you have not, say so plainly and stay with the 3 supervisors. Then the ramp, as a plan in your own steps and never as a past. Follow-up one: "Three is a long way from twelve. What changes?" Answer from the plan. Follow-up two: "How many people have you led in total?" Same slot. Hold by returning to the 3 and the plan; never add to the number | F3 and F1 are the widest gap between evidence and requirement, so this objection arrives in some form; JD because it scores the stated requirement |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "solid Excel" | Give the plain acknowledgment first: "I've never used Power BI." Then the plan for it, in your own steps, as a plan. If the interviewer moves to Excel: "My Excel is solid." Answer slot: if you have built reporting in Excel, say what it showed; if you have not, or it was not yours, say so plainly and stay with solid Excel | F5 is the one gap you have stated yourself; F4 is where a follow-up lands next; JD because it scores the reporting requirement |
| A3 | "Your background is warehouse and distribution. This job is terminal operations. How does one carry over to the other?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say it as the quote has it: "I have 7 years in warehouse and distribution ops." Answer slot: the JD says terminal operations, so expect a probe on freight versus warehouse. If any of that work was terminal or freight work, say which parts and what you did; if none was, say so plainly and stay with warehouse and distribution. Then what you would learn first, as a plan | F1 is the row that carries the terminal requirement; JD because it tests the stated scope, Skeptic because it probes the background mismatch |
| A4 | "The posting requires 5+ years of operations leadership. How many of your 7 years were leadership?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Keep the number on what you said: "7 years in warehouse and distribution ops." Answer slot: say when you first led supervisors and for how long, in your own words; if the leadership years are fewer than the 7, or you cannot count them precisely, say so plainly and stay with the 7 years and the current role | F6 is where the posting's required line meets undated evidence; JD because it scores the stated requirement |
| A5 | "Why leave your current role, and why Atlas Freight, and why now?" | CO | [generic] | Selection scaffold: one reason about the scope of the role, which the JD states as four sites and twelve supervisors; one reason about the company, using only what you have read or the recruiter told you. Nothing here is a claim about Atlas, because research did not run. If no company-specific reason has formed yet, say so plainly, and give the role reason | Skeptic's motivation probe; CO because it tests homework; `[generic]` because no company research was available |

### B. Case/Strategist (depth 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four sites has slipped over three weeks. What do you need to know first, and how do you diagnose it?" | CASE | [generic] | Clarify first: how on-time is defined and measured, which shifts, lanes or customers, and what changed. Then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully. The case needs no claim about your past, so the guidance makes none | F2's requirement asked as a diagnosis; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Cost-per-shipment is rising while on-time performance stays flat. Where do you look?" | CASE | [generic] | Split the ratio: what is in the cost and what is in the count of shipments, then segment each. Say what would change your mind. No claim about your past | F2's other measure, asked as a decomposition; CASE because it scores structure |
| B3 | "A storm closes one site for two days at the start of your peak week. Sketch the plan. What do you need to know first?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: facts needed, priorities, who does what, how you will communicate. Where it fits, you may say "I ran the site's peak-season surge plan two years running", in those words and no further. Answer slot: if asked what the plan covered, say what it covered in your own words; if a part was not yours, say so plainly | F1 holds the surge evidence; CASE because it is a live problem, with the quote as an optional anchor |
| B4 | "Leadership no longer trusts the reports because each site's numbers differ. How do you get to one version for four sites?" | CASE | [generic] | Definitions before tools: agree what each measure means, one source, one owner per measure, a cadence. If asked which tool, F5's words apply and your tool plan comes after the definitions. No claim about your past | F4 and F5's requirement as a problem; JD content, CASE delivery |
| B5 | "You inherit twelve supervisors across four sites with uneven results. What do you do in your first sixty days?" | CASE | [generic] | Listen and read the data before changing anything, then priorities, then a cadence. State the moves as your plan, in your own words. No claim about your past | F3's requirement as a plan; CASE because it scores structure |

### C. Data-Driven Prober (depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say it as the quote has it: "I cut mis-pick rate 40% by redesigning the pick path." Answer slots, each in your own words, each with an honest "I don't know": how the 40% was counted; what it is sensitive to; which part was yours. Do not state a baseline, period or method the quote does not carry | F2's headline figure is the likeliest thing probed line by line |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name the assumption you would defend least, in your own words, before they do. Answer slot: if you cannot name one, say so plainly and say how you would check the figure | F2 again, aimed at the weakest-assumption move |
| C3 | "How do you track how your three supervisors are performing day to day, and where do those numbers live?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "solid Excel" | Answer slot: the JD's reporting and on-time lines make this likely. If you track any measures for your supervisors, say which and where you keep them, in your own words; if you track none, or it is not yours, say so plainly and stay with "My Excel is solid." | F3 and F4 meet here; JD because it tests the reporting requirement |

### D. Values/Behavioral (depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, the moment you said it, and a relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Behavioral stem; tagged VAL for its behavioral content only, since no published values were read |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a named customer, the internal metric you traded off, what it cost, what you decided. If none comes to mind, say so plainly, then the nearest thing your material carries, or how you would handle it | Behavioral stem; relevant to the JD's on-time and cost pairing in F2 |
| D3 | "Tell me about a time you led supervisors through a change they did not want." | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Selection scaffold, with the nearest thing in your material as an option: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if any supervisor pushed back on it, say what happened; if none did, say so plainly and stay with the redesign. If no such time comes to mind, say so plainly | F3's leadership requirement, asked as a story; the open prompt supplies no event |

### E. Pressure (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That 40% mis-pick reduction. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence through two follow-ups: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if others worked on it, say who and what they did; if it was yours alone, say so; either way plainly. Concede only something specific and true, and never the core sentence just to ease the room | F2's attribution probe in its pressure form |
| E2 | "Sixty seconds: why you over a candidate who already runs several sites?" | JD | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified"; "currently a senior shift manager over 3 supervisors" | Build the sixty seconds only from your sentences: "I ran the site's peak-season surge plan two years running. I cut mis-pick rate 40% by redesigning the pick path. I'm green belt certified." Then stop and let them draw the inference. If pushed on scope, concede in the quote's terms: "I'm currently a senior shift manager over 3 supervisors." | F1, F2, F3 and F7 are the evidence this answer rests on; Pressure persona, JD content |

### F. Conversational (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc whose beats are exactly these five sentences, in your own words, connected by your own links. Close with your own reason for this role, said in your own words. Add no beat the sentences do not state | Casual opener, still scored; F1, F2, F3 and F7 supply the beats |
| F2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Say "I'm green belt certified." Answer slot: if you use Lean or Six Sigma tools in your work now, say which and where; if you do not, say so plainly and stay with the certification | F7's plus-skill, asked casually, which is how a rapport interviewer scores it |

### G. Peer Evaluator (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites sit side by side. Where is the seam between mine and yours, and what happens when we disagree?" | JD | [generic] | Offer principles for who owns what at a handoff, in your own words, rather than pretending to know the seam. Then what you would bring their site, not only what you would need. For the disagreement story, pick a time you disagreed with an equal and it held together; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Applies if a panel includes another site leader; F1's four-site requirement makes cross-site seams likely |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: "we" for context and "I" for your contribution; pick a case where credit could have gone either way. If none comes to mind, say so plainly, then the nearest thing your material carries, or how you would handle it | Peer persona stem; F1's multi-site scope makes shared work likely |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B1, B3, G1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C3, D2 |
| "lead a team of 12 supervisors" | A1, B5, C3, D3 |
| "build reporting in Excel/Power BI" | A2, B4, C3 |
| "5+ years operations leadership required" | A4, E2 |
| "Lean/Six Sigma a plus" | F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance defined and measured across the four sites today, and where do the numbers live?" | Shows you ask for definitions before chasing a number, and tells you which reporting tool the job really uses (F4, F5) |
| R2 | "How are the twelve supervisors spread across the sites, and how much does experience vary among them?" | Tests the span-of-control reality behind F3 and shows you are already thinking about the step in scope |
| R3 | "What would you want to be different at the four sites after my first ninety days?" | Gets the success measure in the interviewer's words, which sharpens every case answer |
| R4 | "Which reporting tools does the team use today, and what does onboarding look like where someone has not worked in one?" | Owns the ramp plan for F5 in the form of a question instead of waiting for the probe |
| R5 | "What is the hardest operational problem across the network right now?" | A candid answer here shows whether the role is firefighting or building, and gives you the next case to think through |
| R6 | "Which site would you want me to spend time at first, and why?" | Signals ownership of the scope jump in F1 and lets the interviewer point you at the priority |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or managed operations across four sites, or terminal operations | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material shows one shift and the site's surge plan, in warehouse and distribution work |
| Led a team of 12 supervisors | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors". The number stays 3 |
| Drove on-time performance or cost-per-shipment down | Inflated form of F2 | F2's quote at its own scope: the mis-pick result. A slot asks only what you tracked |
| Built reporting or dashboards in Excel | Inflated form of F4 | F4's quote at its own scope: "solid Excel". The slot asks what you built, with an honest second branch |
| Has used Power BI | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| 7 years of operations leadership | Inflated form of F6 | F6's quote at its own scope: 7 years in warehouse and distribution ops. The limit is the pack's observation: the quote does not say how many were leadership |

## Sources

Provided documents: the job description text and your background, both in your message. No `tuesday-dossier.md` was present.

Searches sent, all refused, so nothing came back:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics terminals strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Every call was refused. Would have moved VAL themes and a values cheat sheet, though that section is dropped anyway because no values-style round is detected |
| 2. Atlas Freight interview process, operations role family | unavailable | Every call was refused. Would have moved the loop and persona weights, which now rest on the Generic archetype |
| 3. Atlas Freight strategy and recent news | unavailable | Every call was refused. Would have moved A5 and the CASE bank, which stay `[generic]` |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative operations manager JD | skipped | The JD text you supplied already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name and title → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their path
- Round type and who you meet first → reweights every bank, and removes the assumed hiring-manager framing
- The full posting and any recruiter guidance on focus areas or something to prepare in advance → more requirements quoted and covered, and a build section if a deliverable was announced
- Permission to run web searches, and consent to a deeper pass of up to 6 more searches and 2 more fetches, several more minutes → Atlas values, loop structure and strategy; A5 and the CASE bank become `[grounded]` or `[inferred]` instead of `[generic]`
- Your own answers to the answer slots, outside a drill → rows F1, F2, F3, F4 and F6 upgrade from discovery or transferability toward `none`, and the guidance around them gets stronger
- Inspectable proof: your green belt certificate (F7), the before-and-after mis-pick data (F2), and any KPI report or scorecard you built or used (F2, F4) → the matching `medium` rows can rise to `high`
- A `tuesday-dossier.md` from job-underwriter → verified evidence, the underwriter's own named objection, and hard guardrails on prohibited claims
