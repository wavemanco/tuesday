Your Stripe prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-3-denied-a2b67175/stripe_product-operations-manager_interview_pack.md`. It has 22 questions across seven interviewer styles, a fit worksheet, six reverse questions, and an upgrade menu.

I built it for a final round with an unknown mix of interviewers, because I only had the company, the role and the round. I had no job description, CV or interviewer names.

- **Research:** Web search was not permitted in this session, so all four searches were refused. Nothing in the pack comes from Stripe's own materials: not its values, its interview process or its strategy. Everything is labeled `[generic]`, and the "Sources" section lists each refused search.
- **Fit worksheet:** The requirements in it are typical of product operations roles, not quotes from your posting. The evidence column is empty for you to fill in.
- **Experience questions:** These are selection scaffolds that end with an honest fallback. I added nothing about your background.
- **Highest-priority prep:** B1, "Which part of this role would you be weakest at on day one?" I picked it because it comes up in nearly every final round, not because of anything in your background.

Say the word and I'll play the hiring manager on B1, one question at a time with follow-ups, and give you feedback afterward. I can also save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to Word.

1. Who are you meeting in the final round, and how many sessions is it? Also, has the recruiter told you about any deliverable, such as a presentation or take-home? The answer reweights the question banks.
2. Can you paste the job description and your CV, or tell me to go on without them? With both, the placeholders become your own evidence.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer(s): not given. Relationship to you: not given. Built on the assumption that this final round holds one or more sessions with an unknown mix of interviewers, so persona weights are blended and flat.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: does what you say you did survive follow-up questions |
| JD | Role-driven: can you do the listed job, including the parts you are weakest at |
| CO | Company and strategy knowledge: how current your homework is |
| CASE | Live problem set in the role, scored on structure and reasoning |

Labels: `[generic]` means a role-family pattern with no claim about Stripe or about you. Nothing in this pack is labeled `[grounded]`, because no document about you or the role was supplied and no research ran. That is the honest cost of a thin input set; the upgrade menu at the end says what converts it.

## Fit snapshot

This is the worksheet variant: no CV, no job description and no recruiter wording were supplied. The requirements below are typical of the product-operations role family and are written as plain prose, not quotes, so they carry no answer slot. Fill the evidence column yourself from your own material before the round.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Runs cross-functional launches or programs from plan to close (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a program you ran, with named teams, a date and an outcome you can state without adding to it. Selection scaffold: pick a launch or program where several teams depended on you, with a named stake and a clear ending; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Builds and runs recurring operating processes, such as reviews, readiness checks and status rhythms (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed, who used it, and how you knew it worked. Selection scaffold: pick a process where you can say what it replaced and how its use was checked; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Uses data to judge product performance and steer decisions (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a figure you can explain end to end: how it was counted, what it is sensitive to, which part was yours. Selection scaffold: pick one number you can defend under two follow-ups; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influences product, engineering, design and go-to-market partners without line authority (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer team that ended with the relationship intact. Selection scaffold: pick a moment you held a position against a peer and the working relationship survived; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritizes and makes progress when scope and ownership are unclear (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a case where you chose what not to do and can say why. Selection scaffold: pick a time with more asks than capacity and a choice you made; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Communicates clearly and concisely to senior leaders (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a written update or review a senior reader acted on. Selection scaffold: pick one such document or meeting you can describe plainly; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

Stripe's actual loop was not established: no loop source was read and no search returned. The weights rest on the Generic archetype from the pack's method (screen, hiring manager, panel, flat weights), not on Stripe's documented process. If your final round is several sessions, per-session weights are in the upgrade menu.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems about launches, adoption and process design | High. Final rounds for an operations role commonly include a hiring manager or skip-level, and that relationship prior favors this persona. Reasoning from a generic prior, not a Stripe fact | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of weakest areas, motivation, why here and why now | High. Same relationship prior as above; derisking is what a final round is for | Rehearse the single most predictable objection until it is boring (B1); candor over bluffing |
| Values/Behavioral | Scenario probes on principles, expecting stories | Medium. Stripe's published values were not retrieved, so the principles themselves are not in this pack | Pick a story per question where your own material carries one; use we for context and I for your part |
| Peer Evaluator | Seam-splitting with adjacent teams, credit, collaboration | Medium. A final loop often includes a prospective peer; unknown here | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober | Asks how each number was counted | Medium. Operations roles lean on metrics, though this is a generic prior | Know how each of your figures was counted and say plainly when you do not know |
| Conversational/Rapport | Friendly openers that are still scored | Medium. Almost every loop opens this way | A pre-scripted 90-second arc for the biography question |
| Pressure | Interrupts, time-boxes, challenges attribution | Low. Fits skip-level or executive sessions; unknown here | Pause, restate, hold through two follow-ups before conceding anything real |

## Question banks

All provenance cells are `[generic]` alone: no question rests on a sentence of yours, because none was supplied. Guidance that touches your experience is a selection scaffold ending in its honest branch.

The pack's highest-ROI prep is **B1**: some version of "where are you weakest" gets asked in nearly every final round, and a rehearsed, non-defensive answer changes the conversation. This is a generic judgement, not derived from your background, since none was given.

### A. Case/Strategist (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product launch is two weeks out and two teams disagree on whether it is ready. What do you need to know first, and how do you run the decision?" | CASE | [generic] | Clarify first: what ready means to each team, what the launch date is tied to, what breaks if it slips. Then name the decision owner, the criteria, and the fallback, and say which premise you would challenge. The question asks about no past, so the guidance makes no claim about yours | Launch readiness is core product-operations territory in the role family (F1, F5). CASE because it is a live problem delivered cold |
| A2 | "Adoption of a feature launched last quarter is 20 percent below plan. Diagnose it." | CASE | [generic] | Structure aloud: confirm the metric and plan basis, split by segment and funnel step, separate awareness from usability from value, then say what you would check first and what would change your mind. Name the assumption you would defend least | Tests the metric-diagnosis habit that F3 depends on. A persona stem, so likely in some form |
| A3 | "A team has no launch process. Sketch the plan to set one up." | CASE | [generic] | Clarify scope and pain, start with the smallest process that fixes the worst failure, state how you would get adoption without authority, and say how you would know it worked after a quarter. No claim about your past | Probes process design and influence together (F2, F4) |
| A4 | "What do you understand about how this company makes money and where it is investing?" | CO | [generic] | Say what you found in the company's own published material and name where you read it. Do not recite from memory or from forum posts. If you have not looked yet, say so plainly and look before the round; the upgrade menu notes that no strategy research ran here | Homework depth at the company's altitude. `[generic]` because the research that would ground it did not run |

### B. Skeptic (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Deepest rehearsal. Name the genuinely thinnest requirement from the posting you hold, before being asked a second time. Say what your material does carry near it, in your own words and at its real scope, then a concrete first-90-days ramp plan. Follow-up levels to rehearse: first, "why is that your weakest"; second, "what if the team needs it in week two"; third, "how will we know you closed it". Hold the plan through two follow-ups, then concede the limit specifically and plainly. If the honest answer is that the area is new to you, say so; that is a limit, not a confession | The one objection every candidate meets in some form (F1 to F6). JD because it scores the stated requirements, including the gaps |
| B2 | "Why product operations, why this company, why now?" | JD | [generic] | Three short beats, each true for you: the work you want more of, what you have actually read about the company, and the timing. If no true reason comes to mind for one of them, say so plainly rather than supplying one | Motivation consistency is what the Skeptic scores; the three-part form is the persona's standard probe |
| B3 | "What would make you decide this role is the wrong fit for you six months in?" | JD | [generic] | Name one real condition you would watch for and what you would do about it first. Candor reads as self-knowledge; a flawless answer reads as rehearsed | Tests honest self-assessment and retention risk |
| B4 | "How would you handle an area of this role where you have less experience than the team expects?" | JD | [generic] | A plan, not a past: who you would ask, what you would read or shadow in week one, what you would deliver to show progress by day thirty, and how you would flag early if it is slipping. Make no claim about work you have not stated | Pairs with B1; the ramp plan is the bridge when evidence is thin (F1 to F6) |

### C. Values/Behavioral (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. Structure it as context, your part, what landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values stem. Stripe's published values were not retrieved, so this is not mapped to any named principle (F6) |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer cost and the metric cost are both statable, and you can say what you chose and what it cost. Use I for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values stem; tests behavior over slogans (F3, F4) |
| C3 | "A team's metric target and what customers are asking for point in opposite directions. How do you decide what to recommend?" | VAL | [generic] | A decision frame, no past: what evidence you would gather from each side, how you would size the trade-off, who decides, and how you would state the recommendation and its risk in one paragraph. The question asks about no history, so none is claimed | Values-flavored hypothetical that needs no story, useful if you lack a clean C2 (F3, F4) |

### D. Peer Evaluator (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know the seam: who owns the decision, who owns the process, how disagreements are escalated. Offer what you would bring to their team, then say you would confirm the actual seam with them | Seam-splitting is the persona's signature probe (F4) |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say your rule in one sentence, then a short true example of it. Use we for context and I for your part. If no example comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing probes attribution honesty (F4) |
| D3 | "What would you need from me in your first month, and what could you give my team?" | JD | [generic] | Reciprocity first: one concrete thing you would offer, then two needs framed as information, not favors | Whether the hire adds to or reduces a peer's load (F4, F5) |

### E. Data-Driven Prober (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a number from your work you are proud of. Walk me through how it was counted." | EXP | [generic] | Selection scaffold: pick a figure you can defend. Say how it was counted, what it is sensitive to, the assumption you would defend least, and exactly which part was yours, in your own words. If you do not know how part of it was counted, say that plainly. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The defend-the-number rehearsal for every headline figure you will bring (F3) |
| E2 | "Tell me about an analysis you did yourself, end to end." | EXP | [generic] | Selection scaffold: pick an analysis where you can state the question, the data, the method and what changed afterward, each in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Probes depth beneath a metrics claim (F3) |
| E3 | "Suppose you introduce a new weekly review across three teams. How would you tell, after a quarter, whether it was working?" | CASE | [generic] | A measurement frame, no past: what outcome the review is for, one leading and one lagging signal, what you would compare against, and what result would make you drop it | Tests whether you define success before building a process (F2, F3) |

### F. Conversational/Rapport (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Script a 90-second arc using only facts from your own history: where you started, the pivot points, why product operations. End on the present role and why this one. Practice it aloud | The most common opener; casual register, still scored |
| F2 | "What drew you to product operations?" | JD | [generic] | One true reason, one specific thing about the work, one line on what you want to do more of. If you cannot name a specific, say so rather than supplying one | Genuine-interest check |
| F3 | "What are you reading, building or testing these days that relates to this work?" | JD | [generic] | Name one real thing and what you took from it. If there is none, say plainly what you would explore first and why | Casual questions about role topics are scored; this one rewards a true answer |

### G. Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then give two criteria from the role you can meet and the evidence for each from your own material. Do not disparage anyone. If pushed, hold through two follow-ups, then concede what you cannot know about the internal candidate | Composure under a time box |
| G2 | "Think of the result you are proudest of. How much of it was actually you?" | EXP | [generic] | Hold-then-concede: state your part in the words you would use under oath, hold it through two follow-ups, then concede specifically what others did. Never fold on the core part to restore harmony. If no result comes to mind, say so plainly | Attribution honesty (F1, F3) |

### Requirement coverage

Role-family requirements only, since no job description was supplied; refresh this table against the real posting.

| Area | Snapshot row | Questions |
|---|---|---|
| Cross-functional launches | F1 | A1, A3, G2 |
| Operating processes | F2 | A3, E3 |
| Data and metrics | F3 | A2, C2, C3, E1, E2, E3 |
| Influence without authority | F4 | C1, C2, C3, D1, D2, D3 |
| Ambiguity and prioritization | F5 | A1, B4, D3 |
| Senior communication | F6 | C1, F1, G1 |
| Motivation and fit | — | B1, B2, B3, F2, F3 |
| Company knowledge | — | A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make someone in this role clearly successful at the six-month mark?" | Moves the conversation to outcomes and shows you are thinking past the offer |
| R2 | "Which part of how product operations works with product and engineering today are you least satisfied with?" | Invites candor and shows you expect to change something, not just run it |
| R3 | "How does the team decide what product operations should not take on?" | Signals you understand scoping is half the job |
| R4 | "What is the hardest cross-team disagreement the team has worked through recently, and how did it resolve?" | Gets a real example and shows how disputes are actually handled |
| R5 | "What did the last person to join this team find most surprising?" | Surfaces onboarding reality and rapport at once |
| R6 | "If you are a peer on the team: what could a new person do in their first month that would genuinely help your work?" | The reciprocity question for a peer interviewer; skip it if you are not meeting a peer |

## Prohibited claims

No entry is listed. No sentence of yours was supplied, so there is no wording to inflate, and you have stated no negative about your background. Every cell above that touches your experience is therefore a selection scaffold ending in its honest branch.

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No candidate material supplied; nothing to inflate and no stated negative | Each experience question is a selection scaffold; say only what you actually did |

## Sources

Provided documents: none. Your message gave the company, the role title and the round.

Searches sent, all refused because web search was not permitted in this session:

- "Stripe values operating principles": refused
- "Stripe interview process Product Operations Manager final round": refused
- "Stripe strategy news 2026": refused
- "Stripe Product Operations Manager job description responsibilities qualifications": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have supplied the published principle names for a values cheat sheet; omitted, since no values-style round is detected without a loop source |
| 2. Stripe interview process, product operations | unavailable | Would have established the loop and set persona weights; the Generic archetype stands in and the pack says so |
| 3. Stripe strategy and recent news | unavailable | Would have grounded A4 and a strategy-based CASE question; both are `[generic]` |
| 4. Interviewer name and Stripe | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the six role-family rows from `[generic]` prose into quoted `[inferred]` requirements |

## Upgrade menu

- The job description text → the six `[generic]` snapshot rows become quoted `[grounded]` requirements, every JD requirement gets a mapped question, and the coverage table becomes exact
- Your CV or background → each fit-snapshot evidence cell fills with your own sentences, the scaffolds become story-mapped answers, and the highest-ROI objection is derived from your actual gaps instead of assumed
- Who you meet and in what order, or the recruiter's prep email → per-session persona weights, plus any pre-declared deliverable gets its own build section; if your final is several sessions, send the schedule
- Interviewer names → an interviewer read, tailored persona weights and a reverse question tied to their path
- Permission to search the web → Stripe's published values (a values cheat sheet if a values round is detected), documented loop structure and current strategy for A4; a deeper pass would add up to 6 more searches and 2 more fetches, several more minutes
- A `tuesday-dossier.md` from an earlier evaluation of this role, if you have one → verified evidence and prohibited claims arrive ready to rehearse
