Writing the pack now.
Switching to Edit calls instead.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-canned-ce16a098/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round with Tobias, since Saltmarsh's careers page puts its single 60-minute interview (the Outage Hour) with the hiring manager. That interview is a live-incident tabletop followed by a values conversation, with no take-home.

The pack has 24 questions across seven interviewer styles, each tied to the quotes from your message. It also has a values sheet for Saltmarsh's three published values, six questions for you to ask Tobias, and a list of claims the pack won't coach.

Start with C1, the in-app-purchases objection. Saltmarsh's September 2026 Project Larkspur announcement moves both titles to a season-pass model, which makes that question likely.

I'll play Tobias on C1 whenever you say. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. **Relationship assumed:** hiring manager. You named him as your interviewer, and Saltmarsh's careers page puts its single 60-minute interview, the Outage Hour, with the hiring manager.
**Format (Saltmarsh's published description):** a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.
**Candidate:** Femi. **Interview:** Friday.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for speaking, not a script. Say only what you actually did, in your own words. Where guidance says "answer slot", it is an instruction for the interview: answer either branch honestly.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour demonstrates Saltmarsh's published values |
| EXP | Whether your experience claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its current direction |
| CASE | Structure and reasoning on a live problem from the role |

Rows labelled `[generic]` are rehearsal patterns. The real tabletop scenario is not published.

## 2. Prep triage

You have two prep days. Do these in order. Everything else is insurance.

1. C1, aloud, until it is boring. It is the highest-ROI prep in this pack. Then C2 and C4.
2. The tabletop: A1, A2 and D1 aloud, twice each. Then read the values sheet (section 7) and rehearse B3.
3. H1, your 90-second arc, once aloud. Play both titles named in the Larkspur announcement (H2).

## 3. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | A length requirement is not a gate. Your quote gives the years and the title, and does not show what kind of title it was. Answer slot: the JD's first requirement makes a probe on what kind of title yours was likely. Say what you can, in your own words. If the question does not fit your title, or the producing was not yours, say so plainly and stay with the four years and the calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but nothing inspected sits behind the line, so expect a probe. Lead with the quote's own terms: you ran the weekly content-drop calendar for the last two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your quote is the main title's content-drop calendar. The requirement is two titles and live events. Your words stay at their scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "two" makes a probe on handling two calendars likely. If you ever ran calendars for more than one title, or planned events as well as drops, say which. If not, say so plainly and stay with the one calendar |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams the calendar was coordinated with. Answer slot: if you worked with any of those four teams on a drop, say which and what you coordinated, in your own words. If you did not, or it was not yours, say so plainly and stay with the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your quote is presenting monthly retention numbers, which is adjacent to a post-event review and does not reach it. Words at their scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's review line makes a probe on whether events were reviewed afterwards likely. If you did, say what you looked at and what came of it. If there was no such step, or it was not yours, say so plainly and stay with the monthly numbers |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms: you wrote the checklist, and QA still uses it. Your material says wrote, not managed each release, so keep the verb. Expect a probe on how the checklist is used day to day |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement: you presented the retention numbers monthly, to the studio head. Your material does not say which retention measures they were, so expect that probe |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | A written document that a team still uses is your evidence here. Reword only that quote: "I wrote the release checklist our QA team still uses." Add nothing about its quality |

## 4. Reading the interviewer

Public professional footprint only. The talk page came from a search snippet and was not fetched in full.

| Public fact | Source | What it means for you | Mirror opportunity |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | Search snippet, talks.gdconf.example | The release checklist is native ground for him. Lead with it, at the quote's scope | F6: "Wrote the release checklist our QA team still uses." This is shared vocabulary, not a shared career jump, so it is not offered as one |
| GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | Search snippet, talks.gdconf.example | The theme matches the published value "Ship the Patch Not the Promise". Expect precision probes on what you did versus what you say, so keep every claim at its quoted scope | none |
| Saltmarsh's published interview format puts the tabletop first and the values conversation second | careers/interviewing | Spend your first-minute energy on the tabletop structure. The values conversation follows | none |

## 5. Persona table

| Persona | How it shows up here | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | The simulated-outage tabletop | High | Hiring-manager prior, and the careers page makes the tabletop the first half of the hour | Clarify, then objective, then who needs to hear what, then metrics and risks. Think aloud. Challenge one premise politely |
| Skeptic | Probes on your stated gaps and the two-titles scope | High | Hiring-manager prior is derisking gaps, and you have named two gaps yourself (P1, P2) | Rehearse the single predictable objection (C1) until it is boring. Bridge only from quoted evidence, with the limit named |
| Values/Behavioral | The second half of the hour | High | The careers page documents a values conversation, so it is guaranteed in this session | One story or scaffold per published value. "We" for context, "I" for what you did |
| Pressure | Time-boxed or interrupted answers in the tabletop | Medium | An inference from a simulated outage. The careers page does not say the interviewer interrupts | Pause, restate, anchor in what you said, hold through two follow-ups, then concede only what is true |
| Data-Driven Prober | Your retention numbers and the checklist | Medium | His published talk is about announcements matching what shipped, so expect verification probes | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| Conversational | The opening biography question | Low | An opener, not a scored round of its own | A 90-second arc built only from your quotes (H1) |
| Peer Evaluator | Seam questions about QA and other teams | Low | He is the hiring manager, so this arrives as collegial packaging | Propose seam principles instead of pretending to know the seam |

## 6. Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a live event. Players report the event reward is not granting, and engineering says a fix is two hours out. First fifteen minutes: what do you do?" | CASE | [generic] | Clarify first: what is broken, who is affected, whether it is spreading. Set the objective: protect players while engineering works. Then who hears what, in what order; the JD names design, art, engineering and community. Then what you will and will not promise; the values sheet's second row applies. Think aloud and challenge one premise, such as whether the event should pause | The first half of the Outage Hour is a live-incident tabletop, and this is the pattern for it. It tests the JD's coordination requirement (F4) in a live form. The real scenario is unpublished, hence `[generic]` |
| A2 | "Write the first player-facing message for that outage. What does it say, and what does it deliberately not say?" | CASE | [generic] | Say what is known, who is affected and when the next update comes. Leave out any fix time nobody has committed to. Read your draft aloud for one claim you could not stand behind | Written communication under pressure (F8's requirement), set inside the tabletop. Generic because it asks for no claim about your past |
| A3 | "Two titles each have an event ending the same weekend, and engineering can support only one release. How do you decide?" | CASE | [inferred] | Derived from the JD's two-titles line. Clarify the constraint, the player impact on each title and what slips for each. Decide with a stated principle, then say what you would tell the other title's players. The values sheet's first row is the published principle for when the calendar and players disagree | The JD asks for two calendars (F3). The scenario is derived from that line, so it is `[inferred]` |
| A4 | "An event ends. Retention for the players who joined during it looks flat against a normal week. What do you look at first, and what do you report?" | CASE | [generic] | Clarify the comparison, the cohort and the time window. State two hypotheses. Say which numbers you would report and what you would refuse to claim from them | Tests the post-event review and KPI requirement (F5) and the retention requirement (F7) in a live form |
| A5 | "Project Larkspur puts two titles on one shared events calendar from February 2027. What would you want to know before planning the first shared calendar?" | CO | [grounded] | Ask about the shared calendar's owner, how titles' events are prioritised against each other, and what the single live-ops group changes about who you coordinate with. These are questions to ask, not claims about Saltmarsh. Think aloud | The announcement is current strategy from Saltmarsh's own news page. CO tag, CASE delivery. It rewards candidates who read it |

### B. Values/Behavioral (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. Your quote carries the calendar and does not carry a disagreement. Pick a time a planned drop and what players needed pulled apart. It needs the plan, the player signal, what you did and what happened to the plan. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the calendar you ran, or how you would handle it | Players Before Plans, from Saltmarsh's published values. The quote is the nearest material (F2) |
| B2 | "Tell me about a time you held back an announcement until the work was actually built." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold. Pick a time the announcement and the build were not in step. It needs what was promised or about to be, what you did, and what it cost you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the checklist you wrote, or how you would handle it | Ship the Patch Not the Promise, and the theme of the interviewer's talk. F6 is the nearest material |
| B3 | "Tell me about a time a release left the checklist better than it found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F6: you wrote the checklist, and QA still uses it. Tell those beats in your own words. Answer slot: the value makes a probe on whether the checklist was improved after a release likely. If you changed it after a release, say what and why. If it was not changed, or not by you, say so plainly and stay with the checklist you wrote | Leave the Build Greener is the one value your quotes carry. Strongest values answer in this pack |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold. Your quote carries presenting numbers to leadership and does not show an unpopular truth. Pick a time the numbers were unwelcome. It needs what you said, how it was received and an intact relationship afterwards. If no such time comes to mind, say so plainly rather than supplying an ending, then give the nearest thing your material does carry, or how you would handle it | The standard Values persona stem, tied to F7 |

### C. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never worked on a game with in-app purchases. What changes for you on day one?" | EXP | [grounded] "never worked on a game with in-app purchases" | **Highest-ROI prep in this pack.** Say it first, in these words: "I've never worked on a game with in-app purchases." Then give a plan in the future tense: what you would learn first, who you would ask and by when. You choose those; the pack does not. Name the nearest thing your material carries at its own scope, presenting the monthly retention numbers, and do not say it covers more. Follow-ups to rehearse: "Both titles are moving to a season pass from February 2027, so how do you ramp?" Then: "What would you not touch until you had learned it?" Hold by returning to the acknowledgment and the plan | P1 is a gap you stated. Saltmarsh's September 2026 announcement moves two titles to a season-pass model, so this objection is likely in some form. EXP because it tests honest self-assessment |
| C2 | "The role asks for three-plus years producing live-service games or apps. How does your four years map to that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Say the four years and the title as they are. Answer slot: say what kind of title yours was, in your own words. If the question does not fit it, or the producing was not yours, say so plainly and stay with the four years and the calendar you ran. Do not restate the title as a different one | F1 is the first requirement and an unresolved discovery row. JD because it scores the stated qualification |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [inferred] derived from the evidence cells of F3, F4 and F5 | Pick the one that is truly weakest by your own account. The rows where your material is thinner are F3 (two titles), F4 (coordinating teams) and F5 (the post-event review). Say why, then what you would do in your first month. Your choice, in your own words | Standard Skeptic stem. The derivation is the pack's reading of where the evidence is thinnest |
| C4 | "You ran the weekly content-drop calendar for your main title. This role runs calendars for two of ours. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote at its scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you ever ran calendars for more than one title, say which. If not, say so plainly and stay with the one calendar. Then say, as a plan, what you would need to learn about running two | F3 is the transferability gap and F2 the supporting row. JD because it scores the requirements to run a content calendar and two titles |
| C5 | "What draws you to live operations at Saltmarsh specifically?" | CO | [grounded] | Pick one specific thing you read and say, in your own words, why it matters to you: the Players Before Plans line on the values page, or the Larkspur announcement. Do not claim a reason you do not hold | Motivation consistency is the Skeptic's score. CO tag: it rewards candidates who read Saltmarsh's own pages |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Engineering says two hours. Community wants a post now. Sixty seconds: what do you tell them?" | CASE | [generic] | Pause, restate, then answer in order: what is known, what is not, what you will not promise, when the next update comes. If interrupted, hold your structure through two follow-ups before conceding anything real | Time-boxed pressure inside the tabletop. Generic because it asks for no claim about your past |
| D2 | "That release checklist you wrote: how much of what QA uses now is actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold only what the quote carries: "I wrote the release checklist our QA team still uses." Answer slot: if others changed it since, say what part is still yours, in your own words. If someone else wrote the version QA uses now, say so plainly and stay with what you wrote. Hold through two follow-ups, then concede only a specific, true uncertainty | F6 is the strongest evidence in your material and so the likeliest attribution probe |
| D3 | "Sixty seconds: why you over someone who has run live events on two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Restate the question, then anchor on the three quotes at their own scope, one sentence each. Do not describe them as proof of anything. Hold through two follow-ups. Concede specifically: "I've never worked on a game with in-app purchases." For the two-titles gap, answer slot: if you ran more than one title's calendar, say so. If not, say so plainly and stay with the one calendar | The comparison is exactly where F3 is thinnest. P1 gives the one plain acknowledgment the concession can use |

### E. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You presented the monthly retention numbers to the studio head. Which numbers were those?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented, in the quote's words. Answer slot: the JD's retention line makes a probe on which retention measures you worked with likely. If you chose or calculated any, say which and how they were counted, including the assumption you would defend least. If the figures were handed to you, or you do not know how they were counted, say so plainly and stay with presenting them | F7 is the retention evidence. A prober checks it to the assumptions, so the honest limit is rehearsed in advance |
| E2 | "A week after an event ends, how do you decide whether it worked?" | JD | [generic] | State the objective of the event first. Name the measures you would use and why, say what would change your mind, and say what you would refuse to claim from the data | Covers the post-event review and the KPIs it reports (F5), and retention comfort (F7), as a method and not a past |
| E3 | "Tell me about a document you wrote that other people relied on." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F6 and F8, with only the beats the quote states: you wrote it, and QA still uses it. Tell them in your own words. Detail beyond that, such as what was wrong before or who reviewed it, is not in your material, so add only what you can stand behind | Tests the JD's written-communication requirement (F8) with the strongest quote you have |

### H. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc made only of your four quotes, in that order, each at its own scope. Close with why live operations at Saltmarsh, in your own words. Do not add a motive or a moment your quotes do not carry | The opener is scored even when it feels casual. Built from F1, F2, F6 and F7 |
| H2 | "What are you playing at the moment, and what is live in it that you would borrow?" | CO | [grounded] | Selection scaffold. Saltmarsh's announcement names Tidepool Tactics and Lantern Row; the JD does not name its two titles, so do not assume they match. Play both before Friday and pick one live feature you can describe specifically. If you have not played them, say so plainly and name what you would look at first | A rapport question about the product. It rewards a candidate who has touched the games |

### G. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Producer and QA sit side by side on a release. Where is the seam, and what happens when we disagree?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Propose seam principles instead of claiming to know the seam. Selection scaffold for the story: pick a time you and a QA colleague disagreed. It needs the disagreement, what you did, and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the checklist you wrote, or how you would handle it | The JD's release-checklist line (F6) means the QA seam is the likeliest peer topic |
| G2 | "How do you handle credit when work spans design, art, engineering and community?" | JD | [generic] | Selection scaffold. Pick a time work crossed teams and credit mattered. It needs what was shared and how you named it. If no such time comes to mind, say so plainly, then say how you would handle it | F4's requirement is the coordination line. Your material does not show it, so this stays a scaffold |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | C4, A3 |
| coordinate design, art, engineering and community teams on each update | G2, A1 |
| own the post-event review and the KPIs it reports | E2, A4 |
| manage the release checklist with QA | G1, D2 |
| 3+ years producing live-service games or apps | C2 |
| experience running a content calendar | C4, B1 |
| comfortable with player-retention metrics | E1, E2 |
| clear written communication | E3, A2 |

## 7. Values sheet

Saltmarsh's careers page documents a values conversation, and the values page names three values.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold, F2: your quote carries the calendar and no disagreement. Pick a time a drop and player needs pulled apart: the plan, the signal, your action, what happened to the plan. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the calendar you ran, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold, F6: pick a time an announcement and a build were not in step. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the checklist you wrote: "Wrote the release checklist our QA team still uses." |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F6: "Wrote the release checklist our QA team still uses." Beats the quote states: you wrote it, QA still uses it. See B3's answer slot for the one probe to prepare |

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Project Larkspur describes one shared events calendar from February 2027. How does this role's calendar work sit inside that, and are the two titles in the JD the same two?" | Shows you read the announcement, and surfaces what the JD does not say |
| R2 | "In your GDC talk you argued a live team is judged by how often its patch notes describe what actually shipped. Where does the producer's release checklist sit in that, and did your QA background shape how you built yours?" | Tied to his own public path and argument. It converts an interrogation into a peer conversation |
| R3 | "What does a good first 90 days look like for someone who has run a content calendar but has not worked on a game with a season pass?" | Puts your one stated gap on the table calmly. The acknowledgment is your own stated negative |
| R4 | "How does the post-event review get used: who reads it, and what has it changed?" | Shows you treat the review as something the role owns, not a report |
| R5 | "How is the release checklist split between the producer and QA today, and who owns changes to it?" | Echoes Leave the Build Greener and uses ground you share with him |
| R6 | "What have the strongest people you have hired into live operations done in their first month?" | Asks him to describe the bar, which gives you something to aim at |

## 9. Prohibited claims

| # | Not coached | Basis | Honest form |
|---|---|---|---|
| P1 | Has worked on a game with in-app purchases | Negative you stated: "never worked on a game with in-app purchases" — your message | The plain acknowledgment: "I've never worked on a game with in-app purchases." Then a plan, never a past. No slot. C1 rehearses it |
| P2 | Has led a team | Negative you stated: "Never led a team" — your message | The plain acknowledgment: "I've never led a team." The JD's line is "coordinate design, art, engineering and community teams on each update", not people management. No slot |
| P3 | Ran live events across two titles | Inflated form of F3 | F3's quote at its own scope. Your material says one title's content-drop calendar, not two titles or live events. C4's slot stays inside the one calendar |
| P4 | Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope. Your material says presenting the monthly retention numbers, not owning a review |
| P5 | Managed releases with QA | Inflated form of F6 | F6's quote at its own scope. Your material says you wrote the checklist QA still uses |
| P6 | Produced a live-service title for four years | Inflated form of F1 | F1's quote at its own scope: "4 years as an associate producer at a puzzle-game studio". Your material shows the title and the years, nothing wider |

## 10. Sources

**Provided documents:** the job description pasted in your message, and your background as you wrote it in the same message. No `tuesday-dossier.md` was present.

**Searches and fetches sent:**

| Query or URL | Returned |
|---|---|
| Search: "Saltmarsh Games values" | https://saltmarshgames.com/values |
| Search: "Saltmarsh Games interview process live operations producer" | https://saltmarshgames.com/careers/interviewing |
| Search: "Saltmarsh Games strategy mobile titles news" | https://saltmarshgames.com/news/project-larkspur (search snippet only, not fetched) |
| Search: "Tobias Wrenfield Saltmarsh Games Head of Live Operations" | https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only, not fetched) |
| Fetch: https://saltmarshgames.com/values | Page text: the three values and their definitions |
| Fetch: https://saltmarshgames.com/careers/interviewing | Page text: the Outage Hour format |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Values sheet (section 7): the three values by official name; B1 to B4 |
| 2. `{company} interview process {role family}` | yes | Loop structure: one 60-minute session, tabletop then values conversation; persona weights and the no-take-home call follow from it |
| 3. `{company} strategy` / recent news | yes | A5, C1's follow-up, F2, R1: the September 2026 Larkspur announcement (snippet only) |
| 4. `{interviewer name} {company}` | yes | Reading the interviewer (section 4) and R2: his role, his earlier QA role and the talk's argument (snippet only) |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- Your CV, or the bullets as written → exact quotes replace my reading of your message, and several `discovery` rows can close
- Your answers to the slots in F1, F3, F4 and F5 (what kind of title yours was, whether you ever ran more than one calendar, which teams you coordinated, whether events were reviewed afterwards) → those four rows get quoted evidence, and the guidance cells that lean on them stop being slots
- Any note from the recruiter about the Outage Hour, such as the kind of scenario → the tabletop bank (A1, A2, D1) stops being `[generic]`
- Confirmation that Tobias is the hiring manager for this role, and whether anyone else joins → persona weights are recomputed
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Saltmarsh's strategy, the talk page read in full instead of from a snippet, and recent organisation context around Larkspur
- A `tuesday-dossier.md` from the job-underwriter, if you have one → verified evidence and prohibited claims arrive pre-graded; the pack above does not need it
