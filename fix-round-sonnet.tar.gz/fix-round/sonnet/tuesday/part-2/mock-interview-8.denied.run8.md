Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-denied-fee6b950/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It has one mini-pack for each of the three rounds on 20 November (28 questions in all), with persona weights and reverse questions per round.

- **Highest-ROI prep:** D1, the Round 2 question about the contact centre. You told me you've never worked in one, and the JD names it, so that objection will come up in some form. The pack rehearses the plain acknowledgment, then one first step you'd really take, held through two follow-ups. D2 does the same for "never presented above regional level".
- **The values cheat sheet has no mapped stories.** None of your four sentences carries a story for any of the four values, so Round 3 values questions G1 to G4 are selection scaffolds. They each end with the honest "if none comes to mind, say so plainly". Writing one real story per value before the 20th is the most useful thing you can do.
- **The case and the strategy brief.** H1 is a practice version of the 20-minute escalation case, not a prediction of the real one. Your brief lines (digital, the move to hubs) feed the strategy questions E1, E2, H3 and J2, including how the hub move meets "Neighbours, Not Numbers" in front of branch managers.
- **Research:** I ran no searches. Your pasted values, the recruiter's email, the JD and the brief lines fixed everything the searches would have fed.

Say the word and I'll play the Skeptic on D1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 20 November 2026 (loop mode, one mini-pack per round)

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1 | The recruiter (unnamed) | 30 min | Recruiter screen |
| 2 | Head of Member Services (unnamed) | 45 min, mostly behavioural | Would be your manager |
| 3 | Panel of two branch managers (unnamed) | 60 min, including a 20-minute complaint-escalation case | Panel, and the values round: scored against the four published values |

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behavioural: does past behaviour show a published Ashgrove value |
| EXP | Work-experience deep-dive: does what you said survive follow-up |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

Guidance is scaffolding, not a script. Everything this pack says about your past rests on four sentences from your message, quoted in the fit snapshot, because no CV was supplied. Where those sentences do not reach a question, the guidance is an answer slot or a selection scaffold. An answer slot is an instruction for the interview: it asks for no reply here, and it always lets the honest answer be "that was not mine" or "that did not exist". Labels: `[grounded]` traces to something you or Ashgrove supplied, `[inferred]` is a named derivation, `[generic]` is a role-family pattern with no claim about you or Ashgrove.

## Prep triage

Nine days. The few things done well, in order:

1. 11 to 14 Nov: write your own answers where only you hold the facts: what the monthly spreadsheet counted and what tool it was in (A3), which rules the formal log sat under (A5), anyone you coached beyond new tellers (C1), any work with a digital team (C4), and one real story per value (G1 to G4). The pack cannot supply these.
2. 15 to 17 Nov: say D1 and D2 aloud until both concessions are boring: the plain acknowledgment, then one first step.
3. 18 to 19 Nov: run H1 aloud against a 20-minute timer, then A1's 90-second arc.
4. 20 Nov: pick two reverse questions per round.

Everything else is insurance.

## Fit snapshot

Shared by all three rounds. No row is a gate: the JD's requirements are experience and skills, not terms such as a licence.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log, not the process end to end, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any part of that was yours, say which and what you did, in your own words; if the log was where your part ended, or the step was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing from branch work is offered as contact-centre experience |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence says you built a monthly complaints spreadsheet your regional manager uses; it does not say what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet counted. If it counted either, say how each was counted and the assumption you would defend least, in your own words; if it counted something else, or neither, say so plainly and stay with the sheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Training new tellers on an escalation script is adjacent to coaching supervisors, and the words stay at tellers: "I trained new tellers on our escalation script." Answer slot: if you coached anyone more senior than new tellers on escalations, say who and what you did; if you did not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | The material is silent, so the words are a slot. Answer slot: the JD's digital-teams line makes a probe likely. If you have worked with any digital or self-service change, say what and what your part was; if you have not, say so plainly, and say what you would ask a digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The quote already speaks to the requirement in other terms, and the words stay in your terms: "I spent six years in retail banking, the last three as a branch supervisor." Answer slot: if asked whether that fits the JD's customer-operations phrase, say what your roles covered; if part of that was not yours, say so plainly and return to the branch roles |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Derived from "formal" in your sentence and "regulated" in the JD; formal is not regulated, so the bridge does not stretch it. Answer slot: the JD asks for regulated complaints, so expect a probe on the rules the log sat under. If you know which, say so and what your part was; if it was an internal procedure, or you do not know which rules applied, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Your sentence says nothing about presenting at regional level, so nothing is claimed there either |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Derived from "spreadsheet" in your sentence and "Excel" in the JD; the sentence does not name the tool. Answer slot: if it was built in Excel, say what you did in it, in your own words; if it was another tool, or the Excel work was not yours, say so plainly and say what you do know |

---

# Round 1: Recruiter screen (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured: the biography, motivation, what you know about them | High: the recruiter-screen prior is Conversational plus a light Skeptic, and the recruiter's email gives no focus areas to shift it | A pre-scripted 90-second arc; treat casual questions as scored; arrive with reverse questions |
| Skeptic (light) | Polite checks on the two gaps you stated | Medium: the same prior, and F2 and F8 are the gaps in your own words | Say the plain acknowledgment once, add one first step, move on; do not bluff a competency |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey from retail banking to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F6, F1 and F3, three beats, each as its quote states it: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. Tell them in your own words in about 90 seconds and end on why this role, a reason only you can give, so none is written here. Answer slot: if asked what handled covered, say what your part was; if a stage was not yours, say so plainly and return to the log | The opening biography question in a screen is near-certain; F6, F1 and F3 are the rows it draws on. EXP because it tests whether your story holds in a short arc |
| A2 | "What do you know about Ashgrove, and what made you apply?" | CO | [grounded] | Use one published value by its exact name (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix) and one line of the July 2026 strategy brief (40% of member service digital by 2028; eight branches into five hubs over 2027; small-business lending in Q1 2027; app-only banks as the main competitive pressure), and say why that pairing matters to a complaints role. One value and one line with a reason beats reciting all eight. Why you applied is yours; none is supplied | A screen tests homework; the value names and brief lines come from what you pasted and sent, and the question makes no claim about your past |
| A3 | "Walk me through the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3: you built it, it is monthly, your regional manager uses it. Answer slot: the JD names volumes, resolution times and Excel, so expect probes on each. If it counted volumes or resolution times, say how each was counted, what it depends on, the assumption you would defend least, and which part was yours; if it counted something else, or neither, say so plainly and stay with what it did count. Say which tool it was built in, whatever the answer | F3 and F9 are where the JD's reporting and Excel requirements meet your material, and the probe is on counting. JD because it scores two listed requirements, delivered as an experience walk-through |
| A4 | "We ask for four-plus years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it in your terms: "I spent six years in retail banking, the last three as a branch supervisor." Answer slot: if asked what that included, describe what your roles covered in your own words rather than adopting the posting's label for them; if part of customer operations was not in your roles, say so plainly and return to the branch roles | F6 is the requirement easiest to check against dates, so a short precise answer is the rehearsal |
| A5 | "The role involves regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say it at its scope: "I handled the branch's formal complaints log." Answer slot: if the log was kept under external rules or a set procedure, say which and what your part was, in your own words; if it was an internal procedure, or you do not know which rules applied, say so plainly and stay with the log | F7 is the requirement your sentence touches without reaching; asked here because the screen is where a hard requirement is confirmed |
| B1 | "You haven't worked in a contact centre. How would you come into that part of the role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain words first: "I haven't worked in a contact centre." Then one first step you would really take, as a plan, in your own words. If asked what carries over, offer only the branch work at its scope: "I handled the branch's formal complaints log." The full-depth rehearsal is D1 | F2 is the stated gap against the JD's channel scope; this is the light version a screen asks. Skeptic delivery, JD content |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose from what you have already told me: "I haven't worked in a contact centre." or "I haven't presented to anyone above regional level." Name one plainly, then one first step as a plan. Pick the one you can speak to best | Stock Skeptic stem; F2 and F8 are the honest candidates, and naming one yourself keeps the answer in your hands |
| B3 | "You've handled complaints at branch level; this role is the whole member base, end to end. What changes?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | Hold at the quote: "I handled the branch's formal complaints log." Answer slot: if the spreadsheet or anything else you did reached beyond your own branch, say which branches' complaints it covered and what your part was; if everything was your branch's, say so plainly and say what you would find out first about the wider process | F1 is the end-to-end requirement; the scale probe is how a screen tests it. Skeptic delivery, JD content |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Is there anything I should read before the panel's case, and does it use a real complaint pattern or a made-up one?" | Only the recruiter can answer it, and it shows you are preparing for the case |
| 2 | "Which complaint rules does the role work under, and what would you expect me to know on day one?" | Opens F7 directly instead of leaving it to a probe |
| 3 | "How is complaint handling in the contact centre set up today?" | Shows you are taking the contact-centre scope seriously rather than skirting it |
| 4 | "What would the Head of Member Services want fixed by the end of year one?" | Turns the next round's priorities into something you can aim at |
| 5 | "Who would I work with most day to day?" | A practical close that keeps the conversation going |

---

# Round 2: Head of Member Services (45 minutes, would be your manager)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes: coaching, owning a problem, telling leaders something unwelcome | High: the recruiter's email says this round is mostly behavioural, which lifts it above the hiring-manager prior of Case plus Skeptic | Story where one of your sentences carries it, selection scaffold where none does; we for context, I for your part |
| Skeptic | Quiet, persistent probing of the gaps, from someone who would own them with you | High: the hiring-manager prior, and F2 and F8 are stated gaps in your own words | Rehearse the contact-centre objection until it is boring; plain acknowledgment, then a plan, never a stretched bridge |
| Case/Strategist | A live problem from the real roadmap | Low: the hiring-manager prior, adjusted down because the email says mostly behavioural; the strategy brief still makes a short case plausible | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role coaches branch supervisors on escalations. Tell me about a time you helped someone handle an escalation better." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4, two beats the sentence states: you trained new tellers, on your branch's escalation script. Tell it in your own words. Answer slot: the JD asks about coaching supervisors, not tellers, so expect a probe on who you coached beyond new tellers. If you coached anyone more senior, say who and what you did; if the training was for new tellers only, say so plainly and stay with it | F4 is adjacent, not direct, so this is where the manager tests the distance. JD content, behavioural delivery |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | No sentence of yours carries this story, so this is a scaffold: pick a time with a named stake, a message the listener did not want, a moment you did not soften it, and a working relationship still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries at its own scope: you built a monthly spreadsheet your regional manager uses. Whether it ever carried unwelcome news is yours to say or leave out | Persona stem for the behavioural round; F3 and F8 are the rows that touch reporting upward. VAL because it scores behaviour, not a listed requirement |
| C3 | "Walk me through the escalation script you trained new tellers on." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: you trained new tellers on the script your branch used. Answer slot: if you wrote or changed any of it, say which parts and how you decided; if it was handed to you, or you only taught it, say so plainly and describe how you taught it. Do not describe the script's contents beyond what you can recall | The script is the one piece of coaching material your sentence names, so the probe goes through it. F1 and F4 are the rows it draws on |
| C4 | "Tell me about a time you worked with a team outside your branch to fix something for members." | JD | [grounded] | Nothing in your material speaks to this, so this is a scaffold: pick a time another team had to change something before a member's problem could be solved; you need who, what you asked for, what changed, and what members then saw. If no such time comes to mind, say so plainly, then say how you would approach working with a digital team on a self-service journey, as a plan | F5 is silent in your material and the JD names digital teams. The theme comes from the JD line, not from any claim about you |
| D1 | "You haven't worked in a contact centre, and this role owns complaints there too. Why should I be comfortable?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. The limit, as the pack's observation: your material carries branch complaints and an escalation script, nothing from a phone channel. Opening: "I haven't worked in a contact centre." First follow-up, what carries over: say only what you can name and stand behind. Answer slot: if something specific from your branch work carries over to a phone channel, say what and why in your own words; if you cannot say yet, say so plainly and say what you would learn first and from whom. Second follow-up, who you would ask first: a first step you would really take, as a plan. Hold by returning to "I haven't done it; here is how I would get there", never by adding to the branch work | F2 is the widest stated gap against the JD's lead responsibility, so this objection arrives in some form from a manager who would carry the gap too. JD content, Skeptic delivery |
| D2 | "The role reports monthly and the posting asks for confidence presenting to senior leaders. You haven't presented above regional level. Where does that leave us?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I built the monthly complaints spreadsheet our regional manager uses." | Plain words first: "I haven't presented to anyone above regional level." Answer slot: if you took anyone through the spreadsheet, say who and how it went; if it was only sent, or no one was taken through it, say so plainly. Then how you would prepare for a first senior-leader presentation, as a plan in your own words, and hold there through two follow-ups | F8 is the second stated gap and a listed requirement. Using the spreadsheet quote lets the answer stay at what you built without claiming you presented it |
| D3 | "You've spent the last three years as a branch supervisor. Why this move, and why now?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Your reasons are yours and none are written here; keep them consistent with how A1 ended. Answer slot: name one thing this role offers that your present one does not, in your own words; if you cannot yet, say so plainly and say what you want to find out in the loop | Motivation consistency is what the Skeptic cross-checks against A1; F6 is the row. JD because it tests fit with the role as posted |
| E1 | "Ashgrove wants 40% of member service on digital channels by 2028. Sketch how complaints should work in those channels. What do you need to know first?" | CASE | [grounded] | Clarify first: which complaint types are in scope for self-service, what happens when a digital attempt fails, and who has hold of the complaint then (Own the Fix: whoever finds the problem keeps hold of it until it is solved). Then objective, segmentation by complaint type, approach, the two metrics the JD names (volumes, resolution times), risks. Use Plain Words as a design test: a journey that needs explaining twice was written wrong. Challenge one premise respectfully, such as what 40% of service counts. The question needs no claim about your past, so the guidance makes none | The brief's digital line and the JD's self-service line meet here; F5 is the requirement it serves. Case delivery because it asks for structure, not history |
| E2 | "Eight branches become five hubs over 2027. What should happen to complaint handling during that change?" | CASE | [grounded] | Clarify: which members and open complaints touch the branches that move. Objective: no complaint loses its owner mid-move (Own the Fix). Segment by complaint stage, approach, metrics (volumes, resolution times), risks, including the town-level cost the Neighbours, Not Numbers value points at. No claim about your past is made or needed | The brief's consolidation line is the live roadmap item most likely to touch a complaints role; F1 is the end-to-end requirement it presses on |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Where do complaints get stuck today between branches and the contact centre?" | Shows you are thinking about hand-offs, which is where the Own the Fix value bites |
| 2 | "What would you want to see in the monthly report by day 90?" | Aims your first deliverable at your manager's own measure |
| 3 | "Which part of this role would you coach me hardest on?" | Owns F2 and F8 openly and invites the coaching, so it reads as self-awareness |
| 4 | "How do you expect complaint handling to change as 40% of service moves to digital?" | Ties your question to the brief and to the self-service line in the JD |
| 5 | "How will complaint ownership work as eight branches become five hubs?" | Takes the consolidation seriously and signals you have read the brief |

---

# Round 3: Panel of two branch managers (60 minutes, the values round, with a 20-minute case)

## Persona table

Persona assignments per panel member are not possible: no names or profiles exist. Weights blend the round's description.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes keyed to the four published values | High: the recruiter's email says the panel is the values round and scores against the four values | One story per value where a sentence of yours carries one, a scaffold with its honest branch where none does |
| Case/Strategist | The 20-minute complaint-escalation case | High: 20 of the 60 minutes is a case, per the email | Clarify, objective, approach, metrics, risks; think aloud; let the values show in the structure, not in recitation |
| Conversational | Warm, unstructured openers and closers | Medium: the prior for a cross-functional values round pairs Values with Conversational | Pre-scripted arc; treat casual questions as scored; no generic answer to the reverse-question slot |
| Peer Evaluator | Seam questions: where the role stops and the branches start | Low: my reading, not the email's; the email says only two branch managers, and the JD has the role coaching branch supervisors | Propose seam principles instead of claiming to know the seam; show what you bring them, not only what you need |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Members First, Always. No sentence of yours carries this story, so this is a scaffold: pick a time a decision turned on what was right for the member rather than for the branch, the process or a target; you need the decision, who would have decided differently, what you did, and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, at its own scope: you handled the branch's formal complaints log | The first of four value questions the panel scores; the theme is the value's own wording. F1 is the nearest row |
| G2 | "Tell me about a time something you said or wrote had to be explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Plain Words. A scaffold: pick a time someone asked you to explain again, whether a member, a new teller or a colleague; you need what was unclear, what you changed, and how you knew it landed. If none comes to mind, say so plainly, then give the nearest thing your material carries: you trained new tellers on your branch's escalation script. Whether the script read plainly is not in your material | Plain Words turns on the value's own test, explained twice. F4 is the nearest row, and the guidance claims nothing about how the script read |
| G3 | "Tell me about a time you weighed what a decision meant for your branch's town, not only its numbers." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Value: Neighbours, Not Numbers. A scaffold: pick a decision where the numbers pointed one way and the branch's place in its town the other; you need the numbers, the local cost or benefit, and what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries: six years in retail banking, the last three as a branch supervisor. The sentence says branch work, nothing about the town | The panel is two branch managers, so this value is the one most likely to be listened to closely. F6 is the nearest row |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Own the Fix. A scaffold: pick a problem that landed with you, where you kept hold through a hand-off or a delay; you need what the problem was, what you did until it was solved, and how you knew it was. If none comes to mind, say so plainly, then give the nearest thing your material carries: you handled the branch's formal complaints log. Whether any problem in it was kept to a solution is yours to say | Own the Fix is the value closest to the JD's end-to-end ownership line, so F1 is the nearest row |
| H1 | "A member complained in branch, was passed to the contact centre, and has now written to say each of you told them something different. Take us through what you do." | CASE | [generic] | Practice version of the 20-minute case; the real one will differ. Clarify first: what the log shows, what the member was told, by whom and when, what they are asking for, and whether any deadlines or an external route apply under the rules you know. Objective: one answer, from one named owner (Own the Fix). Approach: today, this week; write back in plain words (Plain Words); what you tell the branch manager (Members First, Always). Metrics: volumes and resolution times. Risk: the member having to explain twice. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The recruiter's email puts a 20-minute escalation case in this round; this is a pattern for it, not a prediction of its content. F1 and F2 are the JD scope it exercises. `[generic]` because it is a role-family problem |
| H2 | "A supervisor in one of our branches escalates almost everything. How do you coach them?" | CASE | [generic] | Clarify what everything means: which complaint types, how often, what happened to them. Objective: the supervisor handles what they can and escalates what they should. Approach: go through cases together, agree a line, check back; ask the branch manager what they have seen. Metrics: escalation volumes and resolution times. Risk: undermining the supervisor in front of the branch. No claim about your past is made | The JD's coaching line set as a live problem, put to the people whose supervisors would be coached. F4 is the requirement; `[generic]` because it is a pattern |
| H3 | "A member in a town whose branch is moving into a hub writes to complain. How do you handle the complaint, and what do you tell the branch manager?" | CASE | [grounded] | Clarify: what the member is complaining about, which part is the change and which is how it was handled. Objective: the member hears one plain answer and knows who holds it (Plain Words, Own the Fix). Approach, then what you tell the branch manager: what you know, what you do not, and what you will report. Risk: treating a town's complaint as a number (Neighbours, Not Numbers). No claim about your past | The brief's eight-to-five consolidation meets the Neighbours, Not Numbers value in front of two branch managers. CASE because it sets a live problem from the actual roadmap |
| J1 | "Tell us about your time as a branch supervisor." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Rapport opener: a 90-second arc from the sentence: six years in retail banking, the last three as a branch supervisor. Answer slot: describe the branch and its members in your own words, including anything you would say about its town; if there is little to say about that, say so and stay with the work | Conversational openers are scored; F6 is the row. EXP because it tests whether your story reads as a person, not a list |
| J2 | "What do you make of the move to digital, and what do members still need from a branch?" | CO | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Give your own view and use the brief's lines: 40% of member service digital by 2028, and app-only banks as the main competitive pressure. Answer slot: if you saw what members asked for in person at your branch, say what you saw; if you did not, say what you would want to find out and how | CO grounded in current strategy, asked in a warm register to branch managers whose branches are in the brief's consolidation line |
| K1 | "You'd coach supervisors in our branches. When a complaint goes wrong, where does your job stop and ours start?" | JD | [grounded] | Propose principles, not a claimed seam: at any moment one named person holds the complaint (Own the Fix: whoever finds the problem keeps hold of it until it is solved), and the member should not have to explain twice. Then ask how they see it. The line between your role and theirs is theirs to set, and the pack knows nothing about it. No claim about your past | The JD's coaching line and the branch managers' own supervisors meet at a seam; proposing principles avoids pretending to know it. F4 is the requirement |
| K2 | "A monthly report shows one branch's complaints rising. How do you raise it with its manager?" | CASE | [generic] | Ask before you tell: what is behind the number and what the manager already knows. Say what you bring them as well as what you need from them: a view across branches, a way to help. Keep Neighbours, Not Numbers in the framing: a number is a prompt for a conversation, not a verdict on the branch. No claim about your past | Peer-style reciprocity on the JD's monthly-reporting line; F3 is the requirement. `[generic]` because it is a pattern for the problem |

## Values cheat sheet

Published value names, copied from the page text you supplied on 11 November 2026. A values-style round is detected: the recruiter's email says the panel scores against the four values.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decisions are taken from the member's side of the counter | No sentence carries a story. F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Scaffold in G1; if no such time comes to mind, say so plainly, then give that sentence at its own scope |
| Plain Words | If a member has to have it explained twice, the writing was wrong | No sentence carries a story. F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Scaffold in G2; if none comes to mind, say so plainly, then give that sentence at its own scope |
| Neighbours, Not Numbers | Every branch is part of its town | No sentence carries a story. F6: "6 years in retail banking, the last 3 as a branch supervisor." Scaffold in G3; if none comes to mind, say so plainly, then give that sentence at its own scope |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No sentence carries a story. F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Scaffold in G4; if none comes to mind, say so plainly, then give that sentence at its own scope |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do your supervisors find hardest about escalations today?" | Peer-level curiosity about the exact thing the role coaches |
| 2 | "What would genuinely help your branch from a Member Experience Lead in the first month?" | The reciprocity question: it asks what you can give them, not only what you need |
| 3 | "How do you decide in your branch when a complaint is yours to hold and when it is passed up?" | Puts Own the Fix in their hands and shows you are thinking about the seam |
| 4 | "As the hub plans take shape, what are you hearing from members in your town?" | Takes Neighbours, Not Numbers seriously without presuming their view |
| 5 | "Which of the four values shows up most in a hard week in your branch?" | Invites them to tell a story, and a scorer remembers a candidate who made them talk |

---

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 own the process end to end | A1, B3, C3, E2, H1 |
| F2 across branches and the contact centre | B1, B2, D1, H1 |
| F3 monthly reporting on volumes and resolution times | A1, A3, C2, K2 |
| F4 coach branch supervisors on escalations | C1, C3, H2, K1 |
| F5 work with digital teams on self-service journeys | C4, E1 |
| F6 4+ years in financial-services customer operations | A1, A4, D3 |
| F7 regulated complaints | A5 |
| F8 presenting to senior leaders | B2, C2, D2 |
| F9 Excel reporting | A3 |
| The four published values | G1, G2, G3, G4 |
| Strategy: digital 40%, hubs, small-business lending, app-only banks | A2, E1, E2, H3, J2. Small-business lending earns no question: nothing in the JD ties it to complaints, and A2 holds it as an optional line |

## Prohibited claims

Not coached, with the basis and the honest form. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says the branch's formal complaints log, not the process. Slots in B3 and H1 stay inside the log |
| Has worked in a contact centre, or handled contact-centre complaints | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." D2's slot covers the spreadsheet only |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: the material says the formal complaints log, not regulated complaints. A5's slot asks only which rules the log sat under |
| Coached branch supervisors | Inflated form of F4 | F4's quote at its own scope: new tellers. C1's slot stays at the tellers |
| Built Excel reporting on volumes and resolution times | Inflated form of F3 and F9 | F3's quote at its own scope: a monthly complaints spreadsheet. A3's slot asks what it counted and which tool, nothing more |

## Sources

Provided documents: the JD as pasted; the values text as pasted, copied from ashgrovecu.org/about/values on 11 November 2026 (named as the source of pasted text, not read as a link); the recruiter's email about the process; the four lines of the July 2026 strategy brief as you wrote them (the brief itself was not pasted); your background as written in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text, copied the day of this pack, fixes the cheat sheet and the four VAL questions, so a search could not have moved them |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the loop: three rounds, who runs each, lengths, the case and the values scoring, so persona weights and loop structure were already set |
| 3. `Ashgrove Credit Union strategy` | skipped | The four brief lines you supplied, from a July 2026 brief under six months old, fix the CO and CASE questions. A search could add detail beyond those four lines, listed in the upgrade menu |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names were given, only titles, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or the real lines from it → every fit row would quote your own CV sentences instead of four sentences from a message; the monthly complaints spreadsheet itself, with member data removed, would let rows F3 and F9 reach the `high` band
- Your own written answers to the slots, sent in a message → F1, F3, F4, F5, F7 and F9 become story-mapped rows, and the four value scaffolds in G1 to G4 become mapped stories. What to write: what the spreadsheet counted and in which tool; which rules the formal log sat under; anyone you coached beyond new tellers; any work with a digital team; one real story per value
- The interviewers' names, once assigned → an interviewer read, personas set per person, and a reverse question tied to each person's own path
- The recruiter, in one email: the case's format, any reading beforehand, and which complaint rules apply → the Round 3 case guidance stops being a general pattern, and A5 and H1 become specific
- The full strategy brief → more specific CO and CASE questions, including the small-business lending line, which has no question now
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the role-family loop reports, recent organisational context and a grounding brief of current vocabulary; run only on your yes
- A tuesday-dossier.md, if you have one from earlier work on this role → verified evidence, allowed strategies per weak area and absolute prohibited claims would sharpen every guidance cell. Never required
