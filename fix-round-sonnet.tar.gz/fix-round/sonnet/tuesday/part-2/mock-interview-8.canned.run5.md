The pack is written. I'm running a quick format check on the file, then I'll give you the summary.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-canned-f6f54bdd/Ashgrove-Credit-Union_member-experience-lead_interview_pack.md`.

I built it in loop mode, with a mini-pack for each of the three rounds on 20 November. There are 31 questions and five reverse questions per round. Round 3 also has a cheat sheet mapping Ashgrove's four values to what you've told me. No interviewers are named yet, so there's no interviewer read.

Neither your pasted values page nor the recruiter's email needed a web search, and the July strategy brief is under six months old. Nothing was fetched.

**Rehearse first:** the contact-centre gap. It's in the JD's headline line and you named it yourself, so it will come up in all three rounds. The pack drills it as B1, then D1 (the deepest rehearsal), then J1.

**Presenting to senior leaders:** this is your other stated gap. The pack gives you plain acknowledgments for both gaps, each followed by a plan.

**What the pack does not claim for you:**
- It never says you "owned" the complaints process, coached supervisors, or are an Excel expert. Your sentences say you handled one branch's log, trained new tellers, and built a spreadsheet.
- Where the JD asks about something your material doesn't show, such as regulated complaints, digital teams, what the spreadsheet tracked and whether it was Excel, the guidance is an answer slot. You answer from what actually happened, or say plainly that it wasn't yours.
- The Round 3 case questions are practice shapes, because the real scenario isn't known.

Say the word and I'll play the Skeptic on D1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

## 1. Title block

- **Candidate:** Dara
- **Role:** Member Experience Lead, Ashgrove Credit Union
- **Date:** 20 November 2026, three rounds in one day; this pack was built on 11 November 2026
- **Mode:** loop mode, because the recruiter's email gives the three scheduled rounds
- **Interviewers:** none named yet, so there is no interviewer read in this pack

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Nothing beyond the slot |
| 2 | Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation, and "the panel is also the values round — they score against the four values" |

First version; nothing has been regenerated.

## 2. How to use this pack, and the type key

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview, not a question for this conversation.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral and values alignment | Whether past behaviour demonstrates Ashgrove's published values |
| EXP | Work-experience deep-dive | Whether what you say about your own work survives follow-ups |
| JD | Role and JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether you can think at Ashgrove's altitude |
| CASE | Live problem | Structure and reasoning on a problem from the role |

**Highest-ROI prep:** the contact-centre objection, in the order B1, then D1 (the deepest rehearsal in the pack), then J1. It is the JD's headline scope plus a gap you stated yourself, so it will arrive in some form in all three rounds.

## 3. Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process across branches, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened beyond the log likely. If you did more with a complaint than log it, say what and how, in your own words; if the log was the part that was yours, say so plainly and stay with it |
| F2 | "the contact centre" — JD, the second half of the same ownership line | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote reaches monthly complaints reporting and does not show whether it counted volumes or resolution times. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it tracked volumes or resolution times, say which and how each was counted; if it did not, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Training tellers on a script is adjacent to coaching supervisors, and the bridge does not stretch it: "I trained new tellers on our escalation script." Answer slot: if any of it reached colleagues beyond new tellers, or went beyond the script, say who and how; if it did not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this, and you have not said it is absent. Answer slot: if you have worked with a digital or product team on anything members use themselves, say what it was and what your part was; if not, or it was not yours, say so plainly and say what you would ask the digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on what the six years held. Lead with the dates as you gave them: six years in retail banking, the last three as a branch supervisor. For the earlier three years, name your roles in your own words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | "Formal" does not show whether the log fell under regulatory rules; reading it as regulated is this pack's derivation, so it is not asserted. Answer slot: if the log sat under regulatory rules, say which rules and what part of it was yours; if it did not, or the rules were applied by someone else, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. The material does not say what senior means at Ashgrove, so do not read the gap wider or narrower than your own sentence |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel; reading it as Excel is this pack's derivation. Answer slot: if it was built in Excel, say what you did in it, in your own words; if it was another tool, say so plainly and stay with the spreadsheet you built |

No requirement in the JD is a gate, as the evidence conventions define one: the 4+ years is a length of experience, graded in F6, not a term you meet or do not.

## 4. Grounding brief

The strategy brief is the one Ashgrove published in July 2026 and the recruiter sent you; the items below are as you gave them, since the brief's own text was not pasted.

| Item | As you gave it | Provenance | Where it surfaces in this pack |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | A2, D3, E1, H4 |
| Branch consolidation | Consolidate eight branches into five hubs over 2027 | [grounded] | A2, E2, and reverse question R2-2 |
| New product | Launch a small-business lending product in Q1 2027 | [grounded] | A2 |
| Competitive pressure | The main competitive pressure is app-only banks | [grounded] | A2, E1 |

## 5. Round 1: the recruiter, 30 minutes

### Persona weights

| Persona | Weight | Reasoning | Basis | Questions |
|---|---|---|---|---|
| Conversational / Rapport Builder | high | The recruiter-screen prior is conversational plus a light Skeptic: motivation, consistency, knockout checks in a friendly register. Your email gives the slot and nothing about focus, so the prior stands | [generic] | A1 to A5 |
| Skeptic | light | Same prior; the contact-centre scope and the presenting line in the JD are the checks most likely to be put to you here | [generic] | B1 to B3 |

### Question bank

**A: Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Three beats, each a clause the quotes state, in your own words: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you built the monthly complaints spreadsheet your regional manager uses. Close on your own reason for moving to a role that sits above the branch, whatever is true for you. About ninety seconds, then stop, and add no scope the quotes do not state | Opens most recruiter calls and is scored even though it feels casual. F6, F1 and F3 supply the beats; EXP because it tests whether the CV story holds when told aloud |
| A2 | "What do you know about Ashgrove, and why this role now?" | CO | [grounded] | Use the brief's facts as given: 40% of member service to digital channels by 2028, eight branches into five hubs over 2027, a small-business lending product in Q1 2027, app-only banks as the main competitive pressure. Pick the one you can speak to honestly and say what it means for complaints, as your own view and not as a fact. Your reason for now is yours to give; the pack does not supply one | Motivation consistency is the recruiter-screen check; the brief already holds the homework, so no research was needed. CO because it tests how deep the preparation goes |
| A3 | "Which of our four values spoke to you most?" | VAL | [grounded] | Name it by its official name: Members First, Always; Plain Words; Neighbours, Not Numbers; or Own the Fix. Choose the one that is true for you and say why in your own words. If you link it to your work, use only a sentence from the cheat sheet in section 7, at its own scope | The panel scores against the four values, so a recruiter hearing you use them accurately is an early signal. VAL because it tests the published values by name |
| A4 | "Tell me about the complaints work you've done." | EXP | [grounded] "I handled the branch's formal complaints log"; "I trained new tellers on our escalation script" | Two beats at their own scope: you handled the branch's formal complaints log; you trained new tellers on the escalation script. Answer slot: the JD asks for experience handling regulated complaints, so expect a probe on what governed the log. If it sat under regulatory rules, say which rules and what part was yours; if it did not, or the rules were applied by someone else, say so plainly and stay with the log you handled | F7 is the thinnest row on the complaints requirement and F4 is the adjacent one; EXP because it checks what was actually yours |
| A5 | "Can you confirm how long you've worked in financial services, and in what roles?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | State it as you gave it: six years in retail banking, the last three as a branch supervisor. For the earlier three years, name your roles in your own words. Nothing else is claimed about them here | A knockout-style check on the JD's 4+ years line; F6 closes it cleanly, and JD because it scores a stated requirement |

**B: Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre. How do you feel about that, given the role covers it?" | JD | [grounded] "Never worked in a contact centre" | Say the limit first, in your own words and once: "I haven't worked in a contact centre." Then a plan, as a plan: what you would want to see and hear first, who you would ask, how you would check what you learned. Do not add contact-centre experience, and do not apologise past one sentence | F2 is the JD's headline scope and your own stated gap, so this is the first rehearsal of the pack's highest-ROI objection; JD because it scores a stated requirement |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose from what you have stated: the contact centre (F2) or presenting above regional level (F8). Say it plainly, then the plan for it. The material does not show whether you have worked with digital teams, so if you pick that one, use F5's slot and not a claim | A stock Skeptic stem that rewards candour over polish; both stated gaps are in the material, so the honest answer is already available |
| B3 | "The role presents to senior leaders. How comfortable are you with that?" | JD | [grounded] "I've never presented to anyone above regional level" | Say it as stated: "I haven't presented to anyone above regional level." Then how you would prepare, as a plan, such as what you would want to know about the audience and how you would rehearse. Do not describe senior-level presenting you have not done | F8 is a stated gap against a stated requirement, and a recruiter may screen on it; JD because it scores the requirement |

### Reverse questions for round 1

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1-1 | "What would the Head of Member Services most want the first person in this role to have changed after six months?" | Shows you are thinking about the manager's priorities, and gives you something to carry into round 2 | [generic] |
| R1-2 | "Is the panel case scored on structure or on a particular answer, and is there anything I can read beforehand?" | Practical, and it tells you how to spend the 20 minutes | [generic] |
| R1-3 | "Which external complaints rules does Ashgrove report under, and do the branches and the contact centre follow the same ones?" | Lets you match your examples to the right framework, and it signals you know complaints are regulated | [generic] |
| R1-4 | "Will anyone from the contact centre or the digital team be part of the process?" | Shows you have read the scope of the role as wider than the branches | [generic] |
| R1-5 | "Is the digital self-service work already moving, or does this role start it?" | Ties your question to the 40% digital target in the brief | [grounded] |

## 6. Round 2: the Head of Member Services, 45 minutes

### Persona weights

| Persona | Weight | Reasoning | Basis | Questions |
|---|---|---|---|---|
| Values / Behavioral | high | The recruiter's email says "mostly behavioural" | [grounded] | C1 to C3 |
| Skeptic | high | The hiring-manager prior is Case plus Skeptic: they are buying capability and weighing the gaps, and F2, F1 and F5 are the gaps in the material | [generic] | D1 to D3 |
| Case / Strategist | mid | The same hiring-manager prior, lowered because the email puts the 20-minute case in round 3 and calls this round mostly behavioural | [grounded] | E1 to E3 |
| Data-Driven Prober | low | The JD asks for monthly reporting, and the one artefact in your material is a spreadsheet, so expect it to be read closely | [inferred] | F1 and F2 |

### Question bank

**C: Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold, since no sentence in your material carries this: pick a time with a named stake, a moment you did not soften the message, and a relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A Values/Behavioral persona stem, chosen because the manager round is mostly behavioural; no fit row carries it, so it is a scaffold and not a story |
| C2 | "Tell me about a complaint you took from first report to resolution." | EXP | [grounded] "I handled the branch's formal complaints log" | The setting is the log you handled. Answer slot: the JD asks you to own the process end to end, so expect a probe on what happened after a complaint was logged. If you saw one through to its resolution, say what happened and what part was yours; if it passed to someone else, or none stayed with you, say so plainly and stay with the log you handled | F1 is where "end to end" presses hardest; EXP because it tests what was actually yours |
| C3 | "How have you trained or coached other people on handling escalations?" | JD | [grounded] "I trained new tellers on our escalation script" | Say it at its scope: you trained new tellers on the escalation script. Answer slot: the JD asks you to coach branch supervisors, so expect a probe on whether it reached beyond tellers or beyond the script. If it did, say who and how, in your own words; if it did not, say so plainly and stay with the training you gave | F4 is adjacent and not equal to the JD line; JD because it scores the coaching requirement |

**D: Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never worked in a contact centre, and this role owns complaints across branches and the contact centre. How would you handle the part that sits in the contact centre?" | JD | [grounded] "Never worked in a contact centre" | The highest-ROI rehearsal in this pack. Limit first, once: "I haven't worked in a contact centre." Then the plan, as a plan: what you would want to see and hear first, who you would ask, how you would test what you learned. Follow-up ladder to rehearse aloud: level one is "what would you do in week one"; level two is "what if the contact-centre team does not accept a lead from the branch side"; level three is "what would make you wrong about your plan". Answer each as a plan, never as experience. Concede the limit once and plainly, and do not add to it. Rehearse until it is boring | F2 is the JD's headline scope and your stated gap, so it arrives in some form; JD because it scores the stated requirement. This question gets the most follow-up levels and the most exact concession wording |
| D2 | "The JD says own it end to end. What you've described is one branch's log. Where is the distance?" | JD | [grounded] "I handled the branch's formal complaints log" | The words stay at the quote: "I handled the branch's formal complaints log." The limit is the pack's own observation: your material says the branch's log, not the process across branches or channels. Answer slot: if you did more with a complaint than log it, say what and how, in your own words; if the log was the part that was yours, say so plainly and stay with it. Hold through two follow-ups by returning to the log, never by adding to it | F1 is the second-likeliest place to be pressed after F2; JD because it scores the ownership requirement |
| D3 | "What have you done with digital teams on self-service?" | JD | [grounded] | The material does not show this. Answer slot: the JD lists self-service journeys and the brief puts 40% of member service on digital channels by 2028, so expect it. If you have worked with a digital or product team on anything members use themselves, say what it was and what your part was; if not, or it was not yours, say so plainly and say what you would ask the digital team first | F5 is silent, so this is a slot and not a story; JD because it scores a stated requirement |

**E: Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The plan is 40% of member service on digital channels by 2028. What should happen to the way we handle complaints?" | CASE | [grounded] | Think aloud in order: what you need to know first; the objective; which complaints and which members; the approach; how you would measure it; the risks. Challenge one premise respectfully, for example whether every complaint belongs in the same channel. Use words a member would. The question needs no claim about your past, so the guidance makes none | A live problem set on the brief's digital target; CASE delivery with CO content. Counts toward the strategy-grounded question the pack needs |
| E2 | "Eight branches become five hubs over 2027. What would you want to know first about the complaints that follow?" | CASE | [grounded] | Clarify before structuring: where complaints come from today, by branch and channel, and what members in an affected town would notice first. Then objective, approach, measures, risks. Link to Neighbours, Not Numbers only in your own words. No claim about your past | The consolidation is in the brief and touches every branch; CASE with CO content |
| E3 | "Sixty seconds, to the senior team: complaint resolution times are slipping. What do you tell them?" | CASE | [generic] | Headline first, then what you know is driving it, what you are doing, what you need from them. Say plainly what you do not yet know. Stop at sixty seconds. The question needs no claim about your past, so the guidance makes none | Tests the JD's presenting line as a live exercise and not as a CV claim, which is where F8 is thin; CASE because it is delivered live |

**F: Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through the monthly complaints spreadsheet you built. What did it show, and who used it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Three beats the quote states: you built it; it was monthly; your regional manager used it. Answer slot: the JD asks you to report monthly on volumes and resolution times, so expect a probe on what it tracked. If it tracked volumes or resolution times, say which and how each was counted; if it did not, say so plainly and stay with the spreadsheet you built. You have given no figures, so there is no number to defend; if you quote one live, know how it was counted and say plainly if you do not | F3 is the only reporting evidence and nothing is inspected behind it; EXP because it tests what you actually built |
| F2 | "How comfortable are you with Excel reporting?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Say what you built: the monthly complaints spreadsheet. Answer slot: your material says spreadsheet, not the tool. If it was built in Excel, say what you did in it, in your own words; if it was another tool, say so plainly and stay with the spreadsheet you built. Claim only what you have done in it | F9 rests on a derivation, so the label is `[inferred]` and the guidance stays at the quote; JD because it scores a stated requirement |

### Reverse questions for round 2

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R2-1 | "Where do complaints get stuck today between a branch and the contact centre?" | Points at the end-to-end seam and echoes the Own the Fix value | [generic] |
| R2-2 | "When eight branches become five hubs, who decides what changes for members in the affected towns, and where do complaints sit in that?" | Uses the brief and the Neighbours, Not Numbers value together | [grounded] |
| R2-3 | "Which complaint numbers do you read first each month, and which ones do senior leaders ask you about?" | Starts from the reader of the report, which is the part of the job you have not yet done above regional level | [generic] |
| R2-4 | "What would you want me to bring to the digital team, and what would you want to leave to them?" | Proposes a seam and not a claim to know it | [generic] |
| R2-5 | "What would tell you in my first month that this hire is working?" | Gives you the manager's own yardstick to rehearse against | [generic] |

## 7. Round 3: the panel of two branch managers, 60 minutes

The panel scores against the four values and runs a 20-minute case on a complaint escalation. The content of the case is not known, so the case questions below are practice shapes, labelled `[generic]`.

### Persona weights

| Persona | Weight | Reasoning | Basis | Questions |
|---|---|---|---|---|
| Values / Behavioral | high | The email says the panel is the values round and scores against the four values | [grounded] | G1 to G4 |
| Case / Strategist | high | The email gives a 20-minute case on a complaint escalation | [grounded] | H1 to H4 |
| Peer Evaluator | mid | Branch managers are the people whose supervisors you would coach under the JD, so expect questions on the seam and on what you would need from them. Their relationship to the role is this pack's reading, not something the email states | [inferred] | I1 and I2 |
| Skeptic | low | The gaps in F2 and F8 will be probed by someone in some form; names are not assigned, so the panel's blend cannot be split per member | [inferred] | J1 and J2 |

Conversational, Prober and Pressure personas are not weighted for this round; the Prober's ground, the spreadsheet, is rehearsed in round 2.

### Question bank

**G: Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold for Members First, Always, since no sentence in your material carries it: pick a time with a named decision, what the member needed, and what it ran against inside the branch, and say how it ended for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's own wording raises the theme; no fit row carries a story for it, so it is a scaffold |
| G2 | "Tell me about a time something you said or wrote needed explaining twice." | VAL | [grounded] "I trained new tellers on our escalation script" | The setting is the training: you trained new tellers on the escalation script. Answer slot: the value says "if a member needs it explained twice, we wrote it wrong", so expect a probe on whether you changed how something was put after it needed explaining again. If so, say what you changed and why, in your own words; if nothing like that happened, or the script was not yours to change, say so plainly and stay with the training | F4 is the nearest sentence, and it supplies the setting only; VAL because it tests Plain Words by name |
| G3 | "Tell me about a time you weighed a number against what a branch or a town needed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses"; "6 years in retail banking, the last 3 as a branch supervisor" | The settings are the spreadsheet you built and the branch you worked in as a supervisor. Answer slot: the value says "every branch is part of its town", so expect a probe on a real tension. If a figure in your reporting ever pointed one way and what a branch needed pointed another, say what the two were and what you did; if there was no such moment, or the decision was not yours, say so plainly and stay with what you built | F3 makes you the author of a numbers tool, and F6 puts you in a branch, so this value is the one most likely to be pressed from both sides |
| G4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | The setting is the log you handled. Answer slot: the value says "whoever finds the problem keeps hold of it until it is solved", so expect a probe on one specific problem. If there is one you kept hold of until it was solved, say what it was and what part was yours; if the log meant passing complaints on, or none stayed with you, say so plainly and stay with the log you handled | F1 is the nearest sentence and carries the setting only; VAL because it tests Own the Fix by name |

**H: Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member has complained twice at their branch and says nobody has called back. It has been escalated to you. Walk us through what you do." | CASE | [generic] | Spend the first two minutes clarifying: what the member is asking for, what has already been promised, what is recorded, who has touched it, and what time limits apply. Then the objective from the member's side, the approach with one named owner and a date the member is given in plain words, how you would know it is solved, and the risks. Challenge one premise respectfully, such as whether the first step is to investigate or to call the member. Say aloud how you will split the 20 minutes. The question needs no claim about your past, so the guidance makes none | The case is the part of round 3 you can rehearse most; the real scenario is not known, so this is a practice shape |
| H2 | "The branch manager says the member is always like this and the complaint is not worth the time. What do you do?" | CASE | [generic] | Treat the manager as a source and not an obstacle: ask what they know, then separate how often the member contacts the branch from whether this complaint has substance. Keep the member's side of the counter as the objective, agree who tells the member what, and say what you would record. Hold your position politely if pushed. No claim about your past | The panel are branch managers, so how you treat the manager in the scenario is itself scored; CASE delivery |
| H3 | "The same complaint theme turns up in two branches and in the contact centre in one month. What do you report, and to whom?" | CASE | [generic] | Clarify first: how comparable the records are across branches and the contact centre, and over what period. Then headline first, what you know against what you do not, who owns the next step, and what you would check next month. No claim about your past | Tests the JD's monthly reporting line across channels as a live problem; CASE |
| H4 | "The complaint is about a self-service journey in the app, and the digital team says it works as designed. What do you do?" | CASE | [generic] | Start from the member: what they tried and where it failed. Then ask the digital team what "as designed" means and for whom. If a member needs it explained twice, the wording failed, so treat the wording as part of the problem. Propose a joint look and not a verdict, and name how you would tell if repeat complaints on that journey fall. No claim about your past | The JD's digital line plus the brief's 40% target, run as a live problem; the scenario is the pack's, not Ashgrove's |

**I: Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "You'd be coaching my supervisors on escalations. Where is the seam between what you do and what I do, and what happens when we disagree?" | JD | [grounded] "I trained new tellers on our escalation script" | Propose seam principles and not a settled seam, for example who decides what the member is told and who decides what the branch changes, and say you would agree them with the manager. Offer what you would bring to their supervisors. Your own past is the quote at its scope: you trained new tellers on the escalation script | F4 is adjacent to the coaching line, and a branch manager is the person most affected by the answer; JD because it scores the coaching requirement |
| I2 | "What would you need from me in your first month, and what could you give my branch?" | JD | [generic] | Reciprocity: say what you would ask to see and whom you would ask to shadow, then what you would offer in return, as plans. Make no claim about your past | The standard peer reciprocity probe, framed for a branch manager; no fit row is needed because the answer is forward-looking |

**J: Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You've not worked in a contact centre and you've not presented above regional level. Why should we back you to lead across both?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level"; "I handled the branch's formal complaints log"; "I trained new tellers on our escalation script" | Two limits, each once and in your own words: "I haven't worked in a contact centre." "I haven't presented to anyone above regional level." Then what your material does carry, at its scope: you handled the branch's formal complaints log, and you trained new tellers on the escalation script. Then a plan for each limit, as a plan. Add nothing to make the limits smaller | The two stated gaps, F2 and F8, put together as a panel would; JD because it scores two stated requirements |
| J2 | "You've spent three years as a branch supervisor. Why leave the branch for a role that sits above it?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | The reason is yours and the pack does not supply one. Tell it in your own words, tie it to a published value only if it is true for you, and say what you would want to keep from the branch in this role, as a plan | A motivation-consistency probe, and a likely one from branch managers; F6 is the only row it can rest on |

### Values and principles cheat sheet

Official names and one-line definitions are as pasted from ashgrovecu.org/about/values on 11 November 2026.

| Value (official name) | Working meaning | Mapped story, or scaffold | Provenance |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, question G1: pick a time with a named decision, what the member needed, and what it ran against inside the branch. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | [grounded] |
| Plain Words | If a member needs it explained twice, the wording was wrong | F4: "I trained new tellers on our escalation script", setting only; the slot in G2 covers whether anything was changed after being explained again | [grounded] |
| Neighbours, Not Numbers | Every branch is part of its town | F3: "I built the monthly complaints spreadsheet our regional manager uses", setting only; the slot in G3 covers a real tension between a figure and a branch's need | [grounded] |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log", setting only; the slot in G4 covers a specific problem you kept hold of | [grounded] |

### Reverse questions for round 3

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R3-1 | "What do your supervisors find hardest about handling an escalation?" | Asks about their people and gives you the coaching brief | [generic] |
| R3-2 | "When a complaint reaches your branch from the contact centre, what do you wish you had been told?" | Goes to the seam between channels from the branch side | [generic] |
| R3-3 | "What could a new person do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-style interviewer | [generic] |
| R3-4 | "Which of the four values is hardest to hold when the branch is busy?" | Shows you take the values as working rules and not as slogans | [grounded] |
| R3-5 | "What would you want branch staff told about complaints during the move to hubs, and by whom?" | Uses the brief's consolidation plan and the Neighbours, Not Numbers value | [grounded] |

## 8. Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| Own the complaints process end to end across branches | A4, C2, D2, H1 |
| The contact centre | B1, D1, J1 |
| Report monthly on complaint volumes and resolution times | F1, H3, E3 |
| Coach branch supervisors on escalations | C3, I1 |
| Work with digital teams on self-service journeys | D3, E1, H4 |
| 4+ years in financial-services customer operations | A1, A5 |
| Experience handling regulated complaints | A4, C2 |
| Confident presenting to senior leaders | B3, E3, J1 |
| Comfortable with Excel reporting | F2 |

Headline CV figures to defend: none, because your material contains no figure beyond the years, so there is no defend-the-number question to write.

## 9. Prohibited claims

Not coached in any answer, bridge, hold or drill:

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says the branch's log, not the process. D2's slot stays inside the log |
| Worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says new tellers and the script. C3's slot stays inside the training |
| Reported complaint volumes and resolution times every month | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says the spreadsheet, not what it measured. F1's slot asks only what it tracked |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says a formal log, not what governed it. A4's slot asks only what governed the log |
| Is an advanced Excel user | Inflated form of F9 | F9's quote at its own scope. The limit is the pack's observation: the material says spreadsheet, not the tool. F2's slot asks only what you did in it |

## 10. Sources

**Provided documents:** the job description as pasted; Ashgrove's values as pasted, copied on 11 November 2026 from ashgrovecu.org/about/values (a source named for pasted text, not a link to read); the recruiter's email describing the three rounds; the 2026 strategy brief published in July 2026, as you summarised it; your background, as you wrote it.

No dossier was present, and no search or fetch was sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove values` | skipped | Could not have moved the values cheat sheet or the VAL questions: the values page you pasted already supplies the four official names and definitions |
| 2. `Ashgrove interview process member experience` | skipped | Could not have moved the persona weights or the three-round structure: the recruiter's email already gives the rounds, who runs each, their lengths, the case and the values round |
| 3. `Ashgrove strategy` / recent news | skipped | Could not have moved the CO and CASE questions: the July 2026 brief you summarised, about four months old, already supplies the four current priorities |
| 4. `interviewer name Ashgrove` | n/a | No name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- Interviewers' names and roles, once assigned → an interviewer read, persona weights adjusted to their public professional footprint, and one reverse question tied to their own path
- Your answers to the slots in F1, F3, F4, F5, F7 and F9 (what happened after a complaint was logged, what the spreadsheet tracked, whether it was built in Excel, any work with digital teams, whether the log sat under regulatory rules) → those discovery and transferability rows can become `[grounded]` and the banks can use your own sentences
- Your CV text, if you have it to hand → more quotable evidence for every row, and the earlier three years of F6
- The full text of the July 2026 strategy brief → the "as you gave it" items become quoted ones, and the CO and CASE questions can use its own wording
- The complaints framework Ashgrove reports under, which the recruiter can usually answer in one email → F7 and the case rehearse against the right rules (reverse question R1-3 asks it)
- Any detail the recruiter gives on how the panel case is scored, and whether the topic is shared in advance → the H bank can be aimed at the actual format
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering role-family loop reports, recent organisational context, and the interviewers' public footprint once names exist → more specific CO and CASE questions in place of the `[generic]` ones
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence for the answer slots and a sharper account of which objection to rehearse, never required
