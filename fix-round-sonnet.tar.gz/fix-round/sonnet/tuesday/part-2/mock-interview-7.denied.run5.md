Searches were refused, so I'm building the pack from your JD and your note alone. I'm writing it to a file now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-denied-c51fe3b4/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 20 questions, a fit snapshot against each line of the JD, a reverse-question list and a two-day prep triage.

- **No company research:** every web search was refused, so the pack uses only your JD and your note. It has no Saltmarsh values, strategy, loop structure or facts about Tobias, and the Sources section lists each refused search.
- **Assumption:** I built it as a hiring-manager-level round, weighting Case and Skeptic questions highest, since your note doesn't say how Tobias relates to the role.
- **Top prep item:** B1, the in-app-purchases question, rests on a gap you stated yourself. Rehearse your acknowledgment and your learning plan out loud until they sound routine.
- **Answer slots:** several answers say "if you did this, say how; if not, say so plainly." Write your honest version of each before Friday.

I can play the Skeptic on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document if you'd like.

Is Tobias the person you'd report to or a more senior leader, and has the recruiter said what the hour will cover or asked you to prepare anything?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Your note does not say whether he would be your manager or a more senior leader, so this pack is built as a hiring-manager-level round (Case/Strategist and Skeptic weighted highest). Round length: 60 minutes, Friday.
**Research:** none succeeded (see Sources). Everything about Saltmarsh Games beyond your JD is absent from this pack, not guessed.
**Highest-ROI prep in this pack:** B1, the in-app-purchases question. It rests on a gap you stated yourself, and it will be asked in some form.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and where a cell has an answer slot, answer it from your real experience or say plainly that the step was not yours.

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the values, not generic virtue |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, what was actually you |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack, because no company research succeeded) |
| CASE | Live hypothetical problem: structure and reasoning on the spot |

## Prep triage

Two days, Wednesday and Thursday. The few things worth doing well, in order:

1. B1, aloud, until the acknowledgment and your plan sound boring. This is the question most likely to decide the hour.
2. B2, B3, B4, B5: write down your honest answer to each answer slot, in your own words, including the "that was not mine" branch where it applies.
3. A1, A2, A4: talk through each as a live problem, out loud, with a timer of about two minutes.
4. D1: your 90-second arc, using only what your note says.
5. Reverse questions: pick three.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a content-drop calendar for the main title, not live events and not two titles, with nothing inspected behind it, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely. If you ran or coordinated a calendar for another title, or any drop worked as a live event, say which and how, in your own words; if not, or it was not yours, say so plainly and stay with the main title |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line in your message with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms: a weekly calendar, for the main title, for the last two years |
| F3 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and two years on the weekly calendar; it does not say which years were on a game with ongoing updates. Answer slot: the JD's 3+ years line makes a probe on how the four years map likely. Say how many of those years were on a title with ongoing updates, in your own words; if only part of the span was, or you cannot say, say so plainly and stay with the two years on the weekly calendar |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show coordination with design, art, engineering or community. Answer slot: the JD's line makes a probe on which of those teams your updates involved likely. If you coordinated any of them, say which and how, in your own words; if you did not, or it was not yours, say so plainly |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says presenting monthly retention numbers, not running a post-event review and not owning KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on what happened after an event likely. If you ran any review after a drop, say what it covered and what was reported, in your own words; if there was no such review, or it was not yours, say so plainly and stay with the monthly numbers |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap on the requirement's wording, with nothing inspected behind it. Lead with the quote's terms. Answer slot: the JD's retention line makes a probe on what the numbers contained and where they came from likely. Say which measures were in them, in your own words; if you only presented figures someone else produced, or you do not know how they were counted, say so plainly and stay with presenting them |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it, not that you managed it release by release, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's manage-with-QA line makes a probe on running it likely. If you also ran it with QA on releases, say how, in your own words; if not, or it was not yours, say so plainly and stay with writing it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist others still use touches written clarity without showing it; nothing inspected. Answer slot: expect to be asked for an example of your writing. If you have other written material that others used, say what it was and who used it, in your own words; if the checklist is the only one, say so plainly and stay with it |
| F9 | Experience on a title with in-app purchases (no line of the supplied JD asks for this; tracked because you stated the absence) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan in your own words and never as a past. Nothing added to make the gap feel smaller |
| F10 | Leading a team (the supplied JD says coordinate and no line asks for leading; tracked because you stated the absence) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." Then how you would approach coordinating across teams, said as a plan and never as a past |

## Persona table

Weights come from the persona model's relationship priors for a hiring-manager-level round. There is no interviewer profile and no loop source, so nothing adjusts them; the loop falls back to the generic archetype (screen, hiring manager, panel) with its flat tilt. Treat the weights as a starting point and recalibrate if you know more.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems on the role: plan this calendar, diagnose this drop, make this call | Highest. Hiring-manager prior; the JD is a planning-and-coordination role. 5 questions | Clarify, then objective, segments, approach, metrics, risks; think aloud; challenge one premise politely |
| Skeptic (B) | Quiet, persistent probing of the gaps and of how your experience maps | Highest. Hiring-manager prior, and F9 and F10 are stated gaps. 5 questions | Rehearse B1 until it is boring; bridges only from your own quoted adjacent work; say the limit plainly rather than bluffing |
| Data-Driven Prober (C) | Line-by-line probing of the retention numbers and the checklist | Medium. The JD names retention metrics and KPIs. 3 questions | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational (D) | Friendly opener, then scored casual questions | Medium. Every round has a casual register; the biography question is the one to script. 3 questions | A 90-second arc; treat casual questions as scored; never answer the reverse-question slot with "no" |
| Pressure (E) | Interruptions, time-boxes, "how much was you" | Low to medium. Rises if Tobias turns out to be a skip-level. 2 questions | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral (F) | Scenario probes on behavior | Low. No values-style round is detected: no loop source, and the generic archetype reads no. So no cheat sheet; 2 open-prompt questions only | Choose a story where the hard truth landed; say plainly if none comes to mind |
| Peer Evaluator | Seam-splitting between adjacent teams | Low. No bank: on what you have told me, a Head of Live Operations is not a peer of an incoming producer. Add one if your loop includes producers who would sit beside you | n/a |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for next month's live-events calendar across two titles. What do you need to know first?" | CASE | [generic] | Clarify first: the goal of the month, what each title's players are doing now, which teams have capacity, what shipped recently. Then objective, how you would sequence events across the two titles, the metrics you would watch, the risks. Say your assumptions aloud. The question needs no claim about your past, so the guidance makes none | F1's requirement set as a live problem; CASE because it scores structure |
| A2 | "Retention in the week after an event dropped 20 percent against the previous event. Diagnose it." | CASE | [generic] | Clarify what retention measure and which players, then segment (new versus returning, platform, region), then separate event content from anything else that changed that week, then say what you would check first and what you would report. No claim about your past | F6's requirement as a diagnosis; CASE because it scores reasoning from a metric |
| A3 | "Design, art and engineering each tell you they cannot make Thursday's update. What do you do?" | CASE | [generic] | Ask what is actually blocked and by what; separate the must-ship from the can-slip; offer options with their costs; say who decides and how you would tell community. Think aloud and challenge one premise (is Thursday the real constraint?). No claim about your past | F4's requirement as a coordination problem; CASE because it scores how you structure under conflict |
| A4 | "An event underperformed. Walk me through the post-event review and what you would report." | CASE | [generic] | Start from what the event was for, then what you would compare against, what you would report and to whom, and what decision the review should end in. No claim about your past | F5's requirement set forward; CASE because the interviewer wants the structure, not a history |
| A5 | "QA has an open blocker at 4pm on Wednesday for a Thursday release. Walk me through the call." | CASE | [generic] | Clarify severity and who is affected; options (hold, ship with a known issue, cut the feature, hotfix) with the cost of each; who needs to agree; what the checklist says and what you would update after. No claim about your past | F7's requirement as a decision; CASE because it scores judgment under a deadline |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. How do you get up to speed on that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Open with the acknowledgment, in your own words and no longer than your note: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan and never as a past: what you would learn first, who you would ask, how you would know you had it. Follow-ups to expect, each deeper: what you would learn first; whether you would own purchase-related numbers on day one; what you would do if a number you reported turned out wrong. Concede specifically ("that is the part I would need to learn") and never claim anything adjacent as though it were the same: the retention numbers you presented are a different measure from purchase numbers. Hold the plan through each follow-up by returning to it, not by adding to your past | F9 is the biggest stated gap and sits where the role's KPIs point; JD because it scores whether you can do the listed job with that gap |
| B2 | "You haven't led a team, and this role coordinates design, art, engineering and community. Where does that leave you on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Acknowledge plainly: "I haven't led a team." The JD's word is coordinate, not lead, so you can ask what level of coordination is expected. Answer slot: if you coordinated with any of those teams on your updates, say which and how, in your own words; if you did not, or it was not yours, say so plainly. Then how you would approach coordination, as a plan | F10 and F4 together; JD because it scores a stated requirement against a stated gap |
| B3 | "The role asks for three-plus years producing live-service games or apps. How do your four years map to that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | State the span as your note does: four years as an associate producer at a puzzle-game studio. Answer slot: say how many of those years were on a title with ongoing updates, in your own words; if only part were, or you cannot say, say so plainly and stay with the two years on the weekly calendar. Do not round the years up | F3 is where the JD's titled-years line meets a quote that does not say which years; JD because it scores the stated requirement |
| B4 | "The role runs the calendar for two titles. What would change from running the calendar for your main title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start from what you ran: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you ran or coordinated a calendar for another title, say how; if only the main title, say so plainly. Then the plan: what you would ask first about how the two titles' dates and teams overlap | F1 and F2 are the evidence for the calendar requirements; JD because the two-titles line is the JD's |
| B5 | "You presented the monthly retention numbers. The role owns the post-event review and the KPIs it reports. What is the step from one to the other?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Start from what you did: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran any review after a drop, say what it covered and what was reported; if there was no such review, or it was not yours, say so plainly and stay with the monthly numbers. Then what you would add, as a plan | F5 and F6 are the evidence for the review and KPI requirements; JD because it scores the stated requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Defend-the-number slots, each in your own words: how the numbers were counted; what they are sensitive to; the assumption behind them you would defend least; which part was yours. Name the weakest assumption before they do. If you do not know how something was counted, say so plainly; do not supply a method you cannot repeat under a second question | F6 is the only numeric evidence and magnet for a prober; EXP because it tests attribution |
| C2 | "Which retention measures would you put in a post-event review, and which would you not trust?" | JD | [generic] | A professional view, not a history. Say what each measure tells you and what it hides, and which you would read together; name one you would distrust alone and why. No claim about your past | F5 and F6's requirements as a judgment call; JD because it scores the stated requirements |
| C3 | "Walk me through the release checklist you wrote for QA." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F7: you wrote it, and QA still uses it; tell those beats in your own words. Answer slot: the JD's manage-with-QA line makes a probe on running it likely. If you also ran it with QA on releases, say how; if not, or it was not yours, say so plainly and stay with writing it | F7 is the evidence for the checklist requirement; JD because it scores that line, EXP in delivery |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get from a puzzle-game studio to wanting live operations here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc using only those four beats, in that order, in your own words. Answer slot: why this role and why Saltmarsh is yours to say, in your own words; no company facts are supplied here because none were researched | F2, F6 and F7 carry the arc; EXP because it is the biography question in a casual register |
| D2 | "When you look at a live-events calendar, what makes you say that is a good one?" | JD | [generic] | Principles, not a history: what it balances (variety, pacing, team capacity, player fatigue), what it leaves room for, how you would know. Optionally one real calendar you have seen, only if you have one. No claim about your past | F1's requirement in a casual register; JD because it scores calendar judgment |
| D3 | "How do you make a written update clear enough that design, art, engineering and community can each act on it?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Principles first: who needs what, one source of truth, what is decided versus open. If you want a real example, the one your note carries is: "I wrote the release checklist our QA team still uses." Answer slot: if you have other written material others used, say what it was; if not, say so plainly | F8 and F4's requirements; JD because the casual question scores written communication |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has already run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | Pause, restate, then say only what your quotes carry: the weekly calendar, the checklist, the retention numbers. Hold through two follow-ups by returning to those three. Concede specifically: "I haven't worked on a game with in-app purchases." Do not tell them what any of it proves; let them draw the inference | F1, F6, F7 and F9 together; JD because it scores the whole fit |
| E2 | "That calendar you ran. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence's own scope: "I ran the weekly content-drop calendar for our main title." Answer slot: say what was yours and what was shared or someone else's, in your own words; if you cannot separate it, say so plainly. Hold through two follow-ups; concede the specific part that was not yours, never the core | F1 and F2; EXP because attribution probes exist to catch inflation |

### F. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship intact afterwards. Answer slot: if any of the numbers you presented to the studio head were unwelcome, say what and how it landed; if none were, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 gives the one place a leadership audience appears in your material; VAL because it scores behavior |
| F2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the player's experience and a number pointed different ways; it needs a named trade-off and what you gave up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's stock values question, themed to live ops; VAL because it scores behavior |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B4, D2 |
| Coordinate design, art, engineering and community | A3, B2, D3 |
| Own the post-event review and the KPIs it reports | A4, B5, C2 |
| Manage the release checklist with QA | A5, C3 |
| 3+ years producing live-service games or apps | B3 |
| Experience running a content calendar | B4, D2, E2 |
| Comfortable with player-retention metrics | A2, C1, C2 |
| Clear written communication | D3 |
| Company and strategy knowledge (CO) | none, because no company research succeeded |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first ninety days look like for someone producing the calendar across both titles?" | It asks for the bar you will be held to and shows you are planning for outcomes |
| R2 | "How is the live-events calendar planned today: who proposes events and who has the final say on what ships?" | It maps the decision path without assuming one |
| R3 | "What does the post-event review report today, and who reads it?" | The JD makes you the owner of that review, so you are asking about your own inbox |
| R4 | "How do design, art, engineering and community each find out what is in an update?" | It shows you think about coordination as information flow, which is where the JD's coordination line gets real |
| R5 | "What do people new to your titles usually need to learn first, and what helps them most?" | It signals you expect to learn, which is honest, and gives you the interviewer's own advice to act on |
| R6 | "How do the two titles' calendars interact: shared dates, shared teams, or separate?" | It tells you whether the two-titles line means one calendar or two |

## Prohibited claims

Not coached in any answer, slot, hold or bridge. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F10 | The acknowledgment F10 gives: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases, or owned purchase-related KPIs | Negative you stated, F9 | The acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope; the limit is the pack's observation, not words for you: the material says a content-drop calendar for the main title. B4's slot stays inside that |
| Owned the post-event review and the KPIs it reports | Inflated form of F5 | F5's quote at its own scope; the material says presenting the monthly retention numbers. B5's slot stays inside that |
| Managed the release checklist across releases | Inflated form of F7 | F7's quote at its own scope; the material says you wrote it and QA still uses it. C3's slot stays inside that |

## Sources

Provided documents: the Live Operations Producer JD as pasted; your background as written in your message. No dossier was present. No other source was used; everything not traceable to those two is labeled generic.

Searches sent, all refused (the host did not grant search permission), so none returned a result, and none was retried:

- "Saltmarsh Games values mobile game studio": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games strategy news mobile titles": refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have moved a values cheat sheet if a values-style round were documented, and the themes of F1 and F2; moved nothing |
| 2. Saltmarsh Games interview process, live operations | unavailable | Would have replaced the generic-archetype loop with named rounds and re-tuned persona weights; moved nothing |
| 3. Saltmarsh Games strategy / recent news | unavailable | Would have added company-grounded CO and CASE questions and a grounding brief; moved nothing |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have added an interviewer read, persona adjustments and a reverse question tied to his path; moved nothing |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access for this session, or a pasted values page, careers page or strategy summary for Saltmarsh Games: adds the company-grounded CO and CASE questions, the loop structure, and a values cheat sheet if a values round exists. Today those are absent or generic.
- Tobias's public profile, or a line on his background: adds an interviewer read, adjusts persona weights, and ties one reverse question to his career path.
- Whether Tobias would be your manager or a more senior leader: reweights every bank (more Pressure and strategy if senior; more Case and Skeptic if direct).
- The recruiter's description of the hour, or any exercise to prepare: adds focus areas, and a build section if a deliverable was announced.
- Your written answers to the slots in F1, F3, F4, F5, F6, F7 and F8: each becomes quoted evidence, and the rows and the B, C and D banks that draw on them are regenerated.
- Inspectable material: the release checklist itself, a redacted page of the content calendar, or a redacted retention report. Any of these would raise F2, F6 and F7 from medium toward high.
- Your CV, if it says more than your note: more quoted sentences for the evidence column, and possibly more rows closed.
- A tuesday-dossier.md, if you have one, would carry verified evidence and prohibited claims into this pack; the pack does not depend on it.
