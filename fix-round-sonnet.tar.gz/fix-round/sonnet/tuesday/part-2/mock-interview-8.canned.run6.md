Your prep pack is saved, and I'm finishing a last tidy-up of one table cell before I hand it over.
Dara, your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-canned-6f48617b/Ashgrove-Credit-Union_member-experience-lead_interview_pack.md`.

I built it in loop mode, with a mini-pack for each of the three rounds on 20 November, because the recruiter's email fixed who runs each one. No interviewer names are assigned yet, so persona weights rest on each round's role and the recruiter's description. No web research was needed: the JD, your pasted values, the recruiter's email and the strategy brief covered everything research would have.

- **Highest-ROI prep:** D1, the "you've never worked in a contact centre" objection. It is rehearsed in full for the manager round, and lighter versions come up in A3 and B2.
- **Your thinnest area:** the four values stories. Nothing you've told me yet carries a story for Members First, Plain Words, Neighbours Not Numbers or Own the Fix. The panel scores all four, so G1–G4 are selection scaffolds for now. One real episode per value from you would turn them into mapped stories.
- **Claims I won't coach:** "owned the process end to end", "handled regulated complaints", "presented to senior leaders" and "has contact-centre experience". The prohibited-claims table gives the honest wording for each.

Say the word and I'll play the Skeptic on D1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you'd like.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode, three rounds on 20 November 2026, built on 11 November 2026.

| Round | Who | Length | What the recruiter said |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | The recruiter's own screen |
| 2 | Head of Member Services, your would-be manager | 45 minutes | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 minutes | Includes "a 20-minute case on a complaint escalation"; "the values round — they score against the four values" |

No interviewer names are assigned yet, so there is no interviewer read and persona weights rest on each round's relationship and the recruiter's description.

## How to use this pack

- Personas describe how a question is asked; types describe what is being scored. Each round has its own persona table, bank and reverse questions; the fit snapshot, grounding brief and prohibited claims are shared.
- Type key. VAL: whether past behaviour shows the company's published values. EXP: whether your own claims survive scrutiny. JD: whether you can do the listed job, gaps included. CO: whether you can think at the company's altitude. CASE: structure and reasoning on a live problem.
- Provenance key. `[grounded]` traces to something you or the recruiter gave me. `[inferred]` is derived from it, with the derivation named. `[generic]` is a pattern for the problem with no claim about you or Ashgrove.
- Guidance is scaffolding, not a script. Where it names an answer slot, the answer is yours, in your own words; the honest second branch is always allowed.
- The highest-ROI prep in the pack is D1, the contact-centre objection. It is asked first in lighter form in A3 and B2, and it deserves the most rehearsal.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length, and the words stay in the quote's terms: six years in retail banking, the last three as a branch supervisor. It is a self-reported line with nothing inspected behind it, so expect a probe on what the role involved day to day. Whether that counts as customer operations is the interviewer's call, not a claim to make for them |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The words stay at the log: "I handled the branch's formal complaints log." Your material does not show whether those complaints fell under regulator rules, and the JD's word is regulated, so a probe is likely. Answer slot: if regulatory rules or timeframes applied to the log, say which and how the log reflected them, in your own words; if none applied, or that was not yours to track, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Adjacent work at one branch, not a process across channels; your material says the log, not the process end to end. Words: "I handled the branch's formal complaints log." Answer slot: if any stage beyond the log was yours to run, say which and how, in your own words; if the log was the whole of it, or the rest was not yours, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Lead in the quote's own terms: you built it, it is monthly, your regional manager uses it. Your material does not show what it counted. Answer slot: if it tracked volumes or resolution times, say how each was counted, in your own words; if it tracked something else, say what, plainly |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, so the tool is the pack's inference and your material does not show it. Answer slot: if you built it in Excel, say so and what you did in it, in your own words; if it was another tool, say so plainly, and describe your comfort with Excel as it is |
| F7 | "coach branch supervisors on escalations" — JD | "I trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Adjacent: the quote has tellers, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if any of that training reached supervisors or peers, say who and how, in your own words; if it was tellers only, say so plainly and stay with the tellers |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated limit. Words: "I haven't presented to anyone above regional level." Your material does not show what presenting at regional level involved, and whether regional level counts as senior leadership is the employer's call. Then a plan for how you would prepare for senior audiences, said as a plan and never as a past |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing here. Answer slot: if you have worked with any digital or product team on a member-facing process, say what it was and which part was yours; if you have not, say so plainly, and say what you would want to learn first |

## Grounding brief

From the 2026 strategy brief the recruiter sent, as you quoted it. This pack has only these four points; if the brief says more, pasting it sharpens the CO and CASE bank.

| Point | In the brief's words | Where it shows up in this loop | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | A5 in Round 1, F3 in Round 3, and the Round 2 reverse questions | [grounded] |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | Round 3 panel of branch managers; values bank on Neighbours, Not Numbers | [grounded] |
| New product | "launch a small-business lending product in Q1 2027" | Reverse questions: how its complaints will be routed | [grounded] |
| Competition | "the main competitive pressure is app-only banks" | Round 3 CO question on digital and complaints | [grounded] |

---

# Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; biography, motivation, logistics | High: recruiter-screen prior is Conversational plus a light Skeptic; the risk is treating it as unscored | Prepare a 90-second arc built only from your quoted sentences; treat casual questions about JD topics as scored; make the reverse-question slot specific |
| Skeptic (light) | Knock-out checks: the years, the contact centre, why leave | Medium: your material states two gaps (F4, F8) and a recruiter screens for knock-outs | Say the plain acknowledgment first, then the plan; do not wait to be asked twice |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses"; "I trained new tellers on our escalation script" | A 90-second arc in this order, each beat a clause the quotes state: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; the monthly complaints spreadsheet your regional manager uses; training new tellers on the escalation script. Tell them in your own words and add no outcome the quotes do not carry. Close with your own reason for this move, which is yours alone to supply | The opener every screen has; F1, F2, F5 and F7 are the sentences the arc can stand on. EXP because it tests what you actually did |
| A2 | "What draws you to a member-owned credit union?" | VAL | [grounded] values page, "Members First, Always" | Give your actual reason, in your own words. If one of the four published values genuinely speaks to you, name it by its exact title; if none does, do not pretend one does. The guidance makes no claim about your past | A casual-register question that is still scored; VAL because the published values are the raising source |
| A3 | "The role runs complaints across branches and the contact centre. Where does your experience sit against that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | First appearance of the main objection, in light form. Say what the quotes carry: "I handled the branch's formal complaints log." Then the plain acknowledgment: "I haven't worked in a contact centre." Then a plan for learning it, said as a plan; rehearse the full version in D1 | F3 and F4 are the two rows this question presses on; JD because it scores the stated requirement, gap included |
| A4 | "The role asks for 4+ years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | State it in the quote's terms: "6 years in retail banking, the last 3 as a branch supervisor." Stop there; whether it counts as customer operations is theirs to judge, and adding a description of the work the quote does not carry gives them a detail to test | F1 is the knock-out row and it is a clean one; JD because it is a stated requirement |
| A5 | "How much have digital channels featured in your work so far?" | JD | [grounded] JD line, "work with digital teams on self-service journeys" | No quote carries this, so the guidance is an answer slot. If you have worked with any digital or product team on a member-facing process, say what it was and which part was yours; if you have not, say so plainly, and say what you would want to learn first | F9 is silent in your material and the JD names it; JD because it scores a listed responsibility |
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose one of the two you have already stated and name it first: "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level." Pair it with a plan for closing it, said as a plan. Do not add a third weakness the material does not show | F4 and F8 are your stated gaps; JD because it scores honest self-assessment against the listed requirements |
| B2 | "You've been a branch supervisor. What makes you ready to look across every branch and the contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "Never worked in a contact centre" | Hold on what the quote carries: "the last 3 as a branch supervisor." Concede the contact centre with the plain acknowledgment, then the plan. Hold the position through two follow-ups by returning to the quote and the plan, not by adding scope to either | F1 and F4 together make the widest-scope objection; JD because it tests the cross-channel requirement |
| B3 | "Why leave a supervisor role for this one, and why now?" | JD | [generic] | The guidance makes no claim about your past. Give your own reason in your own words, one reason you can defend under a follow-up; avoid reasons that need facts the recruiter can check against the JD | The motivation probe a screen carries; JD because it tests the match between your direction and the role |

### Reverse questions

| Question | Why it lands |
|---|---|
| What does the 45-minute round with the Head of Member Services focus on beyond behavioural questions? | Shows you are preparing by round and may surface the format |
| For the 20-minute case in round three, is it a written scenario, a role-play, or a discussion, and is anything sent in advance? | Un-researchable format detail; it reshapes the case bank and costs the recruiter one reply |
| How does the panel score against the four values, and is there a written rubric? | Shows you take the values round seriously and may tell you what it rewards |

---

# Round 2: Head of Member Services (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes, STAR-shaped stories | High: the recruiter called the round "mostly behavioural" | Pick one story per theme where your material carries one; "we" for context, "I" for contribution; where it carries none, use the selection scaffold and its honest branch |
| Skeptic | Quiet, persistent probing of the gaps | High: this is the would-be manager, and a hiring-manager prior is Skeptic plus Case; your material states two gaps (F4, F8) | Rehearse the single predictable objection until it is boring; plain acknowledgment, then plan |
| Data-Driven Prober | Reads the experience line by line | Medium-low: the spreadsheet and the complaints log are the checkable claims | Know what you can and cannot say about what the spreadsheet counted, and say plainly where you do not know |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold, since no quote carries this story: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I built the monthly complaints spreadsheet our regional manager uses." Or say how you would handle it | The stem is a Values persona staple and the JD asks for leader-facing work (F8); VAL because it scores behaviour, not knowledge |
| C2 | "When have you put a member ahead of an internal metric or rule?" | VAL | [generic] "I handled the branch's formal complaints log" | Selection scaffold: pick a decision where the member's interest and a rule, target or convenience pulled apart, with a named stake and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I handled the branch's formal complaints log." Or say how you would decide | The published value "Members First, Always" raises it; F2 is the nearest sentence and carries no decision |
| C3 | "Tell me about a time you helped someone handle an escalation." | JD | [grounded] "I trained new tellers on our escalation script" | Story-mapped on F7: the tellers, the escalation script, the training, which are the beats the quote states; tell them in your own words. Answer slot: the JD says supervisors, so expect a probe on whether any of it reached supervisors or peers. If it did, say who and how; if it was tellers only, say so plainly and stay with the tellers | F7 is adjacent to the coaching requirement and the likeliest place a manager tests it; JD because it scores a listed responsibility |
| C4 | "Tell me about a time you showed something you had built to someone senior." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses"; "I've never presented to anyone above regional level" | Beats the quotes carry: you built the monthly complaints spreadsheet, and your regional manager uses it. Answer slot: if you ever walked a regional manager through it, say what you showed and how it was received, in your own words; if it was sent rather than presented, or the walk-through was not yours, say so plainly. Hold the limit as stated: "I haven't presented to anyone above regional level." Add a plan for senior audiences, said as a plan | F5 and F8 are where the presenting requirement presses; JD because it scores the stated requirement |
| D1 | "You've never worked in a contact centre. How would you own complaints there?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | **The highest-ROI prep in this pack.** Rehearse until it is boring, in this order. One: the plain acknowledgment, "I haven't worked in a contact centre." Two: the limit before they ask for it, with what you hold at its own scope: "I handled the branch's formal complaints log," which is one branch. Three: a plan, said as a plan and never as a past: choose the learning steps you would actually take before changing anything, and say them in order. Follow-up one will usually test credibility, so hold by repeating the quote and the plan, not by adding contact-centre experience. Follow-up two will test the plan's specifics, so answer with the sequence you chose. Then concede specifically: this is a real gap and the first thing you would close. Never describe contact-centre work, tools or metrics as something you have done | The predictable objection to this candidate, born from F4 and aimed at the role's cross-channel scope (F3); JD because it scores a stated requirement, gap included. The most follow-up levels and the exact concession wording sit here |
| D2 | "The monthly reporting here goes to senior leaders on volumes and resolution times. Where is your gap?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses"; "I've never presented to anyone above regional level" | Start with the quote: you built the monthly complaints spreadsheet, and your regional manager uses it. Answer slot: if it tracked volumes or resolution times, say how each was counted, what it is sensitive to, and the assumption you would defend least, in your own words; if it tracked something else, or you do not know how a figure was counted, say so plainly. Then the stated limit, "I haven't presented to anyone above regional level," and a plan | F5 and F8 together; EXP because it tests what the spreadsheet was and what was yours |
| D3 | "The role involves regulated complaints. What did regulation mean for how your branch handled a formal complaint?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold on the quote: "I handled the branch's formal complaints log." Answer slot: if regulatory rules or timeframes shaped how the log was kept or how a complaint moved, say which, in your own words; if no such rules applied, or the log was not where they were tracked, say so plainly and stay with the log. Do not claim a regulated process the quote does not state | F2 is the discovery row: the JD says regulated and the material says formal. JD because it scores a listed requirement |
| E1 | "Walk me through how your monthly complaints spreadsheet worked." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The quote carries: you built it, it is monthly, your regional manager uses it; say that in your own words. Answer slot: what it counted, how each figure was counted, the assumption you would defend least, and which part was yours. Where you do not know how something was counted, say so plainly. Do not describe a formula or a field the quote does not state | F5 is the one checkable artifact in your material; EXP because probers go to what is checkable |
| E2 | "How comfortable are you in Excel, honestly?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | The quote says spreadsheet, not Excel. Answer slot: if you built it in Excel, say so and what you did in it, in your own words; if it was another tool, say so plainly, and describe your Excel comfort as it truly is. Do not name features you do not use | F6 is a low-confidence inference; JD because it scores the listed Excel requirement |

### Reverse questions

| Question | Why it lands |
|---|---|
| What would you want the person in this role to have changed in the complaints process by the end of their first six months? | Turns the interview toward the first job, and the answer tells you what you are being measured on |
| How are complaints currently split between branches and the contact centre, and where does the process feel least joined up? | Surfaces the contact-centre gap as something you want to learn rather than hide, in a question about the work |
| How does the 40% digital target change what you expect of this role? | Ties your question to a figure in the strategy brief, so it reads as homework, not flattery |

---

# Round 3: panel of two branch managers (60 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The 20-minute complaint-escalation case, plus strategy questions | High: the recruiter stated a "20-minute case on a complaint escalation" | Clarify, then objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully; use Ashgrove's own words |
| Values / Behavioral | Scenario probes, one per published value | High: the recruiter said the panel is "also the values round" and scores against the four values | One story per value where your material carries one, a selection scaffold ending in its honest branch where it does not; the hard truth must actually land in the story |
| Peer Evaluator | Seam-splitting, credit, "what would you need from us" | Medium: the JD has the role coaching branch supervisors on escalations, which sets up a seam with branch managers | Reciprocity framing: what you bring their branches; propose seam principles rather than pretend to know the seam |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "A member comes in upset: their complaint has moved between the branch and the contact centre and nobody has closed it. Walk us through what you do, and what you change afterwards." | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: what the member has been told, what they need, what clock or rule applies, who holds the complaint now. Then the objective, who keeps hold of it until it is solved (the published value is "Own the Fix"), the words you use with the member, what is recorded, how the pattern reaches the monthly report, and what you change in the process. Challenge one premise respectfully. Think aloud | The 20-minute case, and the one the recruiter named; CASE because it asks for structure on a live problem set in the role |
| F2 | "Complaint volumes at one branch have risen sharply over two months. Diagnose it." | CASE | [generic] | Makes no claim about your past. Clarify first: what counts as a complaint, which channel, which category, since when. Segment by branch, product, channel and cause; state two or three hypotheses and the check for each; say what you would do before the next monthly report. Use the plain-words test: if the explanation needs saying twice, rewrite it | A metric-diagnosis case on the JD's monthly volumes line (F5's requirement); CASE because it scores reasoning on a number you do not yet have |
| F3 | "Ashgrove wants to move 40% of member service to digital channels by 2028, and app-only banks are the main pressure. Which complaints should never be handled in a digital channel alone, and why?" | CO | [grounded] strategy brief, "move 40% of member service to digital channels by 2028"; "the main competitive pressure is app-only banks" | Makes no claim about your past. State your assumption about what the brief means before you answer; segment complaints by what the member needs (a fast fix, a human explanation, a formal route); give a view and one concession. Name what you would want to know from the digital team, since F9 is an answer slot and you should not imply digital experience the material does not carry | Grounded in the brief you were sent; CO because it tests whether you can think at the company's altitude, and it is the differentiator most candidates cannot touch |
| F4 | "Over 2027 Ashgrove consolidates eight branches into five hubs. What does that do to complaints, and what do you protect?" | CO | [grounded] strategy brief, "consolidate eight branches into five hubs over 2027" | Makes no claim about your past. Treat it as a hypothesis, not a fact about the panel's views: ask what is known about which complaints move with a closing branch, then name two things you would protect and why. Tie one of them to the published value "Neighbours, Not Numbers" in its own words. Do not assume the panel's feelings about the change | The panel is branch managers and the brief is about branches; CO because it scores strategy fluency without presupposing anything about you |
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] "I handled the branch's formal complaints log" | Selection scaffold: pick a decision where the member's interest and a rule, target or convenience pulled apart, with a named stake and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I handled the branch's formal complaints log." Or say how you would decide | Covers "Members First, Always": "we decide from the member's side of the counter." F2 is the nearest sentence and carries no decision |
| G2 | "Tell me about a time something you wrote or said had to be explained twice. What did you change?" | VAL | [generic] "I trained new tellers on our escalation script" | Selection scaffold: pick a time where wording failed a member or a colleague and you changed the wording. Answer slot: if the script or any member-facing wording was ever reworded because it needed explaining twice, say what and by whom; if not, say so plainly. If no such time comes to mind, give the nearest thing your material does carry: "I trained new tellers on our escalation script." | Covers "Plain Words": "if a member needs it explained twice, we wrote it wrong." F7 is the nearest sentence and says nothing about rewording |
| G3 | "Tell me about a time you let a local circumstance change how you applied a standard process." | VAL | [generic] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold: pick a case where the town, the member or the branch context justified a departure, with the stake and the limit you held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "6 years in retail banking, the last 3 as a branch supervisor." Or say how you would decide | Covers "Neighbours, Not Numbers": "every branch is part of its town." F1 is the nearest sentence; it carries tenure, not a story |
| G4 | "Tell me about a problem you found that was not yours to fix. What did you do?" | VAL | [generic] "I handled the branch's formal complaints log" | Selection scaffold: pick a time where you found something and kept hold of it until it was solved, with what you did at each stage. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I handled the branch's formal complaints log." Or say how you would hold it | Covers "Own the Fix": "whoever finds the problem keeps hold of it until it is solved." The JD's "Own the member complaints process end to end" raises it too (F3) |
| H1 | "You would coach branch supervisors on escalations. Where is the seam between your job and a branch manager's, and what happens when we disagree?" | JD | [grounded] "the last 3 as a branch supervisor"; "I trained new tellers on our escalation script" | Reciprocity first: what you bring their branches. Propose two seam principles for them to react to, rather than claiming to know the seam; choose ones you believe, since you will be asked why. Use only what the quotes carry about your past: "the last 3 as a branch supervisor" and "I trained new tellers on our escalation script." Answer slot: a disagreement you handled with an equal, if one comes to mind, in your own words; if none does, say so plainly and say how you would raise one | F7 and F1 are the only sentences about working beside others; JD because the coaching line creates the seam, and the Peer persona scores partnership fit |
| H2 | "A complaint spans a branch and the contact centre and it goes wrong. How do you handle credit and blame?" | JD | [generic] | Makes no claim about your past. Principle first (the person who finds it keeps hold of it, per the published value "Own the Fix"), then who is told, what is recorded, how the fix is credited to the people who did it. Show spine and tact together | The cross-team scenario a peer interviewer reaches for; JD because it scores the ownership requirement across channels |

### Values / principles cheat sheet

The values below are the page you pasted, copied from ashgrovecu.org/about/values on 11 November 2026. The recruiter's "the panel is also the values round" is the loop source that makes this section apply.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | No quoted sentence carries a story. Nearest: F2, "I handled the branch's formal complaints log". Scaffold in G1, ending in its honest branch |
| Plain Words | If a member has to be told twice, the wording failed | No quoted sentence carries a story. Nearest: F7, "I trained new tellers on our escalation script". Scaffold in G2, ending in its honest branch |
| Neighbours, Not Numbers | Each branch belongs to its town | No quoted sentence carries a story. Nearest: F1, "6 years in retail banking, the last 3 as a branch supervisor". Scaffold in G3, ending in its honest branch |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No quoted sentence carries a story. Nearest: F2, "I handled the branch's formal complaints log". Scaffold in G4, ending in its honest branch |

### Reverse questions

| Question | Why it lands |
|---|---|
| What could a new complaints lead do in their first month that would genuinely help your branches? | The reciprocity question for panel members who run branches; it puts their load first |
| How do you want complaints from the new small-business lending product, due in Q1 2027, to be routed between branches and the contact centre? | Ties your question to a dated move in the strategy brief, so it reads as homework |
| When a branch moves into a hub over 2027, what should stay local in how its complaints are handled? | Connects "Neighbours, Not Numbers" to the consolidation without presuming how the panel feels about it |

---

## Prohibited claims

What this pack will not coach, with its basis and the honest form. Built before the banks, and every guidance cell above is written against it.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says the log, not the process. Slots in A3 and D1 stay inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says the branch's formal complaints log and does not show whether regulation applied. D3's slot stays inside the log |
| Reported on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says the monthly complaints spreadsheet and does not show what it counted. D2 and E1 ask only what it counted |
| Built Excel reports | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says spreadsheet, not Excel. E2's slot asks only about the tool |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material says new tellers, not supervisors. C3's slot stays with the tellers |
| Has contact-centre experience | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD; the values page you copied from ashgrovecu.org/about/values on 11 November 2026; the recruiter's email about the process; the four points you quoted from the July 2026 strategy brief; your background as written in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet: the pasted values page supplies the four names and their wording |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the loop or persona weights: the recruiter's email fixes the three sessions, who runs each, their lengths, the case and the values scoring |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO bank: the July 2026 brief points you quoted supply the digital target, the hub plan, the lending launch and the competitive frame |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what a name would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewers' names once assigned → an interviewer read, persona weights per panel member, and a reverse question tied to their own path
- One real episode, a sentence or two each, for Members First, Plain Words, Neighbours Not Numbers and Own the Fix → G1 to G4 and C1, C2 become story-mapped instead of scaffolds, and the cheat sheet regenerates
- Whether the formal complaints you handled fell under regulator rules or timeframes, and which → F2 and D3 move from discovery to graded; an anonymised extract of the log's columns would raise its confidence band
- What the monthly spreadsheet counted, whether it was built in Excel, and whether you know how each figure was counted → F5, F6, D2, E1 and E2 move out of answer-slot form; an anonymised screenshot of its layout would raise the band
- Whether any of your escalation training reached supervisors or peers, and whether you have worked with any digital or product team on a member-facing process → F7, F9, C3 and A5
- The full text of the 2026 strategy brief → richer CO and CASE questions beyond the four points you quoted
- One email to the recruiter: the format of the 20-minute case, whether regional level counts as senior leadership for the presenting requirement, and logistics (pay band, location, notice) → case bank shaped to the format, F8 re-read, and nothing assumed about gates the material is silent on
- Time you have to prepare → a prep triage ordered to your hours
- A deeper research pass is available: up to 6 more searches and 2 more fetches, several more minutes, for interviewer footprints and recent organisation context once names exist; say "deeper pass" and I will run it
- A `tuesday-dossier.md` from a job-fit assessment would carry verified evidence and the objection to rehearse most, so the strategy for weak areas stops being inferred
