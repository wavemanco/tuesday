The prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-1-denied-e15f48ae/Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`.

The pack has 22 questions in seven persona banks, each tagged by type with answer guidance and a rationale. It is built for one 60-minute peer conversation with Dan. My three web searches (values, loop, Dan's footprint) were not permitted, so the pack comes only from what you gave me. The Sources section records this.

- **Persona weights:** Peer Evaluator and Data-Driven Prober lead at 5 questions each, because Dan is a peer and calls himself data-driven.
- **Highest-ROI prep:** C1, the Skeptic question on her having no sales-ops or quota-setting experience, and its time-boxed twin F2. Dan is the person most likely to find that gap.
- **Next most important:** B1, defending the ~$400M ARR figure. The guidance holds only what you said: she proposed the change and it was credited with the uplift. The rest is left for her to answer in her own words.
- **Not coached:** The pack lists claims Priya shouldn't make, such as owning GTM for a new product, designing a partner motion, calling her volume targets "quotas", or building AI products.
- **Dropped sections:** The values cheat sheet, graded deliverables, prep triage, grounding brief and delivery coaching are left out because their conditions weren't met.

I can play the Skeptic on C1 as a live drill, with follow-ups and feedback against the pack's guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

1. Can you paste the full JD text and Priya's CV? The requirement rows are currently your summary of the posting, and her evidence is your description, so the quotes would upgrade.
2. Did the recruiter give any focus areas or announce a deliverable (a POV, a presentation, a take-home)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer, both reporting to the same VP. **Round:** one 60-minute conversation.
Built from your message alone: web research was not permitted in this session, so nothing here comes from a fetched page. Every row says where it stands.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say only what you actually did, in your own words. Anything marked "Answer slot" is an instruction for the interview, not a question for you now.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether CV claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge, thought at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

Requirements are the JD highlights as you relayed them in your message, so they are your summary, not the posting's own words. Evidence cells hold your description of Priya, verbatim. No row is a hard_gate: none of the highlights you gave is a term such as authorization, licence, location, pay or travel.

Proposed language in this section is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message; "9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material says a proposal credited with an uplift, not go-to-market ownership, and the words stay there: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's two-new-lines line makes a probe on whether any of that work was go-to-market likely. If any was, say how and what part was yours, in your own words; if it was not, or was not yours, say so plainly and stay with the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | Your material does not show work across these stages. Answer slot: if any analysis you did looked at how customers or partners move between stages like these, say what and how, in your own words; if none did, say so plainly and say where you would look first |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | discovery | The material states the skill, not an analysis. Answer slot: a probe on one analysis run start to finish is likely (B4). If you ran one yourself, say which and what you decided from it; if others ran the analyses, or you used the tools differently, say so plainly and stay with "I'm skilled in SQL and Tableau" |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not a designed motion: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if the model shaped how a partner arrangement was structured and you had a part in that, say what; if it informed the negotiation only, or the structuring was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on how the consensus formed (A1, A5). Lead with the quote's own terms: you set the targets, with cross-org consensus |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | presentation | The quote reaches the plus in other terms and stops at use: "I use AI tools daily." Nothing added; the material does not say you built anything with them |
| F7 | Sales-ops or quota-setting background — no JD highlight raises it; listed because you named the absence (generic role-family expectation) | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have no classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Reading the interviewer

Public footprint only; searches for more were refused, so these rows rest on the profile as you described it.

| # | Signal, verbatim | Implication | Provenance | Used in |
|---|---|---|---|---|
| I1 | "relentlessly data-driven" — profile self-description, your message | Probe up: expect every number to be walked to its assumptions | [inferred] | B1 to B5 |
| I2 | "career spine is pricing and monetization roles" — your message | Tilt cases toward pricing, packaging and unit economics | [inferred] | D2, A4 |
| I3 | "one early-stage-startup chapter" — your message | Mild signal: expect a pace-and-scrappiness probe against a long single-company tenure; a builder story lands only if your material carries one | [inferred] | C3 |
| I4 | "Director of Sales Strategy" and "PEER, both reporting to the same VP" — your message | Seam, credit and what-do-you-need-from-me questions arrive collegially; F7 is the area he would know best | [inferred] | A1 to A5, C1 |
| I5 | Mirror: his monetization spine beside F4's quote "built a partner-level revenue model used in carrier negotiations" | A shared vocabulary of revenue and negotiation; use it to ask about his work, not to claim equivalence | [inferred] | R2 |

No shared career jump is offered: nothing in the material shows his path matching hers.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (A, 5 questions) | Seam-splitting, credit, "what would you need from me" | Highest. Peer is this persona's relationship prior; I4 supports it | Reciprocity framing; seam principles, not a pretended seam; speak of your own work only in F5's quote |
| Data-Driven Prober (B, 5) | Walks each number and the analysis behind it | Highest. Peer prior plus I1 | Know what you can and cannot say about how each number was counted; say plainly when you do not know; name your weakest assumption first |
| Skeptic (C, 3) | Quiet probing of F7, F4 and the move from consumer tech | Mid. The gaps are real (F7) but a peer asks them collegially. Depth here is the pack's highest-ROI prep regardless of weight | Rehearse C1 until boring; bridges only from F5 and F4 quotes; a plan, not a past |
| Case / Strategist (D, 3) | Live problems on Northwind's priorities | Mid. One conversation with a peer, so less case-led; I2 tilts it toward pricing | Clarify, objective, segment, approach, metrics, risks; challenge one premise |
| Conversational (E, 2) | Biography opener; AI question asked casually | Low to mid. Opens most conversations; the AI plus (F6) is asked casually | A 90-second arc; treat the casual AI question as scored |
| Pressure (F, 2) | Time-boxed attribution challenge | Low. Peer relationship, but the headline number invites it | Hold, then concede specifically |
| Values / Behavioral (G, 2) | Unpopular-truth and customer-first stories | Low. No values-style round is documented for this loop (your message names one conversation); persona stems only | Selection scaffolds ending in the honest branch |

## Question banks

The highest-ROI prep in this pack is C1, with F2 as its time-boxed twin: this objection will arrive in some form, and F7 is the gap you named. Second is B1, the headline number.

Proposed language in this section is pending your approval.

### A. Peer Evaluator (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where is the seam between GTM strategy for the new lines and Sales Strategy, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Offer seam principles, not a pretended seam: who owns the number, who owns the motion, how a disagreement gets raised and settled. Then one line from your own work, in the quote's terms: you set annual volume targets, with cross-org consensus. Answer slot: a probe on how the consensus formed is likely. If orgs disagreed, say what and what part was yours; if they did not, or the process was not yours, say so plainly and stay with the quote | F5 is the evidence for influence, and a peer prices it against his own work. JD because it scores the stated influence line; peer delivery from I4 |
| A2 | "Say you start tomorrow owning GTM for the two new lines. What do you do in the first 30 days, and what do you need from me?" | JD | [generic] | Lead with reciprocity: what you bring his team first, then what you need. Plan shape, not a past: learn how Sales Strategy works today, set a hypothesis for each line, agree the seam principles from A1. No claim about your history is needed, so none is made | F1 is the requirement; a peer hears this as how the hire changes his load. JD because it scores owning GTM; `[generic]` because it is a pattern, not a Northwind fact |
| A3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams and you shared credit; it needs the other team named, what you attributed to them and what you took for yourself. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The persona's credit stem; a peer prices this. VAL because it scores behavior, not a JD line |
| A4 | "A new line has no history. How should its first targets be set, and who should be in the room?" | CASE | [grounded] "set annual volume targets with cross-org consensus" | Structure: clarify the motion and what comparables exist, objective, segments, approach, who signs off, how you would revisit it. If you cite your own work, stay with the quote. The pack's note, not a line for you: your material says volume targets, not quotas, so do not use the word for yours | F5 and F7 meet here, and I2 makes target-setting native to him. CASE because no past is presupposed |
| A5 | "Where could GTM strategy for new lines create extra work for Sales Strategy rather than remove it?" | JD | [generic] | Name two honest friction points and how you would pre-empt each, then ask him which are real. Making none up for the Northwind org: frame them as hypotheses to test with him | Peer evaluators score whether the hire adds to their load; F5's cross-functional line is the requirement. JD, peer delivery |

### B. Data-Driven Prober (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that ~$400M ARR number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold what the quote carries: you proposed the change, and the uplift was credited to it. Answer slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Never explain a method you cannot repeat under a second question | F1 holds your only figure, and I1 says it gets walked. EXP because it scores whether the claim survives |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name it before he does. Answer slot: the assumption is yours to name; if you do not know which assumption was weakest, say so plainly and say what you would check first. The pack names none | The persona's own stem, the second level of B1; naming it converts a gotcha into credibility. EXP |
| B3 | "Walk me through how you built the partner revenue model." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: you built it, it was partner-level, it was used in carrier negotiations. Answer slot: the JD's independent-analysis line makes a probe on the build likely. If you wrote the queries or dashboards yourself, say which and in what tool; if others did, or there was no such step, say so plainly and stay with the model | F4 and F3 both lean on it. EXP, with JD content |
| B4 | "Show me an analysis you ran yourself, start to finish, in SQL or Tableau." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick one where you wrote the query and made the decision it fed; say the question, the data, what you chose. If none comes to mind, say so plainly, then stay with "I'm skilled in SQL and Tableau" or say how you would approach it. Offering to walk one end to end is the strong move if one exists | F3 is the JD line he can test directly. JD, prober delivery |
| B5 | "Sign-ups for a new line are up but adoption is flat in month three. Diagnose it." | CASE | [generic] | Clarify first (what counts as adoption, which segments), then split by segment, stage and channel, name the three metrics you would pull, and state the decision each would change. Think aloud; challenge one premise | A diagnose-it problem in his data register, touching F2's land and adopt stages. CASE; `[generic]` because it is a pattern, not a Northwind fact |

### C. Skeptic (weight mid; deepest rehearsal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see sales-ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" and "built a partner-level revenue model used in carrier negotiations" | Start with the acknowledgment: "I have no classic sales-ops or quota-setting experience." Do not wait for him to find it. Then the adjacent work at its own scope: you set annual volume targets with cross-org consensus; you built a partner-level revenue model used in carrier negotiations. Follow-up 1, "so who sets the number for a new line?": give the A4 structure and name who you would learn from. Follow-up 2, "and if your first plan is wrong?": concede it specifically, say what you would watch first, and do not fold on what the quotes carry. Ramp plan in your own words: who you would learn from, what you would read, what you would not change until you understood it. Do not bluff a competency he works in | F7 is the gap you named and the most predictable objection; I4 puts it in his lane. JD because it scores the stated role; Skeptic because it probes the gap |
| C2 | "Partner-motion design is required here. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only the quote: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if the model shaped how a partner arrangement was structured and you had a part, say what; if it informed the negotiation only, or the structuring was not yours, say so plainly and stay with the model. Hold through two follow-ups by returning to the model, never by adding to it | F4 is a transferability row against a required line, so this is asked in some form. JD, Skeptic delivery |
| C3 | "Why leave a large consumer-tech company for B2B data infrastructure, and why now?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | The reason is yours: the pack supplies none. Answer slot: say your actual reason in two sentences, then what in this role you would own. Expect a pace follow-up from I3: if you have worked in a small-team or early-stage setting, say so; if not, say so plainly and say how you would operate at that pace | Motivation consistency is what a Skeptic scores, and I3 adds the pace probe. JD because it tests role fit; no dedicated type exists for motivation |

### D. Case / Strategist (weight mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Northwind's stated priorities are enterprise expansion, the Compass copilot launch and reaching profitability. Which pulls hardest on GTM for a new line?" | CO | [grounded] your research note: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Structure: say which you would weight and why, what each implies for the new line, how you would test the tension between launch spend and profitability, and what you would want to know first. Challenge one premise politely. No claim about your past is needed, so none is made | The user's research note supplies current priorities; this is the company-strategy question the rubric requires. CO, with CASE delivery |
| D2 | "A much larger platform vendor bundles a competing capability into its suite at no extra charge. How does that change your land motion?" | CASE | [grounded] your research note: "bundling by a much larger platform vendor" | Clarify (which line, which buyers), objective, segment by buyer already on the larger platform, then choices on positioning and packaging, metrics, risks. Pricing and packaging angles suit I2. Think aloud | The research note names this as the main threat, and I2 makes it his native ground. CASE with CO content |
| D3 | "For a line with no history, where would you look first for whitespace across land, adopt, expand and renew?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | Clarify what the line does and who buys it; split the four stages; pick the stage where the least is known and say why; name the data you would pull and the decision it changes. The question needs no claim about your past | F2 and F1 are the requirements; JD content, CASE delivery |

### E. Conversational / Rapport Builder (weight low to mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc in your own words: two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Add why this role in one sentence of your own; the pack supplies no reason | Biography is the most likely opener, and F1 is the row it frames. EXP, rapport delivery |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say which tools and for what, in your own words. Answer slot: if any of it goes beyond using the tools, such as building something with them for others, say what; if it is use, say so plainly and stay with "I use AI tools daily". Then ask him a question about Compass as curiosity, not as a claim | F6 is the JD plus, asked casually. JD content, Conversational delivery |

### F. Pressure (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate the question. Hold: you proposed the change; the uplift was credited to it. Hold through two follow-ups. Concede specifically: what you do not know about how the credit was assigned. Answer slot: which part was yours, in your own words; if you cannot separate it, say so plainly | The persona's own stem, aimed at the only figure in F1. EXP |
| F2 | "Sixty seconds: why you rather than someone who has carried a quota?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | Pause. "I have no classic sales-ops or quota-setting experience." Then one sentence from the quotes: you set annual volume targets with cross-org consensus. Stop; do not fill the silence with more. Hold through two follow-ups; concede what you would need to learn | Time-boxed twin of C1; F7 and F5. JD, Pressure delivery |

### G. Values / Behavioral (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where the hard truth actually landed and the relationship was intact; it needs a named stake and your own role. If none comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The persona's own stem; no published Northwind values were read, so this themes on the stem alone. VAL |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold: pick a decision where the customer cost you something internally; name the metric and what you did. If none comes to mind, say so plainly | The persona's own stem. VAL; low weight because no values round is documented |

### Requirement coverage

| Requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | A2, D1, D3 |
| identify whitespace across land/adopt/expand/renew | D3, B5 |
| run independent analysis in SQL and Tableau | B3, B4 |
| partner-motion design experience required | C2, B3 |
| strong cross-functional influence | A1, A5 |
| AI experience a plus | E2, D1 |
| Sales-ops or quota-setting (named by you, F7) | C1, F2, A4 |
| Headline number (~$400M ARR uplift) | B1, B2, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity for a peer: it shows you think about his load before your own |
| R2 | "You have spent your career in pricing and monetization, with one stretch at an early-stage startup. What did that chapter change about how you think about monetization at this size?" | Tied to his own path (I2, I3); turns the interrogation into a peer conversation |
| R3 | "Where is the line between Sales Strategy and GTM strategy for the new lines today, and where is it still unsettled?" | Uses A1's seam principles and invites him to define the territory |
| R4 | "How is the bundling pressure from the larger platform vendor showing up in the deals you see?" | Rests on the research note's competitive frame; shows homework and asks for his view |
| R5 | "How does Compass change how you think about packaging across the product lines?" | Connects a stated priority to his pricing spine |
| R6 | "A year from now, what would tell you the hire in this seat worked?" | Gets his own success measure on the table, the one you will be held to |

## Prohibited claims

Not coached in any answer, bridge or drill. Built from the fit snapshot; no dossier supplied one.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or launched go-to-market for a new product | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a proposal, not GTM ownership. A slot stays inside the proposal |
| Caused or single-handedly produced the ~$400M ARR uplift | Inflated form of F1 | "credited with" at its own scope. B1, B2 and F1 ask only how it was counted, what it is sensitive to, the weakest assumption and which part was yours |
| Designed a partner motion | Inflated form of F4 | F4's quote: the model, used in negotiations. C2's slot stays with the model |
| Has quota-setting or sales-ops experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I have no classic sales-ops or quota-setting experience." No slot |
| Called the annual volume targets quotas | Inflated form of F5 | F5's quote at its own scope: "set annual volume targets with cross-org consensus". The limit is the pack's observation: the material says targets, not quotas |
| Built or shipped AI products or features | Inflated form of F6 | F6's quote: "uses AI tools daily". The limit is the pack's observation: the material says use |

## Sources

Provided documents: your message (role and company, JD highlights, Priya's background, Dan's profile description, your research note on priorities and the bundling threat). No dossier was present.

Searches sent, all refused (no permission was granted in this session):

- `Northwind Data B2B data infrastructure company values principles` — refused
- `Northwind Data interview process strategy GTM role` — refused
- `Dan Kovac Northwind Data Director Sales Strategy` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Would have named published values for VAL themes and a values cheat sheet; G1 and G2 use persona stems instead |
| 2. `Northwind Data interview process` | unavailable | Would have confirmed loop structure; persona weights follow your one-conversation description |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies current priorities and the competitive frame; D1, D2, R4 and R5 draw on it |
| 4. `Dan Kovac Northwind Data` | unavailable | Would have added his published talks and writing to the interviewer read; it rests on your description |
| 5. representative role JD | skipped | The JD highlights you supplied fix the fit snapshot and JD-tagged questions |

## Upgrade menu

- Full JD text → the six requirement rows become the posting's own words, and any mid-list item you left out becomes a question
- Priya's CV → evidence cells quote it instead of your description; for strategy work, the revenue model workbook or the write-up of the store-surface proposal would be the inspectable artifacts that raise medium to high
- Her answers to the slots in F1, F2, F3 and F4 (said outside a drill) → those rows regenerate from her own words, and B3, B4 and C2 upgrade from slots to story maps
- Permission to search → the values page, loop structure, and Dan's public footprint, which would upgrade the interviewer read and persona weights
- Recruiter or HR guidance on focus areas or a pre-announced deliverable → coverage beyond round-type priors
- A tuesday-dossier.md from an earlier fit assessment → verified evidence and a named top objection in place of this pack's inferred one
