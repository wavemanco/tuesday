Web search was declined, so I'm building the pack from your message and the JD alone, with company-specific parts marked generic. Saving it now.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-2-denied-2c4f7bb2/atlas-freight_operations-manager_interview_pack.md`.

It has 20 questions across seven interviewer styles. Because I don't know who you're meeting or which round it is, the weights are even across styles and rest on a generic pattern, not on Atlas Freight's actual process.

My web searches were declined, so the pack uses only your message and the JD. Nothing in it comes from Atlas's website, so the company-specific questions (why Atlas, strategy) are generic scaffolds. The pack has no values cheat sheet, since I couldn't find Atlas's published values.

The question the pack names as your highest-ROI prep is B1: going from three supervisors to twelve across four sites. Your other main gaps are warehouse versus terminal work, how many of your seven years were spent leading people, and Power BI. The pack tells you to say plainly that you've never used Power BI and to give a plan for learning it, in the future tense.

Say the word and I'll run a live mock on B1, playing the skeptical interviewer.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is your first interview with a recruiter, your future manager or a peer on the team, and did the recruiter mention any format such as a presentation, case or site walk? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

## 1. Title block

- Role: Operations Manager (regional logistics, 800 employees, four sites, twelve supervisors), per the JD you pasted.
- Interviewer and round type: not known. Persona weights are therefore flat in kind, and the depth each persona gets follows where the JD's lines and your gaps press hardest. They rest on a generic pattern, not on Atlas Freight's documented process.
- Built from: the JD and your message. No CV, no dossier, and no company research (see Sources).
- Highest-ROI prep in this pack: B1, the step from three supervisors to twelve across four sites.

## 2. How to use this pack, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer of 90 to 120 seconds, not a script. Lines in double quotation marks under Provenance are your own words from your message; say only what those words say, in your own voice.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth, and why this company |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## 3. Prep triage

In this order, rehearsing aloud:

1. B1 and G1: the scale concession and the attribution hold. These are the questions most likely to decide the interview.
2. C1 and C2: decide, in your own words, what you can and cannot say about how the 40% was counted.
3. A4 and B4: settle your honest Power BI answer and a first step you would actually take.
4. A1 to A3: say each case structure aloud once.
5. E1, E2, D3 and the reverse questions in section 11.

Everything else is insurance.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message, "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution work, a shift-manager role and the site's surge plan, with nothing inspected behind it, so the words stay there: "I'm a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's daily-ownership line makes a probe on what you set day to day likely. If you set any part of the daily plan, say which and how you decided, in your own words; if it was set for you, say so plainly and describe what you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate is a different measure from the two the JD names, and the bridge does not stretch it: "I cut mis-pick rate 40% by redesigning the pick path." The figure raises its own slots, each answered in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. "I don't know how it was counted" is an honest answer. Answer slot: if the pick-path work was measured on anything besides mis-pick rate, say what and how; if it was not, say so plainly and stay with the mis-pick figure |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote carries three supervisors and the JD says twelve, so the words stay at three: "I'm a senior shift manager over 3 supervisors." The concession that follows from the two numbers: "Twelve is more than the three I lead now." Answer slot: the JD's twelve-supervisor line makes a probe on how you lead the three likely. Say what you set for them and what you leave to them, in your own words; if you set all of it, or it is set above you, say so plainly and describe how you lead the three |
| F4a | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" names a skill, not what was built with it. Answer slot: if you built reports that others relied on, say what and for whom; if it was your own analysis, or none of it was reporting, say so plainly and stay with "solid Excel" |
| F4b | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so yourself. Words: "I've never used Power BI." Then how you would get to working use, said as a plan in the future tense and never as a past. The JD's slash between the two tools does not say whether both are required, which is a question for the interviewer (R4) |
| F5 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Seven years in operations is on the page; how many of them were spent leading people is not, and this pack does not resolve that upward. Not a gate, but a years line can be checked by arithmetic, so expect the question. Answer slot: say when you started leading people and what you led then, in your own words; if you cannot put a number on it, say so plainly and stay with the seven years in operations and the three supervisors you lead now |
| F6 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification with nothing inspected behind it, so expect a probe on what the certificate names and how it was used. Lead in the quote's own terms: "I'm green belt certified." C3 rehearses the application probe |

## 5. Persona table

The persona weights below rest on the generic archetype (screen, hiring manager, panel) with flat weights, because no loop source was read and no round type was given. If you learn the round, the weights shift.

| Persona | How it shows up | Likelihood, with the reasoning shown | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems on on-time performance, cost and reporting | Depth 4 (4 questions). The JD's own lines are operational, so live problems are likely; weight rises if the round is a hiring manager. [inferred] from the JD | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of three versus twelve, warehouse versus terminal, years led, Power BI | Depth 4. F1, F3, F4b and F5 are the snapshot's biggest gaps, and this persona goes where the gaps are. [inferred] from the snapshot | Rehearse B1 until it is boring; bridge only from what you said; give a concrete ramp plan; admit the stated gap plainly |
| C. Data-Driven Prober | Line-by-line questions on the 40% and the green belt | Depth 3. You have one headline metric and one certification, both of which a prober tests; weight rises if the round is a peer. [inferred] | Know what you can and cannot say about how the figure was counted; name the assumption you would defend least before they do |
| D. Values / Behavioral | Scenario stories: an unpopular truth, an underperforming supervisor | Depth 3. No values-style round is detected: no loop source was read, and the generic archetype's values-round column reads no. The questions are therefore generic scaffolds | A story from your own experience with a named stake, "we" for context and "I" for contribution; the honest branch when none comes to mind |
| E. Conversational | The opener and why-here | Depth 2. Weight rises sharply if the first round is a recruiter screen. Casual-register questions are still scored | A pre-scripted 90-second arc; treat the casual questions as scored |
| F. Peer Evaluator | The seam between teams, credit, disagreement | Depth 2. Weight rises if you meet someone on the team as a peer | Propose seam principles rather than pretending to know the seam; reciprocity framing |
| G. Pressure / Stress | Time-boxed answers and attribution challenges | Depth 2. Weight rises for a skip-level or executive round | Pause, restate, anchor in what you said, hold through two follow-ups before conceding anything real |

## 6. Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The JD asks you to drive on-time performance and cost per shipment down. Which would you go after first, and how would you find what is driving it?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Structure it aloud: agree with the interviewer what each measure counts, pick one and give a reason, name what you would look at to find its drivers, and say how you would know it moved. If you reach for your own work, the words are the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if the pick-path work was measured on anything besides mis-pick rate, say what and how; if it was not, say so plainly and stay with the mis-pick figure | F2 is the evidence for the JD's two headline measures and the likeliest place to be asked what you have actually moved. JD because it scores a stated requirement; the delivery is case-style |
| A2 | "Cost per shipment at one terminal is up this quarter. How do you tell a real cost problem from a volume or mix effect?" | CASE | [generic] | Ask what the measure's top line holds and what its bottom line counts. Split the change into volume, mix and rate, say what you would check first and what would change your mind, and challenge one premise in the question. The question needs no claim about your past, so the guidance makes none | A live problem from F2's requirement; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A3 | "On-time performance at one of the four terminals has slipped for three weeks. Walk me through your first two days." | CASE | [generic] | Clarify what counts as on time and whether the slip is real or a change in measurement, state the objective, segment where it slips, say your approach and the metrics you would watch, and name the risks. Think aloud. The guidance makes no claim about your past | A live problem from F2's requirement and the JD's four sites; generic for the same reason as A2 |
| A4 | "Suppose you take over four terminals that each report their own way. What do you build first, and in what tool?" | JD | [grounded] "solid Excel", "never used Power BI" | Choose by the decision the report serves: who reads it, how often, and what they would do differently. Say which tool you would pick and why. For Excel the words are the quote: "I have solid Excel." Answer slot: if you built Excel reports that others relied on, say what and for whom; if it was your own analysis, or none of it was reporting, say so plainly and stay with "solid Excel". For Power BI the words are: "I've never used Power BI." Then a plan in the future tense: your first step and how you would know you had it | F4a and F4b are this requirement's evidence. JD because the posting names both tools; the hypothetical makes it a case in delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have three supervisors now; this role has twelve across four sites. What changes at that scale, and where would you be stretched?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only the quote: "I'm a senior shift manager over 3 supervisors." Concede the step once, specifically: "Twelve is more than the three I lead now." Then give a ramp plan in your own words: what you would learn first about the twelve and the four sites, and how you would find out. Hold through two follow-ups by returning to the three you lead, never by adding scale to them. Answer slot: the JD's twelve-supervisor line makes a probe on how you lead the three likely. Say what you set for them and what you leave to them; if you set all of it, or it is set above you, say so plainly and describe how you lead the three | F3 is the widest distance between the JD's number and your evidence, so this objection arrives in some form. JD because it scores the stated requirement; the Skeptic delivers it |
| B2 | "The role is terminal operations and your background is warehouse and distribution. What carries over, and what would you need to learn first?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say what you have in the quote's terms: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's terminal-operations line makes a probe on what carries over likely. If any part of your work matched part of what the JD lists as terminal operations, say which part and how, in your own words; if none did, say so plainly and stay with warehouse and distribution. Then give the learning plan: what you would ask to be shown first, as a plan | F1 is where the JD's wording and your wording differ in kind, not only in degree. JD because it scores a stated requirement |
| B3 | "Five or more years of operations leadership is required. How many of your seven years were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | Say what is on the page: "I have 7 years in warehouse and distribution ops, and I'm a senior shift manager over 3 supervisors." Answer slot: say when you started leading people and what you led then, in your own words; if you cannot put a number on it, say so plainly and stay with the seven years in operations and the three supervisors you lead now. Do not round the leadership years up to the seven | F5 is the line an interviewer can check by arithmetic. JD because it scores the stated years requirement |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick a real weakness, not a disguised strength. The one your own words state is the Power BI half of the reporting line: "I've never used Power BI." Follow at once with the plan: your first step, who you would ask, and how you would know you had it, in the future tense. Scale (B1) is the other honest answer; whichever you choose, do not switch under pressure | F4b is a gap you stated yourself, which makes it the safest honest answer to this question. JD because it scores the posting's own list |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before they ask; which part was yours. "I don't know how it was counted" is an honest answer; say it plainly and say what you do know. Give a baseline or period only if you know it | F2's headline metric. Every CV number draws a defend-the-number question; EXP because it tests what the figure rests on |
| C2 | "How did you know the pick-path change was what moved the number?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the quote, then the slot: if you compared before and after, or checked the result against anything else, say what; if you did not, say so plainly and return to what the redesign was. Hold through two follow-ups without adding detail you do not have | F2's sensitivity. Probers go two levels deeper than the first answer, and this is level two |
| C3 | "Walk me through a project where you used your green belt." | JD | [grounded] "green belt certified" | Say the quote: "I'm green belt certified." Answer slot: the JD's Lean/Six Sigma line makes a probe on application likely. If you used the green belt's methods on the pick-path redesign or on another project, say which and how, in your own words; if the certification was not used on a project, say so plainly and say what it covered | F6. JD because Lean/Six Sigma is a stated plus; it is also an experience deep-dive on a certificate |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to a manager or a team." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a working relationship intact afterwards. "We" for context, "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common behavioral stem. Generic because no company values were available to theme it |
| D2 | "Tell me about a time a supervisor of yours was not delivering. What did you do?" | VAL | [generic] | Selection scaffold: pick a specific gap you noticed, a conversation you had, and an outcome you can state without embellishing. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3's requirement is leading supervisors, which raises this theme. Open prompt, so it supplies no event |
| D3 | "Walk me through the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The beats are the ones the quote states: the plan, peak season, the site, two years running. Say it in your own words: "I ran the site's peak-season surge plan two years running." Say what the plan was for and what you did. If they ask what the plan covered or what changed between years, answer from what you know and say plainly what you do not; the pack supplies no stages, numbers or outcomes | F1's strongest quote. A plan run twice invites follow-ups; EXP because it tests what was actually yours |

### E. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | A 90-second arc. Open on "7 years in warehouse and distribution ops" and close on where you are now, "a senior shift manager over 3 supervisors". The roles and dates in between are yours to fill; this pack does not know them. End with why this role, in your own words | F5 is what the arc has to carry. Rapport-style interviewers score the opener, and an unscripted one runs long |
| E2 | "Why Atlas Freight, and why this role now?" | CO | [generic] | Selection scaffold: this pack could not research Atlas, so use only what you can read on its own site or hear from the recruiter. Give one reason tied to the role's stated work (four sites, twelve supervisors, on-time and cost) and one honest reason about timing. Make no claim about strategy you have not read. If you cannot say why Atlas yet, say what attracted you to the role's work | Motivation consistency is scored in every round. Generic because company research was unavailable |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles rather than pretending to know the seam: who decides what, how a disagreement escalates, what each side needs from the other. Add reciprocity: what you bring their team. The guidance makes no claim about your past | A peer stem from the persona model; a hypothetical about the working relationship |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams, say who did what, and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer stem; open prompt, so it supplies no event |

### G. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold then concede. Pause, restate the question, anchor in the quote: "I cut mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups by returning to the redesign. Answer slot: say which parts were yours and which were not, in your own words; if it was shared, or someone else led parts of it, say so plainly and describe your part. Concede only what is true and specific, and do not fold on the core claim to restore harmony | F2's figure is the likeliest magnet for an attribution challenge |
| G2 | "Sixty seconds: why you over a candidate who has already run a multi-terminal operation?" | JD | [grounded] "7 years in warehouse and distribution ops", "cut mis-pick rate 40% by redesigning the pick path", "ran the site's peak-season surge plan two years running" | Pause and restate. Then sixty seconds in the quotes' terms and nothing more: "I have 7 years in warehouse and distribution ops. I cut mis-pick rate 40% by redesigning the pick path. I ran the site's peak-season surge plan two years running." If pressed on scale, concede in one line, "Twelve is more than the three I lead now", and move to your ramp plan. Hold through two follow-ups without adding to what you ran | F1, F2 and F3 together are what this question weighs. JD because it scores fit against the stated role |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites (F1) | A3, B2, D3, G2 |
| Drive on-time performance and cost-per-shipment down (F2) | A1, A2, A3, C1, C2, G1 |
| Lead a team of 12 supervisors (F3) | B1, D2 |
| Build reporting in Excel/Power BI (F4a, F4b) | A4, B4 |
| 5+ years operations leadership (F5) | B3, E1 |
| Lean/Six Sigma a plus (F6) | C3 |

The 40% mis-pick figure is the only headline metric, and C1 is its defend-the-number question. No CO or CASE question is grounded in Atlas's current strategy, because company research did not run; E2 and the case questions are generic and labelled so.

## 11. Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What would you want to see changed in the first ninety days, and how will you judge whether it is working?" | It turns the interview into a conversation about the job and tells you what success is measured on |
| R2 | "How are the twelve supervisors organized across the four sites, and what would I inherit on day one?" | The JD gives the numbers; this asks for the structure behind them, which is the step B1 probes |
| R3 | "Where do on-time performance and cost per shipment stand against what you want, and how are they measured today?" | The JD names both as targets; asking how they are measured shows you would start from the definition |
| R4 | "What does reporting look like across the four sites today, and which tools do people use?" | The JD says Excel/Power BI without saying whether both are needed; the answer tells you how much the Power BI gap matters |
| R5 | "What does a new manager get to learn terminal operations: shadowing, a mentor, a ramp plan?" | It shows you plan to own the learning rather than hide the difference between warehouse and terminal work |
| R6 | "What would make someone struggle in this role in their first six months?" | It invites the honest answer and tells you what the real risks are before you accept |

## 13. Prohibited claims

Built from the snapshot before the banks were written. This pack will not coach the following.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned daily terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says warehouse and distribution work, a shift-manager role and the site's surge plan. B2's and D3's answers stay inside what you ran |
| Led a team of twelve supervisors | Inflated form of F3 | F3's quote at its own scope: "I'm a senior shift manager over 3 supervisors." B1 and G2 carry the concession "Twelve is more than the three I lead now." |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote at its own scope; the material says mis-pick rate. C1's and C2's slots ask only the figure's own questions |
| Has used Power BI | Negative you stated, F4b | The plain acknowledgment F4b gives: "I've never used Power BI." No slot; then a plan in the future tense |
| Seven years of operations leadership | Inflated form of F5 | F5's quotes at their own scope: "7 years in warehouse and distribution ops" is operations, and the material does not say how many of those years were spent leading people. B3's slot stays inside the seven years and the three supervisors |

## 14. Sources

- Provided documents: the JD pasted in your message, and your own summary of your background in the same message (no CV was supplied). Every quote in the fit snapshot comes from that message. No `tuesday-dossier.md` was present.
- Searches sent, all refused by the host before returning anything:
  1. "Atlas Freight regional logistics company values" — refused
  2. "Atlas Freight interview process operations manager" — refused
  3. "Atlas Freight regional logistics terminals news strategy" — refused
- Pages fetched: none. Nothing in this pack comes from outside your message.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have fed the values cheat sheet (section 10) with the official value names, if a values-style round was found; section 10 is dropped |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have named the real rounds and replaced the generic archetype behind the persona weights |
| 3. `Atlas Freight strategy / recent news` | unavailable | Every call was refused. It would have grounded a CO or CASE question in current priorities; E2 and the case questions are generic instead |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read (section 7) is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 15. Upgrade menu

- Who the interviewer is, and whether the round is a recruiter screen, hiring manager, peer or panel → persona weights read from the round instead of a generic pattern, and a reverse question tied to their career path
- What the recruiter said about format (any presentation, case, site walk or take-home) → a build section for any announced deliverable, replacing the assumed coverage
- Web search allowed, or Atlas Freight's values and careers pages pasted with anything the recruiter said about the loop (a pass of up to 6 searches and 2 fetches, with a further 6 searches and 2 fetches available if you want depth, several more minutes) → the official value names, the real rounds, and strategy-grounded CO and CASE questions in place of the generic ones
- Your CV, or a few lines on what each role involved → F1, F2 and F5 would be re-graded on quoted evidence, and the E1 arc could be filled in
- Your answers to the answer slots in B1, B3, C1, C2 and C3 → rows F1, F2, F3, F5 and F6 would regenerate with your own quoted words
- The green belt certificate (issuing body and discipline) → F6 could rise from medium to high
- A `tuesday-dossier.md` from an earlier assessment of this role → evidence already graded and confirmed, an interview objection named from your confirmed evidence, and a prohibited-claims list that is not built locally
