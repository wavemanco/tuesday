Your prep pack is saved. I built it as a three-round loop from the recruiter's email, since it fixes who runs each round and the case format. I sent no searches, because your pasted JD, values and strategy points already cover what a search would add.

The full path is `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-denied-758d859a/Ashgrove-Credit-Union_member-experience-lead_interview_pack.md`

- **Highest-ROI prep:** R1-S1, "You haven't worked in a contact centre. How would you own complaints there?" It meets the JD's first line head-on. The pack gives you a plain acknowledgment, then the one sentence your material carries, then your own plan, with hold-then-concede follow-ups. R2-S2, on presenting above regional level, is second.
- **Values round:** nothing in your material yet carries a story for any of the four values. Those four are selection scaffolds with an honest "nothing comes to mind" branch, not mapped answers. The pack's upgrade menu says what would change that.
- **Size:** 29 questions across the three rounds, plus a prep schedule for the nine days to 20 November.

Say the word and I'll play the Skeptic on R1-S1, with follow-ups that react to what you actually say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Built 11 November 2026 for three sessions on 20 November 2026 (loop mode).

| Round | Length | Who | Format, in the recruiter's words |
|---|---|---|---|
| R1 | 30 minutes | The recruiter | Opening conversation |
| R2 | 45 minutes | Head of Member Services, who would be your manager | Mostly behavioural |
| R3 | 60 minutes | Panel of two branch managers | Includes a 20-minute case on a complaint escalation; the panel is also the values round and scores against the four values |

Interviewer names are not yet assigned, so there is no interviewer read in this pack. Loop mode was used because the recruiter's email fixes all three sessions and who runs each.

## 1. How to use this pack

- Personas describe how a question arrives. Types describe what it is scoring.
- Persona letters in question IDs: C Conversational, S Skeptic, V Values/Behavioral, K Case/Strategist, D Data-Driven Prober, P Peer Evaluator. An ID such as R3-V2 is round 3, Values persona, question 2.
- Type tags: VAL = behavioral and values alignment, tested against Ashgrove's published values. EXP = work-experience deep-dive, whether a claim survives scrutiny. JD = role and JD-driven, whether you can do the listed job, gaps included. CO = company and strategy knowledge. CASE = a live problem from the role.
- Provenance labels: grounded = traceable to something you or the employer supplied. inferred = derived from adjacent material, derivation named. generic = a pattern for the problem, no claim about Ashgrove or about you.
- Every sentence in double quotation marks that is about you is your own wording from your message of 11 November 2026. Guidance is scaffolding, not a script.
- An answer slot is an instruction for the interview, not a question for you now. It names a practice only because a source raises it as a likely probe, and it always has a second branch that lets the practice be absent or not yours.

## 2. Prep triage

You have nine days, 11 to 19 November. Hours per day are not stated, so each item is sized in sessions of about 45 minutes, spoken aloud.

| Priority | Do this | Where | Sessions |
|---|---|---|---|
| 1 | Rehearse the contact-centre answer until it is boring: acknowledgment, the one sentence you have, then your own plan, with the hold-then-concede follow-ups | R1-S1, R2-S1 | 4, across days 1 to 4 |
| 2 | Settle your acknowledgment and plan on presenting to senior leaders | R1-S2, R2-S2 | 2 |
| 3 | Check your own files for what the monthly spreadsheet counted and which tool it was in, so the answer slots in R1-D1, R2-D1 and R2-S3 are answered from fact | F3, F4 | 1 |
| 4 | Choose one real moment per value, or decide plainly that none comes to mind, using the four scaffolds | R3-V1 to R3-V4 | 3 |
| 5 | Run the case twice against a clock: 20 minutes, thinking aloud | R3-K1, R3-K2, R3-K3 | 3 |
| 6 | Learn the 90-second arc | R1-C1 | 1 |
| 7 | Pick two reverse questions per round | The reverse-question tables in sections 5, 6 and 7 | 1 |

Everything else is insurance.

## 3. Fit snapshot

Shared by all three rounds. No requirement in the JD is a gate in the sense of a licence, location, pay or similar term, so there is no hard_gate row. Your material gives no headline figure, so there is no defend-the-number question in this pack.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says a branch's log, not the process end to end, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages around the log likely. If any stage beyond the log was yours, say which and what your part was, in your own words; if the log was the whole of it, or the rest was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. The material also names one branch's log rather than several branches; that is the pack's observation and it adds no words for you |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The sentence says you built it, that it is monthly, that it is a complaints spreadsheet and that your regional manager uses it; the words stay there. It does not show whether it carried volumes or resolution times. Answer slot: the JD names both figures. If the spreadsheet counted either, say which and how it was counted, in your own words; if it did not, say so plainly and say what it did hold |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel, and the pack's step from one to the other is its own derivation, so no Excel claim is written for you. Answer slot: if it was built in Excel, say so and which parts you built, in your own words; if it was another tool, say so plainly and say what you would need to ramp up |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message, "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | The sentences say tellers and a script, and that you were a supervisor for the last three years; they do not say you coached supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coach-supervisors line makes a probe on how that differs from training tellers likely. If you have coached a supervisor, say one instance and your part; if not, say so plainly and stay with the tellers |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | You wrote formal; the material does not show what rules the log was kept under. Answer slot: the JD asks for regulated complaints. If the log was kept under a regulator's rules, say which in your own words and what your part was; if you do not know how it was classified, say so plainly and stay with the log |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length, and an experience length is not a gate. A CV-style line has nothing inspected behind it, so expect a probe on whether branch work is the JD's customer operations. Lead with the numbers as written |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I've never presented to anyone above regional level." Then how you would prepare your first senior presentation, said as a plan and never as a past. The sentence does not say what you presented at regional level, and the pack writes nothing about it |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material speaks to this. Answer slot: the JD names it. If you have worked with a digital or product team on something members use themselves, say what it was and what your part was; if you have not, say so plainly and say what you would ask a digital team first |

## 4. Grounding brief

From the July 2026 strategy brief the recruiter sent you, as you reported it. The brief itself was not pasted, so only these four points are in hand. The brief is equally available to rival candidates: bring one point to show you read it, then give your own view, and do not recite all four.

| Point | Source | Provenance | Reading, for the complaints role |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | "2026 strategy brief, July 2026" — your message | [grounded] | Touches the JD's self-service line (F9) and any complaint that starts digitally; whether complaints sit inside the 40% is a premise worth testing out loud |
| Consolidate eight branches into five hubs over 2027 | "2026 strategy brief, July 2026" — your message | [grounded] | Touches the third value, and the branch managers on the round 3 panel; a reading, not a fact about those two people |
| Launch a small-business lending product in Q1 2027 | "2026 strategy brief, July 2026" — your message | [grounded] | A new product line is a new kind of complaint; the brief as you gave it says nothing more |
| Main competitive pressure is app-only banks | "2026 strategy brief, July 2026" — your message | [grounded] | Frames why self-service journeys and plain wording matter |

## 5. Round 1: recruiter screen, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured openers; "walk me through your journey" | High. A recruiter screen starts from this register, and the casual questions are still scored | A 90-second arc you have said aloud; treat casual questions on the JD's hot topics as scored |
| Skeptic | Quiet probing of the gaps and the motive | Medium to high. The recruiter prior is a light Skeptic, and two requirements carry gaps you stated (F2, F8) | Rehearse the most predictable objection (R1-S1) until it is boring; plain acknowledgment, then a plan |
| Data-Driven Prober | Reads the lines of your background closely and asks what is behind them | Low to medium. Your material gives few lines, and the recruiter's email describes this round as the opening conversation | Know exactly what each of your own sentences does and does not say, and say so plainly |

Values, Case, Pressure and Peer personas are not weighted in this round: the recruiter's email places the values scoring and the case in round 3.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-C1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in four beats, each one a clause the quotes state: six years in retail banking; the last three as a branch supervisor; you handled the branch's formal complaints log; you built the monthly complaints spreadsheet your regional manager uses. Tell them in your own words and stop at the quotes' scope. Answer slot: the JD frames the job as owning complaints end to end, so expect "what did that involve" next. If you had a part in anything beyond the log and the spreadsheet, say which; if not, say so plainly and stay with those two. Close with your own reason for wanting this role; the pack does not know it | The arc draws on F1, F3 and F7. Casual in register, scored in practice; EXP because it tests what was actually yours |
| R1-C2 | "Tell me about handling the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on only the beats the sentence states: you handled it; it was the branch's; it was the formal complaints log. Tell it in your own words. Answer slot: the JD asks for regulated complaints and for owning the process end to end. If the log was kept under a regulator's rules, say which and what your part was; if you do not know how it was classified, say so plainly. If any stage around the log was yours, say which; if the log was the whole of it, say that and stay with the log | F1 and F6 meet here, and this sentence is the only complaints line in your material, so it is the likeliest place to be probed; EXP because it tests what was actually yours |
| R1-C3 | "What draws you to a member-owned credit union, and to Ashgrove in particular?" | CO | [grounded] | The question needs no claim about your past, and the guidance makes none. Answer slot: say in your own words what draws you; the pack does not know your reasons and will not supply them. For homework, use the first published value, "Members First, Always — we decide from the member's side of the counter", and one point from the strategy brief, such as the 40% digital target by 2028; say what each means to you for complaints as your own reading, not as inside knowledge | CO because it tests homework; the sources are the values page and brief you supplied, see section 4 |
| R1-C4 | "When have you worked with a digital team on something members use themselves?" | JD | [grounded] | Selection scaffold: pick a time you worked with a digital or product team on something members use themselves; it needs a named journey, what you asked for or fed back, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F9 has no evidence in your material, so the honest answer may be the second branch; JD because it scores a stated responsibility |
| R1-S1 | "You haven't worked in a contact centre. How would you own complaints there?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI prep in this pack, and the deepest rehearsal. Open with the plain acknowledgment: "I haven't worked in a contact centre." Then the one sentence you have, at its own scope: "I handled the branch's formal complaints log." Then a plan, said as a plan. Answer slot, plan only: say in your own words what you would do in your first weeks, such as who you would sit with, what you would read first and what you would ask before changing anything; the pack does not pick your plan. Hold-then-concede across three follow-ups. If pressed that phone and branch complaints differ, hold that you would learn how the team works before judging it. If pressed on day one, concede specifically that you cannot lean on contact-centre experience you do not have. Never widen the log into the contact centre | F2 is a capability gap you stated, and the JD's across-branches-and-contact-centre line meets it head on, so this question will arrive in some form; JD because it scores a stated responsibility |
| R1-S2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Calibrated candor: the two gaps you stated are the honest candidates. Name one plainly, either "I haven't worked in a contact centre" or "I've never presented to anyone above regional level", then say how you would close it as a plan in your own words. If asked for the other, name it the same way. Do not say there is no gap, and do not add a gap you did not state | F2 and F8 are the two stated gaps; JD because it scores the posting's own list |
| R1-S3 | "Why this role, and why now?" | JD | [generic] | No claim about your past is needed. Answer slot: if a particular moment or reason brought you to apply, say it in your own words; if there was none, say what in the JD's first line draws you. Keep it to two sentences and stop | Motive consistency is what a light Skeptic scores; JD because the answer should tie to the posting |
| R1-D1 | "Tell me about the monthly complaints spreadsheet your regional manager uses." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The beats the sentence states: you built it; it is monthly; it is a complaints spreadsheet; your regional manager uses it. Answer slot: the JD names monthly reporting on complaint volumes and resolution times, and comfort with Excel. If the spreadsheet counted volumes or resolution times, say which, how each was counted and the assumption you would defend least; if it did not, say so plainly and say what it did hold. If it was Excel, say so; if it was another tool, say so and what you would need to ramp up | F3 and F4; EXP because it tests what was actually yours |
| R1-D2 | "Your six years are in retail banking, the last three as a branch supervisor. How does that map to customer operations?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Lead with the sentence as written and let the interviewer draw the mapping. Answer slot: the JD asks for four-plus years in financial-services customer operations. If any of the work sat in a customer-operations function by your employer's own description, say so; if it was branch banking and not described that way, say so plainly and stay with the six years. Do not call the work customer operations yourself unless it was called that | F7; JD because it scores a stated qualification |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How does complaints handling in the contact centre connect to the branches today, as one process or two?" | Tests the JD's end-to-end scope and shows you want the real shape of the contact-centre side |
| 2 | "Which part of this role would you most want a new person to be strongest at in the first quarter?" | Lets the recruiter weight the JD's list for you |
| 3 | "For the panel round, should I expect to be given the case file in advance, and is it spoken or written?" | Practical, and it directly sizes how you rehearse R3-K1 |
| 4 | "The strategy brief puts 40% of member service on digital channels by 2028. What does that mean for the shape of the complaints team?" | Shows you read the brief and ties it to the role |
| 5 | "What happens after the third round, and when would you expect to decide?" | Closes the loop on timing |

## 6. Round 2: Head of Member Services, 45 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes, STAR-shaped stories | High. The recruiter calls this round mostly behavioural | A selection of real moments, "we" for context and "I" for contribution; where none comes to mind, say so plainly |
| Skeptic | Derisking probes on gaps | High. The hiring-manager prior includes the Skeptic, and this person would manage you, so your stated gaps (F2, F8) are what they are buying around | Plain acknowledgment, then your plan; never bluff a competency the manager owns |
| Case/Strategist | Live problems on the role's roadmap | Medium. The hiring-manager prior includes it, lowered because the round is mostly behavioural | Clarify before you structure, say the structure aloud, challenge one premise respectfully |
| Data-Driven Prober | Presses the reporting claims | Low to medium. Monthly reporting on volumes and resolution times is a stated duty (F3) | Say plainly what you can and cannot say about how each figure was counted |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-V1 | "Tell me about a time you coached someone through an escalation." | VAL | [grounded] "trained new tellers on our escalation script" | Open with what the quote carries: you trained new tellers on your escalation script. Answer slot: the question asks for a time. If there was a particular escalation where someone needed coaching, say what happened and what part was yours, in your own words; if you were teaching the script rather than coaching through a live case, or there was no such time, say so plainly and tell it as the training you did | F5; VAL because it scores behaviour against the JD's coaching line |
| R2-V2 | "When did you put a member ahead of an internal metric?" | VAL | [grounded] | Selection scaffold: pick a time a member's interest and an internal measure pulled apart; it needs a named decision, what it cost, and the relationship left intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme is the first published value, "Members First, Always"; no sentence of yours carries a story for it, see section 7 |
| R2-V3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something unwelcome; it needs a named stake, a moment you did not fold, and a relationship intact afterwards. Choose a story where the hard truth actually landed; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F8's gap means this question may be heard as a test of senior-facing nerve; VAL because it scores behaviour |
| R2-V4 | "Tell me about a time you had to tell a colleague their handling of a complaint was not good enough." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: pick a time you told a colleague their handling fell short; it needs the specific handling, how you said it, and what changed. The sentence you have states training tellers on a script, not telling a colleague their handling fell short, so it cannot stand in for this story. Answer slot: if a particular conversation like this happened, tell it; if you taught the script and never had that conversation, say so plainly | The theme comes from the JD's coach-on-escalations line (F5); VAL because it is a behavioural probe |
| R2-S1 | "You'd report to me and you haven't worked in a contact centre. What would you need me to put around you?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Plain acknowledgment first: "I haven't worked in a contact centre." Then the sentence you have, "I handled the branch's formal complaints log", at its own scope. Answer slot, plan only: say in your own words what you would ask for in the first weeks, such as who to sit with and what to read first. Reciprocity: say what you would bring from the log, and no more than the sentence carries | F2 again, in the register of someone who has to manage it; JD because it scores a stated responsibility |
| R2-S2 | "This role presents to senior leaders and you've never presented above regional level. What makes you confident?" | JD | [grounded] "I've never presented to anyone above regional level" | The second-highest-ROI prep. Acknowledge: "I've never presented to anyone above regional level." Do not manufacture confidence from nothing. Answer slot, plan only: say how you would prepare your first senior presentation, such as what you would ask about the audience and format first and who you would rehearse with. Answer slot: if you have presented at regional level, say what and to whom; if the regional manager only used your spreadsheet and you did not present it, say so plainly. Hold your plan through two follow-ups; concede specifically that you have no senior-level track record yet | F8 is a stated capability gap, and the premise of this question is your own sentence; JD because it scores a stated requirement |
| R2-S3 | "That spreadsheet — how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Pause, restate the question, and hold the sentence as you wrote it: "I built the monthly complaints spreadsheet our regional manager uses." Hold it through two follow-ups. Answer slot: if any part was inherited, templated or built by someone else, say which part plainly; if all of it was yours, say that and stop. Concede only what is true, and specifically | F3; EXP because this is the attribution probe, delivered under mild pressure |
| R2-K1 | "It's your first month. What do you need to find out before you change anything about how complaints are handled?" | CASE | [generic] | The question needs no claim about your past, and the guidance makes none. Structure aloud: the objective; how complaints split between branches and the contact centre; what you would read first, such as the complaints records, resolution times and escalations; who you would talk to, such as supervisors, the contact-centre team and the digital team; what you would leave alone until you have seen it. Name one risk: acting on numbers alone | A first-30-days case from the JD's end-to-end line; CASE because it scores structure |
| R2-K2 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that mean for complaints?" | CO | [grounded] | The question needs no claim about your past. Clarify first: does the 40% include complaints, or only routine service? Then structure: the objective; which complaints can be digital and which cannot; how a member moves between channels without telling it twice, which is the second value, "Plain Words"; what you would measure; the risk of a member getting stuck in self-service. Differentiate: use the brief for grounding, then give your own view | The brief supplied by the recruiter is the grounding; CO because it tests altitude |
| R2-D1 | "Walk me through how you would report complaint volumes and resolution times to leaders who have ten minutes." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Structure: the one question the report answers; the two figures; how each is counted; what moved and why; what decision you want. Answer slot: if your spreadsheet tracked either figure, say how it was measured and the assumption you would defend least, in your own words; if it tracked neither, say so plainly and describe the structure as how you would do it. Do not use made-up figures | F3 and F4; JD because it scores the reporting duty |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good first quarter look like for the person in this role?" | Lets your future manager name the real measure |
| 2 | "Who reads the monthly complaints report today, and what did it last change?" | Tests whether reporting drives decisions, tying to the JD's reporting duty |
| 3 | "What do you most need from this role that the team does not do well now?" | Opens the real gap the role fills |
| 4 | "How do you see the digital team and this role dividing complaints in self-service journeys?" | Ties to the JD's digital line and the 40% target |
| 5 | "What would make you doubt this hire at six months?" | Invites the objection while you can still answer it |

## 7. Round 3: panel of two branch managers, 60 minutes

Twenty of the sixty minutes are the case on a complaint escalation. The panel scores against the four values.

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes mapped to the four published values | High. The recruiter says the panel is the values round and scores against the four values | A selection of real moments per value; "I" for contribution; the honest branch where none comes to mind |
| Case/Strategist | The 20-minute escalation case | High. It is a named, timed part of the session | Clarify, own it, plain words, record, root cause; think aloud |
| Peer Evaluator | Seam-splitting between a branch manager and this role | Medium. Both interviewers run branches, and the role coaches branch supervisors on escalations; a reading, not a fact about these two people | Reciprocity first; propose seam principles, not a seam you cannot know |
| Skeptic | Probes on whether a central role knows a branch | Medium to low. The recruiter's email gives no sign the panel is scoring gaps, but the gaps in F2 and F8 do not vanish | Plain acknowledgment, then plan |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-V1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] | Selection scaffold: pick a decision where the member's interest and an internal preference pulled apart; it needs what you decided, what it cost, and how it ended, including a hard truth that actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Value one, "Members First, Always — we decide from the member's side of the counter"; no sentence of yours carries a story for it, so this is a scaffold |
| R3-V2 | "Tell me about a time you had to explain something to a member more than once." | VAL | [grounded] | Selection scaffold: pick an explanation that needed a second go; it needs what was unclear, what about the wording or form caused it, and what you changed afterwards. Value two says that if a member needs it explained twice, the wording was wrong, so the answer should say what you changed, not what the member failed to grasp. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Value two, "Plain Words"; F5 is the nearest row and does not carry a story for this |
| R3-V3 | "Every Ashgrove branch is part of its town. Tell me about a time a number and a neighbour pulled in different directions." | VAL | [grounded] | Selection scaffold: pick a time a measure and a local relationship pulled apart; it needs the measure, the relationship, what you did and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Expect this value to be tested against the role's reporting duty and the eight-branches-to-five-hubs move | Value three, "Neighbours, Not Numbers"; the role reports numbers, so the value is the one most likely to be pressed against it |
| R3-V4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a problem you found and kept hold of; it needs what the problem was, what you did, what was yours, and how it closed. The nearest sentence, "I handled the branch's formal complaints log", states the log, not a problem you kept hold of, so do not retell it as a fix you owned unless you did. Answer slot: if a particular complaint stayed with you from first report to close, tell it; if the log was a record you kept and the fixes were others', say so plainly | Value four, "Own the Fix — whoever finds the problem keeps hold of it until it is solved"; F1 is the nearest row |
| R3-K1 | "Practice case, written by this pack and not Ashgrove's: a member complained at a branch on Monday and was told someone would call back. They have now complained again through the contact centre. The branch says it is resolved; the member says it is not. Walk us through it." | CASE | [generic] | The question needs no claim about your past, and the guidance makes none. Time-box to 20 minutes, thinking aloud. Clarify first: what was promised and by whom, what the member wants, what time limits apply, and whether anything in the member's circumstances needs different handling. Then own it: name one person who keeps hold of it, which is the fourth value. Then plain words: what you say to the member, written so it need not be explained twice. Then record it, find the root cause, and feed back to the branch. Challenge one premise: who decided it was resolved | The actual case is the panel's own; this one rehearses the shape. CASE because it scores structure |
| R3-K2 | "The supervisor involved is defensive about the escalation. How would you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | Structure: listen to their account first; agree the facts; agree one thing to do differently; check back. If you draw on experience, the sentence you have is "I trained new tellers on our escalation script", at tellers' scope. Answer slot: the JD's coach-supervisors line makes a probe on whether you have coached a peer likely; if you have, say one instance and your part; if not, say so plainly and stay with the tellers | F5; CASE because it is a live problem from the role |
| R3-K3 | "Eight branches are becoming five hubs over 2027. What would you watch in complaints while that happens?" | CO | [grounded] | The question needs no claim about your past. Clarify first: which members move, and which branches are affected. Structure: members of closing branches and of receiving hubs, and the contact centre; volumes and resolution times by branch, which is the JD's reporting duty; the risk of a member feeling like a number, which is the third value. Do not assume complaints will rise | The brief is the grounding; two branch managers are likely to care about it, which is a reading; CO because it tests strategy fluency |
| R3-P1 | "Where is the seam between this role and a branch manager on an escalation, and what happens when we disagree?" | JD | [generic] | The question needs no claim about your past. Reciprocity first: what you would bring a branch manager, then what you would need. Propose seam principles rather than pretending to know the seam: who keeps hold of the member, who decides, how you disagree. Do not name a past disagreement unless you have one; a selection scaffold applies if you want one: a disagreement with an equal, showing spine and tact, ending with the relationship intact; if none comes to mind, say so plainly | Peer stem; JD because it scores the role's coordination with branches |
| R3-P2 | "How do you handle credit when work spans branches?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams; it needs who did what, how you named it, and how it was received. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer stem; VAL because it scores collaboration against the values |
| R3-S1 | "You'd be coaching our supervisors, and you were one. What do you do when the supervisor knows the branch better than you do?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Lead with the sentence at its scope: you spent the last three years as a branch supervisor. Principle: ask them first, because they know the branch. Answer slot: if you have been coached by someone from outside your branch, say what helped; if not, say so plainly. Do not claim you have coached supervisors | F5; JD because it scores the coaching line |

### Values and principles cheat sheet

A values-style round is detected, because the recruiter says the panel scores against the four values. Names are from the page you copied on 11 November 2026.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold: pick a time a member's interest and an internal preference pulled apart; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. See R3-V1 |
| Plain Words | If a member needs it explained twice, the wording was wrong | Selection scaffold: pick an explanation that needed a second go and say what you changed in the wording; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. See R3-V2 |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold: pick a time a measure and a local relationship pulled apart; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. See R3-V3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1 holds "I handled the branch's formal complaints log", which states the log, not a fix you kept hold of. Selection scaffold: pick a problem you found and kept hold of; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. See R3-V4 |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new person in this role do in their first month that would genuinely help your branch?" | Reciprocity: it asks what you can give them, not only what you need |
| 2 | "How do your supervisors experience escalations today, and what is hardest for them?" | Ties to the JD's coaching line and invites the real problem |
| 3 | "With eight branches becoming five hubs over 2027, what do you most want complaints handling to protect for your members?" | Shows you read the brief and ties it to the third value |
| 4 | "Can you tell me about a time one of the four values was tested in your branch?" | Shows you take the values as practice, not slogans |
| 5 | "How would you like to hear from me when an escalation is not going well?" | Turns the seam question into a working agreement |

## 8. Requirement coverage

| JD requirement | Fit row | Question IDs |
|---|---|---|
| Own the member complaints process end to end | F1 | R1-C1, R1-C2, R2-K1, R3-V4, R3-K1 |
| across branches and the contact centre | F2 | R1-S1, R1-S2, R2-S1, R3-K1 |
| report monthly on complaint volumes and resolution times | F3 | R1-D1, R2-D1, R3-K3 |
| coach branch supervisors on escalations | F5 | R2-V1, R2-V4, R3-K2, R3-P1, R3-S1 |
| work with digital teams on self-service journeys | F9 | R1-C4, R2-K2 |
| 4+ years in financial-services customer operations | F7 | R1-C1, R1-D2 |
| experience handling regulated complaints | F6 | R1-C2, R3-K1 |
| confident presenting to senior leaders | F8 | R1-S2, R2-S2, R2-V3 |
| comfortable with Excel reporting | F4 | R1-D1, R2-D1 |

Headline figures in your material: none, so no defend-the-number question was written. Every question in this pack is in the banks above: 29 across three rounds.

## 9. Prohibited claims

Built from the fit snapshot before the banks were written; no answer slot, hold, bridge or rationale asserts any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says a branch's log, not the process |
| Has contact-centre experience, or owned complaints in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Reported complaint volumes and resolution times monthly | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." Slots stay inside the spreadsheet |
| Has Excel expertise | Inflated form of F4 | The same sentence at its own scope: a spreadsheet. The Excel slot asks only which tool |
| Coached or trained branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: "trained new tellers on our escalation script" |
| Handled regulated complaints | Inflated form of F6 | F6's quote at its own scope: a formal complaints log. The slot asks only under what rules |
| Presented to senior leaders, or is confident doing so | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |

## 10. Sources

Provided documents: the JD (your message); the values copied from ashgrovecu.org/about/values on 11 November 2026 (pasted, not fetched); the recruiter's email on the process; the 2026 strategy brief of July 2026, as the four points you reported (the brief itself was not read); your background, in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet: the values page you pasted fixes the four names and meanings |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email fixes three sessions, who runs each and the case format |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO bank: the July 2026 brief you supplied gives current priorities and the competitive frame |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what a name would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- The interviewers' names, when assigned: an interviewer read, persona weights per panel member, and a reverse question tied to each person's path
- The strategy brief's full text: more specific CO questions in R2-K2 and R3-K3, and a fuller grounding brief than the four points you reported
- The recruiter's answer on the case format, whether the file is given in advance and whether it is spoken or written: tighter guidance for R3-K1 to R3-K3, and usually one email
- What the monthly spreadsheet counted and which tool it was built in, outside this pack: F3 and F4 move from discovery to a story map, and R1-D1, R2-D1 and R2-S3 can be rewritten on facts
- One real complaint you saw through from first report to close, in your own words: upgrades F1 and F6 and turns the Own the Fix scaffold into a story map
- Whether you have presented anything at regional level, and to whom: changes F8's bridge and R2-S2
- A CV or any figure you cite: any headline figure gets a defend-the-number question, and every evidence cell would then quote the CV itself
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes: role-family loop reports, interviewer footprint once a name exists, and recent org context; offered once
- A tuesday-dossier.md, if you already have one: verified evidence and absolute prohibited claims would replace the ones this pack built locally
