Web search was denied on all five calls, so the pack runs without research. Writing it now from your message and the recruiter's quoted email.
Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md` in the working directory. It has 19 questions, a build section for the 15-minute POV, and a four-hour schedule sized to your weekend.

- **Biggest exposure:** Ross's commercial push, specifically "you've never carried a direct quota." B1 is the pack's highest-ROI rehearsal. It opens with your own sentence ("I've never carried a direct quota"), holds on the roughly £4M of *influenced* revenue, and concedes the limit specifically. Expect follow-ups on how that figure was counted and which part was yours. I haven't supplied a method for either, because your message doesn't contain one. That is a gap to fill in your own words before Tuesday.
- **POV:** I laid out three theses, each with the concession you must say aloud, and recommend leading with the one that ends on what it means for the operators. A timed skeleton runs to 12 minutes, leaving 3 spare.
- **What didn't run:** Web search was denied on all five of my attempts. The pack has no Kelverton values, strategy or interviewer research, and no JD, so some content is labelled generic. I also haven't seen the market report, so the "differentiate from it, don't recite it" advice is a method for you to apply to your own copy.
- **Assumption:** I treated Ross as a senior cross-functional stakeholder rather than your direct manager. Deepa is weighted as the hiring manager.

I can run a drill as Ross on B1, the commercial question. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the JD and your CV to hand? Pasting either would restructure the fit snapshot, and I've built without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday, 60 minutes. Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director), as the recruiter's email gives them. First 15 minutes: your POV on where you would take Kelverton's operator partnerships over the next 18 months, no slides. Remaining time: Q&A, with Ross pushing on commercials.

Built from your message and the recruiter's email as you quoted it. No JD, CV or market report text was in hand, and web research did not run (see Sources). Where the pack lacks a source it says so and labels the content `[generic]`.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding to speak from, not a script.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values |
| EXP | Work-experience deep-dive | Whether the claims on your record survive scrutiny |
| JD | Role / JD-driven | Whether you can do the stated job, including its gaps |
| CO | Company and strategy knowledge | Homework depth and altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a live problem |

Provenance labels: `[grounded]` traces to something you or the recruiter wrote, `[inferred]` is derived from it with the derivation named, `[generic]` is a role-family pattern with no claim about Kelverton or about you.

An answer slot is an instruction for the interview. It asks you nothing now. Where a slot says "your own words", the pack does not know the answer and will not supply one.

## Prep triage (four hours, over the weekend)

| Order | Time | Do this | Ties to |
|---|---|---|---|
| 1 | 90 min | Build and rehearse the POV aloud. Pick the thesis, mark the report (one finding to cite, one to depart from, one anti-pick), run it once timed to 12 minutes | Graded deliverable, A1 to A4 |
| 2 | 60 min | Write and say aloud, three times each, your answers to the commercial objection and the number questions | B1, B2, B3, D1, D2 |
| 3 | 45 min | Operator-side and rail-gap answers: what you actually did with operators, and the ramp plan | A5, C1, C2, D3 |
| 4 | 30 min | Second timed run of the POV, then B1, ideally in front of a person or recorded | Graded deliverable, B1 |
| 5 | 15 min | Pick three reverse questions | R1 to R6 |

Everything else is insurance.

## Fit snapshot

No JD was supplied, so requirements are the recruiter's own words, your description of what Kelverton sells, and one plain-prose role-family requirement labeled `[generic]`. Evidence cells hold only your sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships, and the words stay there: "For the last four years I've run the ISV channel at a payments company." A POV is a view and claims nothing about your past, so it needs no further quote |
| F2 | "Ross will push on commercials" — recruiter email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | Your sentence supports the plain acknowledgment and the figure at its own scope: "I've never carried a direct quota; what I can speak to is roughly £4M of influenced revenue." Answer slot: the figure makes a probe on how it was counted, what it is sensitive to, the assumption you would defend least and which part was yours likely. Say each in your own words; if you do not know how it was counted, say so plainly and return to what the sentence says |
| F3 | "Please land on what it means for the operators themselves" — recruiter email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies, and the words stay there: "Before that I spent five years in transport consulting, in bus and light rail network planning." Answer slot: expect a probe on which operators you worked with and what you saw. If you worked with the operators' own teams, say who and on what, in your own words; if the work was for others, or did not involve operators directly, say so plainly and stay with the network planning |
| F4 | "they sell scheduling software to train operating companies" — your message | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn the rail side, said as a plan and never as a past, with nothing added to make the gap feel smaller |
| F5 | Grow and run a portfolio of partners (role-family expectation for a Senior Partnerships Manager; no JD supplied) | "took it from 6 partners to 40" — your message | medium | [generic] | none | The quote already reaches the requirement: "I took the ISV channel from 6 partners to 40." It says ISV channel, not operators, so it is not a claim about operator partnerships. The figure makes the defend-the-number probes in B3 |

## Graded deliverable: the 15-minute POV

The recruiter announced this as the first task, so it is graded. It is built before the Q&A banks because most of the Q&A will be asked off it.

**Facts you may build on** (each with the fit-snapshot row it comes from):

| Row | Quoted sentence | What it licenses |
|---|---|---|
| F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | You have run a partner channel. Nothing about operator partnerships |
| F3 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | Operator questions at the scope of bus and light rail network planning |
| F2 | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | One proof point at most, and you will be asked how it was counted |

**Three defensible theses.** Pick one to lead with. Each carries a concession you must say aloud, because Ross will find it if you do not.

| Thesis | What you would argue | Mandatory concession | Provenance |
|---|---|---|---|
| T1 Depth before breadth | In 18 months, build a few deep operator partnerships (shared roadmap, shared measures) before widening | It is slower to show partner count and revenue, and growing partner count is the shape of your own quoted history (F5), so expect "why not repeat what you did?". Answer from the limit: your quote is ISV channel growth, not operator partnerships | [generic] |
| T2 Measure what the operator feels | Anchor each partnership on one outcome the operator agrees is theirs, reported beside Kelverton's own revenue | An operator-side outcome is harder to attribute to you than Kelverton's revenue, and your own figure is "influenced". Say attribution is imperfect and propose a rule agreed up front | [generic] |
| T3 An ecosystem around operators | Add third-party partners that extend what an operator can do with Kelverton's software | It is the move closest to your ISV history, so expect the pattern-matching jab, and it adds partners before the operator-side case is made | [generic] |

The pack's recommendation, which you are free to overrule: lead with T2, because it lands on the recruiter's required close, and use T1 as the sequencing (first deep, then wide). Whichever you choose, the choice is yours and the words are yours.

**Differentiating from the report.** The market report was circulated internally and the recruiter attached it, so treat it as equally available to the panel. Reciting it scores as homework; departing from it, with reasons, scores as judgment. This pack has not read it. Mark your copy for three things:

1. One finding you accept, credited to the strategy team by name, to prove grounding.
2. One finding you would depart from, with the reason.
3. One thing it does not say about operators that you would ask operators about first.

**The anti-pick.** Name one thing you would not pursue in the 18 months (a segment, a partner type or a deal shape) and the reason. A POV that ends in a choice and a refusal reads as a plan.

**The requested close.** The recruiter asked you to land on what it means for the operators themselves. Finish on a sentence of the form "For an operator, this means..." in your own words. Answer slot: if you saw the operator side of a change like this in your planning years, say what you saw; if you did not, say so plainly and say what you would ask operators first.

**Timing skeleton (rehearse to 12 minutes, leaving three spare):**

| Minutes | Beat |
|---|---|
| 0 to 1 | Frame: the question you are answering and what you would want to check |
| 1 to 3 | One finding from the report you accept, and where you depart |
| 3 to 8 | Your thesis and its first two moves, concession said aloud |
| 8 to 10 | The anti-pick |
| 10 to 11 | The measures you would be held to, so Ross has a commercial landing |
| 11 to 12 | What it means for the operators themselves |

## Persona table

Loop source: the recruiter's email, which gives one panel session, who is on it, a 15-minute POV and the rest as Q&A. No archetype fallback is needed. Relationship priors from `personas.md` are applied per panel member, then adjusted by the recruiter's own flag. Ross's relationship to you is not stated; the pack assumes a senior cross-functional stakeholder, not your direct manager.

| Letter | Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|---|
| A | Case/Strategist | Live problems on Kelverton's actual partnerships, starting with the POV itself | Highest. Hiring-manager prior for Deepa, plus the POV is a case you deliver | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| B | Data-Driven Prober | Line-by-line questioning of the number and the partner count | High. The recruiter wrote that Ross will push on commercials, and your sentence carries two figures | Know what you can and cannot say about how each figure was counted; say plainly when you do not know; name the weakest assumption before they do |
| C | Skeptic | Quiet probing of the rail gap and the quota gap | Medium. Hiring-manager prior for Deepa, and your own message states two limits | Rehearse the likeliest objection until it is boring; bridge only from what you said; give a concrete ramp |
| D | Pressure | Interruptions and time-boxes on the same two limits | Medium. Commercial pushing often arrives as pressure, but the recruiter did not say so | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |
| E | Peer Evaluator | The seam between Partnerships and Commercial | Low. Deepa and Ross sit on neighbouring teams, which the recruiter's titles suggest but do not confirm | Reciprocity framing; propose seam principles rather than claiming to know the seam |
| F | Conversational | The biography opener and a casual market question | Low. Likely only as the opener, and still scored | A 90-second arc; treat casual questions as scored |

No values-style round is detected: the recruiter's email names none, and no values page was read. There is no values cheat sheet.

## Question banks

### A. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through your POV: where would you take our operator partnerships over the next 18 months, and what does it mean for the operators themselves?" | JD | [grounded] | Build it in the graded-deliverable section. This is the recruiter's own brief, a view and not a claim about your past, so the guidance makes none. Finish on the operators, in your own words. Rehearse to 12 minutes aloud | F1's requirement, and the one question certain to be asked. JD because the recruiter announced it as the task |
| A2 | "Before you give us a plan, what do you need to know that you can't see from outside?" | CASE | [generic] | Say your structure aloud: clarify, objective, segmentation, approach, metrics, risks. Draft three clarifying questions for the opening, for example what partnership is meant to deliver commercially, which operator relationships already exist, and what the report treats as the priority. Challenge one premise politely. No claim about your past | Tests clarify-before-structure, the Case/Strategist's main score. F1 is the requirement it serves |
| A3 | "Where does the consensus view of this market go wrong for operators?" | CO | [generic] | Credit one report finding you accept, then depart from one with reasons. Answer slot: name the specific finding you depart from and why; if you have not found one, say so plainly and say what evidence would change your view. No claim about your past | The report is equally available to the panel, so this tests whether you depart from it with reasons. F1. CO because it tests altitude |
| A4 | "If you could only run three partnerships in your first year, which would you choose, and what would you say no to?" | CASE | [generic] | Criteria first, then picks as types of partner unless you have a named one from your own reading, then the no, with the reason. The no is the anti-pick from the graded-deliverable section. Hold it through a push and say what you would need to see to change your mind. No claim about your past | Tests whether the POV ends in a choice. F1. CASE because it is a live prioritisation |
| A5 | "Six months in, how would you know the strategy was working for operators rather than for us?" | JD | [grounded] | Name one measure an operator would recognise as theirs, in your own words, and one Kelverton-side measure to sit beside it. Answer slot: if you have seen an operator-side measure of this kind in your own work, say what it measured; if you have not, say so plainly and say what you would ask operators to find out | Puts the recruiter's required close to a test. F3. JD because it scores a stated requirement |

### B. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've said you haven't carried a direct quota. Why should we trust you with a commercial number here?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "took it from 6 partners to 40, roughly £4M of influenced revenue" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment your sentence supports: "I've never carried a direct quota." Then the figure at its own scope: "What I can speak to is roughly £4M of influenced revenue." Hold through two follow-ups by returning to that figure, and concede specifically that influenced revenue is not a carried number; do not fold on the figure itself. Expect follow-ups on how it was counted, which part was yours and which assumption you would defend least; answer them with the slots in B2. Then a plan, said as a plan: what you would want agreed on the number and who owns it in your first 90 days | F2 and F4 are the largest gap in the material, and the recruiter flagged Ross's commercial push, so this arrives in some form. EXP because it tests what you actually did |
| B2 | "Walk me through how that £4M was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say the figure at its own scope: "roughly £4M of influenced revenue." Answer slot: say how it was counted, what it is sensitive to, the assumption you would defend least and which part was yours, each in your own words; if there was no such step or it was not yours, say so plainly and return to the figure as you stated it. Name the weakest assumption before they ask, or say plainly that you do not know how it was counted | F2 carries the headline metric, and quantified claims are where probers go first. EXP |
| B3 | "What counted as a partner when you went from six to forty?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say it at its own scope: "I took the ISV channel from 6 partners to 40." Answer slot: say how the count was kept, what it is sensitive to, the assumption you would defend least and which part was yours, in your own words; if you do not know, or it was not yours, say so plainly and return to the quote | F5's figure. The pack does not say what counted as a partner because nothing you wrote does. EXP |
| B4 | "An operator offers a longer commitment if it gets a say in our roadmap. How do you think about that trade?" | CASE | [generic] | Structure it: what the operator gets, what Kelverton gets, the floor you would not go below, and who has to agree before you say yes, including bringing the Commercial Director in before offering anything. Ask what the commitment is worth to Kelverton before answering. No claim about your past | Gives Ross a commercial problem with no past to defend, so you can show structure where your record is thin. F2's requirement. CASE |

### C. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see rail in your background. How would you handle the rail side of this role?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Words: "I've never sold into rail specifically." Then the nearest thing your material carries, at its own scope: "Before that I spent five years in transport consulting, in bus and light rail network planning." Then a ramp as a plan: who you would learn from in the first 30 days and what you would ask operators. Say nothing about heavy rail unless you have said it in your own words | F4 is the likeliest objection to arrive after B1. The pack's observation is that your material shows bus and light rail, not train operating companies. JD |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Your sentence carries two stated limits: "I've never sold into rail specifically" and "I've never carried a direct quota." Pick the one that is truly weaker, say it in one plain sentence, then the ramp as a plan. If something else is truer, say that. If no weakness comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem the Skeptic uses to see whether you know your own gaps. F2 and F4. JD |
| C3 | "Why leave payments for rail-tech, and why now?" | JD | [generic] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The pack does not know your reason, so pick one that is true: something specific about the operator problem, something about Kelverton's position from your own reading, and something true of you. If your reason is mostly about the scope of the role, say so plainly. If the transport consulting years are part of the reason, say so in your own words and keep to the quote at its own scope | Motivation consistency is the Skeptic's score, and a switch of sector invites it. F3. JD because no better tag exists |

### D. Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, rather than someone who has already carried a quota into train operators?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" "took it from 6 partners to 40, roughly £4M of influenced revenue" "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause and restate the question. Hold on what your sentences carry: "For the last four years I've run the ISV channel at a payments company," and the figure at its own scope. Concede specifically: "I've never carried a direct quota and I've never sold into rail specifically." Do not claim to be stronger than that person. Hold through two follow-ups, conceding the limit and not the figure | Tests composure on the same two limits as B1. F2 and F4. JD |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say which part was yours in your own words; if the result involved others, or you cannot separate your share, say so plainly and return to "took it from 6 partners to 40." Do not enlarge the sentence under pressure | The attribution probe the Pressure persona uses. F2. EXP |
| D3 | "You've said you know the operator world from the other side. Which operators, and what did you see?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer slot: if you worked with the operators' own teams on those bus and light rail networks, say who and on what, in your own words; if the work was for others, or did not involve operators directly, say so plainly and stay with the network planning | Your own phrase invites this probe. F3. EXP |

### E. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and Commercial sit side by side. Where's the seam, and what happens when we disagree about a deal?" | JD | [generic] | Offer seam principles rather than claiming to know the seam: who owns the number, who owns the relationship, who can say no, how a disagreement is escalated. Add what you would bring to Ross's team, not only what you need. For the disagreement, pick a time you disagreed with a commercial or sales counterpart over a deal and the relationship held, with a named stake and what you said; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Ross's seam with Partnerships is the likeliest peer question. F2's requirement. JD |
| E2 | "When a deal a partner influenced closes through our sales team, how do you handle credit?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Principle: agree the credit rule before the deal, not after. Answer slot: if there was a rule for sharing credit on your influenced revenue, say what it was in your own words; if there was none, or it was not yours to set, say so plainly and return to "roughly £4M of influenced revenue" | A persona stem on credit, which "influenced" revenue invites. F2. EXP |

### F. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc with the beats your sentences state: five years in transport consulting, in bus and light rail network planning; then nine years in partnerships, the last four at a payments company running the ISV channel. End on one sentence about why this role, from your own reason (see C3). Your material says nothing about the first five partnership years, so say nothing about them | The opener, and still scored. F1 and F3. EXP |
| F2 | "What's the most interesting thing you've read about our market lately?" | CO | [generic] | Treat it as scored. Bring one specific finding you actually read in the report, say why it caught you in a sentence, and connect it to your POV. No claim about your past | A casual-register CO question. A1's POV is the natural home for the answer. CO |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: POV on operator partnerships over 18 months | A1, A2, A3, A4, F2 |
| F3: land on what it means for the operators | A1, A5, C1, D3 |
| F2: commercials | B1, B2, B3, B4, D1, D2, E1, E2 |
| F4: sell scheduling software to train operating companies | C1, C2, D1 |
| F5: grow and run a partner portfolio (generic) | B2, B3, F1 |
| Any further JD requirement | none, and why: no JD was supplied |

## Reverse questions

No interviewer profile was available, so these are role-generic. R4 is the reciprocity question for Ross.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make you say, 18 months from now, that this hire was the right one?" | Shows you think in outcomes, and tells you what the panel would score you on |
| R2 | "Where do the strategy team's report and your own view of operator partnerships differ?" | Shows you read it critically and invites the real view behind it |
| R3 | "How does Kelverton count the revenue that partnerships contribute to, and who owns that number?" | Goes straight at the commercial gap, in Ross's own language |
| R4 | "What could a new person in my seat do in their first month that would genuinely help your team?" | Reciprocity for Ross, whose team sits beside Partnerships |
| R5 | "Which operator relationships are in the strongest shape today, and which need the most attention?" | Turns the POV into a working conversation about the real starting point |
| R6 | "What does a good first 90 days look like to you?" | Gives Deepa, your future manager, room to set expectations you can plan against |

## Prohibited claims

What this pack will not coach, with the basis and the honest form. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota, or owned a revenue number | Negative you stated, F2 and F4 | The plain acknowledgment your sentence gives: "I've never carried a direct quota." |
| Sold into rail or into train operating companies | Negative you stated, F4 | The plain acknowledgment: "I've never sold into rail specifically." |
| The £4M as revenue you owned or closed | Inflated form of F2 | F2's quote at its own scope: "roughly £4M of influenced revenue." The limit is the pack's observation: your sentence says influenced, not owned or closed |
| The £4M as an annual figure | Inflated form of F2 | F2's quote at its own scope. The pack's observation: your sentence does not state a period |
| Worked with train operating companies, or knows rail operations from the inside | Inflated form of F3 | F3's quote at its own scope: bus and light rail network planning. The pack's observation: your material does not show train operating companies |
| Ran operator partnerships | Inflated form of F1 | F1's quote at its own scope: running the ISV channel at a payments company |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report is mentioned in your message but its text was not in this conversation, so it has not been read and nothing in the pack rests on it.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

Searches sent, every one refused (the host denied permission to search):

- "Kelverton Rail company values" — refused
- "Kelverton Rail strategy news train operating companies scheduling software" — refused
- "Deepa VP Partnerships Kelverton Rail" — refused
- "Ross Commercial Director Kelverton Rail" — refused
- "Senior Partnerships Manager Kelverton Rail job description" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have themed VAL questions and said whether a values page exists. No values-style round is detected, so no values cheat sheet either way |
| 2. Interview process, partnerships role | skipped | The recruiter's email fixes the loop (one panel session, who is on it, 15-minute POV then Q&A), which sets the persona weights |
| 3. Kelverton strategy and recent news | unavailable | Would have grounded A3, F2 and the POV's differentiation. The report you mention is not in hand, so it cannot fix them |
| 4. Interviewers: Deepa, Ross | unavailable | Would have produced an interviewer read, adjusted persona weights and tied a reverse question to each career path. Both queries were refused |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have turned the generic requirement in F5 into a sourced one and grounded JD-tagged questions |

No dossier was present.

## Upgrade menu

- The JD text → the recruiter-word and generic requirement rows become quoted JD rows, JD-tagged questions become grounded, and any gate (location, travel, pay band, right to work) becomes visible
- The report's sections on operators and partnerships, pasted → the differentiation in the graded-deliverable section names the consensus item and the departure, and A3 and F2 become grounded
- Your CV → more of your own sentences in the fit snapshot, since four sentences carry every row now
- Your own words on how the £4M and the six-to-forty were counted, and which operators you worked with in consulting → F2, F3 and F5 upgrade, and B2, B3, D2 and D3 become story-mapped
- Search access for Kelverton's values, strategy and the two interviewers' public footprints → an interviewer read, adjusted persona weights and a reverse question tied to each career path
- A tuesday-dossier.md from an earlier role assessment → verified evidence and its own prohibited claims, in place of the list built here
