Researching Stripe's values, interview loop and strategy before I build your prep pack.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-3-denied-467ecef2/stripe_product-operations-manager_interview_pack.md`.

I built it for a final round with unknown interviewers and no background from you, so the persona weights are flat. All four of my web searches were refused. The pack has no Stripe-specific facts: no values, no interview loop, no strategy. Every row is labeled generic.

It has 22 practice questions across seven interviewer styles, each with answer guidance. There is also a role-requirements worksheet, six questions to ask them, and a sources and research table. The question to rehearse first is B1: "Which part of this role would you be weakest at on day one?" Any skeptical interviewer will ask it in some form.

Offers:
- Say the word and I'll play the skeptic on B1 for a live drill.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would restructure the pack:
1. Who are you meeting, in what order and in what format (panel, one-on-one, case, presentation), and has the recruiter said anything about focus areas or a deliverable?
2. Can you paste the job description and your CV? I'll proceed without them if you'd rather.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round interview pack

Interviewers and their relationship to the role: not given. Round: final, with the number and format of sessions not given. Built in session mode with flat persona weights, because no loop source establishes the final's structure and the generic archetype applies. This is a first pack with no changelog.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on. Guidance is scaffolding for a spoken answer, not a script, and nothing in it says what you did: wherever a question touches your past, the guidance gives selection criteria that end in an honest branch.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior demonstrates values, not generic virtue |
| EXP | Whether your claims survive scrutiny and what was actually yours |
| JD | Whether you can do the role's responsibilities, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

This pack read no document from you and no Stripe source, because its searches were refused. Every row is `[generic]`: a rehearsal pattern for the role family, not a fact about Stripe or about you. The upgrade menu says what each missing input would turn into `[grounded]`.

## Fit snapshot

Worksheet variant: no CV, no JD and nothing about your past was supplied. The requirements are role-family requirements in plain prose with no source, so none is quoted and none raises an answer slot. Every evidence cell is `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Runs a cross-functional launch or program process across several teams, role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence is a process you ran end to end, with the teams involved and the decisions that were yours named in your own words. Selection scaffold: pick one process where several teams depended on each other and you held the thread; if no such process comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Defines and tracks operating metrics for product teams, role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence is a metric you can explain from definition to data source to what it fails to show. Selection scaffold: pick a figure you reported and can say how it was counted; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Builds or improves a mechanism that other teams adopt, role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence is a mechanism others used without you in the room, and what changed for them. Selection scaffold: pick something that outlived your direct involvement; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Communicates with senior stakeholders in writing and live, role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence is a message or decision memo with a named audience and a named outcome. Selection scaffold: pick an occasion where you carried a hard message upward; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritizes and makes trade-offs without direct authority, role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence is a trade-off you made explicit to people who could have overruled you. Selection scaffold: pick a case where you said no or not yet to a team; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Uses data and tools to diagnose operational problems, role-family requirement, no source | none given | none | [generic] | discovery | Strong evidence is a diagnosis that started from a number and ended in a change. Selection scaffold: pick a time a figure moved and you worked out why; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

No requirement here is a gate as the pack defines one, because none comes from a supplied or fetched source.

## Persona table

No relationship, interviewer or loop source was supplied, so the priors are flat. Depth follows the union of the hiring-manager, cross-functional and peer priors in the pack's own persona model.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: plan this, diagnose that | Medium. A hiring-manager prior puts it first, and no stated relationship rules the prior out. Depth 4 | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of gaps, motive and why now | Medium. The same prior puts it second, and every candidate has a thinnest area. Depth 4 | Rehearse the most predictable objection until it is boring: B1 is the highest-ROI prep in this pack |
| Values / Behavioral | Scenario prompts scored on past behavior | Medium. A cross-functional prior puts it first, but no values-style round is established, so the bank is not mapped to published values. Depth 3 | Choose stories you can tell from your own history; use we for context and I for contribution |
| Data-Driven Prober | Goes two levels deep on any number | Medium. Depth 3 | Know what you can and cannot say about how a figure was counted; say plainly when you do not know |
| Peer Evaluator | Seam-splitting and what would you need from me | Medium. A peer prior is possible in a multi-session final. Depth 3 | Reciprocity framing: what you bring their team as well as what you need |
| Conversational | Friendly, unstructured, still scored | Medium. Depth 3 | A pre-scripted 90-second arc for the biography question; treat casual questions as scored |
| Pressure | Interrupts, time-boxes, questions motive | Lower. Depth 2 | Pause, restate, anchor in what you can actually back, hold through two follow-ups |

## Question banks

Every row is `[generic]` and makes no claim about your past. B1 is the single most predictable objection in a pack built without your CV: replace it with your own, from the CV, once supplied.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Three teams are shipping into the same launch date and each says they cannot slip. You own the launch process. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what is fixed, who decides trade-offs, what each team depends on, what ready means. Then objective, options, a recommendation, the metric that tells you it worked, and the main risk. Challenge one premise aloud, such as whether the date is truly fixed | F1 and F5 are the requirements this live problem scores. CASE because it is delivered live with no claim about your past |
| A2 | "A launch-readiness metric your leadership watches dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Start with the definition and whether instrumentation changed, then segment by team, time and cohort, then rank hypotheses and say which data you pull first. Name what would change your mind | F2 and F6. CASE with JD content: it scores diagnosis, not recall |
| A3 | "Design how a product team hands a new feature to the teams that support customers. What do you need to know first?" | CASE | [generic] | Clarify who receives, what they need, and what fails today. Propose a minimal mechanism, how you would pilot it with one team, and how you would know others adopted it without you pushing | F3. CASE because the mechanism is a design problem, JD because mechanisms are the role's core output |
| A4 | "You have ten requests from product teams for operational help and capacity for three. How do you choose?" | CASE | [generic] | State your criteria aloud, who is affected by each choice, which choices are reversible, and how you communicate the seven that wait. Show the trade-off, not the answer | F5. CASE because it forces a visible trade-off |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Name the real answer before they do, say what you would do in the first 30 days to close it, and do not bluff a competency the interviewer owns. If your honest weakest area comes to mind slowly, that is the finding: settle it before the interview | Asked in some form by any skeptical interviewer across F1 to F6. JD because it scores the role's responsibilities, gaps included |
| B2 | "Why product operations, and why this move now?" | JD | [generic] | Three beats: what pulled you toward the work, what in your own history led there, why this role. If the real reason is messier than a clean arc, say it plainly and keep it short | Motivation consistency is what the Skeptic scores. JD because it tests fit with the role, not a skill |
| B3 | "Product operations sits between teams that each have their own priorities. What stops you becoming a coordinator rather than someone who drives outcomes?" | JD | [generic] | A plan, not a history: what you would write down, who you would get decisions from, and how you would show a team the cost of the alternative. Say how you would handle having no authority | F5 and F1. JD because it tests how you would operate in the role |
| B4 | "Imagine three months in, and the teams you support are not using what you built. What went wrong?" | JD | [generic] | Diagnose the structure: whose problem it solved, who was asked, what it cost them to adopt. Say what you would do in week one of finding out | F3. JD because it tests judgment about adoption |

### C. Values / Behavioral

This bank is not mapped to Stripe's published values: no values page was read, and no loop source documents a values round.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a working relationship intact afterwards. Choose one where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4. VAL because it scores past behavior |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two pulled apart, name what it cost internally, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5. VAL because the stem tests priorities under tension |
| C3 | "Tell me about a time you told a team something they did not want to hear about their own launch." | VAL | [generic] | Selection scaffold: pick a case with a specific message, a specific audience and what happened to the plan. Use I for what you said and we for the context. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 and F1. VAL with EXP content: it scores candor with peers |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a figure you have reported to leadership. Walk me through how it was counted." | EXP | [generic] | Answer slot: say how it was counted, what it is sensitive to and which part was yours, in your own words. If you do not know how it was counted, say so plainly and return to what you do know | F2. EXP because it tests how a figure survives scrutiny |
| D2 | "Which assumption behind that figure would you defend least?" | EXP | [generic] | Name the assumption yourself, before they do: it turns a gotcha into a credibility gain. If you cannot name one, say so plainly and say how you would find it | F2. EXP because it tests whether you know your own assumptions |
| D3 | "Which metrics would you track to know a launch process is working, and what would each fail to tell you?" | JD | [generic] | A plan: a small set of metrics, each with the blind spot you would watch for and the question you would ask a team to cover it | F2 and F6. JD because it tests how you would measure the role's output |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam: who decides what, how disagreements escalate, what you bring the other team. Then ask what the seam is today | F1 and F5. JD because it tests partnership fit |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an occasion where credit could have gone either way and say what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1. VAL because credit-sharing is a behavior probe |
| E3 | "What would you need from me in your first month?" | JD | [generic] | Reciprocity framing: two or three specific asks, then what you would give back. Do not ask for everything | F1. JD because it tests how you would work with this team |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Pre-script a 90-second arc in three beats from your own history, ending on why this role is the next step. Tell it in your own words and keep each beat to what you actually did | Biography questions are scored even when casual. EXP because it tests how you describe your own path |
| F2 | "Why Stripe, and why now?" | CO | [generic] | This pack read no Stripe source and supplies no Stripe fact. Do the reading yourself, then give one specific reason you can say truthfully; if nothing specific is ready, that is the thing to fix before the interview | F1 to F6 are the role; the company reason is separate. CO because it tests homework |
| F3 | "What are you actually playing with these days in your own work?" | JD | [generic] | Name one real tool or method and what you tried with it. If nothing comes to mind, say so plainly and say what you would try first | F6. JD because casual questions about hot topics are still scored |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then give two things you can back from your own history. Hold through two follow-ups before conceding anything real, and concede specifically | Composure is what Pressure scores. JD because the answer is your fit with the role |
| G2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Hold-then-concede: say the parts that were yours in the verbs you can back, name what others did, and concede any limit explicitly. Never fold the core claim just to restore harmony, and never widen it | F1. EXP because attribution honesty is what the question tests |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 cross-functional launch process | A1, B3, C3, E1, E2, E3, G2 |
| F2 operating metrics | A2, D1, D2, D3 |
| F3 mechanisms other teams adopt | A3, B4 |
| F4 senior stakeholder communication | C1, C3 |
| F5 trade-offs without authority | A1, A4, B3, C2, E1 |
| F6 data and tools for diagnosis | A2, D3, F3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first six months look like for the person in this role, and what would you hope they had changed?" | Shows you think in outcomes and gives you the success bar in their words |
| R2 | "Which team's work does this role touch most, and where is the handoff least settled?" | Shows you look for the seam first, and surfaces the real problem |
| R3 | "How do product teams learn about changes to launch process today, and what is working or not?" | Shows operating curiosity and tells you what you would inherit |
| R4 | "How is the impact of this role measured, and who reviews it?" | Signals you want to be held to a metric |
| R5 | "What is something you wish you had known before you joined?" | Invites a candid answer and turns the interview into a conversation |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No sentence of yours was supplied, so there is no wording to stretch and no stated negative to give back | Every guidance cell is a selection scaffold or an answer slot ending in an honest branch. Nothing here says what you did |

## Sources

Provided documents: none. A dossier was not present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Queries sent, all refused: "Stripe operating principles values"; "Stripe interview process Product Operations final round"; "Stripe strategy news 2026"; "Stripe Product Operations Manager job description".

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Every call refused. It would have fed the values cheat sheet and the VAL bank; both are generic or absent |
| 2. Stripe interview process, role family | unavailable | Every call refused. It would have replaced the generic archetype and set persona weights from named rounds |
| 3. Stripe strategy and recent news | unavailable | Every call refused. It would have grounded CO and CASE questions and a grounding brief; F2 is generic |
| 4. Interviewer name and company | n/a | No name was given, so no query could be formed; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Every call refused. It would have turned the six role-family rows into quoted, `[inferred]` requirements |

## Upgrade menu

- The job description text → the six `[generic]` requirement rows become quoted `[grounded]` rows, and each gets a JD-tagged question
- Your CV → the evidence cells fill from your own sentences, the bank stops being selection scaffolds where a sentence of yours carries a story, and B1 is replaced by your own most likely objection
- Who you meet, in what order, and their titles → persona weights replace the flat ones and the bank can be split into per-session mini-packs
- An interviewer's name → an interviewer read and a reverse question tied to their path
- The recruiter's prep email → coverage of any pre-declared deliverable and stated focus areas
- Web research for Stripe's values, loop and strategy, once search is permitted → a values cheat sheet if a values round is documented, and grounded CO and CASE questions; a deeper pass would be up to 6 more searches and 2 more fetches, several more minutes
- How much prep time you have → a prioritized schedule sized to it
- A `tuesday-dossier.md`, if you have one → verified evidence and a constraint on what the pack may coach
