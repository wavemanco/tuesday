Web searches were refused, so I'm building the pack from your inputs only and recording that in the Sources section. I'm writing the pack file now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-1-denied-2dac5d0e/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`.

I built it for a peer conversation with Dan, using only what you gave me. My three web searches (Northwind's values, its interview process, Dan's public footprint) were refused. Nothing in the pack comes from public research, and the Sources section records each refused search.

It has 22 questions across seven personas, each tagged by type with answer guidance, a provenance quote and a rationale. The Data-Driven Prober and Peer Evaluator banks carry five questions each, because Dan is a peer and calls himself "relentlessly data-driven".

The pack also has a fit snapshot, a short grounding brief from your research note, a read on Dan, six reverse questions, a requirement-coverage table and a list of claims the pack won't coach.

The highest-value rehearsal is C1: Priya has no classic sales-ops or quota-setting experience, and Dan lives in that world. The pack rehearses a plain acknowledgment of that gap, then only what her own sentences carry, with the follow-ups and concession wording spelled out.

I can play the Skeptic on C1 as a live drill whenever you want.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions, or convert the pack to a Word document.

Two questions would reshape the pack:
1. Did the recruiter say what Dan will cover, or announce anything Priya should bring (a POV, a case)? A named deliverable would add a graded build section and could reweight the personas.
2. Can you paste the JD and Priya's resume lines verbatim? The fit snapshot currently quotes your summaries, so her exact wording would replace them. It would also show whether the JD has requirements or gate terms (location, travel) that your highlights left out.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer, both reporting to the same VP. **Format:** one 60-minute conversation.

Built from the coach's summary of the JD highlights, the candidate's background and Dan's profile, plus the coach's research note. It is not built from the full JD or CV text, and the web searches I tried were refused, so no public research is in it (see Sources). The pack is written to Priya, so "you" means her.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: the only things that describe your past are your own sentences, quoted in the Provenance column. An answer slot is an instruction for the interview, not a question for you to answer here: say what is true, in your own words, or say plainly that the step was not yours or never existed.

| Type | What it is scoring |
|---|---|
| VAL | Behavioral and values alignment: whether past behavior shows what the company publishes as its values |
| EXP | Work-experience deep-dive: whether the claims survive scrutiny and what was actually yours |
| JD | Role and JD-driven: whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge: whether you can think at Northwind's altitude |
| CASE | Hypothetical or live problem: structure and reasoning, delivered live |

**Highest-ROI prep in this pack: C1**, the objection that you have not done classic sales-ops or quota-setting work and would sit next to the person who lives in that world. It will be asked in some form. Rehearse it until it is boring, then rehearse A1 and A2, because Dan describes himself as "relentlessly data-driven".

## Fit snapshot

The JD side is quoted from the highlights you supplied, not from the full posting. No highlighted requirement is a gate (a legal, credential, location or pay term), so no row is a hard gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | transferability | Your material says product strategy and ops, not go-to-market, and the words stay there: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two-product-lines line makes a probe on whether any of that work was go-to-market likely. If some of it was, say which part and what yours was, in your own words; if none of it was, or it was not yours, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [inferred] | discovery | The sentence shows a proposal and a credited uplift, and does not show whether it touched stages of a customer lifecycle. Words stay at "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD's land, adopt, expand and renew line makes a probe on lifecycle stages likely. If your work looked at any of them, say which and what you found, in your own words; if it did not, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | presentation | The sentence names the tools and says nothing about analyses done. Lead with it in its own terms: "I am skilled in SQL and Tableau." Nothing is added about work done with them; A4 rehearses the story-selection |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model for partners, used in negotiations, not the design of a partner motion, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the requirement is stated as required, so expect a probe on motion design. If any part of the model informed how a partner motion was designed, say which and how, in your own words; if it fed negotiations only, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | A quote already reaches this in other terms, with nothing inspected behind it. Lead with it in its own terms: "I set annual volume targets with cross-org consensus." Say targets, not quotas, and do not widen "consensus" into who gave way |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The sentence is daily use of AI tools. Lead with it in its own terms: "I use AI tools daily." The pack's observation is that the material shows use and does not show building or shipping any AI product |
| F7 | Fluency in sales-ops and quota-setting, as the peer's function would read the role (no JD highlight quotes it) | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it is stated in your own notes. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to that work, and nothing added to make the gap feel smaller |

## Grounding brief

A short brief taken from your research note, whose date I do not know. Treat the framing as possibly dated and check it against anything newer Dan says.

| Item | What the note says | Provenance | Where it is used |
|---|---|---|---|
| Stated priorities | "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" — your research note | [grounded] | D2, D3, C3, reverse questions |
| Competitive frame | "bundling by a much larger platform vendor" — your research note | [grounded] | D2, D3, reverse questions |

## Reading the interviewer

Public footprint was not researched (searches refused). This read rests only on Dan's profile as you described it, and nothing in it is a personality inference.

| # | What the profile says | Source | What it implies |
|---|---|---|---|
| I1 | Self-describes as "relentlessly data-driven" | Dan's profile, via your message | Every number you give gets probed to its assumptions. Know what you can and cannot say about how each figure was counted, and say plainly when you do not know. See A1 to A3 and G1 |
| I2 | Career spine is pricing and monetization roles | Dan's profile, via your message | Native language is pricing, packaging and unit economics, so expect case questions tilted that way (D2) and a collegial interest in how you built your revenue model (A3) |
| I3 | One early-stage-startup chapter | Dan's profile, via your message | Builder stories tend to land with him, and he may probe the pace of a large-company background. Your material has no sentence about a startup, so do not reach for one; answer pace questions from what you actually did |
| I4 | Mirror opportunity: shared vocabulary (revenue and monetization economics) | Dan's profile, via your message; F4 | Pair his monetization spine with one sentence, said at its own scope: "I built a partner-level revenue model used in carrier negotiations." Do not describe the model as pricing work or imply a monetization role you did not state |

## Persona table

Weights follow three passes, shown so you can correct me.

1. **Relationship prior (peer):** Peer Evaluator and Data-Driven Prober dominate.
2. **Interviewer signals:** "relentlessly data-driven" lifts the Prober. The pricing spine tilts the Case bank toward pricing and bundling. The startup chapter adds a light Skeptic probe on pace, and F7 means the Skeptic is not optional.
3. **The loop:** one session with Dan is the whole loop, per your note. No values round is documented, so Values stays low, but it is touched in case he borrows a behavioral stem.

| Persona | Bank | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | A | Line-by-line probing of the ARR figure and the revenue model, two follow-ups deep | Top (5 questions): peer prior, plus I1 | Know what you can and cannot say about how each figure was counted; name the weakest assumption you know of before he does; if you did an analysis yourself, offer to walk it end to end |
| Peer Evaluator | B | Seam-splitting between his team and yours, credit, disagreement with equals | Top (5 questions): peer prior | Offer what you bring his team, not only what you need; propose seam principles rather than pretending to know the seam; use disagreement stories that show spine and tact |
| Skeptic | C | Quiet, persistent probing of the sales-ops gap and partner-motion design | Mid (3 questions): F4 and F7 are real gaps, and C1 is the deepest rehearsal in the pack despite the weight | Rehearse the single most predictable objection until it is boring; bridge only from your own sentences; give calibrated candor over bluffing a competency he owns |
| Case/Strategist | D | A live problem on the new products, with a pricing or bundling angle | Mid (3 questions): I2 and the Compass priority | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Conversational | E | A friendly opener, and a casual question on AI | Low (2 questions): an opening in a peer conversation is likely but short | A tight 90-second arc; treat the casual AI question as scored |
| Values/Behavioral | F | A behavioral stem, if he borrows one | Low (2 questions): no values round is documented | Choose stories where the hard truth actually landed; if none comes to mind, say so plainly |
| Pressure | G | Time-boxed, devil's-advocate versions of the attribution and gap questions | Low (2 questions): a peer is less likely to run this register, but F2 and F7 invite it | Pause, restate, hold through two follow-ups, concede only what is true and specific |

## Question banks

IDs run by persona so the drill can reference them. Provenance quotes are the only sentences the guidance rests on. A row with no quote makes no claim about your past. Types hold one tag each; where a second tag applies, the rationale says so.

### A. Data-Driven Prober (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Tell it at the sentence's scope: you proposed the change, and the figure is what it was credited with. Answer slot, the four that a figure raises, each in your own words: how it was counted; what it is sensitive to; which assumption behind it you would defend least; which parts of the outcome were yours. Where you do not know how it was counted, say that plainly and return to the proposal | F2 holds the headline figure, which a prober goes to first. EXP because it tests attribution and counting |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name it before he does. Answer slot: if you know which assumption you would defend least, name it and say why, in your own words; if you do not know the figure's basis well enough to say, say so plainly and return to the proposal. Do not supply a method or a baseline you cannot repeat under a second question | Persona stem for the Prober, and it turns a gotcha into a credibility gain. EXP as a follow-up depth on F2 |
| A3 | "You built a partner-level revenue model used in carrier negotiations. Walk me through it." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on the sentence: you built it, it was partner-level, it was used in carrier negotiations. Tell those three beats in your own words. Answer slot: his self-described data focus makes a probe on how the model was built likely; say what it covered and what you did, and if parts were someone else's, or you do not know how a part was determined, say so plainly and return to the sentence. Second slot: who used it in the negotiations and what part you took there; if you were not in the room, say so | F4 is the nearest evidence to the partner requirement and, by I2, the most natural bridge to Dan's own domain. EXP because it tests what was actually yours |
| A4 | "This role runs independent analysis in SQL and Tableau. Tell me about an analysis you took end to end." | JD | [grounded] "skilled in SQL/Tableau" | No sentence of yours carries a story, so this is a selection scaffold. Say the sentence: "I am skilled in SQL and Tableau." Then pick an analysis where you can state the question, the data you pulled, the answer, and the decision that followed, because he may ask you to walk it. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run the first analysis in the role | The JD line is the raising source, and F3 has a skill with no work behind it. JD because it scores a stated requirement |
| A5 | "Compass adoption looks flat while seats sold are up. How would you diagnose that?" | CASE | [generic] | Clarify first: what counts as adoption, which accounts, over what period. Then structure it: define the metric, segment, form hypotheses, say which cuts you would pull in SQL, name risks. Challenge one premise respectfully, for example whether seats and adoption are the same thing. The question asks about no past | A live data problem on the Compass priority from the grounding brief, tied to the JD's analysis and whitespace lines (F2, F3). CASE because it scores structure under a live prompt |

### B. Peer Evaluator (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Ask how it works today before proposing anything. Then offer principles, not a map: one shared set of numbers across the motions, a named owner for each decision, and an agreed route when you disagree. Say what you bring his team as well as what you need. The question asks about no past | The peer-prior stem, and F5's requirement is the JD line it scores. CASE because it is a live hypothetical |
| B2 | "You set annual volume targets with cross-org consensus. How did you get there?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Say the sentence, then tell it in your own words. Answer slot: the JD's cross-functional line makes a probe on who disagreed likely. If any group disagreed, say who and what moved them; if consensus came without disagreement, or the targets were mostly set by others, say so plainly and stay with the sentence. Say targets, never quotas | F5 is the evidence for the influence requirement. EXP because it tests what was yours and how |
| B3 | "How do you handle credit when work spans teams?" | EXP | [generic] | An open prompt, so a selection scaffold: pick a time work crossed teams, where you can say who did what and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer-persona stem. EXP because it asks for behavior, and no published value exists to make it VAL |
| B4 | "What would you need from my team in your first sixty days?" | JD | [generic] | Reciprocity first: what you would do for his team, then what you need, kept to principles such as one shared set of numbers across the motions and a standing check-in. Ask him what his team would want first. The question asks about no past | The reciprocity probe in the peer prior. JD because it scores the role's partnership with Sales Strategy |
| B5 | "Tell me about a time you disagreed with a peer and it did not resolve cleanly." | EXP | [generic] | An open prompt, so a selection scaffold: pick a time with a named stake, where you held your view and the relationship held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer-persona stem scoring spine and tact together. EXP because it asks for behavior, and F5's requirement is the line it tests |

### C. Skeptic (mid weight, deepest rehearsal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have not done classic sales-ops or quota-setting work, and this job sits next to mine. Where does that leave us?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | The highest-ROI prep in the pack. Pause and restate. Say it plainly: "I don't have classic sales-ops or quota-setting experience." Then only what your sentence carries, at its scope: "I set annual volume targets with cross-org consensus", and do not call those targets quotas. Then a ramp plan as a plan, not a past: learn from his team how targets are set and carried before proposing anything. Follow-up 1, "Why should I believe you would ramp quickly?": hold on the plan; answer slot: if you have a past case of learning an unfamiliar function quickly, name it in your own words; if none comes to mind, say so plainly and give the plan. Follow-up 2, "What can you not do on day one?": concede exactly, "the sales-ops and quota-setting work itself", and say what you would ask his team first. Follow-up 3, "How do I know this is not a polite way of saying you need hand-holding?": hold by asking what milestones he would want to see. Concede wording: "That is fair: on quota-setting I would be learning from your team, and I would rather say so now." Never fold on the sentences you can stand behind, and never claim that work | F7 is the biggest gap, stated in your own notes, and a peer in sales strategy is the likeliest person to press it. JD because it scores a gap against the role, with Pressure-style follow-ups |
| C2 | "Partner-motion design is a requirement for this role. Which part of designing a partner motion have you done?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Start from the sentence: "I built a partner-level revenue model used in carrier negotiations." The pack's observation is that your material shows partner economics and does not show motion design. Answer slot: if any part of the model informed how a partner motion was designed, say which part and how, in your own words; if it fed negotiations only, or there was no such design step, say so plainly and stay with the model. Hold through two follow-ups by returning to the model, never by adding to it | F4 is stated as required in the JD highlights and is the second likeliest objection. JD because it scores a stated requirement |
| C3 | "Why leave consumer tech for B2B data infrastructure, and why now?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" — your research note | A motivation answer has to be yours: give your own reason in your own words. Answer slot: tie it to one of the stated priorities only if that is true for you, and if no reason comes to mind, say so plainly rather than choosing one. Keep it to 60 seconds | Skeptic stem on motivation consistency. CO because a credible answer needs Northwind's stated priorities |

### D. Case/Strategist (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Take a new product line that has landed its first customers. Where is the whitespace across land, adopt, expand and renew, and what do you need to know first?" | CASE | [generic] | Clarify first: the buyer, the motion so far, what adoption means. Then objective, segmentation by lifecycle stage, approach, metrics, risks. Think aloud, challenge one premise respectfully, and name the first number you would pull in SQL. The question asks about no past | The JD's whitespace line (F2) as a live problem, and the strategist's native format. CASE because it scores structure |
| D2 | "Compass is launching and a much larger platform vendor bundles. Do you price it standalone, bundle it, or include it?" | CASE | [grounded] "an AI copilot launch ('Compass')"; "bundling by a much larger platform vendor" — your research note | Clarify before answering: who the buyer is, what the rival's bundle includes, and what profitability allows. Then take a position and say what would change your mind. Challenge the premise that these are the only three options. Expect Dan to push from his pricing background, so hold through two follow-ups and concede only what you do not know. The question asks about no past | Tilts the case toward his monetization spine (I2) and the stated competitive threat. CASE because it is a live problem, with CO content |
| D3 | "What does bundling by a much larger vendor do to our enterprise expansion motion?" | CO | [grounded] "enterprise expansion"; "bundling by a much larger platform vendor" — your research note | Use Northwind's own vocabulary and think aloud: where bundling would press first, how that sits against the profitability priority, and what you would want to see in the data. Say what you would need to know rather than asserting facts about the vendor | The company-strategy question the rubric requires, grounded in the note only. CO because it scores altitude and homework |

### E. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations" | A 90-second arc with beats from your sentences: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops, then one result sentence, "I built a partner-level revenue model used in carrier negotiations". Answer slot: close with why this role, in your own words; if you do not have a reason yet, say so plainly | The opener in a conversational register is likely and still scored. EXP because it checks economy and consistency with F1 and F4 |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say the sentence: "I use AI tools daily." Answer slot: the JD's AI line makes a follow-up on which tools and what for likely. Say which and what for, in your own words; if it is everyday use rather than building anything, say so plainly. Do not describe building or shipping anything you have not told me about | F6 is the evidence for a plus-skill, asked casually, which is still scored. JD because it tests a stated plus |

### F. Values/Behavioral (low weight)

No published values were fetched and no values round is documented, so these are generic behavioral stems, not mapped to a named value.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | An open prompt, so a selection scaffold: pick a time with a named stake, a message that was hard to hear, and a relationship intact afterward. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Behavioral stem. VAL is the closest tag for it, though no published value stands behind it, and F5's cross-org setting is where such a time would sit |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | An open prompt, so a selection scaffold: a named customer, the metric you set aside, what it cost, what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Behavioral stem, and a B2B data buyer is a plausible theme. VAL for the same reason as F1 |

### G. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That ARR result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold-then-concede. Pause and restate. Hold: "I proposed the change; the uplift is what it was credited with." Hold through two follow-ups by returning to that sentence. Answer slot: say which other parts of the outcome were yours, in your own words; if others did them, or you do not know, say so plainly and return to the proposal. Concede the limit specifically, never the core claim | The attribution probe from the persona stems, aimed at the largest figure (F2). EXP because it tests what was yours |
| G2 | "Sixty seconds: why you rather than someone who has carried a quota?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Concede first, plainly: "I don't have classic sales-ops or quota-setting experience." Then say what your sentences carry, at their scope: you built a partner-level revenue model used in carrier negotiations, and set annual volume targets with cross-org consensus. Leave the comparison to him rather than asserting you are better. Hold through two follow-ups by returning to those sentences | The time-boxed version of C1, for the pressure register (F7). JD because it scores fit against the role |

### Requirement coverage

| JD highlight | Questions that cover it |
|---|---|
| "own GTM strategy for two new product lines" | D1, D2, D3 |
| "identify whitespace across land/adopt/expand/renew" | D1, A5, A1 |
| "run independent analysis in SQL and Tableau" | A4, A5 |
| "partner-motion design experience required" | C2, A3 |
| "strong cross-functional influence" | B1, B2, B4, B5 |
| "AI experience a plus" | E2, D2 |
| Sales-ops and quota-setting fluency (not a JD highlight) | C1, G2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You have worked in pricing and monetization, and had an early-stage chapter. What from those shapes how you think about launching a new product's pricing here?" | Tied to his own path (I2, I3): it turns an interrogation into a peer conversation and shows you read his profile |
| R2 | "What could a new person in this role do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are thinking about his load, not only yours |
| R3 | "Where is the seam between your team's motion and the new products' go-to-market hardest to draw?" | Shows you expect shared territory and want to understand it before proposing anything |
| R4 | "Where does bundling pressure from the larger platform vendor show up first for your team?" | Uses the competitive frame from the grounding brief, and asks about his data and not about opinions |
| R5 | "How does the profitability priority change what you would sequence first for the new products?" | Connects the role to a stated priority and signals you think about economics as well as growth |
| R6 | "What would make you say a year from now that this hire was the right call?" | Reveals his scoring sheet, and rapport-style interviewers weight this slot heavily |

## Prohibited claims

What this pack will not coach, with its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has set sales quotas or run sales operations | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Called the volume targets "quotas" | Inflated form of F5 | F5's quote at its own scope: targets set with cross-org consensus. The limit is the pack's observation, not words for you: the material says volume targets, not quotas |
| Owned go-to-market for a product line | Inflated form of F1 | F1's quote at its own scope. The pack observes that the material says product strategy and ops. C-bank slots stay inside that scope |
| Designed partner motions | Inflated form of F4 | F4's quote at its own scope: a revenue model used in negotiations. C2's slot asks only whether any part informed motion design |
| Drove or delivered the ARR uplift | Inflated form of F2 | F2's quote at its own scope: a proposal, and an uplift it was credited with. A1 and G1 slots ask only which parts were yours |
| Ran independent analyses in SQL and Tableau | Inflated form of F3 | F3's quote at its own scope: skilled in the tools. A4 is a selection scaffold with an honest branch |
| Built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: daily use of AI tools. E2's slot allows "it is everyday use" |

## Sources

**Provided documents:** your message (role and company, JD highlights, the candidate summary, Dan's profile summary, and your research note). No dossier was present.

**Searches sent (all refused, none returned results):**

- "Northwind Data company values" — refused
- "Northwind Data interview process strategy operations" — refused
- "Dan Kovac Northwind Data Director Sales Strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The one search was refused. It would have supplied named values for VAL questions and the values cheat sheet, which is dropped, since no values round is documented |
| 2. `Northwind Data interview process` | unavailable | The one search was refused. It would have confirmed the loop and the persona weights; they rest on your description of a single session with Dan |
| 3. `Northwind Data strategy` / recent news | skipped | Your note already supplies the three stated priorities and the competitive frame the CO bank draws on; its date is unknown |
| 4. `Dan Kovac Northwind Data` | unavailable | The one search was refused. It would have supplied his public talks and writing; the interviewer read rests on the profile you described |
| 5. representative JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text → the highlight quotes in F1 to F6 become verbatim JD lines, mid-list requirements and any gate terms (location, travel, authorization) the highlights omit get checked, and uncovered requirements get questions
- Priya's resume lines verbatim, and her answers to the slots in F1, F2, F4 and F5 → each of those rows upgrades from slot to story, and A1, A2, A3, B2, C2 and G1 regenerate with your own sentences
- Any guidance from the recruiter on what Dan will cover, or a pre-declared deliverable → coverage and persona weights reweight, and a graded-deliverable section is added if one was named
- Dan's public talks or writing, once search is permitted → a more specific interviewer read and a sharper R1
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, and search permission) → a strategy brief for the CO and CASE banks, loop reports, and Northwind's published values, which would also settle whether a values round is likely
- Prep time available → a prioritized prep triage sized to it
- A tuesday-dossier.md from the job-underwriter, if one exists → verified evidence and prohibited claims arrive pre-graded; the pack does not need it
