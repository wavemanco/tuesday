I'll read the playbook's reference files and check for a dossier in the working directory.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-3-denied-3dd7b11a/stripe_product-operations-manager_interview_pack.md`.

I built it for a final round of unknown format, with persona weights blended across the likely interviewers. All four of my web searches (Stripe's values, interview process, strategy, and a sample job posting) were refused. So the pack makes no claims about Stripe and has no values sheet or company-strategy questions. It has 19 questions, all generic, plus reverse questions and a requirement-coverage table. Because I have no CV from you, your history questions are scaffolds for you to fill in, not stories I wrote for you.

Say the word and I'll play the Skeptic on B2 ("Which part of this role would you be weakest at on day one?"). It's the question most likely to come up. I can also save a tuesday-dossier.md recording the gaps this prep exposes, for later sessions. If you'd like the pack as a Word document, I'll convert it.

Two questions would reshape it:
1. Who are you meeting in the final round, and how many sessions is it? If your recruiter said anything about focus areas or a presentation, tell me that too.
2. Can you paste the job description and your CV? I'll proceed without them if you'd rather not.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Round: final round, schedule and interviewers not yet known. Built as session mode with blended persona weights. No JD, CV or interviewer name was provided, and the web searches this pack tried were refused, so every question below is labeled generic and no company fact is asserted.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Say only what you actually did, in your own words.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows what the company says it values |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny and what was actually you |
| JD | Role-driven: can you do the listed job, including its gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, solved aloud |

This pack has no CO questions. Company strategy needs research or a document, and neither was available. The upgrade menu says what would add them.

## Fit snapshot

No background was provided, so this is the worksheet variant. The requirements are role-family patterns written without a source, not quotes from a posting. Fill the evidence column yourself from your own CV before relying on any row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run launches or programs that span product, engineering and customer-facing teams (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a program you coordinated across several teams, in your own words, with your part named. Selection scaffold: pick one such program and say what was yours to decide; if none comes to mind, say so plainly, then give the nearest work your material does carry, or how you would approach it |
| F2 | Define and track product or operating metrics (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a metric you helped define or report, with how it was counted. Selection scaffold: pick one figure you reported and know the counting of; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set up the measure |
| F3 | Turn customer or field feedback into prioritized input for product teams (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a feedback loop you ran or fed, and what happened to it. Selection scaffold: pick one instance where feedback reached a decision-maker; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would build the loop |
| F4 | Build or improve processes and tooling that scale (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a process you changed and what changed for the people using it. Selection scaffold: pick one process change and the part that was yours; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would diagnose a process first |
| F5 | Influence without authority and communicate with senior leaders (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a decision you moved without owning the people involved. Selection scaffold: pick one such moment and how you handled disagreement; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F6 | Structure ambiguous problems (role-family pattern, no posting) | none given | none | [generic] | discovery | Tested live by the CASE bank rather than by your history. Rehearse the structure in the persona table so it is automatic |

## Prep triage

Not included: no prep time was given.

## Persona weights

The loop rests on the Generic archetype (screen, hiring manager, panel, flat weights), not on Stripe's documented process, because the process search was refused. A final round may be several back-to-back sessions with different relationships, so the weights blend the priors for hiring manager, peer, cross-functional and skip-level. Recalibrate as soon as you know who you are meeting.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems drawn from the role: plan this, diagnose that | High: hiring-manager and skip-level priors both lean on it, and the role is about structuring ambiguity | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of gaps, motivation, why now | High: hiring-manager prior, and a final round is where gaps get tested | Rehearse the single most predictable objection until it is boring; calibrated candor over bluffing |
| C. Values/Behavioral | Scenario probes, STAR-shaped stories | Medium: a cross-functional session is plausible, but no values round is documented for this loop | Pick stories from your own history; we for context, I for contribution |
| D. Peer Evaluator | Seam-splitting with adjacent teams, credit, collaboration | Medium: a peer from product or engineering is a common final-round seat | Reciprocity framing; offer seam principles rather than pretending to know the seam |
| E. Pressure | Interruptions, time-boxed answers, motive questions | Medium: skip-level prior | Pause, restate, hold a position through two follow-ups before conceding anything real |
| F. Data-Driven Prober | Goes two levels deeper on any number | Medium: peer and specialist priors | Know how each figure you cite was counted and say plainly when you do not know |
| G. Conversational | Friendly, unstructured, still scored | Low-medium: recruiter-style openers can appear in any session | A 90-second arc for the biography question; treat casual questions as scored |

## Question banks

Provenance is `[generic]` throughout: no sentence of yours was supplied for any question to rest on. Where guidance would describe your past, it is a selection scaffold ending in an honest branch, never a story supplied for you.

### A. Case/Strategist (weight: highest, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A change is about to ship to a large set of customers at once, and three teams each think they own the announcement. Sketch how you would get it launched. What do you need to know first?" | CASE | [generic] | Ask first who decides, what the deadline is, and what failure looks like. Then state the objective, name the groups affected, give an approach with owners and a check-in rhythm, name how you would know it worked, and name the biggest risk. Challenge one premise aloud, for example whether a single owner is needed. Makes no claim about your past | F1 and F5 are the requirements it presses; CASE because it is asked as a live decision |
| A2 | "A metric the team watches dropped twenty percent week over week. Diagnose it." | CASE | [generic] | Clarify before diagnosing: is the measure still counted the same way, over what window, for whom. Then split by segment and time, separate data problems from real change, rank hypotheses by how cheaply they can be checked, and say what you would tell leadership today versus later | F2 and F6; CASE because it scores structure over the right answer |
| A3 | "Customer-facing teams keep reporting the same product complaint in different words. Design a way to turn that into something the product team acts on." | CASE | [generic] | Say who the audience is and what decision the input should change. Propose how to group reports, how to size the issue, how to make it easy for product to act on, and how you would close the loop with the people who reported it. Name one thing you would not build yet | F3; CASE |
| A4 | "You have capacity for two of five requested process improvements for the product org. How do you choose?" | CASE | [generic] | State the criteria aloud before ranking: effect on the most people, cost to do, reversibility, dependence on others. Say whom you would consult and how you would tell the three requesters no | F4 and F5; CASE |

### B. Skeptic (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why product operations, why this company, why now?" | JD | [generic] | Give three honest reasons in your own words: one about the work, one about this company that you actually hold and can name a source for, one about timing. If no company-specific reason is one you hold, say so plainly and give the role-level reason; a reason you cannot source is the one that breaks on the next follow-up | Motivation consistency is what the Skeptic scores; JD because it tests fit for the role |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack, and the pack cannot name your weakest area from here: it is inferred that this objection will arrive in some form. Choose the F row you can least evidence once you have filled the worksheet. Name the limit plainly, then give a concrete ramp: what you would learn in the first thirty days and from whom. If your material shows no gap, say so plainly and name the area you have least depth in | The most predictable objection to any final-round candidate; the pack will sharpen it when a CV is supplied |
| B3 | "What in your background would make me doubt this is the right fit?" | JD | [generic] | Pick the doubt a fair interviewer would actually raise after reading your CV. State it before they do, in one sentence, then give the evidence that limits it, using only what you did. Hold your position through one follow-up; if you do not have a fair doubt in mind, say so plainly and describe what you would want to verify yourself | Skeptic stem; F rows are where the answer comes from once filled |
| B4 | "What would your first ninety days look like here?" | JD | [generic] | Listen and map first: stakeholders, current rituals, where work stalls. Then one small visible win, then a proposal. Do not claim to know this organization's current state; ask what you would want to learn | Hiring managers use it to test judgment without a company case; F4 and F5 |

### C. Values/Behavioral (weight: medium, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: choose a time with a named stake, a moment you did not soften the message, and an intact relationship at the end. Use I for what you said and did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5; VAL because it tests behavior under pressure from above |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: choose a decision where the customer cost was visible, say who disagreed, and what you gave up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | F3 and F5; VAL |

### D. Peer Evaluator (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Offer principles, not a map of a seam you cannot see: who owns the decision, who owns making it happen, how disagreement is escalated and recorded. Ask what the seam looks like today. Say what you would want from a counterpart and what you would give | F1 and F5; JD because it tests the role's boundaries |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: choose an occasion where credit was shared or contested, say what you did, and what the other team would say. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5; VAL |
| D3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Ask-and-offer in equal parts: what you need to learn from them, one thing you could take off their plate. Keep the offer to what a new person could credibly do | Reciprocity framing the Peer persona scores; F1 |

### E. Pressure (weight: medium, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then give two reasons that come from your own history and one honest limit. Hold the position through two follow-ups; concede specifically what you cannot yet claim, never the core | Composure is the score; F5 |
| E2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Name the result, then split it plainly: what you did, what others did, what was luck or timing. Answer slot: if the split is not clear to you, say so; if the result was mostly someone else's, say so and say what you learned from it | Attribution honesty; F1 and F2 |

### F. Data-Driven Prober (weight: medium-low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Pick a number you have reported to a leadership group. Walk me through how it was counted." | EXP | [generic] | Answer slot: say how it was counted, what it is sensitive to, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly and say how you would find out. Never describe a method you did not use | F2; EXP because it tests whether a headline figure survives scrutiny |
| F2 | "Pick a figure you have reported. Which assumption behind it would you defend least?" | EXP | [generic] | Name the weakest assumption yourself before they do; this converts a gotcha into credibility. If you do not know the assumptions behind it, say so plainly | The weakest-assumption move; F2 |

### G. Conversational (weight: low-medium, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc from your own CV: where you started, the two or three turns that mattered, and why this role is next. Every beat must be something you can expand on for two minutes | A casual opener that is still scored; F1 to F5 |
| G2 | "What have you been reading or trying lately that has changed how you think about product work?" | JD | [generic] | Choose something you actually used, say what it changed in how you work, and one thing you are not convinced by. If nothing comes to mind, say so plainly and name what you would like to learn | Casual register, scored on genuine interest; F4 |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 launches across teams | A1, D1, D3, E2, G1 |
| F2 metrics | A2, E2, F1, F2, G1 |
| F3 feedback to product | A3, C2 |
| F4 process and tooling | A4, B4, G2 |
| F5 influence and senior communication | A1, A4, B4, C1, C2, D1, D2, E1 |
| F6 structured problem-solving | A1, A2, A3, A4 |
| Company strategy | none, no research or strategy document was available |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does this role need to accomplish in its first year that the job description does not capture?" | Shows you are scoping the real job, and the answer tells you what the team is worried about |
| R2 | "How does the team decide what product operations should say no to?" | Signals you know the role is about prioritizing and protecting focus |
| R3 | "What would tell you at day thirty that this hire is on track?" | Turns the interview into a shared definition of success |
| R4 | "Where does the product org's process create the most friction today, in your view?" | Invites a candid answer and shows you think in terms of problems to solve |
| R5 | "How do you decide when a process or ritual should be retired?" | Shows you treat process as a cost, not an achievement |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer; use it only if a peer is in the loop |

Tie one question to each interviewer's own path once you have their names.

## Prohibited claims

No entries. No CV or message about your past was provided, so there is no sentence of yours for this pack to inflate and no negative you stated. Every question about your history is an open prompt or a selection scaffold. Once you supply a CV or answers, this section is rebuilt against them before any guidance is written.

## Sources

Provided documents: your message only, which gave the company, role and round.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have supplied the published value names for a values cheat sheet and VAL mapping; the search was refused |
| 2. Stripe interview process, product operations | unavailable | Would have established the loop and moved persona weights; the search was refused, so the Generic archetype stands |
| 3. Stripe strategy and recent news | unavailable | Would have supplied CO and strategy-grounded CASE questions; the search was refused |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. representative Product Operations Manager JD | unavailable | Would have supplied requirements for the fit snapshot and JD-tagged questions; the search was refused |

Searches sent:

- Stripe operating principles values: refused
- Stripe interview process Product Operations Manager final round: refused
- Stripe strategy 2026 annual letter priorities: refused
- Stripe Product Operations Manager job posting responsibilities requirements: refused

## Upgrade menu

- The job description, pasted: the six role-family rows become quoted requirements, and the JD-tagged questions become grounded in them
- Your CV, pasted: the worksheet becomes a real fit snapshot, the story scaffolds become story maps, and B2 is sharpened to your actual weakest area
- The final round's schedule and who you meet, from your recruiter: per-session mini-packs with their own persona weights; if your final is several sessions, send the schedule
- The recruiter's guidance, including any deliverable or presentation: a build section for each
- Interviewer names: an interviewer read and a reverse question tied to each path
- Web research allowed, or Stripe's values page, a description of its loop and a strategy brief pasted: a values cheat sheet if a values round is documented, CO questions, and a grounding brief
- A tuesday-dossier.md from a prior role evaluation, if you have one: verified evidence and prohibited claims arrive ready to use
