Researching Saltmarsh Games and Tobias Wrenfield's public footprint now, then I'll build the pack.
Femi, your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-denied-7be46942/Saltmarsh-Games_live-operations-producer_interview_pack.md`. It has 18 questions across six interviewer styles.

I built it for a hiring-manager round, since you didn't say how Tobias fits in. Web search was refused in this session, so nothing in the pack about Saltmarsh's values, interview format, strategy or Tobias's background comes from research. Questions that depend on those are labeled generic, and the upgrade menu says what permission to search would add.

The question to rehearse most is B2: "Your background doesn't include in-app purchases, and we'd have you running the calendar for two of our titles. How do you get up to speed?" The pack coaches you to say plainly that you haven't worked on a game with in-app purchases, hold to what you actually ran, and give a ramp plan in your own words.

- **Drill:** say the word and I'll play the skeptical interviewer on B2, with follow-ups.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- **Word version:** I can convert the pack to a Word document if you want one.

Is Tobias the person you'd report to, his boss, or a peer, and did the recruiter say anything about format or an exercise to prepare? Either answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh-Games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Interviewer:** Tobias Wrenfield, Head of Live Operations
- **Relationship (assumed, not confirmed):** hiring manager, 60 minutes, Friday
- **Candidate:** Femi
- **Built from:** the JD and background you pasted. Web search was refused in this session, so nothing here about Saltmarsh's values, interview loop, strategy or Tobias's public profile comes from research (see Sources).

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | A stated responsibility or requirement in the posting, gaps included |
| CO | Company and strategy homework |
| CASE | A live problem from the role, structured aloud |

An answer slot is an instruction for the interview, not a question for me. Question IDs are letter-by-persona; the letters skip F so they never collide with fit-snapshot rows.

## Prep triage

Between now and Friday, in this order:

1. B2, then B1 and B3. This is the highest-ROI prep in the pack: say the plain acknowledgments and the ramp plan aloud until they sound boring.
2. B4 and F5. Know what your first two years held, because the JD's years line makes this probe likely.
3. C1, C2 and D2. Be ready to say exactly what was yours in the calendar and the retention numbers.
4. A2 and A5, then A1. Practice clarify-first structure aloud on live problems.
5. E2. Play both titles before Friday; your material does not name them.
6. Pick three reverse questions.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not live events and not two titles, with nothing inspected behind it, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely. If you ever ran or shared more than one, say which and how; if you did not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not establish this; it does not say who you worked with on a drop. Answer slot: if you coordinated any of these four groups on a drop, say which and how, in your own words; if you did not, or someone else did, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | discovery | Presenting numbers is not owning a review or the KPIs it reports, and the words stay at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose or computed any of those numbers, or ran a review of an event, say which and how; if the numbers came from someone else, or there was no such review, say so plainly and stay with the presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it, with nothing inspected behind it; it does not say how releases ran against it. Lead with the quote's own terms: "I wrote the release checklist our QA team still uses." Answer slot: if you ran any release against it with QA, say how; if you did not, or it was not yours, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | A years requirement is graded like any other row. Your material gives four years as an associate producer and two on a content-drop calendar; it does not say whether the title was live-service or what the other two years held. Answer slot: if the title was live-service, say how it ran live, in your own words; if it was not, or those years were different work, say so plainly and stay with the quotes |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap in terms, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you ran it, weekly, for the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote already reaches retention numbers in other terms. Lead with it at its scope: "I presented the monthly retention numbers to the studio head." It does not say how the numbers were counted, and the bridge adds nothing to it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The quote shows a written document in use; it does not show how clear anyone found it, and the pack cannot judge that. Answer slot: if QA or anyone else gave you feedback on the checklist's clarity, say what it was; if none, say so plainly, and share the checklist itself as a sample if you can |
| F9 | Not asked by the JD; a gap you named. Nearest JD line: "coordinate design, art, engineering and community teams on each update" | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." Then how you would work with those teams, said as a plan and never as a past |
| F10 | Not asked by the JD; a gap you named. Nearest JD line: "own the post-event review and the KPIs it reports" | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then what you would learn first and from whom, said as a plan and never as a past |

## Persona table

Assumption: a hiring-manager round, since you did not say. Tell me otherwise and every weight below recomputes.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on the role: plan this, diagnose that | Top, 5 questions. Hiring-manager prior; no research or interviewer signal adjusts it | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Skeptic | Quiet, persistent probing of gaps and "why you" | Top, 4 questions. Hiring-manager prior; your own message names two gaps (F9, F10) and F5 leaves the first two years open | Rehearse the single most predictable objection (B2) until it is boring; bridge only from what you stated; ramp plan in your own words |
| Data-Driven Prober | Reads the CV line by line; asks how numbers were counted | Mid, 3 questions. The JD names retention metrics and your message names monthly retention numbers (F3, F7); no interviewer signal found because search was refused | Know what you can and cannot say about how each number was counted; say plainly when you do not know |
| Pressure | Time-boxes, challenges "why you" and "how much was you" | Low, 2 questions. Not in the hiring-manager prior; kept because stated gaps invite it | Pause, restate, anchor in what you stated; hold through two follow-ups, then concede specifically |
| Conversational | Friendly biography and company questions that are still scored | Low, 2 questions. Casual-register openers arrive in every persona mix | A 90-second arc; treat casual questions as scored |
| Values/Behavioral | Scenario probes, STAR-shaped stories | Low, 2 questions. No values-style round is documented by any source I could read | Story where the hard truth landed; where your material shows none, say so |
| Peer Evaluator | Seam-splitting, credit-sharing | Not banked. Not in the hiring-manager prior; tell me if Friday includes a peer and I will add a bank | Reciprocity framing; seam principles |

## Question banks

### A. Case/Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Next week's biggest update has slipped by a week, and two of our titles have events booked around it. Walk me through what you do." | CASE | [generic] | Clarify before you structure: what slipped and why, what players were already told, which teams and events depend on it, what the studio most needs from that week. Then objective, options, who you tell and in what order, and what you would record for the post-event review. Think aloud and challenge one premise. The question needs no claim about your past, so the guidance makes none | Live problem from the JD's calendar and coordination lines (F1, F2); CASE because it is a live decision |
| A2 | "Retention for players who joined during last weekend's event is down 20% on the previous event. Diagnose it." | CASE | [generic] | Clarify first: which retention measure and which day, how the cohorts were cut, how large they are, whether anything besides the event changed. Then segment, list hypotheses, name the data each would need, and say which you would check first and why. Close with what you would report and to whom. No claim about your past | The Case persona's diagnose stem applied to the JD's retention and post-event lines (F3, F7); CASE because it is live |
| A3 | "Sketch the release checklist for an update that needs design, art, engineering, community and QA. What do you need to know first?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Clarify before you list: what kind of update, which platforms, what must be true before players see it. Then the structure of the checklist you would build. If you refer to your own, the beats the sentence states are that you wrote it and that QA still uses it; tell them in your own words. Answer slot: the JD says manage the checklist with QA, so expect a probe on how releases ran against it. If you ran any release against it with QA, say how; if QA or someone else ran it, or there was no such step, say so plainly and stay with the checklist you wrote | F4 is the evidence for the checklist line and F2 sets the coordination scope; CASE delivery, with JD content |
| A4 | "Two of our titles both want the same weekend for a big event. How do you decide what runs?" | CASE | [generic] | Clarify first: what each event is meant to achieve, which teams and players overlap, what is already announced. Then your criteria, who decides and who advises, what you do about the event that loses, and what gets written down. Challenge one premise: do they really conflict? No claim about your past | Directly tests the JD's two-titles line (F1); CASE because it is a live trade-off |
| A5 | "What goes in a post-event review, and who reads it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure it aloud: what the review is for, what happened against what was planned, which retention measures you would report and what each is sensitive to, what changes next time, and the written form it takes. For the audience beat you can use your own sentence: "I presented the monthly retention numbers to the studio head." Answer slot: the JD says own the review and its KPIs, so expect a probe on which numbers were yours. If you chose or computed any of the numbers you presented, say which and how; if they came from someone else, or you did not choose them, say so plainly and stay with the presentation | JD because it scores the review-and-KPI line (F3); CASE delivery; the written form also touches F8 |

### B. Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick the one you actually think is weakest and say it first. Your material names two gaps, so plain words exist for either: "I haven't led a team." or "I haven't worked on a game with in-app purchases." Then say what you would do in your first month, as a plan, in your own words. Do not pick the answer that feels safest | The Skeptic's standard stem; F9 and F10 are the gaps you named, so it lands there |
| B2 | "Your background doesn't include in-app purchases, and we would have you running the calendar for two of our titles. How do you get up to speed?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Concede the gap in its stated words: "I haven't worked on a game with in-app purchases." Then give a ramp plan in your own words: what you would learn first, from whom, and by when. A plan is a promise, not a past; keep it to what you would actually do. Hold through two follow-ups by returning to the quote, never by adding to it; if pushed on whether the gap matters, say what you do not yet know rather than that it does not matter | F10 is the gap you named and F1 the scope the JD sets, so this objection arrives in some form and a rehearsed, non-defensive answer changes the interview; Skeptic delivery on a JD line |
| B3 | "You haven't led a team, and the JD has you coordinating design, art, engineering and community on each update. How do you get them moving on one schedule?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Plain words first: "I haven't led a team." Then the calendar, as quoted: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD asks about coordinating four groups. If you coordinated any of them on a drop, say which and how, in your own words; if you did not, or someone else did, say so plainly and stay with the calendar. Then your plan, in your own words, for how you would work with each | F9 and F2: the stated gap meets the coordination line |
| B4 | "You have four years as an associate producer and the last two on the weekly calendar. What were the first two?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Start from the quote: "4 years as an associate producer at a puzzle-game studio." Answer slot: the JD asks for 3+ years producing live-service games or apps, so expect this probe. If those first two years were on a live-service title, say what you did and how it ran live, in your own words; if they were on something else, or were different work, say so plainly and stay with the two years on the calendar | F5; a years requirement is graded like any other row, and this is where it surfaces |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F1: the weekly calendar, the main title and the two years are the beats the quote states; tell them in your own words. Answer slot: the JD's live-events line makes a probe on how content got onto the calendar likely. If you decided what went into a week, say how you decided; if what went in was decided elsewhere, or there was no such decision, say so plainly and describe how you kept the calendar | F1 and F6 are the calendar evidence and the likeliest lines to be read closely; EXP because it tests what was yours |
| C2 | "Walk me through the retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start from the quote: "I presented the monthly retention numbers to the studio head." Then defend the numbers, each in your own words: how they were counted, what they were sensitive to, the assumption behind them you would defend least, and which part was yours. If you do not know how they were counted, say so plainly before the interviewer finds it | F3 and F7; the retention line is the likeliest to be taken apart; EXP because it tests attribution |
| C3 | "Which retention measures would you put first in a post-event review, and what is each one sensitive to?" | JD | [generic] | Choose measures you can define in your own words and say what each depends on. If there is one you have not used, say so plainly. The ordering and the reasons are the answer, not a list. No claim about your past | F7 requirement; JD because it scores the retention line directly |

### D. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | Pause, restate the question, then answer from the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Hold that position through two follow-ups. Concede specifically and once: "I haven't worked on a game with in-app purchases." Never claim equivalence to the hypothetical candidate, and never fold on the calendar just to restore harmony | The Pressure persona's why-you stem; F1 and F10 |
| D2 | "That calendar you ran: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause and restate. Anchor in the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours and which others owned, in your own words; if it was shared, or priorities were set elsewhere, say so plainly. Hold the stated verb through two follow-ups and concede only what you actually know | The Pressure persona's attribution stem; F1 and F6 |

### E. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from your own sentences, in this order: the four years, the calendar, the checklist, the monthly retention presentations, each at the scope of its quote. Answer slot: why live operations and why Saltmarsh is not in your material; say it in your own words in a sentence or two, and if you have no reason yet, say what you want to find out | The biography opener is scored; F5, F6, F4 and F7 supply the beats; EXP because it tests the story's consistency |
| E2 | "What have you played of ours?" | CO | [generic] | Play both titles before Friday. The JD says two mobile titles, but your material does not name them and I could not research them, so this guidance holds no fact about Saltmarsh. Say only what you saw yourself, in your own words; if you noticed something about how a title handles events or updates, say that, and if you have not played them, say so plainly rather than guessing. Never assert how Saltmarsh runs events unless you have seen it | A casual-register company question that is still scored; CO because it tests homework; no research ran, so it stays generic |

### G. Values/Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a working relationship still intact; the hard truth has to have actually landed. Your material shows monthly retention presentations to the studio head and does not show a time the numbers were unwelcome; that is the pack's observation, not a story to borrow. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I presented the monthly retention numbers to the studio head.", or how you would handle it | The Values persona's standard stem; the review-and-KPI line (F3) makes reporting hard numbers the likely angle |
| G2 | "Tell me about a time you disagreed with design or engineering about when something should ship." | VAL | [generic] | Selection scaffold: pick a time with a named disagreement, a position you held and why, what the other side wanted, and how the working relationship stood afterward; "we" for context, "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Raised by the JD's coordination line (F2); VAL because it scores behavior with the teams the JD names |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, A4, B2, C1 |
| coordinate design, art, engineering and community teams on each update | A1, A3, B3, G2 |
| own the post-event review and the KPIs it reports | A2, A5, C2, G1 |
| manage the release checklist with QA | A3 |
| 3+ years producing live-service games or apps | B4, E1 |
| experience running a content calendar | C1, D1, D2, E1 |
| comfortable with player-retention metrics | A2, C2, C3 |
| clear written communication | A5 only, as the review's written form; a spoken question cannot show writing, and a sample is in the upgrade menu |
| Gaps you named (F9, F10) | B1, B2, B3, D1 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "What would you want the person in this role to have changed by the end of their first three months?" | It tells you what you will be scored on and shows you are planning to land something | [generic] |
| 2 | "When two titles want the same week, who has the final say today?" | It probes decision rights rather than scheduling, the seam A4 tests | [generic] |
| 3 | "Which KPIs does the post-event review report today, and which would you change?" | The JD says the role owns them; asking shows you read the line as a responsibility | [generic] |
| 4 | "If monetization touches the events calendar here, where would I learn how it works in my first month?" | It turns the gap you named into a ramp question before the Skeptic raises it | [generic] |
| 5 | "What would you change about the release checklist the team uses today?" | It shows you take the JD's checklist line seriously and invites the team's view of your own area | [generic] |
| 6 | "What would tell you, six months in, that this hire is working?" | It ends the slot on measurement; a generic "no questions" is a missed signal | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." Then a plan, never a past |
| Has worked on a game with in-app purchases | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't worked on a game with in-app purchases." Then a plan, never a past |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a content-drop calendar for your main title, not live events and not two titles. B2's and C1's slots stay inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The material says you presented the numbers, not that you owned the review or chose the KPIs. A5's slot stays inside the presentation |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope. The material says you wrote the checklist and QA still uses it, not that you managed releases. A3's slot stays inside the checklist |
| Has 3+ years producing live-service games | Inflated form of F5 | F5's quotes at their own scope. The material says four years as an associate producer and two on the calendar; it does not say the title was live-service. B4's slot stays inside the quotes |

## Sources

Provided documents: the JD you pasted; the background in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Search sent and refused. Would have moved VAL themes and, if a values round were documented, a values cheat sheet |
| 2. Saltmarsh Games interview process | unavailable | Search sent and refused. Would have moved loop structure and persona weights; weights rest on your message and the hiring-manager prior |
| 3. Saltmarsh Games strategy and news | unavailable | Search sent and refused. Would have moved CO and CASE grounding; E2 and the cases are generic |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Search sent and refused. Would have moved an interviewer read, persona signals and a reverse question tied to his path |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent, all refused: "Saltmarsh Games mobile studio company values"; "Saltmarsh Games interview process live operations producer"; "Saltmarsh Games strategy news mobile titles"; "Tobias Wrenfield Saltmarsh Games Head of Live Operations". No pages were fetched.

## Upgrade menu

- Permission to run web search → rerun the L1 research: values page, loop structure, strategy, Tobias's public profile. That grounds a CO bank, adds an interviewer read, tunes persona weights, and adds a reverse question tied to his path
- A deeper L2 pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a grounding brief and role-family loop reports (also needs search permission)
- Your relationship to Tobias (manager, skip-level, peer) → reweights every bank
- The recruiter's note on format and any announced exercise → coverage of a graded deliverable, if one was declared
- Your answers to the slots in B4, C1, C2, B3, A3 and A5, said outside a drill → rows F1 to F5 regenerate with your own quotes
- The release checklist or a monthly retention deck, if shareable → raises F4, F6, F7 and F8, which currently rest on a sentence with nothing inspected behind it
- The names of the two titles → the CO bank becomes specific
- A source documenting a values-style round → a values cheat sheet, which is dropped now because none is detected
- A tuesday-dossier.md from job-underwriter would add verified evidence and a ranked objection; it is never a prerequisite
