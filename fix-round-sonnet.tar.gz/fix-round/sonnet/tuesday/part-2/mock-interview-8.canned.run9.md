Dara, your prep pack is saved. It covers all three rounds on 20 November in one file: a shared fit snapshot, then a mini-pack per round, each with its own persona weights, questions and reverse questions. I built it from your message alone, since there was no CV. I ran no web research, because your pasted JD, values, strategy points and the recruiter's email already fix the pack. No interviewers are assigned yet, so there is no interviewer read.

Your two stated gaps carry the most risk: you've never worked in a contact centre, and you've never presented above regional level. The pack names the contact-centre one as the highest-ROI rehearsal (question 2S1, in round 2 with the Head of Member Services). The presenting gap is rehearsed in 1S2 and 2S4.

Several rows of the snapshot have answer slots: places where your sentences don't show something an interviewer is likely to probe. You can answer them either way. Examples are what your spreadsheet counted, whether it was Excel, and which rules your complaints log followed. Send me your answers and I'll regenerate those rows.

The values cheat sheet uses selection scaffolds rather than finished stories, because none of your sentences carries a values story outright. The scaffolds end in an honest "if none comes to mind" branch.

The file is `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-canned-3c9e526d/ashgrove-credit-union_member-experience-lead_interview_pack.md`

Say the word and I'll play the Skeptic on 2S1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Built 11 November 2026 for three rounds on 20 November 2026, in loop mode (one shared fit snapshot, then a mini-pack per round). This is a first version, not a regeneration. No interviewer is assigned yet for any round, so there is no interviewer read.

| Round | Length | Who | What it is | Provenance |
|---|---|---|---|---|
| 1 | 30 minutes | The recruiter | Screen | [grounded] |
| 2 | 45 minutes | The Head of Member Services, who would be your manager | Mostly behavioural | [grounded] |
| 3 | 60 minutes | A panel of two branch managers | Includes a 20-minute case on a complaint escalation; the panel is also the values round, scored against the four values | [grounded] |

The rounds table comes from the recruiter's email, which is this pack's loop source.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Question IDs are the round number, then the persona letter, then a number: 1C1 is round 1, Conversational, first question.

| Persona letter | Persona |
|---|---|
| C | Conversational / Rapport Builder |
| S | Skeptic |
| D | Data-Driven Prober |
| K | Case / Strategist |
| V | Values / Behavioral |
| E | Peer Evaluator |
| P | Pressure / Stress |

| Type | What it is scoring |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values |
| EXP | Whether what you have said about your work survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know where the company is heading |
| CASE | How you structure a live problem |

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for me: say your own version, and either branch is a good answer. If the practice was not yours, or never existed, saying so plainly is the honest branch. Rows marked `[generic]` are patterns for a problem, not facts about Ashgrove.

## Prep triage

All three rounds are on 20 November, which is nine days from the day this pack was built; the plan is sized to that calendar, not to hours.

| When | Do | Tied to |
|---|---|---|
| 11 to 13 November | Write your own one-to-two-sentence answer to every answer slot in the fit snapshot, either branch. Send them back and the rows regenerate | F1, F3, F4, F6, F7, F9 |
| 14 to 16 November | Rehearse 2S1 aloud with its three follow-ups until the first sentence, the limit, comes out without hesitation. Then 2S4 and 1S2, which share its shape | 2S1, 2S4, 1S2, 1C3 |
| 17 to 18 November | For each of the four values, pick one real story against the selection criteria, or rehearse the honest branch if none comes | 3V1 to 3V4 |
| 18 to 19 November | Run 3K1 as a timed 20-minute case aloud, once with 3K2 as the follow-up | 3K1, 3K2 |
| 19 November | Say your round 1 biography arc once, and plan the day's pacing across three back-to-back rounds | 1C1 |

Everything else in this pack is insurance.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch log, not the process across branches, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's scope is wider than one branch's log, so expect a probe on what your part of a complaint covered. If any stage beyond the log was yours, say which, in your own words; if your part ended at the log, say so plainly and describe how you handled it |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence says you built a monthly complaints spreadsheet your regional manager uses; it does not say what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours counted and how. If it counted either, say what and how, in your own words, and the assumption you would defend least; if it counted something else, or you do not know how part of it was counted, say so plainly and stay with the spreadsheet you built |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says a formal complaints log, and the words stay at that scope: "I handled the branch's formal complaints log." Whether the log fell under outside rules is not in your material. Answer slot: expect a probe on what the log had to record and which rules it followed. If you know, say so in your own words; if you do not know, or the rules were set elsewhere, say so plainly and stay with the log you handled |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your sentence already speaks to the years; the JD labels the work differently from you. Lead with your own words: "I have six years in retail banking, the last three as a branch supervisor," and let the interviewer draw the match. Do not rename your work in the JD's vocabulary |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says tellers, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: expect a probe on who you trained. If any of it reached beyond new tellers, say who and what, in your own words; if not, say so plainly and stay with the script you trained new tellers on |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material speaks to it. Answer slot: if you have worked with a digital or app team, or have used self-service as a route for members, say what and what your part was, in your own words; if you have not, say so plainly and say the one thing you would want to find out first |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated absence on a headline requirement. Words: "I've never presented to anyone above regional level." Then a plan in the future tense. Never a claim to have presented to leaders; the spreadsheet your regional manager uses is not evidence of presenting |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Derived from "spreadsheet", which does not say which tool. Answer slot: if the spreadsheet was in Excel, say so and say what you built into it, in your own words; if it was another tool, or you cannot say, say so plainly and stay with the spreadsheet you built |

F5's years requirement is graded like any other row: a length-of-experience line is not a gate. No requirement in the JD is an eligibility or credential term, so no gate row appears.

## Grounding brief

Built from the four points you relayed from the 2026 strategy brief (published July 2026); the brief itself was not read by this pack.

| Point | As you relayed it | Where it surfaces in this pack | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | 1C2, 2K3, F7 | [grounded] |
| Branch hubs | "consolidate eight branches into five hubs over 2027" | 1C2, 3K3 | [grounded] |
| Small-business lending | "launch a small-business lending product in Q1 2027" | 1C2 | [grounded] |
| Competition | "the main competitive pressure is app-only banks" | 1C2, 2K3 | [grounded] |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own the member complaints process end to end" | 1C4, 2S1, 3K1 |
| "across branches and the contact centre" | 1C3, 2S1, 3K2, 3E1 |
| "report monthly on complaint volumes and resolution times" | 2D1, 2D2, 2K1 |
| "coach branch supervisors on escalations" | 2K2, 2S3 |
| "work with digital teams on self-service journeys" | 1C5, 2K3 |
| "4+ years in financial-services customer operations" | 1C1 |
| "experience handling regulated complaints" | 1S1 |
| "confident presenting to senior leaders" | 1S2, 2S4, 2K1 |
| "comfortable with Excel reporting" | 2D1 |
| The four published values | 3V1, 3V2, 3V3, 3V4, 3V5 |

---

## Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly screen: biography, motivation, one question on where the company is heading. Casual questions are still scored | High. The relationship prior for a recruiter screen is Conversational plus a light Skeptic, and the screen is 30 minutes | Pre-script a 90-second arc (1C1); treat casual questions as scored; never answer "I think you've covered everything" at the reverse-question slot |
| Skeptic (light) | Quiet checks on the JD's listed requirements | Medium. F2 and F8 hold stated absences and F4 asks for more than its quote carries, which is where a screen checks | Say the limit first, once, plainly; follow with a plan in the future tense (1C3, 1S1, 1S2) |
| Data-Driven Prober | Reading a CV line by line | Low for this round: the spreadsheet line (F3) gets its depth in round 2 | None needed beyond 2D1 |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1C1 | "So, walk me through your journey in banking, and why this role now." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Story-mapped on F5 and F1: the six years in retail banking, the last three as a branch supervisor, and the log you handled, which are the beats the sentences state; tell them in your own words in about 90 seconds. The why-now is yours to say: draw it from the JD lines that actually appeal to you, and leave out any reason you do not hold | Recruiter screens open on the biography, and F5 and F1 are the evidence. EXP because it tests what was actually yours; Conversational because of the delivery |
| 1C2 | "What have you picked up about where Ashgrove is heading?" | CO | [grounded] | Pick one point from the grounding brief (digital shift, hubs, small-business lending, app-only competition) and say what it could mean for a member who has a complaint, in your own words and plain terms. Where you do not know how a point affects complaints, say so and name what you would ask. The question needs no claim about your past, so the guidance makes none | Homework depth shows in the first call; the brief's four points make this rehearsable. CO because it scores company knowledge |
| 1C3 | "The role covers the contact centre as well as the branches. How do you feel about that?" | JD | [grounded] "Never worked in a contact centre" | Say it first, in plain words: "I've never worked in a contact centre." Then a plan in the future tense: the first two things you would want to learn, in your own words. Do not describe contact-centre work as something you have seen or done. This is the same limit 2S1 presses harder | F2 is a stated absence inside the role's headline scope, so it arrives in every round in some form. JD because it scores a stated requirement |
| 1C4 | "Tell me about the complaints work you've done." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: you handled the branch's formal complaints log, the one beat the sentence states, at its own scope. Answer slot: expect a probe on what your part of a complaint covered. If any stage beyond the log was yours, say which, in your own words; if your part ended at the log, say so plainly and describe how you handled it | F1 is the evidence for the headline responsibility and the likeliest place to be probed. EXP because it tests what was actually yours |
| 1C5 | "The role works with digital teams on self-service journeys. Where have you come across that?" | JD | [grounded] | Answer slot: if you have worked with a digital or app team, or have used self-service as a route for members, say what and what your part was, in your own words; if you have not, say so plainly and say the one thing you would want to find out first. The guidance makes no claim about your past | F7 has no evidence in your material, so a screen question here is likely. JD because the JD names it |
| 1S1 | "The role asks for experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold only what the sentence carries: you handled the branch's formal complaints log. Answer slot: expect a probe on what the log had to record and which rules it followed. If you know, say so in your own words; if you do not know, or the rules were set elsewhere, say so plainly and stay with the log you handled | F4 is where the JD's wording runs wider than your sentence, so a knockout-style check lands here. JD because it scores a stated requirement |
| 1S2 | "The role presents to senior leaders. What have you presented, and to whom?" | JD | [grounded] "I've never presented to anyone above regional level" | Say the limit first: "I've never presented to anyone above regional level." Then a plan in the future tense, in your own words: how you would prepare for a senior audience. Do not say the spreadsheet you built was presented to leaders; your sentence says only that your regional manager uses it | F8 is a stated absence on a headline requirement. JD because it scores a stated requirement |
| 1S3 | "Why this role, and why a member-owned credit union rather than another bank?" | VAL | [grounded] | The motivation is yours to give; the pack cannot say what draws you. Choose the one or two things that are true for you: a line from the JD, a value on Ashgrove's page, the member-owned part. Use the published value wording only to name it, never as your own history. If one of the four values does not appeal to you, leave it out rather than reciting it | Motivation consistency is the Skeptic's scoring axis; the theme comes from the JD's "member-owned" and the published values. VAL because the answer is judged against them |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "How does the panel score the four values: a score for each, or one overall?" | Shows you read the process and the values, and tells you how to aim 3V1 to 3V4 |
| R1-2 | "Is the 20-minute case live on the day, or is there anything to read beforehand?" | Settles how to prepare 3K1, in one email-sized answer |
| R1-3 | "Once the two branch managers are confirmed, could you share who they are?" | Unlocks an interviewer read later and signals you intend to tailor |
| R1-4 | "What has the Head of Member Services said they most want from this hire?" | The recruiter relays the manager's priorities, usable directly in round 2 |
| R1-5 | "What happens after the 20th, and how soon?" | Practical closure, and it ends the call on the next step rather than on a gap |

---

## Round 2: the Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Persistent probing of the gaps, from the person who would own the hire | High. The hiring-manager prior is Case/Strategist plus Skeptic; F2 and F8 hold stated absences, which a manager derisks | Rehearse the one most predictable objection until it is boring (2S1); limit first, then a plan; never bluff a competency the interviewer personally owns |
| Case / Strategist | A live problem set in the role: a report, a coaching situation, the digital shift | Medium. Part of the hiring-manager prior, but the recruiter's email calls the round mostly behavioural, so it sits below the Skeptic | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Values / Behavioral | Scenario probes for how you behave | Low for the scoring (the values round is round 3), but "mostly behavioural" means stories are certain | Choose stories where the hard truth landed; where your material shows none, say so rather than supplying the ending |
| Data-Driven Prober | Line-by-line questions on the spreadsheet | Low. F3 is the only quantified artefact and there is a reporting duty in the JD | Know what you can and cannot say about what was counted, and say plainly when you do not know |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2S1 | "You've never worked in a contact centre, and this role owns the complaints process across the branches and the contact centre. Why should I believe you can own all of it?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | The highest-ROI rehearsal in this pack. Name the limit before it is asked for: "I've never worked in a contact centre." Then hold only what your sentences carry: you handled the branch's formal complaints log, and you trained new tellers on our escalation script. Follow-up 1, "What would you not know on day one?": answer slot, name what you would not know, in your own words; if you cannot name anything, say so plainly. Follow-up 2, "Who would you lean on to learn it?": a plan in the future tense, never a past. Follow-up 3, "So you're asking us to take a risk": concede that it is a risk, say what you would do in the first weeks, and add no experience you have not stated. Hold through two follow-ups by returning to the log and the script, never by adding to them | F2 is the biggest gap against the role's headline scope, so this objection arrives in some form. JD because it scores the stated scope; the deepest rehearsal because the quotes are thinnest exactly where it presses |
| 2S2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose between the two limits your own sentences state, and say which and why in your own words: "I've never worked in a contact centre" or "I've never presented to anyone above regional level." Follow with a plan. Naming one before they do converts a gotcha into a credibility gain. If a different part of the JD worries you more, say that instead | F2 and F8 are the two stated absences, so the question is nearly certain. JD because it scores the listed requirements, gaps included |
| 2S3 | "Tell me about a time you and a colleague saw an escalation differently." | EXP | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a time with a named disagreement, your position, what you did, and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (you handled the branch's formal complaints log), or how you would handle it. The log alone shows no disagreement, so do not describe one you did not have | The theme comes from the JD's escalations line (F6). EXP because it tests what was actually yours |
| 2S4 | "We would want you in front of senior leaders. Convince me you will be comfortable there." | JD | [grounded] "I've never presented to anyone above regional level" | Hold-then-concede. Concede in the first sentence: "I've never presented to anyone above regional level." Hold what you can back: you are willing, and you have a plan. Answer slot: if there is any presentation, at any level, that you would want them to hear about, say what it was and your part in it, in your own words; if there was none, say so plainly and move to the plan. Do not say you are used to senior audiences | F8 is the second stated absence on a headline requirement, asked here in pressure packaging by the person who would sponsor you. JD because it scores the stated requirement |
| 2K1 | "Walk me through how you would open a presentation to our executive team on this month's complaint volumes and resolution times." | CASE | [generic] | Structure it: the headline in plain words first, what changed, what it means for members, and what you want from the room. If asked whether you have done this before, the plain answer is the one in 2S4. The question needs no claim about your past, so the guidance makes none | A live task from the JD's reporting and presenting lines (F3, F8), asked as a decision. `[generic]` because it is a pattern for the problem, not a fact about Ashgrove |
| 2K2 | "A branch supervisor has handled an escalation badly. How would you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | Structure it: what you would ask them first, what the member needs now, what you would ask them to do differently, and what you would check afterwards. Answer slot: expect a probe on who you trained. If any of it reached beyond new tellers, say who and what, in your own words; if not, say so plainly and stay with the script you trained new tellers on | F6 is the evidence and stops at tellers. CASE because it is a hypothetical set in the role |
| 2K3 | "We want 40% of member service on digital channels by 2028. What does that do to complaints, and what would you watch?" | CO | [grounded] | Clarify first: what counts as member service and as a complaint on each channel. Then your objective, one hypothesis stated early and called a guess, and what you would measure by channel (volumes and resolution times are the JD's own measures). Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The strategy brief makes this the differentiator question most candidates cannot touch. CO because it scores company-level thinking; CASE in delivery |
| 2V1 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [grounded] "I've never presented to anyone above regional level" | Selection scaffold: pick a time with a named stake, a moment you said it plainly, and a relationship intact afterwards, and choose a story where the hard truth landed. Calibrate "senior" to the people you have actually worked with. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Your material shows no such story, so the pack does not supply the ending | A persona stem for the behavioural round; F8 shows where your altitude stops, which the answer should respect. VAL because it scores behaviour, not virtue |
| 2V2 | "When did you put a member ahead of an internal target?" | VAL | [grounded] | Selection scaffold: pick a decision that was yours, name the member's side and the target or rule you set it against, and say how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide. The guidance supplies no event | A persona stem that previews the first published value in round 3. VAL because it scores behaviour against it |
| 2D1 | "Walk me through how that monthly complaints spreadsheet was put together." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3: you built it, it was monthly, and your regional manager uses it, which are the beats the sentence states. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours counted and how. If it counted either, say what and how, in your own words, and the assumption you would defend least; if it counted something else, or you do not know how part of it was counted, say so plainly. If it was in Excel, say so; if another tool, say that | F3 is the only artefact in your material and the likeliest place a prober digs. EXP because it tests attribution and the weakest-assumption move |
| 2D2 | "When does a complaint count as resolved?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Give your own definition in plain words, from the member's side of the counter. Answer slot: if the spreadsheet or the log you handled had a status for resolved, say what it meant, in your own words; if it did not, or you do not know how it was set, say so plainly and give your definition as a view, not a past | The JD reports resolution times (F3), and the figure depends on this definition. JD because it scores the stated reporting duty |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What does the monthly complaints report look like today, and who reads it?" | Ties to the JD's reporting duty and shows you think about the reader |
| R2-2 | "How do complaints move between the branches and the contact centre today?" | Turns the F2 limit into curiosity about the seam rather than a defence |
| R2-3 | "How do you expect the move to 40% digital service by 2028 to change what this role does?" | Shows the strategy brief was read and invites the manager's own view |
| R2-4 | "What would you want this role to have changed by the end of its first year?" | Gives you a success measure to name back to them |
| R2-5 | "What would worry you most about someone coming from a branch background?" | Invites the objection you have rehearsed (2S1); ask it only if you are ready to hear the answer |

---

## Round 3: the panel of two branch managers (60 minutes, including a 20-minute case; the values round)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored scenario probes against the four published values | High. The recruiter's email says the panel scores against the four values | Map a story to each value where your sentences carry one, a selection scaffold where none does; "we" for context, "I" for contribution |
| Case / Strategist | A 20-minute case on a complaint escalation | High. The recruiter's email names it | Clarify, objective, approach, metrics, risks; say the framework aloud; challenge one premise respectfully |
| Peer Evaluator | Seam-splitting between the branches and your role | Low. Two branch managers sit across the seam the role coaches into | Reciprocity framing: propose seam principles, not a claimed seam |
| Pressure | Time-boxed challenges to a position | Low. Nothing signals stress interviewing, but a panel of two can interrupt | Pause, restate, hold through two follow-ups, then concede specifically |

Names are not yet assigned, so weights follow the relationship priors and the recruiter's email only; a profile for either manager would reweight this table.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3V1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, mapped to Members First, Always: pick a decision that was yours, name the member's side and what you set it against, say what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (you handled the branch's formal complaints log), or say how you would decide. The log alone shows no decision, so describe one only if you made it | The theme is the value's own wording. F1 is the nearest evidence and carries no decision. VAL because the panel scores it |
| 3V2 | "When have you had to rewrite something, such as a letter or a script, because a member did not understand it the first time?" | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold, mapped to Plain Words: pick a time with the thing, who did not understand it, what you changed, and whether it worked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (you trained new tellers on our escalation script), or how you would test a letter on a member. The script was for tellers, so it is not by itself a member-facing story | The theme is the value's wording ("if a member needs it explained twice, we wrote it wrong"). F6's quote is about staff, not members. VAL because the panel scores it |
| 3V3 | "Tell me about a time you thought about your branch's town, not the numbers, in a decision." | VAL | [grounded] | Selection scaffold, mapped to Neighbours, Not Numbers: pick a decision where the place and its people were in the room alongside the figures, say what you did and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh it. No sentence of yours carries this value, so the pack supplies no story | The theme is the value's wording ("every branch is part of its town"). VAL because the panel scores it; the brief's hub plans make the value live |
| 3V4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, mapped to Own the Fix: pick a problem you found, a point where you could have passed it on, what you did, and the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (you handled the branch's formal complaints log), or how you would hold one. The log alone does not show a problem kept until solved | The theme is the value's wording ("whoever finds the problem keeps hold of it until it is solved"). F1 is the nearest evidence. VAL because the panel scores it |
| 3V5 | "Which of our four values would be hardest for you to live up to, and what would you do about it?" | VAL | [grounded] | Choose honestly, name the value, say why in your own words, and give a plan. Calibrated candour scores better than a polished non-answer. The question needs no claim about your past, so the guidance makes none | A closing values check that tests self-assessment. VAL because it scores against the published set |
| 3K1 | "A member has complained to their branch three times about the same problem. The supervisor has escalated it, and the member has now come back in, angry. It has been handed to you. What do you do?" | CASE | [generic] | Think aloud for the 20 minutes. Clarify first: what the member has been told each time, who has held it, what outcome they want, and what rules or timings apply (ask, do not assume Ashgrove's). Objective: the member's problem solved and one named person keeping hold. Approach: who you speak to, what you tell the member in plain words, what you record. Risks: it has been passed on again, or it is decided from the branch's side not the member's. Challenge one premise respectfully, such as whether the anger or the unsolved problem is the issue. The question needs no claim about your past, so the guidance makes none | This is the pack's own practice case, because the real case is unknown; the structure holds for any escalation. `[generic]`; CASE because it is a live problem set in the role |
| 3K2 | "Now suppose that member has also phoned the contact centre. Who keeps hold of it, and how do you make that work?" | CASE | [grounded] "Never worked in a contact centre" | Structure: one named owner, a written handover so the member never retells it, what each side tells the member, and how you check afterwards. If asked about contact-centre experience, say the plain line, "I've never worked in a contact centre," then ask what the contact centre records and how it reaches the branch. Offer the principle, not a claimed process | F2 sits inside this follow-up, so the plain acknowledgment is ready before it is probed. CASE because it extends the live problem |
| 3K3 | "Over 2027 we are moving from eight branches to five hubs. What complaints would you expect, and how would you want branch managers involved?" | CO | [grounded] | Clarify what a hub changes for members, say your hypothesis early and call it a guess, and say how you would keep each town's members heard. Ask the managers what they would want from you. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The hub plan is a point in the grounding brief; the panel are branch managers, so involve them rather than lecture them. CO because it scores company-level thinking |
| 3P1 | "Sixty seconds: why you, rather than someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Pause and restate the question. Concede first: "I've never worked in a contact centre." Hold what your sentences carry: you handled the branch's formal complaints log, and you trained new tellers on our escalation script. Answer slot: if there is a reason you are the better fit that your own sentences back, say it; if there is not, say what you would bring and what you would learn. Do not run down others. Hold through two follow-ups by returning to the log and the script | F2 returns in pressure packaging. JD because it scores the role's scope; Pressure because the test is composure |
| 3P2 | "You say you built the monthly complaints spreadsheet. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Pause and restate. Hold the sentence: you built it, and say nothing wider. Answer slot: if anyone else contributed anything, say who and what; if no one did, say so plainly. Add no figure or feature you did not state. Hold through two follow-ups by returning to the sentence | A persona stem on attribution; F3's artefact is the likeliest target. EXP because it tests what was actually yours |
| 3E1 | "Our branches and the contact centre both take complaints. Where is the seam between your role and my branch, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a claimed seam: one named owner per complaint, the branch keeps the member relationship, a plain agreed route for disagreement. Say what the branch gets from the role in the JD's own terms: help with escalations and the monthly picture. Reciprocity: ask what they would want from it. The question needs no claim about your past, so the guidance makes none | The peer stem for two branch managers, tied to the JD's across-branches scope (F2, F6). `[generic]` because it is a pattern, not a fact about Ashgrove |
| 3E2 | "How do you handle credit when a fix involves several branches?" | VAL | [generic] | Selection scaffold: pick a time a fix involved several people, say who did what, and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would share it. The guidance supplies no event | A persona stem for collaboration. VAL because credit-sharing shows Own the Fix and Neighbours, Not Numbers in behaviour |

### Values and principles cheat sheet

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide as the member would see it from the counter | Selection scaffold (3V1). Nearest in your material is F1, "I handled the branch's formal complaints log", which shows the log and no decision; if none comes to mind, the honest branch applies |
| Plain Words | If a member needs something explained twice, the writer got it wrong | Selection scaffold (3V2). Nearest is F6, "trained new tellers on our escalation script", which is a script for staff, not a member-facing story |
| Neighbours, Not Numbers | Each branch belongs to its town | Selection scaffold (3V3). No sentence in your message carries this value |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | Selection scaffold (3V4). Nearest is F1, "I handled the branch's formal complaints log", which does not show a problem kept until solved |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What does a complaint handled well look like in your branch?" | Members First: it asks for their standard rather than offering yours |
| R3-2 | "What do your supervisors find hardest about escalations?" | Ties to the JD's coaching line and gives you the real problem to address |
| R3-3 | "What would you most want from this role when a complaint lands in your branch?" | A peer-facing reciprocity question that shows you think of the branches as the customer of the role |
| R3-4 | "As branches consolidate into hubs over 2027, what do you hope complaint handling keeps from how your branch works today?" | Neighbours, Not Numbers, tied to a brief point, and it asks about their hope rather than their worry |
| R3-5 | "What could someone new in this role do in their first month that would genuinely help your branch?" | The reciprocity question for peers; a concrete first-month answer is rare |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: your material says the branch log, not the process across branches. The slots stay inside the log |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation is that your material does not show which rules the log fell under. The slot asks only what the log had to record |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: "I trained new tellers on our escalation script." The pack's observation is that your material says tellers, not supervisors |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description you pasted; the four published values you pasted (copied from ashgrovecu.org/about/values on 11 November 2026, not fetched by this pack); the recruiter's email about the process, which is the loop source; the four points you relayed from the July 2026 strategy brief (the brief itself was not read); your background as stated in your message. No `tuesday-dossier.md` was present.

No search or fetch was sent, and no link you gave was read.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values page fixes the values cheat sheet and 3V1 to 3V5 by name |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email names three sessions with who runs each and what it holds, which fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The four brief points you gave fix the CO and CASE questions (1C2, 2K3, 3K3) |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer is assigned yet, so there is no name to query; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → more of your own sentences for the fit snapshot, which can turn selection scaffolds into story maps in 3V1 to 3V4 and upgrade several rows
- Your answers to the answer slots in F1, F3, F4, F6, F7 and F9 → those rows regenerate on your own words, and 1C4, 1C5, 1S1, 2D1, 2K2 and 3P2 gain real beats
- A sample of the monthly complaints spreadsheet with member details removed → F3 and F9 can move from medium and low toward high, since the workbook is the inspectable artefact in this field
- The two branch managers' names, once assigned, and the Head of Member Services' name → an interviewer read, persona weights read from public professional footprint, and a reverse question tied to each person's path
- The recruiter's answer on whether the 20-minute case is live or pre-read, and any document it uses → 3K1 and 3K2 rebuilt around the real format instead of the practice case
- The full text of the July 2026 strategy brief → a grounding brief on its own words and numbers instead of the four points you relayed
- The complaint rules your branch log followed, and where Ashgrove operates → F4's slot and 1S1 become specific
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports and recent organisational context for the grounding brief
- A `tuesday-dossier.md` from the job-underwriter, if you have one → verified evidence and ready-made prohibited claims; never a prerequisite
