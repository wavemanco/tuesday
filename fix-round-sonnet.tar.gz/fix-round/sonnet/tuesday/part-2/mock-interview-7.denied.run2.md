Search permission was refused, so I'll build the pack from your message and the JD only, label the rest as generic, and record the refused searches in Sources. Writing the pack now.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-denied-16b28d11/Saltmarsh_Games_live_operations_producer_interview_pack.md`.

- **Assumption:** I built it for a hiring-manager round, since you gave Tobias's title but not whether he'd be your manager. If he isn't, the persona weights shift.
- **No company research:** web search was refused, so nothing in the pack comes from Saltmarsh. The values, strategy and interviewer sections are missing or marked generic, and Sources lists each refused search.
- **Highest-ROI prep:** the in-app-purchase gap (B1, with B2 and F1 behind it). It's the objection most likely to come up, and the pack rehearses an answer that admits the gap, gives a learning plan, and doesn't claim experience you haven't described.
- **Wording to watch:** several rows keep your wording at its exact scope. Your material says one main title, weekly content drops, presenting retention numbers, and writing the checklist. The pack doesn't turn those into two titles, owning the review, or running releases, and it flags where an interviewer will probe the difference.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did the recruiter mention a format, focus areas or a take-home for Friday?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_Games_live_operations_producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

## 1. Title block

- Candidate: Femi
- Role: Live Operations Producer, Saltmarsh Games (mobile game studio)
- Interviewer: Tobias Wrenfield, Head of Live Operations
- Round: one 60-minute interview on Friday
- Built on this assumption: Tobias is the hiring manager for this role. Your note gave his title but not the relationship, so every persona weight below is a prior you can overrule.

## 2. How to use this pack, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: speak it in your own words, and stop at the edge of what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its titles |
| CASE | A live problem from the role, scored on structure and reasoning |

An answer slot is an instruction for the interview. Where one appears, answer from your own experience, or say plainly that the practice was not yours or never existed.

## 3. Prep triage

The interview is Friday, and the time you have is not stated, so this is sized to the days left, not to hours.

| When | Do this | Where |
|---|---|---|
| Today | Rehearse the in-app-purchase objection aloud until it is boring | B1, B2, F1 |
| Tomorrow | Rehearse exactly what was yours in the retention reporting, and think aloud through two cases | C1, F2, A2, A3 |
| Friday morning | Run your 90-second arc and pick your reverse questions | D1, section 11 |

Everything else is insurance.

## 4. Fit snapshot

Requirement quotes are from the JD you pasted. Evidence quotes are your own words. F8 is not a JD line; it is a role-family expectation written as prose, and it raises no answer slot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material shows four years as an associate producer and two years running the content-drop calendar. It does not show whether the first two years involved live work. Words that stay inside it: "I've been an associate producer for four years, and for the last two I ran the weekly content-drop calendar for our main title." Answer slot: the JD's years line makes a probe on how many of those years were live likely. If the earlier two years involved live work, say what it was, in your own words; if not, say so plainly and stay with the two years of the calendar |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says weekly content drops for one main title, with nothing inspected behind it. Words: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks for events across two titles, so a probe is likely on whether your calendar held events as well as drops, and whether you ever coordinated more than one title. If it did, say how; if not, say so plainly and stay with the one calendar you ran |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [inferred] | discovery | Your sentence is about leading, and the JD asks you to coordinate; your material does not show which teams the calendar touched. Answer slot: if running the calendar meant handing work to design, art, engineering or community, say which and what you did; if it did not, say so plainly and stay with the calendar you ran |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presenting monthly retention numbers, not a review that followed each event. Words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's review line makes a probe likely on whether reviews followed events and who chose the KPIs. If any were yours to choose, say which and how you decided; if there was no such review, or it was not yours, say so plainly and stay with the monthly presentation |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Lead with the quote in its own terms: you wrote the checklist, and your QA team still uses it. Words: "I wrote the release checklist our QA team still uses." The sentence says wrote, not ran each release, and the words stay there |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | Lead with the quote in its own terms: monthly, retention, to the studio head. Words: "I presented the monthly retention numbers to the studio head." How the numbers were counted is the defend-the-number work in C1 and F2 |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A checklist is a written artifact, which is the only reach this sentence has to the requirement. Answer slot: if you wrote anything else other teams relied on, say what it was; if not, say so plainly and stay with the checklist |
| F8 | In-app-purchase experience (a role-family expectation for mobile live ops, no source supplied) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## 5. Persona table

The relationship is assumed to be hiring manager. No loop source beyond your own words was available, so what the session holds beyond "one 60-minute interview run by Tobias" is not established, and the weights below rest on the hiring-manager prior.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the job: plan a calendar, diagnose a retention drop, resolve a team conflict | Weight 5. The hiring-manager prior puts it first, and the JD's own lines are planning and coordination work | Clarify, set the objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| B. Skeptic | Quiet probing of the gaps: in-app purchases, one title versus two, why now | Weight 4. The hiring-manager prior puts it second, and F8 and F2 are plain gaps in your own words | Rehearse the in-app-purchase objection until it is boring; stay inside what you said; add a concrete ramp plan |
| C. Data-Driven Prober | Line-by-line on your retention reporting: how it was counted, what was yours | Weight 3. Raised from the prior because the JD names KPIs and retention metrics and your material has one retention sentence to probe | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know |
| D. Conversational | Chatty opener, "walk me through your journey", what you play | Weight 3. Most interviews open conversationally, which is a pattern, not a fact about this one; casual questions are still scored | A 90-second arc built only from your own sentences; never answer "no questions" to the reverse slot |
| E. Peer Evaluator | Seams between live ops and design, art, engineering, community; written handoffs | Weight 2. Tobias is assumed to be your manager, so this is mostly insurance, though the JD is a coordination role | Propose seam principles instead of pretending to know the seam; reciprocity framing |
| F. Pressure | Time-boxed "why you", "how much of that was you" | Weight 2. Low prior for a hiring-manager conversation, but F8 and the retention sentence are exactly what a pressure probe would use | Pause, restate, hold the position through two follow-ups, concede specifically |
| G. Values/Behavioral | Scenario stories, no company values known | Weight 2. No published values were read and no values round is documented, so this is a light touch | Selection scaffolds with an honest branch; no stories supplied for you |

## 6. Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch next month's live-events calendar across our two titles. What do you need to know first?" | CASE | [generic] | Clarify first: each title's goal for the month, what already ships and when, freeze dates, and how much design, art, engineering, community and QA time exists. Then objective, how you would segment the month, the approach, the metrics, the risks. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's calendar line is F2, and a live planning problem is the most direct way to test it. CASE because it scores structure, not recall |
| A2 | "Day-7 retention dropped 20% in the week after an event shipped. Diagnose it." | CASE | [generic] | Clarify what the metric measures and for whom, then rule out measurement and release causes before blaming the event, then segment by new versus returning players and by platform, rank hypotheses, name the first check and what you would report. Think aloud. The question needs no claim about your past, so the guidance makes none | F6 and F4 make retention diagnosis the likeliest live problem. CASE because it scores reasoning over the answer |
| A3 | "An event's art lands two days before the release freeze and QA has not tested it. What do you do?" | CASE | [generic] | Name the decision first: ship, ship reduced, or move the date. Then what you need from QA, art and engineering to choose, who has to agree, and what you tell community. Say what you would record afterwards. The question needs no claim about your past, so the guidance makes none | The JD's release-checklist line is F5; this tests judgment under it. CASE with JD content |
| A4 | "Design wants to add a bonus mid-event and engineering says it cannot ship before the event ends. How do you decide?" | CASE | [generic] | Establish what each side is protecting, what the real constraint is, and the cheapest option that keeps both promises. Say who decides, and how the disagreement is recorded. The question needs no claim about your past, so the guidance makes none | The JD's coordination line is F3, and a disagreement between teams is the core of it. CASE with JD content |
| A5 | "Both titles have an event landing in the same week and community can launch one properly. How do you choose?" | CASE | [generic] | Clarify what each event is for, what a weaker launch would cost each title, and whether either can move. State your criteria before your pick, and say what you would tell the team that loses. The question needs no claim about your past, so the guidance makes none | The JD covers two titles and F2 shows one in your material, so this tests the step up. CASE with JD content |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see in-app purchases in your background. How would you handle that in this role?" | JD | [grounded] "never worked on a game with in-app purchases" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, not a past: what you would ask in your first weeks, starting with which KPIs the post-event review reports (the JD's line) and who owns those decisions. Hold through two follow-ups by returning to what your sentences carry, then concede specifically what you would be learning. Answer slot: if the interviewer presses on the work you did, describe it at its own scope and add nothing to it | F8 is your largest stated gap, so this objection arrives in some form. JD because it scores the stated role; the rehearsal is a non-defensive answer |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | Pick one honestly and say what you would do about it. Your material gives two candidates: the in-app-purchase gap in F8, and covering two titles when your calendar sentence names one main title. Say it plainly, then a concrete first step. Answer slot: if the JD's two-title line is the one you pick, say whether you ever coordinated more than one title; if not, say so plainly and stay with the one calendar | The classic Skeptic stem, aimed at F8 and F2. JD because it scores the listed responsibilities |
| B3 | "You ran the calendar for your studio's main title. This role covers two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F2: the calendar, for the main title, for two years, told in your own words. Answer slot: the JD asks for two titles, so expect a probe on whether you ever coordinated more than one title's schedule; if you did, say how, and if not, say so plainly and return to the one calendar. Then what you would want to know first about shared teams and colliding dates | F2 is the evidence for the calendar line and the place the one-versus-two gap shows. JD because it scores the stated scope |
| B4 | "Why leave a puzzle-game studio where you ran the calendar, and why here, why now?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | A selection scaffold, because your material gives no reason and the pack will not supply one. Your reason should name something specific from the JD, such as its two titles or its post-event review, and be true. If no reason comes to mind beyond the next step, say so plainly, then name what in this role you would actually want to do | Motivation consistency is what the Skeptic scores. F1 is the background it is asked against |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Defend-the-number, in your own words, in four slots. Answer slots: how the numbers were counted; what they are sensitive to; the assumption behind them you would defend least, named before the interviewer does; which part was yours. If you do not know how a figure was counted, say so plainly and return to what you presented | F6 is your one retention sentence, so a prober goes straight to it. EXP because it tests attribution and the candidate's own understanding |
| C2 | "Which retention metric would you put first in a post-event review, and why?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Name your choice and your reason in your own words, and say what you would want to know about the title before locking it in. Start from what you presented monthly (the quote above), then say how an event review would differ. Answer slot: if you chose which metrics were reported, say how you decided; if they were set for you, say so plainly | The JD's KPI line is F4; this scores judgment about what a review reports. JD with a prober's delivery |
| C3 | "In a review, how do you separate an event's effect from everything else that shipped that week?" | CASE | [generic] | Say what else shipped, what you would compare against, and how confident the comparison can be. If you have not run a controlled comparison, say so plainly and say how you would set one up. The question needs no claim about your past, so the guidance makes none | F4 and F6 are the retention work; this tests whether the review's conclusions would hold. CASE with EXP flavor |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc of four beats, each the quote's own scope: four years as an associate producer at a puzzle-game studio; two years running the weekly content-drop calendar for the main title; the release checklist you wrote and QA still uses; the monthly retention numbers you presented to the studio head. Answer slot: end with why this role, in your own words; the pack will not supply a reason | F1, F2, F5 and F4 are the arc; the biography question opens most conversations and is still scored. EXP because it checks your own telling |
| D2 | "What have you been playing lately, and what live events caught your eye?" | CO | [generic] | Pick a mobile live-service game you actually play, name one event you saw, and say what you would have measured. If you do not play one, say so plainly and name what you would do in your first week to learn the two titles. Do not name a Saltmarsh title you have not played | No company research ran, so the CO bank is generic. The question tests genuine interest in the domain, asked casually and scored anyway |
| D3 | "Tell me about the release checklist you wrote." | JD | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F5: you wrote it, and your QA team still uses it. Answer slot: the JD's line is to manage the checklist with QA, so expect a probe on whether you ran releases against it; if you did, say how, and if QA ran it or it was not yours, say so plainly and return to the checklist you wrote | F5 is your most concrete artifact, so it is a natural conversational opener. JD because it tests the release-checklist responsibility |
| D4 | "What should a written brief for an update contain?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Describe the contents in your own words, for the reader who has to act on it. Answer slot: the JD asks for clear written communication, so expect a probe on what else you wrote for other teams; if you wrote briefs or other documents they relied on, say what they were, and if not, say so plainly and stay with the checklist | F7 is thin on the page, so this gives the written-communication line a rehearsed answer. JD because it scores the stated requirement |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Live ops sits between design, art, engineering and community. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know this studio's seam: who decides what, how disagreements are recorded, what you bring each team and not only what you need. Show spine and tact together. The question needs no claim about your past, so the guidance makes none | The JD's coordination line is F3; peer-style framing of it |
| E2 | "What would you need from me in your first month?" | JD | [generic] | Name two or three specific things you would ask for, such as access to past post-event reviews and a walkthrough of how the two titles' calendars are held now, and pair each with what you would give back. The question needs no claim about your past, so the guidance makes none | Reciprocity framing; it also gives the in-app-purchase learning plan in B1 a concrete first month |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a producer who has already run events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "never worked on a game with in-app purchases" | Pause and restate the question. Hold on what your quotes carry: you ran the weekly content-drop calendar for your main title for two years. Concede specifically: "I haven't worked on a game with in-app purchases." Do not claim to be better than a hypothetical rival; say what you would bring and what you would learn. Hold through two follow-ups by returning to the sentence, never by adding to it | F8 and F2 are the pressure points; the stem is a classic Pressure line. JD because it scores fit against the stated role |
| F2 | "That retention reporting: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say exactly what the sentence says: you presented the monthly numbers to the studio head. Answer slot: whether you also pulled, built or interpreted the numbers, in your own words; if the numbers came from someone else, say so plainly and return to the presenting. Hold through two follow-ups by returning to the sentence, then concede uncertainty specifically | F6 and F4 are where attribution gets tested; EXP because this probe exists to catch inflation |

### G. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold, because none of your quoted sentences carries this story. Pick a time with a named stake, a moment you did not soften it, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 is the only reporting-to-leadership evidence and it does not show a hard message landing. No published values were read, so this uses a persona stem |
| G2 | "When did you put a player's experience ahead of an internal metric?" | VAL | [generic] | A selection scaffold, because none of your quoted sentences carries this story. Pick a decision where the player-side cost was named, someone proposed the metric-friendly option, and you can say what was decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common live-ops tension between retention and player trust. VAL by persona stem, `[generic]` because no values source exists |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "3+ years producing live-service games or apps" | B2, B4, D1 |
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A5, B3 |
| "coordinate design, art, engineering and community teams on each update" | A4, E1, E2 |
| "own the post-event review and the KPIs it reports" | A2, C2, C3 |
| "manage the release checklist with QA" | A3, D3 |
| "comfortable with player-retention metrics" | A2, C1, C2, F2 |
| "clear written communication" | D4 |
| In-app purchases (role-family expectation, not in the JD) | B1, F1 |

## 7. Reverse questions

No interviewer profile was available, so none of these ties to Tobias's own career path; the upgrade menu says what would change that.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the post-event review look like today for your two titles, and which KPIs does it report?" | The JD hands this to the producer, and asking shows you are already thinking about how you would run it |
| R2 | "How do events tie to revenue and retention in your titles, and which does the review weigh first?" | It asks about the in-app-purchase side directly instead of pretending, which makes the B1 conversation easier |
| R3 | "What would a strong first 90 days look like for this producer across the two titles?" | Shows you plan to be measured, and tells you how Tobias defines the early win |
| R4 | "How do design, art, engineering and community hand work to live ops today, and where does it get stuck?" | Shows you think about the seams before you arrive |
| R5 | "Where does the release checklist with QA work well, and where would you want it to change?" | Your checklist is your strongest artifact, and this turns it into a conversation about theirs |
| R6 | "What is the fastest way for someone from a single-title, non-monetized background to get up to speed here?" | It names your gap openly as a learning plan, which is the posture B1 rehearses |

## 8. Prohibited claims

Built from the fit snapshot before the question banks were written. No dossier was present.

| Not coached | Basis | Honest form |
|---|---|---|
| Led the design, art, engineering or community teams | Negative the candidate stated, "Never led a team" | The plain acknowledgment: "I haven't led a team." The JD's word is coordinate, and F3's slot stays with that |
| Has worked on a game with in-app purchases, or run events that drove them | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I haven't worked on a game with in-app purchases." No slot |
| Ran the live-events calendar for two titles | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says one main title and weekly content drops |
| Owned the post-event review and its KPIs | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says presenting monthly retention numbers, not a review |
| Managed each release with QA | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says you wrote the checklist |

## 9. Sources

Provided documents: the JD text and your background summary, both in your message. No dossier was present.

Searches sent, all refused because search permission was not granted:

| Query | Outcome |
|---|---|
| Saltmarsh Games mobile game studio values | refused |
| Saltmarsh Games interview process live operations producer | refused |
| Saltmarsh Games strategy news mobile titles | refused |
| Tobias Wrenfield Saltmarsh Games Head of Live Operations | refused |

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have supplied the published value names for VAL questions and a values cheat sheet; the VAL bank is generic |
| 2. Saltmarsh Games interview process, live operations | unavailable | Would have named the rounds; persona weights rest on your own description of one session and the hiring-manager prior |
| 3. Saltmarsh Games strategy / recent news | unavailable | Would have grounded a CO or CASE question in their current titles and priorities; the CO bank is generic |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have supplied an interviewer read and a reverse question tied to his path; both are absent |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 10. Upgrade menu

- Search access granted, or a pasted values page or strategy brief → the VAL bank grounded in their published values by name, and CO or CASE questions grounded in their two titles; today those rows are `[generic]`
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → strategy brief, interviewer talks and writing, role-family loop reports, recent org context
- Tobias's public profile, talks or writing → an interviewer read, persona weights adjusted to him, and a reverse question tied to his path
- The recruiter's note on format, focus areas or any pre-declared deliverable → coverage of what is actually scored, and whether the relationship assumption holds
- Your CV text → evidence cells quoted from the CV itself, and possible upgrades to F1, F2 and F7
- Your answers to the slots, written down: whether the earlier two years involved live work, whether you coordinated teams and more than one title, whether your calendar held events, and who produced the retention numbers → upgrades F1 to F4 and F6
- A `tuesday-dossier.md` from an earlier fit assessment → verified evidence and an evidence-derived objection to replace the one inferred here
