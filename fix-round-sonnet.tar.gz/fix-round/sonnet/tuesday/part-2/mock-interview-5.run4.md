I'm reading the last playbook files, then I'll load the search tool and run the company research before I build the prep pack.
The prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-5-denied-d8ea8a20/Kelverton-Rail_senior-partnerships-manager_interview_pack.md`.

Two things limit how far it goes:
- **No company research.** All six web searches were refused, so the pack rests only on your message and the recruiter's quoted email. The company-knowledge and live-problem questions are generic, and there is no read on Deepa or Ross beyond their titles.
- **No report text.** I haven't seen the market report, so the POV build and questions A4 and A5 leave slots for its findings.

The pack has 21 questions across seven interviewer styles, plus a 15-minute POV build with three thesis options and a four-hour prep schedule. The one to rehearse hardest is B1: "You haven't sold into rail and you haven't carried a direct quota. Why should we trust you with our operator partnerships?" The pack gives you a concede-then-hold answer built only from your own sentences, with both follow-ups.

Say the word and I'll play the Skeptic on B1, or run the full POV with a panel pushing back. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to a Word document if you'd like.

Two questions, either of which you can skip:
1. Can you paste the job description? Its own lines would replace the recruiter's quotes as the requirements, and it might show a gate such as location or travel that the pack has no row for.
2. Can you paste the report's headline findings or summary? The POV's "one point from the report, one divergence, one thing I'd decline" structure and questions A4–A5 are waiting on them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Kelverton-Rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one 60-minute panel. **Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). **Shape, in the recruiter's words:** the first 15 minutes are a short POV on "where you'd take our operator partnerships over the next 18 months", no slides, landing on "what it means for the operators themselves"; the rest is Q&A, and "Ross will push on commercials".

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: every sentence about your past is one you wrote, quoted, and anything the pack does not know is an answer slot, an instruction for the interview that you answer in your own words. Question IDs run by persona, A to H, skipping F so they never collide with the fit-snapshot rows F1 to F4.

| Type | What it is testing |
|---|---|
| VAL | Whether past behaviour shows how you work with others, in a scored behavioural question |
| EXP | Whether the claims in your background survive scrutiny, and what was actually yours |
| JD | The role as the recruiter described it, including its gaps |
| CO | Whether you can think at the company's altitude: its market, its operators, its report |
| CASE | A live problem set in the role, scored on structure and reasoning |

## Prep triage (about four hours over the weekend)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 60 min | Build the 15-minute POV and say it aloud twice, no notes on the second run | Section 5, A1, A4 |
| 2 | 45 min | Rehearse the objection this pack names as the highest-ROI prep, with its two follow-ups, until it is boring | B1, B2, D2 |
| 3 | 45 min | Write your honest answers to the slots on the two numbers; where you do not know, rehearse saying so | C1, C2, C3, D1 |
| 4 | 30 min | Re-read the report and fix one consensus point, one divergence and one thing you would decline | A4, A5 |
| 5 | 30 min | Rehearse the 90-second journey and the questions you will ask them | G1, section 11 |
| 6 | 30 min | Run one drill out loud and repeat the answer that went worst | Drill offer |

Everything else is insurance.

## Fit snapshot

The requirement cells quote the recruiter's email as you pasted it, because no job description was supplied. Evidence cells hold only your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships and not rail, with nothing inspected behind it, and the words stay at that scope: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: the 18-month line makes a probe on what carries over from a channel to operators likely. If any of the channel work maps, say which and how, in your own words; if none does, say so plainly and stay with the channel you ran |
| F2 | "what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning in consulting; it does not name train operating companies. The words stay there: "I spent five years in transport consulting, planning bus and light rail networks." Answer slot: expect a probe on what "the other side" meant. Say who the work was for, in your own words, and if it was bus and light rail only, say so plainly |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The whole claim is roughly £4M, and it is influenced, not closed; "roughly" is your own hedge and stays. Answer slot: expect how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words, and if you do not know how it was counted, say so plainly |
| F4 | "Ross will push on commercials" — recruiter's email | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail, and I haven't carried a direct quota; what I've had is influenced revenue." Then how you would learn it, said as a plan and never as a past. The recruiter did not list either as a requirement, so this row records the likeliest place Ross's commercial push lands, as the pack's observation |

## Graded deliverable: the 15-minute POV

Brief, as the recruiter set it: talk through where you would take operator partnerships over 18 months, no slides, and land on what it means for the operators themselves. This is a graded piece of work, so it gets its own build.

**Facts you may build on.** The only claims about your past this section uses are quoted, at their own scope, from the fit snapshot. F1: "took it from 6 partners to 40". F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". F3: "roughly £4M of influenced revenue".

**Three thesis options.** Pick one and make the concession out loud; a thesis without it reads as a pitch.

| Option | The argument | Mandatory concession | What your material does and does not carry | Provenance |
|---|---|---|---|---|
| T1 Outcome as the unit | Make an agreed operator outcome, not supply of software, the thing each partnership is organised around and reviewed against | It narrows how many operators can be served in 18 months, and Ross will ask what it costs the commercial model | Nothing quoted shows outcome-based partnerships, so do not offer your history as proof of it | [generic] |
| T2 Depth before breadth | Go deeper with a few operators before going wider | Headline partnership growth is slower, and the report's picture may argue the other way | F1's quote counts partners, which an interviewer may hear as breadth, so expect "why not what you did?". Answer slot: say in your own words why depth is right here; if your actual view is that breadth is, pick another option | [generic] |
| T3 Value an operator can verify | Build the measures so the operator can check the value itself, not only read Kelverton's account of it | Shared measurement costs operator time and may show less flattering results; attribution is never perfect | F3's quote shows a number you have worked with that was influenced, not closed; how it was counted is a slot (C1). Do not present it as proof of clean measurement | [generic] |

**Differentiate from the report, never recite it.** The report is the company's own document and equally available to the panel and to every other prepared candidate, so a recited shortlist scores as homework. Bring one point the report itself makes, to show you read it. Then one point where your thesis departs from it, with your reason. Then the anti-pick: one thing you would decline or stop in the 18 months, what saying no costs, and what would change your mind (A4). This pack has not seen the report's text, so it names none of these. Answer slot: fix the consensus point and the divergence in the report's own words, and if you find nothing to depart from, say so and say what you would test first.

**The requested close: what it means for the operators themselves.** Spend the last two to three minutes here, not on Kelverton's growth. Say what is different for an operator by month 18 in three parts: one thing an operator's own people would notice, one thing they would stop doing or stop having to chase, and one commitment you would ask of them in return. Answer slot: name the roles at the operator from the report's own language; this pack does not know them.

**Shape and timing.** Rehearse to about twelve minutes so interruptions do not squeeze the close.

| Minutes | Beat | Note |
|---|---|---|
| 0 to 1 | Frame: say what you take "operator partnerships" to mean, and that you will check it with them at the end | You have no description of the term from the recruiter; stating your assumption is the clarify-first move |
| 1 to 4 | Where things stand: one point from the report | The consensus item only |
| 4 to 9 | Your thesis and two or three moves across the 18 months, with the concession said aloud | Section above |
| 9 to 11 | The anti-pick | A4 |
| 11 to 14 | What it means for the operators, then how you would know it is working and who owns that number | Ross's likeliest hook; if asked who owns it, see F4's words |
| 14 to 15 | Check the framing assumption | Hand over |

## Persona table

The loop is established by the recruiter's own words: one 60-minute panel, a POV, then Q&A. No values-style round has been described, so none is assumed. For a panel the pack blends the top two personas of each member's relationship.

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of rail and quota, and why this move | High. Hiring-manager prior for the future manager, and F4 states two gaps the interviewer will find in one read of your background | Rehearse the single most predictable objection until it is boring; concede what your own sentences concede and hold only what they carry |
| Case/Strategist | The POV itself, then live problems on operator work | High. Hiring-manager prior for Deepa, executive prior for Ross, and the recruiter pre-declared a 15-minute assignment | Clarify, then objective, approach, measures, risks; think aloud; challenge one premise politely |
| Data-Driven Prober | Both of your numbers taken to how they were counted | Medium. The recruiter said Ross "will push on commercials", which raises the Prober for him above its executive-prior position | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know; name the assumption you would defend least before they do |
| Pressure | Time-boxed answers on price and attribution | Medium. Executive prior for Ross; the commercial push is the likeliest place for interruptions | Pause, restate, hold through two follow-ups, concede specifically and never fold on the core claim |
| Peer Evaluator | The seam between Partnerships and Commercial | Low. Deepa and Ross sit side by side in the room, so the seam is a plausible but secondary probe | Offer seam principles, not a seam you cannot know; lead with what you bring them |
| Conversational | The opening biography and a casual company-knowledge probe | Low. Most of the 60 minutes is structured, but an opener is still scored | A 90-second arc built from your quoted facts; treat casual questions as scored |
| Values/Behavioral | Open behavioural prompts | Low. No values-style round has been described and no published values were read | Where no quote carries a story, pick by the scaffold and use its honest branch |

## Question banks

All banks are written against the prohibited list in section 13. Research did not run, so the CO and CASE rows are `[generic]` except where a quoted source says otherwise; that is the honest cost, and the upgrade menu says what removes it.

### A. Case/Strategist (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months, and land on what it means for the operators themselves." | CASE | [grounded] the recruiter's brief | Build it from the section above, not from this cell. The brief fixes two things: about 15 minutes with no slides, and a close on what changes for the operators. Where the POV uses your history, it uses the F1, F2 and F3 quotes at their own scope and nothing wider. Rehearse aloud to about twelve minutes | The recruiter pre-declared it, and F1 and F2 are the requirements it presses on. CASE because it is a live problem on the role delivered as a talk |
| A2 | "Sketch how you'd approach working with one new operator. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what the operator is trying to achieve, who decides, how they would judge success, what is fixed. Then approach, measures, risks, saying the framework aloud before you use it. The question needs no claim about your past, so the guidance makes none | A hiring-manager-prior question that tests the clarify-first habit. F1 is the requirement it tests |
| A3 | "Two operators ask us for opposite things. How do you decide, and what do you tell each?" | CASE | [generic] | Say what you would ask first, how you separate what was requested from what is needed, which part is yours to decide and which belongs to others in the company, and what each operator hears, including the one who does not get what they asked for. No claim about your past | Tests judgement and boundaries, the two things F3 and F4 leave open |
| A4 | "What would you decline, or stop doing, in the first 18 months?" | CASE | [generic] | This is the anti-pick from the build section: one thing, what saying no costs, what would change your mind. Answer slot: take it from your thesis and the report; if you cannot find one you would defend, say so plainly and say what you would learn before deciding | A partnerships seat includes saying no, and a shortlist with no anti-pick reads as the consensus answer |
| A5 | "Our strategy team circulated a market report last quarter. What did you take from it, and where do you differ?" | CO | [grounded] your message: the recruiter attached the report | One point the report itself makes, to show you read it; one point where your thesis departs, and why; one thing it does not settle. Do not recite its list. Answer slot: name the finding in the report's own words, since this pack has not seen its text; if you found nothing to differ on, say so and say what you would test first | Equally available to the panel and to rival candidates, so differentiating from it is the score. CO because it tests homework depth |

### B. Skeptic (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail and you haven't carried a direct quota. Why should we trust you with our operator partnerships?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **The highest-ROI prep in this pack.** The limit, before it is asked: your quotes support an ISV channel at a payments company and bus and light rail network planning, and nothing about rail selling or a quota, so no follow-up pulls you past that. Open by conceding: "I haven't sold into rail, and I haven't carried a direct quota; what I've had is influenced revenue." Hold with only the quotes: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40," and the five years of bus and light rail network planning. Follow-up one, "operators aren't ISVs": agree where true. Answer slot: which parts of the channel work you expect to carry over, in your own words; if you cannot name any, say so plainly and say what you would learn first. Follow-up two, "so you'd be learning on our time": concede specifically, "yes, I haven't sold into rail", and give your own plan to close it, said as a plan. Never claim to know how operators buy | The objection is aimed at F4 and at where F1 and F2 are thin, so it will arrive in some form; a rehearsed, non-defensive answer changes the room. JD because it scores fit for the seat |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Name one of the two gaps you have stated before you are asked, in your own words from that sentence: "I haven't sold into rail" or "I haven't carried a direct quota". Then a plan for that one, said as a plan. Do not offer a weakness you do not have as a strength in disguise | A standard Skeptic stem, and F4 gives you a sourced answer to it |
| B3 | "You say you know the operator world from the other side. Which side was that, and which operators?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer slot: say who the work was for and what "the other side" meant, in your own words. If it was bus and light rail only, say so plainly and return to what the quote says: five years in transport consulting planning those networks. Do not widen it | F2's sentence is a claim of relationship to the operators, and a probe on which side is the quickest way to test it |
| B4 | "Why this move, from payments to rail tech, and why now?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Two quoted facts sit on your path: the partnerships career ending at the payments company, and the transport planning. The reason is yours. Answer slot: say it in two sentences in your own words; the pack supplies no motive. Keep to what you actually did | The motivation probe is part of the Skeptic's job, and F1 and F2 are the two facts the interviewer has to join |

### C. Data-Driven Prober (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Say the figure as you gave it: roughly £4M, influenced. Answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least, named before they do; which part was yours. If you do not know how it was counted, say so plainly. Say nothing you cannot repeat under a second question | F3 is the headline number on your background, and a figure is where a Prober starts |
| C2 | "Six to forty partners. How was a partner counted, and which part of that growth was yours?" | EXP | [grounded] "took it from 6 partners to 40" | Say it at its own scope: you took it from 6 partners to 40. The quote gives no time span, so give one only if it is exact. Answer slots, in your own words: how a partner was counted; what the figure is sensitive to; the assumption behind it you would defend least; which part was yours. If part was someone else's, say so plainly | The second headline number; F1 is the row it supports |
| C3 | "Influenced revenue isn't revenue you closed. What did you own, and what did others own?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue" | Start with the stated limit: "I haven't carried a direct quota; what I've had is influenced revenue." Answer slot: where your part ended and others' began, in your own words; if you do not know how the line was drawn, say so, and if there was no line, say that. Do not describe an ownership you did not state | Ross's commercial push lands here once the number is on the table; F3 and F4 are the rows |

### D. Pressure (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How much of that was actually you?" | EXP | [grounded] "took it from 6 partners to 40"; "roughly £4M of influenced revenue" | Hold only your sentences: you took it from 6 partners to 40, with roughly £4M of influenced revenue. Through two follow-ups, return to those words and add nothing. Concede specifically: the revenue is influenced, and "roughly" is yours. Answer slot: which parts were yours, in your own words; if a part was someone else's, say so plainly and return to the quote | The standard attribution stem applied to F1 and F3; the interviewer is testing composure as much as the number |
| D2 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Concede the true half first: "I haven't sold into rail." Then say only what the quotes carry: four years running the ISV channel at a payments company, and five years of bus and light rail network planning. Stop, and let them draw the inference. Answer slot: what else you would bring, in your own words; if you cannot say, say so | Pressure stem on F4; the discipline is not to argue the point |
| D3 | "Our largest operator says it will walk unless we cut price. You have sixty seconds." | CASE | [generic] | Clarify in one sentence what is behind the ask and what is negotiable. Separate what you can decide from what Commercial decides, say who you would bring in, and say what you would want to learn before offering anything. Do not concede price in sixty seconds. No claim about your past | A time-boxed commercial problem, the form Ross's push is most likely to take; F3 and F4 are the rows |

### E. Peer Evaluator (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and commercial sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Offer seam principles, not a seam you cannot know: who owns the operator relationship, who owns the number, how a disagreement escalates. Say what partnerships gives commercial, not only what it needs. No claim about your past | Both panel members' functions meet here; F3 and F4 are the rows it touches |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold: pick an occasion where credit was shared, with a named stake, a moment where you passed it on or held it, and an intact relationship afterwards. If no such occasion comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer stem; influenced revenue is shared credit by nature, but no quote says how it was handled, so this is a scaffold |

### G. Conversational (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc of three beats: the transport consulting, the partnerships career ending with the ISV channel at the payments company, and why this seat. The last beat is an answer slot: your actual reason, in your own words. Your own wording of "before that" can be read two ways, so do not add up the years unless you are sure of the total | The opener is scored; F1 and F2 supply its two facts |
| G2 | "What do you actually know so far about how operators work with us?" | CO | [generic] | Say what you read in the report and anything you actually know, and stop there. Do not bluff the domain; ask one question back about how it works from their side. No claim about your past | A casual-register company probe; CO because it tests homework |

### H. Values/Behavioral (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship that was intact afterwards, where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; none of your quoted sentences carries a story for it |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold: pick a decision where the customer's interest and an internal number pulled apart, with what you chose and what it cost. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem, relevant because the POV closes on the operators; no quote carries it |

## Requirement coverage

| Requirement (source) | Question IDs |
|---|---|
| F1 "where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, A4, B1, B2, B4, G1 |
| F2 "what it means for the operators themselves" | A1, A5, B1, B3, G1, G2 |
| F3 "Ross will push on commercials" (the number) | C1, C2, C3, D1, D3, E1 |
| F4 "Ross will push on commercials" (rail and quota) | B1, B2, C3, D2 |
| The pre-declared POV | A1, A4, A5, and the build section |
| Open behavioural prompts, which no stated requirement raises | E2, H1, H2: none, because the recruiter named no values-style round; they cover the persona stems only |

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| 1 | "When you say operator partnerships, which relationships do you mean, and which operators does the 18 months most need to move?" | It turns your opening assumption into a confirmed definition and shows you built the POV around the term |
| 2 | "What did the report get right about operators that you would bet on, and what are you least sure of?" | It moves them to their own strategy and signals you read it as a document to argue with |
| 3 | "How is this role measured in the first year, and who owns the revenue number, Partnerships or Commercial?" | Ross is in the room, and it is the honest, diligent way to surface the quota question you have already said you can answer plainly |
| 4 | "What would an operator say today they get from working with us that they cannot get elsewhere?" | It ties the whole conversation back to what the recruiter asked you to land on |
| 5 | "What would you want the person in this seat to have learned about operators by the end of their first 90 days?" | It invites a ramp conversation you want to be having, and gives the panel a reason to describe the gap you flagged |
| 6 | "Where do you see the hardest commercial constraint on partnerships over the next 18 months?" | It gives Ross the floor on his own topic and tells you what the numbers conversation will actually hold |

## Prohibited claims

This pack will not coach these, and the banks above were written against them.

| Not coached | Basis | Honest form |
|---|---|---|
| Having sold into rail | Negative the candidate stated, F4 | The plain acknowledgment: "I haven't sold into rail." No slot |
| Having carried a quota or owned the revenue | Negative the candidate stated, F4 | The plain acknowledgment: "I haven't carried a direct quota; what I've had is influenced revenue." No slot |
| Having generated or delivered £4M of revenue | Inflated form of F3 | F3's quote at its own scope: roughly £4M of influenced revenue. The limit is the pack's observation: the material says influenced, not closed. C1 and C3 slots stay inside the quote |
| Having built the partner programme or channel | Inflated form of F1 | F1's quote at its own scope: you ran the ISV channel and took it from 6 partners to 40. The material does not say which parts were yours to set, and C2's slot asks only what was counted and what was yours |
| Having worked with train operating companies, or knowing how they buy | Inflated form of F2 | F2's quote at its own scope: five years of bus and light rail network planning in consulting. The limit is the pack's observation: the material does not name train operating companies |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report was attached to that email and is not in this session, so nothing here rests on its text. No dossier was present.

Queries sent, all refused:

| Query | Outcome |
|---|---|
| Kelverton Rail values culture about us | refused |
| Kelverton Rail interview process partnerships | refused |
| Kelverton Rail strategy train operating companies scheduling software news | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager rail technology train operating companies job description | refused |

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have decided whether a values cheat sheet exists and themed the Values bank on published values; the Values bank rests on persona stems instead |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Would have named the loop beyond the recruiter's own description and moved persona weights; the weights rest on the recruiter's words and relationship priors |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have grounded the CO and CASE banks in current strategy; they are `[generic]` and A5 rests on the report's existence only |
| 4. `Deepa and Ross, Kelverton Rail` | unavailable | Would have supplied an interviewer read and a reverse question tied to their paths; neither is in the pack |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have supplied requirement cells beyond the recruiter's words; the fit snapshot has four rows |

## Upgrade menu

- The job description's text → F1 to F4 take the posting's own lines as requirements, the coverage table checks every one, and any gate such as location, travel or right to work gets its own row, which this pack has none of
- The market report's headline findings, pasted → A4, A5 and the POV's consensus and divergence stop being slots and the CO bank becomes `[grounded]`
- Web search permission, which was refused in this session → the company's published values, its loop, its strategy, and Deepa's and Ross's public professional footprint (surnames or profile links make that exact); a deeper pass, up to 6 more searches and 2 more fetches and several more minutes, is available once search is allowed
- The recruiter's answer to what "operator partnerships" refers to at Kelverton, in one email → the POV's first minute becomes a statement instead of an assumption
- A document showing how the roughly £4M and the 6-to-40 count were made, if one exists → C1, C2 and D1 can quote the method, and F3 can move from medium to high
- Your typed answers to the slots in B1, B3, B4, C1, C2 and C3 → those rows regenerate from your own words
- A `tuesday-dossier.md` from an earlier underwriting pass would add an evidence-derived objection and a strategy per weak area; this pack stands without it
