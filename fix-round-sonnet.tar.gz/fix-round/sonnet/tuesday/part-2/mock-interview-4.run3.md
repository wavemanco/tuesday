Web search was denied, so I'm building the pack from your dossier alone, with no outside research. Writing it now.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-4-denied-c7fd6e19/Quartzline_product-manager-platform-apis_interview_pack.md`. It has 20 questions across six personas, built for a hiring-manager round with the Skeptic and Case personas weighted highest.

- **No research:** web search was denied, so the pack holds no Quartzline facts. The CASE and company-knowledge questions (B1–B5) are labeled `[generic]`. For B5, bring what you read yourself.
- **Top priority:** A1 is the objection your dossier named, "never held the PM title or owned a roadmap". It gets the deepest rehearsal: concede in the dossier's own words, then the adjacent case with its limit stated up front, then a ramp plan.
- **Prohibited claims held throughout:** the PM title, roadmap ownership and squad prioritization appear only as plain acknowledgments, never as claims.
- **Rows the dossier didn't grade:** it left R2, R3 and R4 ungraded. The pack graded those from your three confirmed quotes, and the underwriter owns that classification. Your roadmap-input sessions are the thinnest evidence (limited inspectable proof), so C3 and F2 coach you to state that limit before you're asked.
- **Answer slots:** A3, A4, C3, D2 and F2 are instructions for the interview, not questions for me.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save an updated `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

- Role: Product Manager, Platform APIs
- Company: Quartzline
- Interviewer: the hiring manager (name not given)
- Round: one 45-minute hiring-manager conversation, Thursday
- Built from: `tuesday-dossier.md` v1.1 (the underwriter's handoff); no outside research reached this pack
- Highest-ROI prep: A1, the objection the underwriter named

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: the only things in it that describe your past are the sentences quoted in each row's Provenance column, kept at their own scope. An answer slot is an instruction for the interview, not a question for this conversation.

| Type | What it scores |
|---|---|
| VAL | Past behavior against the company's published values (none banked here: no published values reached this pack) |
| EXP | Whether your stated experience survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the company and its strategy |
| CASE | A live problem set in the role; asks nothing about your past |

## Prep triage

Sized to "until Thursday"; you did not give hours, so this is a priority order, not a schedule.

1. A1, then F1: say the concession and the adjacent case out loud until neither sounds defensive (fit snapshot F1, F2).
2. C1, C3 and F2: these are your attribution answers; know exactly which part was yours before you walk in (F5, medium-confidence evidence).
3. A3, A4, D2: decide your honest answer to each answer slot (F3, F4, F6).
4. B1 and the first two reverse questions: one live diagnosis case, and the two questions that answer what the dossier left open.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | low | [grounded] | transferability | The quotes show integration leadership and roadmap input, not years in a product management role, and the dossier's condition is that this is positioned as adjacent, never as PM experience. Words: "I haven't held a product manager title" (source: `prohibited_claims: "Having held a product manager title or role"`), then the two quotes at their own scope. A ramp is a plan, never a past |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | capability | A gap wording cannot close, and the dossier records it: the `acknowledge_gap` area for roadmap and prioritization authority, `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`. Words: "I haven't owned a product roadmap." Then how you would learn it, said as a plan and never as a past. No answer slot |
| F3 | "Shipped API or platform products" — JD (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | low | [inferred] | transferability | The quote is integration work; the words stay at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The dossier does not grade this row, so this pack graded it from the quote. Answer slot: the JD line makes a probe likely, and it will land on the stages the quote names. If any of scoping, requirements, architecture, UAT or go-live were yours to decide, say which and how you decided, in your own words; if there was no such decision, or it was not yours, say so plainly and describe how you led the integrations |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier role_profile R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified evidence 2 | low | [inferred] | discovery | The quotes touch the requirement without saying docs or schemas, and the dossier does not grade this row. Answer slot: the JD names API docs and schemas, so expect a probe. If you read, wrote or worked from either in these integrations, say what and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations you led and the playbook you wrote |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [grounded] | transferability | The quotes carry the client side and the handoff to product; engineering and sales are not in them. The roadmap-input quote is confirmed with limited inspectable proof, so volunteer that limit before it is extracted. Answer slot: the JD names engineering and sales, so expect a probe on each. If you worked with either in these integrations or sessions, say who and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the clients and the sessions you ran |
| F6 | "Agile delivery experience" — JD (dossier role_profile R5) | none given | low | [grounded] | discovery | No quote speaks to this requirement, so nothing is bridged. The dossier's strategy is clarify and it grades the row low. Answer slot: the JD line makes this probe likely. If you worked within an agile delivery process, say how, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline defines it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims: "Having held a product manager title or role"` | The plain acknowledgment: "I haven't held a product manager title." Then F1's quotes at their own scope |
| Having owned a product roadmap | Dossier `prohibited_claims: "Having owned a product roadmap"` and the `acknowledge_gap` area for roadmap and prioritization authority | The plain acknowledgment: "I haven't owned a product roadmap." No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims: "Having set prioritization for an engineering squad"` | The plain acknowledgment: "I haven't set prioritization for an engineering squad." No bridge and no slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope; the limit is this pack's observation, not words for you: the material says integrations led, nothing more. A3's slot stays inside the stages the quote names |
| Shaped or influenced the product roadmap | Inflated form of F5's roadmap-input quote | That quote at its own scope: the sessions were quarterly, you ran them, they fed client evidence to product. The limit is this pack's observation: the material does not say what happened to the evidence afterward |
| Presenting the integration work as product management experience | Dossier decision condition: the bridge is positioned as adjacent, never as PM experience | Say "adjacent", and let F1's quotes carry the case at their own scope |

## Persona table

Weights rest on the hiring-manager relationship prior alone. No interviewer information and no company research reached this pack, so the weights are less specific than they would otherwise be. The loop is the one conversation you described, so no archetype fallback applies.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic (A) | Quiet probing of the PM-title and roadmap gap | high | Hiring-manager prior; the underwriter named this objection (F1, F2) | Rehearse A1 until it is boring: concede in the dossier's words, bridge only with the quotes, state the limit before it is asked for |
| Case/Strategist (B) | Live problems on the partner API platform | high | Hiring-manager prior; the dossier's responsibilities include discovery, specs and adoption metrics | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (C) | Walks the headline number and the roadmap-input sessions | medium | One headline figure in the evidence (F1) and an adoption-metrics responsibility; no interviewer signal either way | Know what you can and cannot say about how the figure was counted; name the weakest assumption first (C1, C3) |
| Conversational (D) | Opening chat and casual JD questions | medium | A 45-minute conversation opens informally, and casual questions are still scored | A 90-second arc from your three quoted sentences (D1); treat casual JD questions as scored |
| Peer Evaluator (E) | The seam with the two squad leads | low | The hiring manager is not a peer, but squad authority is the dossier's open question | Offer seam principles, not a claimed seam; ask who decides what (E1) |
| Pressure (F) | Time-boxed challenges to the objection and to attribution | low | No interviewer signal that points to it | Pause, restate, hold through two follow-ups, concede specifically (F1, F2) |
| Values/Behavioral | Not banked | low | No published Quartzline values reached this pack and no values-style round was described; behavioral probes on R4 arrive through D3 and E2 | None |

## Question banks

### A. Skeptic (weight: high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The underwriter named this objection, so it gets the deepest rehearsal. Beat 1, concede first and exactly: "I haven't held a product manager title, and I haven't owned a product roadmap." (sources: `prohibited_claims: "Having held a product manager title or role"` and `prohibited_claims: "Having owned a product roadmap"`). Beat 2, the adjacent case at its own scope, in your own words: the 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live, and the quarterly roadmap-input sessions you ran, feeding client evidence to product. Name the limit before it is asked for: the sessions are confirmed with limited inspectable proof, so say plainly what you can show from them and what you cannot. Say "adjacent", never "equivalent". Beat 3, a ramp as a plan, not a past: in the first weeks, learn which roadmap decisions sit with this role and which with the two squad leads. Follow-up 1, "A PM with three years has shipped products. What have you shipped?": return to beat 2 and the A3 slot, and add nothing. Follow-up 2, "Who decides what the squads build when you and a squad lead disagree?": "I haven't set prioritization for an engineering squad" (`prohibited_claims: "Having set prioritization for an engineering squad"`), then ask which decisions would be yours alone. Follow-up 3, "So why not hire the PM?": hold on beat 2 and concede again in one sentence: "That is a real difference, and here is how I would close it." | Named by the underwriter from F1 and F2, so it is the highest-ROI prep in the pack; JD because it scores the PM-experience requirement, delivered as a Skeptic probe |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] | Name one, not five. Choose from the rows your material marks as gaps. If you choose the roadmap, say "I haven't owned a product roadmap" (`acknowledge_gap` area for roadmap and prioritization authority; `prohibited_claims: "Having owned a product roadmap"`), then give the plan for learning it. If you choose agile delivery, that is the A4 slot; do not claim a practice to make the answer feel safer | F2 is the row where this question lands hardest, and F6 is the one most likely to be offered as the answer; JD because it scores honest self-assessment against the listed role |
| A3 | "This role needs someone who has shipped API or platform products. What have you shipped?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3 only as far as the quote goes: the 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live, told in your own words. Answer slot: the JD line makes a probe on the stages likely. If any of scoping, requirements, architecture, UAT or go-live were yours to decide, say which and how you decided; if there was no such decision, or it was not yours, say so plainly and describe how you led the integrations. Do not say which side of the API relationship you stood on unless you can say it exactly; the quote does not say | F3 is a must-have the quote only partly reaches, and A1's follow-up 1 leads here; the limit sits in the prohibited list; JD because it scores a stated requirement |
| A4 | "How have you worked within an agile delivery process?" | JD | [inferred] | No quoted sentence speaks to this, so there is no story to map. Answer slot: the JD's agile delivery line makes this probe likely. If you worked within one, say how, in your own words; if you never worked that way, say so plainly. Then the honest clarifier: "Here is what I'd want to confirm about how you define agile delivery here, so I answer the right question." | F6 is a discovery gap with the clarify strategy, so the guidance is a slot and a clarifier, not a bridge; JD because it scores a stated requirement |
| A5 | "Why this move — why product, why here, why now?" | JD | [generic] | This needs your reason, and nothing in the dossier states one, so none is supplied. Pick one specific thing from your own integration work that made you want to own what gets built, and one specific thing about this role from the JD's own lines. Keep it short and forward-looking. If no such thing comes to mind, say so plainly, then give the nearest thing from your own work you can describe accurately, or say how you would find out | Motivation consistency is the standard Skeptic probe for a move across functions (F1); JD because it scores fit for the listed role; the pack holds no motivation facts, so it is a scaffold |

### B. Case/Strategist (weight: high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Adoption of a partner API fell 20% quarter over quarter. Diagnose it." | CASE | [generic] | Clarify first: how adoption is defined and measured, over what baseline, for which partners. Then the objective, segmentation (partner type, integration age, endpoint, release), hypotheses (a release, a deprecation, documentation, a change on the partner side, a change in measurement), what to check first, and what you would do under each. Challenge one premise respectfully, such as whether the metric itself changed. This asks nothing about your past; make no claim about it | The role lists defining and tracking adoption metrics, and the dossier flags the current baseline as unknown; CASE because it is a live problem |
| B2 | "Two squads, one quarter, and three partner requests that cannot all fit. What do you need to know first, and how do you decide?" | CASE | [generic] | Clarify what each request is worth to which partner and what each costs, then state your criteria and the trade-off. Say aloud the question the dossier leaves open: which of these calls are yours and which belong to the squad leads, and how you would find out. Stay tactful and make no claim about your past | The role drives delivery with two squads, and F2 is where the gap is; CASE because it is a live prioritization problem |
| B3 | "You start Monday. Sketch your first month of discovery with integration partners — what do you need to know first?" | CASE | [generic] | Clarify who the partners are and what is already known; then objective, how you would choose and sequence partners, what you would ask each, how you would record and compare what you hear, and what decision the month feeds. This is a plan, not a history; make no claim about your past | The role lists discovery with integration partners; CASE because it is a live plan |
| B4 | "Outline a spec for a new endpoint a partner is asking for. What goes in it, and who needs to sign off before the squads pick it up?" | CASE | [generic] | Think aloud: the partner's problem and evidence, who else is affected, the contract (request, response, errors), compatibility and versioning, documentation, the success measure, rollout, open questions, and the sign-offs. Name the parts you would lean on engineers for. This asks nothing about your past | The role lists writing specs, and F4 is the requirement it tests; CASE because it is a live artifact walk-through |
| B5 | "What do you know about how partners use Quartzline's API platform today?" | CO | [generic] | The research pass was refused, so this pack holds no Quartzline facts and supplies none. Bring what you read yourself from whatever public material exists: one thing that stood out and one question it raised. If you find little, say so plainly and ask the question instead of guessing | The one CO question the pack can honestly hold; it stays generic until research or pasted material is available |

### C. Data-Driven Prober (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say you led 30+ client integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend-the-number, in your own words; this pack supplies no method. Cover how the figure was counted, what it is sensitive to, the assumption behind it you would defend least (name it before they do), and which part of each integration was yours. Keep 30+ attached to integrations. If you do not know how it was counted, say that plainly and say what you do know | F1 and F3 both rest on this figure, so it is the number a prober will test; EXP because it checks attribution and counting |
| C2 | "If you owned adoption for the partner API, which three metrics would you track first, and how is each one calculated?" | CASE | [generic] | Choose no more than three. For each, say the numerator, the denominator and the assumption you would defend least. Then ask how adoption is measured today and what the baseline is, because the dossier flags both as unknown. This asks nothing about your past | The role lists defining and tracking adoption metrics; CASE because it is hypothetical, delivered as a Prober question |
| C3 | "Walk me through one of the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on F5's quote, with its caveat coached in: the sessions were quarterly, you ran them, and they fed client evidence to product; tell those beats in your own words. Name the limit first: this is confirmed with limited inspectable proof, so say plainly what you can show and what you cannot. Answer slot: expect a probe on what the client evidence was and how it reached product. If you can say, say it in your own words; if you did not choose it, or cannot say how it reached product, say so plainly and stay with the sessions you ran | F5's medium-confidence evidence is where a prober finds a seam, so the limit is volunteered; EXP because it checks what actually happened |

### D. Conversational (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with four beats, in your own words. Beat 1: the 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live. Beat 2: the internal integration playbook you wrote, which the team uses. Beat 3: the quarterly roadmap-input sessions you ran, feeding client evidence to product. Beat 4 is an answer slot: why this role. If the product side is what you want to own, say what you want to learn; if you have no clear reason yet, say so plainly and say what you are testing. Describe what you did and let the interviewer draw the inference | The biography question is the one most likely to arrive in a casual register and be scored anyway; EXP because it tests how your stated work is told |
| D2 | "What are you working with on API docs and schemas these days?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Answer slot: the JD's technical fluency line makes this casual probe likely. If you work with API docs or schemas now, say what and how, in your own words; if you do not, or not in this way, say so plainly and return to the integrations you led and the playbook you wrote | F4 is a discovery gap, so the honest form is a slot with a way back to the quotes; JD because it scores a stated requirement asked casually |
| D3 | "How do you like to work with engineers day to day?" | JD | [generic] | Pick one specific moment you worked with engineers: it needs a named situation, what you asked of them, and how it ended. If no such moment comes to mind, say so plainly, then give the nearest thing from your own work you can describe accurately, or say how you would work with them. Use "we" for context and "I" for what you did | F5's engineering side has no quote, so this is a selection scaffold; JD because it scores stakeholder management asked casually |

### E. Peer Evaluator (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our two squads sit alongside you — where's the seam between what you decide and what the squad leads decide?" | JD | [inferred] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Offer seam principles instead of pretending to know the seam, then ask the dossier's own question: which roadmap decisions this role makes alone, and which belong to the squad leads. Reciprocity, at the quote's scope: the client evidence you fed to product in the quarterly sessions you ran. If asked whether you have set an engineering squad's priorities: "I haven't set prioritization for an engineering squad" (`prohibited_claims: "Having set prioritization for an engineering squad"`). Derived from the dossier's `opportunity_risks_to_validate` item on squad authority | The dossier flags this authority as asserted in the JD but not evidenced (F2); JD because it scores the stated squad responsibility |
| E2 | "How do you handle credit when work spans teams?" | JD | [generic] | Pick one time work spanned teams and credit was shared: name what was yours and what was others', with "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing from your own work you can describe accurately, or say how you would handle it | F5 asks for stakeholder management across groups, and credit-sharing is the collegial version of that probe; JD because it scores a stated requirement |

### F. Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM who has done this for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The time-boxed A1. Pause and restate the question. One clause of concession in A1's words, one sentence of the adjacent case at the quotes' own scope, and one clause of ramp plan. Hold through two follow-ups by returning to the quotes, never by adding to them; concede again specifically rather than folding | A1 under a clock; the hold-then-concede structure is what this persona scores (F1) |
| F2 | "That roadmap-input work — how much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold on the quote's own verb: you ran the sessions. Concede explicitly what you do not claim: "I haven't owned a product roadmap" (`prohibited_claims: "Having owned a product roadmap"`). Answer slot: if any part of how a session was set up or what went into it was yours to decide, say which part and how; if none was, say so plainly and stay with running the sessions | The persona stem for attribution, aimed at F5's medium-confidence evidence; EXP because it checks which part was yours |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years product management experience (must have) | A1, A2, A5, F1 |
| R2: Shipped API or platform products (must have) | A3 |
| R3: Technical fluency: API docs, schemas | D2, B4 |
| R4: Stakeholder management across engineering, sales, customers | C3, D3, E1, E2 |
| R5: Agile delivery experience | A4 |

Responsibilities are covered by CASE questions: roadmap (B2), discovery with partners (B3), specs and delivery (B4), adoption metrics (B1, C2). No VAL question: no published values reached this pack.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier's risk: squad authority is asserted in the JD but not evidenced. It reads as diligence, and the answer is something you need before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier's risk: adoption metrics are named as a responsibility with no stated baseline. It shows you think in measurements, and it tells you what you would inherit |
| 3 | "Where would you expect someone coming from integration delivery to need the most ramp-up?" | It turns A1 from a probe into a shared planning conversation, and it asks the person who will manage the ramp |
| 4 | "How do the two squads' priorities get set today, and how would this role change that?" | It follows from the authority question and tells you what the role actually changes |
| 5 | "How does delivery run with the two squads, and what does a PM own in it?" | It answers the R5 clarify item (F6) without claiming a practice, and it tells you what agile delivery means here |
| 6 | "What would you want to have seen from me by the end of the first quarter?" | It makes the success standard explicit, so the first-quarter ramp plan from A1 can be aimed at it |

## Sources

Provided documents: `tuesday-dossier.md` v1.1, consumed. It supplied `handoff_to_mock_interview` (verified evidence, weak areas with their strategies, the named objection, risks, employer questions, prohibited claims) and `role_profile` (requirement text stands as the JD's lines; its unknowns feed the reverse questions only). `decision` was read as context only. The dossier carries no `evidence_map`, `evidence_state` or `risk_register`, so the fit snapshot's grading for F3, F4 and F5 is this pack's own, from the quotes; the underwriter owns that classification.

Searches sent, with what came back:

- `Quartzline company values`: refused
- `Quartzline interview process product manager`: refused
- `Quartzline strategy news partner API platform`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have supplied published value names for a values cheat sheet; none was built, and no values-style round was described |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. It would have supplied documented loop structure and sharpened the persona weights beyond the hiring-manager prior |
| 3. `Quartzline strategy` / recent news | unavailable | Every call was refused. It would have grounded B5 and the CASE bank in current strategy; they stay generic |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep note (focus areas, any announced deliverable) → coverage of any pre-declared deliverable and a sharper persona weighting
- Quartzline's published values or interview-loop details, pasted or through search access → B1 to B5 move from `[generic]` toward `[grounded]`, and a values cheat sheet if a values-style round exists
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes; it needs search access, which this session did not have) → a strategy brief behind the CO and CASE banks
- Your own answers to the slots in A3, A4, C3, D2 and F2, given outside a drill → F3, F4, F5 and F6 can move from inferred or low toward grounded
- An agenda, notes or output from one of the quarterly roadmap-input sessions → F5 and C3 can move from medium confidence toward high
- Your raw CV → fit rows quoted from it, and any story the dossier's three confirmed claims do not carry
