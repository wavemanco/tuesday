Searches were refused in this session, so I'm building the loop pack from what you've told me and labelling anything that would have needed research. Writing the file now.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-6-denied-c07d77a4/larkfield-systems_engineering-manager_interview_pack.md`.

I built it in loop mode for your three rounds, with a shared fit snapshot and a mini-pack per round. Each round has its own persona weights, a bank of 9 or 10 questions, and reverse questions. It rests only on your message: I had no full JD or CV. Web search was refused in this session, so there is no research on Larkfield. That means no values cheat sheet for the Monday round, no company-strategy question, and no interviewer reads. The Sources section says exactly what each missing search would have changed.

- **Highest-ROI prep:** the hardware roadmap you've never owned. It comes up in the Director round, the panel and the VP round. Use the same plain acknowledgment and the same plan wording in all three.
- **Numbers to defend:** your 60% on-call drop and the ~40 interviews each get a defend-the-number question. The pack doesn't say how either was counted, because your message doesn't.
- **Claims the pack won't coach:** having managed managers, having led two squads or eleven engineers, and owning hiring beyond the loop are listed in the Prohibited claims section.

Say the word and I'll play the Skeptic on T-A1, the Director-round question the pack names as highest-ROI.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Has the recruiter given you focus areas or a deliverable for any of the three rounds? Even one line would restructure the banks.
Can you paste the full job description and your CV? I've proceeded without them, but they would replace the rows built from your summary with your actual wording.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack (loop mode): Engineering Manager, Larkfield Systems

Three scheduled rounds, one shared fit snapshot, one mini-pack per round.

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1. Tuesday | Director of Engineering, the hiring manager and your would-be boss | 45 min | Hiring manager |
| 2. The Thursday after | Panel: two staff engineers and a product manager | 60 min | Panel (peer and cross-functional blend) |
| 3. The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min | Skip-level, with a values-style conversation |

Built from your message alone: the role description you pasted, your background, and the round descriptions. No full JD and no CV were supplied, and no web research ran (see Sources). Names of the interviewers are not known, so there are no interviewer reads.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: the only claims about your past in it are your own sentences, quoted. Anything marked "answer slot" is an instruction for the interview, not a question for you now; answer it in your own words from what you actually did, or take the honest second branch.

| Type | What it tests |
|---|---|
| VAL | Behavioral and values alignment |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The stated responsibilities, gaps included |
| CO | Company and strategy knowledge (none in this pack, see Sources) |
| CASE | A live problem set in the role |

## Shared fit snapshot

Requirements are quoted from the role description in your message. Evidence is your own words, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "3 as a team lead of 6" — your message; "currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of 6 at a payments company: not two squads, and not device-management services. Words: "I was a team lead of 6." The quote does not name a unit for the 3, so say it the way you would defend it. Answer slot: the role's device-management line makes a probe on your route into that domain likely. If any of your payments work shared a problem with device-management services, say which, in your own words; if none did, say so plainly and stay with the team you led |
| F2 | "own delivery, hiring and growth for 11 engineers" (the delivery part) — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote carries adjacent work, a reliability quarter, and the words stay at its scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: the "own delivery" line makes a probe on how you commit to and track delivery likely. If you did, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role description | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap on the words: you run the hiring loop for backend roles. Expect a defend-the-number probe on the 40; the quote does not say whether it counts interviews you conducted or the loop's total, so say it exactly as the quote does. The material says the loop, not headcount or offers, and the words stay at the loop |
| F4 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role description | none given | none | [grounded] | discovery | Your material does not show anything on developing engineers, and you have not stated an absence. Answer slot: the "growth" line makes a probe on developing people likely. If you have helped someone grow, say who and what, in your own words; if not, say so plainly and say how you would start |
| F5 | "partner with hardware and product on roadmap" (the hardware part) — role description | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "partner with hardware and product on roadmap" (the product part) — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote shows you pushed against roadmap pressure; it does not say who applied it or that a partnership with product was involved, and the words stay at that scope. Answer slot: the "partner with product" line makes a probe on how that relationship worked likely. If you worked it out with a product partner, say how; if there was none, or it was not yours, say so plainly and stay with the quarter |

No row is a hard gate: the role description states no authorization, location, schedule, pay or credential term, so no gate question is asked.

## Shared rehearsal priority

The single most likely objection is F5: a hardware-adjacent roadmap you have not owned, in a role that partners with hardware. It surfaces in T-A1, H-E1 and M-B1 and gets the deepest rehearsal, at T-A1. Use the same plain acknowledgment and the same plan wording in all three rounds, so no interviewer hears a different version of it.

## Round 1: Tuesday, Director of Engineering (45 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the hardware and domain gap, and of why now | High: hiring-manager prior is Case/Strategist plus Skeptic, and F5 and F1 are the largest gaps in the snapshot | Say the limit first, bridge only from adjacent quotes, add a plan |
| B. Case/Strategist | Live problems from the actual role: taking over two squads, a roadmap collision | High: hiring-manager prior; a manager of two squads is bought on structure and reasoning | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| C. Data-Driven Prober | Defends the 60% and the 40 | Medium: two headline numbers in your message; a Director reading your background will test them | Know how each was counted, name the weakest assumption, say plainly what you do not know |
| D. Conversational | The opening "walk me through the journey" | Low weight, but it is the first thing said and it is scored | A 90-second arc built only from your quoted sentences |

Persona weights rest on the relationship prior for a hiring manager. They are not drawn from Larkfield's documented process.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The highest-ROI rehearsal in this pack. Say the limit first, in these words: "I haven't owned a hardware-adjacent roadmap." Then a plan, never a past: who you would sit with in the first weeks and what you would ask first. If asked what you have near it, give the quote at its scope and no wider; the material does not show whether any of that roadmap involved hardware, so do not suggest it did. Follow-ups, in the order they tend to come: what would you do in your first 30 days (answer as a plan); what if hardware dates slip and product pushes (answer as a decision you would make, not something you have done); so you would be learning on my team (concede plainly that on this one area you would be, and hold on what you have actually done) | F5 is where the role's hardware mandate presses hardest, so this objection arrives in some form; JD because it scores a stated requirement |
| T-A2 | "This team builds device-management services. What is your route into that domain?" | JD | [grounded] "currently at a payments company"; "3 as a team lead of 6" | Say plainly: "I'm currently at a payments company." and "I was a team lead of 6." Answer slot: the role's device-management line makes a probe on shared problems likely. If any of your payments work shared a problem with device-management services, say which, in your own words; if none did, say so plainly and return to the team you led. Do not describe device work you have not done | F1 is a transferability gap; the question has no negative in it, so it needs no stated-absence source |
| T-A3 | "Why leave a payments company for an industrial IoT one, and why now?" | JD | [generic] | Selection scaffold, because the pack cannot supply your reason. Pick two things in the role description that genuinely pull you, for example its "partner with hardware and product on roadmap" line or its "own delivery, hiring and growth for 11 engineers" line, and say why in your own words. Do not invent dissatisfaction with your current job. If nothing in the description pulls you yet, say so plainly and say what you would want to learn first | The Skeptic's motivation probe; `[generic]` because it is a pattern, with no claim about Larkfield. Use the same answer in round 3 |
| T-B1 | "Sketch how you would take over two squads in your first 90 days. What do you need to know first?" | CASE | [generic] | Clarify first (each squad's charter, current on-call load, open roles, which roadmap items depend on hardware), then objective, segmentation (people, delivery, roadmap), approach, metrics, risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem from the role's first line (F1); a hiring manager scores structure over the right answer |
| T-B2 | "A hardware release slips three weeks and your squads' roadmap depends on it. What do you do?" | CASE | [generic] | Clarify what actually depends on the release and what can ship decoupled; renegotiate scope with product; tell stakeholders early with a revised date and the options. Where it touches F5, name what you would ask the hardware side, as a plan. The scenario is a hypothetical, not a fact about how Larkfield works | Pressure-tests F5 in the form a hiring manager can actually run; `[generic]` because it is a pattern for the problem |
| T-B3 | "Your on-call load is climbing and a product partner wants a feature quarter. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure the decision: what each choice costs, who you need in the room, what evidence settles it, how you communicate it. If you cite your own quarter, say it at the quote's scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: the "partner with product" line makes a probe on how you made the case likely. If you made it with data, say what data; if there was no such step, or it was not yours, say so plainly and return to the quarter | F2 and F6 are the adjacent evidence for delivery and product partnership; CASE because it is a live decision |
| T-C1 | "You mentioned the on-call burden dropped 60%. Walk me through how that figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number, in your own words. Answer slot: say how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; and which part was yours. If you do not know how it was counted, say so plainly. Stay with the quote's "after"; the material does not say the quarter alone caused the drop | A headline metric is a magnet for probers; weakest-assumption move converts a gotcha into credibility |
| T-C2 | "You mentioned about 40 interviews last year. Walk me through how that figure was counted." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say the quote as it stands: you run the hiring loop for backend roles, about 40 interviews last year. Answer slot: say whether the 40 counts interviews you conducted or the loop's total, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know, say so plainly | F3's number; the quote does not settle what is being counted, so the honest answer is the one that says so |
| T-D1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6"; "currently at a payments company" | A 90-second arc with only the beats your sentences carry: 9 years engineering, 3 as a team lead of 6, currently at a payments company. Add the reliability quarter and the hiring loop in the quotes' own words. Answer slot: if the interviewer asks what pulled you toward leading, say your own reason in your own words; the pack supplies none. If there was no single reason, say so plainly | Casual openers are still scored, and a pre-built arc stops the first five minutes drifting |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| T-R1 | "What would you want to be true of these two squads six months from now?" | Shows you start from outcomes, and gives you the Director's own success definition to work back from |
| T-R2 | "Where do hardware release schedules and the squads' roadmap collide today, and who arbitrates?" | Aims straight at F5 and turns your biggest gap into a learning question |
| T-R3 | "How is reliability and on-call work weighed against feature work in the current roadmap process?" | Opens the topic your reliability quarter belongs to without claiming anything beyond the quote |
| T-R4 | "What is the state of hiring and growth for the 11 engineers: open roles, levels, any development plans already in flight?" | Shows you read "hiring and growth" as real obligations, and tells you what you would inherit |
| T-R5 | "What would make you hesitate about me for this role?" | Invites the objection while you can still answer it, and signals candor |

## Round 2: Thursday panel, two staff engineers and a product manager (60 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator | Seam-splitting between your decisions and theirs; credit across teams; "what would you need from me" | High: the staff engineers are the peer-side of the panel, and the panel rule blends the top two personas of each member's relationship | Reciprocity framing; propose seam principles, do not pretend to know the seam |
| B. Data-Driven Prober | Your hiring judgement; confounders behind the 60% | Medium: staff engineers probing competence collegially | Know how the figure was counted; name the weakest assumption |
| C. Values/Behavioral | Scenario probes, probably from the product manager | Medium: cross-functional prior; roadmap partnership is the PM's native ground | Stories only from your quotes; "we" for context, "I" for contribution |
| D. Case/Strategist | A shared roadmap or health-metric problem | Medium: a PM and staff engineers will test reasoning in the role's own terms | Clarify, structure, think aloud |
| E. Skeptic | Light probing of the hardware gap | Low: the Director likely owns this, but a panel member may repeat it | The same acknowledgment and plan as round 1 |

Names and individual roles on the panel are not known, so personas are blended across the panel rather than assigned per member.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H-A1 | "Where is the line between your decisions and ours on technical direction, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam rather than claiming to know it: what you would decide, what you would defer to the staff engineers on, how a disagreement gets surfaced and settled. Reciprocity: say what you would bring them, not only what you would need. The question needs no claim about your past, so the guidance makes none | The Peer Evaluator's seam stem; the role's "own delivery" line (F2) sits beside staff-level technical ownership |
| H-A2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams and the credit was visible to you; it needs a named stake and an outcome the other team would recognize as fair. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for peers; the pack has no quote about cross-team work, so no story is mapped |
| H-A3 | "What would you need from a staff engineer in your first month, and what could you offer in return?" | JD | [generic] | Two halves, kept short: what you would ask for (their view of the system's weak spots, where decisions live) and what you would give (clear priorities, a route to the Director and product). Everything is a plan, nothing a past | The reciprocity question the Peer Evaluator tends to ask |
| H-B1 | "What does a strong backend hiring signal look like to you, and how do you tell it from a polished interview?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Speak from your own judgment in your own words; the pack supplies none of the signals. Say the loop at the quote's scope: you run the hiring loop for backend roles, about 40 interviews last year. Do not widen it to owning headcount or offers. If a signal you name is one you have not tested, say so plainly | F3 is your strongest-quoted requirement and the likeliest place a staff engineer tests judgment |
| H-B2 | "Could anything besides the reliability quarter explain a 60% drop?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the quote as stated and do not strengthen its "after". Answer slot: say what else was changing in that period, what the figure is sensitive to, the assumption you would defend least, and which part was yours; if you do not know, or others did most of it, say so plainly and return to what the quote carries | An attribution probe on the headline number, asked colleague to colleague |
| H-C1 | "Tell me about a time you held a position against roadmap pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F2 and F6: the reliability quarter, the roadmap pressure, and the on-call burden dropping 60% after, which are the beats the quote states. Answer slot: the role's "partner with product" line makes a probe on how you made the case likely. If you made it with evidence, say what and to whom; if some roadmap items waited, say which and who agreed; if neither happened, or it was not yours, say so plainly and tell the quarter as the quote has it | The theme comes from the JD's roadmap line; the PM is likely to test it |
| H-C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a moment you did not soften it, and a relationship that was intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not borrow the reliability quarter as the answer unless the truth was actually told to leadership | A persona stem; no quote carries a leadership conversation, so the story is yours to select |
| H-D1 | "How would two squads and a product manager agree a quarter's roadmap when hardware dates are uncertain?" | CASE | [generic] | Clarify what is uncertain and by how much; separate what is date-bound from what is not; agree decision points, not just a plan; name who decides what. A hypothetical, not a claim about how Larkfield plans | F5 and F6 together; the PM is likely to run a roadmap problem |
| H-D2 | "How would you tell whether a device-management service is healthy?" | CASE | [generic] | Clarify what devices, what failures matter and to whom; pick a few measures of availability, update success and support load; say what each would miss. Think aloud; do not claim fleet experience you have not stated | F1's domain, set as a problem rather than a past |
| H-E1 | "Which part of this role worries you?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The same wording as T-A1, shortened for a panel: "I haven't owned a hardware-adjacent roadmap." Then the plan in one or two sentences. Do not add adjacent claims to soften it | A panel member may repeat the Director's likeliest question; a different wording from round 1 would read as inconsistency |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| H-R1 | To the staff engineers: "What could a new manager do in their first month that would genuinely help your work?" | The reciprocity question; it reads as partnership, not interrogation |
| H-R2 | To the staff engineers: "What is the best decision these squads made together, and what made it work?" | Surfaces how decisions really get made without asking for complaints |
| H-R3 | To the product manager: "How does hardware input reach your roadmap today, and where does it arrive late?" | Aims at F5 from the PM's seat and converts the gap into learning |
| H-R4 | "What reliability or technical-debt work do you wish had more room on the roadmap?" | Opens your reliability quarter's territory without claiming more than the quote |
| H-R5 | To the product manager: "What does a good partnership with engineering management look like from your side?" | Signals you care about the working relationship the role's roadmap line names |
| H-R6 | "How is ownership split between the two squads today, and what is still unsettled?" | Shows you are thinking about F1's actual scope |

## Round 3: Monday, VP Engineering, values and leadership philosophy (30 min)

A values-style round is detected here from the recruiter's description as you relayed it. Larkfield's published values were not retrieved, so there is no values cheat sheet and no question is mapped to a named value; the VAL questions below are themed from the recruiter's words and persona stems. With 30 minutes, expect roughly the top four or five of these to be asked.

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Values/Behavioral | Scenario probes on truth to leadership, customers, growing people | High: the recruiter's "values and leadership philosophy" names a values round, and the JD's "growth" line raises the people story | Map a story only where your quotes carry one; a selection scaffold elsewhere |
| B. Pressure | Time-boxed "why you" and "how much was you" | Medium: skip-level and executive prior; altitude and composure | Pause, restate, hold the quoted claim through two follow-ups, concede specifically |
| C. Case/Strategist | How engineering, hardware and product should plan together; scaling leadership | Medium: skip-level prior is strategy-heavy | State hypotheses as hypotheses; do not state facts about Larkfield |
| D. Conversational | "Your philosophy" and "why here" | Medium: a 30-minute leadership conversation is often chatty | A short answer built from your own examples; do not recite principles |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-A1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a moment you did not soften it, and a relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use the same story you chose for H-C2 | A persona stem and a likely values probe; no quote carries it |
| M-A2 | "Tell me about a time you helped someone on your team grow." | VAL | [generic] | Selection scaffold: one named person or moment, what you did, and what changed for them, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would start with the 11 engineers | The JD's "growth for 11 engineers" (F4) raises it; the material is silent, so the pack supplies no story |
| M-A3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, what the metric was, who paid for the choice. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; the pack has no quote about customers, so the story is yours to select |
| M-B1 | "Sixty seconds: why you, for a role that works across hardware and product, when you have not owned a hardware-adjacent roadmap?" | JD | [grounded] "never owned a hardware-adjacent roadmap"; "3 as a team lead of 6"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause, restate the question in your own words, then concede first: "I haven't owned a hardware-adjacent roadmap." Then what you have actually done, at the quotes' scope: you were a team lead of 6, and your team's on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. Hold that through two follow-ups by returning to it, never by adding to it. Where you concede, be specific about what you would learn and from whom, as a plan. Do not describe these as proof you can do the role; let the interviewer draw that | F5 under executive time pressure; Pressure persona because composure is what is scored |
| M-B2 | "That 60% drop on-call: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the quote as stated and name its limit: it says the burden dropped after you pushed the quarter through. Answer slot: say which part was yours, which was shared, and who else contributed; if others did most of it, say so plainly and return to the part you pushed. Concede uncertainty specifically; do not fold on what the quote carries | The attribution stem for a Pressure interviewer; the numbers question from rounds 1 and 2 returns at executive altitude |
| M-C1 | "At about 600 people, how should engineering, hardware and product plan together?" | CASE | [generic] | Clarify before structuring (what decisions need all three, where dates are firm); propose a few principles for how planning is shared; say what you would test first. Present your points as hypotheses; none is a claim about Larkfield, whose planning you have not seen. The "about 600" is from the role description | F5 and F6 at skip-level altitude; no company-strategy fluency is offered because research did not run |
| M-C2 | "If these squads grew, who would lead them, and how would you develop them?" | CASE | [grounded] "I've never managed managers" | A hypothetical, so the structure is a plan: how you would choose and develop leads. If the interviewer probes managing managers, the plain acknowledgment is: "I haven't managed managers." Then how you would learn it, as a plan, never as a past. Add nothing to make it smaller | You stated the gap; the JD does not require managing managers, so this is insurance at a VP's altitude and the least likely of the nine |
| M-D1 | "What is your philosophy on leading engineers?" | VAL | [generic] | Selection scaffold: two or three principles, each tied to something you actually did, said in your own words. The pack writes no philosophy for you. If a principle is one you have not yet tested, say so plainly. Do not offer the reliability quarter or the hiring loop as proof of the philosophy; describe what you did and let the interviewer decide | The recruiter named "leadership philosophy" directly |
| M-D2 | "Why this role, why Larkfield, why now?" | JD | [generic] | The same answer you built for T-A3, in two or three sentences, refreshed with anything you learned in rounds 1 and 2. The pack cannot supply your reason | The final round often re-asks motivation; consistency across the three rounds is the point |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| M-R1 | "What does leadership at Larkfield look like when it is working?" | Invites the VP to describe the values in action, which you can echo back |
| M-R2 | "Where is engineering management strongest today, and where do you most want to invest?" | Altitude-appropriate and shows you think about the org, not only the role |
| M-R3 | "How do you hope managers in your organization grow over the next few years?" | Ties to the growth line and to your own never-having-managed-managers limit without raising it |
| M-R4 | "What did the best engineering manager you worked with do that others did not?" | A personal question that moves the exchange from assessment to conversation |
| M-R5 | "What would success look like for me at 12 months, from your seat?" | Closes the loop with the Director's six-month question and checks the two answers agree |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Lead two squads building device-management services" | T-A2, T-B1, H-D2, M-C2 |
| "own delivery" | T-B1, T-B3, H-C1 |
| "hiring" | T-C2, H-B1 |
| "growth for 11 engineers" | M-A2, M-C2 |
| "partner with hardware" | T-A1, T-B2, H-D1, H-E1, M-B1, M-C1 |
| "partner with product on roadmap" | T-B3, H-C1, H-D1, M-C1 |

## Prohibited claims

These are claims this pack will not coach, because the basis below does not support them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has owned a hardware-adjacent roadmap | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I haven't owned a hardware-adjacent roadmap." No slot |
| Has managed managers | Negative the candidate stated, your message: "I've never managed managers" | The plain acknowledgment: "I haven't managed managers." No slot |
| Led two squads or 11 engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a team lead of 6, not two squads |
| Owned hiring for the team, including headcount and offers | Inflated form of F3 | F3's quote at its own scope. The material says the loop for backend roles, about 40 interviews; H-B1 stays inside it |
| Cut on-call load by 60% on your own | Inflated form of F2 and F6 | The quote as stated: the burden dropped 60% after you pushed the quarter through. H-B2 and M-B2 ask only which part was yours |

## Sources

Provided documents: your message (the role description, the three round descriptions, your background). No dossier was present. No JD document or CV was supplied.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, each refused by the host before returning anything:
- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems strategy news device management" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have moved a values cheat sheet for round 3 and mapped VAL questions; neither is in this pack |
| 2. `{company} interview process {role family}` | unavailable | Would have confirmed or corrected the round structure and panel composition; the persona weights rest on your account of the loop and the relationship priors |
| 3. `{company} strategy` / recent news | unavailable | Would have moved a CO question grounded in current strategy; none is in this pack, and M-C1 is labelled `[generic]` |
| 4. `{interviewer name} {company}` | n/a | No interviewer was named, so there was no query to form; there are no interviewer reads |
| 5. representative `{role title}` JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

Persona weights rest on the relationship priors for each round, adjusted by your description of who is in the room. They do not rest on Larkfield's documented process.

## Upgrade menu

- Full job description text → F1 to F6 are built from three lines of a summary; the posting's own wording would re-grade them and may add requirements the summary left out
- Your CV → the fit snapshot would quote CV lines instead of your message, and F1 to F4 could move up a confidence band where the CV carries more
- Your answers to the slots in F1, F2, F4 and F6 (said outside a drill) → those rows become story-mapped and `[grounded]`
- Recruiter guidance for each round (focus areas, any deliverable for the panel, whether the VP slot has a structure) → coverage stops being assumed from round-type priors; usually one email
- The names of the Director, the two staff engineers, the product manager and the VP → interviewer reads, per-member persona weights, and reverse questions tied to their own paths
- Larkfield's published values page, a strategy brief or recent news, pasted in → the round 3 values cheat sheet and a CO question grounded in current strategy; if search is permitted in a later session, a deeper research pass is available (up to 6 more searches and 2 more fetches, several more minutes)
- A tuesday-dossier.md from an earlier fit assessment → would add verified evidence and gap strategies per requirement; never a precondition for this pack
