Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-canned-6b635523/Ashgrove_Credit_Union_member-experience-lead_interview_pack.md`.

I built it as three mini-packs, one per 20 November round, with 28 questions in total. The 20-minute case in round three is a practice shape, because the recruiter hasn't said what the real scenario is. Your pastes already covered the research targets, so I ran no searches; a deeper research pass is offered in the upgrade menu.

The highest-ROI rehearsal is D1, in round two. Your manager is likely to ask what makes you ready to go from one branch's complaints log to the whole process across branches and the contact centre. The pack gives you the concession wording and a four-level follow-up ladder for it.

Say the word and I'll play the Skeptic on D1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_Credit_Union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode, three rounds on 20 November 2026: (1) recruiter, 30 minutes; (2) Head of Member Services, your future manager, 45 minutes, mostly behavioural; (3) panel of two branch managers, 60 minutes, including a 20-minute complaint escalation case, scored against the four published values. Interviewers beyond their roles are not yet assigned, so there is no interviewer read.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview, with two honest branches; either branch is a good answer.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows one of the four published values |
| EXP | Whether what you did survives follow-up, and how much of it was you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Ashgrove's altitude: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your words reach the requirement in retail-banking terms, and the bridge rewords only that quote: "I have six years in retail banking, the last three as a branch supervisor." Nothing is added about what those years covered; expect a probe on what the supervisor years involved |
| F2 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Words stay at the log: "I handled the branch's formal complaints log." The material shows one branch's log, not a process across branches. Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint after it was logged likely. If any later step was yours, say which and what you did, in your own words; if the log was where your part ended, or none of it was yours, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. No substitute experience is offered and nothing is added to make the gap feel smaller |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your sentence says formal, and does not show what the log required of you. Words stay at the log. Answer slot: the JD's complaints requirement makes a probe on what governed the log likely. If it came with required steps or time limits you worked to, say which and where they came from, in your own words; if it did not, or you do not know where they came from, say so plainly and stay with the log you handled |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence shows a monthly complaints spreadsheet that a manager uses; it does not show what the sheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on how the sheet was put together. If any column or total was yours to define, say which and how it was counted, and the assumption behind it you would defend least; if the columns were set by someone else, or it was a simple list, say so plainly and stay with the sheet |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Words stay at the tellers: "I trained new tellers on our escalation script." Tellers and a script are not supervisors. Answer slot: expect a probe on whether any of your training reached supervisors. If it did, say whose and what you did; if it did not, say so plainly and stay with the tellers, then say what you would find out first in the role |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have worked with a digital team on a self-service journey, say who and what part was yours; if you have not, say so plainly and say what you would ask that team first |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated gap. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Your sentence says nothing about presenting at regional level, so none is claimed |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence says spreadsheet and does not name the tool. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you know which tool it was built in and what you built in it, say so in your own words; if someone else built parts of it, or you do not recall, say so plainly and stay with the sheet |

No row is a gate: the JD's requirements are experience and skills, none a licence, location, pay or schedule term.

## Grounding brief (from the July 2026 strategy brief the recruiter sent)

| Item | What you gave me | Provenance | Where it appears in the banks |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] | A2, D4, G2 |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | [grounded] | H3, J2, reverse questions |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] | Reverse questions |
| Competitive pressure | "the main competitive pressure is app-only banks" | [grounded] | G2, J1 |

I have your four-point summary, not the document itself; the upgrade menu says what the full brief would add.

---

# Round 1: Recruiter screen (30 minutes)

## Persona weights

| Persona | Questions | Reasoning | How to meet it |
|---|---|---|---|
| Conversational | 4 (A1 to A4) | The recruiter-screen prior is Conversational plus a light Skeptic; the risk is treating a friendly call as unscored | A prepared 90-second arc; treat every casual question about the JD as scored; never answer "I think you've covered everything" at the end |
| Skeptic | 3 (B1 to B3) | The same prior; the knock-out checks here are the contact-centre half and the years requirement | Say the limit first, plainly, then the plan |
| Values/Behavioral | 1 (C1) | The panel scores values, so the recruiter may test that you read the page; one question, not a full bank | Pick one value you can speak to honestly |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey in banking, and what's brought you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped, each beat a clause the quotes state: the six years in retail banking, the last three as a branch supervisor, then the complaints log, the escalation-script training and the monthly complaints spreadsheet, in those terms. About 90 seconds, then stop at what the sentences say. The why-this-role beat is yours: say in your own words what drew you here, naming a published value or an item from the July 2026 brief only if it is true for you | F1 is the spine of every later answer and the recruiter's first scored impression; EXP because it tests whether the arc matches the CV in plain terms |
| A2 | "What attracted you to a credit union, and to Ashgrove in particular?" | CO | [grounded] | No claim about your past is needed. Choose one of the four published values, or one item from the July 2026 brief, that you honestly care about, and say why in your own words. Do not recite the list; one item with a reason beats four names | Motivation consistency is checked in a recruiter screen; CO because it tests homework depth at low altitude. Grounded in the pasted values page and the brief |
| A3 | "The role covers complaints in the branches and in the contact centre. How do you feel about that second half?" | JD | [grounded] "Never worked in a contact centre" | Say it first and plainly: "I haven't worked in a contact centre." Then a plan, not a past: what you would want to learn first about how the centre handles a complaint before you changed anything. Stop when the plan is said | F3 is a stated gap, and a recruiter screen is where it gets checked cheaply. JD because the requirement is the JD's wording |
| A4 | "Tell me about the complaints work you've done in your branch." | JD | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F2 and F5: the log you handled, and the monthly complaints spreadsheet you built, in those terms. Answer slot: expect a probe on what the log required of you. If it came with required steps or time limits you worked to, say which and where they came from; if it did not, or you do not know, say so plainly and stay with the log | F2, F4 and F5 are the three rows this question touches, and it is the open door to all of them. JD content with EXP delivery |
| B1 | "The role asks for four-plus years in financial-services customer operations. How does your background map to that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | "I have six years in retail banking, the last three as a branch supervisor." Stop, and let them ask what it covered. Do not rename it in the JD's vocabulary | F1 reaches the requirement in other terms, so this is a presentation row; the risk is rewording past the quote |
| B2 | "Which part of the contact-centre side would be new to you?" | JD | [grounded] "Never worked in a contact centre" | "I haven't worked in a contact centre." Then one concrete first step in your plan. Do not describe a call-handling task you have not done | F3 again, asked gently; the answer must match A3 and the later rounds word for word in substance |
| B3 | "Which part of this JD would be weakest for you on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Volunteer the limit before it is extracted, and choose the one your material states most plainly: "I haven't worked in a contact centre." A second stated limit, "I haven't presented to anyone above regional level", is the next to have ready, with its plan. Do not offer a limit your material does not state | F3 and F8 are the two stated gaps; picking one yourself reads as honest self-assessment |
| C1 | "Which of our four values speaks to you most, and why?" | VAL | [grounded] | Choose one and say in your own words what it means to you. For a story to attach to it, use the Round 3 values cheat sheet; attach nothing there that you cannot tell in your own words. The published value names are Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | The values page is in hand, and the panel scores on it; the recruiter may test it lightly first |

## Reverse questions for Round 1

| # | Question | Why it lands |
|---|---|---|
| R1 | "Do you know yet who is on the panel, and is there a scoring guide for the four values?" | Shows you have read how the values round is scored, and may bring back names or a rubric |
| R2 | "How is the complaints process split between the branches and the contact centre today, and who would I work with in each?" | Moves F3 from a gap to a plan of who to learn from |
| R3 | "What will the 20-minute case look like: written scenario, roles played, anything to prepare?" | Practical, and the answer upgrades the Round 3 case from a practice shape to something real |

---

# Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

**Highest-ROI prep in this pack: D1.** Whatever else is asked, some form of "you've handled one branch's log, and this role owns the whole process" will be asked by the person who would manage you. Rehearse D1 until the concession is boring.

## Persona weights

| Persona | Questions | Reasoning | How to meet it |
|---|---|---|---|
| Skeptic | 4 (D1 to D4) | The hiring-manager prior is Case plus Skeptic; a manager is derisking the gaps, and F2, F3, F7 and F8 are all open | Rehearse one objection until it is boring; calibrated candour over bluffing |
| Values/Behavioral | 4 (E1 to E4) | The recruiter said the round is mostly behavioural, so weight moves here from Case | A story where your material carries one; the honest branch where it does not |
| Case/Strategist | 2 (G1, G2) | The hiring-manager prior puts Case high; the recruiter's description lowers it | Clarify, then structure, then answer |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've handled one branch's formal complaints log. This role owns the complaints process across every branch and the contact centre. What makes you ready for that step?" | JD | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses"; "trained new tellers on our escalation script"; "Never worked in a contact centre" | The deepest rehearsal, with four levels and a limit named before it is asked for. Level 1: say what the quotes carry, at their scope: "I handled the branch's formal complaints log, I built the monthly complaints spreadsheet our regional manager uses, and I trained new tellers on our escalation script." Level 2, the concession, specific: yes, that is one branch and this role is wider, and "I haven't worked in a contact centre." Level 3, answer slot: if any complaint you handled ever crossed into another branch or another team, say how and what part was yours; if none did, say so plainly and return to the log. Level 4, a plan and not a past: what you would want to see in how complaints move between branches and the centre before changing anything. Hold through two follow-ups by returning to the three things you did, never by adding to them; do not fold into "I could own it all from day one" and do not withdraw the application's case either | F2 and F3 together are the likeliest objection in the loop, aimed where the material is thinnest. JD because it scores the headline requirement; the Skeptic delivers it |
| D2 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F5: you built it, it is monthly, and your regional manager uses it; tell those in your own words. Answer slot: if any column or total was yours to define, say which and how it was counted, and name the assumption behind it you would defend least; if the columns were set by someone else, or it was a simple list, say so plainly and stay with the sheet. If you do not know how something on it was counted, say that | F5 and F9 sit on this one sentence and a Prober-style follow-up goes two levels deep; EXP because it tests attribution |
| D3 | "The role includes presenting to senior leaders. How would you approach that?" | JD | [grounded] "I've never presented to anyone above regional level" | "I haven't presented to anyone above regional level." Then a plan: ask early what senior leaders need from the monthly report in this role, and rehearse the first one with your manager before it goes live. The plan is future, so it needs no past | F8 is a stated gap, and your future manager is the person it would affect most |
| D4 | "The role works with digital teams on self-service journeys. Have you done that before?" | JD | [grounded] | Answer slot: if you have worked with a digital team on a self-service journey, say who and what part was yours; if you have not, say so plainly. Then a plan: with the July 2026 brief's 40% digital target in mind, say which complaint patterns you would take to that team first and what you would ask them | F7 is silence in the material, so this is an answer slot rather than a coached story. JD because it is a stated duty |
| E1 | "Tell me about a time a complaint outcome wasn't what the member wanted." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, because no quoted sentence carries an instance: pick a time with a named member, what they wanted, what you could and could not do, and how it ended with the relationship intact; tell it in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would handle it | The JD's complaints duty raises the theme; VAL because Members First asks for decisions made from the member's side |
| E2 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F6 at its own scope: you trained new tellers on your escalation script. Answer slot: if a teller found it hard and you changed how you trained them, say what; if none did, or it was not yours to change, say so plainly and tell how you trained them. Whether any of it reached supervisors is a second slot: say whose, or say it did not | F6 is adjacent work, and the JD's coaching duty makes this question near-certain; JD because it scores the duty |
| E3 | "Tell me about a time you delivered an unpopular truth to someone more senior." | VAL | [grounded] "I've never presented to anyone above regional level" | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. Pick it at the level you actually worked, since your material states you have not presented above regional level. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A persona stem from the Values persona; it also tests F8 sideways |
| E4 | "Tell me about a time something you put together changed what someone decided." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F5 and F9: you built the sheet, it is monthly, and your regional manager uses it. Answer slot: if your regional manager made a decision from it, say what and which part of the sheet was yours; if no decision followed, or you do not know of one, say so plainly and describe the sheet. If you know the tool it was built in, say so; if you do not, leave it out | Probes the Excel and reporting requirement without presupposing either; JD because it scores F5 and F9 |
| G1 | "A member has complained to two branches and the contact centre about the same issue, and each thinks the other has it. Who owns it, and what do you do this week?" | CASE | [generic] | No claim about your past is needed. Clarify first: what the issue is, what the member was told, what time limits apply to this complaint. Objective: one owner and one message to the member. Approach: name the owner today, tell the member once in plain words, hand over in writing, check back. Metric and risk: how long it stays open, and the risk of the member being told two things. Use the published value Own the Fix as your frame | A live problem built from the JD's across-branches-and-centre duty; the published Own the Fix line is the value it tests. `[generic]` because the scenario is a pattern, not a fact about Ashgrove |
| G2 | "Ashgrove wants 40% of member service to move to digital channels by 2028. Which complaints should stay with a person, and why?" | CO | [grounded] | No claim about your past is needed. Ask what the 40% measures before structuring. Then segment by what a complaint needs: an explanation, a judgement, a distressed member; say which kinds you would keep with a person and why. Challenge one premise respectfully: what the member is told about the choice. Check your own wording against the published Plain Words line | The brief supplies the target; CO because it tests thinking at the company's altitude. F7 is the only row it touches |

## Reverse questions for Round 2

| # | Question | Why it lands |
|---|---|---|
| R4 | "What would you want this role to have changed, or learned, by day 90?" | Gives you the manager's own definition of success, and shows you plan to ramp |
| R5 | "Where does the complaints process work well today, and where do members say it falls down?" | Shows you want the real picture before changing it, which suits the role's end-to-end remit |
| R6 | "How will the move from eight branches to five hubs change where complaints arise, and who decides process changes?" | Shows you read the July 2026 brief; asks about decision rights |
| R7 | "How is the lead supported when presenting to senior leaders in the first months?" | Turns the stated gap in F8 into a ramp question, honestly |

---

# Round 3: Panel of two branch managers (60 minutes, including a 20-minute escalation case, scored on the four values)

## Persona weights

| Persona | Questions | Reasoning | How to meet it |
|---|---|---|---|
| Values/Behavioral | 4 (H1 to H4) | The recruiter's email says the panel is the values round and scores against the four values | One question per published value, a story where one of your quotes carries it and a scaffold where none does |
| Case/Strategist | 3 (J1 to J3) | The email names a 20-minute case on a complaint escalation | Clarify, then structure, then answer; use the values as vocabulary |
| Peer Evaluator | 2 (K1, K2) | The email gives the panel's roles, not their relationship to the role; branch managers work alongside it, so I weighted the collegial style | Reciprocity: what you bring them, not only what you need |
| Pressure | 1 (L1) | A time-boxed case and a panel of two invite a challenge on composure; weighted low because no interviewer information exists | Hold the position through two follow-ups, then concede specifically |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you put a member's interest ahead of an internal metric." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold for Members First, Always, because no quoted sentence carries such a decision: pick a time with a named member, the internal measure you set aside, and what it cost; it should be a decision, not a feeling. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would decide | A persona stem and the first published value; VAL because the panel scores the value by name |
| H2 | "Tell me about a time you made something clearer for a member or a colleague." | VAL | [grounded] "trained new tellers on our escalation script" | Partial map for Plain Words: the one quoted sentence is that you trained new tellers on your escalation script, so start there, at its scope. The rest is a selection scaffold: pick a time something had to be explained a second time, what you changed in how you said it, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it | The published Plain Words line raises the theme; F6 is the only quote near it |
| H3 | "Tell me about a time you thought about a branch's town, not only its figures." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold for Neighbours, Not Numbers: a named branch or town, the figure in front of you, and what you did differently because of the place. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would hold both. Note for yourself that F5 is the numbers side of this value, so expect the pairing to be tested | The published Neighbours, Not Numbers line raises the theme, and a branch-manager panel is likely to weigh it; VAL because the panel scores it by name |
| H4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Partial map for Own the Fix: the quote is that you handled the branch's formal complaints log. Answer slot: if you stayed with any complaint until the member's issue was settled, say how and what part was yours; if the log was where your part ended, or none was yours, say so plainly and stay with the log | The published value raises the theme; F2 is the nearest quote and the practice is not in it, so the guidance is a slot |
| J1 | "A complaint has been escalated twice and the member says they will move to an app-only bank. The branch manager and the contact centre both have it. Talk us through your first hour." | CASE | [generic] | A practice shape for the real 20-minute case, whose scenario is not yet known. Spend the first minutes clarifying: what happened, what the member was told, what time limits and rules apply, any vulnerability. Objective: the member's outcome and one named owner. Approach: tell the member once in plain words, hand over in writing, agree who rings back, check back. Close with what you would change in the process afterwards. Use the four values as vocabulary, and say what you would do, never what you have done | The email names the case but not its content; `[generic]` until the recruiter says more (R3). F4 is what the clarify step is protecting |
| J2 | "Eight branches are becoming five hubs over 2027. A member complains from a town whose branch is closing. How do you handle it, and what do you tell the branch team?" | CASE | [grounded] | No claim about your past is needed. Ask first what the member was told and what is decided. Then the member's side of the counter, the branch team's side, and the town's side, in that order, in plain words. Do not claim to know which branches change; ask. Tie it to Neighbours, Not Numbers in one sentence | The brief's consolidation plan meets the value most likely to be scored by a branch-manager panel; CASE because it is a live problem with CO content |
| J3 | "Sketch how you'd coach branch supervisors on escalations in your first quarter. What do you need to know first?" | CASE | [grounded] "trained new tellers on our escalation script" | Clarify first: what goes wrong today, what the supervisors already do, what data exists. Structure: objective, who, approach, how you would know it worked, risks. The only past you may point to is "I trained new tellers on our escalation script", at that scope, and never as supervisor coaching | A persona stem; F6 is the row it presses on, so the guidance stays at the tellers |
| K1 | "Our branches are busy. What would you need from us, and what would we get from you?" | JD | [generic] | Reciprocity first: what branch managers would get, such as one named owner for each complaint, a clear hand-over, and the monthly view coming back to them. Then what you would need, framed as principles you would agree together, not a claim that you know where the seam is. No claim about your past is needed | A peer-style probe on partnership fit; JD because the role's duties cross the branch seam |
| K2 | "Tell me about a time you disagreed with a colleague about how a complaint should be handled." | VAL | [generic] | Selection scaffold: pick a time with a named disagreement, what each side wanted, how you handled it, and the relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Spine and tact together | The JD's complaint duty raises the theme; VAL because disagreement style is scored behaviour |
| L1 | "Sixty seconds: why you, rather than an internal candidate?" | JD | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses"; "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Hold-then-concede. Hold: "I handled the branch's formal complaints log, I trained new tellers on our escalation script, and I built the monthly complaints spreadsheet our regional manager uses." Concede specifically, when pressed: "I haven't worked in a contact centre" and "I haven't presented to anyone above regional level." Hold the position through two follow-ups by returning to the three things you did; never add to them to win the exchange, and never fold the core | A persona stem; F3 and F8 are the two stated limits the follow-ups will press; JD because it scores fit for the listed role |

## Values and principles cheat sheet (the panel is a documented values round)

| Value (official name) | Working meaning | Mapped story, or scaffold | Source row |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold: a named member, the internal measure you set aside, what it cost. If none comes to mind, say so plainly, then the nearest thing your material carries: "I handled the branch's formal complaints log" | F2 |
| Plain Words | If a member needs it explained twice, the wording was wrong | Partial map: "trained new tellers on our escalation script". The rest is a scaffold ending in its honest branch | F6 |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold: a named place and a figure, and what you did differently. If none comes to mind, say so plainly, then how you would hold both. The numbers side of this value is F5: "I built the monthly complaints spreadsheet our regional manager uses" | F5 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Partial map: "I handled the branch's formal complaints log". Whether you stayed with a complaint after logging it is an answer slot with both branches | F2 |

## Reverse questions for Round 3

| # | Question | Why it lands |
|---|---|---|
| R8 | "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" | The reciprocity question for a panel that works alongside the role |
| R9 | "Which complaint is hardest for your branch team to hand on, and what would you want a lead to do about it?" | Asks for their real problem, and shows Own the Fix is a working idea for you |
| R10 | "How do you want the complaints process to feel to a member in a branch that is changing?" | Ties the hub plan to Neighbours, Not Numbers without presuming anything about their branches |

---

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1: 4+ years customer operations | B1, A1 | |
| F2: own the complaints process across branches | A4, D1, L1 | |
| F3: and the contact centre | A3, B2, B3, D1 | Stated gap, so the answer is the same plain acknowledgment in every round |
| F4: regulated complaints | A4, J1 | The slot in A4 and the clarify step in J1 |
| F5: monthly reporting | E4, D2 | |
| F6: coach branch supervisors | E2, J3 | |
| F7: digital teams on self-service | D4, G2 | Answer slot; no story is coached |
| F8: presenting to senior leaders | D3, E3, L1 | Stated gap |
| F9: Excel reporting | E4, D2 | The tool is not named in your sentence |

No figure appears in your material, so no defend-the-number question was written beyond D2's attribution slots.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across branches | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material shows one branch's log, not a process across branches. D1's slot stays inside the log |
| Worked in a contact centre | Negative the candidate stated, F3 | "I haven't worked in a contact centre." No slot |
| Presented to senior leaders | Negative the candidate stated, F8 | "I haven't presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: tellers and a script. The limit is the pack's observation |
| Wrote or designed the escalation script | Inflated form of F6 | F6's quote: you trained tellers on it. No slot asks about authorship |
| Handled regulated complaints under external rules | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material shows a formal log, not what governed it. A4's slot asks only what the log required of you |
| Reported monthly on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope. D2's slot asks only which columns or totals were yours to define |
| Built reports in Excel | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. E4's slot asks only for the tool if you know it |

## Sources

Provided documents: the JD; the values page text, pasted by you from ashgrovecu.org/about/values on 11 November 2026; the recruiter's email on the three rounds; your four-point summary of the July 2026 strategy brief; your background message. No dossier was present. Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page, copied this morning, fixes the values cheat sheet and the VAL questions; nothing a search could return would change them |
| 2. Ashgrove interview process, member services roles | skipped | The recruiter's email gives the rounds, who runs each, their length and the case, which fixes the loop and the persona weights |
| 3. Ashgrove strategy or recent news | skipped | The July 2026 brief, as you summarised it, fixes the grounding brief and the CO questions; it is under six months old |
| 4. Interviewer name and Ashgrove | n/a | No name was given, only roles, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewers' names, when assigned: an interviewer read, persona weights adjusted per panellist from their public professional footprint, and a reverse question tied to their own path
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering Ashgrove's recent organisation news, loop reports for this role family and a fuller strategy picture; it would make J2 and G2 less dependent on four lines of the brief
- The full July 2026 strategy brief itself: the CO questions and the grounding brief would rest on the document, not a summary
- Your CV: sentence-level quotes could lift the evidence in F1, F4, F5, F6 and F9 and may turn some answer slots into mapped stories
- Your answers to the answer slots in F2, F4, F5, F6, F7 and F9: each regenerates its row and its questions with your own words
- The recruiter's reply on the case (R3 above) and on whether the values have scoring behaviours: J1 becomes grounded in the real scenario instead of a practice shape
- Hours available before 20 November: a prioritised prep schedule, with everything else marked as insurance
- A tuesday-dossier.md from an earlier role assessment would add confirmed evidence, strategies per weak area and the underwriter's own list of objections; nothing in this pack depends on it
