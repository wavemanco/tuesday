Searches for Atlas Freight were refused, so I'm building the pack from your JD and background only. I'll label anything the research would have supplied as generic.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-2-denied-2c74d9b9/Atlas_Freight_operations-manager_interview_pack.md`. It has 23 questions across seven interviewer styles, a fit snapshot against each JD line, and six questions for you to ask.

I built it for a hiring-manager round, since you didn't say who you're meeting. My web searches on Atlas Freight were refused, so the pack uses only your JD and background. Atlas-specific facts such as its values and interview loop are missing, and the pack says so. Question B1, on stepping from 3 supervisors to 12 across four sites, is the one I'd rehearse most.

Say the word and I'll play the Skeptic on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting, and what round is it (recruiter, hiring manager, panel, skip-level)? The answer reweights every question bank.
2. Can you paste your resume text? Right now the pack quotes your summary message, and your actual resume lines would replace those quotes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas_Freight_operations-manager_interview_pack.md -----
# Atlas Freight — Operations Manager: interview prep pack

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not known. Built on the assumption of a hiring-manager round, because the round type was not given. If that is wrong, the persona weights below change.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Where a cell says "answer slot", it tells you what the interviewer is likely to probe and gives you two honest branches. It never supplies the answer.

| Type | What it scores |
|---|---|
| VAL | Behavior that shows values, not generic virtue |
| EXP | Whether the claims in your background survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

About a week. Do these in order; everything else is insurance.

| Order | Do | Where |
|---|---|---|
| 1 | Rehearse the scale-up objection aloud until it is boring, including the three follow-ups | B1, then B5 and B2 |
| 2 | Defend the 40% figure: how it was counted, what it is sensitive to, the assumption you would defend least, what was yours | C1, C2, D1 |
| 3 | Settle your Power BI answer: the plain statement, then the plan | C3 |
| 4 | Say each live case aloud once, clarify first, structure second | A1 to A5 |
| 5 | Prepare the 90-second journey and read what Atlas publishes about itself | E1, E3 |
| 6 | Pick three reverse questions | Reverse questions |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution operations and a senior shift manager role; it does not show terminal operations or four sites, and the words stay at what you said: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's "across 4 sites" line makes a probe on multi-site work likely. If any of your work touched more than one site, say how, in your own words; if it did not, say so plainly and stay with the operation you run |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | Running a surge plan is not the same as moving an on-time figure, and the bridge should not be stretched. Answer slot: if on-time performance was tracked during the surge plan, say what was measured and what happened, in your own words; if it was not, or it was not yours, say so plainly and say what you would measure first |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [inferred] | discovery | This is a measured improvement to a quality rate, and your material does not show a cost figure behind it. Answer slot: if the pick-path change moved any cost figure, say which and how it was counted; if none was tracked, say so plainly and stay with the mis-pick rate |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote says 3 and the JD says 12; the words stay at your number: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led more than those 3, or led supervisors across more than one shift or site, say how, in your own words; if not, say so plainly and stay with the 3 |
| F5 | "build reporting in Excel/Power BI" — JD (Excel) | "solid Excel" — your message | low | [grounded] | discovery | "Solid Excel" is your own grade of your skill and does not show reporting you built. Answer slot: if you built reports that other people used, say what they showed and who used them; if you did not, say so plainly and say what you would put in a first report |
| F6 | "build reporting in Excel/Power BI" — JD (Power BI) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used Power BI." Then how you would learn it, said as a plan and never as a past: what you would learn first and how you would check you had it. Never a claim to Power BI work |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Your material shows 7 years in operations and a current supervisory role, and not how many of the 7 years were leadership; the pack takes the lower reading. Answer slot: if 5 or more of the years were in roles leading people, say which roles and when; if fewer, say the number plainly and stay with the current role |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | presentation | Say it as you said it: "I'm green belt certified." Answer slot: the JD names Lean and Six Sigma, so expect a probe on which methodology the belt is in and where you applied it. If the pick-path redesign used belt tools, say which, in your own words; if it did not, say so plainly and stay with the certification |

## Persona table

No loop source establishes Atlas Freight's loop (research was refused), so the fallback archetype is Generic: screen, hiring manager, panel, with flat weights. The only tilt applied is the hiring-manager prior, which is an assumption you can overrule.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the job: diagnose a late site, plan peak, size a scorecard | High: the hiring-manager prior puts it first, and the JD is a list of operating problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| B. Skeptic | Quiet probing of the scale step: 3 supervisors to 12, one site to four, Power BI | High: the hiring-manager prior, and F1, F4, F6 and F7 are where your material is thinnest. B1 is the highest-ROI prep in this pack | Rehearse the single most predictable objection until it is boring; keep every claim at its quoted scope |
| C. Data-Driven Prober | Line-by-line on the 40% and the tools | Medium: you gave one hard number, and numbers draw probers | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| D. Pressure | Interrupts, time-boxes, asks how much was actually you | Medium: operations roles at this size often add a composure check; this weight is a flat-archetype default, not a finding | Pause, restate, hold the quoted position through two follow-ups, concede only what is true |
| E. Conversational | Friendly opener, Lean question, "what do you know about us" | Medium: a first conversation tends to open this way, and its questions are still scored | A 90-second arc built from your own sentences; treat casual questions as scored |
| F. Peer Evaluator | Seams between sites, credit across teams | Low: the assumed relationship is a manager, not a peer | Propose seam principles instead of pretending to know the seam |
| G. Values / Behavioral | Scenario probes: unpopular truths, customer over metric | Low: no values-style round is documented for Atlas, so this is two questions from the persona stems | Pick stories your material actually carries, or say plainly that none comes to mind |

## Question banks

### A. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one of your four sites drops sharply over two weeks. Walk me through how you diagnose it." | CASE | [generic] | Clarify first: how on-time is defined, what changed, which lanes. Then segment the delay, pull the data that separates causes, contain what you can this week, and name an owner and a review cadence with the supervisors. The question needs no claim about your past, so the guidance makes none | F2's requirement, asked as a live problem; generic because it is a pattern for the problem, not a fact about Atlas |
| A2 | "Cost-per-shipment is up quarter over quarter. Where do you look first?" | CASE | [generic] | Check the denominator and the shipment mix before the cost lines, then split the numerator into its main drivers, rank by size and by what you can change fast, and say what you would leave alone. Challenge one premise respectfully, such as whether the figure is comparable across sites | F3's requirement as a live problem; generic for the same reason as A1 |
| A3 | "You have twelve supervisors across four sites and one site is chronically late. How do you run your first thirty days?" | CASE | [generic] | Listen before changing anything: what each site's supervisors say is wrong, a baseline on the numbers, time on each site's floor. Then pick one change to test and say how you would know it worked. No claim about your past | F4's requirement; the question borrows the JD's 12 and 4 |
| A4 | "Peak season is eight weeks out. Sketch the surge plan for a four-site network. What do you need to know first?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure it aloud: what you need to know, the objective, the segments, the approach, the metrics, the risks. Then one sentence from your material: "I ran the site's peak-season surge plan two years running." Answer slot: say what the plan was and which parts were yours, in your own words; if any part was set by someone else, say so plainly and stay with the part you ran | F2 is the nearest evidence; CASE because it is asked as a live problem at network scale, which your quote does not claim |
| A5 | "Pick the three numbers you would put on a daily terminal scorecard, and tell me why." | CASE | [generic] | Name each number with its definition, its owner and how often it is read, and say what decision each one changes. Then say what the first version would be built in. No claim about your past | The JD's reporting line asked as a design problem; it needs no Power BI history |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Today you have three supervisors; this job has twelve across four sites. What changes?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Say the two numbers plainly, three now and twelve here. Answer slot: if you have led more than 3 or led across more than one site, say how, in your own words; if not, say so plainly and stay with the 3. Expect three follow-ups, one at a time: what is different at twelve, what you would do in the first thirty days, and what you would want from me. Answer the second as a plan, as in A3, and the third as a plan. Hold by returning to the 3, never by adding scope | F4 is the clearest scale gap and F1 sits beside it, so this objection will arrive in some form; JD because it scores a stated requirement |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Selection scaffold: choose the requirement where your own material is thinnest, name it first, and give the week-one plan for it. Fit rows F1, F4 and F6 are where your material is thinnest, so one of those is the likeliest choice. If no such requirement comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Skeptic's standard stem; the pack's read of F1, F4 and F6 tells you where to look |
| B3 | "Why this role, and why now?" | EXP | [generic] | Answer slot: say your reason in your own words and tie it to the JD's work, such as "own daily terminal operations". If the reason is partly about leaving something, say only what is true and keep it about what you are moving toward. Nothing in your material states a motive, so none is supplied here | Motivation consistency is what the Skeptic scores; the pack does not know your reason |
| B4 | "You come from warehouse and distribution. What do you know about how a terminal differs?" | EXP | [grounded] "7 years in warehouse and distribution ops" | Start from the quote at its own scope: "I have 7 years in warehouse and distribution ops." Answer slot: the JD says "daily terminal operations", so expect a probe on terminals. If any of your work touched a terminal, say what and what your part was; if it did not, say so plainly and stay with warehouse and distribution. Then ask what a day at one of theirs looks like | F1 shows warehouse and distribution, not terminals; EXP because it tests what your background actually covers |
| B5 | "The role needs five-plus years of operations leadership. How much of your seven years was leadership?" | JD | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Say the 7 years as 7 years in warehouse and distribution ops, and the current role as it reads. Answer slot: if 5 or more of the years were in roles leading people, say which roles and when; if fewer, give the number plainly and stay with the current role. Never turn 7 years of operations into 7 years of leadership | F7 is a length requirement the posting marks required, and the quote does not split the 7 years |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: the interviewer will ask how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours. Say each in your own words, and name the weakest assumption before they do. If you do not know how it was counted, say so plainly and return to the quote: "I cut mis-pick rate 40% by redesigning the pick path." Never supply a baseline or a method you cannot repeat under a second question | F3 holds the only figure in your material, and probers go to figures first |
| C2 | "What exactly changed in the pick path, and what was yours versus the team's?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Describe the change in your own words, as the quote says it, a redesign of the pick path. Answer slot: if some of the redesign was set by others or shared, say which parts, plainly; if all of it was yours, say that. Do not add steps the quote does not state | F3's attribution probe; EXP because it tests what was actually the candidate's |
| C3 | "The posting asks for Excel and Power BI reporting. Where are you with each?" | JD | [grounded] "solid Excel, never used Power BI" | Excel at its own scope: "I have solid Excel." Power BI, plainly: "I have never used Power BI." Then the plan, as a plan: what you would learn first and how you would check it. Answer slot: if you built Excel reports that others used, say what and for whom; if not, say so plainly. Never imply Power BI work | F5 and F6 together; the JD names both tools, and the second is a stated gap |

### D. Pressure / Stress (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Hold the quote at its own scope through two follow-ups: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which part of the redesign was yours; if it was shared or someone else's, say so plainly. Concede only what that answer makes true, and never fold on the core claim just to restore harmony | The Pressure stem aimed at the one figure you gave; F3 |
| D2 | "Sixty seconds: why you over someone who already runs a multi-site network?" | JD | [grounded] "7 years in warehouse and distribution ops" "ran the site's peak-season surge plan two years running" "cut mis-pick rate 40% by redesigning the pick path" "green belt certified" | Say what you have, in your own words and no wider: the 7 years in warehouse and distribution ops, the surge plan you ran two years running, the mis-pick cut, the green belt. Answer slot: if you have run more than one site, say so; if you have not, say so plainly and do not claim network experience. Hold through two follow-ups by returning to those four sentences | F1's multi-site gap under time pressure; the answer is the quotes, not a claim about the network |
| D3 | "Two minutes. What is the one thing you would change about how you ran the surge plan?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Answer slot: if there is something, say what and why, in your own words; if you would not change anything or cannot say, say so plainly and stay with what you ran: "I ran the site's peak-season surge plan two years running." Do not invent a flaw to look humble | F2; asked under a time box because the Pressure persona tests composure, not content |

### E. Conversational / Rapport (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | A 90-second arc from your own sentences and no more: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Then say what draws you to the JD's "own daily terminal operations" and stop. Answer slot: the middle of the arc is yours, so say what you did in each stretch in your own words; if there is a stretch you would rather not detail, say so plainly and move on | F1 and F7; the casual register is still scored |
| E2 | "Tell me about a time you used Lean or Six Sigma on a real problem." | JD | [grounded] "green belt certified" "cut mis-pick rate 40% by redesigning the pick path" | Start from "I'm green belt certified." Answer slot: if the pick-path redesign used belt tools, say which, in your own words; if it did not, say so plainly and either name another problem where you used them or stay with the certification. If no such time comes to mind, say so plainly | F8; the JD flags Lean and Six Sigma as a plus and a friendly interviewer will ask about it casually |
| E3 | "What do you know about Atlas Freight?" | CO | [generic] | Research could not run, so the pack knows only what the JD says: "regional logistics, 800 employees". Read their site, careers page and recent news, and bring two facts you found, with where you found them. If you find nothing attributable, say what you read and ask about the rest | Homework depth is scored in a casual register; generic because no company research is in this pack |

### F. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our sites sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles rather than pretending to know the seam: agree the handoff definition, agree who escalates and when, and decide ties on the customer's on-time outcome. Frame what you bring the other site, not only what you need. No claim about your past | F1's four-site requirement as a collaboration probe; the assumed relationship makes this low weight |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an occasion where work spanned shifts or teams, with a named contribution that was not yours alone and a result that shows tact and spine together. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer stem; no quoted sentence carries this story |

### G. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use "we" for context and "I" for what you did | A persona stem; no quoted sentence carries it, and no values-style round is documented for Atlas |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time where the on-time or cost number said one thing and the customer needed another, say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem that fits freight, where the customer's delivery is the product |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, A4, B1, B4, D2, F1 |
| "drive on-time performance" | A1, A4, A5 |
| "cost-per-shipment down" | A2, A5 |
| "lead a team of 12 supervisors" | A3, B1 |
| "build reporting in Excel/Power BI" | A5, C3 |
| "5+ years operations leadership required" | B5 |
| "Lean/Six Sigma a plus" | E2, D2 |

## Reverse questions

| # | Question to ask | Why it lands | Provenance |
|---|---|---|---|
| R1 | "If the first ninety days go well, what do on-time performance and cost-per-shipment look like at the four sites?" | It pins the JD's two headline measures to a definition of success and shows you think in outcomes | [generic] |
| R2 | "How are the twelve supervisors spread across the four sites, and where is the team strongest and thinnest?" | It shows you are already thinking about the scale step rather than avoiding it | [generic] |
| R3 | "Which reports do the sites run from today, and who owns them?" | It opens the reporting question on your terms and makes room for how you would pick up Power BI | [generic] |
| R4 | "How does the network handle peak season, and who owns the plan?" | It ties to your surge-plan experience without claiming network scope | [generic] |
| R5 | "What is the hardest site-level problem you want solved first?" | It turns the interview into a working conversation about the job | [generic] |
| R6 | "What would you want me to have learned by the end of month one?" | It signals you plan to ramp deliberately, which answers the scale objection from the other side | [generic] |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran multi-site terminal operations | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says warehouse and distribution operations and a senior shift manager role, not terminals and not four sites. Slots stay inside what you run |
| Led or managed twelve supervisors | Inflated form of F4 | F4's quote: "currently a senior shift manager over 3 supervisors". The limit is the pack's observation: the quote says 3 |
| Seven years of operations leadership | Inflated form of F7 | F7's quotes at their own scope: 7 years in warehouse and distribution ops, and a current supervisory role. The material does not say how many of the 7 were leadership |
| Any Power BI experience | Negative the candidate stated, F6 | The plain acknowledgment F6 gives: "I have never used Power BI." Then a plan, never a past |
| The pick-path redesign was a Lean or Six Sigma project | Inflated form of F8 | F8's quote at its own scope: "green belt certified". The slots in E2 and F8 let you say whether belt tools were used; the pack does not say they were |

## Sources

Provided documents: the job description pasted in your message and your background as stated in your message. No dossier was present.

Searches sent (all refused, nothing returned):

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Search refused. It would have moved the values cheat sheet (section dropped) and E3's grounding |
| 2. `Atlas Freight interview process operations manager` | unavailable | Search refused. It would have moved the loop structure and persona weights; the Generic archetype stands in and is said so above |
| 3. `Atlas Freight strategy` / recent news | unavailable | Search refused. It would have moved E3 and any strategy-grounded CO or CASE question |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting (recruiter, hiring manager, panel, skip-level) → persona weights recomputed; the assumed hiring-manager tilt replaced by the real one
- The interviewer's name → an interviewer read and a reverse question tied to their path
- Your resume text → evidence cells quote it instead of your message, and bridges for F1 to F8 tighten
- Search permission granted → the three refused targets run, which would add the values cheat sheet and loop structure to the pack; a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is also available on request
- The recruiter's guidance on focus areas or an announced presentation or take-home → coverage built to it, and a build section for any declared deliverable
- Your answers to the answer slots on F1, F2, F3, F4, F5, F7 and F8 → those rows move from `discovery` or `transferability` toward `none`, and the guidance becomes story-mapped
- A `tuesday-dossier.md` from a prior fit review → verified evidence and any prohibited-claims constraints in place of the locally built list
