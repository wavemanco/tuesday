Writing the pack now. Web research was refused in this session, so it is built on your message alone.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-6-denied-d02ff16d/larkfield-systems_engineering-manager_interview_pack.md`.

I built it in loop mode because you gave me the schedule. It has one shared fit snapshot, then a mini-pack for each round with its own persona weights, 8–11 questions and reverse questions. The panel's persona weights assume the two staff engineers and the product manager are who their titles suggest, because I have no names or backgrounds for them.

The pack names the step from a team of six to two squads of eleven as your highest-ROI rehearsal, and that is question A1. It comes back in every round: A1 with the Director, E4 with the panel, I1 with the VP.

I could not research Larkfield: all three searches were refused in this session, so nothing in the pack is a fact about the company. Because I had no published values, the values cheat sheet is dropped. The one company-strategy question (J2) is generic and flagged as the weakest part of the pack.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job posting? It would turn the generic and inferred rows into grounded ones, or say skip and the pack stands as is.
Did the recruiter say anything about what the panel or the VP round will cover, such as a case, a presentation or an exercise? An announced deliverable gets its own build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack — Engineering Manager, Larkfield Systems (loop mode, three rounds)

**Role:** Engineering Manager at Larkfield Systems (industrial IoT, ~600 people). The role description you gave: "Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap."

**Candidate:** Yusuf.

**The loop, as you described it:**

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| Round 1 | Tuesday | Director of Engineering, the hiring manager and your would-be boss | 45 min | Hiring manager |
| Round 2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min | Panel, mixed relationships |
| Round 3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min | Skip-level / executive, values-style |

This is loop mode: one shared fit snapshot and sources block, then a mini-pack per round with its own persona weights, bank and reverse questions. No interviewer names were given, so there is no interviewer read. No search ran (see Sources), so nothing in this pack is a claim about Larkfield itself.

## How to use this pack and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: every sentence about your past comes from something you wrote, and where your material is silent the guidance is an answer slot for you to fill in your own words, or to say plainly that it does not apply.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behaviour shows values and leadership principles, not generic virtue |
| EXP | Whether what you say about your work survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you can think at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

The few things to do well, in order. Everything else is insurance.

1. **Before Tuesday: say A1, A2 and A3 aloud until they are boring.** They are the scope step-up, the people-manager layer and the hardware gap, which are the three places your own message says the material is thin. A1 is the highest-ROI rehearsal in the whole pack.
2. **Before Tuesday: write out your answers to the slots in C1, C2 and F1.** How the 60% was counted, how the 40 interviews were counted, and which part of the reliability quarter was yours. You will be asked for each of them in all three rounds.
3. **Before Tuesday: run B1 and B2 aloud once each.** Think aloud, clarify first.
4. **After Tuesday, before Thursday:** take what the Director told you about how the two squads are structured and revise A1, A2 and E4 against it. Then rehearse E3, E4 and G1.
5. **Before Monday:** draft two or three leadership principles in your own words for H1. Rehearse I1 against a 60-second timer. Read Larkfield's public pages for J2.

## Fit snapshot

Requirements are quoted from the role description in your message. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description, your message | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says one team of six, with nothing about a second team or about device management, and the words stay there: "I've spent three years as a team lead of six." Answer slot: the two-squad line makes a probe on working across a second team likely. If any of your work spanned another team, say what and which part was yours, in your own words; if none did, say so plainly and stay with the team of six |
| F2 | "Lead two squads building device-management services" — role description, your message | "I've never managed managers" — your message | none | [grounded] | capability | The role description does not say whether the squads have their own leads, so this row marks a possible gap, not a stated requirement. If they do, the words are the one you stated: "I've never managed managers." Then how you would approach it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F3 | "own delivery" — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material shows one reliability quarter you pushed through and an on-call drop after it, with nothing inspected behind the figure. It does not say you owned a roadmap's delivery, and the words stay at the quote: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." Answer slot: the delivery line makes a probe on how delivery was tracked likely. If you were accountable for what shipped against a roadmap, say how, in your own words; if delivery was owned elsewhere, say so plainly and stay with the reliability quarter |
| F4 | "hiring ... for 11 engineers" — role description, your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | presentation | The loop is a named record, so lead with it in the quote's own terms: you run the loop for backend roles, about 40 interviews last year. The "40" has two readings (interviews you conducted, or interviews in the loop), so take the reading that claims less until you can say which it is. Expect a probe on how it was counted |
| F5 | "growth for 11 engineers" — role description, your message | none given | none | [grounded] | discovery | Your material does not show this requirement either way, and you have stated no absence. Answer slot: the growth line makes a probe likely. If the growth of any engineer on your team was yours to shape, say how, in your own words; if it was handled elsewhere, or there was no such part, say so plainly and say how you would approach it |
| F6 | "partner with hardware ... on roadmap" — role description, your message | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | You stated an absence of owning a hardware-adjacent roadmap, and the requirement says partner, so the stated negative covers owning and your material is silent on partnering. The words you may use: "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked alongside a hardware team on anything that touched a roadmap, say what and which part was yours; if you have not, say so plainly |
| F7 | "partner with ... product on roadmap" — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote touches roadmap tension and does not show whether you partnered with product on a roadmap. The pack derives only that the topic is likely to come up. Answer slot: if product was one of the parties in that roadmap pressure, say what your working relationship with them was, in your own words; if the pressure came from elsewhere, or product was not involved, say so plainly |
| F8 | "industrial IoT" and "device-management services" — role description, your message | none given | none | [grounded] | discovery | Your material is silent on device or industrial work and you have stated no absence, so the pack writes no first-person negative. Answer slot: if any past work touched device-connected systems, say what and which part was yours; if none did, say so plainly and say what you would ask first |

## Persona tables

Persona weights rest on the rounds as you described them. No documented Larkfield loop was available, so no process claim is made.

### Round 1 — Director of Engineering (hiring manager)

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the step up from one team to two squads, the people-manager layer and the hardware gap | high — the hiring-manager prior is derisking gaps, and F2 and F6 are gaps in your own words | Rehearse the single most predictable objection (A1) until it is boring. Use only what your quotes carry and name the limit before it is asked for |
| Case/Strategist | Live problems drawn from the role: planning two squads against a hardware dependency, a product-versus-reliability call | high — the hiring-manager prior includes live problems on their actual roadmap | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Data-Driven Prober | Asks how the 60% and the 40 interviews were counted | medium — F3 and F4 each hold a figure, and any figure is a magnet | Know what you can say about how each figure was counted, and say plainly when you do not know |
| Conversational | The opening "walk me through your journey" | low — it is certain to be asked but is not where the round is scored | A pre-scripted 90-second arc |

### Round 2 — panel (two staff engineers, one product manager)

Names and exact backgrounds are unknown, so the personas are assigned by each member's role. If you learn their names, send them and the weights get recomputed per member.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between a manager and staff engineers, "what would you need from us", credit and disagreement | high — two of three panelists are staff engineers who will price what a new manager costs them and contributes | Reciprocity framing. Propose seam principles instead of pretending to know the seam. Show spine and tact together |
| Data-Driven Prober | Technical credibility probes, and attribution on the reliability quarter | medium — staff engineers read claims for what was actually yours | Say what part was yours and say plainly when something was not |
| Values/Behavioral | Scenario probes on partnering with product and on disagreement | medium — a product manager is a cross-functional interviewer, which the priors map to behavioural questions | A story where your quotes carry one, a selection scaffold where they do not |
| Conversational | Rapport questions and the "any questions for us" slot | low — it appears mainly in the reverse-question slot | Never answer "I think you've covered everything" |

### Round 3 — VP Engineering (values and leadership philosophy)

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Leadership philosophy, growing engineers, hiring bar, an unpopular truth | high — the recruiter's own words call this round "values and leadership philosophy", which detects a values-style round | Name the principle yourself, then give a quoted event at its own scope. Use "we" for context and "I" for contribution |
| Pressure | Time-boxed challenge in 30 minutes: "why you", and the hardware gap | medium — the executive prior includes composure under time-boxed answers | Pause, restate, hold through two follow-ups, concede specifically |
| Case/Strategist | One structure question on how two squads work with hardware and product, and one company-altitude question | medium — the executive prior is strategy-heavy, but a values-style 30-minute round tilts away from cases, and no Larkfield strategy was researched | Clarify first and say which parts you do not know |

## Question banks

### Round 1 bank — Director of Engineering

**A — Skeptic (weight high)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led a team of six. What changes when the job is two squads and eleven engineers?" | JD | [grounded] "3 as a team lead of 6" | **The highest-ROI rehearsal in this pack.** Hold only what the quote carries: "I've spent three years as a team lead of six." Concede the step specifically: eleven across two squads is more than the six you have led. Then say how you would approach the step, as a plan and never as a past. Answer slot: if any of your work spanned a second team, say what and which part was yours; if none did, say so plainly and return to the team of six. Hold through two follow-ups by returning to the team of six, never by adding to it | F1 and F2 are where this role presses hardest, and the same objection returns in Round 2 as E4 and in Round 3 as I1. JD because it scores a stated requirement, Skeptic because it probes a gap |
| A2 | "This role may mean managing people who manage. Have you managed managers?" | JD | [grounded] "I've never managed managers"; "3 as a team lead of 6" | Say it plainly: "I've never managed managers." Then what you do have, at its own scope: "I've spent three years as a team lead of six." Then how you would approach it, as a plan: what you would ask the Director about the squads' structure, and whom you would learn from. Nothing is added to the experience and nothing is hedged around the stated negative. No answer slot, because the absence is stated | F2 is a gap in your own words, so an honest short answer is the rehearsal. JD because the role description raises leading two squads, Skeptic because it goes straight at the gap |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Say your weakest part first, before anyone finds it: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan: whom you would sit with, what you would read, by when. Answer slot: if you have worked alongside a hardware team on anything roadmap-related, say what and which part was yours, in your own words; if you have not, say so plainly | F6 is your own flagged gap, and "weakest on day one" is a standard Skeptic stem, so the Director will reach it in some form. JD because the hardware partnership is in the role description |
| A4 | "Why industrial IoT, and why now?" | JD | [grounded] "currently at a payments company" | Selection criteria for your own answer: name one specific thing that draws you to device-management work, say what you would carry over from where you are now, and say it in your own words. Honest branch: if the reasons are mostly about the manager scope and less about the domain, say that plainly and then say what you would learn about the domain. The only fact about you the pack supplies is the quote | F8 is silent in your material, so the domain question is a fit question. JD because it scores the stated field, Skeptic because it tests motivation consistency |

**B — Case/Strategist (weight high)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Both squads depend on the hardware team and a firmware release is slipping. Sketch the plan for the quarter. What do you need to know first?" | CASE | [generic] | Structure aloud. Clarify first: what is slipping, who decides trade-offs between the squads and hardware, what is fixed and what can move. Objective, then what must ship and what can slip, approach, metrics, risks. Challenge one premise respectfully, for example whether both squads need the same release. The question needs no claim about your past, so the guidance makes none | A live problem from the role description's hardware partnership (F6's requirement), which the hiring-manager prior says to expect. `[generic]` because it is a pattern for the problem, not a fact about Larkfield |
| B2 | "Product wants a new feature and one squad is carrying reliability debt. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure first: what the debt is costing, what the feature is worth, what each option risks, who else must agree. Then, if useful, one example at the quote's scope: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." Answer slot: if the roadmap pressure came from product, say how you worked it through with them; if it came from elsewhere, or was never resolved with them, say so plainly. Do not claim the story as a general method | F3 and F7 are where your material meets this trade-off. CASE because it is asked as a decision, with EXP as the follow-up if the example is used |
| B3 | "How would you split your attention across two squads in your first ninety days?" | CASE | [generic] | Structure aloud: what you would learn first, whom you would meet, what you would deliberately not change yet, and how you would know it was working. Name what you would ask the squads rather than what you would announce. The question needs no claim about your past, so the guidance makes none | F1 and F2 mean this is the practical form of the step-up question, and a plan is the honest answer to a gap. `[generic]` because it supplies a structure, not a fact about this team |

**C — Data-Driven Prober (weight medium)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 60% drop in on-call burden was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The defend-the-number rehearsal. Answer slot, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before they ask; and which part of it was yours. If you do not know how it was counted, say so plainly. Note the quote says "after", so say what you know about what moved it and what you do not. The pack names no method and no baseline | F3 is the headline figure in your material and the likeliest target for a prober. EXP because it tests whether the number survives scrutiny |
| C2 | "Walk me through your hiring loop and how you counted the 40 interviews." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Story-mapped on F4: you run the loop for backend roles, and there were about 40 interviews last year, which are the beats the quote states. Answer slot: the hiring line in the role description makes a probe on the loop's design likely. If any part of the loop was yours to set, say which and how you decided; if it was set elsewhere, or you only took part, say so plainly. Say which reading of the 40 is true: interviews you conducted, or interviews in the loop | F4 holds a figure with two readings, so it is a defend-the-number target. EXP because it tests attribution |

**D — Conversational (weight low)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering"; "3 as a team lead of 6"; "currently at a payments company" | A 90-second arc told in your own words: nine years in engineering, three of them as a team lead of six, and now at a payments company, which are the beats the quotes state. Answer slot: the beats between them, such as what you worked on and what moved you towards leading, are yours to fill in; if a stretch has no story, skip it. End on why this role, using your A4 answer | The biography question is certain in a manager round and is scored even when it feels casual. EXP because it is the CV walked aloud |
| D2 | "What have you been reading or building around device management lately?" | JD | [generic] | Selection criteria: name one specific thing you actually read, tried or asked someone about, and say what you took from it. Honest branch: if there is nothing yet, say so plainly, then say what you would start with this week. Do not name a technology or product you have not used | F8 is silent in your material, and a casual question about the role's hot topic is still scored. `[generic]` because the pack supplies no specifics about your reading |

**Round 1 reverse questions**

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "How are the two squads structured today: do they have their own leads, and where would the line of accountability sit for me?" | It turns F2 into a structural question, which signals you read the role and also answers whether the manager layer is in play |
| R1.2 | "What does the partnership with hardware look like today, and where does it work well and where does it chafe?" | It surfaces what the hardware gap (F6) really means in practice, and a manager asks about seams before promising anything |
| R1.3 | "How are on-call and reliability work weighed against roadmap commitments across the two squads?" | It tells you whether the reliability trade-off is a live issue, and it lets you listen before you speak |
| R1.4 | "What does a good first six months look like for the person in this role?" | It asks for the Director's own bar, so you can see what they will measure you on |
| R1.5 | "What would you want to see from me in the first ninety days to know the step up from a single team was working?" | It invites the objection openly, which converts an unspoken concern into a plan you can agree on |

### Round 2 bank — panel

**E — Peer Evaluator (weight high)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where does a manager's call end and a staff engineer's begin on technical direction, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam: who owns the decision, who is consulted, how a disagreement is escalated, and how it is recorded. Reciprocity: what you would bring to their work, not just what you need. Show spine and tact together by saying how you would disagree and what would change your mind. The question needs no claim about your past, so the guidance makes none | Two staff engineers will price what a new manager costs their work. JD because the role owns delivery for the squads, with Peer Evaluator as the delivery |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection criteria for your own story: pick a time work crossed teams and the credit was contested or easy to take; it needs a named stake, the moment you chose, and the relationship intact afterwards. Honest branch: if no such time comes to mind, say so plainly, then say how you would handle it | A persona stem for the Peer Evaluator, and credit-sharing probes are standard collegial packaging of a trust question. VAL because it scores behaviour, not skill |
| E3 | "What would you need from staff engineers to run delivery well?" | JD | [generic] | Reciprocity framing: name what you would ask of them in a way that also says what they would get back, such as clearer priorities or a manager who clears roadmap pressure. Say it as a proposal, not as something you have done. The question needs no claim about your past, so the guidance makes none | The "what would you need from me" stem of the Peer Evaluator. It also tells them whether you will add to their load or reduce it |
| E4 | "You've led a team of six. What will you do differently with eleven engineers, some of whom may know the systems better than you?" | JD | [grounded] "3 as a team lead of 6" | The panel's packaging of A1. Hold only the quote: "I've spent three years as a team lead of six." Then the plan, in the future tense: how you would ask, listen and defer on technical depth, and what you would take responsibility for instead. Concede that the step up is real. Answer slot: if any of your past work involved engineers who knew a system better than you, say what happened in your own words; if it did not, say so plainly | The same objection as A1, in collegial form, because staff engineers are the people who would be managed around. JD because it scores the stated requirement |

**F — Data-Driven Prober (weight medium)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through that reliability quarter. What part was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F3 with only the beats the quote states: you pushed a reliability quarter through, against roadmap pressure, and the on-call burden dropped 60% after. Answer slot: if you chose what the quarter contained, say how; if the engineers chose it, or it was set another way, say so plainly and describe what you pushed. Hold through two follow-ups by returning to what you pushed, never by adding to it | Staff engineers probe attribution on claimed work. This is the attribution form of C1, with the same quote and a different slot |
| F2 | "How do you stay technically credible with engineers who are deeper than you in a given area?" | EXP | [grounded] "9 years engineering" | Say plainly what you have: "I have nine years in engineering." Then selection criteria for your own answer: say how you actually stay close to the work, in your own words. Honest branch: if you are less hands-on than you were, say so plainly and say how you stay informed. The pack makes no claim about how hands-on you are now | A manager of staff engineers is judged on credibility, and the quote is the only fact about your technical depth in your material |
| F3 | "Device-management services sit between hardware and the cloud. What would worry you about building one?" | JD | [generic] | Structure aloud: name the unknowns, ask what you would need to know, and say how you would learn it. Answer slot: the role description raises device-management work, so a probe on adjacent experience is likely. If any past work touched device-connected systems, say what and which part was yours; if none did, say so plainly and say what you would ask first | F8 is silent in your material, so this is a discovery question. `[generic]` because the pack supplies no specifics about Larkfield's architecture |

**G — Values/Behavioral (weight medium)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you and product disagreed on priorities." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | An open prompt, so choose your own instance. If the reliability quarter is the one, map it only at the quote's scope: you pushed it through against roadmap pressure and on-call burden dropped 60% after. Answer slot: if the pressure came from product, say how the disagreement was worked through; how it ended with the people who applied the pressure is yours to say, and if it did not end cleanly, say so. If a different story fits better, use it | The role description raises partnering with product on roadmap (F7), and a product manager will score it. VAL because it scores behaviour with a cross-functional partner |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: pick a time with a named customer impact, a metric you let slip or argued against, and an outcome you can state honestly. Honest branch: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for cross-functional interviewers. It also fits a company that builds for industrial customers, though the pack has no Larkfield research behind that |

**Round 2 reverse questions**

| # | Question | Why it lands |
|---|---|---|
| R2.1 | To the staff engineers: "What could a new manager do in their first month that would genuinely help your squads?" | The reciprocity question for peer-facing interviewers, and it tells you what they actually need |
| R2.2 | To the staff engineers: "Where do technical decisions get made today, and where would you want a manager to stay out?" | It shows you respect the seam and gives you their line before you cross it |
| R2.3 | To the product manager: "How does the roadmap get negotiated between product, hardware and engineering today?" | It turns F6 and F7 into a question about the real process, which is more useful than a rehearsed position |
| R2.4 | "When reliability work and roadmap commitments collide, who decides today?" | It surfaces the trade-off you described in your own work, without asserting it as a method |
| R2.5 | "What would make you say yes, we want this person managing our squads?" | It lets the panel state their bar and gives you a last chance to address it |

### Round 3 bank — VP Engineering

**H — Values/Behavioral (weight high)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure."; "I run our hiring loop for backend roles — about 40 interviews last year" | Selection criteria: name two or three principles in your own words, then give one quoted event per principle at its own scope, and let the interviewer draw the inference. Your material carries two events: the reliability quarter you pushed through against roadmap pressure, and the hiring loop you run for backend roles. Which principle each illustrates is yours to say. Answer slot: if there is a principle your material does not carry an event for, say so plainly and say how you would apply it | The recruiter's own words for this round are "values and leadership philosophy", so this is nearly certain. VAL because it scores whether behaviour matches a stated philosophy |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | An open prompt from a persona stem. Selection criteria: it needs a named stake, a moment you did not fold, and an intact relationship at the end. Your material's nearest candidate is the reliability quarter, but it does not say whether the roadmap pressure came from leadership, so use it only if it did. Answer slot: if it did, say what the stake was and how it ended; if it did not, say so plainly and give a different instance, or how you would handle it | A standard values-round probe for an executive, and it tests whether you can hold a position upward |
| H3 | "How do you think about growing the engineers on your team?" | VAL | [grounded] "3 as a team lead of 6" | The role description names growth for the engineers, which makes this likely. Hold only the quote: "I've spent three years as a team lead of six." Answer slot: if the growth of any engineer on your team was yours to shape, say how, in your own words, without names; if it was handled elsewhere, or there was no such part, say so plainly and say how you would approach it as a plan | F5 is silent in your material, so this is a discovery row. The slot lets either truth be told |
| H4 | "You run a hiring loop for backend roles. What are you looking for in a candidate, and when would you say no?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Hold the quote: you run the loop for backend roles. What you look for and when you say no are yours to state, in your own words. Answer slot: if the bar was yours to set, say how you set it; if it was set elsewhere and you apply it, say so plainly and describe how you apply it. Never present the bar as a framework you invented unless you did | F4 is a CV-style line with nothing inspected behind it, so it gets probed. A values round tests judgement in hiring as much as in leading |

**I — Pressure (weight medium)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Sixty seconds: why you, rather than someone who has already led two squads?" | JD | [grounded] "3 as a team lead of 6"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause, restate the question, then answer in sixty seconds from the three quotes, in your own words and at their own scope. Hold the position through two follow-ups by returning to those facts. Concede specifically when pushed: eleven across two squads is a step up from the team of six, and you have not led two squads. Do not claim equivalence, and do not say what your work proves; let them draw the inference | The executive prior includes a time-boxed "why you" and this is the Pressure form of A1. JD because it scores fit to the stated role |
| I2 | "You've never owned a hardware roadmap. Why should I trust you with this role?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Pause, then the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then your position as a plan: how you would partner with hardware, whom you would ask, what you would do in the first weeks. Hold through two follow-ups by returning to the plan, and concede specifically that the learning curve is real. Answer slot: if you have worked alongside a hardware team on anything roadmap-related, say what and which part was yours; if not, say so plainly. The role says partner, and your quote says own, so do not argue the difference beyond one sentence | F6 is your own flagged gap, and an executive may test whether you fold or bluff. The negative is stated by you, so the acknowledgment is yours to say |

**J — Case/Strategist (weight medium)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "There are two squads, one hardware team and one product team. How would you set up how they work together?" | CASE | [generic] | Clarify first: how the work is split today, who prioritises, what has gone wrong before. Then objective, how you would split ownership, how decisions get made, how you would measure it, what could go wrong. Propose seam principles and say which you would test first. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The leadership-case form for a VP, and it draws on both partnership lines in the role description. `[generic]` because it is a structure for the problem |
| J2 | "What do you see as the main challenge for a company of Larkfield's size building device-management software for industrial customers?" | CO | [generic] | No company research was available for this pack, so there is nothing about Larkfield to coach. Before Monday, read Larkfield's public pages yourself and name what you read, then answer from that and say which parts you are inferring. Answer slot: if you have no view yet, say so plainly and say what you would want to learn first. Never assert something about Larkfield's strategy that you did not read | An executive round tends to test company-altitude thinking, and without research this question is `[generic]` and flagged as the weakest bank in the pack |

**Round 3 reverse questions**

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "How does engineering leadership here think about growing managers, and what happens when someone steps up from team lead?" | It turns F1 and F2 into a question about the company's own practice and signals you are planning for the step |
| R3.2 | "What is the hardest trade-off engineering leadership is making this year?" | An altitude question that invites the VP to tell you what matters, and gives you material for any follow-up |
| R3.3 | "How do you see the relationship between the hardware and software teams developing?" | It addresses the role's hardware partnership at the level the VP owns |
| R3.4 | "What would you want a new engineering manager to protect or change after a year?" | It asks for the VP's own bar in leadership terms, which suits a values round |
| R3.5 | "What would make you hesitant about someone with my background, and what would settle it?" | It invites the concern directly, so you can answer it before it hardens |

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| Lead two squads building device-management services | A1, A2, B3, E4, I1, J1 |
| Own delivery | B1, B2, C1, F1 |
| Hiring for 11 engineers | C2, H4 |
| Growth for 11 engineers | H3 |
| Partner with hardware on roadmap | A3, B1, I2, J1 |
| Partner with product on roadmap | B2, G1, J1 |
| Industrial IoT and device-management services | A4, D2, F3, J2 |

## Prohibited claims

What this pack will not coach, built locally from the fit snapshot because no dossier was present.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed or led managers, or led an organisation of leads | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I've never managed managers." Then "I've spent three years as a team lead of six." No slot |
| Owned a hardware-adjacent roadmap | Negative the candidate stated, F6 | The plain acknowledgment F6 gives: "I've never owned a hardware-adjacent roadmap." The partnering slot in F6 asks only whether you worked alongside a hardware team |
| Owned delivery of a roadmap, or cut on-call burden by 60% through your own programme | Inflated form of F3 | F3's quote at its own scope: the on-call burden dropped 60% after you pushed a reliability quarter through. The pack's observation is that your material says "after", not "because", and does not say you owned delivery |
| Owned hiring decisions, headcount or the hiring bar | Inflated form of F4 | F4's quote at its own scope: you run the hiring loop for backend roles, about 40 interviews last year. C2 and H4 slots stay inside the loop |

## Sources

**Provided documents:** your message only (the role description, the round schedule and your background). No CV, full job description, dossier or interviewer information was provided.

**Searches and fetches sent:**

| Query | Outcome |
|---|---|
| Larkfield Systems values industrial IoT | refused |
| Larkfield Systems interview process engineering manager | refused |
| Larkfield Systems strategy device management industrial IoT news | refused |

**Dossier:** none present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have fed the values cheat sheet (section 10), which is dropped, and mapped each published value to a story; VAL questions use the recruiter's own words as their raising source instead |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. It would have documented the loop; persona weights rest on the rounds as you described them |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The search was refused. It would have grounded the CO and CASE questions; J2 is `[generic]` |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | unavailable | No call was sent because the search budget and access went to targets 1 to 3 first and the host refused search. It would have supplied typical requirements, labelled `[inferred]`, for the fit snapshot; the role description you gave fixes the rows above |

## Upgrade menu

- Search access, or pasted Larkfield pages (values page, careers page, any interview guide) → the values cheat sheet, persona weights read from a documented loop, and CO and CASE questions grounded in Larkfield's strategy instead of `[generic]`
- A deeper research pass, up to 6 further searches and 2 further fetches and several more minutes → a strategy brief, a grounding section, and each interviewer's public footprint once names are known
- The full job description → the `[inferred]` and `[generic]` rows become `[grounded]`, and the requirement-coverage table is checked against the real list
- The interviewers' names, especially the two staff engineers and the product manager → per-member persona assignment, an interviewer read, and a reverse question tied to each person's path
- Anything the recruiter said about what the panel or VP round will cover, such as a case, a presentation or an exercise → a build section for each announced deliverable
- Your answers to the slots in F1, F3, F5, F6, F7, F8, C1 and C2, stated in your own words outside a drill → those rows become story-mapped and `[grounded]`, and each stated fact enters the evidence column verbatim
- A `tuesday-dossier.md` from earlier work, if you have one → confirmed evidence, a named top objection and a ready-made prohibited list; the pack is complete without it
