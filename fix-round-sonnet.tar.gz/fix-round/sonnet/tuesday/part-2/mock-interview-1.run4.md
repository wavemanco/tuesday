Running the default research pass now: Northwind Data's values, its interview process, and Dan Kovac's public footprint. Then I'll build the pack.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-1-denied-05572205/Northwind-Data_senior-gtm-strategy-lead_interview_pack.md`.

The host refused all three web searches (company values, interview process, Dan's footprint), so nothing in the pack comes from a search. It rests on your message only: the JD highlights, Priya's summary, your description of Dan, and your research note. The research note is undated, so check that it's still current. The pack was built for a single 60-minute peer conversation, with no recruiter guidance and no published values in hand.

It holds 21 questions across seven personas, each tagged with one question type and carrying answer guidance and a rationale:

| Persona | Questions |
|---|---|
| Data-Driven Prober | 5 |
| Peer Evaluator | 4 |
| Skeptic | 3 |
| Case / Strategist | 3 |
| Conversational | 2 |
| Pressure | 2 |
| Values | 2 |

I weighted the Prober and Peer Evaluator highest because Dan is a peer who describes himself as relentlessly data-driven. The pack also has a fit snapshot and a requirement-coverage table. It covers an interviewer read, six reverse questions, a list of claims it won't coach, and the sources and upgrade menu.

The highest-ROI prep is C1, "I don't see classic sales-ops or quota-setting in your background," followed by C2, on partner-motion design. Those are the two gaps in Dan's territory. The $400M figure (A1 and G1) is the most likely number to be probed.

Where the quotes don't show something, the guidance is an answer slot instead of a script. For example, the pack won't call Priya's volume targets "quotas" or her revenue model a "partner motion".

I can play Dan as the Skeptic on C1, and I'll push on the follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word, if you'd like either.

1. Did the recruiter or Dan's team say what the 60 minutes will cover, or ask Priya to bring something such as a case or a point of view? An announced deliverable would get its own build section.
2. Can you paste the full JD? The six requirement rows come from your highlights, and a full JD could add mid-list items that each need a question.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind. He would be Priya's peer, both reporting to the same VP.
- **Round:** one 60-minute conversation with Dan.
- **Built on:** your message only (JD highlights, candidate summary, interviewer description, your research note). Web research was not permitted in this session, so nothing here comes from a search.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and never say more than the quoted sentence next to it.

Bank letters skip F so they never collide with the fit-snapshot row IDs (F1 to F7).

**Highest-ROI prep: C1, then C2.** C1 is the objection most likely to come from Dan, a peer who owns sales strategy. C2 is the one JD line that says required. Rehearse both until they are boring.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Work-experience deep-dive | Whether the CV's claims survive scrutiny, and what the candidate actually did |
| JD | Role / JD-driven | Whether the candidate can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth: strategy, competition, recent moves |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role, live |

## 2. Fit snapshot

Requirements are quoted from your JD highlights. Evidence is quoted from your message and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | low | [inferred] | transferability | Derived from a career summary that names no go-to-market work. Your material says product strategy and ops at a large consumer-tech company, and the words stay there: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two-new-product-lines line makes a probe on which parts of that work were yours to set likely. If any were yours to set, say which and how you decided, in your own words; if none were, or it was not yours, say so plainly and stay with the strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | Your material says proposed and credited with, not who gave the credit or how the figure was counted. The words stay there: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's whitespace line makes a probe on where the proposal came from likely. If you can say how you arrived at it, say so in your own words; if it came from someone else's work, or there was no analysis behind it, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | No gap on the tools: "I'm skilled in SQL and Tableau." The JD's word is independent, and Dan's self-description makes a request to walk one analysis end to end likely. Answer slot: if you ran an analysis yourself, walk it through in your own words; if others ran it, or you have not done one end to end, say so plainly |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." The pack's observation is that the model is the evidence, not a motion. Answer slot: the JD's required line makes a probe on the model likely. If any parts of it were yours to set, say which and how you decided; if none were, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead in the quote's terms: "I set annual volume targets with cross-org consensus." Answer slot: if the orgs disagreed before consensus, say what and what moved them, in your own words; if they did not, say so plainly. The pack does not call these targets quotas |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | low | [inferred] | presentation | Derived from a quote that names no tool and no task. It is use, and the words stay there: "I use AI tools every day." Answer slot: if you have done anything beyond using tools, say what; if not, say so plainly and say what you would want to learn first |
| F7 | Pack's reading of the peer relationship: Dan's title puts sales strategy and quota-setting in his territory. No JD line says this | "No classic sales-ops or quota-setting experience" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to sales-ops work, and nothing added to make the gap feel smaller |

## 3. Reading the interviewer

Public professional footprint only, taken from your description of Dan's profile. No search could be run to extend it.

| Observation | Source | What it means for the conversation | Provenance |
|---|---|---|---|
| Describes himself as "relentlessly data-driven" | Your description of his profile | Expect each number to be probed to its assumptions. A bank (the Prober) carries the most questions for this reason | [grounded] |
| Career spine is pricing and monetization roles | Your description of his profile | Cases land best in pricing, packaging and unit-economics terms, his native language | [grounded] |
| One early-stage-startup chapter | Your description of his profile | Expect a probe on operating without a playbook and on big-company pace. Answer from what your quotes carry; where they carry nothing, use the honest branch | [grounded] |
| Peer, same VP | Your message | He is pricing what the hire costs and adds to his own work. Reciprocity beats a list of needs | [grounded] |

**Mirror opportunity (shared professional vocabulary, never shared identity):** his pricing and monetization spine pairs with F4's quote, "built a partner-level revenue model used in carrier negotiations". Use it as vocabulary, at its own scope, and do not call it pricing work unless you did that work.

## 4. Persona table

Weights come from three passes. Relationship prior: a peer round tilts to the Peer Evaluator and the Data-Driven Prober. Interviewer signals: "relentlessly data-driven" raises the Prober, a pricing spine tilts the cases, and the startup chapter raises the Skeptic. The loop: your words establish one 60-minute conversation with Dan, so no archetype fallback applies, and no values-style round is detected, which keeps the Values bank light. Recalibrate any weight you know better.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) | Bank and size |
|---|---|---|---|---|
| Data-Driven Prober | Probes how every number was counted and what each rests on | Highest. Peer prior plus his self-description | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know | A, 5 |
| Peer Evaluator | Seam-splitting, "what would you need from me", credit and disagreement | Highest. Peer prior, and he carries the cost of the hire | Reciprocity framing, and seam principles rather than pretending to know the seam | B, 4 |
| Skeptic | Quiet probing of the sales-ops, quota-setting and partner-motion gaps | High. Largest gaps sit in his territory, and the startup chapter adds scrappiness probes | Rehearse the single most predictable objection until it is boring, with calibrated candor | C, 3 |
| Case / Strategist | Live problems framed in pricing, packaging and bundling terms | Medium. Pricing spine tilts cases, but the round is a peer conversation | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise | D, 3 |
| Conversational / Rapport | Casual openers, "what are you playing with in AI" | Low to medium. Casual questions are still scored | A pre-scripted 90-second arc; never "I think you've covered everything" at the end | E, 2 |
| Pressure | Time-boxed challenges on attribution | Low. Possible from a data-driven peer | Pause, restate, hold through two follow-ups, then concede specifically | G, 2 |
| Values / Behavioral | "Tell me about a time" probes | Low. No values round detected, and no published values in hand | Pick stories by criteria, with the honest branch | H, 2 |

## 5. Question banks

Each question carries one type. Where a question has a second flavor, the rationale says so. Provenance quotes every candidate sentence the guidance rests on. A row with a label alone makes no claim about your past.

### Bank A: Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F2: a store-surface change you proposed, credited with a ~$400M ARR uplift. Those are the beats the quote states, so tell them in your own words. Answer slots: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly. Name a weakest assumption only if you actually know one | F2 carries the pack's only quantified claim, so it is the likeliest probe. EXP because it tests attribution and counting, which is the defend-the-number slot |
| A2 | "How was that partner-level revenue model used in the carrier negotiations, and which assumption in it would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: the model, and its use in the negotiations. Those are the beats the quote states. Answer slots: how it was used in the negotiations; the assumption you would defend least; which part was yours. The quote names no outcome, so add none. If you do not know, or it was not yours, say so plainly and return to the model | F4 is the model he is most likely to open, since it sits closest to his pricing vocabulary. EXP because it tests what was actually yours |
| A3 | "For a product with no sales history, where would you look first to size whitespace across land, adopt, expand and renew, and what would you not trust?" | JD | [generic] | Clarify first: what counts as whitespace at each stage, per product line, and what data exists and how it joins. State a hypothesis early, then name what you would distrust (definitions, attribution, selection effects), and end with the first query or view you would build. The question needs no claim about your past, so the guidance makes none | The JD's whitespace line, asked the way a data-driven peer would ask it. JD because it scores the stated requirement; CASE delivery. Generic because it is a pattern for the problem, not a fact about Northwind |
| A4 | "Tell me about an analysis you ran yourself, start to finish, in SQL or Tableau." | JD | [grounded] "skilled in SQL/Tableau" | Say what the quote says: you are skilled in SQL and Tableau. No quote carries a specific analysis, so this is a selection scaffold. Pick one with a question you owned, data you pulled yourself, one definitional choice you made, and what it changed. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach one | The JD's independent-analysis line plus his self-description. F3 is the evidence and has nothing inspected behind it. JD because it scores the requirement; EXP delivery |
| A5 | "How did you land on the annual volume targets you set?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: you set annual volume targets, with cross-org consensus. Those are the beats the quote states. Answer slot: the JD's cross-functional line and his own territory make a probe on how the number was derived likely. If you can say how, in your own words; if the method was not yours, or you do not recall, say so plainly and return to how consensus was reached. Name your weakest assumption only if you know one | F5 sits closest to Dan's quota vocabulary, which makes it the likeliest place for a seam probe. EXP because it tests what was actually yours |

### Bank B: Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between sales strategy and emerging-products GTM, and what happens when we disagree?" | JD | [generic] | Do not pretend to know the seam; ask how it works today. Offer principles: decide in advance whose call each decision is, agree one set of data definitions, and when you disagree, state the other side's case to their satisfaction before arguing yours. Say what you would bring his team, not only what you would need | The persona's own stem, aimed at the JD's cross-functional line. Generic because it makes no claim about Northwind or your past |
| B2 | "What would you need from me in your first 90 days, and what could you take off my plate?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience" | Reciprocity, in two halves. What you bring, at the quotes' scope: a partner-level revenue model used in carrier negotiations, and annual volume targets set with cross-org consensus. What you need: how his team defines and sets targets today. If you choose to name the gap, use the stated words: "I haven't had classic sales-ops or quota-setting experience." Do not offer more than that you bring | The reciprocity question a peer weighs most. F4, F5 and F7 are the three rows it draws on. JD because it scores the cross-functional line |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | State the principle, then keep your own word for your part: proposed. Use we for context and I for contribution. Answer slot: if other teams' work was part of that change, say whose and what; if there was none, say so plainly and stay with what you proposed | The persona's credit stem, and F2's own word credited makes the probe natural. EXP because it tests attribution honesty |
| B4 | "Tell me about a time you disagreed with a peer team's number or plan, and how it resolved." | JD | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold, with F5 as the nearest quote. Pick a case with a named stake, a moment you did not fold, and an intact relationship at the end. Answer slot: if the orgs disagreed before consensus, say what and what moved them, in your own words; if they did not, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The persona's disagreement stem aimed at the JD's cross-functional line. F5 is the only quote near it, and it says consensus, not disagreement |

### Bank C: Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal in this pack.** Deepest rehearsal, three levels. Level 1, concede first and plainly: "I haven't had classic sales-ops or quota-setting experience." Then the quote at its own scope: "I set annual volume targets with cross-org consensus." Do not add to it. Level 2, "So what would you do in the first 30 days?" Give a plan, in the future tense: what you would ask his team for and learn first. Level 3, "What would you not touch until you had learned it?" Name it as a plan too. Hold by returning to the quote, never by widening it | The objection most likely from a peer in sales strategy, and a gap you stated yourself, so F7 is the source. JD because it scores the role's fit; Skeptic delivery. The limit is named before he asks for it |
| C2 | "Partner-motion design is a requirement here. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the quote says: "I built a partner-level revenue model that was used in carrier negotiations." The pack's observation, not words for you: your material shows the model, not a motion. Answer slot: if any parts of the model were yours to set, say which and how you decided; if none were, or it was not yours, say so plainly and stay with the model. Then what you would want to know first about Northwind's partners, as a plan | F4 is the only evidence for the one line the JD marks required, which makes this the second-highest-ROI rehearsal. JD because it scores the stated requirement |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | Selection criteria: pick one you can pair with a first-30-days plan. One candidate your material supports: "I haven't had classic sales-ops or quota-setting experience." Any other weakness is yours to name in your own words. The pack's observation is that F1 also shows no go-to-market work. If you name nothing, say that plainly rather than reaching for a polished non-weakness | The persona's own stem. It sweeps every JD row, so F1 to F7 all feed it. JD because it scores honesty about the listed job |

### Bank D: Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A much larger platform vendor starts bundling a competing capability into its suite at no extra charge. How does that change the GTM for one of the new lines?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" | Clarify first: which line, which segment, and where in land, adopt, expand and renew the exposure sits, since bundling may hit land and renew differently. Then objective, segments, approach (stand-alone value, packaging, partner-led), metrics and risks. Think aloud, and challenge one premise respectfully. Use Dan's pricing and packaging vocabulary. Make no claim about Northwind's actual pricing | The competitive frame from your research note, asked as a live problem. CO because it tests current-strategy fluency; CASE delivery. The note is undated and not checked, so confirm it is current |
| D2 | "Compass is launching into the installed base. How would you sequence GTM across enterprise expansion and new-logo land, given profitability is a stated priority?" | CASE | [grounded] "three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Clarify the objective and what Compass is for (the pack does not know whether it is one of the two product lines; ask). Segment the installed base, sequence the motions, name the metrics from adoption to expansion to renewal, and say what the profitability constraint rules out. State your hypothesis early. No claim about your past is needed | All three stated priorities in one problem. CASE because it asks for structure; CO flavor. The same undated-note caveat as D1 |
| D3 | "Sketch a partner motion for a new data-infrastructure product. What do you need to know first?" | CASE | [generic] | Clarify first: who the partners already sell to, who holds the budget, where the integration sits, and what the partner must earn versus what Northwind must earn. Then objective, partner segments, approach, metrics, risks. The question needs no claim about your past, so the guidance makes none | The persona's stem on the one required JD line, rehearsed as a live problem so C2 has a second angle. Generic because it is a pattern, not a fact about Northwind |

### Bank E: Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc on the quote's beats: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Optional proof points at their own scope: the revenue model, the volume targets. Closing beat, answer slot: why Northwind and why go-to-market now, in your own words, because nothing in your material states it | F1 is the evidence, and a casual opener is still scored. EXP because it tests whether the story is told economically and truthfully |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say what the quote says: "I use AI tools every day." Answer slot: name the tools and what for, in your own words; if it is use rather than building, say so plainly. Do not claim knowledge of Compass internals | The JD's AI-is-a-plus line, asked casually, plus Compass as a stated priority. F6 is the evidence and is thin. JD because it scores the plus |

### Bank G: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That $400M figure. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate, then hold only what the quote carries: "I proposed it, and it was credited with that uplift." Hold through two follow-ups by returning to proposed, never by adding to it. Then concede specifically. Answer slots: how the credit was measured; which part was yours. If you do not know either, say so plainly, and do not fold on the core claim to restore harmony | The persona's attribution stem on F2. EXP because it scores precise attribution under pressure |
| G2 | "Sixty seconds: why you, rather than someone who has run enterprise sales strategy?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience" | Hold what the quotes carry: a partner-level revenue model used in carrier negotiations, and annual volume targets set with cross-org consensus. Concede in the stated words: "I haven't had classic sales-ops or quota-setting experience." Anything you would add about what you bring beyond the quotes is yours to say in your own words, and the pack supplies none | The persona's why-you stem, aimed at the GTM-ownership requirement that F1 only thinly supports. JD because it scores fit for the listed job |

### Bank H: Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a case with a named stake, a hard message that actually landed, and a relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The persona's own stem. No quote carries this, and no values round was detected, so it stays light. Generic because it makes no claim about your past |
| H2 | "Tell me about a time data changed your mind." | VAL | [generic] | Selection scaffold: pick a case where you held a view, saw a number that cut against it, and changed course, with what you did next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | His self-description as data-driven is the raising source, and the story tests whether you hold views loosely. VAL because it scores behavior, not a metric |

### Requirement coverage

| JD requirement (from your highlights) | Questions that cover it |
|---|---|
| "own GTM strategy for two new product lines" | C3, D2, G2, E1 |
| "identify whitespace across land/adopt/expand/renew" | A3, D1 |
| "run independent analysis in SQL and Tableau" | A4, A3 |
| "partner-motion design experience required" | C2, D3, A2 |
| "strong cross-functional influence" | B1, B2, B4, A5 |
| "AI experience a plus" | E2, D2 |
| Pack's reading of the peer relationship (F7) | C1, B2, C3, G2 |

## 6. Reverse questions

| # | Question | Why it lands | Tied to |
|---|---|---|---|
| R1 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it shows you are thinking about his load | Peer |
| R2 | "You've spent most of your career in pricing and monetization, with one early-stage chapter. What from that chapter do you still reach for when a motion has no history?" | Ties to his own path and invites a peer conversation rather than an interrogation | His career path |
| R3 | "Where does your team's work end and emerging-products GTM begin today, and where has that seam been messy?" | Opens the seam conversation B1 rehearses, on his terms | Peer |
| R4 | "When bundling by a larger platform vendor shows up, what does your team see first?" | Shows you did the homework on the competitive frame, and a data-driven peer can answer in numbers | Your research note |
| R5 | "Which two numbers would you want this role to move in the first year, and how are they measured today?" | Fits a self-described data-driven interviewer and gets a concrete definition of success | His self-description |
| R6 | "How is Compass expected to show up in enterprise expansion plans: as its own line, or inside the expansion motion?" | Asks what the pack cannot know, and shows you tied the stated priorities together | Your research note |

## 7. Prohibited claims

Built from the fit snapshot before any bank was written. Each entry is a claim this pack will not coach, with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says product strategy and ops |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says a revenue model used in negotiations, not a motion |
| Found whitespace across the customer lifecycle, or drove the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says proposed and credited with |
| Described annual volume targets as quotas | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says volume targets with cross-org consensus |
| Set quotas or ran sales ops | Negative you stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |

## 8. Sources

**Provided documents:** your message (JD highlights, candidate summary, interviewer description, research note on Northwind's priorities and competitive threat). The research note is undated and was not checked. No `tuesday-dossier.md` was present.

**Searches sent, all refused (the host did not grant search permission), none returned a result:**

- `Northwind Data company values principles`: refused
- `Northwind Data interview process strategy operations GTM role`: refused
- `Dan Kovac Director of Sales Strategy Northwind Data`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have supplied published value names for the VAL bank themes. No values-style round is detected either way, so no cheat sheet is owed |
| 2. `Northwind Data interview process GTM role` | unavailable | The search was refused. It would have checked whether Dan's session or other rounds carry a values-style round, and could have reweighted personas |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the priorities and the competitive frame that feed D1, D2, R4 and R6. Freshness is unchecked |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. It would have added talks and writing to section 3 and could have sharpened R2 |
| 5. representative Senior GTM Strategy Lead JD | skipped | Your JD highlights fix the fit-snapshot rows and the JD-tagged questions |

## 9. Upgrade menu

- Full JD text → the six requirement rows become exact quotes, and any mid-list requirement your highlights dropped gets its own question
- The recruiter's prep email (stated focus areas, any announced deliverable) → coverage matches what will be scored, and a deliverable would get its own build section
- Search access, or Dan's profile and any talks pasted in → section 3 and R2 rest on his own words, and persona weights are re-read from them
- Northwind's published values and interview-process page, pasted in → checks whether a values round exists; if one does, a values cheat sheet is added
- Your CV as written → evidence cells quote the CV instead of your summary; rows F1, F2 and F6 are the likeliest to change
- The write-up behind the ~$400M figure, the revenue model deck, and a sample SQL query or Tableau workbook → raises F2, F4 and F3 from medium toward high, since each is something inspectable
- Your answers to the answer slots on rows F1, F2, F3, F4, F5 and F6, said outside a drill → those rows are regenerated with your own words in place of the slots
- A `tuesday-dossier.md` from a prior role evaluation → verified evidence and a named top objection arrive pre-graded; this pack is complete without one
