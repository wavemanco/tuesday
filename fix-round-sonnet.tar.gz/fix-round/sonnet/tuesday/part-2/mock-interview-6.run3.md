Web search was denied, so the pack has no company research and I'll label company-specific parts generic. I'm writing the three-round pack now.
Yusuf, your three-round prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-6-denied-221d75c6/larkfield-systems_engineering-manager_interview_pack.md`.

I built it in loop mode: one shared fit snapshot, then a mini-pack for each round with its own persona weights, 11–12 questions and reverse questions. It is built from your role summary and the background lines in your message, since I didn't have the full job description or your CV.

- **No company research.** Web search was denied, so the three searches I tried returned nothing. The pack has no Larkfield values, loop details or strategy. Company-specific questions are labeled generic and there is no values cheat sheet.
- **Weights.** Skeptic and Case lead Tuesday, Peer Evaluator and Values lead the panel, and Values leads Monday.
- **Highest-ROI prep.** T-A2 is the hardware question: "You've never owned a hardware-adjacent roadmap — how would you handle the hardware side of this role?" It has the deepest follow-ups. T-A3 and V-B1 cover the "never managed managers" and two-squads scale objections.
- **Your two numbers.** The 60% on-call drop and the ~40 interviews each get a defend-the-number question (T-C1 and T-C2). The pack doesn't claim the quarter caused the drop, or that 40 interviews means 40 hires.
- **Answer slots.** Wherever your material doesn't show something, such as growth work, working alongside a hardware team or what carries over from payments, the guidance gives an answer slot rather than a story. Answer it from your real experience, or say plainly it wasn't yours.

I can run a live drill, for example the Skeptic on T-A2, the question the pack names as its highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Did the recruiter give you focus areas or a pre-declared deliverable for any round, such as something to present to the panel?
2. Can you paste the full job description and your CV? If not, I'll keep working from the role summary and what you've told me.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack — Engineering Manager, Larkfield Systems (three-round loop)

Candidate: Yusuf. Mode: loop — one shared fit snapshot, then a mini-pack per round.

- Tuesday, 45 min — Director of Engineering, the hiring manager and your would-be boss.
- The Thursday after, 60 min — panel of two staff engineers and a product manager.
- The following Monday, 30 min — VP Engineering, described by the recruiter as "values and leadership philosophy".

Built on: the role description in your message, treated as the JD, and your background lines, treated as your CV. Interviewer names were not given, so there is no interviewer read. Web research was not permitted in this session (see Sources), so company values, loop details and strategy are not in this pack, and company-specific items are labeled generic.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script. Every sentence in it that says what you did is one of your own sentences, quoted in that row's Provenance cell. An answer slot is an instruction for the interview: answer it from your real experience, or take the plain second branch.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows values and leadership, not generic virtue |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | The stated responsibilities, including the gaps |
| CO | Company and industry altitude |
| CASE | Structure and reasoning on a live problem |

## Fit snapshot (shared by all three rounds)

No requirement in the role description is a gate (a licence, location, schedule, pay or travel term). If the full posting lists one, send it and it becomes a row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message (two-squads scope) | "9 years engineering, 3 as a team lead of 6" — your message. "I've never managed managers" — your message | medium | [grounded] | transferability | Your material shows one team of six, not two squads, and it states you have not managed managers. The words stay at that scope: "Three of my nine years in engineering have been as a team lead of six." If the squads have their own leads, the honest line is the one you gave: "I've never managed managers." Answer slot: the two-squads line makes a probe on the jump from six likely. If you have led or coordinated work across more than one team, say what and how, in your own words; if you have not, say so plainly and stay with the team of six |
| F2 | "own delivery" — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence shows a reliability quarter pushed against roadmap pressure, not what shipped or who answered for delivery. The words stay at its scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: the own-delivery line makes a probe on what you were accountable for likely. If any delivery commitments were yours to answer for, say which, in your own words; if none were, say so plainly and stay with the reliability quarter |
| F3 | "hiring and growth for 11 engineers" — role description in your message (hiring half) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap in the words, but nothing is inspected behind a self-reported line, so expect a probe. Lead in the quote's own terms: you run the hiring loop for backend roles, and the figure counts interviews, not hires. The sentence does not say whether the forty were yours or the loop's, so that is a defend-the-number slot (T-C2) |
| F4 | "hiring and growth for 11 engineers" — role description in your message (growth half) | none given | none | [grounded] | discovery | Your material does not show growth work with engineers. Answer slot: the growth line makes a probe on how you develop engineers likely. If you have helped any engineer grow, say what you did and what changed, in your own words; if you have not, or it was not yours, say so plainly and say what you would do first in the role |
| F5 | "partner with hardware and product on roadmap" — role description in your message (hardware side) | "never owned a hardware-adjacent roadmap" — your message | low | [inferred] | discovery | Derived from your stated negative, read as covering ownership, not partnership: your message says owned, and is silent on working alongside a hardware team. The plain acknowledgment is yours to give: "I've never owned a hardware-adjacent roadmap." Answer slot: the hardware-partnership line makes a probe on whether you have worked alongside a hardware team at all likely. If you have, say how and which part was yours, in your own words; if you have not, or it was not yours, say so plainly and return to the acknowledgment. Then a ramp said as a plan, never as a past |
| F6 | "partner with hardware and product on roadmap" — role description in your message (product side) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence shows a push against roadmap pressure, not a partnership with product. Words stay at its scope. Answer slot: the product-partnership line makes a probe on who the pressure came from and how it ended likely. Say, in your own words, who it came from and how it ended; if you did not settle it with anyone, or none came from product, say so plainly and stay with the reliability quarter |
| F7 | "building device-management services" and "industrial IoT" — role description in your message | "currently at a payments company" — your message | low | [inferred] | discovery | The sentence names your employer's domain, not the work, so whether anything you build resembles device management is not shown. Answer slot: the device-management line makes a probe on what carries over likely. Say what your team builds and where it resembles this, in your own words; if nothing does, say so plainly and say what you would learn first |

## The three rounds at a glance

The loop is established by your own words: three sessions, each with who runs it and what it holds. No archetype fallback applies. Monday is the values-style round, on the recruiter's description as you relayed it.

| Round | Relationship | Personas, in weight order | What the mini-pack is for |
|---|---|---|---|
| Tuesday, 45 min | Hiring manager, future boss | Skeptic, Case/Strategist, Data-Driven Prober, Conversational | Making the hardware and scale gaps boring, and defending your two numbers |
| Thursday, 60 min | Peer and cross-functional panel | Peer Evaluator, Values/Behavioral, Prober, Pressure, Skeptic | Seams with staff engineers and product, and attribution under probing |
| Monday, 30 min | Skip-level executive, values round | Values/Behavioral, Pressure, Skeptic, Conversational, Case/Strategist | Leadership philosophy, and the leading-leaders gap |

A values cheat sheet is not included: the published values were not in hand, because the research was refused. VAL questions are themed from the recruiter's words and the persona stems.

## Sources and research accounting

Provided documents: your message (role description, round descriptions, background lines).

Searches sent, all refused, nothing returned: "Larkfield Systems values"; "Larkfield Systems interview process engineering manager"; "Larkfield Systems industrial IoT device management strategy news". Fetches: none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Would have fed a values cheat sheet with official value names and the VAL bank; VAL questions here are themed from the recruiter's words instead |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Would have shown whether the panel or the Monday round carries a deliverable or a fixed format; persona weights rest on your description of the rounds |
| 3. Larkfield Systems strategy and recent news | unavailable | Would have grounded the CO and CASE questions in current strategy; they are generic, which is the honest cost |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. Representative engineering manager JD | skipped | The role description you gave fixes the fit snapshot and the JD-tagged questions |

## Round 1 — Tuesday, Director of Engineering (45 min)

### Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps | Top, 4 questions. Hiring-manager prior is Case plus Skeptic, and F1 and F5 give it material from your own stated negatives | Rehearse T-A2 until it is boring; bridge only from stated evidence plus a ramp plan; do not bluff a competency the interviewer owns |
| Case/Strategist | Live problems from their roadmap | High, 3 questions. They are buying capability on a roadmap you have not seen, so the cases here are generic | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Reads your lines closely and asks how a number was counted | Low, 2 questions. The prior does not favor it, but two figures (F2, F3) are magnet targets | Know how each figure was counted and say plainly when you do not; name the weakest assumption first |
| Conversational | An unstructured opener that is still scored | Low, 2 questions. A 45-minute session usually opens with a biography question | Treat casual questions as scored; prepare a 90-second arc |

Values/Behavioral, Peer Evaluator and Pressure are not weighted for this round; they carry the later rounds.

### Question bank — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Name the weakness your material states, in this form: "I've never owned a hardware-adjacent roadmap." Then say the limit, then a ramp as a plan, not a history: who you would meet in your first weeks, what you would ask, what you would read. Stop there. If a different weakness is the truer one, use it in the same shape | F5 is the weakness your own message states, so the Skeptic reaches it first. JD because it scores the stated hardware-partnership requirement. T-A2 is the deeper version |
| T-A2 | "You've never owned a hardware-adjacent roadmap — how would you handle the hardware side of this role?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Hold it through two follow-ups by returning to that sentence, never by adding to it. Follow-up one is likely to be whether you have worked alongside a hardware team at all. Answer slot: the hardware-partnership line makes that probe likely. If you have, say how and which part was yours, in your own words; if you have not, or it was not yours, say so plainly and return to the acknowledgment. Follow-up two is likely to be your first thirty days. Say it as a plan: who you would meet, what you would ask, what you would want to understand before committing the squads to anything. Concede specifically that you would be learning the hardware constraints | F5 and F1 make this the objection most likely to arrive in some form, so it gets the most follow-up levels. JD because it scores a stated requirement; Skeptic is the delivery |
| T-A3 | "You'd lead two squads and eleven engineers — what changes for you from leading a team of six?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6", "I've never managed managers" | Say the sentence at its own scope: "Three of my nine years in engineering have been as a team lead of six." Answer slot: the two-squads line makes a probe on the jump likely. If you have led or coordinated work across more than one team, say what and how, in your own words; if you have not, say so plainly and stay with the team of six. If the squads have their own leads, the line is the one you gave: "I've never managed managers." Follow it with how you would learn it, as a plan. Never imply you have led leaders | F1 is the scale gap and the second-likeliest objection. JD because it scores the two-squads requirement |
| T-A4 | "Why this role, and why now?" | JD | [grounded] "currently at a payments company" | Selection scaffold: your material says where you are, not why you are moving. Start with "I'm currently at a payments company." Then one reason you actually hold for this role, tied to a line of the role description you can quote, then what you want to learn. If no reason specific to this role comes to mind, say so plainly, then say what you are looking for in your next role | F7 is the domain move; motivation consistency is what the Skeptic scores. JD because the answer must land on the role |

### Question bank — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-B1 | "Sketch how you'd spend your first ninety days with two squads you didn't build — what do you need to know first?" | CASE | [generic] | Clarify before structuring: what the squads are committed to, where hardware dependencies sit, the state of on-call, the hiring plan. Then objective, approach, metrics, risks. Think aloud and say what you would not decide until week four. The question needs no claim about your past, so the guidance makes none | The Director's own priorities are unknown, so this is a pattern, not a fact about them. CASE because it is a live problem; it also covers the own-delivery requirement (F2) |
| T-B2 | "Hardware slips a release by two weeks and product wants the date held on a device-management feature. What do you do?" | CASE | [generic] | Challenge one premise respectfully: is the date fixed, or the scope. Then the options, what you would tell each side and when, and the rule you would use to decide. No claim about your past is needed, so the guidance makes none | F5 and F6 meet here: a seam between hardware and product. CASE because it scores structure under a conflict |
| T-B3 | "On-call load keeps climbing on a service your squad owns, and the roadmap is full. How do you decide between a reliability quarter and roadmap work?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure first: the cost of leaving it, what each option buys, who has to agree, how you would put it to product. Your sentence gives the beats of a story you can tell: the reliability quarter, the roadmap pressure, the drop. The story has only those beats; tell it in your own words and add nothing the sentence does not carry | F2 is your strongest evidence, and this is where it is most likely to be used. CASE delivery with an EXP story attached |

### Question bank — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-C1 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Keep the sentence's scope: "my team's on-call burden dropped 60%". Answer slot, how it was counted: if you know, say so in your own words; if you do not, say so plainly. Answer slot, what it is sensitive to: same two branches. Answer slot, the assumption you would defend least: name it before they do; if you do not know one, say so plainly. Which part was yours: "I pushed a reliability quarter through." The drop is your team's. The sentence says "after", so do not say the quarter caused it unless you know that | Every headline figure is a magnet target. F2 holds the figure. EXP because it tests attribution |
| T-C2 | "About 40 interviews last year — how were those counted, and how many were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | The figure counts interviews, not hires or decisions. Say it as written: "I run our hiring loop for backend roles." Answer slot, how it was counted and how many were yours: the sentence does not say whether the forty were yours or the loop's, so say which, in your own words; if you do not know, say so plainly. Answer slot, the assumption you would defend least: same two branches. Name no hiring bar and no number of hires | F3 holds the figure; a count of interviews is easy to hear as a count of hires. EXP because it tests what was yours |

### Question bank — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-D1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6", "currently at a payments company" | A 90-second arc with only the beats your sentences state: nine years in engineering, three of them as a team lead of six, now at a payments company. Where the arc needs a project or a move, pick one you can stand behind and tell it in your own words; the pack supplies none. End on one sentence of your own reason for this role | The casual opener is scored. F1 and F7 hold the facts it can use |
| T-D2 | "What are you actually playing with in device and fleet tooling these days?" | JD | [generic] | Treat it as scored. Selection scaffold: pick one thing you have actually read, tried or discussed about managing devices, and say what interested you. If nothing comes to mind, say so plainly, then say what you would start with | The JD names device-management services, so a casual question about it is a scored one. Generic because the pack has no fact about what you use |

### Reverse questions for Tuesday

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| T-R1 | "What would make you say, six months in, that this hire was right?" | Gets the Director's own scoring criteria, which no pack can supply | [generic] |
| T-R2 | "Do the two squads have their own leads, or would the eleven engineers report to me directly?" | Settles the scale unknown in F1 and shows you are thinking about the structure | [generic] |
| T-R3 | "Where does the hardware roadmap constrain the squads' work most today?" | Turns the hardware gap into a learning conversation | [generic] |
| T-R4 | "How do the squads balance reliability work against roadmap commitments today?" | Opens the topic of your strongest evidence without claiming anything about their team | [generic] |
| T-R5 | "What would you want me to learn in my first thirty days that I am unlikely to know?" | Invites the gap conversation on your terms and signals candor | [generic] |
| T-R6 | "Which part of my background do you still have questions about?" | Gives you the chance to answer the live objection before the round ends | [generic] |

## Round 2 — Thursday panel (60 min)

### Persona weights

Names are unknown, so personas are not assigned per member. The blend takes the top personas of each member's likely relationship: the staff engineers read as peers or technical specialists, the product manager as cross-functional.

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting, "what would you need from me", credit-sharing probes | Top, 4 questions. Both staff engineers and the product manager are people whose load you would change | Reciprocity framing; propose seam principles rather than pretending to know the seam; disagreement stories with spine and tact |
| Values/Behavioral | Scenario probes, often from outside the function | Mid, 3 questions. A product manager is a cross-functional interviewer | Map a story only where your own sentence carries one; "we" for context, "I" for contribution |
| Data-Driven Prober | Depth verification from technical specialists | Low, 2 questions | Know your limits on the domain; say what you would ask |
| Pressure | Interrupts, tests composure | Low, 2 questions. A technical specialist round sometimes adds deliberate pressure | Pause, restate, hold a challenged position through two follow-ups before conceding anything real |
| Skeptic | Probing of the domain gap | Lowest, 1 question; F5 is already covered in Tuesday and Monday | Calibrated candor over bluffing |

Case/Strategist and Conversational get no separate bank here: the case items sit inside the Peer and Prober banks.

### Question bank — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-A1 | "Our team and yours sit side by side — where's the seam, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Propose seam principles rather than claiming to know the seam: who decides what, what gets escalated, how a disagreement is settled before it reaches a roadmap review. For a disagreement story, the sentence you have is "I pushed a reliability quarter through against roadmap pressure." Answer slot: the product-partnership line makes a probe on who the pressure came from and how it ended likely. Say, in your own words, who it came from and how it ended; if you did not settle it with anyone, or none came from product, say so plainly and stay with the sentence | F6 is where this surfaces. JD because it scores the stated partnership requirement |
| P-A2 | "A staff engineer wants a reliability fix to jump the queue; the PM has a customer commitment in the same sprint. You're in the room — what do you do?" | CASE | [generic] | Name the facts you need first, what each person needs, the rule you would use to decide, how you would tell each of them, and what you would revisit later. The question presupposes nothing about your past, so the guidance makes none | A live seam problem for two of the three panelists at once. Covers F2 and F6 requirements as a decision, not a record |
| P-A3 | "What would you need from us in your first month, and what could you do for us?" | JD | [generic] | Reciprocity: ask where the work is fragile and where the seams are, and say what you would offer as a plan, for example how you would handle requests that cross teams. Nothing about your past is needed | A peer is pricing what you cost and contribute. Generic because the pack knows nothing about this team |
| P-A4 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams and credit mattered, where you used "we" for context and "I" for what you did, and the relationships stayed intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona-stem question; it tests partnership, not a claim about you |

### Question bank — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The one sentence your material has that may fit is "I pushed a reliability quarter through against roadmap pressure." Whether that was a hard truth delivered to leadership is not in the material, so tell it only at that scope: the reliability quarter, the roadmap pressure, the drop. If a different time fits better, choose it by these criteria: a named stake, a moment you did not fold, a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for a cross-functional interviewer. F2 is the only evidence that might carry it |
| P-B2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named customer impact, a metric you consciously did not optimize, and a result you can describe without inflating it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona-stem question; no sentence of yours carries it, so the pack supplies none |
| P-B3 | "Tell me about a time you helped someone on your team grow." | JD | [grounded] "9 years engineering, 3 as a team lead of 6" | Your sentence shows the team lead of six; it does not show growth work. Answer slot: the growth line in the role description makes this probe likely. If you have helped any engineer grow, say what you did and what changed, in your own words; if you have not, or it was not yours, say so plainly and stay with the team of six | F4 is the unevidenced half of the hiring-and-growth requirement. JD because the growth line raises it |

### Question bank — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-C1 | "Tell me how the hiring loop you run for backend roles works." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say the sentence at its scope: "I run our hiring loop for backend roles." Answer slot: the hiring line makes a probe on how the loop is built and which parts were yours to set likely. If any were, say which and how you decided, in your own words; if the loop's design was set by someone else, or there was no such step, say so plainly and describe how you run it | F3 is the likeliest place staff engineers probe: they are the people the hire would be evaluating |
| P-C2 | "A batch of devices stops checking in after an update. How do you structure the first hour?" | CASE | [generic] | Say what you would ask before acting: how many, which version, what changed. Then contain, communicate, who you would pull in, and who decides what. As a manager the test is leading the response without taking it over. Do not claim device-management experience; say what you would ask the people who have it | F7: a technical probe at the domain you have not shown. Generic because it is a pattern for the problem |

### Question bank — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-D1 | "That result — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the part the sentence gives you: "I pushed a reliability quarter through." Hold it through two follow-ups by returning to that sentence. Concede specifically: the drop is your team's, and the sentence says "after", not "because". Answer slot: if you know what else changed in that period, say so in your own words; if you do not, say so plainly. Never fold the core claim to restore harmony | Attribution probe built to catch inflation. F2 |
| P-D2 | "Sixty seconds: why should we pick you for this?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6", "I run our hiring loop for backend roles — about 40 interviews last year", "never owned a hardware-adjacent roadmap" | Say what you did in your sentences' own words and let them draw the inference: nine years in engineering, three as a team lead of six; you run the hiring loop for backend roles. Then name the limit yourself: "I've never owned a hardware-adjacent roadmap." Hold your position through two follow-ups | Time-boxed answers test composure. F1, F3 and F5 supply the content |

### Question bank — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-E1 | "What would you need to learn about device management before this team could trust your calls?" | JD | [grounded] "currently at a payments company" | Say "I'm currently at a payments company." Answer slot: the device-management line makes a probe on what carries over likely. Say what your team builds and where it resembles this, in your own words; if nothing does, say so plainly and say what you would learn first and from whom | F7. JD because it scores the stated domain requirement |

### Reverse questions for Thursday

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| P-R1 | "What could a new engineering manager do in the first month that would genuinely help your work?" (to the staff engineers) | The reciprocity question; it tells peers you are thinking about their load | [generic] |
| P-R2 | "Where does the product roadmap most often meet the device and hardware schedule, and how is it settled today?" (to the product manager) | Aims at the seam F5 and F6 sit on | [generic] |
| P-R3 | "Is there technical work you feel does not get protected time today?" (to the staff engineers) | Invites the reliability conversation without claiming anything about their team | [generic] |
| P-R4 | "How would you like to hear that a roadmap commitment is at risk?" | A working-style question each panelist can answer from their own seat | [generic] |
| P-R5 | "What would you want a new manager to do differently from the last one, or the same?" | Surfaces the unwritten expectations of the people you would serve | [generic] |
| P-R6 | "What do you wish I would ask that I have not?" | The last-minute catch-all that rapport-style interviewers weight | [generic] |

## Round 3 — Monday, VP Engineering (30 min)

### Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes on how you lead, from the recruiter's "values and leadership philosophy" | Top, 4 questions. The recruiter's description is the signal; with 30 minutes, rehearse this bank first | Map a story where one of your sentences carries one; a scaffold with an honest branch where none does |
| Pressure | Time-boxed answers; altitude and composure | Low, 2 questions. Skip-level prior | Pause, restate, hold a position through two follow-ups |
| Skeptic | Probing the leading-leaders and hardware gaps | Low, 2 questions. F1 and F5 are your own stated negatives | Acknowledge plainly, then a plan |
| Conversational | A friendly opener that is still scored | Low, 2 questions | Treat as scored |
| Case/Strategist | Strategy-altitude questions | Low, 2 questions. Skip-level prior; generic because company strategy research did not run | Hypotheses labeled as hypotheses |

### Question bank — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-A1 | "What's your leadership philosophy?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6", "I run our hiring loop for backend roles — about 40 interviews last year", "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Selection scaffold. Pick two principles you actually hold, in your own words. Anchor each to what you did, at the scope your sentences give: a team lead of six; running the hiring loop for backend roles; the reliability quarter. Describe what you did and let them draw the inference. If a principle has no instance in those sentences, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The recruiter's own words raise this question. F1, F3 and F2 supply the anchors |
| V-A2 | "Tell me about the reliability quarter — what made you push for it?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The sentence gives four beats: the push, the reliability quarter, the roadmap pressure, the drop. Your reason is yours to give, in your own words; the pack supplies none. If you cannot say why you pushed, say so plainly and stay with the sentence | F2 is the one story your material carries. VAL because the VP is scoring the principle behind it |
| V-A3 | "Tell me about a time you were wrong as a lead." | VAL | [generic] | Selection scaffold: a named stake, what you changed afterwards, a relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Common in leadership rounds; no sentence of yours carries it |
| V-A4 | "How do you hire and grow engineers?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Hiring: say it as written, and note the figure counts interviews. Growth: answer slot, the growth line makes a probe likely. If you have helped any engineer grow, say what you did and what changed, in your own words; if you have not, or it was not yours, say so plainly and say what you would do first in the role | F3 and F4. JD because the requirement raises it |

### Question bank — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-B1 | "You've never managed managers — why should I trust you with two squads and eleven engineers?" | JD | [grounded] "I've never managed managers", "9 years engineering, 3 as a team lead of 6" | Concede first, plainly: "I've never managed managers." Then hold what the other sentence carries: "Three of my nine years in engineering have been as a team lead of six." Hold through two follow-ups by returning to those two sentences. Answer slot: if you have led across more than one team, say what and how; if you have not, say so plainly. Never imply you have led leaders | F1: the sharpest form of the scale objection at executive altitude |
| V-B2 | "Forty-five seconds: what would you change first, and what would you leave alone?" | CASE | [generic] | State that you would listen before changing anything, name one thing you would leave alone and why, and one you would look at first. Do not claim to know their roadmap | Time-boxed altitude test; no claim about your past |

### Question bank — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-C1 | "How would you build credibility with the hardware organization?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Open with "I've never owned a hardware-adjacent roadmap." Then a plan: who you would meet, what you would ask, what you would want to understand. Answer slot: if you have worked alongside a hardware team, say how and which part was yours; if you have not, say so plainly | F5 at executive altitude |
| V-C2 | "Where do you expect to struggle moving from team lead to manager?" | VAL | [grounded] "I've never managed managers", "9 years engineering, 3 as a team lead of 6" | Name one real expectation in your own words, as a plan and not a history. The sentences you can stand on are "I've never managed managers" and the team of six. If no concrete expectation comes to mind, say so plainly and say what you would ask your Director in your first month | F1. VAL because leadership philosophy is the round's subject |

### Question bank — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-D1 | "What drew you toward industrial IoT?" | JD | [grounded] "currently at a payments company" | Say "I'm currently at a payments company," then the real reason for the move, in your own words. If the move is not about the domain yet, say so plainly and say what you want to learn | F7; casual register, scored |
| V-D2 | "What would you want your future team to say about working for you?" | VAL | [generic] | State it as an aim, never as something they have said: "I want them to say…". If you cannot name an aim you hold, say so plainly and say what you would ask them | Values-round opener; no claim about your past |

### Question bank — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-E1 | "In industrial IoT, where does device management create value for a customer, and where does it become a cost?" | CO | [generic] | Say first what you know and what is hypothesis, and label the hypotheses. Structure by customer, by lifecycle stage, by cost. Do not state Larkfield-specific facts; the pack has none | Strategy fluency separates candidates at this altitude. Generic because the research did not run, which is the honest cost |
| V-E2 | "How would you decide what two squads should not build this year?" | CASE | [generic] | A decision rule, who has to agree, and what you would revisit; say you would not decide before understanding the roadmap | Scores judgment at the level of saying no. No claim about your past |

### Reverse questions for Monday

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| V-R1 | "What does a manager here do that you would point to as how we lead?" | Gets the VP's own leadership picture without assuming a published value | [generic] |
| V-R2 | "What is the hardest decision engineering leadership has faced in the last year?" | Altitude question; invites a real story | [generic] |
| V-R3 | "How do you want engineering managers to partner with hardware leadership?" | Returns to F5 on your terms | [generic] |
| V-R4 | "Where do the managers on your team need the most support?" | Shows you are thinking about the level above yours | [generic] |
| V-R5 | "What would make you regret this hire in six months?" | Surfaces the live objection at the end | [generic] |
| V-R6 | "How are managers developed here, and what would growth look like for me?" | Signals long-term intent | [generic] |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Lead two squads (F1) | T-A3, T-B1, V-B1, V-C2 |
| Own delivery (F2) | T-B1, T-B3, P-A2 |
| Hiring (F3) | T-C2, P-C1, V-A4 |
| Growth (F4) | P-B3, V-A4 |
| Partner with hardware on roadmap (F5) | T-A1, T-A2, T-B2, V-C1 |
| Partner with product on roadmap (F6) | T-B2, P-A1, P-A2 |
| Device-management services and industrial IoT (F7) | T-D2, P-C2, P-E1, V-D1, V-E1 |
| About 600 people — none, and why | Company context, not a requirement |

Headline figures: the 60% figure is covered by T-C1 and P-D1; the figure of about 40 interviews by T-C2. The most predictable objection, rehearsed deepest, is T-A2, and it is the highest-ROI prep in the pack.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads or managed eleven engineers | Inflated form of F1 | F1's team-lead quote at its own scope. The limit is the pack's observation: your material says a team of six, not two squads. T-A3's slot stays inside the team of six |
| Managed managers or led leads | Negative the candidate stated, F1 | The plain acknowledgment: "I've never managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative the candidate stated, F5 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." T-A2's slot asks only about working alongside a hardware team |
| Cut the on-call burden by 60% through the reliability quarter | Inflated form of F2 | F2's quote at its own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The limit is the pack's observation: the sentence says "after", not "because", and "my team's", not yours alone |
| Hired about 40 engineers or made the hiring decisions | Inflated form of F3 | F3's quote at its own scope: "I run our hiring loop for backend roles — about 40 interviews last year." The limit is the pack's observation: the figure counts interviews. P-C1's slot stays inside the loop |

## Upgrade menu

- Permission for web search → the three refused L1 targets run: values page (a values cheat sheet and VAL questions mapped to official value names), loop details, and current strategy (the CO and CASE questions in V-E1 and T-B1 stop being generic)
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches and several more minutes, for a strategy brief and interviewer footprints; only if web search is allowed
- The full job description → F1 to F7 requirements become exact quotes, any gate becomes a row, and requirements beyond your summary get questions
- Your CV → more of your own sentences to quote; F4, F5 and F7 rows and the bridges that rest on them are the likeliest to improve
- Your answers to the slots in F1, F2, F4, F5, F6 and F7 → those rows move from discovery or transferability toward none, and the guidance can use your words
- Interviewer names for each round → an interviewer read, panel personas assigned per member, and a reverse question tied to each person's career path
- The recruiter's focus areas or any pre-declared deliverable, such as something to present to the panel → a build section for that deliverable; usually one email to the recruiter
- Hours available for prep → a prep triage ordered by value
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and a named top objection in place of the ones inferred here; not needed to use this pack
