Searches were refused, so I'm writing the pack from your JD and background only, and labeling what research would have added.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-denied-8af8fc89/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 22 questions, a fit snapshot, a persona table, reverse questions and a requirements-coverage table.

- **Research didn't run.** All four searches were refused, so the pack uses only your JD and background. The questions about the studio's titles and strategy are marked as generic. There's no section on Tobias beyond his title.
- **Round type is assumed.** I treated Tobias as the hiring-side decision-maker, so the pack leans toward case questions and skeptic probing.
- **Biggest risk: B2.** "You haven't worked on a game with in-app purchases. How would you get up to speed?" It comes from your own words and is the one to rehearse until it's boring. B3 and F1 press on the same gap and on "never led a team".
- **Years of live-service.** Your material shows four years as an associate producer and two years on the calendar. It doesn't show how many of those years were on a live-service title. B5 covers this, so know your own count before Friday.
- **Answer slots.** Several rows (F1–F5, F8) hold prompts for you to fill in, in your own words, because your material doesn't say. Each has an honest second branch if the thing wasn't yours or didn't happen.

Say the word and I'll play the Skeptic on B2 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias your future manager, a skip-level, or a peer? The answer reweights every bank.
2. Did the recruiter mention a presentation, a take-home, or focus areas for the hour?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. 60 minutes, Friday.
**Candidate:** Femi.
**Built on this assumption:** Tobias is the hiring-side decision-maker for this seat (a hiring-manager round). Your note did not say, so persona weights follow that prior and are flagged for change.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: every statement about your past rests on a sentence you wrote, quoted in the Provenance column. Where the pack cannot know something, the guidance is an answer slot for you to fill in your own words, with an honest second branch.

| Type | What it scores |
|---|---|
| VAL | Past behavior against values or principles |
| EXP | Whether the claims on your CV survive scrutiny |
| JD | The role's stated responsibilities and requirements, gaps included |
| CO | Knowledge of the company and its products |
| CASE | A live problem set in the role |

## Prep triage

Two days remain (today is Wednesday, the interview is Friday). Do these in order; everything else is insurance.

1. Rehearse B2 aloud until it is boring. It is the highest-ROI prep in this pack (see the persona table).
2. Answer the slots in A2, B3, B5, C1 and D3 aloud, in your own words, once each.
3. Run the case structure on A1, A3 and A4 against a timer.
4. Spend an hour with the titles before Friday for A5 and D2: note what you observe, nothing you assume.
5. Pick three reverse questions from section 11.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is your own words from your message and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, not an events calendar across two, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-title line makes a probe on scale likely. If more than one title's calendar was yours, say which and how you kept them apart, in your own words; if only the main title's was, say so plainly and stay with that calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [grounded] | discovery | The material does not show whether coordinating across disciplines was part of the calendar, and you stated you have not led a team. Words: "I haven't led a team." Answer slot: if the content drops needed other disciplines to deliver to your dates, say how you got them there; if the dates were set elsewhere or no cross-team dates existed, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | Your material says presented, not owned and not reviewed, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's ownership line makes a probe on who produced the numbers likely. If you produced or reviewed any of them, say which part, in your own words; if you only presented figures others produced, say so plainly |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it, not that you managed releases against it. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran releases against it with QA, say how, in your own words; if not, or it was not yours, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The material shows four years as an associate producer and two years on the calendar, and does not show how many of the years were on a live-service title. Answer slot: if the main title was live-service for longer than the calendar years, say how long, in your own words; if not, say so plainly and stay with the four years as stated and the two years of the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: weekly, content-drop, main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms. Expect a probe on how the numbers were counted; C1 rehearses it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written document that others use touches the requirement but does not show the quality of your writing. Answer slot: if you wrote other material that others relied on, say what, in your own words; if the checklist is the main written piece you can point to, say so plainly |
| F9 | In-app-purchase experience: not a line in the JD, a role-family expectation with no source here | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

Reasoning shown so you can recalibrate. Relationship prior: hiring manager, which favors Case/Strategist and Skeptic. Loop: your own words establish this session as one 60-minute conversation with Tobias; no source establishes the wider loop, so the archetype fallback is Generic (flat tilt, no values-style round detected). Interviewer signals: none beyond title, since research did not run.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems from the role: plan this calendar, handle this slipped release, diagnose this dip | High. A hiring manager is buying capability, and the JD names calendar, release and retention work that can each be posed as a live problem | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| Skeptic (B) | Quiet probing of the gaps: in-app purchases, never led a team, one title versus two, years of live-service | High. F9 and F2 are the stated gaps and F1 and F5 are the stretched requirements | Rehearse the single predictable objection (B2) until it is boring; plain acknowledgments; a ramp plan said as a plan |
| Data-Driven Prober (C) | Reads the retention line and asks how the numbers were counted | Medium. F3 and F7 rest on one retention sentence, which is exactly where a prober digs | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know; name your weakest assumption first |
| Conversational (D) | Friendly opener, journey question, writing and what-are-you-playing questions | Medium. A 60-minute conversation usually opens this way, and it is scored | A 90-second arc built only from your four quoted sentences; treat casual questions as scored |
| Peer Evaluator (E) | Seam-splitting between disciplines, credit on cross-team work | Low. The role coordinates four disciplines, so collegial versions of F2 can surface | Reciprocity framing; propose principles for the seam rather than pretending to know it |
| Pressure (F) | Time-boxed challenges: why you, how much was actually you | Low. A hiring manager may test composure on the two stated gaps | Pause, restate, hold through two follow-ups by returning to what you quoted, concede specifically |
| Values/Behavioral (G) | Scenario probes on principles | Low. No values-style round is detected and no published values were read | Selection scaffolds with an honest branch |

**Highest-ROI prep: B2.** The in-app-purchase gap is the single most predictable objection, it is stated in your own words, and a rehearsed non-defensive answer changes the interview.

## Question banks

### A. Case/Strategist (weight high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two live titles share one art team. Sketch a four-week events calendar and tell me what you need to know first." | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: the goal of the four weeks, what the shared team can deliver and when, what each title's players are doing now. Then objective, how you would segment the weeks, the approach, the metrics you would watch, the risks. Think aloud and challenge one premise politely | The JD's two-title calendar line, which F1's requirement states; CASE because it is a live problem; generic because it is a pattern for the problem, not a fact about this employer |
| A2 | "Walk me through how you would run the events calendar for two titles at once." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F1: the weekly content-drop calendar, the main title, the two years, which are the beats the quote states; tell them in your own words. Answer slot: the JD's two-title line makes a probe on scale likely. If more than one title's calendar was yours, say how you kept them apart; if only the main title's was, say so plainly and describe how you ran that one | F1 is the evidence for the headline requirement and the likeliest place to be probed; JD because it scores the stated responsibility |
| A3 | "An event is two days from launch and engineering says a blocking bug means it cannot ship on time. Walk me through the next 48 hours." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: who must know and when, the options (slip, cut scope, ship with the issue known), what QA needs to re-verify, what the community team should be told and by whom, what gets recorded afterward. The one claim you can anchor is the checklist you wrote, in the quote's words. Answer slot: if you have handled a launch that was at risk, say what happened and what was yours; if you have not, say so plainly and answer as a plan | F4 is the evidence for the QA requirement; JD content with CASE delivery, because the release line is a stated responsibility posed as a live problem |
| A4 | "Retention for one title dipped in the week after a large event. Diagnose it." | CASE | [generic] | The question needs no claim about your past. Clarify before diagnosing: which players, compared against what, what changed besides the event, what data would separate causes. Offer two or three hypotheses, say how you would test each, and say what you would do if the data was inconclusive. Challenge the premise that the event caused the dip | The JD's retention requirement (F7's requirement) posed as a case; generic because it is a pattern for the problem |
| A5 | "Which of our mobile titles have you played, and what would you change about how its events run?" | CO | [generic] | Play before Friday and say only what you observed: what the events looked like, how often they changed, one thing you would test. If you have not been able to play, say so plainly and say what you would look at first. Research did not run, so nothing here is known about the titles | The JD refers to two mobile titles, so a homework question is likely; CO because it tests company knowledge, generic because it rests on no source about this employer |

### B. Skeptic (weight high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Answer slot: name the part you would be weakest at, in your own words. If you name the in-app-purchase gap, the words are "I haven't worked on a game with in-app purchases." Then say what you would do first to close it. If you name coordinating the four disciplines, the words are "I haven't led a team." Then answer as a plan. Do not choose a gap that is not true for you | F9 and F2 are the stated gaps; JD because it scores honest self-assessment against the listed requirements |
| B2 | "You haven't worked on a game with in-app purchases. How would you get up to speed if our titles rely on them?" | JD | [grounded] "never worked on a game with in-app purchases" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the ramp, said as a plan: what you would study first and whom you would ask, named in your own words. Expect three follow-ups: what you would read or ask first, what you could get wrong in your first event because of it, why not hire someone who has. Concede specifically: "That is a real gap on day one." Name the limit before it is asked: do not offset it with the puzzle studio, and do not add a past the quote does not carry | F9 is where the role presses hardest on your stated gap, so this objection arrives in some form; JD because it scores a requirement the posting is likely to touch |
| B3 | "Our events run across design, art, engineering and community. You've never led a team. How do you get four disciplines to move to your dates?" | JD | [grounded] "Never led a team", "I ran the weekly content-drop calendar for our main title for the last two years." | Open with "I haven't led a team." Answer slot: if the content drops needed other disciplines to deliver to your dates, say how you got them there; if the dates were set elsewhere or no cross-team dates existed, say so plainly and answer as a plan. Hold the line between coordinating and leading: you stated the second, the first is the slot | F2 is the gap the JD's coordination line presses on; JD because the line is a stated responsibility |
| B4 | "Your calendar was for your main title. What changes when it is two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you ran, in the quote's terms: a weekly content-drop calendar, one main title, two years. Answer slot: if any of it carried over to a second title, say how; if none did, say so plainly and answer what you would do differently as a plan, and name the one thing you would want to learn first | F1's gap between one title and two; JD because it scores the stated scale |
| B5 | "The JD asks for three or more years producing live-service games. Walk me through your live-service years." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio.", "I ran the weekly content-drop calendar for our main title for the last two years." | Say the four years and the two years as stated, in those words. Answer slot: if the main title was live-service for longer than the calendar years, say how long and what you did in those years; if not, say so plainly and stay with the two years. A years-of-experience requirement is probed literally, so know your own count before Friday | F5 is a requirement likely to be screened as written; JD because it scores a stated qualification |

### C. Data-Driven Prober (weight medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The beats the quote states: monthly, retention numbers, presented to the studio head. Answer slots, each in your own words: how the numbers were counted, what they were sensitive to, the assumption you would defend least, and which part was yours. If you do not know how they were counted, or you only presented figures others produced, say so plainly and return to what you presented | F3 and F7 rest on this one sentence, which a prober reads closely; EXP because it tests what was actually yours |
| C2 | "What would you want in a post-event review, and which KPIs would you put at the top?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | A question about the future, so structure it: the questions the review must answer, the few numbers that answer them, what you would compare against, what decision follows. The nearest thing your material carries is the monthly retention presentation. Answer slot: if you reviewed any drop after it shipped, say what you looked at; if you did not, say so plainly and answer as a plan | F3's requirement, ownership of the review and its KPIs; JD because it is a stated responsibility |
| C3 | "How would you tell whether an event worked, as opposed to the calendar just being busy?" | JD | [generic] | The question needs no claim about your past. Say what you would compare an event against, what would count as working before it launched, and what you would not conclude from a single event. Name your weakest assumption in the method before the interviewer does | F7's requirement posed as a judgment question; generic because it is a pattern for the problem |

### D. Conversational (weight medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio.", "I ran the weekly content-drop calendar for our main title for the last two years.", "Wrote the release checklist our QA team still uses.", "Presented the monthly retention numbers to the studio head." | A 90-second arc told in the order of your four quoted sentences, each at its own scope. Answer slot: why you are moving, and why live operations at this studio, in your own words; nothing here can supply them, and research on the studio did not run. Close on the role | F6 and F5 are the spine of the biography; EXP because the arc is checked against the CV |
| D2 | "What are you actually playing and watching in mobile live operations these days?" | CO | [generic] | The question needs no claim about your past. Name real games you actually play, and one observation about how their events run. If you have not played this studio's titles, say so. Pick things you can discuss for two follow-ups | A rapport-style opener on the JD's field; generic because it rests on no source about this employer |
| D3 | "What would you point to as evidence of clear written communication?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | The checklist is the written piece your material carries: say that you wrote it and that QA still uses it, in those words. Offer to share it only if you can without breaching your studio's confidence. Answer slot: if you wrote other material others relied on, say what; if the checklist is the main piece, say so plainly | F8's requirement; JD because clear writing is a stated requirement |

### E. Peer Evaluator (weight low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design wants the event bigger, engineering says it is too late, and community has already teased it. Where do you land?" | CASE | [generic] | The question needs no claim about your past. Say what you would ask each side, what option you would put to whoever decides, and what you would hold firm on. Propose principles for the seam rather than pretending to know how this studio splits it | The JD's four-discipline coordination line (F2's requirement) as a collegial disagreement |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a real instance if one comes to mind: a named stake, what you did, how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; VAL because it scores behavior, not a fact on your CV |

### F. Pressure (weight low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a producer who has run live events on games with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years.", "never worked on a game with in-app purchases" | Pause and restate. Hold the position the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Hold through two follow-ups by returning to that, never by adding to it. Concede specifically: "I haven't worked on a game with in-app purchases." | F9 under time pressure; JD because it scores fit against the stated requirements |
| F2 | "That retention reporting: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say which part was yours, in your own words. If you only presented figures others produced, say so plainly and return to what you presented, monthly, to the studio head. Do not fold on the quote and do not enlarge it | F3 and F7 attribution, asked as pressure |

### G. Values/Behavioral (weight low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | The nearest setting your material carries is presenting monthly retention numbers to the studio head. Selection criteria: a named stake, a moment you did not soften it, an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; VAL because it scores behavior, F7's setting is the only leadership-facing context in the material |
| G2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Selection criteria: a decision with a named trade-off, what you chose, what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; generic because no published values were read |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A2, B4, D1 |
| Coordinate design, art, engineering and community | B3, E1 |
| Own the post-event review and its KPIs | C2, C3, F2 |
| Manage the release checklist with QA | A3 |
| 3+ years producing live-service games or apps | B5, D1 |
| Experience running a content calendar | A2, B4 |
| Comfortable with player-retention metrics | A4, C1, C3 |
| Clear written communication | D3 |
| In-app-purchase experience (role-family, not in the JD) | B1, B2, F1 |

## Reverse questions

| # | Question | Why it lands | Rests on |
|---|---|---|---|
| R1 | "What would a strong first event look like in this seat, and what would tell you after 90 days that it went well?" | Calibrates to outcomes rather than activity | JD |
| R2 | "When design, art, engineering and community disagree on a date, who decides and how?" | Surfaces decision rights for the coordination line | F2 |
| R3 | "Which KPIs does the post-event review report today, and which do you trust least?" | Shows you would inspect assumptions, which C1 rehearses | F3 |
| R4 | "How does the release checklist work with QA now, and where does it hurt?" | Ties your checklist to their current pain | F4 |
| R5 | "I haven't worked on a game with in-app purchases. What would you want me to understand about how the titles earn before my first event?" | Turns the stated gap into a working question | F9 |
| R6 | "What is the most useful thing a new producer could learn in their first month?" | A general closer for the reverse-question slot | JD |

## Prohibited claims

Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says one main title's weekly content-drop calendar. A2 and B4 stay inside it |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope. The material says you wrote the checklist and QA still uses it |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The material says you presented the numbers |
| Built or analyzed the retention numbers | Inflated form of F7 | F7's quote at its own scope. C1 and F2 slots ask only which part was yours |
| Four years producing live-service games | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer, two years on the calendar |
| Led or managed a team | Negative the candidate stated, F2 | The plain acknowledgment: "I haven't led a team." No slot on leading |
| Has in-app-purchase experience | Negative the candidate stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the JD as pasted, and your background as written in your message. No dossier was present.

Queries sent, all refused (permission to search was not granted):

- "Saltmarsh Games mobile studio values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games strategy news mobile titles" — refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have moved a values cheat sheet if a values-style round exists. None is detected, so section 10 is dropped and G1 and G2 are generic |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have moved persona weights to the named rounds. The Generic archetype fallback is used and said so above |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have moved the CO bank. A5 and D2 are generic and labeled so |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have moved the interviewer read and a reverse question tied to his path. Both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, or pasted material → the four refused targets run: a values page, the interview process, the strategy and the titles, and Tobias's public footprint. A5 and D2 become grounded and the interviewer read and a tailored reverse question appear. A deeper pass would add up to 6 more searches and 2 more fetches and take several more minutes; this is the one offer of it
- Who Tobias is to the seat (future manager, skip-level, peer) → persona weights recomputed across every bank
- The recruiter's prep note → round format, any announced take-home or presentation, and focus areas for the hour
- Your spoken answers to the slots in F1, F2, F3, F4, F5 and F8 → those rows move from discovery toward grounded, and the matching questions become story-mapped
- A verified-evidence dossier from running the job-underwriter first → an evidence-derived top objection and prohibited-claims constraints; this pack stands without one
