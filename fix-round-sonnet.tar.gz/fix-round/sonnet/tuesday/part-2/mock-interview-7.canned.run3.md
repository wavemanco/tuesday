Searches turned up Saltmarsh's values page, its interview format and its Larkspur announcement. I'm fetching the values and interviewing pages in full next, then I'll build the pack.
Femi, your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-canned-f028c51b/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it assuming Friday is Saltmarsh's "Outage Hour" with Tobias as hiring manager. Their interviewing page describes that as a 60-minute session: a live-incident tabletop on a simulated outage, then a values conversation, with no take-home.

Say the word and I'll run a live drill as the Skeptic on C1. That's the question about no in-app-purchase experience with a season-pass model coming, and the pack names it as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Does the Live Operations Producer report to Tobias directly, or to someone under him? A skip-level answer would shift weight toward the tabletop and pressure questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi. **Interview:** Friday 13 November 2026, 60 minutes. **Interviewer:** Tobias Wrenfield, Head of Live Operations, assumed to be the hiring manager. **Built on this assumption:** Saltmarsh's interviewing page says every loop is a recruiter call, then the Outage Hour, a single 60-minute interview with the hiring manager (a live-incident tabletop on a simulated outage during a live event, then a values conversation). Your Friday session matches that format. Whether the role reports to Tobias directly is unconfirmed.

## 2. How to use this pack

- **Personas describe how a question is asked; types describe what is being scored.** Rehearse both.
- **Guidance is scaffolding, not a script.** Every claim about your past rests on a sentence you wrote, quoted in the Provenance column. Where the pack could not see something, it leaves an answer slot: say what is true in your own words, including that a step did not exist or was not yours.
- **Type key:** VAL is behavioral and values alignment. EXP is a work-experience deep-dive. JD is role and requirement driven. CO is company and strategy knowledge. CASE is a live problem.
- **The session has two parts.** The tabletop comes first, then the values conversation. The page does not say how the 60 minutes split, so prepare both fully.
- **Highest-ROI prep:** the Skeptic question C1 (no in-app-purchase experience, with a season-pass model coming) is the most predictable objection. The tabletop questions A1 to A3 and D1 are the other place to spend your time.

## 4. Fit snapshot

No JD requirement is a gate. "3+ years" is graded as experience, not as a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not a live-events calendar across two titles, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles line makes a probe on running more than one title likely. If you worked on the calendar of any other title, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the main title |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | discovery | Your material does not show whether you coordinated any of these groups; leading a team and coordinating across disciplines are different things, and you have stated only the first absence. Words you can say: "I've never led a team." Answer slot: if any of the four groups fed your content drops, say which and how you worked with them, in your own words; if none did, or you did not work with them directly, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you defined, produced or owned them or ran a post-event review, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event-review line makes a probe on who set what was reported likely. If you chose what was reported, say how you decided; if the numbers came from someone else's report, or there was no review, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it, not that you managed each release with QA, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran releases against it with QA, say how, in your own words; if QA ran it after you wrote it, or that was not your part, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | Four years as an associate producer is stated; your material does not say how many of them were live-service. Answer slot: if the game was live-service for more of the four years than the two calendar years, say how long, in your own words; if only the two years of content drops were live-service, or you are unsure, say so plainly and stay with the quotes |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: weekly, your main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap on the requirement as worded, but nothing inspected is behind it, so expect a probe on what the numbers were and how they were counted (E1). Lead with the presenting, monthly, to the studio head, in the quote's own terms |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | presentation | The checklist is the one written artifact in your material, and the pack derives the link to written communication. Words stay on the artifact: "I wrote the release checklist our QA team still uses." Lead with the artifact, not an adjective about it, and add no claim about how clear it was |
| F9 | "season-pass model" — Project Larkspur announcement (search summary), context and not a JD requirement | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work, and nothing added to make the gap feel smaller |

## 7. Reading the interviewer

Public professional footprint only. The facts come from a single search summary, so confirm them before leaning on them.

| Item | Source | Provenance |
|---|---|---|
| Head of Live Operations at Saltmarsh Games | GDC 2026 talk listing, "Patch Notes Are a Promise" | [grounded] |
| Previously a QA lead at a console studio | Same listing, single source | [grounded] |
| His talk's argument: a live team is judged by how often its patch notes describe what actually shipped | Same listing | [grounded] |
| Implication: expect questions that test whether what you announce matches what shipped, which is also the wording of the published value Ship the Patch Not the Promise | Derived from the talk's argument and the values page | [inferred] |
| Implication: a QA-lineage interviewer will hear the release-checklist story in QA terms, so tell it at its own scope and without adjectives | Derived from his stated QA background | [inferred] |
| Mirror opportunity: his path includes QA, and your side of that ground is F4, "Wrote the release checklist our QA team still uses". It is shared professional ground, not shared identity, so say it once and at its own scope | F4 and the listing | [inferred] |

## 8. Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The live-incident tabletop: a simulated outage during a live event, with decisions asked for live | High. The hiring-manager prior is Case plus Skeptic, and Saltmarsh's interviewing page names the tabletop as the first part of the hour | Clarify, then objective, then who you page, then what you decide now and what waits, then metrics and risks. Think aloud and challenge one premise respectfully |
| B. Values / Behavioral | The second part of the hour, a values conversation | High. The interviewing page documents a values conversation, so this is guaranteed in this session. Saltmarsh publishes three values, so expect questions themed on them | Map a story to each value where one of your sentences carries one. Use a selection scaffold with its honest branch where none does. Use "we" for context and "I" for what you did |
| C. Skeptic | Quiet probing of the gaps: in-app purchases, one title versus two, coordinating without leading | Medium. The hiring-manager prior includes it, and your own message names two gaps. Nothing else raises it above the loop's two stated parts | Rehearse the most predictable objection (C1) until it is boring. Bridge only from what you stated, say the limit plainly, and add a concrete plan |
| D. Pressure | Interruptions and time-boxing inside the tabletop, such as "sixty seconds, decide" | Medium. A live-incident tabletop invites it, and the interviewing page says nothing about style | Pause, restate, decide with a stated condition, hold through two follow-ups, then concede one specific uncertainty without folding the decision |
| E. Data-Driven Prober | Walking through the retention numbers you presented | Low. The JD names retention metrics, but nothing public about Tobias signals an analytics-first style | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| F. Conversational | The opener, "walk me through the journey", and the closing "any questions for me" | Low. It feels safe but is still scored | A 90-second arc built only from your own sentences. Never answer "I think you've covered everything" to the reverse-question slot |
| Peer Evaluator | Not included | The interviewing page puts you with the hiring manager, not a peer | Added if you tell me a peer is in the room |

## 9. Question banks

### A. Case / Strategist (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a limited-time event. Login works, but the event store fails to load for a large share of players on one platform. You are the producer on point. What do you do in the first ten minutes?" | CASE | [generic] | Clarify aloud first: what exactly is failing, which players and platform, since when, when the event ends, and whether purchases are affected. Then the objective: stop harm to players and keep one source of truth. Then who you page (engineering on call, QA to reproduce, community for a holding message), what you decide now versus what waits, and when the next update lands. Challenge one premise, for example confirming it is the store and not the login. Say plainly what you cannot know yet. The question needs no claim about your past, so the guidance makes none | The interviewing page names a tabletop on a simulated outage during a live event; the scenario here is invented as a pattern for that format, which is why it is generic |
| A2 | "Engineering says the fix lands in about three hours, and the event ends tonight. Extend the event, make good to players, or neither? What do you need to know, and what do you decide?" | CASE | [generic] | Name what you need: how many players are affected, what they lost, what extending does to the next event's dates, and how confident the fix is. Decide with a stated condition and say what you would watch. Saltmarsh's published value is that when the calendar and the players disagree, the players win, so be ready to say which side your decision serves and what it costs. No claim about your past | A second decision inside the same scenario, as a tabletop usually escalates; the value it leans on is published, the scenario is not |
| A3 | "Draft the player message you would post within thirty minutes. What does it say, and what does it deliberately leave out?" | JD | [generic] | Three short plain sentences: what is known, what is being done, when the next update comes. Leave out any fix time you cannot stand behind, because Saltmarsh's published value is to announce what is built, not what is hoped. Be ready to write it live. No claim about your past | The JD asks for clear written communication (F8); the delivery is a CASE, so the call is JD content in a live format |
| A4 | "Two weeks on, the outage is over. What goes in the post-event review, which KPIs does it report, and which decision should it change?" | JD | [generic] | Structure: timeline, player impact, what players were told versus what was true, the numbers (retention against comparable past events, participation, contact volume), cause and follow-ups with owners, and the one decision it should change. Say plainly where you would need data you have not seen. Answer slot: the JD's post-event-review line makes a probe on whether you have written one likely. If you have, say how it was built, in your own words; if you have not, or it was not yours, say so plainly and describe how you would build this one | Covers the JD's post-event review and its KPIs, with F3 as the nearest evidence; JD because it scores a stated responsibility, CASE in delivery |
| A5 | "From February, Saltmarsh's titles share one events calendar and one live-ops group. Sketch how you would plan the first quarter. What do you need to know first?" | CO | [grounded] | Clarify: which titles, how much their players overlap, how art, QA and engineering capacity is now pooled, each title's current cadence, and any season-pass milestones. Then objective, segmentation, approach, metrics and risks, such as two titles' events colliding for shared players. Challenge one premise respectfully, for example whether one calendar means one identical cadence. Read the full announcement before Friday: this pack saw only its summary. No claim about your past | The announcement summary says Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027 and a single live-ops group; this is the pack's strategy-grounded question |

### B. Values / Behavioral (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold, because your sentence carries a calendar but no clash: pick a time with a named date you had committed to, what players needed instead, what you gave up, and what actually happened, including if the calendar won. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it | Published value Players Before Plans; VAL because it scores behavior against that value; F1 is the nearest evidence |
| B2 | "Tell me about a time you were asked to announce something before it was built." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold: who wanted to announce what, what you said, what went out, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I wrote the release checklist our QA team still uses", at that scope only, or how you would handle it. The quote does not say the checklist stopped any early announcement, so do not say it did | Published value Ship the Patch Not the Promise; echoes Tobias's talk theme; F4 is the nearest evidence |
| B3 | "Tell me about a time a release left your process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4, with the beats the quote states: you wrote a release checklist, and your QA team still uses it. Tell it in your own words. Answer slot: the published value says every release should leave the checklist better, so a probe on what changed in it over time is likely. If you revised it after releases, say what and why; if you wrote it once and it has not changed, or you did not revise it, say so plainly and stay with the checklist you wrote | Published value Leave the Build Greener; the strongest value story the material carries |
| B4 | "Tell me about a time QA disagreed with you about whether a release was ready." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold: whose call it was, what QA saw, what you decided, what followed, and whether the working relationship was intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I wrote the release checklist our QA team still uses", or how you would handle it. Do not describe a disagreement the material does not show | The JD's QA line raises the theme, and Tobias's QA background makes it likelier; F4 is the nearest evidence |

### C. Skeptic (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases, and we are moving to a season-pass model in February. What do you do in your first month?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | **Highest-ROI rehearsal in this pack.** Hold-then-concede. Start with the plain statement: "I've never worked on a game with in-app purchases." Then what your material does carry, at its own scope: the weekly content-drop calendar and the monthly retention numbers you presented. Then a plan, said as a plan and never as a past: in the first month you would ask which measures the season pass is judged on, sit with whoever owns the economy, and read past event reviews. Do not say what your calendar or retention work shows about monetization; let Tobias draw any inference. Hold through two follow-ups by returning to the plain statement and the plan, and concede specifically what you do not yet know, in your own words | F9 is the biggest stated gap, and the season-pass move makes it matter; CO because it scores the company's strategy, Skeptic in delivery |
| C2 | "You ran the weekly content-drop calendar for your main title. This role runs live-event calendars for two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say what you ran, in those words. Answer slot: the JD's two-titles line makes a probe on running more than one title likely. If you worked on the calendar of any other title, say how; if there was no such step, or it was not yours, say so plainly and stay with the main title. Then, as a plan: what you would ask first about how the two titles' events interact | F1 is the gap between one title's content drops and two titles' live events; JD because it scores the first line of the role |
| C3 | "You've never led a team. How do you get design, art, engineering and community to move on one update?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | Start with the plain statement: "I've never led a team." Answer slot: the JD's coordination line makes a probe on which of those groups fed your drops likely. If any did, say which and how you worked with them, in your own words; if none did, or you did not work with them directly, say so plainly. Then describe how you would do it as a plan, never as a past | F2 is where the JD's coordination line meets your stated limit; JD because it scores a stated responsibility |

### D. Pressure (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds. The event ends tonight and the fix is two hours out. Extend it or end it? Go." | CASE | [generic] | Pause, restate the question, decide with one stated condition. Hold through two follow-ups (for example "engineering says it is risky", then "community wants to compensate everyone") by returning to your criteria. Concede one specific uncertainty, such as how many players are affected, without folding the decision. No claim about your past | A time-boxed version of A2; the tabletop format makes interruptions plausible |
| D2 | "That release checklist you wrote. How much of the release process was actually you?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Hold the sentence: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran releases against it, or others shaped it, say which part was yours and which was not, in your own words; if you wrote it and others ran it, or there was no further part, say so plainly. Hold through two follow-ups by returning to the sentence, never by adding to it | F4 is the JD's QA line and the likeliest attribution probe; JD content, Pressure delivery |
| D3 | "Sixty seconds. Why leave a puzzle studio where you have been running the calendar?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | The reasons are yours; the pack supplies none. Answer slot: say in your own words what draws you to this role, and tie it to a line of the JD that is actually true for you; if you are unsure, say so plainly and say what you want to find out. Keep it to the sixty seconds | Motivation consistency is scored in a stress register; F5 and F6 carry the quotes |

### E. Data-Driven Prober (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly retention numbers you presented to the studio head. Which measures, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you presented, in those words. Answer slot: if you chose or built any of the measures, say how; if they came from someone else's report, or you do not know how a figure was counted, say so plainly. Name, in your own words, the assumption behind the numbers you would defend least. The pack names no measure and no method | F7 is the JD's retention line and the likeliest EXP probe; no figure appears in your material, so the pack supplies none |
| E2 | "Retention drops twenty percent the week after an event ends. Diagnose it." | JD | [generic] | Clarify first: compared to what baseline (comparable past events, same player age), which players and platform, and whether a release or outage coincided. Separate the expected post-event dip from a real drop, state hypotheses, and say what data would settle each. Say plainly what you cannot tell without data. No claim about your past | The JD's retention line as a live problem; JD content, CASE delivery |

### F. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc in order: the four years as an associate producer at a puzzle-game studio, the calendar, the checklist, the retention numbers, each in your own words and no bigger than the sentence. Answer slot: the JD asks for three or more years producing live-service games or apps, so say how many of your years were live-service if you know; if only the calendar years were, or you are unsure, say so plainly | F5 is the "3+ years" line; the opener is scored even though it feels casual, and it is JD content in a casual register |
| F2 | "What are you actually playing these days, and what do its live events get right or wrong?" | CO | [generic] | Answer slot: name a game you actually play and one specific thing you have noticed about its events, such as cadence, rewards or how it announces changes; if you do not play live-service games, say so plainly and say how you would study one. The pack names no game | A casual question about the JD's subject that is still scored; generic because it depends on what you play |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | C2, A5 |
| "coordinate design, art, engineering and community teams on each update" | C3 |
| "own the post-event review and the KPIs it reports" | A4 |
| "manage the release checklist with QA" | D2, B3, B4 |
| "3+ years producing live-service games or apps" | F1 |
| "experience running a content calendar" | C2, F1 |
| "comfortable with player-retention metrics" | E1, E2 |
| "clear written communication" | A3, F1 |

Totals: 19 questions. Every published value is covered: Players Before Plans by B1, Ship the Patch Not the Promise by B2, Leave the Build Greener by B3, with B4 touching the second and third.

## 10. Values cheat sheet

A values-style round is detected: the interviewing page documents a values conversation. Value names are as published on the values page.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold on B1: F1's quote, "I ran the weekly content-drop calendar for our main title for the last two years", carries the calendar but no clash. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold on B2: F4's quote, "Wrote the release checklist our QA team still uses", is the nearest thing and does not show an early announcement. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses". Story-mapped on B3, with its answer slot on what changed in the checklist |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Your GDC talk argues a live team is judged by whether its patch notes describe what actually shipped. How does the team check that today, and where does the producer sit in that check?" | Tied to his own public work, so it shows you researched him and not just the company, and it invites a conversation about the QA and release seam |
| 2 | "You came to live operations from QA. What did that change about how you run releases?" | Tied to his career path. It turns a probing hour into a peer conversation. His QA background is a single-source fact, so ask it as a question and do not assert it |
| 3 | "Project Larkspur moves to one live-ops group and one shared events calendar from February. What does the first quarter of that calendar need most from a new producer?" | Shows homework on the strategy and asks what the role really needs |
| 4 | "What is the best post-event review you have seen, and what did it change?" | Probes the JD's post-event review and KPI line, and signals you take the review seriously |
| 5 | "Where would you expect a producer coming from a puzzle studio to need the most support in the first ninety days?" | Invites candor about the in-app-purchase gap and turns the Skeptic's best question into a coaching conversation |
| 6 | "Who owns changes to the release checklist, and how does QA sit in that?" | Ties to Leave the Build Greener and to your own checklist, and shows you think about the process after launch |

## 13. Prohibited claims

Built locally from the fit snapshot before the banks were written. None of these may be asserted, softened or implied in any answer, hold or bridge.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one main title's weekly content-drop calendar, not two titles' live events. C2's slot stays inside the main title |
| Led or managed the teams on each update | Negative you stated, F2 | The plain acknowledgment: "I've never led a team." The slot in C3 covers only coordination you may have done |
| Has in-app-purchase or monetization experience | Negative you stated, F9 | The plain acknowledgment: "I've never worked on a game with in-app purchases." No slot |
| Managed the release process with QA, or owned QA sign-off | Inflated form of F4 | F4's quote: "Wrote the release checklist our QA team still uses". Your material says you wrote the checklist, not that you ran releases against it |
| Owned, defined or produced the retention KPIs or the post-event review | Inflated form of F3 | F3's quote: "Presented the monthly retention numbers to the studio head". Your material says you presented the numbers |
| Four years of live-service producing | Inflated form of F5 | F5's quotes at their own scope. Your material says four years as an associate producer and two years of weekly content drops, not that all four were live-service |

## 14. Sources

**Provided documents:** the JD you pasted, and your background message. No dossier was present.

**Searches sent, with what came back:**

- "Saltmarsh Games values": returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer": returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games strategy news mobile": returned https://saltmarshgames.com/news/project-larkspur (search summary only; the page itself was not fetched)
- "Tobias Wrenfield Saltmarsh Games": returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (search summary only; single source)

**Fetches sent:** https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both returned.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, section 10, with the three published value names; the B bank themes |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: the Outage Hour, a tabletop then a values conversation, no take-home. Persona weights follow it, and no graded deliverable section is needed |
| 3. `Saltmarsh Games strategy` / recent news | yes | A5 and C1, and reverse question 3. Only the search summary was read, because both fetches went to targets 1 and 2 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read, reverse questions 1 and 2, and the Mirror opportunity |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 15. Upgrade menu

- Recruiter guidance on the Outage Hour (how the 60 minutes split, and what the tabletop covers) → reweights the personas and the depth of banks A and B
- Whether the role reports directly to Tobias → confirms or reweights the persona table
- A deeper research pass (offered once: up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the Larkspur announcement and Saltmarsh's strategy, more of Tobias's public talks and writing, role-family loop reports, and recent org context; A5, C1 and the reverse questions become title-specific
- Which two titles this role covers → A5 and C2 become specific to them
- Your answers to the slots in F1, F2, F3, F4 and F5, stated here and not in a drill → those rows move from discovery or transferability toward grounded evidence, and the banks that draw on them regenerate
- Your monthly retention deck and the release checklist itself → raises F3, F4 and F7 from medium toward high, since these are the artifacts a live-ops hiring manager can inspect
- A short writing sample → raises F8 from low
- Hours available before Friday → a prep triage sized to your time
- A tuesday-dossier.md from an earlier fit assessment → verified evidence and an allowed strategy per weak area, which would sharpen the guidance; the pack does not need it
