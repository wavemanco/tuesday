Searches were denied, so I'm building the pack from your JD and background only. I'll write it to a file now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-2-denied-ca01ead9/Atlas-Freight_operations-manager_interview_pack.md`. I built it for a hiring-manager round, since you don't know who you're meeting. Web search was denied in this session, so everything about Atlas Freight comes only from the posting you pasted. Its values, interview loop and strategy are not covered. The pack's highest-ROI prep is B1: the step from three supervisors at one site to twelve across four.

Say the word and I'll run a live drill, playing the Skeptic on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you know what round this is and who it's with (hiring manager, HR, panel), and has the recruiter mentioned a presentation or an operations case? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas-Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager (regional logistics, 800 employees). Interviewer: unknown. Built on one assumption: a hiring-manager round, because the round type and who you meet are not known. Web research was refused in this session, so nothing here is drawn from Atlas Freight's own pages; the only facts about the employer are the lines of the posting you pasted.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script; every line you say about your past must be one you can repeat under a second question.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows what the question is after |
| EXP | Work-experience deep-dive: whether a claim survives scrutiny, and what was actually yours |
| JD | Role or posting driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role, answered by structure and reasoning |

## Prep triage

Sized to about a week. Do these four, in order; everything else is insurance.

| Order | Do this | Where |
|---|---|---|
| 1 | Say B1 aloud until it is boring: the step from three supervisors at your site to twelve across four. This is the highest-ROI prep in the pack | B1, A3 |
| 2 | Settle the 40 percent figure: how it was counted, what it is sensitive to, what was yours | C1, C2, D1 |
| 3 | Rehearse the Power BI line in one breath, then the plan | B3, A4 |
| 4 | Talk through one live problem out loud with a timer | A1 |

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the posting you pasted. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops and a shift manager's role, and the words stay there: "I'm a senior shift manager over 3 supervisors." The pack observes that the material names no terminal and no second site; that is analysis, not words for you. Answer slot: the JD's four-site line makes a probe on scope likely. If your remit has covered more than one site or any terminal work, say which and what part was yours, in your own words; if it has not, say so plainly and stay with the work you described |
| F2 | "on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The surge-plan sentence touches the requirement without showing whether the plan reached on-time performance, and the bridge should not be stretched. Answer slot: if the plan was tracked against on-time performance, say how and what you saw; if it was not, or tracking was not yours, say so plainly and stay with "I ran the site's peak-season surge plan two years running" |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | A mis-pick rate is not a cost per shipment, and the material does not show whether cost was counted. Answer slot: if cost was counted alongside the mis-pick rate, say what was counted; if it was not, say so plainly and stay with the quote: the 40% is attached to the mis-pick rate |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Three supervisors is adjacent to twelve, with a different span and no second site shown, and the bridge keeps its limit: "I'm a senior shift manager over 3 supervisors." Any wider step is a plan said in the future tense, never a past. Answer slot: if your remit has covered supervisors beyond those three or more than one shift pattern, say which and what was yours; if it has not, say so plainly |
| F5 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" does not show whether reports were built, and the Excel half of the requirement stays at that scope: "I'd call my Excel solid." Answer slot: if you built reports in Excel, say what they tracked and who read them; if your Excel work was not reporting, say so plainly and say what it was |
| F6 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | A length-of-experience line is not a gate; it is graded on evidence. Your quotes show seven years in ops and a current leadership role, and do not show how many of the seven were leadership. Answer slot: if some of the seven years were as a supervisor or manager, say how many and in which roles; if only part of the seven was leadership, say so plainly and say what the other years were |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification stated and not inspected, so expect a probe on it. Lead with it in its own terms: "I'm green belt certified." The pack observes that your material does not say which methodology or who certified you, and does not tie the pick-path redesign to the training. Answer slot: say which belt and who certified you, in your own words |

## Persona table

Loop structure for Atlas Freight is not established: no loop source was read and research was refused, so the fallback archetype is Generic. Weights below rest on the hiring-manager relationship prior, not on this company's documented process, and are flatter than they would be with a known round.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Case / Strategist | Live problems from the role: on-time slip, cost per shipment, first thirty days | high: the hiring-manager prior puts Case first, and the JD names on-time performance, cost per shipment and four sites | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| B Skeptic | Quiet probing of the step from three supervisors to twelve, the years of leadership, the Power BI line | high: second prior for a hiring manager, and F4, F6 and F7 are the widest gaps between your quotes and the JD | Rehearse B1 until it is boring; concede the scope step in words fixed in advance; plan, not past |
| C Data-Driven Prober | Line-by-line questions on the 40 percent and the surge plan | medium: you gave one headline figure, and a figure draws the denominator question | Know what you can and cannot say about how it was counted; say plainly when you do not know |
| D Pressure | Interrupts, time-boxes, asks how much was actually you | medium: the prior for a hiring manager includes challenge, and the 40 percent is where attribution probes land | Pause, restate, hold through two follow-ups, concede specifically |
| E Conversational | Friendly opener and "what do you know about us" | medium: someone may open or close the loop casually; this is guessed, not known | Pre-script a 90-second arc; treat casual questions as scored |
| F Peer Evaluator | Seam questions between sites, credit across teams | low: no peer is known to be in the loop | Offer seam principles, not a pretend map; reciprocity framing |
| G Values / Behavioral | Unpopular truth, customer over metric | low: no values-style round is detected, so these are persona stems, not company values | Select a true occasion; honest branch if none comes to mind |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance has slipped at one of your four sites and the other three are steady. What do you need to know first, and how do you work out why?" | JD | [generic] | Say your structure aloud before you use it. Clarify first: how on-time is defined and measured, when the slip started, what changed at that site only. Objective: restore on-time without moving the problem to another site. Segment the slip by shift, lane, customer and dock, and start with the largest slice. Approach: contain first, then find the root cause. Metrics: on-time by slice, and what the slip costs. Risk: a fix that works at one site and breaks another. Challenge one premise politely, for example whether the cause sits in the site or in what arrives at it. The question needs no claim about your past, so the guidance makes none | F2 is the requirement, and the material shows no on-time work of yours, so a live problem is a likely way to test it. JD content, CASE delivery |
| A2 | "Cost per shipment has risen for two quarters. Where do you look, and in what order?" | JD | [generic] | Clarify the definition of cost per shipment first, then split it into total cost over shipment count, so you know whether the numerator rose or the denominator fell. Break the numerator into labor, transport, facility, and rework or claims, and check mix and volume effects before blaming one site. Pick the biggest mover first and say what you would test. Name the trade-off aloud: a cost cut that hurts on-time performance is not a win. The question asks about no past, so the guidance makes none | F3 is the requirement and the quote reaches mis-pick rate, not cost, so this tests the requirement as a decision. JD content, CASE delivery |
| A3 | "You take over four sites you have not worked at. What do your first thirty days look like?" | CASE | [generic] | Structure it as listen, see, measure, then act. Listen: each supervisor one on one, and each site's biggest pain in their words. See: walk each site through a full shift cycle. Measure: agree one definition per number before comparing sites. Act: one visible quick fix per site, and nothing structural until a baseline exists. Say what you will not do in thirty days: reorganize. This is a plan, never a past, so it claims nothing you have done | F1 and F4 are where the quote and the JD are furthest apart, and this is the ramp plan the B1 hold depends on |
| A4 | "We want one daily page for the four sites. What is on it?" | JD | [grounded] "never used Power BI"; "solid Excel" | Ask first who reads it and what decision it drives. Candidates for the page, in the posting's own terms: on-time performance and cost per shipment by site, plus whatever the sites count that predicts them. Same definitions across sites, one owner per number, trend over single-day figure, exceptions first. If the tool comes up, the quotes are the limit: "I'd call my Excel solid" and "I've never used Power BI." Let the design carry the answer, not the tool | F5 and F6: the reporting line has a stated gap, so a design question lets your thinking show before the tool question arrives. JD content, CASE delivery |
| A5 | "Peak volume lands in three weeks and you have the same twelve supervisors across four sites. Sketch the plan." | CASE | [generic] | Clarify first: expected volume against capacity, which sites can flex, what is fixed. Then structure: a forecast per site, a labor and shift plan, rules for one site helping another, a daily peak scorecard, escalation triggers, and a review afterwards. Say what you would decide first and why. The question asks about no past; tell your own surge story at C3, not here | F1 and F4 together: the same team stretched across four sites. Pairs with C3, the same subject told as past |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role covers four sites and twelve supervisors. Which part is the biggest step up from what you do today?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack, because this objection will arrive in some form. Hold only what the quote carries: "I'm a senior shift manager over 3 supervisors." Name the step before it is named for you: twelve supervisors across four sites is a bigger span than three, then say how you would approach it as a plan (A3). Follow-up one, "Three is not twelve, so what makes you think it scales?": return to the quote and the plan and add nothing to the past. Follow-up two, "How does your leadership change at that size?": answer as method for the future. Fix the concession in advance: "That is a step up, and here is how I would close it." Answer slot: if your remit has covered more than one site or shift pattern, say which and what was yours; if it has not, say so plainly and stay with the three supervisors | F4 is the widest gap between your quote and the JD, and F1 adds the sites. Skeptic because it probes the gap; JD because it scores a stated requirement |
| B2 | "The posting asks for 5+ years of operations leadership. How many of your seven years were in leadership roles?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Start from what the quotes carry: "7 years in warehouse and distribution ops" and your current role over 3 supervisors. Answer slot: the JD's years line makes a probe on how many of the seven were leadership likely. If some were as a supervisor or manager, say how many years and in which roles, in your own words; if only part of the seven was leadership, say so plainly and say what the other years were. Give the number as you know it, not rounded up | F7 is a length-of-experience line, not a gate, and your quotes do not say which years were leadership. The probe is cheap for an interviewer to ask |
| B3 | "The role needs reporting in Excel and Power BI. Where are you with Power BI?" | JD | [grounded] "never used Power BI"; "solid Excel" | Words: "I've never used Power BI." Say it first, in one breath, then the plan in the future tense: what you would do in the first weeks, such as starting from the reports the sites already run and learning the tool against them. On Excel, stay at "I'd call my Excel solid." Answer slot: if you built reports in Excel, say what they tracked and who read them; if your Excel work was not reporting, say so plainly and say what it was | F6 is a stated gap that wording cannot close, so the rehearsal is candor plus a plan; F5 is the Excel half |
| B4 | "Why leave a senior shift manager role for a multi-site operations role now?" | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: pick one true reason you can tie to something in the posting, such as the multi-site scope or the on-time and cost goals. Structure it as what you want more of, why this role offers it, and what you would still bring from today's work. Keep it about the pull toward the role, not the push away from the current one. If part of the true reason is pay or title, say a true version of it plainly, then the pull. If no single reason comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 and F1: a step up in scope invites a why-now probe. VAL because it tests motivation consistency, not a skill |
| B5 | "When have you put your green belt training to work?" | JD | [grounded] "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path" | An open prompt, since the JD lists Lean and Six Sigma as a plus. Start from the quote: "I'm green belt certified." Answer slot: if the pick-path redesign used the green belt's methods, say which and how, in your own words; if it did not, say so plainly, and say how you approach a process problem at a site. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F8 has no gap, but a certification invites a use-it question, and F3's quote does not say the redesign used the training |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40 percent mis-pick figure was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Tell the beats the quote states: the mis-pick rate, the 40% cut, the pick-path redesign. Answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how part of it was counted, say so plainly, which is an honest branch, and name your weakest assumption before the interviewer does. Do not explain a method you could not repeat under a second question | F3 holds your one headline figure, and a figure is where probers go first. EXP because it tests what was counted and what was yours |
| C2 | "What part of the pick-path redesign was yours, and what part was the team's?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold on the quote: "cut mis-pick rate 40% by redesigning the pick path." Answer slot: the probe is the split of credit. If others shaped or tested the redesign, say who and what, with "we" for context and "I" only for what was yours; if the work was yours throughout, say so plainly; if you do not remember the split, say that | F3: attribution honesty on the one figure you gave. EXP |
| C3 | "Walk me through how you ran the site's peak-season surge plan." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The beats the quote states: the plan, the site, two years running. Tell them in your own words. Answer slot: the JD's on-time performance line makes a probe on how the plan was tracked likely. If it was tracked against on-time performance, say how and what you saw; if it was not, or tracking was not yours, say so plainly and stay with the plan you ran. Say in your own words whether you wrote the plan or carried it out | F2 draws on this sentence; ran is a verb that can mean two things, and a prober asks which |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40 percent: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold-then-concede. Pause, restate the question, and hold through two follow-ups by returning to the quote: "cut mis-pick rate 40% by redesigning the pick path." Concede only what is true and specific. Answer slot: if others contributed to the result, say who and how; if you do not know how some part was counted, say that plainly; do not fold on the core claim just to restore harmony | F3, asked under pressure: the same attribution as C2 with the composure test added |
| D2 | "Sixty seconds: why you over someone who has already run four sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Four beats in sixty seconds. Who you are, in the quote's words: "7 years in warehouse and distribution ops." One proof, either "cut mis-pick rate 40% by redesigning the pick path" or "ran the site's peak-season surge plan two years running." The honest concession, in your own words, that the scope is wider than today's. One plan for the first thirty days (A3). Do not run the other candidate down | F1 and F4: the scope gap, in the one form that gives you sixty seconds to answer it |
| D3 | "Ten seconds: the single most relevant thing you have done for this job?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Choose one of the two quoted sentences before the interview so the choice is not made live. Say it in its own words and stop. The interruption tests economy, not content, so a short true answer beats a long reach | F3 and F2: the interviewer picks the time box, and these are the two sentences that carry your strongest work |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path" | A 90-second arc, with beats the quotes carry. Where you come from: "7 years in warehouse and distribution ops." Where you are: "currently a senior shift manager over 3 supervisors." One proof: "cut mis-pick rate 40% by redesigning the pick path." Then why this role, in your own words, chosen as in B4. Do not add a title, a team size or a site count your quotes do not carry | F1, F3 and F4 are the sentences the arc stands on. EXP because it tests whether the story hangs together |
| E2 | "What do you already know about Atlas Freight?" | CO | [generic] | Selection scaffold, because this pack could not research the company. Before the interview, spend twenty minutes on the company's own website and careers page and pick two facts you can name and say why they matter to this role. Say only what you read there; do not present a guess as knowledge. Then ask the interviewer a question about what you could not find. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The posting describes the company only as regional logistics with 800 employees, so this CO question is generic here. CO because it tests homework |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where is the seam between two sites that depend on each other, and what happens when their leads disagree?" | CASE | [generic] | Offer seam principles, not a pretend map of this company's seams: one named owner for each handoff, shared definitions of the numbers, a rule for what gets escalated and when, and one scoreboard both sites see. On disagreement: state the facts both sides accept first, then decide by the shared number, then escalate only what the number cannot settle. Show spine and tact together. The question asks about no past, so the guidance makes none | F1 puts four sites under one owner. A peer from another site is a low-weight guess, so this bank is short |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an occasion where your work and another team's were tangled; use "we" for context and "I" only for what was yours. It needs a named moment where credit could have been misassigned and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for peers; no quote of yours speaks to it, so the scaffold is the honest form |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: it needs a specific message, a named stake, and the reaction. Choose an occasion where the hard truth landed; where your material shows none, say so rather than supplying an ending. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; no values-style round is detected and no quote of yours carries this story |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: it needs the metric, the customer's need, and what you chose. Say what it cost and what you would do again. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem relevant to a role that reports on-time performance and cost per shipment; no quote of yours carries it |

## Requirement coverage

| Requirement from the posting | Questions that cover it |
|---|---|
| "Own daily terminal operations across 4 sites" | B1, A3, A5, F1 |
| "on-time performance" | A1, C3 |
| "cost-per-shipment down" | A2, C1 |
| "lead a team of 12 supervisors" | B1, A5, D2 |
| "build reporting in Excel/Power BI" | A4, B3 |
| "5+ years operations leadership required" | B2, E1 |
| "Lean/Six Sigma a plus" | B5 |

## Reverse questions

| # | Ask | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four sites today, and which site would you want fixed first?" | Uses the posting's own measure and gets you the real starting point |
| R2 | "How are the four sites' results reported today, and in which tools?" | Surfaces the Excel and Power BI reality as diligence, so the tool question stops being a defense |
| R3 | "Of the twelve supervisors, where would you expect the most coaching to be needed?" | Shows you are already thinking about the step from three to twelve |
| R4 | "What would you want to be different ninety days after I start?" | Hands you their definition of success to answer against |
| R5 | "Where do the sites most need to work together, and where does that go wrong today?" | Opens the seam conversation on your terms |
| R6 | "Is there anything in my background you would like me to speak to more directly?" | Invites the scale concern into the open where you have rehearsed it |
| R7 | For a peer: "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question; it moves the peer from evaluating you to working with you |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team of 12 supervisors | Inflated form of F4 | F4's quote at its own scope: "currently a senior shift manager over 3 supervisors." The limit is the pack's observation: the material says three, not twelve |
| Owned operations across multiple sites, or ran terminals | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material names warehouse and distribution ops, not a terminal or a second site. B1's slot stays inside your current remit |
| Improved on-time performance or cut cost per shipment | Inflated form of F2 and F3 | The quotes at their own scope: the surge plan you ran, and the 40% cut in mis-pick rate. A1 and A2 stay live problems; C3's slot asks only how the plan was tracked |
| Has Power BI experience | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never used Power BI." No slot |
| Built the sites' reporting in Excel | Inflated form of F5 | "solid Excel" at its own scope. B3's slot asks only what your Excel work was |
| Led Lean or Six Sigma projects | Inflated form of F8 | "green belt certified" at its own scope. The pack observes the material does not tie the pick-path redesign to the training; B5's slot asks how, if at all |

## Sources

Provided documents: the posting text you pasted, and your message describing your background. No tuesday-dossier.md was present, so nothing was consumed from one.

Searches sent, each refused (the host did not grant search permission):

| Query | Outcome |
|---|---|
| Atlas Freight regional logistics company values | refused |
| Atlas Freight interview process operations manager | refused |
| Atlas Freight regional logistics strategy news | refused |

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have given official value names for VAL questions and, if a values-style round were established, a values cheat sheet; none is built, and G1 and G2 stay persona stems |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have established the loop; persona weights rest on the Generic archetype and the hiring-manager prior instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have grounded the CO bank; E2 is generic and no strategy question is written |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The posting you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you meet (hiring manager, HR, panel, a site peer) → reweights every bank and may add or drop a persona
- The interviewer's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- The recruiter's note on focus areas or a pre-declared deliverable such as a presentation or an operations case → a graded-deliverable build section
- Atlas Freight's own about, values and careers pages pasted in, or search permission granted → E2 and the CO bank move from generic to grounded, and the loop and any values round get established
- Your CV, or a few more lines on your work → F2, F3, F5 and F7 move from inferred toward grounded where you answer their slots: which years were leadership, what the 40% was measured against, what your Excel work was, whether the surge plan was tracked against on-time performance
- The full text of the posting, if it is longer than what you pasted → any mid-list requirement gets its own question and coverage row
- A tuesday-dossier.md from an earlier role review → verified evidence and a named top objection in place of the ones inferred here
