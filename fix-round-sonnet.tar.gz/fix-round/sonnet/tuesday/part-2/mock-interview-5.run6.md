Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-5-denied-c03fe973/kelverton-rail_senior-partnerships_manager_interview_pack.md`.

Correction to that path: the file is named `kelverton-rail_senior-partnerships-manager_interview_pack.md`, in the same folder.

I built it from your message alone. The web searches were refused, so the pack has no verified Kelverton facts and nothing on Deepa or Ross beyond their titles. The market report also didn't reach me, so none of it is used.

- **Most predictable objection (A1):** "You haven't sold into rail specifically." This is the question to rehearse first. The pack gives you plain wording for it, and the bridge uses only what you told me. A4 covers the no-direct-quota version Ross is likely to push.
- **The 15-minute POV:** it has a timed spine and three thesis options, each with a concession you have to say aloud. It also covers how to differentiate from the report rather than recite it, since Deepa and Ross can see it too. I recommend building on "outcomes the operator can see". It fits both the recruiter's instruction to land on operators and Ross's commercial push.
- **Four-hour plan:** the pack's prep triage splits your time into four blocks and says what to skip.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Any answers below sharpen the pack, and it stands without them:
1. Can you paste the market report's three to five headline recommendations, so the POV's agree-then-diverge structure uses the real consensus?
2. Can you paste the job description, or whatever the recruiter said about the role's requirements?
3. Did the recruiter say whether the role carries a revenue number, and does "operator partnerships" mean the operators as customers, as I've read it?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday, 60 minutes, panel.
**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director), both per the recruiter's email.
**Shape of the hour:** the recruiter's words are "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it." and "Rest is Q&A, and Ross will push on commercials."
**Built from:** your message only. No JD text, no market report text, and no web research reached this pack (see Sources). Where that costs the pack something, it says so.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: every sentence about your past is one you wrote, quoted in the Provenance cell beside it, and every blank is yours to fill from what you actually did.

An answer slot is an instruction for the interview, not a question for you now. It names what an interviewer is likely to probe and gives two honest branches: say how it was, in your own words, or say plainly that there was no such step or it was not yours, then return to what your quotes carry.

| Tag | Name | What it tests in this pack |
|---|---|---|
| VAL | Behavioral / values alignment | Not used: no published values were read and no values-style round is documented |
| EXP | Work-experience deep-dive | Whether your numbers and roles survive scrutiny |
| JD | Role / JD-driven | Not used as a label on its own: no JD was supplied, so role-driven items are tagged by the recruiter's words or as generic |
| CO | Company and strategy knowledge | Homework depth and altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem set in the role |

## Prep triage (about four hours)

| Block | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 60 min | Re-read the market report with two lists: what it recommends, and what you would test or disagree with | The 15-minute POV, C1, F2 |
| 2 | 75 min | Pick one thesis, write a six-line spine (no script), say it aloud twice against a clock | The 15-minute POV, C1 |
| 3 | 60 min | Say A1, A4 and A5 aloud, then write your own answers to the defend-the-number slots in B1, B2 and D2 | A1, A4, A5, B1, B2, D2 |
| 4 | 45 min | Say the sixty-second answer to D1 aloud, then choose three reverse questions you would actually ask | D1, R1 to R3 |

Everything else is insurance: C2 to C4, bank E and bank F are worth a read-through once, not an evening.

## Fit snapshot

No JD was supplied, so the requirement column holds the recruiter's own words where she gave any, and plain prose where no text states a requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material describes an ISV channel at a payments company, not operator partnerships, with nothing inspected behind it, so the words stay at that scope: "For the last four years I ran the ISV channel at a payments company." Answer slot: the recruiter's words ask for a view on operator partnerships, so expect a probe on what carries over from the channel. If any part of how you ran it applies to operators, say which part and why, in your own words; if none does, say so plainly and stay with the channel you ran |
| F2 | "what it means for the operators themselves" — recruiter email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The work in the quote is bus and light rail network planning, and "the other side" is your phrase with no scope given, so the words stay there: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: the recruiter asks you to land on the operators themselves, so expect a probe on what from that planning work carries to them. If any part does, say which and why; if none does, or "the other side" meant something narrower, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | Your material gives influenced revenue and says outright it was not a direct quota. Words: "I haven't carried a direct quota, only influenced revenue." Answer slot: expect the figure to be probed on how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer each in your own words; if you do not know how part of it was counted, say so plainly and return to what you do know |
| F4 | Rail-sector selling experience (plain prose: no supplied text states it as a requirement; your message says the company sells scheduling software to train operating companies) | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then how you would learn it, said as a plan and never as a past. No claim to rail selling, and nothing from F2 offered as a substitute for it |

## The 15-minute POV (announced deliverable)

You were asked for this in advance, so it is graded. Nothing below is a fact about Kelverton: the pack could not read the report or research the company, so the theses are shapes you fill from the report and your own judgment.

**Grounded facts to build on**

| Source | Quoted | What it is for |
|---|---|---|
| Recruiter email | "where you'd take our operator partnerships over the next 18 months" | The brief |
| Recruiter email | "no slides needed, just talk us through it" | The format: speak, do not present |
| Recruiter email | "Please land on what it means for the operators themselves." | The required close |
| F1 | "took it from 6 partners to 40, roughly £4M of influenced revenue" | The one number you can put behind a partner-growth point, at its own scope |
| F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Your only operator-adjacent line; say what "the other side" meant |

**Spine for about 12 to 14 minutes** (leave buffer so you finish before the clock does)

| Minutes | Beat | What goes in it |
|---|---|---|
| 0 to 1 | Frame | Say there is one thesis, one thing you would not do, and that you will end on what it means for operators |
| 1 to 3 | Grounding | One point from the report you agree with: ___ (from the report, in your words) |
| 3 to 9 | Thesis | One of the three below, with its concession said aloud |
| 9 to 11 | The anti-pick | One item from the report's centre of gravity you would deliberately not do in 18 months, and why: ___ |
| 11 to 12.5 | Commercials | How you would know it is working, in numbers an operator and Ross could both read; say where your own experience stops, in the plain words from F3 |
| 12.5 to 14 | Close on operators | "For an operator, in 18 months this means ___: what they would do differently, what they would get, and what you would ask of them" |

**Three theses, each with a mandatory concession** (all three are `[generic]` shapes; a thesis that touches your past rests on the row cited)

| Thesis | Shape | Concession you must state | Fits the brief because |
|---|---|---|---|
| T1 Depth before breadth | Concentrate on a small number of operator relationships before widening | It slows coverage, and your own quote in F1 is about growing from 6 partners to 40, so say this is a choice for this market, not a habit carried over | The report's centre of gravity decides whether this is a divergence: fill that in |
| T2 Partner-led reach | Build partners around operators so operators get more from Kelverton | Your quote in F1 is an ISV channel at a payments company, so you would test with operators first whether that shape fits them | Uses what you ran at its own scope; weakest on the operators close unless you can say what operators gain |
| T3 Outcomes the operator can see | Define partnership success in operator terms first, then tie commercial measures to it | You would need operators' agreement and data to define the measures, and F3 says you have not carried a direct quota, so the commercial wiring is something you would build with Ross, said as a plan | Lands the required close and meets Ross's commercial push head on |

Recommendation: T3 as the spine, since it is the thesis the recruiter's two instructions point at together. Choose differently if the report already centres on it; the rule is to depart from the report's centre with reasons, not to recite it.

**Differentiation.** The report is equally available to both interviewers, and it is theirs, so reciting its shortlist scores as homework, not judgment. Bring one consensus item to prove you read it, then one thesis-driven divergence, then the anti-pick. Where the job includes saying no, the anti-pick is the part they will remember.

## Persona table

Weights follow the relationship priors, the recruiter's words and the loop she described (one 60-minute panel: the recruiter's email fixes it). No interviewer public footprint was read, so no signal adjustments were applied.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Skeptic | Quiet, persistent probing of the two limits you stated: rail selling and a direct quota | High. Deepa is "your future manager" per the recruiter, a hiring-manager relationship that pairs Case and Skeptic; Ross will "push on commercials" and your own message states both gaps | Rehearse the single most predictable objection (A1) until it is boring; bridges only from what you stated; a plan, not a past, for the rest |
| B Data-Driven Prober | Every number taken to its assumptions: £4M, 6 to 40 | High. "Ross will push on commercials" and your CV's headline figures are exactly what a prober reads | Know how each number was counted and say plainly when you do not; name the weakest assumption before they do |
| C Case / Strategist | The POV is discussed as a live problem; new operator scenarios | High. Deepa is the hiring manager, and the first 15 minutes are a strategy view | Clarify, then structure, then answer; think aloud; challenge one premise respectfully |
| D Pressure | Time-boxed challenges from Ross | Medium. Commercial pushing can arrive as interruption; no evidence of style beyond the recruiter's line | Pause, restate, hold through two follow-ups, concede specifically |
| E Peer Evaluator | Seam between partnerships and commercial | Low to medium. Ross is outside your future team, so a cross-functional seam question is plausible | Reciprocity first: what you bring his team; seam principles, not a pretended map |
| F Conversational | Opening or closing chat from Deepa | Low. The recruiter structured the hour; casual questions are still scored | A 90-second arc built from your quotes; never leave the reverse-question slot generic |

By member, assuming the weights above: Deepa mostly A and C, with F at the edges; Ross mostly B and D, with E.

## Question banks

### A Skeptic (5 questions; A1 is the highest-ROI rehearsal in this pack)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't sold into rail specifically. Why should we expect you to be effective with operators early on?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | Start with the plain acknowledgment: "I haven't sold into rail specifically." Then the adjacent work at its own scope: five years in transport consulting in bus and light rail network planning, and nine years in partnerships, the last four running the ISV channel. Say what "the other side" meant in your own words; an interviewer will ask. Answer slot: if any part of the bus and light rail network planning carries to the operators here, say which part and why; if none does, say so plainly and stay with the network planning. Then a plan, said as a plan: the first things you would learn about how operators buy, and from whom: ___. Hold through two follow-ups by returning to the quotes, never by adding a rail claim. Likely follow-ups: which part of that planning carries to train operators and which does not, and what you would get wrong first. Concede the limit specifically: "That part I would be learning." | F4 is the row this objection comes from, so it will be asked in some form; F2 is the adjacent evidence. JD because it scores fit to the role's market; this is the question to rehearse first |
| A2 | "Your partners were ISVs. What from the way you ran that channel carries over to operators?" | EXP | [grounded] "last 4 at a payments company running the ISV channel" | Say it at its own scope: for four years you ran the ISV channel at a payments company. Answer slot: if any part of how you ran it carries over, say which and why, in your own words; if none does, say so plainly and stay with the channel you ran. Do not tell them operators are like ISVs | F1 is the adjacent evidence for the recruiter's "operator partnerships"; a Skeptic tests whether adjacency is real |
| A3 | "Why leave payments for rail-tech, and why now?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Three beats, each a reason you actually hold: why this sector, why this company, why now. The thread already in your material is your transport consulting line; use it only as far as it goes and say what "the other side" meant. The pack has no verified Kelverton facts, so reasons about the company must come from the report or your own reading, said as yours. Do not take a reason you do not hold | Motivation consistency is what a Skeptic scores; F2 is the only part of your material that points at the sector |
| A4 | "You haven't carried a direct quota. Why should Ross trust you on commercials?" | EXP | [grounded] "never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Open with the plain acknowledgment: "I haven't carried a direct quota, only influenced revenue." Then what you did carry, at its own scope: roughly £4M of influenced revenue, with the channel going from 6 partners to 40. Concede the difference specifically: "That is a real difference, and I would rather name it than blur it." Hold through two follow-ups by returning to the quotes. Likely follow-up: what you would do the first time you are asked to commit a number; answer as a plan: ___ | F3 holds both the figure and the stated absence; the recruiter's "Ross will push on commercials" makes this the second most predictable objection |
| A5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Choose one of the two limits you stated, whichever is true for you, name it plainly, then give a ramp plan as a plan. The pack does not pick for you. Do not offer a limit you have not stated as a throwaway, and do not claim a strength to balance it | F3 and F4 are the two stated limits; a Skeptic scores honest self-assessment |

### B Data-Driven Prober (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've said roughly £4M of influenced revenue. How was that counted?" | EXP | [grounded] "roughly £4M of influenced revenue" | Say it at its own scope: "roughly £4M of influenced revenue". Answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption you would defend least, named before they ask; which part was yours. If you do not know how part of it was counted, say so plainly and return to what you do know | F3's headline figure; the recruiter's "Ross will push on commercials" makes this the likeliest first commercial probe; EXP because it tests attribution honesty |
| B2 | "At forty partners, what counted as a partner, and how much of the growth from six was yours?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | The number is partners, 6 to 40, not revenue. Answer slots: what counted as a partner; how it was counted; what it is sensitive to; the assumption you would defend least; which part of the growth was yours, in your own words. If part was not yours, say so plainly and return to what was | F1's second headline figure; the 6 to 40 phrase is the likeliest place for scope to slide, so rehearse it at its own scope |
| B3 | "What is the difference, for you, between influenced revenue and revenue you'd be accountable for?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" | Start with the quote: "I haven't carried a direct quota, only influenced revenue." Answer slot: how the two differed in how the work was counted or reviewed, in your own words; if there was no formal difference, or you do not know how the line was drawn, say so plainly and return to the quote | F3's stated limit, asked as an analytical question; EXP because it tests whether you know what your own figure means |
| B4 | "Which one number would you put in front of an operator to show a partnership is working, and what is its weakest assumption?" | CASE | [generic] | No claim about your past. Clarify what the partnership is for, pick a measure an operator would recognise and one Ross would, name the assumption you would defend least before they ask, and say what data you would need from Kelverton and the operator | Joins the recruiter's operator close to a Prober's assumption move; `[generic]` because it is a pattern for the problem, not a fact about this employer |

### C Case / Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] | The announced deliverable: build it from "The 15-minute POV" above. One thesis, its concession, the anti-pick, and the close on operators. Do not restate the report | The recruiter announced it; Deepa is your future manager; it carries the highest weight in the hour |
| C2 | "You can run three operator partnerships properly this year. Which three, and how do you choose?" | CASE | [generic] | Clarify the objective first, then your criteria, then how you would segment and decide, then the risks. Challenge one premise respectfully, such as why three. Give criteria, not operator names, unless the report names them | A Case probe on the POV's focus; `[generic]` because it needs no claim about Kelverton or your past |
| C3 | "A mid-sized operator tells you working with us feels like a vendor relationship, not a partnership. What do you do in your first ninety days?" | CASE | [generic] | A live problem and a plan. Clarify what they mean, sequence what you would learn and who you would involve, and say what you would not change yet. Make no claim about having fixed this before | Tests the recruiter's close from the operator's side; Case because it is a live scenario |
| C4 | "What would you want to know about our operators that you can't learn from outside?" | CO | [generic] | Homework depth. Use the report's own vocabulary, then ask for what it does not say. The pack has no verified Kelverton facts, so do not state any as fact beyond the report | The one CO question; it goes generic because research could not run, and the upgrade menu says what would fix that |

### D Pressure (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail and carried a number?" | EXP | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause and restate the question. Concede first, in the plain words: "I haven't sold into rail specifically, and I haven't carried a direct quota." Hold on what the quotes carry: nine years in partnerships, the last four running the ISV channel, taken from 6 partners to 40. Never say you match them. Hold through two follow-ups by returning to the quotes, conceding uncertainty specifically | F3 and F4 together, asked as a comparison; Pressure scores holding a position without folding |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Pause and restate. Answer slot: say which part was yours, in your own words; if part of the figure reflects work that was not yours, say so plainly and return to what was. Do not defend a larger share than you can explain under a second question | F3 under attribution pressure; the answer is hold-then-concede, limited to what you can back |
| D3 | "What commercial terms would you walk away from with an operator?" | CASE | [generic] | No claim about your past in the guidance. State a principle, who you would involve, and what you would offer instead. Answer slot: if you have walked away from a term before, say what and why, in your own words; if you have not, say so plainly and say how you would decide | A commercial judgment probe from Ross; `[generic]` because it presupposes nothing about this employer |

### E Peer Evaluator (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and commercial both talk to operators. Where is the seam, and what happens when we disagree?" | JD | [generic] | Reciprocity first: what you would bring Ross's team. Propose seam principles, not a map you cannot know. For disagreement, pick a time you disagreed with a colleague on another team: it needs a named stake, what you said, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Ross sits outside the team you would join; a cross-functional seam question is the collegial form of the commercial objection |
| E2 | "How do you handle credit when an operator deal spans partnerships and commercial?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: how credit was handled on that influenced figure, in your own words; if there was no rule you worked to, say so plainly and return to the figure at its own scope. Then a principle for here, said as a plan: agree up front with Ross what counts | F3's word "influenced" is where credit-sharing lives; EXP because it tests how you describe shared work |

### F Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk us through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc whose beats are the clauses you wrote: five years in transport consulting in bus and light rail network planning, then nine years in partnerships, the last four running the ISV channel at a payments company, then why this role now, in your own reason: ___. Your material does not describe the first five years of the nine in partnerships, so have a one-line account of them ready, in your own words | A friendly opener is still scored; F1 and F2 give the only sentences the arc can stand on |
| F2 | "What in the market report would you test or push back on?" | CO | [grounded] "which I've read" | The report is not in this pack, so it cannot name a point for you. Pick one point you would test and say why, in your own words; treat the casual register as scored. Do not recite the report | The report is theirs and equally available to both interviewers; departing from it with reasons scores as judgment |

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| "where you'd take our operator partnerships over the next 18 months" | C1, C2, C3, B4, A2 | C1 is the announced deliverable |
| "what it means for the operators themselves" | C1, C3, C4, A1 | The required close of the POV |
| "Ross will push on commercials" | B1, B2, B3, A4, D1, D2, D3, E2 | Highest density of questions in the pack |
| Rail-sector selling experience (F4) | A1, A5, D1 | The most predictable objection |
| Any requirement in the full JD | none, and why | No JD text was supplied; the upgrade menu says what it would add |

## Reverse questions

No interviewer profile was read, so none of these is tied to a panelist's own career path. R5 is the reciprocity question for Ross.

| # | Question | Why it lands |
|---|---|---|
| R1 | "When you say operator partnerships, which operators or kinds of relationship do you mean today, and what would you want different in 18 months?" | It shows your POV did not assume the answer, and it tells you what the recruiter's phrase covers |
| R2 | "Where does your own view of the next 18 months differ from what the strategy team's report says?" | It invites Deepa's view, not a recital, and shows you read the report as an argument |
| R3 | "How is the commercial side of this role measured, and how is partner-influenced revenue treated?" | It puts the quota gap on the table on your terms, before Ross pushes on it |
| R4 | "What would success look like at six and twelve months from the operators' side?" | It ties directly to the recruiter's instruction to land on the operators |
| R5 | "What could a new person in partnerships do in their first month that would genuinely help the commercial team?" | Reciprocity: it shows you price what you cost Ross's team, not only what you need |
| R6 | "What is a new person in this role most likely to get wrong about operators?" | It invites an honest answer, and it signals you expect to be wrong somewhere |

## Prohibited claims

Built locally from the fit snapshot before the banks were written. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I haven't sold into rail specifically." No slot |
| Has carried a direct quota or owned a revenue number | Negative the candidate stated, F3 | "I haven't carried a direct quota, only influenced revenue." No slot |
| Sold, closed or generated £4M | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says influenced revenue, not revenue sold or closed. B1 and D2 slots stay inside the figure |
| Built the ISV channel from nothing | Inflated form of F1 | F1's quote at its own scope. The material says the channel went from 6 partners to 40, not that it began at zero |
| Managed or owned operator partnerships | Inflated form of F1 | F1's quote at its own scope. The material says an ISV channel at a payments company, not operator partnerships. A2's slot stays on how the channel was run |
| Knows how train operating companies run their operations from experience | Inflated form of F2 | F2's quote at its own scope. The material says bus and light rail network planning, and "the other side" is unspecified. A1's slot stays inside the network planning |

## Sources

**Provided.** Your message: your background, the recruiter's email as quoted in it, and your note that you have read the market report. The market report itself is named by you but did not reach this pack, so nothing from it is used. No `tuesday-dossier.md` was present.

**Searches and fetches sent.** Every one was refused, so none returned a result.

| Query | Outcome |
|---|---|
| Kelverton Rail values principles | refused |
| Kelverton Rail strategy news train operating companies scheduling software | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager rail technology train operating companies job description UK | refused |

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have moved VAL questions and, only if a loop source named a values round, a values cheat sheet; both are absent |
| 2. `Kelverton Rail interview process partnerships` | skipped | Could not have moved persona weights or the loop archetype: the recruiter's email fixes one 60-minute panel, who is on it and what the first 15 minutes hold |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have moved C4 and the grounding brief; C4 stays generic and the brief is dropped |
| 4. `Deepa` and `Ross` at Kelverton Rail | unavailable | Would have moved the interviewer read, persona signal adjustments and a reverse question tied to a panelist's path; all absent |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have moved the fit snapshot's requirement rows and the JD-tagged questions; rows rest on the recruiter's words and plain prose |

## Upgrade menu

- The JD text → the fit snapshot's plain-prose row becomes a quoted `[grounded]` row, JD-tagged questions appear, and the requirement coverage table fills
- The market report's headline recommendations → the POV's consensus item, divergence and anti-pick become concrete, C4 and F2 become `[grounded]`, and a grounding brief becomes possible
- Search access, or Kelverton's published values and careers pages → VAL questions, a checked account of Kelverton's strategy, and `[generic]` rows become `[grounded]`
- The panelists' public profiles, or search access to look them up → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to a panelist's own path
- The recruiter's answer on whether the role carries a number, and what "operator partnerships" covers → A4, D1 and R3 get reshaped around the real answer; one email settles it
- Your own answers to the slots in F1 to F3 (how the £4M and the 6 to 40 were counted, what carries over from the channel and the network planning) → those rows gain quoted evidence and B1, B2 and A2 move from slots to story maps
- A `tuesday-dossier.md` from a prior role assessment → an evidence-derived objection ranking and absolute prohibited claims, in place of the ones this pack built locally
