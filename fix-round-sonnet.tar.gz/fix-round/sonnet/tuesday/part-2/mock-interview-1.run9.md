I've read the playbook and templates. Next I'm running the default research pass on Northwind Data's values and interview loop, plus Dan's public footprint, before writing the pack.
The prep pack is saved as `Northwind-Data_senior-gtm-strategy-lead_interview_pack.md`. It has 22 questions across seven personas, weighted for a peer round. The Peer Evaluator and Data-Driven Prober banks have five each. Each question has a type, provenance, answer guidance and rationale. The pack also has a fit snapshot, a requirement-coverage table, six reverse questions and a prohibited-claims list.

- **Web search was denied.** My three searches (Northwind's values, its interview process, Dan's public footprint) were all refused. So the pack rests on your notes only. Your research note is used as given, since I couldn't check its date or sources. No Northwind values or loop are claimed, and the upgrade menu lists what search would add.
- **Highest-ROI prep is D1.** Priya stated she has no classic sales-ops or quota-setting experience. Dan, as Director of Sales Strategy, sits closest to that gap. D1 has three follow-up levels and exact concession wording. D2, on partner-motion design, is second.
- **Quotes come from your notes, not a CV.** Where they stop, the guidance gives an answer slot: say what you did in your own words, or say plainly it wasn't yours or didn't exist. That applies most to how the ~$400M figure was counted (B1, B2, E1).

Say the word and I'll run a live drill as Dan on D1, the pack's highest-ROI question.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter give any guidance on what Dan will focus on, or announce a case, presentation or take-home? That would change which banks get the most weight.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer round: he and Priya would report to the same VP. Format given: one 60-minute conversation.
**Candidate:** Priya. Everything about her past below comes from the coach's notes; no CV was supplied.
**Built on this assumption:** a peer round is weighted toward the Peer Evaluator and the Data-Driven Prober, and no recruiter guidance on focus areas or deliverables has been seen.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for speaking, not a script, and it never replaces your own words.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the behavior asked about |
| EXP | Work-experience deep-dive | Whether CV claims survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Whether you can think at Northwind's altitude |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Where a question reaches past what your material says, the guidance gives you an answer slot: an instruction for the interview, with an honest branch for "that was not mine" or "that did not exist". Take either branch truthfully.

**Highest-ROI prep in this pack: D1**, the sales-ops and quota credibility question. It sits on a gap you stated yourself, it falls inside the territory of a Director of Sales Strategy, and a peer decides in that answer whether you reduce or add to his load. D2, the partner-motion question, is the runner-up.

## Fit snapshot

Requirements are the JD highlights as relayed in the coach's notes, not the full JD text. F7 is not a JD line.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | transferability | Your material says product strategy and ops, not a go-to-market role, and the words stay there: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's go-to-market line makes a probe on how products reached customers likely. If any of your work set that, say which and how you decided, in your own words; if none did, or it was not yours, say so plainly and stay with the strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [inferred] | discovery | The quote is a proposal credited with an uplift; it does not show a land, adopt, expand or renew view. Answer slot: the JD's lifecycle line makes a probe on how you found opportunities likely. If you looked across stages of a relationship, say how, in your own words; if the finding came another way, or the framing was not yours, say so plainly and stay with the proposal. The figure itself raises the defend-the-number slots, handled in B1, B2 and E1 |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The quote names the tools, with nothing inspected behind it, and a data-driven interviewer will probe it. Lead in its own terms: "I'm skilled in SQL/Tableau." Answer slot: the JD's independent-analysis line makes a probe on who did the work likely. If you ran analyses end to end, say which; if others pulled the data or built the views, say so plainly and stay with what you did |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The quote is a revenue model used in negotiations; the pack's observation is that it does not say a partner motion was designed. Words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's required wording makes a probe on how partners were engaged, beyond modeling them, likely. If the model shaped such decisions, say which and how; if it fed negotiations others ran, or there was no such design work, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap on the quote's face, but a peer who sits at the seam will ask how the consensus formed. Lead in the quote's terms: "I set annual volume targets with cross-org consensus." The slot on how it formed sits in A1 |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote already speaks to the requirement in other terms; reword it only as far as it goes: "I use AI tools daily." Answer slot: the JD's plus makes a probe on what for likely. Name the tools and tasks as you actually use them; if it is mostly personal rather than work use, say so plainly |
| F7 | Sales-ops and quota fluency alongside a Sales Strategy peer, a role-family expectation not in the JD highlights | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it was stated. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. F5's targets stay at the quote's scope and are not offered as the same thing |

## Reading the interviewer

Public professional footprint only, as relayed in the coach's notes. No talks or writing were found or read.

| Signal | Source | Implication |
|---|---|---|
| Describes himself as "relentlessly data-driven" | His profile, per the coach's notes | Every figure you give gets walked back to its inputs and assumptions; see bank B |
| Career spine in pricing and monetization roles | His profile, per the coach's notes | Case questions will most naturally land on pricing, packaging and unit economics; see C1 and C2 |
| One early-stage-startup chapter | His profile, per the coach's notes | Concrete builder stories may land well; expect some probe on pace and scrappiness. This is a reading, not a fact about him |
| Peer, same VP | The coach's notes | He is weighing what you add to or take from his work; keep reciprocity in view; see A2 and the reciprocity reverse question |

Mirror opportunities: none offered. No row of the fit snapshot carries a career path shared with his, and shared background is never a strategy.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Peer Evaluator | Seam-splitting, what you would need from him, credit across teams | High: peer round prior, and he and Priya would sit side by side under one VP | Reciprocity framing; propose seam principles, not a map you cannot know |
| B Data-Driven Prober | Inputs, denominators, validation, two follow-ups deep | High: peer prior plus his own "relentlessly data-driven" description, and the one headline figure in F2 | Know what you can and cannot say about how each number was counted; name your weakest assumption first |
| C Case / Strategist | Live problem on the two new lines, Compass or the bundling threat | Medium: pricing and monetization spine tilts toward pricing and packaging cases; a 60-minute conversation has room for one | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| D Skeptic | Quiet probing of the sales-ops gap and the partner-motion requirement | Medium: F7 and F4 are real gaps and fall near his territory | Rehearse the most predictable objection until it is boring; calibrated candor over bluffing |
| E Pressure | Time-boxed, interrupting, motive-testing | Low: not the prior for a peer, but a data-driven interviewer can press hard on a number | Pause, restate, hold through two follow-ups before conceding anything real |
| F Conversational | Opener and the AI aside | Low: sets the tone in the first minutes and the JD plus is raised casually | Pre-script a 90-second arc; treat casual questions as scored |
| G Values / Behavioral | Scenario probes | Low: no values-style round is established; the user described a single conversation with Dan and named no such round | Pick stories only where your material carries one; say so plainly where it does not |

Loop: one 60-minute session run by Dan, per the user's own description. Persona weights rest on that and on the peer relationship, not on an archetype.

## Question banks

### A. Peer Evaluator (weight: high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Ask what his team owns today before proposing anything. Offer seam principles, not a map you cannot know: who owns the number, who owns the motion, and how a disagreement reaches the shared VP with both views stated. For the past, tell only what the quote states: you set annual volume targets, with cross-org consensus. Answer slot: the JD's cross-functional line makes a probe on a disagreement during that consensus likely. If there was one, say what it was and what you did, in your own words; if consensus formed without one, or resolving it was not yours, say so plainly and stay with the targets | F5 is the cross-functional evidence and the seam is where a peer tests it. JD because it scores the influence requirement, with peer delivery |
| A2 | "What could you do in your first month that would actually help my team?" | JD | [generic] | Answer in reciprocity terms: what you would bring his team, then what you would need from it. Propose a concrete first artifact tied to the JD's own wording, such as a whitespace view across land, adopt, expand and renew for the two lines, offered as something to shape together. The question needs no claim about your past, so the guidance makes none | A peer is pricing the load you add; the rubric names this reciprocity question for peer rounds. JD because it tests the two-lines and whitespace requirements, F1 and F2, in collaborative form |
| A3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Tell it at the quote's scope: you proposed the change, and it was credited with the uplift. Answer slot: the question makes a probe on who else touched it likely. If others built, shipped or measured it, say what each did and what was yours; if you do not know how the credit was assigned, say so plainly and stay with the proposal. Say what you do, not what it proves about you | F2's figure is the one place credit is visibly contestable, and credit-sharing is a standard peer probe. VAL because it scores behavior toward collaborators rather than a skill |
| A4 | "Sales tells you the packaging for one of your two new lines is too complex to sell. How do we work through that together?" | CASE | [generic] | Structure it aloud. Clarify what is meant by complex: win and loss notes, cycle length, attach behavior. Separate selling friction from a packaging flaw, agree what data would settle it and who pulls it, then name a decision rule and an owner. Invite his view of the sales side before concluding. The question asks about no past | A collaboration case on pricing and packaging, his native ground, framed at the seam; covers R1 in collaborative form. CASE because it is a live problem with no claim about the candidate |
| A5 | "A partner-sourced deal and a direct deal land on the same account. Whose number does it count against?" | CASE | [generic] | Ask first what rules exist today for partner and direct overlap. Then principles: the customer outcome first, no incentive that rewards a fight, a clear tie-break that sellers can see, and a decision owned jointly with his team. Say what data you would want on how often it happens. Nothing here claims past work | The JD's partner-motion requirement meets his sales-strategy turf at exactly this seam. CASE, since it tests reasoning; JD in content, as the second place F4's requirement is tested |

### B. Data-Driven Prober (weight: high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the quote says: you proposed the change, and it was credited with a ~$400M ARR uplift. Then the four slots, each in your own words. How it was counted: say what you know, and if you do not know, say so plainly. What it is sensitive to: name it if you know. The assumption you would defend least: name it before he asks. Which part was yours: the proposal, and anything beyond it only as you can stand behind it. Rehearse the plain "I don't know how that was counted" branch until it sounds ordinary | F2 holds the pack's only headline figure, and a self-described data-driven interviewer will go two levels deep on it. EXP because it scores attribution and honesty about the number |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot: name that assumption in your own words before he asks, and say what would change the number if it were wrong. If you do not know which assumption was weakest, or how the figure was built, say so plainly and return to what the quote carries: you proposed the change, and it was credited with the uplift | The follow-up to B1, rehearsed on its own because it is where the weakest-assumption move is made or missed. EXP, same row, F2 |
| B3 | "Walk me through the partner-level revenue model you built, what went into it, and how it was used in the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Describe it in the quote's terms: a partner-level revenue model, used in carrier negotiations. Answer slot: the JD's independent-analysis line makes a probe on which parts you built yourself, and in which tools, likely. Say which parts were yours; if others built pieces, or it was assembled another way, say so plainly and stay with what you built | F4 is the other concrete artifact and the likeliest place to be probed for hands-on ownership. EXP because it tests what was actually the candidate's |
| B4 | "Tell me about an analysis you ran end to end in SQL or Tableau, from the question to the recommendation." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold, since the quote names tools and no analysis. Pick one analysis with a question you framed, data you pulled or defined yourself, a conclusion, and a decision someone made from it. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run one. Offer to walk through it step by step | The JD's independent-analysis requirement is the one a data-driven interviewer scores hardest; F3 has nothing inspected behind it. JD because it tests the stated skill, open prompt delivery |
| B5 | "Pick the metrics you'd use to tell whether a new product is landing but not being adopted. What does the data need to look like?" | CASE | [generic] | Name the stages first, land, adopt, expand and renew, since they are the JD's own words. Choose one leading indicator per stage, state the denominator and cohort for each, and say what would make it misleading. State your weakest assumption aloud. A scaffold for a live problem; it asks about no past | The JD's whitespace line, F2's requirement, turned into a measurement problem his data-driven lens prefers. CASE because it is a live problem; Prober delivery |

### C. Case / Strategist (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is an AI copilot. How would you price it: add-on, bundle, or usage-based? What do you need to know first?" | CO | [grounded] the coach's research note: an AI copilot launch ('Compass') is a stated priority | Clarify before structuring: who buys it, what value it is measured on, what it costs to serve, and what the larger vendors bundle. State a hypothesis early, then test it against the profitability priority in the note. Challenge one premise respectfully, for instance whether the pricing question precedes a packaging one. Use only what the note states about Northwind; say what you would verify | His pricing and monetization spine makes pricing the most natural case. CO because it needs Northwind's stated priorities; CASE in delivery |
| C2 | "A much larger platform vendor starts bundling a competing capability into its suite at no extra charge. What does that do to your GTM plan for an emerging product?" | CO | [grounded] the coach's research note: bundling by a much larger platform vendor is the main competitive threat | Hypothesis first: where bundling hurts most and where it hurts least. Then segments, positioning and partner routes that change the plan, and what win and loss data you would want before committing. Tie it to the enterprise expansion priority in the note. Name what you cannot know from outside the company | The one competitive frame the note gives, and the likeliest strategic question for an emerging product. CO because it needs the company's competitive context |
| C3 | "You have two new product lines and one launch team. How do you decide where the first quarter goes?" | CASE | [grounded] the coach's research note: enterprise expansion is a stated priority | Objective first, then segmentation of accounts and stages, decision criteria, what data would settle a close call, and risks. Link the choice to enterprise expansion and profitability from the note. Think aloud and say what you would ask Dan's team for | R1 is the headline responsibility and this is its live form. CASE because it is a live problem on the actual role |

### D. Skeptic (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your background doesn't include classic sales-ops or quota-setting. How do you earn credibility with the sales organization, and with me?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | The deepest rehearsal in the pack. Pause, then say the limit first and plainly: "I don't have classic sales-ops or quota-setting experience." Then what the quote carries: "I set annual volume targets with cross-org consensus." Follow-up one, a volume target is basically a quota: hold at the quote's scope and keep the limit stated. Answer slot: if you see differences between those targets and a seller's quota, say what they are in your own words; if you do not know how they compare, say so plainly. Follow-up two, what would you get wrong first: answer as a plan, the one thing you would learn first and from whom, never as a past. Follow-up three, why trust you with the sales-facing half: concede specifically, "Fair. The sales-facing mechanics are what I'd learn from your team, and the targets work is where I'd start from." Never fold into claiming sales-ops depth | F7 is the stated gap and the most predictable objection to this candidate, closest to a Sales Strategy director's own work. JD because it scores fit to the role's seam; Skeptic delivery |
| D2 | "The role calls for partner-motion design experience. What in your background speaks to that?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Lead with the quote at its scope: "I built a partner-level revenue model that was used in carrier negotiations." Say plainly that this is a model, and hold that line. Answer slot: if the model shaped decisions about how partners were engaged, say which and how you decided; if it fed negotiations others ran, or there was no such design work, say so plainly and stay with the model. Then say how you would approach a first partner motion, as a plan | F4 is a hard JD requirement with adjacent evidence only, so the objection arrives in some form. JD because it scores the stated requirement; the second-deepest rehearsal |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Choose honestly. One answer your material already supports: "I don't have classic sales-ops or quota-setting experience." Add the plan for closing it, said as a plan. If another requirement feels weaker to you, name it in your own words rather than the one that sounds safest. Do not choose a weakness you do not believe | A direct Skeptic stem that tests calibration. JD because it asks about the listed requirements; it pairs with D1 and F7 |

### E. Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate the question, then hold at the quote: you proposed the change, and it was credited with a ~$400M ARR uplift. Hold through two follow-ups by returning to it, never by adding to it. Answer slot: say what others did and which part was yours, in your own words; if you do not know how the credit was split, say so plainly. Concede that specifically, and do not fold on the core claim | F2 again, delivered as a stress test of attribution. EXP because it scores what was the candidate's; Pressure because of the delivery |
| E2 | "Sixty seconds: why you, rather than someone who has run a sales organization's planning?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops", "built a partner-level revenue model used in carrier negotiations", "set annual volume targets with cross-org consensus", "skilled in SQL/Tableau" | Pause first. In sixty seconds, three facts at the quotes' own scope, with no claim about what they prove: nine years in product strategy and ops at a large consumer-tech company, a partner-level revenue model used in carrier negotiations, and annual volume targets set with cross-org consensus. Add "skilled in SQL/Tableau" if time allows. Close by conceding the gap plainly, and let him draw the inference | F1, F3, F4 and F5 are the pool; F7 is the concession. JD because it scores fit; Pressure through the time box |

### F. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc in three beats: two years in strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company, then why this role. The last beat is yours to write: say, in your own words, what draws you to B2B data infrastructure and to this seat now. Keep the first two beats to what the quotes state | The biography opener is scored for economy and motivation consistency. F1 and F7 are what he will be reading against. EXP because it tests a CV account, in a casual register |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Quote at scope: "I use AI tools daily." Answer slot: the JD's AI plus, and Compass in the note, make a probe on what for likely. Name the tools and one task as you actually use them; if most of it is personal rather than work use, say so plainly. Treat the casual register as scored | F6 is the AI requirement, and Compass is a stated priority. JD because the posting flags AI as a plus; asked casually |

### G. Values / Behavioral (weight: low, 2 questions)

No values-style round is established, so these draw on the standard persona stems rather than published Northwind values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, the evidence you brought, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use "we" for context and "I" for what you did | A standard stem; with a data-driven peer it is most likely to arrive as data contradicting a view. VAL because it scores behavior. Generic because none of your quoted sentences carries this story |
| G2 | "When did you put a customer, or a partner, ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the external party's interest and an internal number pulled apart, name what you did, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard stem, and the partner reading connects to the JD's partner requirement. VAL; generic because no quote carries this story |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "own GTM strategy for two new product lines" | A2, A4, C1, C3, D3, E2 |
| "identify whitespace across land/adopt/expand/renew" | A2, B5, C3 |
| "run independent analysis in SQL and Tableau" | B3, B4, E2 |
| "partner-motion design experience required" | A5, B3, D2 |
| "strong cross-functional influence" | A1, A3, E2 |
| "AI experience a plus" | C1, F2 |
| Sales-ops and quota fluency (not in the JD highlights) | D1, D3 |
| The ~$400M figure | A3, B1, B2, E1 |
| Northwind's stated priorities and competitive threat (coach's note) | C1, C2, C3 |

Total: 22 questions.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your background runs through pricing and monetization. How do pricing decisions for a new product line get made between your team and Emerging Products today, and where would you want that to change?" | Tied to his own career path as his profile describes it; it asks him to describe the seam he lives in, which turns the interview into a peer conversation |
| R2 | "You've also spent time at an early-stage company. What from that do you still use here, and what did you have to change?" | Tied to the startup chapter in his profile; it signals you read his path, not just the company's |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it shows you are pricing what you add to his load |
| R4 | "Which metric do you most wish the two new lines were already instrumented against?" | Fits his data-driven self-description and surfaces where the first analytical work lands |
| R5 | "How is the Compass launch changing the way Sales Strategy plans, and what is still unresolved?" | Uses the stated priority from the note and asks him for the part only he can see |
| R6 | "Where do you see bundling pressure showing up in the pipeline today, if at all?" | Connects the stated competitive threat to his daily view and invites candor |

## Prohibited claims

Built locally from the fit snapshot. The pack does not coach these, and no slot, hold or bridge asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has quota-setting or sales-ops experience | Negative the candidate stated, F7 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." No slot |
| Owned or designed a partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a revenue model used in negotiations, not a motion. D2's slot stays inside the model |
| Drove, owned or delivered the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: you proposed the change, and it was credited with the uplift. B1, B2 and E1 slots ask only about counting, sensitivity, the weakest assumption and your part |
| Owned go-to-market for a product | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops. A2's and C3's cases make no claim about your past |
| Built or led AI products or an AI go-to-market | Inflated form of F6 | F6's quote at its own scope: "I use AI tools daily." F2's slot asks only what you use them for |
| Set the annual volume targets alone, or as sales quotas | Inflated form of F5 | F5's quote with its consensus intact. The pack's observation: the material says volume targets, not seller quotas |

## Sources

**Provided:** the coach's notes, covering the candidate's summary, the JD highlights, the interviewer's profile summary and a research note. The research note's three stated priorities (enterprise expansion, the Compass AI copilot launch, reaching profitability) and its competitive threat (bundling by a much larger platform vendor) are used as given. Its date and sources were not supplied and were not checked, because the search calls below were refused.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Query | Outcome |
|---|---|
| Northwind Data company values principles | refused |
| Northwind Data interview process GTM strategy role | refused |
| Dan Kovac Director of Sales Strategy Northwind Data | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Would have fed a values cheat sheet; no values round is established, so the pack carries G1 and G2 on standard stems |
| 2. `Northwind Data interview process GTM strategy` | unavailable | Would have confirmed the loop and persona weights; they rest on the user's description of one 60-minute conversation instead |
| 3. `Northwind Data strategy` / recent news | skipped | The coach's research note already supplies the priorities and competitive threat that feed C1 to C3 and R5 to R6 |
| 4. `Dan Kovac Northwind Data` | unavailable | Would have fed the interviewer read and a footprint-based reverse question; the read rests on the profile summary alone |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights supplied fix the fit snapshot and the JD-tagged questions |

No dossier was present.

## Upgrade menu

- Search permission (not granted this session) → Northwind's published values and loop, and Dan's public talks or writing, which would reweight the personas and sharpen R1 and R2; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a grounding brief on strategy and competitors
- The full JD text → F1 to F6 rest on highlights rather than the JD's own lines, and any duty not in the highlights, such as forecasting or quota input, would become visible
- Priya's CV, or her own words on each line → the coach's-notes quotes become her own sentences, and scaffold rows such as B4 may become story-mapped
- Priya's answers to the slots, stated outside a drill → B1, B2, E1 (how the ~$400M was counted and what was hers), D2 and F4 (partner decisions the model shaped), B3 and F3 (what she built in SQL or Tableau), F1 (go-to-market decisions)
- The recruiter's guidance on Dan's focus areas, or any pre-declared deliverable → coverage beyond round-type priors, and a build section if a deliverable was announced
- The date and sources of the research note → confirms the CO bank (C1 to C3) is current
- A tuesday-dossier.md from an earlier underwriting pass → verified evidence, binding strategies per weak area, and a named top objection
