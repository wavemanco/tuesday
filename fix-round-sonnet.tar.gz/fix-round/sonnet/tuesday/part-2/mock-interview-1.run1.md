Both web searches were refused, so I'm building the pack from your inputs alone and labeling the research-dependent parts generic. Writing it now.
The full prep pack is built. It has 22 questions across seven personas, and Dan's seat as a peer under the same VP shapes the weighting. The pack covers:

- a fit snapshot of Priya's evidence against each JD requirement
- a persona table showing how the weights were set
- the question banks, with a requirement-coverage table
- six reverse questions
- a prohibited-claims list
- sources, and an upgrade menu

**Web search was refused.** I couldn't read Northwind's published values or Dan's public footprint. The interviewer read rests only on your profile summary. The values-themed questions are marked generic, and there's no values cheat sheet. The case questions about Compass and bundling rest on your research note.

**Dan's likely line.** The top-weighted personas are Peer Evaluator and Data-Driven Prober, because of his "relentlessly data-driven" self-description. His pricing background tilts the case questions toward packaging and unit economics.

**Highest-ROI prep (C1).** This is the "no classic sales-ops or quota-setting" objection, with follow-up levels written out.

**Evidence base.** I could only quote your notes, not Priya's CV or the full JD. So every candidate-evidence cell is second-hand, and where the notes didn't carry a detail the guidance gives answer slots instead of invented specifics. Her CV in her own wording would firm these up.

Saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-1-denied-e91ed757/Northwind-Data_senior-gtm-strategy-lead_interview_pack.md`

Say the word and I'll play Dan as the Skeptic on C1, the pack's highest-ROI question, with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

Candidate: Priya. Interviewer: Dan Kovac, Director of Sales Strategy — a peer (both report to the same VP). Format: one 60-minute conversation, session mode.

Highest-ROI prep in this pack: C1, the "no classic sales-ops or quota-setting" objection. It will be asked in some form by a Sales Strategy peer, and it is rehearsed to the deepest follow-up level.

## How to use this pack

Personas say how a question arrives. Types say what is being scored. Guidance is scaffolding, not a script: every claim about your past rests on a sentence quoted in that row's Provenance cell, and anywhere the material does not carry a detail, the guidance is an answer slot. An answer slot is an instruction for the interview, not a question for now: answer whichever branch is true, in your own words.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows how you work, not generic virtue |
| EXP | Work-experience deep-dive | Whether the claims survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Whether you can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the real role |

Provenance labels: `[grounded]` traces to something you provided; `[inferred]` is a named derivation; `[generic]` is a role-family pattern with no claim about this candidate or this employer.

## The fit snapshot

The role requirements are quoted from the JD highlights in the request. The evidence column holds only the candidate notes as given, so every cell is second-hand until her own CV wording is added.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market, and the words stay at that scope: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two-product-lines line makes a probe on whether any of that work took a product to market likely. If any did, say which decisions were yours, in your own words; if none did, or none were yours, say so plainly and stay with the strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | The quote touches recurring-revenue growth; your material does not show whether it reached any stage of a customer lifecycle. Answer slot: the JD's land, adopt, expand, renew line makes a probe on which stage the change moved likely. If it worked on one of those stages, say which and what you know about the effect, in your own words; if it did not map to any, or the lifecycle framing was not used, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | low | [inferred] | discovery | A skill statement is not an analysis, and your material does not show one you ran yourself. Answer slot: the JD's independent-analysis line makes a probe on a piece of analysis done end to end likely. If there is one, name the question and what was done with the answer, in your own words; if none was yours alone, or it was done in other tools, say so plainly and say what you would pull first in this role |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model at partner level, used in negotiations; it does not say a partner motion was designed, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the word required makes a probe on motion design certain. If any part of how the partnership worked was yours to design, say which and how you decided; if the model informed negotiations someone else ran, or nothing was designed, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Lead with it as stated: "I set annual volume targets with cross-org consensus." A named record beats an adjective. Expect a follow-up on the consensus itself; A4 is the rehearsal |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote reaches the requirement as use of tools, and the words stay there: "I use AI tools daily." It says nothing about building or shipping AI, and the pack writes nothing past it. Compass is one of the three priorities in your research note, so a casual probe is likely; E2 is the rehearsal |
| F7 | Fluency in sales-ops mechanics such as quota-setting, which a Sales Strategy peer works in — the pack's own reading of a peer's world, not a JD line | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the candidate has said so. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. The pack's own observation: your material holds this negative and the sentence about annual volume targets (F5) side by side, and an interviewer may put them together; the pack does not draw the line between them for you |

## Reading the interviewer

Everything below rests on the profile summary in your request. Search for his public footprint was refused, so no talks or writing were read.

| Item | What it says | Provenance |
|---|---|---|
| Self-description | He describes himself as "relentlessly data-driven" | [grounded] |
| Career spine | Pricing and monetization roles, with one early-stage-startup chapter | [grounded] |
| Relationship | A peer under the same VP, so the conversation prices what you would cost and add to his work | [grounded] |
| Implication 1 | Expect every number you give to be probed down to its assumptions; B1 and F1 are the rehearsals | [inferred] derived from the self-description and the data-driven prober signal |
| Implication 2 | Case questions likely lean toward packaging, pricing and unit economics, his native vocabulary; D1 is built that way | [inferred] derived from the career spine |
| Implication 3 | The startup chapter makes a "can you operate without big-company infrastructure" probe plausible; C3 is the rehearsal. Your material carries no builder story, so none is coached | [inferred] derived from the startup chapter and the fit snapshot |
| Mirror opportunity | Shared vocabulary only: his career is in pricing and monetization, and F4's sentence is "built a partner-level revenue model used in carrier negotiations". Use the sentence at its own scope. Do not call it pricing work | [inferred] derived from the career spine and F4 |

## Persona table

Weights were set in three passes: the peer relationship prior, the interviewer signals above, then the loop. The loop is one 60-minute conversation with one interviewer, established by your own description of the round; you named no values round, so none is detected and no values cheat sheet is included.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (a method, not a claim) | Bank |
|---|---|---|---|---|
| Peer Evaluator | Seam-splitting, what you would need from him, credit across teams, collegial disagreement | High: the relationship prior for a peer, and both of you report to the same VP | Reciprocity framing; propose seam principles instead of pretending to know the seam; disagreement stories with spine and tact | A, 5 questions |
| Data-Driven Prober | Inputs, definitions, validation; follow-ups two levels deep | High: the peer prior, raised by the "relentlessly data-driven" self-description | Know what you can and cannot say about how each figure was counted; name the weakest assumption first; offer a walk-through of an analysis you ran | B, 5 questions |
| Skeptic | Quiet, persistent probing of the gaps | Medium: F7 and F1 are the thin rows, and the startup chapter adds a pace probe | Rehearse the single most predictable objection until it is boring; bridge only from what you stated; ramp plan | C, 3 questions |
| Case/Strategist | Live problems from the role | Medium: a peer is not scoring a hire's roadmap, but the pricing spine tilts cases toward packaging and unit economics | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | D, 3 questions |
| Conversational | Chatty opener; the reverse-question slot | Low to medium: a 60-minute conversation opens casually and the AI plus gets asked casually | A pre-built 90-second arc; treat casual questions as scored | E, 2 questions |
| Pressure | Time-boxing and "how much was you" | Low: nothing in the profile signals stress style | Pause, restate, hold through two follow-ups, concede specifically | F, 2 questions |
| Values/Behavioral | Scenario probes | Low: no dedicated values round is established, and published values could not be researched | Selection criteria ending in the honest branch | G, 2 questions |

## Question banks

### A. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where is the seam between Sales Strategy and what you'd own, and what happens when we disagree?" | CASE | [generic] | Propose seam principles instead of claiming to know the seam: who owns which decision, what each side sees before a number goes to the VP, how a disagreement gets escalated. Frame each as a proposal you would test with him, and add what each team could stop re-deriving. Check one premise aloud: where the line sits today. The question needs no claim about your past, so the guidance makes none | The peer's native question; F7's limit makes it sharper. CASE because it is a live problem about the seam, with JD content from F5's requirement |
| A2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold: pick a time work spanned teams, with a named contribution that was not yours, what you said about whose work it was, and the relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I set annual volume targets with cross-org consensus", in those words, or say how you would handle it | The persona stem for a peer, probing partnership fit. VAL because it scores behavior, not a CV line; F5 is the nearest evidence and carries no credit story |
| A3 | "What would you need from me in your first thirty days, and what could you give my team in return?" | JD | [generic] | Ask for the access and definitions you would need, and say what you would offer as a plan, such as sharing the whitespace analysis as you build it. Offer only plans, not skills: the guidance names no capability of yours. Close by asking what would help his team most | The reciprocity half of the peer prior; the JD's cross-functional line (F5) is the raising source. JD because it scores the stated collaboration requirement |
| A4 | "Walk me through how you got cross-org consensus on the annual volume targets." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the annual volume targets, that you set them, and the cross-org consensus are the beats the quote states; tell them in your own words. Answer slot: the JD's cross-functional influence line makes a probe on where the orgs differed likely. If they did, say what happened and which part was yours; if consensus came without disagreement, or the process was not yours, say so plainly and stay with the sentence | F5 is the evidence for the influence requirement and the likeliest place a peer probes. EXP because it tests what was actually the candidate's |
| A5 | "Tell me about a time you disagreed with a peer team and how it ended." | VAL | [generic] | Selection scaffold: pick a time with a real stake, where you held your position and stayed courteous, and the working relationship survived. Say what you would do again and what you would change. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The peer stem on disagreement; the persona scores spine and tact together. VAL because it is behavioral; [generic] because no quoted sentence carries a disagreement story |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say it as stated: "I proposed a store-surface change credited with a ~$400M ARR uplift." Then four answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before he asks; which part was yours. If you do not know how it was counted, say so plainly. Never explain a method you cannot repeat under a second question | F2's figure is the magnet for a self-described data-driven interviewer. EXP because it tests attribution and counting |
| B2 | "The JD requires partner-motion design. Walk me through the partner-level revenue model on your CV and how it was used in the carrier negotiations." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: that you built a revenue model, at partner level, and that it was used in carrier negotiations are the beats the quote states. Answer slot: the JD's independent-analysis line makes a probe on which parts of the model were yours likely; say which you built and which were given to you. A second slot on motion design: if any part of how the partnership worked was yours to design, say which; if not, say so plainly and stay with the model | F4 is the only evidence near the hard partner-motion requirement. JD because the requirement is the raising source, EXP in delivery |
| B3 | "Tell me about an analysis you ran yourself, start to finish. What was the question, and what did you do with the answer?" | EXP | [inferred] "skilled in SQL/Tableau" | Selection scaffold, built as a clarify note because F3 is low confidence: pick one where you wrote the query or built the view yourself, and name the question, the data and the decision. Offer to walk him through it end to end. If none comes to mind, say so plainly, then say how you would approach the first analysis in this role | The JD's independent-analysis line, from a prober. EXP because it tests what was actually done; [inferred] because F3's band forbids asserting the skill |
| B4 | "How would you size whitespace across land, adopt, expand and renew for one of the new lines, and how would you know your first metric was wrong?" | CASE | [generic] | Clarify first: which line, which segment, what decision the sizing feeds. Pick a metric per lifecycle stage, state the assumption you would defend least, and name the check that would falsify it. Say that out loud before he asks. The guidance makes no claim about your past | F2's requirement as a live problem, built for a data-driven interviewer. CASE because it asks for structure on a new problem |
| B5 | "Our data will sometimes disagree with instinct. Tell me about a time evidence changed your recommendation." | VAL | [grounded] | Selection scaffold: pick a time your position moved, name what you recommended before and after and what moved you. If none comes to mind, say so plainly, then say how you decide when the data and your instinct disagree | His self-description is the raising source. VAL because it scores behavior toward evidence |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting in your background, and this role sits right beside my team. How does that work?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | The highest-ROI rehearsal in this pack. Pause, restate the question. Level 1, limit named before he asks for it: "I haven't had classic sales-ops or quota-setting experience." Then what the quotes carry, at their scope: "I set annual volume targets with cross-org consensus" and "I built a partner-level revenue model used in carrier negotiations". Do not call either of them quota-setting or sales ops. Then a plan, not a past: ask how his team's planning works and where your lines depend on it. Follow-up 1, "volume targets sound similar": hold the acknowledgment, say what the work was in the quote's words, and ask what his team counts as quota-setting before comparing; draw a comparison only from what the work actually was. Follow-up 2, "so why partner with my team": concede the limit specifically and name it as the first thing you would close with him; do not fold on the sentences you can stand behind. Follow-up 3, "what if the VP expects quota-adjacent work": say what you would ask the VP and him for, as a plan | The objection born from F7, the fit snapshot's biggest gap and a peer's most natural worry. JD because it scores the fit to the listed job; the deepest hold structure because it is aimed where the material is thinnest |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | Pick the honest answer. The pack's observation is that your material is thinnest on F7 and carries only adjacent work for F1 and F4. Name one plainly, using "I haven't had classic sales-ops or quota-setting experience" if it is that one, and follow with a ramp plan said as a plan, never as a past | The persona stem for the Skeptic; F7, F1 and F4 are the candidate rows. JD because it scores self-assessment against the listed requirements |
| C3 | "You've spent nine years at a large consumer-tech company. What makes you think this works at Northwind?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Your material carries no B2B or early-stage quote, so none is coached. Name one difference you expect between your last setting and this one, and how you would learn it in thirty days, as a plan. If you have worked in a B2B or small-team setting, say what and what part was yours; if not, say so plainly and stay with the strategy and ops work in the sentence | His startup chapter makes a pace and infrastructure probe plausible (F1's evidence is the large-company history). JD because it scores fit to this role's setting, with a motivation edge |

### D. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Suppose Compass has to be packaged and priced for enterprise expansion while the company is also pushing toward profitability. Where do you start?" | CASE | [grounded] | Clarify first, including which of the two new lines Compass is, if either, since the material does not say. Then objective, buyer segments, packaging and pricing options, how each option shows up in enterprise expansion and in margin, metrics, risks. Challenge one premise respectfully. Use the company's three priorities from your research note as the frame. The guidance makes no claim about your past | The research note supplies the priorities, and his pricing spine tilts the case. CASE because it is a live problem; F6's requirement makes AI a fair subject |
| D2 | "A much larger platform vendor starts bundling a competing capability into its suite. What changes in the GTM for one of the new lines?" | CO | [grounded] | Clarify which line and which segment is exposed. Walk the lifecycle: what changes at land, adopt, expand and renew, which motion gets stronger, which gets weaker, and what you would measure first. Use the bundling threat from your research note as the premise and check it aloud. The guidance makes no claim about your past | The research note names bundling as the main competitive threat. CO because it tests altitude; CASE in delivery |
| D3 | "Take one of the two new lines. Where would you look for whitespace across land, adopt, expand and renew, and what would you deliberately not chase?" | CASE | [generic] | Clarify the line and the segment, then one hypothesis per lifecycle stage, then the ranking logic, with profitability as a stated priority from your research note. The "not chase" half scores prioritization: say what you would ignore and why. The guidance makes no claim about your past | The JD's whitespace line (F2) as a live problem. CASE because it asks for structure and prioritization |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey, from consulting to the last nine years to here." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc on the beats the sentence states: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. The third beat is your own reason for this role now: say it in your own words, tied to one of the three priorities in your research note only if that is true | The opening biography question that every conversational interviewer asks; F1's history is the arc. EXP because it tests whether the story hangs together |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it as stated: "I use AI tools daily." Answer slot: a casual probe on which tools and what for is likely, given the JD's AI plus and Compass. If you use them on work outputs, say which and how, in your own words; if not for work, say so plainly. The pack does not name tools or uses, and nothing here claims you build or ship AI | F6's plus, asked casually. The casual register is still scored; JD because it scores a listed plus |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ARR result — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate. Hold the sentence as stated, through two follow-ups: "I proposed a store-surface change credited with a ~$400M ARR uplift." Concede specifically, never by folding: answer slot, if others contributed beyond the proposal, say so plainly and say what you did; if you do not know how the credit was assigned, say that. Return to the sentence each time | The persona stem for attribution under pressure on F2's headline figure. EXP because it scores attribution honesty |
| F2 | "Sixty seconds: why you over someone who has actually run quota?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience" | Hold-then-concede in sixty seconds. Concede first and plainly: "I haven't had classic sales-ops or quota-setting experience." Then describe what you did at the quotes' scope: "I built a partner-level revenue model used in carrier negotiations" and "I set annual volume targets with cross-org consensus", and let him draw the inference; asserting why it matters is the claim that gets tested | The persona stem for a time-boxed motive question, aimed at F7. JD because it scores fit to the listed job |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship in which the truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The persona stem for a behavioral probe. Low weight because no values round is established; [generic] because no quoted sentence carries the story |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the metric and the customer pulled apart, name what you chose and what it cost. If none comes to mind, say so plainly, then say how you would weigh them | The persona stem; published values were not researched, so this is a pattern only. VAL because it scores a decision |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | D1, D2, D3, C3 |
| identify whitespace across land/adopt/expand/renew | B4, D3 |
| run independent analysis in SQL and Tableau | B3, B2 |
| partner-motion design experience required | B2 |
| strong cross-functional influence | A1, A2, A3, A4, A5 |
| AI experience a plus | E2, D1 |
| Sales-ops fluency, the pack's own reading rather than a JD line | C1, C2, F2 |

Only the highlights of the JD were supplied; any further JD requirement is uncovered until the full text is added.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent your career in pricing and monetization, with one early-stage chapter. What did that chapter change about how you work now?" | Ties to his own path, so it turns an interrogation into a peer conversation and shows you researched him |
| R2 | "What could a new person on my side do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it answers his worry about added load |
| R3 | "Where is the line between Sales Strategy and the emerging-products GTM today, and where is it blurry?" | A peer-level question about the seam; it shows you plan to work the seam |
| R4 | "How does the Compass launch change what your team needs from this role?" | Connects to a stated priority and to his daily work |
| R5 | "Which two metrics would tell you in the first six months that the GTM for the new lines is working?" | Speaks his language as a self-described data-driven interviewer |
| R6 | "How do you and the VP settle it when Sales Strategy and Emerging Products disagree on a plan?" | Shows you are already thinking about the disagreement style, which is what a peer is scoring |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or designed the partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a revenue model used in negotiations, not a partner motion. B2's slots stay inside the model |
| Led or conducted the carrier negotiations | Inflated form of F4 | The quote says the model was used in carrier negotiations; it does not say who negotiated, and the pack does not say either |
| Did pricing work | Inflated form of F4 | F4's quote at its own scope; the shared vocabulary with his pricing career is a mirror opportunity and never a claim |
| Drove or delivered the ARR uplift | Inflated form of F2 | "I proposed a store-surface change credited with a ~$400M ARR uplift." Which part was yours is an answer slot in B1 and F1 |
| Owned a go-to-market strategy or led a launch | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. The material does not show go-to-market |
| Has quota-setting or sales-ops experience, or that volume-target setting counts as it | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot, and no claim that the volume-target sentence is the same thing |
| Built or shipped AI products | Inflated form of F6 | "I use AI tools daily." The limit is the pack's observation: the material says use, not building |

## Sources

Provided documents: your message, holding the JD highlights, the coach's notes on Priya, the interviewer's profile summary, and your research note on Northwind's priorities. No dossier was present.

| Query | Outcome |
|---|---|
| Northwind Data B2B data infrastructure SaaS company values principles | refused |
| Dan Kovac Director of Sales Strategy Northwind Data | refused |

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have supplied official value names for VAL themes; the banks are generic instead, and a values cheat sheet is not included because no values round is detected |
| 2. `{company} interview process {role family}` | skipped | Your description of the round fixes persona weights, so a search could not have moved them |
| 3. `{company} strategy` / recent news | skipped | Your research note supplies the priorities and the competitive threat that D1 and D2 rest on |
| 4. `{interviewer name} {company}` | unavailable | Would have added talks and writing to the interviewer read; it rests on your profile summary alone |
| 5. representative `{role title}` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the highlights become exact quotes, and any mid-list requirement not yet covered gets a question
- Priya's CV, in her own words → the evidence cells quote her sentences instead of the coach's notes, and the three rows resting on second-hand notes can move up a band
- The document that records how the ~$400M ARR credit was counted, or the revenue model file → F2's and F4's band can rise to high, and B1 can drop its answer slots where the document answers them
- Her answers to the slots in F1, F2, F3 and F4, stated outside a drill → those rows regenerate as quoted evidence
- Search access, or the official values page and Dan's public talks pasted in → the banks' VAL themes and the interviewer read become grounded; a deeper research pass is offered once here: up to 6 more searches and 2 more fetches, several more minutes
- Recruiter or HR guidance on the conversation's focus → coverage tuned to what Dan has been told to score
- Prep time available → a prioritized prep schedule
- A `tuesday-dossier.md` from a job-underwriter pass → underwriter-verified evidence, a named top objection and a prohibited-claims list; never required for this pack
