Reading the reference files directly.
Dara, your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md` in the working directory.

I built it as a three-round loop from the recruiter's email, with a shared fit snapshot and a mini-pack per round. There are 30 questions, a values cheat sheet for the panel round, and a nine-day prep schedule to 20 November. I didn't run any web research, because your pasted values, strategy points, JD and email already covered what a search would have fed.

- **Highest-ROI prep:** question C1, the Head of Member Services saying "I don't see contact centre experience in your background." Your material says "Never worked in a contact centre", so the pack rehearses a plain concession, then holding only what you've said (the branch complaints log, training tellers on the script), then a plan rather than a claim.
- **Also a stated gap:** presenting above regional level, handled the same way in C3.
- **The four values:** none of your sentences carries a story for them, so each value gets a selection scaffold. Your own stories for them are the biggest upgrade you can add.
- **The panel case is a stand-in.** Nothing you sent says what the 20-minute escalation case will be, so G1–G4 are generic patterns.
- **Branch consolidation:** the panel are branch managers, and the brief turns eight branches into five hubs. The pack flags this as a reason to have a view on the hubs. It is not a claim about what the panel think.

The pack also lists claims it won't coach, such as "owned the process across branches" and "reported volumes and resolution times". Those are wider than what you actually said. The answer slots are for you to fill from memory, either way, and I haven't assumed what's true.

Say the word and I'll play the Skeptic on C1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead — Ashgrove Credit Union — interview loop pack

Candidate: Dara. Loop mode: three rounds on 20 November 2026, built on 11 November 2026 from the recruiter's email.

| Round | Who | Length | What the email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Nothing beyond length and who |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | A panel of two branch managers | 60 minutes | Includes "a 20-minute case on a complaint escalation"; "the values round — they score against the four values" |

Interviewer names are not assigned yet, so no interviewer read is written.

## How to use this pack

- Personas are how a question is asked; types are what is scored. Question IDs run A to B (round 1), C to E (round 2), F to H (round 3).
- VAL: behavioural, whether past behaviour shows Ashgrove's published values. EXP: whether your own history survives scrutiny. JD: a stated responsibility or requirement. CO: company and strategy knowledge. CASE: a live problem on the role.
- Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for me: answer whichever branch is true, from your own experience.
- Every table of proposed wording is pending your approval. Change anything that is not true as you would say it.

## Prep triage — nine days, 11 to 19 November

| When | Do | Tied to |
|---|---|---|
| 11–12 Nov | Say the contact-centre concession and the senior-leaders concession aloud until they are boring; this is the highest-ROI prep in the pack | C1, B2, C3 |
| 13–14 Nov | Write, from memory, what is true for each answer slot, and pick one real story per value where one exists | F1, F3, F4, F5, F6, F8 rows; F1–F4, D1, D2, D4 |
| 15–16 Nov | Run the case aloud, timed to 20 minutes, structure spoken first | G1–G4 |
| 17 Nov | The three moves in the strategy brief, and the coaching question | E1–E3, D3, H1 |
| 18 Nov | The recruiter round: the 90-second arc and the two requirement checks | A1, A4, B1, B3 |
| 19 Nov | One full drill, then a last read of the reverse questions | Pack's drill offer |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process across branches, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint before and after it reached your log likely. If any of that was yours, say which part, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your material says a monthly complaints spreadsheet your regional manager uses; it does not show what the spreadsheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say what it counted and how the regional manager used it, in your own words; if you did not choose what it counted, say so plainly and stay with the spreadsheet you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel. Answer slot: if it was built in Excel, say so and what you do in it, in your own words; if it was another tool, say so plainly and say how you would get to Excel |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and a script, not supervisors, and the script is "our" script, not stated as yours. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on whether you have worked with supervisors on escalations likely. If you have, say who and how, in your own words; if not, say so plainly and stay with the tellers |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent, so nothing is claimed. Strong evidence would be a named journey and your part in it. Answer slot: if you have worked with a digital team or on a self-service step, say what and your part, in your own words; if you have not, say so plainly and say what you would ask the digital team first |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on the years, but a self-stated line with nothing inspected behind it, so expect a probe on what the work involved. Say it as written, with no rounding |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [inferred] | discovery | The sentence says formal, not what rules sat behind the log. Answer slot: say what made the log formal, in your own words; if you do not know what governed it, or that was not yours to know, say so plainly and stay with the log you handled |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for the first one, said as a plan and never as a past |

## Grounding brief

The strategy brief is the one the recruiter sent; the four points below are as you quoted them in your message, and the full text is not in hand.

| Brief point or reading | Where it surfaces | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | E1, G3 | [grounded] |
| "consolidate eight branches into five hubs over 2027" | E2 | [grounded] |
| "launch a small-business lending product in Q1 2027" | E3 | [grounded] |
| "the main competitive pressure is app-only banks" | G3, reverse questions for round 2 | [grounded] |
| Reading: the published value says "every branch is part of its town", the brief consolidates eight branches into five hubs, and round 3 is two branch managers scoring against that value. Derived from your pasted values text, the brief point above and the recruiter's email; it is a reason to have a view on the hubs, not a claim about what the panel think | F3, E2, round 3 reverse questions | [inferred] |

---

# Round 1 — the recruiter, 30 minutes

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly biography and "tell me about" questions | High: a recruiter screen's prior is Conversational plus a light Skeptic, and your email gives only the length and who | A 90-second arc for A1; treat every casual question as scored |
| Skeptic, light | Requirement checks: years, contact centre, weakest area | Medium: the same prior, and the JD lists requirements a recruiter can check in the call | Rehearse B1 and B2 until the plain acknowledgment is boring |

## Conversational bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your career so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F7, F1, F5 and F3: four beats, each a clause of your own sentences, told in your own words in about 90 seconds, and no further. Answer slot: the reason for moving now is yours to give; if it is a mix, say the part that is true | The recruiter's opening is where F7 answers the years line, and the other rows are what the rest of the loop will probe. EXP because it tests what was actually yours; the friendly register is why it feels unscored |
| A2 | "What drew you to Ashgrove, and why this role now?" | CO | [grounded] | No claim about your past is needed. Choose one of the four published values, or one point from the strategy brief, and say in your own words why it matters to you, using Ashgrove's own words for it. Answer slot: if the value that sounds best is not the one that moves you, say the one that does | Motivation consistency is the recruiter's first read; published wording makes you sound current, not archival. CO because it tests homework |
| A3 | "Tell me about the complaints work you've done at your branch." | EXP | [grounded] "I handled the branch's formal complaints log" "trained new tellers on our escalation script" | Story-mapped on F1 and F5: two beats, each at its own scope. Answer slot: the JD's regulated-complaints line makes a probe on what made the log formal likely. Say what you know about that, in your own words; if you do not know, or it was not yours to know, say so plainly and stay with the log you handled | F1 and F8 are where this question presses hardest, and the probe arrives in a friendly register. EXP because it tests what was actually yours |
| A4 | "Tell me about the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3: one beat, that you built a monthly complaints spreadsheet your regional manager uses. Answer slot: the JD's monthly-reporting line makes a probe on what it counted likely. Say what it counted and how the regional manager used it, in your own words; if you did not choose what it counted, say so plainly and stay with the spreadsheet you built | F3's gap is silence about the contents, so the probe lands here first. JD because it scores the reporting line |
| A5 | "How comfortable are you in Excel?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F4: the sentence says a spreadsheet, and it does not say Excel. Answer slot: if it was built in Excel, say so and what you do in it, in your own words; if it was another tool, say so plainly and say how you would get to Excel | F4 is a requirement the JD lists once and the material only touches. JD because it scores a stated requirement |

Guidance in this table: pending your approval.

## Skeptic bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Name the one you would rather they heard from you first. Your quotes carry two stated absences: "I've never worked in a contact centre." and "I've never presented to anyone above regional level." Say one plainly, then say as a plan what you would do first to learn it. Answer slot: the first step is yours to name; if you do not know yet, say how you would find out | F2 and F9 are both stated absences, so this question lands on one of them. JD because it scores the stated requirements, with Skeptic delivery |
| B2 | "The role covers the contact centre as well as branches. What is your experience on that side?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Concede first, plainly: "I've never worked in a contact centre." Then what your quotes carry at their own scope: "I handled the branch's formal complaints log." Stop there; the full rehearsal is C1 | F2 is a stated absence, and the recruiter version is the short one. JD because it scores the requirement's scope |
| B3 | "The role asks for four years or more in financial-services customer operations. Can you walk me through your years?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say it as written: six years in retail banking, the last three as a branch supervisor. No rounding, no added titles. Answer slot: if they ask what the supervisor role covered, answer in your own words from what you did | F7 is the cleanest row, and a requirement check goes quickly when the answer is exact. EXP because it tests the CV line |

Guidance in this table: pending your approval.

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Is there anything in my background you would want me to address before I meet the Head of Member Services?" | It surfaces the contact-centre and presenting concerns before round 2 and turns a probe into prep |
| 2 | "For the panel case, will I see the scenario beforehand, and is there a format I should know?" | The email gives the 20 minutes and the topic only; the answer decides how you prepare G1–G4 |
| 3 | "Once the panel is assigned, could you tell me who they are?" | It is the one missing input to interviewer-specific prep, and asking early is easy |
| 4 | "Which rules and time limits does Ashgrove's complaints process work to?" | The JD says regulated; the answer decides whether A3 and G1 can name the real clock |
| 5 | "What is the timeline after the 20th?" | A logistics question that shows you are planning ahead |

---

# Round 2 — the Head of Member Services, 45 minutes

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time" questions on complaints, coaching and leadership | High: your email says the round is "mostly behavioural" | A story for each prompt where a quoted sentence carries one, a selection scaffold where none does |
| Skeptic | Quiet probing of the contact-centre and seniority gaps | High: a hiring manager's prior is Skeptic plus Case, and this person would manage you | C1 is the pack's highest-ROI prep: rehearse it until the concession is boring |
| Case/Strategist | Live problems from the brief's three moves | Lower: the hiring-manager prior is Case, pulled down by "mostly behavioural" | Think aloud, clarify first, challenge one premise respectfully |

## Values/Behavioral bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, a moment you did not fold, and an intact relationship at the end; use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's seniority line (F9) is where this theme presses, and no quoted sentence carries a story for it. VAL because it is a behavioural prompt; `[generic]` because it is a pattern, not a fact about Ashgrove |
| D2 | "Tell me about a time a member needed an outcome explained and was not happy with it." | VAL | [grounded] | Selection scaffold, on the published "Plain Words" value: pick a time you explained a decision to a member who disagreed. It needs what they asked, what you said in plain words, and whether it landed the first time. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value reads "if a member needs it explained twice, we wrote it wrong", and the panel scores against it in round 3. No quoted sentence carries this story. VAL because it maps to a published value |
| D3 | "Tell me about a time you coached or trained someone on handling an escalation." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on F5: one beat, "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on whether you have worked with supervisors on escalations likely. If you have, say who and how, in your own words; if not, say so plainly and stay with the tellers | F5 is adjacent evidence for the JD's coaching requirement. EXP because it tests what was actually yours |
| D4 | "Tell me about a time a complaint you were handling stalled between two teams." | VAL | [grounded] | Selection scaffold: pick a time a complaint sat between two teams. It needs who held it, what you did about the gap, and what the member was told. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD asks you to own the process across branches and the contact centre (F1, F2), and the theme comes from that line. No quoted sentence carries a story for it. VAL because it is behavioural, and it rehearses "Own the Fix" |

Guidance in this table: pending your approval.

## Skeptic bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see contact centre experience in your background. How would you handle the contact centre side of this role?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" | The pack's highest-ROI prep. Concede first, plainly: "I've never worked in a contact centre." Hold what the quotes carry and no wider: "I handled the branch's formal complaints log", "I trained new tellers on our escalation script". Do not call either contact centre work or similar to it. Follow-up one, "how does that transfer?": return to the log and the tellers, and say what you would need to learn first, in your own words. Follow-up two, "what would you do in your first thirty days?": a plan, not a past. Answer slot: say your first step and how you would know it was working; if you do not yet know how the contact centre is set up, say that plainly. Close on the concession, not on a claim. The limit, as the pack's observation: your material shows one branch's log and no contact-centre contact, and the pack writes nothing about what a contact centre does | F2 is the JD's scope line and a stated absence, so this objection arrives in some form from this interviewer or another. JD because it scores the stated requirement; Skeptic delivery because it probes the gap quietly |
| C2 | "Have you handled complaints beyond your own branch?" | EXP | [grounded] "I handled the branch's formal complaints log" | Answer slot: the JD's across-branches line makes this likely. If you have, say which and your part, in your own words; if not, say so plainly and stay with "I handled the branch's formal complaints log." | F1 is one branch's log against a role that spans branches. EXP because it tests the scope of what was yours |
| C3 | "I understand you haven't presented above regional level. How will you handle presenting to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | Concede first, plainly: "I've never presented to anyone above regional level." Then a plan, not a past. Answer slot: say how you would prepare for the first such presentation, in your own words; if you do not yet have a plan, say what you would ask first and of whom. Hold through two follow-ups by returning to the plan, never by adding an audience | F9 is a stated absence and the JD lists the requirement. JD because it scores the stated requirement |
| C4 | "Sixty seconds: why you rather than someone who has run a contact centre complaints team?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses" "Never worked in a contact centre" | Pause and restate the question. Hold only what the quotes carry: six years in retail banking, the last three as a branch supervisor, "I handled the branch's formal complaints log", "I built the monthly complaints spreadsheet our regional manager uses". Do not compare yourself to the other person; you know nothing of them. After the second follow-up, concede specifically: "I've never worked in a contact centre." Do not fold on the rest | F7 and F2 are the two rows this pressure question sets against each other. JD because it scores fit to the role; Pressure delivery because it time-boxes and challenges motive |

Guidance in this table: pending your approval.

## Case/Strategist bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Ashgrove wants to move 40% of member service to digital channels by 2028. Where do complaints sit in that?" | CO | [grounded] | Think aloud: clarify what the 40% covers and who owns a complaint that starts in a digital channel; objective; segment members who are moving and members who are not; approach; measures; risks. Tie it to "Plain Words", a published value: a complaint that needs explaining twice means the journey was written wrong. Answer slot: the JD's digital-teams line makes a probe on your contact with digital teams likely. If you have worked with one or on a self-service step, say what and your part, in your own words; if you have not, say so plainly and say what you would ask the digital team first | A strategy-grounded question from the brief's first point, and the place F6 surfaces. CO because it tests current priorities |
| E2 | "Eight branches become five hubs over 2027. What would you want in place for complaints before that starts?" | CASE | [grounded] | Clarify first: which branches, what members lose, when. Then objective, segmentation, approach, measures, risks; challenge one premise respectfully. You may name "Neighbours, Not Numbers" as a value Ashgrove publishes, and ask how the hubs sit with it, without telling them what it means to them. The question needs no claim about your past, so the guidance makes none | A live problem from the brief's second point, and the reading in the grounding brief explains why it matters to round 3. CASE because it scores structure |
| E3 | "A small-business lending product launches in Q1 2027. What would you expect to change about complaints, and how would you find out early?" | CASE | [grounded] | Clarify first: what the product is, who answers members about it, who owns a complaint about it. Then structure the answer: what you would count, what you would ask the branches and the contact centre, who needs to hear first. Say what you do not know yet rather than guessing. The question needs no claim about your past, so the guidance makes none | A live problem from the brief's third point. CASE because it tests how you reason about something that does not exist yet |

Guidance in this table: pending your approval.

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "Where does a complaint most often get stuck between a branch and the contact centre today?" | It shows you are thinking about the seam the JD hands you, and the answer tells you where to start |
| 2 | "What would you want the monthly complaints report to change in the decisions leaders make?" | It ties to the JD's monthly-reporting line and to the senior-leaders requirement |
| 3 | "Which self-service journeys are furthest along, and where do complaints show up in them?" | It ties to the JD's digital line and to the 40% digital point in the brief |
| 4 | "With app-only banks named as the main competitive pressure, where do complaints matter most in that fight?" | It uses the brief's own words and asks for their view rather than offering yours |
| 5 | "Who in the contact centre would I work most closely with in my first month?" | It treats the contact-centre gap as something you are already planning around |

---

# Round 3 — the panel of two branch managers, 60 minutes, values-scored, with a 20-minute case

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | A scored prompt per published value | Highest: the recruiter says the panel is "the values round — they score against the four values" | A story per value where a quoted sentence carries one, and a scaffold where none does: see the cheat sheet |
| Case/Strategist | The 20-minute complaint-escalation case, with follow-ups | High: 20 of the 60 minutes | Structure aloud first; clarify before answering; challenge one premise respectfully |
| Peer Evaluator | Seam questions: coaching their supervisors, branch versus contact centre | Medium: you would coach branch supervisors, and the panel are branch managers; the panel prior blends each member's top two personas, and names are not yet known | Propose seam principles instead of pretending to know their seam; say what you bring them |

## Values/Behavioral bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell us about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold, on "Members First, Always": pick a time you made a call that cost you or the branch something, because it was right for the member. It needs the decision, what it cost, and the member's outcome in one sentence. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value is "we decide from the member's side of the counter", and no quoted sentence carries a story for it. VAL because it maps to a published value |
| F2 | "Tell us about a time a member needed something explained twice." | VAL | [grounded] | Selection scaffold, on "Plain Words": pick a time something you wrote or said needed a second explanation, and say what you changed. It needs what was unclear and what the member understood afterwards. Do not claim to have written the escalation script. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value is "if a member needs it explained twice, we wrote it wrong", and F5's sentence says "our escalation script", not that you wrote it. VAL because it maps to a published value |
| F3 | "You built the complaints spreadsheet your regional manager uses. How do you stop a branch becoming a number?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold only what the quote carries: "I built the monthly complaints spreadsheet our regional manager uses." The second half is a selection scaffold, on "Neighbours, Not Numbers": pick a time a figure and a person from the same branch pulled in different directions. It needs what the figure said, who the person was, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value is "every branch is part of its town", the panel are branch managers, and F3's spreadsheet invites a numbers reading; the brief's hubs sit behind it. VAL with Skeptic delivery |
| F4 | "Tell us about a time you found a problem that was not yours and kept hold of it until it was solved." | VAL | [grounded] | Selection scaffold, on "Own the Fix": pick a time you found a problem outside your remit. It needs how you found it, who you told, and how you kept hold of it until it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value is "whoever finds the problem keeps hold of it until it is solved", and no quoted sentence carries a story for it. VAL because it maps to a published value |

Guidance in this table: pending your approval.

## Case/Strategist bank

The scenario below is a stand-in: nothing supplied says what Ashgrove's case will be, so each row is a pattern for the problem, not a claim about Ashgrove.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member has been into the branch twice and rung the contact centre once about a payment taken from their account twice. The supervisor cannot resolve it and the member now wants to make a formal complaint. Talk us through what you do." | CASE | [generic] | Say the structure first. Clarify: what the member has been told, by whom, what is outstanding, what they are asking for, and what time limits Ashgrove's process works to; ask the panel, and do not state one. Objective: the member's problem solved and the member knowing, in plain words, what happens next. Approach: say who holds the complaint from now on, one conversation so the member does not repeat the story, what is recorded, who needs to know. Risks: the seam between branch and contact centre. Challenge one premise: ask whether the payment can be put right separately from the complaint. The question needs no claim about your past, so the guidance makes none | The JD's end-to-end line and the recruiter's 20-minute case; the answer rehearses all four values at once. CASE because it scores structure and reasoning; `[generic]` because the real scenario is unknown |
| G2 | "The supervisor says the contact centre told the member something different. What now?" | CASE | [generic] | Do not pick a side. Establish what each said and when, put the member's position right first, agree one owner, and tell the member plainly what happens next. Afterwards, find where the seam failed. The question needs no claim about your past, so the guidance makes none | A follow-up the panel can add to G1 about the branch and contact-centre seam the JD hands you. CASE because it tests composure under a complication |
| G3 | "The member says they will move to an app-only bank. Does that change what you do?" | CASE | [grounded] | Separate resolving the complaint from keeping the member: the complaint is treated the same either way, and the member's threat is not a lever. Say what you would ask the member about what they need. Tie it to "Members First, Always". The question needs no claim about your past, so the guidance makes none | The brief names app-only banks as the main competitive pressure, and a panel can use it to test whether you trade members off against the numbers. CASE with CO |
| G4 | "Three weeks on, six more members raise the same payment problem. What do you report, to whom, and how?" | CASE | [generic] | Structure: what you would count (how many, how long they took to resolve, which channel they came through, whether the cause is shared), who must hear first (ask), what you would show on one page, and what you do not know yet. Lead with the headline in plain words, then the recommendation. The question needs no claim about your past, so the guidance makes none | The JD's reporting and senior-leaders lines (F3, F9) sit under this one. CASE because it scores how you structure a report to leaders |

Guidance in this table: pending your approval.

## Peer Evaluator bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You would coach our supervisors on escalations. Where is the line between coaching and doing it for them?" | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F5: the one beat the quote carries, "I trained new tellers on our escalation script." Offer the line as a principle, not a claim about your past, and say what you would bring their supervisors in return. Answer slot: if you have coached a supervisor or a peer, say who and how, in your own words; if not, say so plainly and stay with the tellers | F5 is adjacent evidence for the JD's coaching line. JD because it scores the stated responsibility; Peer delivery because it asks about the seam |
| H2 | "When a branch and the contact centre disagree about who owns a complaint, what happens?" | JD | [generic] | Propose seam principles instead of pretending to know theirs: one named owner from the moment the complaint is raised, the member looked after before the disagreement is settled, and an ask of them about how it works today. The question needs no claim about your past, so the guidance makes none | The seam in the JD's first line (F1, F2). JD because it scores the scope; Peer delivery |
| H3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed two teams and credit was shared or contested; use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer stem. VAL because it tests collaboration behaviour |

Guidance in this table: pending your approval.

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "How do your supervisors handle an escalation they are unsure of today, and what would help them most from this role?" | It is the reciprocity question: what you can do for them, not only what you need |
| 2 | "As the eight branches move toward five hubs, what do you most want members to keep feeling about their local branch?" | It uses the published "Neighbours, Not Numbers" value and the brief's second point, and asks for their view |
| 3 | "Where have complaints been hardest for your branches to hold onto until they are solved?" | It uses "Own the Fix" and invites a story you can learn from |
| 4 | "How does your branch learn what happened to a complaint after it leaves the branch?" | It tests the seam in the JD's first line from the branch's side |
| 5 | "Which of the four values is hardest to hold day to day, and what does it look like when it slips?" | It invites an honest story and shows you took the values seriously |

---

# Shared sections

## Values cheat sheet

The panel is the values round. The four values and their wording are as pasted from Ashgrove's values page on 11 November 2026. None of your sentences carries a story for a value, so each row is a selection scaffold with the honest branch.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's side | Selection scaffold: a call that cost you or the branch something because it was right for the member; the decision, the cost, the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. See F1 |
| Plain Words | If a member needs it explained twice, the writing was wrong | Selection scaffold: something you said or wrote that needed a second explanation, and what you changed; do not claim to have written the escalation script. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. See F2 |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold: a time a figure and a person from one branch pulled in different directions, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. See F3 |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | Selection scaffold: a problem outside your remit that you kept hold of until it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. See F4 |

Guidance in this table: pending your approval.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | A3, B2, C1, C2, D4, G1, G2, H2 |
| Report monthly on complaint volumes and resolution times | A4, G4 |
| Coach branch supervisors on escalations | D3, H1 |
| Work with digital teams on self-service journeys | E1 |
| 4+ years in financial-services customer operations | A1, B3 |
| Experience handling regulated complaints | A3, G1 |
| Confident presenting to senior leaders | C3, D1, G4 |
| Comfortable with Excel reporting | A5 |
| The four published values | F1, F2, F3, F4, D2 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation: your material says one branch's log, not the process across branches. C2's slot stays inside the branch |
| Has contact centre experience, or experience similar to it | Negative the candidate stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Presented to senior leaders | Negative the candidate stated, F9 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses". A4's slot asks only what the spreadsheet counted and how the regional manager used it |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: "trained new tellers on our escalation script". D3 and H1 stay with the tellers |
| Wrote the escalation script | Inflated form of F5 | F5's quote at its own scope: the sentence says "our escalation script", not that you wrote it |
| Handled regulated complaints | Inflated form of F8 | F8's quote at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation: your material says formal, not what rules governed it. A3's slot asks only what made it formal |

## Sources

Provided documents: the JD as pasted; Ashgrove's values text as pasted, which you copied on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email; the 2026 strategy brief as quoted in your message, four points, full text not in hand; and your background message. No `tuesday-dossier.md` was present. No search or fetch was sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet or the VAL banks: the pasted values text already fixes the four values and their wording |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the rounds or persona weights: the recruiter's email already names three sessions, who runs each and what the panel scores |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO and CASE banks: the pasted brief, dated July 2026, already supplies the four moves the pack uses |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → the fit snapshot's evidence column can quote more than your message, and rows now `none given` or thin (F4, F6, F8) may upgrade
- Your answers to the slots in F1, F3, F4, F5, F6 and F8, in your own words → those rows' evidence upgrades and the matching bank guidance becomes story-mapped
- The full strategy brief → the grounding brief and the CO and CASE rows go beyond the four points you quoted
- The interviewers' names, once assigned → an interviewer read, persona weights per panel member, and a reverse question tied to their own path
- Which rules and time limits Ashgrove's complaints process works to, from one email to the recruiter → A3 and G1 can name the real clock, and the regulated-complaints probe becomes specific
- The panel case's format, and whether the scenario is shared beforehand → G1–G4 can be rewritten around the real case instead of a stand-in
- On your yes: a deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → recent organisation context and any candidate reports for this role family, with forum claims labelled `[inferred]`
- A `tuesday-dossier.md` from the job-underwriter → an evidence-derived top objection and a prohibited-claims list from that analysis; this pack stands without it
