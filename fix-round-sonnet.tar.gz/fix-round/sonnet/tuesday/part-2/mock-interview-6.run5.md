Your prep pack covers all three rounds and is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-6-denied-5860a5a0/larkfield-systems_engineering-manager_interview_pack.md`. It has a shared fit snapshot, a persona-weighted bank and reverse questions for each round, and an upgrade menu.

My three web searches were refused, so nothing about Larkfield's values, strategy or interview process is researched. Questions that would have rested on that research are labeled generic. Without the company's published values page, I also left out the values cheat sheet for the Monday round.

- **Pack structure:** it has 29 questions: 10 for Tuesday, 10 for Thursday and 9 for Monday. Tuesday leans on case problems and skeptic probing. Thursday blends peer and numbers-probing from the staff engineers with a product manager's behavioral questions. Monday is values first, then pressure.
- **Highest-ROI prep:** B2 is the question to rehearse hardest. It is the hardware-roadmap gap, and you've said you've never owned one. Say that plainly, give a forward-looking plan, and hold it through follow-ups. B1 and I1 cover the same ground for your never having managed managers.
- **Your reliability quarter:** the 60% on-call drop story shows up in all three rounds (B3, E1, H2, I2). Practice defending how it was counted and which part was yours.
- **Fit-row gaps:** growth, and partnering with product on the roadmap, have no evidence in what you've told me. Those rows are answer slots for your own words, not material I filled in for you.

Say the word and I'll play the Skeptic on B2 in a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full posting and your CV or a few bullets? Each would replace my paraphrase with your actual sources. I'll proceed without them if not.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack — Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Role: Engineering Manager, industrial IoT, about 600 people, two squads on device-management services, 11 engineers.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | 45 min | Hiring manager, would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel |
| 3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min | Skip-level, values-style |

This is the first version of the pack. No regeneration changes yet.

## How to use this pack, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: where a cell says "answer slot", it is an instruction for the interview, and the words that fill it must be yours.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral and values alignment | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually you |
| JD | Role and JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical or live problem | Structure and reasoning on a problem from the role, delivered live |

## Prep triage

You have two weeks and three rounds. Do these in order; each is tied to the questions it rehearses.

1. Say your two stated limits plainly and hold them under follow-ups: B2 (deepest rehearsal in this pack), B1, I1. They surface in rounds 1 and 3.
2. Tell the reliability-quarter story in its own terms, and rehearse defending the 60%: B3, E1, H2, I2. It surfaces in all three rounds.
3. Rehearse the hiring loop and the figure of about 40: G1, E2, A4.
4. Run the case structure out loud on A1 to A3 before Tuesday, then J1 and J2 before Monday.
5. Write your own answers to the answer slots in F2 to F6 below; each written answer lets me upgrade those rows.

Everything else is insurance.

## The fit snapshot (shared across all three rounds)

The role description is the text you gave me, quoted as the posting's lines. There is no CV in hand, so the evidence is the four sentences you wrote in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | medium | [grounded] | transferability | Your material says a team lead of 6 at a payments company, not two squads and not device-management, and the words stay there: "I've been a team lead of 6 for 3 of my 9 years in engineering." Where leading through other leads comes up, the words are the one you stated: "I've never managed managers." Say how you would learn it as a plan, never as a past. Answer slot: the role's two squads make a probe on leading more than one group likely. If your leading ever spanned more than the team of 6, say how, in your own words; if it did not, say so plainly and stay with the team of 6 |
| F2 | "own delivery, hiring and growth for 11 engineers" (the delivery part) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Your material says the reliability quarter and the roadmap pressure, not that you answered for a team's delivery, and the words stay there: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the role's own-delivery line makes a probe on what you were accountable for likely. If delivery dates or scope were yours to answer for, say which and how, in your own words; if they were not, or there was no such accountability, say so plainly and stay with the quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | presentation | No gap in the wording, but a claim with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms: you run it, for backend roles. Your material says the loop and about 40 interviews, nothing about offers, headcount or the 11-engineer team |
| F4 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role description in your message | none given | none | [grounded] | discovery | Nothing in your material speaks to growing engineers. Strong evidence would be a named person, what changed for them, and what you did. Answer slot: the role's growth line makes a probe likely. If you grew anyone's scope or career, say who and what you did, in your own words; if you did not, or that was not yours, say so plainly and say what you would do first |
| F5 | "partner with hardware and product on roadmap" (the hardware side) — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Your material does not say whether you have worked alongside hardware teams, so the partnering half of the line is unsettled and nothing is added to settle it |
| F6 | "partner with hardware and product on roadmap" (the product side and the roadmap) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote shows roadmap pressure and your push, not who applied the pressure or whether product was involved. Answer slot: the role's partner line makes a probe on who you worked with on a roadmap likely. If you worked with product or hardware on one, say with whom and what was decided, in your own words; if you did not, say so plainly and stay with the quarter as the quote states it |

## Round 1 — Tuesday, Director of Engineering (hiring manager), 45 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the real roadmap: replan, diagnose, decide | High. The hiring-manager prior pairs Case/Strategist with Skeptic; this person would also be your boss, so expect problems set in the actual squads | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the gaps | High. Same prior; the gaps in F1, F5 and F6 are the ones a hiring manager derisks | Rehearse the one predictable objection until it is boring; limits said plainly; no bluffing a competency they own |
| Conversational | Friendly openers, "walk me through the journey" | Low. The first minutes of any 45-minute round, but a Director buying capability will move on quickly | A short pre-scripted arc; treat casual questions as scored |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Hardware tells you a firmware release will slip six weeks and both squads have work waiting on it. Walk me through how you replan." | CASE | [generic] | Clarify first: what exactly slipped, what each squad can still do, who else depends on it. State the objective, split the work by what is blocked and what is not, pick an approach, name the metric you would watch and the main risk. Challenge one premise, for instance whether six weeks is firm. The question needs no claim about your past, so the guidance makes none | The role's partner line (F5, F6) makes hardware-dependent planning a likely live problem; CASE because it is a problem set in the role, `[generic]` because it is a role-family pattern |
| A2 | "You take over two squads and 11 engineers. What do you want to know in the first 30 days, and what do you leave alone?" | CASE | [generic] | Structure it: what you would ask each squad, what you would ask the people around them, what evidence you want before changing anything, and what you would deliberately not touch yet. Say aloud where you would lean on others. Makes no claim about your past | The two-squad scope is where F1 is thinnest, so a hiring manager tests judgment on it directly; CASE because it is a live scenario |
| A3 | "Product and hardware both want your squads' capacity this quarter. How do you decide between a reliability quarter and feature work?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure the decision: what each side needs, what evidence would settle it, what you would trade and what you would protect. If you choose to draw on your own example, say it in the quote's terms and no wider: you pushed a reliability quarter through against roadmap pressure, and the on-call burden dropped 60%. Answer slot: a probe on who held the opposing priority and what was weighed is likely. If you weighed particular things, say which, in your own words; if there was no explicit weighing, or it was not yours, say so plainly and tell the quarter as the quote states it | F2 and F6 hold the only quoted evidence near this trade-off; CASE because it asks for a decision rule, with EXP behind it if they ask about your own quarter |
| A4 | "You have one hire to place across the two squads. How do you decide where it goes?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Structure it: what each squad needs and what is at risk if it waits, what the role must cover, how you would test a candidate against it, what you would ask each squad lead first. If you draw on your own hiring, say it in the quote's terms: you run the hiring loop for backend roles. Answer slot: the role's hiring line makes a probe on who decided hires likely. If hiring decisions were yours, say how you made them; if they were not, or the loop only assessed, say so plainly and stay with the loop you run | F3 is the evidence nearest this question and F4 sits beside it; CASE because it is a resourcing decision |
| B1 | "Which part of this role description would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Pause, then answer with the limit that is truly your weakest. Two limits you have stated are available as plain acknowledgments: "I've never managed managers" and "I've never owned a hardware-adjacent roadmap." Say one, then a plan in the future tense for learning it. If your real weakest part is something else, say that instead, in your own words. Hold through two follow-ups by returning to the same limit and the same plan, and concede only what you can name specifically | F1 and F5 hold the stated limits; JD because it scores the listed responsibilities, and the Skeptic persona asks it in nearly every hiring-manager round |
| B2 | "I don't see hardware-adjacent roadmap ownership in your background. How would you handle that part of this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | **The highest-ROI rehearsal in this pack.** Hold only what the quote carries. First level: the plain acknowledgment, "I've never owned a hardware-adjacent roadmap," then a plan stated as a plan, in the future tense, in your own words. Second level, if they say partnering is different from owning: stay with the limit and ask what the partnership looks like here. Third level, if they press on week one: say what you would ask hardware first, as a plan. Answer slot: if you have worked alongside hardware teams, say how, in your own words; if you have not, say so plainly and stay with the plan. Never describe hardware work you did not do | F5 is the gap the role's partner line presses hardest on, so it will arrive in some form; JD because it scores a stated responsibility, and the objection is predictable enough to rehearse until it is boring |
| B3 | "Walk me through how you got that reliability quarter through against roadmap pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F2: the reliability quarter, the push, the roadmap pressure and the 60% drop in on-call burden are the beats the quote states; tell them in your own words. Answer slot: a probe on who pushed back and how it was settled is likely. If you made a case to anyone, say to whom and what you showed; if there was no such step, or it was not yours, say so plainly and tell the quarter as the quote states it | F2 and F6 are the strongest quoted evidence you have, so it is the likeliest EXP probe; EXP because it tests what was actually yours |
| B4 | "This role owns delivery, hiring and growth for 11 engineers. What have you owned so far?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say the quote in its own terms: 9 years in engineering, 3 as a team lead of 6. Answer slot: if you owned delivery, hiring or growth for that team of 6, say which and how, in your own words; if any of the three was not yours, or did not exist as a task, say so plainly and return to the team of 6 as the quote states it | F1 is the evidence for the scope gap; JD because it scores the listed responsibility, and the premise comes from the role description rather than from your material |
| C1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc whose beats are the quote's: 9 years in engineering, 3 as a team lead of 6, currently at a payments company. Answer slot: why this role and why now are yours to say in your own words; the pack has no source for your reasons | The opening of nearly any hiring-manager round; EXP because it fixes the baseline later questions probe against F1 |
| C2 | "What draws you to device management specifically?" | JD | [generic] | A selection scaffold: pick one real reason that came from something you did or read, name it concretely, and keep it short. If no specific reason comes to mind, say so plainly, then say what you would want to learn first about the problem space. The pack has no source for your reasons, so none is supplied | The role's first line is device-management services (F1); JD because it scores motivation for the listed work, asked in a casual register |

### Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What does a good first 90 days look like for the two squads' delivery, in your words?" | It gets the interviewer to define success before you are measured against it |
| R1.2 | "Do the two squads have leads under them, or would I work directly with all 11 engineers?" | It surfaces the leading-through-leads question honestly and on your terms (F1) |
| R1.3 | "Where do hardware and software roadmaps disagree most today, and who settles it?" | It shows you take the hardware seam seriously without claiming to know it (F5) |
| R1.4 | "What do you worry about most in filling this role?" | It invites the objection into the open where you can address it |
| R1.5 | "What would make you say, a year from now, that hiring me was right?" | It converts a vague hope into criteria you can plan against |

## Round 2 — Thursday, panel of two staff engineers and a product manager, 60 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting, collaboration, credit-sharing | High. The staff engineers sit closest to the peer relationship; they are pricing what you cost and contribute to their work | Reciprocity framing; propose seam principles, not a pretended seam; spine and tact together |
| Data-Driven Prober | Line-by-line probing of numbers and design judgment | High. The peer prior pairs Peer Evaluator with Prober, and staff engineers verify depth | Know what you can and cannot say about how each figure was counted; name your weakest assumption first |
| Values/Behavioral | Scenario and behavior probes, from outside the function | Mid. The product manager is cross-functional, where the prior is Values/Behavioral with Conversational | Stories where the hard truth landed; "we" for context, "I" for contribution |
| Conversational | Friendly, unstructured questions | Low. Likely a minute or two from the product manager | Pre-scripted short arcs; casual questions are still scored |

Per-round banks are sized 8 to 12; this round carries 10, a single Conversational item being enough at that weight.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where is the seam between a device-management squad and the hardware team, and what happens when we disagree?" | CASE | [generic] | Propose seam principles instead of pretending to know the seam: who owns each interface, how a disagreement escalates and how fast, what each side is told early. Say you would learn the actual seam from them. Add what you would bring them as well as what you would need. Makes no claim about your past | Staff engineers are the people who live at this seam (F5, F6); CASE because it is a live collaboration problem |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold: pick a time when work crossed team lines; it needs a named piece of work, who else contributed, and an outcome you can state plainly. Say "we" for the context and "I" for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing is a standing Peer Evaluator probe; VAL because it scores behavior toward equals |
| D3 | "What would you need from a staff engineer in your first month, and what would you give back?" | JD | [generic] | Reciprocity framing: two or three honest needs, stated as asks, then what you would offer in return, stated as plans. Makes no claim about your past | The panel's staff engineers are pricing your load on them (F1); JD because it scores the working relationship the role implies |
| E1 | "Walk me through how that on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The defend-the-number slots, each in your own words: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of it was yours. Name the weakest assumption before they do. If you do not know how it was counted, say so plainly. The pack does not supply a baseline, a method or an assumption | F2 is the headline figure on your side; EXP because probers go after numbers first |
| E2 | "You said about 40 interviews last year. Were those yours or the loop's, and how did you count them?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | The same four slots, in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If the figure is the loop's total and not yours, say so plainly | F3 holds a second headline figure and its quote does not say whose count it is; EXP because it tests attribution |
| E3 | "A staff engineer proposes a redesign of how devices reconnect after being offline, and you cannot judge the design in the room. How do you decide whether to back it?" | CASE | [generic] | Ask for the problem and the evidence, what happens if nothing changes, who else is affected (hardware, product), whether the change can be reversed. Say where you would lean on the staff engineers' judgment and what you would still own, the decision. The scenario content is a role-family pattern, not a fact about Larkfield. Makes no claim about your past | Panel staff engineers will test technical judgment where F1 shows a domain gap; CASE because it is a live scenario |
| F1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold: pick a time that has a named stake, a moment where the metric and the customer pulled apart, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A product manager from outside engineering often asks a customer-versus-metric question; VAL because it scores behavior, not virtue in general |
| F2 | "I bring you a date my customers need. How do you say no, or not yet?" | JD | [generic] | Structure the conversation: what you would ask first, what evidence you would show, what you could offer instead, and how you would keep the relationship intact. Makes no claim about your past | The role's product-partner line (F6) is the PM's own stake; JD because it scores a stated responsibility through a live exchange |
| F3 | "Tell me about an engineer whose growth you supported." | EXP | [generic] | A selection scaffold: pick a person whose growth you supported, with what changed for them and what you did. Answer slot: if you grew anyone's scope or career, say who and what you did, in your own words; if you did not, or that was not yours, say so plainly and say what you would do first | F4 is discovery with nothing quoted, and the role's growth line raises the probe; EXP because it tests what was actually yours |
| G1 | "Tell me about how you run your hiring loop." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Story-mapped on F3: you run the loop, it is for backend roles, and there were about 40 interviews last year are the beats the quote states; tell them in your own words. Answer slot: the role's hiring line makes a probe on who decides likely. If you set the bar or made offer decisions, say how; if you did not, or the loop only assessed, say so plainly and describe the loop you run | F3 is your most direct evidence against a stated requirement; EXP because it tests what was actually yours |

### Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What does a staff engineer here decide that a manager should not overrule?" | It shows you are mapping the seam before arriving, and respects their authority |
| R2.2 | "What could a new manager do in the first month that would help the squads most?" | It is the reciprocity question for the peers in the room |
| R2.3 | "How do you and the squads agree what is committed and what is exploratory?" | It speaks to the product manager's stake and to the roadmap line |
| R2.4 | "What was the hardest reliability-versus-features decision recently, and how was it settled?" | It invites a real story and shows the trade-off interests you |
| R2.5 | "What would you want a new manager to learn first?" | It asks for guidance rather than reassurance, and tells you where the team hurts |

## Round 3 — Monday, VP Engineering, 30 minutes, "values and leadership philosophy"

The recruiter's own words document this as a values-style round. The company's published values are not in hand (see Sources), so the values cheat sheet is not in this pack; the VAL questions below stand on your own material and on the recruiter's description.

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes, stories, "what do you believe" | High. The skip-level prior leans strategy and composure, but the recruiter's description of this round moves values to the top | Map a story to each belief where one of your quoted sentences carries it; "we" for context, "I" for contribution |
| Pressure | Time-boxed answers, devil's advocate | Mid. The skip-level and executive prior includes Pressure, and 30 minutes forces short answers | Pause, restate, anchor in what you stated; hold through two follow-ups before conceding anything real |
| Case/Strategist | Altitude and judgment, "what do you need to know first" | Low to mid. The prior pairs it with Pressure for executives; with 30 minutes and a values brief there is room for a couple of items | Clarify before structuring; use the company's own vocabulary where you have it |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What is your leadership philosophy, in two minutes?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; "I run our hiring loop for backend roles — about 40 interviews last year" | One belief, one example. Choose a belief you actually hold; the pack has no source for your beliefs. Pair it with an example told in the quote's own terms: you pushed a reliability quarter through against roadmap pressure, or you run the hiring loop for backend roles. Describe what you did and let the VP draw the inference. Answer slot: which belief an example shows is your call; if no example fits a belief you hold, drop the example and keep the belief | The recruiter's description names leadership philosophy directly; F2 and F3 are the only quoted examples; VAL because it scores whether stated values match behavior |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F2: the reliability quarter, the push, the roadmap pressure and the 60% drop in on-call burden are the beats the quote states; tell them in your own words. Answer slot: if the pressure came from leadership and you told them something they did not want to hear, say what you said and how it landed; if the pressure came from elsewhere, or there was no such conversation, say so plainly and tell the quarter as the quote states it | A standing values probe, and F2 is the closest quoted candidate; VAL because it scores whether the hard truth actually landed |
| H3 | "Which of your instincts as a team lead of 6 would you have to unlearn to lead 11 across two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: if you can name an instinct, say it in your own words and what you would do differently; if you cannot yet, say so plainly and say what you would watch for. The quote carries the team of 6 and nothing about your instincts, so none is supplied | F1 is the scale step the VP will see first; JD because it scores the move from the listed scope, asked as a leadership question |
| H4 | "Larkfield is about 600 people in industrial IoT. What does that mean for how engineering should be run?" | CO | [generic] | Say plainly what you have not researched; the pack has no sourced facts about Larkfield's customers or strategy. Offer a question you would want answered first, then one principle you would apply regardless of size. Makes no claim about your past | The VP's altitude invites company-level thinking; the role description gives size and sector only, so CO stays generic until you add research |
| I1 | "Sixty seconds: why you over someone who has already managed managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year" | Hold-then-concede. Pause, restate. The plain acknowledgment, "I've never managed managers," then what your material carries in its own terms: 3 as a team lead of 6, and you run the hiring loop for backend roles. Let them draw the inference. Answer slot: if you have a reason you would be effective, say it in your own words from something you did; if you do not have one yet, say so plainly and say how you would learn it. Hold through two follow-ups by returning to the same sentences | F1 holds the stated limit and the objection is predictable at this altitude; JD because it scores fit against the listed scope, with Pressure's time box |
| I2 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause, restate, anchor in what you said: you pushed a reliability quarter through. Hold through two follow-ups by returning to that sentence. Concede specifically, in your own words, which parts were others'; if you do not know how the figure was counted, say so plainly. Never fold on the core claim just to restore harmony | F2 holds the number and the verb "pushed"; EXP because attribution is what a pressure interviewer is scoring |
| I3 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Pause, then say what you carry in the quote's own terms: 9 years in engineering, 3 as a team lead of 6. Answer slot: if there is something an internal candidate would not bring, say what, in your own words, from something you did; if you cannot say, say so plainly and say what you would do in your first weeks | A persona stem used at the skip-level; JD because it scores motivation and fit together (F1) |
| J1 | "Two squads can build only so much this year. How do you decide what they should not build, and what do you need to know first?" | CASE | [generic] | Clarify first: what the company is trying to achieve, what hardware and product are committing to, what has already been promised. Then segment by customer need and cost of delay, choose a rule, name the metric and the main risk. Makes no claim about your past | The VP's altitude is judgment under scarcity (F1, F6); CASE because it asks for structure on a live problem |
| J2 | "What would you measure, six months in, to know the two squads are healthy?" | CASE | [generic] | Name a small set of measures that cover delivery, reliability and the team, say what each would and would not tell you, and say which one you would defend least. Makes no claim about your past | The VP will care how a manager reads their own teams (F2, F3); CASE because it asks for a measurement design |

### Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What do you want engineering leaders here to be known for?" | It lets the VP state their philosophy, which is what this round is about |
| R3.2 | "Which of the company's stated values do people actually argue about?" | It shows interest in how values work in practice, and covers for the unresearched values page |
| R3.3 | "How does the company support someone growing into leading leads?" | It names the managers-of-managers step as a development question, not a defense (F1) |
| R3.4 | "Where is engineering leadership weakest today, and how would this role help?" | It treats the job as a problem to solve rather than a title to win |
| R3.5 | "What would make you hesitate about me after today?" | It gives the VP room to name the objection while you can still answer it |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before any bank was written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative the candidate stated, F1 | The plain acknowledgment F1 gives: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never owned a hardware-adjacent roadmap." No slot |
| Led two squads, or owned delivery for a team of 11 | Inflated form of F1 and F2 | F1's quote at its own scope: a team lead of 6. The limit is the pack's observation, not words for you: the material says a team of 6, not two squads. B4's slot stays inside the team of 6 |
| Owned hiring end to end, or decided who was hired | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says the loop for backend roles and about 40 interviews, not offers or headcount. G1's slot asks only whose decisions they were |
| Ran the roadmap trade-off, or the whole reliability programme | Inflated form of F2 and F6 | F2's quote at its own scope: you pushed a reliability quarter through against roadmap pressure. B3's and I2's slots stay inside that sentence |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Lead two squads building device-management services" | A1, A2, B1, B4, C2, E3, H3, I1, I3, J1 |
| "own delivery, hiring and growth for 11 engineers" (delivery) | A3, B3, B4, H2 |
| "own delivery, hiring and growth for 11 engineers" (hiring) | A4, E2, G1 |
| "own delivery, hiring and growth for 11 engineers" (growth) | F3 |
| "partner with hardware and product on roadmap" | A1, A3, B1, B2, D1, D3, F2, J1 |

## Sources

Provided documents: the role description and your background, both in your message. No dossier, CV, interviewer profile or assessment was provided.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Queries sent, all refused (the search permission was not granted; none was retried):

| Query | Outcome |
|---|---|
| Larkfield Systems values industrial IoT | refused |
| Larkfield Systems interview process engineering manager | refused |
| Larkfield Systems strategy news device management | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have fed a values cheat sheet for round 3, which the recruiter's own words document as values-style. Absent, so VAL questions rest on your material and `[generic]` scaffolds |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have checked the loop beyond what you told me. Persona weights rest on your schedule and the relationship priors, not on documented practice at this company |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have grounded the CO bank. H4 stays generic and no question rests on current strategy |
| 4. `{interviewer name} Larkfield Systems` | n/a | No name was given for any interviewer, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to run web searches, or the company's values page pasted → the values cheat sheet for round 3, with each published value mapped to a story from your material or a scaffold
- A strategy brief or recent news pasted, or searches permitted → the CO bank (H4 and parts of J1) becomes grounded in the company's current priorities
- A deeper research pass, if searching is permitted — up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on strategy, the likely loop at this company, and recent org context
- The full posting text → the role description here is a summary, and the six fit rows would quote the posting's own lines
- Your CV or bullets → more evidence for F1 to F6 beyond your four sentences, and some slot rows may upgrade
- Your answers to the answer slots in F1 to F6 → those rows regenerate, with your answers quoted in
- Interviewer names or profile links → an interviewer read, tuned persona weights, and reverse questions tied to each person's path
- The recruiter's notes on the panel and the VP round → focus areas and any pre-declared deliverable, which would add a graded-deliverable section
- A tuesday-dossier.md, if you have one → the objection to rehearse deepest would come from verified evidence, and each weak area would carry a constraint on how it may be positioned
