The web searches were refused, so this pack is built from what you gave me, with no outside research. I'm writing the pack now.
The prep pack is built and saved: 22 questions across seven personas. The four web searches I tried were all refused, so it uses only what you gave me.

**Where it rests on your inputs**
- Northwind's priorities and the bundling threat come from your research note, unverified. The Sources section lists the four refused searches.
- The JD is your highlights, not the full text. The interviewer read uses only Dan's profile as you described it.

**How it's built**
- **Persona weights:** Peer Evaluator and Data-Driven Prober come first, because Dan is a peer and calls himself "relentlessly data-driven." The Skeptic and Case personas follow, with the Pressure, Conversational and Values personas lighter.
- **Highest-ROI rehearsal:** C1 ("Which part of this role would you be weakest at on day one?"). Priya's notes say she has no sales-ops or quota-setting experience, and Dan works in exactly that area. The next drills are B1 and E2 on the ~$400M figure.
- **The pack is cautious with the notes:** Priya's notes say she "proposed" the store-surface change and that it was "credited with" the ARR uplift. The guidance keeps that wording. It also doesn't treat her annual volume targets as quotas.
- **Left out:** no values cheat sheet, since nothing in your inputs shows a values round. No prep triage, since prep time is unknown.

Saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-1-denied-aa0647d7/Northwind_Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`

The upgrade menu at the end of the file lists what would improve it.

Say the word and I'll play Dan on C1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for Priya to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind_Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer who reports to the same VP. **Format:** one 60-minute conversation.
**Built on:** your inputs only. Every web search was refused, so no outside research is in this pack. Company facts come from your research note and are unverified.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Types: **VAL** is behavioral or values alignment. **EXP** is a work-experience deep-dive. **JD** is role and requirement driven. **CO** is company and strategy knowledge. **CASE** is a live hypothetical problem.
- Answer guidance is scaffolding, not a script. Say only what you actually did, in your own words.
- Provenance labels: `[grounded]` traces to something you supplied. `[inferred]` is a derivation. `[generic]` is a role-family pattern with no claim about Northwind or you.
- An answer slot is an instruction for the interview, not a question for this chat.
- Start with C1. It is the highest-ROI rehearsal in the pack.

## Fit snapshot

Requirements are quoted from the JD highlights in your message. That is a summary, not the full JD text. Evidence is quoted from your notes on Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material carries strategy and ops work, not go-to-market, and the words stay at that scope: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD asks you to own GTM for new product lines, so expect a probe on taking an offering to market. If any of your work involved a go-to-market decision, say which one and what part was yours, in your own words. If none did, or it was not yours, say so plainly and stay with the strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The quote shows a proposal and a credited uplift. It does not show which stage of the customer relationship the change touched. Answer slot: the JD's land/adopt/expand/renew line makes a probe on where the uplift came from likely. If you know which stage the change touched, say so in your own words. If it did not touch one of those stages, or you do not know, say so plainly and stay with the proposal and the credit as stated |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The quote already names both tools, and a CV-level line with nothing inspected behind it draws a request to walk through an analysis. Lead with the tools in the quote's own terms: "I'm skilled in SQL and Tableau." Offer a walk-through only of an analysis you ran yourself |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the requirement says design, so expect a probe on how the partner relationship was set up. If any of that was yours to design, say which part and how you decided, in your own words. If you built the model only, or the design was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote reaches the requirement. Lead with it in its own terms: "I set annual volume targets with cross-org consensus." Expect a probe on how the consensus formed. Answer slot: if orgs disagreed and you moved them, say what each wanted and what moved. If there was no disagreement, or someone else built the consensus, say so plainly and stay with the targets |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | The quote reaches the requirement as everyday use. Your material shows use, not building or launching. Lead with the quote's own words: "I use AI tools daily." Answer slot: if probed on which tools and for what, say so in your own words. If the use is everyday work only, say so plainly |
| F7 | Sales-ops and quota-setting familiarity, a role-family expectation of a Sales Strategy peer, not in the JD highlights | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it has been stated. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. The pack does not equate the annual volume targets in F5 with quotas, and neither should the answer |

## Reading the interviewer

Public footprint: no search ran, so this read uses only the profile you supplied.

| Observation (source) | What it implies for you | Provenance |
|---|---|---|
| Self-describes as "relentlessly data-driven" — profile you supplied | Expect each number to be followed to its inputs. Rehearse B1, B2 and E2 to the second follow-up | [grounded] |
| Career spine in pricing and monetization — profile you supplied | Case and strategy questions likely arrive in pricing, packaging and unit-economics terms: D2, B5. Mirror his vocabulary, monetization and revenue, in the way F4's quote uses it: "built a partner-level revenue model used in carrier negotiations". Do not describe your work as pricing work | [grounded] |
| One early-stage-startup chapter — profile you supplied | Possible probes on pace and scrappiness against a large-company background. No sentence in your material is a startup story, so none is offered. R1 turns his chapter into a question for him | [grounded] |
| Peer, same VP — your message | He is pricing what you cost and contribute to his work. Prepare seam principles, not a claimed seam: A1, A4 | [grounded] |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy (a method, not a claim) |
|---|---|---|---|
| Peer Evaluator (bank A, 5) | Seam-splitting with Sales Strategy, credit, disagreement | Highest: the relationship prior for a peer. He reports to the same VP, so this is a close read of partnership fit | Reciprocity framing. Propose seam principles, not a seam. Any disagreement story rests on F5's quote or an answer slot |
| Data-Driven Prober (bank B, 5) | Walks the ARR figure, the revenue model and the SQL claim to their inputs | Highest: the peer prior plus "relentlessly data-driven" | Know what you can and cannot say about how each figure was counted. Name the weakest assumption you know of before he does. Say plainly when you do not know |
| Skeptic (bank C, 3) | Presses the missing sales-ops and quota-setting experience, partner-motion design, and why a B2B move | Medium: F7 and F4 are the gaps in the material, and a peer will test them collegially. The startup chapter adds a pace probe | Rehearse the single predictable objection (C1) until it is boring. Bridges come only from quoted adjacent work, and the limit is stated |
| Case / Strategist (bank D, 3) | Live problems on new-line GTM, bundling, and whitespace | Medium: the pricing and monetization spine tilts cases his way. A peer is less likely than a hiring manager to run a long case | Clarify, set the objective, segment, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| Pressure / Stress (bank E, 2) | Time-boxed "why you" and attribution probes | Low: nothing in the profile signals a stress style, but the 60-minute format invites at least one time-boxed question | Pause, restate, hold through two follow-ups, then concede specifically. Never concede the quoted core |
| Conversational / Rapport (bank F, 2) | The opening biography and a casual AI question | Medium for the opener, low for the rest. Casual questions here are still scored, and AI is a stated plus | A 90-second arc built only from quoted beats. Treat the AI question as scored |
| Values / Behavioral (bank G, 2) | Two behavioral prompts with the delivery a peer would use | Low: your input describes a single peer conversation, not a values round, and no published Northwind values were read. The themes come from standard persona stems and from his self-description | Selection scaffolds ending in the honest branch. Use "we" for context and "I" for contribution |

The values cheat sheet is not included. It needs a documented values-style round and the company's published values in hand, and neither exists in your inputs.

## Question banks

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between Sales Strategy and what you'd own, and what happens when we disagree?" | JD | [generic] | Say you do not yet know where the line sits and ask where it is drawn today. Then offer two principles as proposals to test: decisions that change a number the sales org is measured on get made jointly, and disputes about data start with looking at the data together. Ask what has gone wrong at this seam before. The question needs no claim about your past, so the guidance makes none | F7 and F5 make the seam the natural peer question, and F1's two-new-lines scope makes overlap likely. JD because it scores how the role is bounded, with peer delivery |
| A2 | "Tell me about a time you disagreed with a peer team over a number, and how it resolved." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5, at the quote's own beats: annual volume targets, set, with consensus across orgs. Tell those in your own words. Answer slot: the JD's cross-functional line makes a probe on where the orgs disagreed likely. If they did, say what each side wanted and what moved. If there was no disagreement, or the consensus was not yours to build, say so plainly and stay with the targets. If no disagreement comes to mind, say so, then give the nearest thing your material carries or how you would handle one | F5 is the evidence for cross-functional influence, and an open prompt cannot presuppose an event. VAL because it scores behavior with an equal, not a skill |
| A3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep to the quote's verb: you proposed the change, and the uplift was credited to it. Answer slot: if other teams built, shipped or measured the change, say what each did, in your own words. If you do not know, or it was not a multi-team effort, say so plainly and stay with the proposal. Then state your practice for naming others' contributions specifically | F2's quote is credit language, which is exactly the area a peer probes. VAL because the persona stem scores how you share credit |
| A4 | "What would you need from me in your first month, and what could you bring my team?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity first. Offer, as a proposal for future work, to build a shared view of whitespace across the product lines, since you are skilled in SQL and Tableau. Then ask for his view of where the funnel data lives and what has already been tried. State the ask as a question, not a demand | F3 supports the offer. The reciprocity question is the standard peer probe, scored on whether the hire lightens his load. JD because it tests how you would work in the role |
| A5 | "Northwind's three priorities pull against each other: enterprise expansion, the Compass launch, and profitability. Which would you protect first for a new line, and why?" | CO | [grounded] | Name your criteria before choosing. Choose, with reasons. Name the data that would change your answer, and concede that you lack internal numbers. Treat the priorities as your research note's, unverified, and do not present them as current fact | The three priorities come from your research note and no search could confirm them. CO because it tests thinking at the company's altitude. No claim about your past is made |

### B. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say it at the quote's scope: you proposed the change, and it was credited with a roughly $400M ARR uplift. Then four slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer slot: if you know how it was counted, say so. If you do not, say plainly that you do not and who would. Name the weakest assumption before he does | F2 holds the pack's one headline figure, and the profile signals every number gets probed. EXP because it tests attribution and honesty about counting |
| B2 | "Walk me through the revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4, at the quote's own beats: you built it, it was partner-level, and it was used in carrier negotiations. Do not claim who used it or what it achieved beyond that. Answer slot: his self-described data focus and the JD's analysis line make a probe on what went into the model and how it was tested likely. If you can say, do so in your own words. If you cannot, or it was not yours, say so plainly and stay with what you built | F4 is the only partner-related evidence and the likeliest walkthrough. EXP because it tests whether the claim survives scrutiny |
| B3 | "Tell me about an analysis you ran in SQL and Tableau that changed a decision." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold, because no quoted sentence carries an analysis story. Pick one where you wrote the query yourself and can state the question, the data pulled, and what happened next. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries or describe how you would approach one. If an analysis was yours end to end, offer to walk through it | F3 is a skills line with nothing inspected behind it, and the JD says independent analysis. JD because it scores the stated requirement |
| B4 | "A new product line has many accounts that bought it but few using it. What do you look at before deciding it's a GTM problem?" | CASE | [generic] | Clarify definitions first: what counts as bought and as using, over what time window. Then segment, state the hypotheses (GTM, product, pricing, data quality), name the first cut you would run and what result would rule a hypothesis out. Think aloud and state the weakest assumption in your own plan. No claim about your past is made | It tests the land-to-adopt step of the JD's whitespace line with a data-led peer. CASE because it is a live problem with no past presupposed |
| B5 | "Profitability is a stated priority. How would you decide whether a partner motion for a new line earns its cost? What would you measure?" | CASE | [generic] | Clarify the objective and the time horizon. Structure the costs and returns of a partner motion, then the metrics and the thresholds that would stop it. Concede what you would need from internal data. The priority comes from your research note, unverified. No claim about your past is made | The partner-motion requirement (F4) meets the profitability priority in his monetization language. CASE because it is a live problem, with JD content |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | **The highest-ROI rehearsal in this pack.** Hold only what the quotes carry. Say the acknowledgment: "I don't have classic sales-ops or quota-setting experience." Then the adjacent work at its own scope: "I set annual volume targets with cross-org consensus." Do not call those targets quotas. Then a ramp plan as a plan, not a past: what you would ask his team to walk you through in the first weeks and what you would read first. Follow-ups to rehearse, three levels deep: why not hire someone who already has it, what you would get wrong first, and how long until you are useful. Hold on what the quotes carry, concede the specific limit, and never fold on the core to restore harmony | F7 is the largest gap and he works in exactly this domain, so this question arrives in some form. JD because it scores the role's honest day-one fit. Skeptic delivery |
| C2 | "I don't see partner-motion design in your background. How would you handle the partner motion in this role?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." The pack's observation is that the material says model, not motion. Answer slot: if any part of how the relationship operated was yours to design, say which part and how you decided. If you built the model only, or design was not yours, say so plainly and stay with the model. Then your approach to designing one as a plan: who the partners are, what each side needs, how it is measured, and what already exists | F4 is a required experience in the JD with adjacent evidence only. JD because it scores a stated requirement and its gap |
| C3 | "You've spent nine years at a large consumer-tech company. Why Northwind, why a B2B data-infrastructure company, and why now?" | CO | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The reasons are yours, so this is a scaffold. Pick the one thing about Northwind's stated priorities in your research note (enterprise expansion, Compass, profitability, or the bundling threat) that genuinely pulled you, and say why. If none did, say so plainly. Keep the quote at its own scope when you describe your background. Mention no startup experience, because none is in your material | F1 is the move he will test, and the startup chapter in his profile adds a pace probe. CO because it tests homework and motivation consistency |

### D. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Take a new AI copilot like Compass, sold into existing enterprise accounts. Sketch the plan across land, adopt, expand and renew. What do you need to know first?" | JD | [grounded] | Clarify first: the buyer, the product's stage, what success means for the first year. Then segment accounts, lay out each stage with its main lever and its one metric, then risks. Challenge one premise respectfully, for example how the stages are defined. Your research note names Compass, but nothing confirms it is one of the two lines, so treat it as an example. No claim about your past is made | F1, F2 and F6 meet here. JD content with CASE delivery, because it scores the JD's own land/adopt/expand/renew line |
| D2 | "A much larger platform vendor starts bundling a similar capability into its suite. How does that change your GTM for a new line?" | CO | [grounded] | Clarify what is bundled, for whom, and on what terms. Then options across pricing, packaging, positioning and where not to compete, with the one you would pick and what would change your mind. Say what you would want to see in win and loss data first. The threat is from your research note, unverified. No claim about your past is made | The bundling threat is the stated competitive frame, and it lands in his pricing and packaging vocabulary. CO because it tests competitive thinking |
| D3 | "You're handed a table of accounts, products held, usage and renewal dates. How do you find the whitespace? What do you pull first?" | CASE | [generic] | State the unit of analysis, the definitions, and the first pull and the cut you would make. Describe how you would check the data before trusting it, and what result would send you back. If you use a past analysis as an example, it must be one you can walk through end to end. No claim about your past is made here | It tests the whitespace requirement and the SQL line in a live form. CASE with JD content, aimed at a data-driven peer |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus" and "No classic sales-ops or quota-setting experience." | Pause and restate. Give the two quoted facts at their own scope. Hold the position through two follow-ups. When pressed, concede specifically: "I don't have classic sales-ops or quota-setting experience." Never concede the quoted work to restore harmony | F4, F5 and F7 are what an internal candidate would be set against. JD because it scores fit. Pressure delivery |
| E2 | "That ARR number. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold on the quote's verb: you proposed the change. Answer slot: if others built, shipped or measured it, say what each did. If you do not know how the credit was assigned, say so plainly. Hold through two follow-ups by returning to the proposal, and never add to it. Concede specifically what you do not know | F2's figure plus a peer's incentive to test attribution makes this likely. EXP because it tests attribution honesty |

### F. Conversational / Rapport Builder (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with only the quote's beats: two years in strategy consulting at a top firm, then nine in product strategy and ops at a large consumer-tech company. Then why this role in your own words. Add no story, title or result the quote does not hold | F1 holds the arc. EXP because it is the CV walk, asked casually and scored |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it in the quote's terms: "I use AI tools daily." Answer slot: name which tools and for what tasks, in your own words. If it is everyday use rather than building, say so plainly. Then ask how he sees Compass being positioned | F6 supports the stated plus, and a casual question about a plus is still scored. JD because it tests a listed qualification |

### G. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold, because no quoted sentence carries this story. Pick a time with a named stake, a moment you did not fold, and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Standard persona stem. VAL because it scores behavior, and the JD's influence line (F5) is the reason it earns a place |
| G2 | "Tell me about a time the data told you something your stakeholders didn't want to hear." | VAL | [generic] | Selection scaffold: a decision, the data, who did not want to hear it, what you did and what happened. Say what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | His self-description is the theme source. VAL because it scores behavior under data pressure |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "own GTM strategy for two new product lines" | D1, D2, E1, A5 |
| "identify whitespace across land/adopt/expand/renew" | D1, D3, B4 |
| "run independent analysis in SQL and Tableau" | B3, B2, D3, A4 |
| "partner-motion design experience required" | C2, B5, B2 |
| "strong cross-functional influence" | A1, A2, A3, G1 |
| "AI experience a plus" | F2, D1 |
| Sales-ops and quota-setting familiarity (F7) | C1, A1, E1 |
| Headline figure (~$400M ARR uplift) | B1, E2, A3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've worked in pricing and monetization, with one early-stage startup chapter. What did that chapter change about how you approach new lines?" | Ties to his own path, and turns a pace probe into a peer conversation |
| R2 | "Where does the seam between Sales Strategy and this role sit today, and where has it been hardest to hold?" | Shows you plan for the seam instead of assuming it, and it is what he is pricing |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer |
| R4 | "How are quotas for new products set today, and where would an outside view of whitespace help?" | Meets the stated gap on the topic he owns, and offers help rather than a request |
| R5 | "How is success measured for the two new lines at the end of year one, and which numbers will we both be held to?" | Data-driven framing, and it surfaces the profitability priority |
| R6 | "Which two lines are in scope, and where does Compass sit among them?" | Settles the one fact the case questions assume, and reads as diligence |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Designed or owned a partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a revenue model used in negotiations, not a motion. C2's slot stays inside the model |
| Drove or delivered the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: you proposed the change, and it was credited with the uplift. E2's slot asks only what others did |
| Has quota-setting or sales-ops experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot, and no equating of F5's targets with it |
| Built or launched AI products | Inflated form of F6 | F6's quote at its own scope: "I use AI tools daily." The limit is the pack's observation: the material shows use, not building |

## Sources

Provided documents: your message (role, JD highlights, candidate summary, interviewer profile, research note). No dossier was present, so none was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have supplied published values by name for VAL themes. No values-style round is detected in your inputs, so section 10 stays out either way |
| 2. `Northwind Data interview process GTM` | unavailable | The search was refused. It would have documented loop structure. Your own words establish the one session, so persona weights rest on your relationship note |
| 3. `Northwind Data Compass AI copilot enterprise expansion strategy` | unavailable | The search was refused. It would have checked that your research note is current and fed the CO bank. A, D and B5 questions cite the note, unverified |
| 4. `Dan Kovac Northwind Data Director Sales Strategy` | unavailable | The search was refused. It would have supplied talks and writing for the interviewer read, which uses your supplied profile only |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | Your JD highlights fix the fit snapshot rows. They are a summary, so a full JD could still add requirements |

Searches sent, all refused: `Northwind Data company values principles`; `Northwind Data interview process strategy GTM`; `Northwind Data Compass AI copilot enterprise expansion strategy`; `Dan Kovac Northwind Data Director Sales Strategy`.

## Upgrade menu

- Search access, or a pasted values page, loop description and dated strategy brief → checks the research note's currency, upgrades A5, C3, D2 and B5 from unverified, and settles whether a values round exists
- Full JD text → turns the F1 to F6 requirement paraphrases into quotes and shows whether sales-ops or quota requirements are stated
- Which two product lines are in scope, and whether Compass is one → reweights D1 and R6
- Your answers to the answer slots in F1, F2, F4, F5 and F6 → upgrades those rows from discovery and transferability to story-mapped `[grounded]`. Say them outside a drill
- An inspectable artifact, such as the proposal behind the ARR credit or the revenue model's structure → can raise F2 and F4 above medium
- Dan's public talks or writing → his recurring themes become likely questions and a sharper R1
- Recruiter guidance → coverage assumed from round-type priors would become stated focus areas
- Prep time available → adds a prioritized prep triage
- Deeper research pass (once): up to 6 more searches and 2 more fetches, several more minutes → strategy brief, interviewer footprint, loop reports and org context
- A `tuesday-dossier.md` from an earlier underwriting pass → would supply verified evidence and absolute prohibited claims
