Web search was refused, so I'm building the three-round pack from what you gave me. Company facts will be labelled as missing, not filled in.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-6-denied-f124d096/larkfield-systems_engineering-manager_interview_pack.md`.

It covers all three rounds together. It holds a shared fit snapshot, then a mini-pack per round with its own persona weights, 9–11 questions and reverse questions. The rounds are the Tuesday hiring manager, the Thursday panel and the Monday VP.

Web search was refused, so I could not research Larkfield. The pack contains no company facts beyond your role summary. I labelled the company-knowledge and strategy questions generic, and I left out the values cheat sheet. The pack records the three refused searches.

The pack's top prep priority is your hardware-roadmap and managing-managers gaps. You told me you've never done either, so I coached you to say that plainly and then give a plan for learning it. That is questions A1, A2, K1 and K3.

Some rows (growth, product partnership, leading more than one team) are answer slots. Your four sentences don't show them, so I didn't write answers for you. Say what's true for you in your own words, including "that wasn't mine."

I can play the Skeptic on A1, the question the pack names as your highest-ROI prep, or run any other drill you pick.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job posting and your CV, or say skip? The posting would show whether the two squads have their own leads, and the CV would give me more of your own sentences to build answers from.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack (loop mode): Engineering Manager, Larkfield Systems

Candidate: Yusuf. Three scheduled rounds, prepared together.

| Round | When | Who | Format |
|---|---|---|---|
| 1 | Tuesday | Director of Engineering, your would-be boss | 45 minutes, hiring manager |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 minutes, panel |
| 3 | The following Monday | VP Engineering | 30 minutes, "values and leadership philosophy" per the recruiter |

Interviewer names are not known, so there is no interviewer read. Built from your role summary and four sentences about yourself. No web research ran, so nothing here asserts a fact about Larkfield beyond what you wrote.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words and rehearse only what you actually did. Where guidance says answer slot, it is an instruction for the interview, and either honest branch is a good answer.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows values and leadership philosophy, not generic virtue |
| EXP | Whether claims about your work survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

You have about two weeks, three rounds. Do these in order; everything else is insurance.

1. Before Tuesday: rehearse A1 and A2 until they are boring, then K1 and K3 (same objection, harder delivery). This is the highest-ROI prep in the pack.
2. Before Tuesday: write your own answers to the slots on F1, F4 and F6, even if the honest answer is that it was not yours. Every round touches them.
3. Before Thursday: E1, E2 and K2, the two numbers on your sentences (60 percent, about 40 interviews) and what was yours.
4. Before Monday: J1 and J4, your leadership philosophy and what you hire for, in your own words.
5. Pick two reverse questions per round and say them aloud once.

## Fit snapshot (shared across rounds)

Requirements are quoted from the role summary you gave me.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role summary, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says one team of 6 for 3 of your 9 years, in payments, and the words stay at that scope: "I've been a team lead of 6 for 3 of my 9 years in engineering." It does not show two squads or device-management work. Answer slot: the two-squad line makes a probe on leading beyond one team likely. If any of your work spanned more than your team of 6, say what, in your own words; if it did not, say so plainly and stay with the team of 6 |
| F2 | "own delivery, hiring and growth for 11 engineers" (hiring) — role summary, your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap on the hiring part, but a claim with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you run the hiring loop for backend roles. The figure raises the defend-the-number slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words. The sentence does not say who conducted the interviews or who decided |
| F3 | "own delivery, hiring and growth for 11 engineers" (delivery) — role summary, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote carries a fight to protect reliability work and a result that followed it, not ownership of delivery across a roadmap. Words: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." Answer slot: the delivery line makes a probe on how you handle delivery commitments likely. If any commitments were yours to set or keep, say which and how you handled them, in your own words; if delivery was not yours to own, say so plainly and stay with the reliability quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth) — role summary, your message | none given | none | [grounded] | discovery | Strong evidence would be a named person you developed and what you did; your material is silent on it. Answer slot: the growth line makes a probe likely. If you coached, promoted or developed anyone, say what you did, in your own words; if growth conversations were not part of your lead role, say so plainly and stay with the team of 6 |
| F5 | "partner with hardware and product on roadmap" (hardware) — role summary, your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | low | [inferred] | discovery | Your sentence says you have not owned a hardware-adjacent roadmap; it does not say whether you have worked alongside hardware people short of owning one. Words for the part you stated: "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked alongside hardware or device people, say what and how, in your own words; if you have not, say so plainly and move to how you would learn it, as a plan |
| F6 | "partner with hardware and product on roadmap" (product) — role summary, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote touches roadmap pressure and says nothing about who applied it or whether product was a partner. Words: the quote at its own scope. Answer slot: if product people were part of that quarter, say what was discussed and what you did, in your own words; if the pressure came from elsewhere, or no product partner was involved, say so plainly and stay with the quarter |

Reading of the table: no requirement in the role summary is a term such as location, schedule, pay or travel, so no row is a hard gate. The summary does not say whether the two squads have their own leads; the reverse questions ask.

## Round 1: Tuesday, Director of Engineering (hiring manager, 45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the biggest gaps | Highest. Hiring-manager prior is Case plus Skeptic; your own message names two gaps (managers, hardware roadmap), which is what a Skeptic aims at | Rehearse the one predictable objection until boring; limit named first; ramp as a plan |
| Case/Strategist | Live problems from the actual role | High. Same prior; the role's duties give ready material for problems | Clarify, structure, think aloud, challenge one premise |
| Conversational | Opening biography and casual questions | Low to medium. 45 minutes leaves room for one warm opener; nothing says the style | A 90-second arc; treat casual questions as scored |

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI rehearsal in this pack. Lead with the limit your sentence carries, once and plainly: "I've never owned a hardware-adjacent roadmap." Then a plan, not a past: the first things you would learn about the hardware roadmap and who you would ask, in your own words. Hold through two follow-ups by returning to the limit and the plan, never by adding hardware experience. If pushed, concede specifically: "That is a gap, and this is how I would close it." If managers come up, the sentence is also yours: "I've never managed managers." | F5 is the role's thinnest row and the likeliest place to be pressed, so this arrives in some form. JD because it scores the roadmap line; Skeptic is the delivery |
| A2 | "I don't see hardware-adjacent roadmap work in your background — how would you handle the hardware side of this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Acknowledge in the sentence's own words: "I've never owned a hardware-adjacent roadmap." Then the how, as a plan: what you would ask hardware first, what you would not commit to until you understood it, who you would learn from, in your own words. Answer slot: the role pairs you with hardware, so expect a probe on working alongside hardware people short of owning their roadmap. If you have, say what and how; if you have not, say so plainly and stay with the plan | F5's partnership half, which your sentence does not settle. JD because it scores the hardware line |
| A3 | "Why leave a payments company for industrial IoT, and why now?" | CO | [generic] | The reason is yours and the pack has none to give: one or two sentences in your own words, then stop. The only employer facts this pack holds are the role summary's, "industrial IoT, ~600 people" and its three duties; research on Larkfield did not run, so anything else you say about the company should come from what you have read or been told. One reason you can defend through a follow-up beats three you cannot. If part of the reason is wanting to lead more people, say so plainly | F1 is the move being explained, and motivation consistency is what this persona scores. CO because it tests homework; generic because no research ran |
| A4 | "Walk me through the reliability quarter — what pressure were you pushing against, and how did you get it through?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F3, with only the beats the sentence states: a reliability quarter, you pushed it through, against roadmap pressure, and the on-call burden dropped 60% after. Tell them in your own words. Answer slot: the question asks how you got it through. If specific moves were yours, say which and what you did; if there was no negotiation, or it was not yours alone, say so plainly and stay with the quarter and the drop | F3 is your one stand-out story and the likeliest to be walked in detail. EXP because it tests what was actually yours |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two squads share one device fleet. One squad's backlog is full of customer requests; the other is behind on a platform migration. You have one week. Where does your attention go?" | CASE | [generic] | Makes no claim about your past. Clarify first: what each squad has committed and to whom, what slips and who feels it, what each squad's people say. Then objective, options, the criterion you decide by, metrics, risks. Say the structure aloud. Challenge one premise politely, such as whether it is really a one-week decision | F1's two-squad line is what this case tests. CASE because it is a live problem; JD content |
| B2 | "Hardware tells you a firmware release will slip by a month, and your squads' next release depends on it. What do you do this week?" | CASE | [generic] | Makes no claim about your past. Clarify with hardware first: what exactly slips, what is firm, which of your commitments depend on it. Then options, who tells product and when, what you would decide today versus wait on. Say what you do not know about hardware release processes rather than pretending. If asked whether you have faced this, answer from your own experience, or say plainly you have not | F5 is the thinnest row, so a hardware-side problem is likely. CASE because it is hypothetical; JD content |
| B3 | "Product wants a feature for a large customer that would cost one squad its whole quarter. How do you handle the conversation?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure first: what product needs and by when, what the quarter protects, the options between yes and no, what you would put in writing. The reliability quarter is the one stated instance of holding a priority against roadmap pressure; if you use it, say only what the sentence says. Answer slot: if product was the other side of that tension, say how it resolved and what part was yours; if not, say so plainly and answer as a plan | F6 is where product partnership is thinnest. CASE because it is a decision under tension; JD content |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with only the beats the sentence states: 9 years in engineering, 3 as a team lead of 6, now at a payments company. The turn to this role is your reason, in your own words; the pack has none to supply. End on the role, not on your history | F1 is the spine of the arc. EXP because it tests what the career line actually shows |
| C2 | "How do you run the hiring loop for backend roles?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Beats the sentence states: you run the loop for backend roles, with about 40 interviews last year. Answer slot: the role's hiring line makes a probe on how the loop works likely. If you designed or changed parts of it, say which and why; if the loop was set before you or by others, say so plainly and describe how you run your part | F2 is your strongest row, so ask for it casually. EXP because it tests what you actually do |

### Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Do the two squads have their own leads, or would I manage the 11 engineers directly?" | The role summary does not say, and the answer tells you whether the managers gap is live |
| R1.2 | "What does a good first 90 days look like for this role, from where you sit?" | Lets your would-be boss define success; surfaces how much hardware roadmap ownership they expect early |
| R1.3 | "Where are the two squads strongest and weakest on delivery today?" | Moves from interview to problem-solving with the person you would work for |
| R1.4 | "How do the hardware and product roadmaps get reconciled today, and where does it hurt?" | Probes your gap by asking, instead of pretending to know |
| R1.5 | "How would you want me to disagree with you when I think a roadmap call is wrong?" | Shows how you would work with a boss; asks for their style rather than asserting yours |
| R1.6 | "What would make you hesitate about my background, and can I address it now?" | Invites the objection live while you can still answer it |

## Round 2: Thursday, panel of two staff engineers and a product manager (60 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting, "what would you need from us", credit and disagreement | Highest. Panel rule: blend each member's top two. Staff engineers and a product partner all price what you add to their work | Reciprocity framing; seam principles, not a claimed seam |
| Data-Driven Prober | Inputs, denominators, what was yours | High. Staff engineers are the technical-depth relationship; your two figures are magnet targets | Know what you can and cannot say about each figure; say plainly when you do not know |
| Values/Behavioral | Scenario probes, STAR-shaped | Medium. The product manager is a cross-functional seat, which this persona leads; the VP round carries the main values load | Stories only where a sentence of yours carries one; selection scaffold otherwise |
| Conversational | Casual and rapport-based, including the reverse-question slot | Low. Weighted by the cross-functional seat only; roles within the panel are assumed, since names and titles are unknown | Treat the casual question as scored |

### Bank D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side — where's the seam between engineering and product, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Offer seam principles instead of claiming a seam you do not know: who decides what, how disagreements escalate, what gets written down. If you use the reliability quarter, say only what the sentence says. Answer slot: if the roadmap pressure came from product, say how you resolved it and what part was yours; if it came from elsewhere, or was not resolved by talking, say so plainly and stay with the quarter and the drop | F6; JD because it scores the product partnership line |
| D2 | "What would you need from us on day one, and what could you do for us?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Reciprocity: what you need is to hear where each squad's pain is. What you offer is stated at its scope: you run a hiring loop for backend roles, and you can help with hiring. Leave the offer there, in your own words | F2 is the one thing you can offer a staff engineer concretely. JD because it scores the partnership line |
| D3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say "we" for context and "I" for your contribution. Selection scaffold: pick a time work spanned teams and credit mattered, with a named stake, what you did about it, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem from the Peer Evaluator; generic because no sentence of yours carries a credit story |
| D4 | "A staff engineer thinks one squad's technical direction is wrong, and you have already committed the plan to product. Walk us through what you do." | CASE | [generic] | Makes no claim about your past. Clarify what the staff engineer sees and what is at stake, separate the technical question from the commitment, say what you would decide today and what you would take back to product. Name what you would need from the staff engineers to decide well | F1's two-squad span; CASE because it is a live problem with the staff engineers in the room |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how that 60 percent was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The four defend-the-number slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. The sentence says the drop came after your push, not because of it; do not claim the cause. "I don't know exactly how it was counted" is an honest branch if true | F3's headline figure; EXP because it tests attribution |
| E2 | "About 40 interviews last year — how were those counted, and how many were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | The sentence does not say whether the 40 were interviews you conducted, ran through the loop, or the team's total. Say the smaller reading unless you know it is larger. Slots, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours | F2's figure. EXP because the question is attribution |
| E3 | "In this role you would own delivery for 11 engineers. How do you measure whether a squad is delivering?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: if you have used delivery measures in your lead role, say which and what each counted, in your own words; if you have not tracked delivery that way, say so plainly and stay with the one measure your material carries, the on-call burden. Do not describe a measure you did not track | F3's thin bridge, rehearsed so the honest answer is ready. JD because it scores the delivery line |

### Bank G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer need and an internal measure pulled apart, with a named stake, what you chose, how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for the cross-functional seat; no sentence of yours carries a customer story, so it is generic |
| G2 | "Tell me about a time you helped someone on your team grow." | VAL | [generic] | Selection scaffold: a named person (no name needed), what they could do before and after, what you did, how you know. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is silent; the role's growth line raises this. Generic because no quote carries a story |

### Bank H: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So — what does a normal week look like for you now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | The sentence states a team lead of 6 at a payments company. What fills a week is yours to say from your actual week; the pack supplies none of it. Keep it to what you do, in your own words | F1; EXP because it tests whether your day matches your title |
| H2 | "What would you want to ask the three of us?" | JD | [generic] | This is the reverse-question slot and it is scored. Never answer "I think you've covered everything". Ask each person one question from the list below | A persona counter-strategy; generic because it makes no claim |

### Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | To the staff engineers: "Which technical debt in the device-management services would you most want a manager to protect time for?" | Shows you would protect engineering time; hands them the floor on their expertise |
| R2.2 | To the staff engineers: "How do decisions get made when two squads disagree on a design?" | Tests the seam before you inherit it |
| R2.3 | To the product manager: "How does the roadmap get built today, and what do you need from engineering that you do not get?" | Asks for their pain rather than pitching |
| R2.4 | Reciprocity, to all: "What could a new manager do in their first month that would genuinely help your work?" | Turns peers into partners and tells you what they actually need |
| R2.5 | To all: "What would you most like to change about how engineering, product and hardware work together?" | Surfaces the cross-team problem you would be hired to help with |
| R2.6 | To the staff engineers: "How are staff engineers involved in hiring and growth for the squads?" | Ties to F2 and gives you their stake in both |

## Round 3: Monday, VP Engineering (30 minutes, values and leadership philosophy)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes on how you lead | Highest. The recruiter's own words name the round "values and leadership philosophy", which a values-style round by the pack's definition | Stories only where a sentence carries one; a philosophy in your own words |
| Pressure | Time-boxed challenges, composure | High. Skip-level and executive prior; your two stated gaps are what a short, hard question aims at | Pause, restate, hold two follow-ups, concede specifically |
| Case/Strategist | Strategy-flavoured structure | Low. The prior is strategy-heavy, but 30 minutes on philosophy leaves little room | Clarify first; say what you do not know |

No section for the company's published values is included: the values page was not read.

### Bank J: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What's your leadership philosophy, and where did it come from?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your philosophy is yours; the pack will not write it. Say it in your own words, in a few sentences. The reliability quarter is the one sentence of yours that carries a stand; if you use it as an origin, say only what the sentence says. Answer slot: if the philosophy came from a specific experience, say which; if it came from elsewhere, or you cannot name one, say so plainly | The recruiter's own words raise this question. VAL because it scores leadership philosophy; F3 is the only story available |
| J2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The sentence says you pushed against roadmap pressure; it does not say a truth was told to leadership or how it landed. Answer slot: if the quarter involved telling someone senior something unwelcome, say what and how it landed; if not, say so plainly and give the nearest thing your material carries, or how you would handle it | A stem from the Values persona; F3 is the nearest story and the guidance stays inside it |
| J3 | "You'd go from leading a team of 6 to leading 11 engineers across two squads. What changes in how you lead?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | The sentence says you lead a team of 6. What changes is a plan, in your own words: two things you would do differently and one you would keep. Answer slot: if you have seen what changes with scale from your own experience, say where; if you have not led beyond 6, say so plainly: "I've led a team of 6." | F1; VAL because it scores how you lead |
| J4 | "What do you look for when you hire an engineer?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | What you look for is yours to say; the pack supplies no criteria. The sentence states you run the loop for backend roles. Answer slot: if you set those criteria, say how you decided them; if they were set before you or by others, say so plainly and describe how you apply them | The role's hiring line raises it; F2 is your strongest row |

### Bank K: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Sixty seconds: why you over someone who has already managed managers?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause, restate. Hold only what the sentences carry: a team lead of 6 for 3 of 9 years, you run a hiring loop for backend roles, and the reliability result in F3 if you want a third beat. Concede specifically: "I've never managed managers." Hold through two follow-ups by returning to those beats, never by adding to them | F1 and F5. JD because it scores fit for the role; Pressure is the delivery |
| K2 | "That result — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold what the sentence states: you pushed the quarter through, and the burden dropped after. Do not claim the whole drop. Answer slot: which part was yours, in your own words; if you do not know how much of the drop was the quarter, say so plainly | F3. EXP because it is the attribution probe |
| K3 | "You're coming from payments. Why should a devices business trust you with its roadmap?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap." | Acknowledge in your own words: "I've never owned a hardware-adjacent roadmap." Then the plan for earning trust: what you would learn first, who you would ask, what you would not commit to yet. Hold the plan through two follow-ups; never claim device experience | F1 and F5. JD because it scores the roadmap line |

### Bank L: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "You join and find the two squads disagreeing about priorities. What do you do in your first 30 days?" | CASE | [generic] | Makes no claim about your past. Listen first: what each squad believes, what is committed, who is affected. Then objective, a decision rule, what you would change in 30 days versus wait on. Say what you do not know about the company rather than guessing | F1's two-squad line; CASE because it is a live problem |
| L2 | "What do you know about us, and what would you want to learn before day one?" | CO | [generic] | Say only what you have read or been told yourself; the pack holds no research on Larkfield. Name what you would want to learn and from whom. Naming what you do not know is the honest answer | Research did not run, so the question is generic. CO because it tests homework |

### Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does leadership look like here when it is working — what would you point to?" | Invites the VP to define the values in their own words |
| R3.2 | "Which value is hardest to hold when delivery pressure is on?" | Probes the values with a real trade-off |
| R3.3 | "What would you want this role to have changed in a year?" | Shows you think in outcomes at the VP's altitude |
| R3.4 | "How does engineering leadership here decide when reliability work beats roadmap work?" | Speaks to a trade-off the VP owns |
| R3.5 | "What would you want to see from a new manager of two squads in the first six months?" | Asks for expectations directly |
| R3.6 | "What did you learn about leading that you wish you had known earlier?" | Rapport with a senior person; invites a story instead of a pitch |

## Requirement coverage

| Requirement (role summary) | Questions |
|---|---|
| "Lead two squads building device-management services" | A1, B1, D4, J3, L1 |
| "own delivery, hiring and growth for 11 engineers" (delivery) | A4, B1, B3, E3 |
| "own delivery, hiring and growth for 11 engineers" (hiring) | C2, E2, J4 |
| "own delivery, hiring and growth for 11 engineers" (growth) | G2 |
| "partner with hardware and product on roadmap" (hardware) | A1, A2, B2, K3 |
| "partner with hardware and product on roadmap" (product) | B3, D1 |
| Defend-the-number, 60 percent | A4, E1, K2 |
| Defend-the-number, about 40 interviews | C2, E2 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or owned two squads, or an organisation of 11 | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation: your material says one team of 6, not two squads |
| Has managed managers | Negative you stated, in F5's evidence | The plain acknowledgment: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, in F5's evidence | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot |
| Reduced on-call burden by 60 percent, or caused the drop | Inflated form of F3: the sentence says the drop came after your push | F3's quote at its own scope. The limit is the pack's observation: your sentence says after, not because |
| Hired about 40 engineers, personally conducted 40 interviews, or made the hiring decisions | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the sentence says you run the loop and gives a count of interviews, not who conducted them or decided |
| Owned the roadmap, or set product priorities | Inflated form of F3 and F6 | F3's quote at its own scope: "pushed a reliability quarter through against roadmap pressure". The limit is the pack's observation: the sentence says pushed through, not decided or owned |

## Sources

Provided documents: your message, containing the role summary and four sentences about you. No tuesday-dossier.md was present. The loop structure comes from your own and the recruiter's words, which name each round's interviewers and format, so no archetype fallback applies.

Searches sent (all three refused, none returned results):

- "Larkfield Systems values industrial IoT": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems strategy news device management": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The values cheat sheet for the Monday round would have been built from the official names; it is dropped |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Round formats beyond what you told me; persona weights rest on your own description |
| 3. `Larkfield Systems strategy` / recent news | unavailable | CO and CASE questions would have used current priorities; A3 and L2 are generic instead |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so there was no query to form |
| 5. representative `Engineering Manager` JD | unavailable | Search was refused, so no fuller requirement list was fetched; the fit snapshot rests on the role summary alone |

## Upgrade menu

- Full job description text → F1 to F6 requirements become full quoted lines; may show whether the squads have their own leads and whether any requirement is a hard gate
- Your CV → more verbatim evidence for F1, F3, F4 and F6, and stories for growth and product partnership where F4 and F6 are silent
- Your own words on the slots in F1, F4 and F6 (pasted in this conversation) → those three rows regenerate with your sentences quoted
- Larkfield's values page, pasted → the values cheat sheet for the Monday round, and VAL questions mapped to the published names
- A short pasted strategy summary or recent news → A3, L1 and L2 stop being generic
- The interviewers' names and titles → an interviewer read, persona weights from public footprint, and reverse questions tied to their paths
- The recruiter's prep notes → whether any round carries a pre-declared deliverable or exercise
- A tuesday-dossier.md from an earlier fit assessment → a pre-graded evidence map, a ready-made list of prohibited claims, and the objection the underwriter judged worth rehearsing most
