Searches were denied, so I'm building the pack from your JD and background only. I'm saving it now.
I'll make those fixes with the Edit tool instead.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-2-denied-f87d2bc1/atlas-freight_operations-manager_interview_pack.md`. It has 23 questions across seven interviewer styles. Each question comes with answer guidance, a fit snapshot against the JD, a coverage table, reverse questions and a "not coached" list.

- **No company research:** My three web searches were refused, so nothing in the pack is specific to Atlas Freight. Those parts are labeled generic, and the pack says so.
- **Built for a hiring-manager round:** You didn't say who you're meeting, so I assumed that round. The persona weights lean on that assumption and will shift if it's wrong.
- **Highest-ROI prep (B1):** The JD says you'd lead 12 supervisors and you currently lead 3. Rehearse a plain concession and a plan for the larger span.
- **Power BI:** You've said you've never used it, so the pack gives you one honest sentence and a learning plan, not a bridge.
- **Your answers matter most in a few places:** Your background gives no details on the surge plan or the 40% figure, and doesn't say whether you've worked with terminals. Those answers are left as slots for you to fill in your own words. I haven't invented anything for you.

Say the word and I'll play the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Who are you meeting: your future manager, a peer, someone senior, or a recruiter? If the recruiter gave you any focus areas, include those too.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview pack: Operations Manager, Atlas Freight

Interviewer: not known. Round type: not stated, so this pack is built for a hiring-manager round. If that is wrong, the persona weights are the part that changes.

Research did not run (search permission was refused), so everything about Atlas itself is `[generic]` and the Sources section says exactly what was and was not available.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only say what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether the claims on your background survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

Sized to the one week you have. Do these in order; everything else is insurance.

1. B1 and its follow-ups, aloud, until the concession sentence is boring. This is the highest-ROI prep in the pack.
2. The Power BI answer (B2, B4, D3): one plain sentence, then a plan for learning it.
3. The 40% figure (C1, D2): how it was counted, and which part was yours.
4. A1 and A2 aloud: structure only, think aloud, clarify first.
5. Find three things about Atlas you can verify yourself (H2), because this pack could not research them.

Everything else is insurance.

## Fit snapshot

The JD line "build reporting in Excel/Power BI" is split into two rows (F4 and F5) because the evidence for each is of different strength.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows shift management and a surge plan at "the site", not terminal operations and not four sites, and the words stay at that scope: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's four-site line makes a probe on terminal work likely. If any of your work touched terminal operations, say how, in your own words; if it did not, say so plainly and return to the shift management you do |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | The quotes carry a mis-pick figure and a surge plan, not on-time performance or cost-per-shipment, and nothing inspected sits behind either. Words at that scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names two measures, so a probe on them is likely. If you tracked on-time performance or cost per shipment anywhere, say what was counted and how, in your own words; if you did not, or it was not yours, say so plainly and return to the mis-pick figure |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote reaches leading supervisors at three, and the JD says twelve. That difference is the pack's observation, not words for you. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: describe how you lead the supervisors you have today, in your own words; if part of what the probe asks is not something you have done, say so plainly and stay with the three |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel, never used Power BI" — your message | low | [inferred] | discovery | A skill in Excel is not reporting built, and the material does not show whether any was. Answer slot: if you built reports in Excel, say what they showed and who used them, in your own words; if you used Excel for your own analysis only, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD | "solid Excel, never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. The JD's slash does not say whether either tool meets the requirement; reverse question 2 asks. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | The quotes give seven years in operations and a current shift-manager role, and the material does not show how many of the seven years carried people reporting to you. Answer slot: say what the seven years covered, role by role, in your own words; if part of that time was in other kinds of roles, say so plainly and name them |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but nothing inspected behind it (the certificate would be), so expect a probe on where you have used it. Lead with it in the quote's own terms: "I'm green belt certified." the H3 question below holds the slot |

## Persona table

No loop source establishes this company's loop, so the fallback archetype is Generic (screen, hiring manager, panel) with flat tilt, and persona weights rest on the hiring-manager relationship prior alone. That is noticeably weaker than weights built from a known interviewer.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the role: diagnose a slip, break down a cost, plan a start | High, 5 questions. Hiring-manager prior; the JD's named measures (F2) and four sites (F1) invite live problems | Clarify, then structure, then metrics and risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of the gaps: scale, terminals, Power BI, why now | High, 5 questions. Same prior; the snapshot shows gaps at F1, F3, F5 | Rehearse the most predictable objection (B1) until it is boring; concede the limit plainly; return to what you stated |
| C. Data-Driven Prober | Line-by-line questions on the 40% and the surge plan | Mid, 3 questions. One headline figure in the material (F2) | Know what you can say about how the figure was counted and say plainly where you do not know; name the weakest assumption before they do |
| D. Pressure | Time-boxed, devil's-advocate on the gaps | Mid, 3 questions. Composure is tested where the gaps are (F3, F5, F6) | Pause, restate, anchor in what you stated, hold through two follow-ups, concede only what is true |
| H. Conversational | Friendly opener, casual questions about the Lean plus and why Atlas | Mid, 3 questions. Lower prior in this round; kept at mid because F7 and the why-Atlas question can arrive casually | A short arc for the opener from your own sentences; treat casual questions as scored |
| E. Values / Behavioral | Scenario probes on behavior | Low, 2 questions. No values-style round is detected: no loop source, and the Generic fallback reads no | Choose a story with a named stake and an intact relationship; where none comes to mind, say so |
| G. Peer Evaluator | Seam and credit questions between teams | Low, 2 questions. Only if a peer sits in the loop | Offer seam principles rather than claiming to know the seam; show spine and tact together |

## Question banks

Highest-ROI prep: B1. It is where the JD's twelve and your quote's three differ most plainly, so a probe on it is the likeliest in the pack.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one of your four terminals has slipped over the last month. What do you need to know first, and how do you find the cause?" | CASE | [generic] | Clarify first: how on-time is defined and measured, since when, one lane or customer or the whole site. Then split the miss into stages and look at the biggest bucket first; check by lane, shift and day. Name the metric you would watch and the check that stops it slipping back. Challenge one premise, such as whether the measure itself changed. It asks for no claim about your past, so the guidance makes none | F2's requirement is a named measure, so it arrives as a live problem. CASE because it scores structure, not a story |
| A2 | "Cost per shipment has risen for two quarters while volume is flat. How do you break it down?" | CASE | [generic] | Define what is inside the cost first. Compare by site, lane and shift, find the largest mover, and separate what the terminal controls from what it does not. Propose one test before any large change, and name the risk: cutting cost that costs you on-time. Makes no claim about your past | The second measure in F2's requirement. CASE because the answer is a structure |
| A3 | "You start Monday with four sites and twelve supervisors you have not met. What are your first thirty days?" | CASE | [generic] | Sequence it: see each site before changing anything, meet each supervisor one to one, agree the measures and baseline, then set a reporting rhythm. Say what you would hold off changing, and why. A plan, not a past, so it claims nothing | F1 and F3 together are the scale step the JD asks for. CASE because it is a live plan |
| A4 | "Peak volume lands on all four terminals the same week and one is short of people. How do you decide where the people go?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure it: volume and promise at each site, what can flex, what you will not compromise, who you tell. You may anchor with the quote's own words, "I ran the site's peak-season surge plan two years running", and then say the difference yourself: the quote is the site's plan, and the question has four terminals. Say the rest as a plan | F1 and F2 both lean on the surge plan, and the question tests whether it scales past it. CASE because it is a live allocation |
| A5 | "Pick the three numbers you would put on a daily view across four terminals. Why those three?" | CASE | [generic] | Start from the two measures the JD names, on-time performance and cost-per-shipment, and add one leading indicator you can defend. For each, say the decision it drives and how often you would look. Say what you would start with and what you would learn. Makes no claim about your past | F4's requirement is reporting. CASE because it scores structure and judgment, not tool skill |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your team today is three supervisors. This role has twelve, across four sites. What changes?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. The limit first, said by you before it is asked: "I'm currently a senior shift manager over 3 supervisors, and twelve across four sites is a bigger span than that." Concession wording: "Twelve is a bigger span than the three I lead today, and I would plan for that." Answer slot: describe how you lead the supervisors you have today, in your own words, and what you would expect to change at a larger number; if part of that is not yet something you have done, say so plainly and stay with the three. Follow-ups to rehearse, each held by returning to the quote and never by adding to it: "What breaks first?" (answer as a plan, using the A3 shape); "Have you led anyone beyond your current three?" (if you have, say when, how many and what part was yours; if not, say so plainly and return to the three); "Why not hire someone who already has twelve?" (concede the step, then the plan) | F3 is the one place a JD number and a quote differ directly, and F1 adds the four-site step. JD because it scores a stated requirement. Deepest rehearsal because the objection is predictable and the material is thinnest exactly there |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Pick one you can say honestly. Your material gives two candidates: Power BI and the larger scale. For Power BI the words are plain: "I've never used Power BI." Then a plan for closing it in the first thirty days, said as a plan. Do not claim a tool you have not used, or a comfort you have not shown | F5 is a gap you stated, and F1 and F3 are the scale step. JD because it scores the listed job including its gaps |
| B3 | "I don't see terminal operations in your background. How would you handle that side of this role?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops" | Words at the quotes' scope: "I'm currently a senior shift manager over 3 supervisors, with 7 years in warehouse and distribution ops." Answer slot: the JD's terminal line makes this probe likely. If any of your work touched terminal operations, say how, in your own words; if it was warehouse and distribution work only, say so plainly and move to how you would learn the terminal side in your first thirty days | F1 is the requirement where the quotes do not reach the JD's word. JD because it scores a listed responsibility |
| B4 | "The posting lists Excel and Power BI. Where are you with each?" | JD | [grounded] "solid Excel, never used Power BI" | Two short answers. Excel, at the quote's scope: "I'm solid in Excel." Answer slot: if you built reports in Excel, say what they showed and who used them, in your own words; if you used Excel for your own analysis only, say so plainly and stay with "solid Excel". Power BI: "I've never used Power BI", then a plan for learning it. Ask which tool the role leans on (reverse question 2) | F4 and F5, split because the evidence differs. JD because it is a named tool requirement |
| B5 | "Why leave your current role, why Atlas, and why now?" | JD | [generic] | Selection scaffold in three parts, each in your own words. What in the JD pulls you, using its own lines (four sites, twelve supervisors, the two measures). One thing about Atlas you found and can verify yourself, since this pack could not research it. A true reason for now that is not a complaint. If one part has no honest answer yet, say so plainly and give the nearest true thing | Motivation consistency is what the Skeptic scores, and F1 and F3 are the step you are asking to make. JD because it scores the fit to this specific role |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-pick rate 40%. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on F2: the figure and the redesign are the beats the quote states, so say them in your own words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least (name it before they do), and which part was yours. If you do not know how it was counted, say so plainly and say what you do know | F2 is your headline metric, so it is the one a prober goes to first. EXP because it tests whether the number survives a second question |
| C2 | "Walk me through the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Tell it with the beats the quote states: the plan, the site's, two years running. The material gives no detail or result for either year, so supply none. Where the interviewer asks for more, answer from what you actually did, or say plainly that part was not yours and return to what you ran | F1 and F2 lean on this sentence, and a prober tests how far it goes. EXP because it tests what was actually yours |
| C3 | "At your site, what did you track on on-time performance and cost per shipment, and how did it move?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: the JD names both measures, so this probe is likely. If you tracked either, say what was counted, how, and what moved, in your own words; if you did not track them, or tracking was not yours, say so plainly and return to the mis-pick figure | F2's requirement, asked as a metrics probe. JD because it scores a stated measure; the guidance does not adopt the question's premise |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: the posting requires five years of operations leadership. Why should I count yours?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Pause and restate the question. Hold on the quotes: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: say what those seven years covered, role by role, in your own words; if part of that time was in other kinds of roles, say so plainly and name them. Hold through two follow-ups by returning to the quotes, never by adding to them; concede one specific thing, plainly, if it is true | F6 is a stated requirement with a discovery gap. JD because it scores the listed qualification under time pressure |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate. Anchor in the sentence: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which parts you did yourself and which others did, in your own words; if you do not know a part, say so. Hold the core through two follow-ups, concede only what you can name, and never fold on the core to ease the room | F2's figure is where attribution is probed hardest. EXP because it tests precise honesty about your share |
| D3 | "You have never used Power BI, and this role runs on reporting. Why not hire someone who has?" | JD | [grounded] "solid Excel, never used Power BI" | Concede plainly first: "I've never used Power BI." Hold only to what the quote carries: "solid Excel." Then a plan for learning it, said as a plan. Hold through two follow-ups without claiming any tool you have not used, and without claiming Excel equals it | F5 is a gap you stated, so the concession is yours to give. JD because it scores a listed requirement under pressure |

### H. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc using only the beats these sentences state, in the order that is true for you: the seven years in warehouse and distribution ops, where you are now, the pick-path redesign, the surge plan. End on why this role. Answer slot: your reason, in your own words; nothing is supplied here | F6 and F2 are the arc's spine. EXP because it is the CV read aloud, and casual questions are still scored |
| H2 | "What do you know about Atlas Freight, and what drew you to it?" | CO | [generic] | Selection scaffold: before the interview, find three things about Atlas you can state and verify yourself, since this pack could not research them. Say what drew you in your own words. If nothing yet does, say so plainly rather than reciting generalities | CO because it scores homework depth. `[generic]` because no company research ran |
| H3 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path" | Say the certification as stated: "I'm green belt certified." Answer slot: the JD's plus makes a probe on application likely. If the pick-path redesign used those methods, say so and how; if it did not, or you have not applied them lately, say so plainly and say what you would try first at Atlas | F7 is the one requirement with no gap, and the casual register is where it gets tested. JD because it scores a stated plus |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time that has a named stake, a moment you did not fold, and an intact relationship at the end. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Values scoring is possible in any loop; no company values were available, so VAL is generic here |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, what the metric cost you, and what the customer got. If none comes to mind, say so plainly, then give the nearest true thing or how you would decide | Same as E1; the on-time and cost measures in F2 make the tension a natural one |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side — where is the seam, and what happens when we disagree?" | VAL | [generic] | Offer seam principles rather than pretending to know this seam: who owns the promise to the customer, who owns the data. For disagreement, pick a story with spine and tact and an intact relationship; if none comes to mind, say so plainly and say how you would handle it | The role spans four sites and twelve supervisors (F1, F3), so cross-team friction is plausible. VAL because it scores behavior |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | "We" for context, "I" for your contribution. Choose a story where the credit was shared and the hard part landed; if none comes to mind, say so plainly and say how you would handle it | Attribution is rehearsed elsewhere (D2), and a peer asks it collegially. VAL because it scores behavior |

### Requirement coverage

| JD requirement | Fit row | Questions |
|---|---|---|
| "Own daily terminal operations across 4 sites" | F1 | A3, A4, B3, C2 |
| "drive on-time performance and cost-per-shipment down" | F2 | A1, A2, A5, C1, C3 |
| "lead a team of 12 supervisors" | F3 | A3, B1, G1, G2 |
| "build reporting in Excel/Power BI" | F4, F5 | A5, B2, B4, D3 |
| "5+ years operations leadership required" | F6 | D1, H1 |
| "Lean/Six Sigma a plus" | F7 | H3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How is on-time performance defined here, and how is it measured at each of the four sites today?" | It asks for the definition you would need for A1, and shows you start from what is measured |
| 2 | "What does reporting look like today: what lives in Excel, what lives in Power BI, and who builds it?" | It puts the Power BI gap (F5) on the table on your terms and shows whether Excel meets the requirement |
| 3 | "How are the twelve supervisors spread across the four sites, and who do they report to today?" | It shows you are already sizing the span in B1 |
| 4 | "What would a good first ninety days look like for the person in this role?" | It invites the interviewer to describe the standard you will be held to |
| 5 | "What is the biggest difference between your best-run site and the hardest to run?" | It shows where the supervisors' time is going, and gives you the first site to learn |
| 6 | "What would make you hesitate about my fit, so I can address it now?" | It invites the objection live, where B1 and B3 have already been rehearsed |

## Prohibited claims

Built before the banks. None of these is coached, and none appears in any guidance, slot or concession above.

| Not coached | Basis | Honest form |
|---|---|---|
| Led twelve supervisors, or a multi-site team | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says 3 supervisors, the JD says 12. B1's slot stays inside the three |
| Owned terminal or multi-site operations | Inflated form of F1 | F1's quote at its own scope. The material shows shift management and a surge plan at "the site". B3's slot stays inside that |
| Reduced on-time performance or cost per shipment | Inflated form of F2 | F2's mis-pick quote at its own scope. It is a mis-pick figure, not either named measure. C3's slot stays inside the figure |
| Designed or built the surge plan, or got a result from it | Inflated form of F1 and F2 | The quote says "ran", for the site, two years running. C2 tells only those beats |
| Built reporting or dashboards in Excel | Inflated form of F4 | "solid Excel" at its own scope. B4's slot asks only what you actually built |
| Has used Power BI | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Held five or more years of operations leadership | Inflated form of F6 | The quote says 7 years in operations. D1's slot asks only what those seven years covered |
| Applied Six Sigma methods to the pick-path redesign | Inflated form of F2 and F7 | The two sentences are separate in your message. H3's slot asks whether they connect, and either answer is fine |

## Sources

Provided documents: the JD text and your background summary, both from your message. No tuesday-dossier.md was present.

Searches sent, all refused:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | All calls refused. It would have moved the values cheat sheet and the VAL bank (E1, E2, G1, G2), which stay `[generic]` and the cheat sheet is absent |
| 2. `Atlas Freight interview process operations manager` | unavailable | All calls refused. It would have moved persona weights from a documented loop; the Generic fallback is used instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | All calls refused. It would have moved the CO bank; H2 and B5 stay generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting, and the round type → every persona weight is recomputed, and the interviewer read and a tailored reverse question become possible
- Search permission, or a pasted values page, careers page or recent news → the three `[generic]` company rows (values, loop, strategy) become `[grounded]`, and the CO and VAL banks get named values and current strategy
- A deeper research pass, offered once (up to 6 more searches and 2 more fetches, several more minutes) → strategy brief, interviewer footprint, role-family loop reports, once search is allowed
- The recruiter's prep guidance (focus areas, any take-home or presentation; usually one email) → coverage of anything pre-declared, and a build section if a deliverable exists
- Detail on the pick-path redesign, the surge plan and the green belt (what the figure measured, any result, the certificate or a site scorecard) → the answer slots in F1, F2, F6 and F7 can become story-mapped rows, and the `medium` rows can rise toward `high`
- Your answers to the slots in F2, F3, F4 and F6, stated in your own words outside a drill → those rows regenerate from your quotes
- A tuesday-dossier.md from a prior underwriting pass → verified evidence and sourced prohibited claims, in place of the locally built list (never required)
