No dossier present. Reading the reference files the playbook requires.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-3-denied-debb6f07/stripe_product-operations-manager_interview_pack.md`.

I couldn't research Stripe. All four web searches were refused, so nothing in the pack comes from Stripe's own materials. That means no Stripe value names, no documented interview loop and no current strategy. Every row is labeled `[generic]` rather than guessed.

I also had no JD, CV or interviewer details. I built the pack for a final round with unknown interviewers and blended the persona weights. It has 20 questions across seven interviewer styles and 6 reverse questions. It also has a requirement-coverage table and a Sources section that shows the refused searches. Because I don't have your background, the answer guidance helps you choose your own stories and doesn't write any for you. The one question I'd rehearse first is B1: "Which part of this role would you be weakest at on day one?"

Say the word and I'll play the Skeptic on B1, or any other interviewer style, in a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in this final round (future manager, a peer, a skip-level or a cross-functional partner), and has the recruiter said anything about the format or an assignment to prepare? The answer reweights every question bank.

Can you paste the JD and your CV, or would you rather go without them? Both would turn the generic rows into ones built on your own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer and relationship: not given. Built on one assumption: blended persona weights for a final round whose sessions and interviewers are unknown. No job description, CV or Stripe research was available, so every row below is `[generic]` and says so.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: this pack holds nothing about your past, so wherever an answer needs a story, the guidance tells you how to choose one and never supplies one.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether the claims on your CV survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem |

JD-tagged questions here are role-family questions, because no JD was supplied.

## Fit snapshot

Worksheet variant: no CV or background was given, so every evidence cell reads `none given`. The requirements are role-family patterns for a Product Operations Manager, written as plain prose with no quotation marks because no JD, recruiter or interviewer supplied them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run launches, programs or processes across teams that do not report to you (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence here is a named program, who was involved, and what you personally did. Selection scaffold: pick one effort that crossed team lines, with a named stake and an outcome you can state without adding to it. If no such effort comes to mind, say so plainly, then give the nearest thing you did do, or how you would approach it |
| F2 | Design and run a recurring operating rhythm such as planning, reviews or launch readiness (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or ran, with its cadence and who used it. Selection scaffold: pick a recurring process and say what was yours to set. If none comes to mind, say so plainly, then give the nearest thing you did do, or how you would design one |
| F3 | Use data to set priorities and judge whether a change worked (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is one metric you can explain end to end: how it was counted, what it is sensitive to, which part was yours. Selection scaffold: pick one figure you would put on your CV. If you do not know how it was counted, say so plainly, then give the nearest figure you can defend, or how you would check |
| F4 | Turn scattered customer and internal feedback into decisions a product team acts on (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a case where feedback changed something, with the before and after. Selection scaffold: pick one such case and say what you did with the feedback. If none comes to mind, say so plainly, then give the nearest thing you did do, or how you would handle it |
| F5 | Communicate and influence at senior levels, including unwelcome news (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a moment with a named stake where you said something hard and the relationship survived. Selection scaffold: pick one, and choose a case where the message actually landed. If none comes to mind, say so plainly, then give the nearest thing you did do, or how you would handle it |
| F6 | Prioritize and decide when demands compete and requirements are unclear (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a decision you made between competing asks, with what you traded off. Selection scaffold: pick one decision and say what you gave up. If none comes to mind, say so plainly, then give the nearest thing you did do, or how you would decide |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 | A2, B3, E1, E3 |
| F2 | A3 |
| F3 | A1, D1, D2, D3 |
| F4 | A4 |
| F5 | C1, C2, E2, G1 |
| F6 | A2, B1, B3 |

A5, B2, F1, F2 and G2 cover motivation, company knowledge and attribution rather than a listed requirement.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems set in the role: diagnose, prioritize, design | high: a hiring-manager session is a standard prior for a final round, and the work is operational | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of gaps, motivation, why now | medium: the same hiring-manager prior; with no CV the specific gap cannot be named yet | Rehearse the most predictable objection until it is boring; candor over bluffing |
| Values/Behavioral | Scenario probes, story-shaped answers | medium: a cross-functional session is plausible; no loop source documents a values round, so it is not assumed | Choose stories you can back; I for contribution, we for context |
| Data-Driven Prober | Goes two levels deep on any number | medium: peer and cross-functional sessions both prior toward it | Know how each figure was counted; name the weakest assumption before they do |
| Peer Evaluator | Seams between teams, credit, disagreement | medium: a peer session is possible in a multi-session final | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Conversational | Friendly, unstructured, still scored | low: it rides along with any session | Pre-script a 90-second arc; treat casual questions as scored |
| Pressure | Interrupts, time-boxes, tests composure | low: a skip-level session would raise it | Pause, restate, hold through two follow-ups before conceding anything real |

Weights rest on relationship priors for an unknown final round and a flat generic loop, not on this company's documented process. The highest-ROI prep is B1, which will arrive in some form whoever you meet; it is inferred from the persona stem, not derived from your background, because none was supplied.

## Question banks

### A. Case/Strategist (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product team ships a major feature and first-week adoption comes in 20 percent under plan. What do you need to know first, and how would you diagnose it?" | CASE | [generic] | Clarify before structuring: what the plan assumed, which segments, over what window. Then objective, segmentation, approach, metrics, risks. Think aloud, and challenge one premise, such as whether the plan itself was sound. The question needs no claim about your past, so the guidance makes none | Live diagnosis for F3, the persona's own stem; CASE because it scores structure |
| A2 | "Three product teams each want you running launch readiness for their release in the same fortnight. How do you decide whose gets your time first?" | CASE | [generic] | Ask first about stakes, dependencies and dates. Offer prioritization principles rather than a verdict, say what each choice trades away, and name one risk you would watch. No claim about your past | Tests F1 and F6 together as a live decision; CASE because it asks about no history |
| A3 | "A twenty-team product org has no shared planning rhythm. What do you need to know first, and what would you propose?" | CASE | [generic] | Clarify what exists informally and what hurts today. Propose the smallest rhythm that fixes the worst pain, say how you would know it worked, and name the adoption risk. No claim about your past | F2 as a design problem; CASE because it is hypothetical |
| A4 | "Support teams say one complaint keeps recurring; the product team says it does not show in their data. How do you work out who is right?" | CASE | [generic] | Treat both as evidence: ask how each is collected and what each would miss, propose a way to reconcile them, and say what decision follows each outcome. No claim about your past | F4 as a live problem; CASE because it presupposes nothing about you |
| A5 | "What do you think is the biggest challenge facing Stripe's product organization, and where could product operations help?" | CO | [generic] | This pack holds no Stripe research, so it supplies no facts. Bring one specific thing you read from a published source, say where it came from, and give a view with one concession. Do not recite a source any prepared candidate can quote. If you have not researched yet, say what you would want to learn | The CO slot; `[generic]` because search was refused, which is the honest cost named in the upgrade menu |

### B. Skeptic (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Choose the requirement from F1 to F6 where your own evidence is thinnest, say it plainly, then give a concrete ramp plan for the first weeks. Hold through two follow-ups without retreating or inflating, and concede specifically. If you cannot name one, say so plainly, then name where you would ask for help first | Every skeptical round arrives here in some form; JD because it scores the role's stated needs |
| B2 | "Why product operations, and why now?" | JD | [generic] | Three beats, all yours: what drew you to this kind of work, why this company, why this moment. The company beat needs your own research, which this pack could not supply. If the honest answer is partly that the role came along, say so and give what keeps you | Motivation consistency is what a skeptic scores; JD because it tests fit with the job as listed |
| B3 | "How would you handle the parts of this role you have not done before?" | JD | [generic] | Name how you learn: who you ask first, what you read, how you test your understanding early. Pick one real example of learning fast if one comes to mind; if none does, say so plainly, then describe how you would approach it | Probes F1 and F6 without presupposing a gap |

### C. Values/Behavioral (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, the message you actually gave, and an intact relationship afterward. Choose a story where the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing you did do, or how you would handle it | F5; VAL because it scores behavior under pressure. No Stripe values were available, so it is not mapped to named values |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick one decision with a named trade-off, and say what the metric cost. If no such time comes to mind, say so plainly, then give the nearest thing you did do, or how you would decide | F4 and F5; VAL because it scores a choice, not a belief |

### D. Data-Driven Prober (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number you would put on your CV and walk me through how it was counted." | EXP | [generic] | Say how it was counted, what it is sensitive to, and which part was yours, in your own words. If you do not know how it was counted, say so plainly, then give the nearest figure you can defend | F3; the defend-the-number rehearsal |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | A follow-up to D1. Name the weakest assumption yourself before they do; it turns a gotcha into credibility. If you do not know one, say so plainly and say how you would check | The weakest-assumption move, F3 |
| D3 | "A dashboard shows a new process's adoption up 30 percent week over week. What would make you doubt it?" | CASE | [generic] | Ask what is being counted, over what base and period, and whether the definition changed. Say what you would check first. No claim about your past | Probes F3 as a live problem |

### E. Peer Evaluator (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam, and ask how it works today. For disagreement, show spine and tact together; if you use a story, pick one with a named disagreement. If none comes to mind, say so plainly and describe your approach | F1 |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | State your approach first. If you use a story, say what was yours and what was shared. If none comes to mind, say so plainly and describe how you would handle it | F5 |
| E3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Reciprocity: lead with what you bring their team, then what you need. Keep both about method, not claims about past results | F1; the peer's real question is whether you add to or reduce their load |

### F. Conversational (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the turning points, why this role. Every beat must be something you actually did; this pack cannot supply them without your CV. If a turning point is thin, say it briefly and move on | The casual opener is still scored |
| F2 | "What are you working on or learning right now that is relevant to this role?" | JD | [generic] | Name one real current thing and why it matters here. If nothing is current, say so plainly and name what you would pick up first | Casual-register questions on hot topics are scored |

### G. Pressure (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate. Make one claim you can back with a named example, and hold it through two follow-ups. Concede what you do not know, specifically, without folding on the core claim | F5; tests composure |
| G2 | "Pick a result you would lead with. How much of it was actually you?" | EXP | [generic] | State your part precisely and the shared part generously. Hold that statement through two follow-ups. If your part was smaller than the headline, say so plainly; that is the honest branch | The attribution probe |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does a great first six months look like in this role, and what would make you say it was not working?" | Shows you plan to be measured, and surfaces the real success criteria |
| R2 | "How does the product operations team decide what it will not work on?" | Shows you think about prioritization as a discipline |
| R3 | "How does the team know its own work made a difference?" | Signals you care about impact more than activity |
| R4 | "Where has the seam between this role and the product teams it supports been fuzzy, and how was it resolved?" | Turns the seam question into a real conversation about how the work runs |
| R5 | "What has changed about how this team works in the last year, and what is still unresolved?" | Invites candor and shows you are looking at the present |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question, for a peer interviewer |

No interviewer information was given, so none of these is tied to an interviewer's path.

## Prohibited claims

No entries. No sentence of yours is in this pack, so there is no wording to inflate and no negative you have stated. This pack coaches no claim about your past at all: every story is yours to choose and tell as it happened.

## Sources

Provided documents: none. No job description, CV, interviewer name, recruiter guidance or dossier was supplied. The only fact about the round is "final round".

Searches sent, all refused, none returned a result:
- "Stripe operating principles values careers": refused
- "Stripe interview process product operations manager": refused
- "Stripe strategy news 2026": refused
- "Stripe Product Operations Manager job description responsibilities": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have supplied the official value names for a values cheat sheet and for VAL stories. Absent, so section 10 is dropped and VAL questions are not mapped to named values |
| 2. `Stripe interview process product operations` | unavailable | Would have supplied loop structure and persona weights. Absent, weights rest on a generic archetype and relationship priors |
| 3. `Stripe strategy` / recent news | unavailable | Would have grounded A5 and any CO question in current priorities. Absent, A5 is `[generic]` |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Operations Manager` JD | unavailable | Would have turned F1 to F6 into quoted `[inferred]` requirements. Absent, they remain role-family prose |

## Upgrade menu

- Job description text: F1 to F6 become quoted requirements, JD-tagged questions become `[grounded]`, and the coverage table is re-keyed to the real list
- Your CV: the evidence cells fill, selection scaffolds become story maps built on your own sentences, and the most predictable objection to you specifically replaces B1's generic version
- Who you are meeting and in what order: persona weights are recomputed and an interviewer read plus a reverse question tied to their path are added; if your final is several sessions, send the schedule and I will build a per-session mini-pack for each
- The recruiter's prep email or any announced assignment: any pre-declared deliverable gets its own build section
- How much prep time you have: a prioritized prep schedule sized to it
- Permission to search for Stripe research: official value names for a values cheat sheet, the documented loop, and current strategy for A5 (a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, is available once)
- A tuesday-dossier.md from an earlier evaluation of this role: confirmed evidence and claims to avoid arrive already graded; this is an addition, never a requirement
