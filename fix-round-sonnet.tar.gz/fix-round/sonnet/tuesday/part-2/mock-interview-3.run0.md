Reading is done, so I'm starting the Stripe research: values, interview process, recent strategy, and a representative Product Operations JD.
Web search was denied, so I'm building the pack from what you've told me and labeling everything generic. I'm writing it now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-3-denied-b7f7036d/stripe_product-operations-manager_interview_pack.md`.

- **Basis:** I built it for a final round with an unknown interviewer and an unknown number of sessions, so the persona weights are flat.
- **Contents:** 21 questions across the seven interviewer styles, a requirement-coverage table, six reverse questions and a fit worksheet.
- **Highest-ROI prep:** B1, "Which part of this role would you be weakest at on day one?"
- **Generic content:** Web search was denied, so all four searches were refused and nothing in the pack is Stripe-specific. The questions and requirements are generic, with no Stripe values, loop structure or strategy.
- **No CV or JD:** The fit worksheet's evidence cells are empty, and the answer guidance tells you how to choose a story from your own experience without supplying one.

Say the word and I'll play the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting, and is it one session or several back to back? A name, a relationship and any recruiter guidance would reweight every bank.
2. Can you paste the job description and your CV, or a few bullets from it? Without them I'll keep rehearsing from the generic pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview pack: Product Operations Manager, Stripe (final round)

Interviewer and relationship: not given. Built on one assumption: a final round whose interviewers and number of sessions are unknown, so persona weights are blended and flat. No JD, CV or web research was available, so every row below is generic and labeled that way.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: where it points at your experience, it tells you how to choose and tell a story in your own words, and never supplies one.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your experience survives scrutiny; what was actually you |
| JD | Whether you can do the job, including its gaps |
| CO | Whether you did homework on the company |
| CASE | Structure and reasoning on a live problem |

Question IDs are letter-by-persona so a drill can name them. B1 is the highest-ROI rehearsal in this pack.

## Fit snapshot (worksheet)

No CV or JD was given, so this is the worksheet variant. The requirements are role-family patterns written as plain prose, not quotes from a Stripe posting. Every evidence cell is empty until you supply your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run a cross-functional launch or rollout across product, engineering and go-to-market teams (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one launch or rollout you can name, with your part in it stated at its true size. Selection scaffold: pick one with a named stake, a point where teams disagreed, and a result you can say plainly; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define and track product-health metrics and an operating cadence such as reviews and planning (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a metric or review rhythm you can explain end to end, including how it was counted. Selection scaffold: pick one figure or cadence you could defend under two follow-ups; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set one up |
| F3 | Turn an ambiguous product or team problem into a repeatable process or tool (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a before-and-after of one process you changed and who used it afterward. Selection scaffold: pick a case where you started without a defined process; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influence senior stakeholders without formal authority (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a moment you held a position with someone senior and the relationship stayed intact. Selection scaffold: pick one with a named stake and a moment you did not fold; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Use data to diagnose problems and set priorities (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is an analysis you did yourself and can walk through, with its weakest assumption named. Selection scaffold: pick one you can walk through from question to decision; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F6 | Communicate clearly and briefly to senior audiences (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a document or readout you wrote that a senior reader acted on. Selection scaffold: pick one you can describe in two sentences; if none comes to mind, say so plainly, then give the nearest thing your material does carry |

No row is a gate: nothing supplied states a location, authorization, schedule or pay term, and a role-family pattern raises none.

## Persona table

The loop is not established (no loop source was read; "final round" alone does not say how many sessions there are), so the fallback is the Generic archetype with flat weights, and these weights rest on a pattern, not on Stripe's documented process. A final round with an unknown interviewer blends the hiring-manager, peer and cross-functional priors.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems from the job: diagnose, plan, simplify | High: hiring-manager prior, and a product operations role is mostly structured problem solving | Clarify, state the objective, segment, approach, metrics, risks; think aloud; challenge one premise politely |
| Skeptic (B) | Quiet probing of why this role, why now, what is missing | High: hiring-manager prior, and a final round exists to derisk | Rehearse the most predictable objection until it is boring; use only adjacent evidence you actually stated; add a concrete ramp plan |
| Values/Behavioral (C) | Scenario questions scored on past behavior | Medium: cross-functional prior; no round is documented here, so this is a pattern | Choose a story from your own material for each theme; we for context, I for your contribution |
| Peer Evaluator (D) | Seam-splitting, credit, what you would need | Medium: peer prior; a product operations hire sits between teams | Reciprocity: what you bring their team; propose seam principles, not a map you have not seen |
| Data-Driven Prober (E) | How a number was counted, assumptions | Medium: any metrics-heavy role draws it | Know and say how each figure you cite was counted; say plainly when you do not know |
| Pressure (F) | Time-boxed, interrupts, tests composure | Low: skip-level prior only; unknown whether an executive is in the loop | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational (G) | Friendly openers that are still scored | Low: recruiter-screen prior, but openers appear in every round | Prepare a 90-second arc; treat casual questions as scored |

## Question banks

Every row is `[generic]`: there is no JD, CV or research to ground it. No question presupposes anything about your past; where a question asks you to choose an instance, the guidance ends in an honest branch.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch keeps slipping because three teams each think another owns the final checklist. What do you do in your first week?" | CASE | [generic] | Clarify first: what is the launch date's cost, who has been asked to own what, what has already been tried. Then name the decision that unblocks, who makes it, and what you would write down so ownership is visible. The question needs no claim about your past, so the guidance makes none | F1's requirement as a live problem; CASE because it scores structure |
| A2 | "A key product metric dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Rule out measurement first, then segment by user group, time and platform, then separate product change from outside cause, then say what you would check in what order. Think aloud and state the hypothesis early | F5's requirement as a live problem; a standard case shape for the role |
| A3 | "Sketch how you would set up a planning and review cadence for a product group that has none. What do you need to know first?" | CASE | [generic] | Ask about decisions the group already makes, who attends, and what goes wrong today. Propose the smallest cadence that fixes one named pain, with a date to review whether it helped | F2's requirement; tests whether you add process or fix a problem |
| A4 | "Teams say your process adds overhead. How do you decide what to keep, simplify or remove?" | CASE | [generic] | Give criteria, not a story: who is helped, what decision it supports, what breaks if it stops. Offer a cheap test, such as pausing it for a cycle. No past claim is made | F3's requirement; the usual pushback on operations roles |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Highest-ROI prep in this pack. Pick one real gap from your own material, name it in one sentence in your own words, then give a concrete ramp plan: what you would read, who you would ask, what you would do in the first 30 days. Hold through two follow-ups by returning to that plan, not by adding experience. Answer slot: if no gap comes to mind, say so plainly and name the part you would verify first | The weakest-point question arrives in some form in nearly every final round; the pack cannot name your specific objection without a CV, so this generic form is rehearsed deepest |
| B2 | "Why product operations, and why now?" | JD | [generic] | Give one reason about the work, one about the timing, one about this company that you found yourself. Answer slot: if a reason is not yours, leave it out and say so plainly | Motivation consistency is what the Skeptic scores |
| B3 | "How is this different from program management or chief of staff work?" | JD | [generic] | Define the role in your own terms in two sentences, then say where the boundaries blur. Do not claim a title you have not held | Tests whether you understand the job, not just want it |
| B4 | "What would your last manager say you should improve?" | EXP | [generic] | Answer slot: if there is a real piece of feedback, say what it was and what changed since, in your own words; if you have not received any, say so plainly and name what you are working on instead | A common calibration probe on self-assessment |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a case with a named stake, a moment you did not soften the message, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4's requirement; the persona's standard stem |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two pulled apart, what you chose, and what it cost. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | Standard values stem; no Stripe value is asserted because none was researched |
| C3 | "Tell me about a disagreement with a partner team and how it ended." | VAL | [generic] | Selection scaffold: pick one where you can describe the other side's view fairly. Say what you did, what you gave up, and the result. If none comes to mind, say so plainly, then give the nearest thing your material does carry | F1 and F4: cross-team friction is the daily work |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Offer principles for a seam, such as who owns a decision and who is informed, rather than pretending to know it. Say how you would raise a disagreement early and privately | The persona's standard stem |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time credit was shared; describe what you did to make others' work visible. If none comes to mind, say so plainly and describe how you would handle it | Collaboration tone and spine |
| D3 | "What would you need from me in your first month?" | JD | [generic] | Reciprocity first: what you bring their team, then two specific asks such as access to a recurring review and an introduction to one partner | Peer evaluators weigh whether the hire adds to or reduces their load |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How would you decide which metrics a product group reviews every week?" | CASE | [generic] | Start from decisions, not data: which choices recur, what signal would change them, what is cheap to measure reliably. Name one metric you would drop and why | F2's requirement as a live problem |
| E2 | "Choose a figure from your work that you could be asked to defend. How was it counted, and which assumption would you defend least?" | EXP | [generic] | Answer slot: say in your own words how it was counted, what it is sensitive to, the assumption you would defend least and which part was yours; if you do not know how it was counted, say so plainly. Never defend a method you did not use | Quantified claims are magnet targets for probers |
| E3 | "Describe an analysis you did yourself, end to end." | EXP | [generic] | Selection scaffold: pick one you can walk from question to decision without notes. If none comes to mind, say so plainly, then give the nearest thing your material does carry | F5's requirement |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then give two points in order of importance and stop. Answer slot: the points must come from your own material; if you cannot name two, give one and say so plainly | Tests composure and brevity (F6's requirement) |
| F2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Hold through two follow-ups by stating exactly what you did and who did the rest. Concede specifically, never on the core claim. Answer slot: if part was not yours, say so plainly and return to what was | Attribution honesty is what the probe scores |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc from your own material: where you started, the two or three turns that mattered, why this role is next. Tell only what you can stand behind | Casual openers are scored on economy |
| G2 | "Why Stripe?" | CO | [generic] | No Stripe facts are in this pack because none were researched. Use reasons you found in Stripe's own published material and can name; if you have none yet, read it before the interview | The pack cannot supply company specifics without research; see the upgrade menu |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 cross-functional launch or rollout | A1, A4, C3 |
| F2 metrics and operating cadence | A3, E1, E2 |
| F3 ambiguity into repeatable process | A3, A4 |
| F4 influence senior stakeholders | C1, C3, D1, D2 |
| F5 data to diagnose and prioritize | A2, E1, E3 |
| F6 clear, brief communication | F1, G1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make the first six months of this role clearly successful in your eyes?" | Shows you are anchoring on outcomes, and the answer tells you what you are really hired for |
| R2 | "Where does product operations end and the teams it serves begin, today?" | Surfaces the seam directly and signals you think about boundaries |
| R3 | "What is a process here that you would like to see removed rather than added?" | Signals judgment, not a bias toward adding process |
| R4 | "How does the team learn whether a change it made actually helped?" | Shows you care about feedback loops and measurement |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question, useful if the interviewer is a peer |
| R6 | "What do you wish candidates for this role asked you more often?" | Invites candor and often reveals the real concern |

## Prohibited claims

Nothing was listed. No sentence of yours was supplied, so there is nothing to inflate, and requirements your material says nothing about are answer slots, not prohibitions. The pack makes no claim about your past anywhere.

## Sources

Provided documents: your message only (company, role title, final round). No JD, CV, interviewer profile or dossier was supplied.

Searches sent, all refused (permission was not granted, and none were retried):

- "Stripe operating principles values": refused
- "Stripe interview process product operations manager": refused
- "Stripe strategy news 2026": refused
- "Stripe Product Operations Manager job description": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have supplied official value names for a values cheat sheet; that section is dropped and no Stripe value is asserted anywhere |
| 2. `Stripe interview process product operations` | unavailable | Would have established the loop and persona weights; weights fall back to Generic and flat |
| 3. `Stripe strategy` / recent news | unavailable | Would have grounded CO and CASE questions; G2 and the cases are generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Operations Manager` JD | unavailable | Would have made the fit snapshot requirements `[inferred]` quotes from a fetched posting; they are `[generic]` prose instead |

## Upgrade menu

- The job description text → the six `[generic]` requirements become quoted, `[grounded]` rows, and each gets a JD-tagged question
- Your CV or a few bullets → the evidence column fills with your own sentences, the scaffolds become story maps, and the prohibited list can name real inflated forms
- The interviewer's name and relationship to the role → a tailored interviewer read, reweighted personas and a reverse question tied to their path
- The recruiter's prep email, or the schedule if your final is several sessions → real loop structure instead of the Generic fallback, per-session mini-packs and any pre-declared deliverable build
- Web search permission → Stripe's published values, loop reports and current strategy, which would replace G2 with grounded CO questions and add a values cheat sheet if a values round is documented
- A deeper research pass, if search is allowed → up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief and role-family loop reports
- A tuesday-dossier.md from the job-underwriter, if you have one → a verified-evidence base and prohibited claims; the pack does not depend on it
