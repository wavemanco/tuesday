Searches came back with attributable sources, so I'm now fetching Saltmarsh's values page and its interviewing page to get the exact wording.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-canned-8805f129/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 21 questions, a fit snapshot against the JD, and a prep order for Wednesday to Friday.

I assumed Tobias is your hiring manager. Saltmarsh's careers page says every loop is a recruiter call, then the "Outage Hour". That is one 60-minute hiring-manager interview: a live-incident tabletop on a simulated outage, then a values conversation. There is no take-home. The pack is weighted toward case problems and values, then skeptic questions.

- **Biggest gap:** C1 is the question to rehearse most. Saltmarsh announced in September 2026 that its titles move to a season-pass model. You've said you've never worked on a game with in-app purchases, so expect it. The pack coaches a one-sentence plain answer, then a plan, and never a claimed past.
- **Strongest asset:** the release checklist you wrote. Tobias was previously a QA lead and gave a GDC 2026 talk on patch notes, so expect real depth on it (D2).
- **Research limits:** the Larkspur announcement and the talk came from search summaries, not full pages. Read the full Larkspur announcement before running A3.

Say the word and I'll play the Skeptic on C1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias going to be your direct manager, or a skip-level? Has the recruiter said anything about what the Outage Hour covers? Either answer reweights the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** one 60-minute session. Built on this assumption: Saltmarsh's published loop puts the Outage Hour (a live-incident tabletop, then a values conversation) with the hiring manager, and I have treated Tobias as that hiring manager. Your note did not say, so if he is a skip-level, the persona weights below shift.

## 1. How to use this pack

Personas are how a question arrives. Types are what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Saltmarsh's published values, not generic virtue |
| EXP | Whether your background survives scrutiny, and what was actually you |
| JD | The stated requirements and responsibilities, including your gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, scored on structure and reasoning |

Answer slots are instructions for the interview, not questions for you now. If you answer one outside a drill, tell me and I will quote it into the fit snapshot and regenerate the rows it touches.

## 2. Prep triage

Two days to Friday. Do these in order; everything else is insurance.

| Order | Do this | Where |
|---|---|---|
| 1 | Say C1's first sentence aloud until it is boring, then run C1's three follow-ups | C1, prohibited list |
| 2 | Run the tabletop out loud, timed, 90 to 120 seconds each | A1, A2 |
| 3 | Read the full Project Larkspur announcement (this pack saw only a search summary), then run A3 and A4 | A3, A4, F9 |
| 4 | Pick your stories for the three values and rehearse the honest branch of each | B1, B2, B3, section 10 |
| 5 | Know how your retention numbers were counted, or be ready to say you do not | D1 |
| 6 | Friday morning: your 90-second arc and reverse questions R1 to R3 | F1, section 11 |

## 3. Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is your own words from your message. F9 is not a JD line; it comes from Saltmarsh's own September 2026 announcement (seen as a search summary).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and, separately, two years running the calendar for the main title. It does not show whether the title was a live-service game for all four years. Answer slot: the JD's years line makes a probe on this likely. If the title was live-service for the four years, say so and for how long, in your own words; if only part of it was, or it was not, say so plainly and stay with the two years you ran the calendar |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you ran the weekly content-drop calendar for the main title, for two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | The quote is one title and content drops; the JD says two titles and live events. The words stay at the quote's scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if any of those drops were timed live events, say which; if you ever scheduled across more than one title, say what; if neither, say so plainly and stay with the main title's calendar |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Your material does not show which teams the weekly drops involved. Answer slot: the JD names four teams, so expect a probe on whether the drops involved any of them. If they did, say which and how you worked with them, in your own words; if none did, or it was not yours to coordinate, say so plainly and return to the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the numbers; it does not say you ran a review of an event or defined the KPIs. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you reviewed any drop after it shipped, say what you looked at and what came of it; if there was no such review, or it was not yours, say so plainly and stay with the monthly presentation |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it. Lead with it in its own terms, and expect a probe on how the numbers were counted (D1) |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote it, and QA still uses it. Reword only that: "I wrote the release checklist our QA team still uses." Your material says wrote, not managed each release, and the words do not stretch to cover it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written checklist touches the requirement without showing communication to players or stakeholders. Answer slot: if you wrote anything aimed at players or the wider studio, such as notes or a summary, say what and for whom; if not, say so plainly and stay with the checklist. A writing sample is the upgrade-menu item |
| F9 | "season-pass model with one shared events calendar" — Saltmarsh news, Project Larkspur, September 2026 (search summary) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You stated the absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |

## 4. Reading the interviewer

Public professional footprint only: one search result, so the facts below are what that result said.

| Observation | Implication | Provenance |
|---|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | A QA background makes your release-checklist line the likeliest place to be probed in depth (D2) | [grounded] |
| GDC 2026 talk "Patch Notes Are a Promise"; his argument as summarised: a live team is judged by how often its patch notes describe what actually shipped | Announcement wording is a theme he cares about publicly; rehearse E2 and B2 so that every sentence describes only what is built | [grounded] |
| His argument and Saltmarsh's value "Ship the Patch Not the Promise" use close wording | Expect the values half of the hour to lean on that value | [inferred] |

Mirror opportunity, shared vocabulary only: checklists and QA. Your side of it is F7: "Wrote the release checklist our QA team still uses." Offer it at its own scope and no wider.

## 5. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The tabletop: a simulated outage during a live event | High. The hiring-manager prior is Case/Strategist plus Skeptic, and the loop source says the hour opens with a live-incident tabletop | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Values/Behavioral | The second half of the hour, built on the three published values | High. The loop source names a values conversation; the three values are published | Map a story to each value where your own words carry one; where none does, use the selection scaffold and its honest branch |
| Skeptic | Probing the gaps: in-app purchases, team leadership, one title versus two | High. Hiring-manager prior, and F9 is a stated gap against a season-pass announcement | Rehearse the single most predictable objection (C1) until it is boring; calibrated candour over bluffing |
| Data-Driven Prober | Line-by-line questions on the retention numbers and the checklist | Medium. His QA background and the JD's KPI ownership both point at verification; this is my reading, not his stated style | Know how each number was counted and say plainly when you do not; name the assumption you would defend least before he does |
| Pressure/Stress | Interruptions and time-boxing inside the tabletop | Low to medium. Incident tabletops tend to compress time; the loop source does not say he interrupts | Pause, restate, anchor in what you actually said, hold through two follow-ups before conceding anything real |
| Conversational/Rapport | The opening biography question | Low. Every session has an opener; it is still scored | A 90-second arc built only from your own sentences |
| Peer Evaluator | Not banked | The loop source names a single session with the hiring manager, so no peer session is documented | None needed |

## 6. Question banks

### A. Case/Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is day two of a live event. A reward is not granting for some players and support tickets are climbing. You are the producer on call. What do you do in your first twenty minutes?" | CASE | [inferred] | Clarify first: what is confirmed and what is only suspected, who is affected, whether the event can be paused or mitigated, who decides, and who needs to be on the call (the JD names design, art, engineering and community). Then objective, approach, what you tell players, and the risk of each option. Say only what is known; the value "Ship the Patch Not the Promise" is a useful test. Challenge one premise, for example whether twenty minutes is enough to know the cause. No claim about your past is needed | The loop source says the hour opens with a live-incident tabletop; the scenario itself is this pack's invention, so the derivation is the format, not the content. CASE because it asks about no past |
| A2 | "The fix is ready, QA has not finished the release checklist, and the event ends tonight. Ship or hold?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Do not answer ship or hold in the first breath. Clarify what is unchecked and what the downside of each is, name the options between the two (partial fix, extended event, staged rollout), say who owns the call, and keep Players Before Plans in view: when the calendar and the players disagree, the players win. The only claim about your past you may add is the sentence quoted here, at its own scope. Afterwards, say what you would change on the checklist, which is the value Leave the Build Greener | F7 is the evidence for the checklist requirement and the likely hook for this scenario. JD content, CASE delivery, so it carries JD |
| A3 | "From February 2027 both titles share one events calendar and one live-ops group. What would you want to know before planning its first quarter?" | CO | [grounded] | Ask rather than assert. Candidate questions: how events are prioritised when the two titles collide, what the season-pass cadence constrains, how the single group divides the work now that per-title event teams are retired, and who owns the calendar's final sign-off. State a hypothesis early for each. Read the full announcement first: this pack saw only a search summary of it | Grounded in the Project Larkspur summary (Sources, target 3). The most strategy-relevant question available; CO because it tests whether you can think at the company's altitude |
| A4 | "Plan the first four weeks of events for a title on a season pass. What goes in week one, and how do you decide?" | CASE | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Structure: what the season pass is for, what the player should feel in week one, what the calendar must not collide with, how you would check it worked. If spend shapes the answer, say it plainly first: "I haven't worked on a game with in-app purchases." Then ask what the season-pass rules allow and plan inside them. Do not describe how season-pass monetisation works as though you had run it | F9 is the gap this question presses. CASE because it is a live planning problem; the stated negative is the only claim about you |
| A5 | "Day-7 retention dipped after last weekend's event. Diagnose it." | CASE | [generic] | Clarify which retention measure and which cohort, whether the dip is across all players or a segment, what else shipped or broke that weekend, and how this event compares with earlier ones. Then rank hypotheses, say what data would confirm each, and say what the post-event review should record. A diagnostic pattern, with no claim about your past | Stem from the Case/Strategist persona; it covers the retention and post-event-review requirements (F5, F6) as a live problem rather than a history question |

### B. Values/Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold, because none of your sentences carries this story: pick a time when what the schedule wanted and what players needed pulled apart. It needs a named stake, what you chose and why, and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I ran the weekly content-drop calendar for our main title for the last two years." | Players Before Plans, from the published values page. F2 is the nearest evidence and does not carry a conflict |
| B2 | "Tell me about a time you had to decide what to announce about a release." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Nearest material: "Wrote the release checklist our QA team still uses." Answer slot: the value says "we announce what is built, not what is hoped", so expect a probe on whether the checklist touched what was said about a release. If it did, say how, in your own words; if it did not, or announcements were not yours, say so plainly and return to the checklist. If no instance comes to mind, say so plainly | Ship the Patch Not the Promise, and the theme of the interviewer's own talk. F7 is the only nearby evidence and does not show an announcement |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story map on F7: you wrote the checklist, and QA still uses it; those are the beats the sentence states, told in your own words. Answer slot: the value says every release leaves the checklist better than it found it, so expect a probe on whether it changed after you wrote it. If you revised it, say what and why; if it was written once and has not changed, say so plainly and tell that | Leave the Build Greener, from the values page. F7 is the strongest values story in your material and still has a seam, which the slot covers |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: it needs a named stake, the message that was unwelcome, how you said it, and what the relationship looked like afterwards. Nearest material: "Presented the monthly retention numbers to the studio head." Answer slot: if any of those numbers were unwelcome, say which and how it went; if none were, say so plainly and tell the presentation as it was | Persona stem for the values interviewer; F6 is the nearest evidence and does not show an unwelcome result |
| B5 | "Which of our three values would be hardest for you to live up to?" | VAL | [grounded] | Choose honestly; this is a self-assessment, and a pick that sounds safe is the weak answer. Say which, why, and what you would do in your first weeks to work on it. No claim about your past is needed | The published values give the interviewer a natural self-assessment prompt; the Skeptic persona often arrives inside a values round |

### C. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our titles are moving to a season-pass model. What experience do you have with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | **The highest-ROI prep in this pack.** Say the limit first, in one sentence: "I haven't worked on a game with in-app purchases." Then what you carry, at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Then a plan, stated as a plan: what you would ask about the season-pass rules before proposing anything, and whom you would ask. Follow-up 1, how would you learn it: the plan. Follow-up 2, would you be comfortable owning events that drive spend: concede specifically what you cannot yet judge and do not claim comfort you have not earned. Follow-up 3, what would failure look like in your first quarter: name the limit before it is asked for. Hold by returning to the two quotes, never by adding to them | F9 is the biggest gap in the fit snapshot and Saltmarsh has announced the model it presses on; this question will be asked in some form. EXP because it tests what you have actually done |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick the weakness you honestly believe, in one sentence. If it is one you have stated, use the plain words: "I haven't led a team." or "I haven't worked on a game with in-app purchases." Then the ramp: how you would learn it in the first weeks, as a plan. If it is another requirement, F4 and F5 hold the open slots; use theirs | Persona stem for the Skeptic; the stated gaps in F9 and the team-leadership line are where this lands |
| C3 | "Have you led a team? This role coordinates design, art, engineering and community on each update." | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Plain answer first: "I haven't led a team." Then the coordination slot: the JD names four teams, so expect a probe on whether the weekly drops involved any of them. If they did, say which and how you worked with them, in your own words; if none did, or it was not yours, say so plainly and return to the calendar: "I ran the weekly content-drop calendar for our main title for the last two years." The JD says coordinate, not manage, so do not argue the difference for them | F4 is the row this presses; the leadership negative is yours. JD because it scores the coordination responsibility |
| C4 | "You ran the calendar for your studio's main title. This role covers two titles. What makes this a step you are ready for?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "4 years as an associate producer at a puzzle-game studio" | Hold what the quotes carry: you ran the weekly content-drop calendar for your main title for two years, and you have four years as an associate producer at a puzzle-game studio. Answer slot: the JD says two titles and live events, so if you ever scheduled across more than one title or ran a timed event, say what; if not, say so plainly and stay with the main title. Do not say the work is proof of readiness; describe it and let them decide | F1 and F3 are where the JD's scale exceeds your material. JD because it scores the calendar and years requirements together |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Four slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how a number was counted, say so plainly; that is an honest branch. Do not name a method you did not use | F6 is the headline metric line in your material; probers go straight to it. EXP because it tests attribution |
| D2 | "Take me through the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Tell it with the beats the sentence states: you wrote it, and QA still uses it. Answer slot: the JD says manage the checklist with QA, so expect a probe on whether you ran releases against it. If you did, say how, in your own words; if you wrote it and QA ran it, say so plainly and stay with the checklist | F7, and the interviewer's QA background makes this the likeliest deep probe. EXP because it tests what was yours |
| D3 | "After an event ends, what goes in the post-event review, and which retention measures do you watch?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Say how you would structure the review, as a plan: what you would compare, what you would record, who sees it. Answer slot: if you reviewed any drop after it shipped, say what you looked at and what came of it; if there was no such review, say so plainly and return to "Presented the monthly retention numbers to the studio head." | The JD's KPI line (F5, F6). JD because it scores the responsibility |

### E. Pressure/Stress (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has run a monetised live-ops calendar?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Pause, restate the question, then concede first: "I haven't worked on a game with in-app purchases." Hold on what the quotes carry, each at its own scope: the weekly calendar, the checklist QA still uses, the monthly retention presentation. Do not claim to be stronger than the other candidate; say what you bring and what you would need to learn. Hold through two follow-ups by returning to the quotes; concede uncertainty specifically, never on the core claim | The Pressure stem, aimed at F9. JD because it scores the fit against the posting |
| E2 | "Players are angry. Write me the announcement, two sentences, right now." | JD | [inferred] | Pause. Write only what is confirmed: what happened, what players should do, and when the next update comes if you know it. Do not promise a fix time you cannot back. If interrupted, restate and keep the two sentences intact. No claim about your past is needed | Covers "clear written communication" (F8) under time pressure; the derivation is the tabletop format from the loop source and the interviewer's published theme. JD content, CASE delivery |

### F. Conversational/Rapport (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats, each a sentence of yours at its own scope: four years as an associate producer at a puzzle-game studio, then the weekly content-drop calendar for the main title, the release checklist QA still uses, and the monthly retention presentation. Answer slot for the last beat: why this role and why now; the pack has nothing from you on it, so say it in your own words | The opener is scored even when it feels casual; F1, F2, F6, F7 are the material |
| F2 | "What live-service games do you follow, and what have you noticed about how they run events?" | CO | [generic] | Selection scaffold: pick one you actually follow and say one specific thing you noticed. If none comes to mind, say so plainly and ask which of Saltmarsh's titles they would start you on. Do not perform expertise you do not have | Persona stem for the rapport interviewer. CO because it tests homework and genuine interest |

## 7. Requirement coverage

| Requirement or value | Covered by |
|---|---|
| "3+ years producing live-service games or apps" | C4, F1 |
| "experience running a content calendar" | C4, A4, F1 |
| "comfortable with player-retention metrics" | D3, D1, A5 |
| "clear written communication" | E2 |
| "Plan and run the live-events calendar for two of our mobile titles" | C4, A3, A4 |
| "coordinate design, art, engineering and community teams on each update" | C3, A1 |
| "own the post-event review and the KPIs it reports" | D3, A5 |
| "manage the release checklist with QA" | A2, D2 |
| Players Before Plans | B1 |
| Ship the Patch Not the Promise | B2 |
| Leave the Build Greener | B3 |

## 8. Values cheat sheet

Detected: the loop source documents a values conversation. Names are the published ones.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold, no quote carries it: a named stake, what you chose and why, what followed. If no such time comes to mind, say so plainly, then give the nearest thing: F2, "I ran the weekly content-drop calendar for our main title for the last two years." |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F7, "Wrote the release checklist our QA team still uses." It shows a written checklist, not an announcement; B2's slot covers the seam |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F7, "Wrote the release checklist our QA team still uses." B3's slot covers whether it changed after you wrote it |

## 9. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live ops with a QA background. What do you wish a live-ops producer brought on day one?" | Ties to his own public path and lets him describe the bar he is hiring against |
| R2 | "In your talk you argued a live team is judged by whether its patch notes match what shipped. How does that standard show up in how you write a post-event review?" | Shows you read his published argument, and connects it to the part of the role you would own |
| R3 | "Project Larkspur retires per-title event teams for a single live-ops group. Where does this role sit in that structure after February?" | Diligence on the strategy, and it answers something you genuinely need to know |
| R4 | "With a season pass, which numbers does the producer own and which sit with another team?" | Turns your biggest gap into a scoping conversation about the role |
| R5 | "In the Outage Hour, what separates a strong tabletop from an average one?" | Invites him to say what he scores, and shows you take the format seriously |
| R6 | "What would I need to have shipped by day 90 for you to call this hire right?" | Standard, but it makes the first quarter concrete and is rarely asked well |

## 10. Prohibited claims

Built before the banks. These are the claims this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F9's quote | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or ran season-pass or monetised events | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, never a past. No slot |
| Owned the post-event review and defined its KPIs | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says you presented the numbers. C-bank and D3 slots stay inside the presentation |
| Ran live events across two titles | Inflated form of F3 | F3's quote at its own scope: the weekly content-drop calendar for the main title. The limit is the pack's observation, not words for you |
| Managed the release checklist across releases | Inflated form of F7 | F7's quote at its own scope: you wrote it, and QA still uses it. D2's slot stays inside that |
| Four years producing a live-service game | Inflated form of F1 | The quote at its own scope: four years as an associate producer, two of them running the calendar. F1's slot asks only which part was live-service |

## 11. Sources

**Provided:** the JD you pasted; your background as written in your message; the interviewer's name and title. No dossier was present.

**Searches and fetches sent:**

| Query or page | What came back |
|---|---|
| Search: Saltmarsh Games values | https://saltmarshgames.com/values |
| Search: Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Search: Saltmarsh Games mobile studio strategy news | https://saltmarshgames.com/news/project-larkspur (summary only; page not fetched) |
| Search: Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise (summary only; page not fetched) |
| Fetch: https://saltmarshgames.com/values | Read; three values with their definitions |
| Fetch: https://saltmarshgames.com/careers/interviewing | Read; recruiter call, then the Outage Hour: one 60-minute hiring-manager interview, a live-incident tabletop then a values conversation, no take-home |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Section 8 and bank B, with the three values by their official names |
| 2. Saltmarsh Games interview process, live operations | yes | Loop fixed as one session, tabletop then values; persona weights follow it; no graded-deliverables section because there is no take-home |
| 3. Saltmarsh Games strategy and recent news | yes | A3, A4, C1 and R3, R4; read from a search summary only |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Section 4, D2, E2, B2, R1, R2; one result, role and one talk only |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 12. Upgrade menu

- Your relationship to Tobias (direct manager or skip-level) → persona weights recomputed, and bank A or C reweighted
- The recruiter's note on what the Outage Hour covers → the tabletop questions tightened to the real format
- Your actual CV in place of the summary → F1 to F8 quotes upgraded, and gaps re-graded where the CV says more
- Answers to the open slots, in your own words, outside a drill → F1, F3, F4, F5, F7 and F8 regenerate from them
- A writing sample, such as player-facing notes or a post-event write-up → F8 moves from low confidence and E2 gets real material
- The deck or document behind your monthly retention numbers → F6 from medium to high, and D1 answered from the artifact
- Deep research: up to 6 more searches and 2 more fetches, several more minutes → the full Project Larkspur announcement, his talk read in full, and recent org context for a grounding brief
- A tuesday-dossier.md from an earlier underwriting pass would add verified evidence and named objections; none was needed to build this
