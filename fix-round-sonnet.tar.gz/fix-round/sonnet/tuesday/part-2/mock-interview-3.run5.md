Reading is done, so I'm running the Stripe research now. That's the default L1 tier, with searches on values, interview process, strategy and a representative Product Ops JD.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-3-denied-2cd10a48/stripe_product-operations-manager_interview_pack.md`. I built it for a final round with an unknown interviewer, so the persona weights are flat. Web search wasn't permitted, so there's no Stripe-specific research in it. It has 20 questions covering seven interviewer styles, and 6 questions for you to ask them. The questions are live problems or "pick a time you…" scaffolds. They don't claim anything about your past, because I don't have your CV yet.

I can play the Skeptic on A1, which I'd flag as your highest-ROI rehearsal for now, or any other persona.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is your final round a single conversation or several back-to-back sessions, and do you know who they're with (hiring manager, peer, cross-functional, skip-level)? Anything the recruiter said about focus areas or a take-home would also change the structure.
2. Can you paste the job description and your CV, or a few lines on your relevant work? I'll proceed without them if you'd rather, but they turn the generic rows into stories built on your own sentences.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Built from your message alone: company, role title, and "final round". Interviewer and relationship unknown, so persona weights are flat. No JD, no CV, and no web research ran, so most of this is a worksheet and a set of scaffolds, labeled as such.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: the words you say must come from what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows published values, not generic virtue |
| EXP | Whether claims about your work survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the company and can think at its altitude |
| CASE | A live problem, scored on structure and reasoning |

## Fit snapshot

Worksheet variant: no background was supplied, so every evidence cell reads `none given`. The requirements are role-family patterns, not quotes from a Stripe posting, and are labeled `[generic]`. Fill the evidence column with your own sentences and the bridges become story maps.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run launches or cross-team programs from planning to close-out (typical of the role family, no posting read) | none given | none | [generic] | discovery | Strong evidence is a program you ran with named teams, dates and an outcome you can explain. Selection scaffold: pick one program where several teams depended on you, with a named stake and a result you can describe. If no such program comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define and report the metrics that show whether product work is landing (typical of the role family, no posting read) | none given | none | [generic] | discovery | Strong evidence is a figure you can defend: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Selection scaffold: pick one such figure. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Design and maintain operating cadences, documentation and tooling for product teams (typical of the role family, no posting read) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed, with what it replaced and how you knew it worked. Selection scaffold: pick one, and separate what you designed from what you inherited. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influence product, engineering and go-to-market partners without direct authority (typical of the role family, no posting read) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer or senior partner where you kept both your position and the relationship. Selection scaffold: pick one with a named stake and a visible resolution. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Structure ambiguous problems and prioritize across competing asks (typical of the role family, no posting read) | none given | none | [generic] | discovery | Strong evidence is a time you chose what not to do and can say why. Selection scaffold: pick one with a real trade-off. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

### Requirement coverage

No posting was supplied, so these are role-family requirements, not Stripe's stated ones.

| Requirement | Covered by |
|---|---|
| F1 | B1, G1, F2 |
| F2 | B3, E1, E2, E3 |
| F3 | B2, F3 |
| F4 | A3, C1, D1, D2, D3 |
| F5 | A1, B1, B2, C2, F1, G2 |

## Persona table

Weights are flat. The reasoning is shown so you can recalibrate if you know who is on your loop.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (B) | Live problems from running product teams: diagnose, plan, prioritize | Flat. You said final round but not who runs it; a hiring-manager seat would raise this | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Skeptic (A) | Quiet probing of gaps and motivation | Flat. Probing gaps is common late in a loop, but no source here documents Stripe's final round | Rehearse the most predictable objection until it is boring; name limits plainly; add a ramp plan |
| Values/Behavioral (C) | Scenario questions tied to published values | Lowest depth. Stripe's published values were not retrieved, and no source here shows a values-style round | Map a story to each published value once you have the list; for now, use the scaffolds |
| Peer Evaluator (D) | Seam-splitting with adjacent teams, credit, collaboration | Flat. A cross-functional or peer seat is plausible in any final round | Reciprocity framing; propose seam principles rather than claiming to know the seam |
| Data-Driven Prober (E) | Metrics probed to their assumptions | Flat. Product operations work is measured, so numbers are likely to be probed | Know how each figure was counted; say plainly when you do not know; name your weakest assumption first |
| Pressure (F) | Time-boxed, interrupting, devil's advocate | Flat. A final round is often where composure is tested | Pause, restate, hold a position through two follow-ups before conceding anything real |
| Conversational (G) | Friendly, loosely structured, still scored | Flat. Casual openers can appear in any seat | A 90-second arc for the biography question; treat casual questions as scored |

Loop: no loop source was read, so this pack falls back to the generic archetype (screen, hiring manager, panel). Your persona weights rest on that pattern, not on Stripe's documented process.

## Question banks

Every row is Provenance `[generic]` because no candidate material was supplied and no raising source was read. No guidance below claims anything about your past. Wherever it asks for a story, it is a selection scaffold ending in the honest branch.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick the gap you can name honestly, say it in one plain sentence, then give a concrete ramp plan. Do not bluff a competency the interviewer may own. If no honest gap comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The most predictable objection to any candidate, and the highest-ROI rehearsal in this pack until your material shows a sharper one. Ties to F5; JD because it scores the role's requirements, including gaps |
| A2 | "Why this company, why this role, why now?" | CO | [generic] | Name one specific, verifiable thing about the company that you read yourself, and why it connects to the work you want to do. Do not cite anything you have not read. If nothing specific comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Motivation consistency is scored in every late-stage loop. CO because it tests homework; JD second because it tests fit with the role |
| A3 | "Product operations sits between teams that each think they own the answer. Why would they listen to you?" | JD | [generic] | Answer from what you would do, not from a claimed past: how you earn trust without authority. If a story comes to mind where you influenced a peer or senior partner, tell it in your own words with the stake named; if none does, say so plainly and describe your approach | Probes F4, the influence-without-authority requirement; JD because it scores the role's core tension |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A product launch is slipping and three teams each say another team is the blocker. What do you do in your first week?" | CASE | [generic] | Clarify first: the launch date, what is actually blocked, who decides. Then objective, the dependencies segmented by team, an approach (one shared view, one owner per blocker), the metric that shows it is unblocked, and the risk you would watch. The question needs no claim about your past, so the guidance makes none | A live problem from F1 and F5; CASE because it is scored on structure |
| B2 | "Sketch an operating cadence for a product org of several teams. What would you put in, and what would you refuse to add?" | CASE | [generic] | State the goal of the cadence before any meeting or artifact. Segment by decision type, then say what each element must prove it earns. End with what you would refuse and why. No claim about your past | F3 as a live problem; the refusal half is where judgment shows |
| B3 | "A key adoption metric for a product dropped 20% week over week. Diagnose it." | CASE | [generic] | Clarify definition and instrumentation before causes. Then segment: time, cohort, platform, release. Separate a data problem from a real change. Name the first two checks and what each result would change | F2 as a live problem; instrumentation first is the move most candidates skip |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and an intact relationship afterward. Use "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values-round stem. It touches F4 and tests whether the hard truth actually landed |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named customer impact, the metric you set aside, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values-round stem. It touches F5 through the trade-off |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a claim to know the seam: who decides, who informs, who runs the follow-through. Say how you would handle disagreement with an equal: evidence first, then escalation only for decisions, not for taste. Reciprocity: what your work gives the peer's team | F4; JD because it scores the role's working relationships |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time when credit was shared or contested and say what you did. Use "we" for context and "I" for what was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard peer stem; F4 |
| D3 | "What would you need from me in your first month, and what could you give my team?" | JD | [generic] | Lead with the give: what you would take off their plate and how you would know. Then the needs, kept to a few specific ones. No claim about your past | F4; the reciprocity framing is the point |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a metric you have been accountable for. How was it counted?" | EXP | [generic] | Selection scaffold: pick one figure you can defend, then say how it was counted, what it is sensitive to, and which part was yours, in your own words. If you do not know how it was counted, say so plainly. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2; EXP because it tests attribution and whether the number survives scrutiny |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | A follow-up to whichever figure you chose in E1. Name the weakest assumption you actually know of, before the interviewer does. If you do not know of one, say so plainly | Naming the weak point first converts a gotcha into credibility |
| E3 | "How would you decide which three metrics a product operations function reports every month?" | CASE | [generic] | Start from the decisions the metrics inform and who makes them, then candidates, then what you would drop. Say what each metric would fail to show. No claim about your past | F2 as a live problem |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then give two reasons you can back with things you actually did. Hold the position through two follow-ups; concede specifically on what you do not yet know, never on the core claim. Until your CV is in, the reasons are an answer slot: if you have no such reasons, say so plainly and say what you would bring | Composure test; F5 |
| F2 | "That result, how much of it was actually you?" | EXP | [generic] | A follow-up to whichever story you told. Separate your part from the team's in plain words. If the result was mostly others, say so and return to what you did | Attribution honesty is the point |
| F3 | "Product operations adds a layer of process. Why not let each PM run their own launches?" | CASE | [generic] | Hold the position through two follow-ups: say when process pays for itself and when it does not, then concede the cases where the objection is right. No claim about your past | F3 and F5; tests holding a view without defensiveness |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc once your CV is in; for now, a scaffold: where you started, the one or two moves that led toward product operations, and why this role is the next step. Each step must be something you did. If a step is unclear, say so plainly | Always asked in some form; casual register, still scored. F1 |
| G2 | "What do you find most interesting about product operations as a discipline?" | JD | [generic] | Answer with one specific problem in the work that you care about and why, in your own words. Casual questions about the role are scored for genuine interest | F5; economy and genuine interest |
| G3 | "What questions do you have for me?" | JD | [generic] | Use the reverse questions below; never answer "I think you've covered everything" | Rapport-style interviewers weight this slot heavily |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a great first six months look like for this role, and what would make it a miss?" | It asks for the scoring sheet directly and shows you think in outcomes |
| R2 | "Where does product operations end and product management begin here, and where is that seam still being worked out?" | Shows you expect a seam and respect that it is contested |
| R3 | "How does the team decide which launches or programs get operational support, and which do not?" | Prioritization is the role's core trade-off |
| R4 | "What is the one process here that you wish had been fixed two years ago?" | Invites candor and shows you look for real problems |
| R5 | "How do you know product operations is working? What do you look at?" | Probes the measurement culture you would join |
| R6 | "If this seat is a peer's: what could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer interviewer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your past work, results or role | No candidate material was supplied, so there is nothing to quote | Every answer above is a scaffold or an answer slot. Words about your past come only from your own sentences, once supplied |

## Sources

Provided documents: none. Your message supplied the company, the role title and the round.

Searches sent, all refused (the host did not grant search permission):

- Stripe operating principles values: refused
- Stripe interview process product operations manager: refused
- Stripe strategy 2026 news: refused
- Stripe Product Operations Manager job posting: refused

No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have supplied the official value names for a values cheat sheet; the sheet is absent |
| 2. Stripe interview process, product operations | unavailable | Would have named the loop's rounds and set persona weights; weights are flat and the loop is a generic archetype |
| 3. Stripe strategy and recent news | unavailable | Would have grounded a CO or CASE question in current strategy; A2 is generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the fit snapshot rows into inferred, quoted requirements; they are generic |

## Upgrade menu

- Search permission, or a pasted Stripe values page and interview-process notes: adds the values cheat sheet, persona weights from the real loop, and a strategy-grounded CO question
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes, once consent is given; it would add a strategy brief and role-family loop reports
- The job description: turns the five generic fit rows into quoted requirements and lets the JD questions cite the posting
- Your CV or a few lines on your relevant work: turns F1 to F5 from selection scaffolds into story maps built on your own sentences, and sharpens the highest-ROI objection
- Interviewer names and each session's relationship: adds an interviewer read, tuned persona weights and a reverse question tied to their path
- The recruiter's prep email: covers any pre-declared deliverable and stated focus areas
- A tuesday-dossier.md from an earlier fit assessment: would add verified evidence and a prohibited-claims list
