Writing the prep pack now. Web search was denied, so the pack will be built from your JD and background only.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-denied-745904aa/saltmarsh-games_live-operations-producer_interview_pack.md`.

- **Assumption:** You didn't say how Tobias relates to the role, so I built it for a hiring-manager round.
- **No web research:** My four searches were refused, so nothing about Saltmarsh's values, interview loop or strategy is in the pack. Tobias's own background isn't in it either. The "Sources" section lists the four refused searches and what each would have added.
- **Highest-ROI prep:** A1, "what makes you ready to go from a weekly content-drop calendar to a live-events calendar across two titles". The pack keeps your answer to what you actually said you did.
- **Your two stated gaps:** A2 and H1 cover in-app purchases. A3 covers working across teams, since you've never led one.
- **What it covers:** 22 questions across seven interviewer styles, a table mapping each JD requirement to the questions that cover it, six reverse questions, a list of claims the pack won't coach, and a Wednesday-to-Friday triage order.

I can play the Skeptic on A1, live, with follow-ups and feedback. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, a peer or a skip-level, and did the recruiter name any focus areas or anything to bring? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Interviewer:** Tobias Wrenfield, Head of Live Operations
- **Format:** one 60-minute session, on Friday
- **Relationship (assumed, not stated):** Tobias is the hiring manager or senior to the role, so the pack uses the hiring-manager prior. If he is a peer, the persona weights change.
- **Candidate:** Femi

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script. Question letters skip F so that F1 to F9 always mean fit-snapshot rows.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Where a cell says "answer slot", it is an instruction for the interview. Answer it from your own experience, and take the second branch if the practice was not yours or never existed. Everything labeled "pending your approval" is proposed language. Nothing is final until you say it is true of you.

## Prep triage

You have until Friday. Do these in order. Everything else is insurance.

1. A1, the highest-ROI prep in the pack: why you are ready to move from a content-drop calendar to a live-events calendar. Rehearse it aloud until it is boring.
2. A2 and H1: say "I've never worked on a game with in-app purchases" plainly, then give the plan.
3. C1 and H2: decide what you can and cannot say about how the retention numbers were counted, and which part was yours.
4. B1 to B4: think aloud on the four live problems. Clarify, structure, then answer.
5. D1: the 90-second arc, built only from your own sentences.
6. Pick three reverse questions from the list below.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not an events calendar and not two titles, with nothing inspected behind it. The words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events line makes a probe on how the drops differed from events likely. If any of the calendar's contents or dates were yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and describe how you ran the calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [inferred] | discovery | The quote says you have not led a team. It does not say whether you worked across disciplines, and the bridge should not be stretched either way. Plain words for the quote: "I've never led a team." Answer slot: the JD names four teams per update, so a probe on how an update came together is likely. If you worked with any of those teams on a date or a release, say which and what you did, in your own words; if you did not, or it was not yours, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a review or chose its KPIs. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-KPIs line makes a probe on where the numbers came from likely. If you chose or produced any of what was reported, say which and how, in your own words; if the numbers came from elsewhere, or it was not yours, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | The quote already reaches the requirement, but nothing is inspected behind it, so expect a probe. Lead in its own terms: "I wrote the release checklist our QA team still uses." Keep your verb, wrote, and let them ask about the rest |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | The quotes show four years producing and two of them on a weekly content calendar. They do not say whether the title ran as a live service. Answer slot: the JD's live-service line makes that probe likely. If it did, say what made it one, in your own words; if it did not, or you are unsure, say so plainly and describe the weekly cadence you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | Your strongest row. Lead with it in the quote's terms: "For the last two years I ran the weekly content-drop calendar for our main title." Nothing is inspected behind it, so expect a probe on how it ran, answered in your own words |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement: "I presented the monthly retention numbers to the studio head." The probe will be on the numbers themselves: how counted, what they are sensitive to, the assumption you would defend least, which part was yours. The pack gives no method for any of them (see C1 and H2) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | discovery | A checklist others still use is writing, but the quote does not show how clear it is or how it reads to others. Answer slot: the JD's written-communication line raises a probe. If there are other things you wrote that others relied on, say which, in your own words; if the checklist is the main one, say so plainly and stay with it |
| F9 | In-app purchases — not in the JD; added because you raised it | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past: what you would ask first, and whom. Never a claim to monetization work, and nothing added to make the gap feel smaller |

Proposed language in the Gap and bridge column: pending your approval.

## Persona table

The loop rests on your own words: one 60-minute session run by Tobias. No company loop source was read, so the weights below come from the hiring-manager prior, the JD and your stated gaps. Recalibrate them if you know something I don't.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of F2, F9 and the jump from one calendar to two titles | High. The hiring-manager prior puts it first, and F2 and F9 are the gaps you stated | Rehearse the single most predictable objection (A1) until it is boring. Use only the quotes, say the limit plainly, and add a concrete ramp plan |
| Case/Strategist (B) | Live problems from the role: a slipping release, a retention drop, a first-90-days plan | High. Also from the hiring-manager prior, and the JD is plan-and-run work | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Data-Driven Prober (C) | Line-by-line on the retention numbers and KPIs | Medium. F3 and F7 are your headline evidence and the JD names KPIs | Know what you can and cannot say about how the numbers were counted. Name the assumption you would defend least before they do |
| Conversational (D) | An opening biography question and casual asks about live events | Medium. A casual opener is possible in any session, so treat it as scored | A pre-scripted 90-second arc from your own sentences (D1). Never answer "I think you've covered everything" to the reverse-question slot |
| Peer Evaluator (E) | Seams with QA, design and engineering | Low. Tobias is assumed senior, but the JD makes QA and cross-team seams a topic | Reciprocity framing, and seam principles rather than pretending to know the seam |
| Pressure (H) | Time-boxed "why you" and "how much was you" | Low. It is plausible in any session, but nothing in what you shared points to it | Pause, restate, anchor in your quotes. Hold through two follow-ups, then concede specifically |
| Values/Behavioral (G) | Scenario probes on a hard truth or a player-first call | Low. No values-style round is documented and no published values were read | Selection scaffolds with an honest branch, since none of your sentences carries these stories |

## Question banks

### A. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've been running a weekly content-drop calendar for your main title. What makes you ready for a live-events calendar across two mobile titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | The highest-ROI rehearsal in this pack. Open with the quote at its own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Expect follow-ups: first, "how is a live-events calendar different from content drops?", where you give your own view of the difference as a view, not as past experience; then, "and two titles at once?", answered as a plan for how you would sequence two calendars, never as a past. Hold the quote through both. Answer slot: if any drops were timed or themed events, say how, in your own words; if they were not, or the distinction was not yours to draw, say so plainly and stay with the calendar you ran | F1 is the evidence for the JD's headline line and the likeliest place to be probed. The limit sits in F1's bridge, and this question will arrive in some form. JD because it scores the stated requirement |
| A2 | "You haven't worked on a game with in-app purchases. How would you handle events on a title that has them?" | JD | [grounded] "never worked on a game with in-app purchases" | Say it first and plainly: "I've never worked on a game with in-app purchases." Then give a plan, not a past: what you would ask in week one, whom you would ask, and which numbers you would read. Hold through two follow-ups by returning to your plan and to your two quoted strengths, never by claiming exposure to purchases. Concede specifically: you do not yet know how events and purchases interact on these titles | F9 is the one gap you stated outright, so it is the most predictable objection after A1. JD because the question scores role readiness |
| A3 | "Tell me about a time you had to get design, art, engineering or community aligned on a date you did not control." | JD | [grounded] "Never led a team" | None of your sentences carries this story, so this is a selection scaffold. Pick an instance with named disciplines, the date at stake, what you did to get agreement, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. If leading comes up, the plain words are "I've never led a team" | F2 is the JD's coordination line with no evidence behind it. JD because it scores that stated duty |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases"; "Never led a team" | Pick one, not a list, and say it in one sentence using the quote you actually have. Then give the first-week plan. Choose the part you honestly believe is weakest. The pack's reading is that F9 is the only gap you stated, and F2 and the two-title scope are thin | A persona stem built from the fit snapshot's thinnest rows (F9, F2). JD because it asks about the stated requirements |
| A5 | "Why this role, and why Saltmarsh, and why now?" | JD | [generic] | A selection scaffold: your reasons must be yours. Use the JD's own lines, the live-events calendar and the release checklist, as the hooks, and name nothing about Saltmarsh that you have not read yourself. If you have no reason beyond the role, say that plainly | Skeptics score motivation consistency. `[generic]` because no company research is in this pack, so the question makes no claim about Saltmarsh |

Proposed language in this bank: pending your approval.

### B. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A themed weekend event is set for Friday. On Thursday, engineering says the build cannot carry the final feature. What do you do?" | CASE | [generic] | Clarify first: which feature, how central to the event, what the fallback is. Then the objective, the options (cut, slip, ship reduced), who you would talk to (design, art, engineering, community, QA), what the release checklist needs, and what players are told. Close with what you would put in the post-event review. The question needs no claim about your past, so the guidance makes none | Live problem from the JD's coordination and release-checklist lines (F2, F4). `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Day-7 retention on the last event came in 20% below the previous one. Diagnose it." | CASE | [generic] | Clarify definitions and baseline first: which cohorts, which comparison. Then segment (new versus returning, platform, version), check what else changed that week (bugs, overlapping content), say what you would report, and challenge one premise respectfully. Think aloud and state your hypothesis early | A stock Case stem aimed at the JD's retention line (F7). `[generic]` because it is a pattern |
| B3 | "Sketch your first 90 days taking over the calendar for two titles. What do you need to know first?" | CASE | [generic] | Start with what you would ask: what is fixed, what is flexible, who owns what, and where the two titles share teams. Then listening, mapping, one early small win, and what you would report back. Plans only; nothing about your past | Covers the JD's two-title calendar scope (F1). `[generic]` because it is a pattern |
| B4 | "Design the post-event review you would run: what is in it, who sees it, and which KPIs it reports." | CASE | [generic] | Structure it: purpose, inputs, the KPIs and what each tells you (name only ones you can define), who receives it, and what decision it feeds. Say which KPIs you would want to confirm with the team before fixing. No past is claimed | The JD's own-the-review line (F3) asked as a design question, so it needs no claim about your past. `[generic]` because it is a pattern |

Proposed language in this bank: pending your approval.

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start from the quote: "I presented the monthly retention numbers to the studio head." Answer slot, in your own words: how the numbers were counted, what they are sensitive to, the assumption behind them you would defend least, and which part was yours. If you know, say so; if you do not, or someone else produced them, say so plainly and stay with presenting them. Name the weakest assumption before they do | F7 and F3 are your headline evidence. Probers go two levels deep on any figure, so this is the defend-the-number rehearsal. EXP because it tests attribution |
| C2 | "Tell me about a time retention numbers changed what the team planned." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | None of your sentences carries this story, so this is a selection scaffold. Pick an instance with a named number, the decision it fed, and your part in it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An open prompt themed on the JD's retention line (F7). EXP because it tests what you did |
| C3 | "Which retention metrics would you want in the first event review, and what would each tell you?" | JD | [generic] | Name only the metrics you can define in a sentence, and say what each would and would not tell you. For any you cannot define, say so plainly and say how you would learn it. No figure is supplied for you | The JD's KPI line (F3) with nothing premised about your past. `[generic]` because it is a pattern |
| C4 | "If I asked you for a three-line update on an event for design, art, engineering and community, what would be in it?" | JD | [generic] | Say what each audience needs in order, what you would leave out, and how you would mark open questions. Then say it in three real sentences, aloud. The question asks for a plan for a message, not a claim about one you sent | Covers the JD's written-communication line (F8) through a spoken task. `[generic]` because it is a pattern |

Proposed language in this bank: pending your approval.

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey: how did you get from the puzzle studio to wanting this role?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc using only these four sentences as beats, in your own words: the four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for your main title for the last two years; the release checklist QA still uses; the monthly retention numbers you presented to the studio head. Close with your own reason for live events. Say the reason yourself; the pack does not supply it | F5, F6, F4 and F7 are the pool this arc draws on. Conversational questions are still scored. EXP because it tests the story against the record |
| D2 | "What are you actually playing or following in mobile live events these days?" | JD | [generic] | Name only titles or events you have actually played or followed, and say one specific thing you noticed. If you have not played Saltmarsh's own titles, say so plainly and say what you would study first. If nothing comes to mind, say that and name what you would look at before Friday | A casual ask on a hot JD topic is still scored. `[generic]` because no research on Saltmarsh's titles is in this pack |
| D3 | "Tell me about a release you are proud of." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: the checklist, and that your QA team still uses it, which are the beats the quote states; tell them in your own words. Answer slot: if a particular release is the one you mean, say what it was and which part of it was yours; if the checklist is the part you are proud of, or the release was not yours, say so plainly and stay with the checklist | An open prompt themed on the JD's release-checklist line (F4). EXP because it tests what was actually yours |

Proposed language in this bank: pending your approval.

### E. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The JD has you managing the release checklist with QA. Where does your job end and theirs begin, and what happens when we disagree about a date?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Reciprocity first: what you bring QA, which is a checklist QA still uses, in the quote's own words. Then propose seam principles rather than pretending to know their seam: who decides what, who can say no, what gets written down. No disagreement story is carried by your quotes, so use a selection scaffold ending in its honest branch: if no such disagreement comes to mind, say so plainly, then say how you would handle it | F4 and F2 both press on the QA and cross-team seam. JD because it scores the stated checklist duty |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold: pick an instance with the teams involved, what each contributed, and how credit was stated. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then say how you would handle it | A stock peer stem on credit-sharing. `[generic]` because it carries no claim about you |

Proposed language in this bank: pending your approval.

### G. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold: choose an instance where the hard truth actually landed, with a named stake, the moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not supply an ending the facts do not have | A standard values stem. `[generic]` because no published values were read and none of your sentences carries this story |
| G2 | "When did you put a player's experience ahead of an internal date or metric?" | VAL | [generic] | A selection scaffold: name the date or metric, what the player-facing cost was, and who you had to persuade. If no such time comes to mind, say so plainly, then say how you would weigh it | A standard values stem adapted to live operations. `[generic]` because nothing about Saltmarsh's values was researched |

Proposed language in this bank: pending your approval.

### H. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you, over someone who has already run live events at a mobile studio?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "never worked on a game with in-app purchases" | Pause and restate. Then three sentences from your own quotes: the weekly content-drop calendar for your main title for the last two years; the release checklist QA still uses; the monthly retention numbers you presented. Concede specifically: "I've never worked on a game with in-app purchases." Hold through two follow-ups by returning to those quotes, never by adding to them | F6, F4 and F7 are the strengths and F9 is the concession. Pressure interviewers score composure, not content. JD because it scores fit against the role |
| H2 | "That retention number you presented: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold on what the quote says: "I presented the monthly retention numbers to the studio head." Answer slot: if you also produced or analyzed any of them, say which part, in your own words; if someone else did, or it was not yours, say so plainly and stay with presenting them. Hold through two follow-ups, then concede exactly what was not yours | F3 and F7. The attribution probe exists to catch inflation, so the rehearsal is candor. EXP because it tests what was actually yours |

Proposed language in this bank: pending your approval.

## Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, B3, H1 |
| Coordinate design, art, engineering and community teams on each update | A3, B1, C4, E1 |
| Own the post-event review and the KPIs it reports | B4, C1, C3 |
| Manage the release checklist with QA | B1, D3, E1 |
| 3+ years producing live-service games or apps | A1, D1, H1 |
| Experience running a content calendar | A1, B3, D1 |
| Comfortable with player-retention metrics | B2, C1, C2, C3, H2 |
| Clear written communication | C4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a strong first 90 days look like for the person in this seat?" | Shows you plan against outcomes, not tasks |
| 2 | "How is the calendar planned today across the two titles: what is fixed and what is flexible?" | Shows you are already thinking about seams between the two titles |
| 3 | "Which KPIs does the post-event review report now, and which would you most like to change?" | Ties to the JD's own-the-review line and invites his view |
| 4 | "How does the release checklist work with QA today?" | Shows you start from the existing process, not your own |
| 5 | "How do in-app purchases connect to the events calendar on these titles, and who could help me learn that?" | Turns your stated gap into a plan and shows you know what to learn first |
| 6 | "What does the team most want from a producer in how they work with design, art, engineering and community?" | Gives you his priorities in his own words |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed the teams on each update | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I've never led a team." No slot names leading |
| Has worked on a game with in-app purchases | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I've never worked on a game with in-app purchases." Then a plan, never a past |
| Owned the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for your main title. A1's slot stays inside the calendar you ran |
| Owned the post-event review and chose its KPIs | Inflated form of F3 | F3's quote at its own scope. The material says you presented the numbers. C1's and H2's slots ask only how they were counted and which part was yours |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope. The material says you wrote the checklist QA still uses. D3's and E1's slots stay inside the checklist |

## Sources

Provided: the job description you pasted, and your own background as written in your message. No dossier was present.

Searches sent, each refused (permission was not granted, so nothing came back):

| Query | Outcome |
|---|---|
| Saltmarsh Games mobile studio company values | refused |
| Saltmarsh Games interview process live operations producer | refused |
| Saltmarsh Games strategy news mobile titles | refused |
| Tobias Wrenfield Saltmarsh Games Head of Live Operations | refused |

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Every search was refused. It would have fed a values cheat sheet and themed the VAL bank; both are absent |
| 2. Saltmarsh Games interview process, producer role | unavailable | Every search was refused. It would have named the real rounds and reweighted the personas. The loop here rests on your own words |
| 3. Saltmarsh Games strategy and recent news | unavailable | Every search was refused. It would have supplied a strategy-grounded CO or CASE question; none is in the pack |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | The one search was refused. It would have supplied the interviewer read and a reverse question tied to his path; both are absent |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is your future manager, a peer or a skip-level → reweights every persona bank
- Anything the recruiter said about format, focus areas, or something to bring → coverage of any pre-declared deliverable
- Your CV → evidence cells quoted from it, and any headline figures it carries would get defend-the-number questions
- Your answers to the slots in F1, F3 and F5, and in A1, C1 and H2 → those rows regenerate on your own words
- A writing sample you are proud of, such as an update note or a review → F8 goes from discovery toward a supported row
- Saltmarsh's published values page, or any strategy material, pasted in → a values cheat sheet and a strategy-grounded CO question
- Search access, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the four unavailable rows above, including an interviewer read and a reverse question tied to Tobias's own path
- A tuesday-dossier.md, if you have one → verified evidence and prohibited claims arrive pre-graded; never a prerequisite
