Web search wasn't permitted, so I'm building the pack from your message and the recruiter's email only. Writing it now.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-5-denied-86971f9e/kelverton-rail_senior-partnerships-manager_interview_pack.md`. The pack names B1 as the highest-ROI prep: "You've never sold into rail specifically. What do you say to an operator who asks why you?" Your own message gives you the honest answer, and it needs rehearsing until it feels boring.

I built it on the recruiter's email as you quoted it, with Deepa as the hiring manager and Ross as the commercial challenger.

- **Market report:** it didn't come through to me, so nothing in the pack draws on it. The POV section tells you how to use it (one consensus item, one divergence, one thing you'd decline) and leaves blanks for you to fill from it.
- **Web search:** search permission wasn't granted. I tried six searches (values, interview process, strategy, Deepa, Ross, a sample job description) and all were refused. The pack has no company or interviewer research, and the Sources table shows what each search would have changed.
- **POV build:** the pack includes three thesis options with the concession you have to say aloud, plus a 13-minute talk track that ends on what it means for the operators.
- **Prep time:** your four hours are split into two sessions in the order that matters.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description, or say skip? With it, the requirements are quoted from the posting instead of the recruiter's email, and any location, travel or pay terms show up.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday, 60 minutes, panel.
**Panel, as the recruiter's email gives it:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Deepa is treated as the hiring-manager relationship. Ross's relationship to the role is not stated, so he is treated as a senior commercial panelist.
**Shape, as the recruiter's email gives it:** the first 15 minutes are a spoken POV, "no slides needed, just talk us through it", then Q&A, and "Ross will push on commercials".
**Built on:** the recruiter's email as you quoted it and your own background message. There was no job description, the market report did not reach this session, and web search was not available, so the company facts here are only what you told me.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for your own words, not a script.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether you can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role, delivered live |

Provenance labels: `[grounded]` traces to something you or the recruiter wrote. `[inferred]` is derived from an adjacent source, with the derivation named. `[generic]` is a role-family pattern with no claim about this employer. Where guidance rests on your own words, the sentence is quoted beside the label.

**Highest-ROI prep in this pack: B1.** Some version of that question will be asked, and a calm, rehearsed answer changes the interview.

## Prep triage

You have about four hours across two sessions. Do these in order.

| Order | Time | Task | Where |
|---|---|---|---|
| 1 | 60 min | Build the POV: choose one or two theses, write the concession for each, fill the blanks from the report | POV build section |
| 2 | 60 min | Say the POV aloud, timed, at least three times; aim for 12 to 13 minutes so you keep two spare | POV build section, talk track |
| 3 | 45 min | Rehearse B1, B2 and D1 aloud until the plain acknowledgments feel boring | B bank, D bank |
| 4 | 45 min | Write down what you actually know about how the £4M and the 6-to-40 were counted, and mark each slot you cannot fill | C1, C2, D2 |
| 5 | 30 min | Skim A1 to A5, choose three reverse questions | A bank, reverse questions |

Sessions: 1 and 2 in the first, 3 to 5 in the second. Everything else in this pack is insurance.

## Fit snapshot

No requirement here is a gate. Nothing supplied states a term such as location, pay, authorisation or travel, and the upgrade menu says what a JD would settle. Requirements are quoted from the recruiter's email because no JD was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company and a partner count, with nothing inspected behind it, and nothing about operator partnerships. The words stay at the quotes: "I was running the ISV channel at a payments company, and I took it from 6 partners to 40." Answer slot: the recruiter's ask makes a probe on what carries over from that channel to operator partnerships likely. If you can say what carries over, say it in your own words; if nothing does, or you cannot say, say so plainly and stay with what you ran |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The quote names bus and light rail network planning, and the pack's observation is that it does not name train operating companies. The words stay at its scope: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: expect a probe on which operators you worked with and how close they are to Kelverton's operators. Say which, and what your part was, in your own words; if none were close, say so plainly and stay with the bus and light rail network planning |
| F3 | "Ross will push on commercials" — recruiter's email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The quote gives a figure, not the commercial terms behind it, and the material does not show how it was counted. Answer slot: expect to be asked how the roughly £4M was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. Say each in your own words; if you do not know how it was counted, say so plainly and stay with the figure as you gave it |
| F4 | "Ross will push on commercials" — recruiter's email; the part your own words speak to is direct accountability for a number | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never carried a direct quota, only influenced revenue." Then how you would want commercial accountability to work here, said as a plan and never as a past. Never a claim to quota work, and nothing added to make the gap feel smaller |
| F5 | "our operator partnerships" — recruiter's email; the requirement does not mention selling, the gap is the one you named and the one a skeptical panelist reaches for first | "Never sold into rail specifically" — your message | none | [grounded] | capability | Words: "I have never sold into rail specifically." Beside it, and only at their own scope, F2's quote and F1's "running the ISV channel". Then a plan for your first weeks, said as a plan. The pack does not say what your other work proves; the panel draws that inference |

## Graded deliverable: the 15-minute POV

The recruiter asked for a spoken POV on where you would take Kelverton's operator partnerships over 18 months, ending on what it means for the operators. It is graded, so it gets its own build. The market report was circulated by Kelverton's own strategy team, so the panel knows it and, because the recruiter attached it, other candidates may have it too. Reciting it scores as homework. Bring one consensus item from it to prove you read it, then one thesis-driven divergence with reasons, then the anti-pick.

**Grounded facts to build on**

| Fact | Row | Quote, exactly |
|---|---|---|
| Your channel experience | F1 | "last 4 at a payments company running the ISV channel" |
| Your partner-count figure, with its limits | F1 | "took it from 6 partners to 40, roughly £4M of influenced revenue" |
| Where your view of operators comes from | F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" |
| Your stated limit on commercial ownership | F4 | "never carried a direct quota, only influenced revenue" |

**Theses to choose from.** Pick one or two. Each is a pattern, not a claim about Kelverton, and each carries a concession you must say aloud.

| # | Thesis pattern | Mandatory concession | Where your evidence fits | Provenance |
|---|---|---|---|---|
| T1 | Go deeper before wider: fewer operator relationships, each run as a joint plan | Slower headline partner count, and it needs a reason to depart from breadth | F1's quote is a breadth number. If you argue depth, say in your own words what is different here; if you cannot say, choose another thesis | [generic] |
| T2 | Make operators' input a standing part of how Kelverton decides what to build | It asks for roadmap time that partnerships does not control | F2's quote at its scope is the only place your view of operators comes from; use it as "where I'm coming from", never as proof | [generic] |
| T3 | Shape commercial terms around what operators get out of the product | Harder to forecast, and a harder conversation with Ross | F4's quote: offer it as a hypothesis to test with Ross, never as something you have done | [generic] |

**Differentiation against the report**

| Move | What to do | Why | Provenance |
|---|---|---|---|
| Consensus item | Choose one item the report treats as a priority, say it in your own words, and say why you agree | Shows you read it without reciting it | [generic] |
| Divergence | Choose one place where your thesis departs from the report and give the reason | Judgment scores higher than recital | [generic] |
| Anti-pick | Name one thing you would explicitly not do in the 18 months, and why | A partnerships role is partly about choosing what to decline | [generic] |

The report did not reach this session, so the pack cannot fill these blanks for you. Answer slot: your picks come from the report itself, in your own words; if the report offers no clear consensus item to agree with, say that plainly and start from your thesis.

**Talk track, about 13 minutes**

| Time | Beat | Note |
|---|---|---|
| 0:00 to 1:00 | What you are working from | Say what you are using and what you do not have, such as internal data, in your own words |
| 1:00 to 3:00 | The consensus item | One item from the report, one sentence of agreement |
| 3:00 to 8:00 | Your thesis across 18 months | Three stages: months 0 to 6, 6 to 12, 12 to 18. For each, what you would start and what you would stop |
| 8:00 to 11:00 | What it means for the operators themselves | The requested close. Name one change an operator would notice and how they would notice it, in operators' own terms from the report |
| 11:00 to 12:30 | Concession and anti-pick | Say the concession plainly, then the thing you would not do |
| 12:30 to 13:00 | Invite the push | Name the weakest assumption in your POV before Ross does |

## Persona table

The loop source is the recruiter's email: one panel session, 60 minutes, a spoken POV then Q&A. That establishes this session, so no archetype fallback is used.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| A Case / Strategist | Live problems on operator partnerships, probing your POV | High | Hiring-manager prior for Deepa, and the POV makes this register certain | Clarify, structure, think aloud, challenge one premise respectfully |
| B Skeptic | Quiet, persistent probing of the two gaps and the move | High | Hiring-manager prior, plus the two negatives in F4 and F5 | Rehearse B1 until it is boring; bridges only from adjacent quotes, with the limit said plainly |
| C Data-Driven Prober | Figures taken to their assumptions | High | Recruiter says Ross "will push on commercials", and F3 is a figure | Know how each number was counted; say plainly when you do not |
| D Pressure | Time-boxed challenge to your motives and your share of results | Medium | Senior commercial panelist and the word "push" | Pause, restate, hold through two follow-ups, concede specifically |
| E Peer Evaluator | Seam between partnerships and commercial | Low | Nothing says either panelist is a peer | Offer seam principles; do not pretend to know the seam |
| F Conversational | Friendly opener and open Q&A | Low | Second-round Q&A after the POV | Pre-script the 90-second arc; treat casual questions as scored |
| G Values / Behavioral | Scenario probes | Low | The recruiter's email names no values round and no published values were read, so no values round is detected | Use the selection scaffolds and their honest branch |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What would you want to learn in your first 30 days that could change the plan you've just described?" | CASE | [generic] | Clarify before you structure: name two assumptions your POV rests on, say what evidence would break each, and who you would ask. Take them from your own POV, not from a list. Then say what you would do if the answer went against you. No claim about your past is needed, so none is made | The natural follow-up to any POV; F1 is where the POV's own evidence is thinnest, so assumptions are what gets probed. CASE because it scores reasoning |
| A2 | "Take two operators that differ a lot from each other. How would your plan change between them?" | CASE | [generic] | Say first what dimension you are segmenting on and why, then what changes and what stays constant. Pick the dimension from the report or your POV. Limit the answer to what you can defend aloud | Segmentation tests whether the POV survives contact with real variation; F2 is the row it presses on |
| A3 | "An operator asks for something outside your plan and ties it to renewing. What do you do first?" | CASE | [generic] | Clarify the ask and the deadline, separate the request from the need behind it, decide who else has to be in the room, say what you would not commit to alone, say what you would record. Said as a plan, with no past claimed | Tests composure and judgment on a live commercial moment; F3 and F4 are why commercial colleagues will care how it ends |
| A4 | "What do you think we are most likely to get wrong about operators in the next 18 months?" | CO | [grounded] "bus and light rail network planning" | Pick one hypothesis, give the evidence, say what would change your mind. Label what comes from the report and what comes from your own transport consulting, and say the latter at its scope: "my transport consulting was bus and light rail network planning." Answer slot: if something from that work bears on your hypothesis, say what it was and what your part was, in your own words; if nothing does, say so plainly and rest on the report | The question that lets you show company altitude without a strategy brief; F2 is the only row that can support it, and only at its scope. CO because it scores homework depth |
| A5 | "How will we know, 18 months from now, that operator partnerships have worked? Give me three measures." | CASE | [grounded] | Cover three sides: a measure on the operator's side, a measure on Kelverton's side, and a leading indicator. Name one popular measure you would refuse to use and why. The recruiter asked you to land on the operators, so at least one measure must be theirs. No past claimed | The recruiter's "what it means for the operators themselves" turns into a measurement question; F1 and F2 are the rows it tests. CASE because it scores structure |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail specifically. What do you say to an operator who asks why you?" | JD | [grounded] "Never sold into rail specifically" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I have never sold into rail specifically." Then the nearest ground your quotes carry, at its scope: "My transport consulting was bus and light rail network planning" and "I was running the ISV channel at a payments company." Do not say what those prove; let them draw it. Say the limit before it is asked, as a plan in your own words: what you would learn first, and from whom. Follow-up 1, is that close enough: restate the scope and ask what they would want to see. Follow-up 2, why not hire someone from rail: hold on the quotes, and say you cannot speak to candidates you have not met. Answer slot: if you have worked with a rail operator in any capacity, say what and what your part was, in your own words; if not, say so plainly and stay with the quotes | F5 is the likeliest place the panel presses, and Deepa is the person who will carry the answer afterwards. JD because it scores fit to the operator-facing mandate |
| B2 | "Your numbers are influenced revenue rather than a direct quota. How would you want commercial accountability to work in this role?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Open with the plain acknowledgment: "I have never carried a direct quota, only influenced revenue." Then answer the question asked: say how you would want accountability set and why, as a plan in your own words. Hold the plan through two follow-ups; concede specifically what you would want agreed before you take a number. Never imply you have carried one | F4 is the second predictable objection and Ross is the person who will probe it. JD because it scores the commercial side of the role |
| B3 | "Why move from a payments ISV channel to rail scheduling software, and why now?" | JD | [grounded] "last 4 at a payments company running the ISV channel" | Your material does not say why you are moving, and the pack will not supply a reason. Pick one reason you can defend with something you have actually looked at, such as an operator problem or a finding in the report. Say what draws you in one sentence, then what you would be leaving. If no reason beyond general interest comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle the move | The Skeptic's standard motivation probe; F1 is the row being moved away from. JD because it scores whether the story holds together |
| B4 | "Your channel was payments ISVs and this role is operators. What transfers?" | JD | [grounded] "last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40" | Story-mapped on F1: the channel and the partner count, which are the beats the quotes state. Say them in your own words. Answer slot: if you can name what transfers, say it in your own words; if you cannot, say so plainly and return to what you ran | F1 is the evidence for the partnership requirement and the thinnest bridge to operators. JD because it scores the stated role |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Say the figure as you gave it: "roughly £4M of influenced revenue." Answer slots, in your own words: how it was counted; what it is most sensitive to; the assumption behind it you would defend least, named before they ask; which part was yours. If you do not know how it was counted, say so plainly. Do not upgrade "influenced" into anything else | F3 is the headline metric and Ross's stated focus. EXP because it tests whether the number survives |
| C2 | "Walk me through the move from 6 partners to 40. How was a partner counted at each end?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slots, in your own words: how a partner was counted; what the count is most sensitive to; the assumption you would defend least; which part was yours. If you do not know how it was counted, say so plainly and stay with the figure as you gave it | F3 and F1 both carry this figure. EXP because it is a defend-the-number question |
| C3 | "Influenced revenue: how was that defined, and how would it translate into a number you'd own here?" | EXP | [grounded] "only influenced revenue" | Answer slot: say how influenced was defined in your own words; if there was no formal definition, or you do not know it, say so plainly. Then the translation is a plan, not a past: say what you would want to be measured on. Nothing about quota work is claimed | F3 and F4 meet here; a Prober will separate the two quickly. EXP because it tests precision about your own number |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically" | Pause and restate the question. Plain acknowledgment: "I have never sold into rail specifically." Then the two quoted pieces of ground, at their own scope, and stop. Hold through two follow-ups by returning to those quotes; concede that you cannot compare yourself to people you have not met, and say what you would do in your first weeks, as a plan | F5 under time pressure. JD because it scores the same fit question as B1 with composure added |
| D2 | "That £4M, how much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Hold the figure as you gave it. Answer slot: if you can say which part was yours, say it in your own words; if it was a team figure or you cannot separate it, say so plainly and stay with the figure as you gave it. Concede specifically after the second follow-up, never on the whole figure | F3 is where attribution questions land. EXP because it tests honesty about your share |
| D3 | "Your plan costs money. What do you cut to pay for it?" | CASE | [generic] | Decide aloud: name what you would stop and why, then what you would protect. Hold the choice through two follow-ups and concede the trade-off in specific terms. No past claimed | Tests whether the POV was a wish list; F1 and F4 are why the commercial panelist will ask. CASE because it is a live trade-off |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam on a deal with an operator, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam, and offer what you would bring to their team, not only what you would need. For a disagreement story: pick a time you disagreed with a colleague over who owned a relationship; it needs a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Partnerships and commercial share operator deals; F4 is why the seam will be probed. JD because it scores partnership fit |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a time credit was shared across teams; it needs a named stake and how credit was split. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A common peer probe, relevant to any influenced-revenue number; F3 is the row it touches |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc in three beats, each a sentence you have already written: the partnerships years, the consulting years, then why this role. Your material gives the contents, not the order of the middle years, so tell the sequence in your own words. Answer slot for the last beat: your reason for this role is yours to say; if it is not yet clear to you, say so plainly and tell the story without it | The Conversational interviewer opens with biography and scores it; F1 and F2 are the rows it draws on |
| F2 | "What was the most interesting thing in our market report, and what did you disagree with?" | CO | [generic] | Pick one item you agree with and one you push on, and say why for each. Do not recite. Use your own reading of the report, not a list | Doubles as the differentiation move; the report did not reach this session, so nothing here names its contents |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told senior people something they did not want to hear; it needs a named stake, what you actually said, and how the relationship ended up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem; F5 and F4 are the rows where a candid statement will be tested. VAL because no published values were read |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time you chose a partner's interest over a target; it needs the metric, the choice and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Partnerships roles meet this conflict constantly; F3 is the row it touches |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: the POV on operator partnerships over 18 months | POV build, A1, A2, A3, A4, A5, B4 |
| F2: land on what it means for the operators themselves | POV build (close), A2, A4, A5 |
| F3: Ross will push on commercials, the figure | C1, C2, C3, D2 |
| F4: Ross will push on commercials, direct accountability | B2, C3, D3 |
| F5: our operator partnerships, the sector gap | B1, B3, D1 |
| Any JD requirement | none, and why: no JD was supplied, and the rows above rest on the recruiter's email |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "What would you want to be true about operator partnerships by month 18?" | Shows you are thinking about outcomes, and gives you the panel's own success measure to test your POV against | [generic] |
| R2 | "Which finding in the report is hardest to act on?" | Signals you read it closely and invites a candid answer rather than the consensus line | [generic] |
| R3 | "Where do commercial terms with operators flex, and where do they not?" | Gives Ross room to talk about his own area and tells you how much of F4 will matter | [generic] |
| R4 | "When an operator asks for something outside the plan, who decides, and how fast?" | Tests the seam between partnerships, commercial and product, and signals you have thought about A3 | [generic] |
| R5 | "What would make you say six months in that this hire was the wrong call?" | Shows you want a clear bar and gives you the real concern to address | [generic] |
| R6 | "What does the first 90 days look like, and who should I meet first?" | Practical, and tells you how much onboarding the gaps in F5 will get | [generic] |

## Prohibited claims

Built from the fit snapshot before the banks. Nothing here is coached, hinted at or implied.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or has rail partnership experience | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I have never sold into rail specifically." Then the quotes at their own scope; no slot beyond B1's |
| Has carried a revenue quota or owned a number | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I have never carried a direct quota, only influenced revenue." No slot |
| Knows train operating companies from the consulting side | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for the candidate: the material says bus and light rail network planning, not train operating companies |
| Generated, closed or delivered £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue." The limit is the pack's observation: the material says influenced, not owned |
| Built or launched the ISV channel from scratch | Contradicted by F1's quote | F1's quote: "took it from 6 partners to 40", which says it already had partners |

## Sources

**Provided documents**

- Your background message: role, company description, panel, and your own sentences, which are quoted throughout.
- The recruiter's email, as you quoted it: panel, 60 minutes, the POV, the Q&A, and the commercial push.
- The market report: attached to the recruiter's email, per your message, but it did not reach this session. It was not read, and nothing in the pack draws on it.
- No `tuesday-dossier.md` was present.

**Searches sent, all refused because search permission was not granted**

- Kelverton Rail company values: refused
- Kelverton Rail interview process partnerships manager: refused
- Kelverton Rail strategy news train operating companies scheduling software: refused
- Deepa VP Partnerships Kelverton Rail: refused
- Ross Commercial Director Kelverton Rail: refused
- Senior Partnerships Manager rail technology job description train operating companies: refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed the G bank and a values cheat sheet if a values-style round were documented; with no values read, none is detected and section 10 is dropped |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Would have shown whether this loop has other rounds that change persona weights; the recruiter's email already fixes this session's shape |
| 3. `Kelverton Rail strategy` or recent news | unavailable | Would have moved A4 and F2 from `[generic]` and the report-dependent guidance to grounded, and enabled a grounding brief |
| 4. `Deepa` and `Ross` at Kelverton Rail | unavailable | Would have enabled the reading-the-interviewer section, persona signal adjustments, and a reverse question tied to their paths |
| 5. representative Senior Partnerships Manager JD | unavailable | Would have given quoted requirement rows for the fit snapshot and JD-tagged questions in place of the recruiter's words |

## Upgrade menu

- The market report text, or its headline findings and shortlist → a grounding brief, plus POV differentiation with real consensus items instead of blanks, and A4 and F2 grounded
- The JD text → quoted requirement rows, a JD-driven coverage table, and a check for any gate such as location, travel or pay
- Permission for web search → the five unavailable targets above become evidence: values, loop reports, strategy and news, and the interviewers' public footprint
- Deepa's and Ross's full names or profile links → a reading-the-interviewer section, persona weights adjusted from their public footprint, and a reverse question tied to their own paths
- A line from the recruiter on what "commercials" covers for Ross → sharper F3 and F4 rows and C and D banks
- Your written answers to the slots in F1, F2 and F3 → those rows and the questions that draw on them become story-mapped
- A `tuesday-dossier.md` from a job-underwriter run → verified evidence, a named highest-ROI objection and guardrails, never a prerequisite
