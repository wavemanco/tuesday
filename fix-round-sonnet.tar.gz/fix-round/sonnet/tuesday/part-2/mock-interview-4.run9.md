Web search was refused, so I'm building the pack from your dossier alone and leaving the Quartzline values, loop and strategy facts unresearched. I'll write the pack file now.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-4-denied-a2330cca/Quartzline_product-manager-platform-apis_interview_pack.md`. It has 20 questions, a fit snapshot against the dossier's five requirements, five reverse questions and a prohibited-claims list. I built it for a hiring-manager round and took everything about you from your dossier's verified evidence.

- **No web research:** web search was refused, so nothing in the pack is researched. That covers Quartzline's values, its interview loop and its strategy. The pack has no company-knowledge question and only generic values questions. The Sources section records the three refused searches.
- **Highest-ROI rehearsal:** A1 is the dossier's objection: "You have never held the PM title or owned a roadmap…". The pack walks you through it in four steps: concede, bridge from your integration work, name the limit, then give a ramp plan.
- **What the dossier doesn't settle:** it lists shipped API products (R2) as high-priority but gives no strategy for it, so that row is my own call. It is an answer slot in A5, where you say what you shipped, or that you shipped nothing.
- **Roadmap ownership:** this is a plain "I haven't owned a roadmap" plus a ramp plan. I kept your roadmap-input sessions out of that answer, because the dossier lists it as a gap with nothing to bridge.

Say the word and I'll play the Skeptic on A1 as a live drill. I can also save a `tuesday-dossier.md` recording what this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday. Interviewer: name not given. Built on the underwriting dossier you carry (conditional_go). No web research was available this session, so nothing here claims a fact about Quartzline beyond what the dossier holds.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | Scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. No values were read this session, so VAL questions here are generic |
| EXP | Whether claims about your work survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge. This pack has none: strategy research was refused, so no question could be grounded |
| CASE | A live problem set in the role |

Question A1 is the highest-ROI rehearsal in the pack. The underwriter named it, so it gets the deepest treatment.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD, via dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | low | [inferred] | transferability | The underwriter graded this requirement low: the quoted claim is high-confidence with an inspectable playbook behind it, but it is adjacent to the requirement, not the requirement. Position it as adjacent, never as PM experience. Words at the quote's own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." Limit, said plainly: "I haven't held a product manager title." Source for that negative: dossier prohibited_claims: "Having held a product manager title or role" |
| F2 | "Shipped API or platform products" — JD, via dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | low | [inferred] | discovery | Your material shows integrations of the vendor's REST APIs and does not show whether you shipped an API or platform product. Answer slot: the JD's wording makes a probe on what you have shipped likely. If you shipped one, say what it was and what part was yours, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations you led. The dossier lists this as a high-priority requirement but gives it no strategy, so this row is the pack's own call |
| F3 | "Technical fluency: API docs, schemas" — JD, via dossier role_profile R3 | "Wrote the internal integration playbook her team uses" — dossier verified evidence 2; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | low | [inferred] | discovery | The playbook and the integration architecture touch this requirement, and your material does not show whether either involved API docs or schemas. Answer slot: if you wrote or reviewed API docs or schemas, say which and what your part was; if you did not, or it was not yours, say so plainly and stay with the playbook you wrote |
| F4 | "Stakeholder management across engineering, sales, customers" — JD, via dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [grounded] | transferability | Client-facing delivery and a channel from clients to product are what the quotes carry. Neither names engineering or sales. Evidence 3 is confirmed with limited inspectable proof, so expect a probe on it and volunteer that limit yourself. Words at the quotes' scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if you worked with engineering or sales on these, say how and what part was yours; if not, say so plainly and stay with the clients and product |
| F5 | "Agile delivery experience" — JD, via dossier role_profile R5 | none given | low | [inferred] | discovery | The underwriter graded this low with a clarify strategy, and no quoted sentence speaks to it. Answer slot: the JD's wording makes a probe on how you have worked that way likely. If you worked in an agile delivery process, say what it was and what part was yours; if you never worked that way, say so plainly and say what you would want to confirm about how Quartzline defines it |
| F6 | "Own the roadmap for the partner-facing API platform" — JD, via dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area: uncertain_or_weak_areas: "Owning a roadmap and prioritization authority (R1 sub-claim)". Words: "I haven't owned a product roadmap." Source: dossier prohibited_claims: "Having owned a product roadmap". Then a ramp plan, said as a plan and never as a past. No bridge and no slot here |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the missing title and roadmap | High. Relationship prior for a hiring manager is Skeptic plus Case/Strategist. The underwriter's named objection is Skeptic-shaped. No interviewer profile, so no signal moves it | Rehearse the one predictable objection until it is boring. Bridge only from adjacent evidence, name the limit, add a ramp plan |
| Case/Strategist | Live problems from the role: roadmap, adoption, squads | High. Same prior. The JD's responsibilities supply the problems | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| Data-Driven Prober | Reads the headline number and the playbook line by line | Medium. The prior does not list it, but the 30+ figure is the one number in your material and the coverage rule requires a defend-the-number question | Know what you can and cannot say about how the number was counted. Name your weakest assumption first |
| Conversational | A friendly opener and a casual tech question | Medium-low. Any 45-minute conversation has an opener, and casual questions are still scored | A 90-second arc built only from your quoted sentences. Treat the casual question as scored |
| Pressure | Interrupts and tests attribution | Low. Not in the hiring-manager prior, and the attribution probes are the part worth rehearsing | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding |
| Peer Evaluator | Seam-splitting with the two squad leads | Low. The hiring manager is not a peer, but squad authority is an open question in the dossier | Offer seam principles instead of pretending to know the seam. Reciprocity framing |
| Values/Behavioral | Scenario probes | Low. No loop source documents a values round and no values were read this session, so no values-style round is detected | Selection scaffolds that end in the honest branch |

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | The highest-ROI rehearsal, named by the underwriter. Order: concede, bridge, limit, ramp. Concede in the sourced words: "I haven't held a product manager title, and I haven't owned a product roadmap." Bridge at the quote's own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." Name the limit before they ask: that is adjacent work, and you are not presenting it as product management. Ramp, as a plan: what you would learn first is which roadmap decisions are yours and which sit with the squad leads, and how adoption is measured today. Hold through two follow-ups by returning to the integrations, never by adding to them. If pressed, concede the title and the roadmap specifically. Describe the work and let them draw the inference | F1 and F6 are the biggest gaps. JD because it scores R1 and the roadmap line, Skeptic because it is asked as a challenge to the whole background |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] uncertain_or_weak_areas (acknowledge_gap): "Owning a roadmap and prioritization authority (R1 sub-claim)"; prohibited_claims: "Having owned a product roadmap" | The underwriter found no evidence here, so no bridge. Plain acknowledgment: "I haven't owned a product roadmap." Then the ramp plan, said as a plan: ask who decides what between you and the squad leads, review the current roadmap and the adoption baseline, and sit in on partner discovery. Do not reach for a related story to soften it | F6 is an acknowledge_gap area. JD because it asks about the listed responsibilities, including their gaps |
| A3 | "Tell me about your experience with agile delivery." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the JD lists agile delivery, so expect a probe on how you have worked that way. If you worked in an agile delivery process, say what it was and what part was yours; if you never worked that way, or it was not the structure you worked in, say so plainly, then say what you would want to confirm about how Quartzline runs it. Return to the integrations you led, at the quote's scope | F5 is a clarify area: the evidence may exist and was never established. JD because R5 is a stated requirement |
| A4 | "Why product management, why Quartzline, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Your reason is yours: no sentence of yours states one, so the pack supplies none. Answer slot: say what draws you to this role and this company, in your own words; if it is the platform work more than the title, or the reverse, say which. You may anchor in what you did, at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." That evidence is confirmed with limited inspectable proof, so volunteer the limit before a prober finds it. No Quartzline specifics are given here because none could be researched | F4 draws on the same quote. JD because motivation consistency is scored against this role; the Skeptic stem is "why leave, why here, why now" |
| A5 | "The role needs someone who has shipped API or platform products. What have you shipped?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what you led, at the quote's scope. Answer slot: if you shipped an API or platform product, say what it was and what part was yours; if you did not, or it was not yours, say so plainly and return to the integrations. Never describe something as shipped that you integrated | F2 is a must-have requirement the dossier names as high-priority. The question's premise is the JD's, and the guidance does not adopt it |

### B. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You own the roadmap for the partner-facing API platform, with two engineering squads. How do you decide what ships next quarter — what do you need to know first?" | CASE | [grounded] | Clarify before structuring. Your first clarifier is a decision-rights question: which roadmap decisions are yours and which belong to the squad leads. Then objective, partner segments, options, metrics, risks. Challenge one premise respectfully, such as how adoption is measured today. The question asks about no past of yours, so the guidance makes no claim about it | F6's requirement set as a live problem. The scenario's facts come from the dossier's role profile, and the unknowns there are the best clarifying questions |
| B2 | "Adoption among your integration partners fell 20% this quarter. Diagnose it." | CASE | [grounded] | Ask what adoption means and what the baseline is before anything else. Then segment: new versus existing partners, by integration stage, by partner type. Hypotheses, the data that would separate them, what you would do in week one. No claim about your past | The JD's adoption-metrics responsibility as a diagnosis problem. CASE because it is scored on structure |
| B3 | "Your two squad leads disagree about next sprint's priority, and you are the PM. What do you do?" | CASE | [grounded] | Clarify who decides before acting. Then: surface the trade-off with the data you have, agree the criteria before the options, decide or escalate per the decision rights, record why. Propose principles rather than pretending to know how Quartzline splits authority | The role's squad-authority unknown, as a problem. CASE because it asks for a process, not a past |
| B4 | "A large partner asks for a custom endpoint only they would use. Sales wants to say yes; the squad lead says it fragments the platform. What do you do?" | CASE | [generic] | Clarify the partner's underlying need, then options: a general capability, a workaround, a no. Name what each costs the platform and the relationship, who needs to be in the conversation, and what you would tell the partner and when | R4's three audiences in one problem. `[generic]` because it is a pattern for the problem, not a fact about this employer |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your material says 30+ client integrations. How was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The number counts client integrations, not clients or APIs; keep it attached to that noun. Answer slot: say how it was counted, what it is most sensitive to, and which assumption behind it you would defend least, before they ask; say plainly if you do not know how it was counted. Then say which parts of "led" were yours, in your own words. The pack names no counting method | F1's headline figure. EXP because Probers test whether numbers survive |
| C2 | "Walk me through the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Tell the beats the sentence states, in your own words: you wrote it, it is internal, your team uses it. The underwriter inspected it, so it is the one artifact in this pack you can offer to walk through end to end. Where you do not remember a detail, say so rather than reconstruct it | F3 draws on the same quote. EXP because it tests what was actually yours |
| C3 | "Which adoption metrics would you start with, and what do you need to know first?" | JD | [grounded] | The question asks about no past of yours, and no quoted sentence of yours speaks to defining metrics, so claim none. Ask how adoption is measured today and what the baseline is, then propose a small set and say how you would test each | The JD's adoption-metrics responsibility. The baseline question is also on the reverse list |

### D. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each at its quote's scope: the integrations you led, the playbook you wrote, the roadmap-input sessions you ran. Say the limit on the third in your own words: it is confirmed with limited inspectable proof. End on why this role, in your own words; the pack supplies no reason | F1, F3 and F4 hold the three beats. EXP because the biography question is scored on whether it matches the record |
| D2 | "What are you actually playing with in API docs and schemas these days?" | JD | [inferred] "Wrote the internal integration playbook her team uses" | Treat the casual register as scored. Answer slot: if you work with API docs or schemas now, say which and what you do with them; if you do not, say so plainly and say what you would read first. Return to the playbook you wrote, at the quote's scope | F3 is a discovery row. JD because the JD names it |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That playbook — how much of it was actually you?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Pause and restate. Hold the position the quote carries: "I wrote the internal integration playbook my team uses." Hold through two follow-ups by returning to it. Concede specifically: if others contributed or parts predate you, say which, plainly; if none, say so | F3 and C2's probe in a harsher register. EXP because it tests attribution |
| E2 | "Those roadmap-input sessions — how much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold the position at the quote's scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Volunteer the limit before it is extracted: it is confirmed, with limited inspectable proof. Concede specifically: if others ran parts of it or the format was set by someone else, say so plainly. If pushed on what happened to the evidence afterward, say what you know first-hand and where your knowledge stops | F4's medium-confidence evidence is where a prober finds the seam. EXP because it tests attribution |

### F. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "The two squad leads sit alongside you. Where is the seam between your calls and theirs, and what happens when you disagree?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Propose seam principles and ask where Quartzline draws the line; do not pretend to know it. Reciprocity, at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs" is what you bring them from the client side; say plainly that it is not squad leadership. Hold the disagreement answer to a process, not a claim about past disagreements | F4 and the dossier's squad-authority unknown. JD because decision authority is a stated risk |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams and credit was shared. It needs a piece you did, a piece someone else did, and how you said so. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer stem. No quoted sentence carries this, so it is a scaffold |

### G. Values/Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the truth was unwelcome and actually landed, with a named stake and an intact relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. Values are unresearched, so this is generic |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named metric, a named customer need and a decision that was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; generic for the same reason as G1 |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 3+ years product management experience | A1, A2, A4 |
| R2 Shipped API or platform products | A5, C1 |
| R3 Technical fluency: API docs, schemas | C2, D2, E1 |
| R4 Stakeholder management | B4, D1, E2, F1 |
| R5 Agile delivery experience | A3 |
| Own the roadmap (responsibility) | A1, A2, B1 |
| Define and track adoption metrics (responsibility) | B2, C3 |

## Reverse questions

| # | Question | Why it lands | Origin |
|---|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Authority is asserted in the JD and not evidenced. The answer decides whether the role is what it says, and it reads as diligence | Dossier |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | No baseline is stated anywhere in the material. You need it to judge the role, and it shows you think in metrics | Dossier |
| 3 | "How do the two squads run delivery: cadence, planning, who owns the backlog?" | Turns the agile gap into a question you would want answered anyway | Generic |
| 4 | "What does discovery with integration partners look like today, and who does it?" | The role runs partner discovery; this shows where you would start | Generic |
| 5 | "What would the first 90 days need to deliver for you to call this a good hire?" | Moves the conversation from your background to the work | Generic |

No interviewer profile exists, so none of these is tied to the interviewer's own path.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims: "Having held a product manager title or role" | F1's quote at its own scope. Plain acknowledgment, sourced by that field: "I haven't held a product manager title." |
| Having owned a product roadmap | Dossier prohibited_claims: "Having owned a product roadmap"; acknowledge_gap area on F6 | Plain acknowledgment: "I haven't owned a product roadmap." Then the ramp plan. No bridge, no slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims: "Having set prioritization for an engineering squad" | Plain acknowledgment sourced by that field, then the ramp plan. No bridge, no slot |
| Shaped or influenced the roadmap through the roadmap-input sessions | Inflated form of F4's evidence 3 | F4's quote at its own scope. The limit is the pack's observation: the material says the sessions fed client evidence to product, not what product did with it. E2 stays inside what the sessions were |

## Sources

Provided documents: the underwriting dossier (envelope 1.1, a major version this pack reads). It supplied role_profile (requirements and responsibilities, standing as the JD), handoff_to_mock_interview (verified evidence, weak areas and their strategies, the named objection, risks, employer questions, prohibited claims) and decision (context only: conditional_go). The dossier carries no evidence_map, evidence_state or risk_register. No CV was supplied, so every claim about you comes from the dossier's verified evidence. The loop is the one session you described: a 45-minute conversation with the hiring manager. No loop source documents a values round.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Queries sent: "Quartzline company values principles" (refused); "Quartzline interview process product manager" (refused); "Quartzline partner API platform strategy news" (refused).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Every call was refused. Would have moved the values cheat sheet and mapped VAL questions |
| 2. Quartzline interview process | unavailable | Every call was refused. Would have confirmed whether other rounds or a values round exist. Persona weights rest on your own description of this session |
| 3. Quartzline strategy and recent news | unavailable | Every call was refused. Would have moved a CO question and the grounding brief, and the pack has neither |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative role JD | skipped | The dossier's role profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access, then a re-run of the three refused targets → Quartzline's published values, loop and strategy: a values cheat sheet, mapped VAL questions, and a CO question. A deeper pass would add up to 6 more searches and 2 more fetches and take several more minutes
- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their path
- The recruiter's prep email → stated focus areas and any announced deliverable, which would get its own build section
- Your own answers to the slots in A3, A5, C1 and D2, sent as a message → rows F2, F3 and F5 would move from discovery to quoted evidence
- The raw CV behind the confirmed claims → the shipped-products and API-docs rows (F2, F3) could be upgraded or closed
- How much prep time you have before Thursday → a prioritized schedule in this pack
