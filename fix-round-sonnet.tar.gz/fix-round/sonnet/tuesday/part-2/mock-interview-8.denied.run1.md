Dara, your prep pack for all three rounds on 20 November is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-denied-eaf83e35/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it from what you pasted, with no web searches. It has a shared fit snapshot, then a mini-pack per round: 8 questions for the recruiter, 11 for the Head of Member Services, and 10 for the panel (including the values cheat sheet and the escalation case).

- **Highest-ROI prep:** question D1 in round 2: "You've never worked in a contact centre, and this role owns the complaints process across branches and the contact centre." It is built around your own words, "I haven't worked in a contact centre", plus what you did handle: the branch's formal complaints log and training new tellers on your escalation script.
- **Where your material is thin:** the pack doesn't coach you to claim regulated-complaint handling, supervisor coaching, contact-centre experience or senior presenting. Your sentences cover the formal complaints log, new tellers and regional level. Where the JD asks for more, the pack leaves you a slot to answer in your own words, or to say plainly that it wasn't yours.
- **Your strongest evidence:** the monthly complaints spreadsheet you built for your regional manager (E1). Expect a probe on what it counted.
- **A pattern to watch in round 3:** the strategy brief's plan to consolidate eight branches into five hubs sits against the "Neighbours, Not Numbers" value, and the panel is branch managers. I flagged that as my inference, not a known fact.

Say the word and I'll play the Skeptic on D1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Prepared:** 11 November 2026, for three rounds on 20 November 2026 (nine days).

| Round | Length | Who | Format (from the recruiter's email) |
|---|---|---|---|
| 1 | 30 min | The recruiter | Process conversation |
| 2 | 45 min | Head of Member Services, your future manager | Mostly behavioural |
| 3 | 60 min | Panel of two branch managers | 20-minute case on a complaint escalation, plus the values round, scored against the four values |

Interviewer names beyond these roles are not yet assigned, so there is no interviewer read. This is loop mode: one shared fit snapshot, then a mini-pack per round.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows one of Ashgrove's published values |
| EXP | Whether what you say about your own work survives follow-up |
| JD | A stated requirement of the role, including the ones you have said you lack |
| CO | Knowledge of Ashgrove's strategy and competitive frame |
| CASE | A live problem set in the role |

Question IDs run by persona: A and B are round 1, C to F round 2, G to I round 3. An answer slot is an instruction for the interview, not a question for you now.

## Prep triage

Nine days. The few things to do well, in order; everything else is insurance.

| Order | Do this | Tied to |
|---|---|---|
| 1 | Say the contact-centre answer aloud until it is boring, then the senior-presenting answer | D1, A4, B2, D3 |
| 2 | Write your own answers to the answer slots in F2, F4, F5, F6 and F9, so they are in your own words before anyone asks | Fit snapshot |
| 3 | Run the complaint-escalation case aloud, timed to 20 minutes, twice | H1 to H4 |
| 4 | Pick a real story for each of the four values using the scaffolds | Values cheat sheet |
| 5 | Everything else is insurance | Remaining banks |

## Fit snapshot

Your evidence is the four sentences from your message, quoted exactly. Everything the pack says about your past rests on them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on years, but a line with nothing inspected behind it, so expect a probe on what the work was. Say it in the quote's own terms: six years in retail banking, the last three as a branch supervisor |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (branch side) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat beyond your branch likely. If any complaints in the log passed to other branches or teams, say how you handled that, in your own words; if the log covered your branch only, or nothing was passed on, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD (contact-centre side) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your material says formal complaints, and does not show whether regulatory rules governed them. Answer slot: if those complaints fell under regulatory rules, say which and what they meant for how you handled them, in your own words; if they did not, or you do not know, say so plainly and stay with the log you handled |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet you built, used by your regional manager, and does not show what it measured. Answer slot: the JD names volumes and resolution times, so expect a probe on whether yours counted them. If it did, say how each was counted, what it is most sensitive to, the assumption you would defend least; if it held other measures, say so plainly and stay with what it showed |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel. Answer slot: if it was an Excel workbook, say what you built it to show, in your own words; if it was another tool, or its structure was set by someone else, say so plainly and stay with the spreadsheet you built |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Adjacent work at a different level, and the words stay at its scope: "I trained new tellers on our escalation script." Answer slot: if you coached anyone more senior than the new tellers, say who and on what, in your own words; if you did not, say so plainly and stay with the tellers you trained |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have stated the absence. Words: "I've never presented to anyone above regional level." The JD does not say which level counts as senior, and your material does not establish that. Then how you would prepare, said as a plan and never as a past |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent. Answer slot: if you have worked with a digital team, or on a self-service channel, say what and which part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first |

Proposed wording above is pending your approval. Nothing in it is yours to say unless it is true.

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Own the complaints process end to end across branches and the contact centre | A4, D1, F2, H1, H2 |
| Report monthly on complaint volumes and resolution times | E1, H1 |
| Coach branch supervisors on escalations | C3, H2, I1 |
| Work with digital teams on self-service journeys | D4, F1, H4 |
| Experience handling regulated complaints | A5, D2 |
| Confident presenting to senior leaders | B2, D3 |
| Comfortable with Excel reporting | B3, E2 |

## Grounding brief

From the 2026 strategy brief the recruiter sent you, published July 2026. I have its four headline points from your message, not the document. It is equally available to your interviewers, so bring one item to show you read it, then your own view with a reason. Never recite it.

| Brief point | Vocabulary to use | Where it comes up | Provenance |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | "digital channels", "member service" | A2, F1, H4 | [grounded] your message |
| Consolidate eight branches into five hubs over 2027 | "hubs" | A2, F2, G3, I1 | [grounded] your message |
| Launch a small-business lending product in Q1 2027 | "small-business lending" | A2 | [grounded] your message |
| Main competitive pressure is app-only banks | "app-only banks" | F1, H4 | [grounded] your message |

---

# Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured, still scored | High: a recruiter screen's prior is Conversational plus light Skeptic | A 90-second arc for the biography question; treat casual questions as scored; never answer "I think you've covered everything" in the reverse slot |
| Skeptic (light) | Quiet check on the gaps the JD makes visible | Medium: the prior says light, and F3, F4 and F8 are where the JD presses | Rehearse the one-line concessions until boring |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your six years in retail banking and what's brought you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | A 90-second arc on the beats the quote states: six years in retail banking, the last three as a branch supervisor. The first three years and your reasons for moving are yours to say in your own words; the pack holds nothing on either. End on the JD's own line about owning the complaints process | F1 is the evidence for the years requirement, and the opener is where economy is scored. EXP because it tests that the story holds together |
| A2 | "What do you know about Ashgrove so far?" | CO | [grounded] | Name two of the brief's points in one sentence each, for example the 40% digital target by 2028 and the move from eight branches to five hubs over 2027. Then say which one matters most to you and why, in your own words. The pack makes no claim about you here | Casual homework checks are scored. CO because it tests altitude on the company's own strategy |
| A3 | "Which of our four values speaks to you most, and why?" | VAL | [grounded] | Name it exactly as published, explain it in your own words, then use the selection scaffold for that value in the values cheat sheet; if no time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The recruiter's email says the panel scores the values, so an early pass here is a free rehearsal. VAL because it scores values, not virtue |
| A4 | "This role covers the contact centre as well as branches. How do you feel about that side?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Concede first, in your own words: "I haven't worked in a contact centre." Then say, as a plan, what you would want to learn first and from whom. Do not add experience to soften it. Deeper rehearsal is D1 | F3 is the stated gap in a requirement the JD puts in its first line. JD because it scores a stated responsibility |
| A5 | "The role asks for experience handling regulated complaints. What's yours?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from the quote: you handled the branch's formal complaints log. Answer slot: if those complaints fell under regulatory rules, say which and what they meant for how you handled them; if they did not, or you do not know, say so plainly and stay with the log you handled | F4 is where the material does not show whether the work was regulated. JD because the requirement is the JD's |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would be weakest for you on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick the one you would pick anyway, and say it plainly: "I haven't worked in a contact centre" or "I've never presented to anyone above regional level." Then the plan, not a past. Choosing first beats being found | F3 and F8 are the two stated absences. JD because it scores honest self-assessment against the listed role |
| B2 | "You'd present monthly to senior leaders. What's your experience of that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I've never presented to anyone above regional level." Then say how you would prepare, as a plan, in your own words. Do not claim a presentation you did not give | F8 is a stated gap against a JD requirement. JD because the requirement is the JD's |
| B3 | "Excel reporting is on the list. How comfortable are you?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the quote: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it was an Excel workbook, say what you built it to show; if it was another tool, or someone else set its structure, say so plainly and stay with the spreadsheet you built | F6 is thin on the tool. JD because the requirement is the JD's |

Proposed wording in this round is pending your approval.

### Reverse questions: round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Do you know who is on the panel in round three, and whether a topic or brief for the case will be shared beforehand?" | A rapport interviewer weighs this slot as a preparation signal, and the answer fills a gap in this pack |
| R1.2 | "Is the complaints process run in one place today, or split between the branches and the contact centre?" | It tells you how hard D1 will press and shows you are thinking about the contact-centre side |
| R1.3 | "How does the move to five hubs over 2027 affect what the first months of this role look like?" | It ties the role to the brief without reciting it |
| R1.4 | "What happens after round three, and when should I expect to hear?" | A practical close that signals you are planning |

---

# Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes, story-shaped answers | High: the recruiter's email says this round is mostly behavioural | Map a story only where your sentences carry one, otherwise use the scaffold; "we" for context, "I" for contribution |
| Skeptic | Quiet persistence on the gaps | High: a hiring manager's prior is Skeptic, and this person would manage the role, so F3, F4, F8 and F9 are all in play | Rehearse the single likeliest objection (D1) until it is boring; bridge only from adjacent things you stated |
| Data-Driven Prober | Line-by-line reading, asks how a number was counted | Medium: the role is built around monthly reporting, which makes your spreadsheet a magnet | Know what you can and cannot say about what it measured, and say plainly what you do not know |
| Case/Strategist | A live problem on the role's roadmap | Medium-low: a hiring manager's prior, lowered by the round being described as mostly behavioural | Clarify first, structure aloud, challenge one premise respectfully |

### Bank C: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a complaint was escalated to you and how you handled it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a complaint that reached you with a named stake, a decision that was yours, and what the member was told at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you handled the branch's formal complaints log, or how you would handle it | F2 is the evidence nearest the escalation requirement, and no quote carries a specific escalation, so the pack gives a scaffold. VAL because it scores behaviour against Members First |
| C2 | "Tell me about a time you delivered an unwelcome message to someone senior." | VAL | [generic] | Selection scaffold: pick a time with a named message, a named person above you, and a relationship still intact afterwards; say what landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The behavioural persona's standard stem, and it probes the senior-leaders requirement from the side of candour. VAL because it scores behaviour, not title |
| C3 | "Tell me about a time you taught someone something and they went on to do it differently." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-map on the beats the quote states: you trained new tellers, on your escalation script. Answer slot: the JD's coaching line makes a probe on how you knew it worked likely. If you saw a change, say what and how you saw it; if you did not check, say so plainly and stay with the training you gave | F7 is the nearest evidence for coaching escalations. VAL because it scores what you did to bring someone else along |

### Bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never worked in a contact centre, and this role owns the complaints process across the branches and the contact centre. How do you handle that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Open: "I haven't worked in a contact centre." Name the limit before they do: what you would need to learn, as a plan. Level one, "won't that slow you down?": repeat the limit and the plan, add nothing. Level two, "why would complaints work transfer?": return to what you did, that you handled the branch's formal complaints log and trained new tellers on your escalation script, and leave the transfer as a plan. Level three, "would you want a contact-centre colleague alongside you?": concede specifically. Hold through all three by returning to the quotes, never by adding to them | F3 is the stated gap in the JD's first requirement and the person asking would manage you. JD because the requirement is stated; Skeptic delivery because it is asked as a doubt |
| D2 | "How do you decide whether a complaint is formal?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from the quote: you handled the branch's formal complaints log. Answer slot: the JD asks for regulated complaints, so expect a probe on what made one formal. If you applied a rule, or someone else set the line, say which and what part you played; if there was no such line, or it was not yours, say so plainly and stay with the log you handled | F4 is the thin row, and the word formal in your own sentence is where the probe attaches. JD because it scores the regulated-complaints requirement |
| D3 | "Part of this role is presenting to senior leaders. Tell me about your experience." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I've never presented to anyone above regional level." Then your preparation as a plan in your own words: who you would ask to review the first report, and what you would want leaders to decide from it. Choose a plan you would really follow | F8 is a stated gap. JD because the requirement is the JD's |
| D4 | "What's your experience of working with digital teams on self-service?" | JD | [grounded] | Answer slot: if you have worked with a digital team or on a self-service channel, say what and which part was yours, in your own words; if you have not, say so plainly, then say what you would ask a digital team first. The pack makes no claim here | F9 has no evidence, and the 40% digital target makes this requirement live. JD because the requirement is the JD's |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built. What's in it and who uses it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Beats the quote states: you built it, it is monthly, your regional manager uses it. Answer slot: the JD asks for volumes and resolution times, so expect a probe on whether yours counted them. If it did, say how each was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours; if it held other measures, say so plainly and stay with what it showed | F5 is your strongest evidence and where a prober goes first. EXP because it tests attribution and counting |
| E2 | "How comfortable are you in Excel for reporting?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the quote, then the slot: if it was an Excel workbook, say what you built it to show; if it was another tool, or someone else set its structure, say so plainly and stay with the spreadsheet you built | F6 is thin on the tool. JD because the requirement names Excel |

### Bank F: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "We want 40% of member service on digital channels by 2028. Where do complaints fit, and what would you want to know first?" | CASE | [grounded] | Clarify first: what counts as a complaint rather than a service request, and which kinds members would accept resolving digitally. Then objective, segments, approach, metrics, risks, thinking aloud. Bring the brief's target once to show you read it, then one view of your own with its concession, only if you believe it. The question needs no claim about your past | The strategy brief makes this the likeliest strategic question for this role. CASE because it is a live problem on the company's own vocabulary |
| F2 | "We're consolidating eight branches into five hubs over 2027. What does that mean for the complaints process?" | CASE | [grounded] | Clarify what changes for members and for staff before structuring. Cover where complaints are raised, how they are routed, what supervisors need, and what you would watch in the data. Challenge one premise respectfully. No claim about your past is needed | The brief's second headline move, and it lands on the process the role owns. CASE because it is asked as a plan |

Proposed wording in this round is pending your approval.

### Reverse questions: round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would you want the monthly complaints report to show that it doesn't today?" | It puts your reporting evidence to use and tells you what the manager values |
| R2.2 | "How do you expect a complaint to look different once 40% of member service is digital?" | It links the role to the brief with a real question |
| R2.3 | "How do branches and the contact centre handle escalations differently today, if they do?" | It shows you have already seen the contact-centre gap and want to close it |
| R2.4 | "What would you want me to have changed by the end of 2027, once the hubs are in place?" | It asks for the first-year bar against the brief's timeline |
| R2.5 | "As my manager, how would you like to hear about a complaint that's escalating?" | It tests the Own the Fix value from the manager's side and signals reliability |

---

# Round 3: panel of two branch managers (60 minutes, case plus values)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes keyed to the four published values | High: the recruiter's email says the panel scores against the four values | One story per value from your real material, or the scaffold with its honest branch |
| Case/Strategist | The 20-minute escalation case | High: the recruiter's email names the case | Clarify, structure, think aloud, challenge one premise; use plain words, since Plain Words is scored too |
| Conversational | The same questions in a friendly register | Medium: a values round's prior is Values/Behavioral plus Conversational; no separate bank, G1 to G4 are asked in that register | Treat the relaxed tone as scored |
| Peer Evaluator | Seam-splitting, what they would need from you | Low-medium: the JD has you coaching branch supervisors, and branch managers plausibly work alongside those supervisors; that link is an inference | Reciprocity framing; propose principles for the seam, not a claim to know it |

### Bank G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a decision that was yours, where a habit or target pointed the other way, and say what the member experienced afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you handled the branch's formal complaints log, or how you would handle it | The value is Members First, Always, from the published page. VAL because it scores that value |
| G2 | "Tell me about a time you explained something so it only needed saying once." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time you explained something to a member or colleague, what was complicated, and how you knew it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you trained new tellers on your escalation script, or how you would handle it | The value is Plain Words, from the published page. VAL because it scores that value |
| G3 | "Tell me about a time what the figures said and what a branch or town needed pulled apart." | VAL | [grounded] | Selection scaffold: pick a time with a named figure, a named need, and what you did when they disagreed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Panel members who manage branches are hearing about consolidation into hubs, so expect this to carry weight; that is an inference from the brief and the panel's roles | The value is Neighbours, Not Numbers, and the brief's hub plan makes it likely to be pressed. VAL because it scores that value |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-map on the beat the quote states: you handled the branch's formal complaints log. Answer slot: the value says whoever finds the problem keeps hold of it, so expect a probe on one that you followed to the end. If there was one, say what it was and which part was yours; if none, or others took it over, say so plainly and stay with the log you handled | F2 is the nearest evidence, and the value is Own the Fix. VAL because it scores that value |

### Bank H: Case/Strategist (the 20-minute escalation case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member has complained three times in a month. The branch dealt with the first, the contact centre the second, and it has now reached you. Walk us through what you do." | CASE | [generic] | Time-box it: about 2 minutes clarifying (what the member wants, what has been promised, which time limits your regulator sets), 2 on the objective, then the member's outcome, the process fix, the supervisor conversation, and what the monthly report should show. Say each step aloud. Challenge one premise respectfully. The scenario needs no claim about your past | The recruiter's email names a complaint-escalation case, and this is a representative shape. CASE because it is a live problem; the shape is a pattern, not this employer's actual case |
| H2 | "The branch supervisor says they followed the script. What do you do?" | CASE | [generic] | Separate the member's outcome from the supervisor's coaching: fix the member's problem first, then ask how the script was applied before judging it. Coach, do not blame. No claim about your past is needed | F7 is the coaching requirement, asked as a decision. CASE because the question sets a problem, not a history |
| H3 | "How would you explain the outcome to the member in words they only need to hear once?" | CASE | [generic] | Say the outcome first, then what happens next, in short words, and read it back as the member would hear it. Plain Words is a scored value, so make the plainness visible | The panel scores Plain Words and the case is where it can be shown. CASE because it sets a live problem; VAL scoring sits in the rationale |
| H4 | "Where would digital self-service help in this journey, and where would you keep a person?" | CASE | [grounded] | Bring the 40% by 2028 target once, then a view of your own with its concession, only if you believe it. For example, which steps a member would happily do themselves and which need a conversation. The brief names app-only banks as the pressure, so say what they would do better here. No claim about your past | The strategy brief's two headline pressures meet in this question. CASE with a CO flavour; CASE because it is a live design problem |

### Bank I: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "The brief has eight branches becoming five hubs. What do you need from branch managers, and what do we get from you?" | CASE | [grounded] | Reciprocity first: what you would bring to them, then what you would ask. Offer principles for the seam rather than claiming to know it. If you mention coaching, stay inside what you stated: you trained new tellers on your escalation script. Do not describe coaching supervisors as something you have done | F7 is the coaching evidence and the limit stays visible. CASE because it is a role-seam problem |
| I2 | "If we disagreed about how an escalation should be handled, what would you do?" | JD | [generic] | Say what you would ask first, what you would hold and what you would concede, and how the member comes out whole either way. Show spine and tact together. No claim about your past | Peer evaluators price how the hire disagrees with equals. JD because it scores the collaboration the role needs |

Proposed wording in this round is pending your approval.

### Values cheat sheet

Names are exactly as published on ashgrovecu.org/about/values, copied by you on 11 November 2026. Meanings are paraphrased.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F2, scaffold: pick a decision that was yours, where a habit or target pointed the other way, and say what the member experienced afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log and trained new tellers on our escalation script.", or how you would handle it |
| Plain Words | If a member needs it explained twice, the writing is wrong | F2, scaffold: pick a time you explained something so it needed saying once, and how you knew. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log and trained new tellers on our escalation script.", or how you would handle it |
| Neighbours, Not Numbers | Every branch belongs to its town | Scaffold: pick a time a figure and a local need disagreed, name both, and say what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F2, "I handled the branch's formal complaints log and trained new tellers on our escalation script." Story-map on the log you handled; answer slot as in G4: if you followed one to the end, say what and which part was yours; if not, say so plainly and stay with the log |

Proposed wording is pending your approval.

### Reverse questions: round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "How do your supervisors learn to handle an escalation today?" | It makes the coaching requirement concrete and puts you in listening mode |
| R3.2 | "What do members in your branches complain about most?" | It shows you want the member's view from the people who see it |
| R3.3 | "How are you thinking about members in a town where a branch becomes a hub?" | It tests Neighbours, Not Numbers from their side; whether the hubs affect their branches is unknown to me |
| R3.4 | "What would you most want from the complaints lead in the first month?" | A reciprocity question that shows you are thinking about their load |
| R3.5 | "Which of the four values do you see tested most in a complaint?" | It signals you took the values seriously and gives you a live calibration for your stories |

---

## Prohibited claims

The pack will not coach these. The honest form is in the last column.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: your material says the branch's log, not a process across branches. D1's and the case's slots stay inside the log |
| Worked in or ran complaints across the contact centre | Negative you stated, F3 | The plain acknowledgment F3 gives: "I haven't worked in a contact centre." No slot |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says formal complaints, not regulatory handling. A5 and D2 stay inside the log |
| Reported complaint volumes and resolution times every month | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says a spreadsheet, not what it measured. E1 stays inside the spreadsheet |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: new tellers, on your escalation script. The limit is the pack's observation: your material says tellers, not supervisors |
| Presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided: the job description you pasted; your background text; the recruiter's email on the process; the four values copied from ashgrovecu.org/about/values on 11 November 2026 (pasted, not fetched); and your summary of the July 2026 strategy brief, whose four points I have from your message and not from the document. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet: you pasted the four values with their wording, copied this morning |
| 2. `Ashgrove Credit Union interview process member services` | skipped | Could not have moved loop mode or persona weights: the recruiter's email gives the three rounds, who runs each, and the formats |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO and CASE questions: the July 2026 brief, four months old, supplies current priorities and the competitive frame |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No name was assigned beyond roles, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Your own answers to the answer slots in F2, F4, F5, F6 and F9 (what the log covered, whether regulatory rules applied, what the spreadsheet measured and in what tool, any digital work) → those rows become quoted evidence and the banks that rest on them are regenerated
- The strategy brief itself, pasted → the grounding brief and the CO and CASE banks draw on the document and not on a four-line summary
- Interviewer names for round 2 and the panel → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- Which regulator and complaint time limits Ashgrove works to, from the recruiter → the case in H1 can use real time limits and F4's slot can name the rules
- Whether the 20-minute case has a brief or topic shared in advance → a build section for it if one was announced
- Your CV → fit rows with quotes beyond your four sentences, and the first three years of your arc for A1
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → a strategy and recent-organisation brief beyond the one you have, and loop reports for roles like this
- A `tuesday-dossier.md` from a prior underwriting of this role → verified evidence and a named highest-ROI objection, in place of the one inferred here
