Search access was denied, so the pack below is built from your message alone. I'm writing it now.
Your prep pack is saved as `Stripe_product-operations-manager_interview_pack.md` in your working directory. Web search was denied, so none of it is Stripe-specific research. Stripe's values, loop structure and current strategy are absent rather than recalled from memory. I assumed a final round with an unknown interviewer, so the persona weights are blended. It holds 22 questions across seven personas, a fit-snapshot worksheet, reverse questions, and a list of claims it won't coach. Every question is labeled generic, and the file says what would upgrade each part.

Say the word and I'll play the Skeptic on B1 ("Which part of this role would you be weakest at on day one?"), which the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in the final round (hiring manager, peer, skip-level, cross-functional) and how many sessions? Any recruiter guidance on focus areas or a pre-announced exercise would also help. The answer reweights every bank.
2. Can you paste the Stripe job description and your CV? If not, I'll proceed without them; with them, the generic rows become your own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — final-round interview pack

Built for: a final round, interviewer and format not yet known (blended persona weights). Built from your message alone: no CV, no job description, and no web research (search was not permitted in this session). Everything below is labeled for what it rests on.

## How to use this pack

- Personas describe how a question is asked; types describe what it scores.
- Types: VAL (behavioral and values alignment), EXP (work-experience deep-dive), JD (role and job-description driven), CO (company and strategy knowledge), CASE (a live problem set in the role).
- Guidance is scaffolding, not a script. It never supplies a fact about your past: where a story is needed, it gives selection criteria and an honest fallback, and you fill it from what actually happened.
- The label in each Provenance cell says what a row rests on. With no CV and no JD supplied, almost everything is generic, and the upgrade menu says what moves each row.

## Fit snapshot

This is the worksheet variant: no background material was provided, so every evidence cell is empty and the pack does not guess. The requirements are role-family patterns for product operations, written as plain prose, not quotes from a Stripe posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating cross-functional product launches (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence here is a launch or release you helped coordinate across at least two teams, in your own words, with what part was yours. Selection scaffold: pick a launch with a named stake, a point where teams disagreed, and a result you can state without rounding up; if no such launch comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run one |
| F2 | Running an operating cadence for a product organization: planning cycles, reviews, status rhythms (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or ran, what it replaced or improved, and who used it. Selection scaffold: pick a rhythm that people kept using after the first month; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would design one |
| F3 | Defining and tracking product or launch metrics (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a metric you defined or reported, how it was counted, and which assumption behind it you would defend least. Selection scaffold: pick one figure you can explain end to end; if you cannot say how a figure was counted, say that plainly rather than reconstructing it |
| F4 | Influencing without authority across product, engineering, design and go-to-market (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a disagreement with an equal or a senior person that you handled with the relationship intact. Selection scaffold: pick a case with a named disagreement and an outcome you can state; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F5 | Process and tooling design for product teams (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a process or tool you introduced, what changed, and how you know. Selection scaffold: pick something that was adopted, not just built; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would choose a tool for a team |

## Persona table

Relationship is unknown and no loop source was read, so this rests on a generic loop (flat weights, said plainly): the final round is assumed to include a hiring-manager or skip-level conversation, a cross-functional partner and possibly a peer, in some order. Recalibrate if you know the schedule.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems set in the role: plan this launch, diagnose that metric | High: hiring-manager and skip-level priors both lean on it, and product operations is a structure-and-judgment role | Clarify, then objective, then segmentation, then approach, then metrics, then risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of background fit and motivation: why this role, why here, why now | High: a final round is where remaining doubts get tested | Rehearse the single most predictable objection until it is boring; build bridges only from adjacent experience you can state, with a concrete ramp plan |
| Values / Behavioral | Scenario prompts about conduct under pressure, often from someone outside the function | Medium: a cross-functional interviewer is likely in a final round, but no loop source was read, so a dedicated values round is not assumed | Pick stories where the hard truth actually landed; say we for context and I for contribution |
| Peer Evaluator | Seam-splitting between product operations and adjacent teams; collaboration scenarios | Medium: the role sits between teams, so a peer or partner conversation is plausible | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober | Pushes each number to its inputs and assumptions | Medium: the role is metric-adjacent | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| Conversational | Friendly, unstructured openers that are still scored | Medium: every loop opens this way | A 90-second arc for the biography question; treat casual questions as scored |
| Pressure | Interrupts, time-boxes, questions motives | Low: no signal for it; included so the style is never met cold | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

All provenance cells are generic: no question here rests on a quote of yours, so no guidance asserts anything about your past. The highest-ROI rehearsal is B1, as a stem for the Skeptic persona and not a finding about you; it becomes a specific objection once a CV is in hand.

### A. Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Three product teams are launching customer-facing changes in the same quarter and they overlap. What do you need to know first, and how do you structure the launch process?" | CASE | [generic] | Ask clarifying questions before structuring: which launches are fixed, who owns each, what customers will see. Then objective, the sequencing and dependency view, the cadence and decision rights, the metrics, the risks. Challenge one premise, such as whether coordination is the real problem. Makes no claim about your past | Tests structure under ambiguity on the role's central job. CASE because it is a live problem; relates to F1 |
| A2 | "An adoption metric for a recently launched feature dropped 20% week over week. Diagnose it." | CASE | [generic] | Clarify the metric definition and the time window first, then split by segment, channel, platform and release; separate data problems from real behavior change; say which check is cheapest and first. Makes no claim about your past | Standard diagnosis stem for the persona; relates to F3 |
| A3 | "Design the operating cadence for a product organization spanning several product areas. What meetings and artifacts exist, and what would you cut?" | CASE | [generic] | Start from the decisions that need making and who needs to know, not from a meeting list. Name what each ritual is for, how you would tell it had stopped being useful, and what you would remove first. Makes no claim about your past | Probes judgment about process weight; relates to F2 and F5 |
| A4 | "How would you know whether a product operations function is working?" | JD | [generic] | Offer two or three measures tied to outcomes (launch quality, decision speed, team time spent on coordination) and say how each could be gamed. Say what you would want to learn from this team before committing to any of them. Makes no claim about your past | The role has to justify itself; JD because it scores the role definition, CASE-like in delivery; relates to F3 |
| A5 | "What are the two or three forces most shaping Stripe's product priorities right now?" | CO | [generic] | This pack could not research current strategy, so it supplies no facts. Prepare from Stripe's own recent annual letter, newsroom and product announcements, name your sources aloud, and tie each force to what it means for how product teams operate. If you have not read them, say what you would want to learn | CO question that candidates cannot answer from memory; goes generic without research, which is the honest cost here |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal: name one real gap in plain words, say how you would close it in the first 90 days, and stop. Calibrated candor beats a disguised strength. Choose the gap from your own honest read of the role; the pack cannot choose it without your CV | Born from the Skeptic stem; asked in some form in most final rounds |
| B2 | "Why product operations, why Stripe, why now?" | JD | [generic] | Three short parts that agree with each other: what draws you to the work, what draws you to this company (from what you have read and can name), and why the timing makes sense. Consistency across the three matters more than polish | Motivation probe; JD because it scores fit to the role as defined |
| B3 | "Product operations is sometimes described as project management with a better title. How is what you would do different?" | JD | [generic] | Define the difference in terms of decisions and systems, not task lists: who decides, what information they get, how the process improves over time. Hold your definition through a follow-up, and concede where the overlap is real | Tests whether you can define the role's value |
| B4 | "Given what you do not yet know about our teams, what would your first 90 days look like?" | JD | [generic] | Listen, map, then change one thing: who you would meet, what you would read, how you would choose the first improvement, and what you would not touch yet. Say what would change your plan | Ramp-plan rehearsal for any gap B1 exposes |

### C. Values / Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you chose to say it, and a hard truth that actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; no published Stripe values were in hand, so this is not mapped to a value |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a real tradeoff, a named cost to the metric, and what you would do the same or differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; customer-first themes recur in product roles |
| C3 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [generic] | Selection criteria: a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Rehearses hold-then-concede without bluffing |

### D. Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam, such as who owns the decision and who owns the process, instead of pretending to know this team's seam. Offer what you would bring the peer team, not only what you would need | Reciprocity framing for the seam question |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection criteria: a real shared outcome, a clear account of your own part, and credit named for others. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; tests partnership fit |
| D3 | "A product manager tells you your launch checklist slows their team down. What do you do?" | CASE | [generic] | Listen for the real friction, separate checks that prevent damage from checks that only create comfort, change what should change, and keep what should stay with a reason. Makes no claim about your past | Tests disagreement style with equals; relates to F4 and F5 |

### E. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a number you have reported on. Walk me through how it was counted." | EXP | [generic] | Answer slot: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of the work was yours, each in your own words. If you do not know how a figure was counted, say so plainly rather than reconstructing it | Defend-the-number rehearsal without supplying a number; relates to F3 |
| E2 | "How would you set up a dashboard for launch health? What goes in it and what stays out?" | CASE | [generic] | Start from the decisions the dashboard serves, pick few measures, define each, name the owner and refresh cadence, and say what you would leave out deliberately. Makes no claim about your past | Tests metric judgment; relates to F3 |
| E3 | "Two teams report different numbers for the same metric. How do you resolve it?" | CASE | [generic] | Find where definitions diverge (source, filter, time window), agree one definition and one owner, record the decision, and handle the transition. Makes no claim about your past | Common operations problem; relates to F3 |

### F. Conversational (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc in your own words: where you started, the two or three turns that mattered, and why this role is the next step. Use only things you can stand behind if asked a second question | Opener that is still scored |
| F2 | "What does a great week look like in this job, from your side?" | JD | [generic] | Describe outcomes for others, such as teams unblocked and decisions made faster, not activity. Keep it short and specific to what you have learned about the role | Casual question that scores role understanding |

### G. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | EXP | [generic] | Pause, restate, then give two reasons you can support from your actual experience, then stop. Do not criticize the alternative. Choose the reasons from your own material; the pack cannot choose them without your CV | Composure test; EXP because the answer must rest on real history |
| G2 | "That result: how much of it was actually you?" | EXP | [generic] | Asked about whatever result you just described. Give your own part in plain words, name who else contributed and how, and hold that account through two follow-ups; concede specifically if the line between your work and the team's is blurry | Attribution-honesty rehearsal |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Cross-functional launch coordination | A1, D3 |
| F2 Operating cadence | A3, B4 |
| F3 Metrics and product data | A2, A4, E1, E2, E3 |
| F4 Influence without authority | C3, D1, D2, D3, G2 |
| F5 Process and tooling design | A3, D3 — no question on a specific tool, because no source raises one |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make this role clearly successful at six months, and how would you measure it?" | Shows you think in outcomes and gives you the scoring sheet |
| R2 | "Where does product operations end and product management begin on this team, in practice?" | Surfaces the seam question before it becomes a conflict |
| R3 | "What is the most useful process change a recent hire has made here?" | Shows you want to improve systems and tells you how change is received |
| R4 | "What is the hardest cross-team problem the team is working through now?" | Invites a real problem you can think about aloud |
| R5 | "What do you wish you had known in your first month?" | Personal, specific, and hard to answer generically |
| R6 | "If you are a peer: what could a new person do in their first month that would genuinely help your team?" | Reciprocity question; use only if the interviewer is a peer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any specific past achievement, figure, tool, title or team size | No candidate material was provided, so nothing in this pack is a claim about your history | Answer slots and selection scaffolds only; fill them from what actually happened |
| Any fact about Stripe's values, current strategy, or interview loop | Research did not run; these facts are not taken from model memory | Read Stripe's own published pages and say what you read |

## Sources

Provided documents: none. Your message named the company, the role title and the round (final).

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Search refused. Would have supplied official value names for a VAL mapping and a values cheat sheet |
| 2. company interview process, role family | unavailable | Search refused. Would have established loop structure and persona weights; a generic loop is used instead |
| 3. company strategy, recent news | unavailable | Search refused. Would have grounded A5 and the CO and CASE questions in current priorities |
| 4. interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative role JD | unavailable | Search refused. Would have supplied quoted requirements, turning generic rows into inferred ones |

Searches sent, all refused: Stripe operating principles and values; Stripe interview process for program or product operations; Stripe strategy and recent news; Stripe product operations manager job description.

## Upgrade menu

- Permission to search the web → targets 1, 2, 3 and 5 run: official value names, the loop structure, a current strategy sweep and a representative JD, turning most generic rows into grounded or inferred ones
- A deeper research pass (once, never required): up to 6 more searches and 2 more fetches, several more minutes, adding a strategy brief, the interviewer's public footprint, role-family loop reports and recent org context
- The Stripe posting text → generic requirement rows become quoted ones, and JD questions get a coverage line against the real list
- Your CV → the fit snapshot fills with your own words, story-mapped guidance replaces selection scaffolds, and the highest-ROI objection can be named from your actual gaps
- Who you are meeting and the format of each session → persona weights and reverse questions retune; the final-round loop may be several sessions, so the schedule would allow per-session mini-packs
- Any recruiter guidance on focus areas or a pre-declared exercise → a build section for any announced deliverable
- A tuesday-dossier.md from an earlier fit assessment → verified evidence and prohibited claims constrain the guidance, never required
