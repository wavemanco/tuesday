Web search was refused in this session, so I'm building the pack from your JD and background alone. I'm writing it to a file now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-2-denied-122edc1e/Atlas-Freight_operations-manager_interview_pack.md`. It has 23 questions, a fit snapshot against each JD line, a list of claims it won't coach, and six reverse questions.

- **Assumption:** I didn't know the round type or interviewer, so persona weights are close to flat. Depth tilts to the Skeptic and Case questions, where your gaps and the JD's daily-ops ownership point.
- **Research:** web search was refused in this session, so company values, loop structure and strategy are missing. Those questions are labeled generic, and the file's upgrade menu says what a search would add.
- **Highest-ROI prep:** question A1, the jump from three supervisors to twelve across four sites. Next come Power BI (A3, where "I haven't used Power BI" plus a believable learning plan is the honest answer) and the "5+ years leadership" probe (A5).
- **Answer slots:** the pack never supplies details you didn't give me, such as how the 40% was counted, what changed in the pick path, or any on-time or cost-per-shipment figures. Those are answer slots with an honest "that wasn't mine" branch, and your written answers would strengthen the matching rows.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting next week (recruiter, hiring manager, a peer, a panel), and has the recruiter said anything about focus areas or a take-home?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas-Freight_operations-manager_interview_pack.md -----
# Atlas Freight — Operations Manager: interview prep pack

- Role: Operations Manager, Atlas Freight (regional logistics, 800 employees)
- Interviewer: not known. Round type and relationship to the interviewer: not known.
- Built on one assumption: an unspecified round, so persona weights are close to flat. Depth tilts to the Skeptic and Case personas because that is where the fit snapshot's gaps and the JD's daily-operations ownership point. That tilt is my reading, not a documented loop.
- Web search was refused in this session, so nothing here rests on research. Company facts are limited to what your JD says, and questions that would need research are labeled generic.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview ("if you did this, say how; if not, say so plainly"). It is not a question to you, and you fill it in your own words. Anything you tell me about your past outside a rehearsal becomes new material the pack can regenerate from.

## Prep triage (sized to about one week)

1. A1 and A5, the scale jump and the years-of-leadership question. Say them aloud until each answer-slot branch is in your own words. This is the highest-ROI prep in the pack.
2. A3, Power BI. Settle your one-sentence acknowledgment and your learning plan.
3. C1 and G2. Write down for yourself how the 40% was counted, which part was yours, and which assumption you would defend least. The pack does not supply any of these.
4. E1, the 90-second arc. Time it.
5. B1 and B3, one case each, aloud, structure first.
6. Choose three reverse questions.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material names a shift-manager role and one site's surge plan, not terminal operations or four sites, and the words stay at that scope: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on multi-site or terminal work likely. If any of your work covered more than one site, or terminal work, say which and what was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the site and the surge plan |
| F2 | "drive on-time performance" — JD | none given | none | [grounded] | discovery | Your material does not show an on-time measure either way. Answer slot: the JD's on-time line makes a probe on it likely. If you tracked on-time performance, or any timeliness measure, say what it was and what moved, in your own words; if you did not track one, or it was not yours, say so plainly and stay with the mis-pick figure |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says mis-pick rate, not cost per shipment, with nothing inspected behind the figure, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if that change, or any other of yours, was ever counted in cost terms, say how it was counted and what part was yours; if it was not, or it was not yours, say so plainly and stay with the mis-pick rate |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says three supervisors and the JD says twelve; the gap is in the numbers, so state your side at its scope: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have directed more than three supervisors at any point, say how many, when, and what part was yours; if not, say so plainly and return to the three. How you would lead twelve is a plan, in the future tense only |
| F5 | "build reporting in Excel/Power BI" — JD (Excel part) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" names a skill, not a built report, and the bridge does not stretch it: "I'm solid in Excel." Answer slot: the JD's reporting line makes a probe on what you built likely. If you built any report in Excel, say what it showed and who used it, in your own words; if you did not, or it was not yours, say so plainly and say what you would build first |
| F6 | "build reporting in Excel/Power BI" — JD (Power BI part) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past: what you would learn first and by when. If you start before the interview, say only what you have actually done by then. Nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | discovery | Your material says seven years in operations; it does not say how many were spent leading people, and the JD asks for leadership years. Words: "I have 7 years in warehouse and distribution ops." Answer slot: expect a probe on which years you supervised. If supervisors reported to you for some of them, say which years and what you were responsible for; if fewer than five years did, or none did, say so plainly and return to what you did in those years |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | Say it in its own terms: "I'm green belt certified." Your message does not say which program the belt is in, so say that plainly when asked. Answer slot: expect a probe on where you used it. If the pick-path redesign used a Lean or Six Sigma method, say which and what part was yours; if it did not, say so plainly and name the nearest place you did use the training, if there is one |

No requirement in the JD is a gate. The 5+ years line is a length-of-experience requirement, so it is graded as F7 rather than treated as one.

## Persona table

Round type is unknown, so no relationship prior applies. Weights are close to flat, and depth follows the reasoning below. Recalibrate if you know who you are meeting.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the scale jump, the terminal background, Power BI and the leadership years | Highest, 5 questions. Rows F1, F4, F6 and F7 are the gaps, and this persona exists to probe gaps. This is my reading from the snapshot `[inferred]` | Rehearse the most predictable objection (A1) until it is boring; bridge only from your quoted sentences; concede specifics as answer-slot branches, not scripted negatives | A |
| Case / Strategist | A live operations problem: diagnose a drop, plan a surge, find a cost driver | High, 4 questions. The JD asks you to own daily operations, which makes a live problem a plausible format `[generic]` | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | B |
| Data-Driven Prober | Line-by-line probing of the 40% and of any reporting claim | Medium, 3 questions. The 40% figure in F3 is the one headline number you gave | Know how the figure was counted and say plainly where you do not; name the assumption you would defend least before they do | C |
| Peer Evaluator | Seam-splitting between sites, collaboration and credit | Medium, 3 questions. The JD's four sites imply peers who share handoffs `[generic]` | Reciprocity framing; propose seam principles rather than pretending to know the seam | D |
| Conversational / Rapport | Friendly opener, "walk me through the journey", "why us" | Medium, 3 questions. Any recruiter-style or opening conversation uses it, and it is still scored `[generic]` | A pre-scripted 90-second arc; treat casual questions about JD topics as scored | E |
| Values / Behavioral | Scenario probes on leadership and judgment | Medium-low, 3 questions. No loop source was read, and the generic fallback loop has no values-style round, so none is detected; open behavioral prompts still turn up in most loops `[generic]` | Choose stories you can back with a quoted sentence; where none exists, use the selection scaffold and its honest branch | F |
| Pressure / Stress | Time-boxed "why you", "how much was actually you" | Low-medium, 2 questions. More likely at a senior or final stage, which is not established `[generic]` | Pause, restate, hold through two follow-ups by returning to your quoted facts, then concede specifically | G |

## Question banks

Requirement coverage:

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, B1, B3, D1 |
| "drive on-time performance" | A4, B1 |
| "cost-per-shipment down" | A4, B4 |
| "lead a team of 12 supervisors" | A1, B2, F3, G1 |
| "build reporting in Excel/Power BI" | A3, C3 |
| "5+ years operations leadership required" | A5, E1 |
| "Lean/Six Sigma a plus" | E3 |

The headline metric on your resume, the 40% mis-pick reduction, is defended in C1, C2 and G2.

The highest-ROI prep in this pack is A1. The scale jump, from your three supervisors to the JD's twelve across four sites, is where the rest of the pack's gaps converge, so it is the question most likely to arrive in some form.

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're currently over three supervisors and this role has twelve. What part of that jump would you find hardest?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The deepest rehearsal here. State your side at its scope: "I'm currently a senior shift manager over 3 supervisors." Name the limit before they do, in your own words: the role is twelve across four sites and your quote is three. Follow-up one, "how would you lead twelve": answer as a plan in the future tense, built from what you would ask for, what you would measure and what you would leave alone in the first weeks. Follow-up two, "have you ever led more than three": answer slot. If you have directed more than three supervisors, say how many, when, and what part was yours; if not, say so plainly and return to the three. Hold by returning to what you have done, never by adding to it | F4 and F1 carry the scale gap, and this is where a skeptical interviewer starts. JD because it scores the stated requirement; the deepest rehearsal because it will be asked in some form |
| A2 | "You come from warehouse and distribution, and this role is terminal operations across four sites. What would you want to learn first?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say the background at its scope: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's terminal and four-site lines make a probe on terminal work likely. If any of your work was terminal work, or covered more than one site, say what and what was yours; if none was, or it was not yours, say so plainly and answer as a learning plan: what you would ask to see in your first week, and who you would ask | F1 is the gap. JD because it scores the stated scope; the question invites a plan, which is the one honest bridge available |
| A3 | "The role builds reporting in Excel and Power BI. Where are you on Power BI?" | JD | [grounded] "never used Power BI" | Plain acknowledgment, since you stated it: "I haven't used Power BI." Then the plan, as a plan: what you would learn first, by when, and what you would use it for in this role. If you start before the interview, say only what you have actually done by then. Hold two follow-ups with the same sentence and the same plan; never say "some exposure" or "familiar with" | F6 is a gap wording cannot close, and the honest form is a short acknowledgment plus a believable plan. JD because it scores a named tool |
| A4 | "The role is about driving on-time performance and cost-per-shipment down. What have you actually done on either?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Your quoted result is a mis-pick rate, so lead with it at its scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot for on-time: if you tracked on-time performance or any timeliness measure, say what it was and what moved; if not, say so plainly. Answer slot for cost: if that change or any other was counted in cost terms, say how and what part was yours; if not, say so plainly and stay with the mis-pick rate | F2 has no evidence and F3 touches cost without reaching it, so a precise limit is the strongest answer. JD because the question quotes the stated outcomes |
| A5 | "The posting asks for five-plus years of operations leadership. Of your seven years in warehouse and distribution, how many were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: expect this to be probed literally. If supervisors reported to you for some of the seven years, say which years and what you were responsible for; if fewer than five years did, or none did, say so plainly and return to what you did in those years, in the words of your quote. Do not round the number up | F7 is the row the requirement's wording presses on. JD because the requirement is stated in the posting |

### B. Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance across your four terminals has slipped over two months. Where do you start?" | CASE | [generic] | Ask before you structure: how on-time is defined, whether the drop is at one site or all four, whether it is one lane or customer type, and what changed in volume, staffing or carriers. Then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise, the definition of on-time. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's on-time and four-site lines (F1, F2), asked as a diagnosis. Generic because it is a pattern for the problem, not a fact about this employer |
| B2 | "Two of your twelve supervisors resign in the same week. What do you do?" | CASE | [generic] | Structure it: what you need to know first (which sites, which shifts, what is at risk), what you do this week to keep service stable, what you do about the vacancies, and what you tell the other supervisors. Plan language only. Add no past experience | F4 is the span-of-control gap, and a case on the team lets you show leadership reasoning without claiming twelve. Generic because it is a pattern for the problem |
| B3 | "Peak season is eight weeks out. How would you build the surge plan across four sites?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | You may say once, at its scope: "I ran the site's peak-season surge plan two years running." Then structure the four-site version as a plan: what you would ask each site for, what changes with four sites rather than one, the metrics you would watch, the risks. Beyond the quoted sentence, the story has only the beats it states, told in your own words; the pack supplies no plan contents from your history | F1 is your closest evidence for daily operations at volume. CASE because it is asked as a live problem |
| B4 | "Cost per shipment is up at one terminal and flat at the other three. How do you find out why?" | CASE | [generic] | Clarify how cost per shipment is defined and over what period. Break it into its parts and compare the one terminal with the others, then form two or three hypotheses, say how you would test each, and name what you would not change until you knew. Think aloud. The question makes no claim about your past, so the guidance makes none | F3's cost gap, asked as a diagnosis so the answer is structure, not a claim. Generic because it is a pattern for the problem |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% reduction in mis-pick rate was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot, in your own words, covering four things: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. The pack supplies no baseline, method or assumption, because an explanation you cannot repeat under a second question is worse than none | F3 is your one headline number and a magnet for probes. EXP because it tests attribution and counting |
| C2 | "Tell me what changed in the pick path you redesigned." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The quote carries two beats: you redesigned the pick path, and the mis-pick rate fell 40%. Tell those in your own words and order. The pack does not supply what the redesign contained, which is the part an interviewer asks about and the part only your memory can supply | F3 again, asked from the process side so the figure and the change are rehearsed together. EXP because it tests what was actually done |
| C3 | "What reporting would you want to see every day across four terminals, and how would you build it?" | JD | [grounded] "solid Excel" | A design answer. Choose the measures from the JD (on-time performance, cost per shipment) and say what else you would ask for. Say what you would build first and how you would learn what you do not yet know. Your side at its scope: "I'm solid in Excel." Answer slot: if you built any report in Excel, say what it showed and who used it; if not, say so plainly | F5 and F6 are the reporting gaps, and the JD names the tools. JD because it scores a stated responsibility |

### D. Peer Evaluator (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Do not pretend to know the seam. Offer principles: who owns a handoff, what is measured at the boundary, how disagreements are surfaced early and who decides. Frame what you bring to their team as well as what you need. The question needs no claim about your past, so the guidance makes none | The JD's four sites imply peers who share handoffs (F1). Generic because it is a pattern, not a fact about this employer |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Choose a real instance if you have one: it needs a named stake, a moment where credit could have been taken or shared, and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for peers. VAL because it scores behavior, not a published value |
| D3 | "Tell me about a time you disagreed with a peer on how something should run." | EXP | [generic] | Choose a real instance: it needs the disagreement in one sentence, what you each wanted, how it was resolved and what happened to the relationship. Show spine and tact together. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Disagreement with equals is what a peer scores. EXP because it asks for a chosen instance |

### E. Conversational / Rapport (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | A 90-second arc built only from the five quoted sentences: the seven years, the current role, the surge plan, the pick path and the belt. Put them in the order they actually happened and link them in your own words; the pack does not supply why you moved or what connects them. End on why this role, in a sentence of your own | The friendly opener is still scored (F1, F3, F7, F8). EXP because it tests whether the story hangs together |
| E2 | "What made you look at Atlas Freight?" | CO | [generic] | Selection scaffold: use only what you have actually read or learned about the company, and say where. The JD tells you it is regional logistics with 800 employees, four sites and twelve supervisors, and you may say those are what drew you only if they did. If nothing specific comes to mind, say so plainly and say what in the role itself you are looking for. This pack could not research the company | The motivation question every loop carries. Generic because no company research ran, which is the honest cost |
| E3 | "You're green belt certified. Tell me about a time you used it." | JD | [grounded] "green belt certified" | The quote carries one fact: you are green belt certified; say it in those terms and say which program. Answer slot: if the pick-path redesign used a Lean or Six Sigma method, say which and what part was yours; if it did not, say so plainly and name the nearest place you did use the training. If no time comes to mind, say so plainly and say how you would use it here | F8 is a plus in the JD, and a plus asked casually is still scored. JD because it scores the stated qualification |

### F. Values / Behavioral (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose a real instance: it needs a named stake, a message that was hard to hear, and what happened to the relationship afterward. Use "we" for context and "I" for what you contributed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for behavioral rounds. Generic because no published values were available to map |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Choose a real instance: the metric, the customer need, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; a customer-over-metric story suits a freight role. Generic for the same reason |
| F3 | "How do you handle a supervisor who is consistently missing their numbers?" | JD | [generic] | Answer first as an approach: find out why before judging, agree what changes, check it, and say when you would escalate. If you have a real instance, use it in your own words; if not, say so plainly and keep to the approach. Add no instance you cannot back | The JD's twelve-supervisor line (F4) makes team performance a topic. JD because it scores the leadership responsibility |

### G. Pressure / Stress (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who has run twelve supervisors?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, restate, then hold only what the quotes carry: "I cut mis-pick rate 40% by redesigning the pick path. I ran the site's peak-season surge plan two years running. I'm green belt certified." Hold through two follow-ups by returning to those three sentences, never by adding to them. Concede the scale as an answer slot: if you have not led twelve, say so plainly and say how you would start | F4 is the gap this question leans on. JD because it scores fit to the stated role; pressure is the delivery |
| G2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the quote at its scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which part was yours and which was others', in your own words; if you do not know how it was counted, say so plainly. Concede only what is true, specifically, and do not fold on the core claim to restore harmony | F3 again, as the pressure version of C1. EXP because it tests attribution under pressure |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "How is on-time performance measured across the four terminals today, and where does it stand against where you want it?" | It shows you think in measures and tells you how the JD's on-time line is actually defined | [generic] |
| R2 | "How is the role set up day to day: does each terminal have its own manager, or does this role sit directly above the twelve supervisors?" | It clarifies the span and escalation the JD's four-site and twelve-supervisor lines leave open | [grounded] |
| R3 | "What reporting does the team use today, and where is it built?" | It turns a known gap into diligence and tells you how much the Power BI line will matter in practice | [grounded] |
| R4 | "What would make the first ninety days a success?" | It gets the interviewer's scoring sheet in their own words and lets you tailor your close | [generic] |
| R5 | "What is the biggest operational problem the person in this role would inherit?" | It signals ownership and tells you what the job really is | [generic] |
| R6 | "What does the supervisor team need most from its manager right now?" | It signals leadership focus and hands you the answer to A1's follow-up | [generic] |

## Prohibited claims

Built before the banks, from the fit snapshot. These are the claims a candidate reaches for under pressure, and the pack coaches none of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across multiple sites or terminals | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says a site and a shift, not terminals or four sites. A2's slot stays inside what you actually did |
| Led a team of twelve supervisors | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says three supervisors. A1's slot asks only what you directed |
| Reduced cost per shipment | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says mis-pick rate. A4's slot asks only whether it was counted in cost terms |
| Built reporting or dashboards in Excel | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says "solid Excel", not a built report. C3's slot stays inside that |
| Has used Power BI, or has some exposure to it | Negative the candidate stated, F6 | The plain acknowledgment F6 gives: "I haven't used Power BI." Then the plan. No slot |
| Led Lean or Six Sigma projects, or the pick-path redesign was a Six Sigma project | Inflated form of F8 | F8's quote at its own scope. The limit is the pack's observation: the material says certified, not that any project used it. E3's slot stays inside the quote |
| Has five or more years of operations leadership | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says seven years in operations, not how many were leading people. A5's slot asks only which years you supervised |
| Designed the peak-season surge plan | Inflated form of F1 | F1's quote at its own scope: you ran it. The limit is the pack's observation: the material says ran, not designed. B3 stays on the quoted sentence |

## Sources

Provided documents: the JD text and the background note you pasted in your message. There was no CV file, no dossier, and no interviewer information.

Searches sent, with what came back:

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight strategy news terminals": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Every call was refused. Would have moved the values cheat sheet and the VAL banks, which are generic as a result |
| 2. Atlas Freight interview process, operations role | unavailable | Every call was refused. Would have moved the persona weights, which fell back to near-flat, and loop detection |
| 3. Atlas Freight strategy or recent news | unavailable | Every call was refused. Would have moved the CO and CASE banks, which are generic as a result |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting and the round type (recruiter, hiring manager, peer, panel) → persona weights reweight, banks are added or dropped, and the reverse questions retune
- The interviewer's name → a public-footprint read and one reverse question tied to their career path
- Anything the recruiter said about focus areas or a take-home → coverage and a build section for any pre-declared deliverable
- Your answers to the answer slots in F1, F2, F3, F4, F5, F7 and F8, in writing → those rows upgrade from discovery or transferability, and the matching bank rows regenerate on your own sentences
- Your full CV → the evidence cells now rest only on the sentences in your message, so a CV could add inspectable proof for F1, F3 and F7
- Web search allowed → I rerun the three declared lookups (values, loop structure, strategy), which would ground the VAL, CO and CASE banks. A deeper pass is also available: up to 6 more searches and 2 more fetches, several more minutes
- A working-style assessment, if you have one → a delivery-coaching section
- A tuesday-dossier.md from an earlier assessment of this role → verified evidence would upgrade the story-mapping and name the likeliest objection from evidence rather than from my reading
