Searches are done and returned real, attributable pages for Saltmarsh. I'm now fetching the official values page and the interviewing page, then I'll write the pack.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-canned-0d10ab44/saltmarsh-games_live-operations-producer_interview_pack.md`.

I built it assuming Tobias is your hiring manager. It also rests on Saltmarsh's own interviewing page, which says every loop includes a 60-minute interview with the hiring manager. That interview is called the Outage Hour: a live-incident tabletop on a simulated outage, then a values conversation. The pack is weighted accordingly, with tabletop and values questions first.

Three things to know before you open it:
- **The company pages I fetched were thin.** I fetched two Saltmarsh pages, values and interviewing. The Project Larkspur season-pass announcement and Tobias's GDC talk listing came only from search snippets, so the pack treats them lightly.
- **The most predictable objection is in-app purchases.** Project Larkspur moves both titles to a season pass from February 2027, and you've said you haven't worked on in-app purchases. Question C1 is the one to rehearse first.
- **I left your gaps as stated.** You told me you've never led a team and never worked on in-app purchases, so I coached plain acknowledgments and ramp plans for both and no bridges. The pack also lists claims I won't coach, such as running the calendar for two titles or owning the KPIs, because your material doesn't support them.

Say the word and I'll run a live drill, playing Tobias on C1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias the person you'd report to day to day? A different answer reweights every bank.
2. Did the recruiter say anything about what the tabletop covers or what to prepare?
3. Want a deeper research pass? It would be up to 6 more searches and 2 more fetches, several more minutes, and it would fill in the strategy and interviewer sections.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Built on the assumption that he is your hiring manager: Saltmarsh's careers page says every loop includes a single 60-minute interview with the hiring manager. If he is not your day-to-day manager, the persona weights below change.

**Round:** Friday, 60 minutes. Saltmarsh calls it the Outage Hour: a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for your own words, not a script, and it is built only from sentences you wrote.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Saltmarsh's published values |
| EXP | Whether your own claims survive a close look, and what was actually you |
| JD | A responsibility or qualification the posting states |
| CO | Whether you understand the company's current direction |
| CASE | A live problem, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for me. Where one appears, say what is true in your own words. If the practice it names was not yours, or never existed, say that plainly and return to what you did do. That answer is a good one.

## Prep triage (two days)

| Order | Do this | Where |
|---|---|---|
| 1 | Say C1 aloud until it is boring. It is the most predictable objection and the highest-ROI prep in this pack | C1 |
| 2 | Run the tabletop twice out loud, ten minutes each, thinking aloud. This is the first half of the hour | A1, A2, A5 |
| 3 | Write your honest answers to the answer slots on the checklist and the retention numbers, in your own words | B3, D1 |
| 4 | Say the three values back with the one story or honest branch you have for each | Values cheat sheet |
| 5 | If you can, play one of the two titles in the Project Larkspur announcement before Friday, and only say you have if you have | F2 |

Everything else is insurance.

## Fit snapshot

Evidence cells hold only your own words. This pack had your message and the posting, and no CV, so every quote comes from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, with nothing inspected behind it. It says content drops, not events, and one title, not two. The words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely. If you ever ran or shared a second title's calendar, say how, in your own words; if not, say so plainly and stay with the main title. If any of the drops were time-limited events, say how they differed from regular drops; if all were regular drops, say that |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the JD names four teams, so expect a probe on who you worked with when a drop came together. Say which of the four you worked with and what you needed from them, in your own words; if you did not work with one of them, or drops came together differently, say so plainly and describe how they did |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers to the studio head. It does not say you reviewed events or chose the KPIs, and the words stay at the presenting: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on who chose what the numbers covered likely. If any of that was yours to choose, say what and how you decided; if it was set for you, or there was no such review, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you wrote it, and QA still uses it. Stop there; the line does not say you ran QA's sign-off |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | The quote gives the years and the studio, and does not say whether the title was run as a live service. Answer slot: expect a probe on what live meant for the title. If it was updated for players on an ongoing basis, say how, in your own words; if it was not run as a live service, say so plainly and stay with the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. It is one title and nothing inspected sits behind it, so say it as it stands: you ran the weekly content-drop calendar for the main title for two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on how those numbers were counted. D1 holds the slots |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist is writing, and the line shows you wrote one that QA still uses; it does not show what else you wrote. Answer slot: expect a request for what you have written. Name the documents that were yours; if the checklist is the only one, say so plainly |
| F9 | Experience with in-app-purchase titles (not in the JD; raised by the season-pass model in the Project Larkspur announcement, see Sources) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | Leading a team (not in the JD, which says coordinate; included because a hiring manager may ask) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A stated gap. Words: "I haven't led a team." Then how you would get work done across disciplines, said as a plan and never as a past. Coordinating teams, which the JD asks for, is a different thing from leading them, and that is the pack's observation, not a claim about your history |

## Reading the interviewer

Public professional footprint only. I read the search snippet of his talk, not the full page.

| Observation | Source | Provenance | What it means for you |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games; previously a QA lead at a console studio | GDC 2026 talk listing for Patch Notes Are a Promise | [grounded] | The release checklist is where he is most likely to go deep. Rehearse B3 and E2 |
| His talk's argument: a live team is judged by how often its patch notes describe what actually shipped | Same listing | [grounded] | He listens for the gap between what was announced and what was built. Say only what you did, and in the tabletop say what is fixed, not what is hoped |
| Saltmarsh's second published value is "Ship the Patch Not the Promise: we announce what is built, not what is hoped" | saltmarshgames.com/values | [grounded] | His talk and that value cover the same ground, so expect the second value to be probed hardest in the values half. This is the pack's reading of two sources, not something he has said |

Mirror opportunity: shared vocabulary only. He talks about patch notes and checklists, and your own line is "Wrote the release checklist our QA team still uses." (F4). That is the only point of contact in your material, and it is not a career jump, so none is offered.

## Persona table

No persona is weighted for a peer, because the pack assumes he is your hiring manager. Priors come from the relationship and the documented loop.

| Persona | How it shows up here | Likelihood and reasoning | Provenance | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist (5 questions) | The Outage Hour's tabletop on a simulated outage, plus a calendar problem set in Larkspur | Most likely. A hiring-manager prior favours it, and the careers page names the tabletop as half the hour | [grounded] | Clarify, then objective, then segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| Values / Behavioral (4) | The values conversation, the other half of the hour | Near-certain. The careers page names it, and Saltmarsh publishes three values to ask about by name | [grounded] | Where a quoted sentence carries a story, use it at its own scope; where none does, use the selection scaffold and its honest branch |
| Skeptic (3) | Probing the stated gaps: in-app purchases, never leading a team, one title against two | Likely. A hiring manager is derisking the gaps, F9 and F10 are stated, and Larkspur makes the first one live | [inferred] | Rehearse C1 until it is boring. Bridge only from quoted adjacent evidence, say the limit first, and give any ramp as a plan |
| Data-Driven Prober (3) | Line-by-line questions on the retention numbers and on what was yours | Likely. The JD asks for retention comfort, and his public theme is accuracy about what shipped; this reads the footprint, not his personality | [inferred] | Know what you can say about how the numbers were counted, and say plainly where you do not know |
| Pressure (2) | Time-boxing inside the tabletop, a sixty-second challenge | Possible. The careers page says nothing about pressure, but a simulated outage invites it | [generic] | Pause, restate, hold the position through two follow-ups, then concede specifically |
| Conversational (2) | An easy opener and a question about their titles | Possible. Most hours open this way, and casual questions are still scored | [generic] | A 90-second arc built from your own sentences; never answer "I think you've covered everything" at the end |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're on day two of a weekend event and the game stops loading for most players in the evening peak. You have ten minutes before the first player post goes up. Talk me through what you do." | CASE | [grounded] | Think aloud in this order: what you need to know first (what is affected and for whom, what engineering already knows, who writes the player message), your objective, the first actions and who owns each, what players are told and when, and what you record for the review. Say where players' interest overrides the event schedule; the company's first value is that when the calendar and the players disagree, the players win. The question needs no claim about your past, so the guidance makes none | The careers page names a simulated outage during a live event as the first half of the hour; CASE because it scores structure and not the right answer |
| A2 | "The service is back and players lost part of the event. Do you extend it, who decides, and what are the first two sentences of the player notice?" | CASE | [grounded] | Ask what was lost and what the rewards depend on before choosing. Name who you would need in the decision as people to ask, not as experience you claim. For the notice, say what is fixed and what is built, not what is hoped, which is the company's second value in its own words: "we announce what is built, not what is hoped." The question needs no claim about your past, so the guidance makes none | The notice tests F8's written-communication requirement live, and the tabletop's second beat is the one his talk theme points at |
| A3 | "From February 2027 two titles share one events calendar under a season pass. What do you need to know before you plan the first quarter of it?" | CASE | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Clarify first: which titles, how events and the season pass interact, who owns what inside a single live-ops group. Then objective, how you would segment two audiences on one calendar, approach, metrics, risks, and challenge one premise respectfully, such as whether one calendar serves both audiences. If the season pass comes up, the honest line is "I haven't worked on a game with in-app purchases", followed by what you would ask to learn how it works | CO and JD in one: grounded in the Project Larkspur announcement, which I read only as a search snippet, and tied to F1 and F9. CASE because it scores structure; CO because it uses the company's current direction |
| A4 | "What goes in the post-event review for a weekend event, and which numbers does it report?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Start with the decision the review feeds. Then what was planned against what shipped, the effect on players, issues found, and follow-ups with an owner. Pick a small set of numbers and say what each answers. Answer slot: say plainly which retention measures you have worked with and which you would be learning. You may say you presented the monthly retention numbers to the studio head, and no more than that | F3 is where the JD's own-the-review line presses, and the only evidence is the monthly presentation; JD requirement delivered as a CASE |
| A5 | "It's 5pm the day before an event launches and QA finds a bug that affects a reward. How do you run the go or no-go, and what changes on the checklist afterwards?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Clarify severity, who is affected and whether there is a workaround. Lay out the options, say who has the authority to call it, and say what players hear. Afterwards, say what you would add to the checklist; the company's third value is that every release leaves the checklist better than it found it. You may point to the checklist as one you wrote that QA still uses. Answer slot: if you have called or joined a go or no-go on a release, say what the decision was and your part in it; if not, say so plainly and answer as how you would | F4 and the QA background make this the likeliest depth probe; CASE because it is a live decision |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players wanted different things." | VAL | [grounded] | Selection scaffold, because none of your sentences carries this story: pick a moment when a scheduled drop and what players needed pulled apart. It needs a named stake, what you decided or recommended, and what happened after. If no such time comes to mind, say so plainly, then say how you would handle it | The first published value, in its own words: when the calendar and the players disagree, the players win; an open prompt on that theme |
| B2 | "Tell me about a time you had to say what was going out before you were sure it would." | VAL | [grounded] | Selection scaffold: pick an occasion with a specific announcement, what you knew and did not know when you made it, what you said, and how it matched what shipped. If no such time comes to mind, say so plainly, then say how you would handle it | The second published value, and the one his talk theme echoes; an open prompt on that theme |
| B3 | "Walk me through the release checklist you wrote." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it, and QA still uses it. Those are the beats the quote states; tell them in your own words. Answer slot: the third value says every release leaves the checklist better than it found it, so expect a probe on whether it changed after releases. If you revised it after any release, say what prompted the change and what changed; if it stayed as written, or others changed it, say so plainly and describe the checklist as it stands | F4 is your strongest evidence and the likeliest place for depth; VAL because it maps to the third value, EXP in how it is probed |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F3 to the one beat the quote states: you presented the monthly retention numbers to the studio head. Answer slot: if any month's numbers were unwelcome, say what they showed and what you said; if none was, say so plainly and describe how you presented them | A standard values probe; the monthly presentation to the studio head is the only leadership-facing line in your material |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases, and from February both titles move to a season pass. Why should I believe you can plan that calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." [grounded] "Wrote the release checklist our QA team still uses." | The highest-ROI rehearsal in this pack. Say the limit first, short and unprompted: "I haven't worked on a game with in-app purchases." Then what you do bring, in the quotes' own terms: you ran the weekly content-drop calendar for the main title for two years, and you wrote the release checklist QA still uses. Then a ramp plan, said as a plan: what you would ask and learn first, and from whom. Answer slot: name your own first three questions about how paid content interacts with events, in your own words. Hold through two follow-ups, probably on how you would measure a season pass and what differs from a content calendar. Where you do not know, say "I don't know that yet" and how you would find out. Never claim adjacent monetisation experience | F9 is your largest stated gap and Larkspur makes it live. Tagged JD because it tests whether you can do the listed job; the Larkspur page was read only as a snippet |
| C2 | "You haven't led a team, and this role coordinates design, art, engineering and community on every update. How do you get a date to hold when engineering says it can't?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Start with the limit: "I haven't led a team." Then reason through the case: what you would ask engineering first, the options such as cutting scope or moving the date, and who decides. Answer slot: if you have held or moved a date with another discipline, say what happened and your part; if not, say so plainly and answer as how you would | F10 and the JD's coordination line (F2). JD because it scores a stated responsibility |
| C3 | "You've run one title's calendar. What breaks first when it's two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you have ever run or shared a second calendar, say how; if not, say so plainly. Then reason as a case, without supplying experience: what you would check first, such as clashes between the two and shared team capacity | F1 against the JD's two-titles line |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say how they were counted, what they were sensitive to, which assumption behind them you would defend least, and which part of the work was yours, all in your own words. If you do not know how they were counted, say so plainly and return to the fact that you presented them monthly to the studio head. The pack supplies no method, baseline or definition | The defend-the-number question for the only metric in your material; EXP because it tests what was actually yours |
| D2 | "Which parts of the weekly calendar were yours, and which were the team's?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: "I ran it." Answer slot: if parts were set by others, such as design or the studio head, say which, plainly; if all of it was yours, say that | The probe on "ran", the verb a prober reaches for first |
| D3 | "Which retention measures would you look at after a limited-time event, and why?" | JD | [grounded] | Pick a small set and say what each one answers. Answer slot: say plainly which of them you have worked with and which you would be learning. The question needs no claim about your past | The JD's comfort-with-retention requirement as a live question |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run a monetized live title?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." [grounded] "Wrote the release checklist our QA team still uses." [grounded] "Presented the monthly retention numbers to the studio head." [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Give three facts and no adjectives: you ran the weekly content-drop calendar for the main title for two years, you wrote the release checklist QA still uses, and you presented the monthly retention numbers to the studio head. Concede the gap plainly: "I haven't worked on a game with in-app purchases." Hold the three facts through two follow-ups; do not fold by overstating, and do not wave the gap away | A persona stem; the concession and the hold are the skill being scored |
| E2 | "That release checklist, how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it." Answer slot: if others added to or changed parts of it, say who and what, plainly; if it stayed as you wrote it, say that | The attribution probe on your strongest line, from a hiring manager with a QA background |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." [grounded] "Wrote the release checklist our QA team still uses." [grounded] "Presented the monthly retention numbers to the studio head." | A 90-second arc made only of those four lines: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the main title for the last two years, the checklist QA still uses, the monthly retention presentation. Answer slot for the close: say in your own words why this role and why now; if the honest reason is not settled for you, say so plainly | Most hours open this way, and the opener is still scored |
| F2 | "Have you played Tidepool Tactics or Lantern Row?" | CO | [grounded] | Answer slot: if you have played either, say what you noticed about how its events run, in your own words; if you have not, say so plainly and say what you would look at first. The question needs no claim about your past | A casual question about the company's own titles, scored for genuine interest; the titles come from the Larkspur announcement, which may or may not be the two titles the role covers |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, C3, D2 |
| Coordinate design, art, engineering and community teams on each update | A1, C2 |
| Own the post-event review and the KPIs it reports | A4, B4, D1, D3 |
| Manage the release checklist with QA | A5, B3, E2 |
| 3+ years producing live-service games or apps | E1, F1, D2 |
| Experience running a content calendar | A3, C3, D2 |
| Comfortable with player-retention metrics | D1, D3 |
| Clear written communication | A2 |

## Values cheat sheet

A values-style round is documented: the careers page names a values conversation. Names and meanings are from saltmarshgames.com/values.

| Value (official name) | Working meaning | Provenance | Your mapped story |
|---|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | [grounded] | No quoted sentence of yours carries this story. Use B1's selection scaffold, and if no such time comes to mind, say so plainly and say how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | [grounded] | No quoted sentence of yours carries this story. Use B2's selection scaffold, with the same honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | [grounded] | F4: "Wrote the release checklist our QA team still uses." That carries the checklist and QA's use of it. Whether it improved after releases is B3's answer slot |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You moved from QA into running live operations. What from QA do you still lean on when a live event goes wrong?" | Tied to his own path, and it opens the conversation about checklists on his ground | [grounded] |
| R2 | "After Project Larkspur, how will the two titles' events be sequenced, and does this role own the shared calendar or one title's part of it?" | It settles the role's real scope, which the JD's "two of our mobile titles" leaves open | [grounded] |
| R3 | "What does a good post-event review look like today, and which numbers does it report?" | The JD says this role owns it, so it shows you are thinking about the job | [grounded] |
| R4 | "Your talk argued a live team is judged by whether patch notes match what shipped. How does the team measure that now?" | Shows you read his public work; it relies on a snippet, so ask it as a question and do not summarise the talk | [grounded] |
| R5 | "What would I need to learn first about the season-pass model, and who would be the best person to learn it from?" | Turns your stated gap into a ramp plan he can answer | [grounded] |
| R6 | "What would make this role a clear success by the end of the first season?" | An open close that leaves him describing the outcome he wants | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated, F10 | The plain acknowledgment: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases, or on a monetized or season-pass title | A negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a content-drop calendar for one title |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says you presented the numbers |
| Defined the retention KPIs or set how they were counted | Inflated form of F7 | F7's quote at its own scope. D1's slot asks only how they were counted and what was yours |
| Managed QA's release sign-off | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist, and QA still uses it |

## Sources

Provided: the job description and your background, both from your message. No dossier was present and no CV was provided.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches sent:

- "Saltmarsh Games values" returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games strategy news mobile" returned https://saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise

Fetches: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both read in full. Neither page showed a date. The Project Larkspur announcement (September 2026) and the GDC talk listing were read only as search snippets, not fetched, because the fetch budget went on the two pages above.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and the VAL bank: three values by official name |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Established the loop: one 60-minute hiring-manager interview, tabletop then values conversation; it drives persona weights and the tabletop bank |
| 3. `Saltmarsh Games strategy` / recent news | yes | A3, C1 and F9: the Project Larkspur season-pass announcement, September 2026 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read and R1 and R4; snippet only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → evidence cells become CV quotes, and F2, F5 and F8 may gain evidence they lack today
- Your answers to the slots in F1, F2, F3 and F8 → those rows are regenerated from your own words
- What the recruiter said about the tabletop, such as which title it uses → a sharper tabletop bank in A1, A2 and A5
- Which two titles the role covers → settles whether the Larkspur titles are yours, and sharpens A3, C3 and R2
- The full Project Larkspur page and the full text of his GDC talk, pasted in → A3 and the interviewer read rest on the pages rather than snippets
- A tuesday-dossier.md from the job-underwriter → verified evidence, a named top objection, and prohibited claims checked against your confirmed record
