Searches were refused in this session, so I'm building the pack from your message and the recruiter's email alone and labelling everything else generic. I'll write it now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-5-denied-80da80c4/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

It is built for one 60-minute panel with Deepa as your future manager and Ross as Commercial Director, as the recruiter described. It has 19 questions and a four-hour prep schedule, plus a full build for the 15-minute POV: three theses, each with a concession and an operator close, and a run order.

Two limits shape it:
- **No research:** web search was refused in this session, so nothing in the pack comes from the web. Kelverton-specific questions are labelled generic, and the pack has no interviewer read.
- **No report:** the market report didn't reach me, only your note that you've read it. The pack tells you how to differentiate from it but can't name its content.

Prepare most for C1: Ross asking why he should trust you with operator partnerships when you've never sold into rail or carried a direct quota. Both facts are in your own words, so the pack coaches you to concede them plainly and then hold on what your channel work does show, not to talk around them.

Say the word and I'll play Ross on C1, with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Could you paste the report's headline recommendations, or the sections you'd lean on? That would turn the POV differentiation and the strategy questions from generic into grounded.
Do you have the job description text or link, and your CV text? Right now the pack rests on four sentences from your message, and more of your own wording would give you stronger story-maps.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Second round, Tuesday. One 60-minute panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director), per the recruiter's email. First 15 minutes: your spoken POV on operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. Remaining 45 minutes: Q&A, with Ross pushing on commercials.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Behaviour against published company values (none read for this pack, so no VAL questions) |
| EXP | Whether your CV claims survive scrutiny; what was actually you |
| JD | The stated role and its gaps |
| CO | Company and market knowledge |
| CASE | A live problem, structured aloud |

An answer slot is an instruction for the interview. It asks nothing of you here: say your own version if it is true, and if the step did not exist or was not yours, say so plainly and return to the fact your own sentence carries.

## Prep triage (about four hours)

| Block | Time | Do | Ties to |
|---|---|---|---|
| 1 | 90 min | Build the 15-minute POV: choose one primary thesis, write the operator close first, then say the whole thing aloud twice with a timer | Section: Graded deliverable; A2, A3, A4 |
| 2 | 60 min | Rehearse the quota-and-rail objection until it is boring, then write your own answers to the defend-the-number slots | C1, C2, C3, B1, B2, B3, F3, F4, F5 |
| 3 | 45 min | Re-read the market report: pick one item you would also pick, one place you diverge, and one thing you would not do | Section: Graded deliverable; F2, A1, A3 |
| 4 | 45 min | One timed full run, with someone as Ross if you can: POV, then A4 and C1; then choose three reverse questions | Section: Graded deliverable; C1; Reverse questions |

Everything else is insurance.

## Fit snapshot

No job description was supplied. Requirements below come from the recruiter's email (quoted in your message) and, where marked, role-family requirements written from no source. Evidence is limited to four sentences in your message, since no CV text was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material shows a payments channel, not operator partnerships, with nothing inspected behind the figures. Words stay at the quote: "I took the ISV channel from 6 partners to 40." Answer slot: expect a probe on the 6 and the 40. Say how each was counted, what the count is most sensitive to, the assumption behind it you would defend least, and which part was yours, in your own words. If you do not know how it was counted, say so plainly and return to the sentence |
| F2 | "land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | low | [inferred] | transferability | Your material says bus and light rail network planning. It does not say train operating companies, or which side of an operator relationship you stood on, and the words stay at the quote: "For five years I was in transport consulting, in bus and light rail network planning." Answer slot: the operator close invites a probe on whether that work touched train operating companies. If any did, say which and what you saw; if none did, say so plainly and stay with bus and light rail |
| F3 | "Ross will push on commercials" — recruiter's email | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message; "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The commercial evidence is the word you chose: influenced. Words stay there: "roughly £4M of influenced revenue." The pack's observation is that the material says influenced, not closed or owned. Answer slot: how the £4M was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, in your own words; if you do not know how it was attributed, say so plainly |
| F4 | Direct revenue-quota ownership (role-family requirement, written from no source) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota." Then how you would approach it, said as a plan and never as a past. Never a claim that influenced revenue was a number you carried, and nothing added to make the gap feel smaller |
| F5 | Selling into train operating companies (role-family requirement, written from no source) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap you have stated. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past |
| F6 | Senior partnerships experience running a partner channel (role-family requirement, written from no source) | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | none | No gap in the quote's own terms, with nothing inspected behind it, so expect a probe. Lead with the sentence as it stands: nine years, the last four running the ISV channel, because a named record beats an adjective |
| F7 | Fluency in the market report the recruiter attached (inferred from the attachment; the report's contents were not available to this pack) | "She also attached the market report their strategy team circulated internally last quarter, which I've read." — your message | medium | [inferred] | discovery | Your message says you have read it; the pack has not. Answer slot: when asked what stood out, name one item you would also pick and one place you would go differently, each in your own words; if nothing in it moved you, say so plainly and say what you would ask the team about it |

## Graded deliverable: the 15-minute POV

Announced by the recruiter, so it gets its own build. The close is fixed by the recruiter's words: what it means for the operators themselves.

### Facts you build on

| Row | Your sentence | Use |
|---|---|---|
| F1 | "took it from 6 partners to 40, roughly £4M of influenced revenue" | Evidence that you have built a channel; always say "influenced" |
| F2 | "bus and light rail network planning" | Your view of operators' planning work, offered at that scope |
| F6 | "9 years in partnerships, last 4 at a payments company running the ISV channel" | The opening credential |

### Three theses (pick one as primary)

| # | Thesis | What it means for operators (the close) | Evidence | Mandatory concession | Provenance |
|---|---|---|---|---|---|
| T1 | Treat the partner ecosystem as the route by which an operator gets from licence to outcome, and measure partners on operator outcomes rather than introductions | The operator gets the result the scheduling software was bought for sooner, with less of the integration burden on its own teams. Present this as a hypothesis to test | F1: "took it from 6 partners to 40" | "My evidence is a payments channel, not rail, and the operators' real constraint here may be something else. The first weeks would test this against what operators say." | [inferred] |
| T2 | Co-design partnership offers with operators, starting from the constraints their planners actually work to | Operators shape what partners build, so offers fit how they schedule | F2: "bus and light rail network planning" | "That was bus and light rail, not train operating companies. I would ask planners where my picture breaks." | [inferred] |
| T3 | Fewer, deeper operator partnerships, with a hard no on adding partners for their own sake (the anti-pick) | An operator deals with a short list of partners accountable for its outcomes | F1: "took it from 6 partners to 40" | "My own headline is a partner count. In rail, a count may be the wrong measure, and I would want to see what yours is." | [inferred] |

### Differentiating from the market report

| Move | What it holds | Provenance |
|---|---|---|
| The report is shared ground | Your message says their strategy team circulated it internally and the recruiter attached it, so both panelists will know it well. Reciting it scores as homework | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." |
| One consensus item | Bring one recommendation of the report you would also make, in the report's own terms, to show grounding. Pick it yourself: the pack has not seen the report | [generic] |
| One divergence | One place where your evidence (F1, F2) leads somewhere the report does not, with your reasons | [generic] |
| The anti-pick | One thing in the report, or in the obvious plan, you would not do in 18 months, and why (T3 is one candidate) | [generic] |

### Run order (15 minutes)

| Segment | Time | What it holds | Provenance |
|---|---|---|---|
| Frame | 1.5 min | Who you are in one sentence (F6), then say your POV is a set of hypotheses you would test with Deepa's team | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" |
| Where operators are | 3 min | A few questions you would ask about what operators need, not assertions; no facts about Kelverton you cannot cite | [generic] |
| Three moves | 6 min | Primary thesis plus the consensus item and the divergence; one anti-pick | [inferred] derived from F1 and F2 |
| What it means for operators | 2.5 min | The close from your chosen thesis, said in operator terms: what changes for them | [generic] |
| Concessions and next steps | 2 min | The thesis's mandatory concession, then what you would learn first | [generic] |

## Persona table

The panel is blended: top two personas of each member's relationship.

| Persona | How it shows up | Likelihood | Reasoning shown | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | The POV, then live problems on partnerships | High | Recruiter: "present a short POV on where you'd take our operator partnerships"; Deepa is hiring manager | Clarify, then objective, segmentation, approach, metrics, risks; challenge one premise respectfully |
| Data-Driven Prober | Every figure taken apart | High | Recruiter: "Ross will push on commercials"; two headline figures in your material | Know how each figure was counted, name the weakest assumption first, say plainly what you do not know |
| Pressure | Quota and rail objection, time-boxed | Medium-high | Commercial Director, plus the two stated gaps | Pause, restate, hold through two follow-ups, concede specifically |
| Skeptic | Domain and motivation | Medium | Deepa is hiring manager and the gaps are stated in your own words | Rehearse the single objection until it is boring; bridge only from your stated work |
| Peer Evaluator | Seam between partnerships and direct commercial | Low-medium | Ross sits in an adjacent function | Reciprocity framing; seam principles, not a claimed seam |
| Conversational | Opening arc | Low | A 60-minute panel opens with the POV, so little rapport time | A 90-second arc built from your own sentences |

No values-style round is detected: the recruiter's email names one panel with a POV and Q&A, and no published values were read. No values cheat sheet is included.

## Question banks

C1 is the highest-ROI prep in this pack: some form of it will be asked.

### A: Case / Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Before we get to your view, what would you need to know about our operator partnerships to make a call on where to take them?" | CASE | [generic] | Structure it: what the partnerships are for, who the operators and partners are, what success is measured on, what has been tried. Ask these as questions, supply no facts about Kelverton, and note you would hold your POV as hypotheses until answered. The question needs no claim about your past, so the guidance makes none | Clarify-first is what the Case persona scores, and it earns the hypotheses framing in your POV; CASE because it asks for structure, not a past |
| A2 | "Take us through where you'd take operator partnerships over the next 18 months." | JD | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Use the Graded deliverable section. If you cite your channel, stay at the sentence: "I took the ISV channel from 6 partners to 40." Answer slot: if pressed on the figure, say how it was counted, what it is sensitive to, the assumption you would defend least and which part was yours, in your own words; if you do not know how it was counted, say so plainly and return to the sentence | This is the recruiter's announced deliverable, so it is the likeliest opening of the Q&A; JD because it scores the stated ask |
| A3 | "Name one thing in operator partnerships you would deliberately not do in the first 18 months." | CASE | [generic] | The anti-pick from the Graded deliverable section (T3 is a candidate). Give the reason first, then the concession. The question needs no claim about your past, so the guidance makes none | Saying no is where judgment shows; the differentiation rule asks for an anti-pick; CASE because it is live reasoning |
| A4 | "What does your plan mean for a scheduler or planner at one of our operators, day to day?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer in the operator's terms: what they stop doing, start doing or gain. Answer slot: if any of your network planning work involved train operating companies or their scheduling teams, say which and what you saw; if it was bus and light rail only, say so plainly and say what you would ask a planner first | The recruiter fixed the close as what it means for operators, so this follows; F2 is the evidence and its limit; CASE with a CO flavour |
| A5 | "A partnership pilot with an operator stalls after six months. Diagnose it." | CASE | [generic] | Clarify what stalled, segment causes (sponsor, commercial, integration, operational capacity), say which metric you would read first, and name the risk of acting too early. No claim about your past | A live problem set in the role, so a Case/Strategist's natural test of structure |

### B: Data-Driven Prober (top weight, Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Defend-the-number: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly and return to "roughly £4M of influenced revenue" | F3 is the headline figure and the probe's first target; EXP because it tests what was actually yours |
| B2 | "Influenced is a careful word. What exactly did you influence, and what did you not control?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: say what you influenced and what sat outside your control, in your own words; if you do not know the line, say so plainly and return to the sentence. Do not upgrade "influenced" to a stronger verb | The word is yours, and a commercial director reads it literally; EXP |
| B3 | "From 6 partners to 40. What does the 40 count: signed partners, active ones, or something else?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: what the count includes, what it is most sensitive to, and which part was yours, in your own words; if you do not know, say so plainly and return to "took it from 6 partners to 40" | The second headline figure; the probe is how it was counted; EXP |
| B4 | "How would you structure the commercials of a partnership with an operator: who pays whom, and for what?" | CASE | [generic] | Lay out the structure options and what each puts at risk for the operator, then give your recommendation and what you would test. Answer slot: the recruiter said Ross will push on commercials, so expect a probe on whether you have set terms like these; if you did, say which and how you decided; if you did not, say so plainly and answer as a structured case | The recruiter's own words raise commercials; CASE because it is live; JD flavour |

### C: Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail and you've never carried a direct quota. Why should we trust you with operator partnerships?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "9 years in partnerships, last 4 at a payments company running the ISV channel" | The highest-ROI rehearsal. Pause, restate, then concede first, in the sentence's own scope: "I've never sold into rail specifically, and I've never carried a direct quota; my figure is influenced revenue." Then hold on what your sentence carries: nine years in partnerships, the last four running the ISV channel. Follow-up one, "so why would a quota be different": say plainly that it would be new and describe how you would approach it as a plan. Follow-up two, "what number would you commit to": name no number you cannot derive; say you would set it with Deepa after listening, and what you would need to know. Hold by returning to the sentences, never by adding to them | F4 and F5 are the biggest stated gaps, so this objection arrives in some form; JD because it scores whether you can do the stated job; delivered by the Pressure persona |
| C2 | "Sixty seconds: why you rather than someone who already sells into train operators?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" and "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say what your work was in your own words: nine years in partnerships, the last four running the ISV channel, and five years in transport consulting on bus and light rail network planning. Answer slot: if any of the consulting work was for train operating companies, say which; if not, say so plainly and stay with bus and light rail. Do not describe yourself as having worked on the operator side | The standard Pressure stem against the F5 gap; JD |
| C3 | "That growth from 6 to 40: how much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold then concede: your sentence says you took the channel from 6 to 40, so hold that through two follow-ups. Answer slot: say which parts were yours and which were your team's, other partners' or sales' in your own words, using "we" for context and "I" for contribution; if you cannot separate them, say so plainly | The attribution probe the stem names; EXP |

### D: Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick from your own stated gaps and say it plainly: "I've never sold into rail specifically." Then say how you would close it, as a plan and never as a past. Do not offer a fake weakness | The standard Skeptic stem, and F4 and F5 are already in your own words; JD |
| D2 | "You've come from payments. Why rail, and why now?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Selection scaffold: the answer must be a reason you can say without borrowing the company's language, with one specific thing behind it. If your five years in transport consulting are part of the reason, say how, in your own words; if they are not, say what is, plainly | Motivation consistency is what the Skeptic scores; JD |
| D3 | "What do you think operators want from a software vendor's partnerships team that they aren't getting?" | CO | [generic] | Offer one or two hypotheses framed as hypotheses, tie them to the scheduling context rather than to claims about Kelverton, and say how you would test them in the first weeks. No claim about your past | Tests whether you can think at the company's altitude; CO |

### E: Peer Evaluator (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and direct commercial will overlap on operator accounts. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam: agree attribution rules before a deal, agree who holds the relationship, agree how disputes escalate. Frame by what you bring Ross's team as well as what you need. No claim about your past | A Commercial Director prices what the hire costs his team; JD because it scores role fit |
| E2 | "When have you had to agree who got credit for a deal that spanned two teams?" | EXP | [grounded] "roughly £4M of influenced revenue" | Selection scaffold: pick a time that has a named stake, how the credit was agreed, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, your revenue described as influenced, or how you would handle it | Credit-sharing is the Peer persona's stem, and influenced revenue makes it live; EXP |

### F: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk us through the journey from transport consulting to here." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" and "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc with three beats your sentences state: five years in transport consulting on bus and light rail network planning; nine years in partnerships; the last four running the ISV channel. The thread between them and why this role is yours to say: answer slot, if the thread is something you can say truthfully in your own words, say it; if there is no thread beyond the sequence, say so plainly and move to why this role | The rapport opener, still scored, and it frames every later question; EXP |
| F2 | "What stood out to you in the market report?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Name one item you would also pick and one place you would go differently, each in your own words; this pack has not seen the report and supplies neither. If nothing moved you, say so plainly and say what you would ask the team. Do not recite its recommendations as your own thesis | Their own team wrote it, so this is the likeliest Q&A for CO; CO |

### Requirement coverage

| Requirement | Questions |
|---|---|
| POV on operator partnerships over 18 months (recruiter) | A1, A2, A3, A5, D3 |
| What it means for operators (recruiter) | A4, A2, C2 |
| Commercials (recruiter) | B1, B2, B3, B4, C1, E2 |
| Direct quota ownership (role-family) | C1, D1 |
| Selling into train operating companies (role-family) | C1, C2, D1 |
| Senior partnerships experience (role-family) | A2, C3, F1 |
| Market report fluency | F2 — and CO and CASE questions are generic until the report's contents are in hand |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would you want to be true in 18 months that wouldn't be true without this hire?" | Asks Deepa for the success measure, which sets what you are really being hired against |
| R2 | "Which operator relationships are strongest today, and which would you most like to fix?" | Shows you think operator by operator, not in aggregate |
| R3 | "How is partner-influenced revenue credited today, and what do you wish it captured?" | Speaks to Ross in his own language and tests how commercial attribution is handled |
| R4 | "What did the strategy team's report change about how you're approaching partnerships?" | Shows you read it for decisions, not just content |
| R5 | "What should I be most sceptical of in my first 30 days?" | Signals humility about the rail gap and invites candour |
| R6 | "Where do operators' planners say we fall short today?" | Puts operators at the centre, as the recruiter asked |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or knows train operators commercially | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never sold into rail specifically." No slot |
| Has carried a quota or owned revenue directly | Negative you stated, F4 | "I've never carried a direct quota." The £4M stays influenced revenue |
| The £4M was revenue you closed, sold or owned | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue." The limit is the pack's observation: the material says influenced, not closed or owned. B2's slot stays inside the quote |
| Knows the train operator world from the inside, or from the operator side | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The limit is the pack's observation: the material does not say train operating companies or which side you stood on |
| Built the ISV channel from nothing, or ran partner commercials | Inflated form of F1 and F6 | F1's quote at its own scope: "took it from 6 partners to 40," in a channel you were running. The limit is the pack's observation: the material does not say where the 6 came from or who set the terms |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report was described but its contents were not available to this pack. No CV text and no job description were supplied. No dossier was present.

Searches sent, all refused:

- `Kelverton Rail company values` — refused
- `Kelverton Rail scheduling software train operating companies strategy news` — refused
- `Deepa VP Partnerships Kelverton Rail` — refused
- `Senior Partnerships Manager rail technology job description train operating companies` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The search was refused. It would have supplied published value names for VAL questions; none appear here and the upgrade menu offers them |
| 2. `Kelverton Rail interview process partnerships` | skipped | The recruiter's words fix the loop (one 60-minute panel, POV then Q&A, two named panelists), so persona weights and the absence of a values round are already decided |
| 3. `Kelverton Rail strategy` / recent news | unavailable | The search was refused, and the report's contents are not in hand. It would have grounded the CO and CASE questions and a grounding brief; those stay generic |
| 4. `Deepa Kelverton Rail` | unavailable | The search was refused. It would have supplied an interviewer read and tilted persona weights; the section is absent. Ross has no surname given, so no query was sent for him |
| 5. representative `Senior Partnerships Manager` JD | unavailable | The search was refused. It would have quoted requirements into the fit snapshot and JD questions; those rows rest on the recruiter's words and role-family prose |

## Upgrade menu

- The market report's text, or its headline recommendations → F7 and the differentiation moves become grounded, and A1, A3, A5 and F2 stop being generic
- The job description text or link, and your CV text → the generic requirement rows (F4, F5, F6) become quoted requirements, more of your own sentences become story-maps, and any gate row (location, right to work, travel) would be named if the posting has one
- Your own answers to the slots in F1, F3 and F7 (how the figures were counted, what you controlled, what stood out in the report) → those rows regenerate with your words
- Web search allowed in this session → published values, interview-process reports, strategy and news, and public footprints for Deepa and Ross, with an optional deeper pass of up to 6 more searches and 2 more fetches, several more minutes
- One email to the recruiter asking what "push on commercials" will cover (partner economics, pricing, or your own commercial track record) → reweights banks B and C
- A `tuesday-dossier.md` from an earlier job-underwriter pass → verified evidence, the objection worth the deepest rehearsal and prohibited claims arrive pre-graded; the pack does not need one
