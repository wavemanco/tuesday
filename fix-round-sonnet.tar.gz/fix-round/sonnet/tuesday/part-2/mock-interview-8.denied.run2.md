Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-denied-e84a8741/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as three rounds, since the recruiter gave you the schedule. I assumed the two branch managers on the panel are cross-functional to you, so Round 3 is weighted toward the values and the case. I ran no searches. The values text, the recruiter's email, the July strategy brief and the JD you pasted already covered everything a search would have.

Say the word and I'll play the Skeptic on B3, the contact-centre question. The pack names it as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds on 20 November 2026 (pack dated 11 November 2026).
**Interviewers:** none assigned yet. Round 1 is the recruiter (30 min). Round 2 is the Head of Member Services, your future manager (45 min, mostly behavioural). Round 3 is a panel of two branch managers (60 min, including a 20-minute complaint-escalation case), and it is the values round, scored against the four published values.
**Built on one assumption:** the two branch managers are cross-functional to you, not your peers or your line. If the recruiter tells you more about them, the Round 3 persona weights move (see the upgrade menu).

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script.

| Type | What it is really testing |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether what you have told us about your work survives a follow-up |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you have read their material and can think at their altitude |
| CASE | A live problem from the role, scored on structure, not on a right answer |

Two notations. An **answer slot** is an instruction for the interview, not a question for you now: it names what an interviewer is likely to probe, and gives two honest branches, one of which always allows that the thing never happened or was not yours. Labels in square brackets say where a line came from: grounded (your message, the JD, the values text, the recruiter's email, the strategy brief), inferred (derived, derivation named), generic (a pattern with no claim about Ashgrove or about you).

## Prep triage (nine days)

The few things to do well, in order. Everything else is insurance.

| Order | Do | Tied to |
|---|---|---|
| 1 | Rehearse the contact-centre answer aloud until it is boring: plain acknowledgment, plan, hold, concede. Highest-ROI prep in the pack | B1, B3 |
| 2 | Write your own answers to the answer slots on F1, F3, F4, F5, F7, F9. Whatever is true goes in your own words, and "that was not mine" is a valid answer | B4, B5, E1, E2, A4 |
| 3 | Choose one real story each for Members First, Own the Fix and Plain Words from your actual six years. The pack has none it can carry for you except the teller-script one | C1, C3, C4, C5 to C8 |
| 4 | Run the case structure aloud twice against a 20-minute timer | D3, D4 |
| 5 | Practise the senior-leaders acknowledgment and plan | B2, B6 |

Everything else is insurance.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the log, not the process, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's first responsibility line makes a probe on the log's steps likely. If any step was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The words stay at the quote: "I built the monthly complaints spreadsheet our regional manager uses." Your material does not show what it counted. Answer slot: the JD's volumes-and-resolution-times line makes a probe on that likely. If the spreadsheet counted either, say which and how, in your own words; if it counted neither, say so plainly and say what it did show |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says tellers and a script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you taught the script likely. If you chose how it was taught, say how, in your own words; if the script and the method were set for you, say so plainly and stay with the training |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent either way. Answer slot: the JD's digital line, and the strategy brief's 40% digital move, make a probe likely. If you have worked with a digital or product team on anything members used themselves, say what and which part was yours, in your own words; if you have not, say so plainly and say how you would start |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length, but a line with nothing inspected behind it. Lead with it in its own terms: six years, the last three as a branch supervisor. Expect a probe on whether branch work counts as customer operations |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal log; it does not show whether complaints in it were regulated or what deadlines applied. Answer slot: if the log carried deadlines or reporting duties set from outside the branch, say what and how you kept to them, in your own words; if it did not, say so plainly and describe how you kept the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then a plan, said as a plan. Your material does not say what you have presented at regional level, and the pack does not fill that in |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says spreadsheet, not Excel, and the words stay at the spreadsheet. Answer slot: if it was in Excel, say so and say what it did, in your own words; if it was another tool, say so plainly, and say plainly anything you cannot yet do in Excel |

## Grounding brief

The four points from the strategy brief you were sent, to learn the vocabulary. Check them against anything newer the recruiter says.

| Point | What it says | Where it is used | Provenance |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | D1, D2, RQ4 | [grounded] 2026 strategy brief, July 2026, sent by the recruiter |
| Hubs | Consolidate eight branches into five hubs over 2027 | D5, C7, RQ8 | [grounded] 2026 strategy brief, July 2026, sent by the recruiter |
| New product | Small-business lending product launches in Q1 2027 | RQ5 | [grounded] 2026 strategy brief, July 2026, sent by the recruiter |
| Competition | Main competitive pressure is app-only banks | A2, D1 | [grounded] 2026 strategy brief, July 2026, sent by the recruiter |

# Round 1: recruiter screen (30 min)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly opener on your journey and motivation; the JD's headline lines checked casually | High. Recruiter-screen prior is Conversational plus a light Skeptic, and the recruiter's email gives a 30-minute slot with the recruiter | A pre-scripted 90-second arc (A1); treat every casual question as scored |
| Skeptic (light) | Knockout checks on the two requirements your message states as gaps | Medium. The recruiter-screen prior includes knockout checks, and F2 and F8 are the rows where your own message says no | Plain acknowledgment, then a plan, in under a minute (B1, B2) |

## Question bank: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your journey: how did you get to where you are now, and why this role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Story-mapped on F6: the six years in retail banking and the last three as a branch supervisor, which are the beats the quote states; tell them in your own words in about 90 seconds. Answer slot: your reason for moving to this role is not in your material; give it in your own words, tied to the JD lines you actually want, and if you do not yet know, say so plainly and say what you hope to find out | F6 is the evidence the recruiter checks first; EXP because it tests the story behind the quote, with a motivation half that is scored for consistency |
| A2 | "Why a member-owned credit union rather than a bank?" | CO | [grounded] | The question needs no claim about your past, so the guidance makes none. Use Ashgrove's own phrase, "we decide from the member's side of the counter", and say in your own words why that matters to you. The brief names app-only banks as the main competitive pressure; mention it only if it is a view you actually hold. Answer slot: your own reason, and if you have none beyond the role, say so plainly and say what you want to find out | A motivation question every screen carries; CO because it tests whether you have read their material, and it touches no fit-snapshot row |
| A3 | "Which line of the job description excites you most?" | JD | [grounded] | The question needs no claim about your past. Pick the line you honestly want most (the complaints process, the monthly reporting, coaching supervisors, digital self-service) and say why in your own words. Say you want it, and stop short of saying you have done it | Casual questions on the JD's headline lines are scored; JD because the answer shows which requirement you would lean into, and it touches no single row |
| A4 | "Tell me about your experience handling formal complaints." | JD | [grounded] "I handled the branch's formal complaints log" | Say it at its own scope: "I handled the branch's formal complaints log." Answer slot: the JD asks for experience handling regulated complaints, so expect a probe on whether the log carried deadlines or reporting duties set from outside the branch. If it did, say what and how you kept to them, in your own words; if it did not, say so plainly and describe how you worked the log | F7 is where the requirement meets your only complaints evidence, so the screen will test it; JD because it scores a stated requirement |
| A5 | "Tell me about the years you have spent in financial-services customer operations." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | One sentence in the quote's own terms: six years in retail banking, the last three as a branch supervisor. Read dates, titles and employers off your CV, not from memory. Answer slot: if asked whether branch work counts as customer operations, say what the branch work involved, in your own words; if parts of it were not customer-facing, say so plainly and describe the parts that were | F6 is the length requirement, and a recruiter checks length first; JD because it scores the stated 4+ years |
| A6 | "What are your notice period and salary expectations?" | JD | [generic] | The question needs no claim about your past. State your notice period plainly. The JD you pasted names no pay, so asking the band first is reasonable. Answer slot: if you have not set a range, say so and ask what the band is | Logistics are in every screen; generic because it is a pattern for the screen, not a fact about Ashgrove |

## Question bank: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have not worked in a contact centre, and this role owns complaints across it. How do you see that?" | JD | [grounded] "Never worked in a contact centre" | The plain acknowledgment from F2, in your own words: "I've never worked in a contact centre." Then a plan, said as a plan: what you would learn first and from whom, for example sitting with the team before changing anything. Do not bridge to experience you have not stated. Keep it under 45 seconds, and say it without flinching | F2 is the one requirement your message states as absent, so a knockout check lands here; JD because it scores the stated requirement |
| B2 | "This role presents to senior leaders. Have you presented at that level?" | JD | [grounded] "I've never presented to anyone above regional level" | The plain acknowledgment from F8: "I've never presented to anyone above regional level." Answer slot: your material does not say what you have presented at regional level; if you have, say what and to whom, in your own words; if you have not, say so plainly. Then a plan, said as a plan: how you would prepare for a first senior presentation | F8 is the second requirement your message states as absent, and the JD names it; JD because it scores the stated requirement |

## Reverse questions: Round 1

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "What form does the panel's 20-minute case take, and is there anything I should read beforehand?" | The recruiter's email says the case exists and not what it looks like, so the recruiter is the right person; asking is diligence and shapes your prep |
| RQ2 | "How much of the contact centre sits in this role from day one?" | It sizes the weight of F2 and shows you took the gap seriously rather than avoiding it |
| RQ3 | "Could you share the salary band for the role?" | The JD you pasted names no pay, and the recruiter is the person who can answer it |

# Round 2: Head of Member Services, your future manager (45 min)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" prompts, STAR-shaped | Highest. The recruiter's email calls this round mostly behavioural, which outweighs the hiring-manager prior of Case plus Skeptic | One real story per value, "we" for context and "I" for contribution; where no story comes to mind, the honest branch |
| Skeptic | The gaps, from the person who would own the hire's results | High. Hiring-manager prior; F1, F2 and F5 are the thinnest rows against the JD's headline lines | Rehearse the single most predictable objection (B3) until it is boring |
| Data-Driven Prober | Reads your reporting line by line | Medium. The JD names monthly reporting and Excel, and F3 and F9 are quotes with nothing inspected behind them | Say what the spreadsheet counted and did not; plain "I don't know" where true |
| Case / Strategist | A live problem on the role's roadmap | Lower than the hiring-manager prior says, because the recruiter described the round as mostly behavioural; it stays because the brief's digital move is the role's roadmap | Clarify, structure, think aloud; challenge one premise |

## Question bank: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When did you put a member ahead of an internal metric?" | VAL | [grounded] | The values page says "we decide from the member's side of the counter". The guidance makes no claim about your past, because no sentence of yours carries this story. Selection scaffold: pick a time with a named member situation, a moment when a metric or the branch's convenience pulled the other way, a decision that was yours, and an outcome you know. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for a behavioural round, matched to the Members First value; VAL because it scores whether a past decision shows the value |
| C2 | "Tell me about a time you delivered an unpopular truth to someone more senior." | VAL | [generic] | The guidance makes no claim about your past. Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; generic because it is a pattern for the round, not a fact about Ashgrove. VAL because it scores candour under hierarchy |
| C3 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | The context the quote carries is the log: "I handled the branch's formal complaints log." The story itself is a selection scaffold, matched to the Own the Fix value: pick one case with a named problem, a moment someone could have passed it on and you did not, and where it ended. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1 is the only row with complaints evidence, and a log is where a kept problem would show; VAL because it scores the Own the Fix value |
| C4 | "Tell me about a time something had to be explained more than once, to a member or to a new colleague." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: you trained new tellers, and the subject was the escalation script, which are the beats the quote states. Answer slot: Ashgrove's Plain Words line, "if a member needs it explained twice, we wrote it wrong", makes a probe on the script's wording likely. If any wording was yours to write or change, say what and why, in your own words; if the script was written elsewhere and you trained on it as it was, say so plainly and describe the training | F4 is the one row where your own words match a value's subject; VAL because it scores Plain Words |

## Question bank: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B3 | "You would own complaints across the contact centre as well as the branches, and you have not worked in a contact centre. How would you close that?" | JD | [grounded] "Never worked in a contact centre" and "I handled the branch's formal complaints log" | The deepest rehearsal in the pack. Open with the plain acknowledgment from F2: "I've never worked in a contact centre." Then a plan, said as a plan: what you would learn first, from whom, before changing anything. The only position to hold is the quote's: "I handled the branch's formal complaints log". Follow-up 1 will test whether that is the same job: hold at the log and concede it is the branch side only. Follow-up 2 will test what you do if the contact centre team disagrees with your process: answer with a method, for example agreeing what to measure and looking at a real file together, and never with a past. Concede specifically: how a call is logged and escalated there is what you do not yet know, and is the first thing you would learn. Name the limit before it is asked for | F2 is the requirement your message states as absent and F1 is the closest evidence; this is the single most predictable objection to you, so it is the highest-ROI prep in the pack. JD with Skeptic delivery |
| B4 | "What part of an end-to-end complaints process have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log" | The hold is only what the quote carries: "I handled the branch's formal complaints log." Answer slot: the JD's first responsibility line makes a probe on the log's steps likely. If any step was yours to set, say which and how you decided, in your own words; if none was, say so plainly and describe how you worked the log. Hold through two follow-ups by returning to the log, never by adding to it | F1 is where the role's ownership mandate presses hardest on the evidence you have; JD because it scores the headline responsibility |
| B5 | "What have you done with digital or product teams on self-service?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Answer slot: the JD's digital line and the brief's 40% digital move make this probe likely. If you have worked with a digital or product team on anything members used themselves, say what and which part was yours, in your own words; if you have not, say so plainly, say you would start by learning where members currently get stuck, and return to six years in retail banking, the last three as a branch supervisor | F5 has no evidence in your material, so a manager checking the digital half of the role will probe it; JD because it scores a stated responsibility |

## Question bank: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through your monthly complaints spreadsheet: what did it count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The beats the quote states: you built it, it is monthly, your regional manager uses it. Answer slot: the JD's volumes-and-resolution-times line makes a probe on what it counted likely. If it counted either, say which and how each was counted, in your own words; if it counted neither, say so plainly and say what it did show | F3 is the reporting requirement's only evidence; EXP because it tests what the line actually covered |
| E2 | "What is the most involved thing you have built in a spreadsheet?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: your material says spreadsheet, not Excel. If the monthly complaints spreadsheet is the most involved thing, say so and say what it did, in your own words; if something else was, name that instead; if it was in another tool, say so plainly. Say plainly anything you cannot yet do in Excel, and return to the quote | F9 is the Excel requirement and nothing in your material names the tool; JD because it scores the stated requirement |

## Question bank: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The strategy aims to move 40% of member service to digital channels by 2028. As more moves digital, how would you know complaints are being handled well?" | CASE | [grounded] | The guidance makes no claim about your past. Clarify first: what counts as a complaint in a digital channel and who logs it. Objective: members' complaints resolved well, and a falling count alone does not show that. Segment by channel, complaint type and member group. Metrics: volumes and resolution times, the JD's own measures, by channel, plus repeat contacts. Risks: complaints that go unlogged in a new channel. Challenge one premise aloud: fewer complaints in a channel may mean members cannot find where to complain | The brief's digital move is the role's roadmap and the JD names a self-service line; CASE because it asks for structure on a live problem, and CO because it tests altitude |
| D2 | "A member raises a problem in the app, rings the contact centre, then visits a branch about the same thing. Who owns it, and how?" | CASE | [grounded] | The guidance makes no claim about your past. Use Ashgrove's own principle: "whoever finds the problem keeps hold of it until it is solved". Clarify what links the three channels, name one owner, and state what the member should never be asked to do, which is explain it three times; the values page says "if a member needs it explained twice, we wrote it wrong". Metrics: time to resolve across channels, and repeat contacts | It joins the first JD responsibility and the digital line in one problem, and tests the Own the Fix and Plain Words values together; CASE because it is a live problem with no past claim |

## Reverse questions: Round 2

| # | Question | Why it lands |
|---|---|---|
| RQ4 | "The brief aims to move 40% of member service to digital by 2028. What would a good first year look like for complaints in that shift?" | It shows you read the brief and turns the digital line you have no evidence for into a conversation about the job |
| RQ5 | "The brief mentions a small-business lending product in Q1 2027. Will complaints handling be set up before launch?" | It shows you read the roadmap and asks about the first thing a new product creates, which is complaints |
| RQ6 | "How would you want me to get to know the contact centre in my first weeks?" | It turns F2 into a plan and shows you intend to learn before changing anything |

# Round 3: panel of two branch managers (60 min, including a 20-minute case)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored against the four values, by people outside your function | Highest. The recruiter's email says the panel is the values round and scores against the four values | One story per value; the honest branch where none comes |
| Case / Strategist | The 20-minute complaint-escalation case | High. The recruiter's email puts the case at a third of the hour | Clarify, structure, think aloud; apply the values aloud (D3, D4) |
| Peer Evaluator | Seam-splitting between your role and the branches | Medium. Panel rule blends the top personas of each member's relationship, and branch managers are the people your role touches; the relationship is assumed, not known | Reciprocity framing; propose seam principles, never claim to know the seam |
| Skeptic and Pressure | The presenting gap and attribution on your spreadsheet | Lower. Same gaps as Round 2 with fewer minutes per question | Hold, then concede specifically (B6, G1) |

## Question bank: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "Members First, Always: tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | The values page says "we decide from the member's side of the counter". Reuse the story you chose for C1 if it fits. The guidance makes no claim about your past, because no sentence of yours carries this story. Selection scaffold: a named member situation, a moment the branch's convenience pulled the other way, a decision that was yours, and an outcome you know. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Branch managers feel the member-against-branch tension daily; VAL because it scores the Members First value in its own words |
| C6 | "Plain Words: tell me about a time something you explained did not land the first time." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: you trained new tellers on the escalation script, which are the beats the quote states, told in your own words. Answer slot: the values page says "if a member needs it explained twice, we wrote it wrong", so expect a probe on whether the script's wording changed. If any wording was yours to change, say what and why; if the script was set elsewhere and you trained on it as it was, say so plainly and describe the training | F4 is the one row that matches a value's subject; VAL because it scores Plain Words |
| C7 | "Neighbours, Not Numbers: tell me about a time you did something because of the town your branch sat in." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | The quote gives the context, a branch supervisor for the last three of six years, and nothing about a town. Selection scaffold: pick a time with a named local circumstance, a decision that was yours, and what it cost in numbers. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Expect the hub plan to colour this question; see D5 | The value's own words are "every branch is part of its town", and this panel runs branches; VAL because it scores the value |
| C8 | "Own the Fix: tell me about a time you found a problem that was not yours to solve." | VAL | [grounded] | The values page says "whoever finds the problem keeps hold of it until it is solved". The guidance makes no claim about your past, because no sentence of yours carries this story. Selection scaffold: a problem outside your own area, who you told, and how you kept hold of it afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value assigns the fix to whoever finds the problem, so a panel scoring it asks about problems found outside the finder's area; VAL because it scores Own the Fix |

## Question bank: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D3 | "A member's complaint has been escalated twice by the branch. The supervisor says it is resolved; the member says it is not, and a deadline is running. You have 20 minutes: what do you do?" | CASE | [generic] | A practice case written by this pack; the panel's real case will differ, so rehearse the structure. The guidance makes no claim about your past. Clarify first: what the member says is still open, what the file shows, whose deadline it is and when it falls. Objective, then who is involved, then your approach, then what you would record, then risks. Challenge one premise aloud: whether "resolved" means the same to the supervisor and the member. Say the values as you use them: keep hold of it, plain words to the member, decide from the member's side | The recruiter's email says the panel's 20-minute case is a complaint escalation; generic because the case itself is invented here. CASE because it asks for structure on a live problem |
| D4 | "A branch supervisor keeps closing complaints before members agree they are resolved. How do you coach them?" | CASE | [generic] | The guidance makes no claim about your past. Listen first to what resolved means to them and what pressure they are under, show them the member's side with a real file, agree one small change, and check back. Say your method, not a history of using it | F4's requirement is coaching supervisors, and the case lets you show an approach without a past claim; CASE because it is a live problem |
| D5 | "Eight branches are becoming five hubs over 2027. What happens to complaints, and to the towns those branches served?" | CO | [grounded] | The guidance makes no claim about your past. Hold two things the values name together: "every branch is part of its town" and "we decide from the member's side of the counter". You have only the brief's headline, so say what you would want to know first: who takes a complaint in a hub that used to be taken in a branch, and what a member in a changing town would need. Do not pretend to know the consolidation plan | The brief's hub move is the thing this panel will live inside; CO because it tests whether you can think at the company's altitude |

## Question bank: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "You would be coaching supervisors in our branches on escalations. Where is the seam between your role and ours, and what happens when we disagree?" | JD | [generic] | The guidance makes no claim about your past. Propose seam principles and do not claim to know the seam: your role sets the escalation standard and the reporting, the branch manager runs the branch, and a disagreement goes to a real file and to what the member says. Offer what you would bring them as well as what you need | The JD's coaching line puts you in their branches' business; JD because it scores the coaching requirement, and the peer stem is the persona's own |
| F2 | "What would you need from the branches in your first month?" | JD | [generic] | The guidance makes no claim about your past. Ask for the open complaints, the supervisors' view of escalations, and an introduction before any change. Offer one thing back, for example a view of what the branch's open complaints show | Reciprocity is what a peer panel scores; JD because it tests the cross-branch working the role describes |

## Question bank: Skeptic and Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B6 | "This role presents to senior leaders. Your material says you have not presented above regional level. Why should we be comfortable?" | JD | [grounded] "I've never presented to anyone above regional level" and "I built the monthly complaints spreadsheet our regional manager uses" | Hold, then concede. Hold only what the quotes carry: "I built the monthly complaints spreadsheet our regional manager uses." Concede specifically: "I've never presented to anyone above regional level." Then a plan, said as a plan: ask for the audience and format beforehand, and rehearse the first one with your manager. Do not claim confidence you have not shown | F8 is the requirement your message states as absent and F3 is the reporting evidence; JD because it scores the stated requirement, with Skeptic delivery |
| G1 | "That spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Pause, restate the question, then hold: "I built the monthly complaints spreadsheet our regional manager uses." Hold through two follow-ups by returning to the quote's own words. Answer slot: if anyone else shaped it, for example the layout, the measures or the inputs, say so plainly and say which part was yours; if it was entirely yours, say that. Concede what you do not know, specifically, and never fold on a claim that is true | F3 is the evidence behind the monthly-reporting requirement, and attribution probes exist to catch inflated ownership; EXP because it tests what was actually yours |

## Values cheat sheet

Round 3 is the values round. Names are as published on the values page you copied on 11 November 2026.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold, no sentence of yours carries it. Pick a named member situation, a pull the other way, your decision, and a known outcome. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (C1, C5) |
| Plain Words | If a member needs it explained twice, the wording was wrong | F4: "trained new tellers on our escalation script". The beats are the training and the script; the wording question is an answer slot (C4, C6) |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold, no sentence of yours carries it. Pick a named local circumstance, your decision, and its cost in numbers. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (C7) |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold, no sentence of yours carries it. Pick a named problem, a moment you could have passed it on, and where it ended. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (C3, C8) |

## Reverse questions: Round 3

| # | Question | Why it lands |
|---|---|---|
| RQ7 | "Where do escalations get stuck in your branch today, if they do?" | It asks the panel for the thing you would own, and signals Own the Fix without claiming a story |
| RQ8 | "As branches move toward hubs, how do you want a member in one of those towns to experience a complaint?" | It joins the brief's hub plan to Neighbours, Not Numbers and Members First, and invites them to say what they value |
| RQ9 | "What could a new person in this role do in their first month that would genuinely help your branch?" | It is the reciprocity question for a panel that works beside you, and keeps the answer to "any questions for us" specific |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end" | B4, A4, D3 |
| "across branches and the contact centre" | B1, B3, D2 |
| "report monthly on complaint volumes and resolution times" | E1, G1, D1 |
| "coach branch supervisors on escalations" | D4, F1, C4, C6 |
| "work with digital teams on self-service journeys" | B5, D1, D2 |
| "4+ years in financial-services customer operations" | A1, A5 |
| "experience handling regulated complaints" | A4, D3 |
| "confident presenting to senior leaders" | B2, B6 |
| "comfortable with Excel reporting" | E2, E1 |
| Members First, Always | C1, C5 |
| Plain Words | C4, C6 |
| Neighbours, Not Numbers | C7, D5 |
| Own the Fix | C3, C8 |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the log, not the process. The slots on F1 stay inside the log |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says tellers and a script, not supervisors. The slots on F4 stay inside the training |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot on the acknowledgment itself |

## Sources

Provided documents: the job description you pasted; the values text you copied from ashgrovecu.org/about/values on 11 November 2026; the recruiter's email about the process; the 2026 strategy brief published in July 2026, sent by the recruiter; your message about your background. No dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet: the pasted values text fixes the four value names and their wording |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights or the loop: the recruiter's email fixes the three sessions, who runs each, and the panel's values scoring |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Could not have moved the CO and CASE banks: the July 2026 strategy brief you were sent supplies current priorities and the competitive frame |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name has been assigned, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your own one-paragraph account, written outside a drill, of one real case each for Members First, Own the Fix and Neighbours, Not Numbers, plus any time you put a member ahead of a metric → C1, C3, C5, C7 and C8 become story-mapped instead of scaffolds, and the values cheat sheet fills
- Your answers to the slots on F1, F3, F4, F5, F7 and F9 (what the log's steps and deadlines were, what the spreadsheet counted, whether it was Excel, any digital work) → those six rows move from discovery or transferability to grounded with your own words, and A4, B4, B5, E1 and E2 become story-mapped
- A redacted copy of the monthly complaints spreadsheet, or the layout of the complaints log → F3, F7 and F9 can move from medium to high, because that is the inspectable artifact in this field
- Your CV → every evidence cell quotes it alongside your message, and F6's dates and titles are checked against it
- Interviewer names once assigned → an interviewer read, persona weights read from public footprint, and a reverse question tied to each person's own path
- A line from the recruiter on whether the two branch managers sit above, beside or outside your reporting line → Round 3 persona weights stop resting on an assumption
- Your available prep hours per day → the triage is resized to them
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) for role-family interview reports and recent organisation news → CO and CASE questions go from the brief's four points to current context
- A tuesday-dossier.md from an underwriting pass on this role → verified evidence and prohibited claims already graded, which would tighten the bridges on F1, F4 and F7
