Web research was refused (four searches, none returned), so I'm building the pack from your JD and background alone. I'm saving it now.
Your prep pack for Friday's Saltmarsh Games interview is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-denied-662922a9/Saltmarsh_Games_live-operations-producer_interview_pack.md`.

All four web searches were refused (company values, interview process, strategy, Tobias). So the pack has no company or interviewer research. It is built from your JD and your own sentences, and the "Sources" section says what each missing search would have changed.

I assumed Tobias is a hiring-manager-style interviewer in a single 60-minute round. That puts the heaviest weight on live planning problems (bank A) and on skeptical probing of your gaps (bank B). The pack has 18 questions across five personas.

- **Highest-ROI prep:** B1, "You have been an associate producer. What makes you ready to own the calendar for two titles?" Rehearse it aloud, holding what your quotes say and conceding plainly that you've never led a team. The prohibited-claims section lists what not to say, such as having run events across two titles or owned the post-event review.
- **Softest spots:** F3 (the JD wants a live-events calendar for two titles; you ran a content-drop calendar for one) and F5 (you presented the retention numbers; the JD wants you to own the review and its KPIs). The answer slots in those rows are blanks for you to fill truthfully.
- **Not included:** an interviewer read, a values cheat sheet and company-specific questions. Each needs research that didn't run, and the upgrade menu at the end of the file lists what would unlock them.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you would report to, or a peer on the team? That reweights every bank.
Has the recruiter mentioned a format, such as a presentation, a take-home or focus areas?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_Games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi. **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Round:** 60 minutes, Friday.

Built on one assumption: Tobias is a hiring-manager-style interviewer in a single 60-minute conversation. Your note did not say whether he would be your manager or a peer, or whether Friday is the whole loop. If either is different, the persona weights below change.

No web research ran: all four searches were refused (see Sources). Everything about Saltmarsh Games and Tobias is therefore absent from this pack, and the question banks lean on your JD and your own words.

## How to use this pack and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script.

| Type | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values. Not used here: no values were read and no values-style round was detected |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth. Not used here: no company research ran |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Prep triage

You have roughly two days. In order:

1. Say B1 aloud three times, holding through two follow-ups, then conceding exactly as B1 and the prohibited-claims section describe. It is the highest-ROI prep in this pack.
2. Rehearse C1 and C2 until you can say plainly what the retention numbers covered and what you do not know about how they were counted.
3. Do A1 and A2 once each, out loud, using the clarify-then-structure order in the guidance.
4. Time D1 to 90 seconds.
5. Pick three reverse questions from section 11 and drop the rest.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Four years meets the number as stated, but the quotes do not say whether the title was run as a live-service game, and nothing is inspected behind them. Words: "I've spent four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Answer slot: the JD says live-service, so expect a probe on whether your studio's title was run that way. If it was, say how, in your own words; if it was not, or the weekly drops were not part of one, say so plainly and stay with the weekly calendar |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a claim with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you ran the weekly content-drop calendar for your main title for the last two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | The JD asks for a live-events calendar across two titles. The quote is a content-drop calendar for one title, so the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if any of the weekly drops were timed events, say which and how they were scheduled, in your own words; if none were, say so plainly and stay with the weekly calendar |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this one. Answer slot: the JD names four teams, so expect a probe on who you worked with. If you coordinated with any of them, say which and how, in your own words; if not, or it was someone else's job, say so plainly and stay with the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | low | [inferred] | discovery | The quote is about presenting numbers, and the words stay at presenting: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on what those numbers covered and which part was yours. If you produced or defined any of them, say which, in your own words; if you presented numbers someone else produced, say so plainly and stay with presenting |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but nothing inspected behind it. Lead with the quote in its own terms: you presented the monthly retention numbers to the studio head. The quote says presented, so expect a probe on what the numbers covered and how they were counted |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Writing a checklist that QA still uses is adjacent to managing it with them, and the words stay at the quote: "I wrote the release checklist our QA team still uses." Answer slot: expect a probe on whether you ran releases through it. If you did, say how, in your own words; if not, or someone else did, say so plainly and stay with having written it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A written checklist touches this requirement but does not show how clearly it reads. Answer slot: expect a request for something you have written. Name what you can point to, in your own words; if nothing is shareable, say so plainly and stay with the quote: "Wrote the release checklist our QA team still uses." |

## Persona table

The loop is not established (no loop source), so the loop adjustment is the generic archetype: flat weights, said plainly. The one prior is the assumed hiring-manager round.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: plan this, diagnose that | High. Hiring-manager prior, and the JD is built around planning and running a calendar | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the gaps and the motivation | High. Hiring-manager prior, and your own message names two things you have not done | Rehearse the most predictable objection until it is boring; hold what the quotes carry, concede plainly what they do not |
| Data-Driven Prober | Line-by-line probing of the numbers you have presented | Medium. The JD names retention metrics and a KPI-reporting review | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| Conversational / Rapport Builder | Friendly opener, casual questions that are still scored | Medium. Most 60-minute conversations open this way; weight is not raised by any source | A 90-second arc built only from your own sentences; never answer the reverse-question slot with "I think you have covered everything" |
| Pressure / Stress | Interrupts, time-boxes, tests composure | Low. A prior for skip-level rounds, not hiring-manager ones | Pause, restate the question, anchor in what you stated, hold two follow-ups before conceding anything |
| Peer Evaluator | Seam-splitting between adjacent teams | Low for a hiring-manager round, so no bank. If Tobias is a peer, this becomes the top persona | Not drafted until the relationship is confirmed |
| Values / Behavioral | Scenarios mapped to published values | Low. No values page was read and no values-style round was detected, so no bank | Not drafted until a values source exists |

## Question banks

Bank letters skip F so fit rows F1 to F8 stay unambiguous.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A seasonal event lands in three weeks and the art team says their assets will slip by a week. Walk me through what you do." | CASE | [generic] | Clarify first: what slipped, what the event depends on, what is fixed. Then the objective, the options (hold the date, cut scope, move the date), who you would need to hear from, and what each option costs. Say which you would pick and what would change your mind. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's coordination requirement (F4). CASE because it scores structure under a slipping dependency, not experience |
| A2 | "Sketch the plan for the next quarter's live-events calendar across two titles. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify first (the titles, their audiences, fixed dates, team capacity), then objective, segmentation of the quarter, approach, metrics, risks. One optional anchor, in the quote's words only: "I ran the weekly content-drop calendar for our main title for the last two years." The pack's observation is that your material shows one title's content drops, not events across two. Answer slot: say in your own words what in how you ran that calendar would carry over to two titles and what would not; if little would, say so plainly and stay with the structure | The JD's headline responsibility (F3), so some form of this is near-certain. CASE because it asks for a plan, not a record |
| A3 | "Day-seven retention for players who joined during the last event is 20 percent lower than for the event before it. Diagnose it." | CASE | [generic] | Clarify first: which players, what else changed between the two events (content, build, timing, audience), and how retention was defined. Then rank two or three hypotheses, say how you would test each, and say what you would report and to whom. Say plainly which data you would need that you do not have. The question needs no claim about your past | Tests the retention fluency the JD asks for (F6) on a live problem. CASE with an EXP edge, because it also shows how you think about the numbers you presented |
| A4 | "How would you structure the post-event review for an event that underperformed, and which KPIs would it report?" | JD | [generic] | Set the objective before the event so the review has something to measure against; choose KPIs tied to that objective and say why each; separate what happened from why; end with decisions and owners. The pack does not pick your KPIs. If you have a view on which you would trust most, say it in your own words. For what the numbers you presented covered and what was yours, use F5's slot rather than this answer | The JD makes the review and its KPIs yours to own (F5). JD because it scores the stated responsibility; CASE delivery |
| A5 | "Two hours before an event goes live, QA flags a blocker. What do you do, and who do you tell?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Facts first: what is blocked, what ships if you do nothing, what the options are (delay, ship without the feature, hotfix path), who decides, who needs telling and when. If you refer to the checklist, stay with the quote: "I wrote the release checklist our QA team still uses." Answer slot: if a blocker like this ever reached that checklist, say what happened and what was yours; if none did, or it was not yours to handle, say so plainly and answer as a plan | The JD's checklist-with-QA requirement (F7) under time pressure. CASE because it scores decisions, not documents |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have been an associate producer. What makes you ready to own the calendar for two titles?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Never led a team" | The highest-ROI prep in this pack. Hold only what the quotes carry: "I've spent four years as an associate producer at a puzzle-game studio, and I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups by returning to that calendar, never by adding to it. Concede plainly if pressed on leading: "I've never led a team." Then say, in your own words, what you would do in your first weeks to earn the calendar. Answer slot: expect a probe on how the weekly calendar would carry to two titles. Say what would carry and what would not; if little would, say so plainly and stay with the calendar you ran | This is the objection the whole snapshot points at (F1, F3). JD because it scores the stated requirement; the Skeptic delivery is how it will arrive. Most follow-up levels and the exact concession are drafted here because the material is thinnest exactly where this question presses |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team"; "never worked on a game with in-app purchases" | Choose by your own judgment; the pack does not pick for you. If your answer is one of the two things you told me, the words are: "I've never led a team" or "I've never worked on a game with in-app purchases." Say it once, plainly, then say what you would do about it as a plan, never as a past. Name the first concrete step in your own words | A persona stem asked of nearly every candidate. JD because it scores honest self-assessment against the listed role; the stated negatives are what make it dangerous to improvise |
| B3 | "Tell me about a time you got another team to change their plan to hit a date." | JD | [generic] | Selection scaffold: pick a time that has a named stake, a specific ask you made of the other team, what they moved or gave up, and an intact working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use "we" for context and "I" for what you did | The JD's four-team coordination line (F4) has no quote behind it, so this is a scaffold, not a story map. JD because the theme is the stated requirement |
| B4 | "I don't see in-app purchases anywhere in your background. Does that matter for this role, and how would you close it?" | JD | [grounded] "never worked on a game with in-app purchases" | Open with the plain acknowledgment: "I've never worked on a game with in-app purchases." Then answer the question you were asked: whether it matters is theirs to say, so ask Tobias how much of the role touches it, then give a plan for closing it in your own words. Do not claim adjacent monetization experience your material does not show | The candidate stated this gap, so it will be probed whether or not the JD names monetization. JD with Skeptic delivery, because it scores honest self-assessment |
| B5 | "Why live operations at Saltmarsh, and why now?" | JD | [generic] | State your own reason in your own words. This pack has read nothing about Saltmarsh and supplies no company facts for you to borrow. Keep it to what you can defend: what you did in the last two years that made you want this role, using only your own sentences | Motivation consistency is the default Skeptic probe. No company research ran, so this stays generic and the CO type is absent |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. What was in them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F6: the numbers were monthly, they were retention numbers, and the audience was the studio head; those are the beats the quote states. Answer slot: the JD's retention-metrics line makes a probe on what the numbers covered and how each was counted likely. Say what they covered and what part was yours, in your own words; if you presented numbers someone else produced, or you do not know how something was counted, say so plainly and stay with presenting | F6 is the evidence for the retention requirement, and F5 shows why the probe will press on whose numbers they were. EXP because it tests attribution |
| C2 | "Which assumption behind those numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The weakest-assumption move. Name, in your own words, the assumption you would defend least before the interviewer does. The pack does not name one. Answer slot: if you know how the numbers were counted, say the weak point; if you do not know, say plainly "I don't know how that was counted" and say how you would find out | A persona stem for the prober. EXP because it converts a gotcha into a credibility gain, and the honest branch is a legitimate answer |
| C3 | "Walk me through how one week's content drop went from plan to live." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F2: a weekly cadence, one main title, two years; tell those in your own words. Answer slot: the JD's coordination line makes a probe on who you worked with likely. If you worked with design, art, engineering or community on a drop, say which and what each gave you; if not, or it was someone else's job, say so plainly and stay with the calendar you ran | F2 is the strongest evidence you hold, so it will be tested hardest. EXP because it checks what was actually yours; F4 shows why the coordination probe rides along |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc in this order, each beat in the quote's own words: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for the last two years; the release checklist QA still uses; the monthly retention numbers to the studio head. Leave out anything the quotes do not state. Close with why this role, in your own words | The casual opener is still scored. EXP because it is a chronology of your claims; F1 to F7 supply the beats |
| D2 | "Tell me about something you have written that other teams relied on." | JD | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F8: you wrote it, QA is the team, and it is still in use; those are the beats the quote states. Answer slot: the JD's written-communication line makes a probe on how it came to be written and what part was yours likely. If you wrote it alone, say so; if others shaped it, say who and how; if you cannot share it, say so plainly | The only JD line about writing (F8). JD because it scores the stated requirement; the Conversational delivery makes it easy to under-prepare |
| D3 | "What would you want to do in your first ninety days?" | JD | [generic] | A plan, not a past. Say what you would want to learn first, who you would sit with, and what you would want to have changed or shipped, in your own words. The pack supplies no specifics about Saltmarsh and none about what you have done | The JD's calendar responsibility (F3) as a forward question. Generic because no company research ran |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has already run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "Never led a team"; "never worked on a game with in-app purchases" | Hold-then-concede. Hold only what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years, I wrote the release checklist our QA team still uses, and I presented the monthly retention numbers to the studio head." Hold through two follow-ups. If pressed on leading or on purchases, concede exactly: "I've never led a team" or "I've never worked on a game with in-app purchases." Do not claim a comparison you cannot back | The hypothetical rival is the stem's pressure device. F3 is where it presses hardest. JD because it scores fit to the stated role |
| E2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold what the quote carries: "I wrote the release checklist our QA team still uses." Answer slot: if you wrote it alone, say so; if others shaped it, say who and what part was theirs; if you cannot say, say so plainly. Hold through two follow-ups, then concede specifically, never on the core claim | A persona stem. EXP because it tests attribution on F7, where the verb gap between wrote and manage is the soft spot |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 3+ years producing live-service games or apps | B1, D1, E1 |
| experience running a content calendar | C3, B1, D1 |
| comfortable with player-retention metrics | C1, C2, A3 |
| clear written communication | D2 |
| Plan and run the live-events calendar for two of our mobile titles | A2, B1, D3 |
| coordinate design, art, engineering and community teams on each update | A1, B3, C3 |
| own the post-event review and the KPIs it reports | A4, C1, A3 |
| manage the release checklist with QA | A5, E2, D2 |

## 11. Reverse questions

Role-generic, because no interviewer profile was available. None is tied to Tobias's own path.

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| G1 | "How does the live-events calendar get planned across the two titles, and where does the producer sit in that?" | Shows you are thinking about the actual job before you hold it | [generic] |
| G2 | "What does a good post-event review look like here, and who acts on it afterwards?" | Signals you care about outcomes after an event ships, not only shipping | [generic] |
| G3 | "Which KPIs does the review report today, and which do you trust least?" | Invites a candid answer and shows metric fluency | [generic] |
| G4 | "When dates collide, where does the producer's call end and design's or engineering's begin?" | Shows you are thinking about authority and seams, not only process | [generic] |
| G5 | "How does the release checklist work with QA today, and where does it hurt?" | Turns your checklist experience into a question about their actual friction | [generic] |
| G6 | "What would success look like at ninety days?" | Gives you a target to prepare against before day one | [generic] |
| G7 | "What role, if any, does monetization play in the events a producer plans, and how would you want a new producer to get up to speed?" | Raises your stated gap on your terms, as a plan; optional, use only if B4 did not already cover it | [generic] |

## 13. Prohibited claims

Built from the fit snapshot before the banks were written. The banks stay inside these limits.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative the candidate stated: "Never led a team" | The plain acknowledgment: "I've never led a team." No slot |
| Worked on in-app purchases or monetization | Negative the candidate stated: "never worked on a game with in-app purchases" | The plain acknowledgment: "I've never worked on a game with in-app purchases." Then a plan for closing it, never a past |
| Ran a live-events calendar across two titles | Inflated form of F3 | F3's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: the material says a content-drop calendar for one title |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope: "Presented the monthly retention numbers to the studio head." The limit is the pack's observation: the material says presented, not owned |
| Produced or defined the retention metrics | Inflated form of F6 | F6's quote at its own scope: "Presented the monthly retention numbers to the studio head." The pack's observation: the quote does not say who produced them |
| Managed the release process with QA | Inflated form of F7 | F7's quote at its own scope: "Wrote the release checklist our QA team still uses." The pack's observation: the material says wrote, not managed |

## Sources

Provided documents: the job description pasted in your message, and your background as stated in the same message. No CV file and no `tuesday-dossier.md` were provided.

Searches sent, all refused, none returned:

- "Saltmarsh Games mobile studio values" — refused
- "Saltmarsh Games interview process Live Operations Producer" — refused
- "Saltmarsh Games strategy news mobile titles" — refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Call refused. Would have moved a values cheat sheet (section 10), and only if a loop source also documented a values-style round |
| 2. `Saltmarsh Games interview process live operations` | unavailable | Call refused. Would have moved the persona weights, which now rest on the generic archetype and an assumed hiring-manager round |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Call refused. Would have moved the CO bank and made A2 company-specific; both are absent or generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Name given, call refused. Would have moved the interviewer read (section 7), persona adjustments and a reverse question tied to his path; all are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access, or a pasted values page, careers page or loop description → a values cheat sheet if the loop has a values round, and persona weights set from the real loop instead of an archetype
- Tobias's public profile, talks or writing → an interviewer read, persona adjustments, and a reverse question tied to his own path
- The recruiter's prep email → the real round format, any pre-declared deliverable, and the stated focus areas
- A recent news item or strategy summary for the two titles → company-specific CO and CASE questions, and A2 grounded instead of generic
- Your answers to the slots in F1, F3, F4 and F5, said outside a drill → those rows move from discovery toward grounded, with your own sentences quoted into the evidence column
- Your CV or an earlier resume → more quotes for the fit snapshot, and more of the banks story-mapped instead of scaffolded
- A prior job-underwriter dossier → verified evidence and a sourced prohibited-claims list; this pack was built without one and does not need it
