Web search was refused, so I'm building the pack from your message alone and saving it now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-5-denied-eef0dedf/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

- **What it rests on:** only your message. Web search was refused, so nothing about Kelverton's values, strategy, loop or interviewers was looked up. There's no JD, no CV text and no text of the market report. I treated Deepa as the hiring manager and Ross as a senior commercial voice who'll press on numbers.
- **Plan for your four hours:** the pack has a triage schedule. Roughly 105 minutes goes on the 15-minute POV, 45 on the "never sold into rail, no direct quota" question (B1), 45 on defending the £4M figure, 30 on the report and 15 on reverse questions.
- **The question to rehearse most:** B1, the Skeptic's challenge on rail selling and the missing quota. It rests on gaps you stated yourself.

Say the word and I'll run a live drill as Deepa on B1, with follow-ups that react to what you actually say. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you want it.

Can you paste the JD and your CV bullets for the payments role? The requirement rows, the Skeptic questions and the Prober questions (B and C) are built from the recruiter's words and one sentence of yours, and the JD and CV would let me rebuild them on the real requirement list.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Panel round, 60 minutes, on Tuesday. Interviewers: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Format per the recruiter: a 15-minute POV from you with no slides, then Q&A in which Ross will push on commercials. First build of this pack.

## How to use this pack

- Personas are how a question arrives (who is asking, in what style). Types are what is being scored. Every question carries one type tag:
  - VAL: past behavior against values or principles
  - EXP: whether a claim in your background survives scrutiny
  - JD: the role's stated or typical responsibilities, including your gaps
  - CO: company and strategy knowledge
  - CASE: a live problem set in the role
- Guidance is scaffolding, not a script. Where a cell says answer slot, it is an instruction for the interview: answer from your own experience in your own words, or say plainly that the step was not yours or did not exist.
- Provenance labels: grounded (traceable to something you or the recruiter wrote), inferred (derived, derivation named), generic (a role-family pattern with no claim about Kelverton or about you).
- Question IDs are letter-by-persona (A, B, C, D, E, G, H; the letter F is skipped so it cannot be confused with fit-snapshot rows F1 to F5).

## Prep triage

You have about four hours. Do these in order; each is tied to a section or question ID.

| Order | Time | What | Where |
|---|---|---|---|
| 1 | 105 min | Build the 15-minute POV, write your thesis and your operator close in your own words, speak it aloud three times, and time it to about 13 minutes | Graded deliverables; A1 to A4 |
| 2 | 45 min | Rehearse B1 aloud until it is boring, then B2 and D2. B1 is the highest-ROI prep in this pack | B1, B2, D2 |
| 3 | 45 min | Write your own answers to the answer slots on the £4M figure; Ross will push here | C1 to C3, D1 |
| 4 | 30 min | Reread the market report and pick one point to agree with, one to diverge from, and one thing you would not do | A5, A2 |
| 5 | 15 min | Choose three reverse questions | Reverse questions |

Everything else is insurance: the E, G and H banks, and a light read of A3, A4 and D3.

## Fit snapshot

No JD was supplied, so the requirements below are the recruiter's own words, quoted from your message, plus two role-family patterns written as plain prose and labeled generic where they stand. No row below is a gate: nothing in your material names an eligibility, location, travel or credential term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, as you quoted it | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships, and the words stay there: "For the last 4 years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: the recruiter's POV ask makes a probe on how an ISV channel compares with operator partnerships likely. If any part of what you did carries over, say which part and how, in your own words; if none does, or the comparison is not one you can make, say so plainly and return to the channel you ran |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email, as you quoted it | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies, and the words stay there: "Before that I spent 5 years in transport consulting, in bus and light rail network planning." Answer slot: the recruiter's ask makes a probe on which operators and what you saw likely, and on what the other side means. If train operating companies were among the operators you worked with, say so; if not, say so plainly and stay with bus and light rail; say whose side the other side was, in your own words |
| F3 | "Ross will push on commercials" — recruiter's email, as you quoted it | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | discovery | The material gives a figure with the word influenced attached and shows nothing about how it was counted. The words stay at that scope: "roughly £4M of influenced revenue." Answer slot, the four a figure raises: how the figure was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, or a part was not yours, say so plainly |
| F4 | Carrying a revenue target is typical of this title (role-family pattern, no JD supplied) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't carried a direct quota; my number has been influenced revenue." Then how you would work with a number, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | Credibility with train operating companies as a vendor-side partner (inferred from your description of who Kelverton sells to; no JD supplied) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then how you would learn the buying side, said as a plan and never as a past |

## Graded deliverables

The recruiter declared one: a POV of about 15 minutes with no slides, on where you would take operator partnerships over the next 18 months, landing on what it means for the operators themselves. It is graded, so it gets its own build.

### Facts you may build on

| Row | What you may say about yourself, exactly as you wrote it |
|---|---|
| F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." |
| F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." |

Say nothing wider than those sentences about your own past. Everything else in the POV is argument about the future, and is yours to own.

### Shape and timing

About 13 minutes of material, leaving a buffer.

| Block | Time | Content |
|---|---|---|
| Thesis | 2 min | One sentence first, then why. Do not open with your background |
| What I would need to learn | 1 min | Say plainly what you do not yet know about their operators, in your own words |
| The 18 months | 4 min | Three phases, each with one outcome you would hold yourself to |
| What it means for operators | 3 min | The close the recruiter asked for; see below |
| What I would not do | 1.5 min | The anti-pick and its cost |
| Risks and how I would test them | 1.5 min | Two risks, how you would find out early |

### Thesis options, each with a mandatory concession

Pick one as your lead. The other two serve as the divergence and the anti-pick. All three are patterns for a vendor partnership function, with no claim about Kelverton.

| Thesis | Mandatory concession | Provenance | What the operator gets, to say in your own words |
|---|---|---|---|
| Go deep before wide: a few operator partnerships built around an outcome the operator itself would name, before any broader program | Some operators wait, so coverage and near-term pipeline are slower, and Ross will push on exactly that | [generic] | Name the outcome an operator would recognise. Slot: take it from the market report or from the bus and light rail planning in F2, and say which |
| Build an ecosystem around the scheduling product: partners that extend what operators can do without Kelverton building all of it | The only parallel in your material is a payments channel (F1), an analogy and not a rail precedent; breadth also multiplies support and quality-control load | [generic] | Name one thing an operator could do that it cannot do today with Kelverton alone. Slot: from your own reading, and say where it came from |
| Tie every partnership to a named commercial path from day one: who pays, and what changes in the contract | Front-loading the commercial path can narrow what gets explored with an operator and slow trust | [generic] | Name what the operator gets in exchange for committing. Slot: in your own words, and say what you would not ask of them |

### Differentiating from the market report

The report came from Kelverton's strategy team (your sentence: "She also attached the market report their strategy team circulated internally last quarter, which I've read."), so the panel knows it and other candidates may have it. Reciting it scores as homework. Departing from it with reasons scores as judgment.

1. Bring one point from the report you agree with, in one sentence, to show grounding. Slot: which point, from your own reading; this pack has not seen the report.
2. Then one divergence, with your reason. Slot: where your lead thesis differs from what the report implies.
3. Then the anti-pick: one thing you would deliberately not do in 18 months, and what that costs. The role includes saying no to partners.

### The close the recruiter asked for

End on operators, in two beats: what an operator gains by month 18, and what it is asked to give (time, data, change). Naming the cost to the operator is the half most candidates leave out. Use only first-hand operator detail at the scope of F2, and say where anything else came from.

## Persona table

| Persona | How it shows up | Likelihood | Reasoning shown | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Live problems that follow your POV: what would you cut, how would we know it is working | high | Hiring-manager prior is Case/Strategist plus Skeptic, and the recruiter made the POV a graded first 15 minutes, so the Q&A probably builds on it | Clarify, then objective, approach, metrics, risks; challenge one premise respectfully. Any story from your past stays at the scope of F1 and F2 |
| Skeptic | Quiet probing of what is missing: rail selling, a direct number, why this move | high | Hiring-manager prior; F4 and F5 are gaps you stated yourself, and a stated gap is the first place a skeptic goes | Rehearse B1 until it is boring; bridge only from F1 and F2 at their own scope; never bluff a competency |
| Data-Driven Prober | Pressure on the figure and the 6-to-40 growth | high | The recruiter wrote "Ross will push on commercials", and F3 holds the one figure in your material | Know what you can and cannot say about how the figure was counted; name the assumption you would defend least before they do |
| Pressure | Interrupting, time-boxing, motive challenges | medium | Executive-level prior pairs Case with Pressure, and push is the recruiter's own word | Pause, restate, hold the position through two follow-ups, then concede specifically |
| Peer Evaluator | The seam between partnerships and commercial, and credit when work spans both | medium | Role-family pattern (generic): adjacent functions test the seam. No source says how Kelverton divides them | Offer seam principles, not a claimed seam; reciprocity framing |
| Conversational | The opener: walk me through the journey | low | A 60-minute panel with a 15-minute POV leaves less room for chat, but openers are still scored | A 90-second arc built from F1 and F2 |
| Values/Behavioral | Scenario prompts on unpopular truths or customer-first calls | low | The recruiter named no values-style round and none is assumed; no company values were read | Selection scaffolds ending in the honest branch |

Loop basis: the recruiter's own words establish this session (panel of two, 60 minutes, 15-minute POV then Q&A), so no archetype fallback is used.

## Question banks

Ordered by weight. Quotes in Provenance are exactly as they appear in the fit snapshot.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Give me the thesis in sixty seconds: where do operator partnerships go in the next 18 months, and what do operators get?" | CASE | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Thesis first, one sentence, then the three phases from your POV build. For your standing, use one sentence in your own words about the bus and light rail network planning, no wider than that quote. Close on what the operator gets, in your own words | This is the POV compressed, which the recruiter's brief makes the likeliest opener; F2 supplies the only operator-side evidence. CASE because it is a live problem on the role |
| A2 | "What would you deliberately not do in the first 18 months, and what does that cost us?" | CASE | [generic] | Name one thing, give the reason, state the cost plainly, and say what would make you reverse. The question needs no claim about your past, so the guidance makes none | The anti-pick from the deliverable, asked live; where the role includes saying no, a hold with a stated cost reads as judgment. CASE because it is a decision set in the role |
| A3 | "Pick one problem an operator has that a partnership could change, and walk me through what changes for them." | CASE | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Clarify which operator and which problem before structuring. Answer slot: if the problem is one you saw first-hand, say so and say plainly that it was bus or light rail; if it comes from the report, say that is where it came from | The recruiter asked the POV to land on operators, so this tests it live; F2 is the first-hand limit. CASE with a CO flavour |
| A4 | "How would we know in month 12 that operators are better off?" | CASE | [generic] | Pick two measures an operator would recognise and one Kelverton would track, and say how you would find out what operators care about instead of assuming it. No claim about your past is needed | The follow-up a Case interviewer asks of any POV that ends on a benefit; F3 shows why measures will be pushed on. CASE because it scores structure, not a fact |
| A5 | "What in the strategy team's market report do you agree with, and where would you push back?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | One agreement in one sentence to show grounding, then one divergence with your reason. Do not recite. Answer slot: if you differ from the report somewhere, say where and why from your own reading; if you agree throughout, say that and say what you would add. Do not criticise the authors | The panel's own document is the consensus answer; differentiation is the rubric. CO because it tests homework depth |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail and you haven't carried a direct quota. Why should we trust you with operator partnerships?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Highest-ROI rehearsal in this pack. Beat 1, plain and unflinching: "I haven't sold into rail specifically, and I haven't carried a direct quota; my number has been influenced revenue." Beat 2, only what the quotes carry: the ISV channel, 6 partners to 40, the influenced figure with the word influenced attached, and the 5 years in bus and light rail network planning. Beat 3, a plan and not a past: who you would meet first and what you would have learned by day 30, 60 and 90, in your own words. Hold the channel and the planning years through two follow-ups; concede the rail and quota gaps specifically; never widen either | F4 and F5 are gaps you stated, so this question arrives in some form. JD because it scores the role's fit, Skeptic because it is aimed at the gaps |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick the gap your own sentence names, say it in those words, then what you would do about it in the first 90 days. Pick one and stop; a list reads as nervous | A persona stem; with no JD, your stated gaps in F4 and F5 are the honest answer. JD because it asks about the role |
| B3 | "You describe roughly £4M as influenced revenue. What does influenced mean in practice, and where did your part stop?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Answer slot, the four a figure raises: how it was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, or a part was not yours, say so plainly and return to the channel you ran | F3 holds the figure and F4 your stated limit, and a Skeptic reading both asks this. EXP because it tests attribution |
| B4 | "Your partnerships were in payments and your operator knowledge is bus and light rail. What carries over to train operating companies?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Answer slot: name one thing from the channel and one from the planning years that you think carries over, with the evidence in your own words; if you cannot name one that holds, say so plainly and say how you would test it in the first 90 days | F1 and F2 are both adjacent, not direct; this is the bridge question. JD because it scores the transfer to the role |
| B5 | "Why leave payments for rail-tech, and why now?" | JD | [generic] | The reason is yours and this pack does not know it. Say the reason you would give a friend, short, and tie it only to things you have actually said or done; do not state admiration for Kelverton you have not formed from what you read | A persona stem for the Skeptic's motive check. JD because it tests consistency of the move with the role |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say how it was counted, in your own words, step by step as far as you know. If you do not know the method, or it was someone else's, say so plainly and say what you do know. Do not supply a method you cannot repeat under a second question | F3 is the figure a Commercial Director presses first. EXP because it tests the number's provenance |
| C2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Name it before they do, in your own words, and say what would change if it were wrong. If you do not know one, say so plainly; that is an honest branch, and bluffing one is not | The weakest-assumption move turns a gotcha into credibility; F3 is the target |
| C3 | "You took the channel from 6 partners to 40. What counted as a partner, and which part of that growth was yours?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say what counted and which part was yours, in your own words; if the definition was someone else's or you do not know it, say so plainly and stay with the sentence you wrote, taking it from 6 to 40 | The growth figure is the second number on the page; F1 holds it. EXP because it tests attribution |
| C4 | "Next to a commercial team that carries the number, how would you want revenue credited, and why?" | CASE | [generic] | State a position on influenced versus direct credit, then the cost of it. If a view comes from the payments work, say so in your own words; otherwise answer as a design problem. No claim about your past is made here | Ross's push on commercials, set as a design question; F3 and F4 are the exposure. CASE because it scores reasoning |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That £4M — how much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Hold-then-concede. Pause, restate. Hold through two follow-ups only what you wrote: roughly £4M of influenced revenue, the word influenced attached. Concede specifically that you have not carried a direct quota. Do not fold into saying the work was unconnected to the revenue. Answer slot: which part was yours, in your own words | A persona stem aimed at F3 and F4 together. EXP because it tests attribution under pressure |
| D2 | "Sixty seconds: why you over someone who has already sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Acknowledge the gap in your own words first, then say what you bring, at the scope of F1 and F2, and let them make the comparison. Do not argue that your background beats rail selling | F5 is a stated gap, so this comparison is the pressure form of B1. JD because it scores fit |
| D3 | "Stop. Cut your 18-month plan in half. What goes?" | CASE | [generic] | Pause and restate. Name the cut, its cost, and what you would do to protect the part that stays. Tie it to the thing you said you would not do | A time-boxed prioritisation check; the pressure is in the interruption. CASE because it scores trade-offs |

### E. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and commercial sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Offer principles for the seam, not a claimed seam: who owns the operator relationship, who owns the number, how a disagreement is escalated and recorded. Say what you bring to the commercial side as well as what you need | Ross is Commercial Director, and the seam is where the role's value is tested; the persona stem. CASE because it is a live design problem |
| E2 | "How do you handle credit when an outcome spans partnerships and commercial?" | VAL | [generic] | State your principle first. Answer slot: if a real case from your channel work comes to mind, tell it in your own words; if none does, say so plainly and answer as a principle | A persona stem; F3 and F4 make credit a live topic. VAL because it scores collaboration behavior |
| E3 | "What would you need from my team in your first 90 days?" | JD | [generic] | Lead with what you bring, then what you need, in that order. Keep the needs few and specific to what you said you do not yet know | A peer stem; reciprocity framing. JD because it asks about working in the role |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey from transport consulting to here." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc in two beats the quotes carry: 5 years in transport consulting, bus and light rail network planning; then partnerships, with the last 4 years at a payments company running the ISV channel. Third beat, a slot: why you moved from one to the next and why this role, in your own words; if the moves were not deliberate, say that | The opener is scored even when it feels casual; F1 and F2 give the arc. EXP because it tests the story's consistency |
| G2 | "What have you been reading or following in rail scheduling lately?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Answer slot: name what you have read, in your own words; the report is one you said you read. If nothing beyond it, say so plainly and say what you would read next | A persona stem aimed at casual-register homework. CO because it scores curiosity about the domain |

### H. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to a senior person." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; no quoted sentence of yours carries this story, so it is a scaffold. VAL because it scores behavior |
| H2 | "Tell me about a time you put a partner's interest ahead of an internal metric." | VAL | [generic] | Selection scaffold: a named partner, a metric that pointed the other way, the decision, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; a partnerships role invites it and no quote of yours carries it. VAL because it scores behavior |

## Requirement coverage

| Requirement | Questions |
|---|---|
| POV on operator partnerships over 18 months (recruiter) | A1, A2, A4, D3, and the Graded deliverables section |
| Land on what it means for operators (recruiter) | A1, A3, A4, B4 |
| Ross will push on commercials (recruiter) | C1, C2, C3, C4, D1, E1, E2 |
| Carrying a revenue target (role-family pattern) | B1, B2, C4, D1, D2 |
| Credibility with train operating companies (inferred) | B1, B4, D2, G2 |
| The market report, which you have read | A5, A3, G2 |
| JD-listed requirements | none, and why: no JD was supplied |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "In 18 months, what would make you say operator partnerships had worked, and what would an operator have to say about us for that to be true?" | Returns to the brief the recruiter set and surfaces the success measure in the interviewer's own terms |
| 2 | "Where do you want partnerships to carry a number, and where would you rather it influenced one?" | Brings the quota question into the open on your terms (F4) instead of leaving it to the offer stage |
| 3 | "What does a good operator partnership look like today, and where does it fall short?" | Shows you are thinking from the operator's side, and gives you their view before you commit to a thesis |
| 4 | "What would you want from this hire in the first 90 days that you cannot get today?" | A reciprocity question that gives the interviewer room to describe the real job |
| 5 | "Where is the seam between partnerships and commercial today, and where does it get tested?" | Peer framing for Ross, and a way to learn how credit works before you are in it |
| 6 | "Of the points in the strategy team's market report, which are you most acting on?" | Shows you read it and hands them the floor, without reciting it |

## Prohibited claims

What this pack will not coach, and why. Built before the banks and binding on every guidance cell.

| Not coached | Basis | Honest form |
|---|---|---|
| That you have worked with train operating companies | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says bus and light rail network planning, not train operating companies |
| Sold into rail, or rail partnership experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't sold into rail specifically." No answer slot |
| Carried a quota, or owned a revenue number | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't carried a direct quota; my number has been influenced revenue." No answer slot |
| £4M of revenue you generated, closed or owned, with influenced dropped | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue." The limit is the pack's observation: the material says influenced, and shows nothing about how it was counted |
| Built or launched the ISV channel | Inflated form of F1 | F1's quote at its own scope: you ran the ISV channel and took it from 6 partners to 40. The limit is the pack's observation: the material says running it, not building it |

## Sources

Provided: your message, which includes the recruiter's email as you quoted it and your background. Not in hand: the market report (its text was not supplied; only your sentence about it is used), a JD, and CV text. No dossier was present.

Queries sent, every one refused:

| Query | Result |
|---|---|
| Kelverton Rail company values | refused |
| Kelverton Rail interview process partnerships | refused |
| Kelverton Rail scheduling software train operating companies news strategy | refused |
| Senior Partnerships Manager rail technology scheduling software job description UK | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have fed a values cheat sheet; none is built, and the H bank uses persona stems |
| 2. Kelverton Rail interview process, partnerships | unavailable | Would have tested the loop basis; the recruiter's own words established this session, so persona weights rest on those |
| 3. Kelverton Rail strategy and recent news | unavailable | Would have grounded the CO bank and a grounding brief; A5 and G2 rest on your sentence about the report only |
| 4. Interviewer public footprint (Deepa, Ross) | unavailable | Would have fed an interviewer read and a reverse question tied to their paths; both are absent |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have given inferred requirement rows; the fit snapshot uses the recruiter's words and two role-family patterns instead |

## Upgrade menu

- The JD text: the role-family rows F4 and F5 become quoted requirements, JD-tagged questions are mapped to the posting's own list, and any gate terms such as location or travel surface
- CV bullets for the payments and consulting roles: F1 to F3 gain further quotable sentences, and the banks move from scaffolds to story maps
- An attribution report or a quarterly partner review deck from the ISV channel, with figures anonymised: it would raise F3 from medium toward high, and it is the artifact a prober would ask for
- The market report's text pasted in: A5 and G2 become grounded in its actual points, a grounding brief is added, and the differentiation step names the report's own shortlist
- Your answers to the answer slots in F1, F2 and F3, and C1 to C3: each answer enters the snapshot as a quote and upgrades the rows that drew on it
- Interviewers' surnames or profile links: an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to each one's path
- Permission for web search: values, loop reports, recent strategy news and a representative JD, with rows 1 to 5 above re-run
- A tuesday-dossier.md, if you have one: it would carry verified evidence and prohibited claims into this pack; it is not needed to use it
