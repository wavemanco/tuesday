Research is back: the values page, the loop, a strategy announcement and Tobias's GDC talk all came up. I'm now fetching the values and interviewing pages for exact wording, then I'll write the pack.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-canned-a8127e65/Saltmarsh-Games_live-operations-producer_interview_pack.md`. I built it assuming Tobias is the hiring manager you'd report to.

Saltmarsh's interviewing page describes the loop as the "Outage Hour": a 60-minute hiring-manager interview with a live-incident tabletop, then a values conversation. The pack has 19 questions weighted toward that shape.

- **Highest-ROI prep:** C1 is "You've never worked on a game with in-app purchases, and we're moving to a season pass. Why should I believe you can run this calendar?" Saltmarsh's September announcement describes a season-pass move. The pack rehearses a plain acknowledgment, then your calendar, checklist and retention-number lines, then a ramp plan.
- **Your strongest material:** the release checklist QA still uses, which overlaps with Tobias's QA background, and the retention numbers you presented.
- **Where the pack stays careful:** your material shows a content-drop calendar for one title. The JD asks for a live-events calendar for two titles, plus coordination across four teams and ownership of post-event reviews. Those rows are answer slots, not claims. The pack also won't coach "led a team" or any monetization work.
- **Research:** the values page and loop page are fetched. The strategy announcement and Tobias's GDC talk are snippet-only, and the pack says so.

Say the word and I'll play Tobias on C1 (the in-app-purchases objection), or run a tabletop drill on A1 or D1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did your recruiter share anything about how the hour is run?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh-Games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Built for a hiring-manager round, on the assumption that Tobias is the person the role reports to. Saltmarsh's own interviewing page describes every loop as a recruiter call, then the Outage Hour: one 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home. Your hour matches that shape.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values |
| EXP | Whether your background claims survive a close read |
| JD | The stated responsibilities and requirements of the role |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, worked out loud |

## Prep triage (until Friday)

1. Rehearse C1 out loud, twice. It is the single most likely objection and the highest-ROI prep in this pack.
2. Run A1, A2 and D1 against a timer. The tabletop is half the hour, and these are the shapes it takes.
3. Choose real stories for B1, B2 and B4 from your own history before Friday, using the selection criteria in each row. If none comes to mind, the honest branch in each row is the answer.
4. Re-read your own calendar and checklist so C2, E3 and B3 come out in your own words.

Everything else in the pack is insurance.

## Fit snapshot

Gate check: none of the JD's requirements is a gate. "3+ years" is a length-of-experience line, graded like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "experience running a content calendar" - JD | "I ran the weekly content-drop calendar for our main title for the last two years" - your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you ran the weekly content-drop calendar for the main title, for two years |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" - JD | "I ran the weekly content-drop calendar for our main title for the last two years" - your message | medium | [grounded] | transferability | Your material says a content-drop calendar for one title, not an events calendar for two, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-title, live-events wording makes a probe on both likely. If your calendar carried events beside drops, or you ran more than one calendar, say how, in your own words; if it held only drops, or only one title, say so plainly and stay with the calendar you ran |
| F3 | "coordinate design, art, engineering and community teams on each update" - JD | "I ran the weekly content-drop calendar for our main title for the last two years" - your message; "Never led a team" - your message | low | [inferred] | discovery | The calendar line touches coordination without showing it, and your message does not say which teams you worked with. Answer slot: if you worked with any of design, art, engineering or community to get a drop out, say which and what you needed from each; if you did not, or it was not yours to coordinate, say so plainly and stay with the calendar you ran. Your stated negative gives one plain acknowledgment: "I haven't led a team." The JD's word is coordinate, which the pack notes without treating it as a claim about you |
| F4 | "own the post-event review and the KPIs it reports" - JD | "Presented the monthly retention numbers to the studio head." - your message | low | [inferred] | discovery | Presenting retention numbers touches the requirement without showing a post-event review or ownership of the KPIs. Answer slot: if you wrote or ran any review of a content drop, say what it covered and what was yours; if you did not, say so plainly and stay with presenting the monthly numbers |
| F5 | "manage the release checklist with QA" - JD | "Wrote the release checklist our QA team still uses." - your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with the checklist in the quote's own terms: you wrote it, and QA still uses it, because a named record beats an adjective |
| F6 | "3+ years producing live-service games or apps" - JD | "4 years as an associate producer at a puzzle-game studio" - your message; "I ran the weekly content-drop calendar for our main title for the last two years" - your message | medium | [grounded] | discovery | The four years are stated; your material does not say whether the main title was a live-service game. Answer slot: if it was live-service, say what made it so, in your own words; if it was not, say so plainly and stay with the calendar you ran |
| F7 | "comfortable with player-retention metrics" - JD | "Presented the monthly retention numbers to the studio head." - your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it. Lead with it in the quote's terms: you presented the monthly retention numbers to the studio head |
| F8 | "clear written communication" - JD | "Wrote the release checklist our QA team still uses." - your message | low | [inferred] | discovery | A checklist is written work, but the line does not show how clear it was or who read it. Answer slot: if there is a written piece you can point to, name it and say who it was for; if there is not, say so plainly and stay with the checklist |
| F9 | Saltmarsh's September 2026 announcement moves two titles to a season-pass model with a shared events calendar (search result, not fetched) - Saltmarsh news | "never worked on a game with in-app purchases" - your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work, and nothing added to make the gap feel smaller |

## Reading the interviewer

Public professional footprint only, from one search result (a GDC 2026 talk listing, snippet only, not fetched).

| Item | What the public footprint shows | What it means for you | Provenance |
|---|---|---|---|
| Career path | Head of Live Operations at Saltmarsh; previously a QA lead at a console studio | He knows release checklists from the QA side, so the checklist row is where your vocabulary overlaps | [grounded] |
| Published theme | A GDC 2026 talk, "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | Expect precision about what shipped versus what was planned. Do not recite his talk back to him | [grounded] |
| Mirror opportunity | His QA background, and F5: "Wrote the release checklist our QA team still uses." | Shared professional vocabulary, offered as what you did, not as common ground | [inferred] |
| Written answers | The talk's theme is about announcements matching reality | If a written piece is requested in the tabletop, accuracy will probably count more than polish (a reading, not a published statement) | [inferred] |

## Persona table

Weights come from the hiring-manager prior (Case and Skeptic), adjusted by the loop page (a tabletop, then a values conversation). Recalibrate if you know something this does not.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Case / Strategist | The Outage Hour tabletop: a simulated outage during a live event | High. The loop page names the tabletop, and the hiring-manager prior favors Case. 5 questions | Clarify, then objective, then who to pull in, then what players are told, then review |
| B Values / Behavioral | The second half of the hour is a values conversation | High. The loop page names it, and the three published values give it fixed themes. 4 questions | Choose real stories per value, or say plainly that none comes to mind |
| C Skeptic | Persistent probing of one-title scale, IAP, and team leadership | Medium. The hiring-manager prior favors it, and your own message states two gaps. 3 questions | Rehearse the single most predictable objection until it is boring |
| D Pressure | Time-boxed answers inside the tabletop | Medium. A simulated outage invites it, though the page does not say interviewers interrupt (inferred). 3 questions | Pause, restate, hold through two follow-ups, then concede only what is true |
| E Data-Driven Prober | Reads your lines closely: retention numbers, the checklist | Medium. Both appear in your background and the JD. 3 questions | Say plainly what you do and do not know about how a number was counted |
| F Conversational | Opening biography and a casual question about mobile games | Low. Likely as an opener, still scored. 2 questions | A 90-second arc told from your real history |

The Peer Evaluator is dropped: the round is one interviewer, a hiring manager, not a peer.

## Question banks

### A. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a live event: the reward is not granting for some players, and the community channels are filling up. Walk me through your first thirty minutes." | CASE | [generic] | Structure it aloud: what you would ask first (who is affected, since when, is there a way to stop the bleeding), the objective (protect players, which is Saltmarsh's first published value: "when the calendar and the players disagree, the players win"), who you would pull in (engineering, community, QA), what players are told and when, and what you would record for the review. The question needs no claim about your past, so the guidance makes none | The loop page names a tabletop on a simulated outage during a live event, so this shape is likely; CASE because it scores structure under time |
| A2 | "A fix needs the same Thursday slot as a scheduled event, and engineering says the fix also needs the QA window. What gives?" | CASE | [generic] | Clarify what the fix repairs and what the event promised players, then decide by the player-first value, then say what you would tell whoever loses the slot. State one premise you would challenge, respectfully. No claim about your past | A calendar-versus-players conflict is the role's core tension, and the first published value names it; CASE because it asks for a decision | 
| A3 | "Saltmarsh is moving its titles to one shared events calendar. What would you want to know before you built it, and what would you check in the first thirty days?" | CO | [grounded] | Ask before structuring: how the titles' events collide, who decides slot conflicts, what the season-pass model changes about cadence. Then your first-thirty-day checks as a plan, never as a past. If monetization comes up, the plain line is "I haven't worked on a game with in-app purchases." Quote: "never worked on a game with in-app purchases" | The strategy announcement is the freshest company context; CO because it tests whether you thought at the company's altitude, F9 is where it presses |
| A4 | "Plan the first four weeks of an events calendar for a title you have not seen. What do you need first?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify first: cadence, dependencies, buffers, who signs off. For background, one line: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks for events across two titles; if your calendar carried events or more than one title, say how; if it did not, say so plainly and stay with the calendar you ran | F2 is the requirement this scores; JD because it is the first responsibility the posting lists |
| A5 | "What goes into a post-event review, and which numbers does it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: what the event was for, what you decided to measure beforehand, what the numbers can and cannot tell you. Your one line of background is that you presented the monthly retention numbers to the studio head. Answer slot: the JD asks you to own the post-event review and its KPIs; if you wrote or ran a review of a drop, say what it covered and what was yours; if you did not, say so plainly and describe what you would put in one | F4 is the thinnest of the JD's responsibilities against your material; JD because it scores a stated duty |

### B. Values / Behavioral (4)

Saltmarsh's published values, from its values page: Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans. Tell me about a time you changed a plan because of what players needed." | VAL | [grounded] | Selection scaffold, since no sentence of yours carries a story here: pick a time a plan was changed for the people using the product, with a named stake, what you changed, and who agreed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value, asked as an open prompt; VAL because it scores behavior against the named value |
| B2 | "Ship the Patch Not the Promise. Tell me about a time you announced only what was already built." | VAL | [grounded] | Selection scaffold: pick a time you held back, or corrected, a claim until it was real, with what the pressure to say more was and how you resolved it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second value matches the theme of the interviewer's published talk; VAL because it scores behavior against the named value |
| B3 | "Leave the Build Greener. What have you left better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | The story carried by that sentence: you wrote the checklist, and QA still uses it. Tell those beats in your own words. Answer slot: the value says each release should leave the checklist better; if you revised it after a release, say what prompted the change; if it stayed as written, or others maintained it, say so plainly and stay with the checklist you wrote | F5 is the only row that carries a story for this value; VAL because it scores the third published value |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time a number you presented was not what the room hoped, with the number, who heard it, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is presenting the monthly retention numbers to the studio head | A persona stem for the values conversation; VAL because it scores whether a hard truth landed; F7 holds the nearest material |

### C. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never worked on a game with in-app purchases, and Saltmarsh is moving its titles to a season pass. Why should I believe you can run this calendar?" | JD | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Hold in this order: the plain acknowledgment, "I haven't worked on a game with in-app purchases", then what you did carry: you ran the weekly content-drop calendar for the main title for two years, and you presented the monthly retention numbers to the studio head. Then a ramp plan, as a plan: what you would learn first and who you would ask, with no past claims. Hold through two follow-ups by returning to those quotes, and concede specifically that you have not seen monetization data. Name the limit before it is asked for | F9 is the stated gap and F2 the stretch; this objection arrives in some form because the announcement and your background meet exactly here; JD because it scores whether you can do the listed job |
| C2 | "Walk me through how you ran the weekly content-drop calendar." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Beats the quote states: weekly, the main title, two years; tell them in your own words. Answer slot: the JD asks for coordination across design, art, engineering and community; if you worked with any of them, say which and what you needed from each; if the calendar was run without them, or it was not yours to coordinate, say so plainly and describe the calendar you ran | F3 is where the JD's coordination line presses; JD because it scores the stated duty |
| C3 | "Have you led people before?" | EXP | [grounded] "Never led a team" | The plain acknowledgment: "I haven't led a team." Then what getting others to move on a date has looked like for you. Answer slot: if you got others to hold a date or change a plan, say how and what was yours; if you did not, say so plainly and describe how you would do it as a plan, never as a past | The JD asks you to coordinate, not manage, which the pack notes as its own observation; F3 holds the stated negative; EXP because it tests whether the candor is stable under repetition |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds. The reward bug is confirmed, engineering says an hour to a fix, and the studio head wants a player statement now. What do you say?" | JD | [generic] | Pause and restate. Hold one position: say only what is confirmed, as the second value puts it, "we announce what is built, not what is hoped". Concede uncertainty specifically: what you do not yet know and when you will. Written clarity is the scored skill, so keep it short and say what is confirmed first. No claim about your past | F8 is the written-communication row, and the question tests it under time; JD because it scores clear written communication, CASE is the delivery |
| D2 | "That calendar. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if some parts, such as what went into each drop, were set by others, say which, plainly; if all of it was yours, say that without adding to it. Hold through two follow-ups by returning to the calendar, never by adding to it | A persona stem for the Pressure interviewer; EXP because it scores attribution; F1 is the claim under test |
| D3 | "Why you over someone who has run monetized live events?" | JD | [grounded] "Wrote the release checklist our QA team still uses."; "never worked on a game with in-app purchases" | Hold what your quotes carry: you wrote a release checklist QA still uses. Concede the gap in one plain line: "I haven't worked on a game with in-app purchases." Then the ramp plan as a plan. Sixty seconds, no filler | The persona stem; F5 is your sharpest line and F9 the gap to concede; JD because it scores whether you can do the listed job |

### E. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which retention numbers did you present each month, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented, in those words. Answer slot: say which measures you presented and how each was counted, in your own words; if you did not build or define them, say so plainly. Name the assumption behind a number you would defend least, if you know of one; if you do not know how a figure was counted, say that plainly | F7 is the retention evidence and the likeliest place a prober digs; EXP because it tests attribution and honesty about method |
| E2 | "An event ends. Which numbers do you look at on Monday, and what would make you call it a miss?" | JD | [generic] | Fix the question before the numbers: what was the event for. Decide the comparison before the event, not after. State what the numbers cannot tell you, such as what else changed that week. No claim about your past | The JD makes retention metrics a requirement; JD because it scores comfort with them, asked as a live problem |
| E3 | "Take me through your release checklist. What is on it, and who signs it off?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | The beats the quote states: you wrote it, QA still uses it. Answer slot: the JD asks you to manage the checklist with QA; if you ran it on each release and worked with QA on sign-off, say how; if you wrote it and others ran it, or there was no sign-off step, say so plainly and describe the checklist you wrote | F5 is your strongest row and the interviewer's own vocabulary; JD because it scores a stated duty |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you get from puzzle games to wanting to do live ops here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | A 90-second arc from real history: four years as an associate producer at a puzzle-game studio, then your calendar, then your checklist, in your own words. Answer slot: why this role and this studio is yours alone to say; if the published values or the interviewer's talk is part of why, say so plainly, and if not, do not claim it | F6 holds the four years; EXP because it scores whether the story hangs together |
| F2 | "What are you actually playing at the moment, and what are its live events doing?" | JD | [generic] | Selection scaffold: pick a live mobile game you actually play, one event mechanic you noticed, and what you would change. If you do not play any, say so plainly and name the closest thing you have followed | A casual question on a hot JD topic is still scored; JD because the role runs events for mobile titles |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A2, A3, A4, C1 |
| "coordinate design, art, engineering and community teams on each update" | A1, C2, C3 |
| "own the post-event review and the KPIs it reports" | A5, E2 |
| "manage the release checklist with QA" | E3, B3, A2 |
| "3+ years producing live-service games or apps" | F1, C1 |
| "experience running a content calendar" | A4, C2, D2 |
| "comfortable with player-retention metrics" | E1, E2, A5 |
| "clear written communication" | D1 |

## Values / principles cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, players win | No quote carries a story. Selection scaffold in B1, ending in its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quote carries a story. Selection scaffold in B2, ending in its honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F5: "Wrote the release checklist our QA team still uses." Answer slot in B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live operations from QA. What did that teach you that you want a producer to bring to the release checklist?" | Ties to his own public path, and it turns the checklist into a peer conversation |
| R2 | "With the titles moving to a shared events calendar, how will slot conflicts between them be decided?" | Shows you read the announcement, and asks about the exact tension the role manages |
| R3 | "What does a strong first ninety days look like for this producer?" | Makes the success bar explicit and lets you answer to it |
| R4 | "What does a post-event review report today, and what would you want it to report that it does not?" | Goes to the one JD duty your material is thinnest on, from the side of what the team needs |
| R5 | "In the Outage Hour, what separates the answers that stand out?" | Asks what the tabletop is really scoring, which is not published |
| R6 | "What is hardest about the calendar today?" | Invites candor and gives you the real problem to name in your close |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F3 | The plain acknowledgment: "I haven't led a team." The slot in C3 asks only what getting others to move on a date has looked like for you |
| Worked on a game with in-app purchases, or on monetization | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, never a past |
| Ran a live-events calendar for two titles | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says one title's content-drop calendar, not events across two |
| Owned post-event reviews and the KPIs they report | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says presenting retention numbers, not owning a review |
| Managed the release checklist on each release | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says you wrote it and QA still uses it, not that you ran it per release |

## Sources

Provided documents: the JD text and your background, both in your message. No dossier was present.

| Query or fetch | Returned |
|---|---|
| Search: Saltmarsh Games values | saltmarshgames.com/values |
| Fetch: saltmarshgames.com/values | Page text: the three values and their meanings |
| Search: Saltmarsh Games interview process live operations producer | saltmarshgames.com/careers/interviewing |
| Fetch: saltmarshgames.com/careers/interviewing | Page text: the loop, the Outage Hour, no take-home. The page's age is not shown |
| Search: Saltmarsh Games strategy news mobile | saltmarshgames.com/news/project-larkspur (snippet only, not fetched) |
| Search: Tobias Wrenfield Saltmarsh Games | talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only, not fetched) |

Research tier: L1 - searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and B1 to B3, three principles by official name |
| 2. Saltmarsh Games interview process | yes | Loop structure: one hiring-manager session, tabletop then values; persona weights follow it |
| 3. Saltmarsh Games strategy / recent news | yes | A3, C1 and F9: the season-pass and shared-calendar announcement, read from a search snippet only |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read, D1, B2 and R1: his role, his earlier QA role and his GDC talk theme, from a snippet only |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your recruiter's note on what the Outage Hour covers, including whether the tabletop has a written part → reweights A and D, and tells you whether D1 needs its own bank
- Confirmation that Tobias is the person you would report to → settles the persona weights now built on that assumption
- Your answers to the slots in F2, F3, F4, F6 and F8 → those rows move from discovery toward `none`, and the guidance cells that draw on them become story maps
- Your CV → more evidence cells, and the thin rows F3, F4 and F8 may gain a quote
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): the full Larkspur announcement, the GDC talk, role-family loop reports and recent org context → a grounding brief and fewer inferred rows
- A `tuesday-dossier.md` from an earlier job-underwriter run → verified evidence and a named top objection, and no prohibited-claims list built locally
