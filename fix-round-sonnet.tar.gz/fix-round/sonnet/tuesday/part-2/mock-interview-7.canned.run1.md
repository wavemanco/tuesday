Femi, your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-canned-e9789902/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 22 questions across six interviewer styles, and every one maps to a line of the JD.

I built it on the assumption that Tobias is your hiring manager running Saltmarsh's "Outage Hour". Saltmarsh's careers page describes one 60-minute hiring-manager interview: a live-incident tabletop on a simulated outage first, then a values conversation. So the weight sits on tabletop-style questions, the three published values, and probing of your gaps. There's no take-home.

The question the pack names as your highest-ROI prep is the in-app-purchase gap. Saltmarsh announced Project Larkspur in September 2026, moving both titles to a season pass with one shared events calendar from February. Your "never worked on a game with in-app purchases" will come up in some form, so the pack scripts a plain concession and a learning plan. It scripts no claim of adjacent experience.

I searched four times and fetched two pages. The Larkspur announcement and Tobias's GDC talk listing (QA-lead background, "Patch Notes Are a Promise") came from search summaries only, not full pages.

- **Drill:** say the word and I'll play the Skeptic on C1.
- **Dossier:** I can also save a `tuesday-dossier.md` recording the gaps this prep exposed.
- **Word version:** I can convert the pack to a Word document if you want one.

Will Tobias be your direct manager, or a skip-level above the person you'd report to? If you also have any recruiter notes on what the Outage Hour covers, that would sharpen the tabletop questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Treated as the hiring manager running the "Outage Hour": the careers page describes one 60-minute hiring-manager interview, a live-incident tabletop first and a values conversation second. That is the assumption every weight below rests on.
**When:** Friday, 60 minutes.

## How to use this pack

Personas describe how a question arrives (who is asking, in what register). Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your own background claims survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's current altitude |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Anything about your past in the guidance is a sentence you wrote, quoted; where a question reaches past what you wrote, the guidance is an answer slot for you to fill truthfully in your own words, or to say plainly that it was not so.

## Prep triage

Sized to the two days before Friday. Everything not listed here is insurance.

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse the day-one answer on in-app purchases out loud, three times, until the concession is boring | C1 |
| 2 | Run the outage tabletop out loud, once slowly and once in two minutes | A1, A2, E3 |
| 3 | Find a real instance for each of the three values, or decide you have none and rehearse the honest branch | B1, B2, B3 |
| 4 | Fill in each answer slot from memory, including the branch where the answer is no | F1 to F5, F8 in the fit snapshot |
| 5 | Pick three reverse questions and say them aloud | Reverse questions |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not a live-events calendar and not two titles, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events line makes a probe on whether any drops were events likely. If any ran as events, say which and what made them events, in your own words; if none did, say so plainly and stay with the weekly calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show work with any of these four teams. Answer slot: the JD's four-team line makes a probe likely. If you worked with any of them on a drop, say which and how, in your own words; if you did not, or it ran through someone else, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you ran a post-event review or owned the KPIs. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you ever wrote up what happened after a release or event, say what it covered and who read it; if there was no such review, or it was not yours, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it, not that you ran it at each release. The words stay there: "I wrote the release checklist our QA team still uses." Answer slot: if you ran it at releases, say how; if you did not, or others ran it, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material shows four years as an associate producer and two years on the weekly calendar; it does not show what the other two years held. This is a length-of-experience line, so a risk to rehearse and not a gate. Answer slot: if the earlier years involved the same kind of work, say what you produced then; if they did not, say so plainly and stay with the four years and the two on the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: weekly, content-drop, main title, last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but no figure is given, so expect "how were they counted". Lead with the quote's own terms: monthly, retention, to the studio head. D1 rehearses the probe |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | discovery | The checklist touches writing without showing whether anything else was yours. Answer slot: if other written material was yours, say what it was and who read it; if the checklist is the whole of it, say so plainly and stay with the checklist |
| F9 | Familiarity with in-app purchases and a season-pass calendar. Not a JD line; derived from the published Project Larkspur summary (season-pass model for both titles from February 2027) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Reading the interviewer

Public professional footprint only.

| # | Public fact | Source | Provenance | What it means for prep |
|---|---|---|---|---|
| I1 | Head of Live Operations at Saltmarsh Games | GDC 2026 talk listing | [grounded] | Runs the function you would join, so expect questions at the level of how a calendar is run, not only what you did |
| I2 | Previously a QA lead at a console studio | GDC 2026 talk listing | [grounded] | Release-process and verification vocabulary is native to them. Mirror opportunity: F4, in its own words, "Wrote the release checklist our QA team still uses." |
| I3 | Gave the 2026 talk "Patch Notes Are a Promise", arguing a live team is judged by how often its patch notes describe what actually shipped | GDC 2026 talk listing | [grounded] | Expect probes on whether announcements match builds (D2, B2, A2). Precise limits will land better than claims, so the concession wording in this pack is an asset |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | A simulated outage during a live event, run as a tabletop | Highest. The careers page names a live-incident tabletop as the first half of the Outage Hour; the hiring-manager prior also puts Case first | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Values/Behavioral (B) | A conversation mapped to Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener | Highest. The careers page names a values conversation as the second half of the same hour, so a values-style round is detected | One story per value where your own sentences carry one; a selection scaffold ending in the honest branch where they do not |
| Skeptic (C) | Quiet probing of in-app purchases, one title versus two, content drops versus events, no team led | High. Hiring-manager prior; your stated gaps and the published season-pass shift feed it directly | Rehearse the C1 objection until it is boring; concede the limit in specific words; never bridge past your own sentences |
| Data-Driven Prober (D) | Line-by-line questions on the retention numbers and on announcement-versus-build checks | Medium. The interviewer's QA background and published talk theme point to verification probes | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Pressure (E) | Time-boxed decisions inside the tabletop; the "why you" challenge | Medium. A tabletop on an outage has a tempo; no source says the interviewer interrupts | Pause, restate, anchor in what you wrote, hold through two follow-ups before conceding anything real |
| Conversational (F) | Opening biography question; casual questions about what you play | Low. A single 60-minute structured hour leaves little room for it, but the opener is still scored | A 90-second arc built only from your own sentences |
| Peer Evaluator | Not included | The loop source names one interviewer, the hiring manager | Not applicable |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a live event. Players can't claim rewards and the community team is already seeing posts. You get the first alert. Walk me through your first thirty minutes." | CASE | [grounded] Players Before Plans, values page | Clarify first: who is affected, whether the event can be paused, what players can see. State the objective, who tells players and what they are told, the decision points, and what you will record for the review. Tie the player message to the published value: when calendar and players disagree, the players win. The question needs no claim about your past, so the guidance makes none | The careers page names this format as the first half of the hour, so it is the most likely opener; CASE because it scores structure under a live problem |
| A2 | "The outage is fixed, but many players missed most of the event and its last day is tomorrow. What do you do with the calendar, and what do you tell players?" | CASE | [grounded] Ship the Patch Not the Promise, values page | Ask what the event promised. Lay out the options (extend, compensate, leave as is) with what each does to the next item on the calendar. The player message says what happened and what is now built, and nothing hoped for. No claim about your past | The second value is announce what is built; this tests it inside the tabletop. CASE because it is a live decision |
| A3 | "For this outage, what goes in the post-event review, and which KPIs do you report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: timeline, cause, player impact, what changes in the checklist, KPIs with their definitions. You can say, in the quote's own words, that you presented monthly retention numbers to the studio head. Answer slot: the JD's post-event review line makes a probe on whether you have run one likely. If you did, say what it covered and who read it; if there was no such review, or it was not yours, say so plainly and stay with the monthly presentation | F3 is the evidence for this requirement and is thin; JD because it scores the stated responsibility, CASE in delivery |
| A4 | "Both titles want the same weekend for an event. How do you decide?" | CASE | [grounded] Project Larkspur summary: one shared events calendar from February 2027 | Clarify each title's objective for the weekend, who is affected, what engineering can support. Name a decision rule and who signs off. The shared calendar means this becomes a standing decision, so say how you would keep the rule visible. No claim about your past | The JD's two-title line and the published shared calendar make this a recurring decision; CASE because it asks for no past |
| A5 | "In September we announced Project Larkspur: a season-pass model and one shared events calendar for both titles from February, with one live-ops group instead of per-title event teams. What does that change about how the calendar gets planned?" | CO | [grounded] Project Larkspur summary; "Never led a team, and never worked on a game with in-app purchases." | Say only what the announcement summary says, then ask what the first planning cycle looks like and where this role sits. If probed on the season pass, the plain words are: "I haven't worked on a game with in-app purchases." Then the plan to learn it. Do not speculate about internal plans | The strategy sweep returned this as the current direction; CO because it scores homework at the company's altitude |

### B. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] Players Before Plans, values page; "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick an instance with a named plan, a signal from players, a decision and whose it was, and what became of the plan. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the weekly calendar you ran, or how you would handle it | Maps to the first published value; VAL because it scores behavior against that value |
| B2 | "Tell me about a time you told people something would not ship, or would ship smaller than planned." | VAL | [grounded] Ship the Patch Not the Promise, values page | Selection scaffold: pick an instance with what was expected, what you learned, who you told and how, what they did next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Maps to the second value and to the interviewer's published talk theme (I3); VAL because it scores that value |
| B3 | "Tell me about a time you left a process better for the next release." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: the checklist you wrote, and that QA still uses it, which are the beats the quote states; tell them in your own words. Answer slot: the third value says every release leaves the checklist better, so expect a probe on whether it changed. If you revised it after a release, say what prompted it; if it was not revised, or revising it was not yours, say so plainly and stay with the checklist you wrote | F4 is the one row that carries a story for this value; VAL because it scores the third published value |
| B4 | "Which of our three values would be hardest for you to live by, and why?" | VAL | [grounded] values page, all three values | Selection scaffold: choose the one you honestly find hardest, give the reason from your own working habits, and say what you would do about it. If no honest answer comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An interviewer in a values conversation can ask this to test candor; VAL because it scores self-assessment against published values |
| B5 | "Tell me about a time you brought leadership a number they did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | The quote gives you the monthly presentation and the studio head as the audience; those are the beats. Answer slot: whether any month's number was unwelcome is not in your material. If one was, say what it was and what happened; if none was, say so plainly and describe how you presented them | The persona stem on delivering an unpopular truth, with F7 as the only quoted sentence near it; VAL because it scores candor |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see in-app purchases anywhere in your background, and our next year runs on a season pass. What do you do with that on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Presented the monthly retention numbers to the studio head." | The highest-ROI prep in this pack, inferred by this pack from F9 and the published season-pass shift. Concede plainly first: "I haven't worked on a game with in-app purchases." Then what you carry, at its own scope: the weekly calendar for the main title and the monthly retention numbers, and let the interviewer draw the inference. Then the plan, said as a plan: "I'd want to learn how the season pass shapes the calendar before I trusted my own instincts on it." Follow-up one, "how do you know your calendar skills carry over?": "I don't know yet; here is what I'd check first." Follow-up two, "what would you do in your first thirty days?": the plan only, with no past claims. Never claim adjacent monetization experience | The published shift and your own stated gap meet here, so this will be asked in some form; JD because it scores a gap against the role's current direction |
| C2 | "Your calendar was for your studio's main title. This job is two titles, and from February one shared calendar. Why would that scale?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Concede that it is one title. Answer slot: the JD's two-title line makes a probe on whether you ever planned across more than one title likely. If you did, say how; if you never did, say so plainly and stay with the main title's calendar. Hold through two follow-ups by returning to the calendar, never by adding to it | F1 and F6 together; JD because it scores the calendar requirement at its widest |
| C3 | "A weekly content drop and a live event are different jobs. Which parts of what you ran carry over?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Describe the calendar in the quote's terms. Answer slot: if any drops ran as events, say which and what made them events; if none did, say so plainly and stay with the weekly calendar. Do not tell the interviewer which parts carry over; describe what you ran | F1 is where the live-events wording presses hardest; JD because it scores the stated requirement |
| C4 | "You haven't led a team, and this role coordinates design, art, engineering and community on every update. Tell me about a time you got work from people who didn't report to you." | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "Wrote the release checklist our QA team still uses." | Plain acknowledgment first: "I haven't led a team." Selection scaffold: pick an instance with a named person or team, what you asked of them, what they did, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the release checklist QA still uses, or how you would handle it | F2 is the evidence gap; JD because it scores the coordination line, VAL-adjacent in delivery |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which retention numbers did you present each month, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say which numbers and to whom, in the quote's terms. Then the four figure slots, each in your own words: how they were counted, what they are sensitive to, the assumption you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch. Name no method that you cannot repeat under a second question | F7 has no figure, so the probe goes to counting; EXP because it tests what was actually yours |
| D2 | "Before an event announcement goes out, what do you check so it matches what actually shipped?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Structure: take each claim in the announcement, confirm each against the build, decide what happens to claims not yet confirmed (cut or reword), and say who confirms. The quote gives you the checklist you wrote. Answer slot: if your checklist covered announced items, say how; if it did not, say so plainly and say what you would add | The interviewer's talk theme (I3) and F4 meet here; JD because it scores the checklist and written-clarity lines |
| D3 | "Seven days after an event, retention is down 20% against the prior event. Diagnose it." | CASE | [generic] | Clarify which cohort, how it is measured, and whether the baseline is comparable. Segment (new versus returning, platform, region), list hypotheses (event content, reward friction, a technical fault, calendar fatigue), say what you would check first, and name the assumption in your diagnosis you would defend least. No claim about your past | The Prober stem on a metric drop; CASE because it asks for reasoning; labeled generic because it is a pattern for the problem, not a fact about this employer |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: the posting asks for three-plus years producing live-service games, and you have four as an associate producer. Why you for a two-title live-ops role?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | Hold what the quotes carry: four years as an associate producer at a puzzle-game studio, and two years running the weekly content-drop calendar for the main title. Concede in specific words what they do not show. Answer slot: if more than the last two years were spent on the kind of work the posting describes, say which and what you produced; if not, say so plainly and stay with the four years and the two on the calendar. Hold through two follow-ups | F5 is the length-of-experience risk; JD because it scores the requirement, Pressure in delivery |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The quote says you ran it; hold that. Answer slot: name which parts were yours, in your own words; if some parts were set by others, say so plainly and stay with what you ran. Do not enlarge the quote under the second follow-up | The Pressure stem on attribution; EXP because it tests what was actually yours |
| E3 | "Stop. Rolling back loses two hours of player progress; leaving it broken keeps the event live. Decide now." | CASE | [generic] | Ask one clarifying question (how many players, what is lost), then decide and give the reason, tied to the value that players win over plans. Say who you inform next. Hold through a challenge; concede uncertainty specifically, for example what you would watch for in the next ten minutes. No claim about your past | Tabletop tempo; CASE because it is a live decision, labeled generic because it is a pattern for the problem |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc using only these beats: four years as an associate producer at a puzzle-game studio; the last two years running the weekly content-drop calendar for the main title; the release checklist QA still uses; the monthly retention numbers to the studio head. Why this move is your reason, in your own words; the pack supplies none | The opener is scored even when it feels casual; EXP because it tests the background |
| F2 | "What are you playing right now that runs a live calendar, and what would you change about how it runs it?" | JD | [generic] | Selection scaffold: pick a title you actually follow, say one thing you notice about its calendar and one thing you would change, with the reason. If no such title comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Conversational stem on current play; JD because it scores domain interest |

## Values / principles cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No row carries one. Selection scaffold, B1: a named plan, a signal from players, a decision and whose it was; if none comes to mind, say so plainly |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No row carries one. Selection scaffold, B2: what was expected, who you told and how; if none comes to mind, say so plainly |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." — your message. Story and answer slot in B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live ops from QA lead work. What did that change about how you run releases here?" | Ties to the interviewer's own path (I2) and turns the hour into a peer conversation about process |
| R2 | "Your talk argues a live team is judged by whether patch notes describe what shipped. How does the team check that today?" | Shows you read their work (I3) and connects to the second published value |
| R3 | "Project Larkspur retires per-title event teams for one live-ops group. What does the first planning cycle under it look like, and where would this role sit?" | Diligence on the current strategy; also answers something you need to know before accepting |
| R4 | "Who owns the link between events and the season pass?" | Addresses the F9 gap from the side of a person who will work with it, without claiming experience |
| R5 | "Which post-event KPI does the group look at first, and which has misled you before?" | Signals you treat KPIs as something to question, which is the honest side of F7 |
| R6 | "What do people who do well in this role do in their first month that others don't?" | Asks for the success bar and gives you something to act on |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar, or events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar for the main title. C3's slot stays inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: "I presented the monthly retention numbers to the studio head." A3's slot asks only whether you wrote anything up afterwards, and allows that you did not |
| Managed the release checklist with QA at each release | Inflated form of F4 | F4's quote at its own scope: you wrote it and QA still uses it. B3's and D2's slots stay inside that |
| Led a team | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." No slot |
| Has in-app purchase or monetization experience | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the job description you pasted; the background in your message (no CV).

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and bank B: the three value names and meanings come from the official page, fetched |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: the careers page, fetched, establishes one 60-minute hiring-manager session, a tabletop then a values conversation; persona weights and banks A and B follow it |
| 3. `Saltmarsh Games strategy news mobile` | yes | A4, A5, C1, C2 and R3 to R4: the Project Larkspur announcement summary (September 2026). Only the search summary was read; the page was not fetched |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read I1 to I3, D2, R1, R2. Only the talk listing was read |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries and what came back:

| Query | Returned |
|---|---|
| Saltmarsh Games values | https://saltmarshgames.com/values |
| Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Saltmarsh Games strategy news mobile | https://saltmarshgames.com/news/project-larkspur |
| Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise |

Fetches: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing.

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A2, A4, C2, C3 |
| "coordinate design, art, engineering and community teams on each update" | A1, C4 |
| "own the post-event review and the KPIs it reports" | A3, D3 |
| "manage the release checklist with QA" | B3, D2 |
| "3+ years producing live-service games or apps" | E1 |
| "experience running a content calendar" | C2, E2 |
| "comfortable with player-retention metrics" | D1, D3 |
| "clear written communication" | A2, D2 |

## Upgrade menu

- Confirmation of Tobias's relationship to the role (direct manager or skip-level) → reweights every bank
- The recruiter's note on the Outage Hour (which titles, what is simulated) → replaces the generic tabletop in A1 to A2 and E3 with the real shape
- Your answers to the answer slots in F1 to F5 and F8 → rows move from slot to story map, and the matching bank cells become grounded
- Whether your main title was a mobile game and a live-service game → settles how F1 and F5 are worded
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): the full Project Larkspur announcement, Tobias's talk and writing, role-family loop reports, recent org context → a grounding brief and sharper CO and CASE questions
- A `tuesday-dossier.md` from an earlier underwriting pass, if you have one → verified evidence grading and a named highest-ROI objection in place of the one inferred here
