The web searches were denied, so I'm building from what you've told me. I'm checking the working folder for a saved dossier before I write the pack.
Your prep pack for all three rounds is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-6-denied-6e45be2f/larkfield-systems_engineering-manager_interview_pack.md`.

**What's in it.** It has a shared fit snapshot and a mini-pack per round. Each mini-pack has persona weights, a question bank (10, 11 and 9 questions) and reverse questions. The pack names one top-priority rehearsal: B1, "which part would you be weakest at on day one?" It targets your two stated gaps, managing managers and a hardware-adjacent roadmap. Expect it in some form in all three rounds, and J1 on Monday is its executive version.

**What's missing.** Web search was not permitted, so the pack has no Larkfield-specific research. That means no published values and no company strategy, so the Monday values cheat sheet is left out and the company-strategy questions (I1, I3) are generic. The pack also has no interviewer reads, since you gave no names. I assumed the staff engineers are technical peers and the product manager is cross-functional.

Say the word and I'll play the Skeptic on B1, the day-one-weakness question, as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job description and the bullet lines from your CV? That would upgrade the growth, domain and product-partnership rows.
Do you have the interviewers' names or anything the recruiter said about each round's focus? Even a first name and a title changes the weights.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (loop mode, three rounds)

## 1. Title block

- Candidate: Yusuf
- Role: Engineering Manager, Larkfield Systems (industrial IoT, about 600 people). Two squads building device-management services; delivery, hiring and growth for 11 engineers; partnership with hardware and product on roadmap.
- Round 1, Tuesday, 45 minutes: the hiring manager, a Director of Engineering and your would-be boss.
- Round 2, the Thursday after, 60 minutes: a panel of two staff engineers and a product manager.
- Round 3, the following Monday, 30 minutes: the VP Engineering, which the recruiter described as "values and leadership philosophy".
- Built from your message alone. No full JD, no CV, no interviewer names, no recruiter focus areas, and no web research: the searches were not permitted, so nothing here is specific to Larkfield beyond what you told me.
- Assumption behind the panel weights: the staff engineers are technical peers and the product manager is cross-functional. Tell me otherwise and the Thursday weights change.

## 2. How to use this pack, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows values and leadership, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny; what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

An answer slot is an instruction for the interview, not a question for you. It gives two honest branches: say it in your own words if it happened, or say plainly that it did not, or was not yours, and return to what you did. Every pack row draws only on your own quoted sentences; where none carries a story, the guidance is a selection scaffold. IDs: FS rows are the fit snapshot; A to C are Tuesday, D to G Thursday, H to J Monday; RT, RP, RM are the reverse questions.

## 3. Prep triage

| # | When | Do | Tied to |
|---|---|---|---|
| 1 | Before Tuesday | Rehearse the day-one-weakness answer aloud, with its three follow-ups, until it is boring. It is the pack's highest-ROI prep, and J1 is its executive version | B1, J1, FS1, FS6 |
| 2 | Before Tuesday | Write your own four answers on the 60%: how it was counted, what it is sensitive to, the assumption you would defend least, what was yours. The same four serve three questions in three rounds, so keep them identical | B3, E1, J2, FS2 |
| 3 | Before Tuesday | Think aloud through the two live problems once each | A1, A2 |
| 4 | Tuesday to Thursday | Say the seam principles for the staff engineers aloud, and write your own account of the hiring loop in the terms of your quotes | D1, D3, E2, G1 |
| 5 | Thursday to Monday | Write one sentence of your own leadership philosophy and one on what a manager owes an engineer; read what Larkfield publishes before the Monday why-us question | H1, H3, I3 |

Everything else is insurance.

## 4. Fit snapshot

The requirements are the lines of the role description you gave me. The evidence column holds your sentences only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| FS1 | "Lead two squads building device-management services" — your role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | medium | [grounded] | transferability | Your material says a team of six and says you have not managed managers; it does not show whether these squads have leads beneath the manager, so the reverse question RT1 asks. Words at the quote's scope: "I was team lead of six." Plain acknowledgment, your own stated negative: "I've never managed managers." Answer slot: expect a probe on spanning two squads. If you have ever split your attention across more than one group, say how, in your own words; if not, say so plainly and stay with the team of six |
| FS2 | "own delivery" for 11 engineers — your role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence carries a reliability quarter pushed through against roadmap pressure, and a 60% drop that came after it. It does not say how the figure was counted or how much of the drop the quarter explains, and the words stay inside it. Answer slot: the own-delivery line makes a probe on who made the call likely. If the call was yours, say how you made it; if it was not yours, or there was no call to make, say so plainly and stay with what you did |
| FS3 | "hiring" for 11 engineers — your role description | "I run our hiring loop for backend roles" — your message; "about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a claim with nothing inspected behind it, so expect a probe. Lead with the quotes in their own terms: you run the loop for backend roles, and the figure counts interviews. The material says backend roles; it does not say what roles these squads hire |
| FS4 | "growth" for 11 engineers — your role description | none given | none | [grounded] | discovery | Your material shows nothing on developing engineers, and the pack does not supply any. Answer slot: expect a probe on how you grow engineers. If you have supported anyone's growth, say what you did, in your own words; if you have not, say so plainly and say how you would start |
| FS5 | "building device-management services" in industrial IoT — your role description | none given | none | [grounded] | discovery | Your material does not show how close your work has been to this domain. Answer slot: expect a probe on your closest work. If any of it was close, say what it was in your own words; if none was, say so plainly and say what you would learn first about the domain |
| FS6 | "partner with hardware" on roadmap — your role description | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | medium | [grounded] | discovery | You stated you have not owned a hardware-adjacent roadmap, and the requirement is to partner, which the sentence does not speak to. Words: "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked alongside a hardware team in any form, say what it was in your own words; if you have not, say so plainly and give the plan for your first weeks |
| FS7 | "partner with" product on roadmap — your role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | Inferred from the quote touching roadmap pressure without saying who applied it. Answer slot: if product was a party to that pressure, say how you worked it; if the pressure came from elsewhere, or product was not involved, say so plainly and stay with the quarter |

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| FS1 lead two squads | A1, A3, I1, I2, J1 |
| FS2 own delivery | A2, B3, B4, E1, E2, F2, J2 |
| FS3 hiring | G1, H4 |
| FS4 growth | G2, H3 |
| FS5 device-management domain | C2, E3, I1, I3 |
| FS6 partner with hardware | A4, B1, B2 |
| FS7 partner with product | A4, B2, D3, F2 |

## 5. Round 1, Tuesday: hiring manager (Director of Engineering), 45 minutes

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems set on the actual roadmap: plan this, diagnose that | Top. The relationship prior for a hiring manager is Case/Strategist plus Skeptic, and the JD's two-squad and hardware-partner lines are easy to turn into live problems | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet, persistent probing of the gaps | Top, equal to Case. The same prior says a hiring manager is derisking gaps, and FS1, FS6 and FS5 are where your material is thinnest | Rehearse the most predictable objection until it is boring; calibrated candor, no bluffing |
| Conversational | A friendly opener that is still scored | Low. A 45-minute hiring-manager round usually opens with the biography, which is the only place this style is likely | A 90-second arc built only from your own sentences |

The pack's highest-ROI prep is B1, the day-one-weakness question: it will arrive in some form in all three rounds, and it is aimed where your material is thinnest.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads share a device-management platform, and hardware and product each name a different top priority for the quarter. How do you set delivery priorities in your first sixty days, and what do you need to know first?" | CASE | [generic] | Clarify before structuring: what each squad has committed to, what hardware's and product's dates depend on, what the delivery record looks like today. Then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise, for example whether the two priorities really collide. The question needs no claim about your past, so the guidance makes none | A live problem from the role description's two-squad and partner lines, FS1 and FS6 and FS7. CASE because it scores structure, not the right answer |
| A2 | "A service your squads own fails for customers' devices in the field while hardware is mid-release. How do you run the next 24 hours, and what do you change over the next quarter?" | CASE | [generic] | First day: who runs the incident, what hardware and product hear and when, what you stop doing. The quarter: how you decide whether the failure earns a reliability investment against the roadmap, and what you would measure before and after. The question needs no claim about your past, so the guidance makes none | Tests the own-delivery line, FS2, in a form that rewards structure. The hardware release is the case's own detail, not a fact about Larkfield |
| A3 | "You'd lead two squads and eleven engineers. How would you decide where your time goes in the first month?" | CASE | [generic] | State your own principle for allocating time first, then the order it implies, then what you would ask the Director before committing. Name the first thing you would not delegate and why. The question needs no claim about your past, so the guidance makes none | FS1 is the row this scores, and the answer should show scope you have not yet held without claiming it |
| A4 | "Hardware wants a feature that product says customers aren't asking for, and neither will move. What do you do?" | CASE | [generic] | Ask what each side's evidence is and what each loses if it is wrong; say what you would bring to each; say where you would hold and what would change your mind. The question needs no claim about your past, so the guidance makes none | Both partner lines, FS6 and FS7, in one live problem |
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in the pack. Choose the weakness you will name first and say it plainly in the quote's own terms: "I've never owned a hardware-adjacent roadmap." Then give the ramp as a plan, never a past: whom you would meet first, what you would read, what you would not decide alone in the first weeks. Hold through three follow-ups by returning to the plan. On "what if the Director needed that this quarter", concede the limit once and specifically and say what help you would ask for. If they press on managing managers, say "I've never managed managers" once and describe how you would work with leads as a plan. Answer slot: if you have worked alongside a hardware team in any form, say what it was in your own words; if you have not, say so plainly and stay with the plan | The objection aimed at FS1 and FS6, where the material is thinnest, so it is the deepest rehearsal: three follow-up levels and the exact concession wording. JD because it scores the stated requirements |
| B2 | "Tell me about a time you partnered with another function on a roadmap." | JD | [generic] | Pick a time with a named stake on each side, what you did about the disagreement, and what changed. Say we for context and I for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An open prompt on the partner-on-roadmap line, FS6 and FS7. No quote carries a story for it, so it is a scaffold |
| B3 | "Your on-call burden dropped 60%. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say the figure in the sentence's own terms: on-call burden, 60%, after the reliability quarter. Then four answer slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, which part was yours. If you do not know how it was counted, say so plainly. Keep the sentence's word "after"; do not turn it into "because" | The headline figure on FS2, and a magnet for a probe. EXP because it tests attribution and counting |
| B4 | "Walk me through how you got a reliability quarter through when the roadmap was pushing the other way." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on FS2: the beats are the quote's own, you pushed a reliability quarter through against roadmap pressure, and the drop came after. Tell those in your own words. Answer slot: the own-delivery line makes a probe on who made the call likely. If the call was yours, say how you made it; if it was not yours, or there was no call to make, say so plainly and stay with what you did | FS2 is your strongest delivery evidence and the likeliest place a hiring manager digs |
| C1 | "So, walk me through the journey, and what makes this move." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc on the beats the quote states: nine years in engineering, three as team lead of six, now at a payments company. Tell them in your own words. Answer slot: why this role and why now is not in your material and the pack supplies no reason. Say what is true for you in your own words | The opener is scored even when it feels casual. FS1 is the row it draws on |
| C2 | "What draws you to industrial IoT in particular?" | JD | [generic] | Nothing in your material speaks to this, and the pack supplies no reason. Say what is true for you in two sentences, tied to something you can name about the domain; if the interest is recent, say so plainly. Do not recite company facts you have not read, since no research could run for this pack | The domain is the role description's own framing, FS5, and the answer shows genuine interest |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RT1 | "How is day-to-day leadership of each squad shaped today, and where do you expect the manager role to sit relative to it?" | Settles whether managing managers is in scope, FS1, without volunteering a weakness |
| RT2 | "What would a strong first ninety days look like on the hardware partnership, and who should I meet first?" | Turns FS6 into a plan your future boss co-writes |
| RT3 | "What has been hardest about delivery across the two squads recently?" | You listen before you propose, and learn the real problem |
| RT4 | "How do you, hardware and product split roadmap trade-offs today, and where would you want me to carry more?" | Shows you are thinking about the seam from the Director's side |
| RT5 | "What would make you say, six months in, that this was the right hire?" | Gives you the scoring sheet and invites calibration |

## 6. Round 2, Thursday: panel (two staff engineers and a product manager), 60 minutes

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting, "what would you need from me", credit, disagreement | Top. For a panel the prior blends the top two personas of each member's relationship; the staff engineers, assumed peers, bring Peer Evaluator and Prober | Reciprocity framing; propose seam principles, not a pretended seam; spine and tact together |
| Data-Driven Prober | Line-by-line probing of figures and attribution | Mid. The other persona from the assumed staff-engineer relationship, and the 60% is the figure most likely to be probed | Know what you can and cannot say about how the number was counted; name the weakest assumption before they do |
| Values/Behavioral | Scenario probes, often by someone outside the function | Low. The product manager, assumed cross-functional, brings it; it is scored even in a technical panel | Stories for the themes where your quotes carry one, a selection scaffold where none does |
| Conversational | Friendly, unstructured, still scored | Low. The product manager's second persona; it concentrates in the hiring and growth questions | A short arc built from your own sentences |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam between a staff engineer and the engineering manager, and what happens when we disagree?" | JD | [generic] | Propose two or three seam principles you would hold, say them aloud, and do not pretend to know where their seam is today. Say what you would take off a staff engineer's plate. For the disagreement, pick a time you disagreed with a senior engineer and it ended well; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer persona's core question. The seam is the role's own, FS2 and FS1, and no quote carries a disagreement story, so it is a scaffold |
| D2 | "How do you handle credit when work spans a staff engineer's design and your team's delivery?" | JD | [generic] | State the principle you actually hold in one sentence. Then pick a time credit was shared or contested; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer persona's credit stem. JD because it scores partnership fit with the role's seam |
| D3 | "A staff engineer wants the squad's next quarter spent on a platform rewrite; you think it belongs on customer-facing work. Walk us through the conversation." | CASE | [generic] | Ask first what the rewrite buys and what it costs; state your hypothesis early; show spine and tact: where you would hold, and what evidence would change your mind. The question needs no claim about your past, so the guidance makes none | A live collegial disagreement on a roadmap trade-off, FS7 and FS2 |
| D4 | "Which technical decisions would you leave with your staff engineers, and which would you keep?" | JD | [generic] | State in one sentence the principle that separates them, apply it to two examples you choose, and concede one area where you would defer. The question needs no claim about your past, so the guidance makes none | Pricing what the hire costs the staff engineers, FS1 and FS2 |
| E1 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The weakest-assumption move: name it yourself, in your own words, before they do. The pack does not name it. Answer slot: if you know how the figure was counted, say which assumption is weakest; if you do not know how it was counted, say so plainly and say what you would check first | The headline figure on FS2, probed collegially. EXP because it tests counting honesty |
| E2 | "Which of the reliability work in that quarter was yours, and which was your team's?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Stay with the sentence: you pushed a reliability quarter through against roadmap pressure. Answer slot: the own-delivery line makes a probe on attribution likely. If you chose or designed any of the work, say which, in your own words; if the team did, say so plainly and return to pushing the quarter through | FS2 again, in the attribution form staff engineers use when they probe how much a manager really did |
| E3 | "Suppose a squad's services manage a large fleet of devices behind unreliable networks. How would you decide what an acceptable on-call burden is?" | CASE | [generic] | Clarify what counts as burden and who bears it, what the business trade-off is, what you would measure, and what the risks of setting it wrong are. The question needs no claim about your past, so the guidance makes none | A domain-flavored live problem on the on-call theme, FS5 and FS2; the fleet is the case's own detail |
| F1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time with a customer-side stake, an internal metric you did not serve, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The cross-functional member's likely stem. No quote carries this story, so it is a scaffold |
| F2 | "How do you decide with product when a roadmap item and a reliability investment compete?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on FS2: the beats are the quote's own, you pushed a reliability quarter through against roadmap pressure, and the drop came after. Tell those in your own words, then state your decision principle as a belief, not a record. Answer slot: the partner-with-product line makes a probe on whether product was in the room likely. If product was a party, say how you handled it; if the pressure came from elsewhere, or product was not involved, say so plainly and stay with the quarter | FS7 and FS2 meet here, and the product manager is the one person on the panel who can test it |
| G1 | "Tell us about the hiring loop you run for backend roles." | EXP | [grounded] "I run our hiring loop for backend roles" and "about 40 interviews last year" | Story-mapped on FS3: you run the loop for backend roles, and the figure is interviews; keep that noun. Answer slot: the own-hiring line makes a probe on who set the bar likely. If you set or applied the bar, say how; if it was set elsewhere, or none was written down, say so plainly and stay with the loop you run | FS3 is your clearest role-relevant evidence, so spend the story well |
| G2 | "How would you approach growing the engineers on the two squads?" | JD | [generic] | Your material shows no growth work (FS4), so this is a scaffold: pick a time you helped an engineer grow, with what you did and what changed, without naming them. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The growth line, FS4, is the requirement with no evidence at all, so the honest branch is rehearsed |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RP1 | "What could a new manager do in their first month that would genuinely help your work?" | The reciprocity question for the staff engineers; it frames you as reducing their load |
| RP2 | "Which decisions do you want a manager to stay out of, and which do you wish they'd take?" | Hears the seam from them before you commit to one |
| RP3 | "How do hardware constraints reach product planning today, and where is it hardest?" | For the product manager; it shows you are thinking about FS6 and FS7 as a system |
| RP4 | "What's an example of the squads and hardware working well together, and what made it work?" | A positive, concrete frame that reveals the practices they value |
| RP5 | "What does a reliability investment have to show for product to back it?" | Speaks to the product manager's currency without claiming anything about your own past |

## 7. Round 3, Monday: VP Engineering, 30 minutes

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes on values and leadership | Top. The recruiter described the round as "values and leadership philosophy", which documents a values-style round for Monday | Stories where a quote carries one, a scaffold where none does; we for context, I for contribution |
| Case/Strategist | Altitude questions about the shape of the org and the work | Mid. The skip-level and executive prior is Case/Strategist plus Pressure | Think aloud, hypothesis early, challenge one premise |
| Pressure | Time-boxed challenge to the step-up | Low. The other executive-prior persona, with only 30 minutes to spend | Pause, restate, hold the position through two follow-ups, concede specifically |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What is your philosophy of leading engineers?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your philosophy is yours to state, in your own words, as a belief rather than a record. Back it with only what the quotes carry: a team of six, and a reliability quarter pushed through against roadmap pressure. Answer slot: if a belief you hold shaped how you led the team of six or that quarter, say how in your own words; if it did not, say so plainly and stay with the belief | The recruiter's own words for the round. The rows it draws on are FS1 and FS2 |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you did not soften it, and a relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The values persona's standard stem. The reliability quote does not say who applied the pressure, so it is not offered as this story |
| H3 | "What does a manager owe the engineers who work for them, and what do they owe the manager?" | VAL | [generic] | These are your beliefs, so write two sentences of your own; the pack does not supply them. Your material carries no growth story (FS4), so do not reach for one; use a plain account of how you would act | The leadership-philosophy theme the recruiter named, aimed at FS4 and FS1 |
| H4 | "How would you approach hiring for a team you'd own, and what do you hold constant and what do you flex?" | JD | [grounded] "I run our hiring loop for backend roles" and "about 40 interviews last year" | Story-mapped on FS3: you run the loop for backend roles, and about 40 interviews last year; what you hold constant is your belief to state. Answer slot: the own-hiring line makes a probe on who set the bar likely. If you set or applied the bar for any of those roles, say how; if it was set elsewhere, or none was written down, say so plainly and stay with the loop you run | The hiring line, FS3, at the VP's altitude; philosophy first, evidence second |
| I1 | "What would you need to learn before you had a view on whether two squads is the right shape for device-management services?" | CASE | [generic] | Think aloud: purpose of each squad, how the work divides, where the hardware interface sits, what a good split would be measured by. State a hypothesis early and name the evidence that would overturn it. The question needs no claim about your past, so the guidance makes none | Strategy-altitude probing of the role description's own structure, FS1 and FS5. Generic because no research could run |
| I2 | "You inherit eleven engineers across two squads and can change one thing in ninety days. What do you pick, and what do you leave alone?" | CASE | [generic] | Clarify what is unknown, then choose one change and justify it, and name one thing you would leave alone and why. The question needs no claim about your past, so the guidance makes none | Tests judgment on the role's own scale, FS1 |
| I3 | "Why Larkfield, and why industrial IoT?" | CO | [generic] | No company research could run for this pack, so nothing here is specific to Larkfield. Read what they publish before Monday, then name one specific thing in your own words. Do not recite a strategy claim you have not read | The one question that rewards your own homework. Generic is the honest cost of the missing research |
| J1 | "You haven't managed managers before. Why should we trust you with two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" and "I've never managed managers and never owned a hardware-adjacent roadmap" | Practice it as sixty seconds. Hold on what the quote carries: "I was team lead of six." Concede once, specifically: "I've never managed managers." Hold through two follow-ups by returning to the team of six, never by adding to it. If they press on the scale, answer with the plan for your first month, as a plan | The executive version of B1, built on your own stated negative, so the premise is sourced. The row is FS1 |
| J2 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold on the sentence: "I pushed a reliability quarter through against roadmap pressure." Concede specifically: the sentence says the drop came after the quarter, not how much of it the quarter explains. Answer slot: if you can say which part was yours, say it in your own words; if the work was the team's, say so plainly and return to the quarter | FS2 again in its pressure form; the hold is only what the quote carries |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RM1 | "What separates the managers who thrive here from those who struggle?" | Gives you the VP's own standard, which is the thing a values round scores against |
| RM2 | "Where do you want engineering to be with hardware and product a year from now?" | Altitude; it stands in for the strategy knowledge the pack could not research |
| RM3 | "Which of the values you'd hold me to is hardest to uphold when a roadmap is under pressure?" | Ties values to reality instead of reciting them |
| RM4 | "How do you develop your managers, and what would you want from my first six months with you?" | Signals that you expect to be developed and to report up |
| RM5 | "What would you want to be true about the squads in a year that isn't true today?" | Surfaces what actually worries the VP |

## 8. Prohibited claims

Built from the fit snapshot before the banks were written. No answer slot, hold, bridge or rationale in this pack asserts, softens or implies any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads or eleven engineers | Inflated form of FS1 | FS1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a team of six |
| Managed managers | Negative you stated, FS1 | The plain acknowledgment: "I've never managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, FS6 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot |
| The reliability quarter caused the 60% drop | Inflated form of FS2 | FS2's quote at its own scope. The limit is the pack's observation: the material says the drop came after the quarter. The slots in B3, E1 and J2 stay with how it was counted and which part was yours |
| Hired about 40 people | Inflated form of FS3 | FS3's quotes at their own scope. The limit is the pack's observation: the material says interviews. The slots in G1 and H4 stay with the bar and the loop you run |

## 9. Sources

Provided documents: your message (the role description, the three round descriptions, and your own background statements). No CV, no full JD, no dossier.

Queries sent, all refused because web search permission was not granted:

- "Larkfield Systems industrial IoT values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT device management strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Would have produced the Monday values cheat sheet, which is dropped because no published values are in hand |
| 2. Larkfield Systems interview process, role family | unavailable | Would have checked the loop; the three rounds here rest on your own description, which names who runs each and what it holds |
| 3. Larkfield Systems strategy / recent news | unavailable | Would have grounded I1 and I3 and any company question; they are generic instead |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Engineering Manager JD | skipped | Your role description fixes the fit snapshot and the JD-tagged questions |

## 10. Upgrade menu

- Approve web search: Larkfield's published values become a Monday values cheat sheet, its strategy turns I1 and I3 from generic into grounded, and its documented loop can confirm the rounds. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and the interviewers' public footprint; it is offered once and runs only on your yes
- The full job description: the requirement quotes in FS1 to FS7 become the posting's own words, JD-tagged questions get rechecked, and any gate such as location or travel to hardware sites would surface
- Your CV, or the bullet lines for your current role: FS4, FS5 and FS7 could upgrade from none or low, and the stories behind FS1 and FS2 could be mapped to your own sentences
- Your own answers to the slots, as plain text (for example, how the 60% was counted, or what you did with a hardware team): each becomes new quoted evidence and the rows that draw on it regenerate
- The interviewers' names, even just first names and titles: an interviewer read, persona weights read from their public footprint, and a reverse question tied to each one's path
- The recruiter's guidance for each round (focus areas, any exercise): coverage per round instead of the persona priors this pack used, and a build section for any announced deliverable
- A tuesday-dossier.md, if you have one: verified evidence and a prohibited-claims list to hold the banks against
