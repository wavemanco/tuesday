Searches were refused, so I'm building the pack from your JD and background alone. Saving it now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-2-denied-e8cb1233/atlas-freight_operations-manager_interview_pack.md`.

I built it for a hiring-manager round, since you don't know who's interviewing you. Web search was refused in this session, so the pack has no Atlas values, loop details or strategy. It also has no company-knowledge questions, and the values questions use standard stems. The pack's Sources section lists these gaps.

The highest-ROI prep is question B2: "twelve supervisors across four sites, your team is three, convince me." It's the objection you're most likely to face.

The pack stays at the scope of what you told me. It never claims Power BI, multi-site, terminal, or cost-per-shipment results. Where a probe is likely, the guidance is a slot for you to answer in your own words, with an honest "no" branch.

I can play the Skeptic on B2 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you'd like.

1. Do you know who you're meeting: your future manager, a peer, or an HR or recruiter screen? The answer reweights every question bank.
2. Want to paste your CV? I'll proceed without it, but more of your own sentences would turn several thin rows into solid ones.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Relationship assumed: hiring manager (your note did not say). Persona weights below rest on that assumption, not on anything documented about Atlas's process.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values: whether past behavior shows what the employer cares about |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack, see Sources) |
| CASE | Live problem from the role: structure and reasoning |

Answer slots in the guidance are instructions for the interview, not questions for you now. Where a slot gives two branches, either honest branch is a good answer.

## Prep triage

You said the interview is next week. In this order, then stop:

1. B2, the highest-ROI prep in the pack: the three-to-twelve supervisor step. Rehearse it aloud until it is boring.
2. B1 and D3: the plain Power BI answer, said without flinching, plus a plan.
3. C1 and C2: the 40% mis-pick number, how it was counted and which part was yours.
4. A1, A2 and A3: say each case aloud once with the clarify, structure, answer shape.
5. E1: the 90-second biography.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says shift management in warehouse and distribution, not terminal operations and not several sites, with nothing inspected behind it. The words stay there: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's four-site line makes a probe on scope likely. If any of your work covered more than one site, or a freight terminal, say which and how, in your own words; if it did not, say so plainly and stay with the shifts you manage |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | A surge plan is not a result on on-time performance, and the bridge stays at the plan. Answer slot: if on-time performance was tracked during peak, say what you watched and what it did; if it was not tracked, or not yours, say so plainly and stay with the plan you ran |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | A mis-pick rate is not a cost-per-shipment figure. Answer slot: if any cost figure moved with the mis-pick rate, say what was measured and by whom; if none was, say so plainly and stay with the mis-pick rate |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows three supervisors; the JD asks for twelve, so the pack's observation is that the span is a step up. The words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led more supervisors than three, in an earlier role or across shifts, say how many and when; if not, say so plainly and stay with the three |
| F5 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | Solid Excel does not show reporting built. Answer slot: if you built reports in Excel, say what they showed and who used them; if you used Excel for analysis only, or not for reporting, say so plainly and stay with Excel as you use it |
| F6 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. No claim to similar tools, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | low | [inferred] | discovery | Your message gives seven years in operations, not how many of them were spent leading people. Answer slot: say how many years you led supervisors or shifts, and in which roles, in your own words; if it is fewer than five, say so plainly and stay with the seven years you have stated |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a statement with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: you are green belt certified. The certificate would raise the band |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the real job: diagnose on-time slippage, cost creep, a multi-site rollout | High. Hiring-manager prior (assumed), and a role that owns on-time and cost targets | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Skeptic | Quiet probing of the gaps: three supervisors versus twelve, warehouse versus terminal, Power BI | High. Hiring-manager prior, and F4, F6 and F7 are the biggest gaps | Rehearse the single most predictable objection (B2) until it is boring; concede the limit plainly |
| Data-Driven Prober | Reads the CV line by line; wants the 40% counted | Medium. One headline metric invites it | Know what you can and cannot say about how the number was counted; name the assumption you would defend least |
| Pressure | Time-boxes, interrupts, tests composure | Medium. Plausible in a role leading twelve supervisors | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational | Friendly opener, casual questions that are still scored | Low to medium. Often the first ten minutes of any round | A 90-second arc; treat casual JD questions as scored |
| Values/Behavioral | Scenario probes on conflict, customers, unpopular truths | Low. No values-style round is documented | Selection scaffold ending in the honest branch |
| Peer Evaluator | Seam-splitting with the other terminal managers | Low. Four sites imply peers, but the round is assumed to be a manager's | Reciprocity framing; seam principles, not a pretended seam |

Depth follows weight: five questions each for the top two, three for the next two, two for each of the rest.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "One of your four terminals has missed its on-time target for a month. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify first: which lanes and shifts, since when, what changed in volume, staffing or equipment. State the objective, then segment (inbound and outbound, by shift, by customer). Test the likeliest cause first and say why. Name the daily measure you would watch and one risk of your fix. Challenge one premise, such as whether the target itself is right. The question needs no claim about your past, so the guidance makes none | The JD's on-time line, the requirement of F2, asked as a live problem. CASE because it scores structure; generic because it is a pattern for the problem, not a fact about this employer |
| A2 | "Cost per shipment has crept up two quarters running across the four terminals. Where do you look first, and what do you need from finance?" | CASE | [generic] | Ask how the company defines cost per shipment before you assume it. Then split it: labor, handling, linehaul, claims, overtime. Check mix and volume before efficiency. Name the fastest lever and what it could cost on-time performance. The question needs no claim about your past, so the guidance makes none | The JD's cost-per-shipment line, the requirement of F3. CASE because the answer is a method, not a story |
| A3 | "You take over twelve supervisors across four sites, and each site reports its numbers differently. What do you do in your first thirty days?" | CASE | [generic] | Learn each site before you change it. Meet each supervisor one to one. Agree a small common scorecard with them rather than imposing it. Start it in the tool everyone already has before any new reporting tool. Say it as a plan, in the future tense. The question needs no claim about your past, so the guidance makes none | Covers the twelve-supervisor line and the reporting line, the requirements of F4, F5 and F6, as a decision rather than a history |
| A4 | "Tell me about a time you had to run daily operations across more than one area at once." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | You choose the instance. If it is the surge plan, tell the beats the quote states: the plan, peak season, two years running, in your own words. Answer slot: the JD's four-site line makes a probe on how many areas or shifts the plan covered likely. If it covered more than one, say which and how you coordinated them; if it covered one, or the coordination was not yours, say so plainly and stay with the plan you ran | F1 is the evidence nearest to the four-site mandate, and the likeliest place to be probed. EXP because it tests what was actually yours |
| A5 | "Walk me through the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Story-mapped on F2: the plan, the peak season, the two years, as the quote states them. Answer slot: the JD's on-time line makes a probe on what happened to on-time performance under the surge likely. If you tracked it, say what you watched and what it did; if it was not tracked, or not yours, say so plainly and stay with the plan you ran | F2 is the only evidence near the on-time requirement and is thin, so this question is rehearsed in order to say the honest version first. EXP because it tests the claim |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Pick one honestly. If it is Power BI, the plain answer is "I've never used Power BI." Then say, as a plan, what you would do in your first weeks to learn it. Do not claim a similar tool. Hold the Excel claim at its own scope: it says solid Excel, no more | F6 is a gap you stated, so this question will land there or on F4. JD because it scores the stated tooling requirement |
| B2 | "This role leads twelve supervisors across four sites. Your team today is three. Convince me you can make that step." | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | The highest-ROI rehearsal in this pack, and the hold is only what the quotes carry: "I'm currently a senior shift manager over 3 supervisors, and I cut the mis-pick rate 40% by redesigning the pick path." Concede specifically: "The step from three to twelve is a big one." Answer slot: if you have led more than three supervisors at any time, say how many and when; if not, say so plainly and describe how you lead the three you have. Hold through two follow-ups by returning to what the quotes say, never by adding to it. Then give a plan for your first weeks, said as a plan | F4 and F1 are where the role's scale presses hardest, so this objection will arrive in some form. JD because it scores the stated team size |
| B3 | "The role requires five years of operations leadership. How many of your seven years were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say the number you can defend, and the roles it covers. Answer slot: if some of the seven years were as a supervisor or shift lead, say which years and how many people; if the leadership years are fewer than five, or the earlier roles were not leading people, say so plainly and stay with the seven years in operations | F7 is the requirement the posting marks as required, and the question is likely to be asked literally. JD because it scores the stated years |
| B4 | "Your background is warehouse and distribution. This is terminal operations. What's different, and what would you need to learn?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer from what you actually know of terminals. Answer slot: if you have worked in a freight terminal or cross-dock, say where and what you did there; if you have not, say so plainly, then say how you would learn it in your first thirty days, as a plan. The pack's observation is that your material shows warehouse and distribution, not terminal work | F1's gap, rehearsed so the honest answer is ready before the probe. JD because it scores the stated terminal mandate |
| B5 | "Why leave a senior shift manager role for this scope, and why Atlas, and why now?" | JD | [generic] | Selection scaffold: your own reasons, each one true and specific, and a reason for Atlas that you can source from what you read about them. Atlas's own materials were not available to this pack, so read their site and careers page before the round. If no specific reason for Atlas comes to mind, say so plainly, then say what you want from the role. The question needs no claim about your past, so the guidance makes none | The standard motivation probe the Skeptic uses on a step up. JD because it scores fit with the role |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on F3: the 40%, the mis-pick rate, the redesign of the pick path, as the quote states them. Answer slot: expect probes on how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; if you do not know how it was counted, say so plainly and return to what the quote states. Name the weakest assumption before they do if you know it | F3 holds the pack's only headline metric, so it is the magnet for a Prober. EXP because it tests whether the number survives |
| C2 | "You redesigned the pick path. What did you design, and what did your team do?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Tell what you designed, in your own words, and credit others at their real share. Answer slot: if part of the redesign was done by others, say which part; if the whole design was yours, say so plainly. Hold through two follow-ups by returning to what you did, never by adding to it | Attribution probe on F3: how much was actually you. EXP because it tests ownership |
| C3 | "Tell me about a time you used Excel to run part of operations." | JD | [grounded] "solid Excel" | You choose the instance. Say what you used Excel for, and say how solid means solid: the quote says solid Excel, no more. Answer slot: the JD asks for reporting, so expect a probe on reports you built. If you built any, say what they showed and who used them; if you used Excel for analysis only, or not for reporting, say so plainly and stay with Excel as you use it | F5, the Excel half of the reporting line. JD because it scores the stated tooling requirement |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has already run multiple terminals?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, restate, then hold only what the quotes carry: the mis-pick cut by redesigning the pick path, the surge plan run two years running, the green belt. Concede one thing explicitly: you have not stated multi-terminal experience. Do not fold, and do not claim it. Hold through two follow-ups | F1 and F4 are the gap, so the Pressure persona asks the Skeptic's question faster. JD because it scores fit against the role |
| D2 | "You say you ran the surge plan. How much of it was actually you?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The quote says ran, and the guidance stays there. Answer slot: if you made the key decisions in the plan, say which; if others set parts of it, say so plainly and stay with the part you ran. Hold the claim at its own scope through two follow-ups, then concede any limit specifically | F2's evidence, under attribution pressure. EXP because it tests ownership |
| D3 | "The role builds reporting in Power BI and you've never used it. Why should I keep going?" | JD | [grounded] "solid Excel, never used Power BI" | Plain acknowledgment first: "I've never used Power BI." Do not fold and do not bluff. Then a plan in the future tense: what you would do in your first weeks to learn it. Hold the Excel claim at its own scope. Hold through two follow-ups | F6 is a gap you stated; this is the same question B1 may ask, at pressure. JD because it scores the stated tooling requirement |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path" | A 90-second arc in your own words: the seven years in warehouse and distribution, where you are now, and the pick-path redesign as the one story. Answer slot: why this step, and how you moved between roles, are yours to say; the quotes do not carry them | The casual opener is scored. EXP because it sets the facts every later probe starts from |
| E2 | "Tell me about a time you used your Lean or Six Sigma training on the floor." | JD | [grounded] "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path" | The quotes state a certification and a redesign, not a link between them. Answer slot: if the redesign used a method from your green belt, say which and how; if it did not, or you used the training elsewhere, say so plainly and stay with what each quote states | F8, the plus-skill, asked casually. JD because the JD flags it |

### F. Values/Behavioral

No published Atlas values were available (see Sources), so these use standard stems and carry no company claim.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values stem for a role that reports numbers up. VAL because it scores behavior |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named customer, a metric you let slip, and what you told your team. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values stem for a freight role, where on-time and cost pull against each other. VAL because it scores behavior |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites sit side by side. Where's the seam between yours and mine, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam: shared measures, who decides when a load crosses sites, how disagreements escalate. Frame what you bring them, not only what you need. The question needs no claim about your past, so the guidance makes none | Four sites mean peers, even if this round is a manager's. JD because it scores the multi-site mandate |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time with named teams, a split of credit you set or accepted, and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard peer stem. VAL because it scores behavior |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A4, B4, D1, G1 |
| Drive on-time performance | A1, A5 |
| Drive cost-per-shipment down | A2 |
| Lead a team of 12 supervisors | A3, B2, D1 |
| Build reporting in Excel/Power BI | A3, B1, C3, D3 |
| 5+ years operations leadership | B3 |
| Lean/Six Sigma a plus | E2 |
| Headline metric on your background (the 40% mis-pick cut) | C1, C2 |
| Company and strategy knowledge | none: no research could run, see Sources |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured today, and how do the four sites compare?" | Shows you start from the measure, not the target, and gets you the baseline you cannot research |
| R2 | "How are the twelve supervisors spread across the four sites, and where is the team strongest?" | Turns the scale gap into a question about the team you would inherit |
| R3 | "What does reporting look like today: what lives in Excel, what lives in Power BI, and who owns it?" | Puts the tooling gap on the table as a working question, not a confession |
| R4 | "How is cost per shipment defined here, and which lever has moved it most?" | Shows you ask for the definition before you chase the number |
| R5 | "What would you want fixed in the first ninety days?" | Gets the real priority and lets you answer it in the close |
| R6 | "What separates people who do well in this seat in their first six months?" | Invites a direct answer about what the role rewards, from the person who hires for it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led twelve supervisors, or a multi-site team | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says three supervisors. B2's slot stays inside the three |
| Ran terminal operations or owned several sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says warehouse and distribution, not terminals. A4 and B4's slots stay inside what you did |
| Improved on-time performance or cost per shipment | Inflated form of F2 and F3 | F2 and F3's quotes at their own scope. The limit is the pack's observation: the material says a surge plan and a mis-pick rate, not those measures. A5's slot asks only what was tracked |
| Has used Power BI, or an equivalent dashboard tool | Negative the candidate stated, F6 | The plain acknowledgment F6 gives: "I've never used Power BI." No slot |
| Five or more years of operations leadership | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says seven years in operations, not seven in leadership. B3's slot stays inside the seven years |
| The mis-pick redesign was a Six Sigma project | Inflated form of F3 and F8 | The two quotes, each at its own scope. E2's slot asks only whether a green belt method was used |

## Sources

Provided documents: the job description pasted in your message, and your background as you described it in the same message. No CV, no interviewer information and no recruiter notes were given. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused by the host before returning anything:

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight regional logistics terminals strategy news 2026": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have moved a values cheat sheet and the VAL questions. With no values page the bank uses standard stems, labeled generic |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have moved the persona weights and the loop. With no loop source the weights rest on an assumed hiring-manager round, and the archetype fallback is Generic |
| 3. `Atlas Freight strategy / recent news` | unavailable | Would have moved the CO questions. None are in this pack |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, or Atlas's careers page, values page or recruiter email pasted in → company values, the real loop and current strategy; the generic VAL questions and the missing CO questions become grounded. A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes) is available once search is allowed
- The round type and the interviewer's name and title → persona weights read from that person's public footprint, a tailored reverse question, and an interviewer read
- Your CV → F1, F2, F3, F4, F5 and F7 have thin quotes; more of your own sentences turn discovery rows into grounded ones
- Your answers to the slots in F1, F4 and F7: how many people you have led, and for how many years → those rows regenerate on your own words
- The green belt certificate or project file → F8 moves from medium to high
- The recruiter's prep email → focus areas, and coverage of any pre-declared deliverable
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and a named top objection in place of the one this pack inferred
