The pack is built and saved. I'm now handing it over.

Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-denied-b9c11af6/ashgrove_member-experience-lead_interview_pack.md`.

I built it as a loop pack with a mini-pack for each of your three rounds on 20 November. It has 28 questions in total, each with answer guidance tied to your own words.

- **Research:** I sent no searches. Your pasted values, the strategy points and the recruiter's email already fixed the loop, the values and the strategy questions.
- **Biggest gap:** The contact-centre objection, D1 in round 2, gets the deepest rehearsal. You said you've never worked in a contact centre, so the pack coaches you to say that first and then give a plan.
- **Other stated limit:** You've never presented above regional level (B2 in round 1). It's coached the same way.
- **Answer slots:** Where your material is silent, for example digital teams, what your monthly spreadsheet showed, or coaching people at your own level, the pack gives you slots to fill from your real experience. It doesn't script a story for you.
- **Values round:** Each of the four Ashgrove values has a question in round 3. None of your sentences carries a values story, so each gets a pick-your-own-story scaffold, and I haven't invented one.

I'd also be glad to play the Skeptic on D1 as a live drill; say the word.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop:** three rounds on 20 November 2026 (loop mode). **Interviewers:** none named yet; only their roles are known. Built 11 November 2026.

| Round | Length | Who | What the recruiter's email says |
|---|---|---|---|
| 1 | 30 min | The recruiter | Nothing on focus areas |
| 2 | 45 min | Head of Member Services, your future manager | Mostly behavioural |
| 3 | 60 min | Panel of two branch managers | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

**Highest-ROI prep in this pack: D1** (round 2), the contact-centre objection. It is the one question most likely to be asked in some form, because the JD's first requirement runs through the contact centre. B1 in round 1 is its first airing, and I1 in round 3 is where it can return in pressure form.

## How to use this pack

- **Personas** describe how a question arrives (who asks, in what register). **Types** describe what is being scored.
- **Type key:** VAL = behaviour shown against Ashgrove's published values. EXP = your experience holds up under scrutiny. JD = a stated responsibility or requirement. CO = knowledge of Ashgrove's strategy and competition. CASE = a live problem.
- Guidance is scaffolding for a spoken answer, not a script. Every sentence about your past rests on a sentence you wrote, quoted in the Provenance cell.
- An **answer slot** is an instruction for the interview: it marks where only you know the answer. Both honest branches are fine. Saying plainly that something was not yours is a strong answer, not a weak one.
- Provenance labels: `[grounded]` traces to a document you gave me; `[inferred]` is my derivation, named; `[generic]` is a pattern for the problem with no claim about Ashgrove or you.

## Fit snapshot (shared by all three rounds)

Your background reached me as a message summary, not a CV, so every evidence cell quotes that message. Where a row says `none given`, nothing you wrote speaks to the requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on anything beyond the log likely. If any other part of a complaint was yours to decide, say which part and how you decided, in your own words; if the log was the whole of your part, or the rest was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says a monthly complaints spreadsheet, built by you and used by your regional manager; it does not say what was in it. Answer slot: the JD's reporting line makes a probe on what the spreadsheet showed likely. Say what it showed, in your own words, and which part of it was yours; if it showed little, or someone else set what it showed, say so plainly and describe what you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Two separate facts, not one story: you trained new tellers on the escalation script, and you were a branch supervisor. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on helping people at your own level or above likely. If you have done that on anything, say who, what and how it landed; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material speaks to this. Answer slot: if you have worked with a digital team on anything members use, say what it was and what your part was, in your own words; if you have not, say so plainly and say what you would want to learn first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking" — your message | medium | [grounded] | none | No gap, but a summary line with nothing inspected behind it. Lead with the quote's own terms: six years, retail banking |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The quote says formal complaints; it does not show what made them formal. Answer slot: the JD's complaints line makes a probe on that likely. Say, in your own words, what made a complaint formal at your branch and what you did with each one; if that was set by others, or you did not know, say so plainly and return to the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You stated the limit and drew it at regional level; the JD does not say who counts as senior. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan. Your material does not say what you have presented at or below that level, which the upgrade menu asks for |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet, not Excel. Answer slot: if it was built in Excel, say what you did in it, in your own words; if it was another tool, say so plainly and say what you did |

## Grounding brief: Ashgrove's 2026 strategy

You gave me four points from the July 2026 strategy brief the recruiter sent. I have not seen the brief itself, so nothing below goes beyond those four points. The brief is four months old, inside the window where strategy facts stay fresh.

| Point | What it says | Where it appears in this pack | Provenance |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | A4, E1 | [grounded] |
| Hubs | Consolidate eight branches into five hubs over 2027 | E2, G2, reverse questions | [grounded] |
| New product | Launch a small-business lending product in Q1 2027 | R2 reverse questions | [grounded] |
| Competition | Main competitive pressure is app-only banks | E1 | [grounded] |

Vocabulary to use as they use it: member service, digital channels, hubs, members (not customers).

---

# Round 1: Recruiter screen (30 minutes)

### Persona weights

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly walk-through of your background, why Ashgrove, a check on the JD's list | high: a recruiter screen's prior is Conversational plus a light Skeptic, and the email adds nothing that changes it | A 90-second arc built from your quotes; treat casual questions about JD topics as scored |
| B. Skeptic (light) | A quiet check of the biggest gaps against the JD | medium: your material has two stated limits (F2, F8) a recruiter checks first | Say each limit plainly in one sentence, then the plan; rehearse more deeply in round 2 |

### Question bank

**A. Conversational (5)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey in banking and where you are now." | EXP | [grounded] "6 years in retail banking"; "the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F6: an arc of six years in retail banking, the last three as a branch supervisor, then the three things you wrote about, each at its own scope. Tell them in your own words and stop at what the quotes say. Answer slot: your reason for moving toward complaints ownership is yours and not in the material; if there is one, say it in a sentence, and if the move was circumstantial, say that plainly | F6 is the requirement a recruiter confirms first; EXP because it tests that the story you tell matches your summary |
| A2 | "What draws you to Ashgrove specifically?" | CO | [grounded] value text: "we decide from the member's side of the counter" | Pick one published value or one strategy point you can speak to honestly and say in your own words why it matters to you. Do not recite the value. This makes no claim about your past, so the guidance makes none | Rapport-style interviewers score this as a preparation signal; CO because it tests homework depth; the value text is from the page you pasted |
| A3 | "Tell me about your complaints experience so far." | EXP | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F1, F4 and F3: three beats, each the quote's own words. Answer slot: the JD's complaints line makes a probe on what made these complaints formal likely. Say, in your own words, what made a complaint formal at your branch and what you did with each one; if that was set by others, or you did not know, say so plainly and return to the log | F7 and F1 are what the recruiter checks against the JD; EXP because the screen tests that your summary and the role line up |
| A4 | "What do you know about where Ashgrove's member service is heading?" | CO | [grounded] strategy brief point: "move 40% of member service to digital channels by 2028" | State the target as the brief gives it, and name the hubs plan if it fits. One honest line on what you would want to learn about how complaints work in digital channels. No claim about digital experience | Digital self-service is a JD line (F5) and the brief's headline target; CO because it tests whether you read what the recruiter sent |
| A5 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F9: say you built the monthly complaints spreadsheet your regional manager uses, in those words. Answer slot: if it was built in Excel, say what you did in it; if it was another tool, say so plainly and say what you did | The JD's last requirement is the one that is easy to skip; JD because it scores a stated requirement |

**B. Skeptic, light (3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job description would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Name it before they do: "I haven't worked in a contact centre." Then the quote, at its scope: "I handled the branch's formal complaints log." Then your plan, as a plan: you would learn the centre's side first. Do not claim the log transfers; the pack makes no such claim | F2 is the biggest gap against the JD's first line, so a recruiter reaches it first; JD because it scores the stated requirement, with Skeptic delivery |
| B2 | "Have you presented to senior leaders before?" | JD | [grounded] "I've never presented to anyone above regional level" | The plain acknowledgment, in your words from the message: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level or below, say to whom and what, in your own words; if not, say so plainly. Then how you would prepare, as a plan | F8 is a stated limit and the JD's requirement names senior leaders; the recruiter will ask so that they can brief the next rounds |
| B3 | "Why this role, and why now?" | EXP | [generic] | Scaffold: a reason that is about the role and not only about leaving, one you can repeat the same way in every round. If no clear reason comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach the choice. The reason is yours; the pack does not supply it | Motivation consistency is what a recruiter screen scores; this one carries a persona stem the pack can use without any claim about your history |

### Round 1 reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1a | "Is there anything in my background you would want me to address before the next two rounds?" | It turns a hidden objection into one you can answer, and a recruiter who has just read your summary has one |
| R1b | "Which parts of the shift to digital channels touch this role most?" | It uses the brief's own 40% target and tells the recruiter you read what they sent |
| R1c | "Once the panel members are assigned, could you share who they are?" | Names unlock a tailored read of each interviewer; it is also an ordinary process question |

---

# Round 2: Head of Member Services (45 minutes, your future manager)

### Persona weights

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C. Values / Behavioural | Scenario probes, STAR-shaped stories | high: the recruiter's email says "mostly behavioural" | "We" for context, "I" for contribution; where your material carries no story, say so, then give the nearest thing |
| D. Skeptic | The gaps in your material, tested by the person who would manage you | high: a hiring manager derisks gaps, and you have two stated limits plus several discovery rows | Rehearse the single most predictable objection until it is boring |
| E. Case / Strategist | Live problems drawn from the strategy | medium: a manager's prior, and the brief gives them material | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |

### Question bank

**C. Values / Behavioural (4)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unwelcome truth to someone more senior." | VAL | [generic] | Scaffold: choose an instance with a named stake, a moment you did not soften the message, and an intact working relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Where the hard truth landed, say what happened; where it did not, say that | The persona stem for this round; the JD wants confidence with senior leaders (F8) and the material has no story for it |
| C2 | "Tell me about a time a complaint went somewhere it should not have." | JD | [grounded] "trained new tellers on our escalation script" | Scaffold: an instance where you saw it happening, what you did, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the quote at its own scope: "I trained new tellers on our escalation script." Or say how you would handle it | The JD asks you to coach on escalations, so an escalation story is the natural behavioural probe; the material has the training and no specific incident |
| C3 | "Tell me about a time you helped a colleague do something differently." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: the quote, at its scope: "I trained new tellers on our escalation script." Answer slot: if you have helped someone at your own level or above do something differently, say who, what and how it landed; if not, say so plainly and stay with the tellers. Do not widen the training into more than the sentence says | A manager hiring someone to coach reads this as the test of the role; JD because it scores the coaching line (F4) |
| C4 | "Tell me about a time you worked with a team outside your branch to fix something." | JD | [generic] | Scaffold: a named other team, a shared problem, your own part, an outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach working with the contact centre and a digital team. Your material has nothing on this | The JD's role spans branches, the contact centre and digital teams (F1, F2, F5); the material has no cross-team story, so a scaffold is the honest form |

**D. Skeptic (3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have never worked in a contact centre. How would you own a process that runs through one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | **The deepest rehearsal in the pack.** Concede first, then the quotes, then the plan: "I haven't worked in a contact centre. I handled the branch's formal complaints log, and my first job would be to learn the centre's side before I changed anything." Follow-up 1, how you would earn the contact-centre team's trust: hold by returning to the plan (listen to the centre's work, learn how it records and passes on complaints) and never by claiming a likeness to branch work. Follow-up 2, what if the centre does something differently from the branches: hold again; you would look at both before changing either. Concede only what is true: you do not yet know how the centre works. The limit, named before it is asked for: your material covers the branch side, not the centre | F2 is the gap against the JD's first line, stated by you, and a manager's whole case for hiring you rests on how you handle it; JD with Skeptic delivery |
| D2 | "What part of the complaints process have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log" | The hold is only what the quote carries: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on anything beyond the log likely. If any other part of a complaint was yours to decide, say which and how you decided; if the log was the whole of your part, or the rest was not yours, say so plainly. Hold through two follow-ups by returning to the log, never by adding to it | F1 is where the role's end-to-end mandate presses hardest on your material; JD because it scores the stated requirement |
| D3 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3: you built it, it was monthly, it was about complaints, your regional manager used it; those are the beats. Answer slot: the JD's reporting line makes a probe on what it showed likely. Say what it showed, in your own words, and which part was yours; if it showed little, or someone else set what it showed, say so plainly and describe what you built. If a number comes up, say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours; if you do not know how it was counted, say that | The spreadsheet is your one reporting artifact (F3, F9); EXP because a prober starts from the one thing you built |

**E. Case / Strategist (2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "More of our member service will move to digital channels. What should happen to the complaints process, and what do you need to know first" | CASE | [grounded] strategy brief points: "move 40% of member service to digital channels by 2028"; "the main competitive pressure is app-only banks" | Structure it aloud. Clarify (what counts as a complaint in a digital channel, and who sees it). Objective (members are heard and the complaint is resolved wherever it starts). Segment (branches, contact centre, digital). Approach. Measures (the JD's own pair: volumes and resolution times). Risks. Challenge one premise politely. Answer slot: if you have worked with a digital team on anything members use, say what and what your part was; if not, say so plainly and say what you would want to learn. Makes no claim about your past beyond that | The brief's headline target and the JD's self-service line (F5) meet here; CASE because it is a live problem in Ashgrove's own vocabulary |
| E2 | "Eight branches become five hubs over 2027. What would you want to protect in the complaints process while that happens" | CO | [grounded] strategy brief point: "consolidate eight branches into five hubs over 2027" | Same structure. Ask first what is known about timing and which complaints are in flight. Then what to protect (a member's complaint should not be dropped when a branch it started in changes) and how you would know. Tie it lightly to the value "every branch is part of its town", only if it fits | It tests altitude: whether you can think about the process through the change, not around it; CO with CASE delivery |

### Round 2 reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R2a | "Where does a complaint cross between a branch and the contact centre today, and who holds it when it does" | It is the JD's first line turned into a question, and "whoever finds the problem keeps hold of it" is a published value |
| R2b | "With eight branches becoming five hubs over 2027, which complaints would you most want this role to have a handle on before then" | It uses the brief and shows you think about sequence |
| R2c | "What would you want the complaints process to be ready for when the small-business lending product launches in Q1 2027" | It is the only brief item no other question uses and shows you read all of it |
| R2d | "Who reads the monthly complaints report, and what do they do with it" | It shows you treat reporting as an input to decisions, which is what the JD's reporting line is for |

---

# Round 3: Panel of two branch managers (60 minutes, includes a 20-minute case; the values round)

### Persona weights

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| F. Values / Behavioural | Scenarios scored against the four published values | high: the recruiter's email says the panel scores against the four values | Map a story to each value where your material carries one; where it does not, use the scaffold's honest branch |
| G. Case / Strategist | The 20-minute escalation case | high: the email names it and its length | Clarify before you structure; think aloud; challenge one premise |
| H. Peer Evaluator | "What would you need from us", coaching and seam questions | medium: branch managers work next to this role, but the email does not say what they will ask | Reciprocity first; propose seam principles, not a seam you cannot know |
| I. Pressure | A time-boxed challenge, possibly inside the case | low: no source says so; one question is included as insurance | Pause, restate, hold your quoted position through two follow-ups |

### Question bank

**F. Values / Behavioural (4)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] value text: "Members First, Always" | Scaffold: an instance where the member's interest and a rule, target or convenience pulled apart, what you decided, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value named in the panel's own scoring; no quote of yours carries a decision story, so the pack does not supply one |
| F2 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] value text: "Plain Words"; "trained new tellers on our escalation script" | Scaffold: an instance, what you did the second time, and what you took from it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the quote at its own scope: "I trained new tellers on our escalation script." Answer slot: if you have ever changed the wording of a script or a letter because it was not understood, say what and why; if the wording was fixed or not yours, say so plainly and stay with the training | The value reads "if a member needs it explained twice, we wrote it wrong"; the escalation script is the one place your material touches words members hear |
| F3 | "Tell me about a time you took a particular town or community into account in a decision." | VAL | [grounded] value text: "Neighbours, Not Numbers"; "the last 3 as a branch supervisor" | Scaffold: a named place or group, what you weighed, what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is that you were a branch supervisor for the last three of six years, or how you would handle it. The quote does not say anything about the town | The published value says every branch is part of its town; branch managers are likely to score this one personally, and the hubs plan makes it live |
| F4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] value text: "Own the Fix"; "I handled the branch's formal complaints log" | Scaffold: how you found it, who else could have let it go, what you did to see it through, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the quote at its own scope: "I handled the branch's formal complaints log." Or say how you would handle it | The value reads "whoever finds the problem keeps hold of it until it is solved"; it is the closest value to the JD's end-to-end requirement |

**G. Case / Strategist (3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member has complained twice about the same decision at their branch. The branch says it is closed; the member says it is not, and says they will take it further. You are asked to step in. What do you do first" | CASE | [generic] | Clarify first: what exactly was decided, what the member was told and when, and what any rules or deadlines for this kind of complaint require. Objective: a fair outcome for the member and the supervisor's confidence intact. Check whether this is one case or a pattern. Approach, measures (time to resolve), risks (trust, defensiveness). Challenge one premise: by what test is it closed. Where a value is the real reason for a step, say so, and do not recite one. This asks about no past, so the guidance makes no claim about it | The recruiter's email names a 20-minute complaint-escalation case; this is a pattern for it, so it carries `[generic]` and no claim about Ashgrove's real case |
| G2 | "A member at a branch that is closing complains that nobody local knows them any more. How do you handle the complaint, and what does it tell you" | CASE | [grounded] strategy brief point: "consolidate eight branches into five hubs over 2027" | Same structure. Separate the member's complaint from the programme; resolve the one, record the other. Say what you would look at across several such complaints and who you would tell. Tie it lightly to the value "Neighbours, Not Numbers" only if it fits | It joins the strategy and the value the panel scores; CASE because it is a live problem |
| G3 | "In the case, you are asked to coach a supervisor who handled the escalation badly. What do you say" | CASE | [grounded] JD: "coach branch supervisors on escalations" | Open by asking what the supervisor saw and did. Agree the facts first. Name what went right. Give one specific change and how you will check back. Keep it private and without blame. This asks about no past, so the guidance makes none | The JD's coaching line (F4) as a live exercise; branch managers are the people who supervise the supervisors you would coach, so they will score how it sounds |

**H. Peer Evaluator (3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our branches and the complaints lead sit side by side. Where is the seam, and what happens when we disagree about how a complaint should be handled" | JD | [generic] | Reciprocity first: what this role gives a branch manager's time back. Then principles, not a seam you cannot know: who decides a complaint's outcome, who keeps hold of it, how a disagreement is raised. Where a value is the reason, say it plainly. No claim about your past | Branch managers will work next to this role; persona stem for a peer panel |
| H2 | "Tell me about a time you helped a colleague do something differently, and how it landed." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4 at its scope: "I trained new tellers on our escalation script." Answer slot: if you have helped someone at your own level or above, say who, what and how it landed; if not, say so plainly and stay with the tellers | The panel is the likeliest place for the JD's coaching line to be probed in person; a peer panel scores whether you build people up |
| H3 | "A complaint shows a branch got something wrong. Who hears about it, and how" | CASE | [generic] | Principles: the facts first, privately with the supervisor; the learning shared without names; credit by name where a branch fixed it. This makes no claim about your past | Credit and blame across teams is the peer persona's core probe; CASE because it is a live scenario |

**I. Pressure (1)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Sixty seconds: why you over an internal candidate" | JD | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses"; "trained new tellers on our escalation script" | Pause, restate it, then three sentences, one per quote, at their own scope; do not claim to be better. Hold through two follow-ups by returning to the quotes. Concede the one limit plainly if pushed: "I haven't worked in a contact centre." Do not add to the quotes to win the minute | Insurance for a possible time-boxed challenge; no source says the panel will use one |

### Values cheat sheet

Detected because the recruiter's email says the panel scores against the four values. Names are copied from the page text you pasted on 11 November 2026.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold (F1): an instance where the member's interest and a rule or target pulled apart. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs an explanation twice, the wording was wrong | Scaffold (F2), with F4's "trained new tellers on our escalation script" as the nearest thing at its scope. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch belongs to its town | Scaffold (F3), with the quote "the last 3 as a branch supervisor" only as the nearest thing, which says nothing about the town. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold (F4), with F1's "I handled the branch's formal complaints log" as the nearest thing at its scope. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

### Round 3 reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R3a | "What could a new complaints lead do in their first month that would genuinely help your branch" | It is the reciprocity question for a peer panel and answers the "what would you need from us" probe before it is asked |
| R3b | "When a complaint is escalated from your branch, what do you want to hear back, and how soon" | It turns the seam into a service standard you can then own |
| R3c | "How is your branch thinking about the move toward five hubs, and what do members there most want kept" | It ties to "Neighbours, Not Numbers"; ask it only if the conversation has been about the hubs, because it touches their own branches |
| R3d | "Without names, what does 'Own the Fix' look like at your branch" | The panel scores values; inviting their own example shows you are listening for it |

---

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| F1 Own the process end to end | A3, D2, G1 |
| F2 Branches and the contact centre | B1, D1 |
| F3 Report monthly | A3, D3 |
| F4 Coach supervisors on escalations | C2, C3, G3, H2 |
| F5 Digital teams, self-service | A4, E1 |
| F6 4+ years in customer operations | A1 |
| F7 Regulated complaints | A3 |
| F8 Presenting to senior leaders | B2, C1 |
| F9 Excel reporting | A5, D3 |
| Defend-the-number EXP | — none, and why: your material has no figure beyond years of service, so no headline metric exists to defend (D3 holds the counting slots if a number comes up) |

## Prohibited claims

Built from the snapshot before any bank was written; every guidance cell is held against it.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says the branch's log, not the process end to end. D2's slot stays inside the log |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: your material says a monthly complaints spreadsheet, not what it counted. D3's slot asks only what it showed and what was yours |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: your material says new tellers and the escalation script. C3 and H2 stay with the tellers |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: your material says formal complaints, and does not show what made them formal. A3's slot asks only that |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8, at its scope | "I've never presented to anyone above regional level." The pack's observation: the JD does not define senior. No slot beyond B2's regional-level one |

## Sources

Provided documents: the job description you pasted; the four values as copied from ashgrovecu.org/about/values on 11 November 2026 (pasted text, so the page itself was not fetched); the recruiter's email on the three rounds; your four strategy-brief points from the July 2026 brief (the brief itself not seen); your background message. No dossier was present, so none was consumed. Searches sent: none. Fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the values cheat sheet and the four VAL questions |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email fixes the round count, lengths, who runs each, the case and the values round, so persona weights and structure are settled |
| 3. `Ashgrove Credit Union strategy` | skipped | The four brief points you pasted, from July 2026, fix the CO questions and the grounding brief |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No interviewer name was given, so there was no query to form; the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names for rounds 2 and 3 → a public-footprint read of each, persona weights tuned per person, and a reverse question tied to their own path
- Your CV → fit-snapshot rows now quoting a message summary could quote your own wording, which may lift several `medium` rows
- A sanitised sample of the monthly complaints spreadsheet, or a description of its columns → F3 and F9 could move from `discovery` toward `high`, and D3's slot could become a story map
- Your own answers to the answer slots in F1, F3, F4, F5, F7, F8 and F9 → those rows would be regenerated with your words quoted, replacing slots with story maps where you had a story
- What you have presented to at regional level or below → F8, B2 and C1 would gain a real beat
- The recruiter's description of the round 3 case (written or role-played, any materials) → G1 to G3 tuned to its real format; one email to the recruiter
- The full July 2026 strategy brief → the grounding brief and E1, E2 would use its own numbers and wording, not four points
- Hours available before 20 November → a prioritised prep schedule sized to them
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → recent organisational context and role-family loop reports, which would sharpen the CO bank
- A `tuesday-dossier.md` from an earlier underwriting pass, if you have one → verified evidence and a named top objection in place of the ones inferred here
