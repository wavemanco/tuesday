Research was refused, so I'm building the pack from your dossier alone. Company facts stay out of it and the case questions are labeled generic.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-4-denied-2d29af43/quartzline_product-manager-platform-apis_interview_pack.md`. It has 22 questions, built for a 45-minute hiring-manager round from your dossier alone. My three Quartzline searches were refused, so there are no company facts in it, the case questions are generic, and there is no company-strategy question. The pack says so in its Sources and upgrade menu.

The question to rehearse first is B1, the dossier's named objection: "You have never held the PM title or owned a roadmap — why should we hire you…" The pack coaches a short concession, then your three integration sentences kept to their own scope and called adjacent work, then a ramp plan, then holding through two follow-ups. G1 is the sixty-second version.

Three things in the pack depend on the dossier's limits:
- **Roadmap ownership:** the dossier recorded no evidence, so the pack coaches a plain acknowledgment and never a bridge. The roadmap-input sessions are not used as a bridge. They are the medium-confidence entry, so expect a probe.
- **R2 (shipped API products):** the dossier doesn't flag it as weak. I graded it as an adjacent fit myself, so check that row against your own sense of the work.
- **Slots to fill:** four rows (API docs and schemas, stakeholder breadth, agile delivery, and the stages in the R2 row) end in answer slots. Those are for your own words, and the pack supplies no details for them.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save an updated tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack — Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. Interviewer name not given.
**Built from:** your tuesday-dossier.md (underwriter decision: conditional_go) and your message. No Quartzline research ran (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether the claims on your record survive scrutiny |
| JD | The stated role requirements and responsibilities, gaps included |
| CO | Company and strategy knowledge (none in this pack: no research ran) |
| CASE | A live problem, structured aloud |

Question IDs skip the letter F so they never collide with the fit rows F1 to F6. A question has one type tag; where content and delivery differ, the rationale says so.

## Prep triage

Four things done well, in this order. Everything else is insurance.

1. Say B1 aloud until it is boring, then G1, its sixty-second version. The underwriter named this objection, and it is the highest-ROI prep in the pack.
2. Say the plain acknowledgment from B2 once, out loud, without softening it.
3. Prepare C1 and C2. The 30+ integrations are your spine and the likeliest line to be probed.
4. Write your own answers to the answer slots in F3, F4, F5 and F6, then practice A2 and A4 and the first two reverse questions. Those two are the open unknowns in the dossier.

## Fit snapshot

Requirements are the lines in the dossier's role_profile. Evidence is quoted from the dossier's verified_candidate_evidence. The dossier carries no evidence_map, so F3, F4 and F5 are graded by this pack and labeled inferred; check them against your own sense of the work.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff entry 1; "Wrote the internal integration playbook her team uses" — dossier handoff entry 2; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff entry 3 | low | [grounded] | transferability | The underwriter's strategy is bridge, and its limit travels with it: this is adjacent work, never presented as product management experience. The words stay at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The limit, sourced by prohibited_claims: "Having held a product manager title or role" — "I haven't held a product manager title or role." The third quote carries the dossier's medium caveat (confirmed, limited inspectable proof), so expect a probe and volunteer its limit before it is extracted |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | capability | The underwriter recorded this as an acknowledge_gap area: "Owning a roadmap and prioritization authority (R1 sub-claim)". No bridge is coached; the pack's observation is that the third quote in F1 is roadmap input, not roadmap ownership. Words, sourced by prohibited_claims: "Having owned a product roadmap" and prohibited_claims: "Having set prioritization for an engineering squad" — "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then how you would learn it, said as a plan and never as a past |
| F3 | "Shipped API or platform products" — JD (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff entry 1; "Wrote the internal integration playbook her team uses" — dossier handoff entry 2 | high | [inferred] | transferability | The dossier lists no weak area for this requirement; this row is the pack's own call from the quote's wording. The quote carries client integrations of the vendor's REST APIs with the stages it names, and the words stay there: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: the JD's line on this requirement makes a probe on the integrations likely. If any of those stages were yours to set, say which and how you decided, in your own words; if a stage was not yours, or did not exist, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier role_profile R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff entry 1; "Wrote the internal integration playbook her team uses" — dossier handoff entry 2 | low | [inferred] | discovery | The quotes touch REST APIs, architecture and a playbook; none says whether API docs or schemas were read or written, so the pack carries no claim about them. Answer slot: the JD's line on API docs and schemas makes a probe likely. If you read or wrote API docs or schemas in those integrations, say which and what for, in your own words; if you did not, or the playbook did not cover them, say so plainly and stay with the REST integrations |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff entry 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff entry 3 | medium | [inferred] | discovery | The quotes touch clients and the product team; they do not say whether engineering or sales were involved. Answer slot: the JD names engineering, sales and customers, so expect a probe on each. If you worked with any of them in these integrations or sessions, say which and how, in your own words; if you did not, say so plainly and stay with the clients and product team the quotes name. The second quote is the medium-confidence one: say what the sentence says, and volunteer the limit on what you can show of those sessions before you are asked |
| F6 | "Agile delivery experience" — JD (dossier role_profile R5) | none given | low | [grounded] | discovery | The underwriter's strategy is clarify, and no verified entry speaks to this requirement, so nothing about your past goes into the answer. Answer slot, with the requirement's own wording as the interviewer's probe: if you have worked in agile delivery, say how, in your own words; if you never worked that way, say so plainly. Either way you can add the honest question: here is what I would want to confirm about how you define agile delivery on these two squads |

## Persona table

Weights start from the hiring-manager relationship prior (Case/Strategist plus Skeptic) and are adjusted by what the dossier shows. No interviewer information was supplied, and no Quartzline loop documentation was read. Your own description of the round (one 45-minute conversation with the hiring manager) sets the structure; the weights rest on that prior, not on a documented Quartzline process. Recalibrate if you know the interviewer's style.

| Persona (bank) | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems on the platform: diagnose, prioritize, decide | Top, 5 questions. Hiring-manager prior; the role's own responsibilities (roadmap, specs, adoption metrics) translate directly into cases | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet, persistent probing of the title and roadmap gap | Top, 5 questions. Hiring-manager prior, and the underwriter named this objection from your confirmed evidence | Rehearse the one predictable objection until it is boring; bridge only from the adjacent sentences you stated, limit said plainly; ramp plan |
| Data-Driven Prober (C) | Reads your record line by line | Mid, 3 questions. The 30+ figure is a headline number; no interviewer signals either way | Know what you can and cannot say about how the figure was counted; name the assumption you would defend least before they do |
| Conversational (D) | Friendly, unstructured; still scored | Mid, 3 questions. Not weighted by the prior; kept so no style is met for the first time live | A 90-second arc; treat casual questions about the JD's topics as scored |
| Peer Evaluator (E) | Where the PM ends and the squad leads begin | Low, 2 questions. The dossier flags squad-lead authority as unevidenced, so the seam question is plausible even from a manager | Propose seam principles instead of pretending to know the seam; ask it back |
| Pressure (G) | Time-boxes, interrupts, tests composure | Low, 2 questions. Not weighted by the prior; B1 is where it would most likely land | Pause, restate, hold through two follow-ups, concede only specific things |
| Values/Behavioral (H) | Scenario probes | Low, 2 questions. No values-style round is detected and Quartzline's published values could not be retrieved, so these rest on persona stems only | Selection scaffold ending in the honest branch |

## Question banks

Labels: grounded means built on your quoted sentences or a supplied document; generic means a pattern with no claim about you or Quartzline. Answer slots are instructions for the interview, not questions for this conversation.

### A. Case/Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Suppose partners start integrating with the platform API but many stall before going live. How would you diagnose it?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Think aloud. Clarify what counts as stalled and what baseline exists, state the objective, segment the partners, say where you would look first, name the metric you would watch and how it could mislead you. The quote's stage names (scoping, requirements, architecture, UAT, go-live) are available as vocabulary for where partners might stall; say it is a hypothetical, not your past. Challenge one premise, for example how stalled is measured today | Adoption is a stated responsibility and its baseline is an open unknown, so a diagnosis case is likely; CASE because it scores structure and presupposes nothing about you. F1 supplies vocabulary only |
| A2 | "Two squads each want your next quarter: one wants to pay down platform debt, the other a partner-requested endpoint. How do you decide?" | CASE | [generic] | Ask first who holds the decision and what evidence exists; that is also the dossier's open unknown on authority. Then criteria (partner impact, dependencies, cost, reversibility), a recommendation framed as a proposal, and how you would bring both leads along. This is reasoning aloud, not a story. If pressed on experience, use the sourced plain acknowledgment from F2: prohibited_claims: "Having owned a product roadmap" — "I haven't owned a product roadmap, so here is how I would work it." | Roadmap ownership is the role's first responsibility and F2 is where the material is thinnest, so a prioritization case is likely; CASE because it asks for reasoning, not history |
| A3 | "A partner asks you to change a REST endpoint that other partners rely on. How do you decide, and what goes in the spec you hand the squads?" | JD | [generic] | Clarify who is affected and how you would know. Lay out options (version it, deprecate with notice, decline), decide on partner impact and cost, then the spec: the problem, affected partners, the change, the migration path, how you would know it worked, and the docs and schema updates. It asks about no past, so answer as a plan and make no claim about having done it | The JD's spec-writing and API docs and schemas lines (F4) arrive as a live problem; JD content, CASE delivery |
| A4 | "The role has you define and track adoption metrics. What would you measure first, and what would you need to know before choosing?" | JD | [generic] | Start with what is measured today and the current baseline: the dossier lists both as unknowns, so asking is diligence, not evasion. Then a first metric, the decision it would inform, and the weakest assumption behind it, named before they do. Speak in plans, not in past tense | Adoption metrics are a named responsibility with no stated baseline; JD content, CASE delivery |
| A5 | "How would you run discovery with a new integration partner when what they want conflicts with what other partners have asked for?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure it as a hypothetical first: objective, who to talk to, what evidence would settle the conflict, what you would bring back. If you mention your own work, say the sentence and stop: "I ran quarterly roadmap-input sessions feeding client evidence to product." It says roadmap-input sessions, and the JD says discovery, so do not relabel one as the other. Answer slot: the JD's discovery line makes a probe on how those sessions gathered evidence likely. If they involved asking clients open questions about needs, say how, in your own words; if they relayed evidence already gathered, or there was no such step, say so plainly and stay with the sessions as stated. This is the medium-confidence sentence (F1, F5): volunteer the limit on what you can show of them | Discovery with integration partners is a stated responsibility and the sentence only approaches it (F1, F5); JD content, CASE delivery |

### B. Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | **Highest-ROI rehearsal, named by the underwriter's likely_interviewer_objections.** Four beats. One, concede first and briefly, sourced by prohibited_claims: "Having held a product manager title or role" and prohibited_claims: "Having owned a product roadmap" — "I haven't held a product manager title or role, and I haven't owned a product roadmap." Two, the adjacent case with its limit named, in the sentences' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live. I wrote the internal integration playbook my team uses. I ran quarterly roadmap-input sessions feeding client evidence to product." Say it is adjacent work, not product management. Three, the ramp as a plan, never a past: what you would learn first about how the two squads decide. Four, hold through two follow-ups by returning to the integrations, never by adding to them. If they say integration work is not product work, concede in specific words: "Agreed, it is adjacent; the roadmap is the part I would be learning." Do not tell them what the work proves; let them draw the inference. If the third sentence is probed, say what it says and what you can show of those sessions | The objection arrives in some form in nearly any version of this round, and F1 and F2 are where it presses; JD because it scores the first requirement, with Skeptic delivery |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] acknowledge_gap area: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name the gap the underwriter recorded, plainly. The underwriter found no evidence here, so no bridge is coached. Words, sourced by prohibited_claims: "Having owned a product roadmap" and prohibited_claims: "Having set prioritization for an engineering squad" — "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, in the future tense: how you would learn how the two squads decide before proposing anything | F2 is the largest gap and this stem exists to find it; JD because it scores the stated responsibilities |
| B3 | "What has your agile delivery looked like?" | JD | [grounded] | The question presupposes agile delivery, so use the clarify form from F6. Answer slot: the JD's agile delivery line makes this probe likely. If you have worked in agile delivery, say how, in your own words; if you never worked that way, say so plainly. Then the honest question: here is what I would want to confirm about how you define agile delivery on these two squads | F6 is a discovery row with no quote to build on; JD because it scores a stated requirement |
| B4 | "I don't see API products you've shipped in your background — how would you handle that in this role?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the sentence at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The pack's observation is that the sentence does not say what was built on the vendor's side, so do not fill that in. Answer slot, inside the sentence: if any of those stages were yours to set, say which and how you decided; if a stage was not yours, or did not exist, say so plainly and stay with the integrations you led. Then a ramp plan for learning how the platform's releases are decided | F3 is a must-have requirement graded by this pack, and the stem is the Skeptic's standard form |
| B5 | "Why a move into product management, and why Quartzline?" | JD | [generic] | None of your quoted sentences carries your reasons, so these are yours to supply. Draft three sentences: what pulls you toward product work, what you want to carry across from your current work, and what is specific to this role. Cut any reason that is not true. Why Quartzline needs research this pack could not run, so take it from your own reading of the company and the JD | Motivation consistency is the Skeptic's other scoring axis; JD because it tests fit with the role |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations — how was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend-the-number, in your own words. Answer slot: how the 30+ was counted; what it is sensitive to; the assumption behind it you would defend least, named before they do; which part was yours. If you do not know how some of it was counted, say so plainly. The pack supplies no method, baseline or assumption | F1 and F3 rest on this headline figure, and a record-reading interviewer goes here first |
| C2 | "Pick one of those integrations and walk me through it from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The beats are the ones the sentence names: scoping, requirements, architecture, UAT, go-live. What happened at each is yours to tell in your own words; the pack supplies none of the middle. If a stage was someone else's, say so and describe your part. Choose one you can describe end to end | The follow-up to C1 is a walkthrough; EXP because it tests what was actually yours (F1, F3) |
| C3 | "Tell me about the integration playbook — what's in it and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say the sentence at its scope: "I wrote the internal integration playbook my team uses." What is in it is yours to describe; the pack does not know. The dossier marks the playbook as inspectable, so decide beforehand whether it is shareable. Say who uses it only as the sentence does: your team | F1 and F3 both rest on it, and it is the most inspectable evidence you hold; EXP because it tests authorship |

### D. Conversational (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc whose beats are those three sentences, ordered by your own timeline, with nothing added to their scope. End on why this role, in your own words (B5) | The casual opener is scored, and F1 is the spine of the arc |
| D2 | "What are you actually playing with in API docs or schemas these days?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The question presupposes hands-on work with docs or schemas, so use F4's slot. If you have been working with API docs or schemas lately, say what, in your own words; if not, or never in that way, say so plainly and stay with the REST integrations in the sentence | The JD's technical-fluency line asked casually; F4 is a discovery row |
| D3 | "Tell me about a time you had to bring engineering, sales and a customer into the same conversation." | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Selection criteria: pick a time with a named stake, who was in the room and who was not, what each wanted, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the sentence at its scope, "I ran quarterly roadmap-input sessions feeding client evidence to product", with its limit volunteered, or how you would handle it | The JD's stakeholder line names three groups and F5 shows the material touching only some of them; JD content, behavioral delivery |

### E. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the seam between the PM and the two squad leads, and what happens when you disagree?" | JD | [generic] | Propose seam principles, not facts: who decides what, how disagreements are raised and escalated, what you would confirm in week one. Say you would confirm the actual seam, and ask it back; it is the dossier's open unknown (reverse question 1). Make no claim to have set a squad's priorities; the pack's observation is that your material does not show it (F2) | The dossier flags decision authority versus the squad leads as unevidenced; JD because the JD names two squads |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection criteria: choose a time work spanned teams, use we for context and I for your own contribution, and pick one where credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard collegial probe; VAL because it scores behavior, not a stated requirement |

### G. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a PM who has done the job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | B1 compressed. One clause of plain concession, sourced by prohibited_claims: "Having held a product manager title or role" — "I haven't held a product manager title or role." Then the sentence at its scope, then the ramp as a plan, then stop. Do not fill the silence; do not add to the sentence | The time-boxed version of the likeliest objection |
| G2 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the sentence's own attribution through two follow-ups. Answer slot: if others led parts of any of those, say which and what part was yours, in your own words; if you led them as the sentence says, say that and stay with it. Concede only a specific thing you can name; never fold on the sentence to restore harmony | The stock attribution probe against F1's headline figure |

### H. Values/Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, who the leadership was, what the truth was, and how it landed. Choose one where it actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; no Quartzline value is quoted because the published values could not be retrieved |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: the metric and its owner, what the customer needed, what it cost, how you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem in a role that sits between partners and squads |

## Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1 3+ years product management experience | B1, B2, G1 |
| R2 Shipped API or platform products | B4, C1, C2, G2 |
| R3 Technical fluency: API docs, schemas | A3, D2 |
| R4 Stakeholder management across engineering, sales, customers | A5, D3, E1 |
| R5 Agile delivery experience | B3 |
| Own the roadmap | A2, B2, E1 |
| Run discovery with integration partners | A5 |
| Write specs and drive delivery with two squads | A3, E1 |
| Define and track adoption metrics | A1, A4 |
| Company and strategy knowledge (CO) | none, and why: no research ran, so a Quartzline-grounded question could not be written |

## Reverse questions

| # | Question | Why it lands | Source |
|---|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts squad authority and the dossier found it unevidenced. The answer tells you how much of the job is deciding and how much is coordinating, which you need before accepting | dossier questions_for_employer; opportunity_risks_to_validate |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a named responsibility with no baseline stated; you would be judged on them. Asking reads as diligence and answers something you genuinely need | dossier questions_for_employer; opportunity_risks_to_validate |
| 3 | "What would tell you, ninety days in, that this hire is working?" | It makes them state the bar in their own terms, and gives you something specific to hold the first quarter against | pack, generic |
| 4 | "How does feedback from integration partners reach the two squads today, and who owns that path?" | The JD puts discovery with partners in this role; the answer shows what you would inherit and where roadmap input already flows | pack, generic |
| 5 | "What is the hardest trade-off the platform roadmap faces right now?" | It lets the hiring manager talk about their real problem, and your follow-up shows how you reason about it. It is the kind of question you are only able to ask well after A2 | pack, generic |

## Prohibited claims

Not coached anywhere in this pack. Where a sourced entry gives a plain acknowledgment, it is the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | F1's first quote at its own scope, with the plain acknowledgment: "I haven't held a product manager title or role." |
| Having owned a product roadmap | Dossier prohibited_claims, and acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" | F1's third quote at its own scope: the pack's observation is that it is roadmap input, not ownership. Plain acknowledgment: "I haven't owned a product roadmap." No bridge, no slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | The plain acknowledgment: "I haven't set prioritization for an engineering squad." No bridge, no slot |
| Having shipped or owned an API or platform product itself | Inflated form of F3 | F3's quote at its own scope, with its slot inside the quote's stages. The limit is the pack's observation: your material says client integrations of the vendor's REST APIs, not what was built on the vendor's side |

## Sources

Provided documents:
- tuesday-dossier.md, dossier_version 1.1, generated 2026-08-14 by job-underwriter. Consumed: role_profile (the JD's lines, R1 to R5 and the responsibilities), handoff_to_mock_interview (verified evidence, weak areas and strategies, the named objection, risks, employer questions, prohibited claims), and decision (context only). The dossier carries no evidence_map, evidence_state or risk_register, so those did not feed the pack. Anything that changed after that date is not in it.
- Your message: hiring-manager conversation, 45 minutes, Thursday.

Searches sent (all three refused, none returned results):
- Quartzline company values: refused
- Quartzline interview process product manager: refused
- Quartzline partner API platform strategy news: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Every call was refused. Would have moved: a values cheat sheet and VAL questions keyed to published value names. H1 and H2 use persona stems instead |
| 2. Quartzline interview process, product manager | unavailable | Every call was refused. Would have moved: persona weights from documented rounds and whether a values round exists. Your own description of the round sets the structure instead |
| 3. Quartzline strategy and recent news | unavailable | Every call was refused. Would have moved: the CO bank and the grounding of the A-bank cases. The cases are generic and there is no CO question |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. Representative product manager JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → an interviewer read, persona weights adjusted to their public footprint, and a reverse question tied to their path
- The recruiter's guidance on the 45 minutes (focus areas, any exercise or deliverable) → coverage tuned to what will be asked, and a build section for any pre-declared deliverable
- Research that can run (the three Quartzline searches were refused) → values, loop structure and strategy, so the A-bank cases and the missing CO question become grounded rather than generic
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief and the interviewer's published themes
- Your own answers to the slots in F3, F4, F5 and F6, said outside a drill → those rows move from inferred or discovery to grounded and the matching questions get story maps
- A written agenda, notes or roadmap items traceable to the quarterly roadmap-input sessions, and a shareable excerpt of the playbook → raises the medium-confidence sentence toward high and removes the probe in A5, B1 and D3
- The raw CV behind the confirmed claims → richer fit snapshot rows and more story-mapped guidance
