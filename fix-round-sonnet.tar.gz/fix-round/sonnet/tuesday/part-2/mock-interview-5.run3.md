Web searches were refused and the report didn't come through, so I'm building the pack from your message and the recruiter's email alone. Writing it now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-5-denied-c2dca4c4/Kelverton-Rail_senior-partnerships-manager_interview_pack.md`.

I built it for a panel where Deepa acts as your future manager and Ross presses on commercials, using only your message and the recruiter's email. My web searches were refused. The market report also didn't reach me as readable text, so nothing about Kelverton beyond what you told me is researched. Questions that depend on the report (A5, E2) are labelled generic.

The pack has 18 questions. Prep order, in section 3: build the 15-minute POV first (section 5), then rehearse B1, the "you've never sold into rail" objection, which the pack names as your highest-ROI prep. Section 5 gives you three thesis options, each with a concession to state up front. It also gives a time-boxed spine that ends on what it means for operators, as the recruiter asked.

Say the word and I'll play Deepa and Ross: the 15-minute POV first, then Ross pushing on the £4M and the quota gap.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the report's main recommendations (and the JD and your CV, if you have them)? The report would re-ground A5 and section 5's differentiation, and I'll carry on without the JD and CV if you'd rather not.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Kelverton-Rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

## 1. Title block

- Role: Senior Partnerships Manager, Kelverton Rail
- Round: second round, one 60-minute panel on Tuesday
- Interviewers: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director), as the recruiter's email names them. No further profile was available
- Format, from the recruiter's email: the first 15 minutes are a short POV from you, no slides, "just talk us through it"; the rest is Q&A, and "Ross will push on commercials"
- Prep time: about four hours over the weekend
- Built from: your message and the recruiter's email quoted in it. The market report was not readable in this session, and web searches were refused (section 14)

## 2. How to use this pack, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview, not a question for this conversation. Bank IDs run A to E and then G, so that none collides with the fit-snapshot rows F1 to F5.

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment (no bank in this pack, see section 8) |
| EXP | Work-experience deep-dive: do your claims survive scrutiny |
| JD | Role-driven: can you do the job as described, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem, scored on structure |

## 3. Prep triage (four hours)

| Order | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 70 min | Build the 15-minute POV: pick one thesis, write its spine, say it aloud twice, time it, and end on what it means for operators | Section 5, A1 to A3 |
| 2 | 50 min | Rehearse the never-sold-into-rail objection until it is boring: the plain acknowledgment, the hold, the plan sentence | B1, B2, D1, D3 |
| 3 | 50 min | Answer the four slots on your £4M figure aloud, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours | C1, C2, D2 |
| 4 | 40 min | Practise structuring a live problem out loud, clarifying before answering | A4, C3 |
| 5 | 30 min | Pick three reverse questions and run your 90-second arc | Section 11, E1 |

Everything else is insurance.

## 4. Fit snapshot

No job description was supplied, so the requirements are the recruiter's own words, quoted, plus two role-family rows written as plain prose.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships at a rail software company, with nothing inspected behind it. The words stay at that scope: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." The POV itself is a live problem and needs no past claim. Answer slot: if the panel probes which parts of the channel work were yours to set, say which, in your own words; if there was no such step, or it was not yours, say so plainly and return to the quote |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Adjacent work that does not reach the requirement: the quote says bus and light rail network planning in consulting, and the pack's observation is that it does not say train operating companies or time on an operator's side. Words: "I spent five years in transport consulting, on bus and light rail network planning." "From the other side" is your phrase; if you use it, say in plain terms which side you mean, never as having worked inside an operator |
| F3 | "Ross will push on commercials" — recruiter's email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | presentation | The quote already reaches commercial results in other terms, and the words stay in its terms: "I took it from 6 partners to 40, with roughly £4M of influenced revenue." Keep "influenced" and "roughly" on every telling. Answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly |
| F4 | Experience selling into rail operators (role-family row, no supplied JD line, unquoted) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then what you would learn first, said as a plan and never as a past. Never a claim to rail sales, and nothing added to make the gap feel smaller. Whether this role requires it is not in what was supplied |
| F5 | A direct revenue target attached to the role (role-family row, no supplied JD line, unquoted) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | You stated this absence. Words: "I've never carried a direct quota, only influenced revenue." Then how you would want a number agreed and checked, said as a plan. Whether this role carries a quota is not in the material, so the pack treats it as a likely probe from the recruiter's commercials line and not as a stated requirement |

## 5. Graded deliverable: the 15-minute POV (proposed, pending your approval)

The recruiter's two instructions: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it" and "Please land on what it means for the operators themselves". The close is the operators' outcome, so the talk ends there.

**Grounded facts you may build on**

| Row | Sentence from that row's evidence cell |
|---|---|
| F1 | "took it from 6 partners to 40" |
| F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" |

**Thesis options.** Each is a hypothesis to test, not a finding about Kelverton, and each carries a mandatory concession.

| Option | Thesis, stated as a hypothesis | Mandatory concession | Provenance |
|---|---|---|---|
| T1 | Go deeper with fewer operators before going wider | Depth means saying no or later to other operators, and without Kelverton's own partner data the choice is a hypothesis you would test early | [generic] |
| T2 | Agree one outcome per operator that the operator itself would use to judge the partnership | Outcomes differ by operator, so a single shared scorecard will not fit them all | [generic] |
| T3 | Use partners to reduce what an operator has to do to adopt the software | Your channel experience is in payments, so the transfer to rail is untested and you should say that | [inferred] derived from F1 |

**Differentiating from the report.** The strategy team's report went to the interviewers' own side and likely reached other candidates too, so reciting it scores as homework. Bring one item from it to prove grounding, then one divergence with reasons, then the anti-pick (A2): one thing you would deliberately not do in the 18 months, and what that choice costs.

**Spine, about 13 minutes, leaving a buffer inside the 15**

| Minutes | Beat |
|---|---|
| 1 | What you are assuming and what you would want to know first |
| 2 | Your thesis and the concession, stated up front |
| 5 | The 18 months in three phases of six months, with how you would measure each |
| 2 | The anti-pick and the main risk |
| 3 | Land on the operators: "In 18 months an operator working with us would be able to say ___, and it would cost them ___ less." Fill the blanks with an outcome from the report or your own view, not from this pack |

## 8. Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The POV itself, then live problems on operator partnerships, mainly from Deepa | Highest. The hiring-manager prior is Case/Strategist plus Skeptic, and the recruiter makes the POV the opening 15 minutes | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully; land on operators. Makes no claim about your past |
| Skeptic | Probes on never having sold into rail, no direct quota, and why rail-tech | High. Hiring-manager prior; F4 and F5 are the gaps you stated, and the rest of the hour is Q&A | Rehearse B1 until it is boring; bridge only from the F1 and F2 quotes at their own scope; calibrated candor over bluffing |
| Data-Driven Prober | Ross on the £4M | High. The recruiter says Ross will push on commercials, and F3 is the only commercial figure in the material | Know what you can and cannot say about how F3's figure was counted, and say plainly when you do not know; name the weakest assumption before he does |
| Pressure | Ross, time-boxing or challenging | Medium. An executive prior plus the word "push" in the email | Pause, restate, anchor in what you said, hold through two follow-ups, then concede specifically |
| Conversational | Opening minutes or any warm-up | Low. The email sets a fixed shape, a POV then Q&A, so little unstructured chat is signalled; casual questions are still scored | A 90-second arc built only from your quoted sentences; never "I think you've covered everything" at the end |
| Peer Evaluator | The seam between partnerships and commercial | Low. Nobody on the panel is a peer, but the panel pairs the two functions, so the seam is the collegial form of the commercials push | Propose seam principles rather than pretending to know their seam; offer what partnerships gives commercial |

Not banked: Values/Behavioral. No loop source names a values round, and the recruiter's email describes a single session of POV plus Q&A. No published values could be obtained, so section 10 is dropped. No interviewer profile was available, so section 7 is dropped.

## 9. Question banks

### A. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] | Build it in section 5. Structure: assumptions, objective, which operators first, the plan by phase, measures, risks, and last what it means for the operators. The question needs no claim about your past, so the guidance makes none | The recruiter set this as the opening 15 minutes, so it is graded, not a warm-up; F1 is the requirement. CASE delivery, JD content |
| A2 | "Which operators or segments would you deliberately not prioritise in the first 18 months?" | CASE | [generic] | The anti-pick from section 5: name one thing you would not do and why, hold it through one follow-up, then say what the choice costs. No claim about your past | Differentiates you from the shared report; F1 is the requirement. An anti-pick shows judgment where a shortlist shows homework |
| A3 | "What should an operator be able to say about working with us at the end of the 18 months?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The recruiter asked you to land here. Answer in the operator's terms first, then what Kelverton does differently. If you draw on your consulting years, keep the quote's scope: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: if asked what you saw operators need, say what you actually saw, in your own words; if you did not work on that, say so plainly and return to the structure | F2 is the evidence and the recruiter's explicit close. JD content, CASE delivery |
| A4 | "A partner operator tells you our scheduling software doesn't fit how their timetable team works, and the deal is stalling. What do you do first?" | CASE | [generic] | Clarify before answering: what does not fit, who owns it on their side, what a fix would take, who else is affected. Then objective, options, and what you would escalate, to whom and when. Challenge one premise respectfully. No claim about your past | Tests structure before answer on a problem set in the role; F2's operator focus |
| A5 | "What in our own strategy report would you push back on?" | CO | [generic] | I could not read the report, so this is a method. Bring one point you agree with to show grounding and one you would depart from, with reasons, in the report's own vocabulary. Never recite it | The one CO question the report makes likely. Generic because research could not run; pasting the report upgrades it |

### B. Skeptic (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail specifically. How would you handle that in this role?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | The highest-ROI rehearsal in this pack, because this objection will arrive in some form. Four levels. One: state the limit first and plainly, "I haven't sold into rail specifically." Two, if pressed on the operator side: hold on "I spent five years in transport consulting, on bus and light rail network planning", and do not widen it to train operating companies or time inside an operator. Three, if pressed on partnerships: "I took it from 6 partners to 40", with nothing added. Four: one plan sentence, said as future, on what you would learn first, in your own words | F4 is the biggest stated gap and the one a future manager must get past. JD because it scores fit to the role |
| B2 | "Why rail-tech, and why now?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | Your material carries two threads, transport consulting and partnerships, and the connection and the timing are yours to state. Answer slot: say the true reason in your own words; if part of it is simply that this role appeared, say so plainly. If no reason comes to mind that you can stand behind, say so plainly, then say what you do know about the role | Motivation consistency, F1 and F2. The pack supplies no reason because none was given |
| B3 | "What from your payments ISV channel transfers to operator partnerships, and what doesn't?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40" | Say what carries across only in the quotes' terms: the channel, and the growth from 6 partners to 40. Offer the "what doesn't" half before being asked. Answer slot: if you can say how an operator relationship differs from an ISV one in your experience, say it; if you have not seen enough to say, say so plainly and name what you would check | F1 is the transfer question. EXP content, JD delivery |

### C. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | The four slots, each in your own words: how it was counted; what it is sensitive to; the assumption you would defend least, named before he does; which part was yours. Keep "influenced" and "roughly" every time. Answer slot: if you do not know how it was counted, say so plainly. The pack supplies no method | F3, the headline number and the likeliest commercial target. EXP |
| C2 | "Of that £4M, which part would you say was yours?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: if you can separate your part, say how, in your own words; if you cannot separate it from the rest, say so plainly and return to the quote. Do not swap "influenced" for a stronger verb | F3, attribution probe. EXP |
| C3 | "Before you proposed terms to an operator, what would you need to know?" | CASE | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Structure only: who decides on their side, what they get, how they would judge success, what Kelverton gives up, what you would not agree. Answer slot: if you have set terms with partners in a past role, say so and say what was yours; if not, say so plainly, then work it as a structure. If asked about quotas, "I've never carried a direct quota, only influenced revenue." | The recruiter's commercials line, F3 and F5. CASE delivery |

### D. Pressure (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "took it from 6 partners to 40"; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause and restate. Hold on two sentences only: "I spent five years in transport consulting, on bus and light rail network planning" and "I took it from 6 partners to 40." Return to them through two follow-ups rather than adding to them. Then concede: "I haven't sold into rail specifically." | F1, F2 and F4 together. Time-boxed to test composure |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause, restate, anchor in the word you used: influenced. Answer slot: say which part was yours if you can; if you cannot separate it, or it was not yours to claim, say so plainly. Concede the assumption you would defend least, and do not fold on the figure itself | F3. The stem is the Pressure persona's standard attribution probe |
| D3 | "You've never carried a direct quota. If this role came with one, what changes?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | The plain acknowledgment first: "I've never carried a direct quota, only influenced revenue." Then, as a plan and not a past, how you would want a number agreed and checked, in your own words. Do not claim to have carried a number | F5 and the recruiter's commercials line |

### E. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc using only the beats your quotes state: transport consulting on bus and light rail network planning, then partnerships, the last four years on the ISV channel at a payments company, growing from 6 partners to 40. Answer slot: your material does not describe the first five of the nine partnership years; name them in your own words if they belong, or leave them out. Why this role is yours to say (B2) | The biography question is scored; F1 and F2 |
| E2 | "What are you actually looking at in rail-tech at the moment?" | CO | [generic] | Pick one thing you have actually read or looked at and say why it caught your attention. If nothing comes to mind, say so plainly, then name the one point in the strategy report you would most want to ask about | A casual-register question about the sector, still scored; generic because no research ran |

### G. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where's the seam between partnerships and commercial when an operator deal needs terms, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not facts about their organisation: who owns the operator relationship, who owns the terms, how a disagreement escalates. Ask where their seam is rather than guessing. Answer slot: if you have a disagreement story with a commercial counterpart, tell it as it actually went; if none comes to mind, say so plainly and describe how you would handle it | The panel pairs the two functions, so the seam is the likeliest collegial probe |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time credit for a result was shared across teams. It needs a named share and nobody surprised at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer persona's credit probe; F3's figure is the influenced kind, which makes the topic likely |

### Requirement coverage

| Requirement | Questions |
|---|---|
| POV on operator partnerships over 18 months (F1) | A1, A2, A5, B3, E1 |
| Land on what it means for operators (F2) | A3, A4, D1, E1 |
| Commercials push (F3) | C1, C2, C3, D2, G2 |
| Selling into rail (F4) | B1, D1 |
| A direct revenue target (F5) | C3, D3 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would success look like at twelve months for the person in this seat, and who judges it?" | Makes the measure explicit, and answers your own concern about quota versus influence |
| R2 | "Where does partnerships stop and commercial start when an operator deal needs terms?" | Puts the seam question to both interviewers at once |
| R3 | "How are operator partnerships measured today: influenced, sourced, or both?" | Signals you think in measures, and shows whether F5 matters in practice |
| R4 | "Which part of last quarter's strategy report is already changing what the partnerships team does?" | Shows you read it as a working document, not a source to recite |
| R5 | "What would you want a new person to have understood by the end of their first month?" | Turns the gap you named into a ramp conversation |
| R6 | "Which operator relationships do you consider healthiest, and what makes them so?" | Moves the conversation to operators, the close the recruiter asked for |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran or owned operator partnerships | Inflated form of F1 | F1's quote at its own scope: the material says an ISV channel at a payments company, not operator partnerships. B3 stays inside the channel |
| Delivered, closed or owned £4M of revenue | Inflated form of F3 | F3's quote with "influenced" and "roughly" kept. The limit is the pack's observation, not words for you |
| Worked inside a train operating company, or knows operations from the inside | Inflated form of F2 (relationship drift in "from the other side") | F2's quote at its own scope: bus and light rail network planning in consulting |
| Sold into rail | Negative you stated, F4 | The plain acknowledgment: "I haven't sold into rail specifically." No slot |
| Carried a direct quota | Negative you stated, F5 | The plain acknowledgment: "I've never carried a direct quota, only influenced revenue." No slot |

## 14. Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report was attached to that email but was not in this session as text, so nothing from it is used. No `tuesday-dossier.md` was present.

Searches sent, each refused by the host:

1. "Kelverton Rail company values" — refused
2. "Kelverton Rail interview process partnerships" — refused
3. "Kelverton Rail strategy train operating companies scheduling software news" — refused
4. "Deepa VP Partnerships Kelverton Rail" — refused
5. "Senior Partnerships Manager rail technology scheduling software job description" — refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values cheat sheet (section 10), only if a loop source documented a values round |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Would have checked the loop; the recruiter's email already fixes this session's shape, so persona weights rest on it |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have grounded A5 and E2 and section 5's differentiation; they are labelled generic instead |
| 4. `Deepa Kelverton Rail` | unavailable | Would have fed an interviewer read and a reverse question tied to a career path; both are dropped |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have turned F4 and F5 from role-family rows into quoted requirements |

## 15. Upgrade menu

- The market report's text, or its main recommendations → A5, E2 and section 5's differentiation become grounded in the report's own vocabulary
- The job description → F4 and F5 become quoted requirements, any gate terms such as location or travel surface, and the JD-tagged questions are re-checked against its list
- Your CV → fit-snapshot rows quote your CV, and F1 can draw on the first five of your nine partnership years, which your message does not describe
- Search permission, or Deepa's and Ross's surnames → an interviewer read, a reverse question tied to a career path, and rows 1 to 5 of the research table. A deeper pass, up to 6 more searches and 2 more fetches and several more minutes, runs only if search is allowed and you ask for it
- Your own answers to the slots on F3 (how the £4M was counted, what it is sensitive to, your weakest assumption, which part was yours) → C1, C2 and D2 become story-mapped instead of slot-shaped
- A `tuesday-dossier.md` from an earlier fit check, if you have one → verified evidence and any prohibited claims carried in; the pack works without it
