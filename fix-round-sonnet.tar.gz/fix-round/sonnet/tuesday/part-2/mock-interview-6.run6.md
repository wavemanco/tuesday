I've read the prep playbook and am now running the budgeted company research on Larkfield Systems: values, interview process, strategy, and a representative JD.
Web search was refused all four times, so the pack rests on your message alone and company facts are labelled generic. I'm building the three-round loop pack now.
The pack covers all three rounds and is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-6-denied-906aa1c6/larkfield_systems_engineering_manager_interview_pack.md`. I built it from your message alone. The web searches were refused, so there are no Larkfield facts in it, and its company-level questions (strategy, cases) are labelled generic.

- **Biggest exposure:** the step from team lead of 6 to two squads, with no managing managers and no hardware-adjacent roadmap behind you. Question 1A1 is the deepest rehearsal. It comes back as 3F1 and 3G4 in the VP round, so one well-drilled answer covers all three rounds.
- **Your reliability quarter:** this is your strongest story, and it will be probed. Your sentence says the on-call burden dropped 60% *after* you pushed the quarter through, not *because* of it. 1C1 and 3F2 rehearse that distinction, and which parts were yours.
- **Hiring:** "about 40 interviews" is ambiguous. It could be interviews you conducted or the loop's total. Take the smaller reading until you've said which (2C1).
- **Weights:** Tuesday leans on the Skeptic and Case personas, Thursday on the Peer persona, and Monday on Values.
- **Monday cheat sheet:** the values cheat sheet is dropped, because Larkfield's published values aren't in hand and I won't write them from memory.

Say the word and I'll run a live drill as the Skeptic on 1A1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you'd like.

1. Can you paste the full job description and your CV? The pack stands without them, but they would firm up most of the rows.
2. Are the two staff engineers people who'd sit on the squads you'd lead, or on other teams? I assumed other teams, as peers; if they'd be your reports, the Thursday bank gets reweighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_systems_engineering_manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Rounds: Round 1, Tuesday, 45 min, Director of Engineering (hiring manager, would-be boss). Round 2, the Thursday after, 60 min, panel of two staff engineers and a product manager. Round 3, the following Monday, 30 min, VP Engineering ("values and leadership philosophy", per the recruiter).

Built from your message only. No web research ran (see Sources), so nothing here claims a fact about Larkfield beyond what you told me. Questions about the company's strategy are generic problems, labelled that way.

## How to use this pack

Personas describe how a question is asked. Types describe what is scored. Answer guidance is scaffolding for a spoken answer, not a script: say only what you actually did, in your own words. An answer slot is an instruction for the interview: answer it from your real experience, or say plainly that the step was not yours or did not exist.

| Type tag | Meaning |
|---|---|
| VAL | Behavioral and values alignment: does past behavior show what the interviewer says they value |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually you |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack, because research could not run) |
| CASE | Live problem from the role, scored on structure and reasoning |

Question IDs: round number, persona letter, then a count. Persona letters: A Skeptic, B Case/Strategist, C Data-Driven Prober, D Conversational, E Peer Evaluator, F Pressure, G Values/Behavioral.

## Prep triage

- Before Round 1: rehearse 1A1 and 1A2 out loud until they are boring, then 1C1 and 1C2. These are the highest-ROI items in the pack.
- Between Round 1 and Round 2: 2E1, 2C1, 2G1. Reread the answer slots in F3, F4 and F7 and decide your true answers.
- Between Round 2 and Round 3: 3F1, 3F2, 3G1, 3G4. The same limits from Round 1 return here at a higher altitude.
- Everything else is insurance.

The single most predictable objection is the step from team lead of 6 toward leading two squads without having managed managers or owned a hardware-adjacent roadmap (F1, F6). 1A1 is its deepest rehearsal, and it reappears as 3F1 and 3G4.

## Fit snapshot (shared across all three rounds)

The role lines below are quoted from the role description in your message, which I treated as the supplied JD. No full JD text was given.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (leadership of the squads) — role description in your message | "3 as a team lead of 6" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | Your material says three years as a team lead of 6, and a limit you stated. It does not say what the people side of that lead role involved, and it shows one team, not two squads. Words: "three years as a team lead of 6" and "I've never managed managers." Answer slot: the role's two squads and 11 engineers make a probe on what changes beyond one team likely. Say what you would keep and what you would change, in your own words; if you have not worked that out, say so plainly and say what you would want to find out first |
| F2 | "Lead two squads building device-management services" (the device-management domain) — role description in your message | "currently at a payments company" — your message | low | [inferred] | discovery | Your message names the payments company and says nothing about devices, so this row is open, not a limit you have stated. Answer slot: if any of your work dealt with devices, say which and what your part was, in your own words; if none did, or it was not yours, say so plainly and say what you would learn first |
| F3 | "own delivery, hiring and growth for 11 engineers" (delivery) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The words stay at the quote: you pushed a reliability quarter through against roadmap pressure, and the on-call burden dropped 60% after it. The quote says "after", not "because", and says nothing on delivery across two squads. Answer slot: expect a probe on how you would decide between roadmap and reliability work across two squads. If you have weighed a trade like that, say what you weighed and what you decided; if you have not, or it was not yours to decide, say so plainly and stay with the quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" (hiring) — role description in your message | "I run our hiring loop for backend roles" — your message; "about 40 interviews last year" — your message | medium | [grounded] | none | Lead in the quote's terms: you run the hiring loop for backend roles. The quote does not say whether the 40 are interviews you conducted or the loop's total, so say it the smaller way until you have said which. Answer slot: the role's "hiring" line makes a probe on who decided offers or headcount likely. If those were yours to decide, say how, in your own words; if not, or there was no such step, say so plainly and stay with the loop you run |
| F5 | "own delivery, hiring and growth for 11 engineers" (growth) — role description in your message | none given | none | [grounded] | discovery | Your material is silent here, so this is an open row, not a stated limit. Answer slot: the role's "growth" line makes a probe likely. If you have helped someone on your team grow, say what you did and what changed for them, in your own words; if you have not, or it was not yours to do, say so plainly and say what you would do first |
| F6 | "partner with hardware and product on roadmap" (hardware) — role description in your message | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | Words you have stated: "I've never owned a hardware-adjacent roadmap." Your message says nothing either way about partnering with a hardware team, which is what the role line asks. Answer slot: if you have worked alongside or depended on a hardware team, say how and what your part was; if not, say so plainly and say what you would learn first |
| F7 | "partner with hardware and product on roadmap" (product) — role description in your message | "pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote shows a tension with the roadmap, and not who held the other side of it. Answer slot: if the pressure came from a product partner, say how you handled it and what your part was; if it did not, or it was not a negotiation, say so plainly and stay with what the quote says |

## Persona weights per round

### Round 1, Tuesday: Director of Engineering (hiring manager, would-be boss)

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic (A) | Quiet probing of the step up and the missing hardware and people-layer experience | High, 4 questions | Hiring-manager prior: they are buying capability and de-risking gaps; F1 and F6 are the biggest open limits | Rehearse the single most predictable objection until it is boring; calibrated candor over bluffing |
| Case/Strategist (B) | Live problems from the role: plan this, diagnose that | Mid, 3 questions | Hiring-manager prior: expect problems on their actual roadmap; unadjusted by the loop | Clarify, objective, options, decision, metrics, risks; think aloud; challenge one premise |
| Data-Driven Prober (C) | Line-by-line probing of your numbers | Low, 2 questions | The 60% and the 40 interviews are the quantified claims; no signal that this interviewer is metric-led | Know how each figure was counted; name the assumption you would defend least before they do |
| Conversational (D) | Opening biography question | Low, 1 question | Every 45-minute round opens somewhere friendly; the risk is treating it as unscored | A short arc built only from beats you can stand behind |

### Round 2, Thursday: panel (two staff engineers, one product manager)

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator (E) | Seam-splitting, what would you need from us, credit and disagreement | High, 4 questions | Panel rule: blend the top two personas of each member's relationship. I assumed the staff engineers are peers, which you can correct; the product manager sits across the seam you would partner on | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober (C) | Technical and numeric depth on your claims | Mid, 3 questions | Staff engineers as peers: Prober is their second persona | Know what you can and cannot say about how each figure was counted |
| Values/Behavioral (G) | Scenario probes, story-shaped answers | Low, 2 questions | Product manager as cross-functional: Values/Behavioral is their first persona | "We" for context, "I" for contribution; where no story comes to mind, say so |
| Conversational (D) | Friendly question about what interests you | Low, 1 question | Cross-functional prior; casual questions are still scored | Treat it as scored |

### Round 3, Monday: VP Engineering ("values and leadership philosophy")

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral (G) | Philosophy and scenario questions about how you lead | High, 4 questions | The recruiter's description names the round as values and leadership philosophy; that detects a values-style round | Stories only where your sentences carry one; philosophy stated in your own words |
| Pressure (F) | Short time-boxed challenges to your claim | Low, 2 questions | Skip-level prior; altitude and composure | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |
| Case/Strategist (B) | Altitude questions about running the org | Low, 2 questions | Skip-level prior; generic because research could not ground company strategy | Clarify before you structure |
| Conversational (D) | Short personal question | Low, 1 question | A 30-minute round still opens with one | Keep it brief |

## Round 1 question bank, Tuesday (Director of Engineering)

### A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers"; "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Pick the limit you would name first and say it in your own words from the quotes: "I've never managed managers." or "I've never owned a hardware-adjacent roadmap." Then say what you would do about it as a plan, not a past: who you would sit with and what you would learn in the first weeks, chosen by you, since the pack does not know Larkfield's setup. Rehearse three levels of follow-up: which limit matters more to the squads, how you would close it, and what you would do if it did not close in time. At each level add no experience the quotes do not carry, and concede the limit specifically rather than softening it | F1 and F6 carry the stated limits, so this question arrives in some form; JD because it scores the role's stated requirements |
| 1A2 | "This role partners with hardware on roadmap, and you haven't owned a hardware-adjacent roadmap. How would you approach that partnership?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Say the limit first: "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked alongside or depended on a hardware team, say how and what your part was, in your own words; if not, say so plainly. Then say, as intent, how you would learn the hardware team's constraints before committing the squads to anything | F6 is the open row for the hardware half of the role line; the premise is your own stated limit, so it is asked directly |
| 1A3 | "You've been a team lead of 6. This role has 11 engineers across two squads. What changes?" | JD | [grounded] "3 as a team lead of 6"; "I've never managed managers" | Start with the quote's words: three years as a team lead of 6. Answer slot: say what you would keep and what you would change at 11 across two squads, in your own words; if you have not worked that out yet, say so plainly and say what you would ask first. Do not describe the work of the lead role beyond what you can say you did | F1 is the evidence for the leadership line and the row the Director will test most directly |
| 1A4 | "Why move from a payments company to industrial IoT, and why now?" | JD | [grounded] "currently at a payments company"; "9 years engineering" | No quote carries your reason, so the pack supplies none. Name the real reason for the move and the reason for now; it must survive a second follow-up. If you do not yet have one that does, say so plainly, then give what in the role description draws you, in its own words | F2 is open on the domain, so motivation consistency gets cross-examined here; JD because the question scores the role |

### B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1B1 | "Two squads, one quarter. Product wants a new device-management capability and the on-call load is heavy. How do you decide what the squads do" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: what each option costs, who is affected, what product needs by when. Then state the objective, name two or three options, decide, say what you would tell product, and name the metric and the main risk. Challenge one premise respectfully | F3's requirement asked as a live decision; generic because it is a pattern for the problem, not a fact about Larkfield |
| 1B2 | "A hardware release slips six weeks and both squads' plans depend on it. Walk me through your first day and your first week." | CASE | [generic] | No past claimed. Structure: what you need to know first, who you talk to and in what order, what you protect, what you re-plan, what you say to engineers. Think aloud and state your assumptions | F6's requirement as a live problem, asked as a decision rather than a record |
| 1B3 | "Sketch your first 90 days leading two squads you haven't met. What do you need to know first?" | CASE | [generic] | Persona stem, no past claimed. Clarify, then objective, then a sequence: listen, learn the delivery picture, meet hardware and product, then change things. The plan is intent; pick the steps you would really take | F1 and F3 together: how you would enter the role |

### C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1C1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-map at the quote's scope: you pushed the reliability quarter through, and the on-call burden dropped 60% after it. Answer slot, four parts, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly. The quote says "after", so be ready for the question of whether that also means "because", and answer it from what you know | F3 is the headline metric, and quantified claims are where probers press; EXP because it tests attribution |
| 1C2 | "You pushed that reliability quarter through against roadmap pressure. Where did the pressure come from, and how did you handle it?" | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" | Beats the sentence states: the reliability quarter, you pushed it through, against roadmap pressure. Answer slot: where the pressure came from and what you did about it are not in your material. Say them in your own words if you have them; if there was no one to convince, or it was not a negotiation, say so plainly and stay with what the quote says | F7 is where this quote meets the product partnership; the premise is the quote's own |

### D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering"; "3 as a team lead of 6"; "currently at a payments company" | A 90-second arc with only the beats the quotes state: nine years in engineering, three as a team lead of 6, now at a payments company. You may add the reliability quarter you pushed through against roadmap pressure, at that scope. Why you are here is yours to say; the pack does not supply it. Add no beat you cannot back under a follow-up | F1 and F2 set the arc; EXP because an opener is where later probes are seeded |

### Reverse questions, Round 1

| # | Question for the Director | Why it lands |
|---|---|---|
| R1.1 | "What would you want the two squads to have delivered or changed by the end of my first six months?" | Turns a hiring manager's picture into success criteria you can plan against |
| R1.2 | "How do hardware timelines and software roadmaps get reconciled today, and where does that get hard?" | Shows you intend to learn the hardware side, which is the limit in F6, and gets you the real process |
| R1.3 | "How are the 11 engineers split between the squads, and what leadership structure already exists inside them?" | Settles whether managing managers is in scope at all, the biggest open question behind F1 |
| R1.4 | "Which is the harder problem for these squads right now: delivery, hiring or growth?" | Tells you which of the three role lines to emphasise in Rounds 2 and 3 |
| R1.5 | "What does your support for a new manager look like in the first 90 days?" | Tests the boss relationship you would be entering |

## Round 2 question bank, Thursday (panel)

### E: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2E1 | "Our teams sit side by side. Where's the seam between engineering and product on the roadmap, and what happens when we disagree?" | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" | Propose seam principles as intent, not a claim to know Larkfield's seam. The one grounded story is the quote at its scope. Answer slot: if the roadmap pressure came from a product partner, say how you handled the disagreement and what your part was; if it did not, or there was no disagreement as such, say so plainly and stay with what the quote says | F7 is the row where your material meets product partnership; JD because it scores the role's partner-with-product line |
| 2E2 | "What would you need from staff engineers in your first month?" | JD | [generic] | No past claimed. Use reciprocity framing: what you would bring them, then what you would need, said as intent. Do not pretend to know their current seam | Peer persona stem; generic because it is a pattern for the question |
| 2E3 | "How do you handle credit when work spans teams?" | VAL | [generic] | No quote carries a credit story, so this is a selection scaffold. Pick an instance with a named team, a moment where credit could have gone either way, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer persona stem; no row carries it, so the scaffold ends in its honest branch |
| 2E4 | "A staff engineer disagrees with your call on a technical trade-off. What do you do" | CASE | [generic] | No past claimed. Structure: what you ask first, what you hold and what you give, how the decision gets recorded, how the relationship stays intact. State which part of the call is yours to make | Disagreement style with equals, asked as a live decision |

### C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "Where does 'about 40 interviews' come from: interviews you ran, or interviews through the loop you run?" | EXP | [grounded] "I run our hiring loop for backend roles"; "about 40 interviews last year" | Lead with the quote's words: you run the hiring loop for backend roles, and about 40 interviews last year. Answer slot: how the 40 was counted; whether you sat in them or ran the loop; the assumption you would defend least. If the 40 is the loop's total and not your own, say so plainly. Take the smaller reading until you have said which | F4 holds the figure, and the quote leaves the reading open; EXP because it tests attribution |
| 2C2 | "What would you change about your hiring loop?" | EXP | [grounded] "I run our hiring loop for backend roles" | This is an opinion, not a past claim, so the change is yours to name and the pack names none. If you have no change in mind, say so plainly, then say what you would ask these staff engineers about how they would change theirs | F4 again, from the technical side of the panel |
| 2C3 | "This role owns delivery for two squads. How do you know a squad is healthy, and which signals do you read?" | JD | [generic] | Answer slot: if you read particular signals on your own team today, name them in your own words; if you do not have a set, say so plainly and say what you would look at first and why. No signal is supplied by the pack | F3's delivery line; the premise is the role's, and the guidance does not adopt a practice for you |

### G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Persona stem. The nearest sentence in your material is the quote, and it does not say whether leadership was involved. Answer slot: if the pressure involved leadership, say who and what you said, in your own words; if it did not, say so plainly, and use a different instance or say none comes to mind. Choose a story in which the hard truth actually landed | F7 is the nearest row; whether it fits is open |
| 2G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Persona stem; no quote carries it, so this is a selection scaffold. Pick an instance with a named customer need, the internal metric it cost, and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | No row carries a customer story, and the product manager is the likeliest asker |

### D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2D1 | "What are you actually looking forward to working on in device management?" | JD | [generic] | No past claimed. Say what genuinely draws you; the pack cannot supply it. Answer slot: if you have tinkered with something relevant, say what; if not, say so plainly and say what you would learn first | F2's open domain row, asked casually; casual questions are still scored |

### Reverse questions, Round 2

| # | Question for the panel | Why it lands |
|---|---|---|
| R2.1 | To the staff engineers: "What could a new manager do in their first month that would genuinely help your work?" | The reciprocity question for peers; it shifts the panel from judging to advising |
| R2.2 | To the staff engineers: "What is one thing about how the squads work that you would want me to leave alone?" | Signals you will not arrive to re-organise, and surfaces what is valued |
| R2.3 | To the staff engineers: "How do the squads handle on-call and reliability work alongside roadmap work today?" | Connects to F3's territory without claiming anything about Larkfield |
| R2.4 | To the product manager: "How does roadmap input from product reach the squads today, and where does it get contested?" | Maps the seam you would partner on, for F7 |
| R2.5 | To the product manager: "What would a good partnership with me look like in the first quarter?" | Invites them to define success and shows you plan to partner, not just receive |

## Round 3 question bank, Monday (VP Engineering)

### G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3G1 | "What's your philosophy on leading engineers? When do you hold the line and when do you give way?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | The philosophy is yours to state in your own words; the pack supplies none. If you anchor it in a story, the only one your material carries is the quote at its scope. Answer slot: say when you would not have pushed, in your own words; if you cannot name such a case, say so plainly | The recruiter named the round as values and leadership philosophy, which raises this theme; F3 is the nearest evidence |
| 3G2 | "Tell me about a time you helped someone on your team grow." | VAL | [generic] | No quote carries a growth story, so this is a selection scaffold: a named person's starting point, what you did, what changed for them, and which part was theirs and which yours. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F5 is open; the role's growth line raises the theme |
| 3G3 | "How do you think about hiring? What are you looking for in an engineer, and what do you screen out?" | VAL | [grounded] "I run our hiring loop for backend roles"; "about 40 interviews last year" | State your criteria in your own words; the pack names none. Lead with the quote: you run the hiring loop for backend roles. Answer slot: if you set the criteria for that loop, say so; if you inherited them or share them, say so plainly | F4 is the strongest evidence in the snapshot; a VP will test whether the philosophy behind it is yours |
| 3G4 | "This role is a step from a team of 6 to 11 engineers across two squads. What do you expect to be hardest?" | JD | [grounded] "3 as a team lead of 6"; "I've never managed managers" | Say the limit in the quote's words: "I've never managed managers." Then name what you expect to be hardest, in your own words, and what you would do first, as a plan. Answer slot: if you have already done any part of this step at your current team, say which; if not, say so plainly | F1 again, at VP altitude |

### F: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3F1 | "Sixty seconds: why you, given you haven't managed managers?" | EXP | [grounded] "9 years engineering"; "3 as a team lead of 6"; "I've never managed managers"; "I run our hiring loop for backend roles" | Hold-then-concede. Hold only what the quotes carry: nine years in engineering, three as a team lead of 6, and you run the hiring loop for backend roles. Concede specifically: "I've never managed managers." Pause before you answer, restate the question, hold through two follow-ups, and do not fold on the claims above or add to them | The persona stem, aimed at F1's stated limit |
| 3F2 | "That reliability result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Use "we" for context and "I" for contribution. The quote gives you pushing the quarter through; it says the burden dropped after. Answer slot: which parts were yours and which were the team's, in your own words; if you do not know how much of the drop each part accounts for, say so plainly. Hold through two follow-ups and concede what you do not know | F3 is the claim a pressure interviewer tests; EXP because it is an attribution probe |

### B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3B1 | "You inherit two squads whose roadmap depends on hardware commitments. How do you decide what to protect" | CASE | [generic] | No past claimed. Clarify what is committed and to whom, state the objective, set criteria for protecting work, decide, and say what you would tell your Director and the hardware partner. Name the main risk | F6's requirement at VP altitude; generic because research could not ground company strategy |
| 3B2 | "In a year, how would I know you were a good hire for this org" | CASE | [generic] | No past claimed. Name two or three signals you would want judged on, across delivery, hiring and growth, and say how you would check them yourself before they are checked for you | Covers the role's three responsibilities at once |

### D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3D1 | "What do you want your engineers to say about working for you?" | VAL | [generic] | No past claimed. Say what you want in your own words; the pack supplies none. If you want to anchor it, the only story your material carries is the quote at its scope | A leadership-philosophy opener for a short round |

### Reverse questions, Round 3

| # | Question for the VP | Why it lands |
|---|---|---|
| R3.1 | "What does that leadership philosophy look like in practice here: which behaviours get promoted?" | Turns a values round into evidence you can check and shows you take the company's version seriously |
| R3.2 | "What do you expect the hardest decision of this role to be in the first year?" | Reveals what the VP is actually worried about |
| R3.3 | "How do you want engineering managers to disagree with you?" | Tests the working relationship at the altitude where it matters |
| R3.4 | "How have you seen managers grow into leading a larger group, and what helped?" | Raises the step-up honestly and invites coaching rather than judgment |
| R3.5 | "Where do you want device management to be in two years?" | A strategy question that does not need me to know the company's plan |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services: leadership (F1) | 1A1, 1A3, 1B3, 3F1, 3G4 |
| Lead two squads building device-management services: the domain (F2) | 1A4, 1D1, 2D1 |
| Own delivery for 11 engineers (F3) | 1B1, 1B3, 1C1, 1C2, 2C3, 3F2, 3G1 |
| Own hiring for 11 engineers (F4) | 2C1, 2C2, 3G3 |
| Own growth for 11 engineers (F5) | 3G2, 3B2 |
| Partner with hardware on roadmap (F6) | 1A1, 1A2, 1B2, 3B1 |
| Partner with product on roadmap (F7) | 1C2, 2E1, 2G1, 2G2 |

## Values and principles cheat sheet

Dropped. A values-style round is detected for Round 3 (the recruiter's own words name it), but Larkfield's published values are not in hand, and I will not write value names from memory.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having managed managers | Negative you stated, F1 | Your words: "I've never managed managers." No slot |
| Having owned a hardware-adjacent roadmap | Negative you stated, F6 | Your words: "I've never owned a hardware-adjacent roadmap." The slot in F6 asks only about working alongside hardware |
| Managed a team of 6 engineers | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation: your material says team lead, not manager, and shows one team, not two squads |
| Owned delivery across two squads | Inflated form of F1 and F3 | The quarter at its own scope, F3's quote. The material shows one team's reliability quarter |
| Caused the 60% drop on your own | Inflated form of F3 | The quote's "after", at its own scope. 1C1 and 3F2 slots ask only what was counted and which part was yours |
| Owned hiring end to end, including headcount and offers | Inflated form of F4 | F4's quote: you run the hiring loop for backend roles. The slot asks only whether those decisions were yours |

## Sources

Provided documents: your message (the role description, the three rounds with who runs each, and your background). No dossier was present. No links were provided.

Searches sent, all refused by the host before returning anything:

- "Larkfield Systems industrial IoT company values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems device management strategy news": refused
- "Engineering Manager device management platform industrial IoT job description": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have fed the values cheat sheet for Round 3; the section is dropped and VAL questions are generic or built on the recruiter's own words |
| 2. `{company} interview process {role family}` | unavailable | Would have added documented round content to the loop you described; weights rest on relationship priors and your own account of the loop |
| 3. `{company} strategy` / recent news | unavailable | Would have grounded CO and CASE questions; they are generic, and the pack has no CO bank |
| 4. `{interviewer name} {company}` | n/a | No interviewer names were given, so there was no query to form; the interviewer read is absent |
| 5. representative `{role title}` JD | unavailable | You supplied a role summary and not a full JD; a representative posting would have added inferred requirement rows |

## Upgrade menu

- The full JD text: the role lines in F1 to F7 are quoted from your summary; the full posting may add requirements and turn inferred rows grounded
- Your CV: evidence beyond your message could upgrade F2, F5 and F7, and may carry artifacts that raise a medium row
- Your answers to the slots in F1, F2, F3, F4, F5, F6 and F7: each answer is new quoted material that regenerates the rows it touches
- Whether the two staff engineers would be on the squads you would lead or on other teams: reweights the Round 2 bank
- Interviewer names (all three rounds): an interviewer read from their public footprint, tuned persona weights, and reverse questions tied to their paths
- Permission to run web searches: Larkfield's published values (the Round 3 cheat sheet), documented interview rounds, and current strategy (grounded CO and CASE questions). A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief
- The recruiter's prep notes for the panel and the VP round: stated focus areas and any announced deliverable, in one email
- A `tuesday-dossier.md` from an earlier fit review: verified evidence and prohibited claims in one file, never a prerequisite
