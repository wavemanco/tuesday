I've read the playbook and the dossier handoff rules. Next I'm running the default research pass on Quartzline: its values, its interview process, and recent strategy. Then I'll build the pack.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-4-denied-a34e18a4/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for the hiring-manager round you described, from your dossier's `handoff_to_mock_interview` and `role_profile` sections.

- **No company research:** web search wasn't permitted this session, so nothing in the pack comes from Quartzline's own material. The case questions are generic, and the pack has no company-strategy or values questions.
- **Weighting:** Case/Strategist and Skeptic are weighted highest, which is the normal pattern for a hiring manager.
- **Most important rehearsal:** B1 is the underwriter's objection ("never held the PM title or owned a roadmap — why you over a PM with three years?"). The guidance is: concede first in the dossier's own wording, state the integration work at the scope of your quotes, name the limit before they do, then give a ramp plan. F1 is the same question under a 60-second clock.
- **What the pack won't coach:** the three claims in your dossier's `prohibited_claims` are barred, plus two I added: shipping an API product, and deciding roadmap content through the roadmap-input sessions. The roadmap gap gets a plain acknowledgment and a plan, with no bridge.
- **Where I went beyond the dossier:** the dossier doesn't flag R2 (shipped API or platform products) as weak. I graded it as adjacent work that doesn't reach the requirement. The words stay at "led 30+ integrations", and there's an answer slot on go-live. This is my reading, so tell me if the underwriter had more evidence behind it.
- **Your homework:** a few answer slots (F3 to F6, plus C1's counting question) can only be answered by you. Your answers upgrade those rows.

I can run a live drill, playing the Skeptic on B1 with follow-ups and then feedback.

I can also save an updated `tuesday-dossier.md` recording the gaps this prep exposed (the R2 reading, the slots with no story yet) to carry into later sessions.

I can convert the pack to a Word document if you want one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs, Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. **Interviewer:** the hiring manager, name not given. **Built from:** your note about the round, and the underwriting dossier (version 1.1). No company research ran, so everything about Quartzline itself is labeled `[generic]` or absent; see Sources.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview, not a question for you now.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (none read for this pack, so no VAL questions) |
| EXP | Whether the claims about your experience survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy (none in this pack, since no research ran) |
| CASE | Structure and reasoning on a live problem from the role |

The highest-ROI rehearsal is B1. The underwriter named that objection, and it will arrive in some form.

## Prep triage

Sized to Thursday; your available hours were not stated.

1. B1 and F1: say the concession, the quoted work and the limit aloud until they are boring.
2. C1 and C2: the two claims the interviewer can probe line by line.
3. The answer slots in F3 to F6: decide which branch is true for you, in your own words, and write one line each.
4. Reverse questions 1 and 2: decision rights and the adoption baseline.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (R1, must_have) — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's framing is adjacent work, never product management experience. The words stay at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I wrote the internal integration playbook my team uses." The limit is the pack's observation: your material shows integration leadership, not a product manager title or role. The sourced plain acknowledgment, from `prohibited_claims: "Having held a product manager title or role"`, is "I haven't held a product manager title or role." No slot |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile (responsibilities) | none given | none | [grounded] | capability | A gap wording cannot close, and the dossier records it: `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)". The sourced words are "I haven't owned a product roadmap" (`prohibited_claims: "Having owned a product roadmap"`) and "I haven't set prioritization for an engineering squad" (`prohibited_claims: "Having set prioritization for an engineering squad"`). Then how you would learn it, said as a plan and never as a past. No bridge from other evidence, and no slot |
| F3 | "Shipped API or platform products" (R2, must_have) — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [inferred] | transferability | The pack's own reading: the underwriter did not list R2 among the weak areas, and this pack grades it separately because the requirement widens the quote. The words stay at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: the shipping line in the requirement makes a probe on go-live likely. If any part of go-live was yours to decide, say which and how you decided, in your own words; if there was no such decision, or it was not yours, say so plainly and describe the integrations you led |
| F4 | "Technical fluency: API docs, schemas" (R3, important) — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes touch integration architecture and a playbook, and do not show whether API docs or schemas were worked with directly. Answer slot: the requirement names API docs and schemas, so expect a probe on which you worked with. If you worked with docs or schemas directly, say which and what you did with them, in your own words; if you did not, say so plainly and stay with the playbook you wrote |
| F5 | "Stakeholder management across engineering, sales, customers" (R4, important) — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes reach clients and product and do not mention engineering or sales. The roadmap-input sessions are confirmed with limited inspectable proof, so expect a probe on them. Answer slot: if you worked with engineering or sales, say how, in your own words; if not, or it was not yours, say so plainly and stay with the client work. If asked what you can show from the sessions, say plainly what exists and what does not |
| F6 | "Agile delivery experience" (R5, preferred) — dossier role_profile | none given | low | [grounded] | discovery | No quote speaks to this requirement, and the dossier's strategy for it is clarify, so the answer is question-shaped. Answer slot: the requirement's own wording, agile delivery, is the likely probe. If you have worked in an agile delivery cadence, say how, in your own words; if you have never worked that way, say so plainly, then say: "here's what I'd want to confirm about how you define it." |

## Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the partner API platform: adoption, prioritizing across two squads, discovery with partners | top. Hiring-manager prior from the persona model; nothing in the material moves it down | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully (A1 to A5) |
| Skeptic | The gap probes: title, roadmap ownership, agile, shipped products | top. Hiring-manager prior, and the dossier names an objection and three weak areas | Rehearse B1 until it is boring; bridge only from the quotes with the limit named; concede in the sourced words (B1 to B5) |
| Data-Driven Prober | Line-by-line probing of the three confirmed claims | mid. The dossier grades one claim medium and says to expect a probe | Know what you can and cannot say about how the figure was counted; name the weakest assumption first (C1 to C3) |
| Conversational/Rapport | The opening "walk me through the journey" and a forward-looking close | mid. A 45-minute conversation opens with it, and casual questions are still scored | A 90-second arc built only from the quotes; never answer "any questions" with nothing (D1 to D3) |
| Peer Evaluator | The seam between this role and the two squad leads | low. The hiring manager is not a peer, but the squad leads' perspective will be tested | Offer seam principles, not a claimed seam; show spine and tact together (E1, E2) |
| Pressure/Stress | A time-boxed "why you" and an attribution challenge | low. Not a hiring-manager prior; the one pressure point is B1, rehearsed under a clock | Pause, restate, hold through two follow-ups, concede specifically (F1, F2) |
| Values/Behavioral | Scenario probes mapped to published values | low. Your own words name one hiring-manager conversation and no values round, and no published values were read, so no bank | None needed for this round |

## Question banks

### A. Case/Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Partner adoption of a newly released API endpoint is flat six weeks after launch. What do you need to know first, and how would you diagnose it?" | CASE | [generic] | Clarify before structuring: what counts as adoption here, what the baseline was, which partners were expected to adopt. Then objective, segmentation (who has not started, who started and stalled), likely causes, metrics, risks. Think aloud and say your hypothesis early. The question needs no claim about your past, so the guidance makes none | Adoption metrics are a listed responsibility, so a hiring manager can pose this as a live problem from the role itself. CASE because it scores structure, not a past |
| A2 | "You have two squads and one slot left this quarter. A large partner wants a feature and the other squad lead wants platform hardening. How do you decide?" | CASE | [generic] | Clarify who decides before deciding: ask which of these calls are yours and which are the squad leads'. Then name your criteria, what evidence you would want from each side, who you would bring in, and how you would communicate the outcome. Think aloud. The question needs no claim about your past, so the guidance makes none | Tests the prioritization half of F2 as a live problem, without asking for a past you have not had. CASE because it is a decision under constraint |
| A3 | "A partner's integration team says your API docs and schema are why their go-live slipped. What do you do in the first week?" | CASE | [generic] | Ask for specifics first: which docs, which schema, which step failed. Separate documentation defects from behavior defects, from partner-side misreads. Decide what to fix now and what to log. Say how you would close the loop with the partner. The question needs no claim about your past, so the guidance makes none | Covers the R3 line as a live problem (F4). JD content, CASE delivery |
| A4 | "You have five integration partners and 45 minutes with each. How do you structure the discovery, and what would change the roadmap?" | CASE | [generic] | Objective first: what you need to learn. Then who you pick and why, the questions you would ask, how you separate a request from a need, and what evidence would be strong enough to move a priority. Think aloud. The question needs no claim about your past, so the guidance makes none | Discovery with integration partners is a listed responsibility. CASE because it is a plan, not a past |
| A5 | "Pick one adoption metric to put in front of both squads in your first month. What would you want to verify before committing to it?" | CASE | [generic] | Pick one, say why it fits partner API adoption, name the assumption in it you would defend least, and say what you would check first, starting with whether a baseline exists. Think aloud. The question needs no claim about your past, so the guidance makes none | Covers the adoption-metrics responsibility. The weakest-assumption move is rehearsed here on a metric you choose, not on a number from your past |

### B. Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses". Negatives sourced from the dossier: `prohibited_claims: "Having held a product manager title or role"`; `prohibited_claims: "Having owned a product roadmap"` | The highest-ROI rehearsal, and the objection is the underwriter's. Four moves, in order. One, concede first in the sourced words: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Two, say what you have, at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live, and I wrote the internal integration playbook my team uses." Three, name the limit before they do: "That is adjacent to the job, not the job itself." Four, close with a plan, not a past: what you would learn first, in your own words. Follow-up one, "a PM with three years has already made the trade-offs": hold by returning to the integrations, and concede in specific words: "That's true, I haven't set prioritization for an engineering squad" (`prohibited_claims: "Having set prioritization for an engineering squad"`). Follow-up two, "so why you?": do not claim to be better. Say what the quotes carry and ask what the team most needs from this seat. Never add to the quotes to win the exchange | F1 and F2 are the two largest gaps against the must-have, and the dossier names this as the interviewer's likely objection. JD because it scores R1; the deepest follow-up structure is deliberate |
| B2 | "I don't see an owned roadmap in your background. How would you go about owning one for a platform with two squads?" | JD | [grounded] `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)"; `prohibited_claims: "Having owned a product roadmap"` | No bridge and no slot: the underwriter looked and found no credible evidence, and inventing one live is how a candidate is caught. Say it in the sourced words: "I haven't owned a product roadmap." Then a ramp plan, said as a plan: what you would learn first, whose decisions sit where, how you would earn the squad leads' trust. Write the plan's first three steps in your own words before Thursday | F2 is a stated gap, so the honest answer is the acknowledgment plus a plan. JD because it scores the roadmap responsibility |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `prohibited_claims: "Having owned a product roadmap"`; `prohibited_claims: "Having set prioritization for an engineering squad"` | Pick the part your material marks clearest and say so first: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then what you would do in week one to close it, as a plan. Do not soften it, and do not pick a decoy weakness | F2 is where the material is thinnest. A candidate who names it first converts a gotcha into calibrated candor. JD because it scores honest self-assessment against the listed role |
| B4 | "The role drives delivery with two engineering squads. What agile delivery experience do you bring?" | JD | [grounded] | Clarify strategy, and no sentence of yours speaks to this requirement, so nothing about your past goes in the answer unless it is yours to add. Answer slot: the requirement's own wording, agile delivery, is the likely probe. If you have worked in an agile delivery cadence, say how, in your own words; if you have never worked that way, say so plainly, then: "here's what I'd want to confirm about how you define it." | F6 is the one requirement the dossier marks clarify, so the answer is shaped as a question back. JD because it scores R5 |
| B5 | "Tell me about an API or platform product you have shipped." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Bridge with its limit. The words stay at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The pack's own observation is that your material says client integrations of the vendor's REST APIs, and the words do not go further. Answer slot: expect a probe on go-live. If any part of go-live was yours to decide, say which and how you decided, in your own words; if there was no such decision, or it was not yours, say so plainly and describe the integrations you led | F3 is a must-have whose evidence sits next to the requirement and does not reach it. JD because it scores R2 directly |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ client integrations. How was that counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F1 and F3: the beats are the ones the quote states, which are led, 30+, end-to-end, and the stages scoping, requirements, architecture, UAT, go-live. Tell them in your own words. The defend-the-number slots, each in your own words: how the 30+ was counted, what it is sensitive to, the assumption behind it you would defend least, and which parts were yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do | The 30+ is the headline figure on your material, and it is the figure the interviewer can test. EXP because it scores attribution and counting |
| C2 | "Walk me through the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on F5: the sessions, the quarterly rhythm, and client evidence fed to product, which are the beats the quote states. Tell them in your own words and stop at what the quote says: feeding evidence to product is not deciding what goes on a roadmap, and that is why section 13 lists the wider claim. This claim is confirmed with limited inspectable proof, so volunteer the limit before it is extracted. Answer slot: expect a probe on what came of the sessions. If you know what product did with the evidence, say what and how you know; if you do not, or nothing was recorded, say so plainly and stay with the sessions you ran. If asked what you can show from them, say plainly what exists and what does not | F5 rests on this quote and it is the thinnest of the three, so the seam gets rehearsed. EXP because it tests what was actually yours |
| C3 | "The playbook you wrote — what is in it, and who actually uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Story-mapped on F4: you wrote it, it is internal, and your team uses it, which are the beats the quote states. Tell them in your own words. Answer slot: the requirement names API docs and schemas, so expect a probe on whether the playbook covers either. If it does, say how, in your own words; if it does not, say so plainly and stay with the playbook as your team's integration playbook | The playbook is the inspectable piece, so a prober will start there. EXP primary, with JD content from F4 |

### D. Conversational/Rapport (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc from three sentences only: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "I wrote the internal integration playbook my team uses"; "I ran quarterly roadmap-input sessions feeding client evidence to product." The quotes carry no dates or order, so tell them in the order they happened and add no dates they lack. Close the arc by naming it: integration work, adjacent to product management. The motivation beat is a selection scaffold: say in your own words why product management and why a partner API platform; it needs a reason you actually have, and if none comes to mind, say so plainly and name what in the JD's own responsibilities draws you | Casual openers are scored, and this one sets up B1. EXP because it asks for the arc; F1 and F5 supply the beats |
| D2 | "Anything you have been reading or trying lately in API docs and schemas?" | JD | [generic] | Selection scaffold: name one thing you have actually looked at, what you wanted to learn from it, and what you concluded. If nothing comes to mind, say so plainly, then say what you would look at first and why. No claim about your past is made here | R3 names API docs and schemas, and a rapport interviewer asks about hot JD topics casually (F4). JD because it scores R3 |
| D3 | "What would make your first six months here a success?" | JD | [generic] | No claim about your past. Frame success in terms you can check together: learn the adoption baseline and the decision rights first, then ask what success looks like from their seat. Do not promise outcomes you cannot control | A forward-looking close that the open questions in the dossier make natural. JD because it scores readiness for the listed responsibilities |

### E. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The two squad leads will have views on the roadmap. Where is the seam between what you decide and what they decide, and what happens when you disagree?" | CASE | [generic] | Propose seam principles rather than pretending to know the seam: say the first thing you would do is agree it explicitly with the two leads, because decision rights here are not yet established. Offer reciprocity: what you would bring them, and what you would need from them. For disagreement, describe how you would handle it, as a plan. Do not assert authority you have not been given | The dossier lists decision authority versus the squad leads as unevidenced, so this is the live version of that risk (F2). CASE because it is a scenario about the future |
| E2 | "Tell me about a time you disagreed with an engineering lead about scope or timing." | JD | [generic] | Selection scaffold: pick a time with a named stake, a moment you held a position or changed it, and a relationship that was intact afterward. If no such time comes to mind, say so plainly, then say how you would handle it | R4 names engineering as a stakeholder, and no quote carries a story for it (F5). JD because it scores R4 |

### F. Pressure/Stress (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM with three years in the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses". `prohibited_claims: "Having set prioritization for an engineering squad"` | The time-boxed version of B1. Pause and restate the question. Then three sentences: the concession, the quote at its scope, the limit. Hold through two follow-ups by returning to the quoted work. Concede specifically when pushed: "I haven't set prioritization for an engineering squad." Never fold on what the quotes say, and never add to them to restore harmony | B1 under a clock; F1 and F2 are what is being defended. JD because it scores R1 |
| F2 | "That integration count — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the quote's own attribution: you led them. Answer slot: if any part was someone else's or was not yours, say which part and say so plainly, then return to what you led; if all of it was yours, say that in your own words. Hold through two follow-ups, concede only what is true and specific, and do not enlarge the quote | The stem is a standard attribution probe, and the headline figure invites it (F3). EXP because it scores what was yours |

### Requirement coverage

| Requirement or responsibility (source) | Question IDs |
|---|---|
| "3+ years product management experience" (R1) | B1, B2, B3, F1 |
| "Shipped API or platform products" (R2) | B5, C1, F2 |
| "Technical fluency: API docs, schemas" (R3) | A3, C3, D2 |
| "Stakeholder management across engineering, sales, customers" (R4) | C2, E1, E2 |
| "Agile delivery experience" (R5) | B4 |
| "Own the roadmap for the partner-facing API platform" (responsibility) | A2, B2, E1 |
| "Run discovery with integration partners" (responsibility) | A4, C2 |
| "Write specs and drive delivery with two engineering squads" (responsibility) | A2, B4, E1 |
| "Define and track adoption metrics" (responsibility) | A1, A5 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Decision authority versus the two squad leads is asserted in the JD but not evidenced, per the underwriter. Asking reads as diligence and answers something you need before accepting | [grounded] dossier questions_for_employer |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a named responsibility with no baseline stated, per the underwriter. The answer tells you what success is measured against | [grounded] dossier questions_for_employer |
| 3 | "What does discovery with integration partners look like today, who runs it, and how often?" | Discovery is a listed responsibility, and the answer shows how much of it is inherited and how much is yours to build | [inferred] derived from the JD's discovery responsibility |
| 4 | "I haven't held a product manager title (`prohibited_claims: "Having held a product manager title or role"`). What would you most want to see from me in the first 90 days?" | It names the adjacency yourself and turns the hardest objection into a conversation about what proof they want | [grounded] dossier prohibited_claims |
| 5 | "How is the work divided between the two squads today?" | It shows you are thinking about the seam you would sit across, and it feeds E1 | [generic] |
| 6 | "What would you want to be different about how this platform is run a year from now?" | It invites the hiring manager's own priorities and avoids the empty "no questions" close | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | `prohibited_claims: "Having held a product manager title or role"` | F1's quotes at their own scope, plus the plain acknowledgment: "I haven't held a product manager title or role." No slot |
| Having owned a product roadmap | `prohibited_claims: "Having owned a product roadmap"` and `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" | The plain acknowledgment: "I haven't owned a product roadmap." Then a ramp plan, said as a plan. No bridge and no slot |
| Having set prioritization for an engineering squad | `prohibited_claims: "Having set prioritization for an engineering squad"` | The plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says client integrations of the vendor's REST APIs. B5's slot stays inside go-live |
| Set or decided roadmap content through the roadmap-input sessions | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says the sessions fed client evidence to product. C2's slot asks only what came of the sessions |

## Sources

**Provided documents.** Your message (hiring-manager conversation, 45 minutes, Thursday). The underwriting dossier, version 1.1, generated 2026-08-14. It supplied `handoff_to_mock_interview` (verified evidence, weak areas with their strategies, the named objection, risks, employer questions, prohibited claims) and `role_profile` (requirements and responsibilities). `decision` was read as context only. The dossier carries no `evidence_map`, `evidence_state` or `risk_register`, so none was used.

**Research calls sent, all refused (search permission was not granted this session):**

- `Quartzline company values` — refused
- `Quartzline interview process product manager` — refused
- `Quartzline partner API platform strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have moved a values cheat sheet and any VAL bank. Neither is in this pack |
| 2. `Quartzline interview process product manager` | unavailable | Would have moved the loop structure and persona weights. Your own words fix this round as one hiring-manager conversation, so weights rest on that and on the relationship prior |
| 3. `Quartzline strategy` / recent news | unavailable | Would have moved a CO bank and company-specific CASE questions. The CASE bank is `[generic]` instead |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` supplies the requirements and responsibilities, which fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access for this session → Quartzline's published values, interview process and recent strategy, which would turn the generic CASE bank into company-specific CO and CASE questions and show whether a values round exists. A deeper pass would add up to 6 more searches and 2 more fetches and take several more minutes; this is the one offer of it
- The interviewer's name → a reading of their public path, persona weights adjusted from it, and a reverse question tied to their own career
- The recruiter's focus areas or any announced deliverable → coverage of what this round is scoped to test
- Your own answers to the slots in F3, F4, F5 and F6 (and C1's counting question) → those rows regenerate with your words, and the matching banks (B5, C3, B4, C1) get sharper guidance
- A session write-up or the document you sent product after the roadmap-input sessions, if one exists → the medium-confidence evidence behind F5 and C2 could be raised, because it is the inspectable artifact for that claim
