I've read the playbook and the dossier handoff. I'm now running the default-tier company research (values, interview process, strategy) before writing the prep pack.
Web search was refused here, so the company-specific parts of the pack will be labeled generic, not filled from memory. I'm writing the pack file now.
Your prep pack for Thursday is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-4-denied-3899cf82/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a 45-minute hiring-manager conversation from your dossier. It has 20 questions across six personas, a fit snapshot, six reverse questions and a list of claims it won't coach.

- **Web search was refused in this session.** None of the Quartzline-specific content (values, interview loop, strategy) is researched. The company and strategy questions are labeled generic, and the pack has no values cheat sheet. The pack's Sources section lists the three refused queries.
- **Highest-ROI rehearsal is A1.** It is the underwriter's objection, asked as they wrote it: "You have never held the PM title or owned a roadmap…". The pack gives it the deepest coaching: a plain acknowledgment, the bridge with its limit named (adjacent, never PM experience), and a ramp plan. A2, A4 and P1 are the same objection arriving in other registers.
- **R2 and R4 weren't graded as weak in the dossier.** R2 is "Shipped API or platform products" and R4 is stakeholder management across engineering, sales and customers. Your quoted evidence covers integrations of the vendor's APIs and a playbook, not a shipped API product, and doesn't mention engineering or sales. I treated R2 as a bridge with a stated limit and R4 as an open probe (the pack's discovery gap type). You may want to confirm both.
- **The roadmap-input sessions are your medium-confidence entry.** Expect a probe on them. The coaching is to volunteer that you have little to show for them, and never to say they shaped the roadmap.

Everything the pack says about your past rests on the three verified-evidence quotes in the dossier.

Say the word and I'll play the Skeptic on A1 so you can rehearse it live. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

- Role: Product Manager, Platform APIs, Quartzline
- Interviewer: the hiring manager (name not given). Round: one 45-minute conversation, Thursday
- Built from: the job-underwriter dossier you supplied (dossier_version 1.1), which carries the role profile, the decision context and the interview handoff. No raw CV was supplied, so every statement about your past in this pack rests on the three verified-evidence entries in the dossier, quoted below

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims about your work survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Highest-ROI rehearsal: **A1**. The underwriter named it as the objection most likely to be asked, and A2, A4 and P1 are the same objection arriving in other registers. Rehearse A1 until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff verified evidence 3 | low | [grounded] | transferability | The dossier's allowed strategy is bridge, positioned as adjacent and never as product management experience. The limit is the pack's observation: your material shows adjacent work, not the title or the years the requirement names. Words stay at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." and "I ran quarterly roadmap-input sessions, feeding client evidence to product." The second quote is medium confidence: confirmed, limited inspectable proof, so expect a probe on it |
| F2 | "Shipped API or platform products" — dossier R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff verified evidence 1; "Wrote the internal integration playbook her team uses" — dossier handoff verified evidence 2 | high | [inferred] | transferability | The dossier lists this must-have but gives it no strategy, so this pack applies the same bridge-with-limit discipline and records that as feedback. The limit is the pack's observation: the quotes say integrations of the vendor's APIs and a playbook, not a shipped API product. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I wrote the internal integration playbook my team uses." Any wider step is an answer slot inside that scope, as in A3 |
| F3 | "Technical fluency: API docs, schemas" — dossier R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff verified evidence 1; "Wrote the internal integration playbook her team uses" — dossier handoff verified evidence 2 | medium | [inferred] | discovery | The quotes touch REST APIs and architecture without showing whether API docs or schemas were part of the work. Answer slot: the requirement names API docs and schemas, so expect a probe on them. If you read or wrote either in these integrations or in the playbook, say which and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations and the playbook |
| F4 | "Stakeholder management across engineering, sales, customers" — dossier R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff verified evidence 3 | medium | [inferred] | discovery | The quotes reach clients and a product audience, and say nothing about engineering or sales. Answer slot: expect a probe on which of the three groups you worked across. If you worked with engineering or sales in these integrations or sessions, say which and how, in your own words; if you did not, or it was not your part, say so plainly and stay with the clients and the product audience |
| F5 | "Agile delivery experience" — dossier R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy is clarify, and no verified entry speaks to agile delivery itself. Answer slot: the requirement's wording is the interviewer's likely probe. If you worked in an agile way, say how, in your own words; if you never worked that way, or it was not yours, say so plainly, then say how you define it and what you would want to confirm about how this team defines it |
| F6 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibility; dossier weak area "Owning a roadmap and prioritization authority (R1 sub-claim)" | none given | none | [grounded] | capability | The dossier's allowed strategy is acknowledge_gap: no credible evidence, no bridge, no slot. Words come only from the dossier fields acknowledge_gap and prohibited_claims: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: what you would learn first, such as how adoption is measured today and which decisions are yours and which belong to the squad leads. Add one or two first steps in your own words |

## Persona table

Weights rest on the hiring-manager relationship prior and on the dossier. There is no interviewer profile and no researched loop; your own words establish one 45-minute conversation with the hiring manager.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the missing title, the roadmap, and "why you" | High. The hiring-manager prior is derisking gaps, and the dossier names one objection and three weak areas (F1, F5, F6) | Rehearse the single objection until it is boring; build bridges only from the quoted entries, with the limit said plainly; concede the roadmap specifically and do not fold on the rest |
| Case/Strategist | Live problems from the role: partner adoption, prioritizing across two squads, a custom request | High. The hiring-manager prior is live problems from the actual roadmap, and the JD's responsibilities supply them | Clarify, then objective, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Conversational | The "walk me through the journey" opener and casual questions about the platform | Medium. Hiring-manager conversations open this way, and the casual register is still scored | A 90-second arc built only from the quoted entries; treat casual questions as scored; never answer "I think you've covered everything" in the reverse-question slot |
| Data-Driven Prober | Reads the headline figure line by line and goes two levels deeper | Medium. The 30+ figure is the one headline number in the dossier, and no interviewer signal tilts it either way | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know; name the assumption you would defend least before they do |
| Peer Evaluator | Seam-splitting with the two squad leads: who decides what | Low to medium. The interviewer is the hiring manager, not a peer, but decision authority versus the squad leads is an open item in the dossier | Offer seam principles rather than pretending to know the seam; ask where the line sits today |
| Pressure | Time-boxed answers and "why you over a PM who has done this" | Low. No skip-level or executive signal, but the objection in A1 can arrive time-boxed | Pause, restate, anchor in the quoted entries; hold through two follow-ups, then concede only what is true |
| Values/Behavioral | Scenario probes mapped to published values | Low. No loop source documents a values-style round, so there is no bank and no values cheat sheet | Not rehearsed here; if the recruiter names a values conversation, send it and the pack regenerates |

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; negatives sourced from the dossier fields prohibited_claims and acknowledge_gap | The highest-ROI rehearsal, worded as the underwriter wrote it. Beat 1, the plain acknowledgment, sourced from prohibited_claims: "I haven't held a product manager title, and I haven't owned a product roadmap." Beat 2, the bridge with its limit named: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live, and I ran quarterly roadmap-input sessions, feeding client evidence to product." Call it adjacent work and let the interviewer draw the inference. Beat 3, a ramp plan said as a plan: what you would learn first about adoption measurement and about which decisions are yours versus the squad leads, plus one or two first steps in your own words. Follow-up 1: return to the quotes, add nothing. Follow-up 2, the concession, kept specific: on owning a roadmap, "I haven't, and that is the part I would be learning." Do not concede the integrations and do not widen them | F1 and F6 are where this objection presses; the underwriter named it, so it is not inferred. JD because it scores R1 directly, and it gets the deepest rehearsal because a rehearsed non-defensive answer changes the interview |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] dossier acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)"; dossier prohibited_claims | The dossier's strategy here is acknowledge_gap, so there is no bridge and no slot. Say it plainly, sourced from those fields: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the ramp plan: what you would ask in the first weeks about which decisions are yours and how adoption is measured today. Stop there rather than defending the gap | F6 is the capability row, and this is the stem that asks for it directly. JD because it scores the stated responsibility to own the roadmap |
| A3 | "The role is about shipping API and platform products — tell me about the work of yours that comes closest." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Story-mapped on F2, at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live. I wrote the internal integration playbook my team uses." Answer slot: the requirement says shipped API or platform products, so expect a probe on whether any of this was a product you shipped. If any of it was, say which and what part was yours, in your own words; if none of it was, or it was not yours, say so plainly and stay with the integrations and the playbook | F2 is a must-have with adjacent evidence only. Open prompt, so the theme is the JD's, and the question supplies no event |
| A4 | "Walk me through the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on F1, with the beats the quote states: you ran them, they were quarterly, they fed client evidence to product. This entry is medium confidence, confirmed with limited inspectable proof, so volunteer the limit before a prober extracts it: say what you ran and that there is little you can show for it. Do not say the sessions shaped the roadmap; the quote says they fed evidence to product, not what product did with it | The dossier flags this entry as the one to expect a probe on. EXP because it tests what was actually yours |
| A5 | "We run delivery with two engineering squads. What does agile delivery mean to you, and where have you worked that way?" | JD | [grounded] requirement text "Agile delivery experience" from dossier role_profile | A clarify answer on F5. Define it in your own words first. Answer slot: the requirement's wording is the likely probe on where you worked that way. If you worked that way, say where and what your part was; if you never worked that way, or it was not yours, say so plainly, then say what you would want to confirm about how these two squads define it | F5 is a preferred requirement with no verified evidence. JD because it scores the stated requirement, and the premise sits in a slot that allows it to be false |

### B. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says integrating with your API took them three months and they are weighing a competitor's. Diagnose it and tell me what you would do first." | CASE | [generic] | Clarify first: which partner segment, and where in their journey the time went. State an objective, then segment the possible causes, say how you would check each, name the metric you would watch, and name the risk of fixing the wrong thing first. The question needs no claim about your past, so the guidance makes none | A live problem from the partner-facing API platform; generic because it is a role-family pattern and no research ran on Quartzline |
| B2 | "How would you measure adoption of a partner-facing API platform?" | CASE | [generic] | Ask what the current baseline is before proposing anything, since the dossier lists the baseline as unknown. Then say what adoption means for whom, a funnel from sign-up through first use to sustained use, which measures lead and which lag, and one way each could mislead. State your hypothesis early | The JD's responsibility is to define and track adoption metrics, and the dossier notes no baseline is stated. Generic because the guidance is a pattern, not a claim about Quartzline |
| B3 | "Two squad leads each say their item is the partners' top ask. How do you decide what goes first?" | CASE | [generic] | Clarify the decision rights first, since who decides is unspecified in this role. Then criteria, what partner evidence you would collect, how you would make the call visible, and how you would disagree with a squad lead without a turf fight. Say aloud what you are assuming | It tests prioritization authority without presupposing any, which keeps it inside the acknowledge_gap line on F6 |
| B4 | "A large partner asks for a custom endpoint. Walk me through whether you would build it." | CASE | [generic] | Clarify the partner's underlying job, then the cost to the platform, then alternatives that avoid a custom build, then how you would decide and how you would say no if it comes to that. Use the vocabulary of specs and schemas only as far as you can defend it in a follow-up | Tests the technical-fluency requirement (F3) in a live setting; generic as a role-family pattern |
| B5 | "You are starting discovery with a handful of integration partners. Who do you talk to, and what are you trying to learn?" | CASE | [generic] | Structure it: the decision the discovery must inform, which partners and which roles inside them, what you would ask, how you would separate what partners say from what they do, and how you would bring it back to the squads. The question needs no claim about your past | The JD lists running discovery with integration partners as a responsibility; it is asked as a case so it presupposes nothing about your past |

### C. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey: how did you get from integrations to wanting this role?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc whose past-tense beats are exactly the three quotes, at their own scope. Beat 1: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Beat 2: "I wrote the internal integration playbook my team uses." Beat 3: "I ran quarterly roadmap-input sessions, feeding client evidence to product." Beat 4 is yours: why you want this role, in your own words, with nothing supplied here. Call the move adjacent, not a continuation of a product management career | F1 and F2 supply the beats. EXP because it is the biography question, and the casual register is still scored |
| C2 | "What have you seen of how partners use Quartzline's API from the outside?" | CO | [generic] | A selection scaffold, not a story: before Thursday, spend a short block on whatever Quartzline publishes about its API, and pick two concrete observations you can state without overreaching. If you find nothing public, say so plainly and ask how partners use it today, which also serves as your reverse question G4 | Company research was refused in this session, so the CO bank is generic by necessity; the upgrade menu says what research would add |
| C3 | "What is in the integration playbook you wrote, and who uses it?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Story-mapped on F2, at the quote's scope: you wrote it, and your team uses it. Answer slot: the technical-fluency requirement names API docs and schemas, so expect a probe on whether the playbook covers either. If it does, say how, in your own words; if it does not, or that part was not yours, say so plainly and describe what it does cover. The dossier rates this entry high confidence and inspectable, but it is an internal document, so check before offering to share any of it | F2 and F3 meet here. JD because it scores R3 through the one inspectable artifact in the dossier |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The defend-the-number rehearsal, and the figure counts client integrations, not anything else. Answer slot: the four things a figure raises, each in your own words. What counted as one integration; what the figure would be sensitive to; the assumption behind it you would defend least; which part of it was yours. If you do not know how it was counted, say so plainly. The pack does not supply a method, a baseline or an assumption | F1 and F2 carry the only headline number. EXP because it tests attribution and how well you know your own figure |
| D2 | "Tell me about the hardest of those 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | A selection scaffold for one instance: pick one that has a named stake, a moment you had to make a call, and an outcome you can state without embellishing, and tell it at your own scope. If no such one comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The quote carries the 30+ and the stages, not any single integration, so the story is yours to choose and the pack supplies none |
| D3 | "Tell me about a time you worked from API documentation or a schema to unblock a client." | JD | [generic] | A selection scaffold: pick a time with a named client problem, what you read, what you concluded, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would work through it | F3 is a discovery row: no quote shows docs or schemas, so the pack supplies selection criteria and an honest branch. The theme comes from the JD requirement |

### E. Peer Evaluator (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our two squads sit alongside you. Where is the seam between what you decide and what the squad leads decide, and what happens when you disagree?" | JD | [grounded] dossier opportunity_risks_to_validate: "Decision authority versus the two squad leads is asserted in the JD but not evidenced" | Offer seam principles rather than pretending to know the seam, then ask where it sits today. A disagreement approach should show spine and tact together; keep it to what you would do and make no claim about a past disagreement. Do not describe prioritization authority as something you have held | The dossier lists decision authority as unverified, and this is the question that surfaces it. The reciprocity move is to say what you would bring to the squads and what you would need from the leads |
| E2 | "How do you handle credit and pushback when work spans engineering, sales and customers?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot on F4: the requirement names all three groups, so expect a probe on which you worked across. If you worked with engineering or sales in these integrations or sessions, say who and what your part was; if you did not, or it was not yours, say so plainly and stay with the clients and the product audience. Share credit in plain terms and add no incident | F4 is a discovery row, and the quotes do not reach engineering or sales |

### P. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over a PM who has already done this job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold-then-concede on A1's bones, time-boxed. Pause and restate. Hold the position the quotes carry: the 30+ integrations and the roadmap-input sessions, called adjacent. Hold through two interruptions by returning to them, never by adding to them. Concede only the roadmap: "I haven't owned one." | The same objection as A1, rehearsed under time pressure; F1 and F6 are the rows |
| P2 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the quote's own verb, led, and its own scope, 30+ client integrations. Answer slot: if some stages or integrations were another person's, say which, plainly and specifically; if all were yours to lead, say so without adding detail. Concede any stage that was not yours and hold the rest | Attribution probes exist to catch inflation, and this rehearses the honest answer; F1 and F2 are the rows |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1 3+ years product management experience | A1, A2, A4, C1, P1 |
| R2 Shipped API or platform products | A3, D1, D2 |
| R3 Technical fluency: API docs, schemas | B4, C3, D3 |
| R4 Stakeholder management across engineering, sales, customers | B3, E1, E2 |
| R5 Agile delivery experience | A5 |
| Own the roadmap for the partner-facing API platform (F6) | A1, A2, B3 |
| Responsibility: run discovery with integration partners | B5 |
| Responsibility: define and track adoption metrics | B2 |
| Headline figure on the evidence (30+) | D1, P2 |
| Company and strategy knowledge | C2 — generic, since research did not run |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| G1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier flags decision authority as asserted but not evidenced; it reads as diligence and answers something you need to know before accepting |
| G2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier names adoption metrics as a responsibility with no stated baseline; the answer tells you what you would be inheriting |
| G3 | "What would a strong first 90 days look like for this role, given that I would be coming from integration delivery rather than a product seat?" | It turns A1 into a planning conversation and lets the hiring manager name concerns instead of holding them |
| G4 | "How do partners use the API today, and where do they get stuck?" | Shows you are curious about the real usage, and the answer replaces the outside view that C2 could not supply |
| G5 | "How do the two squads take in partner feedback today, and where does it get lost?" | Ties to the roadmap-input work in your quoted entries without claiming anything about what product did with it |
| G6 | "Is there anything in my background you would want me to address before we finish?" | Gives the hiring manager a direct chance to voice the objection, so A1 can be answered while you are still in the room |

## Prohibited claims

Built from the dossier's prohibited_claims and from the stretched wordings of your quoted entries. The banks above were written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| "Having held a product manager title or role" | Dossier prohibited_claims | The plain acknowledgment, sourced from prohibited_claims: "I haven't held a product manager title." Then the F1 quotes at their own scope, called adjacent |
| "Having owned a product roadmap" | Dossier prohibited_claims, and acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" | The plain acknowledgment, sourced from prohibited_claims and acknowledge_gap: "I haven't owned a product roadmap." Then the ramp plan. No bridge and no slot (A2) |
| "Having set prioritization for an engineering squad" | Dossier prohibited_claims | The plain acknowledgment, sourced from prohibited_claims: "I haven't set prioritization for an engineering squad." Then the ramp plan |
| Shipped an API or platform product | Inflated form of F2 | F2's quotes at their own scope. The limit is the pack's observation: the quotes say integrations of the vendor's APIs and a playbook, not a shipped product. A3's slot stays inside those quotes |
| Shaped or influenced the product roadmap | Inflated form of F1's third quote | "Ran quarterly roadmap-input sessions feeding client evidence to product" at its own scope. The limit is the pack's observation: the quote says the sessions fed evidence to product, not what product did with it |

## Sources

- Provided: the dossier you supplied (dossier_version 1.1). Sections consumed: handoff_to_mock_interview (verified evidence, weak areas and their allowed strategies, the objection, risks, employer questions, prohibited claims), role_profile (requirement text and responsibilities, standing as the JD's lines), decision (context only). Not present in the dossier: evidence_map, evidence_state, risk_register, so no map grading beyond the handoff was available. The rows resting on your own confirmed evidence are the quoted ones in F1 to F4 and the questions that quote them; everything else is the pack's inference or generic
- Provided: your own words, that the round is a 45-minute conversation with the hiring manager on Thursday
- Outside sources: none. Every web search sent was refused, so nothing about Quartzline's values, interview loop or strategy comes from research, and none comes from memory

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Query "Quartzline company values" was refused. It would have moved the values cheat sheet and the VAL questions; the cheat sheet is absent and no VAL bank is written |
| 2. Quartzline interview process, product manager | unavailable | Query "Quartzline interview process product manager" was refused. It would have moved the loop structure and the persona weights; weights rest on the hiring-manager prior and your own words |
| 3. Quartzline strategy and recent news | unavailable | Query "Quartzline partner API platform strategy news" was refused. It would have moved the CO and strategy-grounded CASE questions; those rows are generic |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative role JD | skipped | The dossier's role_profile requirement text already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → an interviewer read from their public professional footprint, persona weights adjusted to it, and a reverse question tied to their own path
- The recruiter's prep note, including any named focus areas or a pre-declared deliverable → coverage reweighted to what they said, or a build section for the deliverable
- Search access for Quartzline, or Quartzline's values page, careers page and public API documentation pasted in → the generic CO and CASE rows (B1 to B5, C2) become grounded in their material, and a values cheat sheet appears if a values round is documented
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief and recent organization context for the CO bank
- Your answers to the answer slots in F3, F4, F5, A3, C3, D1 and P2, said outside a drill → new quoted material that upgrades those rows
- An agenda, notes or output from the quarterly roadmap-input sessions → raises the third verified entry above medium and upgrades F1, A4 and P1
- The raw CV behind the confirmed claims → more quoted sentences for the fit snapshot, and possibly an answer for F5 and F4
- How much prep time you have before Thursday → a prioritized prep triage sized to it
