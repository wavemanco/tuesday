The pack is written and saved; I'm now handing it over.

Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-canned-10627995/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It's built in loop mode, with a mini-pack for each of the three rounds on 20 November. There are 8 questions in Round 1, 10 in Round 2 and 10 in Round 3, five reverse questions per round, and a values cheat sheet under the panel. It's built only from what you pasted (JD, values, recruiter email, July brief) and ran no web searches. The case format and the interviewers' names are still unknown.

The pack names D1 in Round 2 as the highest-ROI rehearsal: "you've never worked in a contact centre, and what you've described is one branch's log, so how do you own this end to end?" It's your biggest stated gap against the JD's headline requirement.

Say the word and I'll play the Round 2 Skeptic on D1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Prepared for Dara, 11 November 2026. Loop mode: three rounds on 20 November 2026, per the recruiter's email.

| Round | Who | Length | Format, as the recruiter described it |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Conversation |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; the panel is also the values round and scores against the four values |

Interviewer names are not yet assigned, so there is no interviewer read in this pack. The highest-ROI rehearsal is D1 in Round 2: the contact-centre and end-to-end objection. Rehearse it until it is boring, and it also covers B1 in Round 1.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words. An answer slot is an instruction for the interview, not a question for me; if you answer one in writing here, I will quote it into the fit snapshot and regenerate the rows it touches.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour demonstrates Ashgrove's published values, not generic virtue |
| EXP | Whether what you have said about your experience survives scrutiny; what was actually yours |
| JD | A stated responsibility or requirement in the posting, including its gaps |
| CO | Knowledge of Ashgrove's strategy and competition, and whether you can think at its altitude |
| CASE | A live problem set in the role, scored on structure and reasoning |

## Grounding brief

What Ashgrove has published, for you to sound current. Source for every row: the 2026 strategy brief published in July 2026 and sent by the recruiter, as you described it. It is about four months old.

| Item | What the brief says | Provenance | Where it surfaces |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | A3, E1 |
| Branch network | Consolidate eight branches into five hubs over 2027 | [grounded] | A3, E2, G3 |
| New product | Launch a small-business lending product in Q1 2027 | [grounded] | A3, E3 |
| Competitive pressure | The main competitive pressure is app-only banks | [grounded] | A3, E1 |

## Fit snapshot

Nine rows, one per stated requirement; the JD's first requirement is split into two rows because your material carries two different strengths against it. No requirement is a gate: the four-years line is a length-of-experience requirement, and the rest are not terms you meet or do not.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's formal log, not the process across branches, with nothing inspected behind it, so the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how far your handling reached beyond your own branch likely. If any of it did, say how, in your own words; if none did, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre handling, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says you built the monthly sheet your regional manager uses; it does not say what the sheet showed, and the bridge should not stretch it. Answer slot: say what the spreadsheet was set up to show, in your own words; if you are unsure of any of it, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, not supervisors and coaching, so the words stay at the tellers: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: the JD's supervisor line makes a probe on whether you have guided anyone at your own level or above likely. If you have, say whom and on what; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the JD's digital-teams line makes a probe likely. If you have worked with a digital or online team on anything members use themselves, say what and which part was yours, in your own words; if you have not, or none of it was yours, say so plainly and stay with the escalation script and the spreadsheet your message describes |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence already reaches the years, in other terms: retail banking, the last three as a branch supervisor. Say it in those terms, "6 years in retail banking, the last 3 as a branch supervisor.", and let the interviewer map it to the JD's wording rather than relabelling it yourself. Nothing is inspected behind it, so expect a probe on what the supervisor years held |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your material says formal complaints, not regulated ones, and does not say what rules, if any, the log followed. Answer slot: say what made a complaint formal in your branch's log, in your own words; if you know of any outside rules the log followed, say which; if you do not, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan. Your material does not say what you have presented at regional level or below; the upgrade menu asks for it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says spreadsheet, not which tool, and not how it was built. Answer slot: say what the spreadsheet was built in and what you did in it, in your own words; if you do not remember, or someone else set up parts of it, say so plainly and stay with the spreadsheet you built |

## Round 1: the recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured; a journey question and a why-us question | High. The persona model's prior for a recruiter screen is Conversational plus a light Skeptic, and the recruiter's email describes only a 30-minute conversation, so there is nothing to move it | A pre-scripted 90-second arc for the biography question; treat casual questions about the JD's hot topics as scored; use the reverse-question slot |
| Skeptic, light | Checks the gaps in a friendly register: the contact centre, presenting, why now | Low. Same prior; the screen is where the two gaps you named get their first airing | Say each gap in one plain sentence, then the plan; do not defend |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with only the beats your sentences state: six years in retail banking; the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Tell each in your own words, at that size. Close on why this role, which is yours to say; the pack does not write your reason | The opener of a recruiter call is the biography question, and rehearsing it stops the casual register loosening it. F1, F3, F4 and F6 are the rows the arc touches; EXP because it tests what was actually yours |
| A2 | "The role asks for four or more years in financial-services customer operations. Talk me through the experience you'd point to." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it in the sentence's own terms: "6 years in retail banking, the last 3 as a branch supervisor." Let the interviewer decide how that maps to their wording; do not relabel it as customer operations yourself. Answer slot: expect a probe on what the supervisor years held. Say what they held in your own words; if you are unsure of any of it, say so plainly and return to the six years in retail banking | F6 is the one requirement with a stated number, and its gap is wording rather than substance; JD because it scores the stated requirement |
| A3 | "What do you know about Ashgrove?" | CO | [grounded] | Pick two points Ashgrove has published and say each in your own words: the four values by name (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix) and one move from the July 2026 brief, such as 40% of member service on digital channels by 2028, eight branches into five hubs over 2027, small-business lending in Q1 2027, or app-only banks as the main pressure. Then one question the point raises for complaints, which is yours to draw. The question needs no claim about your past, so the guidance makes none | A recruiter screen is still scored, and this is the cheapest place to show homework; CO because it scores knowledge of the published values and strategy; `[grounded]` because both documents were provided |
| A4 | "The role needs experience handling regulated complaints. Tell me about the complaints you've handled." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold to the sentence: you handled the branch's formal complaints log. Answer slot: the JD's complaints-experience line makes a probe on what made a complaint formal in your branch's log likely. Say what made one formal, in your own words; if you know of any outside rules the log followed, say which; if you do not, say so plainly and stay with the log. Do not describe a process you did not work to | F7 is the requirement your material reaches least precisely, and the likeliest place to be probed in a friendly register; JD because it scores the stated requirement |
| A5 | "Tell me about the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the sentence says: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: the JD's reporting lines make a probe on what it showed and what it was built in likely. Say what it was set up to show and what it was built in, in your own words; if you did not set up part of it, or you are unsure how part of it worked, say so plainly and return to the sheet you built | F3 and F9 both lean on this one sentence, so whichever probe arrives, it arrives here; JD because it scores two stated requirements, EXP is the second call |
| B1 | "The role covers the contact centre as well as the branches, and you've never worked in a contact centre. How do you see that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Concede in one plain sentence: "I've never worked in a contact centre." Then what your material carries, at its own size: "I handled the branch's formal complaints log". Then a plan in the future tense, never as a past: what you would want to learn first and from whom. Do not claim contact-centre handling or imply it. This is the cheap place to rehearse the sentence the Head of Member Services will press harder in D1 | F2 is a stated gap, so the objection is near-certain; the recruiter screen is where it first appears; JD because it scores the stated scope |
| B2 | "How confident are you presenting to senior leaders, and what's your experience of it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold the sentence you gave: "I've never presented to anyone above regional level." Say it plainly, then what you would do to prepare, as a plan. Answer slot: the JD's senior-leaders line makes a probe on what you have presented at regional level or below likely. If you have, say to whom and about what, in your own words; if you have not, say so plainly. Do not offer confidence you have no example for | F8 is a stated gap and a stated requirement; JD because it scores the requirement |
| B3 | "What's making you look at a move from branch supervisor now?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Your reason is yours to give; the pack does not write it. A reason that holds names what pulls you toward this role, not only what you are leaving, and is true for you. Two sentences. Answer slot: if something specific in your supervisor years pointed you here, say it in your own words; if nothing specific did, say so plainly and give the pull toward the role | The Skeptic's motivation probe (why leave, why here, why now) in a light register; F6 carries the years; JD rather than VAL because it scores fit to the stated role |

### Reverse questions

| Question to ask | Why it lands |
|---|---|
| "Is this a new role or a replacement, and what does the first quarter look like?" | Tells you whether the complaints process is being built or inherited, which reshapes how you answer D1 |
| "How is complaints handling in the contact centre organised today, at the level you can share?" | Targets the part of the JD your material does not cover, and signals you want to learn it; the answer sharpens your plan for Round 2 |
| "Will the 20-minute case come with material beforehand, or is it live?" | Structural and un-researchable: only the recruiter knows, and it changes how you prepare G1 to G4 |
| "Is there anything in my background you would like me to address before I meet the Head of Member Services?" | Surfaces a concern while it is still cheap to answer, and signals you are working the process |
| "Who else would I work with most in the first three months?" | Shows you are thinking about the role's seams, which Round 3's Peer questions probe |

## Round 2: the Head of Member Services, 45 minutes

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Open prompts asking for a time you did something; STAR-shaped | Highest. The persona model's prior for a hiring manager is Case/Strategist plus Skeptic, but the recruiter says this round is mostly behavioural, which raises this persona and lowers Case | Where a quoted sentence carries a story, map it; where none does, use the scaffold and its honest branch; "we" for context, "I" for contribution |
| Skeptic | Quiet, persistent probing of the contact-centre and presenting gaps; "which part would be hardest" | High. The Head of Member Services would be your manager, which is the persona model's cue for gap-probing; F2 and F8 are stated gaps | Rehearse the contact-centre objection until boring (D1); concede plainly, hold only what your sentences carry, then a plan |
| Case/Strategist | Live problems from the strategy: digital shift, hubs, the new lending product | Medium. Lowered by "mostly behavioural", but the brief gives them three ready-made problems and a hiring manager's roadmap is where cases come from | Clarify, objective, segmentation, approach, measures, risks; challenge one premise respectfully |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you helped a colleague through an escalation they weren't sure how to handle." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beats your sentence states: new tellers, the escalation script, you trained them. Tell those in your own words, at that size. Answer slot: the JD's coaching line makes a probe on a particular escalation you took someone through likely. If there was one, say what it was and which part was yours; if there was none, or it was not yours, say so plainly and stay with the tellers and the script. Do not call it coaching supervisors | F4 is the JD's coaching requirement, reached only at tellers' level; the behavioural register asks for an instance; JD because it scores the coaching requirement |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "I built the monthly complaints spreadsheet our regional manager uses." | Selection criteria: a time you told someone senior something they did not want to hear, with a named stake, what you said and how, and what happened to the relationship afterwards; the hard truth has to have landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the monthly spreadsheet your regional manager uses, or how you would handle it. Whether that sheet ever carried an unwelcome number is yours to say; the pack does not say it did | A standard Values/Behavioral stem; F3 is the nearest evidence and does not carry a story, so this is a scaffold; VAL because it scores behaviour rather than a stated requirement |
| C3 | "Tell me about a complaint that turned out harder to close than it first looked." | EXP | [generic] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection criteria: one complaint from the log, a point where the first answer did not close it, what you did next and what you would do differently; keep names out. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the formal log you handled, or how you would approach it. Do not add an outcome you could not repeat under a second question | The theme is the JD's complaints line (F1, F7); no quote carries a particular complaint, so the pack supplies none; EXP because it tests what was actually yours |
| C4 | "Tell me about a time you worked with a team outside your own to fix something members kept running into." | JD | [generic] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Selection criteria: a recurring member problem, a team outside yours, what each of you did, and whether it stayed fixed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the escalation script or the spreadsheet your message describes, or how you would approach working with a digital team. Do not describe digital work you did not do | F5 is silent in your material and the JD names digital teams; the pack does not guess an example; JD because it scores the stated requirement |
| D1 | "You'd own the process across branches and the contact centre. You've never worked in a contact centre, and what you've described is one branch's log. How do you get from there to owning it end to end?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Highest-ROI rehearsal in this pack: this question will arrive in some form, so make the answer boring. Concede: "I've never worked in a contact centre." Hold only what your sentence carries: "I handled the branch's formal complaints log." Then a ramp plan in the future tense; plan options, pick two you would really do and say them as intentions, never as things you have done: sit alongside the people who run the contact centre, ask how a complaint moves between a branch and the contact centre, ask what they find hardest. Follow-up one, "what would you do in week one?": the plan again, in order. Follow-up two, "would the contact centre take you seriously?": concede, "Not on the strength of experience, I have not worked in one, so I would earn it by learning from them first." Follow-up three, "how would you know it works end to end?": say what you would look at, as a plan. Never say the process across branches was yours | F1 and F2 together are where the JD's headline mandate presses on your thinnest evidence, which is why the pack names this the most predictable objection; JD because it scores the headline requirement |
| D2 | "Which part of this job would be hardest for you in your first month?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick the one that is true for you and say it first; your own sentence names two. Name one, say what you would do about it as a plan, and stay calibrated rather than bluffing. Answer slot: if neither is the hardest part for you, say what is and why, in your own words | Skeptic's weakest-on-day-one stem; F2 and F8 are the two stated gaps; JD because it scores fit to the stated role |
| D3 | "The monthly complaints spreadsheet you built is one your regional manager uses. This role's monthly report goes to senior leaders. What would change?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Start with the sentence at its size: you built the monthly complaints spreadsheet your regional manager uses. Concede the second half plainly: "I've never presented to anyone above regional level." Answer slot: say what the sheet was set up to show, in your own words; if you do not know how a senior reader would use it, say so plainly and say what you would ask them first. The change is a plan, not a past | F3 and F8 meet here: the reporting requirement and the audience gap; JD because it scores both |
| E1 | "Ashgrove wants 40% of member service on digital channels by 2028. What would you keep human when it comes to complaints?" | CO | [grounded] | The question needs no claim about your past, so the guidance makes none. Structure aloud: clarify first (what counts as member service in the 40%, and are complaints in it?), then the objective, then the segments, the approach, the measures and the risks. Challenge one premise respectfully: test whether complaints belong in the 40% at all. Use a value by name only if you can say what you would do with it | F5's requirement plus the brief's headline number; CO because it scores strategy fluency; `[grounded]` because the figure is in the provided brief |
| E2 | "Eight branches become five hubs over 2027. A member whose branch is closing has a complaint still open. Whose is it, and how do you make sure nothing is lost?" | CASE | [grounded] | The question needs no claim about your past, so the guidance makes none. Clarify first (what the member has been told, who holds it now), then one named owner who keeps it until it is closed, the record moving with the member, and the member told in plain words who has it. Say your assumptions aloud | A live problem from the brief's consolidation item, aimed at F1's end-to-end mandate; CASE because it is a decision, not a record |
| E3 | "Small-business lending launches in Q1 2027. What complaints would you expect, and how would you be ready?" | CO | [grounded] | The question needs no claim about your past, so the guidance makes none. Say first what you do not know about the product and who will handle it; then form two or three hypotheses in your own words, label them as hypotheses, say how you would find out in the first month and what you would put in the monthly report | The brief's new-product item, and the one a hiring manager is most likely to be thinking about; CO because it scores strategy altitude |

### Reverse questions

| Question to ask | Why it lands |
|---|---|
| "How are complaint numbers reported to leaders today, and what is the page they actually look at?" | Ties to the reporting requirement and tells you what D3's report must replace |
| "If the 40% digital target is met, what do you most want to be different about complaints?" | Uses the brief's own number and shows you think at the strategy's altitude |
| "Where does the process between branches and the contact centre break most often?" | Targets F1 and F2 directly, and invites the manager to teach you the part your material lacks |
| "How are branch supervisors supported on escalations today, and where does that stop working?" | Ties to the coaching requirement and tells you what a first coaching conversation would need |
| "How would you want the role to divide its time between the branches and the contact centre while eight branches become five hubs?" | Joins the brief's consolidation to the role's scope and shows you read the brief |

## Round 3: the panel of two branch managers, 60 minutes

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Each of the four values as a prompt; scored against the value | Highest. The recruiter says the panel is the values round and scores against the four values, so every value is likely to be asked in some form | A story or a selection scaffold per value, mapped in the cheat sheet below; hard truth landed |
| Case/Strategist | The 20-minute case on a complaint escalation, and its follow-ups | Highest. Twenty of the sixty minutes are a case, by the recruiter's email | Clarify, structure, answer; say assumptions aloud; challenge one premise |
| Peer Evaluator | Seam-splitting between branches and the role; credit and disagreement | Medium. The pack assumes the branch managers stand in a cross-functional relationship to you (the persona model's prior for that is Values/Behavioral plus Conversational) and that coaching branch supervisors puts the role on their seam; correct me if you know otherwise | Reciprocity framing; propose seam principles rather than pretending to know the seam |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Members First, Always — we decide from the member's side of the counter. Tell me about a time you decided something from the member's side." | VAL | [generic] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection criteria: a decision with a stake on both sides, a member's interest and an internal one, a moment you chose the member's side and what it cost or changed; the hard truth has to have landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the formal complaints log you handled, or how you would decide. "We" for context, "I" for your own contribution. The pack names no incident | The first of four published values; no quote carries a member-side decision, so this is a scaffold; F1 is the nearest row; VAL because it scores behaviour against a published value |
| F2 | "Plain Words — if a member needs it explained twice, we wrote it wrong. Tell me about a time you made something complicated clear to a member or a colleague." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beats your sentence states: you trained new tellers on the escalation script. Tell that in your own words, at that size. Answer slot: the value raises a probe on the wording itself. If any of the script's wording was yours to change, say what and why; if you taught it as written, or none of it was yours, say so plainly and stay with the training | The second published value; F4's sentence is the nearest evidence, at tellers' level; VAL because it scores the value |
| F3 | "Neighbours, Not Numbers — every branch is part of its town. Tell me about a time a number and the needs of a member or a town pulled apart." | VAL | [generic] "I built the monthly complaints spreadsheet our regional manager uses." | Selection criteria: a number you reported or answered for, a member or town need it did not capture, what you did and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the monthly spreadsheet your regional manager uses, or how you would weigh it. Whether that sheet ever missed what a town needed is yours to say; the pack does not say it did | The third published value, and the one branch managers hear most directly; F3 is the nearest row and carries no story; VAL because it scores the value |
| F4 | "Own the Fix — whoever finds the problem keeps hold of it until it is solved. Tell me about a time you kept hold of a problem until it was solved." | VAL | [generic] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection criteria: you found it, you stayed its owner through at least one handoff, and you can say how you knew it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the formal complaints log you handled, or how you would hold a problem to closure. Do not claim a fix you did not close | The fourth published value and the JD's own headline ("own"); F1 is the nearest row; VAL because it scores the value |
| G1 | "A member has complained three times about the same fee. The branch says it is resolved; the contact centre's record says it is open. The member has now written to the board. You have twenty minutes: what do you do?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Spend the first minutes on questions: what the member has been told each time, who holds it now, what the member wants, which deadlines apply (ask, do not assume). Then one named owner today (Own the Fix); a reply to the member in plain words (Plain Words); the branch and contact-centre records reconciled; the cause found so it does not repeat; what goes in the monthly report. Say your assumptions aloud and challenge one premise respectfully | A pattern for the recruiter's named case type, not Ashgrove's actual case, hence `[generic]`; the format and materials are unknown, which is in the upgrade menu; CASE because it is live reasoning |
| G2 | "The branch supervisor escalated it late and says they didn't know they should have. How do you coach them?" | JD | [generic] | The question needs no claim about your past, so the guidance makes none. Ask for their account first; find what they were working from; agree the trigger for escalating together; set a follow-up date; say when you would check. If asked whether you have coached supervisors, the answer is C1's slot | F4's requirement, asked as a decision; JD because it scores the coaching requirement; `[generic]` because it is a pattern for the problem |
| G3 | "Eight branches become five hubs. A long-standing member says nobody at the new hub knows them any more. What do you do?" | CASE | [grounded] | The question needs no claim about your past, so the guidance makes none. Listen first; separate the personal (who knows me) from the procedural (what changed in how my account is handled); keep one owner until it is closed; reply in plain words. Name "Neighbours, Not Numbers" only if you can say what you would do, not as a slogan | The brief's consolidation item set against the third value, in front of two branch managers; CASE because it is a live problem |
| G4 | "The role reports monthly on complaint volumes and resolution times. What would your monthly page for leadership hold?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Design aloud: the two measures the JD names, then what a reader would need next to act on them; the design is yours, in your own words. Answer slot: say what the monthly sheet you built was set up to show, and what you would keep or change for senior readers; if you are unsure what it showed, say so plainly and return to the sheet you built. Do not describe a report to leaders you have given: "I've never presented to anyone above regional level." | F3 and F9, asked as a design problem the panel can score; JD because it scores the stated requirement |
| H1 | "When a complaint goes wrong between a branch and your team, where is the seam, and what happens when we disagree?" | JD | [generic] | Propose principles rather than pretending to know their seam: the member's conversation stays with whoever the member is already talking to until a named owner takes it and the member is told; the fix has one owner until closed; disagreements go to the facts of the complaint, then to a named person. Reciprocity: what the branch gets, which is earlier warning, a clear route and coaching for supervisors. Say you would test the principles with them | The Peer Evaluator's seam stem, aimed at F1 and F4; JD because it scores the role's mandate across branches |
| H2 | "How do you handle credit when a fix comes from one branch and the report goes to leadership?" | JD | [generic] | Criteria: name the branch and the person in the report, and say it in the room, before you present; "we" for context, "I" for your own part. If you have an example, give it in your own words; if you do not, say how you would do it. The pack supplies no example | The Peer Evaluator's credit probe, relevant because the role reports upward on work done in branches; JD because it scores the reporting mandate |

### Values cheat sheet

Published values, copied by you from ashgrovecu.org/about/values on 11 November 2026. Each is mapped to a fit-snapshot row's quoted sentence where one carries a story, and otherwise to a selection scaffold.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message. It carries no member-side decision, so use the F1 scaffold: pick a decision with a stake on both sides; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would decide |
| Plain Words | If a member has to have it explained twice, the wording failed | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message. It carries training on the script, not wording you wrote, so use the slot in F2: say what of the wording was yours, or say plainly that none was |
| Neighbours, Not Numbers | Each branch is part of its town; a figure is not the whole picture | F3: "I built the monthly complaints spreadsheet our regional manager uses." — your message. It carries the sheet, not a story, so use the F3 scaffold: a number and a need it did not capture; if none comes to mind, say so plainly, then the nearest thing, or how you would weigh it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message. It carries the log, not a fix you closed, so use the F4 scaffold: you found it, kept it through a handoff, and can say how you knew it was solved; if none comes to mind, say so plainly |

### Reverse questions

| Question to ask | Why it lands |
|---|---|
| "Which complaints reach you as branch managers that you wish had been caught earlier?" | Invites them to tell you the problem the role exists to solve, in their own terms |
| "When a branch becomes a hub, what do you most want members to still feel is theirs?" | Joins the third value to the consolidation and signals you think from the branch's side |
| "What would make a Member Experience Lead useful to you rather than one more report to fill in?" | A reciprocity question: it asks what you could bring their branch, not only what you need |
| "What could a new person do in their first month that would genuinely help your branch?" | The standard reciprocity question, which peers weight as a preparation signal |
| "Which of the four values is hardest to hold to on a busy day at the counter?" | Turns the values round into a conversation with people who live them, and shows you took the values seriously |

## Requirement coverage

Every stated JD requirement, mapped to the questions that cover it.

| JD requirement | Questions | Fit rows |
|---|---|---|
| Own the member complaints process end to end across branches | D1, H1, G1 | F1 |
| Across branches and the contact centre | B1, D1, D2 | F2 |
| Report monthly on complaint volumes and resolution times | A5, D3, G4 | F3 |
| Coach branch supervisors on escalations | C1, G2, H1 | F4 |
| Work with digital teams on self-service journeys | C4, E1 | F5 |
| 4+ years in financial-services customer operations | A2, A1 | F6 |
| Experience handling regulated complaints | A4, C3, G1 | F7 |
| Confident presenting to senior leaders | B2, D3 | F8 |
| Comfortable with Excel reporting | A5, D3, G4 | F9 |

Totals: 8 questions in Round 1, 10 in Round 2, 10 in Round 3, with five reverse questions each.

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before any bank was written; no dossier was present.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says one branch's log, not the process across branches. D1's and H1's slots stay inside the log |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your message says you built the spreadsheet, not what it showed. The slots in A5, D3 and G4 ask only what it was set up to show |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers and the escalation script. C1's and G2's slots stay with the tellers |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material says formal, not regulated. A4's slot stays with what made a complaint formal in the log |
| Built the complaints reporting in Excel | Inflated form of F9 | F9's quote at its own scope: the spreadsheet you built. The slot asks only what it was built in |

## Sources

Provided documents: the job description you pasted; Ashgrove's values, which you copied from ashgrovecu.org/about/values on 11 November 2026; the recruiter's email about the process; the 2026 strategy brief published in July 2026, which the recruiter sent; and your background as you described it in your message. No `tuesday-dossier.md` was present.

No searches or fetches were sent. The values page you copied and the recruiter's own words fixed the values and the loop, and the strategy brief fixed the strategy; nothing in the pack rests on the model's memory of Ashgrove.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Could not have moved the values cheat sheet: you pasted the four values with their wording, copied that morning |
| 2. Ashgrove interview process, member-service role | skipped | Could not have moved the persona weights or the loop: the recruiter's email names three sessions and who runs each, and says the panel scores against the four values |
| 3. Ashgrove strategy and recent news | skipped | Could not have moved the CO bank: the July 2026 brief you were sent already supplies the priorities and the competitive frame, and is under six months old |
| 4. Interviewer public footprint | n/a | No name was given, so there was no query to form; the interviewer read is absent, and the upgrade menu says what a name would unlock |
| 5. Representative member experience lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A CV or one-page work history → the fit-snapshot rows where your message is silent or thin (F3, F5, F7, F9) can be quoted and regraded, and the F6 row gains something inspected behind it
- Your written answers to the answer slots, outside a drill → each is quoted into the fit snapshot and the rows it touches regenerate: what the monthly spreadsheet was set up to show and what it was built in (F3, F9); whether the formal complaints log followed any outside rules (F7); whether you have presented at regional level or below (F8); whether you have worked with a digital team (F5); whether you have guided anyone at your own level or above on escalations (F4)
- The interviewers' names or public professional roles, once assigned → an interviewer read, persona weights tuned per person, and a reverse question tied to each one's career path
- The case format from the recruiter (live or with material, any scoring criteria) → G1 to G4 can be reshaped to the actual case; usually one email
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a check that nothing has changed since the July 2026 brief, recent organisational context, and the app-only-bank competitive picture, for a fuller grounding brief
- How many hours you have before 20 November → a prioritised prep schedule tied to question IDs
- A `tuesday-dossier.md` from an earlier assessment, if you have one → verified evidence and a constraint on claims, with the most likely objection taken from it rather than inferred here
