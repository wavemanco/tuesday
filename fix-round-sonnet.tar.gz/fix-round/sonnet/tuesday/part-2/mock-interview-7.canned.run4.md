Searches are back, and they found Saltmarsh's own pages. I'm now reading the values page and the interviewing page in full, since the loop format shapes the whole pack.
Your prep pack for Friday is saved. It rests on Saltmarsh's own published pages, and it assumes that Friday is their "Outage Hour".

- **What the Outage Hour is:** Saltmarsh's interviewing page describes one 60-minute hiring-manager interview. It is a tabletop on a simulated outage during a live event, then a values conversation. There is no take-home.
- **What to rehearse first:** the pack names C1 as your highest-ROI question. It's the "no in-app purchases in your background" question, which Saltmarsh's own announcement makes likely: Project Larkspur moves both titles to a season pass from February 2027.
- **Your strongest overlap:** Tobias's GDC 2026 talk is "Patch Notes Are a Promise", and he was previously a QA lead. Your release checklist that QA still uses lines up with that and with the value "Leave the Build Greener".
- **What I could and couldn't quote:** every story in the pack uses only your own sentences. Where your material doesn't carry a story, you get a scaffold or an answer slot, and where you said you lack something (leading a team, in-app purchases), the pack just has you say so plainly.
- **Research limits:** I ran 4 searches and 2 page fetches. I read the Larkspur announcement and Tobias's talk page only as search excerpts, not in full.

The full pack is at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-canned-03bc9283/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 23 questions across seven interviewer styles, a values cheat sheet, six reverse questions, and a list of claims the pack won't coach.

Say the word and I'll run a live drill as the Skeptic on C1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, I'll convert it.

1. Is Tobias the person you'd report to, and did the recruiter tell you anything about the tabletop, such as which title or event it uses? Your answer would reweight the pack and make A1 and A2 specific.
2. Do you want a deeper research pass? It's up to 6 more searches and 2 more fetches, takes several more minutes, and would read the Larkspur announcement and Tobias's talk in full.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

For Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Built on the assumption that Friday is the Outage Hour with Tobias as the hiring manager. Saltmarsh's interviewing page describes one 60-minute hiring-manager interview, a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home. Your note says Tobias is Head of Live Operations and does not say he is the person you would report to.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values |
| EXP | Whether your own claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its current direction |
| CASE | Structure and reasoning on a live problem set in the role |

The highest-ROI rehearsal in this pack is C1, the question on in-app purchases and the season-pass move. It is the most predictable objection to your background, because you have told me the gap exists and Saltmarsh's own announcement points both titles at a season pass. No dossier named it; the pack inferred it.

## 2. Prep triage (Wednesday to Friday)

1. Say C1 aloud three times, with both follow-ups. E1 reuses its two plain acknowledgments.
2. Run A1 and A2 against a timer, speaking the structure aloud. The interviewing page gives the order of the hour, tabletop first and values second, and not the split.
3. Settle B3 and B4, which your material carries. For B1 and B2, find a real story or rehearse the honest branch.
4. Read the Project Larkspur announcement in full, and spend time in Tidepool Tactics or Lantern Row if you can, for A4 and F2. Say only what you actually did.
5. Pick three reverse questions: R1 and two more.

Everything else is insurance.

## 3. Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is your own words from your message; no CV was provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title, with nothing inspected behind it, and the words stay there: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events and two-titles wording makes a probe on timed events and on more than one title likely. If your drops included timed events, say how they were scheduled; if they did not, or you ran only the main title's calendar, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The material shows the calendar and does not show who it coordinated. Answer slot: the JD names four teams, so expect a probe on which of them you dealt with each week. Say which, and how the handoffs worked, in your own words; if some were not part of the calendar, or someone else handled the coordination, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you ran a review or chose what was reported, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on who chose the measures likely. If any choice of what was reported was yours, say what and why; if it was set for you, or no review of a drop followed, say so plainly and stay with presenting the numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms, and the bridge is those terms: "I wrote the release checklist our QA team still uses." Wrote and still uses are the facts; running each release with QA is not in your material, so the line stays at wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Years of experience are not a gate here, so this row is graded like any other. Your material gives four years as an associate producer and two on a calendar, and does not show how many of the four were on a live title. Answer slot: the JD sets 3+ years, so expect a probe on the count. Say how many of the four years the title was live, in your own words; if it was not live for all of them, say so plainly and say which years |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: ran, weekly, main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but no figure is given and the line does not say who counted the numbers, so expect a probe on how they were counted (D1). Lead with the line in its own terms |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written artifact touches the requirement and does not show how you write for players or colleagues. Answer slot: the JD's line makes a probe on written updates likely (A2). If you wrote other updates for colleagues or players, say which, in your own words; if not, say so plainly and stay with the checklist |
| F9 | "season-pass model" — Project Larkspur announcement, September 2026, as returned by search | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." and "I haven't led a team." Then how you would learn it, said as a plan and never as a past. Nothing is added to make either gap feel smaller. The JD asks you to coordinate teams, not lead them; that distinction is the JD's, and C3 uses it |

## 4. Reading the interviewer

Public professional footprint only. Both facts below come from the search excerpt of a GDC 2026 talk page; the talk itself was not read.

| Observation | Source | Provenance | What it means for you |
|---|---|---|---|
| Tobias Wrenfield is Head of Live Operations at Saltmarsh Games; his GDC 2026 talk "Patch Notes Are a Promise" argues that a live team is judged by how often its patch notes describe what actually shipped | GDC 2026 talk page, search excerpt | [grounded] | Expect scrutiny of what gets announced versus what is built. It lines up with the value Ship the Patch Not the Promise, so A2 and B2 are likely. Say only what is confirmed |
| He was previously a QA lead at a console studio | GDC 2026 talk page, search excerpt | [grounded] | Release rigor and the checklist will interest him: B3, E3 and G1. Shared vocabulary, not a shared career jump, is the mirror here: he came from QA, and your F4 evidence is "Wrote the release checklist our QA team still uses." Use it as a plain fact and do not build on any resemblance |
| The Outage Hour is run by the hiring manager | Saltmarsh interviewing page | [grounded] | The pack treats Tobias as that person. If he is not, the persona weights change |

## 5. Persona table

Weights follow the loop and the relationship. Hiring manager is the prior (Case/Strategist and Skeptic). The Outage Hour's two halves, a tabletop and a values conversation, lift Case and Values. Tobias's QA background and talk theme lift release-rigor probes. Your stated gaps feed the Skeptic bank.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | The tabletop: a simulated outage during a live event, plus questions on the Larkspur shared calendar | Highest. Half the stated format is a tabletop, and the hiring-manager prior points the same way | Clarify first, then objective, who you pull in, decision, what players are told, what gets recorded. Challenge one premise politely |
| B. Values/Behavioral | The second half of the hour, against the three published values | High. A loop source documents a values conversation, so it is guaranteed in this session | Map a story to each value where your own sentences carry one. Where none does, pick a real one or say plainly that none comes to mind |
| C. Skeptic | In-app purchases, team leading, one-title calendar versus two titles | High. These are gaps you stated or that the JD's two-titles wording raises; the hiring-manager prior adds weight | Rehearse C1 until it is boring. Plain acknowledgment, a plan, and only the evidence you have |
| D. Data-Driven Prober | The retention numbers you presented | Medium. The JD asks for retention comfort and you presented the numbers monthly | Know how each figure was counted, or say you do not. Name the weakest assumption before they do |
| E. Pressure | Interruptions during the tabletop, and a short challenge on your gaps | Medium. A simulated outage invites time-boxing; no source says Tobias interrupts | Pause, restate, hold the position through two follow-ups, concede specifically |
| F. Conversational | The opening biography and a casual check on whether you know the titles | Low to medium. The hour opens somewhere, and casual questions are still scored | A 90-second arc built from your own sentences. Treat casual questions as scored |
| G. Peer Evaluator | The QA seam and credit across teams | Low. The interviewer is senior to the role. The Larkspur single live-ops group makes the seam topic plausible | Seam principles and reciprocity. Name what you bring, without claiming what you do not have |

## 6. Question banks

### A. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a limited-time event. Players say they can't claim a reward and the support queue is climbing. What do you do in the first fifteen minutes?" | CASE | [generic] | Structure aloud. Clarify first: which title, which reward, since when, is it spreading. Then the objective: players first. Then who you pull in: design, art, engineering and community, plus QA. Then a decision between pausing the event or the reward and patching it. Then what players are told and when, and what gets written down for the review. Challenge one premise politely, such as whether the reports are one defect or several. The question needs no claim about your past, so the guidance makes none | The interviewing page describes a live-incident tabletop, which makes this shape the likeliest first half of the hour. `[generic]` because the actual scenario is unknown and this is a pattern for it; CASE because it scores structure |
| A2 | "Engineering has a fix they trust but it hasn't passed QA, and community wants to tell players now. What does the player message say, and what do you do about the fix?" | CASE | [generic] | Hold the line Saltmarsh publishes: announce what is built, not what is hoped. The first sentence of the message states only what is confirmed. Then what players should do now, and when the next update comes, with a time only if you can keep it. On the fix: ask QA what they can verify and by when, and do not ship what cannot be verified, saying why. No claim about your past | Tests the Ship the Patch Not the Promise value and Tobias's talk theme, and it is also where the JD's written-communication requirement gets scored. CASE with a JD requirement behind it |
| A3 | "Once that outage is over, what would your post-event review cover, and which KPIs would it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: a timeline of what happened and when players were affected; cause and what changes in the checklist; player impact set against an ordinary period; who gets the review and when. Then say what your material carries, at its scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on who chose the measures likely. If any choice of what was reported was yours, say what and why; if it was set for you, or no review followed, say so plainly and return to presenting the numbers | F3 is the weakest-evidenced of the JD's core duties, so a CASE delivery of it is likely. JD because it scores the stated requirement; CASE because it arrives as a live problem |
| A4 | "From February, Tidepool Tactics and Lantern Row share one events calendar. What breaks first, and how would you find out before it does?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first: what shared means here, one calendar, one group, one release train. Then the risks: events from two titles colliding, one team's capacity, an announcement that promises what the other title cannot deliver. Then early-warning signals. Say what you would carry over from the calendar you ran, at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Name the shared-calendar step as the part you would learn from the people already running it | Differentiator question from current strategy, and the Larkspur announcement was read only as a search excerpt. CO because it needs the company's direction; CASE delivery. F1 is the evidence it leans on |
| A5 | "Before an update locks, what do you need from design, art, engineering and community, and what happens when one of them is late?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Structure: what each team hands over, a lock time each, one named owner for the date, and what you do when one is late. This part is a method, not a claim about your past. Answer slot: the JD names four teams, so expect a probe on which you dealt with in the calendar you ran. Say which and how the handoffs worked, in your own words; if some were not part of it, or someone else handled coordination, say so plainly and stay with the calendar | Scores the coordination duty (F2), which your material touches and does not show. JD because it is the stated responsibility |

### B. Values/Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which won?" | VAL | [grounded] | None of your sentences carries this story, so choose one. Pick a time a drop's date or content ran against what players needed. It needs a named stake, what you chose, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Players Before Plans is the first published value and a direct test of calendar ownership. VAL; the open prompt supplies no event |
| B2 | "Tell me about a time you had to say something would not ship as planned, or that a promise could not be kept." | VAL | [grounded] | None of your sentences carries this story, so choose one. It needs what was promised, who you told, and whether the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Ship the Patch Not the Promise, and the theme of Tobias's talk. VAL with some EXP, since the story must survive a follow-up |
| B3 | "Tell me about a time you left a process or a checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4. Beats: you wrote the release checklist, and your QA team still uses it. Tell them in your own words and let the interviewer draw the inference. Answer slot: the value's checklist line makes a probe on what the checklist fixed or replaced likely. If there was something it replaced or an incident behind it, say what, in your own words; if it was written fresh, or there was nothing behind it, say so plainly and stay with: I wrote it and QA still uses it | The one value your material speaks to directly. VAL because it scores Leave the Build Greener; EXP because it will be probed on what was actually you |
| B4 | "Tell me about a time you delivered a number the room did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Beats from the quote: you presented the retention numbers monthly, to the studio head. Answer slot: if any month's number was unwelcome, say what it was, what you said and what happened; if none was, say so plainly and describe how you presented them | The unpopular-truth stem applied to your one quoted reporting duty (F3, F7). VAL with an EXP edge |

### C. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Both of our titles are moving to a season-pass model, and I don't see in-app purchases anywhere in your background. How do you handle that gap?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Say the limit first, before it is asked: "I haven't worked on a game with in-app purchases." Then the plan, as a plan: what you would learn in your first weeks and from whom, such as how the season pass is paced and which revenue figures the review reports, asking the people who run them. Then what you do bring, at its scope: "I presented the monthly retention numbers to the studio head." Do not say it transfers. Follow-up one: retention without purchases is a different problem. Agree it is different, return to the plan, add nothing. Follow-up two: would you own revenue numbers on day one. Concede specifically, naming which reading you would want a partner on, in your own words, and do not fold on the application | F9 is the largest stated gap and Saltmarsh's own announcement points both titles at a season pass, so some form of this arrives. JD because it scores a gap against the role; deepest rehearsal because it is the objection most likely to be asked |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [inferred] "I ran the weekly content-drop calendar for our main title for the last two years." and "Presented the monthly retention numbers to the studio head." and "Never led a team, and never worked on a game with in-app purchases." | Choose one and name it first. The pack's observation, not words for you: your material carries a weekly content-drop calendar for the main title and the monthly presenting of retention numbers, and it does not show the two-title or review-ownership parts. Answer slot: name the part you would be weakest at, in your own words, and the first thing you would do about it | F1, F3 and F9 are where the material is thin. JD because it scores self-assessment against the listing |
| C3 | "You've never led a team, and this role coordinates four of them on every update. How does that work?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment: "I haven't led a team." Then the JD's own word, coordinate: it asks you to coordinate teams, not lead them, and your material does not say you led anyone, so keep it there. Then your method for coordinating, as a plan. Answer slot: the JD's coordinate line makes a probe on what you have coordinated likely. If your weekly calendar meant getting other people to deliver to its dates, say how, in your own words; if it did not, say so plainly and say how you would build that | The second stated gap, aimed at the JD's four-team line (F2, F9). JD; the negative has its source in your own message |
| C4 | "Your calendar was weekly content drops on a puzzle game. Ours is live events across two titles. What changes?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Hold on the quotes: "I ran the weekly content-drop calendar for our main title for the last two years." Concede specifically that events and two titles are the JD's frame. Answer slot: if your drops included timed events, say how you scheduled them; if they did not, or you ran only the main title, say so plainly. Then what you would learn first | F1 is a transferability row: the calendar is real and the JD's frame is wider. JD, delivered as a Skeptic probe |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the retention numbers you presented each month. How was each one counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented and to whom, in the quote's terms. Answer slots for the figure: how it was counted, what moves it, the assumption you would defend least, and which part was yours, each in your own words. If you do not know how a figure was counted, say so plainly. The pack names none of these | F7 gives no figure, so the defend-the-number slots are all open. EXP because it tests what you can stand behind |
| D2 | "Which retention reading would tell you an event worked, and which would fool you?" | JD | [generic] | Structure: pick the few readings you would watch, set each against an ordinary period, and name the one most likely to mislead and why. Naming the weakest assumption before they do is the credibility move. No claim about your past | Scores the retention-comfort requirement as a live problem. `[generic]` because it is a pattern for the problem |
| D3 | "How did the numbers you presented change what you scheduled the next week?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." and "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: the JD's review-and-KPIs line makes a probe on whether numbers fed the calendar likely. If a retention reading ever moved what went into a drop, say what and how you knew; if the two were separate, or nothing changed, say so plainly and return to presenting the numbers monthly | Joins F3 and F6, which your material states separately. The question's premise is not in your quotes, so the guidance does not adopt it |

### E. Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, when you've never led a team or worked on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | Pause and restate. Acknowledge both in one breath: "I haven't led a team, and I haven't worked on a game with in-app purchases." Then hold on what the quotes carry, in order: the calendar, the checklist, the retention numbers. Hold through two follow-ups by returning to them and never adding. Concede specifically that purchases is a learning curve, as a plan | The Pressure form of C1, built from F6, F4, F7 and F9. JD with pressure delivery |
| E2 | "Stop. Engineering says the reward service is fine and community says players are still stuck. Thirty seconds: who do you believe?" | CASE | [generic] | Do not pick a side. Say what you would check: reports by version and platform against service logs, and who you would ask. Hold through the interruption, then concede the uncertainty explicitly. No claim about your past | A pressure variant of the tabletop, since a simulated outage invites interruption. `[generic]`; scores composure, not content |
| E3 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold at the quote's attribution: "I wrote the release checklist our QA team still uses." Hold through two follow-ups by returning to it. Answer slot: if QA or others shaped it, say what part they did and what stayed yours; if it was entirely yours, say so; if part of it started from something you were handed, say that plainly | The attribution probe on F4. Tobias's QA background makes it likelier |

### F. Conversational (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey: what brings you from where you are to live operations here?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." | A 90-second arc in your own words, in this order: the four years as an associate producer at a puzzle-game studio, the calendar you ran, the checklist you wrote. Answer slot: how many of the four years the title was live, if the interviewer asks. For why here, name one thing from Saltmarsh's published values or the Larkspur announcement that genuinely draws you; if none does, say what does | The biography question is scored too, and it carries F5 and F6. JD because it scores the years requirement |
| F2 | "Have you spent time in Tidepool Tactics or Lantern Row?" | CO | [grounded] | Say only what you actually did. If you have not, say so plainly and say what you would look at first. Spending time in both before Friday makes the honest answer a better one | Casual, scored, and cheap to prepare. The titles come from the Larkspur announcement excerpt. CO |

### G. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "QA and live operations sit side by side on a release. Where's the seam, and what happens when we disagree about a date?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Seam principles: one named owner for the date, QA's verification as their call, disagreements settled on facts first. Reciprocity: what you bring to QA is said as a plain fact, "I wrote the release checklist our QA team still uses." Add nothing to it | The QA seam (F4), and the interviewer's QA background. JD |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a real instance where work crossed teams and name what each team did. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. No claim about your past is supplied here | The single live-ops group Larkspur describes makes cross-team credit a plausible topic. VAL; low weight |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, C4 |
| Coordinate design, art, engineering and community teams on each update | A1, A5, C3 |
| Own the post-event review and the KPIs it reports | A3, B4, D2, D3 |
| Manage the release checklist with QA | B3, E3, G1 |
| 3+ years producing live-service games or apps | C2, F1 |
| Experience running a content calendar | C4, F1 |
| Comfortable with player-retention metrics | D1, D2, D3 |
| Clear written communication | A2, B2 — none beyond these, since the interview is spoken; A2 asks you to draft the player message |

## 7. Values cheat sheet

The three published values, by their official names, from Saltmarsh's values page.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players take priority | No story is carried. F6's calendar is the nearest row. Selection scaffold, B1: a time a drop's date or content ran against what players needed, with a named stake and what you chose. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No story is carried. Selection scaffold, B2: a time you said something would not ship as planned, with what was promised and whether the hard truth landed. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." — your message |

## 8. Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You were a QA lead before running live operations. What from those years changed how you run an event calendar?" | Ties to Tobias's own path and invites him to teach, which is a conversation rather than a quiz | [grounded] |
| R2 | "Your GDC talk argues a live team is judged by whether its patch notes match what shipped. How does your team measure that today?" | Shows you read his work and connects it to the Ship the Patch Not the Promise value | [grounded] |
| R3 | "Project Larkspur retires per-title event teams for one live-ops group. How does that change what this role owns compared with the JD's two titles?" | Probes a real mismatch between the JD's wording and the announcement, and it is diligence you need before accepting | [grounded] |
| R4 | "What would the post-event review report on my first event, and who would I learn those numbers from?" | Shows you plan to own the KPIs and openly signals that you will learn the revenue side | [generic] |
| R5 | "What does a strong first ninety days look like in this role?" | Gets the real success criteria in his words, and shows you are thinking in outcomes | [generic] |
| R6 | "After the last live event that went wrong, what changed in the checklist?" | Ties to Leave the Build Greener and to your checklist work, and it reveals how the team learns | [grounded] |

## 9. Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation, not words for you: your material says the main title's weekly content-drop calendar. A4 and C4 stay inside the calendar you ran |
| Coordinated design, art, engineering and community on each update | Inflated form of F2 | F2's quote at its own scope. The pack's observation: your material says the calendar and not who it coordinated. A5's slot stays inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says you presented the numbers, not that you owned the review |
| Managed the release checklist with QA on every release | Inflated form of F4 | F4's quote at its own scope: "Wrote the release checklist our QA team still uses." The pack's observation: your material says wrote and still uses |
| Four years producing a live-service game | Inflated form of F5 | F5's first quote at its own scope: "4 years as an associate producer at a puzzle-game studio." F5's slot asks only how many years were live |
| Has led a team | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases or a season pass | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot; the ramp plan is a plan and never a past |

## 10. Sources

Provided documents: the JD text and your background, both in your message. No CV, no dossier, no assessment, no recruiter notes.

Searches sent, with what came back:

- "Saltmarsh Games values" returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games mobile studio strategy news" returned https://saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise

Pages fetched in full: the values page and the interviewing page. The Larkspur announcement and the talk page were read only as search excerpts.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | The values cheat sheet, section 7, and the B bank; all three values by official name |
| 2. Saltmarsh Games interview process, live operations | yes | The loop: one 60-minute hiring-manager interview, a tabletop then a values conversation. It set persona weights, A1, A2 and E2, and made a values conversation detected |
| 3. Saltmarsh Games strategy and recent news | yes | Project Larkspur: A4, F2, R3 and the C1 premise. Excerpt only |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | The interviewer read, R1 and R2. Excerpt only |
| 5. Representative live-operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- Confirmation that Tobias is your future manager and that Friday is the Outage Hour → persona weights and the Case and Values depth stay as built, or are restructured
- Anything the recruiter told you about the tabletop, such as which title or event it uses → A1 and A2 become specific instead of `[generic]`
- Your CV text → F2 and F8 could move up from `low`, and more stories could be quoted instead of scaffolded
- Your answers to the slots in F1, F2, F3, F5 and F8 → those rows and the questions that draw on them regenerate with your own words quoted
- A retention figure you presented, if there is one → D1's defend-the-number slots become concrete
- The full Larkspur announcement and the talk text or slides → the interviewer read and A4 move from excerpts to full sources
- A tuesday-dossier.md from a role assessment by job-underwriter, if you ever run one → a named objection, strategy limits per weak area, and a prohibited-claims list written from evidence you confirmed
