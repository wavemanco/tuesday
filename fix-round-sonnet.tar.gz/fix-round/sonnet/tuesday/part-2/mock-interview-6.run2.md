Searches were refused, so I'm building the three-round pack from your message alone. It will use generic company questions and won't include a values cheat sheet.
Your prep pack for all three rounds is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-6-denied-c62c3e9c/larkfield-systems_engineering-manager_interview_pack.md`.

It has one shared fit snapshot, then a mini-pack for each round with its own persona weights, 9 questions and 5 reverse questions. It also has a prep schedule, a list of claims the pack won't coach, and a coverage table.

- **Research was refused.** The three web searches on Larkfield (values, interview process, strategy) were denied. The pack rests only on what you told me, so company-specific questions are labeled `[generic]` and there is no values cheat sheet.
- **Assumptions:** It assumes the role description you pasted is the whole JD, and that Round 3 is values-led because the recruiter said so.
- **Highest-ROI prep:** A1, "Which part of this role would you be weakest at on day one?" In your own words, name the hardware gap plainly ("I've never owned a hardware-adjacent roadmap"), then give a ramp plan. It comes back at executive speed as H1 on Monday.
- **Managers gap:** H2 covers "never managed managers." Concede it in your own sentence, don't argue it, and say what you'd do about it as a plan.
- **Numbers:** E1 and E3 cover the 60% on-call drop and the ~40 interviews, which engineers on the panel will test. The pack keeps the 40 as interviews, not hires.

Say the word and I'll run a live drill as the Skeptic on A1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Two things would change the pack: (1) Did the recruiter give any focus areas or a case/presentation for the Thursday panel? (2) Can you paste the full JD or your CV? I can proceed without either.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Role as you described it: "Engineering Manager — Larkfield Systems (industrial IoT, ~600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap."

| Round | When | Who | Relationship |
|---|---|---|---|
| 1 | Tuesday, 45 min | Director of Engineering, the hiring manager and your would-be boss | Manager |
| 2 | The Thursday after, 60 min | Two staff engineers and a product manager | Panel: engineering peers plus a cross-functional partner |
| 3 | The following Monday, 30 min | VP Engineering, described by the recruiter as "values and leadership philosophy" | Skip-level and executive |

No interviewer names were given, so there is no interviewer read. Searches were refused in this session, so everything about Larkfield itself is absent and company-flavored questions are labeled `[generic]`.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: where it quotes you, those are your words from your message, at their own scope.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and leadership, not generic virtue |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The stated responsibilities, including where you are thin |
| CO | Company and strategy knowledge (none in this pack: research was refused) |
| CASE | A live problem set in the role |

An answer slot is an instruction for the interview, not a question for you now: answer from your own experience, or say plainly it was not yours or never happened, and return to what your quotes carry.

## Prep triage (two weeks, three rounds)

1. First, A1: the hardware answer. It is the objection this pack names as the highest-ROI prep, and it recurs in round 3 as H1.
2. Before Tuesday: A1, A2, A3, C1 and C2. Skim B1 to B3 for structure only.
3. Between Tuesday and Thursday: the three number questions E1, E2, E3, then D1.
4. Before Monday: G1, G3, H1, H2.
5. Everything else is insurance.

## Shared fit snapshot

Requirements are quoted from the role description in your message. There is no term in it that is a gate (no location, authorization, schedule or pay line), so no row is a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material says a team lead of six at a payments company; it says nothing about two teams or device-management work, and nothing is inspected behind it. Words stay at the quote: "I've been in engineering for nine years, three as a team lead of six." Answer slot: the role's two squads make a probe on leading beyond one team likely. If you have led beyond your own team, say how, in your own words; if not, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the delivery part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote is a reliability quarter you pushed through, which is adjacent to owning delivery and does not reach it. Words stay at the quote's scope: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." Answer slot: expect a probe on feature delivery rather than reliability work. If you owned dates or commitments for feature work, say which and how you held them; if not, or it was not yours, say so plainly and stay with the quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the hiring part) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap in terms, but a line with nothing inspected behind it, so expect a probe on the number. Lead with it in the quote's own terms: you run the loop for backend roles, and the 40 counts interviews |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the growth part) | none given | none | [grounded] | discovery | Your material shows nothing on helping engineers grow. Answer slot: the role names growth, so a probe on it is likely. If you have helped anyone grow, say who and what you did, in your own words; if not, or it was not yours, say so plainly and say what you would start with |
| F5 | "partner with hardware and product on roadmap" — role description in your message (the hardware part) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The role says partner, and your sentence says owned, so the pack's own observation is that your material does not show whether you have worked alongside hardware teams in any other way; the upgrade menu says what would settle it |
| F6 | "partner with hardware and product on roadmap" — role description in your message (the product part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | Derived from the phrase "roadmap pressure", which touches roadmaps without showing a partnership. Not asserted as your claim. Answer slot: if a product partner was part of that quarter, say what you did with them; if not, or it was not yours, say so plainly and stay with the quarter |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| Lead two squads building device-management services | A2, A4, B1, B3, G4, I1 |
| Own delivery | A3, B1, B2, B3, D4, E1, E2, I2, I3 |
| Hiring | C2, E3 |
| Growth for 11 engineers | G1, G3 |
| Partner with hardware on roadmap | A1, B2, H1 |
| Partner with product on roadmap | B2, D1, D3, F1, F2, I2 |

## Round 1 — Tuesday, Director of Engineering (hiring manager, 45 min)

### Persona weights

Relationship prior for a hiring manager is Case/Strategist plus Skeptic. The loop is established by your own words (three scheduled sessions, who runs each), so no archetype fallback applies.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Skeptic (weight 4) | Probes the gap between your background and this role | Highest. A hiring manager derisks, and your own message names two gaps that map to the role's hardware and two-squad scope (F1, F5) | Rehearse the single most predictable objection until it is boring; say the limit plainly, then a ramp plan |
| B Case/Strategist (weight 3) | Live problems from this role's own work | Medium. A hiring manager buys capability on their actual roadmap; the role description gives the domain, not their live problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C Conversational (weight 2) | Friendly opener and hiring chat | Lower but scored. Casual questions on the hot topics (hiring, your path) still count | A 90-second arc for the biography question; never answer "I think you've covered everything" to the reverse-question slot |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI rehearsal in this pack. Name it first and plainly: "I've never owned a hardware-adjacent roadmap." Do not fill the gap with a bridge; your material carries no adjacent hardware work. Then a ramp plan in your own words, said as future: who you would sit with first, what you would learn about how hardware timelines constrain software commitments, and how that would change what you commit to. Answer slot: if you have worked alongside hardware teams in any form, say how; if not, say so plainly and give only the plan. Hold through two follow-ups by repeating the limit and the plan, never by adding experience | F5 is your own stated gap and aligns with the role's hardware partnership, so this question arrives in some form in this round; JD because it scores the stated requirement |
| A2 | "Two squads is a step up from one team. How would you handle that?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Start from the quote: "I've been in engineering for nine years, three as a team lead of six." Answer slot: if you have led beyond your own team, say how, in your own words; if not, say so plainly and stay with the team of six. If asked directly about managers: "I've never managed managers" (your sentence in your message), then what you would do about that, as a plan | F1 is the scope gap; the question's premise is your own quoted team of six; JD because it scores the stated responsibility |
| A3 | "Walk me through the reliability quarter you pushed through against roadmap pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F2 and F6: the quarter, the push, the roadmap pressure and the drop in on-call burden are the beats the quote states; tell them in your own words. Answer slot: a probe on who pressed and how it was resolved is likely given the role's roadmap partnership. If you worked it out with a product or other partner, say with whom and what was agreed; if it was settled another way or was not yours, say so plainly and return to the quarter | F2 is your strongest quoted story and the likeliest to be walked through; EXP because it tests what was actually yours |
| A4 | "You are at a payments company now. Why industrial IoT, and why this role?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Selection scaffold, because none of your sentences states your reasons: give only reasons that are true, say what pulls you to device management and to this scope, and keep each to a sentence. If no hardware-linked reason comes to mind, say so plainly, then name what does pull you. No claim about your past goes beyond the quote | Motivation consistency is the Skeptic's standing probe; the premise is your quoted current employer |
| B1 | "A firmware update to a connected fleet leaves some devices unresponsive in the field. How do you run the first two days?" | CASE | [generic] | Structure it aloud: what you would ask first (blast radius, whether a rollback exists, who owns customer comms, hardware dependencies), the objective, containment, then diagnosis, metrics and risks. The question needs no claim about your past, so the guidance makes none | A live problem from the role's device-management scope; `[generic]` because it is a pattern for the problem, not a fact about Larkfield |
| B2 | "Product wants a feature next quarter and hardware says the firmware window is later. How do you plan?" | CASE | [generic] | Clarify what each side is committing to and why, find the real constraint, offer options with trade-offs, and say which premise you would challenge. State what you would need from each side. No claim about your past | The role's hardware-and-product roadmap seam, as a decision; `[generic]` |
| B3 | "You inherit two squads: one with a standing on-call problem, one behind on delivery. Where do you start?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure first: what you would measure, what you would ask the squads, how you would sequence. The one story you have that touches on-call is the quarter; if you use it, use it at its quote: "my team's on-call burden dropped 60%." Do not describe how you did it beyond that unless you say it from memory in your own words | Combines the two squads' scope (F1) with your reliability quote (F2); CASE because it is a live problem |
| C1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc built from three quotes: nine years, three as a team lead of six; you run the hiring loop for backend roles; the reliability quarter and the drop in on-call burden. Close with why this role, from your own reasons (selection scaffold, as A4). Add nothing the three sentences do not state | A rapport-style opener is still scored; F1, F2 and F3 are your only quoted material |
| C2 | "How do you approach hiring for a squad like these?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Story-mapped on F3: you run the hiring loop for backend roles; about 40 interviews last year. Answer slot: a probe on what the loop tests and who set it is likely given the role's hiring line. If you designed the loop or its stages, say which; if you run a loop others set, or only took part, say so plainly and return to running it | F3 is your strongest fit for a stated responsibility, so lead from it; JD because the role names hiring |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Do the two squads have leads between this role and the 11 engineers?" | The role description does not say; the answer sets how much your stated "never managed managers" matters, on your terms |
| 2 | "When hardware and product timelines disagree, how does the decision get made and where does it hurt?" | Shows you went to the hardest seam, and tells you how steep your stated hardware gap really is |
| 3 | "Where is delivery strongest and weakest across the two squads today?" | Signals you are thinking about the work, not the title |
| 4 | "What would you want a new person in this seat to learn first about the hardware side?" | Turns your known gap into a mentoring conversation with your would-be boss |
| 5 | "What does growth for engineers look like here today, and what is working?" | Covers the growth line (F4) where your material is silent |

## Round 2 — Thursday panel: two staff engineers and a product manager (60 min)

### Persona weights

A panel blends the top two personas of each member's relationship. Names are unknown, so no per-member assignment. Staff engineers read as peers or technical specialists (Peer Evaluator, Prober); the product manager reads as cross-functional (Values/Behavioral, Conversational).

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| D Peer Evaluator (weight 4) | Seam-splitting between management and technical leadership; what they would need from you | Highest: two of three panelists are engineers who will price what you cost and add to their work | Reciprocity first (what you bring their team); propose seam principles rather than pretending to know the seam; disagreement stories that show spine and tact |
| E Data-Driven Prober (weight 3) | Reads your numbers line by line | Medium-high: your message carries two figures, 60% and about 40 interviews, and engineers test numbers | Know what you can and cannot say about how each number was counted, say plainly when you do not know, name the weakest assumption before they do |
| F Values/Behavioral, cross-functional (weight 2) | A product manager's scenario questions about working across functions | Lower: one panelist, but the role's product partnership line makes it likely | Story where one of your quotes carries it; otherwise a scaffold ending in its honest branch |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between your role and our technical calls, and what happens when we disagree?" | JD | [generic] | Propose principles, not the seam itself, since you do not know it: who owns the what, who owns the how, how a disagreement escalates, how it gets written down. Reciprocity: say what you would bring their teams. For a disagreement story, pick one where you and a technical peer disagreed, with a named stake, a position you held, and an intact relationship at the end; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer Evaluator's standing question; `[generic]` because it is a pattern |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned two teams where credit was a live question, name what you did about it, and keep "we" for the group and "I" for your part. If no such time comes to mind, say so plainly, then say how you would handle it | A persona stem; no quoted sentence carries it, so it is a scaffold, not a story map |
| D3 | "What would you need from me as a staff engineer in your first month, and what would I get from you?" | JD | [generic] | Lead with what you bring them (a plan for how you would protect their time and how you would take their technical calls), then a short list of what you would need. A plan in your own words; no claim about your past | The reciprocity probe: whether the hire reduces or adds to their load |
| D4 | "When a roadmap commitment and an engineer's judgment about quality collide, who decides?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Principle first: who decides on what basis, and how it is written down. The one story you can point to is the quarter, at its quote: you pushed a reliability quarter through against roadmap pressure. Answer slot: if the engineers' judgment was part of that decision, say how; if the call was made another way or was not yours, say so plainly and return to the quote | F2 and F6 touch the collision, and a staff engineer will test it; JD because the role names delivery |
| E1 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend-the-number, in your own words: what was counted, what the figure is most sensitive to, and the assumption behind it you would defend least. Say it before they do. Answer slot: if you do not know how it was counted, say so plainly. Never supply a baseline or a method you cannot repeat under a second question | The headline figure in your message is a magnet target for engineers; EXP because it tests what survives scrutiny |
| E2 | "Which part of that result was yours, and which was your team's?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Use the quote's own split: the push was yours ("I pushed a reliability quarter through against roadmap pressure"); the burden that dropped is "my team's". Answer slot: which other parts were yours, in your own words; if the rest was your team's, say so plainly. Do not claim the whole drop alone | Attribution probe on F2; the honest answer rehearsed is a credibility gain |
| E3 | "About 40 interviews last year. How was that counted, and what is the number sensitive to?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | The noun is interviews. Answer slot: whether you conducted them, coordinated them or both, how they were counted, and what would change the number; if you do not know how it was counted, say so plainly. Do not turn interviews into hires or decisions | F3's number; the quantifier stays attached to interviews |
| F1 | "Tell me about a time you disagreed with a product partner about priorities." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Selection scaffold: pick a time with a named stake, a position you held, and an intact relationship afterward. The nearest thing your material carries is the quarter, at its quote. Answer slot: if the pressure came from a product partner, say who and how it was resolved; if it came from elsewhere, or there is no such time, say so plainly | The product partnership line is a raising source; F6 is only a lead until you answer |
| F2 | "How do you decide what waits when product and engineering both have a case?" | CASE | [generic] | A live decision: say what you would ask first, the criteria you would use, who you would bring in, and how you would record it. No claim about your past | The product manager's likely scenario about how you partner |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | To the staff engineers: "Where do technical decisions get stuck today, and what should an EM do or stay out of?" | Shows you want the seam, not the turf |
| 2 | To the staff engineers: "What would help your team most in an EM's first month?" | The reciprocity question that peer interviewers weight heavily |
| 3 | To the product manager: "How do product and hardware plans get reconciled today, and where does it hurt?" | The seam from your stated gap, asked of the person who feels it |
| 4 | To the panel: "What did the last disagreement between product and engineering look like, and how was it settled?" | Shows you listen for how they resolve disagreement |
| 5 | To the panel: "What would you change about how the squads' work is planned?" | Invites candor and gives you their pain points for round 3 |

## Round 3 — Monday, VP Engineering (30 min, "values and leadership philosophy")

### Persona weights

The recruiter's own words describe a values and leadership-philosophy round, so a values-style round is detected and Values/Behavioral is guaranteed here. The relationship prior for a skip-level is Case/Strategist (strategy-heavy) plus Pressure.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| G Values/Behavioral (weight 4) | Leadership philosophy; scenarios mapped to what Larkfield values (not available: values were not fetched) | Highest: the recruiter said so | Where one of your quotes carries a story, map it; where none does, a scaffold ending in its honest branch; "we" for context, "I" for your part |
| I Case/Strategist (weight 3) | Strategy-altitude problems for the org | Medium: the prior; no Larkfield strategy is known, so questions are `[generic]` | Clarify, structure, metrics, risks; speak at the altitude of two squads and their partners |
| H Pressure (weight 2) | Time-boxed challenge about your gaps | Lower but live: a VP tests composure on exactly what you have stated about managers and hardware | Pause, restate, hold through two follow-ups, concede specifically, never fold on what your quotes carry |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What is your philosophy of leading engineers?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Give two or three principles you actually hold, each in a sentence, each tied to something you did at the quote's scope: the hiring loop you run; the quarter you pushed through against roadmap pressure. Do not say what those prove; describe them and let the VP draw the inference. If a principle has no story behind it, say so plainly and say how you apply it | The recruiter named the round; F2 and F3 are the only stories your message carries |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Selection scaffold: it needs a named stake, a moment you did not fold, and an intact relationship afterward. The nearest thing your material carries is the quarter, at its quote. Answer slot: if leadership was the party pressing, say how the conversation went and what part was yours; if not, or there is no such time, say so plainly | A persona stem; your quote touches the pressure but does not say who applied it (F6) |
| G3 | "How do you think about helping engineers grow?" | VAL | [generic] | Selection scaffold, because none of your sentences carries growth (F4): describe one person or moment where you helped someone grow and what you did, in your own words. If no such time comes to mind, say so plainly, then give how you would begin | The role names growth, and your material is silent on it; this is where the gap is rehearsed |
| G4 | "What kind of leader do you want to be at eleven engineers that you are not at six?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Selection scaffold on the scale step: say what you want to change in your own words, and keep to the quote: you are a team lead of six, and your material does not say how you have led at larger scale. If you have led larger, say how; if not, say so plainly | F1 scope, asked at the VP's altitude; the premise is your quoted team of six |
| H1 | "Sixty seconds: why you over a manager who has already owned a hardware roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause, restate, then concede first: "I've never owned a hardware-adjacent roadmap." Hold only what the quotes carry: you run the hiring loop for backend roles; you pushed a reliability quarter through against roadmap pressure. Then the ramp plan from A1. Hold through two follow-ups by returning to those quotes; never add experience to win the exchange | The Pressure persona on F5; the same rehearsal as A1, at executive speed |
| H2 | "You have never managed managers. Why should I trust you to lead at this scale?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Concede plainly, in your own sentence: "I've never managed managers." Hold: do not argue that you have. Say what you would do about it as a plan, in your own words, and ask the VP what support leaders get here. Answer slot: if any part of your work already involved leading through other leads, say what; if not, say so plainly | The VP's likeliest challenge after the stated gap; hold-then-concede on a negative you stated |
| I1 | "Sketch how you would decide what the two squads should stop doing." | CASE | [generic] | Clarify what each squad exists for, who depends on it, and what a stop costs; then criteria, a sequence, and how you would tell the squads. No claim about your past | A live problem at the role's altitude |
| I2 | "A large customer asks for a device-management feature that would slow your platform work. How do you decide?" | CASE | [generic] | Clarify the ask and its real constraint, the options and trade-offs, how you would bring product and hardware in, and what you would commit to. Challenge one premise respectfully | The role's product and hardware partnership at executive level; `[generic]` |
| I3 | "Six months in, how would you know the two squads are healthy?" | CASE | [generic] | Name a short set of measures for delivery, quality, on-call load and people, how you would read them together, and what you would change if they disagreed. No claim about your past | A metrics-and-judgment case on the role's scope (F2 requirement) |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does good leadership of this organization look like to you, and where is the gap today?" | Gets the VP's own philosophy in the open, which this round is about |
| 2 | "How do hardware and software priorities get arbitrated at your level?" | Shows altitude and probes the seam you have not owned |
| 3 | "How are engineering managers expected to develop engineers here, and how is that supported?" | Covers the growth line (F4) and asks about support for a first-time manager of this scale |
| 4 | "What mistake do you most want a new EM here to avoid?" | A philosophy question that invites candor |
| 5 | "What would success look like for this role at six months, from where you sit?" | Closes on the outcome the VP cares about |

## Prohibited claims

Not coached in any answer, slot, hold, bridge, rationale or drill feedback.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led two squads or managed eleven engineers | Inflated form of F1 | F1's quote at its own scope; the limit is the pack's observation: your material says a team lead of six, not two squads |
| Has managed managers | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | "I've never owned a hardware-adjacent roadmap." No slot |
| Single-handedly cut on-call burden by 60% | Inflated form of F2 | F2's quote at its own scope; the limit is the pack's observation: your material says the burden dropped after you pushed the quarter through, not that your push alone produced the 60% |
| Made hiring decisions for, or hired, about 40 people | Inflated form of F3 | F3's quote at its own scope; the limit is the pack's observation: the number counts interviews |

## Sources

Provided documents: your message (the role description, the three rounds and the recruiter's note on round 3, your background). No `tuesday-dossier.md` was present; no CV or full JD was supplied.

Searches sent, all refused:

- `Larkfield Systems industrial IoT company values` — refused
- `Larkfield Systems interview process engineering manager` — refused
- `Larkfield Systems industrial IoT device management news strategy` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have moved the values cheat sheet (section dropped) and the Round 3 VAL bank, which is now built on the recruiter's words and `[generic]` scaffolds |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have moved whether a case or presentation is expected in the panel; persona weights stand on your own description of the three rounds |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have moved the CO and CASE banks; the CASE questions are `[generic]` and there are no CO questions |
| 4. `{interviewer name} Larkfield Systems` | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search the web → Larkfield's published values, loop structure and strategy: the values cheat sheet appears, CASE questions become `[grounded]` company questions, and a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) becomes available once
- Full JD text → the six fit rows quote the posting itself instead of your summary, and mid-list requirements get their own questions
- The recruiter's notes on each round (focus areas, any case or presentation the panel expects) → coverage assumed from round-type priors becomes real, and a build section appears for any announced deliverable
- Interviewer names → an interviewer read, persona weights per panel member, and a reverse question tied to each person's path
- Your CV → more quoted evidence per row, so scaffolds become story maps, and F4 and F6 can move off `none given` and `low`
- Your answers to the answer slots in F1, F2, F4 and F6, and a statement of whether you have worked alongside hardware teams in any form → each moves the rows it names; the last one settles F5's open observation
- A `tuesday-dossier.md` → would carry verified evidence and the gaps this prep exposes into later sessions
