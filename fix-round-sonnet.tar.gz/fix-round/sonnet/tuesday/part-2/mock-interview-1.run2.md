The web searches were refused, so this pack rests on the material you gave me and no outside research. I'm now writing it to a file.
Your prep pack for the Dan Kovac conversation is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-1-denied-d949f3bb/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

I built it for a single 60-minute peer conversation with Dan, from your message alone. The three web searches (values, interview process, Dan's public footprint) were refused, so there is no outside research. Dan's read comes only from the profile description you gave me, Northwind's published values were not retrieved, and the loop is taken from what you told me.

- **Persona weights:** Peer Evaluator and Data-Driven Prober are the top two. Case/Strategist and Skeptic are mid-weight. Conversational, Pressure and Values are low, because Dan is a peer who describes himself as data-driven, not a skip-level or a stress interviewer.
- **Size:** the pack has 22 questions in seven banks, with a requirement-coverage table and six reverse questions. Two of the reverse questions are tied to Dan's own pricing and startup path, and one is the peer reciprocity question.
- **Highest-ROI prep (D1):** the sales-ops gap, which you stated yourself. Dan runs that territory, so expect it in some form. D1 gives the plain acknowledgment, the nearest thing Priya's material supports at its own scope, and a ramp plan.
- **Second-biggest prep item (B1/B2):** the ~$400M ARR figure. Her material says she proposed the change and that it was credited with the uplift. The pack does not let her say she led or delivered it.
- **Dropped sections:** the prep triage and delivery coaching sections, because they need inputs I don't have. The values cheat sheet is also dropped, because no values round was established and no values were retrieved.

Say the word and I'll play Dan as the Skeptic on D1, the question the pack names as the highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would restructure the pack:
1. Did the recruiter or hiring manager say anything about what this conversation will cover, or ask for a pre-read? A declared deliverable would get its own section.
2. Can you paste the full JD text? Any requirement beyond the six highlights currently has no question.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer; both report to the same VP. **Round:** one 60-minute conversation.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Behavior that shows values, shown through past conduct and not generic virtue |
| EXP | Whether claims on your CV survive scrutiny, and what was actually yours |
| JD | A stated responsibility or requirement of the role, including its gaps |
| CO | Company and strategy knowledge, and thinking at the company's altitude |
| CASE | A live problem set in the role; it asks about no past |

Answer slots are instructions for the interview, not questions for you to answer here. Each has two honest branches. If you did the thing, say how, in your own words. If there was no such step, or it was not yours, say so plainly and return to what you did do.

## Fit snapshot

Requirements 1 to 6 are the JD highlights as you gave them. Row F7 is the pack's addition, because the interviewer owns that territory.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "9 at a large consumer-tech company in product strategy & ops" — your message; "2 years strategy consulting at a top firm" — your message; "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | Your material says product strategy and a proposal, not go-to-market ownership, and the words stay there: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's two new product lines make a probe on taking a product to market likely. If any of your work covered how a product reached customers, say which part, in your own words; if none did, or it was not yours, say so plainly and stay with the product strategy and the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | low | [inferred] | discovery | The pack derives a link from a growth proposal to lifecycle whitespace; the quote does not show any lifecycle stage. Answer slot: the JD names four stages, so expect a probe on which you have worked. If any, say which and what you looked at, in your own words; if none, or it was not yours, say so plainly and say how you would start |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | No gap in terms, but a self-assessment with nothing inspected behind it, and this interviewer self-describes as data-driven. Lead with the quote's own terms, and have one analysis you can walk through end to end (B3) |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not the design of a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: expect a probe on what "partner-level" meant and on how partners were to bring a product to market. Say what partner-level meant in your own words; if the model shaped how a partner sold or supported a product, say how; if it did not, or that was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | none | The quote already reaches the requirement in role terms. Lead with it as written: targets, annual, set with consensus across orgs. A CV line with nothing inspected behind it, so expect a probe on how consensus was reached (A2) |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | none | The quote states daily use, and the pack observes it does not state building or shipping anything. Say "use" and name the tools and tasks yourself (E2) |
| F7 | Sales-ops and quota-setting fluency, as a Director of Sales Strategy would test it; not in the JD highlights | "No classic sales-ops or quota-setting experience" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Reading the interviewer

Public footprint was not researched (search was refused). Everything below comes from the profile description you supplied.

| Signal (source) | Practical implication | Provenance |
|---|---|---|
| "relentlessly data-driven" — his profile, as you described it | Expect every number you give to be taken down to its assumptions. Know how each CV figure was counted, and say plainly when you do not know | [inferred] from the stated self-description |
| "pricing and monetization roles" — his career spine, as you described it | Expect cases tilted to pricing, packaging and unit economics. Bring that vocabulary into the case answers without claiming experience in it | [inferred] from the stated career pattern |
| "one early-stage-startup chapter" — his profile, as you described it | Builder-style stories may land; expect a probe on whether you can work at a scale with less structure than a large company | [inferred] from the stated career pattern |
| Peer; same VP (your message) | He is pricing what your arrival does to his workload. Come with what you bring to his team, not only what you need | [inferred] from the relationship |
| Mirror opportunity: shared vocabulary of monetization | Your side of it is F4's sentence, at its scope: "built a partner-level revenue model used in carrier negotiations". No shared career jump is offered, because no row carries one | [inferred] |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (bank A, 5 questions) | Seam-splitting between your role and his, collaboration scenarios, credit, "what would you need from me" | Highest. The relationship prior for a peer is Peer Evaluator plus Data-Driven Prober, and he would share a VP with you | Reciprocity: say what you bring his team. Offer seam principles as hypotheses to test with him, not as claims about where Northwind draws the seam |
| Data-Driven Prober (bank B, 5 questions) | Takes each number down to its inputs and assumptions; follow-ups go two levels deeper | Highest. The peer prior, raised by "relentlessly data-driven" | Know how the ~$400M figure was counted and say plainly what you do not know. Name the assumption you would defend least before he does. Offer to walk through an analysis end to end |
| Case/Strategist (bank C, 3 questions) | A live problem on a role-relevant topic, in pricing, packaging and expansion terms | Middle. Not a hiring manager, so not dominant, but the pricing and monetization spine tilts cases toward his native ground | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud; challenge one premise respectfully |
| Skeptic (bank D, 3 questions) | Quiet persistent probing of the sales-ops gap and the move from consumer tech | Middle. F7 is a stated gap and he owns that territory | Rehearse the sales-ops objection until it is boring. Calibrated candor over bluffing a competency he owns |
| Conversational (bank E, 2 questions) | Opener and an AI question in a casual register | Low to middle. The biography opener and the JD's AI plus both arrive casually and are still scored | A 90-second arc; treat the AI question as scored |
| Pressure (bank F, 2 questions) | Time-boxed challenges, devil's advocate | Low. A peer conversation, and his stated style is analytic, not stress-based | Pause, restate, hold the position through two follow-ups, concede specifically |
| Values/Behavioral (bank G, 2 questions) | Scenario prompts on past conduct | Low. The loop is one peer conversation, and no values-style round was detected | Selection scaffolds only; see the note under bank G |

## Question banks

Highest-ROI prep in this pack: **D1**, the sales-motion objection. It is aimed at F7, it will arrive in some form from a Director of Sales Strategy, and a rehearsed non-defensive answer changes the conversation.

### Bank A — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side — where's the seam between your role and mine, and what happens when we disagree?" | JD | [generic] | Offer principles as hypotheses to test with him, since you do not yet know where Northwind draws the line: who decides what, which data both teams treat as the source of truth, and where an unresolved disagreement goes — the shared VP. Then ask him how it works today. The question needs no claim about your past, so the guidance makes none | Peers split seams early, and F5's requirement presses here. JD because it scores the stated influence requirement; the delivery is the Peer Evaluator's stem |
| A2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the annual volume targets, set with consensus across orgs; tell the beats the sentence states and no more. "We" for context, "I" for what was yours. Answer slot: a probe on where the orgs differed is likely. If they did, say what happened and which part was yours; if consensus was straightforward, or the targets were not mainly yours, say so plainly and stay with the sentence | F5 is the evidence for influence, so a credit probe follows it. VAL because credit-sharing scores conduct; EXP-style attribution honesty rides inside it |
| A3 | "What would you need from me in your first thirty days, and what could you give my team?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with the reciprocity half. What you offer is a forward-looking statement, not a past claim: that you are skilled in SQL and Tableau, in the quote's words, and could take analysis requests on the new lines. Then what you would need from him, framed as what you want to learn: how targets and pipeline definitions are set. Avoid guessing at his team's pain | The peer prior makes the reciprocity question likely, and F3 is the only row that offers him something concrete. JD because it scores role fit with an adjacent owner |
| A4 | "Tell me about a time you disagreed with a peer team on a number or a target, and how it resolved." | VAL | [generic] "set annual volume targets with cross-org consensus" | Selection scaffold: pick a time that has a named stake, a moment you held your position, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — the sentence quoted here, at its own scope: targets set with cross-org consensus — or how you would handle it | The Peer Evaluator's counter-strategy is a disagreement story showing spine and tact. F5 is the nearest row but states consensus, not disagreement, so the pack gives a scaffold and not a story |
| A5 | "When your pipeline numbers and mine disagree, whose do we use?" | CASE | [generic] | Structure it aloud: agree the definitions before arguing the number, name a source of truth and who maintains it, reconcile in writing, escalate only what definitions cannot settle. The question asks about no past and the guidance makes no claim about yours | A data-driven peer will test how you handle shared numbers. CASE because it is a live decision, not a recounted event |

### Bank B — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Four slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. Name the weakest assumption before he does. Where you do not know how it was counted, say so plainly. The pack supplies no method, baseline or attribution model | A headline figure is the first target for a prober; F1 carries it. EXP because it tests whether the number survives scrutiny |
| B2 | "How much of that uplift was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold the sentence at its scope: you proposed the change, and it was credited with the uplift. Do not say led, built, delivered or owned. Answer slot: if you were involved in carrying the change out, say what you did; if not, or it was others' work, say so plainly. Hold through two follow-ups by returning to the proposal; concede specifically what you do not know | Attribution probes follow every large figure. The held position is only what the quote carries; F1 is the row |
| B3 | "Tell me about an analysis you ran yourself in SQL or Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold, because the quote states a skill and no analysis: pick one you personally ran, with a clear question, the data you used, the definitions you chose and the decision it changed. Offer to walk through it end to end. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach one | The JD says independent analysis; F3 is a self-assessment this interviewer will want evidence for. JD because it scores the stated requirement |
| B4 | "Walk me through the revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: you built a partner-level revenue model, and it was used in carrier negotiations; those are the beats. Answer slot: say what partner-level meant, in your own words; if the model shaped how the partner's terms were set, say how; if there was no such step, or it was not yours, say so plainly and stay with the model | The monetization-minded interviewer will go to the model first. F4 is also where the partner-motion requirement presses; EXP because it tests what the candidate built |
| B5 | "Pick one metric you'd watch for the first ninety days of a new product line across land, adopt, expand and renew, and tell me how it could mislead you." | CASE | [generic] | Name the metric and what decision it feeds, then the way it misleads: lagging, easy to game, or blind to a stage. Say the second metric you would add to cover that. The question asks about no past and the guidance makes none | F2's requirement made live, in a prober's register. CASE because it is a problem set in the role |

### Bank C — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor is bundling against us. How would you shape the go-to-market for a new product line to stand up to that?" | JD | [grounded] research note: "main competitive threat is bundling by a much larger platform vendor" | Clarify first: which product line, who buys, how it is sold today and what it is priced on, asked as clarifying questions of him. Then objective, segmentation, approach, metrics, risks. Use pricing and packaging as a lens, since that is his native ground, and challenge one premise respectfully | F1's requirement set against the stated competitive threat. JD for the ownership requirement, with CASE delivery |
| C2 | "Enterprise expansion is a stated priority. Where would you look for whitespace across land, adopt, expand and renew for an emerging product?" | JD | [grounded] research note: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Structure by stage; say what data you would pull first, in SQL or Tableau terms; then where you would expect the biggest gap and how you would test it. A hypothesis stated early, then revised aloud | F2's requirement tied to a stated priority. JD because whitespace is a listed responsibility; CASE delivery |
| C3 | "Compass, the AI copilot, is launching, and the company also wants profitability. Which accounts would you take it to first, and how would you package it?" | CO | [grounded] research note: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Clarify what you do not know about Compass: its buyer, how it is positioned today, and whether it is sold alone or with something else. Then sequencing logic, a packaging hypothesis stated as a hypothesis, and what would make you change it. Do not assert facts about Compass that you were not given | Two of the three stated priorities in one question; CO because it tests whether you can think at the company's altitude. Pricing tilt follows his career pattern (see the reading section) |

### Bank D — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your background is product strategy and ops, not sales ops. Where does that leave you on the sales-motion side of land, adopt, expand, renew?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "9 at a large consumer-tech company in product strategy & ops"; "set annual volume targets with cross-org consensus" | The deepest rehearsal in this pack. Open with the plain acknowledgment: "I haven't had classic sales-ops or quota-setting experience." Then the nearest thing at its own scope: "I set annual volume targets with cross-org consensus." Do not call them quotas, and do not add territory, compensation or pipeline work you never mentioned. Follow-up one: so you've never set a quota. Hold: yes, and say again what you did do. Follow-up two: why trust you on a number you haven't carried. Concede specifically that this is a real learning curve, and give a ramp plan, said as a plan: what you would learn from his team first and how you would check your assumptions with them. Follow-up three: what would you get wrong first. Name one candidly, without bluffing a competency he owns | F7 is a stated gap in his own domain, so this is the most predictable objection. JD because it scores the sales-motion half of the requirement; Skeptic delivery |
| D2 | "Why Northwind, and why a ~3,000-person B2B data-infrastructure company after consumer tech?" | CO | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Three parts: what draws you to B2B emerging products, what Northwind's stated priorities (enterprise expansion, Compass, profitability) mean for the work you would do, and why now. The reason is yours; the pack does not supply it. Answer slot: state your actual motive, in your own words; if the real reason is mixed, say so plainly | Motivation consistency is what a Skeptic scores. CO because the answer should draw on what Northwind has said, and F1 is the background being moved |
| D3 | "The role requires partner-motion design experience. When have you designed how a partner brings a product to its customers?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Selection scaffold ending in its honest branch: pick a time that has a named partner, a motion you shaped and an outcome you can describe. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — the model quoted here, at its own scope — or how you would design one. The pack observes that a revenue model used in negotiations is not a partner motion, and you should not call it one | A required item, and F4 is transferability, so a probe is certain. JD because it scores the stated requirement; Skeptic delivery |

### Bank E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc in three beats the quotes state: two years of strategy consulting at a top firm; then nine years in product strategy and ops at a large consumer-tech company; then why this role. Rehearse until it is boring, and add no title, team size or scope you did not give | The opener is scored. F1 supplies both beats. EXP because it tests the CV's shape and economy |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Answer slot: name the tools and the tasks in your own words; say whether you use them or build with them, and do not blur the two. If your use is lighter than daily on some tools, say so plainly. Then one thing you would want to learn about Compass, as curiosity and not as expertise | The JD lists AI experience as a plus and a casual register hides a scored question; F6 is the row. JD because it scores a listed plus |

### Bank F — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who has carried a quota?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Pause, restate. Hold-then-concede: concede first, "I haven't had classic sales-ops or quota-setting experience." Then the two quoted sentences at their own scope, and what you would do in the first weeks. Do not claim to be better; do not tell him what your work proves. Hold through two follow-ups; concede specifically what you would not yet know | F7 again, in a time-boxed register. JD because it scores the same requirement as D1 with composure added |
| F2 | "I'm not sure we need this role. Convince me." | JD | [generic] | Do not defend. Ask what problem he sees today, then say what the role would own, using the JD's own words: GTM strategy for two new product lines. Hold your position through two pushes; concede that the answer depends on what he sees in the field. The question needs no claim about your past | A peer who shares a VP may test whether the hire adds to or lifts his load. JD because it scores F1's ownership requirement under pressure |

### Bank G — Values/Behavioral

No values-style round was detected and Northwind's published values were not retrieved, so these are persona-stem questions only. They become mapped to named values if you supply the values page.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time that has a named stake, a moment you did not soften the message, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The behavioral stem, kept short because the round is one peer conversation. VAL because it scores conduct |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time that has a named customer or partner, the metric that pulled the other way, and what you chose. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Customer-over-metric stories can land with a pricing-minded peer. VAL because it scores conduct; low weight because no values round is established |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| own GTM strategy for two new product lines | C1, F2, C3 |
| identify whitespace across land/adopt/expand/renew | C2, B5 |
| run independent analysis in SQL and Tableau | B3, A3 |
| partner-motion design experience required | D3 |
| strong cross-functional influence | A1, A2, A3, A4 |
| AI experience a plus | E2, C3 |
| Headline figure on the CV (~$400M ARR) | B1, B2 |
| Sales-ops and quota-setting gap (F7, not in the highlights) | D1, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent your career in pricing and monetization roles. How does that lens shape how you judge a go-to-market motion for a new product, and where has it misled you?" | Tied to his own path; turns an interrogation into a peer conversation and shows the research was on him |
| R2 | "What from your early-stage-startup chapter do you still use here, and what did you have to unlearn at this size?" | Tied to his own path; invites a story and is a natural way to ask about pace |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it signals you are thinking about his load |
| R4 | "Where do your team and the emerging-products work disagree most today about how a new line should be sold, and how do you two settle it?" | Names the seam directly and tests how he handles disagreement |
| R5 | "With a much larger vendor bundling, which signal tells you first that a new line is being displaced?" | Uses the stated competitive threat and speaks to a data-driven reader |
| R6 | "How would Compass change what expansion means in how your team plans and forecasts?" | Ties to a stated priority and asks about his work, not just the product |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a quota, or done sales ops | Negative the candidate stated, F7 | The plain acknowledgment: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Set quotas; treated annual volume targets as quotas | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says annual volume targets, not quotas |
| Led, delivered or owned the store-surface change or the ~$400M uplift | Inflated form of F1 | F1's quote at its own scope: proposed, and credited with. The material says a proposal, not delivery |
| Owned go-to-market strategy for a product line | Inflated form of F1 | F1's quotes at their own scope. The material says product strategy and ops, not GTM ownership; the slot stays inside that |
| Designed partner motions | Inflated form of F4 | F4's quote at its own scope: a revenue model used in carrier negotiations. A revenue model is not a partner motion |
| Built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily |

## Sources

Provided documents: your message (role and company, JD highlights, candidate summary, interviewer profile description, and the research note on Northwind's priorities and competitive threat). No dossier was present.

Searches sent:

- "Northwind Data company values" — refused
- "Northwind Data interview process strategy GTM" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The one call was refused. It would have named published values for VAL questions and a values cheat sheet; none was built, because no values-style round was detected either |
| 2. `Northwind Data interview process` | unavailable | The one call was refused. It would have confirmed whether other rounds exist. Persona weights rest on your own words (one 60-minute conversation with a peer) and the relationship priors |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note supplies the three priorities and the competitive threat, which fix the CO and CASE questions |
| 4. `Dan Kovac Northwind Data` | unavailable | The one call was refused. It would have added his talks and writing to the interviewer read and the reverse questions; his signals are from the profile description you gave |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → mid-list requirements beyond the six highlights get their own questions, and any requirement written as a gate (location, authorization, schedule) gets surfaced
- Recruiter or HR guidance on this conversation's focus or any pre-read → coverage reweighted; a declared deliverable would get its own build section
- Dan's talks, posts or interviews → his recurring themes become likely questions and sharper reverse questions
- Northwind's published values page → the Bank G stems map to named values with stories, or scaffolds where none of your sentences carries one
- Your answers to the answer slots in F1, F2, F4, B2, B4 and E2 → those rows get story-mapped guidance; say each outside a drill, in your own words
- A fuller version of the company research (up to 6 more searches and 2 more fetches, several more minutes, needs search enabled) → a grounding brief, and CO and CASE questions grounded in more than your note
- The names of the two product lines, and what Compass is → C1 and C3 stop being generic about the product
- A `tuesday-dossier.md` from an earlier role evaluation → a verified-evidence base and an underwriter-named objection in place of the one inferred here
