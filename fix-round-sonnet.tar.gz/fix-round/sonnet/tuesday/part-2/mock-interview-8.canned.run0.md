No dossier present. Reading the files the playbook names.
Dara, your prep pack for all three rounds is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-canned-245557e8/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as one pack with a separate section per round, because the recruiter's email gives the full schedule. Interviewers aren't named yet, so the personas follow each round's role and format. I ran no web searches. Your pasted JD, values, recruiter email and strategy summary already covered everything I would have looked up. I haven't seen the strategy brief itself, only your summary of it.

- **Fit snapshot:** it quotes only your own sentences and shows where your material is thin. The contact centre and presenting above regional level are gaps you stated yourself, so the pack gives you plain wording to acknowledge them. The scope of the complaints process, regulated complaints, digital self-service and coaching supervisors need your own examples to firm up.
- **Highest-ROI prep:** question 2A1, in the manager round. It asks what part of a complaints process you have owned yourself. The pack has you hold to "I handled the branch's formal complaints log", name the contact-centre limit before they do, and rehearse three follow-ups.
- **Round 3:** the pack has one question per Ashgrove value, plus practice escalation cases. The case prompts are practice shapes, because the recruiter has only said the case is on a complaint escalation. None of your sentences carries a story for any of the four values yet, so those answers are selection scaffolds. They will only turn into real stories once you tell me one.
- **Prohibited claims:** the pack won't coach you to say you owned the process end to end, coached supervisors, or presented above regional level.

Say the word and I'll play the Skeptic on 2A1, with follow-ups reacting to what you actually say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack — Member Experience Lead, Ashgrove Credit Union

Prepared for Dara, 11 November 2026, for three rounds on 20 November 2026. Loop mode: one shared fit snapshot, then one mini-pack per round.

| Round | Who | Relationship | Length | Source |
|---|---|---|---|---|
| 1 | The recruiter | Recruiter screen | 30 minutes | "30 minutes with me" — recruiter's email |
| 2 | The Head of Member Services | Hiring manager | 45 minutes | "45 minutes with the Head of Member Services, who would be your manager, mostly behavioural" — recruiter's email |
| 3 | A panel of two branch managers | Panel, and the values round | 60 minutes | "60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation" and "The panel is also the values round — they score against the four values." — recruiter's email |

No interviewer has been named, so there is no interviewer read. Everything below is proposed language, pending your approval.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether what you did survives scrutiny, and what was actually yours |
| JD | A stated requirement in the posting, gaps included |
| CO | Homework on Ashgrove: strategy, competition, what makes it different |
| CASE | A live problem set in the role, scored on structure and reasoning |

Question IDs read round, persona letter, number: 2A1 is round 2, persona A, question 1. Highest-ROI prep in the pack: 2A1, the question on what part of a complaints process you have owned yourself. It is the most predictable objection to this material, it comes from the hiring manager, and it carries the most follow-up levels. The gaps behind it are F1 and F2.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the JD you pasted. Evidence is your own sentences from your message, nothing else. No requirement in the JD is a gate in the sense of a licence, location, schedule or pay term, so no row is a hard gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what came after the log likely. If any later step was yours to decide, such as where a complaint went, how it was closed or what the member was told, say which and how, in your own words; if the log was where your part ended, or none of that was yours, say so plainly and stay with the log |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then a plan, said as a plan and never as a past: what you would find out first about how complaints reach the contact centre. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | The quote says a formal log, not what rules it was kept to, and the bridge should not widen it. Answer slot: the JD's regulatory requirement makes a probe on what governed your log likely. If the log had to meet any external rules or deadlines you know of, name them in your own words; if you do not know of any, or tracking them was not yours, say so plainly and stay with the log you handled |
| F4 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote says a monthly spreadsheet your regional manager uses; it does not show what the spreadsheet counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours held. If it counted either, say which and how it was counted, in your own words; if it held something else, say what; if you do not know how a figure in it was counted, say that plainly |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, with nothing inspected behind it, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line points at supervisors, so expect a probe on anyone beyond new tellers. If you have guided supervisors or colleagues through an escalation, say who and how, in your own words; if not, or it was not yours, say so plainly and stay with the tellers |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not mention digital or self-service work. Answer slot: the JD names digital teams and self-service journeys, so expect a probe. If you have worked with a digital, product or app team, or been part of a change to a member journey, say what and which part was yours, in your own words; if not, say so plainly and answer as how you would work with them |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: "I have six years in retail banking, the last three as a branch supervisor." The pack's observation: the JD says customer operations and your material says retail banking, so a probe on whether that includes contact-centre work is likely, and F2 holds the answer |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." The pack's observation: your material does not establish whether a regional manager counts as a senior leader at Ashgrove. Then how you would prepare, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The quote says spreadsheet and the JD says Excel reporting; the words stay the quote's: "I built the monthly complaints spreadsheet our regional manager uses." The pack's observation: your material does not name the tool |

## Grounding brief (shared)

The strategy section rests on your summary of the July 2026 brief, which the recruiter sent you. The pack has not read the brief itself. Both tables are scaffolding for sounding current, not for reciting. The brief is equally available to every other candidate, so show you read it with one item and then add a view of your own.

| Brief item | Wording as you gave it | Provenance |
|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" — your message | [grounded] |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" — your message | [grounded] |
| New product | "launch a small-business lending product in Q1 2027" — your message | [grounded] |
| Competitive frame | "the main competitive pressure is app-only banks" — your message | [grounded] |

| Reading for this role | Derived from | Provenance |
|---|---|---|
| As more service moves to digital channels, complaints may arrive where a branch log does not see them, which makes cross-channel counting a live question for the monthly report | The digital shift item and the JD's monthly-reporting line | [inferred] |
| Moving from eight branches to five hubs puts a question on who keeps hold of a complaint about a branch that is changing, which sits against the value "Neighbours, Not Numbers" | The consolidation item and the values page you pasted | [inferred] |
| A new lending product in Q1 2027 may bring a new kind of member complaint; treat it as a question to ask, not a fact about Ashgrove | The new-product item | [inferred] |

---

# Round 1 — the recruiter (30 minutes)

## Persona table, round 1

Everything proposed here is pending your approval.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured openers that are still scored | High. The recruiter-screen prior is Conversational plus a light Skeptic, and the round is "30 minutes with me" | A pre-scripted 90-second arc for the career question; treat casual questions about JD topics as scored; never answer "I think you've covered everything" at the reverse-question slot |
| Skeptic, light | Knockout-style checks on the JD, asked in a friendly register | Medium. The same prior carries it, and your two stated negatives are the first things a screen checks against the JD (F2, F3) | Rehearse the single most predictable check until it is boring: the plain acknowledgment, then a plan |
| Not banked | Prober, Pressure, Case, Values, Peer | Low here. You have no figure for a Prober to test, and the case and the values scoring sit in round 3 by the recruiter's own words | Covered in rounds 2 and 3 |

## Question bank, round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "Walk me through your journey in retail banking." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | A 90-second arc on the beats the sentence states: six years in retail banking, the last three as a branch supervisor, in your own words and in that order. Add nothing the sentence does not say, such as titles, team sizes or dates | F7 is the evidence for the years requirement and the usual opening of a screen; EXP because it tests the account of the career, with JD scoring on the years line |
| 1A2 | "What draws you to a member-owned credit union?" | CO | [grounded] | Use Ashgrove's own words, not yours for them: the values page you pasted opens "Members First, Always — we decide from the member's side of the counter." Pick the one value that is true for you, say why in your own words, and stop. The answer makes no claim about your past, so the guidance makes none | A screen checks that the motivation is real; CO because it tests homework on what makes this employer different, and "member-owned" is the JD's own description |
| 1A3 | "What have you read about where Ashgrove is heading?" | CO | [inferred] | Show you read the brief with one item, "move 40% of member service to digital channels by 2028" or "consolidate eight branches into five hubs over 2027", then add one view of your own: ask what the move changes for where complaints land and who keeps hold of them. Put it as a question you would want answered, not as a fact about Ashgrove. Do not recite all four items | The items are grounded in the brief; the view is derived from them, so the row is inferred. CO because it tests current strategy, and the brief is the one source every candidate shares |
| 1A4 | "What did the complaints side of your branch work look like day to day?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." and "I built the monthly complaints spreadsheet our regional manager uses." | Three beats, each in the sentence's own words: you handled the branch's formal complaints log, you trained new tellers on the escalation script, you built the monthly complaints spreadsheet your regional manager uses. Tell them as stated and stop. If a follow-up goes past a beat, answer inside it or say plainly you would have to check. No stages, volumes or outcomes | F1, F4 and F5 are your three complaints sentences, and a recruiter reads them against the JD; EXP because it tests what was actually yours |
| 1A5 | "When have you worked with a digital or product team?" | JD | [grounded] | The JD names self-service journeys, so expect this. Pick a time you worked alongside a digital, product or app team, or were part of a change to a member journey; it needs who was involved, what changed and what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would work with them | F6 is silent on this requirement, so the answer is yours to supply; JD because the requirement is stated and unevidenced |
| 1B1 | "You haven't worked in a contact centre — how would you handle that part of the role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it first and plainly: "I've never worked in a contact centre." Then a plan, said as a plan: what you would find out in the first weeks about how complaints reach the contact centre. Options are yours to keep or swap. Stop there; no claim to contact-centre work or knowledge | F2 is a gap you stated, and a screen reaches it first; JD because the contact centre is named in the requirement |
| 1B2 | "The role asks for experience handling regulated complaints. What's your experience of that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold to what the sentence says: "I handled the branch's formal complaints log." Answer slot: if the log had to meet any external rules or deadlines you know of, name them in your own words; if you do not know of any, or tracking them was not yours, say so plainly and stay with the log you handled | F3 is the thinnest step from a quote to a requirement in this pack, so a screen is where it surfaces first; JD because it scores a stated requirement |
| 1B3 | "Why this move, and why now?" | EXP | [generic] | The reason is yours alone and the pack will not write it. Say what you want more of, in your own words, then point to a line in the JD that carries it. Say it without criticising your current branch. If part of the reason is the scale of the role, say so plainly | The Skeptic's motivation-consistency stem; EXP because it tests whether the career so far and this move make one story |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Is any material or format for the escalation case shared in advance?" | The recruiter can answer it, and the pack's case rows are generic until someone does |
| R1.2 | "What does the panel score in the case?" | Turns twenty unknown minutes into a checklist |
| R1.3 | "How is the role split between branch work and contact-centre work today?" | Shows you have taken in the scope, and informs how you frame F2 |
| R1.4 | "Which part of the JD matters most to the Head of Member Services?" | Tells you where to spend round 2 |
| R1.5 | "What happens after the 20th, and by when?" | Closes the process without asking for a verdict |

---

# Round 2 — the Head of Member Services, your manager (45 minutes, mostly behavioural)

## Persona table, round 2

Everything proposed here is pending your approval.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps: scope, the contact centre, presenting | High. The hiring-manager prior is Case plus Skeptic, because the manager is buying capability and derisking gaps; F1, F2 and F8 are where your material is thinnest | Rehearse the single most predictable objection until it is boring: hold what the sentence says, name the limit before it is asked, give the ramp as a plan |
| Values / Behavioural | Scenario probes, STAR-shaped stories | High. The prior puts Case above it, but the recruiter's words are "mostly behavioural", which moves it up | A story only where one of your sentences carries it; otherwise a selection scaffold ending in its honest branch; "we" for context, "I" for your part |
| Case / Strategist | Live problems from the real roadmap | Medium. The prior ranks it first for a manager, and "mostly behavioural" pulls it down; the strategy brief supplies the roadmap | Clarify, objective, segmentation, approach, measures, risks; think aloud; challenge one premise respectfully |
| Prober | Reads the one artifact you have line by line | Low. The monthly spreadsheet (F4, F9) is the only artifact in your material, and no figure is on it | Say what you can and cannot say about how it counted; say plainly when you do not know |
| Not banked | Pressure, Conversational, Peer | Low here. The prior for a manager does not carry them; Pressure and Peer appear in round 3 | Covered in round 3 |

## Question bank, round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "The role owns the complaints process across every branch and the contact centre. What part of a complaints process have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." and "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Hold only what the sentence carries: "I handled the branch's formal complaints log." Name the limit before it is asked: "I've never worked in a contact centre." Answer slot: if any step beyond the log was yours to decide, such as where a complaint went, how it was closed or what the member was told, say which and how, in your own words; if none was, or it was not yours, say so plainly and stay with the log. Follow-ups to rehearse. One: "Where did your part stop?" — return to the log. Two: "What would you not know on day one?" — the limit, specific, in one sentence. Three: "How long until you'd be comfortable with the rest?" — a plan, said as a plan, never a past. Hold through two, concede the limit explicitly, and never add to the log to restore comfort | F1 and F2 are where the JD's scope presses hardest against the material, so this objection arrives in some form in the manager's round; JD because it scores the stated ownership requirement, with Skeptic delivery |
| 2A2 | "You'd be presenting to senior leaders, and you haven't presented above regional level. What's your plan?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Acknowledge first: "I've never presented to anyone above regional level." Then the plan, said as a plan, with options to keep or swap: ask what leaders want from the monthly report before you build it, rehearse the first report with the Head of Member Services, and keep it in plain words. Never claim senior-leader presenting. The pack's observation is that your material does not show whether a regional manager counts as senior here, so do not argue the point | F8 holds a negative you stated; JD because the requirement is stated, and a manager asks it to learn how the limit will be managed |
| 2A3 | "You haven't worked in a contact centre. How would you earn the trust of a team who have?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Acknowledge: "I've never worked in a contact centre." Then what you would do, as a plan with options: ask the team to show you how a complaint reaches them, listen before you propose anything, and carry their view into the first report. Do not claim you understand their work, and do not let a branch story stand in for it | F2 again, from the manager: how the limit is managed rather than whether it exists; JD because the contact centre is named in the requirement |
| 2A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose one limit you can state truthfully, name it before they do, then give the ramp as a plan. Two your material states: "I've never worked in a contact centre" and "I've never presented to anyone above regional level." A third, digital self-service journeys, is silent in your material (F6), so name it only if it is true for you. Answer in about 40 seconds and stop; do not dress a strength up as a weakness | The Skeptic's standard stem, landing on F2, F8 and F6; JD because it scores the whole requirements list |
| 2B1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | A selection scaffold: pick a time you told someone more senior something they did not want to hear. It needs a named stake, what you said, how it landed and a relationship still intact afterwards. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A mostly-behavioural manager round will carry stems like this one; EXP because it tests what was actually yours, and F8 is why it matters for this role |
| 2B2 | "When did you put a member ahead of an internal target?" | VAL | [grounded] | A selection scaffold built on the value "Members First, Always — we decide from the member's side of the counter." Pick a time you decided from the member's side when it cost the branch something. It needs the stake, what you chose and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value, asked in the manager's behavioural register; VAL because it scores values, and round 3 will ask the same value differently |
| 2B3 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-map on the one sentence that carries it: "I trained new tellers on our escalation script." The tellers were new and the script was the escalation script; those are the beats, in your own words. Answer slot: the JD's coaching line points at supervisors, so expect a probe on anyone beyond new tellers. If you have guided someone else through an escalation, say who and how; if not, or it was not yours, say so plainly and stay with the tellers | F5 is the evidence for the coaching requirement and stops at new tellers; JD because the requirement is stated, with behavioural delivery |
| 2C1 | "Ashgrove plans to move 40% of member service to digital channels by 2028. What happens to complaints as that happens, and what would you want to know first?" | CASE | [grounded] | No claim about your past is needed. Clarify first, and challenge one premise respectfully: does the 40% include complaints, or only routine service? Then the objective, which channels complaints now arrive through, an approach, the measures, the risks. Think aloud. A view to offer, labelled as a view: complaints arriving digitally may not reach the branch log, so the monthly report would need to count across channels | The one strategy case a prepared candidate can differentiate on; CASE because it is a live problem on the roadmap, and the premise it rests on is the brief's |
| 2C2 | "Eight branches become five hubs over 2027. A member's complaint is about a branch that is changing. Who keeps hold of it until it is solved?" | CASE | [inferred] | No claim about your past is needed. Anchor on the value in its own words, "whoever finds the problem keeps hold of it until it is solved". Clarify what changes for the member and who they would reach. Name one owner at the point the problem is found, then what that owner does and what the member is told, in plain words. Say which part you would test before you trusted it | The scenario is the pack's own, derived from the consolidation item and the Own the Fix value, hence inferred; CASE because it is a live problem, with VAL pulling behind it |
| 2C3 | "It's month three. What does the monthly complaints report you bring me look like?" | CASE | [grounded] | No claim about your past is needed. Clarify first: who reads it and what decision it serves; what counts as a complaint and when the clock starts and stops, asked and not assumed; which channels it covers. Then the two measures the JD names, volumes and resolution times, cut by channel and by branch, on one plain page, and what you would not conclude from a single month | The JD's reporting line asked as a live design problem, so it does not depend on what your spreadsheet held; CASE because it scores structure |
| 2D1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-map on the sentence's three beats, in your own words: you built it, it was monthly, your regional manager uses it. Answer slot: the JD names volumes and resolution times, so expect "what did it count?" If it counted either, say which and how it was counted; if it held something else, say what; if you do not know how a figure in it was counted, say that plainly. Name the assumption you would defend least only if you know one | F4 is the one artifact in your material and the place a Prober goes; EXP because it tests what was actually yours |
| 2D2 | "What's the hardest thing you've done in Excel?" | JD | [grounded] | A selection scaffold: pick a piece of spreadsheet work with a named purpose, what made it hard and what changed because of it. The material does not name the tool (F9), so if the spreadsheet was in Excel say Excel, and if it was in another tool say which; do not let the JD's word replace your fact. If no such piece comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Excel requirement was stated once and would otherwise go unrehearsed; JD because it scores a stated requirement |

## Reverse questions, round 2

No interviewer profile exists, so none of these is tied to the Head of Member Services's own path.

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "Which complaint measures do senior leaders look at today, and how do they like to see them?" | Gets ahead of F4 and F8 by asking what the report is for before you build it |
| R2.2 | "How do complaints reach the contact-centre team today, and where do they go next?" | Shows humility about F2 and asks for the thing you cannot know |
| R2.3 | "What would you want changed in how complaints are handled by the end of the first quarter?" | Lets the manager name the outcome, and Own the Fix gives you the vocabulary to answer |
| R2.4 | "How will the move to five hubs change what branch supervisors need from this role?" | Connects the role to the consolidation item and to F5 |
| R2.5 | "What would make this hire the right call a year from now?" | Asks for the manager's success measure in their words |

---

# Round 3 — panel of two branch managers, the values round (60 minutes, including a 20-minute case)

## Persona table, round 3

The panel is two branch managers whose names and relationship to the role are not yet known. Everything proposed here is pending your approval.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scenario probes mapped to the four published values | High. The recruiter's words are "they score against the four values" | Map a story to each value where one of your sentences carries one, and a selection scaffold ending in its honest branch where none does |
| Case / Strategist | A live escalation problem, scored on structure | High. A 20-minute case is a third of the hour | Clarify what rules and deadlines apply and what the member has been told; set the objective; name the owner; plain words to the member; measures; risks |
| Peer | Where the line sits between your job and the branch manager's, and what happens in a disagreement | Medium. The role coaches branch supervisors (F5), and branch managers are a natural place for that seam to be tested; their relationship to the role is unconfirmed | Propose seam principles instead of pretending to know the seam; lead with what you bring their branch |
| Pressure | Time-boxed answers, interruption, "how much was actually you" | Low. A 20-minute case can carry interruptions, and nothing in the email signals it | Pause, restate, hold through two follow-ups, then concede only what you have already said |
| Not banked | Skeptic, Prober, Conversational | Low here. Skeptic objections return in collegial packaging through the Peer and Pressure rows | Covered in round 2 |

## Question bank, round 3

The case rows below are practice shapes. The recruiter said only that the case is on a complaint escalation, so none of them predicts the actual case.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | A selection scaffold on "Members First, Always". Pick a time the member's side and the branch's side pulled apart. It needs the stake, what you decided and what happened to the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first of four values, which the panel scores by name; VAL because it tests behaviour against the published wording |
| 3A2 | "When have you had to explain something to a member twice, and what did you change?" | VAL | [grounded] | A selection scaffold on "Plain Words — if a member needs it explained twice, we wrote it wrong." Pick a time something was unclear to a member or a new colleague. It needs what was unclear, what you changed and whether the second telling was needed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value turns on what you did after the second explanation, which only your own example can show; VAL because it scores the second half of the value |
| 3A3 | "Eight branches are becoming five hubs. What does Neighbours, Not Numbers mean for how you'd run complaints through that?" | VAL | [inferred] | No claim about your past is needed to state the tension plainly: consolidation and "every branch is part of its town" pull in different directions. Then what you would keep local and what you would standardise, as a view. A selection scaffold for the past: pick a time you did something because of the town your branch sat in, not because of a number; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The tension is derived from two pasted sources and a panel scoring this value may test it, hence inferred; VAL with CO delivery |
| 3A4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] | A selection scaffold on "Own the Fix — whoever finds the problem keeps hold of it until it is solved." Pick a time you could have handed a problem on and did not. It needs the moment you found it, what you did to keep it and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1 is the nearest evidence and does not show a fix held, so the story has to come from you; VAL because it is the fourth value |
| 3B1 | "A member says a branch gave them wrong information, the branch disagrees, and the member is now writing to head office. What do you do first?" | CASE | [generic] | No claim about your past is needed. Clarify first: what rules and deadlines apply to this complaint, what the member has already been told, and who has touched it. Then the objective, who owns it from now, what the member hears and when in plain words, the measures and the risks. Think aloud; challenge one premise, such as whether the branch's account has been checked | The shape every escalation case takes; CASE because it scores structure, and generic because it is a pattern, not a fact about Ashgrove |
| 3B2 | "A contact-centre agent hears the same complaint from three members about one branch in a week. Whose problem is it, and what happens next?" | CASE | [generic] | No claim about your past is needed. State an owner at the point the problem is found, then who tells the branch, who tells the members and what changes. Say what you would measure to know it was fixed. Use "whoever finds the problem keeps hold of it until it is solved" only as the value it is | Puts the contact centre and the branches in one scenario, which F2 and F1 mean you cannot answer from the inside; CASE because it is a live problem |
| 3B3 | "A supervisor handles an escalation badly and the member is angrier than before. How do you coach them?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The case needs no claim about your past: what you would ask first, what you would fix for the member today, how you would coach the supervisor afterwards. If you draw on experience, the only sentence your material carries is "I trained new tellers on our escalation script"; do not stretch it to supervisors. Answer slot: if you have coached anyone through an escalation, say who and how; if not, say so plainly and answer as an approach | The JD's coaching line asked as a live problem; F5 stops at new tellers, so the case is answered as an approach; CASE with JD content |
| 3B4 | "Complaints arriving through digital channels are rising while branch complaints fall. What do you do, and what do you report?" | CASE | [inferred] | No claim about your past is needed. Clarify what counts as a digital complaint and whether the two figures are counted the same way. Then possible causes, who needs to know, the report cut by channel and what you would not conclude yet. A view: do not read the two trends as one story until the counting is checked | Derived from the digital item and the JD's reporting line, hence inferred; CASE because it is a live problem, and a panel of branch managers has a stake in the answer |
| 3C1 | "When you coach a branch's supervisors on escalations, where's the line between your job and the branch manager's, and what happens when we disagree?" | JD | [grounded] | Propose principles instead of pretending to know the seam, as options to keep or swap: the branch manager keeps the branch's day; you set out the escalation standard and what good looks like; you tell the branch manager first when something in their branch has gone wrong. On disagreement, raise it early and in private with the member as the anchor. Then what you bring their branch, not only what you need | The Peer's seam question, built on the JD's coaching line; F5 is why a branch manager would probe it; JD because it scores a stated responsibility |
| 3C2 | "When digital wants to move a complaint journey online and a branch says members won't use it, whose call is it?" | CASE | [inferred] | Principles, as options: let evidence from real members decide, test before moving anything, keep a branch route open, and agree who owns the fix across both teams. Answer slot: the JD names digital teams, so if you have worked alongside one, say what and which part was yours; if not, say so plainly and answer as principle | Derived from the JD's digital line and the brief's digital item, hence inferred; CASE because it is a live problem, with Peer delivery |
| 3D1 | "Sixty seconds: why you, when you haven't worked in a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." and "I built the monthly complaints spreadsheet our regional manager uses." and "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold-then-concede. Pause and restate. Hold the position your sentences carry: you handled the branch's formal complaints log, you trained new tellers on the escalation script, you built the monthly complaints spreadsheet your regional manager uses. Concede what you have already said: "I've never worked in a contact centre." Hold through two follow-ups; never add a claim to win the exchange | F2 is the gap most likely to be pressed, and the position held is only what F1, F4 and F5 carry; JD with Pressure delivery |
| 3D2 | "That log — how much of it was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot, in your own words: say which parts of the log were yours and which others shared; if you do not know how to divide it, say that plainly; if it was all yours, say so without adding to it. Hold through two follow-ups by returning to the sentence: "I handled the branch's formal complaints log." | The standard Pressure attribution stem, aimed at F1; EXP because it tests what was actually yours |

## Values cheat sheet (round 3)

A values-style round is documented by the recruiter's own words. Values are quoted as pasted from the page you copied on 11 November 2026. No one of your sentences carries a story for any value, so each row is a selection scaffold ending in its honest branch.

| Value | Working meaning | Provenance | Your story, or the scaffold |
|---|---|---|---|
| "Members First, Always" | Decide from the member's side of the counter | [grounded] | Pick a time you decided from the member's side when it cost the branch something: the stake, what you chose, what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| "Plain Words" | If a member needs it explained twice, the wording was wrong | [grounded] | Pick a time something had to be explained twice and what you changed: what was unclear, what you changed, whether it worked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| "Neighbours, Not Numbers" | Every branch is part of its town | [grounded] | Pick a time you acted because of the town your branch sat in, not because of a number: the local fact, what you did, what it changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| "Own the Fix" | Whoever finds the problem keeps hold of it until it is solved | [grounded] | Pick a time you could have handed a problem on and did not: the moment you found it, what you did to keep it, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could a new person in this role do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-like panel: asks what you can bring before what you need |
| R3.2 | "Which complaints take your branch the most time today?" | Asks for lived experience of the process you would own |
| R3.3 | "When an escalation goes wrong in a branch, what do you wish had happened differently?" | Gets the real escalation problem in the managers' own words |
| R3.4 | "How will the move to hubs change what your supervisors need from this role?" | Connects the role to the consolidation item and to F5 |
| R3.5 | "How would you want to hear about patterns in your branch's complaints: before the monthly report, or in it?" | Tests the working relationship early, and F4 gives you the vocabulary |

---

# Shared sections

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | 1A4, 1B1, 2A1, 2A3, 2C2, 3B1, 3B2, 3D1, 3D2 |
| "report monthly on complaint volumes and resolution times" | 2C3, 2D1, 3B4 |
| "coach branch supervisors on escalations" | 2B3, 3B3, 3C1 |
| "work with digital teams on self-service journeys" | 1A5, 2C1, 3C2 |
| "4+ years in financial-services customer operations" | 1A1, 1A4 |
| "experience handling regulated complaints" | 1B2, 3B1 |
| "confident presenting to senior leaders" | 2A2, 2B1 |
| "comfortable with Excel reporting" | 2D2 |

## Prohibited claims

What this pack will not coach, and why. Inflated-form entries list wording, not a finding that you lack the thing; the limit is the pack's own observation. Proposed language, pending your approval.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's sentence at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says the branch's log, not the process end to end. The slot in 2A1 stays inside the log |
| Handled regulated complaints | Inflated form of F3 | F3's sentence at its own scope. The limit is the pack's observation: your material does not say what rules the log was kept to. The slot in 1B2 asks only what you know of them |
| Reported on complaint volumes and resolution times | Inflated form of F4 | F4's sentence at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The slot in 2D1 asks only what the spreadsheet held |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's sentence at its own scope: "I trained new tellers on our escalation script." The slot in 2B3 stays with the tellers |
| Built Excel reporting | Inflated form of F9 | F9's sentence at its own scope. The limit is the pack's observation: your material does not name the tool |
| Worked in a contact centre | A negative you stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Presented to anyone above regional level | A negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents, all in your message: the JD; the four values as copied from ashgrovecu.org/about/values on 11 November 2026; the recruiter's email; your summary of the July 2026 strategy brief, which the pack has not read itself; your background. No dossier was present. No search and no fetch was sent, and no link was read.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page fixes the values cheat sheet and the four VAL rows by name |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email fixes the rounds, who runs each, their length and the 20-minute case, which fix the persona weights |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief, about four months old, supplies current priorities for the CO and CASE rows |
| 4. Interviewer name and Ashgrove | n/a | No interviewer has been named, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged rows |

## Upgrade menu

- Interviewer names, once assigned → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their path
- A sanitised screenshot or sample of the monthly complaints spreadsheet, and what it counted → F4 and F9 move toward `high`, and the 2D1 and 2D2 slots can become story-mapped
- One complaint you handled, told in your own words, outside the drill → it is quoted into F1, F3 and F5, and the 2B1, 2B2 and 3A1 to 3A4 scaffolds become story-mapped
- Any presenting you have done at regional level or below, in your words → F8 gains adjacent evidence for 2A2
- Anything you have done alongside a digital or product team → F6 gains evidence for 1A5 and 3C2
- The recruiter's answers on whether the case material is shared in advance and what the panel scores → the four case rows stop being generic
- The full text of the July 2026 strategy brief → the CO and CASE rows rest on the brief itself and not on your summary
- A deeper research pass, offered once — up to 6 more searches and 2 more fetches, several more minutes — would add role-family reports on escalation-case formats and recent organisation context
- A `tuesday-dossier.md` from an earlier fit review of this role, if you have one → verified evidence per requirement and a strategy per weak area; never a precondition
