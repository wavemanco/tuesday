Dara, your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-denied-a0128e8c/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a three-round pack from the recruiter's email, with a separate set of questions for each round. No interviewers are named yet, so the persona weights rest on the round types. I ran no web searches, because the JD, values text, loop details and strategy points you pasted already cover everything I would have looked up. The pack has 30 questions, a values cheat sheet for the panel round, and reverse questions for each round.

The question to rehearse most is R2-B1, about owning complaints in the contact centre when you've never worked in one. Versions of it also appear in R1-B1, R1-B2 and R3-F1. The other stated limit, never presenting above regional level, is covered in R2-B3.

Wherever your background doesn't state something, the pack gives an answer slot instead of an answer. Examples are what "formal" complaints meant in practice, what your spreadsheet counted and whether it was Excel, and any work with digital teams. Fill those in using your own experience, or say plainly that it wasn't yours. The upgrade menu at the end of the file lists what would sharpen the pack further.

Say the word and I'll play the Skeptic on R2-B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop:** three rounds on 20 November 2026, built in loop mode from the recruiter's email. **Round 1:** 30 minutes with the recruiter. **Round 2:** 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural. **Round 3:** 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation; the panel also scores against the four published values. No interviewer names are known, so there is no interviewer read and persona weights rest on the round types.

## How to use this pack

Personas are how a question arrives. Types are what is being scored. Guidance is scaffolding to rehearse from, not a script: speak it in your own words, and wherever it says answer slot, the honest answer is whichever branch is true for you.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour demonstrates Ashgrove's published values |
| EXP | Whether what you say you did survives follow-up; attribution |
| JD | A stated requirement or responsibility in the posting, gaps included |
| CO | Knowledge of Ashgrove's strategy and competitive position |
| CASE | A live problem from the role, scored on structure and reasoning |

## Prep triage

Sized to the calendar only: today is 11 November and the loop is 20 November. You have not said how many hours a day you have.

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse the contact-centre answer aloud until it is boring. It arrives in all three rounds in some form | R2-B1 (highest-ROI), R1-B1, R1-B2, R3-F1 |
| 2 | Write your own answers to the answer slots in notes of your own, then say them aloud | F2, F3, F5, F6, F7, F9 slots; R2-B2, R2-B4, R2-G1, R1-B3 |
| 3 | Settle your one line on presenting to senior leaders | R2-B3 |
| 4 | Choose a real instance for each of the four values, or rehearse the honest branch | R3-C1 to R3-C4, cheat sheet |
| 5 | Run the three cases aloud, 20 minutes each, using the six-step structure | R3-D1 to R3-D3, R2-D1, R2-D2 |
| 6 | Learn the four strategy points and the reverse questions | Grounding brief, R1-A3 |

Everything else is insurance.

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence says retail banking and the JD says customer operations, so the pack does not relabel it. Say it as written: "I have six years in retail banking, the last three as a branch supervisor." Nothing inspected sits behind it, so expect a light probe on the supervisor years. No duties are added to it |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your words stay here: "I handled the branch's formal complaints log." Answer slot: the JD's word is regulated and your sentence's word is formal, so expect a probe on what rules or timescales applied to those complaints. If any governed the log, say which and how they shaped your part, in your own words; if none were set out, or tracking them was not yours, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Adjacent work, one branch's log, at its own scope: "I handled the branch's formal complaints log." Answer slot: expect a probe on what happened to a complaint before and after it reached the log. If you followed any through to the end, say how far and which part was yours; if the log was where your part sat, or the stages were not yours, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never worked in a contact centre." Then how you would learn that side, said as a plan and never as a past. Your material also shows one branch, not several, which is the pack's observation and not words for you |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your words stay here: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on what it counted. If it counted volumes or resolution times, say which and how, in your own words; if it did not, or part of it was not yours, say so plainly and stay with the spreadsheet you built |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Adjacent work, tellers not supervisors and training not coaching, at its own scope: "I trained new tellers on our escalation script." Answer slot: expect a probe on how that differs from coaching. Say what your training involved, in your own words; if it was walking tellers through the script, say so plainly and stay with that |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a named self-service journey, the problem members hit in it, your part and what changed. Answer slot: if you have worked with a digital or app team on anything members use themselves, say what and your part, in your own words; if not, say so plainly and say how you would start |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for that audience, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Derived from the JD's Excel against your word spreadsheet, which does not name the tool. Answer slot: say what the spreadsheet was built in; if it was Excel, say what it did, in your own words; if it was something else, say so plainly and stay with the spreadsheet |

## Grounding brief: what Ashgrove has said about its direction

| Point | Provenance | Reading for this role |
|---|---|---|
| 40% of member service to digital channels by 2028 | [grounded] 2026 strategy brief (July 2026), as you relayed it | [inferred] derived from the JD's self-service line: this is the programme that line sits under. Ask about it, do not assert how it affects complaints |
| Eight branches consolidated into five hubs over 2027 | [grounded] same brief | [inferred] derived from the value "Neighbours, Not Numbers" against branch consolidation: expect a probe on how a hub stays part of its town |
| Small-business lending product launching Q1 2027 | [grounded] same brief | [inferred] derived from the brief alone: a new product is a question to ask about complaint routing, not a fact about it |
| Main competitive pressure is app-only banks | [grounded] same brief | [inferred] derived from the brief and the JD's self-service line: members compare Ashgrove's digital experience with those banks' apps |

The brief is about four months old, inside the freshness window. You relayed four points, not the whole document.

---

# ROUND 1: Recruiter, 30 minutes

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured, "walk me through" | High. A recruiter screen starts here, and the recruiter's email describes a 30-minute conversation | A 90-second arc; treat every casual question as scored |
| Skeptic | Quiet check of the gaps and motivation | Medium. A recruiter screens for knockouts, and F4 and F8 are visible in the JD | Say each limit in one plain sentence, then the plan |
| Values/Behavioral | Light, a first pass at the four values | Low. The email names the panel as the values round, so this is a free early rehearsal | Pick a value; back it with something you did or say none comes to mind |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "So, walk me through your journey in banking so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc made only of what the sentences state: six years in retail banking, the last three as a branch supervisor, the complaints log, training new tellers on the escalation script, the monthly spreadsheet. Say "I" for what you did. Close with why this role, in your own words | The biography opener is the Conversational stem; F1 is the requirement it carries. EXP because it checks the CV story hangs together |
| R1-A2 | "What draws you to a member-owned credit union?" | VAL | [grounded] | Choose one of Ashgrove's four values by its official name, for example "Members First, Always — we decide from the member's side of the counter", and say in your own words why it matters to you. If nothing you have done fits any of the four, say so plainly and talk about why the idea appeals. The question needs no claim about your past | Motivation is scored in a recruiter screen. VAL because it is asked through the published values |
| R1-A3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] strategy brief as you relayed it | State the four points as the brief states them: 40% of member service to digital channels by 2028; eight branches consolidated into five hubs over 2027; a small-business lending product in Q1 2027; app-only banks as the main competitive pressure. Then offer one thought from the complaints seat as a question, not a fact: "I'd be interested in how ..." | The recruiter sent you the brief, so reading it is the baseline. CO because it tests homework |
| R1-A4 | "Is there anything on notice period, pay or timing I should know now?" | JD | [generic] | The pack holds none of your facts here and writes none. Decide your notice period and pay range before 20 November and say them plainly; if you cannot yet, say what you need to know to decide | Knockout checks sit in a friendly register at this stage. JD because it concerns the terms of the role |
| R1-B1 | "The role covers branches and the contact centre. What's your experience on the contact-centre side?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Short version of R2-B1. Open with "I have never worked in a contact centre." Then the adjacent thing your sentence states, at its scope: "I handled the branch's formal complaints log." Then what you would want to learn first, in your own words. Describe no contact-centre work | F4 is the largest stated gap, and a recruiter screen checks the JD's stated scope. JD because it scores that scope |
| R1-B2 | "Which part of this job would you find hardest in your first month?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Your material carries two stated limits. Pick the truer one, say it plainly, then say what you would do about it in your own words. If your real weakest area is another one, say that instead | The Skeptic stem for the gaps in F4 and F8. JD because it scores fit to the listed role |
| R1-B3 | "The role reports monthly on complaint volumes and resolution times, in Excel. What reporting have you done?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say it at its scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's volumes-and-resolution-times line makes a probe on what it counted likely, and Excel a probe on what it was built in. If it counted either, or was built in Excel, say so and how, in your own words; if not, or part was not yours, say so plainly and stay with the spreadsheet | F5 and F9 together: the reporting and tool requirements are in the JD's own list. JD because it scores a stated requirement |
| R1-C1 | "Which of our four values feels closest to how you work, and which would stretch you?" | VAL | [grounded] | Selection scaffold. Pick one value by official name; it needs a specific thing you did, not a trait. For the stretch value, say honestly why and what you would do. If no specific thing comes to mind for any value, say so plainly, then say what the value means to you and how you would practise it | A free rehearsal for the round that scores these. VAL because it names the published values |
| R1-C2 | "What would Plain Words mean when you write to a member about their complaint?" | VAL | [grounded] | The value's own wording is "if a member needs it explained twice, we wrote it wrong". Say what that would mean for a response, in your own words. No past claim is needed; if you have a real example of rewriting something for a member, use it, and if not, say how you would test that a letter did not need explaining twice | Second light values question, in the register a recruiter uses. VAL because it is asked through a published value |

## Reverse questions (Round 1)

| Question | Why it lands |
|---|---|
| "For the panel's 20-minute case, is there anything I can read or prepare beforehand?" | Shows you are preparing for the scored part and costs the recruiter one email |
| "What would the Head of Member Services most want to explore with me in round two?" | A recruiter can say what the next round is for, and it shows you are planning ahead |
| "Who in the business does this role work with most in its first few months?" | Shows you are thinking about the role's working relationships |

---

# ROUND 2: Head of Member Services, 45 minutes (your would-be manager)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: contact centre, regulated complaints, senior audiences | High. A hiring manager is derisking gaps, and F4 and F8 are stated | Rehearse the single most predictable objection until it is boring; concede the limit specifically |
| Values/Behavioral | "Tell me about a time" prompts | High. The recruiter's email says this round is mostly behavioural | Choose instances the quoted sentences carry; otherwise use the selection criteria and the honest branch |
| Case/Strategist | Live problems on their roadmap | Medium. Hiring-manager prior, and the strategy brief gives them material | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | Asks you to walk the log line by line | Low. One probe on the one concrete artifact you named | Know what you can and cannot say about how it worked; say plainly where you do not know |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "You'd own complaints in the contact centre too, and you haven't worked in one. How would you get on top of that side?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI prep in this pack. Concede first and plainly: "I have never worked in a contact centre." Bridge only with what the sentences carry, at their scope: "I handled the branch's formal complaints log" and "trained new tellers on our escalation script", one branch. The limit, said before it is asked for: your material shows one branch and no contact centre. Then a ramp plan in your own words: pick two things you would actually do in your first weeks; the pack does not write them. Hold through two follow-ups by returning to what the sentences carry and the plan. Concede specifically what you do not know about the channel; never claim knowledge of it | F4 and F3 together are the likeliest objection in any form. JD because it scores the stated scope; the person who would manage you is pricing the gap they would inherit |
| R2-B2 | "The posting asks for experience with regulated complaints. What made the complaints you handled regulated?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with your own words: "I handled the branch's formal complaints log." Answer slot: the JD's word is regulated and your sentence's is formal, so the probe is on what rules or timescales applied. If any applied, say which and what they meant for your part, in your own words; if none were set out, or tracking them was not yours, say so plainly and return to the log | F2 is a requirement the JD lists and the evidence only partly reaches. JD because it scores the stated requirement |
| R2-B3 | "How comfortable are you presenting to senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly, once: "I've never presented to anyone above regional level." Then what you would do about it, in your own words: how you would find out what that audience asks, how you would practise. The pack supplies no presentation you gave. Hold your plan through two follow-ups and concede the limit specifically | F8 is a stated limit and this interviewer is the senior audience. JD because the requirement is the JD's |
| R2-B4 | "Have you worked with digital teams on anything members use themselves?" | JD | [grounded] | Answer slot: if you have, say what it was and your part, in your own words; if not, say so plainly and say how you would start working with a digital team on a self-service journey. Your quoted sentences do not carry this, so nothing is mapped | F7 has no evidence, and the JD lists the responsibility. JD because it scores a stated responsibility |
| R2-C1 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, a moment you did not fold, and a relationship that was intact after. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values/Behavioral stem for a manager probing how you handle upward honesty. VAL because it scores past behaviour |
| R2-C2 | "When has a complaint exposed a wider problem, and what did you do about it?" | VAL | [generic] | Selection scaffold. Pick a complaint with a pattern behind it: what was found, who you told, what changed. Your quoted sentences do not say any complaint exposed a wider problem, so no story is mapped. If none comes to mind, say so plainly, then say how you would look for a pattern | Ties to Own the Fix and to the JD's responsibility for the process. VAL because it tests behaviour against the published value |
| R2-C3 | "Tell me about a time you helped a colleague through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F6: the beats the sentence states are new tellers and the escalation script, and that you trained them; tell them in your own words. Answer slot: expect a probe on a real escalation. If you supported a specific one, say what it was and your part; if the training was the extent of it, say so plainly and stay with the training | F6 is adjacent, and coaching supervisors on escalations is a listed responsibility. JD because it scores that responsibility |
| R2-D1 | "Which complaints would you move to self-service first, and what would you need to know before deciding?" | CASE | [grounded] strategy brief as you relayed it, JD self-service line | Clarify first: what is known about the complaint types, what members need, what the 2028 digital target covers. Then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully, for example which complaints should stay with a person. Use Ashgrove's words: Plain Words, member. The case asks about no past of yours | The brief's 40% digital target meets the JD's self-service line. CASE because it is a live problem on their roadmap |
| R2-D2 | "Eight branches become five hubs through 2027. What would you do about complaints in your first ninety days?" | CO | [grounded] strategy brief as you relayed it | Clarify what you do not know before structuring: timing of each hub, what changes for members, who holds escalations in a hub. Then objective, segments, approach, metrics, risks. Keep "Neighbours, Not Numbers — every branch is part of its town" in view as you reason. State no outcome as fact; the case asks about no past of yours | The consolidation is the most direct strategy item for a branch-side complaints lead. CO because it scores company-altitude thinking; CASE delivery |
| R2-G1 | "Walk me through how a formal complaint moved through your log, from the day it came in." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The one beat the sentence states is that you handled the branch's formal complaints log; tell it in your own words. Answer slot: the probe is on the stages between arrival and closure. If you set or followed any, say which and what part was yours; if the log was a record and the stages were not yours to set, or there were none, say so plainly and describe what you did with the log | F2 and F3 are the closest evidence for process ownership. EXP because it tests the claim to its detail |

## Reverse questions (Round 2)

| Question | Why it lands |
|---|---|
| "Where do complaints get stuck today between branches and the contact centre?" | Treats the role as a problem to pick up, and points at Own the Fix |
| "As eight branches become five hubs through 2027, who holds escalations in a hub?" | Ties the question to the published plan and to this role's seam |
| "Who are the senior leaders the monthly report goes to, and what do they do with it?" | Shows you are preparing for an audience you have not faced |
| "What would you want to see from this role in its first six months?" | Lets the person who would manage you say what they will score, in their own words |

---

# ROUND 3: Panel of two branch managers, 60 minutes (20-minute complaint-escalation case; values scored)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes mapped to the four values | High. The recruiter's email says the panel scores against the four values | One instance per value where your sentences carry one; a selection scaffold and honest branch where they do not |
| Case/Strategist | The 20-minute escalation case | High. The email says 20 of the 60 minutes are a case on a complaint escalation | Clarify before structuring; use Ashgrove's words; challenge one premise respectfully |
| Peer Evaluator | Seam questions: the branch managers' supervisors are who you would coach | Medium. They are the people whose branches you would work with, and cross-functional rounds lean on partnership fit | Reciprocity framing: what you bring their branches; propose seam principles rather than claiming to know the seam |
| Pressure | Time-boxed challenges on the gaps | Low. Two panelists can interrupt, and the stated gaps are an easy target | Pause, restate, anchor in what you stated; hold through two follow-ups |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | "Tell us about a time you decided something from the member's side of the counter." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." | Selection scaffold. Pick a time you chose the member's side: the stake, what it cost, what came of it. Your quoted sentences carry no story of this kind, so none is mapped. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | First of the four values the panel scores. VAL because it asks for a decision, not a slogan |
| R3-C2 | "Tell us about a time you made something clearer for a member or a colleague." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong." | Selection scaffold. Pick something you rewrote or re-explained: what was unclear, what you changed, how you knew it worked. Your quoted sentences do not say you rewrote anything, so none is mapped. If none comes to mind, say so plainly, then say how you would test a letter did not need explaining twice | Second value. VAL because the bar is a specific decision |
| R3-C3 | "How do you keep a person in the picture when you report complaints as numbers?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." "I built the monthly complaints spreadsheet our regional manager uses." | Your sentence carries the numbers side: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on whether anything in it tied a figure to a branch or to a member's case. If it did, say what; if not, say so plainly and say what you would add. Be ready for the tension with consolidation into hubs, and state no view of Ashgrove's plan as fact | Third value, and the one the JD's monthly reporting puts under tension. VAL because it asks how a value is kept under a numbers job |
| R3-C4 | "Whoever finds the problem keeps hold of it. When have you done that, and how does it sit with passing a complaint up?" | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The sentence states you handled the branch's formal complaints log; it does not say you followed a problem to its fix. Answer slot: if you followed any complaint from the day you found it to its fix, say which kind, what you did and what was yours; if the fix was someone else's, say so plainly and stay with the log. On passing a complaint up, say in your own words how a finder can stay in the loop | Fourth value, and it sits against escalation, which is this role's centre. VAL because it scores a specific decision |
| R3-D1 | "A member's complaint has been to the branch, then the contact centre, and they are on their third explanation of the same problem. Walk us through what you'd do." | CASE | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong." "Own the Fix — whoever finds the problem keeps hold of it until it is solved." | Clarify first: what the member wants, what has been done, who holds it now, what clock applies. Then objective, segments (the member now, the cause), approach, metrics, risks. Think aloud; challenge one premise respectfully. Use Ashgrove's words. The case asks about no past of yours | The case is on a complaint escalation. CASE because it is a live problem; two values give it its vocabulary |
| R3-D2 | "A branch supervisor escalates a complaint to you, but the member has heard nothing. What do you do, and what do you say to the supervisor?" | CASE | [generic] | Member first, then the supervisor. Clarify what has and has not been done, then say what you would tell the supervisor, in your own words. The case asks about no past of yours, and nothing here says you have coached supervisors | Tests the coaching responsibility live. CASE because it is hypothetical; the JD's coach line raises it |
| R3-D3 | "Complaint volumes at one branch double this month. How would you find out why, and what would you tell the executive team?" | CASE | [generic] | Clarify first: what counts as a complaint, over what period, what changed. Then objective, segments, approach, metrics, risks, and what you would say and to whom. Think aloud. The case asks about no past of yours | Brings the monthly reporting and senior-audience lines into a live problem. CASE because it is a diagnosis |
| R3-E1 | "Our supervisors will hear from you after an escalation goes wrong. Where is the line between coaching them and taking it off them?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Offer principles in your own words, not a claim to know their seam. Use your quoted sentence only at its scope if you use it: you trained new tellers on the escalation script. Reciprocity: say what you would bring their branches | F6 is adjacent, and the panel are the supervisors' managers. JD because coaching is a listed responsibility |
| R3-E2 | "What would you do if one of our branches and your team disagreed about who owns a complaint?" | JD | [generic] | A would-do answer built on principles: who the member hears from, how the disagreement is settled, how it is recorded. If a time comes to mind when you disagreed with an equal and kept the relationship, use it; if none does, say so plainly and say how you would handle it | The Peer Evaluator's collegial form of the ownership question. JD because the role spans branches |
| R3-F1 | "Sixty seconds: why should we pick you when you haven't worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Hold then concede. Hold with what your sentences carry, at their scope: the branch's formal complaints log, training new tellers on the escalation script, the monthly spreadsheet. Concede plainly and specifically: "I have never worked in a contact centre." Do not fold the core claim to restore harmony. Hold through two follow-ups | The same gap as R2-B1 with a clock on it. JD because it is the requirement; Pressure by delivery |
| R3-F2 | "How much of the complaints log and the monthly spreadsheet was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Pause, restate, anchor in what you stated: "I handled the branch's formal complaints log" and "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if anyone else contributed to either, say who and what; if nobody did, say so plainly. Hold through two follow-ups; concede specifically only what you truly do not know | The attribution probe on the two concrete artifacts. EXP because it tests how much was yours |

## Values and principles cheat sheet (Round 3)

| Value (official name) | Working meaning | Mapped story, or scaffold |
|---|---|---|
| Members First, Always | Decisions are made from the member's side | Scaffold: pick a time you chose the member's side, with the stake and the cost. No quoted sentence carries one. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | Clarity is the writer's job, not the member's | Scaffold: pick something you made clearer, with how you knew. No quoted sentence carries one. If none comes to mind, say so plainly, then say how you would test it |
| Neighbours, Not Numbers | Each branch is part of its town; people are not only figures | Scaffold: pick a time a figure and a local person pulled apart and what you did. F5's sentence is about the numbers side, so it does not carry this value. If none comes to mind, say so plainly, then say how you would keep both |
| Own the Fix | The finder keeps hold of the problem until it is solved | F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: if you followed any complaint through to its fix, say which and your part; if not, or the fix was someone else's, say so plainly and stay with the log |

## Reverse questions (Round 3)

| Question | Why it lands |
|---|---|
| "What could a new person in this role do in their first month that would genuinely help your branches?" | Reciprocity: asks what you could give, not only what you need |
| "When a complaint escalates from your branch today, which part is hardest for your supervisors?" | Gets at the thing you would be coaching, from the people who see it |
| "When a member wants someone local on a complaint and the contact centre could resolve it faster, how do your branches decide?" | Puts Neighbours, Not Numbers and the digital plan on the table together |

---

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | R1-A1 |
| Experience handling regulated complaints | R2-B2, R2-G1 |
| Confident presenting to senior leaders | R2-B3, R3-D3 |
| Comfortable with Excel reporting | R1-B3 |
| Own the member complaints process end to end | R2-B1, R2-G1, R3-C4, R3-D1 |
| Across branches and the contact centre | R1-B1, R1-B2, R2-B1, R3-F1 |
| Report monthly on complaint volumes and resolution times | R1-B3, R3-C3, R3-D3 |
| Coach branch supervisors on escalations | R2-C3, R3-D2, R3-E1 |
| Work with digital teams on self-service journeys | R2-B4, R2-D1 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says one branch's log, not the process end to end. R2-G1's slot stays inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope: "formal complaints log." The material says formal, not the JD's word. R2-B2's slot stays inside the log |
| Reported on complaint volumes and resolution times | Inflated form of F5 | F5's quote: "I built the monthly complaints spreadsheet our regional manager uses." The material does not say what it counted. R1-B3's slot asks only that |
| Built Excel reports | Inflated form of F9 | F9's quote says spreadsheet, not Excel. R1-B3's slot asks only what it was built in |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote: "I trained new tellers on our escalation script." The material says tellers and training. R2-C3's slot stays inside the training |
| Has contact-centre experience | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I have never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided: the job description as pasted; the values text as pasted (you copied it on 11 November 2026 from the values page, which is where the text came from and was not read as a link); the recruiter's email on the three rounds; the 2026 strategy brief of July 2026 as you relayed four points from it (the brief itself was not pasted); your background as stated in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text, copied that morning, fixes the cheat sheet and the four value questions |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email gives the three sessions, who runs each and what each holds, which fixes loop mode and the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief points you relayed fix the grounding brief and the CO questions, so a search would not change them |
| 4. Interviewer name and Ashgrove | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The names and roles of the Head of Member Services and the two branch managers, once assigned → an interviewer read, per-panelist persona weights, and a reverse question tied to each person's career path
- The full July 2026 strategy brief → CO and CASE questions beyond the four relayed points
- From the recruiter, what the 20-minute case covers and whether anything is sent ahead → R3-D1 to R3-D3 reshaped to the real scenario; usually one email
- Your own answers to the answer slots, said outside any drill → F2, F3, F5, F6, F7 and F9 regenerate from your words, and R2-B2, R2-C3, R2-G1, R1-B3 and R3-C4 firm up
- A redacted view of the monthly complaints spreadsheet's column headings, with no member data → F5 and F9 move from limited proof to something inspectable
- Any figures you would quote about volumes or resolution times → defend-the-number questions on them
- How many hours a day you can prep → a resized triage
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering Ashgrove's recent organisation news, interview reports for similar roles and any public writing by the interviewers once named → say yes to run it
- A `tuesday-dossier.md` from an earlier fit check, if you have one → verified evidence and prohibited claims would replace the ones built here; the pack does not need it
