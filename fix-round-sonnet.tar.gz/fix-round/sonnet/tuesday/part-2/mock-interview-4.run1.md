Running the default research pass on Quartzline: values, interview process and strategy, three searches. Then I'll build the pack.
Your prep pack is saved as `quartzline_product-manager-platform-apis_interview_pack.md`. It has 22 questions across seven interviewer styles, built for a hiring-manager round and weighted toward the Skeptic and the live-case style.

**Research:** the web searches on Quartzline (values, interview process, strategy) were refused, so I couldn't research the company. The company-specific questions (B5, D3) and the values questions are generic, and the persona weights rest on the hiring-manager pattern plus what you told me. The pack's Sources section and upgrade menu say what would fix that.

**Highest-ROI prep:** A1 and its time-boxed twin G1, the "never held the title or owned a roadmap" objection from your dossier. The guidance has you name the limit first, make the adjacent case in your own quoted words, and concede the roadmap and prioritization points plainly. It never bridges them, and the prohibited-claims section binds every cell.

**R2 grading:** the dossier gave no strategy for R2 (shipped API or platform products), so A3 and its grading are my read from your integration evidence. That is probably the second-most-probed must-have, so check A3 closely.

I asked no questions because the dossier and your note covered what I needed.

- Say the word and I'll run a live drill as the Skeptic on A1.
- I can also save a `tuesday-dossier.md` update recording the gaps this prep exposed, for you to carry forward.
- If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday. Interviewer: the hiring manager, name not given. Built from your pasted underwriting dossier (conditional_go) and your message; Quartzline research could not run (see Sources).

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: past behavior, not generic virtue |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, solved aloud |

Bank letters skip F so question IDs never collide with fit-snapshot rows (F1 to F9). Provenance labels: `[grounded]`, `[inferred]`, `[generic]`.

## Prep triage

Do these in order; everything else is insurance.

1. A1 and G1: the objection the underwriter named. This is the highest-ROI prep in the pack. Rehearse the concession wording aloud until it is boring.
2. A2 and E1: the roadmap and prioritization concession, plus the ramp plan.
3. A3 and C1: the shipped-products question (F2) and the 30+ figure.
4. A4 and C2: the two pieces of evidence an interviewer can probe. A4 rests on medium-confidence evidence; C2 rests on an artifact you can bring.
5. B1 to B4: the four live cases.
6. Reverse questions RQ1 and RQ2.

Everything else is insurance.

## Fit snapshot

Requirements are the lines in your dossier's role_profile, which stand as the JD's lines. Evidence is quoted from your dossier's verified_candidate_evidence (numbered in its order). Confidence for F1, F5 and F6 is the underwriter's; the other rows are graded by this pack from the same quotes because the dossier carries no per-row evidence map.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [grounded] | transferability | Bridge, with its limit named first, as the underwriter framed it (`allowed_interview_strategy`: bridge). Limit in your words, sourced to `prohibited_claims`: "I haven't held a product manager title or role." Then the quote at its own scope. The work is adjacent to product management; the pack never writes it as years of the job |
| F2 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | discovery | The dossier lists no strategy for this must-have, so the grading is this pack's. The quote touches the requirement without showing whether it reaches it. Words stay at the quote. Answer slot (A3): R2 makes a probe on whether the integrations count likely. If you shipped an API or platform product, say what and which part was yours; if you did not, or the integrations were as far as it went, say so plainly and stay with the integrations you led |
| F3 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook" — dossier verified_candidate_evidence 2 | medium | [inferred] | discovery | The quotes name REST APIs, architecture and a playbook; neither names API docs or schemas. Answer slot (D2): R3 names them, so expect a probe. If you worked in docs or schemas, say what you did; if you did not, say so plainly and say what you would read first |
| F4 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [inferred] | discovery | The quotes reach clients and product; they do not show engineering or sales. The second quote is confirmed with limited inspectable proof, so expect a probe on it. Answer slot (B4, E2): if sales or engineering were part of that work, say how; if they were not, say so plainly and stay with the clients and product the quotes name |
| F5 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier's clarify area (`allowed_interview_strategy`: clarify): no verified entry speaks to Agile delivery itself, so no story is mapped. Answer slot (A5): if you worked that way, say how; if you never did, say so plainly and say what you would want to confirm about how this team defines it |
| F6 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier's `acknowledge_gap` area and `prohibited_claims`. Words: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan said as a plan, never as a past. No bridge and no slot on this row |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | discovery | The quote lists scoping and requirements as stages of the integrations; it does not say how those stages were done. Answer slot (B1): if scoping and requirements included talking with clients about what they needed, say how; if it did not, or it was not yours, say so plainly and stay with the stages the quote lists |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | discovery | The quote names requirements and architecture as stages, not specs or squads. Answer slot (B3): if you wrote anything engineers built from, say what; if you did not, say so plainly. Prioritizing for a squad stays off the table (`prohibited_claims`) |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | The material is silent. Answer slot (C3): if you tracked any adoption or usage measure, say what was counted and what part was yours; if you never did, say so plainly and say what you would measure first, as a plan |

## Persona table

Weights rest on the hiring-manager relationship prior and your own words (one 45-minute conversation with the hiring manager), not on a documented Quartzline loop. Reasoning is shown so you can recalibrate. Depth follows weight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the title, roadmap and shipped-product gaps | High: the hiring-manager prior includes it, and the underwriter named the objection (A1) | Rehearse A1 until boring; name the limit before it is asked; bridge only from the quoted sentences |
| B. Case/Strategist | Live problems from the role: discovery, adoption, a spec, a blocked go-live | High: the hiring-manager prior includes it, and the role's discovery, spec and adoption lines are live-problem material | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| C. Data-Driven Prober | Line-by-line on the 30+ and the playbook | Medium: any careful reader of your claims tests the figure and the artifact; one claim is medium-confidence | Know how the 30+ was counted or say you do not; name your weakest assumption first |
| D. Conversational | Friendly opener, biography, why this role | Medium: a 45-minute conversation opens with the journey and closes on reverse questions, and casual questions are still scored | A 90-second arc from quoted sentences; never answer the reverse slot with "you've covered everything" |
| E. Peer Evaluator | The seam between the PM and the two squad leads | Low: the interviewer is the hiring manager, but the JD's two squads make a collegial seam probe likely | Propose seam principles; do not pretend to know the seam |
| G. Pressure | The objection, time-boxed or interrupted | Low: not a prior for this round, but A1 can arrive as "sixty seconds" | Pause, restate, hold the quoted claim through two follow-ups, concede exactly |
| H. Values/Behavioral | Scenario probes | Low: no values-style round detected; no Quartzline loop source was read and the fallback archetype is generic | Selection scaffold ending in the honest branch |

## Question banks

### A. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook" | The underwriter named this objection, and it is the highest-ROI prep in the pack. Step 1, say the limit before they do: "I haven't held a product manager title or role, and I haven't owned a product roadmap" (`prohibited_claims`, `acknowledge_gap`). Step 2, the adjacent case at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live — and I wrote the internal integration playbook." Step 3, stop; let them draw the inference. Follow-up 1 ("what transfers?"): repeat that sentence, do not widen it. Follow-up 2 ("that's delivery, not product"): concede exactly: "That's fair. The work I've done is adjacent, and deciding what gets built has not been my job." Then a plan, not a past: in the first weeks you would learn with the squad leads which decisions are whose (RQ1). Never say you were effectively a PM or that this equals three years of the job | F1 is the biggest gap and the question every version of this interview contains; JD because it scores R1 directly |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it yourself, before they do: the roadmap. Words: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad" (`acknowledge_gap`, `prohibited_claims`). Then the ramp plan, as a plan: in week one you would ask which decisions are the PM's alone and which belong to the squad leads. The underwriter found no evidence to bridge this, so do not reach for another story; a candid weakness plus a plan is the whole answer | F6 is an `acknowledge_gap` row, and a persona stem asks exactly this; JD because it scores the responsibility |
| A3 | "What API or platform products have you shipped?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say only the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: R2 asks for shipped API or platform products, so expect a probe on whether the integrations count. If you shipped an API or platform product, say what and which part was yours, in your own words; if you did not, or the integrations were as far as it went, say so plainly and stay with the integrations you led | F2 is a must-have row with no underwriter strategy, so the probe is likely and the honest branch should be ready; JD because it scores R2 |
| A4 | "Walk me through the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on F4's quote at its own scope: sessions, quarterly, you ran them, they fed client evidence to product; tell it in your own words. This claim is confirmed with limited inspectable proof, so name the limit before it is extracted: say plainly what you can and cannot show from the sessions. If asked what product did with the evidence, say what you know, and say plainly if you do not know. Never describe the sessions as setting or shaping the roadmap; that wording is on the prohibited list | F4's third quote is the one the dossier flagged for a probe; EXP because it tests what was actually yours |
| A5 | "What's your experience with Agile delivery?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify strategy: no verified entry speaks to Agile delivery, so no story is mapped. Answer slot: the JD's R5 line names Agile delivery, so expect a probe on what it means for you. If you worked that way, say how, in your own words; if you never worked that way, say so plainly and say what you would want to confirm about how this team defines it. Then return to the one sentence you do have: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." | F5 is the dossier's clarify area; JD because R5 is a stated preferred requirement |

### B. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch your first 60 days of discovery with the partners on this API platform — what do you need to know first?" | CASE | [generic] | Clarify before structuring: who the partners are, who already talks to them, how adoption is measured and what the baseline is (both are open questions for you). Then objective, partner segments, approach, metrics, risks. Say the first thing you would ask the squad leads. Challenge one premise: "discovery" assumes partners can be reached; ask how. A live problem, so it makes no claim about your past | The JD's discovery line (F7); CASE because it is asked as a problem; generic because Quartzline research did not run |
| B2 | "Partner API adoption has been flat for two quarters. Diagnose it." | CASE | [generic] | Define adoption first (sign-up, first successful call, production traffic), then segment partners, find the stage where they drop, list hypotheses (docs, onboarding, limits, partner priorities), say what data you would pull first and what you would not conclude from it. Name your weakest assumption aloud | The JD's adoption-metrics line (F9); the current baseline is an open question, so the case is run on assumptions you state |
| B3 | "A partner asks for a new endpoint. What goes in the spec before you hand it to a squad?" | CASE | [generic] | Structure it: the partner outcome and who else needs it; what you would settle with engineering first; the request and response shape, errors and versioning; how you would know it worked. Ask what engineering needs before you write, rather than asserting a template | The JD's spec line (F8); CASE because it asks what you would do, not what you did |
| B4 | "Sales has promised a partner a workaround for a go-live blocker; engineering says it needs a redesign. What do you do?" | CASE | [generic] | Clarify the blocker and the promise, who decides, what each side is optimizing; options with costs; what you would tell the partner and when; what you would change so it does not recur. Show spine and tact together. It is a hypothetical, so say "I would" | R4's engineering, sales and customers triangle (F4); CASE |
| B5 | "What do you know about how partners use our API platform today?" | CO | [generic] | Quartzline research did not run, so this pack holds no verified facts about the platform; do not guess. What you can say rests on the JD's own lines: a partner-facing API platform, two engineering squads, adoption metrics. Then the honest branch: you have not seen usage data, and say how you would find out. If you have since read Quartzline material, say only what you read | CO coverage; generic, and this is the cost of the research refusal |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The quote says you led 30+ end-to-end integrations; keep to "led". Answer slot, in your own words: how it was counted (what counted as one integration), what the figure is sensitive to, the assumption behind it you would defend least, and which of the listed stages were yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F1's headline figure; EXP because a prober scores attribution and counting |
| C2 | "Show me the integration playbook you wrote — how is it organised, and what would you change in it?" | EXP | [grounded] "Wrote the internal integration playbook" | Story-mapped on F3's second quote: it is the internal integration playbook and you wrote it. The dossier records it as inspectable; if it can be shared, check that you may share it, and bring it or offer to walk through it. Know the section you would revise first and say why, in your own words. Do not describe contents you cannot recall, and do not call it a company standard | The one artifact an interviewer can open; EXP because it tests what you wrote versus what you describe |
| C3 | "How would you define and track adoption for a partner API, and what have you tracked yourself?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the JD's adoption-metrics line makes a probe on tracking likely. If you tracked any adoption or usage measure, say what was counted, how, and which part was yours; if you never did, or it was not yours, say so plainly, then say how you would define it as a plan, and return to the integrations you led | F9 is silent in your material; JD because it scores a stated responsibility |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, each a quoted sentence at its own scope: the integrations you led; the playbook you wrote; the roadmap-input sessions you ran. Say the third with its limit: confirmed, limited inspectable proof. Close with why you are moving toward product, in your own words | F1, F3 and F4 supply the beats; the casual register is still scored |
| D2 | "What have you been working with lately on API docs and schemas?" | JD | [generic] | Answer slot: R3 names API docs and schemas, so expect a probe. If you work with docs or schemas regularly, say what and what you did; if you do not, say so plainly and say what you would read first. Do not name tools you have not used | F3; a casual question about a hot JD topic |
| D3 | "Why this role, and why now?" | JD | [generic] | Selection criteria: the reason must come from you, because neither your material nor any research here carries your motivation. It should be specific to the move toward product, consistent with the A1 concession, and tie to a sentence you could quote from your own work. If no reason is crisp, say what you are trying to find out in this conversation | F1; a motivation probe the Skeptic and Conversational styles both ask |

### E. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You'd sit between two squad leads. Where is the seam between your calls and theirs, and what happens when we disagree?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Offer seam principles, not a map you do not have: decision rights stated up front, who decides when the squads' needs collide, disagreements taken to evidence. Say plainly "I haven't set prioritization for an engineering squad" (`prohibited_claims`). Reciprocity, at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Then ask which decisions are the squad leads' (RQ1) | The dossier's open risk on decision authority (F6, F8); JD because the JD asserts the authority |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection criteria: pick a time work crossed teams and credit mattered; it needs a named stake, what you did about it, and an intact relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4's stakeholder requirement in collegial packaging; the stem is a persona stem |

### G. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, restate the question. Hold only what the quote carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Hold it through two follow-ups by repeating it, not by adding to it. Concede explicitly: "I haven't held a product manager title or role, and I haven't owned a product roadmap" (`prohibited_claims`, `acknowledge_gap`). Never fold on the quoted claim to restore harmony | The time-boxed form of A1, which this pack names as the highest-ROI prep |
| G2 | "That integration work — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Anchor on the verb the quote uses: you led them. Answer slot: which of the listed stages were yours and which belonged to others, in your own words; if some stages were not yours, say so plainly and return to the ones that were. Hold through two follow-ups, then concede specifically what was not yours | F1; attribution is the pressure stem |

### H. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: pick a time with a named stake, the moment you did not soften the message, and a relationship that survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; no Quartzline values were read, so it is not tied to a company value |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a specific decision, what the internal metric was, what the customer needed, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; fits a partner-facing role |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1 3+ years product management experience | A1, A2, D1, D3, E1, G1 |
| R2 Shipped API or platform products | A3, C1 |
| R3 Technical fluency: API docs, schemas | C2, D2 |
| R4 Stakeholder management across engineering, sales, customers | A4, B4, E1, E2 |
| R5 Agile delivery experience | A5 |
| Responsibility: own the roadmap | A1, A2, E1, G1 |
| Responsibility: run discovery with integration partners | B1 |
| Responsibility: write specs, drive delivery with two squads | B3, B4 |
| Responsibility: define and track adoption metrics | B2, C3 |

## Reverse questions

The first two come from your dossier's questions_for_employer and opportunity_risks_to_validate. No interviewer profile exists, so none is tied to their path.

| # | Question | Why it lands | Source |
|---|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts the PM's authority over the two squads but your dossier found no evidence of it; the answer tells you what you would be accountable for, and it reads as diligence | dossier questions_for_employer; opportunity_risks_to_validate |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The role names adoption metrics as a responsibility and no baseline is stated; the answer sizes the first-year target you would inherit | dossier questions_for_employer; opportunity_risks_to_validate |
| RQ3 | "What would a strong first 90 days look like, and what should a new PM leave alone while they learn?" | It invites the hiring manager to set the ramp, which turns your A2 plan into a shared one | [generic] |
| RQ4 | "How do the two squads take in partner input today, and where does it get stuck?" | It shows discovery thinking and gives you the real seam to compare with B1 | [generic] |
| RQ5 | "What separates an adjacent-background hire who succeeds here from one who struggles?" | It puts the A1 objection on the table as a conversation rather than a verdict | [generic] |

## Prohibited claims

Built from your dossier's `prohibited_claims` and from stretched forms of your own sentences. Each is absent from every cell above.

| Not coached | Basis | Honest form |
|---|---|---|
| "Having held a product manager title or role" | Dossier `prohibited_claims` | "I haven't held a product manager title or role." Then the F1 quote at its own scope |
| "Having owned a product roadmap" | Dossier `prohibited_claims` and the `acknowledge_gap` area | "I haven't owned a product roadmap." A ramp plan; no bridge and no slot |
| "Having set prioritization for an engineering squad" | Dossier `prohibited_claims` and the `acknowledge_gap` area | "I haven't set prioritization for an engineering squad." A ramp plan; no bridge and no slot |
| Influenced or shaped the product roadmap | Inflated form of F4's third quote | The quote at its own scope. The limit is the pack's observation: your material says sessions feeding client evidence to product, not what product decided. A4's slot stays inside the sessions |
| Standardised integration practice across the company | Inflated form of F3's second quote | The quote at its own scope. The limit is the pack's observation: your material says you wrote the internal integration playbook, not how far it was adopted. C2's guidance stays inside the playbook |

## Sources

Provided: your message; tuesday-dossier.md, pasted (dossier_version 1.1, generated 2026-08-14 by job-underwriter). Consumed: role_profile (requirements and responsibilities, standing as the JD's lines), handoff_to_mock_interview (all fields), decision (context only). The dossier carries no evidence_map, evidence_state or risk_register, so F2, F3, F4, F7, F8 and F9 are graded by this pack and flagged `[inferred]` or `[grounded]` accordingly.

Searches sent, all refused (permission not granted in this session):
- `Quartzline company values`: refused
- `Quartzline interview process product manager`: refused
- `Quartzline partner API platform strategy news`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline company values` | unavailable | Would have fed a values cheat sheet and VAL questions tied to published values; none is in this pack |
| 2. `Quartzline interview process product manager` | unavailable | Would have fixed persona weights to a documented loop; weights rest on the hiring-manager prior and your own words |
| 3. `Quartzline partner API platform strategy news` | unavailable | Would have grounded B5 and D3 in current strategy; both are generic |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile supplies the requirements the fit snapshot and JD questions use |

## Upgrade menu

- Search permission, or Quartzline's values page and careers page pasted in → B5 and D3 become grounded, and a values cheat sheet appears if their loop includes a values round. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available on your word
- The hiring manager's name or profile → an interviewer read, persona weights adjusted to their public footprint, and a reverse question tied to their path
- The recruiter's prep email (focus areas, any exercise to bring) → coverage of anything pre-declared
- A written record of the roadmap-input sessions (an agenda, a notes page, a summary sent to product) → raises A4's evidence from medium and gives a prober something to inspect
- Your own answers to the slots in A3, A5, B1, B3, C1 and C3, written in your own words → rows F2, F5, F7, F8, F9 regenerate from your quotes instead of from slots
