Web searches were denied, so I'm building the pack from your message and the recruiter's email only, and I'm saving it now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-5-denied-fc0accaf/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

I built it for the panel as the recruiter described. It covers the 15-minute POV and the Q&A, and it is sized to your four hours.

- **Searches were refused.** All five were denied, so the pack rests on your message and the recruiter's email only. There is no interviewer read and no company grounding, and the Kelverton-specific questions are generic.
- **I haven't seen the market report.** The attachment wasn't in our conversation, so I haven't read it. The POV section tells you where to bring in one consensus item and one divergence, but you fill in the actual item from your reading.
- **Highest-ROI prep:** B1, "You haven't sold into rail. What makes you credible with our operators?" The pack rehearses your own wording: "I haven't sold into rail specifically." The one phrase to firm up is "the operator world from the other side." A panel will ask which side that was, so decide how you'd answer it or drop it.

Say the word and I'll play Deepa on B1, the question the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the job description, or the posting text, to paste? With it, the requirement rows and the JD-tagged questions would be re-aimed at Kelverton's actual wording.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your POV on where you would take operator partnerships over the next 18 months, no slides, landing on what it means for the operators. Rest is Q&A; per the recruiter, Ross will push on commercials.

**Built on:** your message and the recruiter's email only. No JD was supplied and web research did not run (every search was refused), so the requirement rows come from the recruiter's words and from role-family patterns, and the interviewer read, grounding brief and values cheat sheet are dropped. The market report was attached to the recruiter's email, but its text is not in this conversation, so I have not seen it.

## 1. How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: where a line is in quotation marks it is your own sentence from your message, and where a beat needs something only you know, it is an answer slot for you to fill in your own words.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows a value, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually you |
| JD | Role-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Homework depth and whether you can think at the company's altitude |
| CASE | Live problem | Structure and reasoning on a problem from the role |

## 2. Prep triage (four hours)

1. **90 minutes, first sitting: build the POV** from section 4. Choose a thesis, write the three moves, the concession and the operator close. Covers A1 and A3.
2. **50 minutes: rehearse the objection aloud.** B1 first, then B2 and D1, until the plain acknowledgment sounds boring. This is the highest-ROI prep in the pack.
3. **50 minutes: write your answers to the number slots** in C1, C2 and D2 in your own words (how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours), then C3 for Ross.
4. **50 minutes: two timed runs of the POV** (aim for 10 to 12 minutes; 15 is the ceiling), then A5 with the report open, then pick two reverse questions from section 8.

Everything else (A2, A4, B3, B4, E1, E2, F1, F2 and the other reverse questions) is insurance.

## 3. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message; "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | transferability | Your material carries partnership work and bus and light rail network planning, not operator partnerships at a rail software company, and the words stay at that scope: "9 years in partnerships, last 4 at a payments company running the ISV channel". Answer slot: the recruiter's ask makes a probe on how the consulting work relates to operators likely. If part of it brought you into operators' own decisions, say which part and what you saw, in your own words; if it did not, say so plainly and stay with the network planning |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The sentence does not say which side you stood on or whether any of it involved train operating companies, and "the other side" is the phrase a panel will ask you to unpack. Answer slot: if you can say in one sentence which side you stood on and what you saw there, say it; if the phrase was looser than that, drop it and use the network planning wording alone |
| F3 | "Ross will push on commercials" — recruiter's email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The sentence is a result with a count and an influenced figure; it does not show pricing, terms or deal structure. Hold it at its scope: "took it from 6 partners to 40, roughly £4M of influenced revenue". Answer slot: if you shaped any commercial terms with those partners, say which and how, in your own words; if you did not, say so plainly and stay with the partner count and the influenced figure |
| F4 | Partnering with rail operators who buy the software — role-family requirement, no JD supplied; context: "they sell scheduling software to train operating companies" — your message | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically, and I never carried a direct quota; the figure is influenced revenue." Then how you would learn it, said as a plan and never as a past |
| F5 | Building and scaling a partner programme — role-family requirement, no JD supplied | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | The quotes already reach the requirement. Lead with them in their own terms, the channel and the count, because a named number beats an adjective. It is a self-reported line with nothing inspected behind it, so expect the defend-the-number probe (C1, C2, D2) |

## 4. Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. Build it from these parts. Every part is proposed, pending your approval.

**Grounded facts to build on (your words only):**

| Fact | Draws on | Quote |
|---|---|---|
| Your channel result | F5 | "took it from 6 partners to 40, roughly £4M of influenced revenue" |
| Your sector background | F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" |
| Your stated limit | F4 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." |

**Three theses, each with the concession you must make** (all proposed, pending your approval):

| Thesis | Mandatory concession | Operator close (slot) | Provenance |
|---|---|---|---|
| T1. Judge every operator partnership by one test: what changes for the operator. Choose partners, and sequence them, by that test. | "I haven't sold into rail specifically" (F4), so this is a test I am proposing, not an answer I already have; I would calibrate it with what your operator partners tell us early on. | For the operator, this means: fill in the one operator-level outcome you can tie to the planning work in F2 or to something the report names; if you can tie it to neither, say it is a hypothesis you would test | [generic] |
| T2. Go deeper before wider: fewer operator partnerships, each built around a shared commercial plan, before adding count. | The number I quote is a count, 6 to 40 (F5); whether breadth is the lever here is something I would want Deepa's view on. | For the operator, this means: fill in what a shared plan gives them that a looser arrangement does not, in their terms rather than ours | [generic] |
| T3. Use operators' own planning constraints as the filter for which partners and integrations to prioritise. | Bus and light rail network planning (F2) is not a train operating company's scheduling; I would test whether it carries over rather than assume it. | For the operator, this means: fill in the constraint it removes or the decision it improves for them | [generic] |

My read: lead with T1, because it closes on the operators by construction, and use T2 as the hook for Ross's commercial push. Keep T3 as backup; it leans on F2's "other side" phrase, which needs the F2 slot answered first.

**Differentiation from the report.** The report is equally available to Deepa, Ross and every other prepared candidate, so do not recite it. Bring one item from it, named exactly, to prove grounding: fill in which item. Then one divergence with your reasons. Then the anti-pick: one kind of operator partnership, or one segment, you would deprioritise in the first 18 months, because part of this role is saying no.

**Shape (a ceiling, not a target):** thesis in the first minute; three moves; the concession said out loud before anyone asks; the operator close last.

## 5. Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Deepa pressing on the POV and live "what would you do" problems | High. Hiring-manager relationship prior is Case/Strategist plus Skeptic, and the POV is itself a live strategy problem the recruiter announced | Clarify, then structure, then answer; challenge one premise respectfully; use their vocabulary |
| Skeptic | Deepa or Ross probing "you have not sold into rail" | High. Same prior, and you stated the gap yourself (F4) | Rehearse the single predictable objection (B1) until it is boring; bridge only from what you said; give a ramp plan |
| Data-Driven Prober | Ross on the 6-to-40 and £4M figures | Medium. The recruiter said Ross will push on commercials, and every headline figure is a probe target | Know what you can and cannot say about how each figure was counted; name the assumption you would defend least first |
| Pressure | Ross time-boxing or challenging "why you" | Medium. Executive-level relationship prior plus the recruiter's note on Ross | Pause, restate, hold the position through two follow-ups, then concede specifically |
| Conversational | A friendly opener before the POV | Low. A short opener is likely, but the recruiter's email makes the POV the structure | Pre-script a 90-second arc from your own sentences; treat casual questions as scored |
| Values/Behavioral | Scenario questions, probably light | Low. No source shows a values round in this loop, so no values-style round is assumed | Choose stories where the hard truth landed; if none comes to mind, say so |

The Peer Evaluator is not built: neither panellist is a peer. Weights rest on relationship priors and the recruiter's words; with no public interviewer information, no signal adjustment was applied.

## 6. Question banks

### A. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months, and land on what it means for the operators." | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Deliver section 4: thesis first, three moves, the concession, then the operator close. Your own background enters only as the quote's words, with the F2 slot answered before you rely on "the other side". Name what you do not yet know about their pipeline as a limit before they do | The recruiter announced it, so it is certain; F2 is the evidence row it leans on. CASE because it is a live problem from the role |
| A2 | "What would you need to know about our operator partnerships before committing to that plan?" | CASE | [generic] | Ask two or three diagnostic questions in order: what success is today, which operators matter most, what the commercial model is. Challenge one premise of the plan respectfully. The question needs no claim about your past, so the guidance makes none | Asked after any POV; it scores whether you clarify before you commit |
| A3 | "Which kind of operator partnership would you decline in your first six months, and why?" | CASE | [generic] | Name one kind and give the criterion, tied to your thesis rather than to a preference. Concede what you cannot see from outside. No claim about your past | Saying no is part of the job, and the anti-pick in section 4 prepares it |
| A4 | "An operator partner tells you our product doesn't fit how their planners actually work. What do you do in the next conversation?" | CASE | [generic] | Structure: listen and restate; separate the product issue from the partnership; agree what you will take back and by when; say who internally you would bring in. It asks about no past of yours | Tests the operator-first stance the recruiter asked for, as a live moment |
| A5 | "Our strategy team circulated a market report. What did you take from it, and where would you disagree?" | CO | [inferred] derived from your message: the recruiter attached the report | One named consensus item to show you read it, then one thesis-driven divergence with reasons, then the anti-pick. Fill in the item from your reading; I have not seen the report. Never recite its list | The report is shared with every prepared candidate, so departing from it with reasons is what scores |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. What makes you credible with our operators?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **Highest-ROI prep in this pack.** Plain acknowledgment first: "I haven't sold into rail specifically." Then the bridge at its own scope: "5 years in transport consulting (bus and light rail network planning". Answer slot: the phrase "the operator world from the other side" is the likely follow-up; say which side and what you saw, in your own words, or drop the phrase. Follow-up ladder: level one, "bus and light rail is not a train operating company", concede it as the limit and say what you would not claim; level two, "so what do you actually bring", return to the quoted facts and a ramp plan stated as a plan, never as a past. State the limit before it is asked for | F4 is the gap you named yourself and the likeliest objection in any form. JD because it scores the role's implicit requirement |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick one of your two stated limits and say it plainly: "I never carried a direct quota; the figure is influenced revenue." Then the ramp plan, as a plan. Do not volunteer a weakness you have not stated | A persona stem; F4 supplies the honest answer |
| B3 | "Why this move, and why now?" | JD | [generic] | The pack has no sentence of yours about why you are moving, so it writes none. Answer slot: say your reason in your own words; if it is partly practical, say so plainly. Pick one reason that is about the role, not about leaving | Motivation consistency is what a skeptic scores |
| B4 | "You've run a payments ISV channel. What transfers to selling through operators, and what doesn't?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Start from the quote at its scope: "last 4 at a payments company running the ISV channel". Answer slot: if some part of running that channel maps to operators, say which and why, in your own words; if nothing does, say so plainly. Name the limit alongside what transfers | F5 and F1 are the adjacent evidence; the question asks you to state its limits |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You took the channel from 6 partners to 40. Walk me through how that was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | The four slots a figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do. I name no method | Headline number on the CV-equivalent; Ross will probe it. F5 |
| C2 | "What does £4M of influenced revenue mean, and what would have happened without you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Say it as you stated it: "I never carried a direct quota; the figure is influenced revenue." Then the four slots in your own words. If part of it would have happened anyway, say so plainly | Influenced revenue is attribution-soft by nature, and the prober goes there. F3, F4 |
| C3 | "What would you want to be accountable for in our numbers over 18 months, and what's realistic?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | State the limit first: "I never carried a direct quota." Then offer how you would frame accountability, as a position: what you would commit to measure first, and what you would need to see before giving a figure. If pressed for a number, give the method for getting one, not a number you have not built | Ross pushes on commercials; the safe answer is a framework plus an honest limit. F3, F4 |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel" "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause, restate. Concede the limit first, then the facts at their scope: nine years in partnerships, the last four at a payments company running the ISV channel, and five years in transport consulting. Hold through two follow-ups by returning to those facts, never by adding to them. Do not claim to be better | A persona stem; F4 is the reason it will be asked |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold the sentence as it stands. Answer slot: say which part was yours in your own words; if you cannot split it, say so plainly. Hold through two follow-ups, then concede the uncertainty specifically without folding on the core claim | A persona stem; attribution is what the pressure persona tests. F3 |
| D3 | "Your plan sounds generic. What in it is specific to us?" | CASE | [generic] | Anchor in the thesis you chose and in the report item you named. Concede what you cannot see yet, and name what you would test first. No claim about your past | Follows any POV; tests whether differentiation from the report was real |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc from these two sentences only: the consulting years, then nine years in partnerships, the last four running the ISV channel. The linking reason is an answer slot: say in your own words what moved you from planning to partnerships; if there was no deliberate move, say so plainly | Likely opener; F1, F5 |
| E2 | "How do you keep up with how train operators run today?" | JD | [generic] | The pack has no sentence of yours about this, so it is a selection scaffold: pick one real habit or source, say it plainly, and name one thing it taught you; if nothing comes to mind, say so, then say how you will start. Never name a source you do not use | A casual question on the role's central topic; still scored |

### F. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; no quote of yours carries this story |
| F2 | "When did you put a partner or customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision with a stated cost to the internal metric and a result the partner could see. If none comes to mind, say so plainly, then say how you would handle it | A persona stem, bent to your channel background; no quote carries it |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 operator partnership direction, 18 months | A1, A2, A3, A4, A5, B4, D3 |
| F2 land on what it means for operators | A1, A4, B1, E1 |
| F3 commercials | C1, C2, C3, D2 |
| F4 partnering with rail operators | B1, B2, D1 |
| F5 building a partner programme | B4, C1, E1 |
| Motivation, curiosity, values | B3, E2, F1, F2 — no requirement; persona coverage only |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do you define a successful operator partnership today, and who inside an operator do you most want to hear it from?" | Shows you start from the operator's view, which is what the recruiter asked you to land on |
| R2 | "What would you want the first 90 days of this role to have changed for operators?" | Turns your POV into a shared plan and tells you what Deepa will judge you on |
| R3 | "How do partnerships show up in the commercial plan today: sourced revenue, influenced revenue, or something else?" | Fair diligence for Ross, and it tells you whether your influenced-revenue background matches how you would be measured |
| R4 | "Does this role carry a revenue target, and how is it set?" | You have not carried a direct quota, so you need the answer to decide, and asking directly is better than finding out later |
| R5 | "Is there anything in the market report you've already revised your view on?" | Signals you read it as a working document and invites the live strategy conversation |
| R6 | "What would make this hire a mistake twelve months from now?" | Surfaces the real objection while you can still address it |

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F4 | The plain acknowledgment: "I haven't sold into rail specifically." No slot |
| Has carried a direct revenue quota or owns a revenue number | Negative you stated, F4 | The plain acknowledgment: "I never carried a direct quota; the figure is influenced revenue." No slot |
| Generated or closed £4M | Inflated form of F3 | F3's quote at its own scope: "took it from 6 partners to 40, roughly £4M of influenced revenue". The limit is the pack's observation: your material says influenced revenue |
| Knows the operator world from the inside, or has worked at a train operator | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says bus and light rail network planning in consulting, and does not say which side you stood on |

## 9. Sources

Provided: your message; the recruiter's email as you quoted it. The attached market report was not in the conversation and was not read.

Searches sent (all refused, none returned a result): "Kelverton Rail values"; "Kelverton Rail strategy news train operating companies scheduling software"; "Deepa VP Partnerships Kelverton Rail"; "Ross Commercial Director Kelverton Rail"; "Senior Partnerships Manager rail technology scheduling software train operating companies job".

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The search was refused; it would have supplied published values for the VAL questions, which stay generic here |
| 2. Kelverton Rail interview process, partnerships | skipped | The recruiter's email already fixes this session's structure and personas; nothing a search could return would change them |
| 3. Kelverton Rail strategy and recent news | unavailable | The search was refused; it would have grounded A5 and a grounding brief, which is dropped |
| 4. Interviewer names with Kelverton Rail | unavailable | Both searches (Deepa, Ross) were refused; they would have supplied the interviewer read, persona adjustments and a reverse question tied to their paths |
| 5. Representative Senior Partnerships Manager JD | unavailable | The search was refused; it would have replaced the role-family rows F4 and F5 with quoted requirements |

## 10. Upgrade menu

- The JD text → F4 and F5 take quoted requirements, JD-tagged questions are re-aimed, and any gate such as location or travel gets surfaced
- The market report's headline recommendations pasted in → A5 and the section 4 differentiation become grounded in its actual items
- The interviewers' public profiles or any talks → an interviewer read, tuned persona weights, and a reverse question tied to their own paths
- Kelverton's published values → named VAL questions and a mapped values sheet, if a values round exists
- Permission to run web searches → the research above, in one pass
- A dossier from an earlier fit assessment → verified evidence for the quote cells, allowed strategies per weak area, and the objection already named
- One email to the recruiter asking what Ross means by commercials (pricing, partner terms, targets) → sharper C-bank and R3
