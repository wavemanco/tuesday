I've read the mock-interview playbook and your dossier. Now I'm running the default research pass on Quartzline (values, interview process, strategy), then I'll build the pack.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-4-denied-7a1ee538/Quartzline_product-manager-platform-apis_interview_pack.md`.

I built it for the hiring-manager round from your dossier and the 45-minute format, with 20 questions across six interviewer styles. Case and Skeptic carry the most weight. I didn't ask you for anything, since the dossier already supplied the role and your evidence.

- **Company research didn't run.** The three web searches (values, interview process, strategy) were refused, so I used no Quartzline facts. Anything company-specific, like D3 "What drew you to Quartzline?", is labeled generic. Do a short read of their public site yourself before Thursday.
- **B1 is the one to rehearse.** It's the underwriter's objection about never having held the PM title or owned a roadmap. The pack scripts the concession, the bridge from your confirmed integration work (clearly labeled adjacent) and a ramp plan.
- **Roadmap-input sessions.** Expect a probe here (C3, E1). The dossier rates this evidence medium confidence, so the pack coaches you to say plainly what you can and can't show of them.
- **The dossier has a hole on R2.** "Shipped API or platform products" is a must-have, but the dossier gives it no strategy. I treated it as an adjacent bridge (B3) and flagged it in the pack.
- **The dossier's "seven years" is not used.** No verified entry carries a duration, so I left it out of anything you'd say. Telling me the real span would let the bridge state it.
- **Answer slots.** Where your confirmed evidence doesn't reach a requirement (API docs and schemas, engineering and sales alignment, agile, adoption metrics), the pack gives an either-way slot, not a story. Fill each with your real answer or the honest "no".

Say the word and I'll play the Skeptic on B1, run as a live drill with follow-ups.
I can also save a `tuesday-dossier.md` update recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. Interviewer: the hiring manager (no name given).
**Built from:** your tuesday-dossier.md (role_profile and handoff_to_mock_interview). No company research ran (see Sources), so company-specific content is labeled `[generic]`.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny and attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

Where a cell says "answer slot", it is an instruction for the interview, not a question for you now: answer either branch honestly, from your own experience.

## Prep triage

Do these in order before Thursday; everything else is insurance.

1. Say B1 aloud until the concession sounds ordinary (the pack's highest-ROI prep).
2. C1, C2 and C3: the three things you said you did, each told at exactly its own scope.
3. A1 and A3: structure a case out loud, and practise asking who decides before you decide.
4. Pick the two reverse questions you most want answered (reverse questions 1 and 2 are the dossier's).
5. Everything else is insurance.

## Fit snapshot

Requirements are quoted from the dossier's role_profile. Evidence cells quote only your confirmed claims (V1 to V3 below), without the dossier's confidence notes, which sit in the Confidence column and the bridge.

- V1 = "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier band: high, inspectable)
- V2 = "Wrote the internal integration playbook her team uses" (dossier band: high, inspectable)
- V3 = "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier band: medium, limited inspectable proof, expect a probe)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| FS1 | "3+ years product management experience" — JD (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | Confidence is the dossier's grade for this requirement (V1 is high, V3 medium). The bridge is adjacent and stays labeled adjacent: integration leadership, not product management. Words stay at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Plain acknowledgment, sourced by `prohibited_claims` (the title/role item): "I haven't held the product manager title." The material shows no duration for the integration work, so no length is claimed |
| FS2 | "Own the roadmap for the partner-facing API platform" — JD (responsibility) | none given | none | [grounded] | capability | The dossier records this as an `acknowledge_gap` area (`uncertain_or_weak_areas`) and lists roadmap ownership under `prohibited_claims`. Words: "I haven't owned a roadmap." Then a ramp plan said as a plan, never as a past. No bridge and no answer slot |
| FS3 | "Shipped API or platform products" — JD (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | The dossier lists this must_have in no weak-area entry, so this grade and strategy are the pack's own derivation. The quote is integration work with go-live in it; it does not say an API or platform product was shipped, and the words stay at the quote. Answer slot: the JD's "shipped API or platform products" makes a probe on what went live likely. If any of what went live was an API or platform product rather than a client integration, say which and what part was yours; if all of it was client integrations, say so plainly and stay with them |
| FS4 | "Technical fluency: API docs, schemas" — JD (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes touch the requirement (REST APIs, architecture, a playbook) without showing API docs or schemas. Answer slot: the JD names API docs and schemas, so expect a probe. If you wrote, reviewed or worked from API docs or schemas, say which and what you did with them; if you did not, say so plainly and say how you read an API you are new to |
| FS5 | "Stakeholder management across engineering, sales, customers" — JD (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The quotes reach clients and product; neither names engineering or sales stakeholders. Words stay at the quotes. Answer slot: the JD lists engineering and sales, so expect a probe on each. If you aligned engineers or sales on a decision during that work, say who and what was decided; if you did not, say so plainly and stay with the client side |
| FS6 | "Agile delivery experience" — JD (preferred) | none given | low | [grounded] | discovery | The dossier's strategy here is `clarify`: no confirmed quote speaks to this. Answer slot: the JD's "Agile delivery experience" is the likely probe. If you have worked in agile delivery, say how, in your own words; if you have not worked that way, say so plainly and say what you would want to confirm about how the two squads define it |
| FS7 | "Run discovery with integration partners" — JD (responsibility) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | Scoping and requirements with clients are adjacent to discovery, not the same work. Words stay at the quotes: you led the integrations, you ran the sessions. Answer slot: if any scoping conversation changed what a client built, say what; if not, say so plainly and stay with the integrations you led |
| FS8 | "Write specs and drive delivery with two engineering squads" — JD (responsibility) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The quote carries requirements through go-live on client integrations; it does not say engineers were directed, and setting a squad's priorities is on the prohibited list. Words stay at the quote. Answer slot: if any of the requirements you wrote were built by an engineering team, say who and what your part was; if not, say so plainly |
| FS9 | "Define and track adoption metrics" — JD (responsibility) | none given | none | [grounded] | discovery | The material is silent, and silence is discovery, not capability. Answer slot: if you have defined or tracked any adoption-type measure, say what was counted and who used it; if you have not, say so plainly and say what you would want to measure first |

## Graded deliverables

None. No pre-declared deliverable was mentioned for this round.

## Persona table

The loop is established by your own words (one 45-minute conversation with the hiring manager), so no archetype fallback is used. Weights start from the hiring-manager relationship prior (Case/Strategist and Skeptic dominant) and are not adjusted by interviewer signals, because no interviewer information exists.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (rehearsal method, not a claim) |
|---|---|---|---|
| A. Case/Strategist | Live problems on the platform: first weeks, a flat adoption metric, conflicting squad asks | High: the hiring-manager prior; the role is the interviewer's own roadmap | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | The PM-title and roadmap objection, in several forms | High: the hiring-manager prior, and the dossier named this objection | Rehearse B1 until it is boring; bridge only from V1 to V3; ramp plan, not bluff |
| C. Data-Driven Prober | "How was 30+ counted", what is in the playbook, what came of the sessions | Medium: one headline figure and three confirmed claims, one with limited inspectable proof | Know what you can and cannot say about each claim; offer to walk through the playbook |
| D. Conversational | "Walk me through the journey", casual questions on JD topics | Medium: most conversations open this way, and the 45 minutes are short | A 90-second arc told from the three quotes; treat casual questions as scored |
| E. Pressure | Time-boxed "why you", "how much was you" | Low: possible after B1, in the hiring-manager prior's shadow | Pause, restate, hold the quoted position through two follow-ups, concede specifically |
| F. Peer Evaluator | "Where is the seam with the squad leads" | Low: the squad leads may appear in the questions even if they are not in the room | Offer seam principles, not a pretended seam; reciprocity |
| Values/Behavioral | Not banked | No values-style round is established by your words, and the hiring-manager prior does not include it; no company values were researched | Revisit if a recruiter names a values round |

## Question banks

Provenance quotes are exact. V1 to V3 are defined above the fit snapshot.

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch your first thirty days on the partner API platform — what do you need to know first?" | CASE | [generic] | Clarify before you structure: who decides what between you and the two squad leads, and how adoption is measured today and from what baseline (the two unknowns in the posting). Then objective, partner segments, approach, metrics, risks. Ask for what you do not know; do not answer as if you have owned a roadmap. The question needs no claim about your past, so the guidance makes none | Covers the roadmap and discovery responsibilities (FS2, FS7). CASE because it is a live problem; `[generic]` because it is a pattern, not a fact about this employer |
| A2 | "Partner API adoption has been flat for two quarters. Diagnose it." | CASE | [generic] | Start by asking how adoption is defined and measured here, then split partners into segments, look for where they stall, state hypotheses, say what data would separate them, and name what you would do first. No claim about your past is needed | The adoption-metrics line (FS9) as a live problem; `[generic]` because the metric definition is exactly what the posting leaves unknown |
| A3 | "Two squads want conflicting API changes this quarter, and a partner is waiting on one. How do you decide?" | CASE | [generic] | First ask who decides, since the posting does not say. Then name your principles (partner impact, cost, reversibility, who is blocked), who you would consult, and when you would escalate. Answer as how you would approach it. Do not answer as if you have set a squad's priorities; if pressed, the plain acknowledgment is "I haven't set prioritization for an engineering squad" (`prohibited_claims`) | Squad authority is the open question in the posting (FS8); it is likely to be tested as a scenario. CASE because it is hypothetical |
| A4 | "A partner tells us our API docs are why their integration is late. How do you find out if that is true?" | CASE | [generic] | Structure it: restate the claim, get the partner's specifics, separate documentation, schema and environment causes, check with engineering and support, decide what is a fix and what is a message. No claim about your past is needed. If you use your own integration work as an example, it is EXP, so stay at V1's scope | Technical fluency (FS4) through a situation; CASE with a JD source |
| A5 | "What would you want to measure to know the partner platform is healthy — and what would you not trust?" | JD | [generic] | Say which behavior you are trying to observe (partners starting, finishing and staying), choose a few measures with a reason each, and name one you distrust and why. Say what baseline you would need before trusting any trend | The adoption-metrics line (FS9); JD because the posting names it, with `[generic]` content |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; "Wrote the internal integration playbook her team uses". Plain acknowledgments sourced by `prohibited_claims` and `uncertain_or_weak_areas` (acknowledge_gap) | The highest-ROI rehearsal in this pack, and the underwriter named this objection. (1) Name the limit first, before you are asked: "I haven't held the product manager title and I haven't owned a roadmap." (2) Bridge, positioned as adjacent and never as PM experience: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I ran quarterly roadmap-input sessions feeding client evidence to product." (3) The sessions carry limited inspectable proof, so say plainly, in your own words, what you can and cannot show of them; the playbook is the inspectable piece, so offer to walk through it. (4) Say what you did and let them draw the inference; do not say it makes you better than a three-year PM. (5) Ramp plan, said as a plan: what you would learn first is which decisions are yours and which are the squad leads', and how adoption is measured and from what baseline; add your own first steps. Follow-up 1, "What would a three-year PM do better in quarter one?": hold the bridge, concede the specific gaps (roadmap ownership, prioritizing with squads, no seat track record), invent nothing. Follow-up 2, "And if the squad leads push back on your priorities?": "I haven't set prioritization for an engineering squad" (`prohibited_claims`), then how you would work out the authority with them. Follow-up 3, "What would make you the wrong hire?": hold-then-concede: if the seat needs someone who can own prioritization from day one with no ramp, you are not that today | The most predictable objection, named by the underwriter from your confirmed evidence, so it gets the most follow-up levels and the exact concession wording; JD because it scores the 3+ years requirement (FS1, FS2) |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Plain acknowledgment sourced by `uncertain_or_weak_areas` (acknowledge_gap) | Pick the one your material actually shows: roadmap ownership and prioritization authority. Say it plainly ("I haven't owned a roadmap"), then the ramp plan. Do not pick a gap to look humble, and do not name agile or API docs unless your slots in FS4 or FS6 say that is true | The standard Skeptic stem; picks up FS2 and keeps the candor consistent with B1 |
| B3 | "The posting asks for shipped API or platform products. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Tell V1 at its own scope, in your own words: you led the integrations, through go-live. Answer slot: the posting's "shipped API or platform products" is the probe. If any of what went live was an API or platform product rather than a client integration, say which and what part was yours; if all of it was client integrations, say so plainly and stay with them. Do not call a client integration a product you shipped | A must_have requirement (FS3) with no underwriter strategy; JD because it scores a stated requirement |
| B4 | "Which of engineering, sales and customers have you had to align on a decision, and how?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | An open prompt: choose one instance. The quote carries the client side only. Answer slot: the posting lists engineering and sales, so expect a probe on each. If you aligned engineers or sales on a decision, say who and what was decided and what part was yours; if you did not, say so plainly and stay with the client side. If no instance comes to mind, say so, then say how you would approach it | The stakeholder requirement (FS5); JD because the posting names all three groups |
| B5 | "Why this move, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Motivation is yours to say, not the pack's. Answer slot: if something specific in your integration or roadmap-input work pulled you toward product, name it in your own words and keep it at the sessions' scope; if nothing specific did, say so plainly and say what draws you to a platform role of this scope. Keep it consistent with B1 | A standard Skeptic probe on motivation consistency; JD because it tests fit for this specific role (FS1) |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30-plus integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped: the integrations, that you led them, and the five stages the quote lists; tell them in your own words. Defend-the-number slots: how the count was made; what it is sensitive to; the assumption behind it you would defend least, named before they ask; which part was yours. If you do not know how it was counted, say so plainly | The one headline figure in the confirmed evidence (FS1) is where a prober starts; EXP because it tests attribution |
| C2 | "Tell me about the integration playbook — what is in it and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Story-mapped: you wrote it and your team uses it, at exactly that scope; do not widen "your team" to the organization. It is your inspectable artifact, so offer to walk through it end to end. Describe what it covers in your own words | The inspectable piece of evidence (FS4); EXP because it tests what you wrote |
| C3 | "Walk me through one of the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped: you ran quarterly sessions and client evidence went to product. This claim is confirmed with limited inspectable proof, so volunteer the limit before it is extracted: say plainly what you can and cannot show. Answer slot: the posting's roadmap line makes a probe on what came of the sessions likely. If you know what product did with the evidence, say so in your own words; if you do not know, or nothing came of it, say so plainly and stay with the sessions you ran | The medium-confidence claim; the dossier says to expect a probe (FS1, FS7) |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each only what its quote says: the integrations you led, the playbook you wrote, the sessions you ran. The order, dates and the turn toward product are yours to supply; the material gives none of them. Close on why this role, in your own words | Most hiring-manager conversations open here; EXP because it checks the story is consistent with the claims (FS1) |
| D2 | "How do you like to work with a squad day to day — what does a good sprint look like to you?" | JD | [generic] | No confirmed quote speaks to this. Answer slot: the posting's "Agile delivery experience" is the likely probe. If you have worked in agile delivery, say how, in your own words; if you have not worked that way, say so plainly and add what you would want to confirm about how these two squads define it | The preferred requirement (FS6) arrives casually; `[generic]` because it carries no claim about your past |
| D3 | "What drew you to Quartzline?" | CO | [generic] | No company research ran, so the pack supplies no company facts. Say what you actually know and where you learned it; if you know little, say so and say what you want to find out. Do a short read of their public site before Thursday and use only what you read | A casual question that is still scored; `[generic]` because the company research was refused |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That roadmap-input work — how much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Pause and restate. Hold the quoted position: you ran quarterly sessions that fed client evidence to product. Hold it through two follow-ups by returning to the sessions, never by adding to them. Answer slot: if any part was someone else's, or not yours alone, say which and name it specifically; if all of it was yours, say that plainly. Concede only what is true | Attribution under time pressure on the medium-confidence claim (FS1, FS7) |
| E2 | "This role owns the roadmap for the partner platform. Why isn't that a no for you?" | JD | [grounded] Plain acknowledgment sourced by `uncertain_or_weak_areas` (acknowledge_gap) and `prohibited_claims` | Pause. "I haven't owned a roadmap." Then the ramp plan, a plan and never a past. Do not fold into a claim of PM-level ownership to restore harmony, and do not argue the gap away. Hold that position through two follow-ups | The pressure delivery of the FS2 gap; JD because it scores the stated responsibility |

### F. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "The squads sit right beside you — where is the seam between what you decide and what the squad leads decide, and what happens when we disagree?" | JD | [generic] | Do not pretend to know the seam; offer principles (who owns the outcome, who is the expert, who gets blocked), propose agreeing the seam with the leads early, and say how you disagree with equals. No claim about your past is needed. If asked directly: "I haven't set prioritization for an engineering squad" (`prohibited_claims`) | The decision-authority unknown (FS8) in collegial form; JD because the posting asserts squad work |
| F2 | "What would you need from my squad in your first month, and what would you give back?" | JD | [generic] | Reciprocity: what you would ask (context, access to the right people, how decisions get made) and what you would offer. Offer the playbook as something you can share only if it is yours to share, at its own scope | A collaboration probe on FS5; `[generic]` because it makes no claim about your past |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 3+ years product management experience | B1, B2, B5, D1, E2 |
| R2 Shipped API or platform products | B3, C1 |
| R3 Technical fluency: API docs, schemas | A4, C2 |
| R4 Stakeholder management across engineering, sales, customers | B4, F1, F2 |
| R5 Agile delivery experience | D2 |
| Own the roadmap for the partner-facing API platform | A1, B1, E2 |
| Run discovery with integration partners | A1, C3 |
| Write specs and drive delivery with two engineering squads | A3, F1 |
| Define and track adoption metrics | A2, A5 |

## Reverse questions

Each is interview-ready, and each also answers something you need to know before accepting.

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The posting asserts authority over two squads but shows none; the answer tells you what the seat is, and it reads as diligence |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The posting names adoption metrics as a responsibility and states no baseline; it also tests whether you would own a measure that already exists |
| 3 | "What would you want to see from this person at thirty, sixty and ninety days?" | It turns your ramp plan from B1 into shared expectations, so the gap becomes a plan the interviewer helped write |
| 4 | "How do the two squads split ownership of the platform today, and where does the split cause friction?" | It tests the seam (F1) from the other side and shows you are thinking about the squads, not just the title |
| 5 | "Where does partner feedback reach the roadmap today?" | It lets you connect your own roadmap-input work only if you choose to, and it shows what discovery looks like here |
| 6 | "What would the strongest candidate for this seat have that you have not found in the people you have seen?" | It surfaces how much weight the title carries before you accept, and it invites a candid answer |

## Prohibited claims

Built before the question banks. Sourced entries come from the dossier's `prohibited_claims`.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | `prohibited_claims`, dossier | FS1's quote at its own scope. Plain acknowledgment: "I haven't held the product manager title." |
| Having owned a product roadmap | `prohibited_claims`, dossier; also an `acknowledge_gap` area in `uncertain_or_weak_areas` | The plain acknowledgment: "I haven't owned a roadmap." Then a ramp plan. No bridge, no slot |
| Having set prioritization for an engineering squad | `prohibited_claims`, dossier | The plain acknowledgment: "I haven't set prioritization for an engineering squad." Then how you would work out authority with the leads |
| Shipped an API or platform product | Inflated form of FS3 | FS3's quote at its own scope: integrations you led, through go-live. The limit is the pack's observation: the material says client integrations, not a shipped product. B3's slot stays inside that scope |
| Set or shaped the product roadmap | Inflated form of FS1 and FS7 | The quote at its own scope: you ran sessions that fed client evidence to product. The limit is the pack's observation: the material says input, not ownership. C3's slot stays inside the sessions |
| Directed engineers or ran engineering delivery | Inflated form of FS8 | The quote at its own scope: you led integrations. The limit is the pack's observation: the material does not say engineers were directed. FS8's slot stays inside the requirements you wrote |
| The playbook is used across the organization | Inflated form of V2 | The quote at its own scope: your team uses it. C2's guidance keeps to that scope |

## Sources

**Provided documents:** tuesday-dossier.md (dossier_version 1.1, generated by job-underwriter, 2026-08-14). Consumed: role_profile (the JD equivalent) and handoff_to_mock_interview (verified evidence, weak areas and strategies, the named objection, risks and employer questions, prohibited claims). decision was read as context only. The dossier carries no evidence_map, evidence_state or risk_register, so no gap grades beyond the three listed areas came from it; the grades on FS3, FS4, FS5, FS7, FS8 and FS9 are this pack's own derivation.

**Searches sent (all refused, nothing came back):**
- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline strategy partner API platform news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Search was refused. It would have produced the values cheat sheet if a values-style round is documented, and VAL questions by published value name |
| 2. `Quartzline interview process product manager` | unavailable | Search was refused. It would have checked loop structure and could have reweighted personas |
| 3. `Quartzline strategy` / recent news | unavailable | Search was refused. It would have grounded D3 and added a strategy-based CO or CASE question; those stay `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile supplies the requirement text, which fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access (the three searches were refused) → values, loop structure and strategy, so D3 and the CO/CASE content become `[grounded]`; a further deeper pass of up to 6 more searches and 2 more fetches, several more minutes, is available on request
- The hiring manager's name → an interviewer read, reweighted personas and a reverse question tied to their own path
- The recruiter's prep email (focus areas, any deliverable) → coverage of anything pre-declared
- The length of your integration work (the dossier's decision text mentions a duration, but no verified entry carries one) → FS1's bridge and D1's arc can state it in your words
- How the 30+ count was made → C1's slots can be filled and rehearsed
- A session agenda or notes from one roadmap-input session, or a roadmap item that cites client evidence → V3 can move from medium toward high; C3 and E1 sharpen
- Whether you wrote or worked from API docs or schemas → FS4 and A4 move from discovery
- Any shipped API or platform product, engineering or sales alignment, agile delivery, or adoption measures you have worked with → FS3, FS5, FS6 and FS9 (B3, B4, D2, A2 and A5) become story-mapped instead of answer slots
