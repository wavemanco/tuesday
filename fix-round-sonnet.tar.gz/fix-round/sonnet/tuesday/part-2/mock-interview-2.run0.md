Web search was denied, so the pack rests on your JD and background alone. I'm writing it now.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-2-denied-9f4378ab/Atlas-Freight_operations-manager_interview_pack.md`. It has 22 questions, a fit snapshot against each JD line, a list of claims it won't coach, and reverse questions.

I built it for an unknown round with equal persona weights, since you didn't say who is interviewing you. My three web searches were refused, so nothing in it is researched about Atlas Freight. The company-knowledge question (E3) is generic and there is no values cheat sheet. The pack draws only on your JD lines and background.

- **Likeliest objection (A1):** you currently lead 3 supervisors and the role has 12 across 4 sites, and your material doesn't show terminal operations. A1 and its follow-ups are the pack's top rehearsal.
- **Power BI:** you've never used it, so the pack coaches a plain acknowledgment plus a learning plan, never a claim.
- **The 40% mis-pick figure:** B1 and C2 rehearse how it was counted and which part was yours. Mis-pick rate isn't on-time or cost-per-shipment, so the pack doesn't stretch it to cover those.
- **Seven years versus "5+ years leadership":** your seven years are operations, and I couldn't tell how many were leadership. Have those dates ready for A3.

Say the word and I'll play the Skeptic on A1 with live follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document.

Who is interviewing you, and in what round (future manager, a peer, a recruiter, a panel), and has the recruiter said anything about focus areas or a take-home? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas-Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Round type and relationship: not known, so persona weights are flat (see the persona table). Built from the JD lines and background you gave; nothing about Atlas Freight was researched (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script. An answer slot is an instruction for the interview: answer whichever branch is true for you, in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values the company publishes, not generic virtue |
| EXP | Whether the claims on your CV survive scrutiny, and what was actually you |
| JD | The stated responsibilities and qualifications, including the gaps |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

Labels: grounded means traceable to something you or the JD said; inferred means derived from that, with the derivation named; generic means a role-family pattern with no claim about you or Atlas Freight.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution operations and a surge plan for the site, not terminal operations or four sites, and the words stay at that scope: "I have seven years in warehouse and distribution operations, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on how many sites you covered likely. If your responsibility has covered more than one site, say which and what you decided, in your own words; if it has not, or it was not yours, say so plainly and stay with the surge plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | Mis-pick rate is a different measure from on-time performance or cost-per-shipment, so the bridge stays at the quote: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost per shipment at your site, say which measures and how they were counted, in your own words; if you did not, or it was not yours, say so plainly and say what you would measure first |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says three supervisors and the JD says twelve; that is the pack's observation, not words for you. Say it as it stands: "I'm a senior shift manager over three supervisors." Answer slot: if you have overseen supervisors in any other setting or number, say where and how many; if you have not, say so plainly and stay with the three |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" touches the requirement without showing that you built reporting others used. Answer slot: if you built reports, say what each showed and who read it, in your own words; if you used Excel for your own analysis and not for reporting, or it was not yours, say so plainly and stay with what you did in Excel |
| F5 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. The JD lists Excel and Power BI together, so F4 carries part of this requirement; whether both are expected is a question for the recruiter |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | medium | [inferred] | discovery | Seven years is operations, and the quote does not say how many were leadership, so the pack claims only the seven years. A length-of-experience requirement is not a gate. Answer slot: if part of the seven years was in a lead or manager role, say how many years, in your own words; if only your current role was, say so plainly and stay with the seven years in operations |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification with nothing inspected behind it, so expect a probe on application. Say it in the quote's own terms: "I'm green belt certified." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the gaps: scale, terminal background, Power BI | Equal weight, plus one extra question. Round type and interviewer are unknown, so no relationship prior applies; F3, F5 and F6 are the thinnest rows, so the pack's deepest rehearsal sits here | Rehearse A1 until it is boring; bridges only from the quotes in the fit snapshot; a ramp plan stated as a plan |
| Data-Driven Prober (B) | Line-by-line on the CV and on the metrics the JD names | Equal weight. The JD names on-time performance, cost-per-shipment and reporting, and F2 and F4 are thin | Know what you can and cannot say about how the 40% was counted; say plainly where you do not know |
| Pressure (C) | Time-boxed, interrupting, tests composure | Equal weight. No signal either way | Pause, restate, hold the quoted claim through two follow-ups |
| Case / Strategist (D) | Live operations problems | Equal weight. The JD's own lines on on-time performance, cost and four sites invite them | Clarify, objective, segment, approach, metrics, risks; think aloud |
| Values / Behavioral (E) | Scenario probes, plus company knowledge | Equal weight. No published values were obtained, so these questions are themed from the personas' standard stems, not from Atlas Freight's values | Selection scaffolds ending in the honest branch |
| Conversational (G) | Friendly, unstructured, still scored | Equal weight. A recruiter screen would raise it, and no round type is known | A 90-second arc built only from your own sentences |
| Peer Evaluator (H) | Seam-splitting between sites and teams | Equal weight. Four sites implies adjacent managers, but whether a peer interviews you is not known | Reciprocity framing; seam principles, not a pretended seam |

## Question banks

Highest-ROI prep in this pack: A1 and its follow-ups. F3 (three supervisors against twelve) with F1 (four sites) is where the material is thinnest against the JD's headline duties, so this objection will arrive in some form.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "never used Power BI" | The deepest rehearsal here. Choose the gap you can speak to most honestly and name it first, at the quote's scope: "I'm a senior shift manager over three supervisors." or "I haven't used Power BI." Follow-up one, "Why does that prepare you for the full team": hold to the quote and add nothing to it. Answer slot: if you have overseen supervisors in any other setting or number, say where and how many; if you have not, say so plainly and stay with the three. Follow-up two, "Which site would you struggle with": answer slot: if any of your work has touched more than one site, say which; if none has, say so plainly. Close each answer with a first step you would take, said as a plan and never as a past, with the timeframe you would actually commit to | F3 and F5 are the clearest named gaps and F1 adds the four-site scope, so this is the likeliest probe; JD because it scores the stated duties | 
| A2 | "Your background is warehouse and distribution. This job is terminal operations. How does one carry over to the other?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running" | Start at the quotes: "I have seven years in warehouse and distribution operations, and I ran the site's peak-season surge plan two years running." Answer slot: the JD says terminal operations, so expect a probe on what in your work touched terminal operations as the JD uses the term. If anything did, say what and how, in your own words; if nothing did, or it was not yours, say so plainly and return to the seven years and the surge plan | F1 is the evidence and the requirement's scope is wider than it; JD because it scores the stated responsibility | 
| A3 | "Five-plus years of operations leadership is required. How many of your seven years were leadership?" | JD | [inferred] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: give the dates or years when you first led others and when you became a shift manager, in your own words; this pack does not hold them. If the leadership years come to fewer than five, say the number plainly and return to the seven years in operations and the role you hold now | F6 is open on how many of the years were leadership; JD because it checks a stated requirement | 
| A4 | "The role builds reporting in Excel and Power BI. You haven't used Power BI. How do you get there?" | JD | [grounded] "never used Power BI"; "solid Excel" | Acknowledge it first and briefly: "I haven't used Power BI." Then the plan, said as a plan: what you would do first and by when, in your own words; the pack names no course or timeline for you. Anchor on what you do have: "I'm solid in Excel." Answer slot: if you built reporting in Excel that others used, say what it showed; if you did not, say so plainly | F5 is a stated gap and F4 is the part of the requirement the quote touches; JD because it scores a named tool | 

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Start from the quote: "I cut the mis-pick rate 40% by redesigning the pick path." Four answer slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before the interviewer does | F2 holds the only metric on the CV; every headline number is a target for probes; EXP because it tests whether the number survives | 
| B2 | "On-time performance and cost-per-shipment are the scorecard here. What did you track at your site?" | JD | [inferred] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Answer slot: if you tracked on-time performance or cost per shipment, say which measures and how they were counted, in your own words; if you did not, or it was not yours, say so plainly and say what you would measure first. Then return to the quotes at their own scope: "I cut the mis-pick rate 40% by redesigning the pick path." | F2 is thin on the JD's two named measures; JD because it scores the stated duty | 
| B3 | "Describe a report you built in Excel and who used it." | JD | [inferred] "solid Excel" | The quote supports only this: "I'm solid in Excel." Answer slot: if you built reports, say what each showed, who read it and what changed because of it, in your own words; if you used Excel for your own analysis and not for reporting, or it was not yours, say so plainly and stay with what you did in Excel | F4 is the JD's reporting requirement against a vague quote; JD because it scores the tool | 

### C. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over a candidate who already runs terminal operations?" | JD | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | Pause and restate. Say only what the quotes carry: "I ran the site's peak-season surge plan two years running. I cut the mis-pick rate 40% by redesigning the pick path. I'm green belt certified." Hold through two follow-ups by returning to those sentences, never by adding to them. Answer slot: if pressed on terminal experience, and you have worked in a terminal, say where and what you did; if not, say so plainly and return to the surge plan | F1 is the scope gap this probe aims at; JD because it scores fit to the stated role | 
| C2 | "Peak season: how much of that surge plan was actually you?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Hold the quoted claim: "I ran the site's peak-season surge plan two years running." Answer slot: say which decisions in the plan were yours and which were set by someone else, in your own words; if the plan was set elsewhere and you ran it, say so plainly. Concede only exactly what you did not decide, and do not fold on what you ran | F1's surge-plan quote is attribution-sensitive; EXP because it tests what was the candidate's | 
| C3 | "Lean and Six Sigma is a plus. Why should I care about a certificate?" | JD | [grounded] "green belt certified" | State it at its scope: "I'm green belt certified." Answer slot: if you have applied the training to any work, say what and with which tools, in your own words; if you have not, or not on work you can describe, say so plainly, stay with the certification, and say how you would use it here, as a plan. Do not get defensive; a short, calm answer beats a long one | F7 is a certification with nothing inspected; JD because it scores a named plus | 

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "On-time performance at one of the four sites has slipped for three weeks. You're the new Operations Manager. What do you need to know first, and how do you diagnose it?" | CASE | [generic] | Clarify first: what changed, which lanes and shifts, how on-time is defined. Then objective, segmentation, approach, metrics, risks, thinking aloud, and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's on-time line (F2's requirement); generic because it is a pattern for the problem | 
| D2 | "Peak season starts in six weeks and volume is forecast well above last year across all four sites. Sketch the plan." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure it: what you need to know, the capacity and labour levers, the sequence, the metrics, the risks. You may point once to your own experience at the quote's scope: "I ran the site's peak-season surge plan two years running." Answer slot: if any part of that plan is one you would reuse, say what and why, in your own words; if none is, say so plainly. Do not describe what the plan contained unless you say it from your own memory | F1's surge-plan quote is the nearest evidence for the JD's four-site scope; CASE because it is asked as a live problem | 
| D3 | "Cost-per-shipment is above target and on-time performance is below target. Leadership will fund one fix this quarter. How do you choose?" | CASE | [generic] | Clarify what the two measures include, set the objective, segment where each gap sits, weigh the options on effect and time to effect, and name the risk of the option you drop. Make no claim about your past | F2's two named measures together; generic because it is a pattern for the problem | 

### E. Values / Behavioral

No values were researched and no loop source names a values round, so these use the standard persona stems and make no claim about Atlas Freight's values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard stem; no quoted sentence of yours carries this story | 
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two pulled apart, say what you chose and what it cost the metric. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard stem; no quoted sentence of yours carries this story | 
| E3 | "What do you know about Atlas Freight, and why us?" | CO | [generic] | The pack holds nothing researched about Atlas Freight. Read their site, their careers page and recent news before the interview, and say only what you read. You may open from the JD's own description, "regional logistics, 800 employees", and its scope of "4 sites". Then give your own reason for wanting the role | CO question with no strategy research behind it, so it is generic by the pack's own degradation | 

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc whose beats are the clauses your sentences state: seven years in warehouse and distribution operations, a senior shift manager over three supervisors now, the mis-pick reduction from redesigning the pick path, the surge plan two years running, the green belt. Put them in whatever order is true. Answer slot: close with why this role, in your own words | F1, F3 and F7 are the spine of the story; EXP because the biography question is scored on economy and accuracy | 
| G2 | "What are you actually playing with in Lean and Six Sigma these days?" | JD | [grounded] "green belt certified" | Answer slot: if you are applying it right now, say what, in your own words; if nothing is active, or you hold only the certification, say so plainly and stay with "I'm green belt certified." Casual register, still scored | F7 is the JD's named plus, asked casually; JD because it scores the plus | 
| G3 | "What made you look at this role?" | JD | [generic] | Pick your honest reason and tie it to the JD's own lines: "Own daily terminal operations across 4 sites" and "lead a team of 12 supervisors". Say it as a direction you want, not as experience you have | Motivation consistency is scored in a friendly register; generic because the guidance makes no claim about your past | 

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Four sites share one network. A peer manager asks you to lend people at their busiest hour, and your own site is behind. What do you do?" | CASE | [generic] | Reciprocity framing: what you would ask, what you would offer back, and the principle you would use to decide between the sites. Propose seam principles and do not pretend to know the seam. The question needs no claim about your past | F1's four-site scope makes cross-site trade-offs likely; generic because it is a pattern for the problem | 
| H2 | "Tell me about the last time a peer disagreed with how you were running your area." | VAL | [generic] | Selection scaffold: pick a disagreement with an equal, where you held your view and kept the relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer-persona stem; no quoted sentence of yours carries this story | 
| H3 | "The role has twelve supervisors across four sites. How would you run your first month with them?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Structure it as a plan: who you would meet, what you would listen for, what you would not change yet. Answer slot: if there is a routine you use with your three supervisors that you would carry over, name it in your own words; if there is none, say so plainly and describe how you would set one | F3 is the requirement; JD because it scores the stated lead-twelve duty | 

## Requirement coverage

| Requirement | Fit row | Questions |
|---|---|---|
| Own daily terminal operations across 4 sites | F1 | A2, C1, D2, H1 |
| Drive on-time performance and cost-per-shipment down | F2 | B2, D1, D3 |
| Lead a team of 12 supervisors | F3 | A1, H3 |
| Build reporting in Excel/Power BI | F4, F5 | A4, B3 |
| 5+ years operations leadership | F6 | A3 |
| Lean/Six Sigma a plus | F7 | C3, G2 |
| The 40% mis-pick figure (headline metric) | F2 | B1 |

## Reverse questions

No interviewer profile exists, so these are role-generic.

| Question | Why it lands |
|---|---|
| "Which of the four sites is closest to its targets and which is furthest, and what explains the difference?" | It shows you think site by site against the JD's on-time and cost lines |
| "How is cost-per-shipment defined here, and who owns the number?" | Pinning the definition mirrors how you would defend your own number |
| "What do the twelve supervisors most need from this role in the first ninety days?" | It starts from the team the JD asks you to lead |
| "What reporting exists today in Excel and Power BI, and what is missing?" | It meets the Power BI gap openly by asking about the current state |
| "What would make you say in six months that this hire was right?" | It asks for the interviewer's own success measure, not a generic one |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran or owned terminal operations across several sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says warehouse and distribution operations and the site's surge plan, not terminals or four sites. A2's slot stays inside what you did |
| Led a team of twelve supervisors | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors". A1's slot stays inside the three |
| Improved on-time performance or cost-per-shipment | Inflated form of F2 | F2's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path". B2's slot asks only what you tracked |
| Seven years of operations leadership | Inflated form of F6 | F6's quote at its own scope: "7 years in warehouse and distribution ops". A3's slot asks only for your leadership years |
| Built reporting or dashboards that others used | Inflated form of F4 | F4's quote at its own scope: "solid Excel". B3's slot asks only what you built |
| Power BI experience of any kind | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't used Power BI." Then a plan. No slot |
| Applying Six Sigma methods to specific results | Inflated form of F7 | F7's quote at its own scope: "green belt certified". C3 and G2 slots ask only what you have applied |

## Sources

Provided documents: the JD lines in your message, and your background summary in the same message. No dossier was present. No fetches were sent.

Searches sent, all refused, so none returned a result:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Would have moved a values cheat sheet and the VAL bank; E1 and E2 use standard persona stems instead |
| 2. Atlas Freight interview process, operations roles | unavailable | Would have moved persona weights and the loop structure; weights are flat on the generic archetype |
| 3. Atlas Freight strategy and recent news | unavailable | Would have moved the CO and CASE banks; E3 is generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Operations Manager JD | skipped | The JD lines you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who is interviewing you (future manager, peer, recruiter, panel) → reweights every persona bank and adds an interviewer read
- Interviewer's name → a tailored reverse question and persona weights from their public footprint
- Anything the recruiter told you about focus areas, or a take-home → coverage of any pre-declared deliverable
- Atlas Freight's values or careers page pasted, or permission to run web search → a values cheat sheet if a values round is documented, grounded CO questions, and a loop structure in place of the generic archetype
- Your answers to the slots in A1, A2, A3, A4, B2 and B3 → they upgrade rows F1, F2, F3, F4 and F6 from discovery or transferability to quoted evidence
- Your CV text → more of your own sentences to quote, which turns selection scaffolds into story-mapped answers
- The green belt certificate and the figures behind the 40% → F7 and the B1 slots rise from medium toward high
- Hours you can spend before the interview → a prep triage sized to that time
- An earlier role analysis saved as tuesday-dossier.md → verified evidence and prohibited claims in place of the ones inferred here; never a precondition
