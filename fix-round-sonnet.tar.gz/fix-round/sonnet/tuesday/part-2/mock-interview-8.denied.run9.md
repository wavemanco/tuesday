Your prep pack is built and saved. Since you have three rounds on 20 November, I made it a loop pack: one shared fit snapshot, then a separate bank for each round. It's saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-denied-04010823/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

- **What it's built from:** your pasted JD, values, recruiter email and strategy points, plus your background in your own words. I ran no web searches, because those inputs already covered everything a search would have added. There was no CV, so every line about you is quoted from your message.
- **Round 1 (recruiter):** 8 questions, mostly friendly screening with a light Skeptic edge.
- **Round 2 (Head of Member Services):** 11 questions, weighted to behavioural and Skeptic.
- **Round 3 (panel):** 12 questions, split between the four values and the 20-minute escalation case. It includes a cheat sheet for the four values.
- **Highest-ROI prep:** R2-B1. It's the contact-centre question, aimed at the gap you stated yourself, and your future manager would be the one asking. Presenting above regional level is the second gap, covered in R2-B2.
- **Where your material is thin:** your sentences don't cover whether the complaints log was regulated, what the spreadsheet tracked, whether it was Excel, or any digital-team work. Those cells are answer slots for you to fill truthfully, not wording I wrote for you.
- **Case practice:** the practice cases are stand-ins, since the real case is unknown.
- **No interviewer read:** names aren't assigned yet.

Say the word and I'll play the Skeptic on R2-B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview pack for Dara

Loop mode: three rounds on 20 November 2026. Built 11 November 2026 from the JD, the four published values you pasted, the recruiter's email, the July 2026 strategy points you gave me, and your background in your own words. No CV was supplied, so every candidate sentence below is quoted from your message.

| Round | Who | Length and format | Source |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | The recruiter's email |
| 2 | The Head of Member Services, who would be your manager | 45 minutes, mostly behavioural | The recruiter's email |
| 3 | A panel of two branch managers, names not yet assigned | 60 minutes, including a 20-minute case on a complaint escalation; also the values round, scored against the four values | The recruiter's email |

## How to use this pack, and the type key

Personas describe how a question is asked; types describe what is scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Question IDs read round, persona letter, number: R2-B1 is round 2, Skeptic, first question. Persona letters: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Peer Evaluator, P Data-Driven Prober.

| Type | What it tests |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether your background survives scrutiny, and what was actually yours |
| JD | The posting's stated duties and requirements, gaps included |
| CO | Whether you can think at the company's altitude: strategy, competition, recent moves |
| CASE | A live problem from the role, scored on structure and reasoning |

## Prep triage: nine days to 20 November

Sized in days, since you have not told me your hours. Do these in order; everything else is insurance.

1. Say R2-B1 aloud until it is boring. It is the highest-ROI prep in the pack: it presses on the gap you stated outright, and the person asking would be your manager.
2. Run R3-D1 to R3-D3 against a 20-minute timer, spending the first three or four minutes clarifying out loud. The case is a third of the panel hour.
3. For R3-C1 to R3-C4, find one real story of your own per value. The pack supplies none; where none comes to mind, rehearse the honest branch in the cell.
4. Say R2-B2 and R3-D3 in 60 seconds each, in plain words. That is your rehearsal for senior leaders.
5. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | Years are covered, but nothing is inspected behind the line, so expect a probe on what the six years were. Lead with it in its own terms: six years in retail banking, the last three as a branch supervisor. Do not relabel it as customer operations unless the interviewer does |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The quote says a formal log, and the material does not show what governed it. Words: "I handled the branch's formal complaints log." Answer slot: the JD's regulated-complaints line makes a probe on what the log was kept to likely. If it was kept to an outside standard you can name, say which and what it asked of you; if it was an internal log, or you are not sure what governed it, say so plainly and stay with the log |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says what you built and who uses it, not what it tracked. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on what the sheet tracked. If you can say, say it in your own words; if it tracked something else, or you cannot say, say so plainly and stay with the spreadsheet |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Inferred from spreadsheet to Excel; the quote says spreadsheet, and the pack does not assume the tool. Answer slot: if it was built in Excel, say so and say what you did in it; if it was another tool, say so plainly and say what you have used |
| F5 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then a plan, said as a plan and never as a past. Answer slot: if you have presented at regional level, say to whom and about what; if not, say so plainly |
| F6 | "Own the member complaints process end to end across branches and the contact centre" — JD (the branches part) | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | The quote is one branch's log. Words: "I handled the branch's formal complaints log." The pack's observation: your material says one branch, not the process across branches. Answer slot: if your handling of the log reached beyond your own branch, say how; if it did not, say so plainly and stay with the log |
| F7 | "Own the member complaints process end to end across branches and the contact centre" — JD (the contact centre part) | "Never worked in a contact centre" — your message | none | [grounded] | capability | A stated gap. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The quote is training new tellers, not coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if any of that training reached supervisors, say how; if it did not, say so plainly and stay with the tellers |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | The material is silent. Answer slot: if you have worked with a digital team or on a self-service journey, say what and which part was yours; if not, say so plainly and say what you would ask a digital team first |

## Grounding brief

You gave me four points from the July 2026 strategy brief the recruiter sent; I have not seen the brief's full text.

| Point | What it says | Where it surfaces | Provenance |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | R1-A2, R3-D4 | [grounded] |
| Hubs | Consolidate eight branches into five hubs over 2027 | R1-A2, R3-D4 | [grounded] |
| New product | Launch a small-business lending product in Q1 2027 | R1-A2 | [grounded] |
| Competition | The main competitive pressure is app-only banks | R1-A2 | [grounded] |

## Persona table

Numbers are questions in that round's bank. The reasoning is shown so you can recalibrate if you know something I don't.

| Persona | R1 | R2 | R3 | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| A Conversational | 5 | 0 | 0 | A 30-minute call with the recruiter, per the email [grounded]. Recruiter screens tilt friendly with logistics and motivation checks [generic] | Pre-script a 90-second arc; treat casual questions about the JD's hot topics as scored |
| B Skeptic | 3 | 3 | 2 | Your own message names two gaps, the contact centre and presenting above regional level [grounded]. The R2 interviewer would be your manager and the email says R2 is mostly behavioural [grounded]. Managers derisk gaps [generic] | Rehearse the single most predictable objection until it is boring; concede only what you stated; plan, not past |
| C Values/Behavioral | 0 | 4 | 4 | The email says R2 is mostly behavioural and R3 is the values round, scored against four values [grounded] | Map a story to each value where your own sentences carry one; where none does, use the scaffold and its honest branch |
| D Case/Strategist | 0 | 2 | 4 | R3 includes a 20-minute case on a complaint escalation [grounded]. The practice cases are invented stand-ins; the real one is unknown | Clarify, objective, segmentation, approach, metrics, risks, aloud; challenge one premise respectfully |
| E Peer Evaluator | 0 | 0 | 2 | R3 is two branch managers; the role coaches branch supervisors [grounded]. That they work alongside the role is inferred from the JD's coaching line | Reciprocity: what you bring them, not only what you need; propose seam principles, not a seam you cannot know |
| P Data-Driven Prober | 0 | 2 | 0 | You built the monthly complaints spreadsheet, which gives a prober something to read line by line [grounded] | Say plainly what you can and cannot say about what the sheet tracked |

## Round 1 mini-pack: the recruiter, 30 minutes

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "So, walk me through the journey. How did you get to where you are, and why this role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log and trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in three beats. Beat one is the first sentence's own: six years in retail banking, the last three as a branch supervisor. Beat two is the complaints log you handled, the new tellers you trained on the escalation script, and the monthly spreadsheet you built that your regional manager uses. Beat three is yours. Answer slot: say in your own words what drew you to this role; the JD's lines on owning complaints and coaching supervisors are the likely hooks, and if your reason is something else, say that | F1 carries the years requirement, and this is the first chance to say it. EXP because it sets out the claims F2, F3 and F8 later probe |
| R1-A2 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Four points are in hand from the brief: 40% of member service to digital by 2028, eight branches into five hubs over 2027, a small-business lending product in Q1 2027, and app-only banks as the main competitive pressure. Pick the two nearest complaints and say in your own words what you would want to know about each. Do not recite all four; the recruiter sent you the same brief | The recruiter chose to send the brief, which makes it fair game from the first call. CO because it tests homework depth |
| R1-A3 | "What are you actually looking at in digital self-service these days?" | JD | [grounded] | Nothing in your material reaches digital work, so this is an answer slot. If you have worked with a digital team or on a self-service journey, say what and which part was yours; if you have not, say so plainly and say what you would ask a digital team first | F9 has the least behind it, and the brief's 40% digital target makes it likely to come up early. JD because it scores the posting's digital line |
| R1-A4 | "Which part of this role are you most looking forward to?" | JD | [grounded] | Choose one of the posting's four duties, owning the complaints process, monthly reporting, coaching supervisors or digital self-service, and say why in your own words. Prefer one your material carries (F2, F3 or F8) over the one that sounds biggest | Casual in register but scored for real interest and for choosing a duty you can back. F2, F3 and F8 are the rows it draws on |
| R1-A5 | "What are your salary expectations and notice period?" | JD | [generic] | The pack supplies no figures. Answer slot: state your range and your notice period in your own words; if you have not settled the range, say what you would need to know about the package first | A logistics check that fits a recruiter screen. JD because the supplied JD states no pay terms |
| R1-B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Name the gap yourself before it is found. Lead with one: "I haven't worked in a contact centre", or "I've never presented to anyone above regional level". Then a plan in your own words: what you would learn first, from whom, and by when. The plan is yours to fill; it is a plan, not a past | F7 and F5 are the two rows where you stated the gap. Saying them here means R2-B1 and R2-B2 are not the first time you say them aloud |
| R1-B2 | "You're a branch supervisor today. Why move away from the branch?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | The sentence's beats are six years in retail banking, the last three as a branch supervisor. Why you are moving is yours. Answer slot: say in your own words what you want from this role that the branch role does not give you; do not run the branch down | Motivation-consistency probe; F1 is the background it tests |
| R1-B3 | "Why Ashgrove, and why now?" | VAL | [grounded] | Pick the one published value that is genuinely yours: Members First, Always; Plain Words; Neighbours, Not Numbers; or Own the Fix. Say why in your own words. If the reason is the brief, the digital move or the hubs, say that. Do not claim a value you have not lived; round 3 scores all four | Motivation consistency, themed on the published values. VAL because it tests whether your reason matches what Ashgrove says it stands for |

### Round 1 reverse questions

| Question | Why it lands |
|---|---|
| "Is the 20-minute case given in advance or live, and is there anything I should bring?" | It tells you whether R3-D1 to R3-D3 is prepared or cold, and shows you are planning the round |
| "How does the panel weigh the four values against the case?" | It sets your split of prep time between R3-C and R3-D |
| "Who will be on the panel, and in what roles?" | Names unlock a tailored interviewer read; asking the recruiter costs one email |
| "Where does this role sit between the branches, the contact centre and the digital teams?" | It shows you read the role as spanning three groups, and the answer sizes F7 and F9 |
| "What would the first month look like?" | A practical question that lets the recruiter describe the job as they see it |

## Round 2 mini-pack: the Head of Member Services, 45 minutes

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "This role owns complaints across the branches and the contact centre, and you've never worked in a contact centre. How do you get to owning that?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | The highest-ROI prep in this pack. Concede first and exactly: "I haven't worked in a contact centre." Then hold only what the quote carries: "I handled the branch's formal complaints log." The limit, named before it is asked for, is the pack's observation: your material says one branch's log, not the process across branches or the contact centre, so do not stretch the log to cover them. Follow-up one, what would be hardest. Answer slot: say in your own words what you would need to learn and from whom; a plan, not a past. Follow-up two, why trust a branch person with the contact centre. Answer slot: if any of your log work touched calls or other channels, say how; if it did not, say so plainly, return to the log, and say what you would ask the contact-centre team first. Concede the contact centre; do not concede the log | F7 is a stated gap and F6 is thin, and this is the posting's first duty. JD because it scores that duty, with EXP in the follow-ups |
| R2-B2 | "The role presents to senior leaders. Have you presented above regional level?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses" | Say it plainly: "I've never presented to anyone above regional level." Then a plan in your own words: how you would prepare, who you would ask to review, what you would cut. Answer slot: if you have presented at regional level, say to whom and about what; if not, say so plainly. The spreadsheet quote says your regional manager uses what you built; it does not say you presented it, so do not imply that | F5 is a stated capability gap and a headline requirement, so it is asked directly. JD because it scores the posting's presenting line |
| R2-B3 | "Imagine the contact-centre team doesn't see why a branch supervisor should lead the complaints process. How do you win them over?" | CASE | [generic] | Structure it aloud. Clarify first: what they see as the problem, and listen before proposing. Objective: one process members never have to explain twice, in the pasted values' terms. Approach: start from their records and their questions, not yours. The limit is stated up front: you have not worked in a contact centre, so lead with questions. The question needs no claim about your past, so the guidance makes none | A live version of the F7 objection, asked as a problem to solve. CASE because it scores structure; generic because it is a pattern, not a fact about Ashgrove |
| R2-C1 | "Tell me about a time you coached someone through a difficult escalation." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold; the quote carries training, not a coaching story. Pick a time with a named person, a named escalation and a result you can describe without rounding it up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you trained new tellers on our escalation script, at that scope, or how you would coach a supervisor through one | F8 is the posting's coaching duty, and R2 is mostly behavioural. VAL because behaviour is what is scored |
| R2-C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Pick a time with a named truth, a named audience, the moment you did not soften it and the relationship afterwards. Choose a story at the level you have actually worked, since F5 limits what you can claim above regional level. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem that the role's reporting duty makes likely. F5 sets its limit |
| R2-C3 | "Tell me about a complaint that stayed with you. What happened, and what did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold; the quote says you handled the log, so any story is yours to supply and the pack supplies none. Choose a complaint you personally handled: what the member needed, what you did, how it ended. If no such complaint comes to mind, say so plainly, then give the log at its own scope, or how you would handle one | F2 and F6 are where your complaints work lives, and the posting's Own the Fix value is its natural theme |
| R2-C4 | "Tell me about a time you worked with a team outside your branch to get something done." | VAL | [grounded] | Selection scaffold, and your answer may feed F9. Pick a time with a named team, a named goal and what was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach working with a digital team | The posting spans branches, the contact centre and digital teams, so cross-team work is likely to be probed. VAL because it scores behaviour |
| R2-P1 | "Walk me through how the monthly complaints spreadsheet works." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The beats the sentence states: you built it, it is monthly, it is about complaints, your regional manager uses it. Answer slot: the JD asks for monthly reporting and Excel, so expect a probe on what the sheet tracked and which tool it was in. If you can say, say it in your own words; if you cannot say, or it tracked something else, say so plainly and return to: you built it and your regional manager uses it | F3 and F4 are both inferred or silent past the quote, so the probe lands here. JD because it scores the reporting and Excel lines |
| R2-P2 | "What made a complaint formal at your branch?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: the JD asks for experience handling regulated complaints, so expect a probe on what the log was kept to. If it was kept to an outside standard you can name, say which and what it asked of you; if it was an internal log, or you are not sure what governed it, say so plainly and return to: "I handled the branch's formal complaints log." | F2: the material says a formal log, not what governed it, which is the pack's observation. JD because it scores the regulated-complaints line |
| R2-D1 | "Complaint volumes in two of your branches have jumped this month. What do you do first?" | CASE | [generic] | Structure it aloud. Clarify: a jump against what, over what period, the same type or different. Objective, then segment by branch, product and channel; check whether the change is real or a change in how things are recorded; say who you would tell and when; name the measure you would watch and the risk of acting too early. Challenge one premise, for example whether two branches make a pattern. No claim about your past | A warm-up for the R3 case in a manager's frame. CASE because it scores structure |
| R2-D2 | "Where would you start on one picture of complaints across the branches and the contact centre?" | CASE | [generic] | Start by asking what each channel records today, in what form, and who owns each record. Objective: one picture a senior leader reads in plain words. Then segmentation, a first-month approach and the risk of two records disagreeing. The limit is stated up front: you have not worked in a contact centre, so begin from their records, not yours | The JD's end-to-end ownership line, asked as a live problem. It also rehearses F7 without a claim |

### Round 2 reverse questions

| Question | Why it lands |
|---|---|
| "Across branches, the contact centre and digital, where is complaint handling weakest today?" | It shows you see the three groups and lets your manager name the real problem |
| "At six months, which monthly numbers would you want to see moving?" | It ties the reporting duty to an outcome, and answers what F3 should track |
| "How do the 2027 hub changes affect who this role coaches?" | It links the strategy brief to the coaching duty |
| "Who are the senior leaders this role reports to, and what do they ask for?" | It sizes the F5 gap honestly and shows you are planning for it |
| "Which branches or supervisors would I work with first, and how do they see the role?" | It shows you take the coaching duty as a relationship |

## Round 3 mini-pack: the panel of two branch managers, 60 minutes

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | "Members First, Always. Tell us about a time you decided from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Pick a decision, who it cost, and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you handled the branch's formal complaints log, at that scope, or how you would decide | The value's own words are the theme. VAL because it scores whether your behaviour shows this value |
| R3-C2 | "Plain Words. Tell us about a time something you wrote or said had to be explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold. Pick a letter, script or explanation, what made it need a second go, and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you trained new tellers on our escalation script, at that scope, or how you would test whether something reads plain | The value's own test is that a member who needs it explained twice means it was written wrong. F8 is the nearest row |
| R3-C3 | "Neighbours, Not Numbers. Tell us about a time a branch's place in its town mattered more than what the figures said." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold. Expect the probe to press on your own spreadsheet: the value's name sits against numbers work like F3, and the pack's reading is that you will be asked how you keep a figure from hiding a place. Pick a time with a named branch or town and what you did. If no such time comes to mind, say so plainly, then give the spreadsheet at its own scope, or how you would keep the two together | The branch managers' own towns make this value likely to be probed hard. F3 is the row that creates the tension |
| R3-C4 | "Own the Fix. Tell us about a time you found a problem that wasn't yours and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold; the quote says you handled the log, which carries no fix. Pick a problem, the moment you picked it up, who else could have dropped it, and how it ended. If no such time comes to mind, say so plainly, then give the log at its own scope, or how you would keep hold of one | The value's own words are the theme. F2 and F6 are the nearest rows |
| R3-D1 | "A member is told one thing by the contact centre and another at a branch, and escalates. Walk us through what you do." | CASE | [generic] | A stand-in for the real case, which is unknown. Clarify aloud for the first three or four minutes: what the member was told by each, what they want, what has been promised, and what time limits apply under the rules you work to. Then objective, who owns it now, approach, what you tell the member and in what words, and what changes so it does not happen again. One structured answer can show all four values: decide from the member's side, say it plainly, keep hold of it until solved | The 20-minute case is a third of the hour. CASE because it scores structure; generic because the pack does not know the actual case |
| R3-D2 | "A branch supervisor thinks the member is wrong and doesn't want to escalate. How do you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | Ask first what the supervisor has seen. Separate the member's account from what the record shows. Say what you would do about recording the complaint, in your own words. You trained new tellers on an escalation script, at that scope, so describe a coaching approach as a plan, not as something you have done with supervisors | F8 is the posting's coaching duty, and branch managers manage the supervisors it names. CASE because it is a live problem |
| R3-D3 | "Pick the numbers you'd put in the first monthly report to leadership, and tell us why." | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Start with the two measures the JD names, volumes and resolution times. Say what each tells and what it hides, then add one of your own and say why. Give it in 60 seconds in plain words, as a rehearsal for senior leaders. The spreadsheet quote is context for what you built, not evidence of what it reported; do not describe more than R2-P1's slot lets you | F3 and F5 meet here: reporting, and presenting plainly. CASE because the numbers are yours to choose live |
| R3-D4 | "Ashgrove plans to move 40% of member service to digital by 2028 and consolidate eight branches into five hubs over 2027. What happens to complaints?" | CO | [grounded] | State the two moves in the brief's terms. Clarify what the 40% counts, contacts or members. Segment: members who go digital, members who stay with a hub, towns that lose a branch. Approach: a complaint journey a member never has to explain twice, which is the Plain Words test. Metrics: resolution time and volume by channel. Risk: complaints that fall between channels. Challenge one premise respectfully. No claim about your past | The differentiator question: it links the brief to complaints. The hubs plan bears on branch managers' own branches, which is inferred from the brief, so expect it to matter to this panel |
| R3-E1 | "A branch wants to settle a complaint quickly, and you want it logged and escalated. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles in your own words, not a seam you cannot know: who decides what, and when the branch and the complaints lead must share. For disagreement, pick a story that shows spine and tact together. If no such story comes to mind, say so plainly, then say how you would handle it. The one thing your material carries on the branch side is "6 years in retail banking, the last 3 as a branch supervisor" | Branch managers are likely to test the line between their branch and your role. CASE because it is a live seam problem |
| R3-E2 | "What would you need from us, and what would we get from you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" "trained new tellers on our escalation script" | What you bring, at the quotes' scope: a monthly complaints spreadsheet you built that your regional manager uses, and training you gave new tellers on an escalation script. What you need is yours. Answer slot: say in your own words what you would ask of branch managers; if you have not worked that out, say what you would find out first | Reciprocity: what the hire adds to their branches, not only what you need. F3 and F8 are the rows it draws on |
| R3-B1 | "Which of our four values would be hardest for you to show from your own experience?" | VAL | [grounded] | Pick the one where your story is thinnest after rehearsing R3-C1 to R3-C4, say so plainly, and say what you would do about it. Calibrated candor beats bluffing a value the panel is scoring | A direct self-assessment probe on the values round. VAL because it scores honesty about the fit with published values |
| R3-B2 | "You haven't worked in a contact centre and you haven't presented above regional level. Why should two branch managers back you?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" "6 years in retail banking, the last 3 as a branch supervisor" | Hold, then concede. Concede both plainly: "I haven't worked in a contact centre" and "I've never presented to anyone above regional level". Hold what your material carries: six years in retail banking, the last three as a branch supervisor. Then a plan, in your own words, for each gap. Do not add to the branch experience to outweigh the gaps | F7 and F5 returned in a panel's framing. JD because it scores the posting's requirements, gaps included |

### Values and principles cheat sheet

The values are as you pasted them, copied on 11 November 2026 from ashgrovecu.org/about/values. Every story is yours to supply; the pack supplies none.

| Value | Working meaning, paraphrased | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold for R3-C1: a decision, who it cost, what the member got; if none, say so plainly, then give the nearest thing your material does carry (F2), or how you would decide |
| Plain Words | If a member needs it explained twice, the writing was wrong | Selection scaffold for R3-C2: a letter, script or explanation and what you changed; if none, say so plainly, then give the nearest thing (F8), or how you would test it |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold for R3-C3: a named branch or town and what you did; if none, say so plainly, then give the nearest thing (F3), or how you would keep the two together |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold for R3-C4: a problem, the moment you picked it up and how it ended; if none, say so plainly, then give the nearest thing (F2), or how you would keep hold of one |

### Round 3 reverse questions

| Question | Why it lands |
|---|---|
| "When a complaint escalates from your branch today, what helps and what gets in the way?" | It asks them to describe the current process from their side, which is the side you are least placed to know |
| "What do you wish complaints leads understood about running a branch?" | It puts you in the listening role for the side of the job you will coach |
| "How are you thinking about complaints as eight branches become five hubs?" | It links the brief to their own branches and tests how far Neighbours, Not Numbers reaches |
| "Which of the four values do you see tested most in your branch week to week?" | It shows you take the values as working tools, not slogans |
| "What could a new person do in their first month that would genuinely help your branches?" | Reciprocity: it asks what you can give them |

## Requirement coverage

| JD requirement or strategy point | Question IDs |
|---|---|
| "4+ years in financial-services customer operations" | R1-A1, R1-B2 |
| "experience handling regulated complaints" | R2-P2, R2-C3 |
| "Own the member complaints process end to end across branches and the contact centre" | R2-B1, R2-B3, R2-D2, R3-D1 |
| "report monthly on complaint volumes and resolution times" | R2-P1, R3-D3 |
| "coach branch supervisors on escalations" | R2-C1, R3-D2 |
| "work with digital teams on self-service journeys" | R1-A3, R2-C4, R3-D4 |
| "confident presenting to senior leaders" | R2-B2, R2-C2, R3-D3 |
| "comfortable with Excel reporting" | R2-P1 |
| The four published values | R3-C1, R3-C2, R3-C3, R3-C4, R3-B1, R1-B3 |
| Strategy: digital shift, hubs | R1-A2, R3-D4 |

## Prohibited claims

Built from the fit snapshot before the banks were written. No bank cell, bridge or hold asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches | Inflated form of F6 | F6's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch, not the process across branches. R2-B1's slots stay inside the log |
| Has handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says a formal log, not what governed it. R2-P2's slot asks only what the log was kept to |
| Reported complaint volumes and resolution times each month | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The slots ask only what the sheet tracked |
| Coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope: "I trained new tellers on our escalation script." |
| Has presented to senior leaders | A negative you stated, F5 | The plain acknowledgment F5 gives: "I've never presented to anyone above regional level." No slot beyond regional level |
| Has worked in a contact centre | A negative you stated, F7 | The plain acknowledgment F7 gives: "I haven't worked in a contact centre." No slot |

## Sources

Provided documents: the JD as you pasted it; the four published values as you pasted them, copied from ashgrovecu.org/about/values on 11 November 2026 and not fetched; the recruiter's email on the three rounds; the four points you gave me from the July 2026 strategy brief; your background in your own words. No dossier was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Could not have moved the cheat sheet: the pasted values page, copied this morning, already supplies the four values by name |
| 2. Ashgrove interview process, member experience roles | skipped | Could not have moved the persona weights: the recruiter's email already gives three rounds, who runs each, their length and format |
| 3. Ashgrove strategy and recent news | skipped | Could not have moved the CO questions: the four points from the July 2026 brief already supply current priorities and the competitive frame |
| 4. Interviewer name and Ashgrove | n/a | No names yet, only roles, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → the quoted lines in F1 to F8 become CV lines, and the Provenance quotes can draw on more than one message. Wanted most: a redacted sample of the branch complaints log, or the monthly spreadsheet with figures removed; either is the inspectable artifact that would move F2, F3 and F4 from medium or low toward high
- Your answers to the slots in F2 (what the log was kept to), F3 and F4 (what the sheet tracked, and the tool), F6 (whether the log reached beyond your branch), F8 (whether any training reached supervisors) and F9 (any digital work) → those rows upgrade from discovery to grounded evidence, and the matching banks become story-mapped
- The full text of the July 2026 strategy brief → the grounding brief and R3-D4 sharpen from your four points to the brief's own wording
- The interviewers' names when assigned → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's answer on whether the case is given in advance, and how the panel weighs the values against the case → R3-D resizes, and prep triage re-orders
- Your hours of prep per day → the triage resizes from days to hours
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → role-family reports on how rounds like this run, recent organisational context, and a fuller strategy brief. Offered once; say the word and I will run it
- A tuesday-dossier.md from an earlier underwriting pass, if you have one → verified evidence and absolute prohibited claims replace the ones built here from your message
