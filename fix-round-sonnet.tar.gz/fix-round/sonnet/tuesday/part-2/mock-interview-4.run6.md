I'm building the prep pack now. The web searches were refused, so it uses only your dossier and says so where that limits it.
Your prep pack for the Thursday hiring-manager round is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-4-denied-d3cca6dc/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for one 45-minute conversation with the hiring manager, with the Skeptic and Case/Strategist styles weighted highest. It has 20 questions, 5 reverse questions and a prep order.

- **No company research:** web search was refused, so there is nothing on Quartzline's values, interview process or strategy. The pack has no company-strategy questions, and the case questions are generic. The Sources section lists the three refused searches.
- **A1 is your most important rehearsal:** it is the "never held the PM title or owned a roadmap" objection your dossier named. Concede it plainly, bridge to the integration work with its limit named, then give a ramp plan. Rehearse it out loud first.
- **R2 is graded by me, not the dossier:** the handoff lists "Shipped API or platform products" as a must-have but names no weak area for it. Your evidence is leading integrations of the vendor's APIs, so I treated it as a bridge. The pack doesn't coach "shipped an API product".
- **The roadmap-input sessions are medium confidence:** expect a probe. The pack has you say up front that they were input to product and that you haven't owned a roadmap.
- **The dossier is about three months old:** it is dated 2026-08-14, so check the posting still reads the same. Its decision summary says "seven years of integration leadership", but no verified entry gives a duration, so the pack uses none. Say your tenure from your own CV.

I can run a live Skeptic drill on A1. I can also save a `tuesday-dossier.md` update recording what this prep exposed, for you to carry into later sessions, or convert the pack to Word.

Did the recruiter say what the hiring manager will focus on, or give you anything to prepare? A stated focus would change the persona weights.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday. Interviewer: not named. Built from your pasted dossier (role_profile and handoff_to_mock_interview). No company research ran, because web search was refused in this session, so company-specific questions are absent rather than guessed.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: rehearse it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior demonstrates the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack, see Sources) |
| CASE | Structure and reasoning on a live problem from the role |

Question IDs run by persona: A, B, C, D, E, G. There is no bank F, because F1 to F9 are the fit-snapshot rows. A guidance cell that ends in an answer slot is an instruction for the interview, not a question for you now: say what is true, in your own words, and take the second branch if the first is not true.

## Prep triage

Ordered by payoff. Everything else is insurance.

1. A1, out loud, until it is boring. It is the objection the underwriter named, and it will be asked in some form.
2. A2, A5 and E2: the roadmap and prioritization limits. Say the plain acknowledgment without apologizing and without adding to it.
3. A4 and C1 to C3: what the 30+ integrations were, what the playbook is, and what you can and cannot say about adoption.
4. B1, B3 and B5: three live cases. Practice clarifying first and structuring second.
5. Reverse questions 1 and 2: they close two risks the underwriter left open.

## Fit snapshot

Requirements are quoted from the dossier's role_profile. The three evidence sentences are the dossier's verified entries, quoted exactly; its confidence notes sit in the Confidence column and the bridge, not in the quote.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified evidence 2 | low | [grounded] | transferability | Dossier strategy: bridge, positioned as adjacent and never as PM experience. Both quotes are graded high by the dossier and are integration delivery and documentation, so the words stay there: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Name the limit in the same breath, sourced to `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title or role." |
| F2 | "Shipped API or platform products" — dossier role_profile, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | medium | [inferred] | transferability | This grading is the pack's own: the handoff names no weak area for R2 and the dossier carries no evidence_map. The quote is delivery against a vendor's API, and your material does not show shipping an API product, so that wording is not coached (section 13). Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the JD's "Shipped API or platform products" line makes a probe on whether any of that work shaped what the vendor shipped likely. If any did, say what and which part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the integrations you led |
| F3 | "Technical fluency: API docs, schemas" — dossier role_profile, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | medium | [inferred] | discovery | The quote touches REST APIs and architecture without showing whether docs or schemas were part of it. Answer slot: the JD names API docs and schemas, so expect a probe on them. If you read, wrote or reviewed either, say which and how, in your own words; if you did not, say so plainly and stay with the REST integrations |
| F4 | "Stakeholder management across engineering, sales, customers" — dossier role_profile, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [grounded] | discovery | The quotes show clients and product. They do not show engineering or sales, which the JD names. Quote 3 is confirmed with limited inspectable proof, so volunteer its limit before it is extracted. Words: "I ran quarterly roadmap-input sessions that fed client evidence to product." Answer slot: if any of this work involved engineering or sales colleagues, say who and how, in your own words; if not, say so plainly and stay with clients and product |
| F5 | "Agile delivery experience" — dossier role_profile, preferred | none given | low | [grounded] | discovery | Dossier strategy: clarify. No verified entry speaks to agile delivery itself, so no bridge is offered and nothing nearby is stretched. Answer slot: "Agile delivery" is the JD's wording, so expect a probe on how work was planned and delivered. If you worked in sprints or a similar cadence, say how, in your own words; if you never worked that way, say so plainly. Then the clarifying move: say what you would want to confirm about how this team defines agile delivery |
| F6 | "Own the roadmap for the partner-facing API platform" — dossier role_profile, responsibilities | none given | none | [grounded] | capability | Dossier strategy: acknowledge_gap, so no bridge and no slot. Plain acknowledgment, sourced to `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan said as a plan, never as a past: what you would learn first about who decides what, and how adoption is measured. The roadmap-input sessions in F4 are not offered as roadmap ownership |
| F7 | "Run discovery with integration partners" — dossier role_profile, responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | medium | [inferred] | discovery | The quote carries scoping and requirements on client integrations; whether any of it was discovery in the JD's sense is not shown. Answer slot: the JD's discovery line makes a probe likely. If any scoping or requirements work involved learning what a client needed beyond the integration at hand, say what you learned and what changed, in your own words; if not, say so plainly and stay with the integrations you led |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile, responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | medium | [inferred] | discovery | The quote says requirements, architecture and UAT. It does not say specs for, or delivery with, engineering squads, and that wider wording is listed in section 13. Answer slot: if any of the requirements you took to go-live were written for an engineering team, say what you wrote and for whom, in your own words; if not, or it was not yours, say so plainly and stay with the integrations |
| F9 | "Define and track adoption metrics" — dossier role_profile, responsibilities | none given | none | [grounded] | discovery | Nothing in the material speaks to adoption measures, and the dossier records that no baseline is stated, so silence here is discovery, not a stated absence. Answer slot: if you defined or tracked any measure of how a client used an integration after go-live, say what it was, in your own words; if you did not, say so plainly and say what you would want to measure first |

## Persona table

Loop: one session, a 45-minute conversation with the hiring manager, from your message. No values-style round is detected, so there is no Values bank. Weights below start from the pack's hiring-manager prior (Case and Skeptic dominant) and move on the dossier.

| Persona | How it shows up here | Likelihood, with reasoning | Basis | Counter-strategy (method) | Bank |
|---|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title and roadmap gap, the agile question and what the sessions achieved | High. The hiring-manager prior puts it first, and the underwriter named a specific objection, so it moves up | [inferred] | Rehearse the single objection until it is boring: concede plainly, bridge with the limit, ramp plan | A1 to A5 |
| Case / Strategist | Live problems from the role: first 90 days, adoption diagnosis, a conflict between partners, a spec | High. Hiring-manager prior; the JD's roadmap, spec and adoption responsibilities are all case-shaped | [inferred] | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | B1 to B5 |
| Data-Driven Prober | Reads the evidence line by line: the 30+, the playbook, adoption numbers | Medium. Evidence 1 carries a headline figure, so a defend-the-number question is owed | [inferred] | Know what you can and cannot say about how the 30+ was counted; name the assumption you would defend least | C1 to C3 |
| Conversational | Friendly opener, journey question, casual API-interest question; still scored | Medium. Every hiring-manager conversation opens with one | [generic] | A pre-scripted 90-second arc; treat casual questions as scored | D1 to D3 |
| Pressure | Time-boxed challenge on why you and on how much the sessions changed | Low. Possible as a variant of the Skeptic, not the dominant register | [inferred] | Pause, restate, hold through two follow-ups, concede specifically | E1, E2 |
| Peer Evaluator | Collegial seam-splitting about the two squad leads | Low. The squad leads are peers of the role, and decision authority is an open unknown in the dossier | [inferred] | Offer seam principles instead of pretending to know the seam; reciprocity framing | G1, G2 |
| Values / Behavioral | Not banked | No values round is detected and no published values were read | [generic] | None | none |

## Question banks

Highest-ROI rehearsal in this pack: A1. The underwriter's dossier named this objection from the evidence you confirmed, and it gets the deepest rehearsal.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Concede first and plainly, sourced to `prohibited_claims: "Having held a product manager title or role"` and `prohibited_claims: "Having owned a product roadmap"`: "That's right, I haven't held the PM title and I haven't owned a roadmap." Then the bridge, with its limit named: "What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live, and write the integration playbook my team uses. That is integration delivery, and I'm not presenting it as the PM job." Then a ramp plan, said as a plan: what you would learn first about who decides what between you and the two squad leads, and how adoption is measured today. Hold through two follow-ups by returning to the integration work in the quote's own terms and letting the interviewer draw the inference; do not tell them what it proves. If asked what transfers, describe scoping, requirements, architecture, UAT and go-live, nothing more. Concede specifically that there is a ramp | The underwriter named this objection (F1, F6). JD because it scores the must-have R1; the dossier strategy is bridge for F1 and acknowledge_gap for F6 |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `prohibited_claims: "Having owned a product roadmap"` | Name it yourself before they do, sourced to `prohibited_claims: "Having owned a product roadmap"` and the dossier's acknowledge_gap area: "Owning a roadmap. I haven't done that." Stop there, then give the ramp plan as a plan: the first things you would learn, the decision split with the squad leads and the current adoption baseline. Do not soften the acknowledgment with an adjacent story | F6 is the one gap the underwriter found no evidence for, so this is where a candid answer scores; JD because it asks against the posting |
| A3 | "Tell me about a time you worked in an agile delivery cycle." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (derived from the dossier's clarify area for R5; low confidence, so it appears only as a clarify note) | No verified entry speaks to agile delivery, so no story is mapped. Answer slot: the JD's agile delivery line makes a probe on how work was planned and delivered likely. If you worked in sprints or a similar cadence, say how, in your own words; if you never worked that way, say so plainly and return to the integrations you led from scoping through go-live. Then ask what they mean by agile delivery on their squads, so the answer becomes a conversation | F5 is a clarify area, so the honest move is a question-shaped answer; JD because R5 is a stated preference |
| A4 | "Tell me about a time you shipped an API or platform product." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-map on the integrations in the quote's own terms: end to end, scoping through go-live, of the vendor's REST APIs. Say the limit as you tell it: this was integrating the vendor's APIs for clients. Never describe it as shipping an API product. Answer slot: if any integration led to something the vendor then changed or shipped, say what and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the integrations | F2 is a must-have with only adjacent evidence, so this question will be asked in some form; JD because it scores R2 |
| A5 | "Walk me through how the roadmap-input sessions worked." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Medium confidence: confirmed with limited inspectable proof, so volunteer the limit before it is extracted. Tell the beats the quote states: you ran them, they were quarterly, they fed client evidence to product. Name the limit yourself, sourced to `prohibited_claims: "Having owned a product roadmap"`: "That was input to product. I haven't owned a roadmap." Anything about how a session ran is yours to supply from memory; the pack supplies none of it. If asked what product did with the evidence, say what you know and how you know it, and say plainly if you do not know. Never describe the sessions as shaping or setting priorities | F4 is the quote most likely to be probed because little inspectable proof sits behind it; EXP because it tests what was actually yours |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would approach your first 90 days on the partner-facing API platform. What do you need to know first?" | CASE | [generic] | Clarify first, out loud: who decides what between the PM and the two squad leads, and how partner adoption is measured today and from what baseline (the two unknowns the dossier left open). Then objective, partner segments, approach, metrics, risks. Challenge one premise respectfully. This is a plan, not a past: make no claim about roadmap work you have done | Live problem from the JD's roadmap and discovery lines (F6, F7); CASE because it scores structure, and the question presupposes nothing about your past |
| B2 | "Adoption of a partner API endpoint dropped 20% quarter over quarter. Diagnose it." | CASE | [generic] | Clarify what adoption means here and what the baseline was before diagnosing. Segment partners, list hypotheses with the data that would separate them, name the first cut you would look at, and say what you would not conclude yet. Use their vocabulary where you know it, and ask where you do not | Adoption is a stated responsibility with no baseline in the dossier (F9); CASE because it tests diagnosis, not recall |
| B3 | "Two partners want conflicting API changes and engineering has capacity for one. How do you decide?" | CASE | [generic] | Reason aloud from criteria: partner impact, platform consistency, cost and risk to engineering, and what each partner would do if declined. Name who you would involve, the squad leads, and say you would confirm who holds the final call. Frame it as how you would reason, not something you have done, sourced to `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't set prioritization for an engineering squad." | Prioritization authority is the F6 gap and the dossier's open question, so a hypothetical is the natural way it is probed; CASE |
| B4 | "What does a spec for a breaking change to a partner API need before engineering starts?" | CASE | [generic] | Structure it: the problem and who is affected, the change and its compatibility, the migration path for existing partners, how success is measured, open questions for engineering. Make no claim about specs you have written; if asked, answer from the quote only: "I led end-to-end integrations, from scoping and requirements through architecture, UAT and go-live." | The JD says write specs and drive delivery (F8); CASE because it presupposes nothing about your past |
| B5 | "How would you define and track adoption for a partner API platform? What would you measure first?" | CASE | [generic] | Clarify what a successful partner looks like before choosing a metric. Separate activation, depth of use and retention, name the weakest assumption in your first metric, and say how you would get a baseline if none exists. A plan, not a past | JD responsibility on adoption (F9) and an unknown baseline; CASE |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure is the headline of your evidence, so know your answers before the probe. Answer slot: say what counted as one integration, how comparable the 30+ were, which assumption behind the figure you would defend least, and which parts were yours, each in your own words. If you do not know how something was counted, say so plainly; if there were integrations where your part was smaller than leading, say so | F1 and F2 rest on this figure; EXP because it tests attribution and counting |
| C2 | "Tell me about the integration playbook: what it covers and how your team uses it." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say it at its own scope: you wrote it, it is internal, your team uses it. Anything about its contents or adoption comes from memory, in your own words; the pack supplies none. The dossier records it as inspectable, which makes it your strongest artifact: if sharing it is appropriate, offer it, but check that it is yours to share first | F1; EXP because it is the one piece of evidence an interviewer could ask to see |
| C3 | "The role defines and tracks adoption metrics. What did you track after integrations went live?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The JD's adoption line raises this, and no quote carries it. Answer slot: if you tracked any measure of use after go-live, say what and how, in your own words; if you did not, or it was not yours, say so plainly and return to the integrations you led. Then say what you would want to measure first | F9 is silence in the material, so discovery; JD because it scores the stated responsibility |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with the three quotes as its beats, each at its own scope: the integrations you led, the playbook you wrote, the sessions you ran. Close on why this role: nothing in the material states your motivation, so say in your own words why product and why this platform, and why now. Do not call the path a PM career | F1 and F4; EXP because it is the biography question and it is scored |
| D2 | "What do you read or use these days to stay current on API design?" | JD | [generic] | Pick something you actually use and say why. If nothing comes to mind, say so plainly, then give the nearest thing your material carries: the REST API work in your integrations | R3 (F3); a casual question that is still scored, and a selection scaffold because no quote carries it |
| D3 | "Tell me about a client integration that taught you something about what partners need from an API." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick one of the integrations where scoping or requirements surfaced a need you had not expected. It needs a named client, what you learned, and what changed afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would run discovery | The JD's discovery line (F7); JD, asked as an open prompt that supplies no event |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause and restate the question. Then hold only what the quote carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Concede plainly, sourced to `prohibited_claims: "Having held a product manager title or role"`: "I haven't held the PM title." Hold through two follow-ups by returning to the integrations; do not escalate to claiming you already do the PM's work | A time-boxed variant of A1 (F1); JD |
| E2 | "Did those roadmap sessions change anything product actually built?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold the quote and nothing beyond it: you ran quarterly sessions that fed client evidence to product. If you do not know what product did with it, say that plainly rather than guessing. Concede specifically, sourced to `prohibited_claims: "Having owned a product roadmap"`: "I haven't owned a roadmap, so what went on it wasn't mine to decide." Do not claim influence the quote does not state | F4's medium-confidence quote under pressure; EXP because it tests attribution |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You would work with two squad leads. Where is the seam between your calls and theirs, and what happens when you disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam, and say that where decision authority sits is the first thing you want to confirm. Reciprocity: what you would bring them, such as partner evidence and clear requirements. For the disagreement part, tell a real story only if one comes to mind. If none does, say so plainly and describe how you would handle it | F8 and the dossier's open question about decision authority; JD |
| G2 | "How do you handle credit when work spans teams?" | VAL | [inferred] "Wrote the internal integration playbook her team uses" | Use "we" for context and "I" for contribution. The quote gives you the playbook and your team, nothing about who else contributed, so any credit story is told from memory. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | F1; VAL asked as an open prompt with a selection scaffold, since no quote carries a credit-sharing story |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1 3+ years product management experience | A1, A2, E1 |
| R2 Shipped API or platform products | A4, C1 |
| R3 Technical fluency: API docs, schemas | D2, B4 |
| R4 Stakeholder management across engineering, sales, customers | A5, G1, G2 |
| R5 Agile delivery experience | A3 |
| Own the roadmap | A1, A2, B1, B3, E2 |
| Run discovery with integration partners | D3, B1 |
| Write specs and drive delivery with two engineering squads | B4, B3, G1 |
| Define and track adoption metrics | B2, B5, C3 |

## Reverse questions

| # | Question | Why it lands | Basis |
|---|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The posting asserts authority over two squads but the dossier found it unevidenced. Asking reads as diligence, and the answer decides what you would actually own | `questions_for_employer`, `opportunity_risks_to_validate` |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a named responsibility with no baseline stated. You would be accountable for a number you cannot yet see | `questions_for_employer`, `opportunity_risks_to_validate` |
| 3 | "How do the two squads split the platform, and how do partner requests reach them today?" | Shows you are already thinking about the seam you will work across, and fills what the dossier does not carry about the squads | Generic |
| 4 | "What are partners complaining about most with the API today?" | Shows a discovery instinct and gives you the first problem to bring to the 90-day case | Generic |
| 5 | "What would success look like at 90 days and at 12 months in this role?" | Turns the title-gap conversation into agreed outcomes, and an answer you can plan against | Generic |

## Prohibited claims

What this pack will not coach, with its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The F1 quote at its own scope, plus the plain acknowledgment sourced to `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title or role." |
| Having owned a product roadmap | Dossier `prohibited_claims` and the acknowledge_gap area | The plain acknowledgment sourced to `prohibited_claims: "Having owned a product roadmap"`: "I haven't owned a product roadmap." No slot, no bridge |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` and the acknowledge_gap area | The plain acknowledgment sourced to `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says integrations of the vendor's REST APIs, not a product shipped |
| Wrote specs for, or drove delivery with, engineering squads | Inflated form of F8 | F8's quote at its own scope. The material says requirements, architecture and UAT; the slot stays inside the integrations |
| Shaped or influenced what went on the roadmap | Inflated form of F4 | F4's quote at its own scope. The material says sessions that fed client evidence to product; the limit is the pack's observation, and the plain acknowledgment above covers ownership |

## Sources

Provided documents: tuesday-dossier.md, written by job-underwriter, dossier_version 1.1, dated 2026-08-14, decision conditional_go. Consumed: role_profile (requirement and responsibility lines stand as the JD) and handoff_to_mock_interview (verified evidence, weak areas and their strategies, the named objection, risks, employer questions, prohibited claims). The decision is context only. The dossier has no evidence_map, evidence_state or risk_register, so grades for rows without a weak-area entry are the pack's own, and say so. Its decision summary refers to "seven years of integration leadership"; no verified entry carries a duration, so the pack uses none. The dossier is about three months older than today, so check the posting's lines still read the same.

Searches sent:

- "Quartzline company values": refused
- "Quartzline interview process product manager": refused
- "Quartzline strategy news partner API platform": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Every call was refused. Would have decided whether a values-style round exists and fed a values cheat sheet; none is built |
| 2. Quartzline interview process, product manager | unavailable | Every call was refused. Would have named the loop. Persona weights rest on the hiring-manager prior and your own description of one 45-minute conversation |
| 3. Quartzline strategy and recent news | unavailable | Every call was refused. Would have fed company-strategy and CASE questions; no CO questions are written, and the CASE questions are generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Manager JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD questions |

## Upgrade menu

- The hiring manager's name: an interviewer read, persona weights adjusted to their public footprint, and a reverse question tied to their own path
- Permission to run web search: values, loop and strategy research, which would turn rows 1 to 3 above into sourced facts and add strategy-grounded CO and CASE questions
- Anything the recruiter said about what the hiring manager will focus on, or any assignment to prepare: replaces the round-type priors, and adds a build section if an assignment exists
- Your own answers to the slots in A3, A4, C3, D3 and the F3, F7, F8 and F9 rows: each answer you give outside a drill is quoted into the fit snapshot and upgrades those rows from a scaffold to a story
- The raw CV behind the confirmed claims, and an agenda or non-confidential output from one of the roadmap-input sessions: the sessions are the one medium-confidence quote, and an inspectable artifact would raise its band
