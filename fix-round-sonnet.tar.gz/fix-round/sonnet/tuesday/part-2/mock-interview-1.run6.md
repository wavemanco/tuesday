Web search was denied, so I'm building the pack from what you gave me and will list the research gap in the pack. Writing the file now.
The prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-1-denied-08c95b02/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. It has 21 questions across seven interviewer personas, weighted for a peer round with Dan (two Prober-tilted, "relentlessly data-driven" signals included). Every question has a type tag, provenance, answer guidance and a rationale.

The web searches I tried (Northwind values, a check on the Compass note, Dan's public footprint) were all refused, so the pack rests only on what you gave me. Three consequences:
- **No values section.** Without Northwind's published values it is dropped, and the two values questions use generic prompts.
- **Thinner interviewer read.** Dan's profile comes only from your description.
- **Unchecked strategy note.** The Compass and bundling questions are only as current as your research note, whose date I couldn't verify.

The question to rehearse first is C1, the "no classic sales-ops or quota-setting" challenge. The second is A1, defending the ~$400M ARR figure. Both are written to hold what Priya actually said and nothing more. Her "annual volume targets" are never called quotas, her revenue model is never called partner-motion design, and the ARR figure stays a proposal that was credited. The pack's prohibited-claims table lists these limits.

Where your inputs were silent, such as how the ARR was counted or what Priya designed on the partner side, the guidance is an answer slot for her to fill in her own words, not content I supplied.

Say the word and I'll play Dan as the Skeptic on C1, or as the Prober on A1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

- Interviewer: Dan Kovac, Director of Sales Strategy. Relationship: peer, both reporting to the same VP
- Round: one 60-minute conversation with Dan
- Candidate: Priya
- Built on: the JD highlights, the candidate summary, Dan's profile description and your research note, all from your message. Web research was refused, so nothing in this pack comes from outside those inputs (see Sources)

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and rehearse only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows the thing asked about |
| EXP | Work-experience deep-dive: whether a claim survives scrutiny and how much of it was yours |
| JD | Role and JD fit: whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge: whether you can think at Northwind's altitude |
| CASE | A live problem set in the role: structure and reasoning |

Highest-ROI prep in this pack: C1, the question about the missing sales-ops and quota-setting background. It will be asked in some form, and a rehearsed non-defensive answer changes the interview. Second: A1, the defence of the ~$400M ARR figure.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message; "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material says a proposal and a product strategy and ops career, not GTM ownership of a product line, and the words stay there: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's own-GTM line makes a probe on taking a product to market likely. If any part of a launch plan was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | The material does not show this work. Answer slot: if you have looked at where customers or partners could adopt or expand further, say what you looked at, in your own words; if you have not worked a lifecycle like that, or it was not yours, say so plainly, then say how you would size whitespace first, as a plan |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | discovery | The line names the tools and does not show whether an analysis was run independently, with nothing inspected behind it. Words: "I'm skilled in SQL/Tableau." Answer slot: if there is an analysis you ran yourself, say what question it answered and what you did, in your own words; if the work was shared or someone else ran it, say so plainly and stay with the tools |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not partner-motion design, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: this is the JD's hard requirement, so a probe is certain. If any part of how the partner relationship was structured or run was yours to design, say which and how you decided; if the model fed negotiations and the structure was set elsewhere, or there was no such step, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: "I set annual volume targets with cross-org consensus." Keep your own noun, volume targets, every time |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | presentation | The quote already reaches the plus in other terms. Words: "I use AI tools daily." Nothing is added to it: it says use, and it says nothing about building or selling an AI product |
| F7 | Sales-ops and quota-setting fluency (role-family expectation for a sales-strategy peer; no JD line was supplied, so this is not a quoted requirement) | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap wording cannot close, and it was stated in your message, which I have treated as Priya's own statement. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| Own GTM strategy for two new product lines | D1, D2, B4, C1 | JD-tagged on D1 and B4 |
| Whitespace across land/adopt/expand/renew | D1, A5 | A5 carries it as a metrics case; the evidence row is thin, so both are live-problem questions |
| Independent analysis in SQL and Tableau | A2, B4 | JD-tagged on both |
| Partner-motion design experience (required) | C2, A3, D1 | JD-tagged on C2 |
| Strong cross-functional influence | B1, B2, A4 | JD-tagged on B1 and B2 |
| AI experience a plus | E2 | JD-tagged |
| Defend-the-number: the ~$400M ARR uplift | A1, F1 | EXP on both |
| Company strategy: enterprise expansion, Compass, profitability, bundling | D2, D3, R4, R5 | grounded in your research note only |
| Values questions | G1, G2 | no published values were in hand; themes come from persona stems, not from Northwind's values |

## Reading the interviewer

Public professional footprint only. Everything here comes from the profile description in your message. The search for more was refused, so no talks or writing were read.

| Item | Reading | Provenance |
|---|---|---|
| Role and seat | "Director of Sales Strategy" — your message, and a peer who reports to the same VP as Priya would | [grounded] |
| Self-description | "relentlessly data-driven" — your message | [grounded] |
| Career spine | "career spine is pricing and monetization roles, with one early-stage-startup chapter" — your message | [grounded] |
| Implication 1 | Expect every figure to be taken to its inputs, so define terms aloud before being asked (A1, A5). Derived from the self-description above and the persona rule that a data-driven history raises the Prober | [inferred] |
| Implication 2 | Expect a pricing, packaging and unit-economics lens on any GTM answer, so put one pricing or packaging consideration into each case (D1, D2). Derived from the career spine and the persona rule for pricing-native interviewers | [inferred] |
| Implication 3 | The startup chapter may bring pace and scrappiness probes about a large-company background. Derived from the persona rule for founder or early-stage chapters | [inferred] |
| Implication 4 | As a peer who reports to the same VP, he is pricing what the hire adds to or takes from his load, so offer reciprocity before asking for anything (B4, R3). Derived from the peer-round prior | [inferred] |
| Mirror opportunity | Shared vocabulary of revenue and monetization pairs with F4: "built a partner-level revenue model used in carrier negotiations". The limit: a model for negotiations is not pricing work, and the pack does not offer it as such. No shared career jump is offered, because no row's evidence carries one | [inferred] |

## Persona table

Weights start from the peer-round prior (Peer Evaluator and Data-Driven Prober), are adjusted by the interviewer signals above, and then by the loop. The loop is one session with Dan, set by your message, and it names no values round, so Values stays low.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Data-Driven Prober | Takes each figure and claim down to its inputs and assumptions | Highest, 5 questions: peer prior, plus "relentlessly data-driven" | Know what you can and cannot say about how each number was counted, say plainly when you do not know, and name the weakest assumption before he does | A |
| Peer Evaluator | Seam-splitting between his team and the role, credit-sharing, what you need from him | High, 4 questions: the relationship is peer and the same VP is above both | Reciprocity: say what you bring his team. Offer seam principles, not a map of a seam you cannot know yet | B |
| Skeptic | Quiet probing of the sales-ops gap, the partner-motion requirement and the move from consumer tech | Medium, 3 questions: F7, F4 and F2 are the thin rows | Rehearse C1 until it is boring. Bridge only from what you stated, say the limit plainly, then give a ramp plan | C |
| Case/Strategist | Live GTM, whitespace and bundling problems, with a pricing tilt | Medium, 3 questions: pricing and monetization spine, and the role is strategy | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise per case | D |
| Conversational | The opening "walk me through the journey", and a casual question about AI | Low, 2 questions: a 60-minute peer conversation still opens this way, and the AI plus is asked casually | A pre-scripted 90-second arc. Treat casual questions as scored | E |
| Pressure | Attribution pressure on the headline figure, and a time-boxed "why you" | Low, 2 questions: peer rounds seldom stress, but the figure invites it | Pause, restate, hold through two follow-ups, concede specifically and never fold on the core claim | F |
| Values/Behavioral | Unpopular-truth and customer-versus-metric prompts | Low, 2 questions: no values-style round is detected, and no published values were in hand | Use selection criteria; where nothing comes to mind, say so rather than supplying an ending | G |

## Question banks

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start with the quote at its own scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Then the four slots, each in your own words. How it was counted: if you know, say how; if you do not know how it was counted, say that plainly. What it is sensitive to: name it if you know. The assumption behind it you would defend least: name it before he asks; if you do not know, say so plainly. Which part was yours: say what you did and what others did; if the work after the proposal was not yours, say so and stay with the proposal | F1 holds the pack's one headline figure, which a Prober goes to first. EXP because it tests whether the number survives scrutiny and whether the attribution is exact |
| A2 | "Tell me about an analysis you ran yourself in SQL or Tableau, from question to answer." | JD | [grounded] "skilled in SQL/Tableau" | The quote carries only the tools: "I'm skilled in SQL/Tableau." Choose the story by criteria: it was yours end to end, you can name the question it started from and the data it used, and you can say what it informed. Name the assumption in it you would defend least before he asks. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3 is the only evidence for the independent-analysis requirement, and it names tools without an analysis. JD because it scores the stated requirement; open prompt, so it supplies no event |
| A3 | "Walk me through the partner-level revenue model you built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Tell the beats the sentence states: you built it, it was partner-level, it was a revenue model, and it was used in carrier negotiations. Say it in your own words. Expect follow-ups on how it was put together: answer only what you know, and say plainly where your knowledge stops | F4 is the only row behind the partner requirement, so a Prober opens it. EXP because it tests what the model was and what was yours; the partner-motion requirement itself is scored in C2 |
| A4 | "Walk me through how you set the annual volume targets." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the sentence states: annual volume targets, you set them, with cross-org consensus. Say it in your own words and keep your own noun, volume targets, every time. Answer slot: the JD's cross-functional line makes a probe on how the orgs came to agree likely. If they disagreed, say about what and what moved them; if consensus came without disagreement, or you were not the one who brought it, say so plainly and stay with the targets you set | F5 is the row closest to Dan's own domain, so wording discipline matters most here. EXP because it tests what was actually the candidate's |
| A5 | "A new product line has just launched. Which metrics tell you whether the land, adopt, expand and renew stages are working, and how is each defined?" | CASE | [generic] | Clarify first: who the buyer is, what a land means for this product, how the contract is shaped. Then go stage by stage, name one leading indicator for each and define its numerator and denominator aloud before he asks. Say what data you would need and where SQL would pull it from. Finish with the metric you would trust least and why. The question asks for no claim about your past, so the guidance makes none | F2 has no evidence, so a live problem lets the candidate show lifecycle reasoning without claiming experience. CASE because it is delivered live; the JD whitespace line is its source |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between Sales Strategy and what you would own, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a map you cannot know: who owns the question versus who owns the data, how a disagreement is settled on shared numbers, and when it goes to the VP you both report to. Say you would ask him how it works today before proposing anything. The question asks for no claim about your past, so the guidance makes none | F5 and F1 are why the seam is the peer's first worry. JD because the role's cross-functional line is what it scores; the Peer Evaluator stem delivers it |
| B2 | "How do you get people on other teams to move when you do not manage them?" | JD | [grounded] "set annual volume targets with cross-org consensus" | The quote carries the outcome: "I set annual volume targets with cross-org consensus." It does not say how consensus was reached. Answer slot: if you changed anyone's position, say how, in your own words; if consensus formed without you moving anyone, or the work was not yours alone, say so plainly and stay with the targets. Use "we" for context and "I" for your contribution. Hold on the quote's wording and do not upgrade it to persuaded or aligned | F5 is the evidence for cross-functional influence and the likeliest place to be probed. JD because it scores the stated requirement |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Describe the work at its own scope: you proposed the change, and the change was credited with the uplift. Answer slot: if others built, launched or measured it, name that credit plainly and say what they did; if you did any of those, say which; if it is unclear who did what, say so. Credit others by name for what was theirs before he asks | A peer prices credit-sharing, and F1's wording is where credit is most exposed. EXP because it tests attribution honesty; the Peer Evaluator stem carries it |
| B4 | "What would you need from my team in your first 90 days, and what would you bring us?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with what you bring: "I'm skilled in SQL/Tableau", offered as analysis you could run on questions his team is carrying. Frame your needs as questions: how targets are set today, how stages are defined, and what data you can reach. Do not claim to have solved his problems | F3 and F1 meet here. JD because it scores the analysis and own-GTM requirements; reciprocity is the peer counter-strategy |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I do not see classic sales-ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | The highest-ROI rehearsal in this pack. Say the limit first, before he asks for it: "I don't have classic sales-ops or quota-setting experience." Then the nearest thing the quote carries, at its scope: "I set annual volume targets with cross-org consensus." Then a plan in the future tense: what you would ask him first about how targets are set today, and what you would pull in SQL. Follow-up 1, likely: volume targets are not quotas, so how do they differ. Hold by not defending an equivalence; say what differs in your own words, and if you do not know, say so. Follow-up 2, likely: what would you get wrong in your first quarter. Concede one or two specific things in your own words. The pack does not name them; if none comes to mind, say you would want to find out from him. The two quoted sentences stand through both follow-ups | F7 is a stated gap and F5 is the nearest evidence, so this objection is aimed exactly where the material is thin. JD because it scores a gap in the listed role |
| C2 | "Partner-motion design is a requirement here. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The quote at its own scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of how the partner relationship was structured or run was yours to design, say which and how you decided; if the model fed negotiations and the structure was set elsewhere, or there was no such step, say so plainly and stay with the model. Hold through two follow-ups by returning to the model, never by adding to it. The honest branch is a limit, not a confession | F4 is the evidence for the JD's one hard requirement, so it will be pressed. JD because it scores the stated requirement |
| C3 | "Why move from consumer tech into B2B data infrastructure, and why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The sentence carries the arc, and it does not carry the motive. Say your reason in your own words: one reason, not a list. Tie it to one of Northwind's three priorities only where it is genuinely yours: enterprise expansion, Compass, profitability. Say that the consumer-tech career is where you are coming from, and avoid presenting it as B2B experience | F1 supplies the career arc and F7 the sales-side gap that makes the move a question. EXP because it tests whether the story is consistent under cross-examination |

### D. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "We have two new product lines and one GTM lead. Walk me through how you would build the GTM strategy. What do you need to know first?" | JD | [grounded] | Clarify first: which buyers, what stage each product is at, how the two relate, where Compass sits. Then objective, segmentation, approach, metrics, risks. Challenge one premise respectfully, for instance whether two lines should share one motion. Put one packaging or pricing consideration and one partner-motion design question into the approach, and say what data you would pull. The question asks for no claim about your past, so the guidance makes none | The JD's first line is this question, and F1, F2 and F4 are the rows it leans on. JD content with CASE delivery, and the pricing tilt follows the interviewer read |
| D2 | "A much larger platform vendor starts bundling a competing capability into its suite at no extra price. How does that change the GTM plan for an emerging product?" | CASE | [grounded] | Clarify which buyers see the bundle and what exactly is bundled. Then where you win standalone, how you position against the bundle, what the pricing and packaging response is, what the partner motion does, and what you would stop doing. Name the data that would change your view. The setting comes from your research note: "main competitive threat is bundling by a much larger platform vendor". The question asks for no claim about your past | The bundling threat is Northwind's stated competitive frame in your note, and pricing and unit economics are Dan's native angle. CASE because it is delivered live |
| D3 | "Enterprise expansion, the Compass launch and reaching profitability are all on the table. Where does a GTM lead for emerging products pull against one of them?" | CO | [grounded] | Take a position on the tension you actually see, state your assumptions about internal numbers as assumptions, and say what data would change your answer. Do not claim knowledge of Northwind's internal figures. The priorities come from your research note, whose date I could not verify, so check that they are current before the interview. The question asks for no claim about your past | The only CO question grounded in Northwind's stated strategy. CO because it tests altitude; the pricing and profitability angle suits the interviewer |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" and "built a partner-level revenue model used in carrier negotiations" and "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc built only from the quotes: the two stages of your career, then the model, then the proposal, each at its own scope, then a sentence pointing at this role in your own words. Say what you did and let him draw the inference | F1 and F4 carry the arc. EXP because the opener is a CV walk-through; the Conversational stem delivers it |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | The quote at its own scope: "I use AI tools daily." Name one specific thing you do with them and what you learned, in your own words. If your use is for your own productivity rather than anything shipped, say so plainly. Do not extend it toward building or selling an AI product | F6 is the only evidence behind the AI plus. JD because the JD flags it, and casual register is how a plus gets scored |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ~$400M ARR. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate the question. Hold on the quote at its scope: "I proposed the change, and it was credited with the uplift." Hold through two follow-ups. Then concede specifically, in your own words: say who built, launched or measured it, and what was not yours. Do not concede the proposal. Answer slot: if you do not know how the credit was assigned, say so plainly | F1 is where an attribution probe lands. EXP because it tests whether the claim shrinks gracefully; the Pressure stem delivers it |
| F2 | "Sixty seconds: why you over someone who has run sales ops and partner programs?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus" and "proposed a store-surface change credited with a ~$400M ARR uplift" | Three beats, each at its quote's scope, then one honest limit: "I don't have classic sales-ops or quota-setting experience." Describe what you did and let him draw the inference; do not state what it proves | F4, F5 and F1 are the beats and F7 the limit. JD because it scores fit against the listed job; the time-box is the Pressure stem |

### G. Values/Behavioral (weight 2)

No published values were in hand, so these two use persona stems and are not mapped to Northwind values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: pick a time with a named stake, a moment you held your position, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Choose a story where the hard truth actually landed | No fit-snapshot row carries this story, so it is a selection scaffold. VAL because it scores behavior against a virtue; low weight because no values-style round is detected |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a decision where the two pulled apart, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No row carries this story either. VAL for the same reason; the pick comes from the Values/Behavioral stems, not from Northwind's values |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has run through pricing and monetization. When a new product line has no pricing history, what do you wish the GTM lead had on the table before packaging gets decided?" | Tied to his own path, in his native language, and it shows you prepared on him, not only the company |
| R2 | "You also spent time at an early-stage startup. What from that chapter do you wish more people brought to an emerging-product launch here?" | Tied to his own path again, and it turns the pace and scrappiness probe into a peer conversation |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are weighing what you add to his load |
| R4 | "How do the two product lines relate to Compass and the enterprise-expansion push, and where is the seam with your team on them?" | Uses Northwind's stated priorities from your note and asks about the seam, so it reads as homework |
| R5 | "When a much larger vendor bundles against us, where does it show up first in your data?" | Speaks to a data-driven interviewer in his own terms and tests your CASE reasoning from D2 |
| R6 | "Where does target-setting for a new product line sit today, and where would you want the GTM lead's view to come in?" | Opens the F7 gap as a working question about the seam and not as a confession |

## Prohibited claims

Built before the banks. Each is a claim this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience | Negative stated in your message, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Treating the annual volume targets as sales quotas | Inflated form of F5, and contradicted by F7's stated negative | F5's quote at its own scope: "I set annual volume targets with cross-org consensus." The limit is the pack's observation: the material says volume targets, not quotas |
| Designed or owned a partner motion or channel strategy | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a revenue model used in negotiations, not partner-motion design. C2's slot stays inside the model |
| Owned, drove or delivered the ~$400M ARR uplift | Inflated form of F1 | F1's quote at its own scope: a proposal that was credited with the uplift. The limit is the pack's observation: the material says proposed and credited |
| Owned or led GTM for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a proposal and a strategy and ops career, not GTM ownership |
| Pricing or packaging experience | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: a revenue model used in negotiations is the only commercial work the material states |
| Built or sold AI products | Inflated form of F6 | F6's quote at its own scope: "I use AI tools daily." The limit is the pack's observation: the material says use only |

## Sources

Provided documents: your message, which held the JD highlights, the candidate summary, Dan's profile description and the research note on Northwind's three priorities and the bundling threat. No dossier was present. The negative in F7 is taken from your message and treated as Priya's own statement.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | One search was sent, "Northwind Data company values principles data infrastructure", and it was refused. It would have moved the values cheat sheet and the VAL themes. With no values page and no values-style round in the loop, that section is dropped |
| 2. Northwind Data interview process, GTM strategy | skipped | No search sent. Your message fixes the loop as one 60-minute conversation with Dan, which fixes the persona weights |
| 3. Northwind Data strategy and recent news | unavailable | One search was sent, "Northwind Data Compass AI copilot launch", to check your research note, and it was refused. It would have moved how current the CO bank is; the note's date is unknown, so D2, D3 and R4 are as fresh as the note |
| 4. Dan Kovac, Northwind Data | unavailable | One search was sent, "Dan Kovac Director of Sales Strategy Northwind Data", and it was refused. It would have moved the interviewer read and R1 and R2; both rest on the profile description in your message |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the six highlight rows become quoted rows, and any mid-list requirement the highlights left out gets a question; the coverage table was checked only against the six highlights
- Priya's CV text → the F1 to F6 evidence cells hold her exact wording instead of your summary, and the guidance beats follow it
- The artifact behind each headline claim, such as the revenue model file, the written proposal for the store-surface change, or a dashboard → F1 and F4 can rise from medium to high
- Priya's own answers to the answer slots in F1 to F4, sent as a message outside a drill → those rows are regenerated with her words, and C2 and A1 become story-mapped
- Recruiter or HR guidance, such as stated focus areas or any announced deliverable → coverage beyond round-type priors; usually one email to the recruiter
- Search permission, and a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → Northwind's published values and the values cheat sheet, a current strategy check on Compass and the bundling threat, Dan's public talks and writing, and a grounding brief
- Prep time available → a prioritized prep schedule sized to it
- A tuesday-dossier.md from a prior role assessment → verified evidence, a stated objection and prohibited claims in place of the ones inferred here; the pack does not depend on it
