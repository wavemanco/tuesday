Web searches weren't permitted, so I'm building the pack from your message and the recruiter's email as you quoted it.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-5-denied-4a26e66b/kelverton-rail_senior-partnerships_manager_interview_pack.md`.

I built it from your message and the recruiter's email as you quoted it. It has no JD, no market report and no web research. The report didn't come through to me, and the web searches were refused, so nothing in the pack draws on either. The company-specific questions are labelled generic because of that.

The prep triage fits your four hours.

Say the word and I'll play Ross on B1, the question the pack names as your highest-ROI prep (no rail sales, no quota). I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the JD to paste? It would turn the role-family requirement rows into quoted ones and settle any location, travel or pay terms. If the market report's headline findings come with it, the POV worksheet can be filled from the source.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail — Senior Partnerships Manager — second-round panel prep pack

Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: a 15-minute POV from you, then Q&A, with Ross pushing on commercials (recruiter's email, as you quoted it).

Built from your message and the recruiter's email only. No JD, no market report (it did not reach me) and no web research (searches were not permitted), so company-specific rows are generic and say so. Sections dropped because their conditions failed: grounding brief (no strategy brief in hand), reading the interviewer (titles only, no public footprint), values cheat sheet (no values-style round detected), delivery coaching (no assessment).

## 1. How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did. An answer slot is an instruction for the interview, not a question for you now.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The role as described, including its gaps |
| CO | Company and strategy knowledge, at the company's altitude |
| CASE | Structure and reasoning on a live problem |

## 2. Prep triage (four hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 75 min | Build the POV, then say it aloud three times against a clock; aim for 12 to 13 minutes so Q&A is not squeezed | Section 3, A1, D3 |
| 2 | 45 min | Rehearse the concession-then-bridge answer until it is boring: the highest-ROI prep in this pack | B1, B3, D1 |
| 3 | 45 min | Defend the number: how the £4M was counted, what it is sensitive to, the assumption you would defend least, what was yours | C1, C2, D2 |
| 4 | 30 min | Re-read the market report for one consensus item, one divergence and one anti-pick | Section 3, A4 |
| 5 | 15 min | Write your 90-second journey and pick three reverse questions | F1, Section 7 |
| 6 | 30 min | Live drill with Ross pushing on commercials | C3, C4, D2 |

Everything else is insurance.

## 3. Graded deliverable: the 15-minute POV

The recruiter's brief, as you quoted it: "present a short POV on where you'd take our operator partnerships over the next 18 months", "no slides needed, just talk us through it", and "Please land on what it means for the operators themselves." This is graded, so it gets its own build.

**Grounded facts to build on** (each a sentence quoted exactly from that row's evidence cell)

| Row | Quote | Use |
|---|---|---|
| F1 | "took it from 6 partners to 40" | One sentence, at its own scope, as the reason you have a view on partner programmes. |
| F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say the work, not the phrase "the other side", until you can say which side. |
| F3 | "roughly £4M of influenced revenue" | Consider leaving it for Q&A: mentioning it in the POV invites Ross's commercial probe before you have landed the operator close. |

**Shape** (generic timing; adjust to your own pace)

| Beat | Minutes | Holds |
|---|---|---|
| Frame | 0 to 1.5 | The assumption you are making about what "operator partnerships" means, stated aloud, and your thesis in one sentence |
| Three moves | 1.5 to 10.5 | Each move: what you would do, what you would stop doing, and what it means for an operator in the operator's terms |
| The operator close | 10.5 to 13 | The requested close: what changes for the operators themselves if all three moves land |
| Verify and concede | 13 to 15 | The one thing you would check first in 90 days, and your concession |

**Thesis options** (pick one as the spine; each carries a mandatory concession)

| Thesis | Mandatory concession | Provenance |
|---|---|---|
| Fewer, deeper operator partnerships, each defined by an outcome the operator would sign up to | "I haven't seen your partnership numbers, so how many and how deep is a hypothesis for my first 90 days." | [inferred] derived from the recruiter's close on what it means for the operators themselves; no claim about your past |
| A repeatable path from first conversation to live partnership, so each new partner costs less to bring on | "A payments ISV channel is not a rail operator programme; whether operator partnerships are many and similar or few and bespoke is what I would test first." | [inferred] derived from F1, "took it from 6 partners to 40", used as a reason for the view and never as proof it transfers |
| Every partnership carries a commercial case both sides can read, built with the commercial team | "I haven't carried a direct quota; my number was influenced revenue, so I would build these with Ross's team and not alone." | [inferred] derived from the recruiter's "Ross will push on commercials"; the concession's words are F4's: "never carried a direct quota, only influenced revenue" |

**Differentiation.** The market report is available to the panel and to every other candidate, so reciting it scores as homework. The pack has not seen it and names none of its content. Fill in from the report:

| Slot | What goes in it |
|---|---|
| One consensus item | The one report finding you agree with, to prove grounding, in a sentence |
| One divergence | A place you would take it further or differently, with your reason; offer it as a lens, never as a correction of the people who wrote it |
| The anti-pick | One thing you would deliberately not do in the 18 months, and why; a plan that drops nothing is not a thesis |

**The requested close.** For each move, one sentence of what changes on the operator's side. The pack does not supply operators' goals; they come from the report and from your own planning work at its own scope.

## 4. Fit snapshot

No JD was supplied, so requirements are the recruiter's words as you quoted them (grounded), the role title, and two role-family requirements written as plain prose and labeled generic. No gate rows: nothing supplied states a gate term (location, travel, schedule, pay, authorization), and the upgrade menu says what the JD would settle.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, as you quoted it | "running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material says an ISV channel in payments that grew from 6 partners to 40, not operator partnerships, and the words stay there: "I ran the ISV channel and took it from 6 partners to 40." The POV is a view about what comes next, so it needs no claim about past rail work. Nothing is inspected behind the 6-to-40 line, so expect a probe on it (C2) |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email, as you quoted it | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning; your message says Kelverton sells to train operating companies and does not say you worked with them. Words at that scope: "I spent five years in transport consulting, on bus and light rail network planning." "The other side" is yours and your message does not say which side. Answer slot: expect a probe on how close that work sat to an operator's own decisions. If it sat close, say how, in your own words; if it did not, or you only saw the results of those decisions, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter's email, as you quoted it | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The figure is influenced revenue, with "roughly" in front, and nothing is inspected behind it. Words: "The number I can give is roughly £4M of influenced revenue." Your message does not say whether it is per year or across the four years, so say which only if you know. Answer slot: expect how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer each in your own words; if you do not know how it was counted, or part of it was not yours, say so plainly and return to the figure at its own scope |
| F4 | Carry a commercial number for partner revenue [generic] | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't carried a direct quota; my number was influenced revenue." Then what you would do about it, said as a plan and never as a past. Never a claim to a target you carried |
| F5 | Experience selling into or partnering with rail operators [generic] | "Never sold into rail specifically" — your message | none | [grounded] | capability | Words: "I haven't sold into rail specifically." The nearest thing your material carries is F2's network planning, at its own scope. Then a ramp plan, said as a plan: who you would sit with, what you would read, what you would have produced by day 90, all yours to fill. Never a claim to rail sales or operator relationships |
| F6 | "Senior Partnerships Manager" — role title, your message | "9 years in partnerships" — your message | medium | [grounded] | discovery | The title asks for seniority and you give nine years, which an interviewer will read beside the five years of consulting and the last four at the payments company your message also gives. Your message does not say how those figures fit, and the pack will not pick a reading. Answer slot: if the nine includes the consulting years, say so, in your own words; if the consulting years were not partnerships work, say so plainly and stay with the nine as you gave it |

## 5. Persona table

Weights rest on the recruiter's email and relationship priors, not on a documented Kelverton loop (no loop source beyond the recruiter's own words, which establish this one session). Panel rule: blend the top two personas of each member's relationship.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | The POV itself, then live problems on operator partnerships | High. Deepa is the hiring manager (prior: Case and Skeptic), and a 15-minute POV was announced | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Probing the absences: rail, quota, why this move | High. Hiring-manager prior, and F4 and F5 are stated absences | Rehearse the one predictable objection until it is boring; concede plainly; bridge only from what you stated; add a ramp plan |
| Data-Driven Prober (C) | Ross on the numbers behind any figure | High. The recruiter says Ross will push on commercials, and F3 is the one headline figure | Know what you can and cannot say about how the figure was counted; name the weakest assumption before he does |
| Pressure (D) | Interruptions and time-boxes, mostly from Ross | Medium. Senior-commercial-stakeholder prior, assumed; his seniority relative to Deepa is not known | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Peer Evaluator (E) | The seam between Partnerships and Commercial | Low. Ross sits on the commercial side next to Deepa's function, and the recruiter's note points to commercials, not to the seam | Reciprocity: what you bring his team; propose seam principles rather than pretending to know the seam |
| Conversational (F) | The opening journey question and a casual operator question | Low. Likely as the opener; the risk is treating it as unscored | A 90-second arc built only from what you stated; treat casual questions as scored |
| Values/Behavioral (G) | One or two scenario prompts | Low. No values-style round is detected: the recruiter's description names none, and no published values were read | Selection scaffolds with the honest branch; pick stories where the hard truth landed |

## 6. Question banks

### A. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have fifteen minutes: where would you take our operator partnerships over the next 18 months, and what does it mean for the operators themselves?" | CASE | [grounded] | This is the announced deliverable arriving live, so rehearse it as your opening and not as an answer. Say the shape aloud first: your assumption about what operator partnerships means, one thesis, three moves, what each means for an operator, and the one thing you would verify first. If the panel corrects your assumption, take it and carry on. Build and timing are in section 3. The question needs no claim about your past, so this guidance makes none | The recruiter named this deliverable and its close, so it is graded; CASE because it is a live problem on the role |
| A2 | "A major operator partner tells you the last two integrations ran later than promised and they are weighing whether to continue. What do you do in your first week?" | CASE | [generic] | Clarify before you structure: what the delay cost the operator in their terms, what was promised and by whom, and what the continuation decision turns on. Then: listen and confirm facts with the operator first; separate repairing the relationship from finding the cause; agree one next step the operator would recognise as a fix; tell Deepa and Ross what you know and do not know before promising anything. Challenge one premise respectfully, such as whether the delay is the real reason for the doubt. No claim about your past | A hiring manager's likeliest live problem is a partner at risk, and it tests the operator-first close the recruiter asked for; `[generic]` because it is a pattern for the problem, not a fact about Kelverton |
| A3 | "We can only properly invest in a handful of operator relationships over the next 18 months. How do you decide which, and which do you say no to?" | CASE | [generic] | Say what you would need before ranking: each operator's aims, readiness, cost to serve, and commercial value. Name the criteria aloud and rank only afterwards, then actually name something you would not do; offer to revisit in 90 days with their real data. The pack does not supply the ranking. No claim about your past | Tests the anti-pick that section 3 asks for; CASE because it is a live prioritisation problem |
| A4 | "You have read the market report our strategy team circulated. Where would you take its view further, or differently?" | CO | [generic] | Differentiate, never recite: one consensus item to prove you read it, one divergence with your reason, and the anti-pick. Offer the divergence as a lens or a question and not as a correction of the people who wrote it. The pack has not seen the report and names none of its content; fill in the worksheet in section 3. No claim about your past | Cannot be grounded in current strategy without research or the report, which is the honest cost of the missing inputs; CO because it tests homework depth |
| A5 | "Eighteen months from now, how would you know operator partnerships were working, for the operators and not just for us?" | CASE | [generic] | Name the operator-side outcome first and the Kelverton-side measure second; separate early signals from lagging ones; say you would agree the definitions with operators and with Ross's team in the first 90 days. The pack does not supply operators' goals; they come from the report and your own reading. No claim about your past | Follows the recruiter's operator close and Ross's commercial lens; CASE because it asks for a measurement design |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail and you haven't carried a quota. Why should we believe you can do this job?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The highest-ROI rehearsal in this pack: some form of this question is coming, and a calm answer changes the room. Concede first, plainly: "I haven't sold into rail specifically." "I haven't carried a direct quota; my number was influenced revenue." Then the nearest thing, at its own scope: "I ran the ISV channel and took it from 6 partners to 40." "I spent five years in transport consulting, on bus and light rail network planning." Then a plan, not a past: your first 90 days on the operators' side, who you would sit with, what you would read, what you would have produced; the pack does not write it for you. Hold through two follow-ups by returning to those sentences, never by adding to them | F4 and F5 are the two stated absences, so this objection arrives in some form; JD because it scores whether you can do the role as described, gaps included |
| B2 | "Why this move, from payments into rail operators, and why now?" | JD | [grounded] "last 4 at a payments company running the ISV channel"; "5 years in transport consulting" | Your reasons are not in your material, so the pack supplies none. Selection criteria: one reason specific to this role and this employer that you can say to Deepa in a sentence, one reason that is not about leaving something, and a why-now that is true. The arc your quotes carry is five years in transport consulting, then the last four at a payments company running the ISV channel; say it in that order and let your reasons connect the two. If no clean reason comes to mind, say so plainly, then give the nearest honest thing or say how you weighed the move | The classic Skeptic motivation probe, sharper for a move between sectors (F1, F2); JD because it scores fit with the role |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Name one, once, without padding. If it is the quota, the words are: "I haven't carried a direct quota; my number was influenced revenue." Then how you would close it, as a plan in your own words: who you would pair with and what you would have agreed by day 90. One weakness chosen honestly beats a list. If a different weakness is truer, use it; the pack does not choose for you | A stock Skeptic stem, and F4 is where the commercial probe will press; JD because it scores honest self-assessment against the role |
| B4 | "You ran an ISV channel in payments. What makes you think operators would partner with us the way those partners did?" | JD | [grounded] "running the ISV channel"; "took it from 6 partners to 40" | Do not claim it transfers; say it is a hypothesis you would test. What your quotes carry: "I ran the ISV channel and took it from 6 partners to 40." The rail side is untested in your material, and you can say so. Name what you would test first and how you would know within 90 days; that test is yours to write. Hold through two follow-ups by returning to the sentence above | F1 is the strongest evidence and also where an analogy from another sector is most likely to be challenged; JD because it scores the stated mandate |

### C. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | Defend-the-number, in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Name the weakest assumption before he does. Answer slot: if you know how it was counted, say how; if you do not, or part of it was not yours, say so plainly and return to "roughly £4M of influenced revenue". Say whether it is per year or across the four years only if you know. The pack names no method, baseline or attribution model | F3 is the headline figure and the recruiter says Ross will push on commercials; EXP because it tests whether the claim survives scrutiny |
| C2 | "How much of the six-to-forty growth was actually you?" | EXP | [grounded] "took it from 6 partners to 40"; "running the ISV channel" | Hold what the quotes carry: "I ran the ISV channel and took it from 6 partners to 40." Answer slot: if you personally brought in or onboarded some of those partners, say how many and how you know, in your own words; if the growth came through others or other routes, or you do not have the split, say so plainly and return to running the channel. Name the assumption you would defend least | F1's growth figure is the second magnet for a prober; EXP because it is an attribution probe |
| C3 | "Walk me through the commercial case you would put to an operator for a partnership with us. What numbers do we need to see before we commit?" | CASE | [generic] | Clarify first: what the partnership costs Kelverton to serve, what the operator would otherwise do, and what each side gets. Name the few numbers you would need before committing a view, and commit to a range only afterwards, saying you want their actuals. Offer to build it with Ross's team. No claim about your past; the pack supplies no pricing or terms | The recruiter says Ross will push on commercials, and this is the live form of that push; CASE because it asks for structure on a live problem |
| C4 | "Influenced revenue isn't revenue you were accountable for. Why should a commercial director give it any weight?" | EXP | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue" | Hold, then concede. Hold: "The number I can give is roughly £4M of influenced revenue." Concede specifically: "I haven't carried a direct quota." Answer slot: if you can say what the influence consisted of, in your own words, say it; if you cannot trace it, or it was not yours to claim, say so plainly and return to the figure at its own scope. Never convert influenced into closed | F3 and F4 meet here, and a commercial director will say it out loud; EXP because it tests attribution honesty |

### D. Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, over a candidate who has sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "took it from 6 partners to 40"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause, restate the question, anchor in what you stated. Hold: "I ran the ISV channel and took it from 6 partners to 40." "I spent five years in transport consulting, on bus and light rail network planning." Concede specifically: "I haven't sold into rail specifically." Do not claim to be better; say what you bring and what you lack. Hold through two follow-ups, and never fold on the core claim just to restore harmony | F5 is the absence this question presses; JD because it scores the fit against the role |
| D2 | "That £4M — how much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Expect an interruption halfway through. Pause and restate. Answer slot: say what part was yours, and how you know, in your own words; if you cannot separate it, or it was largely others', say so plainly and return to the figure as influenced revenue. Hold through the second follow-up | The same figure as C1 in a stress register (F3); EXP because it tests attribution under pressure |
| D3 | "Your plan assumes we can staff this. We can't. What changes?" | CASE | [generic] | Do not fold, and do not defend the plan out of habit. Restate the constraint, concede it specifically, then show what you would drop first and what you would protect, using your anti-pick from section 3. Say what you would need to know to size it properly. No claim about your past | A time-boxed challenge to the POV itself, which A1 makes likely; CASE because it asks for live re-planning |

### E. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and commercial sit side by side here. Where is the seam, and what happens when we disagree about a deal?" | JD | [generic] | Propose seam principles rather than pretending to know the seam, and lead with what you bring his team. Selection scaffold for the disagreement: pick a time you disagreed with someone on the commercial side about a partner deal; it needs a named stake, what each of you wanted, and an intact working relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Ross sits on the commercial side of the seam; JD because it scores the role's working boundary |
| E2 | "Tell me about a time credit for a result was shared across teams. How did you handle it?" | EXP | [generic] | Selection scaffold: pick a time the credit for a result was split or contested, with a named stake, what you did, and how the relationship ended. "We" for context, "I" for your own contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer-evaluator stem, made likelier by a figure labeled influenced (F3); EXP because it scores attribution with colleagues |

### F. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40"; "9 years in partnerships" | A 90-second arc, in order: five years in transport consulting on bus and light rail network planning, then the last four at a payments company running the ISV channel, where "I took it from 6 partners to 40". Your reasons for this move are yours to add. Answer slot: your message gives nine years in partnerships and does not say how they fit with the five and the four. If the nine includes the consulting years, say so; if the consulting years were not partnerships work, say so plainly and stay with the nine as you gave it | The opener is near-certain and is scored (F1, F2, F6); EXP because it tests whether the story hangs together |
| F2 | "You said you know the operator world from the other side. What did that give you?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say the work first: five years in transport consulting, on bus and light rail network planning. Answer slot: your message says "the other side" and does not say which side. Say plainly which side of the table you sat on and what you saw from it, in your own words; if the work gave you little sight of operators' own decisions, say so and stay with the network planning. Do not claim operator relationships | Casual-register, but it tests F2 directly; EXP because it scores whether the claim survives a follow-up |

### G. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told a senior person something they did not want to hear; it needs a named stake, the moment you did not soften it, and an intact relationship at the end. "We" for context, "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values stem, low weight because no values round is detected; VAL because it scores behavior against a value |
| G2 | "When did you put a partner's interest ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a partner's outcome and an internal number pulled apart; it needs the two in tension, what you chose, and what it cost. Where the hard truth did not land, say so rather than supplying an ending. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Echoes the recruiter's operator-first close; VAL because it scores behavior, and low weight for the same reason as G1 |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" (F1) | A1, A2, A3, A4, D3, B4; section 3 |
| "Please land on what it means for the operators themselves" (F2) | A1, A5, F2; section 3 |
| "Ross will push on commercials" (F3) | C1, C2, C3, C4, D2, E2 |
| Carry a commercial number for partner revenue, generic (F4) | B1, B3, C4 |
| Selling into or partnering with rail operators, generic (F5) | B1, B2, D1 |
| "Senior Partnerships Manager" (F6) | F1, B3 |
| Headline figures: £4M and 6-to-40 | C1, D2, C2 |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To Deepa: "What would you want to be true about operator partnerships at the end of my first six months?" | Turns the interview into a shared definition of success and hands you a 90-day frame |
| R2 | To Deepa: "Where would you want a hire who hasn't sold into rail to ramp fastest?" | Draws on F5, "Never sold into rail specifically": invites her to name the gap with you instead of testing it |
| R3 | To Ross: "What does a good commercial case for a partnership look like to you, and where do they usually go wrong?" | He pushes on commercials; asking for his standard signals that you want to meet it |
| R4 | To Ross, reciprocity: "What could a new person in this role do in their first month that would genuinely help your team?" | Frames you as reducing his load, which is what a commercial counterpart is pricing |
| R5 | To both: "When Partnerships and Commercial disagree about a deal, what usually decides it?" | Shows you understand the seam (E1) before you are in it |
| R6 | To both: "Which operator partnership are you proudest of, and what did it look like from the operator's side?" | Rehearses your POV close and tells you what the panel counts as a win |

## 8. Prohibited claims

Built locally from the fit snapshot before the banks; none of these is coached, asserted, softened or implied anywhere in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or to train operating companies | Negative the candidate stated, F5 | "I haven't sold into rail specifically." No slot |
| Carried a revenue target or quota | Negative the candidate stated, F4 | "I haven't carried a direct quota; my number was influenced revenue." No slot |
| Closed or generated £4M of revenue | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The pack's observation: your material says influenced revenue and nothing about how it was counted. C1 and D2 stay inside the quote |
| Built the ISV channel from nothing | A claim F1's quote contradicts | "took it from 6 partners to 40", and nothing more |
| Brought in all the new partners yourself | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says the channel grew, not who brought in each partner. C2 stays inside the quote |
| Planned train operators' networks, or worked inside a train operator | Inflated form of F2 | F2's quote at its own scope: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". The pack's observation: your material says bus and light rail network planning. F2's slot stays inside the quote |

## 9. Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report you said was attached to the recruiter's email was not in my context, so nothing in this pack draws on it. No dossier was present.

| Query | Outcome |
|---|---|
| Kelverton Rail company values | refused |
| Kelverton Rail interview process partnerships manager | refused |
| Kelverton Rail strategy scheduling software train operating companies news | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager rail technology software job description train operating companies UK | refused |

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Every call was refused. Would have moved the values cheat sheet if a values-style round were detected, and VAL themes |
| 2. Kelverton Rail interview process, partnerships | unavailable | Every call was refused. Would have moved loop structure and persona weights, which now rest on the recruiter's email and relationship priors |
| 3. Kelverton Rail strategy and recent news | unavailable | Every call was refused. Would have moved A4 and A5 from generic to grounded, and enabled a grounding brief |
| 4. Interviewer names with Kelverton Rail | unavailable | Both calls (Deepa, Ross) were refused. Would have moved the interviewer read and persona weights, and a reverse question tied to their paths |
| 5. Representative Senior Partnerships Manager JD | unavailable | The call was refused. Would have moved the requirement column of the fit snapshot and the JD-tagged questions, as inferred rows |

## 10. Upgrade menu

- The JD text → the role-family rows F4 and F5 and the title row F6 become quoted JD requirements, the coverage table gains a row per stated requirement, and any gate term (location, travel, schedule, pay, authorization) gets checked, since none is established now
- The market report pasted, or its headline findings → the section 3 worksheet (consensus item, divergence, anti-pick) is filled from the source, A4 and A5 become grounded, and a grounding brief section is added
- Web research on Kelverton Rail (searches were not permitted this session) → values and any values-style round, documented loop structure, current strategy, and the five targets above, which would turn the generic CO and CASE rows into grounded ones
- Interviewers' surnames or public profile links → a reading-the-interviewer section, persona weights from their public footprint, and a reverse question tied to their own paths
- Ross's place in the structure, reporting to Deepa or alongside her → reweights Pressure against Peer Evaluator and retunes D and E
- Your answers to the slots, outside a drill → each becomes quoted evidence and upgrades the rows it touches: how the £4M was counted and which part was yours (F3, C1, C2, D2), which side of the table you sat on (F2, F2 question), and how the nine years and the five fit (F6, F1)
- The recruiter's reply to one email asking what "operator partnerships" covers and whether the report is expected as background → sharpens the POV's frame and the first line of A1
- A `tuesday-dossier.md` from an earlier role-fit check → verified evidence and absolute prohibited claims, which would replace the locally built list in section 8
