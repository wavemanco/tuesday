Web search was refused in this session, so I'm building the pack from what you gave me alone. I'm writing it now.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-1-denied-da858a82/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

I built it for a peer conversation with Dan Kovac, 60 minutes, with no deliverable assumed. All four web searches were refused (company values, interview process, strategy, and Dan's public footprint). So company facts come only from your research note, which is undated. Nothing about Dan comes from outside your description of his profile.

The pack has 23 questions across seven personas, led by the Data-Driven Prober and the Peer Evaluator. It also has the fit snapshot, a requirement-coverage table, six reverse questions, the prohibited claims, and the upgrade menu.

- **Highest-ROI rehearsal:** D1, "You haven't done classic sales-ops or quota-setting work." It opens with the concession in your note's own words and carries three follow-ups.
- **The $400M figure:** it is credited to a proposal, so A1 and F2 rehearse "proposed, and credited with" and do not claim she delivered it.
- **Partner-motion design:** the evidence is a revenue model used in carrier negotiations, which is not the same as designing a partner motion. D3 stays inside that scope.
- **No values questions grounded in published values:** no values-style round is documented anywhere in what you gave me, so G1 and G2 are generic.

Say the word and I'll play Dan on D1, the pack's highest-ROI question. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two things would restructure it:
1. Did the recruiter say what Dan will focus on, or ask Priya to bring anything, such as a POV, a presentation or a case? A deliverable would add its own graded build section.
2. Can you paste the full JD text and Priya's CV lines? With them, the pack's quotes come from her CV, and mid-list JD requirements get questions. Without them, the pack stands as is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind. **Relationship:** peer, both reporting to the same VP. **Round:** one 60-minute conversation. **Built on:** your notes only (no web research ran), so company facts come from your research note, whose date is not shown.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge, and thinking at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

**Highest-ROI prep in this pack: D1.** It is the question most likely to be asked in some form, so rehearse it until it is boring. Then A1 and F2, the number defenses.

Answer slots (instructions that begin "Answer slot") are for the interview, not for this chat. Meet them with either honest branch.

## Fit snapshot

Requirements are quoted from the JD highlights in the coach's notes. They are highlights, not the full JD, so mid-list requirements may be missing.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, the coach's notes | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material shows product strategy and ops work and a proposal that was credited with an ARR uplift, nothing inspected behind either. The words stay at that scope: "I spent nine years in product strategy and ops at a large consumer-tech company, and I proposed a change that was credited with a ~$400M ARR uplift." Answer slot: the JD's own-the-GTM line makes a probe on go-to-market work likely. If any of your work set how a product reached customers, say which part and what was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, the coach's notes | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The quote touches ARR but does not show whether it reaches land, adopt, expand or renew work. Answer slot: if any of your work looked at where customers or partners stood across those stages, say what it was and which part was yours; if none did, say so plainly and say how you would cut the four stages first |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, the coach's notes | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: "I'm skilled in SQL and Tableau." Nothing is inspected behind it, so expect a probe, rehearsed at A3. The quote says skill; it does not say which analyses were yours |
| F4 | "partner-motion design experience required" — JD highlights, the coach's notes | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The words stay at the quote: "I built a partner-level revenue model that was used in carrier negotiations." Your material shows a model used in negotiations, not the design of a partner motion. Any wider step is an answer slot inside the model's scope, worked at D3 |
| F5 | "strong cross-functional influence" — JD highlights, the coach's notes | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: "I set annual volume targets with cross-org consensus." Nothing inspected, so expect a probe on how the consensus came about, rehearsed at A5 and B1. Your material says volume targets, not quotas |
| F6 | "AI experience a plus" — JD highlights, the coach's notes | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | No gap on the plus, but the quote states daily use of AI tools and nothing more, so say it in those terms. Your material does not show AI product work |
| F7 | Sales-ops and quota-setting experience — no JD quote; raised by your own note | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it has been stated. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (bank A) | Asks how each CV number was counted, two follow-ups deep | High. Peer round priors favor it, and the profile self-description "relentlessly data-driven" pushes it to the top | Know what you can and cannot say about how each figure was counted; say plainly when you do not know; name the weakest assumption before he does |
| Peer Evaluator (bank B) | Seam-splitting between his team and the new role, credit, "what do you need from me" | High. Peer is the relationship prior, and the shared VP makes the seam a live question | Reciprocity framing; propose seam principles instead of pretending to know the seam; disagreement shown with spine and tact |
| Case/Strategist (bank C) | Live problems on the two product lines, bundling, pricing, spend | Medium-high. The role is built around GTM strategy, and a pricing and monetization career spine tilts cases toward pricing, packaging and unit economics | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (bank D) | Quiet probing of the sales-ops and quota gap, the partner-motion requirement, and why this move | Medium. Your own note states the sales-ops gap, and he works in sales strategy | Rehearse D1 until boring; bridge only from what your quotes carry; concede the limit before it is asked |
| Conversational (bank E) | Friendly biography and "what are you playing with in AI" | Low-medium. Peers open warmly, and AI is a JD plus | A 90-second arc; treat the casual questions as scored |
| Pressure (bank F) | Time-boxed "why you" and "how much was you" | Low. Nothing signals a stress format, but his self-described rigor makes a compressed challenge plausible | Pause, restate, anchor in your own sentences, hold through two follow-ups before conceding anything real |
| Values/Behavioral (bank G) | Scenario stories on candor and customer focus | Low. The one conversation you described is with a peer, and no values-style round is documented in anything provided | Choose stories where the hard truth actually landed; if none comes to mind, say so |

## Reading the interviewer

Signals come from the profile as you described it. Public professional footprint only.

| Signal (per the coach's notes) | Practical implication | Provenance |
|---|---|---|
| Self-described "relentlessly data-driven" | Expect every number to be taken to its assumptions; banks A and F2 are built for it | [inferred] |
| Career spine in pricing and monetization | Expect cases framed as pricing, packaging and unit economics (C3, C4); his vocabulary is revenue and margin, so state your framework aloud | [inferred] |
| One early-stage-startup chapter | A builder story may land well, and a probe on pace or scrappiness is possible; your material carries no startup story, so do not reach for one | [inferred] |
| Peer reporting to the same VP | He is pricing what you would cost and contribute to his work; B3 and R2 are the reciprocity answers | [inferred] |

Mirror opportunity: his pricing and monetization spine and F4's evidence share revenue-model vocabulary: "built a partner-level revenue model used in carrier negotiations". Use it as common language, not as a claim of pricing experience. His startup chapter has no counterpart in F1 to F7's evidence, so it is not offered as a shared path.

## Question banks

Provenance quotes are the sentences the guidance rests on. A cell with a label alone makes no claim about your past.

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open in the sentence's own terms: you proposed the change, and it was credited with a ~$400M ARR uplift. Then the four slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly and return to what you proposed. Name the weakest assumption before he does | F1 and F2 carry the headline figure, and a self-described data-driven interviewer goes to it first; EXP because it tests what was counted and what was yours |
| A2 | "Walk me through the partner-level revenue model that was used in carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the quote says: you built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: expect follow-ups on the model; answer each in your own words from what you did, and where a follow-up asks about a step you did not take or that was not yours, say so plainly and return to the sentence. Do not describe inputs or outcomes you could not repeat under a second question | F4 is the evidence for the partner requirement, and a model is exactly what a prober asks to open; EXP because it tests what was built versus used |
| A3 | "Tell me about an analysis you ran yourself in SQL, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | Your sentence says skill, not a specific analysis, so this is selection: pick one analysis you can tell end to end, naming the question, the data, the answer and what changed because of it. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one. Offer to walk through it in full | F3 mirrors the JD's independent-analysis line, and the quote is a skill claim with nothing inspected; JD because it scores the stated requirement |
| A4 | "Land-to-adopt conversion looks flat while expansion revenue is growing. What would you pull first?" | CASE | [generic] | Clarify definitions first: what counts as land, adopt and expand, and over what window. State a hypothesis, then the cuts you would run (cohort, segment, product, partner versus direct), the table or field each needs, and the result that would change your mind. Think aloud. The question needs no claim about your past, so the guidance makes none | A live data problem from the JD's land/adopt/expand/renew line (F2, F3); CASE because it is a diagnosis delivered live; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A5 | "Walk me through how the annual volume targets were set." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Say what the sentence says: you set annual volume targets, with cross-org consensus. Answer slot: expect follow-ups on how the numbers were reached and who had to agree; answer in your own words from what you did, and if a step was not yours or did not exist, say so plainly and return to the sentence. Do not call them quotas: your material says volume targets | F5 is where a sales-strategy peer will test the nearest thing your material has to target-setting; EXP because it separates what you did from what was done around you |

### B. Peer Evaluator (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between us, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose seam principles instead of claiming to know the seam: who owns the number, who owns the customer motion, who breaks ties; then ask what his team owns today. For disagreement, anchor in the sentence: you set annual volume targets with cross-org consensus. Answer slot: if reaching consensus involved a disagreement, say what it was and what you did, in your own words; if it did not, or was not yours, say so plainly and stay with the sentence | F5 is the cross-functional evidence and the seam is where it presses; JD because it scores the stated influence requirement |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | "We" for context, "I" for contribution. Use the sentence's own verbs: you proposed the change, and it was credited with the uplift. Answer slot: if others shaped the idea or its results, name what they did; if you do not know who else did, say so plainly and return to the proposal | F1 and F2 carry a credited figure, so credit is a natural collegial probe; EXP because it tests attribution honesty |
| B3 | "What would you need from my team in your first sixty days, and what would you bring us?" | JD | [grounded] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | Lead with reciprocity. What you bring, in the quotes' own words: skilled in SQL/Tableau, and a partner-level revenue model used in carrier negotiations. Then what you would ask for, as a plan: the funnel definitions and the data behind them, and how his team's targets are set today. Never imply you would take over any of his work | A peer is pricing the hire's load on his own team (F3, F4); JD because it scores working fit with the listed role |
| B4 | "Two new product lines want the same field attention this quarter. How do you decide whose motion gets priority, and what do I do with my team's targets?" | CASE | [generic] | Clarify first: what the two lines are and what the field can carry. Then criteria (stated priority, readiness, margin, partner dependency), a recommendation, and how a disagreement between our teams resolves: data first, then a shared recommendation to the VP you both report to. Challenge one premise, such as whether the choice is binary. No claim about your past | A live seam problem from the JD's two-lines requirement (F1); CASE because it is a decision delivered live |
| B5 | "Compass is the AI copilot launch. Where do you want my team's help, and where would you stay out?" | CO | [grounded] research note: Compass, the AI copilot launch | Do not pretend to know the seam: propose principles (who owns launch targets, who owns the customer motion), then ask where his team is already in it. Ask him what the sales motion for an AI copilot needs that existing products do not. Never claim AI product work (see the prohibited list) | The research note names Compass as a priority, and the peer's own stake is how it is sold (F6); CO because it needs the company's current strategy, labeled grounded on your note, whose date is unknown |

### C. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A new product line is launching into enterprise accounts, and a much larger vendor is bundling a comparable capability. Sketch the GTM plan. What do you need to know first?" | JD | [grounded] research note: enterprise expansion, bundling by a much larger platform vendor | Clarify before structuring: which line, which buyer, what the existing install base looks like. Then objective, segmentation, motion (direct, partner or both), metrics across land, adopt, expand and renew, and the bundling risk. Think aloud and challenge one premise. No claim about your past; if asked what you have launched, answer from F1's sentences only | This is the JD's two-lines requirement (F1) set against both stated priorities and the named threat; JD content with CASE delivery |
| C2 | "Where would you look for whitespace across land, adopt, expand and renew for a new data-infrastructure product, and how would you size it?" | JD | [generic] | State the four stages in your own words, then where whitespace typically hides (unadopted seats or products inside landed accounts, expansion ahead of renewal), the data you would need, and a sizing logic you can defend aloud with its weakest assumption named. Say what you would ask for before trusting any size | F2's requirement, asked as a method; `[generic]` because it is a pattern, and the candidate's material does not show this work |
| C3 | "The much larger vendor is bundling a comparable capability. Do you price our AI copilot as a standalone add-on or package it into existing tiers? How do you decide?" | CASE | [grounded] research note: AI copilot, bundling threat, profitability priority | Clarify who pays and what the copilot costs to serve, then lay out both options against expansion upside, margin and cannibalization, and say what you would test first. Your material does not show pricing work, so reason aloud rather than borrowing his vocabulary as experience. Concede what you would need to learn from the data | A pricing-and-packaging case matches his monetization spine (reading above); CASE because it is a live trade-off; it ties the copilot launch to the profitability priority |
| C4 | "Profitability is a stated priority, and two new lines need investment. How would you decide where GTM spend goes first?" | CO | [grounded] research note: reaching profitability, enterprise expansion | He knows the stated priorities, so bring one to prove grounding, then a judgment with reasons: the criteria you would use, the payback question you would ask, what you would defer. State the weakest assumption in your own recommendation | The profitability priority collides with two new lines (F1); CO because it needs company-level trade-offs, and it is a divergence question, not a recital of the shared note |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales-ops or quota-setting work. Which part of this role would be weakest on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI prep.** Pause, then concede first, in these words: "I haven't had classic sales-ops or quota-setting experience." Name the limit before he asks for it: your material says volume targets, not quotas, so do not call the two equivalent. Then what your quotes carry, at their scope: you set annual volume targets with cross-org consensus, and you built a partner-level revenue model that was used in carrier negotiations. Close with a plan, not a past: what you would learn first and from whom. Follow-up 1, "How would you set expansion targets for a new line?": answer as an approach and ask what data exists, never as something you have done. Follow-up 2, "Why not hire someone who has?": hold, return to the two sentences, concede the specific limit, no disparaging of that candidate. Follow-up 3, "What would you get wrong in your first quarter?": name the stated gap and how you would shorten it. Hold through two follow-ups by returning to the sentences, never by adding to them | F7 is the biggest gap and sits in a peer's home territory, so some form of this question is the most predictable in the loop; JD because it scores the role's own requirement, with a Skeptic's delivery |
| D2 | "Why leave nine years at a large consumer-tech company for Northwind, and why now?" | CO | [grounded] "9 at a large consumer-tech company in product strategy & ops" | A motivation only you have, so selection not script: what pulls you toward B2B data infrastructure, one Northwind priority from your note that makes this role matter to you (enterprise expansion, Compass or profitability), and what the next role lets you do. Keep it consistent with what you told the recruiter. If the real reason is less tidy, say the true part plainly | The move from consumer tech to a B2B data vendor is the standing motivation probe (F1); CO because the "why here" needs company homework |
| D3 | "The role asks for partner-motion design experience. What have you designed, and what would you design here?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say the sentence: you built a partner-level revenue model that was used in carrier negotiations. Answer slot: if the model shaped how the partner relationship was structured, say how, in your own words; if the work was the model and not the motion, or the structure was not yours, say so plainly and stay with the model. For the second half, a plan: who the partners would be, the economics, who sells, who supports. Never describe a designed motion you did not build | F4 is the partner-motion evidence and the JD marks it required; JD because it scores a hard stated requirement, probed by a Skeptic |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops"; "proposed a store-surface change credited with a ~$400M ARR uplift"; "built a partner-level revenue model used in carrier negotiations" | A 90-second arc, in the quotes' own terms: two years in strategy consulting at a top firm; nine years at a large consumer-tech company in product strategy and ops; within that, a proposal credited with a ~$400M ARR uplift and a partner-level revenue model used in carrier negotiations. Then why this role, in your own words. End there, not on a list | The opener that is still scored; EXP because it tests whether the CV story hangs together |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it in those terms: you use AI tools daily. Answer slot: name the tools and what you use them for, in your own words; if you use them as a user and have not built anything with them, say so plainly, since that is the honest scope. Turn it into a question for him: what does selling an AI copilot need from the motion | The JD's AI plus asked casually (F6); JD because it scores a stated plus |

### F. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has carried a quota?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | Pause and restate the question. Concede first in the D1 words: "I haven't had classic sales-ops or quota-setting experience." Then the two sentences at their scope, and what you would bring a peer in a plan. Hold through two follow-ups by returning to the quotes, concede only the limit you named, never fold on the core claim | D1 compressed into a time box (F7); JD because it scores fit to the role, with a Pressure delivery |
| F2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold first: you proposed the change, and it was credited with a ~$400M ARR uplift. Concede specifically: the sentence says credited, not that you delivered it. Answer slot: which parts beyond the proposal, if any, were yours; if none, say so plainly and stay with the proposal. Hold through two follow-ups; do not widen the claim to make the number feel safer | F1 and F2 carry the figure and the attribution probe exists to catch inflation; EXP because it tests what was actually yours |

### G. Values/Behavioral (2)

No values-style round is documented in anything provided, and the company's published values were not available, so these are themed from the persona stems and carry no mapped story.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | No sentence in your material carries this story, so select one: it needs a named stake, the message itself, how it was received and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Candor with leadership matters to a peer who shares a VP; `[generic]` because no published value was available to anchor it |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Select a time you can name: the metric, what it cost, who decided and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A customer-versus-metric trade-off is the standing values probe for a GTM role; `[generic]` for the same reason |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "own GTM strategy for two new product lines" | C1, C4, B4 |
| "identify whitespace across land/adopt/expand/renew" | C2, A4 |
| "run independent analysis in SQL and Tableau" | A3, A4 |
| "partner-motion design experience required" | D3, A2 |
| "strong cross-functional influence" | B1, B2, B3 |
| "AI experience a plus" | E2, B5, C3 |
| Sales-ops and quota-setting (not a JD quote; raised by your note) | D1, F1, A5 |
| Mid-list JD requirements beyond the highlights | none, and why: the highlights you gave are all the pack has seen |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has run through pricing and monetization with one early-stage chapter. What did the startup chapter change about how you think about GTM here?" | Ties to his own public path and turns the exchange into a peer conversation |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it signals you are thinking about his load |
| R3 | "For the two new lines, where does your team's work end and this role's begin, and where do you expect friction?" | Surfaces the seam so you can propose principles instead of guessing |
| R4 | "How is success defined in year one for the two lines: adoption, expansion or profitability, and who decides the trade-off?" | Ties to the three stated priorities and tests what the VP is actually measuring |
| R5 | "Which land, adopt, expand and renew data do you trust today, and where are the holes?" | Speaks to a data-driven peer in his own register |
| R6 | "How is the bundling pressure showing up in deals today, and what has your team already tried?" | Shows you took the competitive threat seriously and asks for his evidence, not a recital |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has quota-setting or classic sales-ops experience | Negative the candidate stated, F7: "No classic sales-ops or quota-setting experience" | The plain acknowledgment: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Treated the annual volume targets as quotas | Inflated form of F5 | F5's quote at its own scope: "set annual volume targets with cross-org consensus". The limit is the pack's observation: the material says volume targets, not quotas |
| Drove or delivered the ~$400M ARR uplift | Inflated form of F1 and F2's quote | The quote at its own scope: proposed, and credited with the uplift. The limit is the pack's observation: the material says proposed and credited, not delivered. F2's slot stays inside the proposal |
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope: a revenue model used in carrier negotiations. D3's slot stays inside the model |
| Owned or launched GTM for a product line | Inflated form of F1 | F1's quotes at their own scope. A probe on go-to-market work stays an answer slot |
| Built or launched an AI product, or Compass-type work | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily" |

## Sources

Provided: your message (role and JD highlights, candidate summary, interviewer profile summary, research note on priorities and the competitive threat). The research note is undated. No dossier was present. The loop comes from your own words: one 60-minute conversation with Dan.

Searches sent, all refused, nothing returned: "Northwind Data company values"; "Northwind Data interview process strategy GTM"; "Northwind Data strategy Compass AI copilot news"; "Dan Kovac Northwind Data Director Sales Strategy".

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Search refused. Would have moved VAL themes and a values cheat sheet if a values-style round were documented |
| 2. `Northwind Data interview process GTM` | unavailable | Search refused. Persona weights rest on your stated loop and relationship priors, not a documented process |
| 3. `Northwind Data strategy` / recent news | unavailable | Search refused. CO and CASE questions rest on your undated note, and no grounding brief could be built |
| 4. `Dan Kovac Northwind Data` | unavailable | Search refused. The interviewer read rests on your description of his profile, with no talks or writing checked |
| 5. representative Senior GTM Strategy Lead JD | skipped | Your JD highlights fix the fit snapshot rows; requirements beyond them are an upgrade-menu item |

## Upgrade menu

- Search permission granted → the L1 pass runs (up to 6 searches and 2 fetches): official values, documented loop, a current strategy sweep and Dan's public footprint, which would also sharpen R1 and the CO bank
- A deeper research pass afterwards (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief, his talks and writing, role-family loop reports and recent org context; this is the one offer of it
- The full JD text → the highlight rows become fully grounded, and mid-list requirements get questions or a stated reason they do not
- Her CV lines in place of the coach's notes → every evidence cell quotes her CV, and the defend-the-number slots can be tightened; for the ARR figure, the artifact that would raise confidence from medium is whatever document records how the ~$400M was credited, if one exists
- Her answers to the answer slots at F1, F2, F4, A1, A2, A5, D1 and D3, stated outside a drill → those rows regenerate on her real material
- The recruiter's prep email → any pre-declared deliverable gets its own build section, and stated focus areas replace the round-type priors
- A dated strategy brief → a grounding-brief section and sharper CO and CASE questions
- Prep time available → a prioritized prep schedule
- A prior tuesday-dossier.md → verified evidence, a named top objection and prohibited claims arrive pre-built; the pack is complete without one
