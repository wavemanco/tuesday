Web searches were refused by the host, so I'm building the pack from what you've given me. I'm writing it now.
Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md` in the working directory. It has 20 questions across six personas, a build section for the 15-minute POV, and a four-hour prep schedule.

I built it for a two-person panel: Deepa as your future manager, and Ross pressing on commercials. Three gaps limit it:
- **Job description:** I didn't have it, so the requirements rest on the recruiter's wording and are labeled as such.
- **Market report:** its content wasn't in our conversation, so the POV's "cite one consensus item, then one departure, plus the anti-pick" structure is in the pack but can't yet name your actual picks.
- **Research:** the host refused all five web searches, so nothing comes from outside your message, and the pack says so.

The pack names C1 as the highest-ROI prep. The question is "You've never sold into rail. Why should we believe you can do this here?" Say the limit in your first sentence, using your own words about never having sold into rail. Then give the five years of bus and light rail planning at its own scope. The next most important are the no-quota question (C4) and the "how was the £4M counted" question (B1). The pack stays at "influenced revenue" and never lets it become "generated". It also doesn't claim knowledge of train operating companies, since your material says bus and light rail.

Say the word and I'll play the Skeptic on C1, live. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions, or convert the pack to Word.

1. Can you paste the job description and your CV? They would turn the role-family rows into quoted requirements, and would add evidence beyond your message.
2. Can you paste the report's headline recommendations on operators? That would let me name your consensus item and your departure, instead of leaving them as slots.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday, one 60-minute panel. The recruiter's own words, quoted in your message, set the shape: a 15-minute spoken POV with no slides, then Q&A where "Ross will push on commercials".
**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director).
**Built from:** your message only. No job description, no CV and no market report text were in hand, and every web search was refused by the host (see Sources). Requirements therefore rest on the recruiter's wording and on role-family patterns, labeled as such.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding to rehearse from, not a script: where it says answer slot, the answer has to come from your own experience, in your own words.

| Type | What it scores |
|---|---|
| VAL | Past behavior against the company's published values |
| EXP | Whether your claims survive scrutiny: what you actually did |
| JD | The stated role, including its gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, structured aloud |

## Prep triage (about 4 hours, spread over the weekend)

| Order | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 75 min | Build the 15-minute POV: pick one thesis, write the operator close first, then speak it aloud twice against a timer | Graded deliverable below; A1 to A5 |
| 2 | 30 min | Re-read the report with one job: choose one consensus item to cite, one place you depart, one thing you would not do | Graded deliverable below; A2, A3 |
| 3 | 45 min | Say the four objection answers aloud until they are boring: rail, ISV-versus-operator, no quota, why you | C1, C2, C4, D1 |
| 4 | 30 min | Write, on paper, what you know about how the £4M and the 6 to 40 were counted, and what you do not | B1, B2, B3, G2 |
| 5 | 30 min | One full timed dry run: POV, then C1 and B1 cold | All of the above |

Everything else in this pack is insurance. About 30 minutes is slack; spend it on the order-1 build, not on more questions.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Adjacent work, not operator partnerships, and the words stay at the channel: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the POV is about operator partnerships, so expect a probe on what carries over from ISV partners. If any part of how you grew the channel applies, say which and why, in your own words; if none of it maps, or you have not worked it out yet, say so plainly and stay with the channel as you ran it |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email, quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies. Words: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: if any of that work was with or for train operators, say what it was; if it was bus and light rail only, say so plainly and stay there |
| F3 | "Ross will push on commercials" — recruiter's email, quoted in your message | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure keeps its noun: "roughly £4M of influenced revenue". Nothing inspected sits behind it, so expect it to be probed. Answer slot: say how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours; if you do not know how it was counted, say so plainly |
| F4 | Owning a direct revenue number (role-family expectation, no source supplied) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota — only influenced revenue." Then how you would approach a number, said as a plan and never as a past |
| F5 | Selling into rail (role-family expectation, no source supplied) | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then F2's quote at its own scope, and how you would learn the rest, said as a plan |
| F6 | Building and scaling a partner channel (role-family expectation, no source supplied) | "took it from 6 partners to 40" — your message | medium | [grounded] | none | No gap, but nothing inspected behind it, so expect a probe on what counted as a partner. Lead with the figures in the quote's own terms: you ran the channel and took it from 6 to 40 |

## Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded: "present a short POV on where you'd take our operator partnerships over the next 18 months", landing on "what it means for the operators themselves".

**Grounded facts you may say about yourself.** Nothing else about your past goes in the POV.

| Fit row | Sentence you may rest on, quoted |
|---|---|
| F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel" |
| F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" |
| F6 | "took it from 6 partners to 40" |

**Thesis options.** Pick one. All three are patterns to test against the report you have read, not claims about Kelverton or the operator market.

| Thesis | What you would argue | Mandatory concession | What it means for operators (the close) | Provenance |
|---|---|---|---|---|
| T1 Depth before breadth | Work closely with a small number of operators first and let their needs shape the partner roadmap, instead of widening coverage | Slower reach; and you cannot yet say how many operators Kelverton already works with | Say what an operator gets from being in the small group, in the report's own terms for what operators need | [generic] |
| T2 Partners extend the core | Third-party partners extend what operators get from the scheduling product without Kelverton building every piece, the ISV-channel pattern applied to operators | You have run an ISV channel, not an operator one; and partner-led scale puts integration work in front of operators | Say what an operator would no longer have to build, buy or wait for, using the report's terms | [generic] |
| T3 Commercial shape follows operator outcomes | Structure partner arrangements so Kelverton and partners both benefit when the operator's result improves | You have never carried a direct quota, and you have not seen Kelverton's current terms | Say what an operator is better off by under such terms, in the report's terms | [generic] |

**Differentiation from the report.** The report was circulated to Kelverton's strategy team, so Deepa and Ross will know it and any prepared candidate will have read it. Reciting its shortlist scores as homework. Cite one consensus item, once, to show you read it. Then give one thesis-driven departure, with your reason. Then give the anti-pick: the thing a Senior Partnerships Manager here should say no to in the next 18 months. This pack has not seen the report, so it cannot name your consensus item or your departure; the upgrade menu says what would change that.

**Shape of the 15 minutes.**

| Minutes | Beat | Provenance |
|---|---|---|
| 0 to 1 | Frame: the question you are answering and your one-sentence thesis | [generic] |
| 1 to 3 | Where you start: one consensus item from the report, cited once, plus F1 and F2 said at their own scope | [grounded] |
| 3 to 9 | The thesis, three moves over 18 months, each with what you would measure | [generic] |
| 9 to 12 | The close: what it means for the operators themselves, said from the operator's side, ahead of the risks | [generic] |
| 12 to 14 | Your concession and the anti-pick | [generic] |
| 14 to 15 | What you would want to learn in your first 90 days, handing the room to Q&A | [generic] |

Land on operators before the risks, because the recruiter asked you to land there and the last thing you say is what they will remember.

## Persona table

Panel prior: Deepa is your future manager, so the hiring-manager prior (Case/Strategist plus Skeptic) applies. Ross is the commercial voice and the recruiter says he will push, so Prober plus Pressure. Panel rule: blend the top two of each member. The loop is one session whose shape the recruiter's own words establish, with no values round named.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Case/Strategist | Extends your POV into live problems: first 90 days, who you would not partner with | High: Deepa's prior, and a POV invites extension | Clarify, structure aloud, challenge one premise respectfully |
| B Data-Driven Prober | Takes your £4M and 6 to 40 to their assumptions | High: Ross "will push on commercials" and F3 is a figure | Know what you can and cannot say about how each number was counted; say so plainly when you do not know |
| C Skeptic | Quietly probes rail, the ISV-versus-operator jump, the missing quota | High: F4 and F5 are your own stated negatives, and the objection is predictable | Rehearse the single objection until it is boring; limit named first, then adjacent evidence |
| D Pressure | Time-boxes you, plays devil's advocate on commercials | Medium: a senior commercial voice, and the gaps give it material | Pause, restate, hold the position through two follow-ups, concede specifically |
| E Conversational | Friendly opener, "walk me through the journey" | Low: a 60-minute panel, but the opener is still scored | A 90-second arc built only from your own sentences |
| G Peer Evaluator | Seam between partnerships and commercial, credit on shared revenue | Low: Ross sits across the seam from your future team | Propose seam principles, not a map you cannot know; reciprocity framing |
| Values/Behavioral | Scenario probes against published values | Low, so no bank: the recruiter's email names no values round, and no values page was read | If asked, use a selection scaffold ending in its honest branch |

## Question banks

### A Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch your first 90 days on operator partnerships. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what the current partnerships are meant to achieve, and which operators Kelverton already works with. Then objective, which operators first, approach, how you would know it is working, risks. Think aloud. The question needs no claim about your past, so the guidance makes none | F1's requirement is forward-looking, so a live problem is the natural follow-up to the POV. CASE because it is asked as a problem |
| A2 | "You've read the report we sent. What did you take from it?" | CO | [grounded] raised by the recruiter attaching the report, per your message | Do not recite it. Name one consensus item once, then your one departure and the reason; both come from the report you have read, which this pack has not seen. The question needs no claim about your past, so the guidance makes none | The report is equally available to the panel and to rival candidates, so this is where differentiation shows. CO because it tests homework depth |
| A3 | "Where would you not partner in the next 18 months?" | CASE | [generic] | Name a category you would decline and the reason in operators' terms, then say what that choice costs. A clear no, with its cost, reads as judgment. The question needs no claim about your past, so the guidance makes none | The anti-pick is part of the POV build, and a manager hiring for judgment will probe it. CASE because it is a live choice |
| A4 | "Which operator would be hardest to persuade of your plan, and why?" | CASE | [generic] | Pick a type of operator rather than a named one unless the report names one, and reason only from what the report says operators need. Do not assert operator facts the report does not give. The question needs no claim about your past, so the guidance makes none | F2 is the row where the panel will test how far you can think from the operator's side. CASE because it is a live challenge |
| A5 | "In your plan, who is the partner and who is the customer?" | CO | [grounded] "they sell scheduling software to train operating companies" — your message | Ask which the panel means before answering, since the recruiter's phrase is "operator partnerships" and your message says Kelverton sells scheduling software to train operating companies. Then give your working definition aloud and say what a partnership would add beyond a sale. The question needs no claim about your past, so the guidance makes none | F1's requirement turns on this distinction, so a clarify here shows structure. CO because it tests how you read Kelverton's model |

### B Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the roughly £4M was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Story-mapped on F3, with only the beats the quote states: say the figure as you gave it, roughly £4M of influenced revenue. Answer slot: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, in your own words. If you do not know how it was counted, say so plainly; that beats a method you cannot repeat under a second question | F3 is a headline figure, which probers go to first, and Ross is the one expected to push on commercials. EXP because it tests attribution honesty |
| B2 | "How much of that influenced revenue was down to what you did?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold only what the quotes carry: you ran the ISV channel, took it from 6 partners to 40, and the revenue was influenced revenue. Answer slot: say which part was yours; if you cannot separate your part from others, say so plainly and return to the channel you ran | F3 and F1 together invite the attribution probe. EXP because it is a "how much was you" question |
| B3 | "What counted as a partner in the 40?" | EXP | [grounded] "took it from 6 partners to 40" | Say the 6 and the 40 as you gave them. Answer slot: say how a partner was counted, in your own words; if you do not know, or there was no fixed definition, say so plainly and stay with the 6 and the 40 | F6 is where scale claims get tested, since a count depends on its definition. EXP because it tests whether you know your own number |
| B4 | "What commercial terms would you expect to be involved in with an operator partner, and where would you stop?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | A forward question, so it asks about no past. Structure: what you would need to learn before saying anything specific, what you would bring to Ross rather than decide alone, and where you would stop. Say the limit once, early: "I've never carried a direct quota — only influenced revenue." Then move to the plan, which is a plan and not a past | The recruiter flagged commercials, and F4 is the gap this question lands on. JD because it tests the stated commercial emphasis |

### C Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail. Why should we believe you can do this here?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The highest-ROI rehearsal in this pack. Say the limit in your first sentence: "I've never sold into rail specifically." Then the adjacent evidence at its own scope: "I spent five years in transport consulting, in bus and light rail network planning." Follow-up one, that bus and light rail is not train operating: hold by returning to what the work was and concede nothing wider. Follow-up two, what from that work applies: answer slot. If any of it was with or for train operators, say what; if it was bus and light rail only, say so plainly. Finish with a ramp plan, said as a plan | F5 and F2 are the pair this objection is built from, and it will arrive in some form. JD because it scores a stated requirement and its gap |
| C2 | "Your channel was ISV partners. Operators aren't ISVs. What carries over?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Say what the work was: "I ran the ISV channel at a payments company for the last four years." Your material says an ISV channel, not operator partnerships. Answer slot: say what carries over and what does not, in your own words; if you have not worked it out, say so plainly and say how you would find out | F1 is adjacent work, and this is the probe it invites. JD because it tests the transfer the role needs |
| C3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Pick one gap you can name plainly and show a ramp. Words, pick one: "I've never sold into rail specifically" or "I've never carried a direct quota — only influenced revenue." Then how you would close it, said as a plan | F4 and F5 are the two gaps this question reaches. JD because it is the standard day-one-weakness probe on the stated role |
| C4 | "You've not carried a direct quota. How do you approach the commercial side of this role?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Words: "I've never carried a direct quota — only influenced revenue." Then the figure at its own noun: "roughly £4M of influenced revenue." Do not let influenced become owned or delivered. Then the plan: what you would learn about the terms and who you would work through | F4 meets F3 here, and it is the second objection to rehearse after C1. JD because it scores the commercial emphasis |

### D Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you rather than someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "took it from 6 partners to 40"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause, restate the question, then concede first: "I haven't sold into rail." Hold on two sentences only: you took the ISV channel from 6 partners to 40, and you spent five years in transport consulting in bus and light rail network planning. Let them draw the inference. Hold through two follow-ups by returning to those sentences, never by adding to them | F5 is the gap this stress question points at, and the structure is hold-then-concede. JD because it scores the stated requirement under pressure |
| D2 | "If we set you a direct number in year one, would you take it?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Whether you would is your decision, to make before Tuesday; this pack does not make it. Whatever you decide, concede plainly: "I've never carried a direct quota — only influenced revenue." Answer slot: if you would take it, say on what basis; if only with conditions, or not at all, say so plainly | F4 is the gap, and a Commercial Director pressing on commercials will test willingness as well as history. JD because it scores the stated emphasis |
| D3 | "You're asking us to bet on someone without rail selling behind them. What do we risk?" | JD | [grounded] "Never sold into rail specifically" | Name the risk honestly rather than defending against it: you have not sold into rail. Then say how you would shorten that, as a plan, and what you would want checked at 90 days. Stay at what the quote carries and add nothing to make the risk feel smaller | F5 again, in the version that tests composure. JD because it scores the stated role and its gap |

### E Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning" | A 90-second arc with only the beats the quotes state: nine years in partnerships, the last four running an ISV channel at a payments company; five years in transport consulting, in bus and light rail network planning. Answer slot: say the order those happened in as it was, in your own words; then why this role, in your own words | An opener, but it is scored, and F1 and F2 are what it should carry. EXP because it tests your own account of your path |
| E2 | "Why this role, and why Kelverton?" | JD | [generic] | A selection scaffold: choose the two real reasons you would give a friend, one about operators and one about the work. Use only Kelverton facts you have read in the report or the recruiter's email. If you cannot yet find a Kelverton-specific reason, say what draws you to operator partnerships and say plainly that you are still learning about Kelverton | The standard motivation probe, in a friendly register. JD because it tests fit with the stated role |

### G Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Partnerships and the commercial team sit side by side — where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a map you cannot know: who holds the operator relationship, who holds the terms, how disagreements are settled. Add what partnerships brings Ross's team. For a disagreement story: pick a time you disagreed with a counterpart and kept the working relationship intact; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Ross is the commercial counterpart to Deepa's function, so the seam is a natural question. JD because it tests partnership fit with the stated function |
| G2 | "How do you handle credit when revenue is influenced rather than closed?" | EXP | [grounded] "roughly £4M of influenced revenue" | The figure is influenced revenue, and it stays that in your words. Answer slot: say which part was yours; if you cannot separate your part, say so plainly. How credit for others' share was handled is yours to describe in your own words; if there was no agreed way, say so plainly | F3 is the figure, and credit on shared revenue is the peer version of the attribution probe. EXP because it tests attribution honesty |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 POV on operator partnerships | A1, A2, A3, A4, A5, C2 |
| F2 land on operators themselves | A4, C1, E1 |
| F3 commercials | B1, B2, B3, B4, G2 |
| F4 direct revenue number | B4, C3, C4, D2 |
| F5 selling into rail | C1, C3, D1, D3 |
| F6 build and scale a partner channel | B3, C2, E1 |

## Reverse questions

No interviewer profile was available, so none is tied to a panel member's own path, and none is a peer-reciprocity question.

| # | Ask | Why it lands |
|---|---|---|
| R1 | "Which operator relationships do you see as the model for what partnerships should be, and what makes them work?" | It asks them to teach, and their answer tells you what a good operator partnership means to them before you commit to a thesis |
| R2 | "What would make the first six months a success from each of your seats?" | Deepa and Ross may define success differently, and you leave knowing both |
| R3 | "How is this role measured: a direct number, influenced revenue, or operator outcomes?" | It surfaces the quota question openly, which you have already named as your gap |
| R4 | "Which recommendation in the report do you expect to be hardest to land with operators?" | It shows you read the report as a working document and moves the conversation to operators |
| R5 | "Where do partnerships and the commercial team see priorities differently, if at all?" | It shows seam awareness without claiming to know the seam |
| R6 | "What would you want me to have learned about operators by day 90?" | It converts the rail gap into a shared plan |

## Prohibited claims

Built before the banks, from the fit snapshot. No guidance, slot, hold or bridge asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F5 | The plain acknowledgment: "I've never sold into rail specifically." No slot |
| Carried a direct quota or owned a revenue number | Negative you stated, F4 | The plain acknowledgment: "I've never carried a direct quota — only influenced revenue." No slot |
| Knows train operating companies or heavy rail operations | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says bus and light rail network planning, not train operating companies. The slot stays inside that work |
| Generated, delivered or closed £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The slot asks only how it was counted and which part was yours |
| Personally recruited or signed the 34 added partners | Inflated form of F6 | F6's quote at its own scope: you took the channel from 6 partners to 40. The slot asks only what counted as a partner |

## Sources

**Provided documents:** your message, which carries your background and the recruiter's email. The market report was attached to that email, but its content was not shared with this conversation, so nothing here draws on it.

**Searches sent, all refused by the host (nothing returned):**

- "Kelverton Rail values": refused
- "Kelverton Rail interview process partnerships manager": refused
- "Kelverton Rail strategy scheduling software train operating companies news": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Senior Partnerships Manager rail technology job description train operating companies": refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have moved a values cheat sheet only if a values round were detected; none is, so the loss is small |
| 2. Kelverton Rail interview process, partnerships | unavailable | Would have checked the loop; the recruiter's own words establish this session, so persona weights are unaffected |
| 3. Kelverton Rail strategy and recent news | unavailable | Would have moved A2 to A5 from generic to grounded, and the POV's departure and anti-pick |
| 4. Deepa, VP Partnerships, Kelverton Rail | unavailable | Would have moved the interviewer read, persona adjustments and a reverse question tied to her path |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have moved F4 to F6 from role-family expectations to quoted requirements |

## Upgrade menu

- The job description text → F4 to F6 become quoted requirements, and the coverage table is re-checked against the posting's own list
- Your CV → fit snapshot evidence beyond your message, which could upgrade F3 and F6 and add rows
- The report's headline recommendations on operators, pasted → the POV's consensus item, departure and anti-pick become specific, and A2 to A4 move from generic to grounded
- Public professional pages for Deepa and Ross → a reading of each interviewer, persona adjustments, and a reverse question tied to a panel member's own path
- Your own answers to the slots in F1, F3 and F6 → those rows upgrade, and B1 to B3 and C2 sharpen
- Search permission for this session → rows 1 to 5 above are re-run; a deeper pass, up to 6 more searches and 2 more fetches and several more minutes, is available once if you want it
- One email to the recruiter asking what Ross means by commercials: pricing, contract structure or partner economics → B4 and D2 are aimed at his actual focus
- A prior tuesday-dossier.md, if you have one → verified evidence and prohibited claims arrive pre-built; never required
