Web search was denied in this session, so I'm building the pack from your JD and background alone. I'll save it now and label anything that isn't grounded in them.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-2-denied-427c03bb/atlas-freight_operations-manager_interview_pack.md`. It has 21 questions across seven interviewer styles, a fit snapshot, reverse questions and a prep schedule for the week.

- **Assumptions:** Web search was denied, so the pack rests only on your JD and background; anything company-specific is labeled generic. I also assumed a hiring-manager round, since you didn't say who you're meeting.
- **Highest-ROI prep:** A1, the jump from 3 supervisors to 12 across four sites. It will be probed in some form, and the pack gives you the exact concession wording and a 30-day ramp plan to rehearse.
- **Power BI:** Your material says you've never used it, so the pack coaches you to say that plainly, then give a plan: Excel first on the JD's own measures, then Power BI. It never coaches you to imply familiarity.
- **Where the pack stops:** It doesn't tell you how the 40% figure was counted, how many people you've led in earlier roles, or what your Excel work produces. Those are answer slots for you to fill in your own words. The upgrade menu lists what you could send to turn them into worked answers.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting: your future manager, a peer, or a recruiter, and did anyone mention focus areas or pre-work? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight ("regional logistics, 800 employees" — JD)
**Interviewer:** not known. **Round assumed:** hiring-manager round, because your note did not say who you are meeting. If that is wrong, the persona weights below are the first thing to change.
**Research:** none could run in this session, so nothing in this pack is drawn from the web. Everything company-specific is either your JD or labeled `[generic]`.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored. Every question carries one of five tags: **VAL** (behavioral or values alignment), **EXP** (work-experience deep-dive), **JD** (role and JD-driven), **CO** (company and strategy knowledge), **CASE** (live problem from the role).
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer from what you actually did, in your own words, or say plainly that it was not yours or did not happen.
- Provenance comes before the guidance. Whatever the guidance says about your past rests on the sentence quoted there and nothing else.

## Prep triage

Sized to "next week": a few things done well, in this order. Everything not listed is insurance.

1. **A1 and A2, aloud, timed to 90–120 seconds.** A1 is the highest-ROI prep in the pack: the jump from 3 supervisors to 12 across four sites will be probed in some form.
2. **C1 and D1.** Write down, in your own words, how the 40% mis-pick figure was counted, what it is sensitive to, the assumption you would defend least, and what part was yours.
3. **A3 and C2.** Get your Power BI sentence and your Excel sentence to the point where they are boring.
4. **B1, B2 and B5.** Say the structure out loud once each; these are live problems, so the habit matters more than the content.
5. **A4 and the reverse questions.** Spend time on Atlas's own public material yourself, so the answer to "why here" is something you read.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows warehouse and distribution years and one site's surge plan; it does not show four sites, and it says warehouse and distribution where the JD says terminal. Words stay at the quote: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four sites make a probe on the reach of what you ran likely. Say, in your own words, how far the surge plan reached, which parts of the site and which teams; if it was narrower than that, or not yours to set, say so plainly and describe the plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate is a different measure from on-time performance or cost per shipment, and your material names neither. Words stay at the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's two measures make a probe on how the redesign related to them likely. If anything else was tracked alongside mis-pick rate, say what; if nothing was, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors; the JD says 12. Words stay at the quote: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's twelve makes a probe on how you lead supervisors likely. Say, in your own words, how you work with the three you have now; if some part of it is not yours to decide, say so plainly and stay with the three |
| F4 | "build reporting in Excel/Power BI" (Excel half) — JD | "solid Excel" — your message | low | [inferred] | discovery | Two words do not show what your Excel work produces or who sees it, and the bridge is not stretched past them. Answer slot: the JD's reporting line makes a probe on what your Excel work produced likely. Say, in your own words, what you use Excel for and who sees the output; if it is your own analysis and nobody else reads it, say so plainly and say what you would build first |
| F5 | "build reporting in Excel/Power BI" (Power BI half) — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would get up to speed, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [inferred] | discovery | Seven years of operations is shown; how many of them were spent leading people is not, and the reading resolves downward to the current role. Answer slot: the JD's years-of-leadership line makes a probe on how long of your seven you spent leading people likely. Say, in your own words, which roles you led people in and for how long; if the number is smaller than the seven, say it plainly and stay with what the seven years were |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification with nothing inspected behind it, so expect a probe on what you have used. Lead with it in the quote's own terms: "I'm green belt certified." |

## Persona table

Weights are the priors for an assumed hiring-manager round. No loop source establishes Atlas's loop and no interviewer signals exist, so nothing adjusted them; the loop archetype falls back to Generic (screen, hiring manager, panel) with flat tilt. This is noticeably weaker than a pack built on a known round, and the first upgrade-menu line fixes it.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the span, the scale and the tools gap | High. A hiring manager is derisking gaps, and F3, F5 and F6 are where your material is thinnest. Five questions | Rehearse the span objection until it is boring; build bridges only from what you stated; calibrated candor over bluffing |
| B. Case/Strategist | Live ops problems: diagnose a slip, plan a surge, build a view | High. A hiring manager buys capability on live problems, and the JD is built around on-time, cost and reporting. Five questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C. Data-Driven Prober | Walks the 40% figure and the reporting claim line by line | Medium. The JD names reporting tools and you have one headline metric. Three questions | Know how the figure was counted and say plainly what you do not know; name the weakest assumption before they do |
| D. Pressure | Interrupts and time-boxes; tests composure on scale and ownership | Medium-low. Less typical for this round, but the scale gap invites it. Two questions | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| E. Values/Behavioral | Scenario probes on leading supervisors and delivering hard news | Medium-low. No values-style round is established, and no published values were read. Two questions | Selection scaffolds with an honest branch; "we" for context, "I" for contribution |
| F. Conversational | Friendly biography and "what are you playing with" questions | Medium-low. Easy to under-prepare because it feels unscored. Two questions | A pre-scripted 90-second arc; treat casual questions about JD topics as scored |
| G. Peer Evaluator | Seam-splitting between sites; collaboration and credit | Low in this assumed round, but plausible in a panel. Two questions | Reciprocity framing; propose seam principles rather than pretending to know the seam |

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a senior shift manager over 3 supervisors today. What would be hardest about leading 12 supervisors across 4 sites on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Say the JD's size aloud before they do. Words stay at the quote: "I'm currently a senior shift manager over 3 supervisors." Concede the difference specifically: "The JD's twelve across four sites is more than the three supervisors I'm over now." Then a concrete ramp plan, said as a plan and never a past: whom you would meet first, what you would measure before changing anything, what you would leave alone for the first 30 days. Answer slot: say, in your own words, how you work with the three you have now; if some part of it is not yours to decide, say so plainly and stay with the three. Follow-ups to rehearse: "How does your day change at four times the span?"; "Who covers a site when you cannot be there?"; "What would you refuse to change in the first month?" | F3 is the widest gap between the JD and your material, so this objection arrives in some form; JD because it scores the stated team requirement |
| A2 | "The posting asks for 5+ years of operations leadership. How many of your 7 years were spent leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Say the seven years and the current role in those words. Answer slot: say, in your own words, which roles you led people in and for how long; if the number is smaller than the seven, say it plainly and stay with what the seven years were. Do not round the number up | F6 is a stated, titled-years requirement and your material shows the years but not the leadership split; JD because it scores the requirement directly |
| A3 | "You haven't used Power BI, and this role builds reporting in it. How would you handle that?" | JD | [grounded] "never used Power BI"; "solid Excel" | Words: "I've never used Power BI. My Excel is solid." Then a plan, said as a plan: the first report you would build, for whom, and on which of the JD's own measures (on-time performance and cost-per-shipment), in Excel first; then how you would get Power BI skill. Never describe learning you have not done. Answer slot: say, in your own words, what you use Excel for and who sees the output; if it is your own analysis, say so plainly and stay with "solid Excel" | F5 is a gap you stated and F4 is thin, so this is asked in some form; JD because the tool is named in the requirement |
| A4 | "Why this move, and why Atlas?" | CO | [generic] | Selection scaffold, since no sentence of yours carries the answer: pick one reason that is true for you and tied to what the JD describes (four sites, twelve supervisors, on-time and cost); add one thing about Atlas you read yourself, not guessed. If no reason beyond the title comes to mind, say so plainly, then give the nearest true thing or how you would approach the role | The Skeptic's motivation probe, with CO because it tests homework. No company research ran for this pack, so the grounding is yours to supply; `[generic]` for that reason |
| A5 | "What from your experience carries over to four sites, and where does it stop?" | JD | [grounded] "ran the site's peak-season surge plan two years running" | Story-mapped on F1: the surge plan, the site's, two years running. Those are the beats the quote states; tell them in your own words. Answer slot: the JD's four sites make a probe on the reach of what you ran likely. Say how far the surge plan reached, which parts of the site and which teams; if it was narrower than that, or not yours to set, say so plainly and describe the plan you ran | F1 is the main place the JD's scale presses on your material; JD because it scores the multi-site requirement |

### B. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one terminal drops 20% in a month. Diagnose it." | CASE | [generic] | Clarify first: how on-time is defined, which lanes and customers, since when, what changed. Then objective, segmentation (by lane, shift, dock, customer), approach, the metrics you would watch, the risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's on-time line (F2's requirement); `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Cost per shipment is rising at one site while on-time performance is flat. Where do you look, and what would you not touch?" | CASE | [generic] | Clarify what the cost is made of and how it is allocated. Segment (labor, dock time, linehaul, rework), pick the likeliest two drivers, say what data you would need and how fast you could get it. Name one lever you would deliberately leave alone and why. No claim about your past | The JD's cost-per-shipment line (F2's requirement), asked as a diagnosis; `[generic]` for the same reason as B1 |
| B3 | "Peak season: three of four terminals are on plan and one is falling behind. What do you do in the first 48 hours?" | CASE | [generic] | Triage structure: what you need to know first, what you would move or borrow between sites, what you would tell supervisors and when, what you would stop doing. State the trade-off you are accepting. No claim about your past | The multi-site requirement (F1's) as a live problem; `[generic]` because it is a pattern |
| B4 | "Design a one-page weekly view of a terminal. What is on it, and how do you build it?" | CASE | [generic] | Clarify the audience first (supervisors or the site's leadership). Choose a short list of measures, starting with the JD's on-time performance and cost-per-shipment; say where each number would come from and who owns its definition. Excel first, and what you would hand to Power BI later, said as a plan | The JD's reporting line (F4 and F5's requirement) as a design exercise; `[generic]` because it makes no claim about this employer's systems |
| B5 | "You inherit 12 supervisors you have never met across four sites. What do you do in your first 30 days?" | CASE | [generic] | A ramp plan in order: who you meet, what you observe before changing anything, which two or three measures you set as the shared scoreboard, what you deliberately leave alone, and how you earn credibility with supervisors who know the sites better than you. Said as a plan, never a past | F3's requirement as a live problem, and it rehearses the plan A1 asks for; `[generic]` because it is a pattern |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Words stay at the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before they ask; which part of the redesign was yours. If you do not know how it was counted, say that plainly. Do not explain a method you cannot repeat under a second question | F2's one quantified claim and the likeliest thing a prober opens with; EXP because it tests whether the number survives scrutiny |
| C2 | "This role builds reporting in Excel and Power BI. Tell me about reporting you have built in Excel." | JD | [grounded] "solid Excel" | Words: "My Excel is solid." Answer slot: say, in your own words, what you use Excel for and who sees the output; if it is your own analysis, or there was no such reporting, say so plainly and stay with "solid Excel". Do not describe a report you cannot walk through cell by cell | F4 is the thinnest-evidence row the JD names as a tool requirement; JD because it scores the stated skill |
| C3 | "You are green belt certified. Which tool would you reach for first on a recurring late-delivery problem, and why?" | JD | [grounded] "green belt certified" | Words: "I'm green belt certified." Choose a tool you can explain end to end, including what data it needs. Answer slot: if you have applied it at work, say where and what came of it, in your own words; if the certification is the extent, say so plainly, then say which tool you would start with and why | F7 is a certification with nothing inspected behind it; JD because the JD lists the skill |

### D. Pressure (weight: medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40% mis-pick result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, then the quote at its own attribution: "I cut mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups by returning to that sentence, never by adding to it. Answer slot: if others shaped the redesign or the result, say what they did and what was yours; if it was not all yours, say so plainly and stay with what you did. Concede uncertainty specifically, such as how a part of the figure was counted, and never the core claim just to restore harmony | Attribution probes exist to catch inflation, and F2 is your one quantified claim; EXP because it tests what was actually yours |
| D2 | "Sixty seconds: why you over someone who has already run multiple sites?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified"; "currently a senior shift manager over 3 supervisors" | Three beats, each a clause the quotes state, in your own words: the mis-pick result, the surge plan, the certification. Stop there and let the interviewer draw the inference. Hold through two follow-ups by returning to the quotes. Concede the scale specifically: "The JD's twelve across four sites is more than the three supervisors I'm over now." Then say what you would do in the first 30 days, as a plan | The Pressure persona's standard stem, aimed at F1 and F3, where scale is the weak point; JD because it scores fit against the stated role |

### E. Values/Behavioral (weight: medium-low)

No published values were read and no values-style round is established, so these two are open prompts built from the JD and a persona stem, not mapped to Atlas's values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to hold a supervisor accountable for a result." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: you are over supervisors now, so pick an instance with a named stake, what you actually said, and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use "we" for context and "I" for what you did | The JD's team-leadership line (F3's requirement) as a behavioral probe; VAL because it scores behavior, though not against published values |
| E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and an intact relationship at the end; the hard truth should have landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values persona's standard stem, covering what the JD's scale makes likely; `[generic]` because it is a pattern |

### F. Conversational (weight: medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc whose beats are the quotes: seven years in warehouse and distribution ops, currently a senior shift manager over 3 supervisors, then why this role. Answer slot: the years in between, which roles in which order, are yours to fill in your own words; if any step was short or not what the title suggests, say so plainly. Treat it as scored | The casual opener that sets the frame for everything after it; EXP because it tests whether the CV's story hangs together (F6) |
| F2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Casual in register, scored in content. Words: "I'm green belt certified." Answer slot: if you are applying something now, say what and where; if the certification is not something you are using at the moment, say so plainly, then say what you would want to apply first in this role | The JD lists Lean/Six Sigma as a plus, and a casual question on a flagged topic is still scored (F7) |

### G. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our four terminals sit side by side. Where is the seam between sites, and what happens when two supervisors or two sites disagree?" | CASE | [generic] | Propose seam principles rather than pretending to know where the seam is: who decides what, what gets escalated, how a disagreement is settled quickly. Reciprocity: say what you would bring the other sites, not only what you would need. No claim about your past | The multi-site requirement (F1's) from a peer's angle; `[generic]` because it is a pattern |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams, say which part was yours and which was theirs, and how the credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer persona's standard stem; `[generic]` because it is a pattern |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A5, B3, B5, G1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, B4 |
| "lead a team of 12 supervisors" | A1, B5, E1 |
| "build reporting in Excel/Power BI" | A3, B4, C2 |
| "5+ years operations leadership required" | A2, F1 |
| "Lean/Six Sigma a plus" | C3, F2 |

Your one headline metric, the 40% mis-pick reduction, is covered by C1 and D1.

## Reverse questions

Questions to ask them. Each one asks about Atlas and tells you something you need; none asserts anything about the company.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four sites today, and which site is furthest from where you want it?" | Gets you the starting point for the JD's lead measure and tells you where you would spend your first weeks |
| R2 | "How are the twelve supervisors spread across the four sites, and how long has each been in seat?" | Shows you are thinking about span before you are in it, and gives you the answer to A1's ramp plan |
| R3 | "Where does reporting live today, in Excel, in Power BI or elsewhere, and who reads it?" | Turns the Power BI gap into a scoping conversation you started rather than a probe you are defending |
| R4 | "What would tell you in the first 90 days that this hire is working?" | Gets you the scoreboard you will be held to, in their words |
| R5 | "Is this a new role or a backfill, and what would you keep or change from how it has been done?" | Tells you what the job inherits and how much room there is to redesign |
| R6 | "What moves cost per shipment here that the terminals do not control?" | Tells you where the number is constrained before you promise to move it |

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran terminal operations across multiple sites | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the site's surge plan, not four sites. A5's slot stays inside the surge plan |
| Led a team of 12 supervisors | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors". The material says 3. A1's slot asks only how you work with the three you have now |
| Has improved on-time performance or cost per shipment | Inflated form of F2 | F2's quote at its own scope: the mis-pick result. The measures the JD names are not in your material. The slot asks only what else was tracked alongside mis-pick rate |
| Has built Excel reporting that others use | Inflated form of F4 | F4's quote at its own scope: "solid Excel". The slot asks only what you use Excel for and who sees the output |
| Has used, or is familiar with, Power BI | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Has 5+ years of operations leadership | Inflated form of F6 | F6's quotes at their own scope: seven years in operations, and a current role over 3 supervisors. The leadership split is the pack's observation of a limit, not words for you |
| Led Lean or Six Sigma projects | Inflated form of F7 | F7's quote at its own scope: "green belt certified" |

## Sources

**Provided documents:** the job description as pasted into your message; your background as written in your message. No `tuesday-dossier.md` was present.

**Searches sent, all refused, none returned a result:**

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have moved the values cheat sheet and the themes of E1 and E2, if a values-style round were detected; the upgrade menu offers it |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have moved the persona weights, which now rest on the Generic archetype and an assumed hiring-manager round |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have moved A4 from `[generic]` to grounded and added a strategy-grounded CO or CASE question |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what a name would unlock |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting, and whether it is a hiring manager, a peer, a skip-level or a recruiter screen → reweights every bank; add any focus areas or pre-work the recruiter mentioned, which is usually one email to them
- Atlas's values or careers page, or recent news, pasted in (web search was refused in this session) → A4 moves from `[generic]` to grounded, a strategy-based CO or CASE question can be added, and a values cheat sheet if the loop has a values round
- The interviewer's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their own path
- Your earlier roles, with titles, years and how many people reported to you in each → upgrades F3 and F6 from thin rows, and A1 and A2 can then be story-mapped
- How the 40% mis-pick figure was counted and which part of the redesign was yours → C1 and D1 become story-mapped instead of answer slots
- What your Excel work produces and who sees it → upgrades F4, A3 and C2
- Whether on-time performance or cost per shipment was tracked anywhere you have worked → upgrades F2 and B1, B2
- A `tuesday-dossier.md` from an earlier fit assessment would add verified evidence and a named highest-risk objection; nothing in this pack needs it
