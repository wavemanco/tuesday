No dossier present. Reading the reference files the playbook requires.
Dara, your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-denied-1342fcc6/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a three-round loop from the recruiter's email. It has 28 questions across the rounds, grouped by how each interviewer will ask, plus a values cheat sheet for the panel. The interviewers aren't assigned yet, so there's no interviewer read. I used only what you pasted and ran no research.

- **Biggest objection (D1):** "You've never worked in a contact centre." The JD's first line puts the contact centre in scope, so expect it in every round. The pack coaches a plain acknowledgment in your own words, then what your branch complaints work does cover, then a plan for the first weeks.
- **Second objection (D3):** you've never presented above regional level. Same approach.
- **Answer slots:** some of your material doesn't say enough to write a story for you. These include what your monthly spreadsheet measured, whether the logged complaints carried regulatory deadlines, and whether you've ever coached supervisors or worked with digital teams. I left those as slots where you say what's true, or say plainly it wasn't yours.
- **Round 3 case:** I don't know the real case, only that it's a complaint escalation, so G1 to G4 are practice cases for the structure.
- **Strategy brief:** I only had your four-point summary of the brief. Read the brief itself before the 20th for exact wording and figures.

Say the word and I'll play the Head of Member Services as a Skeptic on D1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Prepared:** 11 November 2026, nine days before the loop on 20 November 2026.
**Mode:** loop, three scheduled rounds on one day, from the recruiter's email.

| Round | Length | Who | Relationship | Persona weights (reasoning in each round) |
|---|---|---|---|---|
| 1 | 30 min | The recruiter | Recruiter screen | Conversational, then Skeptic |
| 2 | 45 min | Head of Member Services, your future manager, mostly behavioural | Hiring manager | Values/Behavioral and Skeptic, then Case/Strategist |
| 3 | 60 min | Panel of two branch managers; 20 minutes is a complaint-escalation case; also the values round, scored against the four values | Panel | Case/Strategist and Values/Behavioral, then Peer Evaluator |

Interviewers beyond their roles are not yet assigned, so there is no interviewer read. The highest-ROI prep in the pack is **D1** (the contact-centre objection), then **D3** (presenting above regional level).

## How to use this pack

- **Personas are how a question is asked; types are what is scored.** Every question carries both.
- **Type key.** VAL: past behaviour against the published values. EXP: whether your own experience survives scrutiny. JD: a stated requirement of the role. CO: company and strategy knowledge. CASE: a live problem set in the role.
- **Guidance is scaffolding, not a script.** Say it in your own words and in under two minutes.
- **Answer slot** means an instruction for the interview. It is not a question for you now. Fill it truthfully from your own experience, or take the plain second branch, which is always allowed.
- **Provenance:** `[grounded]` traces to something you or Ashgrove supplied; `[inferred]` is this pack's derivation, named; `[generic]` is a pattern with no claim about you or Ashgrove. A Provenance cell quotes the sentences of yours the guidance rests on.
- Question IDs run by persona within each round: A, B (round 1); C, D, E (round 2); G, H, J (round 3). Fit rows are F1 to F9.

## Fit snapshot (shared across all three rounds)

No requirement in the JD is a gate: the years requirement is experience, not a legal or credential bar.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD, branches half | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end and not several branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's across-branches line makes a probe on reach likely. If any of your work touched complaints beyond your own branch, say how, in your own words; if none did, say so plainly and stay with the branch's log |
| F2 | "across branches and the contact centre" — JD, contact-centre half | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn that side, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says you built a monthly complaints spreadsheet that your regional manager uses. It does not say what the spreadsheet measured, and nothing inspected sits behind it. Say it in those words. Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet showed. If it showed either, say which and how it was counted; if it showed neither, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, and the pack reads no tool into it. Answer slot: if the spreadsheet was in Excel, say so and say what you did in it, in your own words; if it was another tool, say so plainly and say how you would get comfortable in Excel |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Lead with the years and the title exactly as you stated them: "I have six years in retail banking, the last three as a branch supervisor." Which of those years count as customer operations is the employer's reading, so offer the facts and let them place it. Nothing inspected sits behind the line, so expect a probe on it |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Formal is your word and regulated is the JD's; the pack does not equate them. Answer slot: the JD's regulated line makes a probe likely. If the complaints you logged carried external rules or deadlines, say which and what they required of you, in your own words; if you do not know, or the log was not tied to any external requirement, say so plainly and stay with the formal log you handled |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and a script, and the words stay at that scope: "I trained new tellers on our escalation script." The step to coaching supervisors is an answer slot: if you ever supported a fellow supervisor on an escalation, say what and how, in your own words; if you did not, say so plainly and stay with the tellers |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap on its face, stated by you. Words: "I've never presented to anyone above regional level." The material does not say what you presented at regional level or how, so the pack says nothing about it. Then how you would prepare for senior audiences, said as a plan and never as a past |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have worked with a digital, product or online team, say what the work was and what part was yours, in your own words; if you have not, say so plainly and say what you would bring them, as a plan |

## Grounding brief (strategy brief supplied by the recruiter)

The pack read your summary of the 2026 strategy brief, published July 2026, which is inside the six-month freshness window. It did not read the brief itself, so read it before the 20th for exact wording and figures.

| Move | In your words | What it touches in this role | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" — your message | The JD's self-service line; this is where the digital teams in F9 come in | [grounded] |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" — your message | The branches half of F1, and the supervisors in F7; derived from the JD's scope, not stated in the brief | [inferred] |
| New product | "launch a small-business lending product in Q1 2027" — your message | A new product line that new complaint types may follow; derived, not stated | [inferred] |
| Competitive frame | "the main competitive pressure is app-only banks" — your message | The frame for the self-service questions | [grounded] |

Ashgrove describes itself in the JD as member-owned with about 900 staff.

## Prohibited claims (shared, built before the banks)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log, not the process, and one branch, not several |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Reported complaint volumes and resolution times each month | Inflated form of F3 | F3's quote at its own scope. The material says a monthly complaints spreadsheet, not what it measured; A-bank and C3 slots stay inside the spreadsheet |
| Advanced or confident in Excel | Inflated form of F4 | F4's quote at its own scope. The material says spreadsheet, not Excel |
| Handled regulated complaints | Inflated form of F6 | F6's quote at its own scope. The material says a formal log, not regulated complaints |
| Coached supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: tellers and a script |
| Presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |

---

# Round 1: the recruiter (30 minutes)

## Persona table, round 1

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly walk through your background and motives, plus logistics | High: the recruiter-screen prior is Conversational first, and the email names no focus areas, so the prior stands | A 90-second arc for the biography question (A1); treat the casual questions as scored |
| Skeptic (light) | Quiet checks of the JD's stated requirements against your background | Medium: years, regulated complaints and the contact-centre scope are checkable in a sentence each | Say each answer plainly at the scope of your own words; never fill a gap to get past a check |

## Question bank, round 1 (8 questions)

### A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your six years in retail banking and what has brought you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Build a 90-second arc from the beats these sentences state: six years in retail banking, the last three as a branch supervisor; then the branch's formal complaints log you handled, the escalation script you trained new tellers on, and the monthly complaints spreadsheet your regional manager uses. Answer slot: the material says nothing about the first three years or about why this role. Say what those years held and your actual reason for moving, in your own words; if there is no tidy reason, say so plainly and stay with the three things above | F5 gives the arc; F1, F7 and F3 give its three beats. EXP because the screen checks that the story hangs together; Conversational because it arrives as an open invitation |
| A2 | "Why Ashgrove?" | CO | [grounded] | Answer slot: the reason is yours and the pack does not supply one. Build it from what Ashgrove publishes: member-owned in the JD, and "we decide from the member's side of the counter" on the values page. Say which part is true for you, in your own words; if it is mostly the role, say that plainly | Every screen tests motivation for consistency with what you do next. CO because the published values are the checkable homework |
| A3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Say the four moves from the grounding brief in your own words: the digital shift, the hub plan, the small-business lending product, the app-only competition. Pick the one that touches complaints and put it as a question you would want answered, not a conclusion you have reached | The recruiter sent you the brief, so reading it is the baseline. CO because it scores strategy fluency at the first conversation |
| A4 | "What is your notice period, and what are you looking for on salary?" | JD | [generic] | Answer slot: your real notice period and range; the pack knows neither and the JD states no pay. State what you have decided, and where you have not, say so plainly | Logistics are standard at a recruiter screen. JD because it concerns the terms of the role |

### B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the branches and the contact centre. Where does your experience sit?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | Branch side first, at its scope: "I handled the branch's formal complaints log." Then the plain acknowledgment: "I haven't worked in a contact centre." Then one sentence on how you would learn that side, as a plan. Do not say the two processes are the same | F1 and F2 are the two halves of the JD's first line. D1 takes the same objection deeper with the manager; JD because it scores the stated scope |
| B2 | "Which part of this JD would be your weakest on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose one of the two gaps your own message names and say it plainly: "I haven't worked in a contact centre" or "I've never presented to anyone above regional level". Then your plan for the first weeks. One named gap with a plan reads as self-knowledge; a hedge across both does not | F2 and F8 are the two stated gaps. Persona stem for the Skeptic; JD because it tests honest self-assessment against the listed requirements |
| B3 | "The role asks for four-plus years in financial-services customer operations. Which of your six years come closest?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | "I have six years in retail banking, the last three as a branch supervisor." Which years count as customer operations is their reading, so offer the facts. Answer slot: say what the first three years held and which of the six involved dealing with members directly, in your own words; if their definition is narrower than your work, say so and ask what they mean by it | F5 is a years requirement, which is a risk to name and not a gate. JD because it tests the stated minimum |
| B4 | "This role needs experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log" | Start where your material does: "I handled the branch's formal complaints log." Answer slot: the JD's regulated line makes a probe on external rules likely. If the complaints you logged carried regulatory timelines or reporting, say which and what they required of you; if they did not, or you do not know, say so plainly and stay with the formal log | F6 is low confidence: the quote says formal, the JD says regulated. JD because regulated complaints is a stated requirement |

---

# Round 2: Head of Member Services, your future manager (45 minutes)

## Persona table, round 2

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Open "tell me about a time" prompts drawn from the JD's duties | High: the recruiter described the round as mostly behavioural. The hiring-manager prior is Case and Skeptic, so this tilts it toward Behavioral | Choose a story from your own sentences where one carries it, a scaffold where none does; "we" for context, "I" for what was yours (C bank) |
| Skeptic | Probing the contact-centre scope, one-branch reach and the senior-audience requirement | High: the person buying the hire is derisking the three stated gaps (F1, F2, F8) | Rehearse D1 until it is boring: plain acknowledgment, then the quote at its scope, then a plan; hold through follow-ups, concede only what is true |
| Case/Strategist | A short live question on the strategy, as the manager's roadmap | Medium: the prior's Case weight is cut to two questions because the email says mostly behavioural | Clarify, then structure, then answer; challenge one premise respectfully (E bank) |

## Question bank, round 2 (10 questions)

### C: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on the one sentence: new tellers, an escalation script. Tell those beats in your own words. Answer slot: the JD's coaching line makes a probe on a moment someone struggled likely. If someone did, say what you did and how it went; if no moment like that happened, say so plainly and describe the training you gave | F7 is the nearest evidence for the JD's coaching line, and it sits at teller level. JD because the prompt comes from a stated duty |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone more senior something they did not want to hear. It needs a named stake, the moment you did not soften it, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then say how you would handle it | Persona stem for Values/Behavioral. The pack has no sentence of yours that carries this story, so it does not write one; F8 limits how far up that leadership has been |
| C3 | "Tell me about a time a report you produced changed what someone did." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on the sentence: you built a monthly complaints spreadsheet, and your regional manager uses it. Answer slot: the JD names monthly reporting on volumes and resolution times, so expect a probe on what it showed, what it was built in and what was done with it. If your regional manager acted on something in it, say what and which part was yours; if not, or you do not know, say so plainly and stay with what you built. Name the figure you would defend least, or say plainly you do not know how a figure was counted | F3 and F4 draw on this one sentence. JD because it scores the reporting duty; the defend-the-number habit applies even though no figure was given |
| C4 | "Tell me about a time you worked with a team outside your own function." | JD | [generic] | Selection scaffold: pick a time you worked with a digital, product or head-office team; it needs a named purpose, what each side wanted and a result. If no such time comes to mind, say so plainly, then say what complaint themes you would bring a digital team and how you would approach the first meeting | The JD's digital-teams line has no quote behind it in your material (F9), so the pack offers a scaffold. JD because it scores a stated duty |

### D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have never worked in a contact centre. How would you own complaints there?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | **Deepest rehearsal in the pack.** Hold, in three moves. First, the plain acknowledgment: "I haven't worked in a contact centre." Second, what your material does carry, at its scope: "I handled the branch's formal complaints log." Third, your plan for the first weeks, as a plan: for example listening to how members reach the centre and sitting with its team leads, in your own words. Follow-up 1, "why would branch experience carry over?": do not claim the two processes are alike; say what you handled and that you would test the fit. Follow-up 2, "who would you ask first, and about what?": name a role and a question. Follow-up 3, "what if the centre's team will not take direction from you?": concede it is a real risk and say how you would earn it. Never fold on the first acknowledgment; never add contact-centre experience | F2 is the stated gap, and the JD's first line puts the contact centre in scope, so this objection arrives in some form in every round. JD because it scores a stated scope; the most likely objection to this candidate |
| D2 | "You have handled the branch's complaints log. Why should we trust you with the process across every branch?" | JD | [grounded] "I handled the branch's formal complaints log" | The hold is only what the quote carries: "I handled the branch's formal complaints log." Concede the scope plainly. Answer slot: if any of your work touched complaints beyond your own branch, say how, in your own words; if none did, say so plainly and say how you would get across the other branches, as a plan. Hold through two follow-ups by returning to the log, never by adding to it | F1 is where the owns-end-to-end line presses hardest. JD because it tests the stated scope |
| D3 | "The role presents to senior leaders. You have not presented above regional level. How do you see that?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Plain acknowledgment first: "I've never presented to anyone above regional level." Then the plan: how you would prepare for a first senior audience, for example asking what leaders want to see and keeping the first report short. Answer slot: the material says your regional manager uses the spreadsheet, not that you presented it. If you presented to your regional manager, say what and how it went; if the spreadsheet was sent rather than presented, say so plainly | F8 is the second stated gap. JD because it scores the senior-presenting requirement |
| D4 | "After three years as a branch supervisor, what will you miss about branch work, and why leave it?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Answer slot: your real reasons are yours and the pack supplies none. Say what you would miss and what pulls you to this role, in your own words; if the honest answer is that you are drawn to the complaints work more than leaving the branch, say that plainly. Keep it consistent with what you told the recruiter in A1 and A2 | Motivation consistency is the Skeptic's third test after capability and scope. F5 establishes the branch years; EXP because it tests whether your own story holds together |

### E: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Ashgrove wants 40 percent of member service on digital channels by 2028. What does that mean for how complaints arrive, and what would you want to know first?" | CASE | [grounded] | Clarify before structuring: what counts as member service, which channels, and what share of complaints each channel carries today, since you do not know the last. Then objective, segmentation (by channel and by complaint type), approach, metrics and risks. Challenge one premise respectfully, for example whether the target covers service or also complaints. Use the brief's own vocabulary; do not present guesses about Ashgrove as facts | CO and CASE grounded in the brief. Case/Strategist because the manager scores structure and the use of the company's own words; the question asks about no past |
| E2 | "Eight branches become five hubs over 2027. How should the complaints process cope during that change?" | CASE | [grounded] | Clarify: what happens to branch supervisors and tellers during the move, and where complaints are logged while it happens. Then structure: owners that do not change when a branch does, one logging route, plain-words communication to members, and a view in the monthly report of whether volumes shift. Name the risk that complaints fall between old and new branches. Do not speculate about which branches or what happens to people | Second brief-grounded case. CASE because it is a live problem in the role; the manager's roadmap is the hubs |

---

# Round 3: panel of two branch managers (60 minutes, with a 20-minute case; the values round)

## Persona table, round 3

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The 20-minute complaint-escalation case, scored on structure and reasoning | High: the email names the case and gives it a third of the round | Clarify, objective, approach, risks; think aloud; challenge one premise (G bank) |
| Values/Behavioral | Scenario probes scored against the four published values | High: the recruiter's email says the panel is the values round and they score against the four values, so this is guaranteed in this session | One story or scaffold per value (H bank, cheat sheet below); "we" for context, "I" for contribution |
| Peer Evaluator | The seam between branches and the central complaints role, and what each side needs from the other | Medium: the role coaches branch supervisors and reports on branch complaints, and the two panelists are branch managers, so the seam is theirs. This is the pack's derivation from the JD and the email, not a fact about these two people | Offer seam principles rather than pretending to know the seam; reciprocity framing (J bank) |

## Question bank, round 3 (10 questions)

### G: Case/Strategist (complaint-escalation case)

The pack does not know the actual case, only that it is a complaint escalation. These are rehearsal cases, `[generic]`, built to practise the structure.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member has complained three times about the same fee error. The branch says it is fixed; the contact centre's log says it is not. You are the complaints lead. What do you do in the first hour?" | CASE | [generic] | Clarify first: what the member says the outcome is, whether it is logged as a formal complaint and which clock is running, and who has touched it. Objective: the member's problem fixed, explained in plain words. Approach: one named owner, who keeps it until it is solved; a reply the member would not need explained twice; the record kept. Then risks and what you would feed into monthly reporting. Challenge one premise: is the branch's word that it is fixed confirmed with the member? The question asks about no past | The panel's case is a complaint escalation, and this is its most likely shape across branches and contact centre. CASE; the structure maps onto Own the Fix and Plain Words |
| G2 | "A supervisor tells you a complaint is just a misunderstanding and does not want it logged. How do you respond?" | CASE | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Structure: ask what the member said they wanted; check against what the escalation rules count as a complaint; treat it as a coaching moment, not a telling-off; agree who logs it today. You may anchor in your two sentences at their scope, but the material shows no moment like this one, so do not tell one. Answer slot: if a colleague ever resisted escalating, say what you did; if none did, say so plainly and answer as a plan | F7 is the nearest evidence for coaching supervisors, and F1 for the log. CASE because it is a live problem; the persona is Case with a Peer edge, since the panel are the supervisors' managers |
| G3 | "Three escalations land at once: one from a branch, one from the contact centre, one from a member who has written to a senior leader. Which do you take first?" | CASE | [generic] | Ask before ranking: member harm, any deadline, whether someone already owns it, how long each takes. Say your rule aloud, then pick. If pushed to choose only one, pick and state what you are trading off. Leave each of the other two with a named owner and a time. Do not rank by who is loudest or by source channel | Prioritising under pressure is the standard escalation test, so rehearse it. CASE; the structure maps onto Own the Fix |
| G4 | "Complaints about one branch have doubled this month while resolution times held steady. Where do you start?" | CASE | [generic] | Clarify definitions first: what counts as a complaint, whether anything about logging changed, whether it is one cause or many. Segment by complaint type, channel and week. Form two or three hypotheses and name the data that separates them. Say what you would tell that branch's manager and when. Name the assumption you would trust least | Metric-diagnosis stem for the Case persona. CASE; it presses the JD's reporting duty without any claim about your past |

### H: Values/Behavioral (scored against the four values)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Selection scaffold, for Members First, Always: pick a time a member's interest and a branch process or target pulled apart. It needs a named stake, what you decided, and what it cost you. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", as it stands, or say how you would decide | The pack has no sentence of yours that carries a decision against a process, so it does not write one. VAL because the value is published and scored by name |
| H2 | "Tell me about a time you had to explain something more than once, or rewrite it, because it was not clear the first time." | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words. Story-mapped on one sentence: you trained new tellers on the script. Answer slot: the material does not say whether you wrote or changed any of the script. If you reworded part of it or changed how you taught it, say what and why; if the script was given to you and you did not change it, say so plainly and describe the training you gave | F7 is the only sentence near explaining, and it is about teaching, not writing. VAL because the value is "if a member needs it explained twice, we wrote it wrong" |
| H3 | "Tell me about a time you weighed a number against what your branch's community needed." | VAL | [generic] | Selection scaffold, for Neighbours, Not Numbers: pick a time a target or a figure pointed one way and what you knew of the people your branch served pointed another. It needs a named stake, what you chose and the result. If no such time comes to mind, say so plainly, then say how you would weigh it. The brief's hub plan touches branches, and the pack does not know whether either panelist's branch is affected; do not speculate about which branches or about people, and ask rather than assert | F5 establishes the branch years but carries no such decision. VAL for the value by name; the panel is two branch managers, so the value is theirs |
| H4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix. Story-mapped on the one sentence: you handled the branch's formal complaints log. Answer slot: pick one complaint. If it stayed with you through to a resolution, say what you did and which part was yours, in your own words; if complaints in the log were passed on to others, or you have no case like that, say so plainly and stay with how you kept the log | F1 is the strongest sentence for this value, and it stays at the log's scope. VAL because the value is "whoever finds the problem keeps hold of it until it is solved" |

### J: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "When a complaint escalates from our branch to you, where is the seam between what we do and what you do, and what happens when we disagree?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Offer principles, not a map of a seam you have not seen: the member keeps one owner until it is solved; the branch keeps what it can fix on the day. You were a branch supervisor for three years, so you have stood on the branch side of the seam. Answer slot: if you escalated a complaint to a regional or central team, say what that was like from your side; if complaints never left your branch, say so plainly. On disagreement, show spine and tact together | The panel's branch managers are the people the role coaches and reports to. JD because it concerns the role's cross-branch scope; Peer because the seam is theirs |
| J2 | "What would you need from us in your first month?" | JD | [generic] | Reciprocity first: what you would bring them (a clear route for their complaints, a plain monthly picture), then what you need: time with supervisors and an introduction to their escalation cases. Ask what would be most useful to them, then say it back | Reciprocity is what a peer panel scores. JD because the role depends on branch cooperation |

## Values cheat sheet (round 3)

Values come from the page as you pasted it on 11 November 2026 from ashgrovecu.org/about/values.

| Value (official name) | Working meaning | Your mapped story | Fit row |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No sentence of yours carries a story; selection scaffold in H1, ending in the honest branch | F1 |
| Plain Words | If a member needs it explained twice, the writing was wrong | "trained new tellers on our escalation script" — your message; the script's authorship is an answer slot in H2 | F7 |
| Neighbours, Not Numbers | Every branch is part of its town | "6 years in retail banking, the last 3 as a branch supervisor" — your message; the branch years only, with a selection scaffold in H3 | F5 |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | "I handled the branch's formal complaints log" — your message; H4 | F1 |

## Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| Own the complaints process across branches and the contact centre | B1, D1, D2, G1, G3, J1 | |
| Report monthly on volumes and resolution times | C3, G4 | |
| Coach branch supervisors on escalations | C1, G2 | |
| Work with digital teams on self-service journeys | C4, E1 | |
| 4+ years in financial-services customer operations | A1, B3 | |
| Experience handling regulated complaints | B4 | |
| Confident presenting to senior leaders | D3 | |
| Comfortable with Excel reporting | C3 | Covered inside C3's slot; no separate question, because nothing in your material raises a distinct Excel story |

No headline numbers appear in your material, so there is no defend-the-number question beyond C3's slot.

---

## Reverse questions

### Round 1, the recruiter

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does the panel case work: is the material live, or is there something to read beforehand?" | The format of the 20-minute case is the largest unknown, and the recruiter can usually answer it |
| R2 | "Once the Head of Member Services and the panel are confirmed, can you tell me their roles?" | It asks for what the email says is not yet assigned, and keeps the interviewer read open |
| R3 | "Is there anything in the JD you would want me to cover more fully in the later rounds?" | It invites a stated focus area, which would replace the assumed coverage |

### Round 2, the Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| R4 | "How does complaints handling work in the contact centre today, and where do the branch and the centre hand off to each other?" | It turns the D1 objection into curiosity about the scope you would own |
| R5 | "Who does the monthly complaints picture go to, and what do they ask about it?" | It tells you the senior audience in D3 and shows you think about the reader |
| R6 | "What is changing in complaints handling as eight branches become five hubs?" | It ties your question to the July brief and the manager's own roadmap |
| R7 | "What would you want settled in my first 90 days?" | It asks for the manager's priorities rather than guessing them |

### Round 3, the panel

| # | Question | Why it lands |
|---|---|---|
| R8 | "Which complaints do your supervisors find hardest to escalate, and why?" | A reciprocity question aimed at the panel's own work, and it surfaces the coaching need in F7 |
| R9 | "What would make the monthly complaints report useful to you, rather than something you receive?" | It treats branch managers as users of the reporting duty, not an audience |
| R10 | "What do you most want the central complaints role to do differently for your branch?" | It invites the seam J1 rehearses and signals you will listen before you propose |

## Sources

**Provided documents:** the job description as pasted; the values page text as pasted, copied on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the process, which is the loop source; the 2026 strategy brief, of which the pack read only your four-point summary; your background in your message. No dossier was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the cheat sheet or the VAL bank: the values page pasted this morning supplies the four names and definitions |
| 2. `Ashgrove Credit Union interview process member services` | skipped | Could not have moved the persona weights: the recruiter's email gives three rounds, their lengths, who runs each, the case in round 3 and the values scoring, which establishes the loop |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO and CASE questions: the July 2026 brief, under six months old, supplies four priorities in your summary |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- How many hours you have before 20 November → a prep triage that puts the few things in order and calls the rest insurance
- Names and roles of the Head of Member Services and the two branch managers, once assigned → an interviewer read, persona weights tuned to each, and a reverse question tied to each person's path
- The strategy brief itself → exact wording and figures in the grounding brief; the two `[inferred]` rows become `[grounded]`
- Your answers to the answer slots: what your first three years held; what the spreadsheet measured and what it was built in; whether the logged complaints carried external rules; whether you ever supported another supervisor on an escalation; whether you have worked with a digital or head-office team → F1, F3, F4, F6, F7 and F9 become sourced, and scaffolds in C4 and H1 to H3 become story maps
- An anonymised sample of your monthly complaints spreadsheet or log layout, with no member data → an inspectable artifact that could raise F3 and F4 from their current confidence
- The recruiter's answer on the panel case format, and on any focus areas for round 1, a single email → coverage of what the case gives you beforehand, in place of the assumed structure
- Deeper research, offered once: up to 6 more searches and 2 more fetches, several more minutes → public material on Ashgrove, reports on how its rounds run and recent organisational context for the CO bank
- A `tuesday-dossier.md` from an earlier fit assessment → verified evidence and a sourced objection list in place of this pack's local inference
