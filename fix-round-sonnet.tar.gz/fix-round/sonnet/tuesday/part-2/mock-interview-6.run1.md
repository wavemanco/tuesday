Yusuf, the prep pack for all three rounds is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-6-denied-088c09d2/larkfield-systems_engineering-manager_interview_pack.md`.

It's built as one shared fit snapshot plus a mini-pack per round. The persona weights come from each seat's relationship and the round descriptions you gave me:
- **Tuesday, Director of Engineering:** mostly Skeptic and Case, with a Prober on your 60% figure and a Conversational opener. That is 11 questions.
- **Thursday panel:** Peer Evaluator first, then Case, Prober and Values/Behavioral. That is 11 questions.
- **Monday, VP:** Values/Behavioral first, then Pressure and Case. That is 8 questions, and 30 minutes won't fit them all, so the triage puts them in order.

Each round also has its own reverse questions. The pack includes a prep triage for the gaps between rounds.

**Highest-ROI prep:** R1-A1 and R1-A2. The two gaps you named, managing managers and owning a hardware-adjacent roadmap, are the likeliest first push from a would-be boss. Rehearse the plain acknowledgments for both until they are boring, then say how you would close them.

**What the pack rests on:**
- **No research ran.** My three web searches (values, interview process, strategy) were refused because search permission isn't granted. So there is no values cheat sheet for Monday and no strategy-grounded case questions. The company-specific questions are labelled generic.
- **Only your own words count as your evidence.** The role summary stands in for the JD, and your four sentences about yourself are the only quoted material. Where they don't cover a requirement, the guidance is an answer slot or a selection scaffold, not a story I wrote for you. That applies to device management, growing engineers, working with hardware and product, and owning delivery.

I can play the Skeptic on R1-A1, the question the pack names as your highest-ROI prep, whenever you want to drill it.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full posting and your CV? Everything stands without them, but they would turn the thin summary rows into rows built from the real text.

Did the recruiter say anything about focus areas or a deliverable, such as a case or presentation, for any of the three rounds?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Rounds: Tuesday, 45 min, Director of Engineering (the hiring manager and would-be boss). The Thursday after, 60 min, panel of two staff engineers and a product manager. The following Monday, 30 min, VP Engineering (described by the recruiter as "values and leadership philosophy"). No interviewer names were given, so there is no interviewer read; persona weights come from each seat's relationship and from the loop you described.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows values and leadership, not generic virtue |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The stated role: can you do the listed job, gaps included |
| CO | Company and domain altitude |
| CASE | Structure and reasoning on a live problem from the role |

Question IDs read round, persona letter, number: R1-A1 is Round 1, persona A, question 1. Answer slots (instructions inside guidance that start "Answer slot") are for the interview, not for a reply here.

## Prep triage

The three rounds are about two weeks apart in your calendar, so the plan is sized per gap between rounds. Each step is tied to a question ID.

| Window | Do these, in order | Why these |
|---|---|---|
| Before Tuesday | 1. R1-A1 and R1-A2, the highest-ROI prep in the pack: rehearse the two plain acknowledgments from F1 and F6 until they are boring. 2. R1-C1: write your own notes on how the 60% was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. 3. R1-D1: a 90-second arc built from the sentences it quotes. 4. R1-A3 and R1-A4 slots | The Director is buying capability and de-risking gaps; the gaps are the ones you named yourself |
| Tuesday to Thursday | 1. R2-A1 seam principles. 2. R2-C1 the interview count. 3. R2-C2 the reliability quarter, told in your own words. 4. R2-B1 the roadmap-with-product case | The panel prices what you add to their work and probes your numbers collegially |
| Thursday to Monday | 1. R3-A1 leadership philosophy. 2. R3-B1 the 60-second answer. 3. R3-A2 pick your unpopular-truth story, or have the honest branch ready | Thirty minutes will not fit the bank; rehearse in this order |

Everything else in the pack is insurance.

## Shared fit snapshot

Requirements come from the role summary you pasted (the thin JD; a full posting would replace these rows). Evidence cells hold only your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — JD summary in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message. "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material says a team lead of six for three years and that you have not managed managers; it does not show two groups or eleven people. Words: "For three years I was a team lead of six." If structure comes up: "I've never managed managers." Answer slot: the JD's two squads make a probe on the step from six people to eleven likely. Say in your own words what changes for you at that size; if you do not yet know, say so plainly and say what you would ask first |
| F2 | "building device-management services" — JD summary in your message | none given | none | [grounded] | discovery | Your material shows nothing about device management or IoT. Answer slot: the JD's device-management line makes a probe likely. If any work of yours touched devices or fleets, say what, in your own words; if none did, say so plainly and say what you would learn first |
| F3 | "own delivery" — JD summary in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The sentence carries a reliability quarter, roadmap pressure and an on-call figure; it does not say whether delivery was yours to own. Words stay at the sentence: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." Answer slot: the JD's own-delivery line makes a probe on what you were accountable for likely. If delivery dates or scope were yours to set, say which and how you decided; if they were not, say so plainly and stay with the reliability quarter |
| F4 | "hiring and growth for 11 engineers" (the hiring part) — JD summary in your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No wording gap, but nothing inspected stands behind it, so expect a probe on the figure. Lead in the quote's own terms: you run the hiring loop for backend roles, about 40 interviews last year. The quote says interviews, not hires, and "about" stays "about" |
| F5 | "hiring and growth for 11 engineers" (the growth part) — JD summary in your message | none given | none | [grounded] | discovery | Your material does not show the growth side. Answer slot: the JD's growth line makes a probe on how you develop engineers likely. If growing engineers was part of your work, say how, in your own words; if it was not, say so plainly and say how you would start |
| F6 | "partner with hardware and product on roadmap" — JD summary in your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | low | [inferred] | discovery | Your sentence says you have not owned a hardware-adjacent roadmap; it does not say whether you worked with hardware or product people on one. Words you may say: "I've never owned a hardware-adjacent roadmap." Answer slot: the JD's partner line makes a probe likely. If you worked alongside hardware or product people on a roadmap, say what and which part was yours; if you did not, say so plainly and say what you would ask them first |

### Requirement coverage

| Requirement | JD-tagged questions | Other questions that touch it |
|---|---|---|
| F1 lead two squads | R1-A2 | R1-D1, R3-C1 |
| F2 device-management services | R1-D2 | R1-B1, R1-B2, R2-B2, R3-C2 |
| F3 own delivery | R1-A1 | R1-B3, R1-C2, R3-A1, R3-A4 |
| F4 hiring | R1-A3 | R2-C1, R3-B1 |
| F5 growth | R1-A3 | R3-A3 |
| F6 partner with hardware and product | R1-A1, R2-A1 | R1-B2, R1-B3, R2-B1 |

## Round 1: Tuesday, Director of Engineering (hiring manager), 45 min

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of what the material does not show | High. The hiring-manager prior is Case plus Skeptic, and the two negatives you stated (F1, F6) are the gaps a would-be boss derisks first | Rehearse the single most predictable objection (R1-A1) until it is boring; calibrated candor over bluffing |
| B. Case/Strategist | Live problems from the role: plan this, diagnose that | High. The same prior; the role is device-management services and the roadmap | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| C. Data-Driven Prober | Line-by-line probing of your one metric | Medium. The 60% (F3) is the one headline figure | Know how it was counted; name your weakest assumption before they do; say plainly where you do not know |
| D. Conversational | Friendly opener that is still scored | Medium. A 45-minute first conversation with a future boss almost certainly opens with your journey | A 90-second arc built only from your own sentences |
| Pressure | Interrupts, time-boxes | Low in this round; rehearsed in Round 3 | n/a |

Highest-ROI prep in the pack: R1-A1, with R1-A2 beside it.

### Question bank

#### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The deepest rehearsal in this pack. Choose your weakest area in your own words; if it is the hardware side, the sentence supports: "I've never owned a hardware-adjacent roadmap." Then a ramp plan said as a plan, never as a past: what you would ask hardware and product partners in your first weeks. Follow-up 1, why you anyway: return to the reliability sentence at its own scope, "I pushed a reliability quarter through against roadmap pressure", and add nothing. Follow-up 2, a harder push: hold by returning to the same sentences; concede specifically, "that is a gap, and this is how I would close it", rather than folding on what you did do | F6 and F1 are the likeliest places a would-be boss presses, and F3 is the evidence you hold. JD because it scores the stated role; the hold-then-concede structure is borrowed from the Pressure persona |
| R1-A2 | "I don't see experience managing managers in your background — how would you handle that in this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment first, in your stated words: "I've never managed managers." Your material does not say whether this role has leads under it, so do not adopt that premise; put the question back: do the squads have leads today. Answer slot: the JD's two squads and eleven engineers make a probe on the jump from six people likely; say in your own words what you would do differently at that size, and if you do not yet know, say so plainly | F1 holds the stated negative. JD because the question scores whether you can do the listed job, with the gap named by you |
| R1-A3 | "The role owns hiring and growth for 11 engineers. What have you done on each?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Hiring: "I run our hiring loop for backend roles", with "about 40 interviews last year" as stated; not hires, not offers. Growth: answer slot. The JD's growth line makes a probe on how you develop engineers likely. If growing engineers was part of your work, say how, in your own words; if it was not, or there was no such step, say so plainly and say how you would start | F4 carries the hiring half; F5 is silence, so its half is a slot. JD because it scores two stated responsibilities |
| R1-A4 | "Why leave payments, why industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | The reasons are yours; the pack supplies none. Open with the sentence's own facts, then your reasons in your own words. Answer slot: if part of the reason is the device or hardware side, say what you have actually done or read about it; if you have done none, say so plainly and say what draws you | A motivation-consistency probe is standard for a Skeptic, and F1's evidence names the current employer. JD because it scores fit to the role |

#### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-B1 | "Sketch the plan for onboarding a large batch of newly shipped devices onto a device-management service — what do you need to know first?" | CASE | [generic] | Clarify first: what the devices report, who owns the firmware, what success means. Then objective, segmentation (device types, regions), approach, metrics, risks. Ask your hardware-side questions aloud. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's device-management line (F2); generic because it is a pattern for the problem, not a fact about this employer |
| R1-B2 | "A firmware update fails on a subset of devices in the field. Your squads own the service and hardware owns the firmware — how do you run the next 48 hours?" | CASE | [generic] | Structure: contain, find the affected subset, who decides on rollback, communications, then the seam question afterwards. Propose seam principles rather than pretending to know their seam. No claim about your past | Tests the hardware partnership in F6 without presupposing any experience |
| R1-B3 | "Product wants a feature next quarter, hardware's release cycle means the data it needs arrives a quarter later, and the squads carry a reliability backlog. Walk me through the call." | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure first: clarify what each party needs and by when, options, criteria, who you take it to. Where your reliability quarter bears, say only what the sentence says. Answer slot: if the trade-off in that quarter was yours to argue, say how, in your own words; if it was settled by someone else, say so plainly and stay with the quarter | F3 is the nearest evidence for own-delivery trade-offs; F6 is why hardware is in the case. CASE because it is a live decision |

#### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-C1 | "Walk me through how that 60% on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend-the-number slots, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. Where you do not know how it was counted, say so plainly. Keep "after" as the sentence has it; do not turn it into "I cut it by 60%" | F3's only figure is the likeliest probe target; EXP because it tests what you can stand behind |
| R1-C2 | "Looking back at the reliability quarter, what would you change?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Stay at the sentence: you pushed a reliability quarter through against roadmap pressure. Answer slot: if there is something you would change, say what and why in your own words; if there is nothing, or you did not choose how it was run, say so plainly and return to what the sentence states | A Prober follow-up on F3 that tests honest self-assessment; EXP |

#### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-D1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc with three beats from the first sentence: nine years of engineering, three as a team lead of six, currently at a payments company. Then at most one of the other two sentences as evidence, at its own scope. Close with why this role, in your own words; the pack supplies no motive | A casual opener is still scored; F1 is the arc's spine and F3 or F4 the evidence. EXP because it tests the story you tell about your own history |
| R1-D2 | "What are you actually playing with in device management these days?" | JD | [generic] | Answer slot: if you have been looking at anything in device management, say what in your own words; if you have not, say so plainly and say what you would learn first. Never name tools or projects you have not touched | The JD's device-management line (F2) asked in a casual register; generic because it is a pattern, not a claim about this employer |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What does a strong first six months look like in this role, and where is the biggest delivery risk across the two squads?" | Shows you are thinking in outcomes, and tells you what the job actually is |
| "How are the two squads split, and where do they depend on hardware?" | Surfaces the hardware seam F6 worries about before you accept |
| "Do the squads have leads today, and who do the eleven engineers report to?" | Answers whether this is people-management one level up, which only the room can tell you |
| "How does the roadmap get set between engineering, product and hardware, and where does it break down?" | A diligence question that also shows you expect a trade-off |
| "How does reliability work get weighed against roadmap commitments here?" | Gives you their real operating answer on the theme your own evidence sits on |
| "What would make you say, after a year, that this hire was the right one?" | Gets the scoring criterion in their words |

## Round 2: the Thursday after, panel (two staff engineers and a product manager), 60 min

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator | Seam-splitting, what you would need from them, credit and disagreement | High. Staff engineers are peers or technical specialists; they are pricing what you cost and contribute to their work | Reciprocity framing; propose seam principles rather than a seam you cannot know; disagreement stories that show spine and tact |
| B. Case/Strategist | Live problems; the PM will likely ask a roadmap case, the staff engineers a technical one | High. Panel blend: top two personas of each seat | Clarify before structuring; where your knowledge ends, say so rather than bluff a competency they own |
| C. Data-Driven Prober | Collegial depth-probing of your two specifics | Medium. A technical-specialist relationship pairs Peer with Prober | Know how each figure was counted; say plainly what you do not know |
| D. Values/Behavioral | Scenario probes, often from the PM | Medium. A cross-functional seat tilts to behavioural, and a values-style conversation is likely somewhere in the loop | Selection scaffolds with an honest branch; "we" for context, "I" for contribution |

### Question bank

#### A. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-A1 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a seam: who decides what, what gets escalated and to whom, how a disagreement gets written down. Say plainly that you do not yet know where it hurts for them, and ask. No claim about your past | The seam between squads and hardware or product is F6's territory, and the hardest peer question to fake. JD because it scores the stated partnership |
| R2-A2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Describe the quarter at the sentence's scope: you pushed a reliability quarter through. Answer slot: if others contributed, say who and what in your own words; if it was only your own team, or you cannot split it, say so plainly and stay with the sentence | A standard peer probe on F3's attribution; VAL because it scores how you behave with equals |
| R2-A3 | "As the person who would manage this team, what do you need from us, and what would we get from you?" | JD | [generic] | Reciprocity first: what you bring the peer team, then what you need. Keep both as principles you can stand behind; no claim about your past | A reciprocity question for peers; generic because it asks for a stance, not an event |
| R2-A4 | "Tell me about a time you disagreed with a senior engineer on a technical call and how it ended." | VAL | [generic] | Selection scaffold: pick a time you disagreed with a senior engineer; it needs a named stake, what you held, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer stem "where's the seam, and what happens when we disagree" raises disagreement; your material shows no such story, so this is a scaffold |

#### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "Walk us through how you would build a quarterly roadmap with product when hardware dependencies are uncertain." | CASE | [generic] | Clarify what is uncertain and who knows; objective; options; what you commit versus what you hold open; how you tell product early. No claim about your past | The JD's roadmap partnership (F6) as a live problem for the PM seat |
| R2-B2 | "How would you think about what a device-management service must handle when thousands of devices reconnect at once after an outage?" | CASE | [generic] | Think aloud, structure it, and say where your own knowledge ends; a staff engineer will notice a bluff. Name the questions you would take to the squads. No claim about your past | Tests F2 at the altitude of a manager among strong engineers; CASE because it is a live problem |
| R2-B3 | "A metric we rely on drops 20% after a release — diagnose it." | CASE | [generic] | Clarify what the metric measures and what shipped; segment; hypotheses and how you would check each; who you would involve. No claim about your past | A stock Case stem; included so you are not meeting the style for the first time live |

#### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-C1 | "Walk me through how that 'about 40 interviews' figure was counted." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Slots, in your own words: how it was counted; what it is sensitive to; the assumption you would defend least; which part of the loop was yours. "About" stays "about"; interviews are not hires. If you do not know how it was counted, say so plainly | F4's only figure; a staff engineer who sits on hiring loops will probe it |
| R2-C2 | "Walk me through the reliability quarter." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Beats the sentence carries: a reliability quarter, roadmap pressure, on-call burden down 60% after. Answer slot: if the pressure came from named people, say who and how you handled it; if it was general, say so plainly. Tell it in your own words and add nothing the sentence does not say | F3 again from the technical seat; EXP |

#### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the truth was unpopular and it actually landed; it needs a named stake and an intact relationship. Your material does not show whether the roadmap pressure came from leadership, so do not map the reliability quarter onto this unless it truly fits. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A Values stem; no quoted sentence carries it, so a scaffold |
| R2-D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named customer impact and a metric you gave up; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A Values stem; the PM seat is the likeliest to ask it; scaffold because nothing quoted carries it |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What could a new manager do in their first month that would genuinely help your work?" | The reciprocity question for peers: it asks what you can reduce for them |
| "Where do the squads' priorities and the platform's priorities collide most?" | Names the seam and shows you expect one |
| "What is the one thing on the on-call rota or in the codebase you wish someone would fix?" | Pulls out the reliability pain in their own words |
| "How does product hear from customers and hardware, and where do you want engineering more involved?" | The PM's own territory, asked as a question about them |
| "How are technical disagreements settled today?" | Gives you the operating model |
| "What does great partnership with engineering look like from your seat?" | A direct question for the PM that sets the scoring criterion |

## Round 3: the following Monday, VP Engineering, 30 min

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Values/Behavioral | "Values and leadership philosophy", scenario probes | High. The recruiter's own description names this round's focus, and a values-style round is detected from it | Map to a story one of your sentences carries; where none does, a selection scaffold with its honest branch |
| B. Pressure | Time-boxed, devil's advocate, "why you over an internal" | Medium. The skip-level prior is Case plus Pressure; composure is scored | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| C. Case/Strategist | Altitude: what you would do with two squads, domain fluency | Medium. Skip-level priors | Say your framework aloud; where your knowledge ends, say so |

The recruiter's description is the only source for this round's focus. The company's published values were not available, so there is no values cheat sheet; see the upgrade menu.

### Question bank

#### A. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-A1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Anchor in the one sentence you can stand behind: "I pushed a reliability quarter through against roadmap pressure." What that shows about how you lead is yours to say in your own words; the pack does not say what it is proof of. Answer slot: if there is a principle you held behind that decision, say it in your own words; if you do not have a name for one, say so and describe what you did | The recruiter's words raise leadership philosophy; F3 is the only quoted sentence about how you act under pressure |
| R3-A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the hard truth actually landed; it needs a named stake and an intact relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A Values stem; no quoted sentence carries it |
| R3-A3 | "What kind of manager do you want to be for engineers who are stronger than you at something?" | VAL | [generic] | A principle, one behaviour that follows from it, one limit you hold. It is your stance; the pack supplies none and claims nothing about your past | Leadership philosophy is the recruiter's own phrase; the question has to be answered in your voice |
| R3-A4 | "How do you balance roadmap commitments against the load your team carries?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Use only the sentence: on-call burden, a reliability quarter, roadmap pressure. Answer slot: if you weighed the two explicitly, say how in your own words; if you did not, say so plainly and describe what you did | Draws on F3's own terms, and on what the VP may think about sustainability; VAL |

#### B. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-B1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause and restate. Then at most two of the three evidence sentences, at their own scope. Hold through two follow-ups by returning to them, not adding to them. If pressed on the gap, concede it specifically in the sentence's words: "I've never owned a hardware-adjacent roadmap", then the plan | A Pressure stem; F1, F3, F4 and F6 are what an internal candidate would be measured against |
| R3-B2 | "That reliability result — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the sentence: you pushed the quarter through. Answer slot: if others did parts, say which and say so plainly, in your own words; if you cannot separate them, say so and stay with the sentence. Do not defend more than you did | F3's attribution, asked under pressure; the honest answer is the safe one |

#### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | "You inherit two squads and eleven engineers, with hardware and product pulling in different directions. What do you do in the first two weeks, and what do you refuse to do?" | CASE | [generic] | Clarify what you would want to know, then a plan: listen, understand the squads, meet the partners, one early commitment, one thing you will say no to. No claim about your past | A skip-level altitude case on F1's scope |
| R3-C2 | "What do you think industrial IoT customers are most likely to care about in device management, and how should that shape what two squads build?" | CO | [generic] | No research ran, so say what you know and where it ends; ask a question back. Do not assert facts about this company's customers | The CO question this pack can honestly carry without research; generic because it states nothing about this employer |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What do you want the engineering organisation to be known for in two years?" | Asks for the VP's altitude in their own words |
| "What leadership behaviour do you most want to see more of in the managers at this level?" | Lets you hear the bar directly |
| "Where has a value pulled against the roadmap recently, and how did you decide?" | Turns the values round into a concrete example you can learn from |
| "How do you develop managers here, and what does growth look like for someone in this role?" | The growth side of F5 asked about yourself |
| "What do new managers here find hardest in their first year?" | Surfaces the real difficulty before you accept |

## Prohibited claims

Built from the fit snapshot before the banks were written. Not coached, each with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers or led leads | Negative you stated, F1 | The plain acknowledgment: "I've never managed managers." No slot, no bridge |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." F6's slot asks only about working alongside hardware or product people |
| Led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope. The pack's observation: the material says a team of six |
| Owned delivery or set the roadmap | Inflated form of F3 | F3's quote at its own scope. The pack's observation: the material says a reliability quarter and an on-call figure, not delivery ownership |
| Cut on-call burden by 60% on your own | Inflated form of F3 | The sentence as written: it dropped 60% after you pushed the quarter through. R1-C1 and R3-B2 slots ask which part was yours |
| Hired about 40 people, or made the hiring decisions | Inflated form of F4 | F4's quote: about 40 interviews. The pack's observation: the material says the loop and the interviews, not hires |

## Sources

Provided: your message (the role summary, the three rounds with who runs each and how long, your four sentences about yourself, and the recruiter's description of the Monday round). No `tuesday-dossier.md` was in the working directory, so none was consumed. The loop is established by your own words (three sessions, who runs each), so no archetype fallback applies.

Searches sent, all refused (the host did not grant search permission); each returned nothing:

- "Larkfield Systems industrial IoT company values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT device management strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have fed a values cheat sheet for Round 3; the section is dropped and the values themes rest on the recruiter's words alone |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. It would have checked the loop beyond your own description; persona weights rest on your stated rounds only |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The search was refused. It would have grounded the CO and CASE questions in current priorities; they are labeled generic |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | skipped | The role summary you supplied fixes the fit rows and the JD-tagged questions as far as it goes; a full posting is the upgrade, not a search |

## Upgrade menu

- Full posting text → the six rows built from a one-sentence summary become rows built from the posting's own words, and any gate the summary omits (location, travel, schedule) becomes visible
- Your CV → the story-mapped guidance replaces the scaffolds in R2-D1, R2-D2, R2-A4 and R3-A2, and F2 and F5 may gain quotes
- Your answers to the slots in F1, F2, F3, F5 and F6 → those rows upgrade from discovery or transferability and the questions that draw on them get story-mapped guidance
- Search permission → a values page for a Round 3 values cheat sheet, the loop check, and a strategy sweep that grounds R3-C2 and the CASE questions; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can be offered once searches run
- The names of the Director, the two staff engineers, the PM and the VP → an interviewer read per seat, persona weights per panel member, and a reverse question tied to each person's public path
- The recruiter's focus areas or any pre-declared deliverable for any round → coverage built to what they said, and a build section for any announced deliverable
- Prep hours per day → the triage resized to your actual time
- A `tuesday-dossier.md` from an earlier role assessment → confirmed, graded evidence and a named top objection in place of the ones inferred here; never a prerequisite
