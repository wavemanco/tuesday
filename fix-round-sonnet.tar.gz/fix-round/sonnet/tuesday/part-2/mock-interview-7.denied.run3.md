Web search was denied, so I'm building the pack from your JD and background alone. I'll mark everything that research would have supplied.
Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-denied-acf6fd51/saltmarsh-games_live-operations-producer_interview_pack.md`.

I built it for a hiring-manager conversation with Tobias, since your note didn't say how he relates to the role. My four web searches (company values, interview process, strategy, Tobias) were all refused, so nothing about Saltmarsh itself is researched. Company-specific questions are marked `[generic]`, and the Sources section lists what each refused search would have changed.

- **Biggest prep item:** B1, "I don't see in-app purchases in your background." It's the one gap you stated outright, and your material has no adjacent line to bridge it. Rehearse saying it plainly, then giving a learning plan, without implying experience you don't have.
- **Second:** B2, leading and coordinating teams. You've never led a team, and the JD asks you to coordinate four.
- **Thinnest rows:** owning the post-event review and KPIs, and managing the release checklist with QA. Your material says you presented the retention numbers and wrote the checklist, so the pack keeps your answers at that scope.
- **Prohibited claims:** the pack lists wordings it won't coach, such as "ran live events across two titles" and "owned the KPIs".
- **Size:** 22 questions across seven personas, with an answer slot wherever the pack couldn't know what you did.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and has the recruiter mentioned a format such as a case or take-home? Either answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: assumed hiring manager, not confirmed. Format: one 60-minute session on Friday, session mode. Research did not run (web search was declined), so company-specific rows are `[generic]` and the Sources section says what that cost.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: every sentence it says about your past is one of your own quoted sentences, and every place the pack could not know something is an answer slot for you to fill in your own words or honestly leave empty.

| Type | What it scores |
|---|---|
| VAL | Past behavior against values, not generic virtue |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The listed responsibilities and requirements, gaps included |
| CO | Homework on the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage (between now and Friday)

1. Say B1 and B2 aloud until the plain acknowledgment stops feeling hard. This is the highest-ROI prep in the pack.
2. Say the D1 arc aloud once, under 90 seconds, in your own words.
3. Settle C1 on paper: for each of the four parts, write down what you can say and what you do not know. Answer slots only work if you have already decided the honest branch.
4. Run two of A1 to A4 aloud, thinking out loud with the structure in the guidance.
5. Prepare D2 and A5: play a mobile title with live events and write down one observation.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's calendar line makes a probe on how your calendar differs from the one this role runs likely. If you can say what differs, say it in your own words; if there is no such difference, or you have not seen this role's calendar, say so plainly and stay with the weekly calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | Your material shows the calendar and does not show which teams you worked with on it, and the pack does not fill that in. Answer slot: the JD names four teams, so a probe on how an update moved between them is likely. If you worked with any of them on updates, say which and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you defined or produced them, with nothing inspected behind it. The words stay at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on who defined and produced those numbers likely. If you chose or built any of what was reported, say which and how, in your own words; if you presented numbers someone else produced, or no such step was yours, say so plainly and stay with the monthly presentations to the studio head |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that your QA team still uses it, with nothing inspected behind it: "I wrote the release checklist our QA team still uses." Answer slot: the JD's with-QA line makes a probe on what you and QA did with the checklist after it was written likely. Say what happened to it, in your own words; if it was simply handed over, say so plainly and stay with the fact that QA still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material gives the years, the title and the kind of studio, and does not show how the title's updates ran. Answer slot: the JD's years line makes a probe on the kind of title you worked on likely. Say what the title was and how its updates ran, in your own words; if it did not work that way, or the updates were not yours, say so plainly and stay with the four years as an associate producer |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: weekly, your main title, two years. A named cadence beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but nothing inspected behind it, so expect the probe in C1 on how the numbers were counted. Lead with the quote's own terms: monthly, retention, the studio head as audience |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A written document a team still uses touches the requirement and does not show whether it was clear. Answer slot: if you wrote anything else that others relied on, name it; if nothing comes to mind, say so plainly and stay with the checklist your QA team still uses |
| F9 | No JD line; a gap you named yourself: in-app purchases — your message | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | No JD line; a gap you named yourself: leading a team — your message | "Never led a team" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never led a team." Then how you would get work moving across teams, said as a plan. The JD line in F2 says coordinate, and the pack does not treat that as leading |

## Persona table

Weights start from the relationship prior (hiring manager: Case/Strategist plus Skeptic), then adjust for the loop. The loop is what you told me: one 60-minute session with Tobias. No interviewer signals were available because the search that would have found them was refused, and no source documents a values round. Recalibrate if you know otherwise.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems on a calendar, an update or a release | High (5 questions): the hiring-manager prior, and the JD's duties convert directly into live problems | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet, persistent probing of absent background | High (5 questions): the hiring-manager prior, and the two largest gaps are ones you named yourself (F9, F10) | Rehearse the single predictable objection until it is boring; bridge only from adjacent quotes; a concrete ramp plan |
| C. Data-Driven Prober | Line-by-line questions on how a number was counted | Mid (3 questions): the JD names retention metrics and KPIs, and F7 is a quote about presenting them | Know what you can and cannot say about each number, say plainly when you do not know, name the weakest assumption first |
| D. Conversational | Opening arc, "what are you playing" | Mid (3 questions): a conversation tends to open this way, and casual questions are still scored | A 90-second arc; treat casual questions about live events as scored; never answer "I think you've covered everything" to the reverse-question slot |
| E. Pressure | Time-boxed "why you", attribution challenges | Low (2 questions): no signal in the inputs; kept because the gaps invite it | Pause, restate, hold the position through two follow-ups, concede specifically |
| G. Values/Behavioral | Scenario probes on principles | Low (2 questions): no source documents a values round, so this is rehearsal only | Choose stories where the hard truth landed; where none exists, say so |
| H. Peer Evaluator | Seam-splitting between teams | Low (2 questions): rises sharply if Tobias is not your future manager or others join the session | Propose seam principles rather than pretending to know the seam; reciprocity framing |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A title's event participation has dropped three weeks running. What do you need to know first, and how do you diagnose it?" | CASE | [generic] | Clarify before structuring: what counts as participation, which players, what changed and when. Then objective, segments, approach, the numbers you would check, risks. Think aloud and challenge one premise, such as whether the drop is real. The question needs no claim about your past, so the guidance makes none | Tests the retention-metrics line (F7) as a live diagnosis rather than a story. CASE because it is scored on structure, with JD content |
| A2 | "Plan the next four weeks for a title: one major event, one smaller event and one update that needs engineering sign-off. How do you sequence it, and what do you check before you commit?" | CASE | [generic] | Ask for constraints first: what is already locked, what depends on what, each team's capacity. Then sequencing logic, what you would confirm with design, art, engineering, community and QA, and the trade-off you chose. No claim about your past | The JD's calendar and coordination lines (F1, F2) as a live problem. CASE with JD content |
| A3 | "Players say the weekend event felt grindy. Design wants to hold, engineering says a change needs a hotfix, community wants an answer today. What do you do?" | CASE | [generic] | Say who decides and how you would find out, what evidence you need before changing anything, the options with their costs, what you tell each team and the players, and what goes into the post-event record. No claim about your past | Coordination under disagreement (F2) and the review loop (F3) in one problem. CASE because it is a decision, not a story |
| A4 | "A release is due Thursday and QA raises a blocker on Wednesday evening. Take me through your next hour." | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Structure: what the blocker is and how severe, the options (hold, fix, ship with a mitigation), who decides, who hears what and when. If you refer to your checklist, use the quote's words and stop there: you wrote it, and your QA team still uses it. The case itself needs no claim about your past | Tests the release line (F4) as a decision. CASE because it is scored on reasoning under time pressure |
| A5 | "What have you noticed about our games, and what would you want to understand before suggesting a change?" | CO | [generic] | Selection scaffold: before Friday, play each title long enough to note one concrete observation (event structure, rhythm, how players are told). Say it as an observation, not criticism, and end with what you would ask the team. If you have not played them, say so plainly, then say what you would do in your first week. The pack could not research the titles | CO because it tests homework; `[generic]` because research did not run. Ties to the two titles in F1 |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see in-app purchases anywhere in your background. How would you handle that in this role?" | JD | [grounded] "never worked on a game with in-app purchases", "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. Say the plain acknowledgment first and do not pad it: "I've never worked on a game with in-app purchases." Then the plan, said as future: who you would ask, what you would read, what you would want to understand in your first weeks, in your own words. You may offer the adjacent fact at its own scope, "I presented the monthly retention numbers to the studio head", and let him draw any link; do not say it is the same as purchase experience. Follow-ups to rehearse: what worries you most (name one specific thing to learn) and why take the bet (concede the gap is real and return to what you have said you did; never fold by implying experience you lack) | F9 is the one gap you stated flat out, with no adjacent quote to bridge it, so a rehearsed non-defensive answer is the whole defense. JD because it scores fit against the role; the Skeptic stem asks about absent background |
| B2 | "I don't see you leading a team, and this role coordinates design, art, engineering and community. How would you get them moving together on one update?" | JD | [grounded] "Never led a team", "I ran the weekly content-drop calendar for our main title for the last two years" | Plain acknowledgment first: "I've never led a team." Then how you would coordinate without authority, said as a plan: one calendar everyone reads, asking each team what it needs and when, agreeing who decides. Answer slot: if you worked with any of those four teams on the calendar you ran, say which and how; if you did not, or it was not yours, say so plainly and return to the calendar. Hold through two follow-ups, then concede specifically | F10 is a stated gap and F2 is where the JD presses on it; second-highest ROI. JD because the four teams are the JD's list |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases", "Presented the monthly retention numbers to the studio head" | Name your real weakest area before he does, and pick one you can stand behind. Your material gives two candidates: the stated gap (B1 covers it) and the JD's own-the-review-and-KPIs line, where your quote says you presented the numbers. For the second: if you chose or built any of what was reported, say which; if not, say so plainly. Then one concrete first-month step | Honest self-assessment is what this stem scores. F3 and F9 are where the material is thinnest. JD because it is read against the listed duties |
| B4 | "You ran a weekly content-drop calendar. How is that different from a live-events calendar?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F1: the calendar, weekly, your main title, two years, which are the beats the quote states; tell them in your own words. Answer slot: if you can say what differs, say it; if you see no difference, or do not know what this role's calendar holds, say so plainly and stay with the weekly calendar you ran. You can turn it into a conversation by asking about the rhythm of his calendar | F1 is the evidence for the calendar requirement and the likeliest place to be probed. EXP because it tests what your calendar actually was |
| B5 | "This role covers two of our titles. Your calendar was for your main title. How would you handle two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say what the quote carries: the weekly calendar for your main title. Answer slot: if you ever planned more than one title or stream, say how; if not, say so plainly. Then the plan, said as questions you would ask: what rhythm each title has, where they compete for the same teams, how he wants your attention split | F1 names two titles, and your material names one. JD because the two-title scope is the JD's |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented each month were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot, four parts, each in your own words: how the numbers were counted, what they were sensitive to, the assumption you would defend least, and which part of the work was yours. If you do not know how something was counted, say so plainly. The pack supplies no method, baseline or figure. Name the weakest assumption before he does | F7 and F3 are the quote a prober reads closest. EXP because it tests attribution and how the numbers were counted |
| C2 | "Which retention numbers would you want in a post-event review, and what would each one tell you?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Start from the decision the review serves, then pair each number with the question it answers and what you would compare it to; choose a few rather than reciting a glossary. You may anchor in the quote, "I presented the monthly retention numbers to the studio head", and no further | F3 and F7 together: the JD wants someone who owns the review's numbers. JD because it is the listed duty |
| C3 | "The review says an event the whole team liked hurt retention. What do you do with that?" | CASE | [generic] | Check the data before the story; separate the event from anything else that changed in the window; share it plainly and early with the teams; decide what to keep; record it. No claim about your past | Tests the JD's own-the-review line (F3) under social pressure. CASE because it is a decision |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | A 90-second arc, each beat a clause one of those sentences states: the four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for your main title over the last two years, the release checklist your QA team still uses, the monthly retention numbers to the studio head. Answer slot for the last beat: say in your own words what draws you to this role at Saltmarsh; the pack supplies no reason | F5, F6, F4 and F7 are the whole stated career. EXP because it is the biography question; casual in register, scored all the same |
| D2 | "What are you actually playing at the moment, and what have you noticed about how it runs its events?" | JD | [generic] | Selection scaffold: pick a title you genuinely play and one observation about its events (rhythm, how players are told, what it asks of them). If no live mobile title comes to mind, say so plainly, then say what you have looked at for this interview | Casual questions about the JD's central topic are scored; the stem comes from the Conversational persona. `[generic]` because it asks for your own choice |
| D3 | "How do you like to communicate around an update: messages, docs, meetings?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F8: a written checklist your QA team still uses, which are the beats the quote states. Answer slot: if anything about how you wrote it was deliberate for clarity, say what, in your own words; if you did not write it with that in mind, say so plainly and describe it as it stands | F8 is a low-confidence row, so the rehearsal is what makes it credible. JD because the JD lists written communication |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses" | Pause and restate first. Hold-then-concede: concede plainly, "I've never worked on a game with in-app purchases", then hold only what the quotes carry: the weekly calendar for your main title over two years, and the checklist your QA team still uses. Do not claim you would learn faster; nothing here supports it. Hold through two follow-ups by returning to the same two facts | The same gap as B1 (F9), delivered under time pressure. JD because it scores fit against the role |
| E2 | "That retention work: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: who produced the numbers and which parts were yours; if you assembled them, say how; if someone else produced them and you presented, say so plainly. Concede uncertainty specifically, never on the core claim | F3 is where the claim is thinnest. EXP because it is an attribution probe |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end; "we" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not supply an ending the facts do not have | F7 is the nearest quoted material and is silent on whether any of it was unwelcome. `[generic]` because no quote carries a story here |
| G2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, what you weighed, what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A Values stem, kept for rehearsal only because no source documents a values round |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Where is the seam between live operations and design on an update, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who owns the calendar, who owns the content, how a disagreement is escalated, decided and recorded. Reciprocity: say what you bring to them, not only what you need. No claim about your past | F2 is the coordination line; this is its collegial form, likelier if Tobias is not your future manager |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams and say what you did about credit, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A Peer stem. Kept short because the persona is low weight in this assumed round |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| F1 live-events calendar, two titles | A2, B4, B5 |
| F2 coordinate design, art, engineering, community | A2, A3, B2, H1 |
| F3 own post-event review and KPIs | A3, B3, C1, C2, C3, E2 |
| F4 release checklist with QA | A4, D3 |
| F5 3+ years producing | D1 |
| F6 content calendar | B4, D1 |
| F7 player-retention metrics | A1, C1, C2, E2 |
| F8 clear written communication | D3 |
| F9 in-app purchases (no JD line) | B1, B3, E1 |
| F10 leading a team (no JD line) | B2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like for this producer across the two titles?" | Invites him to define success in his own terms and shows you are thinking about scope |
| R2 | "Where does an update most often get tight: the design handoff, engineering, QA or community?" | Gets at the real friction in the JD's coordination line (F2) and lets you relate it to your own calendar work |
| R3 | "How is a post-event review run today, who reads it, and what has it changed recently?" | Tests the JD's own-the-review line (F3) from his side and shows you care about decisions, not decks |
| R4 | "How do purchases and events inform each other in your titles, and who would I learn that from?" | Turns the stated gap (F9) into a learning plan he can respond to rather than a confession |
| R5 | "How does the release checklist work between the producer and QA today, and what would you change?" | Connects to F4 and invites a conversation about something you have already written |
| R6 | "How would you like me to work with community in the weeks around an event?" | Shows you see the community team as part of the calendar, not an afterthought |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Planned and ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar for your main title. The slots in B4 and B5 stay inside it |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says you presented the numbers, not that you defined them or owned the review. The slots in C1 and E2 stay inside it |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says you wrote the checklist, not that you managed releases against it. A4 and D3 stay inside it |
| Four years of producing live-service games or apps | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says associate producer at a puzzle-game studio and does not say how its updates ran. D1 stays inside the quotes |
| Led a team | Negative the candidate stated, F10 | The plain acknowledgment F10 gives: "I've never led a team." No slot |
| Has worked on a game with in-app purchases | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I've never worked on a game with in-app purchases." No slot |

## Sources

Provided: the JD you pasted, and your background as written in your message. No dossier was present.

Searches sent, all refused by the host (nothing returned, nothing used):

- Saltmarsh Games values: refused
- Saltmarsh Games interview process live operations producer: refused
- Saltmarsh Games strategy news mobile: refused
- Tobias Wrenfield Saltmarsh Games: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have set the VAL themes by published value names; G1 and G2 stay `[generic]` |
| 2. `Saltmarsh Games interview process live operations` | unavailable | Would have named the loop's rounds and set persona weights; they rest on your description (one session with Tobias) and the hiring-manager assumption |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have grounded a CO or CASE question in current strategy; A5 and the CASE questions are `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have supplied the interviewer read and adjusted persona weights; the section is dropped |
| 5. representative `Live Operations Producer` JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to run web search → the four unavailable rows above: values themes, the loop, a strategy-grounded CO question, and an interviewer read with a reverse question tied to Tobias's own path
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), once search is allowed → a strategy brief for the CO and CASE banks, plus interviewer talks and writing
- Whether Tobias is your future manager, and any format guidance from the recruiter (a case, a take-home, a presentation) → reweights every bank and adds a build section if a deliverable was announced
- The names of the two titles → A5, D2 and R2 become `[grounded]` instead of `[generic]`
- Your own answers to the answer slots in F1, F2, F3, F4, F5 and F8 (said outside a drill) → those rows get quoted evidence and the guidance that draws on them regenerates
- A monthly retention slide, the release checklist document, and a calendar export (anonymized) → the inspectable artifacts that would move F3, F4, F6 and F7 from medium toward high
- A tuesday-dossier.md from an earlier underwriting pass → verified evidence, per-gap strategies and absolute prohibited claims, sharpening B1 and B2
