Search permission was denied, so I'm building the pack from what you've given me. That's your JD and background, with nothing researched about Saltmarsh. I'll write it now.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-denied-4b0456ee/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say how Tobias relates to the role. Web search was denied, so none of it is researched. It rests on your JD and background only, and the Sources table shows the four refused searches. Anything about Saltmarsh's titles, values or Tobias himself is labeled `[generic]`.

I can run a live drill as the Skeptic on B1, which the pack names as your highest-ROI prep: coordinating four disciplines when you haven't led a team.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, or a peer or skip-level? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. **Round:** one 60-minute interview, Friday. **Built on this assumption:** a hiring-manager round, because your note did not say how Tobias relates to the role. If he is a peer or a skip-level, the persona weights below change.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. No published values were in hand for this pack, so VAL rows here follow persona stems, not Saltmarsh's own values |
| EXP | Whether a claim about your work survives scrutiny, and what was actually yours |
| JD | A stated responsibility or qualification, including its gaps |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem set in the role, answered by structuring it aloud |

Provenance labels: `[grounded]` traces to a document you gave me, `[inferred]` is derived from one and the derivation is named, `[generic]` is a role-family pattern with no claim about you or Saltmarsh.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title. It does not say the drops were live events, that a second title was involved, or that the main title was a mobile game. Words stay at the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD line makes a probe on events, the second title and the platform likely. If any drops were time-limited events, say which and how they were scheduled, in your own words; if none were, or you worked on one title only, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team, and never worked on a game with in-app purchases" — your message | low | [inferred] | discovery | The quotes do not show who the calendar was coordinated with, so coordination across the four disciplines is not established either way. The JD line says coordinate; your message says you have not led a team. Answer slot: if you worked with any of design, art, engineering or community on the drops, say which and how dates got agreed, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar you ran. The plain acknowledgment you have stated is: "I haven't led a team." |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says monthly retention numbers were presented to the studio head. It does not say a review followed any content drop or event, or who chose the figures. Words stay at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: the JD line makes a probe on the post-event review likely. If a review followed any drop, say what it covered and what part was yours; if there was no such review, or it was not yours, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | The quote says you wrote the checklist and that QA still uses it. It does not say how releases were run against it. Words stay at the quote: "I wrote the release checklist our QA team still uses." Answer slot: the JD says manage, so expect a probe on how the checklist was used release to release. If you worked through it with QA on releases, say how, in your own words; if you wrote it and others ran it, say so plainly and stay with the writing |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | discovery | Your material gives four years as an associate producer and two years of the calendar. It does not show which years were on a live game with ongoing updates, so whether the requirement is met is not established. Answer slot: if the years you have named were on live-service work, say which and how, in your own words; if only the calendar years were, or none were, say so plainly and stay with the quotes |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on the calendar itself. Lead with it in the quote's own terms: you ran the weekly content-drop calendar for the last two years, because a named cadence beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Reword only the quote: "I presented the monthly retention numbers to the studio head." Presenting numbers is not the same as producing them, and the quote says presented, so expect C1 to ask where the numbers came from |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | The checklist is the one written artifact your material names, and it does not show how clear it was or who else read it. Answer slot: if other writing was regularly yours, say what and for whom, in your own words; if the checklist is your main example, say so plainly and stay with it |

## Persona table

Weights start from the hiring-manager prior (Case/Strategist and Skeptic dominant), which is an assumption about this round. Your message establishes one session run by Tobias, and names no values-style round, so none is assumed. Depth follows weight: 5, 4, 3, 3, 2, 2.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| A. Case/Strategist | Live problems from the role: plan a calendar, diagnose a retention drop, run a release under pressure | Highest. A hiring manager buys capability and the JD is a list of live duties, so each duty converts into a problem | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully per case |
| B. Skeptic | Quiet, persistent probing of the gaps | High. Your message states two gaps outright, and the JD's coordination duty presses on one of them | Rehearse the most predictable objection until it is boring. Bridge only from what you stated, say the limit plainly, and bring a concrete ramp plan |
| C. Data-Driven Prober | Reads your lines closely and asks how a number was counted | Mid. The retention presentation is the one figure-bearing line in your material, and F7 points at it | Know what you can and cannot say about how the numbers were counted. Name the assumption you would defend least before they do |
| D. Conversational | Friendly, unstructured; the biography question and casual questions about live events | Mid. A 60-minute interview opens this way and casual questions are still scored | A 90-second arc built from your own sentences. Treat the casual questions as scored. Never let the reverse-question slot go generic |
| E. Pressure | Time-boxed challenges, "how much of that was you" | Low. Often rides inside a hiring manager's follow-ups, so two questions are enough | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |
| F. Values/Behavioral | Scenario probes, STAR-shaped stories | Low. No values page was in hand and no values round is named, so these rows follow persona stems | "We" for context, "I" for contribution. Where no story comes to mind, say so plainly |

## Question banks

Highest-ROI prep in this pack: **B1**. It is the objection most directly tied to a duty the JD names. Rehearse it until the concession wording is boring.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Suppose you inherit the live-events calendar for two mobile titles next quarter. Sketch the plan. What do you need to know first?" | CASE | [grounded] | Needs no claim about your past, so the guidance makes none. Ask first: what each title's events are meant to move, what cadence exists today, what fixed dates (releases, store events) constrain you, how much team capacity there is. Then objective, segmentation by title and by player group, a calendar frame, the metrics you would watch, the risks. Challenge one premise politely. Say you would check each assumption against how Saltmarsh actually runs it | The JD's first duty converted into a problem (F1's requirement). CASE because it scores structure; JD because the theme is the duty |
| A2 | "Design wants one weekend for its update, engineering says another update takes the same weekend, and art says assets will slip. How do you decide, and what do you tell each team?" | CASE | [generic] | Needs no claim about your past. Clarify what is fixed and what can move, what each slip costs, then who needs to agree to what. State your recommendation, and say what you would tell each team and by when. Close with the risk you are accepting. If this resembles something you did, say so in your own words; if not, say you are reasoning from first principles | The coordination duty (F2's requirement) as a live trade-off. `[generic]` because the scenario is a pattern, not a fact about Saltmarsh |
| A3 | "Retention for players who joined during the last event is 20% below the event before it. Diagnose it." | CASE | [generic] | Needs no claim about your past. Clarify first: which retention measure, which cohort, what else changed (a release, an overlapping event, a shift in where players came from). Then segment, list hypotheses in order of likelihood, say what data you would pull for each, and what would change your mind. Say plainly what you would not conclude from the data alone | The retention requirement (F7's requirement) as a diagnosis, the persona's own stem. CASE because it is delivered live |
| A4 | "An event has just ended. What post-event review would you run, and which KPIs would you report?" | CASE | [grounded] | Needs no claim about your past, so describe what you would do, not what you did. Start from the event's goal set before it ran, compare against a baseline, separate what worked from what coincided, end with the decisions the review should change. Choose two or three KPIs tied to the goal and say why. Where a KPI depends on in-app purchase revenue, say you would ask the team for its definitions rather than guess | The JD's review-and-KPIs duty (F3's requirement). CASE delivery of a JD topic |
| A5 | "A hotfix is needed on Thursday while a Friday event release is already with QA. How do you run it?" | CASE | [generic] | Needs no claim about your past. Clarify severity and what the hotfix touches, what QA has and has not covered, then the options (ship both, split them, hold the event) with the cost of each. State a recommendation and the communication it triggers. If you have handled something like this, say so in your own words; if you have not, say you are reasoning it through | The QA duty (F4's requirement) under time pressure. `[generic]` pattern |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates design, art, engineering and community on every update, and you haven't led a team. How do you get four disciplines to hit a date?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Highest-ROI rehearsal. Name the limit first, in the words you stated: "I haven't led a team." The JD line says coordinate, not lead, and that is the ground to stand on. Then the answer slot: if you worked with any of the four disciplines on the weekly drops, say which and how dates got agreed; if you did not, or it was not yours, say so plainly and stay with the calendar you ran. Follow-up one: what if engineering says no? Describe how you would handle it as a plan, not a past. Follow-up two: who decides when a date moves? Say how you would find out here. Never describe an authority you did not have | F2 is the thinnest row on a named duty, and the one where you stated a limit. JD because it scores a stated duty, Skeptic because it targets the gap |
| B2 | "I don't see in-app purchases anywhere in your background. What would you need to learn first?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Say the stated limit plainly: "I haven't worked on a game with in-app purchases." Then give a plan, not a past: what you would ask the team for first (how events relate to monetization, who sets the goals, which reports to read), and how you would ramp. The persona stem is the raising source for this probe; the JD text you gave me does not mention in-app purchases, so ask Tobias what the role touches rather than assume | The stated gap, rehearsed so the honest answer is ready before the probe. Skeptic because it targets background mismatch; the rationale rests on F3 and F7 being the rows where revenue-linked questions would land |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Pick one row from your fit snapshot where your own answer to the slot was no: F2, F3, F5 or F8. Say it plainly, then what you would do in your first weeks, as a plan. Calibrated candor beats bluffing a competency the interviewer owns | The persona's own stem. Choosing from the snapshot keeps the answer inside your quotes |
| B4 | "The role asks for 3+ years producing live-service games or apps. How does your time at the puzzle studio map to that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Give the two facts at their own scope: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the last two years. Answer slot: the JD's 3+ years line asks about live-service work. If that applies to the years you have named, say which and how, in your own words; if it applies only to the calendar years, or not at all, say so plainly and stay with the quotes | F5's requirement presses here. JD because it scores a stated qualification |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Defend the number in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. The quote says presented. If you produced the analysis, say so; if you presented numbers someone else produced, say so plainly. "I don't know how that was counted" is an honest branch. Name your weakest assumption before they do | F7 is the one figure-bearing line in your material. EXP because it tests attribution |
| C2 | "The posting says comfortable with player-retention metrics. Which ones are you comfortable with, and which are you not?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Name the metrics you have actually worked with, in your own words, and say plainly which you have not touched. Do not list measures from memory of what a live game uses. The quote says you presented the monthly numbers; stay at that scope | F7's requirement asked directly. JD because it scores the stated qualification |
| C3 | "Tell me about a time a number you reported changed what the team did next." | EXP | [generic] | Open prompt, so no story is mapped to it from your material. Pick a time with a named number, a named decision and your part in it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's KPIs duty (F3's requirement) as a behavior probe. A selection scaffold, because none of your quotes carries a story for it |

### D. Conversational/Rapport Builder (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc with only the beats those sentences state: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the last two years; the release checklist you wrote that QA still uses; the monthly retention numbers you presented. Then answer slot: why this role and why Saltmarsh now. Your material does not say; say it in your own words | The biography question every conversational round opens with (F5, F6). Built from your sentences only |
| D2 | "What live events in mobile games have caught your eye lately, and why?" | CO | [generic] | Open prompt. Pick an event you have actually seen, say what you noticed as a producer, and what you would have asked its team. If none comes to mind, say so plainly and name what you would study first | The casual JD-topic question the persona asks (F1's requirement). `[generic]` because no research on Saltmarsh's titles was possible |
| D3 | "Have you played our titles? What did you notice?" | CO | [generic] | Needs no claim about your past. Play both before Friday and bring two or three observations about their live events, said as observations, not criticisms. Do not guess at facts about the studio. If you have not played them by the interview, say so plainly and say what you plan to look at | Company-homework check. Nothing about Saltmarsh's titles was researched here, so this is a pattern for you to fill in |
| D4 | "On a live update that touches four teams, what would you write down, and who would read it?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Describe the artifacts and the readers you would choose, as a plan. The one written artifact your material names is the checklist you wrote, which QA still uses; say it at that scope. Answer slot: if other writing was regularly yours, say what and for whom, in your own words; if the checklist is your main example, say so plainly | F8's requirement, asked casually. JD tag, since the JD lists written communication |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team, and never worked on a game with in-app purchases" | Pause and restate. Hold only what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "I wrote the release checklist our QA team still uses." Concede specifically: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to those two facts, never by adding to them | The persona's own stem pointed at the stated gap (F6, F4). Pressure because it tests composure |
| E2 | "You say you ran that calendar. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the sentence: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which decisions about what shipped and when were yours, and which came from elsewhere, in your own words; if the calendar was set for you, or you only maintained it, say so plainly. Hold through the second follow-up, then concede only what is true | F6 is the line a probe will test. EXP because it checks attribution |

### F. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Open prompt from the persona stem. The one leadership-facing line in your material is the monthly presentation. Answer slot: if any month's numbers were unwelcome, say what you said and what followed, in your own words; if none were, say so plainly, then give the nearest thing your material carries, or how you would handle it | F7 is the only row with a leadership audience. VAL by stem; no Saltmarsh value was available to map it to |
| F2 | "Tell me about a time QA and the schedule pulled in different directions." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Open prompt, themed on the JD's QA duty. The checklist is where such a story might sit, but your quote does not carry one. If a time comes to mind, say what was at stake and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4's requirement as a behavior probe. A selection scaffold, not a mapped story |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, D2, E2 |
| "coordinate design, art, engineering and community teams on each update" | A2, B1 |
| "own the post-event review and the KPIs it reports" | A4, C3 |
| "manage the release checklist with QA" | A5, F2 |
| "3+ years producing live-service games or apps" | B4 |
| "experience running a content calendar" | A1, E2 |
| "comfortable with player-retention metrics" | A3, C1, C2 |
| "clear written communication" | D4 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "How are the KPIs in a post-event review chosen here, and who has the last word on them?" | Shows you want the team's definitions before you own the numbers | [generic] |
| R2 | "Where does an update most often come under pressure between design, art, engineering and community, and what would you want the producer to do about it?" | Turns the coordination probe into a working conversation | [generic] |
| R3 | "How does the release checklist work with QA today, and where would you want it to change?" | Signals respect for the QA relationship and a wish to learn the current process | [generic] |
| R4 | "I haven't worked on a game with in-app purchases. What would you want me to learn first about how events relate to monetization here?" | Names the gap yourself, with your stated words, and asks for direction | [grounded] "Never led a team, and never worked on a game with in-app purchases" |
| R5 | "What would make you say, a year from now, that this hire was the right one?" | Gets the scoring criteria out in the open | [generic] |
| R6 | "What does the first month look like for someone taking over the calendar for the two titles?" | Shows you are planning your ramp, and tells you what the team expects | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated: "Never led a team, and never worked on a game with in-app purchases" | The plain acknowledgment that quote gives: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, same quote | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Planned and ran live-events calendars for two mobile titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar for one main title |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The material says the monthly retention numbers were presented, not that a post-event review was owned |
| Managed releases with QA against the checklist | Inflated form of F4 | F4's quote at its own scope. The material says the checklist was written and that QA still uses it |
| Four years of live-service production | Inflated form of F5 | The two quotes at their own scope. The material does not show which years were on live-service work |

## Sources

Provided documents: your message (the JD text and your background). No dossier was present. No interviewer profile, values page or company material was provided.

Searches sent (none returned a result):

- `Saltmarsh Games mobile studio values`: refused
- `Saltmarsh Games interview process live operations producer`: refused
- `Saltmarsh Games strategy news mobile titles`: refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | The search was refused. It would have fed a values cheat sheet; VAL rows are persona stems, and no values-style round is assumed |
| 2. Saltmarsh Games interview process, live operations | unavailable | The search was refused. It would have named the rounds; the persona weights rest on your message and the hiring-manager assumption |
| 3. Saltmarsh Games strategy or recent news | unavailable | The search was refused. It would have grounded CO and CASE questions in the studio's titles; D2 and D3 are `[generic]` |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | The search was refused. It would have supplied the interviewer read and one reverse question tied to his path; both are absent |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- How Tobias relates to the role (future manager, peer, skip-level) and anything the recruiter said about format or focus → persona weights recomputed, banks reweighted
- Search access, or pasted company material (a values page, anything on the two titles, a strategy note) → D2 and D3 become `[grounded]`, A1 gains the studio's own vocabulary, and a values cheat sheet appears if a values round is named
- Anything Tobias has published or said publicly, pasted → an interviewer read and a reverse question tied to his own path
- Your answers to the slots in F1, F2, F3, F4, F5 and F8, in your own words, stated outside a drill → those rows regenerate on your quotes and move from `[inferred]` or transferability toward `[grounded]`
- The release checklist itself and a redacted page of the content calendar → F4 and F6 can move from `medium` to `high`; a screenshot of the retention report you presented does the same for F7
- Hours available before Friday → a prioritized prep schedule
- A `tuesday-dossier.md` from the job-underwriter → verified evidence and a sharper objection; never a prerequisite
