I'm writing the pack now. The three web searches were declined, so everything in it rests on what you gave me, with no outside research.
Priya's prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-1-denied-28e9d2b7/Northwind_Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. It has 22 questions across seven personas, each tagged by type with answer guidance, a rationale and a provenance label. I built it for a single 60-minute peer conversation with Dan, as you described.

**No outside research was done.** The three web searches I tried (Northwind's values, its interview process, Dan's public footprint) were refused, so the pack rests only on what you gave me. Your research note is the only source for the company questions, and I couldn't check how current it is. The Sources section lists each search as refused.

**Weights and gaps:**
- **Weighting:** Peer Evaluator and Data-Driven Prober come first, because Dan is a peer who calls himself "relentlessly data-driven". Case questions are tilted toward pricing and packaging, given his career spine. The Values/Behavioral questions use generic persona stems, because I found no Northwind values.
- **Highest-ROI prep (C1):** the objection that Priya has no classic sales-ops or quota-setting experience, which your notes state. C1 has the exact concession wording and two follow-ups. It keeps her volume-targets work at its own scope and never calls it quota-setting.
- **Second priority (B1, B2, F2):** the ~$400M figure. The guidance stays at "proposed… credited with" and leaves the method, baseline and attribution as answer slots for her to fill in her own words.
- **Not coached (section 13):** claiming sales-ops or quota experience, owning or delivering the ARR uplift, designing a partner motion, negotiating with carriers, building AI products, and owning a product launch's GTM.

Everything in the pack is built from your summary of the JD, not its full text.

Say the word and I'll run a live drill as Dan on C1, the Skeptic question the pack names as the highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Two things would restructure the pack:
- Did the recruiter give any guidance on focus areas, or announce a deliverable such as a POV or a take-home? A deliverable would get its own build section.
- Can you paste the full JD text? Right now the requirement rows quote only your highlights.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind_Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Mock interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind. He would be Priya's peer, both reporting to the same VP.
**Format assumed:** one 60-minute conversation with Dan, as you described. That is the whole loop this pack prepares for, so persona weights come from the peer relationship plus Dan's profile, not from any documented Northwind interview process.
**Built on:** your JD highlights (a summary, not the full JD text), your notes on Priya, your description of Dan's profile, and your research note. No web research was available this run (see Sources).

## How to use this pack

Personas describe **how** a question arrives. Types describe **what is being scored**. Guidance is scaffolding, not a script: say it in Priya's own words, and where a cell says "answer slot", the honest answer is whichever branch is true.

| Type tag | Meaning |
|---|---|
| VAL | Behavioral and values alignment. No Northwind values page was available, so VAL questions here are generic behavioral probes, not mapped to published values |
| EXP | Work-experience deep-dive: do the claims survive scrutiny, and what was actually hers |
| JD | Role and JD-driven: can she do the listed job, including its gaps |
| CO | Company and strategy knowledge |
| CASE | Live problem set in the role, scored on structure and reasoning |

**Highest-ROI prep in this pack: C1.** The sales-ops and quota-setting objection will be asked in some form, by a Director of Sales Strategy, and a rehearsed non-defensive answer changes the interview. Second: B1 and B2, because Dan describes himself as data-driven and the ~$400M figure is the headline number.

## Fit snapshot

Requirements are quoted from your JD highlights (your message), which summarize the JD and are not its full text. Evidence is quoted from your notes on Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | transferability | The material shows strategy and product strategy and ops tenure, not go-to-market ownership. Words stay at the quote: "I spent two years in strategy consulting, then nine in product strategy and ops at a large consumer-tech company." Answer slot: the JD's GTM line makes a probe on go-to-market work likely. If any of that work was go-to-market for a new product, say what it was and which part was yours, in your own words; if none was, or it was not yours, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The quote touches growth but does not show whether any analysis looked at stages of a customer lifecycle. Answer slot: if any analysis you ran separated customers by stage, say what it showed; if none did, say so plainly, then say how you would start segmenting the two new product lines |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | presentation | A skill statement with nothing inspected behind it, so expect a probe. The words are the quote's: "I'm skilled in SQL and Tableau." The pack adds no analysis to it; B4 rehearses choosing a real one |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material says a revenue model that was used in negotiations, not a partner motion. Words at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on whether the model shaped how partners were engaged likely. If it did, say how, in your own words; if it did not, or that was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Words: "I set annual volume targets with cross-org consensus." Expect a probe on where the orgs disagreed; A3 holds the answer slot |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote says use, not building or launching. Words: "I use AI tools daily." Which tools and for what is an answer slot in E2 |
| F7 | Sales-ops and quota-setting fluency, the interviewer's own seat; not a JD line (role-adjacent, plain prose) | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it was stated in your notes. Words: "I haven't had classic sales-ops or quota-setting experience." Then how Priya would learn it, said as a plan and never as a past. Her volume-targets sentence (F5) is adjacent work and is not called quota-setting |

## Reading the interviewer

Public professional signals only, as you described them. Nothing here is inferred about personality.

| Signal | Source | Practical implication | Provenance |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | Dan's profile, your description | Every number gets probed to its assumptions. Know how each CV figure was counted, or say plainly that you do not. Bank B | [grounded] |
| "career spine is pricing and monetization roles" | Dan's profile, your description | Pricing, packaging and unit-economics angles are his native language; case answers should reach for them. Bank D | [grounded] |
| "one early-stage-startup chapter" | Dan's profile, your description | Builder stories may land, and big-company-pace or scrappiness probes are possible. Bank C and reverse question R1 | [grounded] |
| Peer, same VP | Your message | He is pricing what this hire costs and contributes to his own work: seam, reciprocity, credit-sharing. Bank A | [grounded] |

**Mirror opportunity.** Dan's public path runs through pricing and monetization. Priya's side of that vocabulary is one sentence, from F4: "built a partner-level revenue model used in carrier negotiations". Use it as shared commercial language and do not present it as a shared career. No shared personal background is used.

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator | Seam between his team and this role, what she needs from him, credit-sharing | Highest. Peer relationship prior; same VP. Weight: 5 questions | Reciprocity framing; propose seam principles, not a claimed seam |
| B. Data-Driven Prober | Defends the CV numbers, the model, the analysis | Highest. Peer prior plus "relentlessly data-driven". Weight: 5 questions | Know what you can and cannot say about how each number was counted; name the weakest assumption before he does |
| C. Skeptic | Sales-ops, quota-setting, partner-motion gaps | Medium. Gaps F4 and F7 are exactly where a sales-strategy director looks. Weight: 3 questions | Rehearse C1 until boring; bridge only from the quoted adjacent work; concede the gap plainly |
| D. Case / Strategist | Whitespace, pricing and packaging, bundling pressure | Medium. Pricing spine tilts cases his way; a peer is less likely than a hiring manager to run a long case. Weight: 3 questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| E. Conversational | Opening journey question, the AI chat | Lower, but the opener is near-certain in any 60-minute conversation. Weight: 2 questions | A 90-second arc built from your own sentences; treat the AI question as scored |
| F. Pressure | Short, challenging versions of the C and B questions | Lower. Peers rarely run stress interviews, but the objection can arrive curt. Weight: 2 questions | Pause, restate, hold through two follow-ups, then concede specifically |
| G. Values / Behavioral | Disagreement and customer-versus-metric stories | Lower. No values-style round is detected in a single peer conversation; stems come from the persona model, not Northwind values. Weight: 2 questions | Choose a story where the hard truth landed; if none comes to mind, say so |

## Question banks

The Provenance column carries each quoted sentence the guidance rests on, copied from the fit snapshot.

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between sales strategy and this role, and what happens when we disagree?" | JD | [generic] | No claim about your past is needed. Propose seam principles rather than pretending to know the current seam: who owns the question versus who owns the numbers, which decisions are made jointly, how a disagreement gets escalated to the shared VP. Then ask Dan where the seam chafes today. Say aloud that you are proposing principles, not describing Northwind | The role's GTM-strategy line (F1) is the likeliest place for overlap with a sales-strategy director. JD for content, Peer delivery; `[generic]` because it is a pattern, not a fact about Northwind |
| A2 | "How do you handle credit when a result spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open prompt, so choose your own instance. If you use the uplift story, keep the quote's scope: "I proposed the change, and the uplift was credited to it." Answer slot: if other teams built, shipped or measured it, say who and what, in your own words; if no one else did, or you do not know, say so plainly and stay with what you proposed | Credit and attribution are a peer's main concern about a new colleague. F2 holds the headline claim, so this is also an early attribution check; EXP because it tests what was actually hers |
| A3 | "Tell me about a time you had to get several teams to agree on a number." | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5. The beats are the ones the quote states: annual volume targets, set, with consensus across orgs; tell them in your own words. Answer slot: the JD's influence line makes a probe on where the orgs disagreed likely. If they did, say what each side wanted and which part was yours; if consensus came without much disagreement, or was not mostly yours, say so plainly and stay with the targets | F5 is the only evidence for the cross-functional-influence requirement. JD because it scores that line; the open-prompt form lets her choose the instance |
| A4 | "What would you need from my team in your first 90 days, and what could you bring us?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity first: lead with what you can offer, then what you need. The offer is a future one, in the quote's scope: "I'm skilled in SQL and Tableau, so I can take analysis off your team's plate where useful." Ask what Dan would hand over today. Do not describe a past analysis you did not mention; B4 is where that is rehearsed | The reciprocity question for a peer converts a collaboration probe into a trade. F3 is the evidence; JD because it scores whether she reduces his load |
| A5 | "Tell me about a disagreement with an equal where neither of you had the final call." | VAL | [generic] | Selection scaffold: pick a disagreement with a named stake, where you held your view without souring the relationship, and where you can say what actually changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or describe how you would handle it | Peers test disagreement style with equals. VAL only in the generic behavioral sense, since no published Northwind values were available; the material carries no such story, so this is a scaffold |

### B. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start inside the quote: "I proposed the change, and the uplift was credited to it." Four answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; and which part was yours. If you do not know how it was counted, say that plainly. Name the weakest assumption before he asks | The headline metric on the CV, F2, is the magnet for a data-driven prober. EXP because it tests whether the number survives; the pack names no method because the material gives none |
| B2 | "If that uplift would have happened without your change, what changes?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Same four slots, aimed at sensitivity. Do not defend the number by supplying a method. Answer slot: if you know what the figure depends on, say it; if you do not, say so plainly and return to "I proposed the change, and the uplift was credited to it" | The second-level follow-up the Prober style predicts after B1. EXP; the guidance stays inside the quote because an explanation she cannot repeat under a third question is worse than none |
| B3 | "Walk me through the revenue model you built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Describe it in your own words, starting from the quote: a partner-level revenue model, used in carrier negotiations. Answer slot: the JD's partner-motion line makes a probe on whether the model shaped how partners were engaged likely. If it did, say how; if it did not, or that was not yours, say so plainly and stay with the model. Offer to walk through it end to end | F4 is the evidence for the partner requirement. EXP for the model itself, JD for where the interviewer will take it |
| B4 | "Pick an analysis you ran yourself end to end in SQL or Tableau and walk me through it." | JD | [grounded] "skilled in SQL/Tableau" | Open prompt. Choose one you did yourself: the question, the data, what the output changed, what you would redo. The quote supports only that you are skilled; the specifics have to be yours. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one | The JD's independent-analysis line (F3), tested by someone who will read your answer as an analyst. JD because it scores that line; the pack names no analysis because none was given |
| B5 | "Walk me through the annual volume targets you set with cross-org consensus." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Tell it at the quote's scope: annual volume targets, set, with consensus across orgs. Answer slot: expect a probe on how the number was derived and how it differs from a sales quota. If you know, say it in your own words; if the derivation was not yours, or you are unsure how it compares, say so plainly. Do not call the targets quotas | F5 and F7 meet here: the adjacent work is real in the notes, and the gap is the sales-ops step beyond it. EXP, because he will test what was hers |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that here?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | **The deepest rehearsal in the pack.** Pause and restate the question. Concede plainly: "I haven't had classic sales-ops or quota-setting experience." Then the adjacent evidence at its own scope: "I set annual volume targets with cross-org consensus." Do not call those targets quotas. Follow-up 1, "how is that different?": answer slot. If you know how volume targets differ from quotas, say what you understand; if not, say so plainly and return to the sentence. Follow-up 2, "what happens in your first month?": a plan, not a past. Name what you would learn first and from whom, in your own words. Concede the gap specifically each time, and hold by returning to the two sentences, never by adding to them | F7 is the biggest gap in the material and sits in the interviewer's own domain. JD content with Skeptic delivery; the negative is sourced to your notes |
| C2 | "Partner-motion design is a stated requirement. Where does your experience sit against it?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the quote says: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if the model shaped how partners were engaged, say how, in your own words; if it did not, or that was not yours, say so plainly and stay with the model. Hold through two follow-ups by returning to the model, not by describing a partner program | F4 is a transferability gap against a requirement marked required. JD, because the question is the JD line itself |
| C3 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Selection scaffold. Your material is thinnest on F7, F4 and F2; choose the one you genuinely believe, name it plainly, and give a concrete first-30-days plan for it. If you cannot choose, say so and give the one you would ask Dan about first | The standard Skeptic stem. Answering it before being asked shows calibration, and the pack's own reading of the thinnest rows is analysis, not words for Priya |

### D. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have two new product lines and a limited sales team. Where is the whitespace across land, adopt, expand and renew, and what do you want to know first?" | JD | [generic] | No claim about your past. Clarify first: what stage each line is at, who buys, what usage data exists. Then objective, segmentation by lifecycle stage, approach, metrics, risks. Think aloud, name a hypothesis early, and challenge one premise respectfully. Bring a pricing and packaging angle, since that is Dan's vocabulary | The JD's whitespace line (F2) and GTM line (F1) as a live problem. JD for content, CASE delivery; `[generic]` because the problem is a pattern, not a fact about Northwind's products |
| D2 | "Northwind is pushing enterprise expansion and launching Compass while working toward profitability, and a much larger platform vendor is bundling. How should an emerging product line be positioned?" | CO | [grounded] your research note | Use only what the note gives: the three priorities and the bundling threat. Structure it: where a bundle is weakest, what a standalone buyer pays for, how profitability limits discounting, what enterprise expansion asks of the motion. Say what you would need to know, such as attach and discount data, and ask Dan what the data shows today. State no facts about Compass or the vendor beyond the note | The research note is the strategy source in hand; its age is unknown and no outside check ran. CO for the company altitude, with CASE delivery |
| D3 | "Compass is launching with limited usage history. How would you decide whether to price it standalone, bundle it, or meter it?" | CASE | [grounded] your research note | Names Compass only because the note does. No claim about your past. Clarify what is known about usage and buyers, state decision criteria such as attach, expansion and discount pressure, propose a small test with clear read-outs, and name the risk of each option under bundling pressure. Bring SQL and Tableau only as a future plan | Dan's pricing and monetization spine makes this the likeliest case. CASE; the premise that Compass is launching is from the note, and everything else is a pattern |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. Why B2B data infrastructure, and why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc built from the sentence: two years in strategy consulting, then nine in product strategy and ops at a large consumer-tech company. The why-B2B and why-now are answer slots: say your own reasons, and tie to Northwind's priorities only where it is genuinely yours. If there is no deliberate reason, say what drew you plainly | The opener is the most predictable question in the conversation, and it is where a consumer-to-B2B switch is first tested. F1 holds the evidence; EXP because the arc is a CV claim |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Answer slots: which tools, for what tasks, in your own words. The quote says daily use, not building or launching, so keep to use. Then ask Dan how he sees copilots changing sales strategy. Do not describe understanding of Compass beyond what is public | F6 is the plus-requirement, asked casually but scored; a casual register does not lower the bar. JD |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has done this inside a sales org?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "skilled in SQL/Tableau"; "No classic sales-ops or quota-setting experience" | Pause, restate, then hold only what the quotes carry: two years of strategy consulting and nine years of product strategy and ops, and a skill in SQL and Tableau. Concede specifically: "I haven't had classic sales-ops or quota-setting experience." Hold through two follow-ups by returning to the quotes; never by adding to them | The curt form of C1. F7 is the concession; JD because it scores fit against the role |
| F2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold the quote's own scope: "I proposed the change, and the uplift was credited to it." Do not claim the uplift was yours. Answer slot: if you know how it was counted or what part you carried, say it in your own words; if you do not, say so plainly. Hold through two follow-ups, then concede exactly what you do not know | The attribution question the pack exists to rehearse. F2; EXP because it is the CV claim under pressure |

### G. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a moment you did not fold, and a relationship that was intact afterwards, with the hard truth landing. Your material carries no such story. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem, used because no Northwind values page was available. The material has no row for it |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision where the customer's interest and an internal number pulled apart, what you chose, and what it cost. Your material carries no such story. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Relevant to a B2B role. A persona stem, not a Northwind value |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "own GTM strategy for two new product lines" (F1) | A1, C3, D1, E1, F1 |
| "identify whitespace across land/adopt/expand/renew" (F2) | D1, C3 |
| "run independent analysis in SQL and Tableau" (F3) | B4, A4 |
| "partner-motion design experience required" (F4) | C2, B3 |
| "strong cross-functional influence" (F5) | A3, B5 |
| "AI experience a plus" (F6) | E2 |
| Sales-ops and quota-setting fluency (F7, not a JD line) | C1, F1, B5 |
| Headline figure, ~$400M (F2) | B1, B2, F2, A2 |

Question totals: 22. Types: JD 10, EXP 7, VAL 3, CO 1, CASE 1. CO and CASE are thin because no outside strategy research ran; D2 and D3 rest only on your research note.

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Your path runs through pricing and monetization and includes an early-stage chapter. What did that chapter change about how you think about packaging a new product?" | Tied to his own path, from your description of his profile; it turns the interview into a peer conversation about his craft | [grounded] |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it shows she is thinking about his load | [generic] |
| R3 | "Where does the data on the two new product lines feel thinnest today across land, adopt, expand and renew?" | Uses the JD's own lifecycle language and invites the data-driven answer he is likely to enjoy | [grounded] |
| R4 | "With a much larger vendor bundling, which product-line decision is the team least sure about?" | Shows she read the competitive frame in your research note without pretending to know the answer | [grounded] |
| R5 | "How are decisions split between your team and this role today, and where does that split chafe?" | The seam question from her side; it surfaces how he thinks about the overlap | [generic] |
| R6 | "How will success in this role be judged after a year, and who weighs in?" | Pins the outcome the VP cares about, and signals she plans to be accountable for it | [generic] |

## Prohibited claims

Not coached by this pack, with the basis and the honest form for each.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience, or "set quotas" | Negative stated in your notes, F7 | The plain acknowledgment: "I haven't had classic sales-ops or quota-setting experience." Her volume-targets sentence (F5) stays at its own scope. No slot |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says she proposed a change that was credited with the uplift, not that she delivered or owned it |
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a revenue model used in negotiations, not a partner motion |
| Negotiated with carriers | Inflated form of F4 | F4's quote at its own scope: the model was used in carrier negotiations; the material does not say she took part in them |
| Built or launched AI products, or has experience with copilots like Compass | Inflated form of F6 | F6's quote at its own scope: she uses AI tools daily |
| Owned go-to-market for a product launch | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says strategy and product strategy and ops tenure |

## Sources

Provided documents: your message (JD highlights, notes on Priya, description of Dan's profile, research note). No dossier was present.

Queries sent, all refused (permission to search was not granted):

- "Northwind Data B2B data infrastructure company values principles" — refused
- "Northwind Data interview process strategy GTM role" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Search refused. Would have moved the VAL bank, which is generic as a result; the values cheat sheet is omitted because no values-style round is detected in a single peer conversation |
| 2. `Northwind Data interview process, strategy and GTM roles` | unavailable | Search refused. Would have moved persona weights if a wider loop exists; the weights rest on your description of one conversation with a peer |
| 3. `Northwind Data strategy` / recent news | unavailable | No search sent; research was declined. Would have moved D2 and D3 and checked the currency of your research note |
| 4. `Dan Kovac Northwind Data` | unavailable | Search refused. Would have moved the interviewer read beyond your description and the reverse question tied to his path |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions; the full text would improve them |

## Upgrade menu

- The full JD text → the six JD rows move from your highlights to exact quotes, and any requirement not in the highlights, such as tools, scope or location and travel terms, gets a row
- The recruiter's guidance on focus areas, or a pre-declared deliverable → coverage assumed from the peer-round prior would become tailored, and a deliverable would get its own build section
- Priya's answers to the answer slots, stated outside a drill → F1, F2 and F4 upgrade from `low` or `medium` to specific quotes, and B1, B2, B3, B4 and F2 get story maps
- The written readout or attribution memo behind the ~$400M credit, or the partner revenue model itself (redacted as needed) → F2 and F4 can rise from `medium` toward `high`, since these are the inspectable artifacts in strategy and ops
- Web research on Northwind's values, interview process, recent strategy and Dan's public talks or writing → a values cheat sheet if a values round exists, a sourced grounding brief, and sharper reverse questions
- A `tuesday-dossier.md` from a prior review → verified evidence and a prohibited-claims list from that review would replace the ones this pack built locally
