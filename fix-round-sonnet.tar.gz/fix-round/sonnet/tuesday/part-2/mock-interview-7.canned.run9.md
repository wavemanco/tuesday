Running the first round of company research on Saltmarsh Games: values, interview process, strategy, and Tobias's public footprint.
Research is done: 4 of 6 searches and both fetches. Before I write the pack, I'll read the dossier hand-off spec for the offer, and check whether you already have a dossier file.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-canned-a9e60390/saltmarsh-games_live-operations-producer_interview_pack.md`.

Saltmarsh's careers page describes its loop as "a recruiter call, then the Outage Hour: a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation." I built the pack on the assumption that Friday is that session, with Tobias as the hiring manager. Their values page names three published values: Players Before Plans, Ship the Patch Not the Promise and Leave the Build Greener.

- **Highest-ROI prep (C1):** your message says you've never worked on a game with in-app purchases. Saltmarsh's September 2026 Project Larkspur announcement moves two titles to a season pass, so expect this to come up. The pack rehearses a plain acknowledgment, then a plan, with three follow-up levels. The same applies to "never led a team" in C2.
- **Tabletop first:** A1, A2 and F2 are the outage drills. They come first in the prep order because the tabletop opens the hour.
- **Tobias:** he was a QA lead before heading live operations, and his GDC 2026 talk argues patch notes are a promise. Your release checklist and the announce-only-what-is-built value are your natural common ground. Two reverse questions use his talk and QA background. I read his talk and the Larkspur announcement only as search snippets, so read the talk yourself before using V1.
- **Rows I couldn't ground:** several rows (F1, F2, F3, F5, F8) have answer slots rather than scripted answers. Your material doesn't show whether any drops were time-limited events, whether any review followed them, which years were live-service, or whether you coordinated across design, art, engineering and community. Answer those honestly, either branch.

Research used 4 of 6 searches and both fetches, so a deeper pass is available as one line in the upgrade menu. I asked you nothing, because your message already covered what the pack needed.

Say the word and I'll run the Outage Hour live: I'd play Tobias on the A1 tabletop, or on C1, the pack's top-priority question, with follow-ups that react to what you say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager, assumed from the careers page in Sources, which gives the session to the hiring manager. Round: a single 60-minute session, a live-incident tabletop first and a values conversation second, per that page.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: where it quotes you, say the quoted thing in your own words and stop where the quote stops.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Saltmarsh's published values |
| EXP | Whether what you have said about your work survives questions |
| JD | The listed responsibilities and requirements, gaps included |
| CO | Whether you can think at the company's altitude |
| CASE | A live problem set in the role, answered by structure |

## Prep triage

Two days is enough for the few things below, done in this order. Everything else is insurance.

| Order | Do this | Where |
|---|---|---|
| 1 | Say the tabletop answers out loud, standing up, until the first thirty minutes of an outage comes out in a fixed order | A1, A2, F2 |
| 2 | Rehearse the in-app purchases answer until it is boring: the plain acknowledgment, then your plan | C1 |
| 3 | Find a real instance for each published value, or decide you have none and rehearse the honest branch | B1, B2, B3 |
| 4 | Practise the two holds: the checklist and the leadership question | D2, C2 |
| 5 | Read the GDC talk and pick two reverse questions | Section 11 |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title over two years, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's calendar line makes a probe on what each drop contained likely. If any ran for a limited time, say which and how you scheduled it, in your own words; if none did, or the timings were not yours, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show work across these four teams. Answer slot: the JD's coordination line makes a probe on cross-team work likely. If you worked with any of them on a drop, say which and what you did, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | discovery | Your material says you presented retention numbers, which is not a review and is not the KPIs a review reports, and the words stay at presenting: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event line makes a probe on what followed the numbers likely. If a review of any kind followed a drop, say what it covered and what part was yours, in your own words; if there was no such review, or it was not yours, say so plainly and stay with the numbers you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you wrote it, and QA still uses it. The JD says manage and the quote says wrote, so do not use the JD's verb for your own history |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Your material shows four years as an associate producer and two on the calendar; it does not show whether the studio's title was live-service, or which years. Answer slot: the JD's years line makes a probe on which years were live-service likely. If the title was live-service, say which years, in your own words; if it was not, or only part of the four years was, say so plainly and stay with the four years and the two on the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote already says what the JD asks. Lead with it in its own terms: the weekly calendar, your main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the line at its own scope: you presented the numbers, monthly, to the studio head. Expect a probe on how they were counted; E1 holds that rehearsal |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | Your material shows one written artifact, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's writing line makes a probe on other written work likely. If you wrote anything else that colleagues or players read, say what and who read it, in your own words; if not, say so plainly and stay with the checklist |

## Reading the interviewer

Public professional footprint only. The talk page was read as a search snippet, not fetched.

| # | Reading | Provenance |
|---|---|---|
| I1 | Career pattern: Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | [grounded] |
| I2 | Public argument: a GDC 2026 talk, "Patch Notes Are a Promise", whose argument is that a live team is judged by how often its patch notes describe what actually shipped | [grounded] |
| I3 | Implication: what gets announced, and whether it shipped, is likely a live topic; Saltmarsh's second published value uses the same idea, "we announce what is built, not what is hoped" | [inferred] |
| I4 | Implication: release gating is native ground for him, so answers in A2, A5 and F2 should say what is confirmed and what is not yet known, and keep the two apart | [inferred] |
| I5 | Mirror opportunity, shared professional vocabulary only: release gating with QA, beside F4's "Wrote the release checklist our QA team still uses." — your message. It is a shared subject, not a shared career jump, and none is offered | [inferred] |

## Persona table

Weights start from the hiring-manager prior (Case/Strategist and Skeptic), then follow the loop the careers page names. Recalibrate if you know something this pack does not.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | The Outage Hour tabletop: a simulated outage during a live event | Highest. The careers page names a live-incident tabletop in the session; the hiring-manager prior agrees | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Values/Behavioral | The second half of the session, against three published values | Guaranteed somewhere in the hour: the careers page names a values conversation | Map a story to each value where one of your sentences carries it; "we" for context, "I" for contribution; where none does, say so |
| C. Skeptic | Quiet probing of what your message says you have not done | Mid. Hiring-manager prior; your message states two gaps; the Larkspur announcement makes one of them current | Rehearse the single likeliest objection (C1); bridges only from what you said; a plan, not a claim |
| D. Pressure | Time-boxing and challenge inside the tabletop | Mid. A live simulated incident invites interruption; no source says the interviewer interrupts | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding |
| E. Data-Driven Prober | The retention line, probed for how it was counted | Low. One metric-shaped line in your material, with no figure attached | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know |
| F. Conversational | An opening chat and the biography question | Low. The careers page describes a structured session, but openers are still scored | A 90-second arc built only from your quoted sentences |
| G. Peer Evaluator | The producer and QA seam, inside the tabletop | Low. He is your manager, not a peer; the seam probe is the part that carries over | Reciprocity framing; propose seam principles rather than claim to know the seam |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a weekend event, and the event servers are down for about half your players. Talk me through your first thirty minutes." | CASE | [generic] | Clarify first: what is confirmed, who is affected, whether the event is still fair to everyone in it. State the objective: stop harm to players before protecting the schedule, which is Saltmarsh's first value. Then roles, a communication cadence, the decisions you would put to the room, and what you would log for the review. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The careers page names this format, so it is the likeliest opening; CASE because it is scored on structure. Covers F1's requirement from the planning side |
| A2 | "During that outage, who do you pull in, and what do you tell players, and when?" | CASE | [generic] | Name the four disciplines the JD lists and, in one line each, what you would ask of them. For players, say what is confirmed, what is not yet known, and when the next update comes; do not promise a fix time or compensation that has not been decided. The guidance makes no claim about your past | F2's requirement asked as a decision; I3 and I4 explain why the confirmed-versus-hoped line matters to this interviewer |
| A3 | "The outage is over. What goes in the post-event review, and which numbers do you report?" | CASE | [generic] | Structure: what happened, a timeline, player impact, the decisions taken and why, what changes next. Choose a few measures you can define in one sentence each and say what each is sensitive to and cannot tell you. The guidance makes no claim about your past | F3's requirement asked as a live problem rather than a record, since F3 holds no review to describe |
| A4 | "Project Larkspur puts two titles on one shared events calendar from February 2027. What do you need to know first, and how would you build the first quarter?" | CO | [grounded] | Clarify before structuring: which events are shared and which stay title-specific, who signs off, how a season pass changes cadence, what the single live-ops group replaces. Then structure, then risks such as two titles colliding, player fatigue and the release load landing on QA. No claim about your past | The strategy sweep in Sources found the Larkspur announcement; CO because it tests current-strategy fluency, CASE in delivery. F1 and F6 are the requirements it serves |
| A5 | "QA flags a serious bug four hours before an event goes live, and engineering wants to ship. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: what the bug does to players, who makes the call, the options (hold, ship with a stated limit, ship in part), what you would tell players. Where the checklist comes in, say it at its own scope: "I wrote the release checklist our QA team still uses." Answer slot: the JD's checklist line makes a probe on what the checklist says about a case like this likely. If it gave a rule for it, say what; if it did not, say so plainly and say what rule you would want | F4 is the evidence for the release requirement; CASE because the question is a live decision, and the first value says players win |

### B. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the plan and the players pulled in different directions, and which one won." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | No sentence of yours carries this story, so choose one: it needs a named stake, what the plan was, what you gave up, and who agreed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I ran the weekly content-drop calendar for our main title for the last two years.", or say how you would handle it. The pack does not supply the event | The first published value, "Players Before Plans", is the raising source; F1 is the only calendar evidence, and it does not show a conflict |
| B2 | "Tell me about a time you told people what was built rather than what was hoped." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | No sentence of yours carries this story, so choose one: a named announcement, what had been promised against what existed, and what it cost you to say. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I presented the monthly retention numbers to the studio head.", which shows presenting and not whether any number was unwelcome, or say how you would handle it | The second published value, "Ship the Patch Not the Promise", is the raising source; F3 is the closest evidence and is thin |
| B3 | "Tell me about a time you left a process or a checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4, with only the beats the quote states: you wrote it, and QA still uses it. Tell those in your own words. Answer slot: the third value, "Leave the Build Greener", makes a probe on whether the checklist changed after later releases likely. If it changed, say what and why; if it did not, or the changes were not yours, say so plainly and stay with the checklist you wrote | F4 is the one quoted sentence that fits this value; VAL because it scores behaviour against a published value |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We are moving our titles to a season pass, and you haven't worked on a game with in-app purchases. What would you not know on day one, and how would you close it?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message, "I ran the weekly content-drop calendar for our main title for the last two years.", "Presented the monthly retention numbers to the studio head." | The highest-ROI prep in this pack. Open with the plain acknowledgment and stop: "I haven't worked on a game with in-app purchases." Name the limit before you are asked for it: that sentence is the whole limit, so add nothing to it and take nothing from it. Then give a plan, said as a plan: what you would learn first, from whom, and by when. What you can stand on is two quoted sentences at their own scope, the calendar and the presented numbers; do not stretch the retention line into purchase behaviour. Follow-up 1, "what would you look at first?": answer with the plan. Follow-up 2, "the team will make pricing calls you cannot judge; what is your part?": hold on the part your material carries and say what you would ask of the specialists. Follow-up 3, "is that enough for a February start?": concede specifically, that you would be learning in the first weeks and would say so, and do not fold on the calendar and the checklist | The season-pass move is in the Sources announcement and the negative is yours, so this objection arrives in some form; P1 is the entry behind it. CO because the premise is company strategy, Skeptic in delivery |
| C2 | "The JD has you coordinating design, art, engineering and community on every update, and you haven't led a team. How do you get four disciplines moving?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first: "I haven't led a team." Then a method for getting work from people you do not manage, said as what you would do: one owner per item, one source of truth, a named escalation path. Answer slot: the JD's coordination line makes a probe on cross-team work likely. If you worked across any of those disciplines on a drop, say which and what you did, in your own words; if you did not, or none of it was yours, say so plainly and return to the calendar you ran. Hold through two follow-ups by returning to what you said | F2 is the thin row and P2 the stated negative; JD because it scores the listed coordination duty |
| C3 | "Your calendar was for your main title. What part of running events across two titles would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say the quote at its scope, then name the weakest part in your own words; the pack does not pick it for you. Answer slot: the JD's two-titles line makes a probe on what a second title would change likely. If any drop of yours ran for a limited time, say what that taught you about timing; if none did, say so plainly and say what you would want to learn first | F1 is where the JD presses on scope; Skeptic stem, JD tag because the requirement is being scored |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds. The studio head is on the line, the event is failing, and wants a recommendation. What is it?" | CASE | [generic] | Pause, restate the question, give the recommendation first, then the one reason and the one thing you would confirm. Hold through two follow-ups; concede a specific uncertainty without folding on the recommendation. No claim about your past | The tabletop is live, so time-boxing is the likeliest pressure; CASE because it scores a decision under time |
| D2 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold on the quote: "I wrote the release checklist our QA team still uses." Answer slot: if others edited or added to it, say who and what; if it was all yours, say so plainly; if you were given a draft, say that. Hold through two follow-ups by returning to the sentence, never by adding to it, and concede only a specific thing you do not know | F4 is a CV-style line with nothing inspected behind it, so attribution is the likeliest probe; P5 is the inflated form to avoid |
| D3 | "Sixty seconds: why you over someone who has run live events and worked on monetisation?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message, "Wrote the release checklist our QA team still uses." — your message, "Never led a team, and never worked on a game with in-app purchases." — your message | Pick two of your quoted sentences and say them at their own scope. Then acknowledge both stated gaps in your own words, "I haven't worked on a game with in-app purchases" and "I haven't led a team", rather than argue around them. Do not claim your puzzle-game work is the same as live events. Hold, then concede specifically | The comparison the question invents is the one this hiring manager can make; P1, P2 and P3 bound the answer |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what the quote says: monthly, to the studio head. Answer slot: the JD's retention line makes a probe on how the numbers were counted, what they were sensitive to, and which part was yours likely. If you built or counted them, say how, in your own words; if someone else produced them and you presented them, or there was no such step, say so plainly and stay with presenting. Name the assumption you would defend least, if you know one; if you do not, say plainly that you do not know | F7 is the only metric-shaped line in your material, which is where a prober starts |
| E2 | "The role reports the KPIs for each post-event review. Which retention measures would you put in it, and how would you tell whether an event moved them?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Choose the measures you would defend and define each in one sentence. Say what each is sensitive to and what it cannot tell you. Where you refer to your own work, say it at its scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you have built a measure like this before, say how; if you have not, say so plainly and say what you would define first | F3 and F7 are the two rows this question sits across; JD because it scores two listed requirements |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey, and where the live-service work sits in it." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message, "Wrote the release checklist our QA team still uses." — your message, "Presented the monthly retention numbers to the studio head." — your message | A 90-second arc, one beat per quoted sentence at its own scope: the four years, then the calendar, then the checklist, then the presented numbers. Answer slot: the JD's years line makes a probe on which years were live-service likely. If the title was live-service, say which years; if it was not, or only part was, say so plainly. Answer slot: say in your own words why live operations and why Saltmarsh; nothing in your material says it, so the pack does not | The biography question is scored even when it sounds casual; F5 is the requirement it carries |
| F2 | "Here is the outage. Give me the two lines players read first." | JD | [generic] | Say what is confirmed, what players should do, and when the next update comes. Promise nothing that has not been decided, and give no fix time you cannot keep: Saltmarsh's second value is "we announce what is built, not what is hoped". The guidance makes no claim about your past | F8's requirement tested live rather than by claim; JD because the writing line is scored, with CASE delivery |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our QA lead says hold the release and engineering says ship. Where is the seam between producer and QA, and what happens when you disagree?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Reciprocity first: what you bring QA, at the quote's scope, "I wrote the release checklist our QA team still uses." Then propose seam principles rather than claim to know the seam: the producer carries the calendar and the player message, QA brings the quality evidence, and a disagreement goes up framed as player impact. Answer slot: if you have disagreed with QA or engineering over a release, say what and how it ended; if not, say so plainly and say how you would handle it | F4 and F2 meet here; the seam probe carries over from the peer prior even though he is your manager |
| G2 | "How do you handle credit when an update spans design, art, engineering and community?" | JD | [generic] | Principles, not a story: name each team's work in the update notes, say what each did in their terms, keep your own part to what you did. Answer slot: if you have a time you shared credit across teams, say it in your own words; if not, say so plainly and give the principle. No claim about your past | F2's requirement, collegially packaged; generic because no sentence of yours speaks to it |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A4, C3 |
| "coordinate design, art, engineering and community teams on each update" | A2, C2, G1, G2 |
| "own the post-event review and the KPIs it reports" | A3, E2 |
| "manage the release checklist with QA" | A5, D2, G1 |
| "3+ years producing live-service games or apps" | F1 |
| "experience running a content calendar" | A4, C3 |
| "comfortable with player-retention metrics" | E1, E2 |
| "clear written communication" | A2, F2 |

## Values cheat sheet

A loop source documents a values conversation, and the values page was fetched, so the three values are by their published names.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, players win | No quoted sentence carries it. Selection scaffold: a named stake, what the plan was, what you gave up, who agreed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, F1's "I ran the weekly content-drop calendar for our main title for the last two years." — your message, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence carries it. Selection scaffold: a named announcement, what had been promised against what existed, what it cost to say. If none comes to mind, say so plainly, then give F3's "Presented the monthly retention numbers to the studio head." — your message at its scope, or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." — your message. The beats are the two the quote states; whether it changed after later releases is B3's answer slot |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| V1 | "Your GDC talk argued that a live team is judged by whether its patch notes describe what shipped. In the post-event review here, which measure tells you the notes kept their promise?" | It meets his own public argument with a working question. Read the talk first; if you have not, skip this one | [grounded] |
| V2 | "You were a QA lead before you ran live operations. How did that shape how releases are gated here?" | Ties to his own path and to F4's subject without claiming a path of yours | [grounded] |
| V3 | "Project Larkspur retires per-title event teams in favour of one live-ops group. Where does this role sit in that group, and what would the first shared-calendar event need from it?" | Shows you read the strategy and asks what the role is for | [grounded] |
| V4 | "What separates an Outage Hour answer you would call strong from one that is merely correct?" | Treats the format as scored and invites a calibration | [grounded] |
| V5 | "When the calendar and the players disagree, what is a recent case where the players won, and what did it cost the calendar?" | Treats the first value as a decision, not a slogan | [grounded] |
| V6 | "Given the move to a season pass, what would a good first ninety days look like, and where would you want me to ask for help?" | Turns the two gaps you stated into a ramp conversation instead of leaving them for him to raise | [grounded] |

## Prohibited claims

| # | Not coached | Basis | Honest form |
|---|---|---|---|
| P1 | Has worked on a game with in-app purchases | Negative the candidate stated: "Never led a team, and never worked on a game with in-app purchases." — your message | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan. No slot |
| P2 | Has led a team | Negative the candidate stated, same sentence | The plain acknowledgment: "I haven't led a team." No slot; C2's slot stays inside the calendar |
| P3 | Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title, not a live-events calendar across two titles. C3's slot stays inside the calendar |
| P4 | Owned the post-event review and the KPIs it reports | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you presented retention numbers, not that you owned a review or its KPIs. E1 and E2 stay inside presenting |
| P5 | Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says you wrote the checklist QA still uses, not that you managed releases. D2 and G1 stay with the checklist |
| P6 | Produced a live-service game for three or more years | Inflated form of F5 | F5's quotes at their own scope. The limit is the pack's observation: your material says four years as an associate producer and two on the weekly calendar, not three live-service years. F1's slot stays inside those quotes |

## Sources

Provided documents: the job description and your background, both in your message. No dossier was present. The careers page establishes the loop (one session, 60 minutes, the hiring manager, a tabletop then a values conversation), so no archetype fallback was used.

Searches and fetches, every call sent:

| Call | Query or URL | What came back |
|---|---|---|
| Search 1 | Saltmarsh Games values | https://saltmarshgames.com/values |
| Search 2 | Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Search 3 | Saltmarsh Games strategy mobile games news | https://saltmarshgames.com/news/project-larkspur, read as a snippet only |
| Search 4 | Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise, read as a snippet only |
| Fetch 1 | https://saltmarshgames.com/values | The three values by name, with a line each |
| Fetch 2 | https://saltmarshgames.com/careers/interviewing | The loop description above |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet; B1 to B3 themes; I3 |
| 2. Saltmarsh Games interview process, live operations producer | yes | The loop: persona weights, A-bank and B-bank, the whole pack's structure |
| 3. Saltmarsh Games strategy or recent news | yes | A4, C1, V3 and V6; read as a snippet because both fetches went to targets 1 and 2 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | The interviewer read, V1 and V2; read as a snippet only |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → the Larkspur announcement and the talk read in full rather than as snippets, and a grounding brief that sharpens A4, C1 and V1 to V3
- Your answers to the answer slots in F1, F2, F3, F5 and F8, said to me outside a drill → those rows move from discovery toward grounded, and the matching banks regenerate
- The release checklist itself, a calendar export or a post-event review document → the inspectable artifacts that could lift F4 and F8 above their current bands
- Whether the puzzle game was live-service, and which years → F5
- Confirmation that Tobias runs the Outage Hour as the hiring manager → if it is a panel or another round, persona weights and the reverse questions change
- The recruiter's notes on focus areas → coverage tuned to what was announced, usually one email to the recruiter
- A tuesday-dossier.md from a job-underwriter run → user-confirmed evidence, an underwriter-named objection and absolute prohibited claims
