Web research was declined, so I'll build this pack from your JD and your background only. First I'm checking for an earlier dossier file.
Femi, your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-7-denied-39226336/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 20 questions, a fit snapshot against the JD, and six reverse questions for Tobias.

I built it for a single hiring-manager conversation, assuming Tobias is your future manager because of his title. Web search was refused in this session, so it rests only on your JD and your message. It has no Saltmarsh values, strategy or loop details, and nothing about Tobias's background. The persona weights follow a generic pattern, and the upgrade menu says what research would add.

Say the word and I'll play the Skeptic on B1, the in-app-purchase question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, a peer, or someone else, and is the 60 minutes one conversation or a panel? The answer reweights every bank.
Did the recruiter mention any focus areas or something to prepare in advance?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be the hiring manager, from the title alone; not confirmed.
**Round:** one 60-minute conversation on Friday 13 November 2026, treated as a single session.
**Built on:** your pasted JD and your own background message. No web research ran (search access was refused in this session), so company, loop and interviewer facts are absent rather than guessed, and the pack's persona weights rest on a generic pattern, not on Saltmarsh's documented process.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did. Bank letters skip F so they cannot be confused with the fit-snapshot rows F1 to F10.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. None is used here, because no values were researched |
| EXP | Whether your background claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge. None is used here, because research did not run |
| CASE | A live problem from the role, scored on structure and reasoning |

The highest-ROI prep in this pack is B1, the in-app-purchase question: you have told me you have no such experience, so it will be asked in some form, and a calm, rehearsed answer changes the interview.

## Prep triage

You have about two days. Do these in order and stop when your time runs out.

| Order | Do | Tied to |
|---|---|---|
| 1 | Say your answer to B1 aloud three times, ending with the reverse question RQ4 | B1, RQ4 |
| 2 | Run A1, A2 and A3 aloud with a timer, clarifying before structuring | A1, A2, A3 |
| 3 | Write your own answers to the four slots in C1, then rehearse the 90-second arc | C1, D1 |
| 4 | Rehearse B3 and B4 | B3, B4 |

Everything else is insurance.

## Fit snapshot

Requirements are quoted from your JD. Evidence is your own words, quoted. F9 and F10 are not JD lines: they are the two absences you stated, kept visible because the interview may press on them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not live events and not two titles, with nothing inspected behind it. The words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on how the planning worked likely. If any part of planning the weekly calendar was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams the calendar involved. Answer slot: the JD's four-team line makes a probe likely. If you coordinated any of design, art, engineering or community on the drops, say which and what was yours to do, in your own words; if the calendar did not involve coordinating them, or it was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers to the studio head, not that you reviewed an event or owned a KPI, with nothing inspected behind it. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's ownership line makes a probe on which part of the numbers was yours likely. If any review of a drop fed those numbers and was yours, say how, in your own words; if there was no such review, or it was not yours, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it, not that you worked it release to release. The words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's with-QA line makes a probe likely. If you worked the checklist with QA on releases, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Four years is the figure you gave, as an associate producer; your material does not say the main title was run as a live service. Answer slot: the JD asks for live-service work. If the title was operated live, say what that meant day to day, in your own words; if it was not, or you cannot say, say so plainly and stay with the four years and the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you ran it, weekly, for the main title, for the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on the numbers. Lead with it in its own terms: you presented them monthly, to the studio head. Comfort is the JD's word; do not claim more fluency than that sentence carries |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | The sentence says you wrote a document a team still uses; it says nothing else about your writing, and the pack adds nothing. The words stay there: "I wrote the release checklist our QA team still uses." Answer slot: if there is other written work you did, say what it was, in your own words; if there is none, say so plainly and stay with the checklist |
| F9 | Leading a team: not a JD line, which says "coordinate", not lead or manage | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap you stated, and not one the JD lists. Words: "I haven't led a team." Then how you would approach coordinating teams, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | Experience with in-app purchases: the pack's own role-family expectation for a mobile title, not a JD line | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then what you would learn first and from whom, said as a plan and never as a past. Never a claim to purchase-related work, and no near-substitute offered in its place |

## Persona table

Weights are a shown judgment; recalibrate if you know something the pack does not.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: plan the calendar, diagnose a retention move, decide on release day | Highest. Hiring-manager prior is Case/Strategist plus Skeptic; no loop source established the loop, so the generic pattern applies with flat tilt beyond that | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet, persistent probing of gaps | Highest, alongside Case. Same hiring-manager prior, and your own message states two absences (F9, F10), which is the pack's inference that they will be probed | Rehearse the single most predictable objection until it is boring; build bridges only from what you actually stated; calibrated candor over bluffing |
| Data-Driven Prober | Reads your claims line by line; asks how numbers were counted | Medium. The JD names KPIs and retention metrics (F3, F7); no interviewer profile exists to push it higher | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know; name the assumption you would defend least before they do |
| Conversational/Rapport Builder | Friendly openers and "walk me through" questions | Medium. Openers arrive in any conversation, though the recruiter-screen prior does not apply here | Pre-script a 90-second arc; treat casual questions as scored; never answer "I think you've covered everything" to the reverse-question slot |
| Pressure/Stress | Time-boxed, devil's-advocate, "how much was you" | Low to medium. The hiring-manager prior does not weight it, but attribution probes arrive in every register | Pause, restate, anchor in what you actually said; hold through two follow-ups before conceding anything real |
| Values/Behavioral | Scenario probes, STAR-shaped stories | Low. No loop source documents a values-style round, and the generic fallback assumes none | "We" for context, "I" for contribution; where no honest story comes to mind, say so plainly |
| Peer Evaluator | Seam-splitting between adjacent teams | Low, so no bank. The relationship is assumed to be manager, not peer; if peers join, a bank is added | Reciprocity framing; propose seam principles rather than pretending to know the seam |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Suppose you inherit the live-events calendar for two mobile titles. Sketch the next eight weeks. What do you need to know first?" | CASE | [generic] | Clarify before you structure: what is already fixed, what team capacity each title has, who signs off. Then objective, how you would split the two titles, the order of work across design, art, engineering and community, what you would report afterward, and what could collide. Think aloud and challenge one premise. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's first line (F1's requirement), asked as planning rather than record. CASE because it scores structure; generic because it is a pattern for the problem, not a fact about this employer |
| A2 | "An art asset for Thursday's update will miss its date and the build is already locked. How do you decide what happens, and who do you speak to first?" | CASE | [generic] | Ask what exactly is late and what the options cost: cut, slip or swap. Name who owns the decision, who must hear it, and what you would record for the review afterward. The question needs no claim about your past, so the guidance makes none | Tests the JD's four-team coordination line (F2's requirement) as a decision under pressure. CASE because it is live; generic because the scenario is a pattern |
| A3 | "Retention for players who joined during the last event looks lower than for the one before. Diagnose it." | CASE | [generic] | Clarify the metric, the cohort and the window first. Then segment, check what else changed in the period, form one hypothesis, and say what you would report and what you would not conclude yet. The question needs no claim about your past, so the guidance makes none | Combines the JD's post-event review and retention lines (F3 and F7's requirements) in the persona's native "diagnose it" form. CASE; generic |
| A4 | "An hour before a planned release, QA flags a blocker. Walk me through how you decide whether to ship." | CASE | [generic] | Ask how severe it is, whom it affects, and whether the change can be rolled back. Name the decision owner, what you tell the community team, and what you would add to the checklist afterward. The question needs no claim about your past, so the guidance makes none | Covers the JD's release-checklist-with-QA line (F4's requirement) as a live decision. CASE; generic |
| A5 | "You have more event ideas than calendar slots across the two titles. How do you decide what runs and what waits?" | CASE | [generic] | Ask what the calendar is for and who decides trade-offs. Then name your criteria, how you would compare options against the KPIs you would report, and how you would tell the people whose idea waits. The question needs no claim about your past, so the guidance makes none | The JD's "plan and run" line (F1's requirement) turns on prioritization, and this is the question that exposes it. CASE; generic |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see any in-app purchase work in your background. How would you approach that in this role?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Step 1, the plain acknowledgment, in your own voice: "I haven't worked on a game with in-app purchases." Step 2, the limit before it is asked for: say what your material does carry, and only that: "I ran the weekly content-drop calendar for our main title for the last two years." Offer it as what you did, and let them draw any inference. Step 3, a ramp plan said as a plan: what you would learn first, from whom, and how soon, in your own words. Expect two follow-ups: what you would learn first, and what you would leave alone until you had. Hold by returning to Steps 1 to 3, never by adding experience. Then, if it fits, ask RQ4 | F10 is your stated absence and the likeliest place this interview presses, so it is the pack's deepest rehearsal. EXP because it tests whether your story survives cross-examination |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick the requirement where your material is thinnest and say so plainly. The pack's reading, from the fit snapshot, is that F1 and F2 are where it is thinnest. Say what you did in the quote's own terms, then what you would do in your first weeks as a plan. Choose one; a list of weaknesses reads as no judgment | The Skeptic's stem, aimed at the JD's mid-list rather than its headline. JD because it scores the stated requirements |
| B3 | "You've run the calendar for your studio's main title. What changes when it's two titles at once?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence at its scope: "For the last two years I ran the weekly content-drop calendar for our main title." Then answer as a plan, not a past: what you would need to know about the second title first, and what you would expect to differ. Keep the plan separate from the past, and do not describe the second title's work as something you have done | F1 is the thinnest-scope row against the JD's "two of our mobile titles". JD because it scores that stated scope; the premise is your own quote's |
| B4 | "Tell me about a time you had to coordinate design, art, engineering or community work on one update." | JD | [grounded] "Wrote the release checklist our QA team still uses." | No quoted sentence of yours carries this story, so this is a selection scaffold. Pick a drop where more than one discipline had work due; it needs a named dependency, a moment it was at risk, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I wrote the release checklist our QA team still uses", or how you would handle it | F2 is silent in your material, so this probe is likely. JD because the four-team line is the JD's own |
| B5 | "The JD asks for 3+ years producing live-service games or apps. How would you describe your four years against that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Say it in the sentences' own terms: four years as an associate producer at a puzzle-game studio, and for the last two the weekly content-drop calendar for the main title. Answer slot: if the title was operated live, say what that meant day to day; if it was not, or you cannot say, say so plainly and stay with the four years and the weekly calendar. Do not retitle yourself | F5 is the years requirement, where the title and the live-service claim are separate questions. JD because it scores the stated requirement |

### C. Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Open with the sentence's own scope: you presented the monthly retention numbers to the studio head. Then four slots, each in your own words. How the numbers were counted. What they were sensitive to. The assumption behind them you would defend least. Which part was yours. If you do not know how they were counted, say so plainly; if you only presented what others produced, say so plainly and return to the monthly presentation | A headline claim from the background, and exactly where a prober goes. F3 and F7 are the evidence. EXP because it tests attribution |
| C2 | "What should the post-event review tell the team?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | A method question, so answer it as method: the decision the review supports, what you would compare against, what you would report and what you would leave out, and which KPIs you would ask Tobias about instead of assuming. The nearest thing your material carries is the one sentence, so keep it at that scope: "I presented the monthly retention numbers to the studio head." | The JD's ownership line (F3's requirement). JD content with a CASE delivery; the evidence it leans on is thin, so it is rehearsed as method |
| C3 | "When two retention views disagree, how do you decide which to trust?" | JD | [generic] | A method answer, so the guidance makes no claim about your past: define the metric, the cohort, the window and the denominator for each view, say which assumption you would defend least, and say what you would check before choosing. Name the weakest assumption before you are asked | F7's requirement is comfort with retention metrics, and this is how a prober tests comfort. JD; generic because it is a pattern |

### D. Conversational/Rapport Builder (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc in four beats, each a clause your sentences state: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for the last two years; the release checklist QA still uses; the monthly retention numbers presented to the studio head. Answer slot: why this role and why now is yours to say; the pack supplies no reason | F5 to F8 are the beats. EXP because it is the biography question, scored on economy |
| D2 | "Why live operations on mobile, and why Saltmarsh?" | JD | [generic] | The motive is yours and the pack supplies none. Say what drew you, in your own words. Any fact you cite about Saltmarsh should be one you have read on their own pages, because research did not run and the pack holds none | The rapport interviewer's motivation probe. JD because it scores the role; generic because no company fact was established |
| D3 | "If I asked you to put an event-date change in writing for the four teams, what would that message need?" | JD | [generic] | Say who it is for, what changed, what you need from whom by when, and where the single current version lives. The question needs no claim about your past, so the guidance makes none. If you offer your own writing, keep it at its scope: "I wrote the release checklist our QA team still uses." | The JD's written-communication line (F8's requirement), asked casually and scored anyway. JD; generic |

### E. Pressure/Stress (low to medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already done this job?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Never led a team, and never worked on a game with in-app purchases." | Pause and restate it. Anchor in what you stated: you ran the weekly content-drop calendar for your main title for the last two years. Hold through two follow-ups by returning to that, never by adding to it. Concede the limit specifically, in your own voice: "I haven't worked on a game with in-app purchases." Do not fold on the calendar you ran to restore harmony. Answer slot: what you would bring beyond that is yours to say in your own words | The persona's "why you" stem, and F1 and F10 are the two sides of it. EXP because it tests whether you hold a position without bluffing |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold at the sentence's scope: "I wrote the release checklist our QA team still uses." Answer slot: if any part was not yours, say which part and whose it was; if all of it was yours, say that and stop. Concede uncertainty specifically and never add detail to make the claim feel bigger | F4 is the evidence, and attribution probes land on a claim nothing inspected backs. EXP because it tests precision |

### G. Values/Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Your sentence carries a presentation to the studio head and does not say the numbers were unwelcome, so this is a selection scaffold. Pick a time the hard truth actually landed, with a named stake and an intact relationship afterward; use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I presented the monthly retention numbers to the studio head", or how you would handle it | The persona's own stem, used because behavior questions can arrive in any manager round. F3 holds the nearest sentence. EXP because it is about past behavior; no company values were established, so it is not VAL |
| G2 | "When did you put players ahead of an internal metric?" | EXP | [generic] | A selection scaffold: pick a time with a named choice, who disagreed, and what you chose; it needs a real decision, not a general attitude. If no such time comes to mind, say so plainly, then say how you would handle it. The pack supplies no event | The persona's customer-over-metric stem, adapted to players. Generic because no quoted sentence carries it and no company value was established |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A5, B3 |
| "coordinate design, art, engineering and community teams on each update" | A2, B4 |
| "own the post-event review and the KPIs it reports" | A3, C2 |
| "manage the release checklist with QA" | A4, E2 |
| "3+ years producing live-service games or apps" | B5, D1 |
| "experience running a content calendar" | B3, D1 |
| "comfortable with player-retention metrics" | A3, C1, C3 |
| "clear written communication" | D3 |

## Reverse questions

No interviewer profile exists, so none is tied to Tobias's own path; the upgrade menu says what would change that.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "How do the calendars for the two titles work together today: one team, shared slots, or separate?" | It shows you read the JD's two-titles line as an organizing problem, not a volume problem |
| RQ2 | "Which KPIs does the post-event review report today, and who reads it?" | It goes to the JD's ownership line and tells you what you would actually be measured on |
| RQ3 | "What does the release checklist with QA look like today, and what would you want changed first?" | It invites a peer conversation about a document the JD names |
| RQ4 | "What part do in-app purchase metrics play in the KPIs this role reports?" | It turns your stated absence into an honest question about where it matters, instead of waiting to be asked |
| RQ5 | "Which of the four teams is hardest to coordinate with on an update, and why?" | It signals you expect the coordination to be the hard part of the job |
| RQ6 | "What would a strong first ninety days look like for this role?" | It ties the whole conversation to an outcome Tobias can name |

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't worked on a game with in-app purchases." No slot |
| Ran live events, or ran the calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says one main title's weekly content-drop calendar. B3's answer stays inside the main title |
| Owned the post-event review or the KPIs | Inflated form of F3 | F3's quote at its own scope. The material says you presented the monthly retention numbers to the studio head. C1's slots ask only about those numbers |
| Managed releases against the checklist | Inflated form of F4 | F4's quote at its own scope. The material says you wrote the checklist and QA still uses it. E2 stays with the checklist you wrote |

## Sources

Provided documents: the pasted JD and your background message. No dossier was present, and none was consumed.

Searches sent, all refused, so none returned a result:

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games strategy mobile titles news": refused
- "Tobias Wrenfield Saltmarsh Games": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have moved the values cheat sheet and the VAL questions; both are absent, and the upgrade menu offers them |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have moved the loop structure and the persona weights; the generic pattern stands in, and the pack says so |
| 3. `Saltmarsh Games strategy` | unavailable | Would have moved the CO bank; no CO question is included |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have moved the interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access for a targeted research pass (up to 6 searches and 2 fetches), and then a deeper pass if you want it (up to 6 further searches and 2 further fetches, several more minutes) → published values and the loop, so persona weights stop resting on a generic pattern; a CO bank grounded in current strategy; a values cheat sheet if a values round turns up
- Whether Tobias is your future manager, a peer or a panel member, and whether the 60 minutes is one conversation → every bank reweights
- Tobias's public profile or talks → an interviewer read, persona adjustments, and a reverse question tied to his own path
- The recruiter's prep note, if any, including focus areas or something to prepare in advance → coverage of anything pre-declared
- Your own answers to the answer slots in F1 to F5 and F8 → those rows and the guidance that rests on them regenerate with your words
- The release checklist, a sample drop calendar, or a redacted retention deck → F1, F3, F4 and F7 can move from medium toward high, because these are the inspectable artifacts for this kind of role
- Hours you have before Friday → the prep triage resizes
- A tuesday-dossier.md from an earlier role assessment → verified evidence and a prohibited-claims list from that work, so the highest-ROI objection is evidence-derived instead of inferred
