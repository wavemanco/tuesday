Your prep pack for Thursday is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-4-denied-aeb5cf34/Quartzline_product-manager-platform-apis_interview_pack.md`. It has 20 questions, built for a hiring-manager conversation using your dossier's confirmed evidence.

- **Research was refused.** The host denied all three searches (Quartzline's values, interview process and strategy). The company-knowledge question (D3) and the live-problem bank (B) are therefore labelled generic. Persona weights rest on your note and the hiring-manager default. The Sources section records this.
- **Most important rehearsal:** A1 is the objection your dossier named, that you've never held the PM title or owned a roadmap. P1 is the same objection asked as a 60-second challenge. Your dossier doesn't list a prepared answer for either, so I built the guidance from your confirmed evidence.
- **One thing to check:** the dossier lists R2, "Shipped API or platform products", as a must-have but gives it no strategy. Your confirmed evidence is leading integrations of the vendor's APIs, not shipping an API product. I treated it as an open question (A2): answer with what you actually shipped, or say plainly that you led integrations instead.

Say the word and I'll play the Skeptic on A1 with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager (interviewer name not given). **Built on:** your note about the round plus the job-underwriter dossier you carry (`tuesday-dossier.md`, version 1.1).
**Highest-ROI prep:** question A1. The underwriter named that objection from evidence you confirmed, so it gets the deepest rehearsal. P1 is the same objection delivered under time pressure.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what the quoted sentences carry. Every answer block is language proposed for you and is pending your approval.

| Type | What it scores |
|---|---|
| VAL | Behaviour against the company's published values. No VAL questions here, because no values-style round was detected |
| EXP | Whether your claims survive scrutiny and what was actually yours |
| JD | The stated requirements and responsibilities, including the gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role |

## Fit snapshot

Requirement text is quoted from the dossier's `role_profile`, which stands as the JD. Evidence is quoted from the dossier's `verified_candidate_evidence`. A confidence note attached to a verified claim is not part of the quote. It sits in the Confidence column and in the bridge as a stated limit.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified evidence 2; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | low | [grounded] | transferability | The underwriter's strategy is a bridge, positioned as adjacent and never as product management experience. Your material says integration leadership, a playbook and input sessions, not a product management role, and the words stay at that scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The third quote is confirmed with limited inspectable proof, so expect a probe on it and say its limit before it is extracted. Any wider step is an answer slot: if a probe asks what part of product work those sessions covered, say what happened in your own words; if they only fed evidence to product, say so plainly |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records roadmap ownership and prioritization authority as an acknowledge_gap area, with prohibited_claims entries beside it. Words: "I haven't owned a product roadmap." Then a plan, said as a plan and never as a past: learn how roadmap decisions are made with the two squad leads and get the adoption baseline before proposing priorities. No bridge and no slot, and F1's quotes are not offered as roadmap ownership |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | low | [grounded] | discovery | The quote touches REST APIs and go-live without showing whether any API or platform product was shipped. The dossier lists R2 as a high-priority must-have and gives it no strategy of its own. Answer slot: the R2 line makes a probe on what you shipped likely. If you shipped an API or platform product, or part of one, say what it was and what part was yours, in your own words; if what you led was integrations of the vendor's APIs rather than shipping one, say so plainly and stay with the quote |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified evidence 2 | medium | [grounded] | discovery | The quotes reach REST APIs, architecture and a playbook, not API docs or schemas in those words. Answer slot: the R3 line makes a probe on docs and schemas likely. If the playbook or the integrations involved them, say how, in your own words; if not, say so plainly and stay with the quotes |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [grounded] | discovery | The quotes reach clients and product, and say nothing of sales. Engineering appears only as architecture inside the integrations. The second quote is confirmed with limited inspectable proof. Answer slot: the R4 line names engineering, sales and customers, so expect a probe on each. If you aligned any of them on something, say what and what part was yours; if one was not part of your work, say so plainly and stay with the quotes |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier marks this clarify: the evidence may exist but was not established, and no verified entry speaks to it. Answer slot: the R5 line makes a probe on how you have worked with delivery teams likely. If you worked inside an agile delivery process, say how, in your own words; if you never worked that way, say so plainly, then say what you would want to confirm about how Quartzline defines it |

Pending your approval: every bridge and answer slot in the Gap and bridge column.

## Persona table

The loop is one upcoming session, a 45-minute conversation with the hiring manager, taken from your own note. Weights start from the hiring-manager prior and are adjusted by the dossier. No interviewer profile exists, so there is no interviewer read.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A, 5 questions) | Quiet, persistent probing of the title, roadmap and agile gaps | High. The hiring-manager prior favours it, and the underwriter named a Skeptic-shaped objection and two weak areas (F1, F2, F6) | Rehearse A1 until it is boring. Bridge only from your quoted sentences with the limit named, then give a ramp plan |
| Case/Strategist (B, 5 questions) | Live problems on the role's own responsibilities: roadmap, adoption metrics, discovery, specs | High. The hiring-manager prior favours it, and the JD names four such responsibilities | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Data-Driven Prober (C, 3 questions) | Takes the headline figure and the playbook line by line | Medium. "30+" is the one number in your evidence and a magnet for this style | Say plainly how much you know about how the figure was counted. Name the assumption you would defend least before they do |
| Conversational (D, 3 questions) | Friendly opener and a why-us question that are still scored | Medium. Every 45-minute conversation has an opening, and the style is cheap to underprepare for | A 90-second arc, with casual questions on JD topics treated as scored |
| Peer Evaluator (E, 2 questions) | Seam-splitting with the two squad leads, collaboration scenarios | Low to medium. The interviewer is the hiring manager, not a peer, but the JD's two engineering squads invite the same probe | Propose seam principles instead of pretending to know the seam |
| Pressure (P, 2 questions) | Time-boxed challenge on why you over a PM with the title | Low. It is not in the hiring-manager prior, but A1 can arrive this way | Pause, restate, hold through two follow-ups, concede one thing explicitly and specifically |

## Requirement coverage

| Stated requirement or responsibility | Question IDs |
|---|---|
| R1 3+ years product management experience | A1, A3, A5, P1 |
| R2 Shipped API or platform products | A2 only. A second question would need evidence the material does not carry |
| R3 Technical fluency: API docs, schemas | C3, D2 |
| R4 Stakeholder management across engineering, sales, customers | E2, E1 |
| R5 Agile delivery experience | A4 |
| Own the roadmap | A3, B1, B3 |
| Run discovery with integration partners | B4 |
| Write specs and drive delivery with two engineering squads | B5, E1 |
| Define and track adoption metrics | B2 |

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; the plain acknowledgments are sourced from the dossier's prohibited_claims and its acknowledge_gap area | The highest-ROI rehearsal, named by the underwriter. Four beats. One, concede first, in the question's own terms: "I haven't held the product manager title, and I haven't owned a product roadmap." Two, the adjacent case at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I wrote the internal integration playbook my team uses." Three, the nearest product-facing item with its limit said first: "I ran quarterly roadmap-input sessions feeding client evidence to product." It is confirmed with limited inspectable proof, so say what you can show, and say it was input to product. Four, a ramp plan said as a plan: learn the roadmap process and the squad leads' decision rights first. Follow-ups. "Feeding evidence isn't owning a roadmap" — agree it is not. "Why not the PM who has done it?" — do not claim to be better; return to the quotes and the plan. "What if a squad lead disagrees?" — the plain acknowledgment from prohibited_claims is "I haven't set prioritization for an engineering squad", then how you would learn the decision rights. Never say you have effectively done the job | F1 and F2 are the evidence and the gap. The underwriter derived this objection from evidence you confirmed, so it is asked as they wrote it: every negative in it has a dossier source. JD because it scores R1 directly, in Skeptic delivery |
| A2 | "Tell me about an API or platform product you've shipped." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | An open prompt, so you choose the instance. Answer slot: if you shipped an API or platform product, or part of one, say what it was and what part was yours, in your own words. If what you led was integrations of the vendor's APIs rather than shipping one, say so plainly and tell that at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Hold that scope through two follow-ups, and do not let go-live become a product launch | F3. R2 is a must-have, and the dossier left it without a strategy, so this is the question where the honest branch matters most |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] the acknowledgment is sourced from the dossier's acknowledge_gap area and prohibited_claims | Name the roadmap, plainly: "I haven't owned a product roadmap." Then the plan, said as a plan: learn how roadmap decisions are made with the two squad leads and get the adoption baseline before proposing priorities. No bridge. The underwriter looked for roadmap evidence and found none, so inventing one live is how you get caught | F2. The stem rewards calibrated candor, and the answer is already fixed by the dossier. JD because it scores the stated responsibility |
| A4 | "How have you worked inside an agile delivery process with an engineering team?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the JD's R5 line makes this probe likely. If you worked inside an agile delivery process, say how, in your own words. If you never worked that way, or it was not yours, say so plainly and return to the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Then say what you would want to confirm about how the two squads define agile | F6. The premise is the JD's and not yours, so the second branch allows that it never existed. JD because it scores the preferred requirement |
| A5 | "Why product, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The reason is yours, and the pack does not know it. The one fact it can hold is the quote, at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product," with the limit that the sessions were confirmed with limited inspectable proof. Answer slot: if a specific moment in that work pointed you toward product, say it in your own words; if there was no such moment, say so plainly and give the reason you do have. Never say those sessions changed what product built | F1. Motivation consistency is what the Skeptic scores here. JD because it scores whether the move is credible against the R1 gap |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You start Monday and own the roadmap for the partner API platform. Sketch your first ninety days — what do you need to know first?" | CASE | [generic] | Clarify first, aloud: what the platform is for, who the partners are, the adoption baseline, and which decisions are yours versus the squad leads'. Then objective, approach (listen before proposing, learn decision rights, baseline the metrics), risks (acting on authority you do not yet have). Challenge one premise respectfully, for example whether ninety days should end in a roadmap or in a proposal to the squad leads. The question needs no claim about your past, so the guidance makes none | The JD's roadmap responsibility is the problem, and the dossier's unknowns are the clarifying questions. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Suppose adoption of a partner API has stalled. How do you diagnose it?" | CASE | [generic] | Ask what counts as adopted and what the baseline is, and do not assume how Quartzline measures it. Segment partners, list hypotheses, pick the cheapest test, and name the assumption you would defend least. Makes no claim about your past | The JD's adoption-metrics responsibility. The dossier says no baseline was stated, so the clarifying step is the honest move |
| B3 | "Two squad leads want opposite things for the same partner request. How do you decide what goes on the roadmap?" | CASE | [generic] | Ask first who decides, since the JD asserts authority that the dossier could not verify. Then the evidence you would gather from partners, the criteria, and the escalation path. If pushed on whether you have done this, the plain acknowledgment sourced from prohibited_claims is "I haven't set prioritization for an engineering squad" | F2. A live problem on the exact seam the dossier flags as unverified |
| B4 | "How would you run discovery with integration partners in your first quarter?" | CASE | [generic] | Whom you would speak to first, what you would try to learn, and how it would feed decisions that you would make jointly with the squad leads. A plan, with no claim that you have run product discovery before | The JD's discovery responsibility, asked as a plan |
| B5 | "A change you want to make to the API could break live integrations. How do you write the spec and bring both squads along?" | CASE | [generic] | The problem and the partners affected, the options including not changing, the compatibility risk, who must review, the success measure, and how partners are told. Makes no claim about your past | The JD's spec-writing and squad-delivery responsibility |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ client integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: say how the 30+ was counted, in your own words, and what it is sensitive to. Name the assumption behind it you would defend least. If you do not know how it was counted, say so plainly. Keep the number on the noun it came from: client integrations | F1 and F3 rest on this figure, and the playbook is the inspectable proof behind it. EXP because it tests whether the claim survives |
| C2 | "Of scoping, requirements, architecture, UAT and go-live, which were yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The question is premised on the quote's own list. Answer slot: say which stages you did yourself and which others did, in your own words. If some were shared or someone else's, say so plainly. Keep "led" at its scope | F1. "Led" invites an attribution probe, and a precise answer is the credibility gain |
| C3 | "Walk me through the integration playbook you wrote — what's in it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say: "I wrote the internal integration playbook my team uses." Answer slot: the JD's R3 line makes a probe on API docs and schemas likely. If the playbook covers them, say what and how; if it does not, say so plainly and describe what it does cover. The dossier records the playbook as inspectable, so offer to share it if you are permitted to | F4. EXP because it tests the one claim with an artifact behind it |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through your background." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc on three beats the quotes state: you led the integrations, you wrote the playbook, you ran the input sessions (limited inspectable proof, so say it plainly). A fourth beat, why this role, is yours to supply and A5 rehearses it. Keep each verb at its scope | F1. The casual opener sets the frame for everything after it |
| D2 | "What have you been working with lately around API design, documentation or schemas?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | An open prompt. Pick something you actually looked at recently, with a named artifact, what you noticed, and what it changed in how you think. If nothing comes to mind, say so plainly, then give the nearest thing your material carries, the REST APIs in the integrations you led, or how you would get up to speed on Quartzline's docs | F4. Casual questions on JD topics are still scored |
| D3 | "Why Quartzline?" | CO | [generic] | No research ran, so the pack holds no facts about Quartzline's strategy. Use only what the JD says: a partner-facing API platform, discovery with integration partners, two engineering squads. Add your own reasons. Never state a fact about the company you have not read yourself | `[generic]` because the search that would have grounded it was refused. The upgrade menu says what that would change |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where is the seam between you and the two squad leads, and what happens when you disagree?" | JD | [generic] | Propose principles instead of claiming to know the seam: who decides what, how disagreement is raised, how it escalates. Say you would want Quartzline's actual split first and ask it. The plain acknowledgment sourced from prohibited_claims is "I haven't set prioritization for an engineering squad". Do not claim the authority, since the JD asserts it and the dossier could not verify it | F2. The dossier's open risk, rehearsed |
| E2 | "Tell me about a time you had to align engineering, sales and a customer." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | An open prompt on the three groups the JD's R4 line names. Answer slot: if you aligned all three on something, say what and what part was yours, in your own words. If one of the three was not part of your work, say so plainly and tell the integration story at the quote's scope | F5. R4 names three groups and the quote reaches only clients |

### P. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over a PM who has done this for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; the plain acknowledgment is sourced from the dossier's prohibited_claims | Pause and restate the question. Hold: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Concede one thing explicitly: "I haven't held the product manager title, and I haven't owned a product roadmap." Hold through two follow-ups by returning to the quote and never by adding to it. Do not claim to be better | F1. A1's objection with a stopwatch |
| P2 | "Of those 30+ integrations, how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold "led" at its scope. Answer slot: say specifically which parts were yours and which were others', in your own words. If you do not know a part of the split, say so plainly. Do not fold on the core claim to ease the moment | F1. Attribution pressure is the one probe built to catch inflation |

## Reverse questions

Questions 1 and 2 come from the dossier's `questions_for_employer`. The rest come from its risks and from this pack.

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's open risk is that decision authority is asserted in the JD and not evidenced. The answer decides whether the role is what the posting says |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are named as a responsibility with no baseline stated. It reads as diligence and tells you what you would be judged on |
| 3 | "What would you want to see in my first ninety days to know that coming from integration delivery was the right call?" | It turns the A1 objection into a shared success definition, using words you can source |
| 4 | "How does partner evidence reach the roadmap today, and who owns that channel?" | It ties to the input sessions in F1 without claiming an outcome for them, and it shows whether product already has a discovery owner |
| 5 | "What did the two squads decide last quarter that you would want a new PM to have been part of?" | It probes the real working seam and gives you a concrete example for E1 |
| 6 | "What would a strong first year look like, and what would a weak one look like?" | It surfaces the hiring manager's bar and lets you test it against F2 and F6 |

## Prohibited claims

Built from the dossier's `prohibited_claims` and from the stretched forms of your quoted sentences, before the question banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | The plain acknowledgment: "I haven't held the product manager title." The adjacent case stays at the scope of "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" |
| Having owned a product roadmap | Dossier prohibited_claims, and the acknowledge_gap area for roadmap ownership | The plain acknowledgment: "I haven't owned a product roadmap", then a ramp plan. No slot and no bridge. Your material says input sessions feeding evidence to product, not ownership |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | The plain acknowledgment: "I haven't set prioritization for an engineering squad", then how you would learn the decision rights |
| Shipped an API or platform product | Inflated form of F3's quote | The quote at its own scope. The limit is the pack's observation: your material says integrations of the vendor's REST APIs, not shipping an API product. A2's slot asks only what you shipped, if anything |
| Shaped or influenced the product roadmap | Inflated form of F1's third quote | The quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product". The pack's observation is that no outcome of those sessions appears in your material |

## Sources

- Provided: `tuesday-dossier.md`, pasted by you (dossier_version 1.1, from job-underwriter, 2026-08-14). Sections consumed: `role_profile` (supplied the JD tier: requirements R1 to R5, responsibilities, unknowns), `handoff_to_mock_interview` (verified_candidate_evidence, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims) and `decision` (context only). This dossier has no `evidence_map`, `evidence_state` or `risk_register`. The loop comes from your own note.
- Searches sent, all refused by the host: "Quartzline company values" — refused; "Quartzline interview process product manager" — refused; "Quartzline partner API platform strategy news" — refused.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have named published values. Nothing else moves, because no values-style round is detected and section 10 is dropped either way |
| 2. Quartzline interview process, product management | unavailable | Would have documented other rounds. Persona weights rest on your own note and the hiring-manager prior |
| 3. Quartzline strategy and recent news | unavailable | Would have grounded D3 and the B bank, which are labelled `[generic]` for this reason |
| 4. Interviewer name and Quartzline | n/a | No name was given, so there was no query to form |
| 5. Representative Product Manager, Platform APIs JD | skipped | The dossier's role_profile supplies the requirements and responsibilities that fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep email → focus areas and any pre-declared deliverable, which become a build section
- Search access, either a light pass (up to 6 searches and 2 fetches) or a deeper one adding up to 6 more searches and 2 more fetches, several more minutes → D3 and the B bank become grounded in Quartzline's published strategy, and any documented loop replaces the hiring-manager prior
- Your answers to the slots in F3, F4, F5 and F6 → those rows can move from discovery to a story-mapped answer. This also applies to the A2, A4, C2 and E2 slots
- A sample agenda or notes from one of the roadmap-input sessions → F1's third quote could rise from medium to high, which is the one claim a prober can find the seam in
- The CV behind your confirmed claims → more quoted sentences for rows F3 to F6
