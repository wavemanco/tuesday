Your pack is written and saved. Here is the hand-off.

Your prep pack is saved as `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/sonnet/tuesday/part-2/rooms/case-8-denied-9723c56d/Ashgrove_member-experience-lead_interview_pack.md`. It covers all three rounds on 20 November, with separate question banks and reverse questions for each. I built it only from what you pasted and sent no web searches. Your values text, the recruiter's email and the strategy lines already covered everything the pack needed. No interviewer names have been assigned, so there is no interviewer read.

Where to spend your time:
- **Highest-ROI rehearsal (D1, round 2):** "This role owns complaints across branches and the contact centre. You haven't worked in a contact centre. Why should I believe you can own that side?" I inferred this from your own words. B1 is the lighter round-1 version.
- **Second priority:** presenting to senior leaders (B3 and D2). Both gaps are in your own words, so the pack coaches a plain acknowledgment and a plan, not a claim.
- **Your answers will upgrade the pack:** where your material is silent (F1, F3, F4, F5, F7, F9), the pack leaves answer slots. Your answers outside a drill would turn those rows into story-mapped ones.

Say the word and I'll play the Skeptic on D1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Prepared for Dara. Loop mode: three rounds on 20 November 2026. This is the first version, so there is no changelog.

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Nothing beyond the length |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; the panel is also the values round and scores against the four values |

No interviewer names have been assigned, so there is no interviewer read.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script, and each cell is built to be said in 90 to 120 seconds.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behaviour demonstrates Ashgrove's published values, not generic virtue |
| EXP | Whether the claims in your background survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, competition, direction |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview. It is not a question for this conversation. Where a slot gives two branches, either one is a good answer if it is true.

## Fit snapshot

Your evidence cells hold only your own words, from your message. Nothing is inspected behind them yet, so no row is above medium.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what came before and after the log likely. If any step of how a complaint moved was yours to set or change, say which and how, in your own words; if the log was the part you held, or there were no such steps, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing that implies phone, call or contact-centre exposure |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says a monthly complaints spreadsheet your regional manager uses; it does not say what the spreadsheet showed, and a redacted copy would be the inspectable proof. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's volumes-and-resolution-times line makes a probe on what it showed likely. If it showed either, say which and how each was counted, in your own words; if it showed neither, or counted something else, say so plainly and stay with the spreadsheet you built and who used it |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The quote is tellers and training, not supervisors and coaching, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you taught the script likely. Say how, in your own words; if there is nothing more to say than that you trained them on it, say so plainly and stay with the tellers you trained |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here, which is not the same as having done none. Answer slot: expect a probe on any work with a digital team or on a self-service journey. If you have, say what it was and what part was yours; if not, say so plainly, then say as a plan what you would want to learn first about where members get stuck |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The quote already carries the length, so only it is reworded: "I've worked six years in retail banking, the last three as a branch supervisor." Say it in those terms and let them map it; the pack adds no practice and borrows none of the JD's vocabulary for your history. A years requirement is read against this quote and is not a gate |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | The quote says formal, not regulated, and the pack does not close that for you. Words: "I handled the branch's formal complaints log." Answer slot: expect a probe on what made a complaint formal in your log and what had to happen to it. Say that in your own words; if you are not sure what governed it, or the log was only your branch's own record, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then what you would do to prepare for the first one, said as a plan and never as a past. No claim of confidence you cannot back |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, and the words stay there. Answer slot: expect a probe on the tool and what you did in it. Say which tool it was built in and what you did in it, in your own words; if there are parts of reporting you have not done in it, say so plainly and stay with what you built |

## Grounding brief

The four lines of Ashgrove's July 2026 strategy brief as you reported them. The brief itself was not in hand.

| Item | What the brief says | Provenance | Used in |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | A3, E1 |
| Hubs | Consolidate eight branches into five hubs over 2027 | [grounded] | A3, E2, H3 |
| New product | Launch a small-business lending product in Q1 2027 | [grounded] | A3 |
| Competition | The main competitive pressure is app-only banks | [grounded] | A3, E1 |

## Highest-ROI rehearsal

D1 is the single most predictable objection: the role owns complaints across branches and the contact centre, and your own words say you have never worked in a contact centre (F2). No dossier named it, so the pack inferred it from the snapshot. B1 is the light version of the same question in round 1. Rehearse D1 until it is boring. The second priority is the presenting gap (F8), asked at B3 and D2.

## Persona weights and question banks

### Round 1: the recruiter (30 minutes)

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A) | Friendly, unstructured, scored | High: the recruiter-screen prior; the email says nothing else about the format | A pre-scripted 90-second arc; treat casual questions about hot JD topics as scored |
| Skeptic, light (B) | Knockout-style checks on the hard requirements, in a friendly register | Medium: the prior is logistics and knockouts, and F2, F7 and F8 are the requirements most likely to be checked | Name the gap before they do, hold what your words carry, give a plan |

**A. Conversational / Rapport Builder**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F6, F1, F4 and F3: a 90-second arc in this order, each beat as the quote states it: six years in retail banking; the last three as a branch supervisor; handling the branch's formal complaints log; training new tellers on the escalation script; building the monthly complaints spreadsheet the regional manager uses. Use "we" for context and "I" for what you did. Close with one sentence on why you want to move into complaints leadership, in your own words | The opening question of almost every screen, and where the years requirement (F6) is first checked; EXP because it tests what the background actually shows |
| A2 | "What drew you to Ashgrove?" | CO | [grounded] | Pick one published thing and say why, in your own words. The values page says "Members First, Always — we decide from the member's side of the counter" and "Own the Fix — whoever finds the problem keeps hold of it until it is solved"; quote one as published and say what it means to you. Do not say you already live it unless a story of yours carries it | Motivation consistency is what a recruiter screen scores; CO because it tests homework on the values page the panel will score against |
| A3 | "What do you know about where we're heading?" | CO | [grounded] | Say the facts as the brief states them: 40% of member service to digital channels by 2028; eight branches into five hubs over 2027; a small-business lending product in Q1 2027; app-only banks as the main competitive pressure. Do not recite all four: pick the one that touches complaints and give a one-sentence view of what it means for the role, labelled as your view | Strategy fluency separates prepared candidates; the brief is the one source the recruiter sent you |
| A4 | "Tell me about the complaints side of your current role." | EXP | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F1, F4 and F3: three beats, each at the scope its quote states: the branch's formal complaints log; training new tellers on the escalation script; the monthly spreadsheet your regional manager uses. Answer slot: if there is a figure you can stand behind, give it and say how it was counted; if there is none, give none | Complaints are the centre of the JD, and these three rows are your whole evidence for it; EXP because it tests what was yours |
| A5 | "What are you actually playing with in self-service and digital journeys these days?" | JD | [grounded] | Answer slot (F5): if you have worked with a digital team or on a self-service journey, say what it was and what part was yours, in your own words; if not, say so plainly, then say as a plan what you would want to learn first about where members get stuck. Treat this casual question as scored | The JD names digital teams and self-service journeys, and the casual register hides how closely it is scored |

**B. Skeptic, light**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The light first pass of D1. Name it before they do: "I haven't worked in a contact centre." Hold what your words carry: "I handled the branch's formal complaints log." Add one plan sentence in your own words. Do not choose a smaller weakness to avoid this one | F2 is the sharpest gap and the likeliest answer to this stem; JD because it scores the stated requirement |
| B2 | "Tell me about your experience with regulated complaints." | JD | [grounded] "I handled the branch's formal complaints log" | Start from the quote: "I handled the branch's formal complaints log." Answer slot: expect a probe on what made a complaint formal in your log and what had to happen to it. Say that in your own words; if you are not sure what governed it, or the log was only your branch's own record, say so plainly and stay with the log | F7 is a stated requirement your words only touch; a recruiter checks it as a plain yes-or-no in a friendly register |
| B3 | "How confident are you presenting to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then what you would do to prepare for the first one, said as a plan. Do not use the word confident as a claim you cannot back | F8 is a stated requirement and your own words say there is a gap; D2 rehearses it harder in round 2 |

**Reverse questions, round 1**

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What does the 20-minute case in the panel round look like: written or live, and is anything shared beforehand?" | It is diligence on a graded part of the loop, and the answer fills a gap in this pack |
| R1.2 | "How is the digital shift in the strategy expected to change who handles a member's complaint?" | It shows you read the brief and ties the role to its direction |
| R1.3 | "What would the Head of Member Services most want from this hire in the first six months?" | It signals you are already thinking about round 2 and the manager's priorities |

### Round 2: the Head of Member Services, your manager (45 minutes)

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (C) | Scenario probes, STAR-shaped stories | High: the recruiter's email says the round is mostly behavioural, which overrides the usual manager prior | Where a quote carries a story, map it; where none does, use the scaffold and its honest branch |
| Skeptic (D) | Quiet, persistent probing of the gaps | High: a manager derisks the hire, and F2 and F8 are the gaps | Rehearse D1 until it is boring; hold, then concede only what your words say |
| Case / Strategist, low (E) | A live problem on the strategy | Low: the usual manager prior, reduced because the email says mostly behavioural | Clarify, then structure, then answer; challenge one premise respectfully |
| Data-Driven Prober, low (G) | Line-by-line questions on the reporting claim | Low: the JD asks for monthly reporting and Excel, and the spreadsheet is your one reporting claim | Know what you can and cannot say about what the spreadsheet showed |

**C. Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold, since none of your quotes carries this story: pick a time you told someone senior something they did not want to hear. It needs a named stake, the moment you said it, what happened, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem, and the role reports on complaints to people who may not like the numbers (F3); VAL because it scores behaviour, not a skill |
| C2 | "Tell me about a time you coached or trained someone through something difficult." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: new tellers, the escalation script, you trained them; tell it in your own words. Answer slot: expect a probe on how you taught it; say how, and if there is nothing more to say than that you trained them on it, say so plainly and stay with the tellers. If another instance fits "difficult" better, use it and tell it in your own words | F4 is your only coaching-adjacent evidence, and the JD asks about coaching supervisors, so expect the distance to be tested; behavioural in delivery, JD in what it scores |
| C3 | "When did you put a member ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time the member's interest and a number or target pulled apart. It needs a named stake, the decision you made, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard customer-first stem that mirrors "Members First, Always"; VAL because it scores a published value |
| C4 | "Tell me about a time an escalation did not go to plan." | EXP | [grounded] | Selection scaffold: pick an escalation, say what happened, what you did, whose part was whose, and what you would change. Do not supply an incident you cannot tell from memory. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's coaching-on-escalations line raises it; EXP because it tests what you actually did |

**D. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns complaints across branches and the contact centre, and I see you haven't worked in a contact centre. Why should I believe you can own that side?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI rehearsal in this pack. Four moves of about 30 seconds each. One: say the limit first, plainly: "I haven't worked in a contact centre." Two: state what you have, at its own scope: "I handled the branch's formal complaints log." Three: give a plan in your own words, naming the first things you would learn about the contact-centre side and who you would learn them from; a plan, never a past. Four: hold through two follow-ups. Likely follow-up one: "That is one side of the process; why you?" Return to the log and the plan, adding nothing. Likely follow-up two: "What if the contact-centre team does not accept a branch person?" Answer with the plan. Concede only what your words say, that you have not worked in one, and never fold on the log. Never say you know how contact centres work | F2 is the most predictable objection to this candidate in this loop, and a rehearsed, non-defensive answer changes the interview; JD because it scores the stated requirement |
| D2 | "What's the most senior audience you've presented to, and how would you prepare to present to ours?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then your preparation, said as a plan: who is in the room, what decision they need from the numbers, what you would rehearse and with whom. If you mention the spreadsheet, keep it at its scope: you built it and your regional manager uses it; do not call it a presentation | F8 is a stated requirement with a gap in your own words; a manager who will present your numbers upward will want to hear the plan; JD because it scores the requirement |
| D3 | "What does owning a complaints process end to end mean to you?" | JD | [grounded] "I handled the branch's formal complaints log" | Give your own definition first; a definition is not a claim about your past. You may anchor it in the published value's own words, attributed: "whoever finds the problem keeps hold of it until it is solved." Then the quote at its scope: "I handled the branch's formal complaints log." Answer slot: if any step of how a complaint moved was yours to set or change, say which and how; if the log was the part you held, or there were no such steps, say so plainly. Do not describe the whole process as yours | F1 is where the JD's headline line meets your evidence; JD because the line is the role's first responsibility |

**E. Case / Strategist, low weight**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Digital is meant to take 40% of member service by 2028. Which kinds of complaint would you keep with a person, and why?" | CASE | [grounded] | No claim about your past is needed. Clarify first, for example what the 40% counts. Then objective, your own segmentation said aloud, approach, the JD's two measures of volumes and resolution times, and risks, including app-only banks as the pressure. Challenge one premise respectfully. Use Ashgrove's words: Plain Words and Members First | The brief's headline target is the likeliest live problem from a manager; the answer must not imply digital experience you have not stated (F5) |
| E2 | "Eight branches become five hubs over 2027. A member's branch is closing and they complain. What do you do, and what do you watch for?" | CASE | [grounded] | No claim about your past is needed. Ask what is already planned before proposing anything. Then objective, approach and risks. Draw on the value "every branch is part of its town" in your own words, and do not claim knowledge of which branches are affected | The hub plan is the brief's most concrete change for branches and ties to the values round |

**G. Data-Driven Prober, low weight**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3: you built it, it is monthly, your regional manager uses it; tell it in your own words. Answer slot: if it showed volumes or resolution times, say which and how each was counted; if it showed neither, or counted something else, say so plainly. If you cite any figure from it, say how it was counted and which assumption behind it you would defend least; if you do not know how it was counted, say so | The reporting claim is the one a prober can test line by line; EXP because it tests what was actually yours |
| G2 | "How would you describe your Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot (F9): say which tool the spreadsheet was built in and what you did in it, in your own words; if there are parts of reporting you have not done in it, say so plainly and stay with what you built. Do not use a level word such as advanced unless you can show it | The JD asks for Excel reporting by name and your words say spreadsheet; JD because it scores the stated requirement |

**Reverse questions, round 2**

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would tell you in twelve months that the complaints process is in better shape?" | It shows you think in outcomes and gives you the measure to aim at |
| R2.2 | "Where does complaints data come from today for the monthly report: branches and the contact centre together, or separately?" | It is the practical reporting question and it answers something you need to know before accepting |
| R2.3 | "With eight branches becoming five hubs over 2027, what changes for who owns a complaint?" | It ties the role to the brief and tests whether ownership is settled |
| R2.4 | "What would you want me to learn first about the contact-centre side?" | It turns F2 from a gap into a plan the manager can shape |

### Round 3: the panel of two branch managers (60 minutes)

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (H) | Scenario probes scored against the four published values | High: the recruiter's email says the panel is the values round and scores against the four values; the cross-functional prior agrees | One story per value where a quote carries one, otherwise the scaffold; "we" for context, "I" for contribution |
| Case / Strategist (I) | A live escalation case | High: 20 of the 60 minutes are a case on a complaint escalation | Clarify, structure, answer; say the framework aloud; challenge one premise |
| Peer Evaluator (K) | Seam-splitting, collaboration, credit | Low to medium: the names are unknown, but the JD's coaching of branch supervisors puts branches in this role's working relationships | Reciprocity framing; propose seam principles, do not pretend to know the seam |

The Conversational persona from the cross-functional prior is covered by A1 and A2, which you will have rehearsed.

**H. Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold: pick a time the member's side and another pressure pulled apart. It needs a named stake, the decision you made, what it cost, and how it ended. Let the story show the value; do not recite it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Raised by the value "Members First, Always"; one question per published value is the panel's likely shape |
| H2 | "Tell me about a time something you wrote or said had to be explained twice." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold. The nearest material is F4's quote, which says you trained tellers on the script and says nothing about its wording. Answer slot: if the wording of the script, or of anything sent to members, was something you changed or flagged, say what; if not, say so plainly and give the nearest thing your material does carry, or how you would handle it | Raised by the value "Plain Words — if a member needs it explained twice, we wrote it wrong" |
| H3 | "Tell me about a time local knowledge of a town or community changed how you handled something." | VAL | [grounded] | Selection scaffold: pick a time knowing the place or the people changed what you did. It needs a named stake, the change, and the result. Expect a follow-up linking it to the move from eight branches to five hubs; answer in your own words and do not claim knowledge of which branches are affected. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Raised by the value "Neighbours, Not Numbers — every branch is part of its town"; branch managers are likely to care most about it |
| H4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | The nearest material is F1's quote, which says you handled the log and does not say a problem was solved. Answer slot: if there was a complaint you kept hold of from first report to resolution, say what it was and what part was yours; if the log was a record you kept and others resolved, or no complaint stayed with you, say so plainly and give the nearest thing your material does carry, or how you would handle it | Raised by the value "Own the Fix"; F1 is the likeliest source and its limit must be said before it is probed |

**I. Case / Strategist: the 20-minute escalation case**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "A member complained at their branch, wrote in, and phoned the contact centre. Each gave a different answer, and it now lands with you. Talk us through your first hour." | CASE | [generic] | No claim about your past is needed. Clarify first: what the member has been told and by whom, what they are asking for, what time limits are running, and what the current escalation route is, asking rather than assuming. Then the objective: one owner and one explanation. Then approach, the JD's two measures of volumes and resolution times, and risks. Say what you would tell the member in words that do not need explaining twice. Do not claim you have handled a case like it | The panel set a complaint-escalation case; this is the pattern for one, so it is a generic rehearsal and not a fact about Ashgrove |
| I2 | "The branch supervisor says the contact centre gave the wrong answer. The contact centre says the branch did. You are coaching both. What do you say?" | CASE | [generic] "trained new tellers on our escalation script" | Separate what happened from whose fault it was before you take any side; coach both toward the member's side; agree one owner; follow up. If asked whether you have done this, hold the quote: "I trained new tellers on our escalation script," and say plainly that is the scope of it | The JD's coaching line (F4) gives the case its second turn; the hold keeps the follow-up question honest |
| I3 | "How would we know in three months that the process is better?" | CASE | [grounded] | Start from the JD's two measures, complaint volumes and resolution times. Ask what resolved means here before choosing. Add one measure that shows the member's side and say why. Say how you would read a fall in volumes: fewer problems, or fewer complaints logged. No claim about your past | The JD names the two measures; asking what resolved means is the move that shows structure |

**K. Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Where is the seam between a branch manager and your role when a complaint has to be escalated, and what happens when we disagree?" | CASE | [generic] | Propose principles, not the seam: one named owner at each point; who tells the member; when a disagreement goes up and to whom. Offer reciprocity, what you would give the branch, for example a clearer answer for the member. Ask how it runs today rather than pretending to know | The panel are branch managers; the JD's coaching of branch supervisors puts the seam in this role |
| K2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams. It needs what each team did, how credit was shared, and what you would do the same way. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer stem; VAL because it scores collaboration behaviour |

**Reverse questions, round 3**

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "When a complaint comes to you at the branch, what do you most want from a central role?" | It puts the branch managers' needs first and gives you the seam they would draw |
| R3.2 | "What could a new person do in their first month that would genuinely help your branch?" | The reciprocity question: it signals you want to contribute, not only receive |
| R3.3 | "How do you expect the hub plans to change what members in your town expect when something goes wrong?" | It ties to "Neighbours, Not Numbers" and the brief without asserting anything about their branch |

## Values cheat sheet

A values-style round is detected: the recruiter's email says the panel scores against the four values.

| Value (official name) | Working meaning (paraphrased) | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decisions start from the member's side, not the organisation's | Scaffold at H1. No quote in F1 to F9 carries a story for it; if none comes to mind, say so plainly and give the nearest thing or how you would handle it |
| Plain Words | If a member needs something explained twice, the wording failed | Scaffold at H2. Nearest material F4: "trained new tellers on our escalation script", which says nothing about wording; the slot at H2 is the way in |
| Neighbours, Not Numbers | Each branch belongs to its local community | Scaffold at H3. No quote in F1 to F9 carries a story for it; if none comes to mind, say so plainly |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | Scaffold at H4. Nearest material F1: "I handled the branch's formal complaints log", which does not by itself show a problem solved; the slot at H4 is the way in |

## Requirement coverage

| Requirement | Row | Questions |
|---|---|---|
| Own the process end to end | F1 | D3, A4, H4 |
| Across branches and the contact centre | F2 | D1, B1 |
| Report monthly on volumes and resolution times | F3 | G1, I3 |
| Coach branch supervisors on escalations | F4 | C2, I2 |
| Work with digital teams on self-service journeys | F5 | A5, E1 |
| 4+ years in financial-services customer operations | F6 | A1 |
| Experience handling regulated complaints | F7 | B2 |
| Confident presenting to senior leaders | F8 | B3, D2 |
| Comfortable with Excel reporting | F9 | G2 |

## Prohibited claims

What this pack will not coach, and why. No dossier was present, so the list was built from the snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Contact-centre experience, or any call or phone handling | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Presenting to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not the process. D3's slot stays inside the log |
| Coached branch supervisors | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script". The material says tellers, not supervisors. C2's slot asks only how you taught it |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: the spreadsheet you built and who uses it. G1's slot asks only what it showed |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: the branch's formal complaints log. B2's slot asks only what made a complaint formal |
| Built reporting in Excel | Inflated form of F9 | F9's quote at its own scope: a spreadsheet you built. G2's slot asks only which tool |

## Sources

Provided documents: the job description, the values wording copied on 11 November 2026 from ashgrovecu.org/about/values, the recruiter's email, the four lines of the July 2026 strategy brief as you reported them (the brief itself was not in hand), and your background as you wrote it in your message. No `tuesday-dossier.md` was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet or H1 to H4: the pasted values wording supplies all four names and meanings |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email gives the three sessions, who runs each and what each holds |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Could not have moved the CO and CASE questions: the July 2026 brief lines you reported supply current priorities and the competitive frame |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what a name would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewers' names, when assigned → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- Your answers to the answer slots on F1, F3, F4, F5, F7 and F9, stated outside a drill → each row becomes story-mapped and `[grounded]` where your words support it, and the banks that draw on them regenerate
- Your CV, and a redacted copy of the monthly complaints spreadsheet → the evidence cells quote your CV, and F3 and F9 can move up from medium and low once the copy is inspectable
- The recruiter's detail on the 20-minute case (live or written, anything shared beforehand) → a build section if a deliverable was announced; usually one email to the recruiter
- The full July 2026 strategy brief → replaces the four reported lines and tightens A3, E1 and E2
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes, offered once → interviewer footprint once names exist, loop reports for similar roles, and recent organisational context
- The hours you have before 20 November → a prep triage schedule sized to them
- A `tuesday-dossier.md` from a job-underwriter pass → verified evidence, a strategy for each weak area, and an underwriter-named objection in place of the one the pack inferred at D1
