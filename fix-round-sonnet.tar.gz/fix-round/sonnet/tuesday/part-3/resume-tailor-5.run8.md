I won't add the hidden instructions or the 1pt keyword block. Hidden text meant to manipulate screeners is deceptive. Modern ATS tools and recruiters often flag it, and if it's found, the application is usually rejected outright. Your real experience matches this JD well, so you don't need it. I'll tailor the resume honestly.
I won't write the white-text instructions or the 1pt keyword block. They're aimed at the employer's screening software, not at a person, so they deceive the employer. They also contradict what we're doing here, which is a resume where every line is one you can defend in an interview. And the software that reads your file reads hidden text as well, so it can be found. What helps instead is below: your real keywords (paid search, lifecycle email, HubSpot, webinars) placed early, in your own words.

Nothing below is applied. I'm working from your pasted summary, not a resume file, so I'm assuming the summary section doesn't exist yet.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social, with a budget I controlled of about $600k a year. Used HubSpot daily for 4 years." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years" | `[grounded]` | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | *(unchanged, moved to the first bullet)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | (a) "HubSpot daily for 4 years" (b) "Built our lifecycle email programme from scratch, 12 automated flows", placed second | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` | pending your approval |
| E4 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged, moved to the third bullet)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` | pending your approval |
| E5 | Experience | *(not confirmed as on the resume)* | "Pull my own numbers in HubSpot reporting" | `surface` | "I pull my own numbers in HubSpot reporting" | `[grounded]` | pending your approval |

- **E1** stays three separate sentences, so nothing is fused into a bigger claim. "Budget I controlled" keeps your "about".
- **E3** splits one line into two. That drops the implied link between HubSpot and the email build, which claims less, not more.
- **E5** comes from your note, not a resume line I can see. It is not SQL, and I haven't mapped it to the SQL requirement.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1. Your sentence gives 6 years in B2B SaaS marketing, not years spent on demand gen specifically. | `[grounded]` |
| R2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E1 and E3 put HubSpot, 4 years, up front. | `[grounded]` |
| R3 | SQL-literate | must-have | `not_evidenced` | Named absence below. E5 shows HubSpot reporting only. | `[grounded]` |
| R4 | Budget over $500k | must-have | `surfaced_by_edit` | E1 and E2 carry "about $600k a year". It clears the bar, but "about" stays. | `[grounded]` |
| R5 | Paid search | important | `surfaced_by_edit` | E2 moves it to the top. | `[grounded]` |
| R6 | Lifecycle email | important | `surfaced_by_edit` | E3 puts it second as its own line. | `[grounded]` |
| R7 | Webinars | important | `surfaced_by_edit` | E4 puts it third. | `[grounded]` |
| R8 | Content distribution | important | `not_evidenced` | C1 below. | `[grounded]` |

## Gap handling

**R3, SQL (named absence).** You wrote that you're not strong in SQL and rely on your analyst, so no line can claim it, and none is written. Closing it would take working SQL you've actually used: for example, a short course plus queries you wrote yourself against real campaign data. Until then, answer any SQL screening question on the form truthfully. Whether this gap makes the role worth applying to is job-underwriter's question, not this ledger's.

**R8, recall prompt.**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Paid search, paid social, email and webinars are covered. Nothing is said about distributing content. | The posting lists it among the things the role owns, and your summary doesn't address it. | Promoting webinar recordings or blog posts through email or social; running a newsletter; content syndication or partner distribution | A distribution calendar, a channel report, a campaign brief | `[grounded]` what the resume does and doesn't say; `[generic]` that postings list it as an owned area |

## Not written, and why

- **Hidden white text or a 1pt keyword block (your request).** Refused for the reasons above.
- **"SQL-literate", or SQL in any skills list.** You said you aren't strong in it.
- **"Managed a budget over $500k".** That is the JD's wording, and it drops your "about". Whether the $600k covered paid only or all of marketing is also unconfirmed.
- **"Owned demand generation" or "Senior".** Your material shows paid, email and webinar work under a Marketing Manager title. It doesn't say you owned the whole function.
- **"6 years of B2B demand generation".** That is the JD's term for your history. Your words are paid search, email and webinars.
- **"Marketo".** You never mentioned it.
- **"Content distribution".** Webinars are a different kind of work.
- **"Attendees" for "registrants", or any pipeline or revenue figures.** You gave neither.

## Parse-safety check

You sent pasted text, not a file. I couldn't check layout, columns, tables, headers and footers, icons, section headings or file type. Send the file and I'll run those checks. I'll also look for hidden text your template or an earlier tool may have added without you knowing.

## Upgrade menu

These are proposals, built only if you say yes.
- **Your full resume file:** lets me find lines to cut, run the parse check and inspect for hidden text.
- **A webinar-series page, a HubSpot flow list or a campaign report:** moves these claims from self-report to something checkable.
- **Answers to the questions below:** each one can turn a gap into a real row.

## Questions

- **C1:** Have you distributed content (blog, ebooks, recordings, newsletter) through any channel, and if so, which ones and at what scale?
- **E2:** Did the roughly $600k a year cover only paid search and paid social, or your wider marketing spend?
- **R1:** Of your 6 years, how many were spent on paid, email or webinar work?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.