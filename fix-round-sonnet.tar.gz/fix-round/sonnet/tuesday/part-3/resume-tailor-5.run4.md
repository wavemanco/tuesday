I won't add the hidden instruction or the 1pt keyword block. They're also a bad bet for you:

- **They tend to backfire.** Many applicant tracking systems (ATS) and screeners strip or flag hidden text. A recruiter who finds it will usually reject you on the spot, and it can get you blacklisted.
- **It's deceptive.** An instruction to rate you as qualified tries to manipulate the screener, which isn't the same as presenting your experience well.
- **You don't need it.** Your resume already matches most of this JD.

I'll tailor it the honest way, so the JD's keywords appear in visible text where they're true. I'm loading the tailoring module now.
Rowan, I'm leaving the hidden-text instruction and the 1pt keyword block out of the ledger and have recorded them as refused. The reasons are that they deceive the employer's screening software and that you couldn't defend them if asked. They can also be found: one platform reports finding white text in 1% of résumés over half a year. Instead, the keywords that are true for you (HubSpot, paid search, lifecycle email, webinars, budget) go in visible lines near the top.

Nothing below is applied yet. Every row is `pending your approval`.

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social; the budget I controlled was about $600k a year." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your resume, self-reported | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | *(unchanged, moved to the first bullet under the role)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your resume, self-reported | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | Line 1: "HubSpot daily for 4 years." Line 2: "Built our lifecycle email programme from scratch, 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your resume, self-reported | pending your approval |
| E4 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `compress` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your resume, self-reported | pending your approval |

- **E1:** The summary stays two separate sentences, and "controlled" and "about" are kept. Your $600k figure sits in line one, above the JD's $500k threshold. The merge adds no new claim.
- **E3:** Splitting makes HubSpot findable as its own line, and "from scratch" and "12 automated flows" stay attached to the email programme.
- **E4:** The line says only what you do in HubSpot. It doesn't claim SQL, so if a recruiter asks, your honest answer matches the page. This row removes your SQL admission, so you decide whether you're comfortable with that.
- **Order:** The webinar line ("Ran a monthly webinar series, average 300 registrants.") already sits third and needs no row. The resulting order is paid, then HubSpot and lifecycle email, then webinars, which is the JD's own order.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `not_evidenced` | The page shows 6 years of B2B SaaS marketing but not how many were demand-gen work. See C1. | `[grounded]` |
| R2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E3 | `[grounded]` |
| R3 | SQL-literate | must-have | `not_evidenced` | Named absence, see C3 | `[grounded]` |
| R4 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E1, E2. Your words are "controlled" and "about $600k a year", so the ledger keeps them. | `[grounded]` |
| R5 | Paid search | important | `already_evidenced` | "Ran paid search and paid social"; E2 only moves it | `[grounded]` |
| R6 | Lifecycle email | important | `already_evidenced` | "built our lifecycle email programme from scratch, 12 automated flows" | `[grounded]` |
| R7 | Webinars | important | `already_evidenced` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` |
| R8 | Content distribution | important | `not_evidenced` | Nothing on the page mentions it. See C2. | `[grounded]` |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years B2B demand gen | must-have | 6 years as Marketing Manager in B2B SaaS, plus paid, email and webinar work. It doesn't say how many of those years that work covered. | The JD sets a 5-year bar, and the page proves 6 years of marketing, not 5 years of demand gen. | Paid search or paid social running from year 1 or 2; lifecycle email starting before the 4 HubSpot years; webinars before the monthly series | Job-history dates, or an old campaign report | `[grounded]` what the resume says and omits; `[generic]` what this costs on a posting with a years bar |
| C2 | Content distribution | important | Nothing. Paid social and webinars are adjacent but aren't described as distributing content. | The JD lists it as one of four owned channels. | Promoting webinar recordings after the live session; newsletter or blog sends; paid promotion of ebooks | A distribution calendar, or a channel report | `[grounded]` what the resume says; `[generic]` what this costs on a posting that names the channel |
| C3 | SQL-literate | must-have | You pull numbers in HubSpot reporting and ask your analyst for SQL. | The JD lists it as a requirement, and no honest line here can meet it. | None found | A query you wrote yourself, even a simple one | `[grounded]` what the resume says; `[generic]` what this costs on a posting that lists it |

**C3 is a named absence.** You aren't SQL-literate yet, and no wording fixes that. Closing it means a few weeks of a basic SQL course plus real queries on your own HubSpot or warehouse exports. Until then, treat it as a real risk on this role, and don't tick "SQL" on any application form. Whether Cloudpath is still worth applying to with that gap is job-underwriter's question.

## Not written, and why

- **"SQL-literate", "data-driven" or "analytics" claims:** you ask your analyst, and "HubSpot reporting" is different work from SQL.
- **"Demand generation" or "demand gen" as a label for your history:** that's the JD's word, and you haven't told me which years it covers (C1).
- **"Managed a $600k budget":** you wrote "controlled", and "managed" is the JD's verb.
- **"Senior" in your title:** you hold "Marketing Manager", and the JD's word isn't yours.
- **"Content distribution":** nothing you wrote supports it.
- **Hidden white text, near-zero-font keyword blocks, instructions to an AI screener:** refused. They aim deception at the employer's software, and if found they can cost you the application.

## Parse-safety check

You pasted plain text, so I couldn't run the checks that need the file: multi-column layout, tables or text boxes, images or skill bars, contact details in headers or footers, non-standard headings, and file type. I also couldn't check for hidden text that a template or earlier tool might have left in your file.

## Upgrade menu

- **Your resume as a .docx or text-layer PDF:** lets me run the full parse check and flag any hidden text you didn't write.
- **Dates for each role and any earlier resume version:** may settle C1 and could surface dropped evidence.
- **A budget sheet or ad-platform spend export:** would let me confirm whether the $600k covers paid search and paid social or something wider.
- **A HubSpot dashboard or lifecycle report, and a webinar deck or registration export:** gives the 12 flows and the 300 average registrants something inspectable behind them.

## Questions

C1 — Of your 6 years in B2B SaaS marketing, how many were spent running paid, email or webinar programmes, and was that one role throughout?
C2 — Have you ever distributed content, for example by promoting webinar recordings, sending newsletters or pushing ebooks through paid social? If so, what and when?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.