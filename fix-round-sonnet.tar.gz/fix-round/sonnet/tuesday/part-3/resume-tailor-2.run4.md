Now the files this playbook names for building the ledger.
Dev, here is your ledger. Nothing is applied yet. I treated your message as the resume, so the "Current line" cells quote your sentences exactly. I can't see your bullet order or section layout. Rows E2 and E3 assume those two lines aren't already at the top, so correct me if they are.

Four of the eight requirements below are `not_evidenced`: R1, R2, R3 and R8. Whether to apply with the 3+ years must-have unmet is a decision for job-underwriter, not this pass.

## Edit ledger — `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(wording unchanged — moved to the first bullet)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E3 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(wording unchanged — moved to the second bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | Line 1: "Fixed our nightly dbt job when it breaks." Line 2: "Added tests to our nightly dbt job." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | Line 1: "Python for analysis — pandas." Line 2: "Some scripting to pull vendor APIs on a cron." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |

- **E1** keeps "with our then-DE" and stays three separate sentences. Joined into one, it would read as sole ownership of the model.
- **E4 and E5** only separate what each sentence already says. "Some" stays in E5. I didn't write "production", because you said "for analysis".

To approve, reply with row numbers, e.g. `Approved: E1, E2, E4`.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | No row. Your title is Senior Data Analyst and nothing you gave me is a data engineering role. See Not written, and C3. | `[grounded]` the resume does not show a data engineering role; `[inferred]` from the JD's "must-have", it is likely read against titles |
| R2 | Production Python | important | `not_evidenced` | E5 puts the cron scripting on its own line without claiming "production". C1 asks. | `[grounded]` your Python is described as "for analysis" plus "some scripting"; `[generic]` what "production" usually implies in a posting like this one |
| R3 | Airflow or equivalent orchestration | important | `not_evidenced` | E4 surfaces the nightly dbt job you fix. It doesn't say what schedules it, so I can't call it orchestration. C2 asks. | `[grounded]` you said you've never used Airflow |
| R4 | Dimensional modelling | important | `surfaced_by_edit` | E1 and E2, with "with our then-DE" kept. | `[grounded]` your message |
| R5 | Own data quality and SLAs | important | `surfaced_by_edit` | E4, line 2, covers the tests only. Nothing you gave me mentions SLAs, so that half stays open. | `[grounded]` your message |
| R6 | Build and own batch pipelines | important | `surfaced_by_edit` | Partial. E3 and E4 cover the dbt models and the nightly job, which is the transformation layer. Ingestion and scheduling are R2 and R3. The posting's word "pipelines" is not applied to your work. | `[grounded]` your message |
| R7 | Partner with analytics on requirements | important | `already_evidenced` | You sit on the analytics side, so no line is needed or written. | `[grounded]` your title and the orders mart work |
| R8 | Streaming experience; Spark and Kafka named in the duties | preferred | `not_evidenced` | Named absence below. | `[grounded]` you said you've never used Spark or Kafka |

I took "important" for the unmarked requirements, since the JD labels only the 3+ years as must-have. Say so if you read the posting differently.

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | important | Python "for analysis" and "some scripting to pull vendor APIs on a cron". It doesn't say whether those scripts feed anything others rely on. | The cron scripts are your nearest evidence for this requirement, and what they feed decides whether they can be described as more than analysis scripting. | A vendor pull that feeds a dbt source or the orders mart; one that alerts or retries on failure; one that other people's dashboards depend on | The script repo, a cron or job config, a failure alert | `[grounded]` what the resume says and doesn't; `[generic]` what this costs on data engineering applications |
| C2 | Airflow or equivalent orchestration | important | A nightly dbt job that you fix and added tests to. What schedules it isn't stated. | Without the scheduler named, the closest evidence stays a fix-it story rather than orchestration. | Setting or changing the job's schedule; ordering the job after the vendor pulls; owning run notifications | A dbt Cloud job config, a cron entry, or run history | `[grounded]` what the resume says and doesn't; `[generic]` what this costs on applications of this kind |

**Named absence, R1 (3+ years data engineering).** You haven't held a data engineering role, and wording can't change that. It closes only through evidence of data-engineering-shaped work inside the five years. C1, C2 and C3 are where that evidence would come from. If none exists, the honest status is a stretch application on this must-have.

**Named absence, R8 (streaming, Spark, Kafka).** You have no exposure to any of them, and streaming is only a plus. A small public project, such as a Kafka topic feeding a table with tests, would close part of the gap in a few weeks. It isn't worth closing for this role alone.

## Not written, and why

- "Data Engineer", "Analytics Engineer" or any new title: your title is Senior Data Analyst.
- "3+ years of data engineering experience": nothing in your message supports it.
- "Built production pipelines" or "production Python": you said Python is "for analysis" plus "some scripting".
- "Orchestrated pipelines" or any Airflow-equivalent wording: what schedules the nightly job isn't stated, and fixing a job isn't orchestrating it.
- "Owned data quality and SLAs": you added tests, and no SLAs appear in your message.
- "Led warehouse design" or "owned the star schema": you designed it with the then-DE.
- Anything on Spark, Kafka or streaming: you said you've never used them.

## Parse-safety check

Your resume arrived as pasted text, so I couldn't run the layout checks: columns, tables or text boxes, images, headers and footers, or file type. I also couldn't check for hidden text a template might have left behind. Send the file and I'll run those.

## Upgrade menu

- **The resume as a file.** This unlocks the layout and hidden-text checks above.
- **A repo or sanitized sample of the vendor API scripts, or the dbt project.** This is the inspectable proof for data engineering, and it would raise R2 and R6 from your own word to something checkable.
- **The dbt job's config or run history.** This settles whether R3 is real or a gap.
- **Prior resume versions.** An older version may hold pipeline or ingestion work that the current one dropped.
- **A gap-closing project plan (an extra I'm offering, not part of the ledger).** It would be a small Airflow-plus-Kafka build scoped to your stack. This engagement earns it because R3 and R8 can't be closed by wording. I'll build it only if you approve.

Questions, each answerable in text, a pasted voice transcript, an attached document, a link, or `skip`:

**C1 —** For the vendor API scripts on a cron, what runs them, what depends on their output, and what happens when one fails?

**C2 —** What triggers the nightly dbt job (dbt Cloud, cron, Airflow, something else), and did you set or change its schedule or dependencies, or only fix it when it broke?

**C3 —** Did any part of the five years carry formal pipeline responsibilities, such as a job description line, on-call duty, or ownership of a load? If so, which?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.