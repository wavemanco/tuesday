I'm tailoring your resume to the Bellhaven JD as an approve-first edit ledger. Nothing is applied until you approve specific rows.

I have your resume as summary prose, not its actual bullets. "Current line" and "Traces to" quote your message word for word, and I assumed these lines sit in Experience in roughly the order you gave them. If the real bullets read differently, tell me and I'll rebase the rows. Whether this role is worth applying to, given its 3+ years must-have, is a separate question from tailoring.

## Coverage map

I treated the JD's "Requirements" items as must-have, its responsibilities as important, and streaming as preferred. Spark appears only in the tools list, so I rated it as no requirement.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 3+ years data engineering | must-have | not_evidenced | Your title is Senior Data Analyst, 5 years. The adjacent work is in E1 to E3 and is not DE-titled years. See Named absences. | `[grounded]` what your message says; `[generic]` what this costs on applications of this kind |
| M2 | Production Python | must-have | not_evidenced | E4 shows pandas analysis and API-pull scripts on a cron. "Production" is not stated. See C1. | `[grounded]` |
| M3 | Airflow or equivalent orchestration | must-have | not_evidenced | The nightly dbt job (E3) and cron scripts (E4) are adjacent. You said you've never used Airflow. See C2. | `[grounded]` |
| M4 | Dimensional modelling (warehouse modelling) | must-have | surfaced_by_edit | E2, E6. The "with our then-DE" qualifier stays. | `[grounded]` |
| M5 | Build and own batch pipelines | important | surfaced_by_edit | E1, E3. This covers the dbt transformation layer and fixing the nightly job. Ingestion and ownership are not stated. | `[grounded]` |
| M6 | Data quality | important | surfaced_by_edit | E3, from "added tests". Ownership is not stated. | `[grounded]` |
| M7 | SLAs | important | not_evidenced | Nothing in your material mentions them. See C3. | `[grounded]` |
| M8 | Partner with analytics on requirements | important | not_evidenced | You stood on the analytics side, and E2 is the nearest evidence. See Named absences. | `[grounded]` |
| M9 | Streaming experience | preferred | not_evidenced | You said you've never touched Kafka. See Named absences. | `[grounded]` |

## The edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the top of Experience)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved directly under E1)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks; added tests to it" | `compress` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | Line 1: "Python for analysis (pandas)". Line 2: "Some scripting to pull vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E5 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved below E1 to E4)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your message | pending your approval |
| E6 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |

- **E3 and E4:** they keep your qualifiers ("our", "some", "on a cron") and add no "production", "pipeline" or "orchestration".
- **E6:** it stays three separate sentences. Joined into one, the schema design would read as solo work, and your sentence says it was with the then-DE.

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Pandas analysis and some vendor-API scripts on a cron. It does not say whether anyone else depended on them or what happened when they failed. | A "production Python" requirement is usually read as code others rely on, not code you run for your own analysis. | The vendor-API pulls feeding a table or dashboard others used; retries, logging or alerts you added; the scripts living in a repo with review | The repo, the cron entry, a failure alert, a runbook | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Airflow or equivalent orchestration | must-have | A nightly dbt job you fix and a cron. It does not say what schedules or sequences them. | A named orchestrator is the most literal screen for this line, and an equivalent has to show scheduling plus dependencies. | What triggers the nightly dbt run (dbt Cloud schedule, cron, CI runner); whether the vendor pull must finish before dbt starts; who is alerted on failure | Scheduler config, a job-run history, the on-call or alert channel | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | SLAs and data-quality ownership | important | Tests added to the nightly job. It does not say who set the standard or what a failed test triggered. | The JD asks the hire to own both, and tests alone do not show who owned them. | A time by which the orders mart had to be fresh; tests that block or alert; a stakeholder who relied on the mart; an incident you traced | A freshness test, a dbt test config, an incident write-up | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

## Named absences

- **M1, 3+ years of data engineering:** `[grounded]` you have 5 years as an analyst and no DE-titled role. No wording changes that, and E1 to E3 are adjacent work, not DE years. To close it, either C1 to C3 turn up pipeline ownership you haven't listed, or you get a DE-scoped stretch in your current role. If neither happens, this requirement stays open.
- **M9, streaming:** `[grounded]` you've never touched Kafka, and the JD lists it as a plus. Spark is in the same position. The resume says nothing on either, and I won't add them to a skills list. A small Kafka consumer project is the cheapest way to close it, and it is only worth doing if you want this path.
- **M8, partnering with analytics:** `[grounded]` you were the analytics side of that partnership. E2 shows you working a schema through with a DE, and nothing more is written. What you needed from a DE is yours to say in an interview.

## Not written, and why

- **"Data Engineer" title or "3+ years data engineering":** your title is Senior Data Analyst, and an equivalent retitle would be an upgrade.
- **"Production Python" or "built production pipelines":** you described analysis and cron scripts. This is a drift in kind and scope.
- **"Orchestrated" or "orchestration experience":** you've never used Airflow. A cron is not shown to be an equivalent.
- **"Owned data quality and SLAs":** your sentence says you added tests.
- **"Partnered with analytics" in a DE voice:** you stood on the other side of that table. This is a relationship inversion.
- **Kafka, Spark or streaming, including in a skills list:** you've never used them.
- **"Designed the star schema" without "with our then-DE":** dropping the qualifier would be a scope and ownership drift.
- **"25+ models":** your words are "about 25".

## Parse-safety check

The resume arrived as pasted prose, so I could not run any of these checks:
- multi-column layout
- tables and text boxes
- images and icons
- content in headers or footers
- section headings
- file type

If you send the file, I'll run them. A `.docx` or a text-layer PDF is the safe pair.

## Upgrade menu

- **Your actual resume file:** I'd quote your real bullets, rebase the rows, and run the parse-safety check.
- **Artifacts for C1 to C3:** a repo link, scheduler config, a dbt test config or an alert history would move those rows from guesses to `[grounded]` lines.
- **An earlier resume version:** it may hold DE-adjacent work the current one dropped.

## Questions

C1. Did anyone besides you depend on your vendor-API scripts, and did you add retries, alerts or logging to them?
C2. What actually triggers your nightly dbt run, and does anything have to finish before it starts?
C3. Is there a time the orders mart has to be ready by, and what happens when a test fails?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.