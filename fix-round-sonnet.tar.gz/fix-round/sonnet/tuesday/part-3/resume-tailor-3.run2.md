I've tailored your CV to the Quartzline posting as an approve-first edit ledger. Nothing has been applied to the CV yet.

I worked from your summary of the CV, so every quote below is your sentence as you gave it to me. I don't have your real bullets or layout. Where your actual wording differs, paste the CV and I'll re-trace the rows.

From the Tuesday dossier I used the role profile, the R1 and R2 evidence-map judgments (both `adjacent`, `medium`), the pending edit E1, and both rejected inferences. The dossier is only an excerpt, and I found no mismatch with this JD.

## Edit ledger

Edit ledger (resume_edits_pending_approval):

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses" (as you described it; I can't see where it sits in your CV) | "Wrote the internal integration playbook the whole team uses", as its own bullet | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV, and the dossier's pending edit E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end" | *(unchanged, moved to the first bullet under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product" | *(unchanged, moved directly after E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Skills / top of CV | "Comfortable in Postman, SQL, OpenAPI specs" | "Comfortable in Postman, SQL, OpenAPI specs", moved to a visible line near the top | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |

Notes on the rows:
- **E1:** I audited this inherited row against your sentence and it still traces. The dossier carries the evidence at `medium`, so expect a probe on how widely the playbook is actually used.
- **E2:** "30+" stays attached to client integrations. It does not become 30+ API products shipped.
- **E3:** The wording keeps "collecting client feedback for product". It never says you owned or set the roadmap.
- **E4:** The verb stays "Comfortable in". It does not become "proficient" or "authored".

## Coverage map

The JD tiers only the PM requirement as a must-have. I've treated the other requirements and the four responsibilities as `important`.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ yrs PM | must-have | `not_evidenced` | Seven years of adjacent work appear in E2 and E3, but you've held no PM title. The dossier's judgment carries over: `adjacent`, `transferability`, `medium`. Roadmap ownership and prioritisation authority aren't evidenced. See C1. | `[grounded]` your CV and the dossier |
| R2 | Shipped API or platform products | important | `not_evidenced` | E2 shows you led client integrations of your vendor's APIs, which is adjacent to shipping them. The dossier has this as `adjacent`, `medium`. See C2. | `[grounded]` your CV and the dossier |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4, supported by E2 | `[grounded]` your CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E3, partial: a client-to-product feedback loop. Nothing in your material covers engineering squads or executives. | `[grounded]` your CV |
| R5 | Discovery with integration partners | important | `surfaced_by_edit` | E3, partial: your sessions collected feedback from clients. Your sentence doesn't say "discovery" or "partners". | `[grounded]` your CV |
| R6 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | "Comfortable in OpenAPI specs" is familiarity, not authorship or delivery. See C3. | `[grounded]` your CV |
| R7 | Define adoption metrics | important | `not_evidenced` | Nothing in your material covers it. See the named absence below. | `[grounded]` your CV |

## Recovery per gap

| # | Requirement | Priority | What your CV currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ yrs PM, specifically roadmap ownership and prioritisation authority | must-have | You ran the roadmap-input sessions and fed product, but nothing says who decided what got built. | It's the must-have, and the dossier already marks it unproven. | Deciding which client-requested API changes went to product and which were declined; setting the order of an integration backlog; being the named owner on a roadmap item | A roadmap doc or a prioritised request list with your name on it | `[grounded]` what your CV does and doesn't say; `[generic]` what this gap costs on applications of this kind |
| C2 | Shipped API or platform products | important | You led client integrations of existing APIs, which doesn't establish that you shipped one. | The JD names it as a requirement, and the dossier marks it adjacent. | A new endpoint, API version, sandbox, or integration template that went live to clients, where you scoped it or set its timing | A release note, a changelog entry, or a client-facing doc for it | `[grounded]` what your CV does and doesn't say; `[generic]` what this gap costs on applications of this kind |
| C3 | Write specs and drive delivery with engineering squads | important | OpenAPI familiarity is listed, but nothing says you wrote requirements an engineering team built from. | It's half of the role's day-to-day. | Requirements or an OpenAPI spec you wrote that engineers built to; a delivery you tracked with an engineering team | The spec or ticket itself, with sensitive details redacted | `[grounded]` what your CV does and doesn't say; `[generic]` what this gap costs on applications of this kind |

**Named absence, R7 (define adoption metrics):** Your material contains no adoption metrics work. To close it, use client go-live and usage data from your own integrations to write a short, honest adoption-metrics sketch. That would be a work sample, not a resume claim. If you never had access to that data, the gap stays open for this role. A candidate with no PM title is more likely to be probed on it.

## Not written, and why

- "Product manager" experience or "3+ years in product management": you've never held the title, and it's the posting's must-have. The adjacent work is in E2 and E3, and the gap is named in R1.
- "Owned the roadmap" or "prioritised the roadmap": your sentence says you collected client feedback for product. Ownership isn't evidenced, and the dossier says the same.
- "Shipped API products": you led client integrations of your vendor's APIs, which is a different kind of work.
- "Ran discovery with integration partners": that's the JD's vocabulary, not your history. Your sentence says client feedback sessions, and "partners" would change which side of the table you sat on.
- "Wrote API specs" or "drove delivery with engineering": "Comfortable in OpenAPI specs" doesn't say you authored them or delivered anything.
- "Defined adoption metrics": nothing in your material supports it.
- "Built an internal request-triage tool": a memory lead you couldn't confirm ownership of. It stays out, unaltered from the dossier.
- "Has been the customer of a partner API platform": you worked vendor-side, as the dossier already corrected.

## Parse-safety check

Your CV arrived as a description, so I couldn't run any of the layout checks: multi-column layout, tables or text boxes, images or icons, headers and footers, section headings, or file type. If you attach the actual file, I'll run them.

## Upgrade menu

- **CV text or file:** it replaces my paraphrase and lets me run the parse checks.
- **The integration playbook:** an inspectable artifact like this could move E1 from `medium` toward `high`.
- **A roadmap-session output** (notes, a summary sent to product, or a resulting change): this would help R1 and R5.
- **Optional extra, offered only:** a short summary line built solely from your existing sentences. It adds a top-of-page read for this role, and I'll draft it only if you want it.

## Questions

C1 — Did you decide which client-requested API changes went to product, which got declined, or in what order, or did product make those calls?
C2 — Did anything you scoped or specified go live to clients, such as an endpoint, a version, a sandbox, or an integration template? If so, what was your part?
C3 — Did you write requirements or an OpenAPI spec that an engineering team then built to?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.