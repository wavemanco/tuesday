Nadia, I've built the edit ledger for the Quartzline role below. I haven't seen your CV file, only your description of it. The quoted lines come from your message, so check each one against the real file before approving.

I used your dossier excerpt as given: the E1 edit, the rejected inferences, and R1/R2 as `adjacent` with `medium` confidence. Tailoring doesn't raise any of that. It's a 7-year solutions engineer CV with no PM title. The edits below reorder and surface what you wrote, and nothing makes you look more like a PM than you are.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (as one item inside a longer line; I haven't seen your layout) | "Wrote the internal integration playbook the whole team uses." as its own line | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV, plus dossier E1, re-audited | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved directly after E2 and E1)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved from the skills area to a line directly under the summary)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |
| E5 | Summary | *(no current line)* | "Seven years as a solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Wrote the internal integration playbook the whole team uses." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor"; "Led 30+ client integrations of our REST APIs end to end."; "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV | pending your approval |

- **E5 is a draft summary and is pending your approval as its own block.** It keeps three separate sentences, because joining them would blur who did what. Your title stays as written, and "enterprise software vendor" stays in because it states which side of the table you were on.
- **E3 and E4 keep your qualifiers.** "Collecting client feedback" doesn't become "owning the roadmap". "Comfortable in" doesn't become "authored".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM | must-have | `not_evidenced` | No PM role or PM-scoped line exists. Your adjacent work is in E1, E2 and E3. Wording can't close the years, so see the named absence below and C1. | `[grounded]` the CV has no PM title; dossier R1 `adjacent`, `transferability`, `medium` |
| 2 | Shipped API or platform products | important | `not_evidenced` | E2 puts your integration work first, but integrating the vendor's REST APIs is not shipping them. Dossier R2 is `adjacent`. See C2. | `[grounded]` the CV says integrations were led, not releases; dossier R2 |
| 3 | Technical fluency | important | `surfaced_by_edit` | E4 and E2 | `[grounded]` your CV |
| 4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3 carry the evidence (client-facing delivery, feedback sessions). The phrase itself isn't used for you. | `[grounded]` your CV |
| 5 | Run discovery with integration partners | important | `surfaced_by_edit` | E3. Your sessions were with your vendor's clients, not integration partners, and I haven't relabelled them. | `[grounded]` your CV |
| 6 | Own the roadmap | important | `not_evidenced` | You collected input "for product". Who decided what happened to it isn't evidenced. See C1. | `[grounded]` what the CV does and doesn't say; dossier R1 reasoning |
| 7 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | "Comfortable in … OpenAPI specs" doesn't establish authoring specs or driving delivery. See C3. | `[grounded]` your CV |
| 8 | Define adoption metrics | important | `not_evidenced` | Nothing on your CV touches metrics. See C3. | `[grounded]` your CV |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Own the roadmap; 3+ years PM | must-have | Client input was collected "for product". It doesn't say whether you had a say in what got prioritised. | The dossier names roadmap ownership and prioritisation authority as the unevidenced part of R1. | A ranked client-request list you handed product; a feature that shipped partly because of your sessions; a trade-off you argued for | A session summary or readout doc, a ticket or request you wrote, a release note naming the change | `[grounded]` what the CV does and doesn't say; `[generic]` what this costs on applications of this kind |
| C2 | Shipped API or platform products | important | 30+ integrations of existing REST APIs. No release, launch or API change is mentioned. | Dossier R2 is `adjacent` for the same reason. | Requirements you gave product for an API change; beta-testing a new endpoint with clients; migration or release notes you wrote | A release note, a migration guide, a beta feedback summary | `[grounded]` what the CV does and doesn't say; `[generic]` what this costs on applications of this kind |
| C3 | Specs and delivery; adoption metrics | important | Tool familiarity only. No authored spec and no metric appears. | Two of the JD's four main duties are writing specs and defining adoption metrics. | An OpenAPI spec you wrote or edited; tracking time-to-live, number of live integrations or call volume per client | The spec file, an integration-tracking sheet or dashboard | `[grounded]` what the CV does and doesn't say; `[generic]` what this costs on applications of this kind |

**Named absence, 3+ years PM.** You have never held the title, and the JD makes the years a must-have. Wording can't close that. What can narrow it is evidence of roadmap and prioritisation work (C1). If C1 comes back empty, the honest position is to apply as an adjacent candidate and say so, or aim at a role that doesn't ask for titled PM years.

## Not written, and why

- "Product management experience" or any PM-titled phrasing: you've never held the title, and the JD makes the years a must-have.
- "Owned the roadmap": you ran input sessions. Collecting input and deciding what gets built are different jobs.
- "Shipped API products": you led integrations of your vendor's APIs, which is a different activity.
- "Ran discovery with integration partners": your sessions were with clients, and the word change would move which side of the table you sat on.
- "Wrote and managed API specs" or "drove delivery with engineering": "comfortable in OpenAPI specs" doesn't say you authored any.
- "Defined adoption metrics": nothing in your CV supports it.
- "Built an internal request-triage tool": this is a rejected inference from your dossier. It was a memory lead and you couldn't confirm ownership.
- "Experience as a customer of a partner API platform": this is also a rejected inference. You worked vendor-side.

## Parse-safety

I couldn't run any parse-safety checks (columns, tables, text boxes, headers and footers, headings, file type) because your CV arrived as prose. Send the file and I'll run them.

## Upgrade menu

- **Your CV as a file**, or pasted exactly as written. This lets me quote verbatim and run the parse-safety checks.
- **The integration playbook itself** (or an excerpt). An inspectable artifact would move the E1 evidence from `medium` toward `high`.
- **A roadmap-session readout, a release or migration note, or an OpenAPI spec you wrote.** Each is the specific artifact that would back C1, C2 and C3.

## Questions

C1 — After a roadmap-input session, did you have any say in what product prioritised (a ranked list, a request you wrote, a feature that shipped partly because of it), or was it hand-off only?
C2 — Did you contribute to any API change that product released, for example requirements, beta testing with clients, or release or migration notes?
C3 — Have you written or edited an OpenAPI spec, or tracked integration numbers such as time to go live or how many clients are live?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.