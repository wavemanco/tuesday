Tailored ledger for the Tessellate role, Priya. It only proposes changes. Nothing is applied until you approve specific rows.

I only have the text you pasted, not the CV file. Every "Current line" and "Traces to" cell quotes your message word for word. If your CV has other bullets, I haven't seen them, and I may have cut candidates once I do.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E1 puts the 7 years next to Go/Rust. Your CV doesn't say all 7 years were backend, so I haven't written "backend" anywhere. | `[grounded]` the "7 years" and ledger-service lines; the backend split is unconfirmed |
| R2 | Production Go | must-have | `surfaced_by_edit` | E1 states Go daily for 4 years. Your text doesn't say which language the three ledger services are in (question E1 below). | `[grounded]` the Go line; `[inferred]` that the services are Go |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | Kafka appears only in a tools list, and "40k requests/minute" is throughput, not a distributed-systems claim. See C1. | `[grounded]` what the CV says and omits |
| R4 | Strong incident response | must-have | `surfaced_by_edit` | E4 | `[grounded]` |
| R5 | Experience mentoring | must-have | `surfaced_by_edit` | E5. Your evidence is onboarding new hires, and their seniority isn't stated. The JD says "mid-level engineers". | `[grounded]` |
| R6 | Own high-volume Go services and drive down p99 | important | `surfaced_by_edit` | E2 and E3 | `[grounded]` |
| R7 | Own on-call for your services | important | `surfaced_by_edit` | E4 | `[grounded]` |
| R8 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in the CV touches product partnership. See C2. | `[grounded]` |

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary / headline | "Senior Software Engineer, 7 years." and "Go and Rust daily for 4 years, Python before that." as separate lines | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the first bullet under your current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` | pending your approval |
| E3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with each for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` | pending your approval |
| E6 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | *(unchanged, moved directly under the Go/Rust line)* | `reorder` | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` | pending your approval |

Choices behind the rows:
- **E2 and E6:** the JD's headline items (p99 and Go) come first, and the tools sit next to Go. Position is the only change.
- **E3:** "about 40k requests/minute" stays attached to the one service it describes. I did not write "high-volume services" for all three.
- **E4:** "ran" stays "ran". I did not write "led" or "owned the incident process".
- **E5:** I kept "usually" and "new hires". I did not use the JD's "mentor mid-level engineers", because you haven't said what level they were.

## Gaps

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | Kafka in a tools list and a 40k requests/minute service. It doesn't say what distributed-systems problems you worked on. | It's a named must-have, and nothing on the page currently supports it. | Keeping ledger writes consistent across services; handling duplicate or out-of-order Kafka messages; partitioning or sharding a hot dataset; the cache-layer rework if it involved multiple nodes or invalidation | A design doc, a postmortem, an architecture diagram | `[grounded]` what the resume says and omits; `[generic]` what a must-have gap costs on applications of this kind |
| C2 | Partner with product on roadmap sequencing | important | Nothing about working with product. | The role asks for it directly, and the page is silent. | Negotiating the order of ledger work with a PM; deciding what shipped first, and why; pushing back on a deadline with technical tradeoffs | A planning doc, a roadmap thread, a launch note | `[grounded]` what the resume says and omits; `[generic]` what this costs on applications of this kind |

## Not written, and why

- **"Distributed systems experience"** and **"event-driven architecture"**: Kafka in a tools list is a tool you list, not a system you designed or owned. This stays out until C1 is answered.
- **"Production Go services"**: you wrote "Go and Rust daily for 4 years" and "three services", but never said the services are Go. Held until the E1 question is answered.
- **"7 years backend"**: your text says 7 years as a Senior Software Engineer, with Python before the Go and Rust years. Whether all of it was backend is unconfirmed.
- **"Mentored mid-level engineers"** (the JD's phrase): you onboarded new hires, and their level isn't stated.
- **"Designed" or "architected" the cache layer**: your word is "reworking".
- **"Reduced p99 across the platform"** or **"for high-volume services"**: the 380ms to 95ms result is for the balance-read path only.
- **"Led incident response"**, **"reduced MTTR"**, or **"built the on-call process"**: you ran six incidents as incident commander. Nothing was said about process or time-to-resolve.
- **"Partnered with product"** and **any developer-tools or build-cache experience**: nothing in your text supports either.

## Parse-safety check

You pasted text rather than a file, so I could not check layout, columns, tables, text boxes, headers or footers, icons or skill bars, or file type. I also could not check for hidden text from a template. If you attach the CV file, I'll run those checks.

## Upgrade menu

- **Attach the CV as a file.** This runs the parse checks above and lets me find cut candidates.
- **A dashboard screenshot or postmortem for the p99 work, or an incident write-up.** Either would move E2 and E4 from self-report to something inspectable.
- **Offer, not included above:** a drafted two-line summary built only from E1 to E5. Say yes if you want it. It would go through the same audit and its own approval.

## Questions

E1 — Are the three ledger services you own written in Go, Rust, or a mix?
C1 — In the ledger pipeline, what's one concrete distributed-systems problem you handled, such as consistency across services, duplicate or out-of-order Kafka messages, or partitioning, and what did you do?
C2 — Have you ever helped decide the order or scope of work with a product manager, for example what shipped first on a ledger change? If so, what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.