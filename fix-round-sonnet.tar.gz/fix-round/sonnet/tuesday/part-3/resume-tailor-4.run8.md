You're partly right: keywords matter, but a keyword filter probably isn't what's rejecting you. The evidence on ATS behaviour is thin and comes mostly from one small sample.

- **Auto-rejection:** a vendor interviewed 25 US recruiters and reports "AI/content auto-rejection configured: 8% of recruiters" (cite C25). That is 2 recruiters, in a sample the vendor says is themes rather than representative statistics.
- **What rejects without a person:** "When automated filters are used, they’re almost always knockout questions" (cite C26). These are yes/no checks on the application form, such as work authorization, licence and location. Nothing on the resume changes them.
- **Match scores:** "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27) In that sample, "56% either ignore the feature or don’t have it available." (cite C27)

So I've optimised for being findable and readable, and I haven't written any keyword you can't defend. Most of the JD's keywords are tools your resume doesn't show you using, so I've listed them as gaps instead of writing around them.

Whether this role is realistic given those gaps is a decision question, and job-underwriter covers it.

**Assumptions.**
- I worked from your summary, not the PDF. The quotes below come from your message.
- The JD doesn't separate required from preferred. I ranked priority by how central each item is to "own platform reliability and developer experience". That is my reading, not Ridgemount's.

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to first bullet)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your resume | pending your approval |
| E2 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "AWS (EC2, S3, RDS, IAM), Docker, Kubernetes (two-month proof-of-concept, never went to production), Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production."; "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged, moved to second bullet)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume | pending your approval |

E2 puts "Kubernetes" where a parser and a recruiter will find it. The qualifier stays on the same line, because a tool listed is not a tool owned.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Own platform reliability, SRE practices | must-have | `not_evidenced` | Nothing on your resume describes on-call, incident work, SLOs or reliability ownership. See C1. | `[inferred]` priority, from the JD's "You will own…" sentence; `[grounded]` what the resume says |
| R2 | Developer experience | must-have | `not_evidenced` | You built a deploy pipeline, but nothing says developers used it or how it served them. See C3. | `[inferred]` priority; `[grounded]` what the resume says |
| R3 | Kubernetes | must-have | `surfaced_by_edit` | E2 and E3. Evidence is a two-month proof-of-concept only, so the match is partial and it will read as a proof-of-concept. | `[grounded]` |
| R4 | Terraform | must-have | `not_evidenced` | Ansible is configuration management and does not stand in for Terraform. See C2. | `[inferred]` priority; `[grounded]` what the resume says |
| R5 | AWS | important | `already_evidenced` | "AWS (EC2, S3, RDS, IAM)" is already there. | `[grounded]` |
| R6 | AWS EKS | important | `not_evidenced` | EKS is not shown. Your Kubernetes proof-of-concept doesn't say where it ran. | `[inferred]` priority; `[grounded]` what the resume says |
| R7 | CI/CD | important | `already_evidenced` | The Jenkins deploy pipeline. E1 moves it first. | `[grounded]` |
| R8 | GitLab CI | important | `not_evidenced` | Your pipeline experience is Jenkins. | `[inferred]` priority; `[grounded]` what the resume says |
| R9 | Python | important | `already_evidenced` | "Bash and Python scripting" is already there. | `[grounded]` |
| R10 | Prometheus, Grafana, observability | important | `not_evidenced` | CloudWatch is monitoring and is the only related item on your resume. | `[inferred]` priority; `[grounded]` what the resume says |
| R11 | ArgoCD, GitOps, Helm | important | `not_evidenced` | None of these appear. | `[inferred]` priority; `[grounded]` what the resume says |
| R12 | Istio, service mesh | preferred | `not_evidenced` | Does not appear. | `[inferred]` priority; `[grounded]` what the resume says |
| R13 | Vault | preferred | `not_evidenced` | Does not appear. | `[inferred]` priority; `[grounded]` what the resume says |
| R14 | Go | preferred | `not_evidenced` | Does not appear. | `[inferred]` priority; `[grounded]` what the resume says |

## Recovery per gap

These rows are recall prompts: things you may have done that your resume doesn't show. The questions are in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Own platform reliability, SRE practices (R1) | must-have | CloudWatch for monitoring and Jenkins job upkeep. Nothing about incidents, on-call or reliability targets. | This is the JD's one prose sentence about the job, so a resume silent on it has nothing to match. | Carrying a pager rotation; writing or running postmortems; tuning CloudWatch alarms after an outage; defining uptime or error targets for a service | An alarm config, a postmortem doc, an on-call schedule, an incident ticket | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Terraform (R4) | must-have | Ansible for config management. No infrastructure provisioning tool is named. | Terraform is named first among the JD's tools after Kubernetes. | Terraform in a side project or a one-off migration; reading or reviewing others' Terraform; CloudFormation work | A repo, a module, a PR | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | CI/CD and developer experience (R2, R7) | must-have | A deploy pipeline in Jenkins and about 30 jobs. It doesn't say whether they build and test or only deploy, or who uses them. | The JD pairs "developer experience" with ownership. Developer users and a scope are what would let your pipeline work count toward it. | Build and test stages; number of teams or developers deploying through it; deploy time before and after; onboarding or docs you wrote | A pipeline diagram, a Jenkinsfile, a deploy-time dashboard | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

**Named absences.** The gap and what closing it would take:

| Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|
| ArgoCD, GitOps, Helm (R11) | Nothing on your resume shows any of them. | A small project that deploys a chart to a cluster through Argo CD from a Git repo. You could then name it as a personal project, not as work experience. | `[grounded]` what the resume says; `[generic]` the closing path |
| AWS EKS (R6) | You haven't shown EKS. | Repeating your proof-of-concept on EKS would close it. If the proof-of-concept already ran on EKS, C3-style detail would surface it. | `[grounded]` what the resume says; `[generic]` the closing path |
| Prometheus, Grafana (R10) | CloudWatch is the only monitoring tool you list. | A Prometheus and Grafana stack on your proof-of-concept cluster, with one dashboard and one alert. | `[grounded]` what the resume says; `[generic]` the closing path |
| Istio, Vault, Go (R12, R13, R14) | None appear. All three are listed after the core tools. | Likely not worth closing for this application. They are the least central items and each is months of real use to claim. Go would be the cheapest one to start. | `[inferred]` from the JD's ordering; `[grounded]` what the resume says |
| GitLab CI (R8) | Your pipeline experience is Jenkins. | A small pipeline in GitLab CI on a personal project. | `[grounded]` what the resume says; `[generic]` the closing path |

## Not written, and why

- **"Infrastructure as code" or "Terraform"**: Ansible is configuration management, and calling it infrastructure as code changes the kind of work you did.
- **"Production Kubernetes" or "Kubernetes engineer"**: your own sentence says it never went to production.
- **"GitOps", "ArgoCD", "Helm"**: no sentence of yours supports them.
- **"Observability", "Prometheus", "Grafana"**: CloudWatch is monitoring, and relabelling it in the JD's words would be the JD's vocabulary, not your history.
- **"SRE", "platform reliability", "developer experience"**: nothing you wrote shows you owning either. A pipeline you built is not the same as a platform you owned.
- **"CI/CD (GitLab)"**: your experience is Jenkins. I also haven't relabelled your deploy pipeline as "CI/CD pipelines", because you haven't said whether the jobs build and test. C3 asks.
- **Hidden keyword blocks, white text or keyword stuffing**: refused. This is deception aimed at a machine acting for the employer, and it contradicts a resume you can defend line by line.

## Parse-safety check

I couldn't inspect the PDF, so these are risks from your description, not findings from the file.

| Check | What breaks | What it costs | Provenance |
|---|---|---|---|
| Two-column layout (you described this) | Parsers read linearly and can interleave the columns | Dates and roles can detach, and text can come out scrambled | `[generic]` mechanism; `[grounded]` your description |
| Icons for each skill (you described this) | Icons can render as garbage characters or be skipped | Any skill conveyed only by an icon is absent | `[generic]` mechanism; `[grounded]` your description |
| Contact details in the header (you described this) | Headers can be discarded as page furniture | A recruiter may have no way to contact you | `[generic]` mechanism; `[grounded]` your description |
| Canva PDF file type | Depends on whether the PDF has a text layer | Not checked, since I don't have the file | `[generic]` |
| Section headings | Parsers look for conventional labels | Not checked, since I haven't seen your headings | `[generic]` |

## Upgrade menu

- **Paste the resume text, or the file.** Quotes become exact, and I can run the checks above on what is actually there.
- **Paste what you get from select-all and copy on the PDF.** That is roughly what a parser sees, so I can tell you what survives.
- **Answers to C1 to C3**, or a Jenkinsfile, pipeline diagram or alarm config. These could turn `not_evidenced` rows into real ones.
- **Whether your Kubernetes proof-of-concept ran on EKS or elsewhere.** This decides whether R6 moves at all.

## Questions

C1 — Have you carried on-call, handled incidents, or written postmortems or alerting for services you ran, and what happened in the most recent one you remember?
C2 — Have you written or reviewed any Terraform, or CloudFormation, even in a side project?
C3 — Do your Jenkins jobs build and test as well as deploy, and who or how many developers deploy through the pipeline you built?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.