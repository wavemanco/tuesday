I've read the resume-tailor playbook and its rules. I'm now building the ledger from what you pasted.

**One correction before the work.** I can't tell you keyword matching is why you're being rejected, and the evidence I have points elsewhere. A résumé-builder vendor interviewed 25 US recruiters and calls its sample themes, not representative statistics.
- **Auto-rejection on content:** it found "AI/content auto-rejection configured: 8% of recruiters", which is two people.
- **Knockout questions:** "When automated filters are used, they’re almost always knockout questions". These are yes/no checks on work authorization, license or location, and they sit in the application form, not the resume.
- **Match scores:** "Many teams use match scores/filters to prioritize who gets reviewed first", and "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile". That keywords drive those scores is an inference.

So the useful question is which JD requirements your resume actually evidences, and whether the file parses. The coverage map below shows the first, and I couldn't fully check the second. Adding the JD's words to your resume wouldn't close a gap, and I won't write a line your history can't back. Whether this role is worth applying for is a separate question for job-underwriter.

I only have your pasted text, not the PDF. Section names and the quoted lines come from what you typed, so placement is my guess.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs" | *(unchanged, moved to the first bullet)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs" | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production" | *(unchanged, moved to the second bullet; "never went to production" stays)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production" | `[grounded]` your resume | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" | "Docker, Jenkins, Bash and Python scripting, AWS (EC2, S3, RDS, IAM), Ansible for config management, CloudWatch for monitoring" | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" | `[grounded]` your resume | pending your approval |
| E4 | Skills | *(no Kubernetes entry)* | Add after Docker: "Kubernetes (two-month proof-of-concept, not in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production" | `[grounded]` your resume | pending your approval |

E4 keeps the proof-of-concept qualifier on purpose. A bare "Kubernetes" in a skills list would claim more than you did, and you'd be asked about it in the first interview question.

## Coverage map

The JD doesn't rank its requirements. I ranked them from list position and the duties line, so correct me if a priority is wrong.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | `surfaced_by_edit` | E2 and E4 put the proof-of-concept in view. It is partial: it never reached production, and the lines say so | `[grounded]` your resume |
| R2 | CI/CD pipelines | must-have | `surfaced_by_edit` | E1 leads with the Jenkins deploy pipeline. The wording stays "deploy pipeline", not "CI/CD" | `[grounded]` your resume |
| R3 | GitLab CI | important | `not_evidenced` | A1 | `[grounded]` your resume |
| R4 | Python | important | `already_evidenced` | "Bash and Python scripting" is on the resume. E3 moves it earlier | `[grounded]` your resume |
| R5 | Terraform | must-have | `not_evidenced` | C2. Ansible is config management, not infrastructure provisioning, so it doesn't stand in | `[grounded]` your resume |
| R6 | AWS EKS | must-have | `not_evidenced` | C1. AWS and a Kubernetes proof-of-concept are both listed, but nothing says what the proof-of-concept ran on | `[grounded]` your resume |
| R7 | ArgoCD and GitOps | must-have | `not_evidenced` | A2 | `[grounded]` your resume |
| R8 | Helm | important | `not_evidenced` | C1 asks whether the proof-of-concept used it | `[grounded]` your resume |
| R9 | Prometheus and Grafana | important | `not_evidenced` | C3. CloudWatch is adjacent and stays in the skills line | `[grounded]` your resume |
| R10 | Istio and service mesh | important | `not_evidenced` | A3 | `[grounded]` your resume |
| R11 | Vault | important | `not_evidenced` | A4. IAM is access control, not secrets management | `[grounded]` your resume |
| R12 | SRE practices | important | `not_evidenced` | C3 | `[grounded]` your resume |
| R13 | Go | important | `not_evidenced` | A5 | `[grounded]` your resume |
| R14 | Owning platform reliability and developer experience | must-have | `not_evidenced` | C3. You built and maintain the Jenkins pipeline, but nothing says you owned reliability or developer experience | `[grounded]` your resume |

## Recovery per gap

**Where you may have something to recall (each is asked in the closing questions):**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS and Helm | must-have | A two-month Kubernetes proof-of-concept, with no platform or tooling named | The JD names EKS and Helm explicitly, and the proof-of-concept is your closest evidence for both | A proof-of-concept that ran on EKS; Helm charts you wrote for it; manifests you deployed with | A README, repo, cluster config or demo notes | `[grounded]` what the resume says; `[generic]` what an unnamed platform costs on applications like this |
| C2 | Terraform | must-have | Ansible for config management, which is a different kind of work from provisioning | The JD names Terraform among its core tools | Terraform modules for any AWS resources; a state-file migration; a one-off environment you stood up | A module, a repo, a PR or a pipeline step | `[grounded]` what the resume says; `[generic]` that infrastructure-as-code tooling is a core platform requirement |
| C3 | Prometheus and Grafana, SRE practices, and owning reliability | must-have | CloudWatch for monitoring, with no on-call, alerting or incident work stated | The JD says "You will own platform reliability", and your resume doesn't show reliability ownership | CloudWatch alarms you tuned; being on call; runbooks; incident follow-ups; dashboards others use | A dashboard, a runbook, a post-incident note | `[grounded]` what the resume says; `[generic]` how reliability ownership reads in a platform role |

**Named absences (nothing to pull, with what closing each would take):**

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | GitLab CI | Your pipeline experience is in Jenkins, not GitLab | Use GitLab CI on real work, or build a small pipeline on a GitLab project you can show. Until then it's a stated difference, not a hidden one | `[grounded]` what the resume says; `[generic]` what closing it takes |
| A2 | ArgoCD and GitOps | Nothing on your resume touches either | Deploy a small app through ArgoCD on a test cluster you can show. It would count as a personal project and must be labelled that way | `[grounded]` what the resume says; `[generic]` what closing it takes |
| A3 | Istio and service mesh | Nothing on your resume touches either | Install it on a test cluster and route traffic between two services. It's a lower priority than C1 to C3 and A1 and A2 | `[grounded]` what the resume says; `[generic]` what closing it takes |
| A4 | Vault | Nothing on your resume touches secrets management | Run Vault in a test environment and inject a secret into a workload. A lower-priority closing move | `[grounded]` what the resume says; `[generic]` what closing it takes |
| A5 | Go | Your scripting is Bash and Python only | Write and ship one small tool in Go that you can show. Not worth doing before C1 to C3 | `[grounded]` what the resume says; `[generic]` what closing it takes |

## Not written, and why

- "Terraform", "EKS", "Helm", "ArgoCD", "GitOps", "Prometheus", "Grafana", "Istio", "Vault", "Go" or "GitLab CI" in any skills list. None is evidenced, and listing a tool is claiming you used it.
- "Production Kubernetes experience" or "managed Kubernetes". The proof-of-concept never went to production, so every line mentioning it keeps that qualifier.
- "Infrastructure as code" for Ansible. Configuration management and provisioning are different kinds of work.
- "GitOps", "CI/CD (GitLab)" or "platform engineering" for the Jenkins pipeline. You built a deploy pipeline in Jenkins, and the JD's vocabulary would change what that sentence says.
- "Owned platform reliability" or "SRE". Maintaining about 30 Jenkins jobs and using CloudWatch doesn't say you owned reliability.
- Any line that goes beyond "about 30 Jenkins jobs" or "two months" in scope or duration.

## Parse-safety check

I have your description, not the file. These findings are about how text extraction commonly fails, not measured rates. I report them and don't redesign anything.

| Check | Your resume as described | What breaks and what it costs | Provenance |
|---|---|---|---|
| Multi-column layout | Two-column | Parsers read linearly, so columns can interleave and detach dates from roles | `[grounded]` your description; `[generic]` how parsers fail |
| Icons for skills | An icon beside each skill | Anything carried only by an icon is absent after extraction. If the skill names are text beside the icons, they should survive | `[grounded]` your description; `[generic]` how parsers fail |
| Contact details in the header | In the header | Header content is often treated as page furniture and discarded. If so, you become unreachable | `[grounded]` your description; `[generic]` how parsers fail |
| Section headings, text layer, hidden text from templates | Not visible to me | Could not run. I can't see the file, so I can't say whether the PDF has a real text layer or whether the Canva template left hidden text in it | `[generic]` what these checks would cover |

## Upgrade menu

- **The PDF itself:** lets me run the checks above for real, including the text layer and any hidden text a template left behind.
- **Your resume's exact text:** lets me quote you character for character. At the moment I'm quoting your description.
- **The full JD or application form:** shows which requirements are explicit must-haves and whether any knockout questions are likely, which are what most often reject without a person.
- **Artifacts from the proof-of-concept, Jenkins pipeline or monitoring work:** a README, repo, dashboard or runbook would turn recall prompts into real ledger rows.

## Questions

C1. What did your Kubernetes proof-of-concept run on (EKS or something else), and did you use Helm or ArgoCD?
C2. Have you written any Terraform, even a single module or a one-off environment?
C3. Have you been on call, tuned CloudWatch alarms or written runbooks that other people rely on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.