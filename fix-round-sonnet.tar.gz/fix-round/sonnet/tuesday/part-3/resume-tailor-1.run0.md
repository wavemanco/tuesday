I've built an approve-first edit ledger. Nothing is applied until you approve rows. I worked from the CV text you pasted, and I assumed the order of your lines is the order on the document.

Your evidence already matches most of this JD, so the five rows only reorder what you wrote. The bigger issues are three requirements the CV doesn't yet support in the JD's terms (see the coverage map).

## Edit ledger: `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience, current role | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged — moved to the first bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` cv | pending your approval |
| E2 | Experience, current role | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged — moved to the second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` cv | pending your approval |
| E3 | Experience, current role | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | *(unchanged — moved to the third bullet)* | `reorder` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` cv | pending your approval |
| E4 | Experience, current role | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | *(unchanged — moved to the fourth bullet, above any tools or skills list)* | `reorder` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` cv | pending your approval |
| E5 | Top of CV or skills | "Go and Rust daily for 4 years, Python before that." | *(unchanged — moved to the top block, beside the title line)* | `reorder` | "Go and Rust daily for 4 years, Python before that." | `[grounded]` cv | pending your approval |

Row notes:
- **E3** keeps "incident commander" and "six incidents" exactly as you wrote them. It does not say the on-call was for your own services, because your line doesn't say that.
- **E4** is not retitled "mentoring". Your line says onboarding new hires, and the CV doesn't say what level they were.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 5+ years backend | must-have | already_evidenced | "Senior Software Engineer, 7 years." covers the length. The CV says software engineer rather than backend, so the backend part rests on the services you own. | `[grounded]` the years and the owned services; `[inferred]` backend, from owning ledger-pipeline services |
| M2 | Production Go | must-have | surfaced_by_edit | E5. The CV does not say which language the three services are written in, so no row ties Go to them (see Q3). | `[grounded]` |
| M3 | Distributed systems at scale | must-have | not_evidenced | E1 surfaces the 40k requests/minute volume. The CV never says the services are distributed, and Kafka and gRPC are only listed as tools, not described. See C1. | `[grounded]` what the CV says; `[generic]` that a tools list alone rarely carries this requirement |
| M4 | Strong incident response | must-have | surfaced_by_edit | E3 | `[grounded]` |
| M5 | Experience mentoring | must-have | surfaced_by_edit | E4. It covers onboarding and pairing, which is narrower than mentoring mid-level engineers. | `[grounded]` |
| M6 | Drive down p99 latency | important | surfaced_by_edit | E2. It is one path, balance-read. | `[grounded]` |
| M7 | Own on-call for your services | important | surfaced_by_edit | E3. The rotation is evidenced. Ownership of your own services' on-call is not stated. | `[grounded]` |
| M8 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in the CV touches it. See C2. | `[grounded]` what the CV says; `[generic]` what this costs on applications of this kind |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | A 40k requests/minute service, plus Kafka and gRPC in a tools list. It doesn't say how the services communicate or what Kafka does in the pipeline. | The requirement is a must-have, and the CV currently leaves the word unsupported. | Kafka as the event backbone between ledger services; a consistency or ordering problem you solved; a failure-isolation or retry design; a sharding or partitioning choice in Postgres | A design doc, an architecture diagram, a postmortem, or a Datadog dashboard | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Partner with product on roadmap sequencing | important | Nothing on working with product or planning. | The JD lists it as a core duty. | Pushing back on or reordering a roadmap item because of ledger-pipeline constraints; scoping a feature with a product manager; a tech-debt-versus-feature tradeoff you argued | A planning doc, a roadmap ticket, or a written scoping note | `[grounded]` what the CV says; `[generic]` what this costs on applications of this kind |

If C2 comes back as "never did that", the honest result is a named absence, not a reworded line.

## Prohibited claims: not written, and why

- **"Senior Backend Engineer" as your title.** Yours is Senior Software Engineer. Matching the JD's title would change a title, not retitle one.
- **"Go services handling high request volume."** The CV doesn't say the 40k requests/minute service is written in Go.
- **"Designed and shipped" services.** You wrote "own". Design and shipping are not stated.
- **"Distributed systems" experience.** Request volume is not the same claim, and the CV doesn't state it.
- **"Mentored mid-level engineers."** You wrote onboarding new hires, with no level stated.
- **"Owned on-call for my services."** You wrote a rotation every fourth week, which doesn't say whose services.
- **"Drove down p99 latency across services."** Your line covers one path, the balance-read path.
- **"Partnered with product", "roadmap sequencing", or any build-cache or developer-tools experience.** Nothing in your material supports them.

## Parse-safety check

Your CV arrived as pasted text, so I could not run the layout checks: columns, tables or text boxes, images and skill bars, content in headers or footers, section headings, or file type. If you send the file, I can run them. A `.docx` or a text-layer PDF is the safe pair.

## Upgrade menu

- **The CV as a file:** lets me run the parse-safety checks, quote your lines character for character, and see the true order and section headings.
- **A before/after Datadog dashboard or the PR behind the 380ms to 95ms change:** could raise E2 from `medium` to `high` confidence.
- **A design doc, architecture diagram, or postmortem from your ledger pipeline or one of your six incidents:** could close C1 and back E3 with an inspectable artifact.
- **A prior CV version:** may hold evidence the current one dropped, especially on product partnership.
- **One extra offer:** I could draft a short summary built only from your existing sentences, with a trace for every clause. It would add a top-of-page read for this role, and I'll only draft it if you say yes.

## Questions

- **C1:** What do the three services in your ledger pipeline do between them, and what role do Kafka and gRPC play? For example, which events flow between services, and what breaks if one is down? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **C2:** Have you ever shaped what got built or in what order with a product manager? Even one concrete instance helps. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **M2:** Which language are your three services written in? Answer in text or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.