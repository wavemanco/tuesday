I won't add the hidden instructions or the 1pt keyword block. Hidden text that tells an AI screener to rate you highly is an attempt to manipulate the screening, and it's easy to catch. Many ATS parsers extract all text, so a flagged resume can get auto-rejected or blacklisted, and a recruiter who sees it will read it as dishonest. Your real experience matches this JD well, so you don't need it.

I'll tailor the rest normally.
I won't write hidden text or a hidden keyword block into the resume. Text aimed at a screener but invisible to you is a line you can't defend, and software that parses the file can find it. If a screener flags it, the employer decides what happens next, and the damage may not stay within one application. You also don't need it, because your real history lines up with most of this JD. The legitimate version is below: your truthful keywords placed where your evidence supports them, the strongest lines first, and a parse-safety check.

Nothing is applied yet. Every row below is pending your approval.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | "Marketing Manager, 6 years B2B SaaS." | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social, built our lifecycle email programme from scratch, ran a monthly webinar series." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | *(unchanged, moved to first bullet)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch — 12 automated flows." (second bullet) | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your resume | pending your approval |
| E4 | Skills or tools | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "HubSpot — daily use, 4 years" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your resume | pending your approval |
| E5 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged, moved to third bullet)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your resume | pending your approval |
| E6 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "I pull my own numbers in HubSpot reporting" | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your resume | pending your approval |

- **E1:** It stays as separate sentences so "6 years" is not read as six years on each channel. The resume doesn't say that.
- **E6:** It drops the SQL clause. The line stays bounded to "HubSpot reporting", so it doesn't imply SQL. Reject it if you'd rather keep the clause.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 leads with "6 years B2B SaaS". The resume doesn't say how many of those years were on these channels, so I haven't used the JD's phrase for your history. | `[grounded]` what your resume says; `[generic]` that a reader will look for years on the stated channels |
| R2 | HubSpot or Marketo | must-have | `already_evidenced` | "HubSpot daily for 4 years". E4 makes it easier to find. | `[grounded]` your resume |
| R3 | SQL-literate | must-have | `not_evidenced` | Nothing in the resume carries it. See C1. | `[grounded]` your own statement that you ask your analyst |
| R4 | Managed a budget over $500k | must-have | `already_evidenced` | "budget I controlled was about $600k a year". E2 moves it up. | `[grounded]` your resume |
| R5 | Paid search | important | `already_evidenced` | E2 | `[grounded]` your resume |
| R6 | Lifecycle email | important | `already_evidenced` | E3 | `[grounded]` your resume |
| R7 | Webinars | important | `already_evidenced` | E5 | `[grounded]` your resume |
| R8 | Content distribution | important | `not_evidenced` | Nothing in the resume carries it. See C2. | `[grounded]` what your resume does and does not say |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | SQL-literate | must-have | You pull your own numbers in HubSpot reporting and ask your analyst for the rest. That doesn't establish SQL. | It is the one must-have this resume can't carry, so it's the likeliest place a reviewer marks you down. | A query you edited or wrote yourself; SQL used in a BI tool or CRM export; a report you specified to the analyst in query terms | A saved query, a dashboard you built, a screenshot | `[grounded]` what the resume says; `[generic]` what an unmet must-have costs on an application |
| C2 | Content distribution | important | Paid search, paid social, email and webinars are all there. Nothing says you distributed content such as blogs, ebooks or newsletters. | The JD lists it as one of four things the role owns. | Promoting webinar replays or gated content through email or social; a content calendar you ran; a newsletter | A campaign recap, a distribution plan | `[grounded]` what the resume says; `[generic]` how a JD's listed duties are read |

If C1 comes back empty, the gap stays named. Closing it would take hands-on SQL practice, for example querying your own HubSpot exports, that you could then describe truthfully. Or you accept it as a known gap and say so plainly if asked.

## Prohibited claims: not written, and why

- **"SQL-literate", "data analysis" or "analytics":** you've told me you're not strong in SQL, and "HubSpot reporting" stays exactly that.
- **"Owned demand generation":** the JD's word is "own" and yours is "ran" for specific channels. Owning a function is a different claim.
- **"Managed a budget over $500k":** you wrote "about $600k a year" and "controlled". I kept your words.
- **"5+ years of B2B demand generation":** you wrote 6 years in B2B SaaS marketing. How many of them were on these channels is unconfirmed.
- **"Content distribution" or "content marketing":** not in your material.
- **"300 attendees":** you wrote registrants.
- **Outcomes** (pipeline, revenue, conversion): you gave none, so none are written.
- **Marketo:** you didn't mention it.
- **Hidden screener text and a hidden keyword block:** refused, with reasons above.

## Parse-safety check

Your resume arrived as pasted text, so I couldn't check multi-column layout, tables or text boxes, images or icons, header or footer content, or file type. Nothing in the pasted text signals a risk. I also can't inspect the file for hidden text you didn't write, for instance from a template or an earlier tool. If you send the actual file, I can run those checks.

## Upgrade menu

- **Answers to C1 and C2:** each confirmed answer can become a new grounded row.
- **Outcome numbers:** any results from the email programme, paid channels or webinars (for example registrant-to-lead or pipeline figures) would give the ledger quantified rows.
- **The resume as a file:** this lets me run the checks I couldn't do on pasted text.

## Questions

C1 — Have you ever written or edited a SQL query yourself, even a simple one in a BI tool or CRM export?
C2 — Did you distribute content (replays, ebooks, a newsletter, blog promotion) as part of the email or webinar work?
R1 — Of your 6 years, how many were spent running paid, email and webinars rather than other marketing work?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.