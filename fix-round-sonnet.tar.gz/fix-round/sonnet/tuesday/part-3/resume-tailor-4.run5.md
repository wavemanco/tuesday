Now the files this playbook names for this step.
Short version: keyword wording isn't what's costing you here, and I can't tell from here why you were rejected. The one study I can cite is small: one résumé-builder vendor interviewed 25 US recruiters. It found "AI/content auto-rejection configured: 8% of recruiters" (cite C25), and "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are form questions such as work authorization, licence and location, not resume content. Where match scores exist, "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27).

So keywords may affect how far down the pile you land, and I'll place the truthful ones where your evidence supports them. But I'm not adding any term you can't back up. Most of this JD's stack isn't on your resume, and no wording fixes that. The coverage map below shows which rows are real gaps. Whether this role is worth applying to at all is job-underwriter's question, not this one.

Nothing below is applied. Every row waits for your approval.

## Edit ledger — `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged — moved to the first bullet under your current role)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` resume | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged — moved to the second bullet, qualifier kept)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | Five plain-text lines: "AWS (EC2, S3, RDS, IAM)" / "Docker, Jenkins" / "Bash and Python scripting" / "Ansible for config management" / "CloudWatch for monitoring" | `split` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` resume | pending your approval |

The ledger is short on purpose. Your evidence supports reordering and separating, and nothing further. E1 and E2 put your strongest and most relevant lines first, and E2 keeps "never went to production". E3 gives Python and AWS their own findable lines as plain text, using only your wording.

## Coverage map

The JD gives no must-have or preferred tiers. I tiered by its order and by "You will own platform reliability and developer experience". Correct me if the real weighting differs.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | surfaced_by_edit | E2. The evidence is a two-month proof-of-concept only, not production, so the match is partial. | `[grounded]` the PoC line and its qualifier |
| R2 | AWS EKS | must-have | not_evidenced | EC2, S3, RDS and IAM are on your resume and EKS is not. See C1. | `[grounded]` what the resume does and does not say |
| R3 | Terraform | must-have | not_evidenced | Ansible is config management, which is different work. See A1. | `[grounded]` what the resume does and does not say |
| R4 | GitOps, ArgoCD | must-have | not_evidenced | See A2. | `[grounded]` what the resume does and does not say |
| R5 | CI/CD (GitLab) | must-have | surfaced_by_edit | E1 and E3. Jenkins is evidenced; GitLab is not, and no row claims it. | `[grounded]` the Jenkins pipeline line |
| R6 | SRE practices, platform reliability | must-have | not_evidenced | See C2. | `[grounded]` what the resume does and does not say |
| R7 | Developer experience | must-have | not_evidenced | See C3. | `[grounded]` what the resume does and does not say |
| R8 | Helm | important | not_evidenced | See C1. | `[grounded]` what the resume does and does not say |
| R9 | Istio, service mesh | important | not_evidenced | See A3. | `[grounded]` what the resume does and does not say |
| R10 | Prometheus, Grafana, observability | important | not_evidenced | CloudWatch is on your resume (E3 gives it its own line) but it is neither tool. See A5. | `[grounded]` what the resume does and does not say |
| R11 | Vault | important | not_evidenced | See A4. | `[grounded]` what the resume does and does not say |
| R12 | Python | important | already_evidenced | "Bash and Python scripting" is on your resume as written. E3 only separates the line. | `[grounded]` resume |
| R13 | Go | important | not_evidenced | See A6. | `[grounded]` what the resume does and does not say |

## Recovery per gap

These are the gaps where your own history might hold something. Each row's question is in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes depth, with EKS and Helm | must-have | One Kubernetes proof-of-concept of two months that never went to production. It doesn't say where it ran or how things were deployed to it. | The JD names EKS and Helm. A proof-of-concept that ran on EKS and used Helm would say more than "Kubernetes" alone. | A cluster you stood up on EKS; Helm charts or manifests you wrote; monitoring you wired into the proof-of-concept | A repo, a runbook, a write-up or a demo notes page from the proof-of-concept | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | SRE practices and platform reliability | must-have | You maintain about 30 Jenkins jobs and use CloudWatch for monitoring. Nothing shows on-call, alerting, incidents or reliability targets. | The JD closes on owning platform reliability. | Being paged for a failed deploy; setting CloudWatch alarms; writing up an outage; a rollback process you made | A post-incident write-up, an alarm config or a runbook | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Developer experience | must-have | "Built our deploy pipeline in Jenkins" doesn't say who uses it or how many. | The JD closes on owning developer experience, and the pipeline is your closest evidence. | The number of teams or developers deploying through it; deploy steps you shortened; docs or onboarding you wrote | Pipeline usage counts, a README or internal docs | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

### Named absences

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | Terraform | Nothing on your resume provisions infrastructure as code. | A small project that builds a VPC and an EKS cluster with Terraform in a personal account, in a public repo. Or any Terraform you've touched at work, if you tell me. | `[grounded]` the resume has no such line |
| A2 | GitOps, ArgoCD | Nothing on your resume shows a Git-driven deploy flow. | A hands-on ArgoCD install syncing a repo to a cluster, kept in a repo you can show. | `[grounded]` the resume has no such line |
| A3 | Istio, service mesh | Nothing on your resume touches a mesh. | A long stretch to close alone. I'd not close it before applying and would learn it if you reach an interview. | `[grounded]` the resume has no such line |
| A4 | Vault | IAM is on your resume, but it is not secrets management. | A Vault dev-server exercise with Kubernetes auth, kept as a documented personal project. | `[grounded]` the resume has no such line |
| A5 | Prometheus, Grafana | CloudWatch is your monitoring tool and these are different tools. | The cheapest gap to close: install a Prometheus and Grafana stack on a proof-of-concept cluster and document the dashboards. | `[grounded]` the resume has no such line |
| A6 | Go | Only Bash and Python are on your resume. | One small tool written and published in Go. | `[grounded]` the resume has no such line |

Closing a gap with a personal project gives you honest material to say in an interview. It's labelled as a project, not as job experience, and I won't write it up any other way.

## Not written, and why

- **"Platform Engineer"** as your title. You are a DevOps Engineer. Taking the JD's title would swap your title for theirs, and `retitle` allows an equivalent, not an upgrade.
- **"Kubernetes in production"** or "orchestrated containers on Kubernetes". Your own sentence says "never went to production".
- **EKS, Helm, Terraform, ArgoCD, Istio, Vault, Prometheus, Grafana, Go, GitLab CI** in any skills list. A listed tool is not an owned one, and nothing you've told me supports any of them.
- **"Observability"** for CloudWatch. You wrote "monitoring", and the JD's word would change the kind of work.
- **"Owned platform reliability"** or "SRE". Maintaining about 30 Jenkins jobs is a different job, and no incident, alerting or on-call work is stated.
- **"Improved developer experience"** or any claim about who uses the pipeline. Your sentence says "our deploy pipeline" and no more.
- **Any invented metric.** There is no deploy-time or uptime figure in your material, so none is written.

## Parse-safety check

I haven't seen the PDF. This is from your description only, and layout is reported as a risk, not redesigned.

| Check | What I can see | What it costs | Provenance |
|---|---|---|---|
| Multi-column layout | Two-column PDF | Text can interleave, and dates can detach from the roles they belong to | `[generic]` how parsers read columns |
| Images and icons | An icon for each skill | If any skill sits only in an icon, it is absent to a parser. E3 puts every skill in plain text. | `[generic]` how parsers treat images |
| Content in the header | Contact details sit in the header | Header text can be dropped as page furniture, leaving you unreachable | `[generic]` how parsers treat headers |
| Not run | Whether the PDF has a text layer, how the section headings read, whether any hidden text came in from the Canva template | Unknown until I can inspect the file | `[generic]` |

## Upgrade menu

- **The PDF itself.** It would let me run the parse checks above on the real file, including the hidden-text check, instead of guessing from your description.
- **Anything from the Kubernetes proof-of-concept** (repo, notes, a diagram). It's the one claim here that could move up to a stronger band.
- **An answer to C1, C2 or C3.** Each converts a `not_evidenced` row into a real one, after a confirmation step.

C1 — In the Kubernetes proof-of-concept, what did you run it on (EKS or something else), how did you deploy to it (Helm, plain manifests, anything else), and did you set up any monitoring?
C2 — In your current role, who gets paged when a deploy or production system breaks, and have you set up alerts or written up an incident?
C3 — Who uses the Jenkins pipeline you built: how many developers or teams deploy through it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.