I've built the tailoring as a ledger of proposed edits, because I only have your prose summary and not the CV file. Every row quotes your own sentence, and nothing is applied until you approve it row by row. I've treated your sentences as the current CV lines and assumed the three services and the 40k figure sit under your current role.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years backend | must-have | surfaced_by_edit | E1 carries "Senior Software Engineer, 7 years" as you wrote it. "Backend" isn't in your words, so no line adds it. | `[grounded]` what the CV says |
| 2 | Production Go | must-have | surfaced_by_edit | E1 carries Go daily for 4 years and E2 carries the three services. Nothing says which services run Go, so no line joins the two (see C2). | `[grounded]` what the CV says |
| 3 | Distributed systems at scale | must-have | not_evidenced | E2 carries the 40k requests/minute figure, but nothing in your material describes the services as distributed (see C2). | `[grounded]` what the CV says |
| 4 | Strong incident response | must-have | surfaced_by_edit | E4 and E5 | `[grounded]` what the CV says |
| 5 | Experience mentoring | must-have | surfaced_by_edit | E6 says onboarding and pairing with new hires. The JD says mid-level engineers, and your level isn't stated, so the line doesn't say "mentor". | `[grounded]` what the CV says |
| 6 | Drive down p99 latency | important | surfaced_by_edit | E3 | `[grounded]` what the CV says |
| 7 | Own on-call for your services | important | surfaced_by_edit | E4 carries the rotation. Nothing says it covers your own three services, so no line says that. | `[grounded]` what the CV says |
| 8 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in your material touches this (see C1). | `[grounded]` what the CV does not say |

## Edit ledger — resume_edits_pending_approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged — moved to the first bullet under the current role)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged — moved to the second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Line 1: "On-call rotation every fourth week for two years". Line 2: "Ran six incidents as incident commander" | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E5 | Experience | the two lines from E4 | *(unchanged — moved to the third and fourth bullets, directly below E3)* | `reorder` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E6 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team — usually two or three a year — pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV | pending your approval |

- **E4:** the split keeps the six incidents from reading as having happened inside the two-year rotation. Your sentence doesn't say that.
- **E6:** I kept "them" rather than "each", and kept the volume and the first-month scope as you stated them.

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Partner with product on roadmap sequencing | important | Technical ownership, latency work, on-call and onboarding. Nothing on working with product or on deciding what ships when. | The JD lists it as a responsibility, and your material gives a reader nothing to match it to. | Deciding with a product manager which reliability or latency work went before feature work; sequencing the cache-layer rework against other commitments; pushing back on or reordering a request. | A planning doc, roadmap or epic you contributed to, a design doc with a sequencing section | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Distributed systems at scale | must-have | A 40k requests/minute service, three owned services, and Kafka and gRPC in a tools list. No sentence describes how the services work together. | The JD makes it a must-have, and a tools list shows tools without showing use. | Ordering or idempotency decisions in the ledger pipeline; consumer lag or retry handling on Kafka; a gRPC contract between your services; failure of a downstream dependency. | An architecture diagram, a design doc, a runbook, a Datadog dashboard for the 40k service | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

## Not written, and why

- "7 years of backend engineering": you wrote 7 years as a Senior Software Engineer. "Backend" would be my addition.
- "Production Go services handling 40k requests/minute": your material doesn't say the 40k service runs Go, and you also work in Rust.
- "Distributed systems at scale": your words don't say it, and Kafka and gRPC are tools you listed, not described work.
- "Mentored mid-level engineers": you pair with new hires through onboarding. The level isn't stated, and mentoring is a different kind of work.
- "Owned on-call for my services": you describe a rotation, not that it covers your three services.
- "Partnered with product on roadmap sequencing": nothing in your material supports it.
- "Build-cache or developer-tools experience": the cache work you describe is on a payments balance-read path.
- "Cut p99 across high-volume services": your result is on the balance-read path, and I haven't widened it.

## Parse-safety check

Your CV arrived as pasted prose, so I could not check layout. That means I couldn't check columns, tables, text boxes, icons or skill bars, header or footer content, section headings or file type. I also couldn't check the file for hidden text you didn't author. Nothing here asks for hidden text, and I'd decline it if it did.

## Upgrade menu

- **The CV as a file (.docx or PDF):** this runs the parse-safety checks above and the hidden-text check.
- **A before/after Datadog dashboard or write-up for the 380ms to 95ms change:** this is the inspectable artifact that would raise your strongest claim from confirmed-only to documented.
- **Incident reviews you wrote or contributed to:** these would document the six incidents.
- **Answers to C1 and C2:** a confirmed answer can turn a gap into a row, once you've checked my reading of it.
- **Offer (beyond the ledger):** I can draft a one-sentence summary line, built only from E1 to E6 and audited like any row, if you want a summary above the experience section.

## Questions

C1 — Have you worked with a product manager on what got built first, for example when the cache-layer rework was scheduled against other work?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Which of your three ledger services run in Go, and what do Kafka and gRPC do between them?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q3 — Were all 7 of your years backend work, or only some of them?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.