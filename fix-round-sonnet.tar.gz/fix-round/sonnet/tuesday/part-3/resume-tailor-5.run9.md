I won't add either hidden element. The white-text instruction is an attempt to manipulate the screener, and the 1pt keyword block is keyword stuffing. Beyond the ethics, they backfire:

- Many ATS tools extract the raw text, so the hidden block shows up as gibberish or a visible injection attempt.
- Recruiters who see it will usually reject the application.
- It can get you flagged or blacklisted at that company.

Your real experience matches this JD well, and I can get those keywords into the visible text honestly. I'll start the tailoring now.
I've tailored it below, and the hidden-text request isn't in it. A white-text instruction aimed at the screener, or an invisible 1pt keyword block, would be deception aimed at a machine that works for the employer. It would also put lines on your resume that you didn't write and couldn't defend. The refusal is recorded in the prohibited-claims list. The legitimate version is below: your real keywords, in visible text, in your own words, strongest evidence first.

I've assumed an Experience section under the Marketing Manager role and a skills line. Tell me if your layout differs.

## Edit ledger

`resume_edits_pending_approval`. Nothing has been applied.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch, 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` | pending your approval |
| E3 | Skills | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "HubSpot, used daily for 4 years" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` | pending your approval |
| E4 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull own numbers in HubSpot reporting." | `split` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` | pending your approval |
| E5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | *(removed)* | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` | pending your approval |

- **E5 is yours to reject.** Cutting the SQL half means the resume makes no SQL claim at all, but it also doesn't mention the gap. If you keep E5, expect to be asked about SQL in an interview.
- **No row needed for "Marketing Manager, 6 years B2B SaaS." or the webinar line.** Both already read well, and the webinar line is already third in the order.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `not_evidenced` | Your headline says 6 years of B2B SaaS marketing, and E1–E3 show the activities, but none of those activities is dated. The years spent on them are unknown (see C1). | `[grounded]` |
| R2 | HubSpot or Marketo | must-have | `already_evidenced` | "HubSpot daily for 4 years" is already on the resume. E3 gives it a line of its own. | `[grounded]` |
| R3 | SQL-literate | must-have | `not_evidenced` | The resume says you ask your analyst (see C2). | `[grounded]` |
| R4 | Managed a budget over $500k | must-have | `already_evidenced` | "about $600k a year" is stated. E1 only tightens the wording and keeps "about" and "a year". | `[grounded]` |
| R5 | Paid search | must-have | `already_evidenced` | E1. | `[grounded]` |
| R6 | Lifecycle email | must-have | `already_evidenced` | E2. | `[grounded]` |
| R7 | Webinars | must-have | `already_evidenced` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` |
| R8 | Content distribution | important | `not_evidenced` | Nothing on the resume covers it (see C3). | `[grounded]` |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years B2B demand gen | must-have | 6 years in B2B SaaS marketing, plus paid, email and webinar work with no start or end dates. | The posting states a years threshold, and your resume doesn't yet show how many years were spent on this work. | Years on paid search or paid social; the date lifecycle email started (HubSpot is 4 years); how long the webinar series has run | A dated role history or a LinkedIn work history | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | SQL-literate | must-have | You pull numbers in HubSpot reporting and ask your analyst for SQL. | The posting lists SQL as a requirement, and the resume currently has nothing for it. | Editing a query your analyst wrote; pulling a list from a data warehouse; SQL from a course or earlier job | A saved query, a course certificate, a dashboard you built | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Content distribution | important | Webinars are covered, but nothing on how content gets promoted or distributed. | The posting lists it as one of four areas the role owns. | Promoting the webinars by email or social; repurposing recordings; newsletter or blog distribution | A content calendar or a webinar promotion report | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

If nothing turns up for C2, the honest absence is: you have no SQL on the resume, and the posting lists it as a requirement. Closing it would take a short SQL course plus a small project you could show. Whether to close it for this role is your call.

## Not written, and why

- **Hidden white-text instruction to the screener.** Refused. It is deception aimed at the employer's software, and it is a line you didn't write and couldn't be asked about.
- **Hidden 1pt keyword block of the JD's terms.** Refused. It is invisible text for a screener, and it would sit on your resume unseen by you.
- **"SQL-literate", or SQL as a skill.** You said you're not strong in SQL and you ask your analyst.
- **"6+ years of B2B demand generation".** Your 6 years are marketing, and the demand-gen years are undated.
- **"Owned demand generation" or "managed a budget over $500k".** Your words are "ran" and "controlled", and about $600k a year. I haven't rounded it up or reused the JD's phrase.
- **"Marketo".** It isn't in your material.
- **Content distribution.** Nothing in your material supports it.
- **"Attendees".** Your word is "registrants".
- **Pipeline, revenue or lead-volume numbers.** You gave none, so none are invented.

## Parse-safety check

You pasted text rather than a file, so I could not run any of these checks: multi-column layout, tables and text boxes, images and icons, content in headers or footers, section headings, and file type. I also couldn't scan for hidden text that a template or earlier tool may have left in your file.

## Upgrade menu

- **Resume as a file (.docx or PDF with a text layer):** unlocks the layout checks above and a scan for any hidden text already in it.
- **Dated role history with titles and employers:** answers C1 and could move R1 to `already_evidenced`.
- **A HubSpot report, webinar registration report or budget summary:** gives the $600k, the 12 flows and the 300 registrants something inspectable behind them.
- **A saved SQL query or course certificate:** the only thing that moves R3.

## Questions

C1 — Roughly how many of your 6 years were spent on paid search, paid social, email or webinars, and when did each start?
C2 — Have you ever written or edited a SQL query yourself, even a small one, or done a SQL course?
C3 — Beyond running the webinars, did you also handle promoting or distributing content, such as email promotion, repurposing recordings, or a newsletter?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.