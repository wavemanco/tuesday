Your resume is probably being hurt less by keyword matching than you think, and I wouldn't try to fix it by adding the JD's keywords. Two things are probably costing you more: the gaps between your experience and this stack, and a layout that may be scrambling or dropping your content. Below is the full edit ledger, built only from sentences you gave me. Nothing is applied yet.

**On the premise.** The one source I have on this is a small vendor interview study, so weigh it accordingly. It reports "AI/content auto-rejection configured: 8% of recruiters" (cite C25), which is 2 of 25 recruiters, and the vendor says its findings are themes rather than representative statistics. It also says "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are yes/no form questions on work authorization, licence or location. On keywords it says "Many teams use match scores/filters to prioritize who gets reviewed first" (cite C27). A low score isn't an auto-reject, but it can push you down the pile. So I'd place truthful keywords where your evidence already supports them and never invent any.

In the coverage map below, M2, M3, M5, M7–M15 are `not_evidenced`. No wording change closes those. Whether this role is worth the time given those gaps is a separate question for job-underwriter.

## Coverage map

The JD doesn't tier its requirements, so I assumed the ownership sentence, Kubernetes, EKS, Terraform, CI/CD, Python and SRE practices are must-haves, and the rest are important. Tell me if you read it differently.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Kubernetes | must-have | surfaced_by_edit | E1, E3. Evidence is the proof-of-concept only, so it stays "proof-of-concept, not production" | `[grounded]` your POC sentence; priority `[inferred]` from JD order |
| M2 | AWS EKS | must-have | not_evidenced | You name EC2, S3, RDS, IAM, not EKS. Recovery: C2 | `[grounded]` |
| M3 | Terraform | must-have | not_evidenced | Ansible is a different tool and kind of work. Recovery: C1 | `[grounded]` |
| M4 | CI/CD | must-have | surfaced_by_edit | E2, E4 lead with the Jenkins pipeline | `[grounded]` |
| M5 | GitLab CI/CD | important | not_evidenced | Jenkins is not GitLab. Named absence A1 | `[grounded]` |
| M6 | Python | must-have | already_evidenced | "Bash and Python scripting" is in your tools list. It only counts if that section parses, see the parse check | `[grounded]` |
| M7 | Go | important | not_evidenced | Named absence A2 | `[grounded]` |
| M8 | ArgoCD, GitOps | important | not_evidenced | Recovery: C2 | `[grounded]` |
| M9 | Helm | important | not_evidenced | Recovery: C2 | `[grounded]` |
| M10 | Istio, service mesh | important | not_evidenced | Named absence A3 | `[grounded]` |
| M11 | Prometheus, Grafana | important | not_evidenced | Named absence A4 | `[grounded]` |
| M12 | Observability | important | not_evidenced | CloudWatch stays "monitoring" because relabelling it would change the kind of work. Named absence A4 | `[grounded]` |
| M13 | Vault | important | not_evidenced | IAM is access management, not secrets management. Named absence A5 | `[grounded]` |
| M14 | SRE practices | must-have | not_evidenced | Recovery: C3 | `[grounded]` |
| M15 | Owning platform reliability and developer experience | must-have | not_evidenced | E2 and E4 put your pipeline first without claiming ownership | `[grounded]` |

## Edit ledger (resume_edits_pending_approval)

I'm working from your description rather than the PDF's text. "Moved to the top of Experience" assumes these are Experience bullets. Each quote is exactly what you gave me.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged wording — moved to sit directly under the Jenkins pipeline bullet)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged wording — moved to the first bullet under Experience)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your resume | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring, Kubernetes (proof-of-concept only)." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production."; "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your resume | pending your approval |
| E4 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your resume | pending your approval |

E1 keeps "never went to production" on purpose. "Last year" goes stale, so if you approve E1, swap in the actual year. E3 adds Kubernetes to your skills list only with its limit attached. E4 keeps the two sentences separate so "maintain" doesn't turn into "owned" or "led".

## Not written, and why

- **"Platform Engineer" as your title.** That's the JD's word for your DevOps Engineer history, and a retitle has to be an equivalent, not an upgrade.
- **"Kubernetes" as a plain skill, or "production Kubernetes".** Your own sentence says it never went to production.
- **Terraform, Helm, ArgoCD, GitOps, Istio, Vault, Prometheus, Grafana, Go, GitLab CI, EKS as skills.** Nothing you wrote supports them. Listing them is the keyword stuffing I'm declining, and it would put things on the page you'd be asked about in the interview.
- **"Observability" for CloudWatch monitoring.** That's the JD's vocabulary replacing yours.
- **"GitOps pipeline" or "GitLab-style CI/CD" for the Jenkins pipeline.** Different tools and different work.
- **"Owned platform reliability" or "SRE practices".** You haven't described either.
- **"Secrets management" for IAM.** A different kind of work.

## Recovery per gap

These three might be recoverable if you've done the work and it just isn't on the page.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Terraform | must-have | Ansible for config management, and nothing on provisioning infrastructure as code | The JD lists it among its first tools | Provisioning AWS resources (VPC, EC2, RDS) in Terraform at work or in a personal account; a Terraform step in a Jenkins job; reading or changing someone else's modules | A repo, a module, or a Jenkinsfile with a plan/apply stage | `[grounded]` what the resume says; `[generic]` what this costs on infrastructure roles |
| C2 | AWS EKS, plus Helm and ArgoCD/GitOps | must-have | A two-month Kubernetes POC with no platform, tooling or contents stated | The POC is your only Kubernetes evidence, so what it ran on and used decides how much of M2, M8 and M9 it can carry | The POC ran on EKS rather than minikube or kind; you packaged apps as Helm charts; you deployed from Git with ArgoCD or Flux | The POC's README, a design note, manifests or charts, an architecture diagram | `[grounded]` what the resume says; `[generic]` what this costs on Kubernetes roles |
| C3 | SRE practices | must-have | Jenkins pipeline work and CloudWatch for monitoring, with nothing on incidents, alerting thresholds or reliability targets | The JD says you will own platform reliability | Being on call; running or writing up an incident; setting CloudWatch alarms that paged someone; cutting a pipeline's failure rate; defining an SLO | A postmortem, an alarm config, a dashboard, a before/after pipeline number | `[grounded]` what the resume says; `[generic]` what this costs on reliability roles |

The remaining gaps have nothing in your history to pull from, so here is where you stand and what closing each would take.

| # | Requirement | Gap and what closing it would take | Provenance |
|---|---|---|---|
| A1 | GitLab CI/CD | You've built CI/CD only in Jenkins. Closing it means real GitLab CI pipeline work, or a personal project with a `.gitlab-ci.yml` you'd describe as a project, not as job experience. | `[generic]` |
| A2 | Go | There's no Go anywhere in your material. Closing it means a small Go tool in a public repo, described as that. | `[generic]` |
| A3 | Istio, service mesh | Nothing in your history touches a mesh. It would need hands-on work, for example Istio on a local cluster, and that would still be a lab, not experience. | `[generic]` |
| A4 | Prometheus, Grafana, observability | You have CloudWatch only. The path is running Prometheus and Grafana against a service you operate, and what it would need to cover is metrics, dashboards and alerting. | `[generic]` |
| A5 | Vault | You have no secrets-management work. Closing it would take using Vault (or a comparable secrets tool) in a project. If this role is the target, it's one of several things you'd need to build. | `[generic]` |

## Parse-safety check

I can't open the PDF, so this runs from your description only. I couldn't check file type or text layer, heading names, or whether the template left any hidden text in the file.

| Check | What breaks | What it costs |
|---|---|---|
| Two-column layout | Parsers read linearly and can interleave the columns | Dates can detach from roles and bullets can be reordered, so the Jenkins and Kubernetes lines may not read as you wrote them |
| Contact details in the header | Header content can be treated as page furniture and discarded | Your contact details may not reach the recruiter at all |
| Icons for each skill | Icons render as junk or get skipped, so only your text labels survive | If any skill is shown by an icon alone, it's absent. Python and Docker are the two that matter here |

## Upgrade menu

- **The PDF itself, or its text pasted.** I could then run the checks above and quote your lines exactly instead of from your description.
- **Prior resume versions.** An older one may still carry Terraform, Helm or Kubernetes detail the current one dropped.
- **Anything from the Kubernetes POC** (README, design doc, manifests, diagram). That would move your only Kubernetes evidence from self-report to something inspectable.
- **A sanitised Jenkinsfile or pipeline description, plus any numbers** on failure rate, build time or who uses it. That would give M4 and M15 something real to stand on.

C1 — Have you provisioned infrastructure with Terraform, or any IaC tool besides Ansible, at work, in a side project or in a personal AWS account? If so, what did it create?
C2 — What did your Kubernetes POC run on (EKS, self-managed, minikube/kind), and did it use Helm charts or a GitOps tool like ArgoCD or Flux? What did it deploy?
C3 — Have you done on-call, incident response, postmortems, alert or SLO setup, or reliability work on your Jenkins pipeline? Please give any numbers you actually have.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.