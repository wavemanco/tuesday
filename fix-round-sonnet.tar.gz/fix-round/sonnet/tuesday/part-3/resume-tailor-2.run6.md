Checking your notes against the JD now. Below is the full edit ledger. Nothing is applied until you approve rows.

I built this from your notes as you pasted them, not from a formatted resume, so each "Current line" is a sentence from your notes. I had no dates, employer name or education to work with. The biggest finding is that "3+ years data engineering" is the one must-have your material doesn't evidence, and no edit can fix that. I wrote nothing that implies it.

## The edit ledger — resume_edits_pending_approval

Every proposed bullet drops the "I" for resume voice. Nothing else changes in tense or scope.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first bullet, above the SQL line)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your notes | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." | `surface` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your notes | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | Two bullets: "Fixed our nightly dbt job when it breaks." and "Added tests to our nightly dbt job." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your notes | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis (pandas); some scripting to pull vendor APIs on a cron." | `compress` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your notes | pending your approval |
| E5 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved below E1 through E4)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your notes | pending your approval |

- **E1, E2, E5:** these lead with the modelling work the JD asks for, and the SQL line stays intact below it.
- **E3:** one sentence was doing two jobs, so I split it. I didn't use "owned", "on-call" or "data quality", because your sentence says neither.
- **E4:** I kept "some" and "on a cron". Compression usually drops the qualifier first, and here the qualifier is the honest part.

## The coverage map

The JD marks only the 3+ years as must-have. I've graded the other requirements "important" and streaming "preferred", following its "a plus".

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | No row. Your title is analyst. The nearest work is E1 to E3, which the resume doesn't call data engineering. See C3. | `[grounded]` |
| R2 | Production Python | important | `not_evidenced` | E4 states your Python accurately. Nothing in your notes says the cron scripts are deployed or depended on. See C1. | `[grounded]` |
| R3 | Airflow or equivalent orchestration | important | `not_evidenced` | E3 shows upkeep of a nightly dbt job. Your notes don't say what schedules it. See C2. | `[grounded]` |
| R4 | Dimensional modelling | important | `surfaced_by_edit` | E2, with E1 | `[grounded]` |
| R5 | Own data quality | important | `surfaced_by_edit` | E3 ("added tests"), which doesn't say you owned data quality | `[grounded]` |
| R6 | Own SLAs | important | `not_evidenced` | No row. Nothing in your notes mentions a deadline or an agreed service level. See C2. | `[grounded]` |
| R7 | Build and own batch pipelines | important | `not_evidenced` | E3 shows you fixed and tested a nightly job. Building it or owning it isn't stated, so no row claims either. | `[grounded]` |
| R8 | Partner with analytics on requirements | important | `surfaced_by_edit` | E2 shows you co-designed a mart with a DE. Gathering requirements isn't stated, and no row says it. | `[grounded]` |
| R9 | Streaming experience (Kafka) | preferred | `not_evidenced` | Named absence below | `[grounded]` |

## Gap handling

Whether to apply with the 3+ years unmet is a job-underwriter question, not this ledger's.

Recall prompts, each with something that might already be in your history:

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | important | "some scripting to pull vendor APIs on a cron", plus pandas for analysis. It doesn't say whether anything runs unattended or is relied on. | The JD lists production Python as a requirement, and "scripting for analysis" reads as a different kind of work. | A vendor-pull script whose output a dashboard or the orders mart depends on; a script with retries or alerting; code in a shared repo that others run | The script or repo, a README, a cron or scheduler config | `[grounded]` what your notes do and don't say; `[generic]` what this costs on applications of this kind |
| C2 | Orchestration, SLAs, batch ownership | important | You "fixed" and "added tests to" the nightly dbt job. Your notes don't say what runs it, who depends on it, or whether it has a deadline. | Three JD requirements (orchestration, batch pipelines, SLAs) all hang on the nightly job. | dbt Cloud or another scheduler running the job; a morning deadline the business relies on; alerts or retries you set up; being the person who got paged | Scheduler config, a screenshot of the run history, a runbook | `[grounded]` what your notes do and don't say; `[generic]` what this costs on applications of this kind |
| C3 | 3+ years data engineering | must-have | Five years as Senior Data Analyst. DE-type work appears only as "with our then-DE". | It's the one must-have. The resume reads as analyst-with-dbt unless some DE scope is on record. | A stretch covering the DE's pipelines after "then-DE" left; an analytics-engineer scope in your role; a formal title or review wording | A job description or review text from that period, a repo | `[grounded]` what your notes do and don't say; `[generic]` what this costs on applications of this kind |

Named absences:

- **Airflow by name.** You've never used it. Closing it would take a small project: an Airflow DAG running a dbt build, on a public repo, or on a local setup you can demo. C2 may already show an "equivalent", and that is the cheaper route.
- **Kafka and streaming.** You've never touched it. The JD calls streaming "a plus", so it isn't worth closing before applying. A small consumer-and-sink project would be the path if you wanted to.
- **Spark.** It appears only in the JD's list of pipeline tools, not in its requirements. It isn't worth closing before applying either.
- **R1 if C3 comes back empty.** Then the resume stays honest at five years as an analyst, and the gap is carried as is.

## Not written, and why

- **"Data Engineer" or "Analytics Engineer" as a title, or "3+ years data engineering".** Those would be an upgrade, not an equivalent.
- **"Production Python" or "built data pipelines".** Your Python is for analysis plus "some scripting" on a cron, which is a different kind of work.
- **"Orchestrated pipelines" or "Airflow-equivalent".** Your notes don't say what schedules the job or whether you owned it.
- **"Owned data quality and SLAs".** You added tests. No SLA appears anywhere in your notes.
- **"Partnered with analytics on requirements".** This is the posting's wording, and the DE would be the one saying it. Your notes put you on the analyst side, so swapping the word would change which side of the table you sat on.
- **Rounding "about 25 dbt models" to "25+".** The "about" stays.
- **Any Kafka, Spark or streaming exposure.** You've said you have none.

## Parse-safety check

Your resume arrived as pasted notes, so I couldn't run any of the six checks: columns, tables, images, headers and footers, section headings, file type. I also can't see whether your real document has dated roles or conventional headings. Send the file and I'll run them.

## Upgrade menu

- **Your actual resume file.** This unlocks the parse-safety checks and exact quotes, and may surface evidence these notes dropped.
- **The nightly job's scheduler config or run history, or the cron script's repo.** This would answer C1 and C2 and could raise those rows from your word alone to something inspectable.
- **A small Airflow-plus-dbt project, or an earlier resume version.** The project turns a named absence into a `[grounded]` row. An old version may hold evidence the current one dropped.
- **Optional extra (not part of this ledger):** a short summary section built only from rows you approve. It would add a top-of-page framing sentence, and I'd build it only if you ask.

## Questions

C1. Do any of your vendor-API scripts feed something others rely on, such as a dashboard or a table in the orders mart, and are they in a shared repo with any alerting or retries?
C2. What runs the nightly dbt job (dbt Cloud, cron, something else), and is there a time by which it has to finish for someone downstream?
C3. Did any part of your five years carry data-engineering scope, such as covering pipelines after the DE left, or a title or review wording that says so?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.