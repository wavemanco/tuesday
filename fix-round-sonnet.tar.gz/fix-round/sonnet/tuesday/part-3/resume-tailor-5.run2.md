I won't add the hidden instruction or the 1pt keyword block. Those are attempts to deceive the screening system. They're also a real risk to you: many ATS tools and recruiters flag hidden text, and getting flagged can get you rejected outright. Your real experience matches this JD well, so you don't need them. I'll tailor the resume honestly.
I won't write the hidden instruction or the 1pt keyword block. Both are aimed at deceiving the employer's screening software, and your resume would then hold lines you didn't write and couldn't defend if asked. They can also be found. One candidate told the NYT that "One recruiter discovered the prompt hacking and turned him down because of it" (cite C35). A keyword block would also have to include SQL, which you've said you can't claim. Your real material fits this JD better than most, so the ledger below does the legitimate version: your strongest evidence goes first, and the keywords you actually have sit in their own lines.

Nothing is applied yet. Every row waits for your approval. I'm reading your background as self-report, because I haven't seen the resume file.

**Edit ledger** (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | *(unchanged, moved to the first bullet)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your background | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | *(unchanged, moved to the second bullet)* | `reorder` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E3 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged, moved to the third bullet)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your background | pending your approval |
| E4 | Experience | "I pull my own numbers in HubSpot reporting" (buried in a clause about SQL) | "Pull my own numbers in HubSpot reporting." | `surface` | "I pull my own numbers in HubSpot reporting" | `[grounded]` your background | pending your approval |

- **E1–E3 only change position.** The order follows the JD's own order: paid search, lifecycle email, webinars. Each line keeps "about", "controlled", "from scratch", "12" and "average" as you wrote them.
- **E4 is the only row that touches analytics, and it makes no SQL claim.** Drop it if you'd rather not draw attention to that area.
- **Nothing is cut.** Paid social stays because it's inside your own sentence.

**Coverage map**

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Paid search | important | `already_evidenced` | Your sentence stands as written; E1 moves it first | `[grounded]` |
| R2 | Lifecycle email | important | `already_evidenced` | Stands as written; E2 moves it second | `[grounded]` |
| R3 | Webinars | important | `already_evidenced` | Stands as written; E3 moves it third | `[grounded]` |
| R4 | Content distribution | important | `not_evidenced` | Nothing in your material mentions it; see C1 | `[grounded]` |
| R5 | 5+ years B2B demand gen | must-have | `not_evidenced` | You say 6 years in B2B SaaS marketing. Your material doesn't say how many of those years were spent on paid, email or webinars; see C2 | `[grounded]` what you wrote; `[generic]` a years requirement is usually read as years doing that work |
| R6 | HubSpot or Marketo | must-have | `already_evidenced` | "HubSpot daily for 4 years" stands as written; E2 moves it up | `[grounded]` |
| R7 | SQL-literate | must-have | `not_evidenced` | E4 covers HubSpot reporting only, which is not SQL; see the named absence below | `[grounded]` |
| R8 | Budget over $500k | must-have | `already_evidenced` | "about $600k a year" is in E1, and stays "controlled" and "about" | `[grounded]` |

**Recovery per gap**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Paid search, paid social, email and webinars. Nothing about distributing content. | It is the fourth item in the JD's list of what you'd own, so a reader finds no match for it. | Promoting webinar recordings or gated assets through your email programme; a newsletter you sent; working with a syndication or partner channel; repurposing webinar content | A send calendar, a campaign report, a distribution plan | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |
| C2 | 5+ years B2B demand gen | must-have | 6 years in B2B SaaS marketing, plus the channels above | The JD asks for years doing demand gen, and your material doesn't say how many of the 6 were that work. | Years you ran paid, lifecycle email or webinars, even in a broader role | Job history with dates, or a role description | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |

**Named absence**

| # | Requirement | The absence | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | SQL-literate | You said you aren't strong in SQL and ask your analyst. That is a listed requirement, so no line goes on the resume. | Writing the queries you now hand off, enough that you could truthfully say you do. Until then, expect it to be asked about. Say plainly what you do in HubSpot and where the analyst steps in. | `[grounded]` |

**Parse-safety check.** I couldn't run any checks because your resume arrived as text. Layout, tables, headers and footers and file type all need the file.

**Not written, and why**
- **Hidden instructions to a screener, and a 1pt keyword block.** Refused for the reasons at the top.
- **"SQL" or "SQL-literate" anywhere.** Your own words rule it out. A line that gestures at it, such as "data-driven" or "analytics expert", is the same claim in softer words.
- **"Marketo".** You haven't named it, and the JD says "HubSpot or Marketo".
- **"Managed a $600k budget".** "Managed" is the JD's word. Yours is "controlled", and it stays.
- **"Owned demand generation".** You ran the channels. "Own" is the JD's verb.
- **"5+ years of demand generation".** Your 6 years are B2B SaaS marketing, and C2 is what would support the stronger claim.
- **"Senior Marketing Manager", or any title upgrade.** Your title is Marketing Manager.
- **Anything on content distribution.** It stays out unless C1 is confirmed.

**Upgrade menu**
- **The resume as a file (.docx or text PDF).** This lets me run the parse-safety checks and flag any hidden text a template or earlier tool added without your knowing.
- **A HubSpot export or ad-platform spend report.** It would back up the $600k figure, since right now it's your word only.
- **A webinar platform report.** It would back up the 300-registrant average.
- **A HubSpot workflow list.** It would back up the 12 flows.
- **Offered extra: a two-sentence summary** built only from your existing sentences, with its own approval row. It would put the strongest evidence first for a reader who stops early.

To approve, reply in the form "Approved: E1, E2, E3, E4" and add anything you reject.

**Questions**
C1 — Have you ever been responsible for distributing content, for example promoting webinar recordings or gated assets through email, or running a newsletter or syndication channel? If so, what and how often?
C2 — Of your 6 years, about how many were spent running paid, lifecycle email or webinars, as opposed to other marketing work?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.