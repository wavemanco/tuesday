I read the dossier excerpt. Its `role_profile` is present, so I took the role from your message and from the dossier's judgments. This is the edit ledger only. Nothing is applied, and every row is pending your approval.

Your CV reached me as pasted prose, so I can't see its layout. "Current line" below is your sentence as written. If a line already stands alone on your CV, that row drops out.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | *(unchanged wording, on its own line)* | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; inherited from dossier edit E1 and re-audited | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged — moved to the first bullet under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged — moved to the third bullet, after E2 and E1)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged — moved from the end of the CV to directly under the role bullets)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |

- **E1** is the dossier's drafted edit. I re-checked it against your current wording, and "the whole team" stays as your scope.
- **E3** keeps "collecting client feedback for product" exactly. It does not become "informed" or "shaped the roadmap".
- **E4** moves a line and nothing more. "Comfortable in" does not become "authored" or "owned".
- **No title row.** I haven't proposed any change to your "solutions engineer / implementation lead" title. Nothing equivalent to a PM title exists.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years as a PM | must-have | `not_evidenced` | The dossier already rated this adjacent (transferability), and I inherit that. Integration leadership and the roadmap-input sessions are adjacent. Roadmap ownership and prioritisation authority are not evidenced. E3 raises the sessions but claims no PM years. See C1. | `[grounded]` CV and dossier |
| 2 | Shipped API or platform products | important | `not_evidenced` | The dossier rated this adjacent. You led integrations of your employer's REST APIs, which is a different job from shipping them. E2 raises that work without relabelling it. See C2. | `[grounded]` CV and dossier |
| 3 | Technical fluency | important | `surfaced_by_edit` | E2, E4 | `[grounded]` CV |
| 4 | Stakeholder management | important | `surfaced_by_edit` | E2, E3 | `[grounded]` CV |
| 5 | Owning the partner API roadmap | important | `not_evidenced` | Only the feedback-collection side is on your CV. See C1. | `[grounded]` CV |
| 6 | Specs, and delivery with two engineering squads | important | `not_evidenced` | Nothing on your CV shows specs written or squads worked with. See C2. | `[grounded]` CV |
| 7 | Adoption metrics | important | `not_evidenced` | Nothing on your CV mentions adoption or usage measures. See C3. | `[grounded]` CV |

## Recovery per gap

| # | Requirement | Priority | What your CV currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM; roadmap ownership | must-have | You ran quarterly sessions that collected client feedback "for product". It doesn't say what you decided or prioritised. | This is the must-have, and the CV currently shows input to a roadmap rather than ownership of one. | Choosing which client requests went to product; ranking or scoping them; being asked to justify a priority; a feature that shipped because of your sessions | A session summary, a ranked request list, a product ticket you filed | `[grounded]` what the CV says; `[generic]` that PM postings usually screen first on roadmap and prioritisation evidence |
| C2 | Shipped API products; specs and squad delivery | important | You integrated clients onto your vendor's REST APIs and are "comfortable in" OpenAPI specs. No spec authorship or engineering partnership is stated. | The role is spec-and-delivery work, and the CV currently shows the consumer side of an API. | Writing or editing an OpenAPI spec the vendor shipped; a client-driven API change you carried to engineering; testing a release before launch | An OpenAPI file or diff, a ticket thread, release notes | `[grounded]` what the CV says; `[generic]` that API-platform PM roles weigh the producer side |
| C3 | Adoption metrics | important | Nothing on adoption or usage. | The JD asks you to define adoption metrics, and this is the thinnest area. | Tracking time-to-integrate or integrations live per client; a SQL query on API usage; a success measure you set for the playbook | A query, a dashboard screenshot, a client-by-client tracker | `[grounded]` what the CV says; `[generic]` that adoption is a core deliverable for a platform PM |

## Not written, and why

- **"Built an internal request-triage tool."** This is from the dossier's `rejected_inferences`. It was a memory lead and you could not confirm ownership.
- **"Has been the customer of a partner API platform."** Also from `rejected_inferences`. You worked vendor-side.
- **"3+ years of product management experience."** You have never held the title, and the roadmap-input sessions were feedback collection.
- **"Shipped API products."** You led integrations of the vendor's APIs, which is not the same work.
- **"Ran discovery with integration partners."** This is the JD's wording. Your sessions were with clients, collecting feedback for product, so the word change would move which side of the table you sat on.
- **"Owned" or "shaped the product roadmap."** Your sentence says you collected input, and no roadmap authority is evidenced.
- **"Wrote or authored OpenAPI specs."** Your line says "comfortable in", which does not establish that you wrote any.
- **"Partnered with engineering squads" or "defined adoption metrics."** Nothing on your CV supports either.

## Parse-safety check

I could not run these checks because I received prose rather than a file: multi-column layout, tables and text boxes, images and icons, headers and footers, section headings, and file type. Send the file and I'll run them. Nothing here uses hidden text, and I wouldn't add any.

## Upgrade menu

- Answers to C1–C3 would turn `not_evidenced` rows into traceable ones.
- Work samples such as a playbook excerpt, an OpenAPI spec you worked on, or a roadmap-session summary would add `[grounded]` rows.
- Your actual CV file would let the parse-safety check run.
- Offer, not built unless you approve: a two-sentence summary made only from your existing sentences. It would add a strongest-evidence-first opening for a screener.

## Questions

C1 — Did you decide which client requests went to product or in what order, or did you only pass the feedback along? Give one concrete example if you did.
C2 — Have you written or edited an API spec, or taken a client-driven API change to engineering, that the vendor then shipped?
C3 — Did you ever track or measure how clients adopted the APIs, for example time-to-integrate or integrations live?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.