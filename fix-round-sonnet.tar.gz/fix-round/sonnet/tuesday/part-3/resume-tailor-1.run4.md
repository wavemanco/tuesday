I've built a tailoring ledger from what you pasted. Nothing is applied yet. I only had your summary text, not the CV file, so each "Current line" is your own sentence as you wrote it, and every quote in "Traces to" is verbatim.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `already_evidenced` | "Senior Software Engineer, 7 years." says software engineer, not backend. I read it as backend because of the services you own. That is an assumption. | `[grounded]` |
| R2 | Production Go | must-have | `surfaced_by_edit` | E5 puts "Go and Rust daily for 4 years" up top. Your sentences don't say the three services are written in Go, or use the word "production". See question R2. | `[grounded]` |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | Kafka and Postgres are only listed as tools, and nothing describes how your services interact. Adjacent work exists; see C1. | `[grounded]` |
| R4 | Strong incident response | must-have | `surfaced_by_edit` | E3 | `[grounded]` |
| R5 | Experience mentoring | must-have | `surfaced_by_edit` | E4 carries your onboarding and pairing, in your words. It does not say "mentor", and your sentence doesn't say the hires are mid-level. | `[grounded]` |
| R6 | Drive down p99 latency | important | `surfaced_by_edit` | E1 | `[grounded]` |
| R7 | Own services handling high request volume | important | `surfaced_by_edit` | E2 | `[grounded]` |
| R8 | Own on-call for your services | important | `surfaced_by_edit` | E3, which keeps your rotation wording as it is | `[grounded]` |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material; see C2. | `[grounded]` |

## Edit ledger — resume_edits_pending_approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged — moved to the first bullet under your current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged — moved to the second bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E4 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV | pending your approval |
| E5 | Summary | "Senior Software Engineer, 7 years." | "Senior Software Engineer, 7 years. Currently at a payments company. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV | pending your approval |

I kept E5 as three separate sentences. Joined into one clause, it would read as "7 years of Go and Rust", which you didn't say.

## Gaps and recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | Three services in a ledger pipeline, one at about 40k requests/minute at peak, and Kafka and Postgres in a tools list. It doesn't say how the services coordinate or what you decided about it. | The posting lists it as a requirement, and your lines currently leave it implied. | A consistency or idempotency decision across your ledger services; a Kafka replay or rebalance you handled; a Postgres replica-lag or partitioning call; a failover you designed or ran | An architecture or design doc, a throughput dashboard, an incident postmortem | `[grounded]` what the resume does and doesn't say; `[generic]` what this costs on applications of this kind |
| C2 | Partner with product on roadmap sequencing | important | Nothing in your material touches product or roadmap work. | The posting lists it among the role's duties. | Sequencing the cache rework against feature work; trading off scope or deadlines with a product manager; helping plan a quarter | A roadmap doc, a planning ticket, an RFC you wrote or commented on | `[grounded]` what the resume does and doesn't say; `[generic]` what this costs on applications of this kind |

If nothing true fits C2, say so. Then the honest closing path is to drop the requirement from your pitch for this role, not to word around it.

## Not written, and why

- "Mentored mid-level engineers": you onboard new hires and pair for a month. That is related work, but the posting's wording is different, and your sentence doesn't give their level.
- "Production Go services": you said Go and Rust daily, not which language the three services use.
- "Owned on-call for your services": you did a rotation every fourth week, which doesn't say the services were yours.
- "Designed and shipped" the services: you wrote "own", not "design" or "ship".
- "Distributed systems at scale" or "high-volume": these are the posting's words. Your 40k requests/minute stays as you stated it.
- "Kafka", "Postgres" and the other tools as owned experience: a tool in a list is not a tool you owned.
- "Partnered with product on the roadmap": nothing supports it.
- "Led incident response": you ran six incidents as incident commander, which is not leading a practice.

## Parse-safety check

You pasted text, so I couldn't check layout. That means columns, tables, text boxes, headers and footers, images, section headings and file type are all unchecked.

## Upgrade menu

- **Your actual CV file:** this lets me run the parse check, quote your real lines, and find cut candidates. I have no cut rows because I haven't seen the rest of the document.
- **Answers to C1 and C2:** a confirmed answer can turn a `not_evidenced` row into a real ledger row.
- **An artifact for the p99 work:** a design doc or dashboard screenshot would let me raise that evidence from `medium` to `high`.

## Questions

C1 — How do your three ledger services depend on each other, and what did you decide about consistency or failure handling between them?
C2 — Have you worked with a product manager on sequencing or scope, and if so, what was the decision?
R2 — Are the three services you own written in Go, Rust, or a mix?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.