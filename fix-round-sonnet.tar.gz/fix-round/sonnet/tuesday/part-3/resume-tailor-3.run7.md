I'm tailoring your CV to the Quartzline role. I've read the resume-tailor playbook and your dossier, and this is the full edit ledger. Nothing is applied until you approve it.

I'm using the dossier's role profile and evidence map. Your CV came as a prose summary, not a file, so the "Experience" and "Skills" section labels below are my assumption. Dossier rows keep their confidence: R1 and R2 are both `medium`, and tailoring doesn't raise that.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." (as its own line, wording unchanged) | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV; this is the dossier's pending edit E1, re-audited against your sentence as it stands now | pending your approval |
| E2 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | "Ran quarterly roadmap-input sessions collecting client feedback for product." (moved to second, after the integrations line) | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E3 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." (own line, directly under the integrations and roadmap-input lines) | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |
| E4 | Experience | "7 years solutions engineer / implementation lead at an enterprise software vendor." | "Solutions Engineer / Implementation Lead (client API integrations), enterprise software vendor, 7 years" | `retitle` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |

- **E1** was already drafted in the dossier. I re-checked it against your wording and it still traces. The playbook is your strongest written artifact and should stand alone.
- **E2** only changes position. The verb stays "Ran", with no "owned" or "led".
- **E3** keeps your "Comfortable in". It doesn't become "fluent" or "expert", and it doesn't claim the posting's "technical fluency" for you.
- **E4** adds a parenthetical that is a plain description of your integration work, not a new title. It doesn't say "Product" or "Platform".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM | must-have | `not_evidenced` | Matches the dossier's R1 (`adjacent`, `transferability`). E1 and E2 show adjacent work only. Roadmap ownership and prioritisation authority aren't evidenced, and you never held a PM title. | `[grounded]` dossier R1 and your CV |
| 2 | Shipped API or platform products | must-have | `not_evidenced` | Matches the dossier's R2 (`adjacent`). Leading 30+ integrations of your vendor's REST APIs is working with an API product, not shipping one. | `[grounded]` dossier R2 and your CV |
| 3 | Technical fluency | important | `surfaced_by_edit` | E3, with E4 giving context. Evidence is limited to the tools you listed and the integration work. | `[grounded]` your CV |
| 4 | Stakeholder management | important | `surfaced_by_edit` | Partial: E2 and E4. Your CV shows clients and product, not a stated stakeholder role. | `[grounded]` your CV |
| 5 | Run discovery with integration partners | responsibility | `surfaced_by_edit` | Partial: E2. Your sessions were with clients of your vendor, not partners building on a platform you owned. | `[grounded]` your CV |
| 6 | Own the roadmap | responsibility | `not_evidenced` | See C1. | `[grounded]` your CV |
| 7 | Write specs and drive delivery with engineering squads | responsibility | `not_evidenced` | See C3. OpenAPI is listed as a tool, not as spec-writing. | `[grounded]` your CV |
| 8 | Define adoption metrics | responsibility | `not_evidenced` | See the named absence below. | `[grounded]` your CV |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Own the roadmap and prioritisation | must-have | Roadmap input collected from clients. It doesn't say what happened to it, or who decided. | Roadmap ownership is the core of the role, and the dossier flagged prioritisation authority as not evidenced. | A feature or fix you got prioritised and the reason it won; a trade-off you argued with product; a roadmap item that exists because of your sessions | A product ticket, a roadmap doc or slide, a note crediting your input | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Shipped API or platform products | must-have | Integrations of existing APIs. Nothing says you built or released one. | The posting says "shipped", and a reader will look for a launch. | An endpoint, SDK, sandbox, webhook or integration template you specified or released; a client-facing tool you shipped | A launch note, release notes, a changelog entry, a docs page | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Specs and delivery with engineering | important | OpenAPI is listed as a tool. No spec, handoff or delivery is described. | The role runs delivery with two squads. | A spec or requirements doc engineering built from; a bug or change you drove through to release; work with an engineering team on an API change | A spec, a ticket thread, a release note | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

**Named absence: adoption metrics.** Your CV has nothing on defining or tracking adoption. Closing it would take a real example, such as client time-to-first-API-call, or integrations live versus started. If you tracked something like that informally, tell me and it goes through the confirmation card. If you didn't, this stays a gap you'd cover as an interview answer. It doesn't get a resume line.

## Not written, and why

This list carries over the dossier's rejected inferences unaltered, plus what the posting invites.

- "Built an internal request-triage tool". This was a memory lead and you couldn't confirm you owned it. It is not in the ledger and won't be unless you confirm it.
- "Has been the customer of a partner API platform". You worked vendor-side. This is a relationship inversion.
- "3+ years of product management experience" or any PM title. You've never held one, and the dossier records the gap as `transferability`.
- "Owned the roadmap" or "set priorities". You collected input, and no sentence of yours says who decided.
- "Shipped API products". You led integrations of your vendor's APIs, which isn't the same work.
- "Partnered with integration partners". Your word is "client", and the swap would change which side of the table you stood on.
- "Drove delivery with engineering squads" and "defined adoption metrics". Nothing in your CV says you did either.

## Parse-safety check

The CV arrived as pasted text, so I couldn't check layout, columns, tables, headers and footers, or file type. Send the file and I'll run those. Your section headings can't be assessed either, because I only have the prose.

## Upgrade menu

- **Your actual CV file:** unlocks the parse-safety checks, and lets me replace my assumed section labels with your real ones.
- **A spec, launch note, roadmap doc or release note** (any one): the artifact that would raise R1 or R2 from `medium`, and turn C1–C3 into rows.
- **A prior CV version:** may hold bullets this one dropped.

Questions (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

- C1: Did any of the feedback from your roadmap-input sessions end up as a prioritised product change, and what was your part in that decision?
- C2: Have you specified or released anything customers or partners called through, such as an endpoint, SDK, sandbox or template?
- C3: Have you written a spec or requirements doc that engineering built from?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.