I tailored your CV to the Tessellate role as a ledger of proposed edits. Nothing is applied yet. I worked from your prose summary, which I treat as self-report, and found no `tuesday-dossier.md`. Every row quotes your own sentence word for word, and none adds a claim.

## The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Own three services in our ledger pipeline — one handles about 40k requests/minute at peak. Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `merge` | "Senior Software Engineer, 7 years."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV summary | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged — moved to the first bullet under your current role)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged — moved to the second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | *(unchanged — moved to the third bullet)* | `reorder` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | *(unchanged — moved to the fourth bullet)* | `reorder` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV | pending your approval |
| E6 | Skills | "Go and Rust daily for 4 years, Python before that." | *(unchanged wording — promoted to its own first line in Skills, above the tools list)* | `surface` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your CV | pending your approval |

Two things about how I wrote these:
- The rows only change order and emphasis, so most of them are `reorder` with unchanged wording. I can't see your current layout, so "moved to" means relative to the order I'd guess from your summary.
- I kept "7 years" attached to "Senior Software Engineer". Your CV doesn't say "backend", so I haven't written "7 years backend".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | already_evidenced | "7 years" is in E1. Your CV says "Senior Software Engineer", not "backend", and I added nothing. | `[grounded]` |
| R2 | Production Go | must-have | surfaced_by_edit | E6 puts Go first. Your CV doesn't say the three services are written in Go, so no line claims it (see question R2). | `[grounded]` |
| R3 | Services at high request volume | must-have | surfaced_by_edit | E1 and E2 lead with the 40k requests/minute figure. | `[grounded]` |
| R4 | Distributed systems at scale | must-have | not_evidenced | Kafka and gRPC appear only in a tools list. Gap C1 below. | `[grounded]` what your CV says; `[generic]` a tool named is not a system described |
| R5 | Strong incident response | must-have | surfaced_by_edit | E4 | `[grounded]` |
| R6 | Experience mentoring | must-have | surfaced_by_edit | E5. Your line describes onboarding new hires with a month of pairing. It doesn't say the hires were mid-level, and it doesn't use "mentor". | `[grounded]` |
| R7 | Drive down p99 latency | important | surfaced_by_edit | E1 and E3 | `[grounded]` |
| R8 | Own on-call for your services | important | surfaced_by_edit | E4. You state a rotation every fourth week. Your CV doesn't say it covers your three services. | `[grounded]` |
| R9 | Own services | important | surfaced_by_edit | E2. "Own" is yours. "Design and ship" isn't in your CV (see the not-written list). | `[grounded]` |
| R10 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in your CV touches product planning. Gap C2 below. | `[grounded]` what your CV says |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | A ledger pipeline of three services, one at about 40k requests/minute, plus Kafka and gRPC in a tools list. It doesn't say how either is used or how the services depend on each other. | It's a must-have, and a tools list alone doesn't show you owned the system. | A Kafka consumer or producer you own, with ordering, retry or replay concerns; a gRPC contract between services you changed safely; a cross-service failure such as duplicate or out-of-order messages that you fixed | A design doc, an incident postmortem, an architecture diagram, a dashboard | `[grounded]` what the resume says and omits; `[generic]` a must-have with only a tools-list mention is thinly supported |
| C2 | Partner with product on roadmap sequencing | important | No mention of product, planning or prioritisation. | It's one of the JD's named responsibilities, and nothing on the page answers it. | Reordering or pushing back on a request because of ledger constraints; an estimate that changed a launch order; taking part in quarterly planning for the pipeline | A planning doc, an RFC, an epic or ticket thread | `[grounded]` what the resume says; `[generic]` what an unanswered responsibility costs on an application like this |

If neither gap has a real example behind it, the honest position is that R4 and R10 stay open and the CV is strongest on R1 to R3 and R5 to R9. I won't write lines that gesture at them.

## Not written, and why

- **"7 years backend"**: your CV says 7 years as a Senior Software Engineer. "Backend" is the JD's word, not yours.
- **"Production Go services handling 40k requests/minute"**: your CV doesn't say the three services are written in Go. Go and Rust are listed separately.
- **"Designed and shipped"** the services: you say you "own" them. Design and shipping are different claims, and an interviewer will ask what you designed.
- **"Mentored mid-level engineers"**: you onboard new hires and pair with them for a month. That is a different kind of work, and the hires' seniority isn't stated.
- **"Owned on-call for my services"**: you state a rotation. The rotation covering your three services is an assumption.
- **"Distributed systems"** or "event-driven architecture": Kafka and gRPC are in a tools list only. A tool listed is not a tool owned.
- **"Partnered with product on the roadmap"**: nothing in your CV supports it.
- **"Reduced latency on a high-throughput caching platform"** or anything echoing build-cache: your cache layer was on the balance-read path, which is different work from a build cache.
- **Incident outcomes** such as "reduced MTTR" or "improved reliability": you gave none, so none are written.

## Parse-safety check

You pasted text rather than a file, so I couldn't run any of these checks: multi-column layout, tables or text boxes, icons and skill bars, content in headers or footers, non-standard section headings, file type, or hidden text from a template. Send the file and I'll run them.

## Upgrade menu

- **Your actual CV file**: it lets me run the parse checks and quote your real lines instead of my reading of your summary.
- **The dashboard or write-up behind 380ms to 95ms**: it makes the headline number inspectable.
- **An incident postmortem you commanded**: it backs the incident-response claim with an artifact.
- **A design doc or architecture diagram for the ledger pipeline**: it would close C1 if the evidence exists.

## Questions

- **R2**: Which language are the three ledger-pipeline services written in: Go, Rust, Python, or a mix?
- **C1**: How do Kafka and gRPC figure in the services you own, and what happens when they fail or reorder?
- **C2**: Have you ever worked with product to decide what gets built first, or to push back on a request?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.