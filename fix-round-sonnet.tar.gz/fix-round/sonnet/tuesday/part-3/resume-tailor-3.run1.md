I've built the tailoring as an edit ledger, not a rewritten CV. Nothing is applied yet. You pasted an excerpt of the dossier, so I worked from that. Your CV came as summary sentences, so I treated each as a line on your CV and quote it exactly. I'm using the dossier's `role_profile`, `evidence_map` rows R1 and R2, the pending edit E1, and the two rejected inferences. The dossier is for this same role, so nothing in it is stale. Your CV text carries no PM title and no roadmap-ownership claim, so none of the rows below add one.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | *(unchanged text, as its own separate line)* | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` cv, inherited from dossier E1 and re-audited against your sentence | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged — moved to the first line under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` cv | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged — moved directly after the playbook line)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` cv | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged — moved from its current position up beside the role, as its own line)* | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` cv | pending your approval |
| E5 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` cv | pending your approval |

- **E1** comes from the dossier. The wording stays yours, including "the whole team uses". I did not widen that to company-wide.
- **E3 stays a reorder.** The sessions collected feedback, so the line does not become "owned the roadmap".
- **E4 stays "Comfortable in".** That is a tool you are comfortable with, not a spec-writing claim.
- **E5 is two sentences, not one.** Joining them into one clause would make "end to end" sound like your role scope.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 3+ years PM | must-have | `not_evidenced` | Inherits the dossier's R1 call: adjacent, transferability gap, medium confidence. E1–E3 show the nearest work, but no PM title or roadmap ownership is evidenced. See C1. | `[grounded]` cv and dossier R1 |
| M2 | Shipped API or platform products | important | `not_evidenced` | Inherits R2: adjacent, medium confidence. "Led 30+ client integrations of our REST APIs end to end." is integration work, not shipping a product. See C2. | `[grounded]` cv and dossier R2 |
| M3 | Technical fluency | important | `surfaced_by_edit` | E2, E4 | `[grounded]` cv |
| M4 | Stakeholder management | important | `surfaced_by_edit` | E2, E3. Your CV shows client-facing delivery and feedback sessions but no cross-functional wording. | `[grounded]` cv |
| M5 | Run discovery with integration partners | important | `surfaced_by_edit` | E3. It is client feedback collection, not partner discovery. | `[grounded]` cv |
| M6 | Own the roadmap for the API platform | important | `not_evidenced` | The roadmap-input sessions feed product, and nothing shows you deciding the roadmap. See C1. | `[grounded]` cv |
| M7 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | OpenAPI familiarity is not spec authorship, and no squad work appears. See C2. | `[grounded]` cv |
| M8 | Define adoption metrics | important | `not_evidenced` | Nothing about usage or adoption measurement appears. See C3. | `[grounded]` cv |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Roadmap ownership and prioritisation (M1, M6) | must-have | Quarterly sessions that collect client feedback for product. It does not show who decided what went on the roadmap. | The dossier names prioritisation authority as the unevidenced part of the must-have, so this is the row that could move it. | A client request you argued for and saw prioritised; a trade-off you made between two integration asks; a playbook change that altered what the product team built | A roadmap-input summary, a ticket or request with its outcome, a deck from a session | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Shipped API or specs, and delivery with engineering (M2, M7) | important | Integrations of your vendor's existing APIs. No API feature, spec or engineering delivery is stated. | The role asks you to write specs and drive two squads, and the CV shows you consuming a finished platform. | An API change or endpoint you specified that shipped; an OpenAPI spec you wrote or edited; a fix you pushed through engineering | A spec, a changelog or release note entry, a pull request or ticket link | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Adoption metrics (M8) | important | No usage, adoption or success measure appears. | The role requires you to define adoption metrics, so an absent measure reads as a gap. | Time-to-first-call across your 30+ integrations; integrations live versus started; usage you tracked per client | A dashboard, a report or a SQL query you used | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

**Named absence: two engineering squads.** You have not worked inside a delivery squad as its product owner, and the JD makes that part of the job. What would close it is work with engineering that you directed, which C2 may surface. If C2 comes back empty, the honest position is that this part of the role is a stretch.

## Not written, and why

These come in two groups. The first two are your rejected inferences from the dossier, carried over with their original reasons. The rest are claims the JD invites and the evidence cannot support.

- "Built an internal request-triage tool" — a memory lead you could not confirm ownership of. Staying out, and not re-entering in other words.
- "Has been the customer of a partner API platform" — you worked vendor-side, so this would flip which side of the table you sat on.
- "Product Manager" or "3+ years of product management" — you never held the title, and the JD makes it a must-have.
- "Owned the API roadmap" or "set priorities" — your sessions collected input for product, and the CV does not say you decided anything.
- "Shipped API products" — you led integrations of an API your company had already built.
- "Partnered with integration partners" — the JD says "partners" and your CV says "client". It is the JD's word for a different relationship.
- "Wrote specs" or "defined adoption metrics" — "Comfortable in Postman, SQL, OpenAPI specs" is a tool familiarity line, and no metric work appears.
- "Drove delivery with engineering squads" — no squad work appears anywhere on your CV.

## Parse-safety check

I could not run any of the checks (multi-column layout, tables and text boxes, images or skill bars, contact details in headers or footers, non-standard headings, file type), because your CV arrived as pasted text, not a file. Send the actual file and I'll run them.

## Upgrade menu

- **The full CV as a file.** I'd get your real bullet wording, can propose `cut` rows for lines that don't serve this role, and can run the parse-safety check.
- **Artifacts.** The integration playbook, a roadmap-input summary, an OpenAPI spec you edited, or an integration-success report would each support the rows above. They could move the M1, M2 or M8 evidence up from medium confidence.
- **Earlier CV versions.** They sometimes hold details that were dropped from the current one.

## Questions

C1 — Did any client feedback from your roadmap-input sessions end up deciding what product built, and was your recommendation the thing that moved it?
C2 — Have you written or edited an API spec, or pushed a change through engineering that shipped?
C3 — Did you track anything across your 30+ integrations that worked like adoption, such as time to first call or integrations live?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.