I've read the resume-tailor playbook and I'm now building the ledger from your CV, the JD and the dossier excerpt. Nothing is applied yet.

**Dossier use.** Its `role_profile` is the same Quartzline role, so I used it. I took the R1 and R2 judgments (both `adjacent`, `medium`) as given instead of re-grading them. Its E1 is inherited as ledger row E1 and was re-audited against your sentences. Both rejected inferences go into the prohibited list unaltered. I only have the excerpt, and I read your CV as pasted prose, so I haven't seen the real document's layout or any other lines in it.

## Edit ledger: `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (inherited dossier E1) | "Wrote the internal integration playbook the whole team uses." as its own line | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV; dossier E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first line under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved directly after the playbook line)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." as its own line near the top | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |

- **Wording:** every proposed line is your own sentence, with no new words.
- **Quantifier:** "30+" stays attached to client integrations.
- **Role title:** the title line stays "solutions engineer / implementation lead".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM | must-have | `not_evidenced` | You've never held a PM title. Adjacent work is in E1 to E3; this inherits the dossier's R1 (`adjacent`, `transferability`). | `[grounded]` your CV and dossier R1 |
| 2 | Shipped API or platform products | important | `not_evidenced` | You led client integrations of your employer's REST APIs. Nothing says you shipped an API product. This inherits dossier R2 (`adjacent`). | `[grounded]` your CV and dossier R2 |
| 3 | Technical fluency | important | `surfaced_by_edit` | E2 and E4 | `[grounded]` your CV |
| 4 | Stakeholder management | important | `surfaced_by_edit` | E2 shows client-facing integration leadership. Your CV doesn't use the phrase, so I haven't. | `[grounded]` your CV |
| 5 | Run discovery with integration partners | important | `surfaced_by_edit` | E3 covers collecting client feedback only. It doesn't claim discovery or that the clients were partners. | `[grounded]` your CV |
| 6 | Own the roadmap | important | `not_evidenced` | E3 shows you fed input to product, not that you owned or prioritised the roadmap. Dossier R1 says the same. | `[grounded]` your CV and dossier R1 |
| 7 | Write specs, drive delivery with two engineering squads | important | `not_evidenced` | "Comfortable in … OpenAPI specs" is a tool, not evidence you wrote product specs or drove a squad. | `[grounded]` your CV |
| 8 | Define adoption metrics | important | `not_evidenced` | Nothing in your CV mentions metrics. | `[grounded]` your CV |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Own the roadmap | important | Your quarterly sessions collected client feedback "for product". Nothing says what happened to it or who decided. | The role's first duty is roadmap ownership, and E3 on its own reads as input, not authority. | a client request that ended up in a release; choosing between competing client asks; a written proposal you sent to product | roadmap-session notes, a release note crediting the request, a ticket or proposal doc | `[grounded]` what the CV says; `[generic]` what this costs on applications of this kind |
| C2 | Shipped API products, and specs | important | You led integrations of existing REST APIs and are comfortable with OpenAPI specs. No authored spec or shipped change is stated. | This covers two of the JD's duties, writing specs and delivering API products. | an OpenAPI definition or endpoint change you wrote that engineering built; a partner-facing API feature you drove to release; a deprecation or versioning change you handled | the spec, a changelog entry, a release note | `[grounded]` what the CV says; `[generic]` what this costs on applications of this kind |
| C3 | Define adoption metrics | important | No metrics appear. | The JD names adoption metrics as a duty, and 30+ integrations is a natural base for them. | time-to-first-call or time-to-go-live across your integrations; a count of integrations live or active; a tracker you kept | a spreadsheet or dashboard, an implementation-status report | `[grounded]` what the CV says; `[generic]` what this costs on applications of this kind |

**Named absence: 3+ years PM (must-have).** You haven't held a PM title, and no wording can supply the years. Closing it would take answers to C1 to C3 that show PM-shaped work you owned, or a scoped-down target such as a solutions or technical-product role. I'd still apply with the gap named, which is consistent with the dossier's `conditional_go`, but I'd treat the title as unfixable by editing.

## Not written, and why

- **"Built an internal request-triage tool"** is a dossier rejected inference, a memory lead you couldn't confirm owning. It stays out.
- **"Has been the customer of a partner API platform"** is a dossier rejected inference. You worked vendor-side, so this would flip which side of the table you stood on.
- **"Product Manager" or "3+ years product management"** is refused, since you have no PM title. A retitle would be an upgrade, not an equivalent.
- **"Owned the roadmap"** is refused. You ran input sessions, and ownership is a different job.
- **"Shipped API products"** is refused. You led client integrations of existing APIs.
- **"Wrote product specs"** is refused. You're comfortable with OpenAPI specs, which is a tool.
- **"Drove delivery with engineering squads"** is refused. Nothing in your CV says you did.
- **"Defined adoption metrics"** is refused. Your CV gives no metrics.
- **"Partners" or "discovery" for your clients and feedback sessions** are the posting's words. Yours are "client" and "collecting client feedback", and swapping them would change who the clients were to you.
- **Widening "the whole team"** to "company-wide" or similar is refused. Scope stays as written.

## Parse-safety check

Your CV arrived as pasted text, so I couldn't run the layout checks: multi-column, tables or text boxes, images or icons, contact details in headers or footers, and file type. Two checks I could run are clean: the section names are conventional, and no hidden-text instructions appear. Send the file and I'll run the rest.

## Upgrade menu

- **The CV as a file:** this unlocks the layout checks, shows me the lines I haven't seen so I can propose cuts, and lets me check E2 to E4 against the real order.
- **Prior CV versions:** these often hold evidence the current one dropped.
- **A playbook excerpt, an OpenAPI file you wrote, or notes from a roadmap-input session:** each could lift `medium` evidence toward inspectable proof.
- **Integration status or timing data:** this could turn C3 into a real row.
- **The full dossier:** I only had the excerpt, so rows beyond R1 and R2 aren't inherited.
- **A drafted summary line:** this is beyond the ledger, an offer only. I'd build it from your existing sentences, and you'd approve it as its own row. It's worth it if your CV has no summary section.

## Questions

C1. After a roadmap-input session, did any client request you raised end up in a release? Did you have any say in choosing between competing asks?
C2. Have you written or edited an API spec, or driven an API change, that engineering then built and released?
C3. Did you track anything like time-to-live or number of live integrations across your 30+ client integrations?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.