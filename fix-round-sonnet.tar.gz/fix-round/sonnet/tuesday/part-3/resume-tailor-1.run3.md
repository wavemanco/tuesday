I've tailored your CV as an edit ledger: five proposed changes, nothing applied yet. Every row quotes your own sentence. I only had your text, not the CV file, so "Current line" quotes your message verbatim. Check each quote against the CV before approving.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `merge` | "Senior Software Engineer, 7 years"; "Go and Rust daily for 4 years, Python before that"; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak" | `[grounded]` your CV text | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer" | *(unchanged, moved to the first bullet under your current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer" | `[grounded]` your CV text | pending your approval |
| E3 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander" | "On-call rotation every fourth week for two years. Incident commander on six incidents." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander" | `[grounded]` your CV text | pending your approval |
| E4 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month" | "Onboard new hires on my team, usually two or three a year, pairing with them for their first month" | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month" | `[grounded]` your CV text | pending your approval |
| E5 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust, Python; Kafka, gRPC, Postgres, Datadog, Terraform" | `surface` | "Go and Rust daily for 4 years, Python before that"; "Kafka, Postgres, Terraform, gRPC, Datadog" | `[grounded]` your CV text | pending your approval |

- **E1:** The summary is three of your sentences kept separate.
- **E3:** The split gives the on-call and the incident-commander line one claim each. It does not say the rotation covered your own services, because you didn't say that.
- **E4:** I kept "two or three a year" and "first month".
- **E5:** Go, Rust and Python are pulled from your experience line. The tools keep your wording; I only moved them up.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `already_evidenced` | "Senior Software Engineer, 7 years" is already stated; E1 moves it to the top. The word "backend" isn't in your material and I haven't added it. | `[grounded]` your CV text |
| R2 | Production Go | must-have | `already_evidenced` | "Go and Rust daily for 4 years". Your text doesn't say which language the three services are written in (see question R2). | `[grounded]` your CV text |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | Kafka in the tools list is a tool listed, not a tool owned. Nothing in your text describes distributed-systems work (see C1). | `[grounded]` your CV text |
| R4 | Go services at high request volume | must-have | `surfaced_by_edit` | E1 puts the 40k requests/minute service up front. You say "own", so I haven't written "design" or "ship". | `[grounded]` your CV text |
| R5 | Drive down p99 latency | important | `surfaced_by_edit` | E2 | `[grounded]` your CV text |
| R6 | Incident response and on-call | must-have | `surfaced_by_edit` | E3 | `[grounded]` your CV text |
| R7 | Mentoring | must-have | `surfaced_by_edit` | E4, onboarding and pairing. The seniority of the people you pair with isn't stated. | `[grounded]` your CV text |
| R8 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material (see C2). | `[grounded]` your CV text |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | Kafka in the tools list and a 40k requests/minute service. Nothing says how services coordinate, fail, or stay consistent. | It's a must-have, and a reader has only the tools list to go on. | Kafka producers or consumers you built or owned; handling retries, ordering or duplicate messages across services; a cross-service failure you debugged | A design doc, an incident review, an architecture diagram | `[grounded]` what your text does and doesn't say; `[generic]` that screeners tend to read a tools-list mention as weak evidence |
| C2 | Partner with product on roadmap sequencing | important | Nothing. Your material is all engineering ownership. | It's a named duty, and a gap here reads as engineering-only. | Deciding with product what to build first; pushing back on or re-ordering scope; a tradeoff between a feature and reliability work | A planning doc, a roadmap thread, a launch note | `[grounded]` what your text says; `[generic]` that senior roles of this kind usually expect product partnership |

If you've done neither, the honest path is a named absence. C1 is a must-have, so I'd treat it as the one that matters. C2 is closable only by real experience, and it's a smaller risk. The domain (build-cache and developer tools) isn't in your history either. The JD doesn't list it as a requirement, so I haven't mapped it.

## Not written, and why

- "Designed and shipped high-volume Go services": you say you own them, and the posting's "design and ship" is its wording, not yours.
- "Distributed systems at scale": nothing in your text says this, and 40k requests/minute plus a Kafka listing doesn't carry it.
- "Mentored mid-level engineers": you onboard new hires, and their level isn't stated.
- "Owned on-call for my services": you describe a rotation, not ownership of specific services' on-call.
- "Partnered with product on roadmap sequencing": nothing supports it.
- "Cut p99 latency by 75%": that's a figure I'd compute, not one you wrote. I kept 380ms to 95ms as stated.
- "Kafka/gRPC/Terraform expertise": these are listed tools, not described work.

## Parse-safety check

Not run on layout, since I have pasted text and not the file. I couldn't check for columns, tables, text boxes, icons, or contact details in headers or footers. Send the file (a `.docx` or a text-layer PDF) and I'll check it.

## Upgrade menu

- **Full CV file:** I could add cut proposals for lines irrelevant to this role and run the parse-safety check. Cuts need the lines I haven't seen.
- **Answers to the questions below:** they could convert the gaps into traceable rows.

## Questions

R2 — Are the three ledger services written in Go, Rust, or a mix, and is the 40k requests/minute one in Go?
C1 — Have you built or owned anything involving Kafka or coordination across services (retries, ordering, duplicates, failure handling)? What was yours versus the team's?
C2 — Have you ever worked with product on what to build or sequence first? Any example, however small?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.