Dev, I can't produce a finished rewrite yet, because this skill only applies lines you've approved. What follows is a ledger of proposed edits, each tied to a sentence you wrote. Nothing is applied. I can only reorder and sharpen what's true, so the "3+ years data engineering" must-have shows up below as a gap and isn't written around. You pasted a summary rather than the document, so the "Current line" column quotes your message. I've assumed the section names, and I'll rebuild the real document from whichever rows you approve. Whether this role is worth applying to with that gap is job-underwriter's call, not this ledger's.

## Edit ledger: `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience, Senior Data Analyst | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E2 | Experience, Senior Data Analyst | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved to second bullet)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E3 | Experience, Senior Data Analyst | "I've fixed our nightly dbt job when it breaks and added tests to it." | *(unchanged, moved to third bullet)* | `reorder` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E4 | Experience, Senior Data Analyst | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | Two bullets: "Python (pandas) for analysis" and "Some scripting to pull vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |

- **E1–E3:** these move your three most engineering-shaped lines to the top, as written. "With our then-DE" stays in E2 on purpose, since dropping it would change who did the design.
- **E4:** "some" stays. Each half still traces to your sentence, and neither half says "production".
- **Left alone:** your SQL/Redshift line drops below the three above. I'm not rewording it.
- **Not proposed:** a retitle. "Senior Data Analyst" stays.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Five years as an analyst, no DE-titled role. Adjacent work is in E1–E3. See the named absences below. | `[grounded]` your resume gives analyst years only |
| R2 | Production Python | must-have | `not_evidenced` | E4 surfaces the API-pull scripting, but your sentence doesn't say anything depended on it. See C2. | `[grounded]` what you wrote; `[generic]` "production" is usually probed in screens |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | The nightly dbt job (E3) and the cron scripts (E4) are adjacent. Nothing you wrote shows orchestration. See C1. | `[grounded]` "Never used Airflow or Spark." |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E2, with the DE collaboration stated as you wrote it. | `[grounded]` your message |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E1 (about 25 dbt models, including the orders mart). | `[grounded]` your message |
| R6 | Own data quality | important | `surfaced_by_edit` | E3. The evidence is tests added to one nightly job, not a quality program. | `[grounded]` your message |
| R7 | Own SLAs | important | `not_evidenced` | You fixed the nightly job when it broke, but nothing says there was a deadline or an owner. See C3. | `[grounded]` your message |
| R8 | Partner with analytics on requirements | important | `surfaced_by_edit` | E2 shows one design collaboration, from the analytics side. It's evidence of working with a DE, not of partnering as one. | `[grounded]` your message |
| R9 | Spark (named in the duties) | important | `not_evidenced` | Named absence below. | `[grounded]` "Never used Airflow or Spark." |
| R10 | Streaming experience (Kafka named in the duties) | preferred | `not_evidenced` | Named absence below. | `[grounded]` "Never touched Kafka." |

## Recovery per gap

Each row below has a matching question in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | must-have | A nightly dbt job you repair, and API pulls on a cron. It doesn't say what schedules or sequences them. | This requirement accepts "or equivalent", so what actually runs your jobs decides whether anything here counts. | The nightly dbt job runs from a scheduler such as dbt Cloud; you've edited a DAG owned by the DE; one job waits on another finishing | A screenshot or export of the schedule, a DAG file you edited | `[grounded]` what the resume does and doesn't say; `[generic]` an "or equivalent" clause usually gets a probe |
| C2 | Production Python | must-have | pandas for analysis and some cron scripting. Nothing says anything downstream depended on the scripts. | "Production" is the word that separates analysis scripts from pipeline code. | A dashboard or mart that reads the vendor data your script pulls; retries or failure alerts you added; a script you handed to someone else to run | The script or repo, crontab or alert config | `[grounded]` what the resume does and doesn't say; `[generic]` what this costs on DE applications |
| C3 | Own SLAs | important | You fix the nightly job when it breaks. No deadline, consumer or response expectation is stated. | Ownership of an SLA is a claim you'd be asked to explain in detail. | A report or exec dashboard that had to be ready by a set time; you were the person pinged when the job failed; a documented "fixed by X" expectation | Slack or alert history, a runbook, an incident note | `[grounded]` what the resume does and doesn't say; `[generic]` what this costs on DE applications |

**Named absences (nothing to pull, so nothing is written):**

| # | Requirement | The gap, plainly | What closing it would take | Provenance |
|---|---|---|---|---|
| R1 | 3+ years data engineering | You have 5 years as an analyst and no data-engineering role. Adjacent work exists, but it isn't those years. | About three years of DE-scoped work, or a role that frames itself as an analytics-to-engineering move. If this posting screens the years literally, no wording on the resume changes that. | `[grounded]` your resume gives analyst years only; `[inferred]` literal screening, derived from the posting marking it must-have |
| R9 | Spark | Never used. | A small personal Spark job on a public dataset, shown as a project and never as work experience. It's named in the duties but not in the requirements list, so it's the cheaper gap. | `[grounded]` "Never used Airflow or Spark."; `[generic]` project route |
| R10 | Streaming experience | Never touched Kafka. | A small producer/consumer project you build, shown as a project. The posting calls streaming a plus, so leaving it open is a fair choice. | `[grounded]` "Never touched Kafka."; `[generic]` project route |

## Not written, and why

- **"3+ years of data engineering"**, or any year count that blends your analyst years with DE. Your years are analyst years.
- **Airflow, orchestration, or "orchestrated pipelines"**. You've never used Airflow, and a cron plus a dbt job isn't evidence of orchestration. That stays closed unless C1 turns something up.
- **"Production Python" or "production pipelines"**. You wrote "some scripting to pull vendor APIs on a cron", which says nothing about production.
- **"Built" or "owned" data pipelines, batch pipelines, or ELT**. These are the posting's words. You built dbt models and maintained a nightly job.
- **"Owned data quality" or "SLAs"**. You added tests to one job, and nothing says there was an SLA.
- **"Designed the warehouse" or "designed the star schema" without "with our then-DE"**. Dropping the DE would change what you did.
- **"Partnered with analytics"**. You were the analytics side, and the word would flip which side of the table you stood on.
- **Spark, Kafka or streaming, including a "familiar with" in a skills list**. A tool listed there reads as a tool owned.
- **A Data Engineer or Analytics Engineer title**. That's an upgrade, not an equivalent.

## Parse-safety check

Your resume arrived as pasted text, so I couldn't run these checks: multi-column layout, tables and text boxes, images or skill bars, header/footer contents, non-standard section headings, and file type. I can run them if you send the file.

## Upgrade menu

- **The resume file:** I'd replace my assumed sections with your real ones, quote your actual lines, and run the parse checks above.
- **The dbt project, or its docs and lineage view:** an inspectable repo or model graph would raise the dimensional-modelling and data-quality rows from your self-report toward inspectable proof.
- **The orders-mart schema or ERD:** this is the artifact that would back R4 most directly.
- **The cron script and its alert or log setup:** this could settle C2.
- **The nightly job's schedule, run history or runbook:** this could settle C1 and C3.
- **Offer beyond the ledger:** I can draft a two-sentence top-of-page summary built only from sentences you've already given me. It would give the page a first line stating what the resume supports. I'll build it only if you want it.

## Questions

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C1 — What actually triggers your nightly dbt job (dbt Cloud's scheduler, cron, an Airflow DAG the DE owned), and have you ever edited or sequenced anything in it yourself?
C2 — Did any dashboard, mart or other job depend on the vendor data your cron script pulls, and did you add retries, alerts or logging when it failed?
C3 — When the nightly job broke, was there a time something downstream had to be ready by, and were you the person expected to fix it?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.