Sam, here is the ledger. Nothing is applied yet, and every row is waiting on your approval. I worked from your description rather than the document itself, so the "current line" quotes are your words from your message.

**On the ATS premise.** The one sample I can cite is 25 recruiters interviewed by a résumé-builder vendor, so treat it as thin. In it, "AI/content auto-rejection configured: 8% of recruiters." (cite C25), which is two people. The same source says "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are yes/no form questions about work authorization, licence or location, and nothing in a resume changes them. Match scores mostly set review order: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27). So keywords may matter for ranking, but I can't confirm that keyword filters are what has been rejecting you.

The map below shows a bigger problem than wording. Rows G3, G4, G5, G7, G9, G10, G11, G12, G13 and G14 are `not_evidenced`. Your resume doesn't contain that experience, so rewording can't fix them, and I won't write it in. What I can do is make sure the evidence you do have is findable and leads the page. Whether this role is worth applying to at all is job-underwriter's question, not this ledger's.

## Coverage map

The JD gives no tiers. I weighted by its order and by its closing sentence, "own platform reliability and developer experience".

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| G1 | AWS | must-have | `already_evidenced` | "AWS (EC2, S3, RDS, IAM)" is on the page as written | `[grounded]` your skills sentence |
| G2 | Kubernetes | must-have | `surfaced_by_edit` | E2 and E4. It lands as a proof-of-concept, because your sentence says it "never went to production" | `[grounded]` your PoC sentence |
| G3 | AWS EKS | must-have | `not_evidenced` | C1. Your sentence doesn't say which platform the PoC ran on | `[grounded]` what the resume does not say |
| G4 | Helm | important | `not_evidenced` | C1 | `[grounded]` what the resume does not say |
| G5 | Terraform | must-have | `not_evidenced` | C2. Ansible is config management, and I'm not treating it as infrastructure-as-code | `[grounded]` your Ansible line |
| G6 | CI/CD pipelines | must-have | `surfaced_by_edit` | E1. Your sentence says "deploy pipeline", so the CI side isn't stated | `[grounded]` your pipeline sentence |
| G7 | GitLab CI | important | `not_evidenced` | A1 | `[grounded]` what the resume does not say |
| G8 | Python | important | `already_evidenced` | "Bash and Python scripting" is present. E3 only moves it earlier | `[grounded]` your skills sentence |
| G9 | Go | important | `not_evidenced` | A2 | `[grounded]` what the resume does not say |
| G10 | ArgoCD / GitOps | important | `not_evidenced` | A3 | `[grounded]` what the resume does not say |
| G11 | Prometheus / Grafana / observability | important | `not_evidenced` | C3. Your CloudWatch line is monitoring, and I'm leaving it as monitoring | `[grounded]` your CloudWatch line |
| G12 | Istio / service mesh | important | `not_evidenced` | A4 | `[grounded]` what the resume does not say |
| G13 | Vault | important | `not_evidenced` | A5. IAM is access control, which is a different kind of work | `[grounded]` your IAM mention |
| G14 | SRE practices, platform reliability and developer experience | must-have | `not_evidenced` | C4 | `[grounded]` what the resume does not say |

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to the first bullet in Experience)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your pipeline sentence | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged, moved to the second bullet in Experience)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your PoC sentence | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" | "AWS (EC2, S3, RDS, IAM), Python and Bash scripting, Jenkins, Docker, Ansible for config management, CloudWatch for monitoring" | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" | `[grounded]` your skills sentence | pending your approval |
| E4 | Skills | *(no Kubernetes entry in the skills line)* | "Kubernetes (proof-of-concept only; never went to production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your PoC sentence | pending your approval |

E4 keeps the qualifier in the skills line on purpose. A bare "Kubernetes" would be a tool listed as if you owned it. If you'd rather not carry the qualifier, I'd drop E4 rather than shorten it.

## Not written, and why

- **"Platform Engineer" as your title.** It changes the kind of work you've said you did. Your title stays "DevOps Engineer".
- **"Kubernetes experience" or "Kubernetes in production" without the PoC qualifier.** Your sentence says it never went to production.
- **"CI/CD pipelines" in place of "deploy pipeline".** That's the JD's word for your history, and "deploy pipeline" doesn't say whether the pipeline builds or tests.
- **"Infrastructure as code" or "Terraform".** Nothing you've said covers it. Ansible config management is a different activity.
- **"Observability", "Prometheus" or "Grafana".** You said CloudWatch for monitoring, and nothing else.
- **"Owned platform reliability", "SRE practices" or "developer experience".** You never stated these practices, so writing them would supply them. C4 asks instead.
- **"Managed our Jenkins platform".** You said you maintain about 30 jobs, and that's the extent of it.
- **EKS, Helm, ArgoCD, GitOps, Istio, Vault, GitLab or Go on any line.** Each is a named gap below, not a hedged line.

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes on AWS EKS, with Helm | must-have | One two-month PoC that never reached production. It doesn't say where it ran or what ran on it | The JD names EKS and Helm, and the PoC is your closest evidence | The PoC ran on EKS; you deployed with Helm charts; an app or service of yours ran on it | PoC notes, manifests or charts, a repo, an architecture sketch | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Terraform | must-have | Ansible for config management, and no provisioning tool named | Terraform is the JD's second term, and the gap is visible on one read | Terraform at work, a module you wrote, a personal AWS project, a course lab | A repo, a plan output, a module | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Prometheus / Grafana / observability | important | CloudWatch for monitoring | Two named tools sit under this term | Grafana dashboards on top of CloudWatch, Prometheus in the PoC, a home-lab stack | Dashboard screenshots, alert rules | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C4 | Owning reliability and developer experience | must-have | You built the deploy pipeline and maintain about 30 jobs, with no users, incidents or on-call stated | It's the JD's closing sentence, and the one place your Jenkins work could count directly | Developers who depend on your pipeline; being paged when it breaks; fixing recurring failures; a runbook | A runbook, an incident write-up, a pipeline-usage note | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

## Named absences

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | GitLab CI | You have Jenkins and no GitLab pipeline | Rebuild one real pipeline of yours in GitLab CI on a free project. Then it becomes evidence, though "equivalent to Jenkins" would be my word, not yours | `[grounded]` your Jenkins line; `[generic]` the closing path |
| A2 | Go | Python and Bash only | A small working tool written in Go, kept in a public repo | `[grounded]` your scripting line; `[generic]` the closing path |
| A3 | ArgoCD / GitOps | Nothing in your material | Deploy one app by ArgoCD from a Git repo to a local cluster. This closes only if you do it for real | `[grounded]` what the resume does not say; `[generic]` the closing path |
| A4 | Istio / service mesh | Nothing in your material | Run Istio on a local cluster with two services. For this role it's likely better to leave it as an honest gap than to chase it | `[grounded]` what the resume does not say; `[generic]` the closing path |
| A5 | Vault | Nothing in your material; IAM isn't secrets management | Stand up Vault in dev mode and wire one app's secret to it | `[grounded]` your IAM mention; `[generic]` the closing path |

## Parse-safety check

I can't open your file, so this reports what your description implies. It is not a layout verdict.

| Check | Your resume, as you describe it | What it costs | Provenance |
|---|---|---|---|
| Multi-column layout | `[grounded]` two columns, made in Canva | `[generic]` a parser reading linearly can interleave the columns, and dates can detach from their roles | `[grounded]` your description; `[generic]` the failure mode |
| Icons for skills | `[grounded]` an icon for each skill | `[generic]` anything carried only by an icon is absent. A skill name written as text beside an icon survives | `[grounded]` your description; `[generic]` the failure mode |
| Contact details in the header | `[grounded]` header placement | `[generic]` header content is often treated as page furniture and discarded, so you may arrive with no contact details | `[grounded]` your description; `[generic]` the failure mode |
| File type | `[grounded]` a PDF from Canva | `[generic]` I can't tell whether it has a real text layer | `[grounded]` your description; `[generic]` the failure mode |
| Section headings and hidden text | Could not run: I haven't seen the file | Unknown | `[grounded]` I haven't seen the file |

These are risks, not redesign advice. If your contact details are lost in parsing, nobody can reach you however good the content is.

## Upgrade menu

- **Paste the text copied out of your PDF** (select all, copy, paste as plain text). The order it comes out in is roughly what a parser sees, and it lets me run the heading and layout checks I couldn't run above.
- **The resume file itself**, so the parse checks run on the real document.
- **Answers to the questions below**, which could turn rows in the recovery table into real ledger rows.
- **Artifacts that count in this field:** Jenkinsfiles, PoC manifests or charts, runbooks, dashboard screenshots, or a prior resume version that carried more detail.

## Questions

C1 — What did the Kubernetes proof-of-concept actually run on (EKS or something else), did it use Helm, and what did you deploy to it?
C2, C3 — Have you used Terraform, Prometheus or Grafana hands-on anywhere (work, a home lab, a course), and what did you build with it?
C4 — Who depends on your Jenkins pipeline, and what happens when it breaks (are you paged, who fixes it)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.