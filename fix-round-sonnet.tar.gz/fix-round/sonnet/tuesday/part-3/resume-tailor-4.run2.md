The cause is probably not what you think, and the bigger problem is content rather than layout. I've built the full edit ledger below. Nothing is applied until you approve it.

**On the ATS premise.** In the one source available, auto-rejection on resume content was uncommon: "AI/content auto-rejection configured: 8% of recruiters" (cite C25), which was 2 of 25 recruiters in a résumé-builder vendor's interviews. The same source says "When automated filters are used, they're almost always knockout questions" (cite C26). Those are yes/no eligibility checks in the application form, such as work authorization, licence and location, and nothing on your resume changes them. Match scores mostly order who gets reviewed first: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27). That sample is small and vendor-run, so I can't say how often any of this happens at Ridgemount.

The coverage map shows what keywords can and can't fix here. Most of the JD's named tools have no evidence in what you've told me, and I won't write them in. Whether this role is worth applying to with that many gaps is a separate question, which job-underwriter answers.

I'm working from your description of the resume, not the file, so the quotes below come from your message.

**Edit ledger** (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | Own bullet in Experience, wording unchanged, qualifier kept | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | Wording unchanged, moved to the first bullet of Experience | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |
| E3 | Skills | "Bash and Python scripting" | "Bash scripting" and "Python scripting" as two separate entries | `split` | "Bash and Python scripting" | `[grounded]` your message | pending your approval |
| E4 | Skills | *(Kubernetes is not in the skills list)* | "Kubernetes (two-month proof-of-concept, not production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |

- **E1 and E4:** these make "Kubernetes" findable while keeping the "never went to production" qualifier. Dropping it would make the claim bigger than it is.
- **E2:** this keeps your word "deploy pipeline" and "Jenkins" rather than swapping in the JD's "CI/CD (GitLab)".

**Coverage map**

The JD gives no tiers, so priorities are my reading.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | `surfaced_by_edit` | E1 and E4; proof-of-concept only, no production use | `[inferred]` JD lists it first and builds the role around it |
| R2 | AWS EKS | must-have | `not_evidenced` | Your AWS list names EC2, S3, RDS and IAM, not EKS | `[inferred]` from the JD's wording |
| R3 | Terraform | must-have | `not_evidenced` | Ansible is the nearest thing you've listed, but it is not Terraform | `[inferred]` from the JD's wording |
| R4 | ArgoCD and GitOps | must-have | `not_evidenced` | Nothing in your material | `[inferred]` from the JD's wording |
| R5 | Istio and service mesh | important | `not_evidenced` | Nothing in your material | `[inferred]` from the JD's wording |
| R6 | Prometheus, Grafana, observability | must-have | `not_evidenced` | You list CloudWatch for monitoring; the JD names different tools | `[inferred]` from the JD's wording |
| R7 | Vault | important | `not_evidenced` | Nothing in your material | `[inferred]` from the JD's wording |
| R8 | Helm | important | `not_evidenced` | Nothing in your material | `[inferred]` from the JD's wording |
| R9 | CI/CD (GitLab) | must-have | `surfaced_by_edit` | E2; your pipeline is Jenkins, not GitLab | `[inferred]` from the JD's wording |
| R10 | Python | important | `surfaced_by_edit` | E3 | `[inferred]` from the JD's wording |
| R11 | Go | important | `not_evidenced` | Nothing in your material | `[inferred]` from the JD's wording |
| R12 | SRE practices; owning reliability and developer experience | must-have | `not_evidenced` | You describe building and maintaining pipelines, not reliability or developer-experience ownership | `[inferred]` from the JD's closing sentence |

**Recovery per gap** (recall prompts, `pending your approval` on any row they produce)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Terraform | must-have | Ansible for config management; no infrastructure-as-code tool otherwise named | Terraform is named in the JD and nothing on the resume is an adjacent match for it | Terraform modules at a past job; infrastructure you provisioned with code; a personal project | A repo, a module, a plan output | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Prometheus, Grafana, observability; SRE practices | must-have | CloudWatch for monitoring; no alerting, on-call, incident or reliability work stated | The role is to "own platform reliability", and the resume shows monitoring only | Dashboards or alarms you built; on-call rotations; incident write-ups; any SLO or error-budget discussion | A dashboard, a runbook, a post-incident review | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Kubernetes depth: EKS, Helm | must-have | A two-month proof-of-concept, never in production | The JD names EKS and Helm; the proof-of-concept might already cover them | EKS as the cluster; Helm charts you wrote or used; what you deployed to it | A design doc, a repo, a demo write-up | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

**Named absences**

- **Istio / service mesh, Vault, ArgoCD/GitOps:** you have no evidence of any of these. Closing them takes real hands-on work, such as running them in a personal EKS or kind cluster and keeping the repo. Until then, the honest position is that they're gaps.
- **Go:** this is also a gap. The closing path is a small tool written in Go that you can show.

**Not written, and why**

- "Platform Engineer" as your title. You are a DevOps Engineer, and `retitle` allows an equivalent, not an upgrade.
- "Kubernetes in production", "managed clusters" or "container orchestration" as a skill. You had a two-month proof-of-concept that never shipped.
- "Terraform", "infrastructure as code" or "IaC". Ansible is a different tool, and the word change would claim a skill you haven't stated.
- "Observability", "Prometheus" or "Grafana". You wrote CloudWatch, and relabelling it would borrow the JD's vocabulary for your own history.
- "CI/CD (GitLab)". Your pipeline is Jenkins.
- "GitOps", "service mesh", "SRE practices" or "owned platform reliability". Nothing you wrote supports them.
- A block of JD keywords, hidden or visible, with no work behind it. Hidden text I refuse outright, because it is deception aimed at the employer's software and it can be found.

**Parse-safety check** (reported, not redesigned)

I haven't seen the PDF, so I couldn't test extraction. Here is what your description implies:

| Check | Finding | What it costs |
|---|---|---|
| Multi-column layout | Risk, from your description | Parsers read linearly, so text can interleave and dates can detach from roles |
| Images and icons for skills | Risk, from your description | If a skill appears only as an icon, its name is absent from the extracted text |
| Contact details in the header | Risk, from your description | Header content can be discarded as page furniture, leaving you unreachable |
| Section headings | Could not check | I haven't seen them |
| File type | Could not check | Canva PDFs vary; a text-layer PDF or a .docx is the safe pair |

A quick way to check is to select-all and paste the PDF into a plain-text editor. Whatever comes out is roughly what a parser sees.

**Upgrade menu** (offers only, built on your say-so)

- **The actual resume text or file.** It would let me quote your lines exactly and run a real parse check.
- **Evidence for your proof-of-concept and pipeline.** A Kubernetes design doc or repo, your Jenkinsfiles, CloudWatch dashboards or alarm definitions, and Ansible roles are the artifacts this field keeps. They would let me raise the medium-confidence rows.
- **Prior resume versions.** They often hold work the current one dropped.

C1 — Have you used Terraform, or any other infrastructure-as-code tool besides Ansible, at work or in a personal project?
C2 — Have you built dashboards or alerts, been on call, or written up an incident, and was any of it done in Prometheus or Grafana rather than CloudWatch?
C3 — In your Kubernetes proof-of-concept, did you run on EKS or use Helm, and what did you actually deploy?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.