Priya, the ledger is below. I worked from the sentences you pasted, not a CV file, so each "current line" is your own wording and every trace is a verbatim quote from your message. Nothing is applied yet. Every row is `pending your approval`, and I'll produce the tailored CV only from the rows you approve.

Your evidence is strongest on p99, on-call and incident command, and Go and Rust experience. It is thinnest on product roadmap work, on whether you designed services, and on which language the ledger services use.

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | "Senior Software Engineer, 7 years." and "Go and Rust daily for 4 years, Python before that." | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV text | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged, moved to the first bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV text | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV text | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years" and "I've run six incidents as incident commander." | "On-call rotation every fourth week for two years; I've run six incidents as incident commander." | `merge` | "On-call rotation every fourth week for two years"; "I've run six incidents as incident commander." | `[grounded]` your CV text | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "I do onboarding for new hires on my team (usually two or three a year), pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV text | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Kafka, gRPC, Postgres, Datadog, Terraform" | `reorder` | "Kafka, Postgres, Terraform, gRPC, Datadog" | `[grounded]` your CV text | pending your approval |

- **E1:** It joins two of your sentences and keeps them separate. It does not add the word "backend" to the 7 years, because your line says "Software Engineer".
- **E4:** The on-call sentence and the incident sentence stay as two clauses. I did not write "owned on-call", because a rotation is not the same as owning on-call for your own services.
- **E5:** It stays as onboarding and pairing. I did not turn it into "mentoring mid-level engineers".
- **E6:** It only moves the tools you already list. Putting Kafka and gRPC first and Datadog before Terraform leads with what a high-volume, latency-focused role reads first. Listing a tool does not claim a depth of use.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| K1 | 5+ years backend | must-have | `surfaced_by_edit` | E1 puts "7 years" up top. The word "backend" is not added, because your line says "Software Engineer"; the ledger services imply it and C3 can settle it. | `[grounded]` your CV text |
| K2 | Production Go | must-have | `already_evidenced` | Your Go line stands as written, and E1 only moves it earlier. | `[grounded]` your CV text |
| K3 | Distributed systems at scale | must-have | `surfaced_by_edit` | E2 puts the 40k requests/minute service first, and E6 moves Kafka and gRPC up. The phrase "distributed systems" is not written, because your material doesn't say it. | `[grounded]` scale and tools; `[inferred]` that the pipeline is distributed, derived from Kafka, gRPC and multiple services |
| K4 | Go services at high request volume | must-have | `not_evidenced` | Your material gives the volume but not the language of the ledger services. C3 would settle it. | `[grounded]` volume is stated; language is not |
| K5 | Drive down p99 | must-have | `already_evidenced` | E3 only moves the bullet up. | `[grounded]` your CV text |
| K6 | Own on-call and strong incident response | must-have | `already_evidenced` | E4 combines the two sentences into one bullet. | `[grounded]` your CV text |
| K7 | Experience mentoring | must-have | `surfaced_by_edit` | E5 keeps your onboarding and pairing wording. "Mentoring" is the JD's word, not yours. | `[grounded]` your CV text |
| K8 | Design Go services | important | `not_evidenced` | You say you "own" the services; nothing says you designed them. See C2. | `[grounded]` what your CV says and doesn't say |
| K9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material touches this. See C1. | `[grounded]` what your CV says and doesn't say |

## Gap handling (recall prompts)

The questions these rows imply are asked once, in the closing block, tagged by row.

| # | Requirement | Priority | What your CV currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Partner with product on roadmap sequencing | must-have | Nothing about product work. All bullets are engineering ownership, on-call and onboarding. | The JD lists this as a responsibility, and a reader has no evidence of it from your CV. | Deciding with a product manager which ledger work shipped first; pushing back on or re-ordering a deadline for a reliability or latency reason; writing up trade-offs for a planning session | A planning doc, a roadmap ticket thread, or a short written trade-off you authored | `[grounded]` what the CV does and doesn't say; `[generic]` what it costs on applications of this kind |
| C2 | Design Go services | important | You own three services. That establishes ownership but not who designed them. | The JD says "design and ship", and ownership alone doesn't show the design half. | Writing the design doc for one of the three; choosing a data model, queue or API shape; leading the cache-layer rework design | A design doc or RFC, an architecture diagram, or a review thread | `[grounded]` what the CV does and doesn't say; `[generic]` what it costs on applications of this kind |
| C3 | Go services at high request volume | must-have | The 40k requests/minute service is described, but its language isn't. | "Production Go" is the JD's first technical requirement, and your Go line doesn't say it applies to this service. | The 40k requests/minute service or the balance-read path being in Go | A repo language breakdown, a service README, or a deploy config | `[grounded]` what the CV does and doesn't say; `[generic]` what it costs on applications of this kind |

## Not written, and why

- "Designed and shipped Go services": your material says you own them. It doesn't say you designed them or what language they use (C2, C3).
- "Mentored mid-level engineers": you onboard and pair with new hires, and nothing says what level they were.
- "Distributed systems experience": the phrase isn't in your material. Scale and the tools you list are written as you said them.
- "Partnered with product on roadmap": nothing in your material supports it (C1).
- "7 years of backend experience": your line says "Software Engineer, 7 years".
- "Owned on-call for my services": you wrote "on-call rotation every fourth week".
- "Reduced p99 latency by 75%": you gave 380ms to 95ms, and I kept your two figures.
- "Built the incident-response process": you wrote that you ran six incidents as incident commander, which is different from building the process.

## Parse-safety check

You pasted text, not a file, so I could not run any of the layout checks: multi-column layout, tables or text boxes, images or skill bars, header and footer content, section headings, file type. If you send the actual file, I'll run them. A text-layer PDF or `.docx` is the safe pair.

## Upgrade menu

I'd build the following only if you want it, since it goes beyond the ledger:
- **Evidence for your best claims:** a redacted Datadog p99 before-and-after chart, or an incident postmortem you commanded, would give the 380ms to 95ms and six-incident claims something inspectable.
- **A design doc excerpt** would close C2 if one exists.

## Questions

C1 — Have you ever helped decide with a product manager what got built first on the ledger pipeline, or argued to change that order? If so, what was the call?
C2 — Did you design any of the three services you own, or did you inherit them? For the 40k requests/minute service in particular, who made the original design choices?
C3 — Are the ledger services, especially the 40k requests/minute one and the balance-read path, written in Go?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.