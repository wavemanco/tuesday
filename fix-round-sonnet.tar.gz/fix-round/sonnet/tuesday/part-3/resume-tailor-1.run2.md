Priya, below is the tailoring ledger for the Tessellate role. It holds proposals only, and nothing is applied until you approve specific rows.

I worked from the CV text you pasted. I haven't seen the file, so I don't know what else is on it or how it's ordered. Every "Current line" below is quoted from your message.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line seen)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV text | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged — moved to the first bullet under your current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV text | pending your approval |
| E3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged — moved to the second bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV text | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | *(unchanged — moved to the third bullet, kept as one line)* | `reorder` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV text | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | *(unchanged — moved to the fourth bullet)* | `reorder` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV text | pending your approval |

- **E1:** It is built only from three of your sentences and kept as three. I dropped only the "I". The adjacency of the Go sentence and the services sentence is deliberate to flag. Your CV doesn't say the three services are written in Go, so the summary doesn't say so either (see C1).
- **E4:** I kept it as one line on purpose. Splitting it would tie "six incidents" to "two years", and your sentence doesn't say that.
- **E5:** I did not use the word "mentored". Your sentence says onboarding and pairing, and the JD's word is "mentor mid-level engineers".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 5+ years backend | must-have | `surfaced_by_edit` | E1 puts "7 years" beside the services you own. I don't know whether all 7 years were backend, so the line says only what you wrote. | `[grounded]` your CV text |
| M2 | Production Go | must-have | `surfaced_by_edit` | E1 puts "Go and Rust daily for 4 years" in the summary. Which language the three services use isn't stated; see C1. | `[grounded]` your CV text |
| M3 | Distributed systems at scale | must-have | `surfaced_by_edit` | E1 and E3 surface the 40k requests/minute figure. I don't use the phrase "distributed systems" for your history, and Kafka is only a tool listed, not a role you've described. | `[grounded]` your CV text |
| M4 | Strong incident response | must-have | `already_evidenced` | The incident commander line already says it; E4 only moves it up. | `[grounded]` your CV text |
| M5 | Experience mentoring | must-have | `surfaced_by_edit` | E5 surfaces the onboarding and pairing line. Whether the new hires were mid-level, or whether you've mentored beyond onboarding, isn't stated. | `[grounded]` your CV text |
| M6 | Own on-call for your services | important | `already_evidenced` | The rotation line covers it. It says rotation, so I don't call it "owning" on-call. | `[grounded]` your CV text |
| M7 | Drive down p99 latency | important | `already_evidenced` | The 380ms to 95ms line; E2 moves it first. | `[grounded]` your CV text |
| M8 | Design and ship Go services at high request volume | important | `not_evidenced` | Nothing says you designed services or what language they're in. See C1. | `[grounded]` your CV text |
| M9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in the CV touches product or roadmap work. See C2. | `[grounded]` your CV text |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Design and ship Go services at high request volume | important | You own three services and reworked a cache layer. It doesn't say who designed the services, or which language they're in. | The posting leads with designing and shipping Go services, and ownership alone doesn't show design. | A service you designed or substantially re-architected; a new endpoint or pipeline stage you took from proposal to production; the cache rework itself, if you designed it | A design doc, an RFC, a launch note, a repo | `[grounded]` what the resume does and doesn't say; `[generic]` what this costs on applications of this kind |
| C2 | Partner with product on roadmap sequencing | important | Nothing in the resume touches product or roadmap work. | It is the one responsibility in the posting with no counterpart on your CV. | Trading off a ledger-pipeline project against product asks; giving effort estimates that changed a quarter's plan; pushing back on or re-sequencing a request | A planning doc, a roadmap thread, an estimate you revised | `[grounded]` what the resume does and doesn't say; `[generic]` what this costs on applications of this kind |

If C2 comes back with nothing, it stays a named absence. One missing responsibility among nine is something you can address in the interview, and it doesn't call for writing around it.

## Not written, and why

- **"Designed and built Go services"**: you say you own three services and reworked a cache layer. Design and language aren't stated, and an interviewer will ask what you designed.
- **"Mentored mid-level engineers"**: your evidence is onboarding and pairing new hires. Their level and any ongoing mentoring aren't stated.
- **"Distributed systems experience"**: this is the posting's phrase. You gave a request rate and listed Kafka, and I won't turn a listed tool into a claim about owning it.
- **"Partnered with product" or "drove roadmap sequencing"**: there is no source sentence for either.
- **"Owned on-call for my services"**: your sentence says rotation every fourth week. Rotation and ownership are different claims.
- **"Redesigned" or "architected" the cache layer**: your word is "reworking".
- **Kafka, Postgres, Terraform, gRPC, Datadog beyond the tools list**: listing them says nothing about how you used them.

## Parse-safety check

Your CV came as pasted text, so I couldn't check multi-column layout, tables or text boxes, images or skill bars, content in headers or footers, or file type. Attach the file and I'll run those checks. A `.docx` or a text-layer PDF is the safe pair.

## Upgrade menu

I can build better rows if you give me any of these:
- The actual CV file, for the parse check and to catch anything your summary dropped.
- Any design doc or RFC for the cache rework, which would unlock C1.
- A Datadog p99 before-and-after screenshot, or a postmortem for one of the six incidents, which would put an inspectable artifact behind the strongest bullets.

## Questions

C1. Are the three services you own written in Go, and did you design any of them, or the cache rework, or were you extending something already built?
C2. Have you been involved in deciding what your team builds or in what order, such as estimates, trade-offs or pushback on a product request?
M5. Were the new hires you pair with mid-level engineers, and have you mentored anyone beyond their first month?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.