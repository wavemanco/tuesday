Your resume supports a credible "analytics engineer moving toward data engineering" story. It does not support the JD's must-have of 3+ years of data engineering, and I can't write around that. Below is the full ledger. Nothing is applied until you approve specific rows.

Two assumptions. I built this from your description, not a resume file, so each "Current line" is your sentence as you gave it to me. And since you pasted text, the layout checks (see Parse-safety) couldn't run. Whether the role is worth applying to with that must-have unmet is job-underwriter's question, and I haven't assessed it.

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your description | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your description | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then data engineer." | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your description | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fix our nightly dbt job when it breaks." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your description | pending your approval |
| E5 | Experience | *(second half of the line in E4)* | "Added tests to our nightly dbt job." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your description | pending your approval |
| E6 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Write Python for analysis in pandas." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your description | pending your approval |
| E7 | Experience | *(second half of the line in E6)* | "Wrote some scripts that pull vendor APIs on a cron." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your description | pending your approval |
| E8 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved below E2–E7)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your description | pending your approval |

What the rows do and don't do:
- **E4 and E5** keep "fix … when it breaks" and "added tests" as two separate claims. Neither says "owned", "maintained" or "built", because your sentence says neither.
- **E7** keeps "some". That qualifier is the honest part of the line, and the row does not say "pipeline", "production" or "automated".
- **E3** keeps "with our then data engineer", so the credit stays shared as you wrote it.
- **E1** is built only from three of your sentences and keeps them as three. I did not add a "transitioning to data engineering" line, because nothing in your material makes it a claim I could trace.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Five years as an analyst. Adjacent work (dbt models, nightly-job fixes) sits in E2–E5 but does not read as data engineering years. Recovery C1. | `[grounded]` your description |
| R2 | Production Python | important | `not_evidenced` | Pandas analysis and some cron scripts (E6, E7). Nothing says where they run or who depends on them. Recovery C2. | `[grounded]` your description |
| R3 | Airflow or equivalent orchestration | important | `not_evidenced` | You have never used Airflow. What runs the nightly dbt job is not stated. Recovery C3. | `[grounded]` your description |
| R4 | Dimensional modelling | important | `surfaced_by_edit` | E3 and E1. The JD's phrase is not written for you. The line says "star schema", which is what you did. | `[grounded]` your description |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E1 and E2 (about 25 dbt models, orders mart). The scope is one mart plus those models, not "the warehouse". | `[grounded]` your description |
| R6 | Own data quality | important | `surfaced_by_edit` | E5 ("added tests"). It evidences adding tests, not owning data quality. | `[grounded]` your description |
| R7 | Own SLAs | important | `not_evidenced` | Nothing mentions a delivery deadline or alerting. Recovery C3. | `[grounded]` your description |
| R8 | Build and own batch pipelines | important | `not_evidenced` | You fix a nightly job (E4) and wrote some API-pull scripts (E7). Neither says you built or owned a pipeline. Recovery C2, C3. | `[grounded]` your description |
| R9 | Partner with analytics on requirements | important | `not_evidenced` | You sat on the analytics side. Nothing says you handed requirements to an engineer. Named absence below. | `[grounded]` your description |
| R10 | Streaming (Kafka, Spark) | preferred | `not_evidenced` | You have never used either. Named absence below. | `[grounded]` your description |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | Five years as an analyst with dbt modelling and nightly-job fixes. No role or bullet reads as data engineering work. | It is the posting's stated must-have, and an unmet must-have usually costs more than any preferred item. | Stretches where you kept the orders mart's loads and models running; load failures you diagnosed end to end; modelling work you did without an engineer. | dbt project commit history, job run logs, an incident note | `[grounded]` what the resume says; `[generic]` what an unmet must-have costs |
| C2 | Production Python | important | Pandas analysis and "some scripting" to pull vendor APIs on a cron. It does not say where the scripts run, who relies on them, or what happens on failure. | "Production" is the word a reader checks, and scripts on a cron don't establish it. | A vendor pull that other people's dashboards depend on; a script that retries or alerts on failure; one kept in version control with review. | A repo link, a README, alert or log config | `[grounded]` what the resume says; `[generic]` how readers treat the word "production" |
| C3 | Orchestration and SLAs | important | A nightly dbt job you fix and added tests to. It doesn't say what schedules it or whether anyone expects it by a set time. | The JD asks for Airflow "or equivalent", and a scheduler only counts if it is named. | The tool that triggers the nightly run (dbt Cloud, cron, a scheduler); a morning deadline dashboards depend on; an alert when the run fails. | Job or schedule config, a failure alert, a run history | `[grounded]` what the resume says; `[generic]` what readers look for in "equivalent" |

**Named absences.**
- **R9, partnering with analytics on requirements.** You were on the analytics side, and the resume does not show you handing requirements to an engineer. To close it, you'd need one specific case where you specified something the data engineer then built, such as a field or grain for the orders mart. If you have one, tell me and I'll run it through a confirmation card before it becomes a row.
- **R10, streaming and Spark.** You have never touched either. It is a plus, not a requirement. You could close it with a small Kafka project or course plus a working demo, but it isn't worth closing before you apply to this role. It would add a line about learning, not experience.

## Prohibited claims (not written, and why)

- **"3+ years of data engineering" or a "Data Engineer" title.** You have five years as an analyst, and the JD makes this a must-have. Adjacent work is in E2–E5 and the gap is named in R1.
- **"Owned" or "maintained" the nightly pipeline.** You fixed the job when it breaks and added tests. Ownership is a different claim, and an interviewer can test it with one question.
- **"Production Python".** The scripts run on a cron. Nothing says others depend on them.
- **"Orchestrated pipelines".** A cron isn't what the JD means by an orchestrator, and what runs your dbt job isn't stated.
- **"Designed the data warehouse".** You designed the orders mart's star schema with the then-DE. The JD's "model the warehouse" is larger.
- **"Owned data quality and SLAs".** You added tests. Nothing mentions an SLA.
- **Airflow, Spark, Kafka, streaming**, even as "familiar with". You have not used them, so they appear nowhere.
- **"Partnered with analytics".** You were inside analytics, and the posting's word would change which side of the table you sat on.

## Parse-safety check

You pasted text, so none of these could be checked: multi-column layout, tables and text boxes, icons and skill bars, content in headers or footers, section headings, file type, and hidden text. Send the file and I'll run them. Nothing in the pasted text raises a parse risk.

## Upgrade menu

Both items below are offers I'd build only if you say yes.
- **The actual resume file.** It would let me quote your real lines instead of your summary and run the parse checks above.
- **A repo link or config for the dbt project or the vendor scripts.** It would turn rows in R2, R3 and R8 into grounded evidence instead of gaps.

## Questions

C1 — Roughly how much of your five years went to keeping loads and models running or fixing them, as opposed to analysis, and since when?
C2 — Where do the vendor-API scripts run, who depends on their output, and what happens when one fails?
C3 — What runs the nightly dbt job (dbt Cloud, cron, a scheduler), and does anyone expect it finished by a set time?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.