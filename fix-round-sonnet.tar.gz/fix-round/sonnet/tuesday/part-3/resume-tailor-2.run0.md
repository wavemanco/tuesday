The request is to rewrite a resume for a named role, so I'm running resume-tailor. Reading its playbook first.
Dev, I haven't rewritten the resume yet. This is a ledger of proposed edits for you to approve row by row, and the tailored document gets built from the approved rows only. I only have your description of the resume, so the "Current line" quotes below are your own sentences from your message. If your real bullets read differently, paste them and I'll re-run the rows.

The honest picture is that your resume can be made to lead with its strongest evidence, but it can't cover this JD's must-haves. The star schema work holds up. The 3+ years of data engineering, production Python and orchestration requirements are not evidenced as written, and no edit should paper over that. Whether the role is worth applying to with that gap is job-underwriter's question, not this one.

## The edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Looking to move into data engineering from analytics. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics"; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved to the first bullet)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | *(unchanged, moved to the third bullet, after the dbt models line)* | `reorder` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | Two bullets: "Write Python for analysis — pandas" and "Some scripting to pull vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E5 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved to the last bullet)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your message | pending your approval |

- **E1** keeps the four claims as four separate sentences. Merging them into one clause would turn "with our then-DE" into sole ownership.
- **E2** puts the one fully evidenced requirement, dimensional modelling, first. "With our then-DE" stays attached.
- **E4** splits the line so the cron scripting reads on its own. I kept "some", and I did not add "production", "ingestion" or "pipeline".
- **Bullet voice:** your first-person "I" is left as you wrote it. Converting to bullet voice would be a separate `compress` row if you want it.
- **Resulting order:** star schema, dbt models, nightly job, the two Python bullets, SQL.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Your title is Senior Data Analyst for 5 years. Pipeline-adjacent work exists (E2, E3, E4) but no row can claim it as data engineering years. Recovery row C1. | `[grounded]` your message has no DE role; `[generic]` a length requirement is usually read against titles first |
| R2 | Production Python | must-have | `not_evidenced` | The cron scripts are adjacent, but "production" isn't established. Recovery row C2. | `[grounded]` "some scripting to pull vendor APIs on a cron" |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | You wrote that you've never used Airflow. What schedules the nightly dbt job is unknown. Recovery row C3. | `[grounded]` "Never used Airflow or Spark." |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E2 leads with it, and E1 repeats it in the summary. | `[grounded]` "I designed the star schema for the orders mart with our then-DE." |
| R5 | Data quality ownership | important | `surfaced_by_edit` | E3 raises the tests you added to the nightly job. "Own" is not claimed. | `[grounded]` "added tests to it" |
| R6 | SLAs | important | `not_evidenced` | Nothing in your material mentions a delivery time or a lateness rule. Recovery row C3. | `[grounded]` absent from your message |
| R7 | Build and own batch pipelines | important | `not_evidenced` | You fixed the nightly job and built dbt models. Building and owning pipelines is a different claim. Recovery rows C1 and C3. | `[grounded]` "I've fixed our nightly dbt job when it breaks" |
| R8 | Partner with analytics on requirements | important | `already_evidenced` | You sit on the analytics side already. No row claims you "partnered", since that would move which side of the table you were on. | `[grounded]` "Senior Data Analyst" |
| R9 | Streaming experience | preferred | `not_evidenced` | Named absence below. | `[grounded]` "Never touched Kafka." |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | Five years as an analyst with dbt models and a nightly job you maintained. It does not say pipeline work was your main duty for any stretch. | This is the posting's one stated must-have on years, and the resume currently answers it with an analyst title. | Owning the nightly dbt job end to end for a period; being the person called when the vendor scripts failed; handing over or taking over pipeline work from the then-DE | The dbt project repo, the job's run history, or a handover note | `[grounded]` what the resume says and omits; `[generic]` a years-of-experience requirement is commonly checked against titles |
| C2 | Production Python | must-have | Python for analysis, plus some scripting that pulls vendor APIs on a cron. Nothing says anyone depends on those scripts. | "Production" is the posting's word, and your sentence doesn't say it. | Dashboards or reports that read the pulled data; retries or failure alerts on the scripts; the scripts living in version control | The scripts' repo, a cron or scheduler config, or an alert email | `[grounded]` the sentence as written; `[generic]` what readers look for under "production Python" |
| C3 | Airflow or equivalent orchestration, and SLAs | must-have | A nightly dbt job that you fixed and added tests to. It doesn't say what triggers it or what "on time" means. | If the trigger is a scheduler with dependencies and alerting, "equivalent" may be arguable. If it's bare cron, it likely isn't. | A dbt Cloud or similar scheduler job with dependencies; a deadline the job had to meet for a morning report; an on-call or alert routine | The job config, a lineage graph, or a run-failure log | `[grounded]` what your message does and doesn't say; `[inferred]` from what a dbt job could be scheduled by |

### Named absences

- **Streaming and Kafka:** you have none, and the posting lists streaming as "a plus". Closing it would take a small project, for example a Kafka consumer loading into your warehouse. That would let you say you built a small one, not that you ran streaming in production. For this application it isn't worth closing unless you want the project for its own sake.
- **Spark:** you have none, and the Requirements line doesn't list it. It appears only in the description of the work. Nothing is written for it, and no cheap path closes it before this application.

## Not written, and why

- "3+ years of data engineering experience", or a Data Engineer or Analytics Engineer title. Your title is Senior Data Analyst, and a retitle has to be an equivalent, not an upgrade.
- "Built and owned batch pipelines". You fixed the nightly job and added tests; building and owning it are different claims.
- "Production Python" or "production ingestion pipelines". The scripts are "some scripting on a cron", and nothing says anyone relied on them.
- "Orchestration" or "workflow management" in any form, and Airflow, Spark or Kafka in a Skills list. You've used none of them, and a cron job isn't what the posting means by orchestration.
- "Owned data quality" or "managed SLAs". You added tests, and nothing mentions a delivery time.
- "Led data modelling" or any wording that drops "with our then-DE". You designed the star schema alongside a data engineer, and that qualifier is the honest part.
- "Partnered with data engineering". Your word is "with"; the posting's relationship runs the other way, since you'd be the analytics side.
- "25+ models" or "25 production models". Your sentence says "about 25".

## Parse-safety check

You pasted a description rather than a file, so I could not run any of these checks: multi-column layout, tables and text boxes, images or skill bars, contact details in headers or footers, non-standard section headings, and file type. Send the actual file (a `.docx` or a text-layer PDF) and I'll run them.

## Upgrade menu

Each of these would turn a gap row into real evidence:
- The repo or a screenshot of the dbt project, which would support E1 to E3 and C1.
- The scheduler or cron config for the nightly job, which answers C3.
- A run-failure log or an alert email from the nightly job or the vendor scripts, which answers C2 and C3.
- Any handover note or runbook you wrote, which bears on C1.

Beyond the spec, I can offer a short plan for one small gap-closing project (an orchestrated pipeline, Airflow or similar, running on a schedule against your own data). It would add something real to put on a resume later. I'll only draft it if you ask.

## Questions

C1 — Was pipeline work (owning or running scheduled jobs, not analysis) your main duty for any stretch of the five years, and for roughly how long?

C2 — Do other people or dashboards depend on the output of the vendor-API scripts, and what tells you when one fails?

C3 — What triggers the nightly dbt job (dbt Cloud, cron, something else), and has anyone set a time it must finish by or a rule for when it counts as late?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.