I've read the resume-tailor playbook and its rules. I'm checking the upgrade-menu rules, then I'll send you the full edit ledger.
Nothing is applied yet, so there is no tailored resume to send. I built the ledger from the sentences you gave me and treated them as self-report. You gave no employers, dates or metrics, so I invented none. A tailored resume will exist only after you approve rows.

The only wording change across the rows is dropping "I" so the lines read as bullets. Every other word is yours.

## Edit ledger — `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." (moved to the top of Experience) | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | "Built and maintained about 25 dbt models including the core orders mart." (moved to second) | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your resume | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Added tests to our nightly dbt job." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your resume | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis — pandas." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your resume | pending your approval |
| E6 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Some scripting to pull vendor APIs on a cron." (placed straight after E4) | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your resume | pending your approval |
| E7 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | "SQL every day on Redshift, complex window functions and CTEs." (moved below E1–E6) | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your resume | pending your approval |

- **E3 and E4:** the original sentence did two jobs, so each half is its own row. You can approve the test-adding line without the fixing line.
- **E6:** it keeps "some" and "on a cron". It does not say production, pipeline or orchestration.
- **E7:** your day-to-day SQL work is now the supporting line, since it is not what this JD is asking for.
- **No summary:** I did not propose one. Any summary would be built from these same sentences, so it would add nothing.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | not_evidenced | Your title is Senior Data Analyst. The nearest work is E1–E4, which are modelling and maintenance of a dbt job. See C1 and Q3. | `[grounded]` JD wording and your title |
| R2 | Production Python | must-have | not_evidenced | E5 and E6 show analysis Python and cron scripting, but nothing says the scripts are deployed, monitored or versioned. See C2 and Q2. | `[grounded]` your resume |
| R3 | Airflow or equivalent orchestration | must-have | not_evidenced | You said you've never used Airflow. A nightly dbt job exists (E3, E4), but what schedules it is unstated. See C3 and Q1. | `[grounded]` your resume |
| R4 | Dimensional modelling | must-have | surfaced_by_edit | E1 puts the star schema first; E2 supports it. | `[grounded]` your resume |
| R5 | Data quality (the SLA half is not evidenced) | important | surfaced_by_edit | E4 is the only line on it. Nothing in your history mentions SLAs. | `[grounded]` your resume |
| R6 | Batch pipelines (Spark named in the JD) | important | not_evidenced | You said you've never used Spark. See A1. | `[grounded]` your resume |
| R7 | Streaming (Kafka named in the JD) | preferred | not_evidenced | You said you've never touched Kafka. See A2. | `[grounded]` your resume |

## Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | 5 years as an analyst. A star schema built with a DE, and upkeep of a dbt job. | The JD makes DE years a must-have, and your title does not say DE. | Taking over ingestion or modelling after the then-DE left; being the person on call for the nightly run; adding sources to the warehouse | A pull request history, a runbook, a data-source inventory you maintained | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Production Python | must-have | Analysis in pandas, plus some cron scripting to pull vendor APIs. | "Production" is the word the JD uses, and analysis code does not establish it. | Cron scripts that feed a table others depend on; retries or failure alerts; scripts kept in a repo | The repo, a crontab or scheduler config, an alert message | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Airflow or equivalent orchestration | must-have | A nightly dbt job you've repaired and added tests to. What runs it is not stated. | The JD allows "equivalent", but it is on you to show that. | dbt Cloud or a scheduler you configured; dependencies between jobs; alerting on failure | Job config, a DAG-style dependency diagram, a failure notification | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

## Named absences

| # | Requirement | Priority | Gap | What closing it would take | Provenance |
|---|---|---|---|---|---|
| A1 | Spark | important | You have never used it, and nothing in your history is adjacent to it. | A small personal project: a batch transform in PySpark over a public dataset, kept in a repo. This is a few weeks of evenings, not a rewrite of your history. For this role it is a gap to carry, not one to hide. | `[grounded]` your resume; `[generic]` closure path |
| A2 | Streaming (Kafka) | preferred | You have never touched it. | A short Kafka consumer or producer project would let you say you have run it. Until then, leave it out. It is a plus rather than a requirement, so it is probably not worth chasing before applying. | `[grounded]` your resume; `[generic]` closure path |

## Not written, and why

- **"3+ years of data engineering experience"**: 5 years as an analyst is a different title and kind of work. C1 may change this if you did carry DE duties.
- **"Owned the nightly pipeline"**: you fixed the job and added tests. Ownership is a different claim.
- **"Production Python pipelines"**: "some scripting … on a cron" is the supported scope. Production is an open question (C2).
- **"Orchestrated with Airflow-equivalent tooling"**: what schedules the job is unstated, and "orchestration" is the JD's word, not yours.
- **"Partnered with analytics on requirements"**: the JD wants a DE doing this. You sat on the analytics side, so the phrase would flip which side of the table you were on.
- **Airflow, Spark and Kafka in a skills list**: you have not used them, and a listed tool reads as an owned tool.
- **"Built the data warehouse"**: you designed one star schema with a DE and built models, which is narrower.

## Parse-safety check

You pasted text, not a file, so I could not run these checks: layout and columns, tables and text boxes, images or icons, content in headers or footers, and file type. Section headings look conventional in what you gave me. If you send the actual file, I can check the rest.

## Upgrade menu

- **Your actual resume file:** lets me run the parse-safety check and see dates, employers and bullets I have not seen.
- **Earlier resume versions:** may hold DE-flavoured lines you cut, which could move R1–R3.
- **A link or sample of the dbt project or cron scripts:** a repo or job config is the inspectable proof for this field. It could take R2 and R3 from your say-so to something checkable.
- **Whether to apply at all:** the 3+ years must-have is a bigger question than wording. That is job-underwriter's call, and I haven't made it here.

## Questions

Approve or reject rows by number, for example "Approved: E1, E2, E7".

- **C3:** what runs your nightly dbt job (dbt Cloud, cron, Airflow someone else owns), and did you set it up or only maintain it?
- **C2:** where do the vendor-API cron scripts run, are they in a repo, and does anything alert you when they fail?
- **C1:** after the then-DE left, did you take over any ingestion, scheduling or warehouse ownership, and for roughly how long?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.