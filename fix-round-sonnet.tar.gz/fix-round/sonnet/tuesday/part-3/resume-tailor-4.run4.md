You're half right. Keywords may be a factor, but most of the gap is in the evidence, not the wording. Your resume has Python, AWS, Jenkins and a two-month Kubernetes proof-of-concept. The JD asks for much more than that, and I can't write those missing items onto your resume without making claims you couldn't defend in an interview.

**On the ATS premise.** The one sample I can cite is a résumé-builder vendor's interviews with 25 US recruiters, so treat it as thin:
- Content-based auto-rejection was rare in it: "AI/content auto-rejection configured: 8% of recruiters" (cite C25).
- The same recruiters said "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are yes/no checks on the application form, such as work authorization or location. Nothing on your resume changes them.
- Where match scores exist: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27).

So the useful goal is to make your real evidence findable and parseable. I haven't invented any keywords.

**Assumptions.**
- The JD gives no must-have versus preferred tiers, so I ranked by listed order and the ownership sentence. Tell me if the full posting says otherwise.
- I haven't seen your PDF. Every quote below is from what you typed here, so check each one against your actual resume.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Kubernetes | `must-have` | `surfaced_by_edit` | E1. Proof-of-concept only, never production, so a real gap remains | `[grounded]` |
| M2 | Terraform | `must-have` | `not_evidenced` | C1. Ansible is config management, not provisioning | `[inferred]` from "Ansible for config management" |
| M3 | CI/CD (GitLab) | `must-have` | `surfaced_by_edit` | E2 covers the Jenkins pipeline. GitLab itself is M10 | `[grounded]` |
| M4 | Python | `must-have` | `already_evidenced` | E3 only separates the entry | `[grounded]` |
| M5 | AWS EKS | `important` | `not_evidenced` | C2. EC2, S3, RDS and IAM are stated, EKS is not | `[grounded]` |
| M6 | GitOps, ArgoCD | `important` | `not_evidenced` | C2 | `[grounded]` |
| M7 | Helm | `important` | `not_evidenced` | C2 | `[grounded]` |
| M8 | Prometheus, Grafana, observability | `important` | `not_evidenced` | C3. CloudWatch monitoring is the adjacent work | `[grounded]` |
| M9 | SRE practices; owning platform reliability and developer experience | `important` | `not_evidenced` | C3 | `[grounded]` |
| M10 | GitLab | `important` | `not_evidenced` | A1 | `[grounded]` |
| M11 | Istio, service mesh | `important` | `not_evidenced` | A2 | `[grounded]` |
| M12 | Vault | `preferred` | `not_evidenced` | A3 | `[grounded]` |
| M13 | Go | `preferred` | `not_evidenced` | A4 | `[grounded]` |

AWS (EC2, S3, RDS, IAM) is already on the resume, so I left it out as an `already_evidenced` row.

## Edit ledger: `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged, moved to the second bullet, under E2)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to the first bullet)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |
| E3 | Skills | "Bash and Python scripting" | "Python scripting" and "Bash scripting" as two separate entries | `split` | "Bash and Python scripting" | `[grounded]` your message | pending your approval |

- **E1 keeps "never went to production".** Dropping that qualifier would turn a proof-of-concept into production experience.
- **E1 and E2 only change position.** If they already sit near the top, they're no-ops.
- **The ledger is short on purpose.** Most of the JD has no evidence behind it, and the ledger doesn't try to hide that.

## Gap handling

**Recall prompts.** These are things you may have done but not written down.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Terraform | `must-have` | Ansible for config management; no provisioning tool named | The JD lists it among its first tools, and nothing on the resume matches it | Terraform modules at a past job; CloudFormation; provisioning AWS through scripts that someone later moved to Terraform | A repo, module, PR or ticket | `[grounded]` what the resume does and does not say; `[generic]` what an unmatched core tool costs on a platform role |
| C2 | EKS, Helm, GitOps/ArgoCD | `must-have` | A two-month Kubernetes PoC; cluster type and tooling unstated | If the PoC used EKS, Helm or a GitOps flow, those can be stated truthfully | Cluster built on EKS; charts written; deploys driven from Git | PoC write-up, README, architecture note, demo | `[grounded]` what the resume says; `[generic]` what these cost on this kind of role |
| C3 | Prometheus, Grafana, SRE practices, reliability ownership | `important` | CloudWatch monitoring; no incident or on-call work stated | The JD ends on owning reliability, and none of that shows | Dashboards or alerts you built; on-call rotation; post-incident reviews; SLO or error-budget work | Dashboard export, runbook, postmortem | `[grounded]` what the resume says; `[generic]` what this costs on such roles |

**Named absences.** Each has a closing path.

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | GitLab CI | No GitLab in your material | Rebuild one Jenkins job as a GitLab pipeline in a personal project, then link it | `[grounded]` |
| A2 | Istio, service mesh | Nothing stated | Add Istio to a small cluster and write up what you did. This may not be worth closing before you apply | `[grounded]` |
| A3 | Vault | Nothing stated | A small Vault project, or something you already built if your secrets work touched it. Low priority | `[grounded]` |
| A4 | Go | Python is your language | Roughly a month on a small Go tool. Not worth closing for this application alone | `[grounded]` |

## Not written, and why

- **"Terraform" or "infrastructure as code".** Ansible isn't the same work, and "a tool listed is not a tool owned".
- **"Production Kubernetes" or "Kubernetes experience".** You wrote "never went to production".
- **"Observability".** That's the JD's word, and your own is "CloudWatch for monitoring". Swapping it in would upgrade what you did.
- **"CI/CD (GitLab)".** You used Jenkins, and a deploy pipeline is not shown to be GitLab.
- **EKS, Helm, ArgoCD, GitOps, Istio, Vault, Go in a skills list.** Nothing in your material supports them.
- **"Owned platform reliability" or "improved developer experience".** Nothing you wrote says either.
- **Hidden keyword blocks.** I'd refuse these anyway: they're deceptive, they contradict a resume you can defend line by line, and they can be found.

## Parse-safety check

I haven't seen the file, so these risks come from your description only.

| Check | What I can say | Provenance |
|---|---|---|
| Multi-column layout | A two-column PDF is a risk. Parsers read linearly, so text can interleave and dates can detach from roles | `[grounded]` your description; `[generic]` how parsers fail |
| Icons for skills | Anything shown only as an icon may be skipped or turn into garbage characters | `[grounded]`; `[generic]` |
| Contact details in the header | Header content is often discarded as page furniture, so your contact details may not reach a recruiter | `[grounded]`; `[generic]` |
| Text layer and section headings | I could not check these | `[generic]` |

I'm reporting risks only and not redesigning anything. Send me the PDF and I can tell you what actually extracts.

One extra I can build on your approval: a short summary line made only from your existing sentences. It would give the screener a compact version of your strongest evidence.

Whether this role is worth applying to, given the size of the gaps, is job-underwriter's question and not part of this pass.

**Upgrade menu**
- **The PDF itself:** lets me run the parse check on the real file, including any hidden text a template left behind.
- **A Kubernetes PoC write-up, repo or architecture note:** could raise C2 from `medium` to `high` and may support EKS, Helm or GitOps lines.
- **Terraform or monitoring artifacts** (a module, dashboard export or runbook): would back C1 and C3.
- **Older resume versions:** may hold evidence the current one dropped.
- **The full posting:** would settle must-have versus preferred and show any knockout questions.

**Questions**

C1 — Have you used Terraform or another provisioning tool (CloudFormation, Pulumi) at work or on a side project, even for part of an environment?

C2 — In your Kubernetes proof-of-concept, where did it run (EKS or elsewhere), and did you use Helm or deploy from Git (ArgoCD, Flux)?

C3 — Have you built dashboards or alerts, carried on-call, or run incident reviews, and was any of it beyond CloudWatch?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.