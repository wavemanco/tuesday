Some of the rejections may be keywords, but the evidence points elsewhere first, and most of the gap is in what the resume doesn't show.

**Premise check.** In one small vendor-run sample of recruiters, content-based auto-rejection was rare: "AI/content auto-rejection configured: 8% of recruiters." (cite C25) That was 2 of 25 interviewed, and the vendor calls its findings themes rather than representative statistics. What those recruiters did describe is this: "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are yes/no eligibility checks on the application form, not on the resume. Match scores, where they exist, mostly set review order: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27). So keywords may affect whether a person reads your resume, but a missing keyword is not necessarily what rejected you. Two other things in your case are likelier culprits: the layout (see the parse-safety check below) and the fact that most of this JD's tools don't appear in your history (see the coverage map). I can only fix the first, and only by moving text around. I won't add any claim you can't defend.

Your message is my only copy of your resume, so every "current line" and quote below comes from your wording. Whether this role is worth applying to with this many gaps is job-underwriter's question, not this one.

The JD has no must-have or preferred tiers. I graded by position in the list and by its closing sentence, so correct me if you know which tools matter most.

## The edit ledger — `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | Two bullets: "Built our deploy pipeline in Jenkins" and "Maintain about 30 Jenkins jobs" | `split` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` resume | pending your approval |
| E2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged — the two E1 bullets moved to the top of your current role)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` resume | pending your approval |
| E3 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." as its own bullet directly under E1/E2. Reject this row if it already sits there. | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |
| E4 | Skills | "Bash and Python scripting" | "Bash scripting; Python scripting" | `split` | "Bash and Python scripting" | `[grounded]` resume | pending your approval |
| E5 | Skills | *(no Kubernetes entry stated)* | "Kubernetes (two-month proof-of-concept, not in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |

- **E3 and E5:** the qualifier stays in both. A tool listed is not a tool owned, and an interviewer will ask about the PoC.
- **E4:** this makes "Python" its own token, so a parser or a recruiter's search finds it.
- **Rows I didn't write:** I can't propose `cut` rows without seeing the full resume.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | `surfaced_by_edit` | E3, E5. Evidence is a two-month proof-of-concept, not production. | `[grounded]` |
| R2 | AWS EKS | must-have | `not_evidenced` | Your AWS is "AWS (EC2, S3, RDS, IAM)"; EKS is not mentioned. Recall prompt C1. | `[grounded]` |
| R3 | Terraform | must-have | `not_evidenced` | You list "Ansible for config management", which is a different tool and job. Recall prompt C2. | `[grounded]` |
| R4 | ArgoCD, GitOps | must-have | `not_evidenced` | Named absence below. | `[grounded]` |
| R5 | CI/CD | must-have | `surfaced_by_edit` | E1, E2. Evidence is a Jenkins deploy pipeline. | `[grounded]` |
| R6 | GitLab (CI/CD) | important | `not_evidenced` | Named absence below. | `[grounded]` |
| R7 | Python | must-have | `already_evidenced` | E4 only makes it a separate keyword. | `[grounded]` |
| R8 | Go | important | `not_evidenced` | Named absence below. | `[grounded]` |
| R9 | Prometheus, Grafana, observability | important | `not_evidenced` | You list "CloudWatch for monitoring". Recall prompt C3. | `[grounded]` |
| R10 | Istio, service mesh | important | `not_evidenced` | Named absence below. | `[grounded]` |
| R11 | Vault | important | `not_evidenced` | Named absence below. | `[grounded]` |
| R12 | Helm | important | `not_evidenced` | Named absence below. A Helm question rides on C1. | `[grounded]` |
| R13 | SRE practices | important | `not_evidenced` | Recall prompt C3. | `[grounded]` |
| R14 | Owning platform reliability and developer experience | important | `not_evidenced` | Your pipeline work is adjacent, but nothing you said describes ownership of either. | `[grounded]` |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes in production, AWS EKS, Helm | must-have | A two-month Kubernetes proof-of-concept that "never went to production". It doesn't say where it ran or what was deployed. | Kubernetes is the center of this JD, and the PoC is the closest evidence you have. | The PoC ran on EKS; you deployed one of your Jenkins-built services to it; you used Helm charts or plain manifests | A manifests repo, a PoC write-up, an architecture note | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Terraform | must-have | Ansible for configuration management, and AWS services by name. It doesn't say how the AWS resources were provisioned. | Infrastructure as code is usually screened by tool name. | Terraform or CloudFormation used for part of your AWS estate; modules you wrote or edited; Terraform in the PoC | A `.tf` file or module, a pull request, a repo link | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Prometheus, Grafana, SRE practices | important | "CloudWatch for monitoring". It doesn't say whether you set alerts, were on call, or ran incident reviews. | The JD pairs observability with SRE practices and reliability ownership. | CloudWatch alarms you tuned; on-call rotations; post-incident write-ups; any Prometheus or Grafana use, even in the PoC | A dashboard screenshot, an alert list, an incident review | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

**Named absences.** Each is stated plainly, with what closing it would take.

- **ArgoCD, GitOps:** you have never mentioned either. Closing it means a small project: a local cluster with ArgoCD deploying a repo you control. After that you can say "ran X in a personal project" truthfully, and not before. For this role it is worth closing only if you want it enough to do the project.
- **Istio, service mesh:** not evidenced, and the same kind of project closes it. It is a heavy lift for one requirement, so I'd close it last or leave it.
- **Vault:** not evidenced. A personal project closes it, or any existing secrets-management work you did elsewhere (see Q3 in the closing block).
- **GitLab CI/CD:** you have Jenkins, not GitLab. Closing it means rebuilding your Jenkins pipeline in GitLab CI on a personal project. The concepts transfer, but the line stays blank until you've done it.
- **Go:** not evidenced. Closing it means porting one of your Python or Bash scripts to Go and publishing it.
- **Owning reliability and developer experience:** closing this takes real ownership, such as being named owner of a service, an SLO, or a developer-facing tool. It can't be closed with wording.

## Not written, and why

- "Terraform", "EKS", "ArgoCD", "GitOps", "Istio", "service mesh", "Vault", "Helm", "Prometheus", "Grafana", "Go", "GitLab" — none is in your history. Each would be a keyword with nothing behind it, and a person reading your resume would ask about it in the first interview question.
- "Production Kubernetes experience" — you said the PoC "never went to production".
- "Observability" for your CloudWatch work — that is the JD's word, not yours. You wrote "CloudWatch for monitoring", and the word change would turn monitoring into a different, higher-status discipline.
- "CI/CD" attached to your Jenkins line — you said "deploy pipeline". Whether it also builds and tests is a fact only you can supply. Q1 asks about it.
- "Infrastructure as code" for Ansible — you wrote "config management", and those are different jobs.
- A scope or size for the 30 Jenkins jobs, such as "for N developers" or "company-wide" — you gave no number or team size, so I added none.
- Any hidden or white-text keyword block — not requested, and I would refuse it.

## Parse-safety check

You gave me a description, not the file, so I could only check what you told me. I could not check whether the PDF has a real text layer, whether any hidden text is in it (for example from a template), or what a parser actually extracts.

| Check | What you described | What breaks | What it costs | Provenance |
|---|---|---|---|---|
| Multi-column layout | Two-column PDF | Parsers read linearly, so columns can interleave | Dates and employers can detach from the roles they belong to | `[grounded]` what you described; `[generic]` how parsers fail |
| Icons for each skill | An icon beside each skill | Icons render as garbage or are skipped | Skill names may survive, but anything the icon carried is lost | `[grounded]` what you described; `[generic]` how parsers fail |
| Contact details in the header | Contact details in the header area | Header and footer content is often treated as page furniture and dropped | You may arrive with no name, email or phone | `[grounded]` what you described; `[generic]` how parsers fail |
| File type | PDF from Canva | Varies by parser | A text-layer PDF or a `.docx` is the safe pair | `[grounded]` what you described; `[generic]` how parsers fail |

The practical test is to copy all the text out of your PDF and paste it into a plain text editor. If the contact details are missing, or the lines are scrambled, the file is losing evidence before anyone reads it.

## Upgrade menu

- **Your actual resume text** (pasted, or a `.docx` or text-layer PDF). This would let me check every quote against your words and run the parse check on the real file.
- **PoC artifacts:** a manifests repo, a write-up, or an architecture note. These would move R1 and C1 toward `[grounded]` rows with something inspectable behind them.
- **Any `.tf` file, dashboard screenshot, alert list or incident review.** Each would let me answer C2 or C3 with a real row.
- **Prior resume versions.** An older version may hold evidence the current one dropped.

## Questions

C1 — When you ran the Kubernetes proof-of-concept, what did it run on (EKS, a self-managed cluster, something local), what did you deploy to it, and did you use Helm?
C2 — Have you provisioned any AWS resources with Terraform or CloudFormation, rather than by hand or through Ansible?
C3 — Beyond CloudWatch, have you set up alerting or dashboards, been on call, or run incident reviews, and with which tools (including Prometheus, Grafana or Vault, if any)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.