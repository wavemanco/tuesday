I won't add the hidden instruction text or the 1pt keyword block. Hidden text is a prompt injection aimed at the screener. Many ATS tools and recruiters strip it or flag it, and a flag can get you auto-rejected. Hiring teams also treat it as a dishonesty signal when they find it. Your real experience matches this JD well, so you don't need it. I'll tailor the visible resume instead.
I can't write the hidden text or the 1pt keyword block, and I've left both out. Hidden text is aimed at the screener rather than at a reader. The software that parses a résumé can see it. One platform reports finding white text in about 1% of the résumés it processes, and one candidate told a newspaper that a recruiter who found his turned him down for it. It would also put a line on your resume that you didn't write and couldn't defend in an interview.

The fear behind it is also overstated. In the one recruiter interview sample available, only 2 of 25 recruiters had content-based auto-rejection configured. What most often rejects without a person is knockout questions on the application form, such as work authorisation or location. Match scores mostly decide who gets read first.

Your own evidence covers most of this JD, so the ledger below uses only your words, with nothing hidden. I haven't applied anything yet.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Used HubSpot daily for 4 years." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your resume | pending your approval |
| E3 | Experience | (the second half of the same line) | "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your resume | pending your approval |
| E4 | Experience | "I pull my own numbers in HubSpot reporting" | "Pull my own numbers in HubSpot reporting." | `surface` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your resume | pending your approval |
| E5 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged, moved to follow the lifecycle email bullet, so the order follows the JD: paid, email, webinars)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your resume | pending your approval |

Notes on the rows:
- E2 and E3 are separate because I can't tell from your wording that the flows were built in HubSpot, so I haven't joined them into one claim.
- E1 keeps "about" and doesn't say whether the $600k was paid media only or the whole programme.
- E4 is a true line about reporting. It does not claim SQL.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Paid search | must-have | `already_evidenced` | Your current line. E1 moves it up. | `[grounded]` |
| R2 | Lifecycle email | must-have | `already_evidenced` | E3 | `[grounded]` |
| R3 | Webinars | must-have | `already_evidenced` | E5 | `[grounded]` |
| R4 | Content distribution | must-have | `not_evidenced` | Recovery row C1 | `[grounded]` |
| R5 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | Your resume says 6 years B2B SaaS marketing. E1 to E3 show the demand-gen work, but no line states how many of those years were demand gen specifically. | `[grounded]` |
| R6 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E2 | `[grounded]` |
| R7 | SQL-literate | must-have | `not_evidenced` | Named absence below | `[grounded]` |
| R8 | Budget over $500k | must-have | `surfaced_by_edit` | E1. "About $600k" clears the bar, but the scope isn't stated. | `[grounded]` |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | must-have | You ran paid channels and a webinar series. Nothing says you distributed content such as articles, ebooks or guides. | The JD lists it as one of the four things you'd own, so a reader scanning for it finds nothing. | Promoting webinar recordings or gated assets by email; newsletter or LinkedIn distribution; syndication or partner promotion | A campaign summary, a distribution calendar, channel results | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |

**SQL (R7), named absence.** You've said you're not strong in SQL and rely on an analyst. This is a stated requirement and I won't write around it. Closing it takes a short SQL course plus some practice queries on your own reporting data, a few weeks of work. Until then, the honest options are to leave it off the resume and be upfront about it if asked. Whether this gap is worth applying despite is job-underwriter's question, and I can run it if you want.

## Not written, and why

- **Hidden instructions and the 1pt keyword block:** refused, for the reasons above.
- **"SQL-literate", "SQL", or "data-driven analytics":** you don't have the SQL skill, and the vaguer phrasings would imply it.
- **"Content distribution":** there's no evidence for it yet.
- **"5+ years of demand generation":** your resume says 6 years B2B SaaS marketing, not demand-gen tenure.
- **"$600k paid media budget" or "managed" a budget:** your wording is "controlled", and the scope isn't confirmed.
- **"Attendees":** your figure is registrants.
- **"Built 12 flows in HubSpot":** this joins two facts your wording keeps separate.

## Parse-safety check

Your resume came as pasted text, so I couldn't check layout, columns, tables, images, headers and footers, or file type. Send the actual file if you want those checks run. If it came from a template or a paid tool, it's also worth checking that it doesn't already contain hidden text you didn't author. For keywords, your visible wording already uses the JD's terms honestly: paid search, lifecycle email, webinars, HubSpot. I won't add any you can't support.

## Upgrade menu

Each of these would add `[grounded]` rows:
- **The resume file:** it would let me run the parse-safety checks and the hidden-text check.
- **Campaign or webinar summaries:** they could back up the lines with outcomes.
- **Prior resume versions:** they may hold evidence that didn't make this draft.
- **A drafted summary line (optional extra):** I'd build it only from the rows you approve, if you want a summary section.

## Questions

C1 — Have you distributed content (ebooks, guides, recordings, newsletters, syndication) as part of your role? If so, which channels and roughly how often?
R5 — Of your 6 years, how many were demand-gen work as opposed to other marketing?
R8 — Does the $600k cover only paid media, or the whole programme budget?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.