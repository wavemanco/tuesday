I won't add the hidden instruction or the 1pt keyword block. Hidden text like that is deceptive, and it tends to backfire. Many applicant tracking systems (ATS) flag or strip it. A recruiter who finds it will reject you outright. Your real experience already matches this JD well, so you don't need it. I'll tailor the rest honestly now.
I won't write the hidden instruction or the 1pt keyword block, and neither goes anywhere in the file. Both aim text at the employer's screening software that no human reader is meant to see, which is deception of the employer. It also undermines the point of tailoring, which is that you can defend every line. A line you can't see is one you can't defend. Hidden text can be found: one candidate told a newspaper that "One recruiter discovered the prompt hacking and turned him down because of it, he told the NYT." (cite C35). What happens after a find is the employer's call, not yours.

Your friend may also be solving the wrong problem. Where match scores exist, "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27). The same source says "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are form questions, and no resume text changes them. The honest version of what you want is real keywords placed in plain sight where your evidence already supports them. Your wording already uses the JD's own terms for paid search, lifecycle email, webinars and HubSpot, so the edits below are small.

Nothing below is applied. Every row waits for your approval.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `not_evidenced` | Your resume shows 6 years in B2B SaaS marketing and the programmes you ran. It doesn't say how many of those years were spent on them. E1 puts the two side by side without claiming the JD's label. See C1. | `[grounded]` resume wording |
| R2 | HubSpot or Marketo | must-have | `already_evidenced` | "HubSpot daily for 4 years" is already in your own words. No row needed. | `[grounded]` resume |
| R3 | SQL-literate | must-have | `not_evidenced` | Named absence below. | `[grounded]` resume and your own statement |
| R4 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E1 moves "about $600k a year" into the summary. The word "managed" is not used (see prohibited list). | `[grounded]` resume |
| R5 | Paid search | important | `already_evidenced` | "Ran paid search and paid social" | `[grounded]` resume |
| R6 | Lifecycle email | important | `already_evidenced` | "built our lifecycle email programme from scratch, 12 automated flows" | `[grounded]` resume |
| R7 | Webinars | important | `already_evidenced` | "Ran a monthly webinar series, average 300 registrants" | `[grounded]` resume |
| R8 | Content distribution | important | `not_evidenced` | Nothing in your material mentions it. See C2. | `[grounded]` resume |

Your lines already follow the order the JD lists the programmes in, so I'm proposing no reorder.

**R3, SQL-literate (named absence).** You told me you ask your analyst, so nothing in this ledger claims SQL. The HubSpot reporting line (E2) is true, but it is a different kind of work and I haven't tied it to SQL. Closing the gap would take learning to write your own basic queries (SELECT, JOIN, GROUP BY) against real campaign or CRM data, then adding the line once it's true. Without that, expect this must-have to read as unmet. Whether to apply anyway is job-underwriter's question, not this one.

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social; controlled a budget of about $600k a year." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| E2 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `split` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` resume | pending your approval |
| E3 | Experience | "I'm not strong in SQL — I ask our analyst" | *(removed)* | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` resume | pending your approval |

E1 keeps "about" and "controlled". The summary is two sentences, not one clause. Whether the $600k covers only paid or more is open (see C3), so the line doesn't say.

E3 removes a self-disclosure, not a claim, so nothing grows. It doesn't close the SQL gap. An interviewer may still ask, so be ready to say it plainly.

## Not written, and why

- **Hidden screener instructions and the 1pt keyword block.** Refused (see above).
- **Any SQL skill.** You said you rely on your analyst.
- **"Managed a budget over $500k."** "Managed" is the JD's verb. Your word is "controlled", and your sentence says "about $600k".
- **"5+ years of demand generation" or "owned demand generation."** These are the JD's phrases. Your resume says you ran specific programmes, and how long you ran them is open (C1).
- **"Senior Marketing Manager."** Your title is Marketing Manager. A retitle can clarify, never upgrade.
- **"Content distribution."** Nothing in your material supports it. Paid social is a different kind of activity.
- **Marketo.** Never mentioned in your material. The JD says "HubSpot or Marketo", and HubSpot already meets that.

## Gaps worth closing

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years B2B demand gen | must-have | 6 years in B2B SaaS marketing, plus paid search, lifecycle email and webinars. It doesn't say how long you ran them. | A reader checking for years of demand gen has to infer it, which is easy to skip past. | Years running paid search as a main duty; earlier roles that included email or webinar programmes; any year you took on paid before the 4 years of HubSpot | An ad-platform spend history, a campaign report, an earlier resume version | `[grounded]` what the resume says and omits; `[generic]` how screeners read tenure requirements |
| C2 | Content distribution | important | No mention. | The JD names it as part of the role, so silence leaves one of four named areas uncovered. | Promoting webinar recordings or gated assets by email or paid social; syndication or a partner newsletter; sharing content through a channel you ran | A distribution plan, a campaign report, a link to the content | `[grounded]` resume omission; `[generic]` what an unaddressed named area costs |

## Parse-safety check

You pasted text, not a file, so I could not run any of these: multi-column layout, tables and text boxes, images or skill bars, contact details in headers or footers, non-standard section headings, file type. Send the file (a `.docx` or a text-layer PDF is the safe pair) and I'll run them. I'll also flag any hidden text your template or an earlier tool may have left in without your knowing.

## Upgrade menu

- **The resume as a file** unlocks the parse check above and a hidden-text check.
- **Answers to C1 and C2** can turn two `not_evidenced` rows into real ones.
- **A spend report** (ad-platform or HubSpot) for the $600k would back the budget line with something checkable.
- **A webinar platform report** would do the same for the 300 average registrants.
- **An earlier resume version** may hold evidence this one dropped.

C1 — Roughly how many of your 6 years were spent running paid search, lifecycle email or webinars as a core part of the job?
C2 — Have you distributed content in any form (webinar recordings or gated assets by email or paid social, syndication, a partner newsletter)? What part was yours?
C3 — Does the $600k a year cover only paid search and paid social, or more, such as webinars and tools?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.