I've built your tailoring ledger. Nothing is applied yet, and every row is pending your approval.

**Scope of what I worked from.** I used your CV as you summarised it in your message (self-report), plus the dossier excerpt. Your quotes below are your own sentences from that message. Because I haven't seen the CV as a file, I can't say what else is on it, so there are no `cut` rows. I couldn't run the layout and parse checks either.

**Dossier use.** The role matches, so I'm using it. R1 and R2 stay `adjacent` / `transferability` at `medium` confidence, and I haven't upgraded either. Dossier edit E1 came through the audit again and is row E1 below. Both `rejected_inferences` are in the prohibited list unaltered.

## The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | *(playbook authorship is not its own line, per dossier E1)* | "Wrote the internal integration playbook the whole team uses." | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV summary; dossier E1 re-audited | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV summary | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to the second bullet, directly after E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV summary | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." as its own line near the top, not buried in a tools list | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV summary | pending your approval |
| E5 | Summary | *(no current line)* | "Seven years as a solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor"; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV summary | pending your approval |

- **E1 audit.** It keeps your scope, "the whole team uses", and doesn't widen it to company-wide. It keeps your verb, "wrote". The line doesn't mention products or specs.
- **E2 and E3.** They change position only. "Led" and "end to end" stay as you wrote them. "For product" stays on E3 because it shows the feedback went to the product team and that you weren't deciding the roadmap.
- **E4.** "Comfortable in" stays. I haven't upgraded it to "expert" or "proficient".
- **E5.** It is two separate sentences. Joined into one, "led" could read as covering the whole seven years. The summary does not say "product", "PM" or "transitioning".
- **Title.** I made no `retitle` row. An equivalent title isn't available, and "Product" in any title would be an upgrade.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Adjacent work in E2, E3 and E1 (the dossier's `transferability` call). Roadmap ownership and prioritisation authority aren't evidenced, and no line can claim PM years. See C1. | `[grounded]` the dossier's R1 row; `[generic]` titled-years requirements are often screened literally |
| R2 | Shipped API or platform products | must-have | `not_evidenced` | You integrated and implemented the vendor's APIs, per E2. The dossier carries it as `adjacent`, `medium`. No line says you shipped one. See C2. | `[grounded]` the dossier's R2 row and your CV summary |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4, backed by E2 | `[grounded]` your CV summary |
| R4 | Stakeholder management | important | `surfaced_by_edit` | Through position only (E2, E3). Your sentences describe client-facing integration leadership, and the word "stakeholder" is not written for you. | `[grounded]` your CV summary |
| R5 | Discovery with integration partners | important | `surfaced_by_edit` | E3. Your sessions collected client feedback, so they are adjacent to partner discovery and not the same thing. | `[grounded]` your CV summary; `[generic]` roadmap-input sessions are typically a weaker signal than running discovery |
| R6 | Define adoption metrics | important | `not_evidenced` | Nothing in your summary. See C3. | `[grounded]` your CV summary does not mention metrics |
| R7 | Write specs and drive delivery with engineering squads | important | `not_evidenced` | "OpenAPI specs" is an API-contract tool and doesn't show you writing product specs or driving delivery. Named absence: closing it would take one real example of a feature you specified and followed through to release. If one exists, say so. If not, this is the gap to carry into the interview honestly. | `[grounded]` your CV summary |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM, specifically roadmap ownership and prioritisation authority | must-have | You ran the roadmap-input sessions. Who decided what got built isn't stated. | This is the dossier's named weak point on a must-have. Without it, the case rests on adjacency. | A backlog item you ranked; a trade-off you decided between two client requests; a feature you got into a release | A prioritised list, a roadmap or review deck with your input, a ticket trail | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Shipped API or platform products | must-have | You led client integrations of "our REST APIs". It doesn't say you launched or scoped one. | A second must-have sitting at `adjacent`, `medium`. | An endpoint, SDK, sample, developer docs or a webhook that you scoped or launched, not only used | A launch note, a changelog entry, a spec or a docs page you wrote | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Define adoption metrics | important | No numbers or tracking appear in your summary. | The role's last duty, and nothing supports it yet. | Time-to-first-successful-call, integrations per quarter or a go-live rate you tracked for the team | A dashboard export, a report or a QBR slide | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

## Not written, and why

- **"3+ years product management" or any PM-flavoured title.** You've never held the title and it's a must-have. The adjacent work is in E1 to E3, and the gap is named in R1.
- **"Owned the roadmap".** Your sessions collected input "for product". Owning a roadmap is a different job, and an interviewer will test the difference in one question.
- **"Shipped API products".** You integrated them. Shipping one is the other side of the transaction.
- **"Partners" in place of "clients".** The JD's word is "partners"; your word is "client". Swapping them changes who you stood across from.
- **"Drove delivery", "wrote specs for engineering squads" and "defined adoption metrics".** Nothing in your summary supports any of the three. See R6 and R7.
- **"Stakeholder management" as a label on your work.** The JD's wording, not yours. It would be borrowing the JD's vocabulary for your own history.
- **"Company-wide playbook".** You wrote that the whole team uses it, and that scope stays.
- **Rejected inference from the dossier:** "built an internal request-triage tool". It was a memory lead and you couldn't confirm you owned it. It stays out.
- **Rejected inference from the dossier:** "has been the customer of a partner API platform". You worked vendor-side. The relationship stays as you lived it.

## Parse-safety check

I could not run any of the checks (layout, tables, headers and footers, images, file type), because your CV arrived as text rather than a file. I'd run them on the file.

## Upgrade menu

- **Your CV as a file:** it unlocks the parse-safety check, `cut` rows for lines that don't help with this role, and verbatim quotes in place of my reading of your summary.
- **Dates and titles per role:** a precise `compress` of the 7 years.
- **A redacted copy of the integration playbook, or an OpenAPI spec you wrote:** each is an inspectable artifact that would take the technical-fluency and playbook evidence from `medium` toward `high`.
- **A roadmap-input session write-up, or a client request that ended up shipped:** this would turn the R1 and R5 adjacency into something concrete, if it exists.

## Questions

C1 — In the roadmap-input sessions, did you ever decide or rank what product built, or did you pass the feedback on and product decided?
C2 — Have you scoped or launched anything developer-facing, such as an endpoint, SDK, sample or docs set, as opposed to integrating what already existed?
C3 — Did you ever track a number for how clients adopted the APIs, such as time to go-live or time to first call?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.