I won't add the hidden instructions or the 1pt keyword block. Both are attempts to deceive the screener, and they backfire. Many ATS tools and recruiters now flag hidden text, and it can get you auto-rejected or blacklisted. Your real experience matches this JD well, so you don't need them. I'll tailor the rest normally.
Your actual SQL level stays in the resume, which means I'm not writing SQL-literate in. The hidden-text block isn't in the ledger either, and I've recorded the refusal under "Not written" below.

I overstated the risk in my first message. I said hidden text can get you auto-rejected or blacklisted. The sources I have show that platforms detect white text, and one candidate told a newspaper that a recruiter who found it turned him down. They don't show blacklisting, or how often rejection follows. My main reason for refusing is different: you'd be putting a line on your resume that you didn't write and couldn't defend.

I only have the five sentences you pasted, so nothing below includes company names, dates or titles.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social, budget I controlled was about $600k a year. HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows. Ran a monthly webinar series, average 300 registrants." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your pasted resume | pending your approval |
| E2 | Skills | *(no current line)* | "HubSpot (daily for 4 years)" | `surface` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your pasted resume | pending your approval |
| E3 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "I pull my own numbers in HubSpot reporting" | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your pasted resume | pending your approval |

- **E1:** The four sentences stay separate and in your words. The only change is position, so the channels and the budget are the first thing a reader meets.
- **E3:** This drops the SQL admission from the line. It does not add a SQL claim. If you'd rather keep the line as written, reject E3.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 puts "6 years B2B SaaS" beside the channels you ran. Your sentence says B2B SaaS marketing years, not demand-gen years, so how many of the six were on these programmes is open (see C2). | `[grounded]` your resume; `[generic]` the posting's years requirement is usually read against the role title and channels |
| R2 | HubSpot or Marketo | must-have | `already_evidenced` | "HubSpot daily for 4 years" is already in your line. E2 makes it findable in a Skills section. | `[grounded]` your resume |
| R3 | SQL-literate | must-have | `not_evidenced` | Not covered. See the named absence below. | `[grounded]` your resume |
| R4 | Managed a budget over $500k | must-have | `already_evidenced` | "budget I controlled was about $600k a year", kept as you wrote it, including "about" and "controlled". | `[grounded]` your resume |
| R5 | Paid search | important | `already_evidenced` | Your paid search and paid social sentence, in E1. | `[grounded]` your resume |
| R6 | Lifecycle email | important | `already_evidenced` | Your HubSpot sentence (12 automated flows, built from scratch), in E1. | `[grounded]` your resume |
| R7 | Webinars | important | `already_evidenced` | Your monthly series, about 300 registrants on average, in E1. | `[grounded]` your resume |
| R8 | Content distribution | important | `not_evidenced` | Nothing in your material. Paid social is not the same work. See C1. | `[grounded]` your resume |
| R9 | Owning demand generation overall | important | `not_evidenced` | You describe running individual programmes, not owning the whole demand plan. See C2. | `[grounded]` your resume; `[generic]` the posting's "Own demand generation" is read as whole-function scope |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | No content programme is mentioned. Paid social is the closest channel. | It is one of the four named areas of the role, so a reader who sees three of four will notice. | Newsletter sends; promoting webinar recordings or gated assets; syndication or partner placements; organic social; repurposing content across channels | A channel calendar, a distribution report, or a content performance export | `[grounded]` what the resume does and does not say; `[generic]` what a missing named area costs on applications of this kind |
| C2 | Years of demand gen and overall ownership | must-have | "6 years B2B SaaS" and several programmes, but not how long you ran them or whether you set the overall plan. | The role says "Own demand generation", and the years requirement is 5+. | Setting the quarterly demand plan; splitting budget across channels; reporting results to leadership; being the person who decided which channel got the money | A budget plan, a quarterly plan, or a leadership report | `[grounded]` what the resume does and does not say; `[generic]` how this posting wording is usually read |

Named absence, which asks no question:

| # | Requirement | Priority | What your resume currently shows | What closing it would take | Provenance |
|---|---|---|---|---|---|
| A1 | SQL-literate | must-have | You pull your own numbers in HubSpot reporting and ask your analyst for SQL. That is not SQL. | Writing your own queries (joins, aggregation, filtering) against your CRM or warehouse data, and being able to show one. A few weeks of practice on real marketing data would do it. Until then the line stays out, and an interview question on it should get an honest answer. If you also want to ask whether this gap makes the role worth applying to, that is job-underwriter's call. | `[grounded]` your resume; `[generic]` how a stated skill requirement is tested |

## Not written, and why

- **Hidden white text and a 1pt keyword block** — refused, as explained above.
- **Any SQL claim**, including "SQL-literate", "queried" or "data analysis in SQL". You ask your analyst, so any of these would be false.
- **"Managed a $600k budget"** — you wrote "controlled". "Managed" is the posting's word, and I don't carry it into your history.
- **"6 years of B2B demand generation"** — you wrote 6 years in B2B SaaS marketing, and nothing says all six were demand gen.
- **"Senior Marketing Manager"** or "Owned demand generation" as a title or scope — your title is Marketing Manager, and ownership of the whole plan is unconfirmed (C2).
- **Any content-distribution line** — nothing supports it until C1 is answered.
- **Marketo or other tools from the posting's wording** — you named HubSpot only.

## Parse-safety check

Your resume arrived as pasted text, so most checks could not run.

| Check | Could I run it? | Finding |
|---|---|---|
| Multi-column layout | No | Needs the file |
| Tables and text boxes | No | Needs the file |
| Images, icons, skill bars | No | Needs the file |
| Headers or footers holding contact details | No | Needs the file |
| Section headings | Partly | I can't see your headings. Standard labels like Summary, Experience and Skills are the safe choice. |
| File type | No | A `.docx` or a text-layer PDF is the safe pair |
| Hidden text already in the file, for example from a template | No | Needs the file |

## Upgrade menu

Offer, not part of this ledger: send the resume as a file and I'll run the layout checks and look for hidden text a template may have left. Any of these would also let me raise a claim from your word to something inspectable: a budget plan or finance sign-off (R4), a webinar platform report (R7), a HubSpot workflow list (R6), or a campaign performance export (R5).

C1 — Have you done any content distribution, such as newsletter sends, pushing webinar recordings or gated assets, syndication, or organic social? If so, what did you do and roughly when?
C2 — Of your 6 years, how many were spent running paid, lifecycle and webinars? And did you set the overall demand plan and budget split, or own part of it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.