I'll tailor the resume, but I won't add the hidden text or the 1pt keyword block. I'll load the resume-tailoring workflow now.
I won't add the hidden instruction block or the 1pt keyword block. Both are text meant for an automated screener, not for a person reading your resume. They're aimed at the employer's tool, so they deceive the employer. They also put a line in your resume that you didn't write and couldn't explain if asked. Software that parses the file can see hidden text, so you'd carry the risk of being found. The legitimate version is below: a parse-safety check, your real keywords placed where your own evidence supports them, and your strongest evidence first.

Here is the tailoring itself. Nothing is applied until you approve rows.

**Edit ledger (resume_edits_pending_approval)**

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | "Marketing Manager, 6 years B2B SaaS." | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social, controlling a budget of about $600k a year. Built our lifecycle email programme from scratch." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "built our lifecycle email programme from scratch" | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch, 12 automated flows; HubSpot daily for 4 years." | `reorder` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your resume | pending your approval |
| E4 | Skills | *(no current line)* | "Pull my own numbers in HubSpot reporting." | `surface` | "I pull my own numbers in HubSpot reporting" | `[grounded]` your resume | pending your approval |

- **E1** repeats existing sentences and keeps the claims separate. I kept your verb "controlled" rather than the JD's "managed".
- **E3** changes order only, so "daily for 4 years" stays attached to HubSpot and isn't stretched to cover the email build.
- **E4** is a separate line on purpose. It shows you work in HubSpot reporting. It doesn't claim SQL.
- The webinar line ("Ran a monthly webinar series, average 300 registrants.") stays as written.

**Coverage map**

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Paid search | must-have | `already_evidenced` | "Ran paid search and paid social"; tightened in E2 | `[grounded]` |
| R2 | Lifecycle email | must-have | `already_evidenced` | 12 flows built from scratch; E3 moves it first | `[grounded]` |
| R3 | Webinars | must-have | `already_evidenced` | Monthly series, average 300 registrants; no edit | `[grounded]` |
| R4 | Content distribution | must-have | `not_evidenced` | Nothing in your material; see C1 | `[grounded]` |
| R5 | 5+ years B2B demand gen | must-have | `not_evidenced` | You have 6 years in B2B SaaS marketing. The resume doesn't say how many of them were demand gen; see C2 | `[grounded]` |
| R6 | HubSpot or Marketo | must-have | `already_evidenced` | HubSpot daily for 4 years; E3 and E4 | `[grounded]` |
| R7 | SQL-literate | must-have | `not_evidenced` | HubSpot reporting is adjacent, not SQL; see the gap note below | `[grounded]` |
| R8 | Budget over $500k | must-have | `surfaced_by_edit` | About $600k a year, in E1 and E2. The "about" stays, and C3 asks about scope | `[grounded]` |

**Gap handling**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | must-have | Paid and email channels and webinars; nothing about distributing content | It is one of the four named areas you'd own, so a reader finds it missing | Promoting webinar recordings or gated content through email or paid; syndication or partner placements; social or newsletter distribution you ran | A campaign recap, a distribution calendar, a channel report | `[grounded]` what the resume does and doesn't say; `[generic]` what an absence costs on a posting like this |
| C2 | 5+ years B2B demand gen | must-have | 6 years of B2B SaaS marketing; the demand-gen share isn't stated | The requirement is stated in years, and "marketing" alone doesn't show how many were demand gen | Years you ran paid, lifecycle or webinars as your main job | Past job titles and dates, a role scope doc | `[grounded]` what the resume says; `[generic]` how years requirements are read |

**SQL, a named absence.** You don't write SQL, and the posting lists it as a requirement. Closing it would take hands-on querying practice plus a real example you could show, such as queries on a marketing dataset. If you don't want to build that, it stays an open gap on this application. I won't write around it, and nothing in the ledger implies it.

**Not written, and why:**
- "SQL-literate" or any SQL skill. You ask your analyst, so the claim would fail on the first technical question.
- "Managed a $600k budget." Your word is "controlled", and the budget figure is "about".
- "Demand generation" as a description of your history. That is the JD's vocabulary, and nothing in your material says how many of your years were demand gen.
- "Content distribution" experience. It isn't in what you gave me.
- The hidden screener instruction and the 1pt keyword block, per the refusal above.

**Parse-safety check.** Your resume arrived as pasted text, so I couldn't run the layout checks (columns, tables, text boxes, header or footer content). I also couldn't check the file for hidden text you didn't author, for example from a template. If you send the actual file, I'll run all of these. A .docx or a text-layer PDF is the safe format.

Whether the SQL gap makes this role worth your time is a separate decision. The job-underwriter module covers that, if you want it.

**Upgrade menu** (offers, built only if you ask):
- Send the resume file, and I'll run the parse and hidden-text checks properly.
- Send a screenshot or list of your 12 HubSpot flows, and I can tie each claim to something inspectable.
- Send a paid search spend summary or a webinar report, and the budget and registrant lines can be checked against it.

**Questions**
- C1: Did you distribute content in any form, such as promoting webinar recordings or pieces through email, paid or social? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- C2: Roughly how many of your 6 years were spent running paid, lifecycle email or webinars as your main job? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- C3 (for E1 and E2): Is the $600k a year only the paid search and paid social spend, and did you control that level across your time there or only recently? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.