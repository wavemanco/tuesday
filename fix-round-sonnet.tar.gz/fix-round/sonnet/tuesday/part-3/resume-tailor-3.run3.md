Reading the last playbook sections on the upgrade menu and scope, then I'll deliver the ledger.
Nothing is applied yet. Every row below is a proposal, pending your approval. I used the dossier's `role_profile`, the two evidence rows you pasted (R1, R2), its pending edit E1 and its two rejected inferences. You pasted only an excerpt, so I haven't seen the rest of its evidence map. The dossier edit E1 went through the same audit as my own rows. I only have your summary of the CV, not its layout. So I quote your sentences as you gave them, and the "current line" cells can't show where each sits today.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | The line that currently carries it (not visible to me) | "Wrote the internal integration playbook the whole team uses" as its own line | `split` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV; inherited from dossier E1 | pending your approval |
| E2 | Experience | *(position not visible to me)* | *(unchanged, moved to the first line under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | *(position not visible to me)* | *(unchanged, moved directly after E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Experience | *(wherever your tools currently sit)* | "Comfortable in Postman, SQL, OpenAPI specs" as its own line near the top of the role | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |

The audit changed three things:
- **No verbs changed.** "Led", "Wrote", "Ran" and "Comfortable in" are all yours.
- **Scope stays as you gave it.** The playbook is "the whole team" and the integrations are "30+ client integrations".
- **No vocabulary borrowed from the JD.** "Roadmap-input sessions collecting client feedback" does not become "discovery" or "roadmap ownership". The tools line stays "Comfortable in" and does not become "expert".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Dossier: `adjacent`, `transferability`, `medium`. E1–E3 are adjacent work, not PM years. You never held the title. | `[grounded]` dossier evidence_map, your CV |
| R2 | Shipped API or platform products | important | `not_evidenced` | Dossier: `adjacent`, `medium`. You integrated clients onto existing APIs. Nothing shows you shipped one. See C2. | `[grounded]` dossier evidence_map, your CV |
| R3 | Technical fluency | important | `surfaced_by_edit` | E2 and E4 | `[grounded]` your CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3 carry the client-facing work. The lines don't use the phrase. | `[inferred]` from client-facing integrations and feedback sessions |
| R5 | Roadmap ownership and prioritisation | important | `not_evidenced` | Dossier R1: "roadmap ownership and prioritisation authority not evidenced". E3 is adjacent. See C1. | `[grounded]` dossier reasoning, your CV |
| R6 | Discovery with integration partners | important | `not_evidenced` | E3 is adjacent, but those sessions were with clients. See C1. | `[grounded]` your CV |
| R7 | Writing specs and driving delivery with two squads | important | `not_evidenced` | "OpenAPI specs" is a tool you are comfortable in, not a spec you wrote for engineering. See C2. | `[grounded]` your CV |
| R8 | Adoption metrics | important | `not_evidenced` | Nothing in the CV. See C3. | `[grounded]` your CV |

## Recovery per gap (pending your approval)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Roadmap ownership; discovery with partners | important | Roadmap-input sessions that collected client feedback for product. Nothing shows what happened to that feedback or who decided. | The JD's first duty is owning the roadmap, and your lines stop at collecting input. | A client request from those sessions that reached the product plan; your part in ranking or arguing for it; a session format you designed | A session summary, a feedback log, a ticket or roadmap entry | `[grounded]` what the CV says and omits; `[generic]` what this costs on PM applications |
| C2 | Shipped API products; specs and delivery | important | 30+ integrations onto your vendor's REST APIs, plus comfort with OpenAPI specs. Nothing shows a change to those APIs that you drove. | "Shipped" and "write specs" are the two claims an integration background most often cannot back. | A new endpoint, field or fix you wrote up for engineering that shipped; acceptance criteria you wrote; a launch you coordinated | A ticket or spec you wrote, a release note, an API changelog entry | `[grounded]` what the CV says and omits; `[generic]` what this costs on PM applications |
| C3 | Adoption metrics | important | No figures beyond "30+". | The JD asks you to define adoption metrics, and a number you actually tracked is the nearest evidence. | How many integrations went live; time to first successful call; usage after go-live | A go-live report, a dashboard, a handover document | `[grounded]` what the CV says and omits; `[generic]` what this costs on PM applications |

**R1 named absence.** You have no PM years, and the JD makes them a must-have. No wording closes that. It closes only if C1 and C2 turn up work a reader would count as PM scope. Otherwise it stays a stated gap: you'd be applying as an adjacent candidate, and the dossier's `conditional_go` already assumes that.

## Not written, and why

- **"Built an internal request-triage tool"**: carried from the dossier. It was a memory lead and you could not confirm ownership.
- **"Has been the customer of a partner API platform"**: carried from the dossier. You worked vendor-side.
- **"3+ years of product management"**, or any PM title or "product" retitle. You never held the title and the JD makes it a must-have. Retitling "solutions engineer / implementation lead" would be an upgrade, not an equivalent.
- **"Owned the roadmap" or "prioritised the backlog".** Your sessions collected feedback for product. Who decided isn't evidenced.
- **"Shipped API products" or "launched API platform features".** You led integrations onto APIs your vendor already had.
- **"Ran discovery with integration partners".** That is the posting's phrase. Yours is "client feedback", and "partners" would move you to a different side of the table.
- **"Wrote product specs" or "drove delivery with engineering squads".** "OpenAPI specs" appears only as a tool you are comfortable in.
- **"Defined adoption metrics".** There is no number or tracking anywhere in the CV.

## Parse-safety check

Your CV reached me as prose, so none of the layout checks could run: columns, tables and text boxes, images, headers and footers, section headings, file type.

## Upgrade menu

- **Your CV as text or a file.** I could quote your current lines exactly and run the parse-safety check.
- **A session summary, a spec or ticket you wrote, or a go-live report.** Any of these could move R5 to R8 from `not_evidenced` to a row.
- **The complete dossier.** I could check the rest of its evidence map against these rows.
- **A summary line.** I can draft one from your approved rows only, if you want it. Nothing is drafted unless you say yes.

## Questions

C1 — Did any request from your roadmap-input sessions end up on the product roadmap, and what was your part in getting it there?
C2 — Was there a change to your company's own REST APIs (an endpoint, a field, a fix) that you wrote up for engineering and that shipped?
C3 — Do you have any numbers on how your client integrations fared after go-live?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.