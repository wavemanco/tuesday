I tailored this from the summary you pasted, not from your CV's actual bullets. I'm treating your sentences as self-report. Every "Current line" cell reads "not supplied" because I haven't seen your CV file, so the real lines may differ. Nothing below is applied yet.

## Edit ledger

All six rows are `resume_edits_pending_approval`. The quotes in "Traces to" are copied from what you sent.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | *(not supplied)* | "Own three services in the ledger pipeline; one handles about 40k requests/minute at peak." | `surface` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` | pending your approval |
| E2 | Experience | *(not supplied)* | *(unchanged, moved directly under E1)* "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` | pending your approval |
| E3 | Experience | *(not supplied)* | "On-call every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` | pending your approval |
| E4 | Experience | *(not supplied)* | "Onboard new hires on my team, usually two or three a year, pairing with each for their first month." | `surface` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` | pending your approval |
| E5 | Skills | *(not supplied)* | *(unchanged, moved to lead the skills block, ahead of Kafka, Postgres, Terraform, gRPC, Datadog)* "Go and Rust daily for 4 years, Python before that." | `reorder` | "Go and Rust daily for 4 years, Python before that." | `[grounded]` | pending your approval |
| E6 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years. Currently at a payments company, owning three services in the ledger pipeline." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "Currently at a payments company."; "I own three services in our ledger pipeline" | `[grounded]` | pending your approval |

I kept E6 as three claims that each trace to one of your sentences, so none of them gains scope.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `already_evidenced` | "Senior Software Engineer, 7 years" is already enough. E6 only moves it to the top. | `[grounded]` |
| R2 | Production Go | must-have | `surfaced_by_edit` | E5 and E6 put "daily for 4 years" first. You didn't say which of your three services are Go, so I didn't claim any are (see Q3). | `[grounded]` |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | The nearest evidence is E1's 40k requests/minute. Kafka appears only in your tools list, and a listed tool isn't a tool owned. See C1. | `[grounded]` what the CV says; `[generic]` what a reader infers from a tools list |
| R4 | Strong incident response | must-have | `surfaced_by_edit` | E3 | `[grounded]` |
| R5 | Experience mentoring | must-have | `surfaced_by_edit` | E4. Your sentence says onboarding new hires. It doesn't say their level or call it mentoring, so E4 keeps your wording. | `[grounded]` |
| R6 | Own services handling high request volume | important | `surfaced_by_edit` | E1 states the volume as the figure and doesn't call it "high-scale". | `[grounded]` |
| R7 | Drive down p99 latency | important | `surfaced_by_edit` | E2 | `[grounded]` |
| R8 | Own on-call for your services | important | `surfaced_by_edit` | E3. Yours is a rotation every fourth week, so I didn't write "owned on-call". | `[grounded]` |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material touches it. See C2. | `[grounded]` |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | A 40k requests/minute service in a ledger pipeline, plus Kafka in the tools list. It doesn't show what you designed or decided about how services coordinate. | A reader checking this requirement has only a volume figure and a tool name to go on. | A Kafka consumer or producer you owned, and how you handled duplicates or ordering; keeping ledger writes and balance reads consistent; a failure in one of your three services under peak load | A design doc, an incident write-up, or a diagram of the pipeline you can describe | `[grounded]` what the CV says; `[generic]` what a screener does with a tools list |
| C2 | Partner with product on roadmap sequencing | important | Nothing. The material is entirely engineering delivery. | The JD lists it as a core duty, and this CV is silent on it. | Deciding what to build first with a product owner; pushing back on or re-ordering a request because of a latency or reliability cost; scoping the cache rework | A planning doc, a roadmap ticket thread, or the rationale for the cache project | `[grounded]` what the CV says; `[generic]` how roles of this kind weigh it |

If C2 has no answer, the honest position is that this is a gap and not a presentation problem. The role asks for it explicitly. It may not need closing before you apply, but you should expect to be asked about it.

## Not written, and why

- **"Designed and shipped Go services"**: you said you own three services. You didn't say you designed them, or which are in Go.
- **"Mentored mid-level engineers"**: your sentence is about onboarding new hires, and their level isn't stated.
- **"Owned on-call for my services"**: yours is a shared rotation every fourth week.
- **"Led incident response"**: you were incident commander on six incidents, which is narrower.
- **"High-scale distributed systems"**: 40k requests/minute is one figure, and Kafka is a tools-list entry.
- **"Partnered with product"**: nothing supports it.
- **A derived "75% latency reduction"**: I kept your 380ms to 95ms. I can add the percentage if you want it, but it would be a figure you didn't write.

## Parse-safety check

You pasted text, so I couldn't run any of the checks. That includes layout and columns, tables and text boxes, images or skill bars, header and footer contents, and file type. Send the file and I'll run them. The headings I proposed are the standard ones: Summary, Experience, Skills.

## Upgrade menu

These are offers, and I'll build them only if you approve.
- **Your CV file**: I'd quote your real current lines in the ledger and run the parse-safety check.
- **A dashboard, postmortem or design doc for the p99 work or one of the incidents**: it would let me raise those rows from your self-report to inspectable evidence.
- **Answers to C1 and C2**: I'd confirm them back to you first, then write rows from them.

## Questions

C1: In the ledger pipeline, what did you personally design or decide about how services exchange data (Kafka topics, retries, idempotency, ordering, ledger-versus-read consistency)?
C2: Have you helped decide what to build first with a product partner, and on what project?
Q3 (for E1 and E5): Which of your three services are written in Go, and which in Rust?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.