I'm still reading the resume-tailor reference files. Next is the rest of the coverage, gaps and parse-safety rules, and then I'll build the ledger.
Dev, I've built this as an approve-first edit ledger rather than a rewritten resume, because your resume can't be rewritten into a data-engineering match without adding claims. I treated your pasted summary as the resume and assumed Summary, Experience and Skills sections, since I only have prose. Nothing below is applied yet. Whether the 3+ years must-have makes this role worth applying to is job-underwriter's question, not this ledger's.

## Edit ledger

`resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail." / "Built and maintained about 25 dbt models including the core orders mart." / "I designed the star schema for the orders mart with our then-DE." (three separate sentences, not one clause) | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first line of Experience, above the SQL line)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved to the second line of Experience)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | Line 1: "Python for analysis — pandas." Line 2: "Some scripting to pull vendor APIs on a cron." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your resume | pending your approval |
| E5 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | Line 1: "Fixed our nightly dbt job when it breaks." Line 2: "Added tests to our nightly dbt job." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your resume | pending your approval |
| E6 | Skills | *(no current line)* | "SQL (Redshift), dbt, Python (pandas)" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your resume | pending your approval |

- E1 keeps "with our then-DE" and the qualifier "about 25". E4 keeps "some".
- The sentences weren't merged into one clause. That would make the star schema read as something you did alone.
- Airflow, Spark and Kafka appear nowhere, because you've never used them.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | `not_evidenced` | Your title and years are analyst. The adjacent work is in E1 to E5, but no row counts it as data engineering. | `[grounded]` "Senior Data Analyst, 5 years, retail." |
| C2 | Production Python | must-have | `not_evidenced` | E4 puts the cron API scripts on their own line, but "some scripting" doesn't establish production use. See recall prompt C2. | `[grounded]` "some scripting to pull vendor APIs on a cron" |
| C3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | A cron and a nightly dbt job are stated. What schedules the dbt job is not. See recall prompt C3. | `[grounded]` "Never used Airflow or Spark." |
| C4 | Dimensional modelling | must-have | `surfaced_by_edit` | E1 and E3. The star schema was designed "with our then-DE". | `[grounded]` "I designed the star schema for the orders mart with our then-DE." |
| C5 | Build and own batch pipelines | important | `not_evidenced` | E5 shows maintenance of one nightly job. Building and owning are not stated. See named absences. | `[grounded]` "I've fixed our nightly dbt job when it breaks" |
| C6 | Data quality | important | `surfaced_by_edit` | E5, line 2. The tests are evidenced, but their coverage is not. | `[grounded]` "added tests to it" |
| C7 | Own SLAs | important | `not_evidenced` | Nothing in your material mentions a delivery or freshness commitment. See recall prompt C7. | `[grounded]` what your resume does not say |
| C8 | Model the warehouse | important | `already_evidenced` | E2 moves it up. What's evidenced is the marts layer in dbt, not the whole warehouse. | `[grounded]` "Built and maintained about 25 dbt models including the core orders mart." |
| C9 | Partner with analytics on requirements | important | `not_evidenced` | You sat on the analytics side of that relationship. No row claims the data-engineering side. See named absences. | `[grounded]` "Senior Data Analyst" |
| C10 | Streaming experience | preferred | `not_evidenced` | Nothing to surface. See named absences. | `[grounded]` "Never touched Kafka." |

Spark appears only in the JD's duties list, not its requirements, so it has no row.

## Recovery: recall prompts

The questions these rows imply are asked once, in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C2 | Production Python | must-have | Python for analysis, plus "some scripting" that pulls vendor APIs on a cron. Nothing on who depends on it or what happens when it fails. | Production Python is a must-have, and "scripting" alone usually reads as analyst-side work. | A script whose output a dashboard or the orders mart depended on; failure alerting or retries you added; a script that others maintain or run | The script repo, the cron entry, a failure alert or log | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Airflow or equivalent orchestration | must-have | A nightly dbt job you fixed and added tests to. What schedules it is not stated. | Orchestration is a must-have, and the posting accepts "equivalent". Whether your scheduler counts depends on what it is. | Setting or changing the job's schedule; adding a dependency between jobs; configuring retries or alerts; handling a backfill | The job config, scheduler run history, or an alert setup | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C7 | Own SLAs | important | Tests were added. No delivery-time or freshness commitment is mentioned. | The posting makes SLAs a named duty alongside data quality. | A promised "ready by" time for the orders mart; a stakeholder complaint you handled; a freshness check you wrote | A message or doc stating the commitment; a freshness test | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

## Named absences

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| C1 | 3+ years data engineering | You have 5 years as an analyst with some pipeline-adjacent work. That is not 3 years of data engineering, and no edit changes it. | Time in a data-engineering role, or a recruiter who counts the adjacent work. Your answers to C2, C3 and C7 are what would show how much of it is real. For this role it may not be closable by wording. | `[grounded]` the resume's title and years; `[generic]` how experience-length requirements are usually read |
| C5 | Build and own batch pipelines | You maintained and fixed one nightly job. Building and owning one is a different job. | One pipeline you build end to end, where you are the one paged when it breaks, whether at work or as a project. | `[grounded]` "fixed our nightly dbt job when it breaks" |
| C9 | Partner with analytics on requirements | You were the analytics partner, not the engineer being partnered with. | Nothing to close with wording. The star schema work with the then-DE is the nearest evidence, and it is already in E1 and E3. | `[grounded]` "with our then-DE" |
| C10 | Streaming experience | Kafka and streaming work are absent. It is only a preferred requirement. | A small Kafka-to-warehouse project, only if you want to pursue it. It is not needed to apply. | `[grounded]` "Never touched Kafka." |

## Not written, and why

Pending your approval: this list only records refusals.

- **"Data Engineer" as a title or headline.** It would retitle five years of analyst work into the role you are applying for.
- **"3+ years of data engineering".** Your years are analyst years.
- **"Built and owned pipelines" or "pipeline ownership".** You fixed and added tests to a nightly job, which is maintenance.
- **"Orchestrated workflows" or "workflow orchestration".** That is the JD's phrase, and your material says cron and a nightly dbt job. Nothing says either is orchestration.
- **"Production Python" or "production-grade ETL".** Your own word is "scripting", and its production status is unconfirmed.
- **"Led" or "architected" the warehouse or star schema.** Yours was "with our then-DE".
- **"Owned data quality and SLAs".** You added tests. No SLA is stated.
- **"Partnered with analytics on requirements".** You stood on the analytics side, so the sentence would flip which side of the table you were on.
- **"Exposure to" or "familiar with" Spark, Airflow or Kafka.** You said you've never used them.

## Parse-safety check

Your resume arrived as pasted text, so none of the checks could run: multi-column layout, tables and text boxes, images or skill bars, content in headers or footers, section-heading names, and file type. Send the file and I'll run them.

## Offered, not built

A short, honest plan for closing the Airflow and Kafka gaps with one owned project you could put on the resume once it exists. It would add a path to closing C3, C5 and C10, and your answers to C2 and C3 would show how big those gaps really are. I'll build it only if you say so.

## Upgrade menu

These would raise confidence or unlock rows:
- The dbt project repo or a model-docs export, to show which of the 25 models you own.
- The DAG view of the orders mart, to show how much of the schema was yours.
- The vendor API scripts and cron entries, or a link to the repo.
- The nightly job's config or run history, to show what schedules it.
- Any message or doc stating a "ready by" time for the orders mart.

## Questions

C2: For the vendor API scripts on a cron, how long have they run, who depends on their output, and what happens when one fails?

C3: What runs the nightly dbt job (dbt Cloud, cron, Airflow owned by someone else, something else), and did you own any part of that scheduling?

C7: Was there ever a "ready by" time or freshness expectation on the orders mart that you were responsible for?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.