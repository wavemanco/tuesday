I read the tailoring playbook and audited each line against what you wrote. Here is the full ledger. Nothing is applied until you approve rows.

I'm working from your prose summary, not a formatted resume. The "Current line" quotes below are your own sentences, and any bullets or dates I haven't seen are not covered.

The posting makes "3+ years data engineering" a must-have, and your material doesn't show it. A resume edit can't create that. The ledger makes your real data-engineering-adjacent work easier to find without writing it up as more than it was. Whether this role is worth the application given that gap is a separate job-underwriter question, and I haven't answered it.

## Edit ledger

`resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your summary | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved to the second bullet, so "with our then-DE" stays attached)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your summary | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | *(unchanged, moved to the third bullet)* | `reorder` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your summary | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | Line 1: "I write Python for analysis — pandas". Line 2: "I write some Python scripting to pull vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your summary | pending your approval |
| E5 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved below the Python lines)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your summary | pending your approval |

- **E1–E3:** These move your three most engineering-shaped lines to the top. Wording is untouched, so "about 25", "with our then-DE" and "when it breaks" all stay.
- **E4:** The only change is that the cron and vendor-API line stands on its own instead of trailing the pandas line. "Some" stays, and I did not add "production" or "pipeline".
- **E5:** Your SQL line moves down but is not cut.
- **Voice:** I left the first-person "I" alone. Whether to drop it for resume style is your call, and I haven't proposed it as an edit.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Your title is "Senior Data Analyst, 5 years, retail". The closest work is in E1–E4, and recall prompt C3 asks whether more exists. | `[grounded]` your title and sentences; `[generic]` a years requirement is likely to be read against job titles |
| R2 | Production Python | important | `not_evidenced` | E4 shows analysis Python and cron scripts. Nothing says the scripts are production, so see C1. | `[grounded]` your wording "for analysis" and "some scripting" |
| R3 | Airflow or equivalent orchestration | important | `not_evidenced` | You wrote "Never used Airflow". A nightly dbt job exists in E3, but your material doesn't say what schedules it, so see C2. | `[grounded]` your summary |
| R4 | Dimensional modelling | important | `surfaced_by_edit` | E2 (you designed it with the DE, not alone), supported by E1 | `[grounded]` your summary |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E1 and E2, on Redshift | `[grounded]` your summary |
| R6 | Build and own batch pipelines | important | `not_evidenced` | E3 and E4 are adjacent. You fixed and tested a job and wrote cron scripts, but nothing says you built or owned a pipeline. See C2. | `[grounded]` your summary |
| R7 | Own data quality | important | `surfaced_by_edit` | E3, which shows tests added to one nightly job. It does not show ownership of data quality. | `[grounded]` your summary |
| R8 | Own SLAs | important | `not_evidenced` | Nothing in your material mentions deadlines or SLAs. Folded into C2. | `[grounded]` your summary |
| R9 | Streaming experience | preferred | `not_evidenced` | Named absence below. | `[grounded]` "Never touched Kafka" |

R4, R5 and R7 are surfaced by edits. The other six rows are `not_evidenced`.

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | R2 Production Python | important | Python "for analysis" plus "some scripting to pull vendor APIs on a cron". That does not establish production use. | The JD lists production Python as a requirement. | A cron script a team's reports depend on; one with retries or alerting; one that loads a warehouse table | The script repo, a cron or scheduler entry, or a failure or incident note | `[grounded]` what the resume says; `[generic]` what the gap costs on applications like this |
| C2 | R3 orchestration, R6 batch pipelines and R8 SLAs | important | A nightly dbt job you fixed and added tests to. Nothing says what runs it, who owns it, or whether output is due by a deadline. | These three are the core of the JD's "build and own batch pipelines" and "own SLAs". | A scheduler (cron, dbt Cloud, other) you configured or changed; a time the job had to finish by; a fix you handled outside work hours | The scheduler config, a runbook, or a message about a missed deadline | `[grounded]` what the resume says; `[generic]` what the gap costs on applications like this |
| C3 | R1 3+ years data engineering | must-have | Five years in an analyst title. The only data-engineer work shown is the star schema built with the DE. | This is the posting's must-have, and the resume as written does not meet it. | Pipeline, loading or warehouse work you took over from or alongside a data engineer, and for how long | A dbt repo history, project docs, or a performance-review line | `[grounded]` what the resume says; `[generic]` what the gap costs on applications like this |

**Named absences**

- **Kafka and streaming (R9):** You have never used it, and the JD lists it as a plus rather than a requirement. Closing it would take a small real project, such as consuming a Kafka topic into a warehouse table, which you could then list only as that project. For this role I'd treat it as optional and not worth closing before applying.
- **Spark:** You have never used it. It appears in the JD's duties but not in its requirements list. The closing path is the same as for Kafka: a real project, listed as what it was. I would not mention it on the resume until then.

## Not written, and why

- **"Data engineer" or "analytics engineer" as a title or headline.** Your title is Senior Data Analyst. A `retitle` must be an equivalent, not an upgrade.
- **"Built and owned batch pipelines", "orchestrated pipelines", "ETL/ELT pipelines".** You fixed and tested a nightly job, and you wrote scripts on a cron. Building and owning pipelines is a different job. An interviewer would find the difference quickly.
- **"Production Python".** Your sentence says "for analysis". It stays out until C1 is answered.
- **"Airflow", "Spark", "Kafka", or any orchestration or streaming keywords.** You've never used them, and the JD's tools list is not your history.
- **"Owned data quality" or "owned SLAs".** You added tests. That is E3, not ownership.
- **"Led" or "owned" the star schema.** You designed it "with our then-DE", and that qualifier stays.
- **"Partnered with analytics on requirements".** That is the JD's phrase. You sit on the analytics side, so writing it would put you on the wrong side of that relationship.

## Parse-safety check

This ran on pasted prose only, so I couldn't check layout, columns, tables, text boxes, headers and footers, or file type. I can run those checks if you send the file. I also haven't checked for hidden text, because I haven't seen the file.

## Upgrade menu

Each of these would let me do more:

- **The resume as a `.docx` or PDF:** parse-safety checks, plus the bullets, dates and sections I haven't seen.
- **Your dbt project (the `schema.yml` tests, or the model docs):** evidence for E1, E3 and R7.
- **A star schema diagram or ERD for the orders mart:** a stronger basis for E2.
- **The cron script repo or the nightly job's scheduler config:** needed to answer C1 and C2.
- **Prior resume versions:** they may contain data-engineering work your current one dropped.

One optional extra: I can draft a short summary section built only from rows you approve. It would add a top-of-page framing line, and I'd write nothing in it that isn't already in an approved row.

## Questions

C1 — For the vendor-API scripts on a cron: what uses what they pull, and what happens when one fails?
C2 — What runs your nightly dbt job, and is there a time its output has to land by?
C3 — Besides the star schema, have you done any pipeline or warehouse-loading work that would normally sit with a data engineer, and over what period?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.