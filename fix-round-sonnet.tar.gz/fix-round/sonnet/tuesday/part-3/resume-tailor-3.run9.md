I've tailored your CV as a ledger of proposed edits. Nothing is applied until you approve rows. I used the dossier's `role_profile`, `evidence_map` and `rejected_inferences`, and its one pending edit (E1) is re-audited below. I've treated your CV as self-report, so every row is `[grounded]` in what you wrote, not in verified evidence.

The posting's must-have is 3+ years of PM experience, and you've never held a PM title. No wording can close that. This ledger makes your adjacent work easy to find and defends every line. It doesn't present you as a PM.

## Edit ledger

I assumed your CV has no summary line yet. Each trace quotes your own sentence.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (inside a longer bullet) | "Wrote the internal integration playbook the whole team uses." as its own bullet | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` cv; inherited from dossier E1, re-audited | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` cv | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved directly after E2 and E1)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` cv | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." as a line directly under the role header | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` cv | pending your approval |
| E5 | Summary | *(no current line)* | "7 years as solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` cv | pending your approval |

- **E1** keeps "the whole team" exactly as you wrote it, with no "company-wide" or "org-wide".
- **E3** keeps "collecting client feedback for product". I did not write "owned the roadmap" or "ran discovery with partners": those are the posting's words, not yours.
- **E4** is a surface only. "Comfortable in" OpenAPI specs is not "wrote specs", so the line stays as it is.
- **E5** is two separate sentences, not one clause. It states your real title up front, so the PM gap is visible rather than hidden.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | not_evidenced | The dossier rates this adjacent (transferability, medium confidence). E1, E2 and E3 show the integration and client-feedback work next to it. They don't show roadmap ownership or prioritisation authority, and you've never held the title. | `[grounded]` your CV and the dossier row; `[generic]` that a title gap usually gets probed early |
| R2 | Shipped API or platform products | must-have | not_evidenced | The dossier rates this adjacent (medium). E2 shows you led integrations of your vendor's APIs, which is using and deploying them, not shipping them. See C1. | `[grounded]` your CV and the dossier row |
| R3 | Technical fluency | important | surfaced_by_edit | E4 and E2 | `[grounded]` your CV |
| R4 | Stakeholder management | important | surfaced_by_edit | E2 and E3 show client-facing work and feedback collection. Your CV doesn't use the word "stakeholder", and no row adds it. | `[grounded]` your CV |
| R5 | Own the partner-API roadmap | important | not_evidenced | E3 is the nearest evidence, and it stops at collecting input. | `[grounded]` your CV |
| R6 | Write specs and drive delivery with two engineering squads | important | not_evidenced | E4 shows tool comfort only. Nothing shows specs you wrote or delivery you drove. See C2. | `[grounded]` your CV |
| R7 | Define adoption metrics | important | not_evidenced | Nothing in your CV touches metrics. See C3. | `[grounded]` your CV |

## Recovery per gap

Each row implies one question, asked at the bottom.

| # | Requirement | Priority | What your CV currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Shipped API or platform products | must-have | You led 30+ client integrations of your vendor's REST APIs. It doesn't say you shaped, specified or released any of those APIs. | A reader scanning for "shipped" will see integrator, not product owner. | A change you pushed to the API team that shipped; an endpoint or API version you specified; a customer-facing integration kit or sandbox you built | A changelog entry, spec, release note or doc page | `[grounded]` what your CV does and doesn't say; `[generic]` what this costs on applications of this kind |
| C2 | Write specs and drive delivery with engineering squads | important | OpenAPI comfort, and "for product" feedback. No spec authorship or delivery role is stated. | The posting asks for spec writing and delivery in the same breath. | A requirements doc you wrote that engineers built from; a client-driven fix you tracked through to release | A spec, ticket thread or release note | `[grounded]` your CV; `[generic]` posting-pattern for platform PM roles |
| C3 | Define adoption metrics | important | Nothing about metrics or usage appears. | The posting names adoption metrics as a duty. | How you decided whether an integration "worked"; any usage or time-to-integrate figure you tracked | A dashboard, SQL query or report | `[grounded]` your CV; `[generic]` what this costs on applications of this kind |

**Named absences with no closing path in this ledger:**

- **Prioritisation authority (R1, R5).** Your CV shows you fed input to product, not that you decided what got built. Closing it takes real scope: a documented prioritisation call you made, or a role with PM scope. Without that, the honest position is "adjacent, not direct", and this CV can't change it.
- **PM title (R1).** For this role the gap is real, and it is worth having a spoken answer ready for it.

## Not written, and why

- **"3+ years product management experience"**: you never held the title, and the dossier rates it adjacent.
- **"Owned the partner API roadmap"**: you collected client input for product, which is not ownership.
- **"Shipped API products"**: you led integrations of APIs, and the dossier rates this adjacent.
- **"Ran discovery with integration partners"**: that is the posting's phrase. Your sessions collected feedback from clients, and the word change would blur whose roadmap it was.
- **"Wrote specs"**: comfort with OpenAPI specs doesn't state authorship.
- **"Drove delivery with engineering squads"** and **"defined adoption metrics"**: nothing in your CV supports either.
- **From the dossier's `rejected_inferences`, carried unaltered:**
  - "built an internal request-triage tool": a memory lead, and you could not confirm ownership.
  - "has been the customer of a partner API platform": you worked vendor-side.

## Parse-safety check

Your CV arrived as prose, not a file, so I couldn't run any of the layout checks: multi-column layout, tables and text boxes, images and icons, headers and footers, non-standard headings, or file type. A `.docx` or text-layer PDF is the safe pair.

## Upgrade menu

- **Your CV as a file:** lets me run the parse-safety checks.
- **A spec, changelog entry or doc page you wrote:** could turn C1 or C2 into a grounded row.
- **Notes or an output from a roadmap-input session:** could show what you did after collecting the input, for E3 and R5.
- **A usage or integration-time report:** could ground C3.

## Questions

C1 — Did any API, endpoint or integration kit you worked on ship because of your input or spec, and what exactly was your part?
C2 — Have you written a requirements doc or spec that engineers built from, or tracked a client-driven fix through to release?
C3 — Did you ever track how integrations were adopted or performed, and with what measure?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.