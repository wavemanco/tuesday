I've built the ledger from your summary of the CV and the dossier excerpt. Nothing is applied yet. Every row is a proposal for you to approve or reject.

I used the dossier's `evidence_map` verdicts, E1, the two `rejected_inferences` and the `conditional_go` decision as they stand. It names the same role as this JD, so I treated it as current. I only had the excerpt, not the full file. Where I work from your summary rather than the CV itself, the "current line" wording is as you gave it to me.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (as one item among others) | "Wrote the internal integration playbook the whole team uses." as its own line | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV, and dossier E1 (inherited, re-audited) | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to the second bullet, after E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." as its own line near the top | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |

- **E1** is the dossier's edit, kept word for word. Surfacing it adds no "authored a framework", "standardised" or "company-wide".
- **E2 and E3** change position only. "30+" stays attached to integrations, and "roadmap-input sessions" does not become "informed the roadmap" or "shaped priorities".
- **E4** assumes the tools are currently buried in a skills list or a run-on line. If they already sit near the top, drop the row. A tool listed is not a tool owned, so "Comfortable in" stays.
- **Title line:** I'm not retitling "solutions engineer / implementation lead". Any PM-flavoured title would be an upgrade, not an equivalent.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM | must-have | not_evidenced | Seven years are solutions and implementation work with no PM title. The dossier grades this adjacent, with a transferability gap, and I inherit that. See C1. | `[grounded]` CV and dossier R1 |
| 2 | Shipped API or platform products | important | not_evidenced | You led integrations of your vendor's REST APIs, which is not shipping them. The dossier grades this adjacent. See C2. | `[grounded]` CV and dossier R2 |
| 3 | Technical fluency | important | surfaced_by_edit | E4, with E2 as the evidence of using it | `[grounded]` CV |
| 4 | Stakeholder management | important | surfaced_by_edit | E2 and E1, since 30+ client integrations end to end is the CV's evidence for it | `[grounded]` CV |
| 5 | Discovery with integration partners | important | surfaced_by_edit | E3. Your sessions were with clients, not partners. | `[grounded]` CV |
| 6 | Own the roadmap | important | not_evidenced | You collected input for product. Prioritisation authority isn't evidenced, as in the dossier's R1 reasoning. See C1. | `[grounded]` CV and dossier R1 |
| 7 | Write specs, drive delivery with two engineering squads | important | not_evidenced | OpenAPI fluency is not spec authorship, and nothing shows delivery with engineers. Named absence below. | `[grounded]` CV |
| 8 | Define adoption metrics | important | not_evidenced | No metric of any kind appears in the CV. See C3. | `[grounded]` CV |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Own the roadmap; 3+ years PM | must-have | Quarterly sessions that collected client feedback, with nothing on what happened to it or who decided | The posting's first responsibility is roadmap ownership, and this CV stops at input | Feedback you turned into a ranked list; a request you pushed through that shipped; a call between two competing asks that you made or argued | A session write-up, a ranked backlog, a release note that cites the request | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Shipped API or platform products | important | Leading client integrations of existing APIs | Using an API and shipping one are different jobs | A new endpoint or API version you helped launch, beta-tested or documented; an OpenAPI spec you wrote or revised before release | A spec, a changelog or release note, a partner-facing doc | `[grounded]` what the CV says; `[generic]` what this costs on applications of this kind |
| C3 | Define adoption metrics | important | No metrics | The role is measured on adoption, so absence here is visible | Integration counts or time-to-integrate you tracked; playbook usage; clients live per quarter | A dashboard, a spreadsheet, a QBR slide | `[grounded]` what the CV says; `[generic]` what this costs on applications of this kind |

**Named absence, specs and delivery with two engineering squads:** nothing in your material shows you writing specs for engineers or driving a delivery team. Closing it would take a real instance, such as a requirements doc an engineering team built from, or a cross-team release you coordinated. If none exists, this stays a gap to address openly in an interview, not on the CV.

**Named absence, the PM title:** no wording closes "3+ years PM". The dossier's `conditional_go` already reflects that. The only honest closure is evidence of PM-scope work from C1 to C3.

## Parse-safety check

You gave me pasted text, not a file. I could not check layout, columns, tables, text boxes, headers and footers, icons or skill bars, section headings, or file type. Send the file and I'll run them.

## Not written, and why

- "Product Manager" or "3+ years of product management": you have never held the title, and it is the posting's must-have.
- "Owned the roadmap" or "set roadmap priorities": you ran input sessions. Ownership isn't evidenced.
- "Shipped API products": you integrated clients onto APIs, and the dossier grades this adjacent.
- "Wrote specs" or "authored API specifications": you are comfortable in OpenAPI specs, and nothing says you authored any.
- "Drove delivery with engineering teams": nothing in the material supports it.
- "Defined adoption metrics": no metric is anywhere in the CV.
- "Partnered with integration partners": the posting's word is "partners" and yours is "clients". Using it would change who sat across the table from you.
- "Built an internal request-triage tool": from the dossier's `rejected_inferences`. It was a memory lead, and you could not confirm you owned it.
- "Experienced customer of a partner API platform": from the dossier's `rejected_inferences`. You worked vendor-side.

## Upgrade menu

- **The CV as a file:** this unlocks the parse-safety checks I couldn't run.
- **The full dossier:** I only saw the excerpt, so the other evidence rows and constraints would sharpen the ledger.
- **Work samples:** a playbook excerpt with client details removed, an OpenAPI spec you wrote or edited, or a roadmap-session summary. Any of these could lift `medium`-confidence rows toward `high`.

## Questions

C1. Roadmap and prioritisation: what happened to the feedback from your quarterly sessions, and did you rank or decide anything yourself, or hand it to product?
C2. Shipped API products: did you help launch, test or document a new endpoint or API version, or write an OpenAPI spec before it shipped?
C3. Adoption metrics: did you or your team track any numbers on integrations or playbook use, such as clients live, time to integrate or usage?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.