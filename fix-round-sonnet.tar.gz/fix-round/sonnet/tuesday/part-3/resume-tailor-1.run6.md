I've built the edit ledger below. Nothing is applied until you approve rows. You pasted a summary rather than the CV itself, so each row's "Current line" and "Traces to" quote your message word for word. I haven't seen your CV's own wording or layout.

## Edit ledger

All rows are `pending your approval`. I've assumed the CV has no summary section; E1 is a proposal, so drop it if you already have one.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years, currently at a payments company. Go and Rust daily for 4 years, Python before that. Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `merge` | "Senior Software Engineer, 7 years. Currently at a payments company."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your pasted CV summary | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged, moved to the first bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your pasted CV summary | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your pasted CV summary | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your pasted CV summary | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team — usually two or three a year — pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your pasted CV summary | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "gRPC, Kafka, Postgres, Datadog, Terraform" | `reorder` | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your pasted CV summary | pending your approval |

- **E4 and E5:** I kept the qualifiers ("every fourth week", "usually", "first month"). I didn't swap in "mentored" or "strong incident response" for your own verbs.
- **E6:** this only changes order. A tool on your skills line is not a claim that you owned it.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E1 puts the 7 years next to the services you own. Your CV says "Software Engineer", not "backend", so the services carry the backend evidence. | `[grounded]` your CV summary |
| R2 | Production Go | must-have | `surfaced_by_edit` | E1 and E2 put "Go and Rust daily for 4 years" next to the services you own. | `[grounded]` your CV summary |
| R3 | Distributed systems at scale | must-have | `surfaced_by_edit` | E2 carries the 40k requests/minute figure. The phrase "distributed systems" is not written, because it is the JD's word. Kafka appears only on the skills line, tied to no claim. | `[grounded]` your CV summary; `[generic]` what a reader looks for here |
| R4 | Strong incident response | must-have | `already_evidenced` | The incident commander bullet is explicit. E4 only tightens it. | `[grounded]` your CV summary |
| R5 | Mentoring experience (JD says mid-level engineers) | must-have | `surfaced_by_edit` | E5 shows the onboarding and pairing. Your sentence says new hires, not mid-level, so it stays that way. | `[grounded]` your CV summary |
| R6 | Design and ship Go services | important | `not_evidenced` | You say you own three services. That doesn't say you designed them. See C1. | `[grounded]` your CV summary |
| R7 | Drive down p99 latency | important | `already_evidenced` | The 380ms to 95ms bullet. E3 moves it up. | `[grounded]` your CV summary |
| R8 | Own on-call for your services | important | `already_evidenced` | Every-fourth-week rotation for two years, plus owning three services. | `[grounded]` your CV summary |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in what you pasted touches product partnership. See C2. | `[grounded]` your CV summary |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Design and ship Go services | important | You own three ledger-pipeline services and cut p99 on the balance-read path. It doesn't say whether you designed any service or inherited it. | The JD opens with "design and ship". Ownership alone reads as maintenance. | Writing the design doc or RFC for one of the three services; choosing the cache approach in the p99 rework; a service you built from scratch or rebuilt | A design doc, RFC, or PR description | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Partner with product on roadmap sequencing | important | Nothing on working with product or planning. | The JD lists it as a core duty of the role. | Deciding with a product or finance partner which ledger work shipped first; pushing back on or re-ordering a request because of a latency or reliability cost; a quarterly plan you contributed to | A planning doc, roadmap thread, or ticket history | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

R5 has a limit, not a gap: you onboard new hires, and I have no evidence they were mid-level. C3 below asks about it.

## Not written, and why

- "Senior Backend Engineer" as your title. Yours is Senior Software Engineer, and a retitle must be an equivalent, not the JD's title.
- "Distributed systems" or "Kafka-based architecture" in a sentence about your work. Kafka is a listed tool, not a stated claim, and "distributed systems" is the JD's vocabulary.
- "Designed and shipped Go services". You own them. Whether you designed them is C1.
- "Mentored mid-level engineers". You onboarded new hires, and their level is unknown.
- "Partnered with product" or "drove roadmap". Nothing you gave supports it (C2).
- "Handled 40k requests/minute across the pipeline". The figure belongs to one service.
- Any build-cache or developer-tools experience. Nothing you gave touches it.

## Parse-safety check

Your CV arrived as pasted text, so I could not run any of these checks: multi-column layout, tables and text boxes, images or skill bars, contact details in headers and footers, non-standard headings, and file type. None of them can be run on pasted text.

## Upgrade menu

- **The full CV as a file (.docx or text-layer PDF):** rows would then trace to your real lines, I could propose cuts of lines irrelevant to this role, and the parse check could actually run.
- **A latency dashboard screenshot, the cache-rework PR, or a postmortem:** it would give the 380ms to 95ms claim something inspectable behind it.
- **A design doc or RFC for any of your three services:** it would settle C1.

## Questions

C1 — Did you design any of the three services, or the cache-layer rework behind the p99 drop? If so, which one, and what was your part versus the team's?

C2 — Have you worked with product or another business partner on what ledger work got built first or later? If so, what was the decision and what was your role in it?

C3 — Were the new hires you onboard mid-level or more junior, and did any go on to own something you paired with them on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.