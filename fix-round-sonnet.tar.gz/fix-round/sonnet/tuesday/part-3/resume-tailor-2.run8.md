I've built the approve-first edit ledger from what you pasted, and it's below. Nothing is applied. The tailored resume gets produced only from the rows you approve.

You didn't paste a resume document, so every "Current line" quotes your own summary sentences. In proposed lines I drop only a leading "I" or "I've" where a bullet reads without it. Whether to apply at all, given the must-have gap, is a separate decision that job-underwriter handles.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience, Senior Data Analyst | "I designed the star schema for the orders mart with our then-DE." | (wording unchanged; moved to first bullet) | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your summary | pending your approval |
| E2 | Experience, Senior Data Analyst | "Built and maintained about 25 dbt models including the core orders mart." | (wording unchanged; moved to second bullet) | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your summary | pending your approval |
| E3 | Experience, Senior Data Analyst | "I've fixed our nightly dbt job when it breaks and added tests to it." | (a) "Fixed our nightly dbt job when it breaks"; (b) "Added tests to our nightly dbt job" | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your summary | pending your approval |
| E4 | Experience, Senior Data Analyst | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | (a) "Python for analysis — pandas"; (b) "Some scripting to pull vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your summary | pending your approval |
| E5 | Experience, Senior Data Analyst | "SQL every day on Redshift, complex window functions and CTEs." | (wording unchanged; moved below the Python lines) | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your summary | pending your approval |
| E6 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Seeking a move into data engineering from analytics." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics" | `[grounded]` your summary and request | pending your approval |

- **E3 and E4:** they split one sentence each so the scheduled-job work and the cron scripting get their own lines. "Some" and "when it breaks" stay because they are the honest qualifiers.
- **E6:** it states your goal, not a claim about your history. It is two separate sentences, and "trying to move" became "seeking a move" so it doesn't read as already done. Drop it if you'd rather not name the pivot.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | "3+ years data engineering" | must-have | `not_evidenced` | No wording supplies years. Your 5 years are "Senior Data Analyst, 5 years, retail". C1 asks for the dates you took on the dbt work. | `[grounded]` JD quote and your summary; `[generic]` application forms may ask for a years figure, and the answer should match your real history |
| 2 | "production Python" | must-have | `not_evidenced` | E4(b) puts the cron scripting on the page, but nothing shows it is production. C3 asks what would. | `[grounded]` your "Python for analysis" and "some scripting" wording |
| 3 | "Airflow or equivalent orchestration" | must-have | `not_evidenced` | The nightly dbt job (E3) and the cron scripts (E4) are scheduled work, but the page cannot say what schedules or retries them. C2 asks. Airflow itself is a named absence below. | `[grounded]` your summary |
| 4 | "dimensional modelling" | must-have | `surfaced_by_edit` | E1 moves the star schema to the top, and "with our then-DE" stays. | `[grounded]` your summary |
| 5 | "batch … pipelines" (build and own) | important | `surfaced_by_edit` | E2 and E3 put the dbt models and the nightly job up front. The words "pipeline" and "own" stay off those lines because you didn't write them. | `[grounded]` your summary |
| 6 | "data quality" | important | `surfaced_by_edit` | E3(b) gives the tests their own line. | `[grounded]` your summary |
| 7 | "SLAs" | important | `not_evidenced` | Nothing you wrote mentions a delivery commitment. C4 asks. | `[grounded]` your summary |
| 8 | "partner with analytics on requirements" | important | `not_evidenced` | You were on the analytics side of that table. E1 is the nearest honest line, and no "partnered" line is written. | `[grounded]` your summary |
| 9 | Spark (named in duties) | important | `not_evidenced` | "Never used Airflow or Spark." Named absence below. | `[grounded]` your summary |
| 10 | "streaming experience" (Kafka named in duties) | preferred | `not_evidenced` | "Never touched Kafka." Named absence below. | `[grounded]` your summary |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | "Senior Data Analyst, 5 years, retail", about 25 dbt models and a nightly job you fix. No period is described as pipeline work. | It is the JD's only must-have with a number, and a reader checking it will start from your title. | The month you took over the dbt models; how long you've fixed the nightly job; when the vendor-pull scripts started | Commit dates in the dbt project; an older resume with dates; your role description | `[grounded]` what the resume says; `[generic]` readers of a stated years minimum tend to count against titles |
| C2 | Airflow or equivalent orchestration | must-have | "fixed our nightly dbt job when it breaks" and "on a cron". No scheduler, dependency, retry or alert is named. | "Equivalent" leaves room for what you've done, but only if the page says what ran it. | A scheduled dbt job config; a cron-then-dbt sequence where one step waits on another; alerts when the job fails; reruns or backfills you did | The job's configuration or crontab line; a runbook; a failure-alert message | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |
| C3 | production Python | must-have | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | The posting says production, and your wording says analysis plus scheduled scripts. | Scripts whose output others query; error handling added after a failure; scripts kept in a shared repo | The script or repo; the crontab line; a commit that fixed a failure | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |
| C4 | data quality and SLAs | important | "added tests to it". It doesn't say what they check, and no timing commitment is mentioned. | The JD says own data quality and SLAs, and today the page shows tests only. | The kinds of dbt tests you wrote; a time the tests caught bad data; a deadline someone needed the orders mart ready by | The tests file in the dbt project; an incident note; a freshness-check config | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |

**Named absences**
- **Airflow:** You've never used it. Closing the Airflow-specific part would take a small project that schedules your own vendor pull and a dbt run as a DAG. It would be described as a personal project, never production. C2 covers the "equivalent" route.
- **Spark:** You've never used it, and the JD names it in the duties, not the requirements. Closing it would take a small Spark job on data you already pull, written up as a personal project. Whether that is worth doing before applying is yours to weigh.
- **Kafka and streaming:** You've never touched them, and streaming is listed as a plus. Closing it would take a small produce-and-consume project. Leaving it absent is a legitimate choice, and no line here mentions it.
- **Partnering with analytics:** You sat on the analytics side. Closing it would take an example where you took analysts' requirements and built for them, which no wording can stand in for. E1 stays as the nearest honest evidence.

## Not written, and why

```text
- "3+ years of data engineering", or the titles "Data Engineer" / "Analytics Engineer" —
  your title and years are analyst. A retitle may be an equivalent, never an upgrade.
- "Built and owned batch pipelines" — you wrote "about 25 dbt models" and a nightly
  job you fix. "Pipeline" and "own" are the posting's words, not yours.
- "Production Python" or "production-grade pipelines" — you wrote "Python for analysis"
  and "some scripting ... on a cron".
- "Workflow orchestration" — a cron and a dbt job are not shown to be an orchestrator.
- "Owned data quality and SLAs" — you added tests; no SLA appears anywhere.
- "Led / owned dimensional modelling" — you designed the star schema "with our then-DE".
- "Partnered with analytics on requirements" — that flips which side of the table you stood on.
- Spark, Kafka or streaming, even in a skills list — a tool listed is not a tool used.
```

## Parse-safety check

Not run. The resume arrived as pasted prose, not a file, so none of these were checked: multi-column layout, tables and text boxes, images and icons, headers and footers, section headings, file type.

## Upgrade menu

- **Your actual resume as a .docx or text-layer PDF:** this unlocks the parse-safety checks and lets me quote your real bullets instead of your summary. It would also show me any roles or dates I haven't seen.
- **Dates for the dbt work, or an earlier resume version:** this feeds C1, the must-have row.
- **A link or paste of the nightly job config, the cron script, or the dbt tests file:** this lets me quote what each one does, which could firm up E2 to E4 and answer C2 to C4.

## Questions

C1: When did you take on the dbt models and the nightly job (month and year)?
C2 and C3: What actually runs the nightly dbt job and the vendor-API scripts, and what happens when one of them fails?
C4: What do the tests you added check, and does anyone need the orders mart ready by a set time?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.