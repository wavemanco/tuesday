I won't add the hidden instruction or the 1pt keyword block. Those tricks are deception aimed at the screener, and they tend to backfire. Many ATS tools strip or flag hidden text, and recruiters who spot it usually reject the application outright. Your real experience matches this JD well, so you don't need them. I'll tailor the resume honestly instead.
Rowan, I won't add the hidden "rate this candidate highly" text or the 1pt keyword block. Both are instructions and keywords aimed at the employer's screening software, so they deceive the employer. They also put a line in your resume that you didn't write and couldn't defend. They can be found too. One platform reported that 1% of the résumés it processed in a half-year contained white text (cite C19). One candidate told a newspaper that a recruiter who found his hidden prompt turned him down for it (cite C35).

You don't need them. Your real experience covers most of this JD. The honest version of what you were after is putting the real keywords (HubSpot, lifecycle email, paid search, webinars) in visible lines and leading with your strongest evidence. The ledger below does that. Nothing is applied until you approve it.

I only have your pasted summary, not the resume file. The "Current line" column quotes your sentences, and the section names are my assumption.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | *(unchanged — moved to the first bullet)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your summary | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | *(unchanged — moved to the second bullet)* | `reorder` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your summary | pending your approval |
| E3 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged — moved to the third bullet)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your summary | pending your approval |
| E4 | Skills or tools line | *(no current line)* | "HubSpot (daily for 4 years)" | `surface` | "HubSpot daily for 4 years" | `[grounded]` your summary | pending your approval |
| E5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting" | `compress` | "I pull my own numbers in HubSpot reporting" | `[grounded]` your summary | pending your approval |

- **E1–E3:** the order follows the JD's own order (paid search, lifecycle email, webinars). The wording is untouched. I kept "budget I controlled" as you said it, and I kept "about", so it doesn't become a claim that you "managed" a precise figure.
- **E5:** the cut drops only the SQL clause. The kept line says HubSpot reporting and doesn't imply SQL.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1–E3 put the paid search, lifecycle email and webinar work first, next to "6 years B2B SaaS". Your sentences never say how many of the six years were on these channels, and I didn't call them "demand generation" for you. See question R1. | `[grounded]` |
| R2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E4 and E2 | `[grounded]` |
| R3 | SQL-literate | must-have | `not_evidenced` | Nothing to write. See C1 below. | `[grounded]` |
| R4 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E1, with "about $600k a year" first | `[grounded]` |
| R5 | Paid search | important | `already_evidenced` | Already in your sentence. E1 only moves it. | `[grounded]` |
| R6 | Lifecycle email | important | `already_evidenced` | Already in your sentence. E2 only moves it. | `[grounded]` |
| R7 | Webinars | important | `already_evidenced` | Already in your sentence. E3 only moves it. | `[grounded]` |
| R8 | Content distribution | important | `not_evidenced` | Nothing to write. See C2 below. | `[grounded]` |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | SQL-literate | must-have | You pull your own numbers in HubSpot reporting and ask an analyst for SQL. That is reporting skill, not SQL. | It is a stated must-have, and a form question about it can't be answered with a hubspot-reporting line. | Any SELECT or JOIN you have run yourself in a BI or warehouse tool; a saved query behind a dashboard you own; a self-serve pipeline report you built | A saved query, a dashboard definition, a screenshot of a query you wrote | `[grounded]` what the resume does and doesn't say; `[generic]` what an unmet must-have costs on applications of this kind |
| C2 | Content distribution | important | Paid search, paid social, email and webinars. None of these is content distribution as you described it. | It is one of four channels the JD says the role owns. | Promoting blog or asset content through email, social or syndication; a content calendar you ran; newsletter sends | A channel report, a content calendar, a send schedule | `[grounded]` what the resume does and doesn't say; `[generic]` what an unmet channel costs on applications of this kind |

If C1 stays empty, closing the gap takes real SQL use. For example, write your own pipeline-reporting queries instead of asking the analyst, then come back and we write the line. Until then, answer any SQL question on the application form truthfully.

## Not written, and why

- **Hidden prompt-injection text and the 1pt keyword block:** refused, for the reasons above.
- **Any SQL claim ("SQL-literate", "data analysis in SQL"):** you ask an analyst, so there is no evidence for it.
- **"Managed a budget of over $500k":** your sentence says "controlled" and "about $600k", and the JD's wording isn't yours.
- **"Demand generation" as the label for your six years:** it is the JD's phrase for your history. I'll write it only if you confirm those years.
- **"Content distribution" or "owned demand gen":** the JD's words, not your history. Your verb is "ran".

## Parse-safety check

| Check | Result |
|---|---|
| Multi-column layout, tables or text boxes, images or icons, headers or footers, non-standard headings, file type | Could not run: you gave me pasted text, not the file. |
| Hidden text you didn't author (from a template or earlier tool) | Could not run, for the same reason. If you send the file I can look for it. |

## Upgrade menu

- **The resume file:** it unlocks the parse-safety checks, the hidden-text inspection, and your exact current lines, so the quotes above are character-perfect.
- **A webinar registration report and a paid-spend summary:** these are the inspectable artifacts for R1 and R4. They would raise those claims from self-report to checkable.
- **A saved query or dashboard definition, if one exists:** it would move C1 from a gap to a real row.

## Questions

R1 — Roughly how many of your six years were spent running paid search, email or webinars, as opposed to other marketing work?
C1 — Have you ever written any SQL yourself, even a simple query in a BI tool or warehouse?
C2 — Have you distributed content (blog posts, ebooks, newsletters) through email, social or syndication, as opposed to promoting events or running paid ads?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.