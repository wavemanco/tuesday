**Short version:** the keyword theory is probably only part of the story. Sam, your resume is evidenced for 3 of the 14 JD requirements, and no phrasing can change that.

On the keyword theory, the one sample the research here rests on is small: 25 recruiters interviewed by a résumé-builder vendor, whose findings it calls themes rather than representative statistics. In that sample, content-based auto-rejection was rare ("AI/content auto-rejection configured: 8% of recruiters" (cite C25)). What did reject without a person was form questions: "When automated filters are used, they’re almost always knockout questions" (cite C26). Match scores mostly set review order: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27). Truthful keywords can improve your position in that ordering, so the ledger below places the ones your history supports. Hidden keyword text is something I won't write. It's deception of the employer and you couldn't defend it in an interview.

Whether this role is worth applying to, given the gaps, is job-underwriter's question, not this one's. I worked only from your description, not the file itself.

## Coverage map

The JD doesn't say which items are required, so I haven't guessed. Only the closing sentence is marked must-have, and the tool list is marked important.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Own platform reliability and developer experience | must-have | not_evidenced | Nearest work is the Jenkins pipeline, in E4. Nothing you wrote says you owned reliability. Named absence below. | `[grounded]` |
| M2 | Kubernetes | important | surfaced_by_edit | E1, E2 and E4, always with "never went to production" attached | `[grounded]` |
| M3 | AWS EKS | important | not_evidenced | AWS is in your skills, but nothing says the proof-of-concept ran on EKS. See C1. | `[grounded]` |
| M4 | Helm | important | not_evidenced | See C1 | `[grounded]` |
| M5 | GitOps / ArgoCD | important | not_evidenced | See C1 | `[grounded]` |
| M6 | Terraform | important | not_evidenced | Ansible is config management, not infrastructure provisioning. See C2. | `[grounded]` |
| M7 | Prometheus, Grafana, observability | important | not_evidenced | CloudWatch is adjacent, but I won't call it observability. See C3. | `[grounded]` |
| M8 | SRE practices | important | not_evidenced | See C3 | `[grounded]` |
| M9 | Istio / service mesh | important | not_evidenced | Named absence below | `[grounded]` |
| M10 | Vault | important | not_evidenced | Named absence below | `[grounded]` |
| M11 | CI/CD | important | already_evidenced | Your Jenkins pipeline sentence covers it as written. The literal string "CI/CD" isn't there, and I'm not adding it: "deploy pipeline" doesn't say whether it also builds or tests. | `[grounded]` |
| M12 | GitLab (CI/CD) | important | not_evidenced | Named absence below | `[grounded]` |
| M13 | Python | important | already_evidenced | In "Bash and Python scripting". E3 only makes the word stand alone. | `[grounded]` |
| M14 | Go | important | not_evidenced | Named absence below | `[grounded]` |

## Edit ledger

`resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | *(Kubernetes not listed)* | "Kubernetes (proof-of-concept only, not in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged, moved directly under the Jenkins pipeline line)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |
| E3 | Skills | "Bash and Python scripting" | "Python (scripting)" and "Bash (scripting)" as two separate entries | `split` | "Bash and Python scripting" | `[grounded]` resume | pending your approval |
| E4 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |

The traces are quoted from your message, not from the PDF.

## Gaps with something to pull

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS, Helm, GitOps / ArgoCD | important | A two-month Kubernetes proof-of-concept, with no stated platform, packaging or deployment method | Three JD items hang on what that proof-of-concept actually used, and the resume is silent on all three | The cluster ran on EKS; services were deployed with Helm charts; changes were applied through a GitOps tool such as ArgoCD | Proof-of-concept README, repository, architecture notes, or a demo write-up | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Terraform | important | Ansible for config management and AWS services, with no infrastructure-as-code provisioning stated | A Terraform requirement that finds no provisioning evidence is a plain miss | Terraform modules you wrote or edited; VPC, EKS or RDS definitions; a side project | A repository, a pull request, or a module file | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Prometheus, Grafana, observability, SRE practices | important | CloudWatch for monitoring; nothing on dashboards, alerting design, on-call or incident reviews | Four JD items sit on this, and the role is about reliability | Grafana dashboards you built; Prometheus alert rules; an on-call rotation; blameless post-incident reviews you wrote or joined | A dashboard export, an alert-rule file, or an incident review document | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

## Named absences

- **Istio / service mesh, Vault:** your resume shows no work with either. Closing it means a small public lab project, such as mesh mTLS on a local cluster or Vault-injected secrets. That gives you an inspectable artifact, but it would be written as a lab, not as experience.
- **GitLab (CI/CD):** you've built a Jenkins pipeline, but GitLab CI isn't shown. Rebuilding a pipeline in a free GitLab project would close it.
- **Go:** nothing in your resume. A small public tool in Go would close it, and it's a longer road than the others.
- **Owning platform reliability and developer experience:** maintaining about 30 Jenkins jobs is adjacent but isn't owning reliability. Closing it means evidence of on-call, SLO or incident work (C3), or a target role one step below this one.

## Not written, and why

- "Kubernetes experience" with no qualifier, or "production Kubernetes": your proof-of-concept never went to production.
- "Terraform" or "infrastructure as code": Ansible is configuration management, a different kind of work.
- "Observability" or "Prometheus/Grafana": CloudWatch monitoring is not those tools.
- "GitOps" or "ArgoCD": a Jenkins deploy pipeline is a different practice.
- "EKS" or "Helm": nothing says the proof-of-concept used either.
- "SRE practices" or "platform reliability": maintaining jobs doesn't show either.
- "CI/CD pipeline" as a description of your work: "deploy pipeline" doesn't say it builds or tests.
- "Platform Engineer" as a retitle of your role: that's an upgrade, not an equivalent.
- Hidden keyword text: refused, for the reasons above.

## Parse-safety check

I couldn't open the PDF, so these are risks from what you described, not observations. I couldn't run the text-layer, hidden-text, heading or file-type checks.

| Check | What I could observe | What breaks | What it costs | Provenance |
|---|---|---|---|---|
| Multi-column layout | You described a two-column layout | Parsers read linearly and can interleave the columns | Skills and experience can mix, and dates can detach from roles | `[generic]` |
| Images and icons | Icons mark each skill | Icons can render as garbage or be skipped | Any skill information carried only by an icon is absent | `[generic]` |
| Contact details in the header | Contact details sit in the header | Header or footer content can be discarded | Your contact details can be lost, so you're unreachable | `[generic]` |
| Hidden text | Not checked | A template or tool may have left some in | A liability you can't see | `[generic]` |

## Upgrade menu

- **Your resume as pasted text or the PDF itself.** This lets me use verbatim traces and run the checks above.
- **The Kubernetes proof-of-concept write-up, repository or notes.** This could move M2 toward inspectable evidence and decide M3 to M5.
- **Any Terraform, Prometheus or Grafana artifacts, or an older resume version.** Older versions often hold evidence the current one dropped.

## Questions

C1 — Which pieces did the Kubernetes proof-of-concept actually use (EKS or self-managed, Helm charts, any GitOps tool), and what ran on it?
C2 — Have you written or edited Terraform for any infrastructure, even in a side project?
C3 — Have you worked with Prometheus or Grafana, or been on an on-call rotation, and if so what did you build or handle?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.