I'll read the skill's reference files before building the assessment.
**Yes, apply, on conditions. Status: `conditional_go`.** R2, R3, R4, R5a, R6, R7a, R8 and R9 all land `direct` on what you've told me. Pet-insurance experience is R10. People management isn't in the JD, so it has no row, and RR3 asks whether the post carries it.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5a, R6, R7a, R8 · unclear: R5b (Monitor rating models)
- `important` — adjacent: R10 (Pet-insurance pricing) · unclear: R7b (Recommendations for product)
- `preferred` — direct: R9

R10 (`medium`) — a credible bridge, its limit named; R5b (`low`) — "maintained" does not yet establish monitoring; R1 — nothing yet settles the location term.

**Opportunity ledger.** The role content is concrete and fits its title (RR5). The employer and live posting are unverified because research did not run (RR1). Pay (RR2), line-management scope (RR3) and decision rights over rate changes (RR4) are all unstated.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed, see G1; (2) the employer and live posting verified, see RR1; (3) the pet-insurance bridge framed as adjacent, never as pet experience, see R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; existence not yet verified (RR1) | `[grounded]` JD header as you supplied it |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Reporting line | Odile Varga, Director of Pricing | `[grounded]` your message |
| Scope read | An individual-contributor-shaped analyst post: the JD lists no direct reports and no team size, so your lack of management experience meets no stated requirement. Whether the post carries reports is open (RR3) | `[inferred]` from the JD's duty list and its silence on people management |
| First-year outcomes | Not stated, and I have not inferred them | `[grounded]` JD silent |
| Market calibration | Not available. The role-family sweep was refused, so there is no salary or scope band, and I won't supply one from memory (RR2) | no label, nothing asserted |
| Unknowns | Salary, who signs off rate changes, direct reports, team size, success measures | `[grounded]` JD silent on each |
| Contradictions | None found between the JD and your background. The JD could not be checked against a careers page | `[grounded]` no careers page read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You work at a UK insurer, but your location and right to work were not stated. Confidence is `low` because that is unconfirmed, not because the role fails it | `[grounded]` your background says UK motor insurer; location unstated | G1 question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst. Length of experience is not a gate. Confirmed prose, no inspectable artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" establishes use. Depth ("strong") is unprobed | `[grounded]` your background | optional: a sanitized code sample or query set |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book. A motor book, not pet | `[grounded]` your background | a sanitized model spec or validation note would raise to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4. Carried with its qualifier: one young-driver book | `[grounded]` your background | as R4 |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may include monitoring, but it does not say what was tracked, how often or with what result. Ambiguity resolves downward | `[grounded]` your wording, read at its narrower sense | G2 question |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. "Ran" does not say whether you designed them or read the results, so that stays open | `[grounded]` your background | G3 question |
| R7a | Recommendations for underwriting | must_have | direct | medium | discovery | You worked with underwriting on the tests and present the quarterly pricing review to the head of underwriting. "Recommendations" was not your word, so whether the review ends in them is unconfirmed | `[grounded]` your background | G3 question |
| R7b | Recommendations for product | important | unclear | none | discovery | Nothing you've said touches a product team | `[grounded]` no evidence supplied | G4: keep in mind, not asked this turn |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | a sanitized review pack would raise to `high` |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance pricing (implied by "our pet-insurance product") | important | adjacent | medium | transferability | The bridge is your GLM rating work in motor. The limit is that you have not worked on pet insurance, and pet-specific rating and claims data were not exercised. The JD never lists pet experience as a requirement | `[inferred]` from the JD's scope line against your stated lack of pet experience; `[generic]` that rating structures differ by product line | G5: frame as adjacent, limit stated |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and right to work (R1, hard_gate) | hard_gate | Your employer is UK-based; your own location and eligibility are unstated | A term the role sets. A mismatch would end the application, whatever the fit | A term, not experience | Nothing to attach | `[grounded]` JD term, your background silent |
| G2 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" the GLM model, with no detail on what you tracked | A must-have at `unclear`. Resolving it firms up half of the JD's first duty | Tracking actual vs expected claims or loss ratios; model refreshes; drift checks; reporting on model performance to others | A sanitized monitoring pack, a model-review note, a performance dashboard screenshot | `[grounded]` your wording; `[generic]` that monitoring is usually probed alongside building |
| G3 | Test design, readout and recommendations (R6, R7a, must_have) | discovery | 14 tests run with underwriting, and a quarterly review presented | "Design and read" is the JD's wording, and the difference from "ran" is the one an interviewer is most likely to test | Choosing test and control groups; sizing or duration; writing the readout; recommending rolling out, pausing or changing a rate | A sanitized test readout, a test plan, a review deck | `[grounded]` your wording; `[generic]` that interviews probe own-vs-team contribution |
| G4 | Product-side recommendations (R7b, important) | discovery | No product-team evidence | An important row at `none` confidence | Pricing input to a product launch or change; work with a product or commercial team | A launch note or a pricing paper | `[grounded]` no evidence supplied |
| G5 | Pet-insurance knowledge (R10, important) | transferability | Motor GLM work only | The most likely objection to your application, since the product is pet insurance | Any non-motor product work, even briefly; claims-cost modelling for another line | A sanitized note on any non-motor work | `[generic]` that the product line is the first objection to an out-of-line hire |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No check ran, so nothing here is a finding about Brindlemoor | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | "Fully remote (UK)" ends the JD with no pay figure | The posting may withhold pay, or the figure may have been lost in the paste. Your pay floor is not given, so no mismatch can be assessed | `[grounded]` JD as supplied states no figure | What salary range is budgeted for this post? | unresolved |
| RR3 | Line-management scope unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The post may be purely individual-contributor, or it may carry or grow into reports | `[inferred]` from the JD listing no people-management duty and no team size | Does this post have direct reports now, or is that planned? | unresolved |
| RR4 | Decision rights over rate changes unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend while underwriting or product decide | `[inferred]` from "recommendations" against the JD's silence on who decides | Who signs off rate changes that come from this role's recommendations? | unresolved |
| RR5 | Concrete, coherent duties | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is readable and fits the title, with no bundled specialisms | `[inferred]` from the JD text | What would a strong first year in this role look like? | noted |

## Application plan

Everything proposed in this section, table rows and the lead-with advice inside them, is `resume_edits_pending_approval` and needs your approval before use.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV or profile with three things in your own terms: the GLM rating model you built and maintained for the young-driver book; the 14 price tests you ran with the underwriting team last year; the quarterly pricing review you present to the head of underwriting. Do not write "designed", "owned" or "recommended" until G3 is answered | see R4, R5a, R6, R8 | `[grounded]` your background | pending your approval |
| E2 | State plainly in any cover note or first call that your insurance background is motor and that you have not worked on pet insurance. Claim no pet knowledge | see R10 | `[grounded]` your own statement | pending your approval |
| E3 | If management comes up, say you have not managed anyone. Do not offer a leadership claim, because the JD asks for none | see RR3 | `[inferred]` from the JD's duty list | pending your approval |
| A1 | Before investing in the loop, confirm the posting is live on Brindlemoor's own careers page and check for a salary range | see RR1, RR2 | `[grounded]` register | pending your approval |
| Q1 | In the loop, ask the verification questions from RR2, RR3 and RR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is prose self-report, so `medium` is its ceiling until you attach something inspectable.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused ("Brindlemoor pet insurance insurtech", "Brindlemoor careers Senior Pricing Analyst"). They would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | One search was refused ("senior pricing analyst pet insurance UK salary remote"). It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | unavailable | One search was refused (the hiring manager's name with the company and title). It would have moved the scope read and which of your stories to lead with |

I can save this assessment as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- **Brindlemoor's live posting or careers page**, as a link or pasted text. This closes RR1, may answer RR2, and fills role reality's contradictions row. A link you give me to read isn't charged to the research budget.
- **Permission for web search**. The remaining budget is 1 search and 2 fetches, so a pasted link goes further. This would also fill the market calibration row and the hiring-manager footprint.
- **A sanitized model spec, validation or monitoring pack, test readout or review pack**. This raises R4, R5a, R5b, R6 and R8 toward `high`.
- **Your pay floor, notice period and any other non-negotiables**. Hard-gate checks against them are unknown until I have them.
- **Your CV**. I'm working from your prose summary, and a CV would let me propose line-level edits.
- **Any non-motor or claims-cost modelling you've touched, even briefly**. This strengthens R10's bridge.

**Questions**

- **G1** — Are you based in the UK and eligible to work for a UK employer without sponsorship, fully remote?
- **G2** — After you built the young-driver GLM, what did you personally monitor, how often, and what did you change because of it?
- **G3** — On the 14 price tests, which parts were yours (design, running, reading results), and did your quarterly review to the head of underwriting end in recommendations that were acted on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.