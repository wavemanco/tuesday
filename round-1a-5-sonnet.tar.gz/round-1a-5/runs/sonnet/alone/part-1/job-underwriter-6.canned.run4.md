I'll read the skill's reference files before building the assessment.
## Decision snapshot

**Yes, worth applying to, as a stretch. Status: `conditional_go`.** R3, R4 and R5 land `direct`. The forecast and finance-data asks (R7, R8) are `adjacent`. Billing data (R9) is `absent`. The location and pay gates (R1, R2) aren't checked against you yet.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol, two office days), R2 (£61,500–£67,000 plus options)
- `must_have` — direct: R3, R4, R5 · adjacent: R7 (Owning a forecast), R8 (Working with finance on billing or revenue data) · unclear: R6 (Spreadsheet modelling)
- `important` — direct: R10 · adjacent: R11 (Working with the CFO) · absent: R9 (Owning billing data)

R7, R8 — adjacent, limits named (finance owned the forecast); R9 — absent, confirmed by you; R6 — use confirmed, modelling not shown; R1, R2 — waiting on your constraints.

**Opportunity ledger.** The pay sits at the market median (RR6) at an established, funded employer (RR7). Open unknowns are the reporting line (RR1), the forecast process (RR2), option terms (RR4) and whether the post is on Quillfield's own careers page (RR5). RR3, several specialisms under one title, is a low-severity watch.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days), R2 (£61,500–£67,000 plus options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Bristol with two office days and the pay range both fit your own limits (R1, R2).
  2. You frame forecast experience as adjacent, never as ownership (R7, RR2).
  3. The interviews show how billing data is learned and supported, since you've never worked on it (R9, RR1, RR3).
  4. The recruiter confirms the post on Quillfield's own site (RR5).
- **What would flip it:** a failed R1 or R2 makes it `no_go`. A forecast built from scratch with no support (RR2) would push it to a hold.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options, terms not stated | `[grounded]` JD |
| Stated requirements | 4+ years in RevOps, sales ops or similar analytics at a B2B software company; HubSpot or Salesforce admin; strong SQL and spreadsheet modelling; forecast ownership; finance work on billing or revenue data | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Hiring manager | Tamsin Achebe: Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. That she is hiring manager for this post comes from your recruiter. The posting doesn't say. | `[grounded]` search result (linkedin.example/in/tamsin-achebe) for title and history; `[grounded]` your report for the recruiter's statement |
| Scope read | The post probably sits in or beside Tamsin's function, and bundles CRM, billing data, reporting and forecasting under one title | `[inferred]` from her public title and the JD's mandate list |
| Market calibration | £61,500–£67,000 brackets the survey median of £64,200 and sits inside its interquartile range (£57,800–£70,400), for UK B2B software revenue operations leads (n=438). The survey is UK-wide, not Bristol-specific, and is the band to expect, not Quillfield's offer to you. | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` JD for the posted range |
| Unknowns | Reporting line and team; forecast process today; option terms; whether the post is on the company's own careers page | — |
| Contradictions | None between the JD and the about page (Bristol, invoicing). The careers page couldn't be compared because quillfield.co.uk/careers returned no page. | `[grounded]` search and fetch results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You gave no location or commute limit, so there's nothing to grade the role against | `[grounded]` JD terms; no constraint stated by you | G1 question |
| R2 | £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | You gave no pay floor; the band itself sits at market median (RR6) | `[grounded]` JD; `[generic]` survey band | G1 question |
| R3 | 4+ years in RevOps, sales ops or similar at a B2B software company | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations for the UK team, covers years and function. "Payments company" versus "software company" is a sector-label difference to check against how your CV words the employer. A years requirement isn't a gate. | `[grounded]` your background; `[inferred]` on the sector wording | Check the CV describes the employer's product |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified is specific and confirmed, but nothing inspected yet | `[grounded]` your statement | A credential record or link would raise to high |
| R5 | Strong SQL | must_have | direct | medium | none | SQL weekly is confirmed. "Strong" is untested, so expect a technical probe. | `[grounded]` your statement | A sanitized query sample would raise to high |
| R6 | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily shows use, not modelling | `[grounded]` your statement; `[inferred]` that use isn't modelling | G4, not asked this turn |
| R7 | Experience owning a forecast (the role runs the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director. Limit: you've never owned the company forecast, finance did. In revenue teams pipeline reviews commonly inform forecast calls, which is why this is adjacent and not absent. | `[grounded]` your statement; `[generic]` pipeline-to-forecast link | G2 question |
| R8 | Experience working with finance on billing or revenue data | must_have | adjacent | low | discovery | Rebuilding renewal dashboards touches revenue data, but nothing says you worked with finance on it. The posting says "billing or revenue", so the revenue route can count. | `[grounded]` your statement; `[inferred]` renewal data is revenue data | G3 question |
| R9 | Owning billing data (from "own our CRM and billing data") | important | absent | none | capability | You've never worked on billing data. The CRM half is covered by R4. Tiered `important` because the posting's requirements list asks only for "billing or revenue" experience, which R8 may meet. | `[grounded]` your statement and JD | G5 closure path |
| R10 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them isn't stated. | `[grounded]` your statement | A sanitized screenshot would raise to high |
| R11 | Working with the CFO on the quarterly forecast | important | adjacent | low | transferability | Your senior cadence is the monthly review with a sales director. Limit: that's not finance leadership, and it's monthly pipeline rather than a quarterly forecast. | `[grounded]` your statement and JD | Covered by G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay (R1, R2, hard_gate) | hard_gate | The posting states both terms; nothing says whether they fit your limits | A failed gate would make the status `no_go` whatever the fit elsewhere | Not an experience question: your commute and your minimum pay | Your own statement | `[grounded]` posting terms and your silence on limits |
| G2 | Forecast ownership (R7, must_have; R11, important) | transferability | A monthly pipeline review is confirmed; a forecast number of your own isn't | It's the posting's most explicit ask ("run the quarterly revenue forecast") and the likeliest probe | Submitting a commit or call from pipeline; owning a region or segment forecast; reconciling pipeline to finance's number; explaining forecast-versus-actual variance | A sanitized forecast-versus-actual sheet or pipeline-review pack | `[grounded]` your statement; `[generic]` that this is the likeliest probe for this title |
| G3 | Finance on revenue data (R8, must_have) | discovery | Renewal dashboards confirmed; finance contact unconfirmed | It could close a `must_have` row at `adjacent` | Agreeing renewal or ARR figures with finance; reconciling a dashboard to their numbers; finance consuming your reports | A dashboard screenshot or reconciliation sheet | `[grounded]` your statement; `[inferred]` that this moves R8 |
| G4 | Spreadsheet modelling (R6, must_have) | discovery | Daily Excel use confirmed; models aren't | It shows whether a forecast model is within reach | A capacity or quota model; a churn or renewal-rate model; scenario tabs | A sanitized workbook | `[grounded]` your statement. Not asked this turn. |
| G5 | Billing data (R9, important) | capability | You've never worked on it | The role's first-named responsibility, so a learning-curve risk | Closure path: ask in interviews how billing data is structured and who supports it; learn the basics of invoice-to-cash data before starting. No question asked. | Interview answers | `[grounded]` your statement; `[inferred]` that billing data is central to an invoicing company's data |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Reporting line and team unstated | unknown | — | "Revenue Operations Lead" | The post may sit under the Head of Revenue Operations with no team, or may lead one | `[inferred]` from the title, the posting's silence and Tamsin's public title | Who does this role report to, and are there direct reports or a team around it? | unresolved |
| RR2 | Forecast process and accountability | risk_signal | low | "run the quarterly revenue forecast with the CFO" | The role may be accountable for a number with no stated process, model owner or accuracy measure | `[inferred]` from the accountability language against the posting's silence on success measures | What does the forecast process look like today, who built the model, and how is accuracy judged? | unresolved |
| RR3 | Several specialisms under one title | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting ..., and run the quarterly revenue forecast" | CRM, billing data, reporting and forecasting are bundled. Median pay (RR6) argues against junior pricing, so severity stays low. | `[generic]` role-family pattern, not a claim about this employer | What does support around the role look like: analysts, tooling, finance partners? | unresolved |
| RR4 | Option terms unstated | unknown | — | "plus share options" | Value depends on number, vesting, strike and exercise terms, none given | `[grounded]` posting states options without terms | What are the option terms: number, vesting, strike price and exercise window? | unresolved |
| RR5 | Post not found on the company's own careers page | unknown | — | "Revenue Operations Lead, Quillfield" (Tallyboard listing) | The role may be listed elsewhere on the site, may be newly posted, or the one address tried may simply be wrong | `[grounded]` fetch of quillfield.co.uk/careers returned no page | Can you point me to this role on Quillfield's own careers page? | unresolved |
| RR6 | Pay stated and in the market band | positive_signal | — | "£61,500–£67,000 plus share options" | No seniority-compensation mismatch seen | `[grounded]` posting; `[generic]` Ledgerline band | Where in the range would a hire with my background land? | noted |
| RR7 | Employer attributable; public profile consistent with the recruiter's account | positive_signal | — | "Founded 2018 in Bristol; 96 employees. Series A (£11M) closed in April 2025." | Established, funded employer in the posting's city; the named manager's public title is in revenue operations | `[grounded]` about-page and profile search results | What has the revenue operations function delivered in the last year that this role builds on? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the proposed lines below | R3, R4, R10 | `[grounded]` your own description | pending your approval |
| P1 | Say plainly, in the application and early interviews, that finance owned the company forecast and that you haven't worked on billing data. Present the pipeline review and renewal dashboards as what you did run. | R7, R9: ownership is the point interviews will test, so the candid version is the safe one | `[grounded]` R7 and R9 rows | pending your approval |
| P2 | Lead with the sales-operations-to-RevOps path and the monthly pipeline review, since Tamsin's public profile shows a sales operations background. This rests on your strongest rows, not on a guess at what she wants. | R3, R10 | `[inferred]` from her public title and prior role | pending your approval |
| W1 | A sanitized pipeline or renewal dashboard screenshot, or a dummy-data forecast model. Limit: a model shows modelling skill, not forecast ownership. | R4, R6, R10 | `[grounded]` rows named | pending your approval |
| Q1 | Ask RR1–RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm R1, R2 and RR5 with the recruiter before investing in the loop | Cheapest checks first | `[grounded]` rows named | pending your approval |

`resume_edits_pending_approval` (nothing is final until you approve it; this holds for the table above and the lines below):

- Five years in sales operations at a B2B payments company, the last two running revenue operations for the UK team.
- Rebuilt the pipeline and renewal dashboards; run the monthly pipeline review with the sales director.
- Tools: Salesforce (admin certified), SQL, Excel.

## Evidence status

Verified: none yet. Stage assumed: evaluating. Your background came in as prose, so it's treated as CV-equivalent and capped at `medium`.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company" (returned "About Quillfield", quillfield.co.uk/about) and "Quillfield careers Revenue Operations Lead Bristol" (no results); fetched quillfield.co.uk/careers (no page). Moved: role reality's organization row, the contradictions row and RR5. |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software £60,000 £70,000", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration and RR6. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved: role reality's hiring manager and scope rows, and P2. Only a title and prior role were found; nothing beyond public professional footprint was used. |

If you'd like, I can save all of this as `tuesday-dossier.md`.

**Upgrade menu**

- Your location and pay floor → R1 and R2 resolve, and the decision firms up.
- Your CV or a prior resume → R3–R5 and R10 firm up, and any buried evidence surfaces as presentation edits.
- A Salesforce credential record → R4 to `high`. A sanitized query sample → R5 to `high`. A sanitized dashboard screenshot → R10 to `high`.
- Anything showing a forecast or finance reconciliation of yours → R7, R8 and R11 firm up.
- The recruiter's answers on reporting line, forecast process and option terms → RR1, RR2 and RR4 close.
- The role on Quillfield's own careers page → RR5 closes.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1 (R1, R2) — Do the two office days a week in Bristol and the £61,500–£67,000 range both work for you, or is either outside your limits?

G2 (R7, R11) — Has any part of a forecast or commit number been yours, even a region, a segment or the pipeline input finance took from you, and what exactly was yours versus finance's?

G3 (R8) — When you built the renewal dashboards, did you work with finance on revenue or renewal figures, such as agreeing ARR, reconciling to their numbers or sharing the dashboards with them, and what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.