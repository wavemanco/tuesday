Reading the remaining reference files (decision rules, snapshot shape, evidence vocabulary), then I'll write the assessment.
# Job Underwriting: Senior Product Analyst, Harborlight Health

## Decision snapshot

**Yes, apply. You are a fit on the analytics core (R1, R2, R3, R4, R6a and R7 are all `direct`). The healthcare domain (R9a) is a gap you can bridge honestly, and it doesn't block you. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R6a, R7 · unclear: R5 (define and maintain the metrics layer)
- `important`: unclear: R6b (partnering with clinicians), R8 (mentoring two junior analysts)
- `preferred`: adjacent: R9b (handling regulated personal data) · absent: R9a (healthcare data experience)

R5 (`low`): metrics-layer ownership is unconfirmed; R9a: the domain gap, bridged by R9b with its limit named.

**Opportunity ledger.** The posting is specific about duties, which is a positive (RR4). I couldn't verify that the employer and posting are live (RR1), and pay and level are not stated (RR2, RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown. The "5+ years" line is an experience requirement, so it is graded as R1 and is not a gate.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting verify as live (RR1); (2) you can show ownership of metric definitions, not only dashboards (R5); (3) the healthcare gap is framed as adjacent privacy and consent work, never as HIPAA experience (R9a, R9b); (4) pay and level are acceptable once stated (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header; not independently verified (RR1) |
| Mandate | Own product analytics: metrics layer, A/B test design and analysis, self-serve Looker dashboards, roadmap partnership with PMs and clinicians, mentoring two juniors | `[grounded]` JD |
| Seniority signal | Senior individual contributor with light mentoring. Two juniors are named, but no title such as lead or manager is stated | `[grounded]` JD for the two juniors; `[inferred]` that this is a senior IC, from the mentoring being listed last and no management title appearing |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Pay, location, work pattern | Not stated | `[grounded]` JD silence |
| Market calibration | Not run, because research was unavailable. No claim is made about where this title and scope sit against norms | `[generic]` none available |
| Unknowns | Whether "metrics layer" means LookML or a separate semantic layer; how often analysts work with clinicians; team structure; pay; remote or on-site | `[inferred]` from the JD's wording and silences |
| Contradictions | None found between the JD and your background. I had no second source to compare the JD against | `[grounded]` inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company. Self-reported, not yet probed | `[grounded]` your background as typed | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake. "Expert" rests on your word. A reviewable query or model would be the inspectable proof | `[grounded]` your background as typed | optional: a sanitized query or model sample would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Specific and plausible, with no artifact inspected yet, so expect a probe on the 11% and your role in it. Whether "at scale" carries over depends on Harborlight's traffic, which is unknown | `[grounded]` your background as typed; `[generic]` that interviewers for this role family probe test attribution and statistical power | optional: a sanitized test write-up would raise to high |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your background as typed | optional: a screenshot or description of the governance model would raise to high |
| R5 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" and a warehouse consent-state model are close to this. Nothing you've said confirms you owned metric definitions, such as LookML explores or a shared metrics catalog | `[grounded]` your background is silent on metric-definition ownership; `[inferred]` that the governed dashboards and consent model imply some of it | see G1 |
| R6a | Partner with product managers to turn analysis into roadmap decisions | must_have | direct | medium | none | Monthly presentations to the VP Product and a monthly metrics memo read by the exec team | `[grounded]` your background as typed | none |
| R6b | Partner with clinicians | important | unclear | low | discovery | Your background doesn't mention working with domain experts such as clinicians or medical staff. Close analogues might exist, such as culinary or operations teams | `[grounded]` your background is silent | see G3 |
| R7 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads | `[grounded]` your background as typed | none |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Your background doesn't mention mentoring or managing | `[grounded]` your background is silent | see G2 |
| R9a | Healthcare data experience | preferred | absent | none | capability | You've said you've never worked in healthcare, and nothing in your background shows healthcare data | `[grounded]` your statement | closure path in G4; carried as a minor risk |
| R9b | Handling regulated personal data (the HIPAA-adjacent part of the "plus") | preferred | adjacent | medium | transferability | You've handled GDPR and CCPA consumer PII and built the warehouse consent-state model. Limit: this is consumer-privacy law and not health information, so PHI, minimum-necessary access and BAAs were not exercised | `[grounded]` your background as typed for the experience; `[inferred]` that it is a credible bridge, because both involve consent and access rules on sensitive data | frame as adjacent only; see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R5, must_have) | discovery | A Looker build with governed dashboards and a consent-state model, but no statement about who defined and versioned metrics | A must-have at `unclear`; resolving it is the likeliest way to turn the lead requirement into `direct` | LookML explores or derived tables you wrote; a metric dictionary or definitions doc; a dbt or semantic-layer model; resolving conflicting KPI definitions across teams | A metric catalog excerpt, a LookML snippet, or a definitions doc, sanitized | `[grounded]` your background is silent on definition ownership; `[inferred]` that this is the row that matters most to the decision |
| G2 | Mentoring juniors (R8, important) | discovery | No mention of mentoring or managing anyone | The JD names it as part of the role, and your background doesn't show it | Onboarding a new analyst, reviewing others' SQL or dashboards, running a team analytics office hours, a formal mentee | None required; a sentence or two of specifics is enough | `[grounded]` your background is silent |
| G3 | Clinician partnership (R6b, important) | discovery | PM and exec partnership is clear; domain-expert partnership is not | The JD names clinicians as stakeholders | Co-designing an analysis with a nutritionist, culinary or quality team; translating an operations expert's questions into metrics | A project brief or a stakeholder-facing write-up | `[grounded]` your background is silent. Not asked in this turn, given the three-question limit |
| G4 | Healthcare domain (R9a, preferred) and the bridge (R9b) | capability | No healthcare data; a credible adjacent privacy bridge | A preferred item, so a minor risk. The danger is overstating it | A short HIPAA fundamentals course; reading about how PHI differs from consumer PII; asking about the data governance setup in interviews | A completed course or certificate, if you take one | `[grounded]` your statement for the gap; `[generic]` that a short self-study is a realistic closure path for a preferred domain item |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources: research could not run, so nothing here verifies Harborlight Health, the posting or the stage | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be real and the posting live. It may also be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. None of these is ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (no figure in the posting) | The posting's silence may be company practice, or the figure may sit below what you'd accept. Your floor was not given, so I can't check it | `[inferred]` from the JD's silence on pay | What is the budgeted salary range for this role? | unresolved |
| RR3 | Level and scope: "Senior" with two juniors to mentor, but no management title and no stated decision rights | unknown | — | "mentor two junior analysts" | The role may be a senior IC with light mentoring, or may be expected to grow into team lead | `[inferred]` from the JD's wording against its silence on title and reporting line | Who does this role report to, and are the two junior analysts direct reports or peers I mentor? | unresolved |
| RR4 | Responsibilities and requirements are specific: metrics layer, experiments, Looker and stakeholders are each named | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | The role's scope appears concrete, which is a better sign than a vague mandate | `[grounded]` JD states each duty | What are the first priorities for this role in the first six months? | noted |
| RR5 | Healthcare domain ramp and HIPAA data access | risk_signal | low | "healthcare data experience (HIPAA) a plus" | The employer lists it as a plus, so a ramp period is probably acceptable. Severity stays low because this is a preferred item | `[inferred]` from the JD's "a plus" wording | What does onboarding look like for an analyst new to healthcare data and HIPAA? | unresolved |

## Application plan

Every row below, and any wording in this message, is a proposal pending your approval. Nothing here is finalized.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your resume with the Looker build (40+ governed dashboards) and the experimentation program (30+ tests a year, the pricing test behind the 11% retention lift), using your own figures as stated | R3, R4 | `[grounded]` your background as typed | pending your approval |
| E2 | Surface the consent-state model and GDPR/CCPA PII handling as its own line: "regulated personal data handling, consent-state model". Do not use the words HIPAA, PHI or healthcare | R9b | `[grounded]` your background as typed | pending your approval |
| E3 | State the healthcare gap plainly in a cover note or screen call: "no healthcare background; here is the adjacent privacy work and what I'd learn first" | R9a, R9b | `[grounded]` your statement | pending your approval |
| A1 | Before spending effort, confirm the role on Harborlight's own careers site | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for "Harborlight Health care navigation app careers" was refused by the host. It would have confirmed the company, the stage and whether the posting is live. RR1 stands as unresolved |
| 2. Role-family sweep | unavailable | A search for "senior product analyst digital health salary range experimentation Looker" was refused by the host. It would have set a pay band and scope norm for the market calibration row in role reality and for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you'd like a `tuesday-dossier.md` of this analysis to carry forward, say so and I'll write it.

## Upgrade menu

- Search access for the employer and market checks → RR1 could verify or clear, and a pay band would set RR2 against the market.
- A sanitized test write-up, query sample or Looker model description → R2, R3 or R4 to `high`.
- A metric catalog excerpt or LookML snippet → G1, and R5 toward `direct`.
- Your pay floor, location and work-authorization needs → the hard-gate line can be checked against them instead of marked unknown.
- The hiring manager's name → role reality's scope read, and which story to lead with.

## Questions

1. **Constraints:** What are your non-negotiables for a move: pay floor, remote or on-site and location, and any work-authorization limits? A stated pay floor or a location mismatch could change the decision outright.
2. **G1 (R5):** Did you personally define and maintain metric definitions, such as LookML, a metrics catalog or KPI definitions that other teams used? What did you own, and who relied on them?
3. **G2 (R8):** Have you mentored, onboarded or reviewed the work of other analysts? What did that look like, and for how long?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.