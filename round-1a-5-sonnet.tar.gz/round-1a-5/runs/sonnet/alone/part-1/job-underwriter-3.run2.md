I've read the underwriting rules. Next I'm loading the search tool to check Novaline and the pay band for this role, and then I'll write the assessment.
# Job Underwriting — Head of Growth at Novaline

## Decision snapshot

**No, this isn't worth pursuing as posted. R1 and R2, both hard gates, fail · `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Base pay: $70–85k), R2 (On-site in Austin, five days a week)
- `must_have` — direct: R3, R4, R5
- `important` — unclear: R6 (SEO/content), R7 (Brand, PR, partnerships), R8 (Sales ops)

R3 (`medium`) — nine years against 8+, on your own account; R6, R7, R8 — not established either way.

**Opportunity ledger.** Thin on its own terms:
- Seven functions are loaded onto one person (RR3).
- After-hours work is stated as the norm (RR4).
- Success is left undefined (RR5).
- Authority, budget and equity are blank (RR6, RR7).
- The employer is unverified (RR8).

RR1 and RR2 run against your terms. RR9 runs the other way: pay and on-site terms are stated plainly.

- **Hard gates:** failed: R1 (Base pay: $70–85k), R2 (On-site in Austin, five days a week)
- **Severe red flags:** none found.
- **What would change this:** the posting would have to differ on R1, with a base at or above your $150k floor, and on R2, with remote work from Portland. It states both without room (RR1, RR2). A strong match on R3, R4 and R5 does not offset either gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; none of it checked, see Evidence status |
| Mandate | Own all revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | "A team of one to start"; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Terms | $70–85k base plus equity with no figure given; on-site Austin 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` JD |
| Requirements | 8+ years of growth leadership; thrives on ambiguity | `[grounded]` JD |
| First-90-days and first-year outcomes | None stated; "success metrics will evolve as we learn" | `[grounded]` JD silence |
| Scope read | Seven functions that usually span several roles sit with one person under a "Head of" title. That is unusually broad for a post with no team | `[inferred]` from the seven named functions against "team of one" and the stated pay |
| Market calibration | Not established: the role-family search was refused, so no band is offered. Against your floor, the posting's top figure is $65k short and its bottom figure $80k short (R1) | `[grounded]` JD figures and your stated floor |
| Unknowns | Budget and decision rights; equity size; who held growth before; how success is measured; whether the Series A and profitability claims hold | — |
| Contradictions | Not checked: the careers page was not reached | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay: $70–85k, against your $150k base floor | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your floor, which is your own, specific and confirmed. Fit fails because the JD's top figure is $65k under it | `[grounded]` JD quote and your stated floor | Surface in the snapshot; only the employer changing the figure resolves it |
| R2 | On-site in Austin, five days a week, no exceptions, against your remote-only, Portland, no-relocation constraint | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your constraint, stated and confirmed. Fit fails because the JD rules out any remote day | `[grounded]` JD quote and your stated constraint | Surface in the snapshot; only the employer changing the term resolves it |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | You gave 9 years in growth, as growth lead and then Head of Growth at two B2C subscription companies. This is prose with nothing inspected, so `medium`. How many of the nine were in lead roles is not stated | `[grounded]` your account | None now; a CV or LinkedIn history would raise it |
| R4 | Paid acquisition | must_have | direct | medium | none | You said you owned paid, and scaled one company from $8M to $40M ARR over three years with a budget you controlled. Prose only; budget size and channel mix are not stated | `[grounded]` your account | None now; a channel or budget report would raise it |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You said you owned lifecycle and are deep in Braze. Prose only, nothing inspected | `[grounded]` your account | None now; a program or results export would raise it |
| R6 | SEO/content | important | unclear | low | discovery | You listed paid, lifecycle and experimentation. SEO and content are not mentioned, and silence is not absence | `[grounded]` your account's silence | See G1 |
| R7 | Brand, PR, partnerships | important | unclear | low | discovery | Not mentioned in your account; nothing to confirm or rule out | `[grounded]` your account's silence | See G2 |
| R8 | Sales ops | important | unclear | low | discovery | Not mentioned. Your companies were B2C subscription, so any sales-ops work may be thin or absent | `[grounded]` your account's silence; `[inferred]` from B2C-only history | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, important) | discovery | Nothing on organic or content work in your account | An `important` row. It cannot move the status while R1 and R2 fail, but it matters for other roles asking for it | Setting organic targets; managing an agency or writers; running measured content tests | A GA4 organic report, a content calendar | `[grounded]` your account's silence; `[generic]` that these examples are what counts |
| G2 | Brand, PR, partnerships (R7, important) | discovery | Nothing in your account | As G1 | Launching a partner or affiliate channel; coordinating a PR push or brand campaign | A partner program brief, a campaign recap | `[grounded]` your account's silence; `[generic]` for the examples |
| G3 | Sales ops (R8, important) | discovery | Nothing in your account, and B2C subscription work often has little of it | As G1 | Owning a trial-to-paid or sales-assisted pipeline; CRM routing and reporting | A pipeline dashboard export, a routing spec | `[grounded]` your account's silence; `[generic]` for the examples |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor (see R1) | red_flag | medium | "$70–85k base plus meaningful equity upside" | Pay may also sit below what 8+ years across seven functions normally commands. No market band was checked. I put this at `medium` because the stop is carried by R1, not by this entry | `[inferred]` from the JD's years and scope against its stated figure | How was the base range set for a role asking for 8+ years of growth leadership? | confirmed |
| RR2 | Location term incompatible with remote-only (see R2) | red_flag | medium | "On-site in our Austin office 5 days a week — no exceptions." | By the posting's own words there is no remote flexibility. I put this at `medium` because R2 carries the stop | `[grounded]` JD quote and your stated constraint | Is every working day expected in the Austin office, with no remote days? | confirmed |
| RR3 | Bundled specializations on a team of one | risk_signal | medium | "Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | Several full roles are folded into one title and priced at the low end | `[inferred]` from the quote against the stated pay | Which of these functions would I run hands-on in year one, and what hires or budget are committed? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine rather than occasional | `[inferred]` from the phrasing, which presents it as culture | In the last quarter, how many evenings or weekends did the team work, and what prompted them? | unresolved |
| RR5 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may arrive without an agreed definition of success | `[inferred]` from the JD's silence on outcomes | What does success look like at 90 days and at 12 months, and who sets the targets? | unresolved |
| RR6 | Authority and budget unstated | unknown | — | "Report to the CEO with a dotted line to the board" | The reporting line is named, but nothing says what budget or decision rights come with it | `[inferred]` from the JD's silence | What budget does this role control, and which decisions does it make alone? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | The upside cannot be valued without percentage, vesting or strike price | `[grounded]` JD gives no figures | What percentage, vesting schedule and strike price does the equity carry? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No search completed, so nothing was looked for or found | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Pay and location terms stated up front | positive_signal | — | "$70–85k base"; "On-site in our Austin office 5 days a week" | The posting lets a candidate screen on the two terms that matter most before spending effort | `[grounded]` JD states both | Why is the role open now, and who held growth before? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pass on this posting as written | See R1, R2 | `[grounded]` gate rows | pending your approval |
| A2 | If you proceed against the `no_go`, take the questions in RR1 through RR8 into the first conversation, starting with RR6 and RR7 | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | For roles whose pay and location terms fit, lead with your own line: scaled one company from $8M to $40M ARR over three years with a budget you controlled. Carry it as you stated it, without naming channels or attributing the growth to one function | See R3, R4, R5 (`medium`: your account, nothing inspected, so expect a probe) | `[grounded]` your account | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Novaline e-commerce enablement startup Austin Head of Growth" was refused (search permission not granted); no page was read. It would have moved role reality's organization and contradictions rows and shown whether RR8 stands |
| 2. Role-family sweep | unavailable | The search "Head of Growth salary Series A startup base compensation 2026" was refused (search permission not granted). It would have supplied the market-calibration band and RR1's comparison |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

## Upgrade menu

- Search permission, so the Novaline lookup and the pay-band search can run. This would settle RR8 and fill market calibration. It cannot change the `no_go`, which rests on R1 and R2.
- A deeper diligence pass on Novaline (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs. Like the lookup above, it cannot change the `no_go`.
- A CV or LinkedIn history, or any inspectable artifact: a channel or budget report, a Braze program export. This would raise R3, R4 and R5 toward `high` for use on other roles.
- Any SEO/content, brand/PR/partnerships or sales-ops history, however small. This would close G1, G2 and G3.
- The hiring manager's name, which would sharpen role reality's scope read.

I can save this as `tuesday-dossier.md` whenever you want it.

No questions this turn: G1, G2 and G3 cannot move the status while R1 and R2 fail.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.