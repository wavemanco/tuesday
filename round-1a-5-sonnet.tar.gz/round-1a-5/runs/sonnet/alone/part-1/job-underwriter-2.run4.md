I've finished reading the underwriting rules. Next I'll load the search tool and run the L1 research on Quartzline and on PM salary and scope norms.
**Research status:** My search permission was refused, so nothing about Quartzline has been checked from outside your JD. The company facts below come from the JD header only. Market-pay and norm claims are `[generic]` or missing.

## Decision snapshot

**Are you wasting your time? No, not on this map. But R1a, a `must_have` requiring 3+ years of PM experience that you can't show under a PM title, is absent, and no wording closes that. Treat this as a bounded stretch application, not a bet. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3 · adjacent: R1b (the work of 3+ years PM experience), R6 (own the roadmap) · unclear: R2 (shipped API or platform products) · absent: R1a (3+ years PM experience, titled)
- `important`: direct: R4a, R7 · adjacent: R8 (write specs, drive delivery with two squads), R10 (coordinate launches with sales and support) · unclear: R4b (stakeholders in sales), R5 (agile delivery), R9 (define and track adoption metrics)

R1a — nothing in the inputs supports the titled years; R1b, R6 — credible bridges, limits named; R2 (`low`) — a lead waiting on your confirmation.

**Opportunity ledger.** The role's scope is concrete (RR4), but the employer could not be established from outside the JD (RR1), and compensation (RR2) and working location (RR3) are unstated.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting verifies as live and as Quartzline describes it (RR1); (2) G1 confirms a product you shipped (R2), or you accept R1a as a likely screen-out and use a referral route (A2); (3) every line you send claims what you did and no PM title or PM years (R1a, R1b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not checked against any outside page | `[grounded]` JD header only |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Must-have stated by the posting | "3+ years product management experience (must-have)" | `[grounded]` JD |
| Scope read | One product surface (a partner API platform) and two squads is a focused scope for a PM title, and your integration background sits inside this domain | `[inferred]` from the JD's single-product mandate against your 30+ client integrations of REST APIs |
| Screening read | A posting that marks titled PM years as must-have is often screened on that line before a human reads the rest; this is a risk to plan for, not a gate | `[generic]` role-family pattern, not a claim about Quartzline |
| Pivot read | Implementation and solutions backgrounds are a common route into platform and API PM roles, usually via roles that value integration depth | `[generic]` role-family pattern |
| Market calibration | Not available this run: no search ran and the JD states no pay | `[generic]` none used; see upgrade menu |
| Unknowns | Decision rights over roadmap and squads; compensation; location or remote policy; who the role reports to; what "adoption" targets exist | `[inferred]` from the JD's silence on each |
| Contradictions | None within the JD itself. The JD was not checked against a careers page | `[grounded]` JD read alone |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, held as a PM role | must_have | absent | none | capability | You say you have never held a PM title, so there are no titled years. Wording can't create them. The row is graded on the titled claim only; the adjacent work is R1b | `[grounded]` your statement; `[generic]` that titled-years lines are often screened literally | No wording fix. See G3 for the route; carry as a material risk |
| R1b | 3+ years product management experience, the work itself | must_have | adjacent | medium | transferability | Real adjacent work: requirements documents, integration architecture, coordinating engineers, client engineers and product managers on custom builds, and quarterly roadmap-input sessions. Limit: that work fed product decisions and did not own them, and no roadmap, prioritisation or metric accountability is stated | `[grounded]` CV claims, self-reported, no artifact inspected | Answer G2 to see whether any of it was ownership |
| R2 | Shipped API or platform products | must_have | unclear | low | discovery | The CV shows you implemented our REST APIs for clients and wrote the integration playbook, which is internal. It does not show an API or platform product you shipped. Prior context hints at an internal request-triage tool that support agents adopted, but that is unconfirmed | `[grounded]` CV silence; `[inferred]` a lead from prior context, unconfirmed | Ask G1 |
| R3 | Strong technical fluency: API docs and schemas | must_have | direct | medium | none | Postman, SQL, reading OpenAPI specs and 30+ end-to-end REST integrations. Self-reported, nothing inspected, so `medium` and expect a technical probe | `[grounded]` CV | none |
| R4a | Stakeholder management across engineering and customers | important | direct | medium | none | Coordinated your engineers and client engineers, ran scoping workshops through go-live | `[grounded]` CV | none |
| R4b | Stakeholder management with sales | important | unclear | low | discovery | The CV never mentions sales | `[grounded]` CV silence | Fold into your answer to G2 if relevant; no separate question this turn |
| R5 | Agile delivery experience | important | unclear | low | discovery | The CV names UAT and go-live, not sprints, backlogs or squads | `[grounded]` CV silence | Not asked this turn; unresolved |
| R6 | Own the roadmap | must_have | adjacent | medium | transferability | You collected client feedback for product on a quarterly cycle. Limit: collecting inputs is not setting priorities, and the CV does not say you owned the roadmap | `[grounded]` CV | Answer G2 |
| R7 | Run discovery with integration partners | important | direct | medium | presentation | Quarterly client-feedback sessions and scoping workshops are close to partner discovery, but the CV frames them as delivery. Limit: clients are not necessarily integration partners | `[grounded]` CV; the repositioning is E1 | E1 pending approval |
| R8 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents and coordination on custom builds are close. Limit: the CV does not show you writing product specs for a squad you worked alongside as its PM | `[grounded]` CV | Answer G2 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | The CV states no adoption or usage metrics. The triage-tool lead, if confirmed, may bear on this | `[grounded]` CV silence; `[inferred]` the lead | Answer G1 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live of client integrations is launch work. Limit: it is client-by-client, not a product launch to a partner base | `[grounded]` CV | Answer G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | A shipped product or tool (R2, R9; must_have and important) | discovery | The CV shows no shipped product. The one lead is an unconfirmed request-triage tool support agents adopted | A confirmed, specific tool with a usage number would move R2 and R9 and could make the application much more credible | An internal tool or portal you built or specified; a client-facing dashboard or template others adopted; the integration playbook's reach beyond your team | A short description, usage numbers, screenshots, an internal announcement | `[grounded]` CV silence; `[inferred]` that this resolves two rows |
| G2 | Ownership of scope and priority (R1b, R6, R8, R10; must_have and important) | discovery | The CV shows you coordinated and fed product, not that you decided what got built | This is the line between adjacent and direct evidence for the roadmap requirement | A custom build where you set scope or said no; client asks you prioritised; a launch you ran for a build | A scoping document, a prioritisation note, a go-live plan | `[grounded]` CV; `[generic]` that interviews for this title probe decision ownership |
| G3 | Titled PM years (R1a; must_have) | capability | No titled PM role exists | Wording can't close it; it is a risk to plan around | An interim, acting or associate PM or product-owner stint, even partial. None is stated | An org-chart title or a manager's statement, if one exists | `[grounded]` your statement; `[generic]` the closure path |
| G4 | Sales stakeholders, agile (R4b, R5; important) | discovery | The CV is silent on both | Smaller than G1 and G2 | Joint deals with sales; sprint ceremonies on custom builds | A deal note or a sprint board screenshot | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small for a footprint, the posting may be stale, or it may not represent a live hiring employer; none is likelier on this evidence | `[generic]` pattern, not a claim about this company | Can you point me to this role on your own careers site, and say who I would interview with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (no compensation in the posting) | The pay may or may not fit your floor; the withholding is itself worth a question | `[inferred]` from the JD's silence | What is the budgeted pay band for this post? | unresolved |
| RR3 | Location and working pattern not stated | unknown | — | (no location in the posting) | It may conflict with constraints you haven't given | `[inferred]` from the JD's silence | Is the role remote, hybrid or on-site, and where? | unresolved |
| RR4 | Scope concrete and bounded | positive_signal | — | "Own the roadmap for our partner-facing API platform ... drive delivery with two engineering squads" | A single product surface and named partners and squads make success checkable | `[grounded]` JD | Which roadmap decisions are yours alone, and which need sign-off? | noted |

## Application plan

All rows are proposed and pending your approval. Approval of this plan covers its prose and tables alike.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on Quartzline's own careers page before spending effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Seek an introduction or a referral to the hiring team instead of applying cold | A literal titled-years screen is the likeliest barrier, and a human reader can weigh adjacent work | `[generic]` how hiring often works for stretch applicants | pending your approval |
| A3 | Time-box this application, and apply in parallel to platform or technical PM roles that don't require titled PM years | see R1a | `[generic]` role-family pattern | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 questions verbatim at the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

`resume_edits_pending_approval`

| # | Current line | Proposed line | Source clause | Status |
|---|---|---|---|---|
| E1 | "Ran quarterly roadmap-input sessions collecting client feedback for product" | Ran quarterly sessions collecting client feedback as input to the product roadmap | your own sentence, reordered; no new facts | pending your approval |
| E2 | "Wrote the internal integration playbook the whole team uses" | Wrote the integration playbook the whole team uses | your own sentence | pending your approval |

Cover-note opening, pending your approval: "For seven years I led client integrations of our REST APIs end to end, more than 30 of them, and ran quarterly sessions collecting client feedback for our product team. I haven't held a PM title; here is the work I did that sits closest to this role." Every clause traces to your own sentences. It claims no PM years and no ownership.

## Evidence status

Verified: none yet. Unverified leads: prior context suggests you once built an internal request-triage tool that support agents adopted; it is unconfirmed and serves only as the basis for G1.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Queries for Quartzline's company and careers pages were refused. It would have fed role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | A query on API-platform PM pay and entry routes was refused. It would have fed the market-calibration row and the pay check |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Your answer to G1 (what the tool was, who used it, a usage number, a screenshot) → R2 and R9 could move toward direct.
- Your answer to G2 (a build where you set scope or priority) → R1b, R6, R8 and R10 could move toward direct.
- A pay floor, location and work-authorization constraints → hard-gate checks run instead of showing "unknown".
- Search permission → targets 1 and 2 rerun (two of the five L1 searches remain). A deeper L2 pass would add up to 5 more searches and 2 more fetches.
- The hiring manager's name → positioning for that reader.

I can also save all this as `tuesday-dossier.md` if you'd like it for later.

**Questions** (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

- **G1:** What was the request-triage tool: did you build or specify it, who used it, and how did you know it was adopted?
- **G2:** On the custom builds, who decided what was in scope and what got cut, and was any of that you?
- **C1:** What are your non-negotiables on pay floor, location and work authorization, and are you applying now or still exploring?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.