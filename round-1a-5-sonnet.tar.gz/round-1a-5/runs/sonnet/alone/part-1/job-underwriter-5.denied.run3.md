I'll read the skill's reference files before building the assessment.
**Pellucid Learning, Senior Data Engineer: yes, it looks worth applying to, on conditions. Status: `conditional_go`.** R1 and R2, the location and pay gates, can't be checked because you haven't given me your location or pay floor. RR1, the unverified employer, also caps the status at `conditional_go`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery warehouse); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts analysts depend on)

R9 — a credible bridge, its limit named; R10 (`low`) — nothing stated yet; R11 (`low`) — nothing stated yet.

**Opportunity ledger.** The mandate and stack are concrete (RR5) and the pay sits inside the market band you sent (RR3). Reporting line and team size are unknown (RR2), equity terms are unstated (RR4), and the employer is not yet verified because my search calls were refused (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and pay floor clear R1 and R2; (2) the posting is confirmed live on Pellucid's own careers page (RR1); (3) the BigQuery gap is stated plainly, not hidden (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; the live page was not checked (RR1) |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow "or similar", data quality testing | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| First 90 days and first year | Not stated | `[grounded]` JD silent |
| Scope read | One domain's pipelines and warehouse, with no direct reports mentioned, which matches the report's typical Senior scope | `[inferred]` from the JD's mandate against the pay report's scope note |
| Market calibration | The report gives a Senior Data Engineer at Series B–D companies a base median of $151,000 and an interquartile range of $139,000–$163,500, with "Senior" typically meaning 5–8 years. The posting's low end is $3,000 below the median and its high end is $2,500 above the range's top. Its midpoint, $157,000, is $6,000 above the median. So pay is at market to slightly above, and the band is not this employer's offer | `[grounded]` posting and the report as you pasted it (not independently checked); `[inferred]` the comparison |
| Unknowns | Hiring manager and reporting line (none named); team size; equity terms; whether "run the pipelines" includes on-call | `[grounded]` JD silent; `[inferred]` on-call from the verb "run" |
| Contradictions | None between the JD and the about text as pasted | `[grounded]` the two pasted texts; live pages unchecked |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | "Remote (US) or our Denver office" | hard_gate | unclear | none | hard_gate | You haven't said where you are or whether you can work in the US, so the gate can't be settled either way. Confidence is `none` because there is no stated constraint to grade | `[grounded]` JD text; your message silent on location | Q1 below |
| R2 | "$148,000–$166,000 plus equity" | hard_gate | unclear | none | hard_gate | The range is stated, but your pay floor isn't, so whether it meets your floor is open | `[grounded]` JD text; your message silent on a floor | Q2 below |
| R3 | "5+ years data engineering" | must_have | direct | medium | none | "6 years of data engineering at a B2B payroll company" is above 5+. It is a stated claim with nothing inspectable yet. Experience length is graded as a requirement, not a gate | `[grounded]` your background; the report's 5–8 year "Senior" range is `[grounded]` as pasted | none |
| R4 | "Strong SQL and Python" | must_have | direct | medium | none | "Python and SQL daily" is confirmed. "Strong" has no inspectable proof yet, so expect a probe | `[grounded]` your background | Offer: a sanitized query or pipeline sample would raise to `high` |
| R5 | "dbt" | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models." Ownership of the build is stated. Your share of the work versus the team's isn't, and nothing is inspectable yet | `[grounded]` your background | Offer: a sanitized model DAG or project structure would raise to `high` |
| R6 | "a cloud warehouse" | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the generic requirement is met. The BigQuery specifics are R9 | `[grounded]` your background | none |
| R7 | "orchestration with Airflow or similar" | must_have | direct | medium | none | "Airflow for orchestration" is confirmed. The detail on what you ran or owned is thin | `[grounded]` your background | Optional: one sentence on DAG count or scope |
| R8 | "experience with data quality testing" | must_have | direct | medium | none | "I set up our Great Expectations test suite" states ownership of the setup. Coverage and outcomes aren't stated | `[grounded]` your background | Offer: a sanitized suite summary would raise to `high` |
| R9 | "a dbt-modelled warehouse in BigQuery" | important | adjacent | medium | transferability | Tiered `important` because the requirements list says "a cloud warehouse" and BigQuery appears only in the mandate. Bridge: dbt and warehouse SQL on Snowflake. Limit: you have never used BigQuery. Platform-specific mechanics such as its cost model and table design are usually where Snowflake-to-BigQuery moves get probed | `[grounded]` JD quote and your statement; `[generic]` on what gets probed | G1; C1 in the plan |
| R10 | "ingestion from our app and CRM" | important | unclear | low | discovery | Nothing you've said covers ingestion sources. Running Airflow suggests pipeline work, but not from which systems | `[grounded]` your background silent on sources; `[inferred]` from the Airflow claim | G2 |
| R11 | "the data contracts our analysts depend on" | important | unclear | low | discovery | The Great Expectations suite is related work, but a data contract is a separate thing you haven't described | `[grounded]` your background silent; `[inferred]` relatedness from the suite | G3; Q3 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt are confirmed; BigQuery use is not | The JD names BigQuery in the mandate, so the screen will likely probe it | A BigQuery side project; a migration or evaluation you took part in; BigQuery used through a dbt adapter | A repo or a short write-up | `[grounded]` your statement of no BigQuery use; `[generic]` that a named platform is probed |
| G2 | Ingestion from app and CRM (R10, important) | discovery | The sources your pipelines pulled from aren't stated | The JD makes ingestion the first named responsibility | Loading product or event data; syncing a CRM such as Salesforce or HubSpot; third-party APIs or CDC feeds | A pipeline diagram or DAG screenshot | `[grounded]` background silent on sources |
| G3 | Data contracts for analysts (R11, important) | discovery | The Great Expectations suite is confirmed; contracts with analysts are not | The JD names these as what analysts depend on | Agreeing schemas or freshness expectations with downstream teams; breaking-change rules; dbt model contracts or tests analysts relied on | A contract doc, a schema agreement, or a dbt YAML sample | `[grounded]` background silent; `[inferred]` that the suite is the nearest related work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Series C ($52M, February 2026)" and "264 employees" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Hiring manager, reporting line and team size unstated | unknown | — | "The posting names no hiring manager" (your note) | Scope and support around the role may be thinner or clearer than the mandate suggests | `[inferred]` from the posting's silence | Who does this role report to, and who else works on the data platform? | unresolved |
| RR3 | Pay range stated and inside the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The posting is transparent on base pay, which sits at market to slightly above | `[grounded]` posting and pay report as pasted | Is the range the same for the remote and Denver versions of the role? | noted |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | The size and structure of the equity are unknown, so total compensation can't be compared | `[inferred]` from the posting's silence | What is the equity grant type, vesting schedule and current strike or valuation basis? | unresolved |
| RR5 | Mandate and stack are concrete | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role has a defined domain and named tools rather than a bundle of unrelated duties | `[grounded]` JD | What would success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the top bullet with your own sentence, "Built our dbt project on Snowflake — about 180 models", unchanged | R5 and R6, your strongest direct match | `[grounded]` your background | `resume_edits_pending_approval` |
| E2 | Add "Set up our Great Expectations test suite" as its own data-quality bullet beside it | R8 | `[grounded]` your background | `resume_edits_pending_approval` |
| C1 | In a cover note or summary: "Six years of data engineering; dbt and Airflow on Snowflake. I haven't yet used BigQuery." | R9: the JD names BigQuery, and stating the limit yourself avoids a surprise at the screen | `[grounded]` your statements; `[generic]` that a named-platform gap is usually probed | pending your approval |
| A1 | Check that the role is live on Pellucid's own careers page before spending effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the RR2, RR3 and RR4 questions verbatim once you are in a loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Everything in this table is proposed, not applied, and nothing is finalized until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent: one on Pellucid's business description and funding, one limited to its own domain for the posting. Both were refused, so nothing was returned. It would have moved RR1 and the contradictions row |
| 2. Role-family sweep | skipped | The pay report you pasted is in hand and already fixes the market calibration and the pay comparison this target feeds |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Closing

I can save all of this as `tuesday-dossier.md` for later turns or other tools, if you'd like it.

**Upgrade menu**

- Your location, work authorization and pay floor → R1 and R2 move from `unclear` to `direct` or `hard_gate_fail`, and the status likely settles.
- Your CV itself → R3 to R8 get checked against the actual wording, and E1 and E2 can be checked against it.
- A sanitized dbt DAG, query or test-suite summary → R4, R5 or R8 to `high`.
- An answer to G1, G2 or G3 → R9, R10 or R11 close or strengthen.
- A link to the live posting on Pellucid's own careers page → RR1 can clear.
- Search access granted here, or a deeper company pass (up to 5 more searches and 2 more fetches; search was refused this turn, so it needs access first) → RR1 and leadership or funding checks.
- A hiring manager's name → role reality's scope read.

**Questions**

- **R1:** Where are you based, and can you work in the US without sponsorship?
- **R2:** What is the lowest base salary you would accept for this role?
- **G3:** Have you agreed schemas, freshness or breaking-change rules with the analysts or teams using your data, and what did you personally own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.