Search permission was refused, so I'm assessing from your resume and the JD alone.

## Decision snapshot

**No, this isn't a waste of your time. Apply, on conditions. R1b (titled PM years) is absent, but it is a length-of-experience requirement and not a gate. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1a (work that may count toward PM years), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery) · absent: R1b (Titled PM years)
- `important` — direct: R7 · adjacent: R6 (Own the partner API roadmap), R8 (Specs, drive delivery with squads) · unclear: R9 (Adoption metrics)

R1b — absent, and no resume wording closes it; R1a, R2 — credible bridges, limits named; R3 (`medium`) — self-reported, waiting on an artifact.

**Opportunity ledger.** The employer is not established from here (RR1), pay is unstated (RR2), and authority over the two squads is unstated (RR3). The scope reads as defined (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify as live and real, see RR1; (2) the recruiter or hiring manager confirms that comparable non-titled work is considered against the 3+ years, see R1b and R1a; (3) R1a and R2 are presented as adjacent, never as titled PM work or as shipping the API product itself.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B. Existence and live posting not checked here (RR1) | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs and drive delivery with two squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Scope read | One PM over a single platform with two squads. The "3+ years" bar points to a mid-level post and not a lead role | `[inferred]` from the squad count and the stated experience floor |
| Seniority and pivot route | Moves from solutions or implementation work into API or platform PM are a commonly described route, because the buyers are integrators whose work the candidate already does | `[generic]` role-family pattern, not a claim about Quartzline |
| First-year outcomes | Not stated. The likely ones are a roadmap in place, adoption metrics defined and tracked, and launches coordinated | `[inferred]` from the responsibility list |
| Market calibration | Not run, because the role-family search was refused. No pay band is given and no claim is made about this title's norms | `[grounded]` research state |
| Unknowns | Salary; location or remote terms; whether this is the first PM on the platform; authority over squad priorities; adoption targets | `[grounded]` JD silence |
| Contradictions | None inside the JD. It could not be checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience: work that may count | must_have | adjacent | medium | transferability | Your account: "Ran quarterly roadmap-input sessions collecting client feedback for product"; "Coordinated our engineers, the client's engineers, and product managers on custom builds"; requirements documents on 30+ integrations. Limit: you fed the roadmap and worked beside PMs, and you did not say you set priorities or answered for outcomes | `[grounded]` CV prose, unprobed, so `medium` is the ceiling | See G2 and A1 |
| R1b | 3+ years product management experience: titled PM role | must_have | absent | none | capability | You say you have never held a PM title. A time-in-title requirement may be screened literally by recruiters or filters, so this is the likeliest reason for rejection at the first screen | `[grounded]` your statement and the JD's "must-have"; `[generic]` that titled years are often screened literally | No wording closes this. Ask the recruiter (A1); see G6 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Strong delivery on the consuming side: 30+ client integrations of your vendor's REST APIs. Limit: that is integrating a product, and nothing stated shows you releasing or owning the API product itself | `[grounded]` CV prose | See G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | "Comfortable in Postman and SQL and reading OpenAPI specs", backed by 30+ integrations. Specific, but no inspectable artifact yet, so expect a probe | `[grounded]` CV prose | Offer: a sanitized Postman collection or integration spec would raise it to `high` |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | Coordinated your own engineers, clients' engineers and product managers across 30+ integrations | `[grounded]` CV prose | none |
| R4b | Stakeholder management with sales; launch coordination with sales and support | must_have | unclear | none | discovery | Nothing in the resume touches sales or support. Go-lives are launch-like work, but whether sales or support were involved is not stated | `[grounded]` CV silence | See G4 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | The resume does not say whether the custom builds ran in sprints. Coordinating engineers on builds is indirect context only | `[grounded]` CV silence plus indirect context | See G5 |
| R6 | Own the roadmap for the partner API platform | important | adjacent | medium | transferability | You collected roadmap input. Limit: ownership means prioritising and trading off, and you did not state that you did either | `[grounded]` CV prose | See G2 |
| R7 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly client sessions are discovery with the people who integrate. The resume files them under integration delivery, so a PM reader may miss them. Limit: the sessions collected feedback for product and did not decide what was built | `[grounded]` CV prose | E1 to E3 pending approval |
| R8 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents and integration architecture for client builds are adjacent to product specs. Limit: written for a client's project, not for a standing product squad | `[grounded]` CV prose | See G2 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | The resume is silent on adoption. An unconfirmed lead from an earlier conversation suggests you built an internal request-triage tool that support agents adopted. It is a lead only | `[grounded]` CV silence; `memory_lead` unconfirmed | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped API or platform product (R2, must_have) | transferability | Integration delivery on the consuming side; the possible triage-tool lead is unconfirmed | A must-have at `adjacent`. A confirmed internal tool with real users would be the nearest thing to a shipped product on your record | An internal tool, script or portal others used; a client-facing API feature you specified or beta-tested with engineering; a reusable integration template adopted across the team | A short write-up, screenshot, usage numbers or a README | `[grounded]` CV scope; `[inferred]` that a confirmed tool would narrow the limit |
| G2 | Roadmap and spec ownership (R1a, R6, R8) | transferability | Roadmap-input sessions, requirements documents, coordination with PMs; no stated decision rights | These rows decide whether the bridge reads as PM work or as adjacent support | Feedback from your sessions that changed what product built; a priority call you made between competing client asks; a spec engineering built from | A roadmap-input summary, a requirements document with identifying details removed, or a feature that shipped from a client request | `[grounded]` CV prose |
| G3 | Adoption metrics (R9, important) | discovery | No metric work on the resume; one unconfirmed lead | The JD names adoption metrics, and a confirmed measured outcome is the clearest evidence for it | A usage count or adoption rate you tracked for the triage tool or the playbook; time-to-go-live across the 30+ integrations | A dashboard screenshot, a report, or a before and after count | `[grounded]` CV silence; `memory_lead` is a lead only |
| G4 | Working with sales and support on launches (R4b, must_have) | discovery | No mention of either | A must-have with no evidence either way | Handoffs from a pre-sales scoping call; a go-live you coordinated with the client's support team; escalation paths you set with your own support team | A go-live checklist, a handoff note or an email thread, sanitized | `[grounded]` CV silence |
| G5 | Agile delivery (R5, must_have) | discovery | The resume is silent on sprints or ceremonies | A must-have a recruiter can tick quickly if true | Sprint planning or standups with engineers on custom builds; backlog grooming; release or UAT cycles run in iterations | A board screenshot, a sprint review note, or a release plan | `[grounded]` CV silence |
| G6 | Titled PM years (R1b, must_have) | capability | No titled PM role, by your own statement | The one row no wording can fix; it may screen you out before a human reads further | An internal transfer or a part-time PM remit would count only if real and titled. Otherwise the route is a recruiter or hiring-manager conversation, or a role that reads adjacent work as equivalent | Not applicable | `[grounded]` your statement; `[generic]` that some employers read adjacent work as equivalent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No negative finding exists; the search was refused | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` research state | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation, location and remote terms unstated | unknown | — | no pay or location line in the pasted JD | Pay may sit anywhere relative to a pivot-level offer; no band could be run, so no comparison is made | `[grounded]` JD silence | What is the salary range and the location or remote arrangement for this post? | unresolved |
| RR3 | Ownership of the roadmap without stated authority | unknown | — | "Own the roadmap for our partner-facing API platform; ... drive delivery with two engineering squads" | The PM may be accountable for outcomes without decision rights over squad capacity or priorities | `[inferred]` from the ownership language against silence on decision rights | Who sets squad priorities, and which roadmap calls does this role make alone? | unresolved |
| RR4 | Scope and responsibilities explicit | positive_signal | — | "run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics" | The mandate is concrete; the success measures are still open | `[grounded]` JD states the duties | What would adoption look like at twelve months, and what is the baseline today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before investing in a full application, ask the recruiter whether comparable non-titled work is weighed against the 3+ years | R1b, R1a, RR1 | `[grounded]` R1b and the JD's "must-have" | pending your approval |
| A2 | Seek a warm introduction to the hiring team or a current partner of Quartzline before applying cold | A person can read past a title screen that a form cannot | `[generic]` role-family pattern, not a fact about Quartzline | pending your approval |
| P1 | In the cover note, say plainly that you have not held a PM title and that your work is integration delivery plus roadmap input, then lead with the 30+ integrations and the quarterly roadmap-input sessions | Naming the gap yourself reads straighter than a reader finding it, and matches R1a, R7 | `[grounded]` CV and your statement | pending your approval |
| Q1 | Ask RR2, RR3 and RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | If G1 comes back without a shipped tool, draft a one-page proposal for one improvement to your own vendor's API developer experience, built from friction points you met in integrations | Could make R2's bridge inspectable. Work sample, optional | `[inferred]` from R2's limit | pending your approval |

Proposed resume edits, `resume_edits_pending_approval`. Each clause traces to a sentence you wrote, and none adds a fact:

| # | Your current line | Proposed | Change |
|---|---|---|---|
| E1 | "Ran quarterly roadmap-input sessions collecting client feedback for product" | Same words, moved to the top of the role entry | Position only (R7, R6) |
| E2 | "Led 30+ client integrations of our REST APIs end to end — scoping workshops, requirements documents, integration architecture, UAT, go-live" | Same words, listed second | Position only (R2, R8) |
| E3 | "Coordinated our engineers, the client's engineers, and product managers on custom builds" | Same words, listed third | Position only (R1a, R4a) |

I haven't proposed "owned the roadmap", "shipped" or "product" language for any of these lines, because none of those words appears in your sentences. Everything in this plan is proposed and pending your approval, the table rows and the P1 prose advice included.

## Evidence status

Verified: none yet. Unverified lead: a prior-context mention of an internal request-triage tool that support agents adopted. It is unconfirmed and prompts G1 and G3 only.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The call was refused. It would have moved RR1, role reality's organization and contradictions rows, and the standing failed-attribution entry |
| 2. Role-family sweep | unavailable | The call was refused. It would have moved role reality's market calibration and how often R1b is screened literally |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can also package this as a `tuesday-dossier.md` file if you want to keep or reuse it.

## Upgrade menu

- Allowing web search lets targets 1 and 2 run, which would settle RR1, add a pay and scope band for R1b and RR2, and show how Quartzline's own careers page describes the role.
- A link to the live posting or Quartzline's careers page closes RR1 directly.
- A sanitized Postman collection, an integration spec, or a requirements document raises R3 to `high` and gives R8 something inspectable.
- A product-side artifact (a roadmap-input summary, a spec an engineering team built from, a launch checklist, or an adoption or usage report) lifts the rows it touches (R1a, R6, R8, R9, G4) from `adjacent` or `unclear`.
- Your non-negotiables (pay floor, location or remote, anything on work authorization) create hard-gate rows against the JD's silence in RR2.
- The hiring manager's name feeds role reality's scope read and which of your stories the plan leads with.
- A deeper pass on Quartzline (funding, leadership changes, public reports, recent news) takes up to 5 more searches and 2 more fetches. Say the word and it runs, once search is allowed.

## Questions

G1 — A prior conversation suggested you once built an internal request-triage tool that support agents adopted, and I haven't confirmed that. If it's right, what did you build, what was yours and what was the team's, and how did you know people used it (any number, report or screenshot)?

G2 — In the quarterly roadmap-input sessions, did feedback you collected ever change what product built or prioritised, and who made that call, you or product?

Intake — Do you have non-negotiables for a role like this, such as a pay floor, location or remote, or work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.