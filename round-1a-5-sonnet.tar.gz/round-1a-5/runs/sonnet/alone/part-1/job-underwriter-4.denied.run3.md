I'll read the skill's reference files first.
## Decision snapshot

**Yes, go for it, on conditions. Status: `conditional_go`.** Your two worries aren't gates. Pet insurance sits at R10 (`adjacent`, preferred), and none of the map's rows asks for line management. R2, R3, R4, R5a, R6a, R7a and R8 (all `must_have`) are `direct`. R5b, R6b and R7b (`must_have`) are not yet established, and the employer is unverified (RR1).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5a, R6a, R7a, R8 · unclear: R5b (monitor rating models), R6b (design price tests), R7b (recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (pet-insurance familiarity)

R5b, R6b — the CV says "maintained" and "ran", not "monitored" or "designed"; R7b — product audience unevidenced; R10 — a credible motor-to-pet bridge, its limit named; R4 (`medium`) — confirmed in your own words, waiting on an artifact.

**Opportunity ledger.** Sound on its face, but unverified. The employer wasn't checked (RR1), and pay and contract are unstated (RR2). Rate-approval rights (RR3) and the pet team and data (RR4) are also unstated. The posting does name concrete deliverables (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) you're confirmed UK-based for the remote term (R1); (3) the answers on monitoring and test design (R5b, R6b) land as truthful claims, or the lines stay worded as "maintained" and "ran".

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Existence and posting status not checked (search was refused) | `[grounded]` JD header; existence not established |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` as you gave it |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Scope read | A senior individual-contributor post. The JD names no direct reports or management duty | `[grounded]` JD lists none |
| First-year outcomes | Not stated. Likely: take over model monitoring and the test pipeline for the pet product | `[inferred]` from "own pricing analytics" and "build and monitor" |
| Market calibration | Not offered. The role-family sweep didn't run, so there is no title, scope or pay band, and none is given from memory | `[grounded]` JD states no pay; sweep unavailable |
| Unknowns | Salary; contract basis; who approves rate changes; team size; pet data and tooling | `[grounded]` JD silent on each |
| Contradictions | None inside the JD. It couldn't be compared with a careers page | `[grounded]` JD as pasted |

## Evidence map

Your background, typed in the conversation, counts as CV-equivalent. That caps most rows at `medium` until an artifact is inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You work at a UK insurer, but your location and right to work weren't stated. Confidence is low because the constraint is unconfirmed, not because the role fails it | `[inferred]` from "UK motor insurer"; `[grounded]` JD term | Question 3 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics stated, 2 of them senior. A length requirement, not a gate | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. "Strong" rests on your word, with no sample | `[grounded]` your background | optional: a sanitised query or notebook |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Specific and confirmed, no artifact | `[grounded]` your background | optional: a model summary or validation note |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4. Limit: one motor book | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" doesn't establish post-release performance tracking. Ambiguity resolves downward | `[grounded]` "maintained"; `[inferred]` that monitoring may sit inside it | G1, question 1 |
| R6a | Read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your background | none |
| R6b | Design price tests | must_have | unclear | low | discovery | "Ran" doesn't say who chose the design (cells, sample, success measure) | `[grounded]` "ran"; design ownership not stated | G2, question 2 |
| R7a | Recommendations for underwriting | must_have | direct | medium | none | 14 tests with underwriting, plus the quarterly review you present to the head of underwriting | `[grounded]` your background | none |
| R7b | Recommendations for product | must_have | unclear | low | discovery | Nothing in your background reaches a product audience | `[grounded]` silence | G3, queued |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance familiarity (implied by the product, not asked for) | preferred | adjacent | medium | transferability | Bridge: GLM rating and price testing in motor. Limit: you haven't exercised pet-specific factors. Pet books likely differ in what drives risk | `[grounded]` you've never worked on pet insurance; `[generic]` that pet rating differs from motor | G4, queued |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | "Built and maintained" the young-driver GLM. Nothing says how its performance was tracked | The JD names "monitor" in its first sentence, so this decides whether R5b becomes `direct` | Tracking actual vs expected performance after release; spotting drift and triggering a refit; a recurring monitoring pack someone reviewed | A sanitised monitoring report, dashboard screenshot or governance note | `[grounded]` JD wording and your "maintained"; `[inferred]` it could move R5b |
| G2 | Designing price tests (R6b, must_have) | discovery | You ran 14 tests. Design ownership isn't stated | "Design and read" is a named duty; "ran" alone supports only the reading half | Choosing test segments, control groups, duration or the success measure; reading results and recommending a rollout | A sanitised test brief or results deck | `[grounded]` your "ran" and the JD; `[inferred]` it could move R6b |
| G3 | Recommendations to product (R7b, must_have) | discovery | Your audiences so far are underwriting and the head of underwriting | The JD names product as a second audience | A pricing finding that fed a proposition, cover-design or distribution decision | A paper or deck that went beyond underwriting | `[grounded]` JD and your background |
| G4 | Pet-insurance familiarity (R10, preferred) | transferability | Strong motor rating, no pet exposure | Preferred only, but it shapes how you frame the application | Any non-motor or multi-line pricing exposure | Nothing needed now; the honest framing is in P1 below | `[grounded]` your statement; `[generic]` that pet and motor risk drivers differ |

G3 and G4 aren't asked this turn because the question budget is spent on higher-impact rows.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | No search ran, so nothing here confirms the employer. It may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and contract basis unstated | unknown | — | "Fully remote (UK)" (the JD's last line; no pay or contract line follows) | The salary may or may not match a senior role, and the post may or may not be permanent | `[inferred]` from the posting's silence as pasted | What is the salary band, and is the post permanent? | unresolved |
| RR3 | Decision rights unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend while another team approves rate changes | `[inferred]` from "recommendations" against the JD's silence on approval | Who approves a rating change, and what does this role decide versus recommend? | unresolved |
| RR4 | Team, data and tooling unstated | unknown | — | "build and monitor rating models" | The pet book's data depth, tooling and team size are unknown | `[inferred]` from the JD's silence | What data and tooling does the pet product rate on, and who else works on rating? | unresolved |
| RR5 | Concrete deliverables and a named senior manager | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The JD names three concrete activities and a Director-level hiring manager | `[grounded]` JD | What would a good first year look like in this role? | noted |

RR1 caps the decision at `conditional_go` until it is verified.

## Application plan

`resume_edits_pending_approval` — nothing below is applied until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting and employer from the employer's own careers site before drafting anything | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV summary with: "Pricing analyst with 5 years at a UK motor insurer, the last 2 as senior analyst. Built and maintained the GLM rating model for the young-driver book; ran 14 price tests with the underwriting team last year; present the quarterly pricing review to the head of underwriting. SQL and Python daily." It uses "maintained" and "ran", not "monitored" or "designed", until G1 and G2 are answered | see R4, R5a, R6a, R7a, R8; each clause traces to your own sentence | `[grounded]` your background | `resume_edits_pending_approval` |
| P1 | If asked about pet insurance, say what you told me: your work has been motor, not pet, and you'd be learning the pet-specific rating factors. Don't say more than that | see R10 | `[grounded]` your statement | pending your approval |
| Q1 | In the loop, ask RR1–RR4's questions verbatim, and RR5's | the register doubles as interview preparation | `[grounded]` register | pending your approval |

Positioning for Odile Varga isn't tailored, because her public footprint wasn't researched.

## Evidence status

Verified: none yet. Stage assumed: evaluating.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst"; the host refused both. Would have moved role reality's Organization and Contradictions rows, and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst UK pet insurance salary remote"; refused. Would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing"; refused. Would have moved the scope read and the application plan's positioning |

I can save all this as `tuesday-dossier.md` if you'd like it kept.

## Upgrade menu

- **Search access, or a link to the live posting.** This unlocks the employer check (RR1), a market band for RR2, and Odile Varga's public professional footprint for positioning. A link you hand me to read isn't charged to the research budget.
- **Your actual CV.** This lets me find buried evidence and test E1 against your real wording. Right now the fit side rests on your summary.
- **A sanitised monitoring report** moves R5b. **A test brief or results deck** moves R6b and can lift R6a. **A model summary** moves R4 and R5a toward `high`. **A sanitised query or notebook** does the same for R3.
- **A paper that reached a product audience** moves R7b.
- **Your constraints (location, pay floor, contract type)** settle R1 and let the other gates be checked.

## Questions

1. **G1 (R5b):** After you released the young-driver GLM, how did you track whether it was performing, and did that ever trigger a change you made or recommended? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **G2 (R6b):** On the 14 price tests, which parts did you choose yourself (segments, control groups, duration, success measure), and which were set by the underwriting team? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **R1:** Are you UK-based with the right to work there, and are there any non-negotiables (pay floor, contract type, hours) I should check this role against? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.