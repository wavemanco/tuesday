I'll read the skill's reference files before building the assessment.
**Am I wasting my time? No, not on this role. But it's a stretch application, not a strong-fit one: R1b (3+ years of titled PM experience) is `absent`, while R3 and R5 are `direct`. Status: `conditional_go`.** This reads this one posting against your resume. It doesn't judge the PM pivot as a whole.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R3, R5 · adjacent: R1a (PM-equivalent work), R2 (shipped API products), R4 (roadmap ownership), R6 (specs, squad delivery) · absent: R1b (titled PM years)
- `important` — direct: R7 · unclear: R8 (agile delivery), R9 (adoption metrics), R10 (launches with sales, support)

R1b — titled years absent, and no wording changes that; R2, R4, R6 — adjacent bridges with their limits named; R8, R9, R10 — unresolved, and cheap to settle with your answers.

**Opportunity ledger.** The employer is unestablished from here (RR1), the posting withholds pay, location and level (RR2), and it is silent on reporting line (RR4) and on how strictly it reads "3+ years" (RR5). RR3 runs the other way: the partner-facing API scope is concrete.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The employer and the live posting verify (RR1).
  2. Someone at Quartzline confirms that equivalent product work is read alongside titled years (R1b, RR5) before you invest in a full application.
  3. Your adjacent work stays framed as adjacent (R1a, R2, R4, R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not verified (see Evidence status) | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Stated requirements | 3+ years of PM experience (marked must-have), shipped API or platform products, technical fluency (API docs, schemas), stakeholder management across engineering, sales and customers, agile delivery | `[grounded]` JD |
| Hard gates | None stated. "3+ years" is a length-of-experience requirement, so it is tiered `must_have` and not a gate | `[grounded]` JD states no authorization, location, schedule or pay term |
| First-year outcomes | Not stated. The JD lists responsibilities and no targets for adoption or launches | `[grounded]` JD |
| Scope read | One platform, two squads, and a "3+ years" bar point to a single-product PM post and not a leadership post | `[inferred]` from squad count and the experience bar |
| Market calibration | Not established: the role-family sweep did not run, so no pay band or title norm is offered | `[grounded]` search refused, see Evidence status |
| Unknowns | Pay, location or remote policy, level, reporting line, PM team size, how "3+ years" is screened | `[grounded]` JD silent |
| Contradictions | None inside the JD. JD against careers page not checked | `[grounded]` search refused |

## Evidence map

Every claim here comes from your pasted resume, so each one is self-report at intake. That caps confidence at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience: the work, not the title | must_have | adjacent | medium | transferability | Roadmap-input sessions, requirements documents and coordination with product managers on custom builds are PM-shaped. Limit: you collected input and wrote requirements for client builds, and you didn't own a product's priorities | `[grounded]` resume prose; `[generic]` that screens often read this line literally | Bridge case in G4 |
| R1b | 3+ years PM experience: titled years | must_have | absent | none | capability | You have never held a PM title, so no titled years exist. This is not a gate, but it is the likeliest screening risk | `[grounded]` your statement; `[generic]` that some employers screen on title | Closure path in G5; ask RR5 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote its integration playbook. Limit: that is the consumer-facing side of API products, not owning one's roadmap or release. An unconfirmed lead about an internal tool is not counted | `[grounded]` resume prose; the lead is a `memory_lead`, asked in G1 and not asserted | Bridge in G4; G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture, stated specifically. Medium until an artifact is inspected | `[grounded]` resume prose | Offer: a sanitized playbook excerpt would raise to high |
| R4 | Own the roadmap for the API platform | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions that collected client feedback for product. Limit: you fed the roadmap and did not set or trade off its priorities | `[grounded]` resume prose | Bridge in G4; G2 |
| R5 | Discovery with integration partners | must_have | direct | medium | none | Scoping workshops and quarterly feedback sessions with clients integrating your APIs are discovery with the same kind of counterpart. Clients are not necessarily partners, so expect a probe | `[grounded]` resume prose | none |
| R6 | Write specs and drive delivery with two engineering squads | must_have | adjacent | medium | transferability | You wrote requirements documents and integration architecture and coordinated your engineers, the client's engineers and product managers. Limit: coordination on client builds, with no stated authority over a squad's backlog | `[grounded]` resume prose | Bridge in G4; G2 |
| R7 | Stakeholder management across engineering, sales and customers (engineering and customers; sales is carried at R10) | important | direct | medium | none | Engineers on both sides and clients across 30+ integrations, stated | `[grounded]` resume prose | none |
| R8 | Agile delivery | important | unclear | low | discovery | The resume describes UAT and go-live and says nothing of sprints, backlogs or cadences. Silence isn't absence | `[grounded]` resume silence | G2 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | The resume is silent on adoption measures. One unconfirmed lead exists about an internal tool agents adopted | `[grounded]` silence; lead from `memory_lead` | G1 |
| R10 | Coordinate launches with sales and support | important | unclear | low | discovery | Go-lives are evidenced. Sales and support involvement is not, and a client go-live is not obviously a product launch | `[grounded]` resume prose and silence | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Adoption metrics (R9, important) | discovery | No metric ownership stated. Something earlier suggested an internal request-triage tool that support agents adopted, but nothing is confirmed | If real and yours, it would be the nearest thing to a built-and-adopted product, and it bears on R2 as well | Choosing what "adopted" meant; tracking usage; deciding what to change after launch; being the person who decided what it did | Usage screenshot, a one-page spec, an adoption number, a rollout note | `[grounded]` resume silence; `[inferred]` it could move R9 and R2 |
| G2 | Agile delivery and prioritization (R8, important) | discovery | UAT and go-live are described, with no cadence, backlog or trade-off work | The answer also bears on R4 and R6, the two adjacent must-haves closest to the PM job | Running sprints or standups with engineers; deciding what was cut or deferred on a custom build; keeping a backlog | A sanitized backlog, a scope-change log, a build plan | `[grounded]` resume silence; `[inferred]` the answer bears on R4 and R6 |
| G3 | Launches with sales and support (R10, important) | discovery | Go-lives are stated, sales and support involvement isn't. The question is held back this turn to stay within budget | An important row that a short answer could settle | Handing a go-live to support; briefing sales on a new capability | A go-live checklist or handoff note | `[grounded]` resume prose |
| G4 | Bridge: PM work to PM role (R1a, R2, R4, R6; all `must_have`) | transferability | Adjacent evidence that carries over: integration scoping, requirements, roadmap input, cross-team coordination. Limits: input and requirements for client builds, with no owned priorities, no shipped product and no squad authority | This is the case you will make to a reader who sees no PM title | A short work sample would narrow the limits: a one-page roadmap or spec for a gap you saw across your integrations | A sanitized one-pager, or the playbook | `[grounded]` rows named; `[generic]` that a work sample narrows a titled-experience gap |
| G5 | Titled PM years (R1b, must_have) | capability | No titled PM years. No wording creates them | If the screen is literal, it can end the application before a person reads the rest | Nothing counts as titled years. Closure paths are a PM-titled role, an internal transfer, or an employer that reads equivalent work (RR5) | None | `[grounded]` your statement; `[generic]` that closure paths are these three |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay, location and level withheld | unknown | — | none: the posting states no salary, location or level | Pay may sit anywhere relative to your floor, and the work may not fit your location needs; the withholding is itself worth a question | `[inferred]` from the JD's silence | What is the salary range, the location or remote policy, and the level this role is hired at? | unresolved |
| RR3 | Partner-facing platform scope is concrete | positive_signal | — | "Own the roadmap for our partner-facing API platform ... drive delivery with two engineering squads" | The scope is defined enough to evaluate | `[grounded]` JD | Which partners and integrations are live today, and what does adoption look like now? | noted |
| RR4 | Reporting line and PM team unstated | unknown | — | "drive delivery with two engineering squads" | The role may be the platform's first PM, or sit under senior product leadership; that matters most for a first PM role | `[inferred]` from the JD's silence | Who does this role report to, and who else does product work on the platform? | unresolved |
| RR5 | How strictly "3+ years" is read | unknown | — | "3+ years product management experience (must-have)" | A literal title screen would end R1b; a hiring manager may read equivalent product work | `[generic]` hiring pattern, not a claim about this employer | Is the 3+ years read as titled PM years, or can equivalent product work count? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the employer and the live posting (careers page, recruiter's email domain) before polishing anything | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Put RR5 to a person (recruiter or hiring manager) before investing in a full application | R1b, RR5 | `[grounded]` RR5; `[generic]` that a human conversation can precede a screen | pending your approval |
| E1 | Proposed lead summary line: "Solutions engineer and implementation lead with seven years at an enterprise-software vendor. Led 30+ client integrations of our REST APIs end to end, from scoping workshops and requirements documents through integration architecture, UAT and go-live. Ran quarterly roadmap-input sessions collecting client feedback for product." Every clause traces to your resume text, with no PM title, owned roadmap or shipped-product claim added | R1a, R4, R5; reframing audit run | `[grounded]` your resume | resume_edits_pending_approval |
| E2 | Proposed cover-note sentence: "I haven't held a product manager title. For seven years I've led client integrations of our REST APIs, written the requirements, and collected client feedback for product through quarterly roadmap-input sessions." It names the title gap before the reader finds it | R1b, R1a | `[grounded]` your statements; `[generic]` that naming a gap first is common advice | pending your approval |
| W1 | Optional work sample: a one-page, sanitized note on a gap you saw across integrations, with a proposed fix and how you'd measure adoption. Only if you can write it from real experience | G4 | `[grounded]` G4 | pending your approval |

Nothing above is applied. E1, E2 and W1 are drafts for your approval, and I'll adjust them to your actual resume text once I have it.

## Evidence status

Verified: none yet. Unverified lead: an earlier-conversation mention of an internal request-triage tool that support agents adopted. It is unconfirmed, unspecified, and used only as the basis for G1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched for Quartzline's careers page and the role; the search was refused. It would have fed RR1 and the contradictions row, and its absence leaves RR1 unresolved |
| 2. Role-family sweep | unavailable | Searched for pay, scope and requirement norms for API platform PM roles; the search was refused. It would have fed the market calibration row and a pay comparison for RR2, and both are empty |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

I can save all of this as a `tuesday-dossier.md` you can keep or hand to later steps. Say the word and I'll write it.

## Upgrade menu

- Your actual resume text, because I worked from your summary and E1 and E2 are drafts until I have it.
- A sanitized playbook excerpt, which would raise R3 to `high`.
- Any artifact for the triage tool (screenshot, adoption figure, spec) → G1 resolves, and R9 and R2 may move.
- A sanitized backlog, scope-change log or build plan → G2 resolves, and R8, R4 and R6 may move.
- Allowing web search → targets 1 and 2 run, which would settle RR1 and add a pay comparison for RR2. After that, a deeper pass (up to 5 more searches and 2 more fetches) is available once, on your say.
- Your pay floor, location needs and authorization status → hard-gate checks run. At the moment they are unknown.
- A hiring manager's name → target 3 and sharper positioning.

## Questions

**G1** — Something earlier suggested you built or ran an internal request-triage tool that support agents adopted. Is that right? If so, what did you personally decide or build, how did you know people used it, and what changed after launch?

**G2** — On your custom builds, did you ever set or push back on scope or priorities with engineers, run a sprint-style cadence or keep a backlog, or decide what got cut? What was theirs and what was yours?

**RR2** — What pay floor, location or remote needs, and work authorization should I check this against? Any of them could turn into a hard gate once the posting states its terms.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.