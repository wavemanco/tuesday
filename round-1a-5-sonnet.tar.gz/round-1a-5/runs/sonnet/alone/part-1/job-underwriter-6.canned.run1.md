I've read the posting and most of the skill's rules. Next I'm reading its evidence vocabulary, then I'll run the budgeted research on Quillfield, the salary band and Tamsin Achebe's public profile.
# Job Underwriting: Revenue Operations Lead, Quillfield

## Decision snapshot

**Yes, Joss, worth going for. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days), R2 (pay £61,500–£67,000)
- `must_have`: direct: R3, R4 · adjacent: R5 (SQL and spreadsheet modelling), R6 (owning a forecast) · unclear: R7 (finance billing or revenue data)

R6: a credible bridge, its limit named; R7: turns on one answer about your renewal data; R5 (`low`): modelling depth not yet confirmed.

**Opportunity ledger.** The mandate is defined and the pay is published (RR4). Open unknowns are team and decision rights (RR1), the share options (RR3) and whether the posting is live on Quillfield's own site (RR5). The four-part mandate is a mild bundling signal (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (pay £61,500–£67,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol hybrid and the pay range clear your own limits (R1, R2); (2) the forecast gap is framed honestly as adjacent, never as ownership (R6, RR1); (3) your answer on billing and revenue data holds up (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about), snippet only |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options (number, strike and vesting not stated) | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` recruiter's name via you; career line from a search-result snippet, profile page not opened |
| First 90 days and first year | Not stated. The first quarterly forecast cycle with the CFO is the most visible early deliverable | `[inferred]` from the mandate's quarterly cadence |
| Scope read | Four duties (CRM, billing data, reporting, forecast) in one post with no team or reports named | `[inferred]` from the posting's silence on staff against its breadth |
| Market calibration | £61,500–£67,000 sits inside the band for this title and sector: median £64,200, interquartile range £57,800–£70,400. That is a pattern, not Quillfield's offer | `[generic]` role-family search, 2026 pay guide, n=438; `[grounded]` posting for Quillfield's own figure |
| Unknowns | Team and reports; who owns the forecast number (you or the CFO); option terms; reporting line, since the hiring manager's title is Head of RevOps | `[grounded]` posting silence |
| Contradictions | None between the posting and the company page. The posting was read on Tallyboard only, and Quillfield's careers page was not reached | `[grounded]` both pages as seen |

## Evidence map

Your background is typed prose, so it counts as self-report: `medium` is the ceiling until something inspectable is shown.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You gave no location or working-pattern constraint, so the gate is not settled either way | `[grounded]` posting; no constraint supplied | G3 |
| R2 | Pay £61,500–£67,000 plus options | hard_gate | unclear | none | hard_gate | You gave no pay floor, so whether the range clears it is not established | `[grounded]` posting; no floor supplied | G3 |
| R3 | 4+ years in RevOps, sales ops or similar analytics at a B2B software company | must_have | direct | medium | none | 5 years in sales operations, the last 2 running RevOps for the UK team. The employer is a "B2B payments company"; whether that reads as B2B software is a judgement for the screener, so expect a probe | `[grounded]` your account; sector match `[inferred]` | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, and you rebuilt the pipeline and renewal dashboards. The certificate is inspectable but unseen, hence `medium` | `[grounded]` your account | Have the certificate ready if asked |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | low | discovery | SQL weekly and Excel daily is confirmed use. "Strong" and "modelling" (building models, not running queries) are not yet shown. Lower band taken | `[grounded]` your account; the depth is unconfirmed | Name one query or workbook you built |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You have never owned the company forecast; finance did. Bridge: you run the monthly pipeline review with your sales director. Limit: no forecast ownership, no CFO-level number, no forecast method of your own | `[grounded]` your account; the bridge is `[inferred]` | G2 |
| R7 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | You have never worked on billing data. Unresolved: whether your renewal dashboards drew on contract or revenue data finance maintained | `[grounded]` your account; source of the renewal data unknown | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Finance billing or revenue data (R7, must_have) | discovery | "Never worked on billing data" is clear. Not clear is what fed your renewal dashboards and whether finance supplied or checked it | The posting says you will "own our CRM and billing data", so this is the largest unknown on the fit side | Renewal dashboards built on contract values or invoiced revenue; reconciling CRM figures against finance's numbers; agreeing definitions (ARR, churn, renewal date) with finance | A dashboard screenshot, a metric-definition note, an email thread with finance | `[grounded]` your statement; `[inferred]` that the renewal dashboards may touch finance data |
| G2 | Owning a forecast (R6, must_have) | transferability | Your pipeline review is real adjacent work; the forecast itself was finance's | It is the posting's headline duty ("run the quarterly revenue forecast with the CFO"). The bridge must carry its limit wherever it is used | A pipeline review whose output finance used as forecast input; a commit or best-case view you maintained; a forecast-accuracy check you ran | A sanitized review pack or pipeline-coverage chart | `[inferred]` bridge from the pipeline review; limit `[grounded]` from your statement |
| G3 | Location and pay limits (R1, R2, hard_gate) | hard_gate | No constraints supplied | A gate nobody has checked can end the process late | Not experience; facts about your situation | None needed | `[grounded]` constraints not given |
| G4 | SQL and spreadsheet modelling depth (R5, must_have) | discovery | Use is confirmed, depth is not | Cheap to close with one example | A model with assumptions and scenarios; a SQL job joining several tables for the renewal dashboards | A sanitized query or workbook | `[grounded]` your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Accountability without stated team or decision rights | unknown | — | "You will own our CRM and billing data ... and run the quarterly revenue forecast with the CFO" | You may be a one-person function, or the forecast number may be the CFO's with you as preparer | `[inferred]` from the posting's silence on team and authority | Who reports to this role, and who signs off the forecast number: the CFO, the Head of RevOps, or this role? | unresolved |
| RR2 | Four duties bundled in one post | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting ..., and run the quarterly revenue forecast" | Admin, data ownership, reporting and forecasting may be folded into one title. Severity kept at `low` because the pay sits inside the band in role reality | `[inferred]` from the mandate; `[generic]` that this bundling is common at 100-person companies | What does the first year look like, and what would you want this role to stop doing by month twelve? | unresolved |
| RR3 | Share options with no terms | unknown | — | "plus share options" | Options could be material or nominal; unknowable from the posting | `[inferred]` from the missing figures | How many options, at what strike, on what vesting schedule? | unresolved |
| RR4 | Pay range published and in the market band | positive_signal | — | "£61,500–£67,000" | Transparent range, near the median of the band in role reality | `[grounded]` posting; `[generic]` band | Is the top of the range open for a candidate who has not owned a forecast? | noted |
| RR5 | Posting seen on a job board only | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role is probably also on Quillfield's own site; not checked | `[inferred]` from the company's existence on its own site against the unchecked careers page | Can you point me to this role on Quillfield's careers page? | unresolved |

## Application plan

Every row is proposed and none is final until you approve it. That covers the framing advice in P1 and E2, not only the wording rows.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with "run the monthly pipeline review with the sales director" and "rebuilt pipeline and renewal dashboards", in your own numbers once confirmed | See R6, R4 | `[grounded]` your account | pending your approval |
| E2 | State plainly that finance owned the company forecast in your current role, and describe your pipeline-review work as input to it, never as forecast ownership | See R6; claiming more would not survive a CFO-level probe | `[grounded]` your statement; the risk of being probed is `[generic]` | pending your approval |
| P1 | For the hiring manager: Tamsin Achebe's earlier sales ops career was at a payments company, close to your own. Lead with the pipeline and renewal story rather than guessing what she wants | See role reality, hiring manager | `[grounded]` snippet; her preferences are not researched | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Check Bristol hybrid and the pay range against your own limits before investing in the loop | See R1, R2 | `[grounded]` gate rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company"; the result "About Quillfield" (quillfield.co.uk/about) matches the posting's company description. It moved role reality's organization row and the contradictions row. The careers page was not reached, hence RR5 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol UK B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). It moved market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). It moved the hiring manager row and P1; only the snippet was read |

## Dossier offer

I can save all of this as a `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Your location and a pay floor → R1 and R2 move from `unclear` to met or failed, which could simplify the decision.
- A sanitized dashboard, query or workbook → R5 and R4 rise toward `high`, and G1 may close.
- Your answers on G1 and G2 → R7 and R6 are re-graded, and E1 and E2 can be finalized.
- The recruiter's answers on reporting line, option terms and the live posting → RR1, RR3 and RR5 close.
- A deeper research pass on Quillfield (funding history, leadership changes, recent news; up to 5 more searches and 2 more fetches) → feeds the risk register. Say the word and it runs.

## Questions

G1 (R7): Did your renewal dashboards or pipeline reporting use billing, invoice or contract-value data, and did finance supply or check it? What did you own?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 (R6): What do you hand finance from the pipeline review, and does it feed their forecast? Who decides the final number?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 (R1, R2): Where are you based, are two office days a week in Bristol workable, and what is your pay floor?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.