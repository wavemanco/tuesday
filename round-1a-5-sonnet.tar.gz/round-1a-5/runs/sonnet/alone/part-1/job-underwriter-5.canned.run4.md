Checking the posting against the company's live careers page, then I'll write the assessment.
## Decision snapshot

**Yes, this is worth applying to, on conditions. You have direct evidence on R3, R4, R5, R6, R8 and R9, and the one real gap is BigQuery (R7). The role's location and pay terms (R1, R2) can't be checked yet because I don't have your constraints. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R8, R9
- `important` — adjacent: R7 (BigQuery warehouse) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R7 — a credible bridge, its limit named; R10, R11 — your background doesn't say either way, recall questions below.

**Opportunity ledger.** Pay and stack are stated and specific (RR2, RR5). Team shape and on-call are unstated (RR1), and so are first-year success measures (RR4) and the equity terms (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your constraints are met by R1 and R2; (2) RR1 and RR4 verify as reasonable in a first conversation; (3) the BigQuery bridge is presented as adjacent, never as BigQuery experience (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026). The funding figure comes from the company's own page only. | `[grounded]` company About page, as returned by search |
| Mandate | Build and run pipelines for platform reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` live careers page |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` live careers page |
| Scope read | The posting covers ingestion, modelling and contracts, which is a multi-stage remit. It names no team, reports or hiring manager, so I can't tell a sole data engineer from one of several. | `[inferred]` from the posting's stage count against its silence on team |
| Market calibration | Posting range sits at $3,000 below the report's base median ($151,000) at the bottom and $2,500 above its 75th percentile ($163,500) at the top. Report: n=2,310, Senior Data Engineer at Series B–D, 2026. "Senior" is typically 5–8 years with one domain's pipelines and no direct reports. Equity is on top, unquantified. | `[grounded]` pay report you supplied, for the figures; `[inferred]` for the comparison |
| Unknowns | Team size, reporting line, on-call, success measures, equity terms, whether "salary" means base | — |
| Contradictions | None. The pasted JD and the live careers page match. | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or your work-authorization status, so the term can't be checked. | `[grounded]` posting terms; no candidate statement given | Q1 |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so the range can't be checked against one. | `[grounded]` posting figure; no candidate statement given | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company. Self-report, nothing inspected yet. The report's "Senior" band is 5–8 years. | `[grounded]` your statement; `[generic]` report norm | Offer: CV or LinkedIn dates would raise to high |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You stated daily use. No artifact seen. | `[grounded]` your statement | Offer: a sanitized query or repo sample |
| R5 | dbt | must_have | direct | medium | none | You stated you built the dbt project, about 180 models, on Snowflake. The posting says "dbt" without naming a warehouse. | `[grounded]` your statement | Offer: a project docs or lineage screenshot, sanitized |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. This row is the generic requirement, and BigQuery is separate in R7. | `[grounded]` your statement | none |
| R7 | BigQuery-based warehouse (named in the responsibilities, not the requirements list) | important | adjacent | medium | transferability | Credible adjacency: a 180-model dbt project on another cloud warehouse. Limit: you've never used BigQuery. Its cost and partitioning model differs from Snowflake's. | `[grounded]` your statement; `[generic]` BigQuery differences | See G1 |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | You stated Airflow was your orchestrator. The posting names Airflow, so it's an exact tool match. | `[grounded]` your statement | none |
| R9 | Data quality testing | must_have | direct | medium | none | You stated you set up the Great Expectations suite. That is ownership, not just use. | `[grounded]` your statement | Offer: suite structure or coverage summary, sanitized |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Your sources at the payroll company aren't stated, so there's neither a match nor a miss. | `[grounded]` your background is silent on sources | Q2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | You may have set schema or freshness expectations with consumers, but nothing stated says so. | `[grounded]` your background is silent | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | Strong dbt and warehouse work on Snowflake, with no BigQuery use. | The posting names BigQuery in its first line of responsibilities, so it will likely come up as a question. | A personal or side project loading data into BigQuery with dbt; BigQuery work in a prior role you haven't mentioned | A small public repo or write-up, or any prior BigQuery exposure | `[grounded]` your statement; `[inferred]` it will be probed because the posting names it |
| G2 | Ingestion sources (R10, important) | discovery | Pipelines are described, their sources aren't. | A match on app or CRM sources would move R10 to direct. | Ingesting from a product database, an event stream, a CRM or HRIS API, or SaaS exports | An architecture diagram or DAG list, sanitized | `[grounded]` your background is silent |
| G3 | Data contracts (R11, important) | discovery | Testing is evidenced, and formal agreements with analysts are not. | The posting names contracts as a core deliverable. | Schema-change processes, freshness SLAs, documented model owners, tests tied to a stakeholder agreement | A schema-change policy or SLA doc, sanitized | `[grounded]` your background is silent; `[inferred]` the Great Expectations suite may be related |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team shape, reporting line and on-call unstated | unknown | — | "Build and run the pipelines" | The role may be the sole data engineer, with on-call for the pipelines it runs. | `[inferred]` from "build and run" against the posting's silence on team | How many data engineers are on the team, who does this role report to, and what is the on-call expectation? | unresolved |
| RR2 | Pay disclosed and inside the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The posting is transparent, and the range straddles the report's base median with no seniority-pay mismatch. | `[grounded]` posting and the pay report you supplied | Is the stated salary base pay, and where in the range would this role land? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The equity may be options with a long vesting schedule, or may be small. | `[inferred]` from "plus equity" with no terms | What type of equity is this, what grant size is typical, and what is the vesting schedule? | unresolved |
| RR4 | No first-year outcomes stated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The mandate may be defined by ongoing operation, with no named milestones. | `[inferred]` from the posting's silence on outcomes | What would a successful first year look like, and which pipelines or contracts need to exist by then? | unresolved |
| RR5 | Specific, coherent stack and responsibilities, matching the live careers page | positive_signal | — | "a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role is concretely scoped around named tools and a real consumer, the analysts. | `[grounded]` posting, careers page fetched | Which data contracts exist today, and who enforces them? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your summary with the 6 years, the ~180-model dbt project on Snowflake, Airflow and the Great Expectations suite you set up. These are the exact tools in the posting's requirements. | R3, R5, R8, R9 | `[grounded]` your statements | pending your approval |
| E2 | State BigQuery as a bridge: "dbt on Snowflake; BigQuery not yet used." Don't write it as BigQuery experience. | R7 | `[grounded]` your statement | pending your approval |
| W1 | A small public dbt-on-BigQuery project would narrow the R7 limit. It's optional. | G1 | `[inferred]` from the posting naming BigQuery | pending your approval |
| Q1 | Ask RR1, RR3 and RR4's questions in your first conversation. | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Interview rehearsal is mock-interview's job, if you decide to apply and want it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): live, "Accepting applications", text identical to what you pasted. Searched "Pellucid Learning Series C tutoring K-12 Denver", which returned "About Pellucid Learning" (pellucidlearning.com/about) matching the company description you pasted. This moved role reality's organization and contradictions rows. Funding is not corroborated outside the company's own site. |
| 2. Role-family sweep | skipped | The pay report you pasted fixes the market calibration and the pay-mismatch check, so a search couldn't have moved either. |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form. |

## Upgrade menu

- Your base location, work authorization and pay floor → R1 and R2 resolve, and the decision becomes `go` or `no_go`.
- A CV, or dates for the payroll company role → R3 to `high`. A sanitized dbt lineage or docs screenshot, a Great Expectations suite summary or a DAG list would raise R5, R8 and R9.
- Answers to the R10 and R11 recall questions → both rows resolve to `direct` or stay open, and the application plan's lead story tightens.
- A hiring manager's name or recruiter details on team size → RR1 and the scope read firm up.
- A deeper research pass on Pellucid Learning (funding and leadership churn, hiring patterns, candidate and employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

I can write all of this up as `tuesday-dossier.md` if you want a file to keep or send to your recruiter. Just say so.

Q1 (R1, R2) — Do this role's terms (US remote or Denver, $148,000–$166,000 plus equity) work for your constraints, and if not, which one doesn't?
Q2 (R10) — Which upstream sources fed your pipelines at the payroll company, and did any come from a product database or a CRM?
Q3 (R11) — Did you set formal expectations, such as schema, freshness or ownership, with the analysts who consumed your models, and what happened when a model broke them?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.