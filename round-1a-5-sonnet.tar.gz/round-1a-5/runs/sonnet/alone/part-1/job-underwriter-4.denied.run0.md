I've read the skill's rules. Next I'm loading the search tool so I can check whether Brindlemoor and the posting can be verified, then I'll write the assessment.
**Yes, apply.** R1 isn't confirmed yet and the employer isn't established (RR1), but R2, R3, R4, R5, R6, R7a and R8 all land `direct`. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5, R6, R7a, R8
- `important`: unclear: R7b (Recommendations to product)
- `preferred`: direct: R9; adjacent: R10 (Pet-insurance product knowledge)

R10 is a credible bridge with its limit named. R7b has nothing yet on product audiences. R1 is a gate nobody has confirmed.

**Opportunity ledger.** The posting is thin on checkable detail rather than bad. The employer isn't established (RR1), pay is unstated (RR2), and decision rights and reporting lines are unspecified (RR3). One entry runs the other way: the duties are named concretely (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The employer and the live posting are verified (RR1).
  2. Your location and non-negotiables are checked against R1 and RR2.
  3. The pet-insurance bridge is framed as adjacent (R10), never as pet-insurance experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product. Its existence and the live posting are not established (RR1) | `[grounded]` JD header, as you pasted it |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | An individual-contributor analytics post with influence over underwriting and product; the JD names no reports or budget | `[inferred]` from "own pricing analytics" and the JD's silence on a team |
| Line management | The JD doesn't mention it, so your having never managed anyone doesn't fail any stated requirement. Whether the post carries reports is open (RR3) | `[grounded]` JD silence plus your statement |
| First-year outcomes | Not stated. The JD gives recurring duties, not deliverables | `[grounded]` JD |
| Compensation | No figure in the JD. No market band is given, because the role-family sweep could not run | `[grounded]` JD silence |
| Market calibration | Not established, for the same reason | — |
| Unknowns | Salary; pricing team size and data stack; which decisions the role makes versus recommends; whether the post has reports | — |
| Contradictions | None between the JD and what you told me; the company's own pages were not checked | `[grounded]` provided inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | You said nothing on location or right to work. A UK motor insurer suggests UK-based, but that is a guess | `[inferred]` from your employer being UK-based | Question 1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer clears the stated length. It is intake prose with no artifact, so `medium` | `[grounded]` your prose | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is stated. "Strong" is your own grading, with nothing inspectable | `[grounded]` your prose | A sanitized notebook or script would raise it to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. It is motor, not pet, which R10 carries | `[grounded]` your prose | A sanitized model spec or factor summary would raise it to high |
| R5 | Build and monitor rating models | must_have | direct | medium | none | Building is stated. "Maintained" is the only evidence on monitoring, and I take the lower reading | `[grounded]` your prose | Add monitoring wording to the CV only once you confirm which checks you ran |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with underwriting. "Ran" doesn't say how much of the design was yours, and the application plan keeps your verb | `[grounded]` your prose | A test summary or readout would raise it to high |
| R7a | Turn results into recommendations for underwriting | must_have | direct | medium | none | You worked the tests with the underwriting team and present the quarterly pricing review to the head of underwriting | `[grounded]` your prose | none |
| R7b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing in your background mentions product audiences | `[grounded]` your prose is silent | Question 2 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting. Presenting to actuarial leads is not stated | `[grounded]` your prose | A review deck, sanitized, would raise it to high |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your prose | none |
| R10 | Pet-insurance product knowledge (not asked for; the JD scopes the role to the pet product) | preferred | adjacent | medium | transferability | Carries over: GLM build, price tests, presenting to underwriting. Limit: no exposure to pet rating factors or pet claims data. Pet cover usually behaves differently from motor on cost trends and policy structure | `[inferred]` bridge from your motor work; `[generic]` that pet and motor differ in rating factors and claims patterns | Question 3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and constraints (R1, hard_gate) | hard_gate | Nothing on where you are based, right to work, pay floor or other non-negotiables | The gate can't be marked met, and the pay floor can't be tested against a salary the JD withholds | UK residence, right to work, a minimum salary, any limits on remote working | Your own statement is enough | `[grounded]` your message is silent; `[inferred]` that the pay floor matters because the JD gives no figure |
| G2 | Recommendations to product (R7b, important) | discovery | Underwriting audiences are covered. Product audiences are not | It is half of one stated duty, and the answer changes how you describe the work | Findings that changed a product feature, a cover tier, an excess or a renewal rule; a pricing paper for a product owner; a test readout that went to a product or proposition team | A readout or paper, sanitized | `[grounded]` your prose is silent |
| G3 | Pet-insurance knowledge (R10, preferred) | transferability | Motor pricing only | The posting is for a pet product, and an interviewer may test the limit | Work on a non-motor line; analysis involving animals, vet costs or health claims; any pet-related data project | A project note or a short write-up | `[grounded]` your prose; `[generic]` that interviews for a product-specific role probe the distance from adjacent work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. These possibilities sit side by side. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | The pasted JD contains no figure | The pay may sit below what the seniority and scope normally command, or the company may not publish pay in postings. I can't give a band without the search | `[inferred]` from the JD's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Authority and reporting scope unspecified | unknown | — | "Own pricing analytics for our pet-insurance product" | The post may own the analysis while decisions sit with underwriting, and may or may not carry reports | `[inferred]` from the JD's scope language against its silence on decision rights and team | Which pricing decisions does this role make itself, which does it recommend, and does it have any direct reports? | unresolved |
| RR4 | Duties named concretely | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The work is defined in specific, checkable activities | `[grounded]` JD | What would the first price test or model review be? | noted |

## Application plan

Every row below is proposed. Nothing is final until you approve it.

**Proposed CV lines**, `resume_edits_pending_approval`. Each line uses your own sentence from this conversation as its baseline. I haven't seen your current CV, so these are for you to compare against it.

| # | Proposed line | Traces to your words |
|---|---|---|
| E1 | Built and maintained the GLM rating model for the young-driver motor book | "Built and maintained the GLM rating model for our young-driver book" |
| E2 | Ran 14 price tests with the underwriting team last year | "Ran 14 price tests last year with the underwriting team" |
| E3 | Present the quarterly pricing review to the head of underwriting | "I present the quarterly pricing review to the head of underwriting" |
| E4 | SQL and Python daily | "SQL and Python daily" |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Order the CV so E1, E2 and E3 come first | They match the first three duties in the JD | `[grounded]` JD | pending your approval |
| A2 | Say plainly that your pricing work has been motor, not pet, and that the GLM build, the price tests and the underwriting presentations are what you bring | Frames R10 as adjacent with its limit named | `[grounded]` your prose | pending your approval |
| A3 | Don't claim pet-insurance experience, people management, or an actuarial audience | None is in your evidence (R10, RR3, R8) | `[grounded]` your prose | pending your approval |
| A4 | Ask RR1, RR2 and RR3 verbatim before investing in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst" were refused, so nothing came back. Role reality's organization and contradictions rows and RR1 stay open |
| 2. Role-family sweep | unavailable | One search on UK senior pricing analyst pay was refused. It would have fed the market calibration row and RR2 |
| 3. Hiring manager's public footprint | unavailable | One search on Odile Varga's public professional footprint was refused. It would have fed the scope read and which story the plan leads with |

## Dossier offer

If you'd like a saved copy of this assessment, I can write it as `tuesday-dossier.md`.

## Upgrade menu

- Your constraints (location, right to work, pay floor) → R1 resolves and RR2 can be tested against your floor.
- Permission to run web search (up to 5 searches and 2 fetches) → RR1, the market band for RR2, and the scope read for Odile Varga.
- A link to the live posting or Brindlemoor's careers page → RR1 can close.
- Your CV file → E1 to E4 are checked against your actual wording, and any `presentation` gaps surface.
- A sanitized notebook, model spec, test readout or review deck → R3, R4, R6 and R8 rise to `high`.
- Your stage (I assumed you're evaluating) → the plan shifts if you've already applied or have a call booked.

## Questions

1. **G1:** What are your non-negotiables for this move — are you UK-based with the right to work there, and is there a minimum salary or other limit I should test the role against?
2. **G2:** Have you ever taken test or model results to a product, proposition or marketing team, as opposed to underwriting? What did you own, and did anything change as a result?
3. **G3:** Have you worked on any line other than motor, or on any data involving animals, vet costs or health claims, even briefly?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.