I'll read the reference files the skill points to before building the assessment.
# Job Underwriting — Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Yes, go for it, but first settle whether the role is remote. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R10 (Fully remote (UK))
- `must_have` — direct: R1, R2, R3, R4a, R5, R6a, R7 · adjacent: R4b (monitor rating models)
- `important` — unclear: R6b (recommendations to product)
- `preferred` — direct: R8 · adjacent: R9 (pet-insurance product knowledge)

R10 — the posting and the careers page disagree; R4b (`medium`) — "maintained" is confirmed, "monitored" is not; R9 — a credible bridge from motor, its limit named.

**Opportunity ledger.** The mandate is clear and reports to a named Director (RR3). The posting and the careers page conflict on working pattern (RR1), no salary is stated (RR2), decision rights over pricing changes are unstated (RR5), and nothing beyond the employer's own page shows its stage or size (RR4).

- **Hard gates:** none failed; unconfirmed: R10 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is settled and acceptable to you (R10, RR1); (2) the salary clears your floor, which you haven't told me (RR2); (3) the pet bridge is framed as adjacent and never as pet-insurance experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. The role is live on brindlemoor.co.uk. Stage, size and funding are not established | `[grounded]` JD header and fetched careers page |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing, Odile Varga | `[grounded]` careers page and JD |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` JD against fetched careers page |
| Line management | The JD states no line-management requirement. Your having never managed anyone touches no requirement row | `[grounded]` JD |
| Scope read | A single-product, individual-contributor senior post | `[inferred]` from "own pricing analytics for our pet-insurance product" and the absence of any team-leadership language |
| Market calibration | UK insurer and insurtech senior pricing analysts: median base £58,400, interquartile range £52,100–£64,900 (n=612, 2026). Read from a search snippet, page not fetched. Not this employer's offer (RR2) | `[generic]` role-family sweep, one salary search; `[grounded]` JD, for the missing figure |
| Hiring manager | Director of Pricing. Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. Previously head of pricing analytics at Calloway Re for six years | `[grounded]` public professional profile, search snippet only |
| Unknowns | Salary; team size; decision rights; first-year outcomes; contract basis | — |
| Contradictions | Working pattern, as above | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer. Confirmed and specific, but nothing inspectable yet | `[grounded]` your intake message | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is confirmed. Nothing inspectable, so expect a probe on depth | `[grounded]` your intake message | offer: a sanitized query or notebook would raise to `high` |
| R3 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, no artifact yet | `[grounded]` your intake message | offer: a sanitized model summary or documentation page would raise to `high` |
| R4a | Build rating models | must_have | direct | medium | none | Same evidence as R3: built the young-driver GLM | `[grounded]` your intake message | none |
| R4b | Monitor rating models | must_have | adjacent | medium | discovery | You said "maintained", which is not the same as monitored. How the model was tracked after launch is unstated, so I have not claimed it | `[grounded]` your wording; `[inferred]` that maintenance may have included monitoring | G2 |
| R5 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with underwriting. Confirmed. Which parts were yours (design, readout) is not stated, so the CV should say "ran", not more | `[grounded]` your intake message | none |
| R6a | Recommendations to underwriting | must_have | direct | medium | none | You ran tests with the underwriting team and present the quarterly pricing review to the head of underwriting | `[grounded]` your intake message | none |
| R6b | Recommendations to product | important | unclear | low | discovery | Nothing in your background mentions a product or proposition team | `[grounded]` silence in your background | G3 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Actuarial audiences are not mentioned | `[grounded]` your intake message | none |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your intake message | none |
| R9 | Pet-insurance product knowledge | preferred | adjacent | low | transferability | The JD requires no pet experience. This row is inferred from the mandate. Your GLM work on motor is a credible bridge. Limit: you have not worked on a pet book, and pet and motor books use different rating factors | `[inferred]` from "our pet-insurance product"; `[generic]` on rating-factor differences | G4 |
| R10 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD says remote, but the careers page says Leeds four days a week. You have not stated a location or working-pattern constraint, so there is no claim to grade | `[grounded]` JD against fetched careers page; your constraints not given | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R10, hard_gate) | hard_gate | The JD and the careers page disagree and your constraint is unstated | If remote is a must for you, this could turn the status to `no_go` | — (a term you meet or don't) | The employer's written confirmation of the pattern | `[grounded]` both sources; `[inferred]` that a remote requirement would fail the gate |
| G2 | Monitoring rating models (R4b, must_have) | discovery | "Maintained" is confirmed, but the CV does not show tracking after launch | A must-have, and the hiring manager has spoken publicly about monitoring in small books, so expect a probe | A recurring actual-versus-expected report; drift or loss-ratio alerts; a refit trigger; a monitoring pack presented to underwriting | A sanitized monitoring report, dashboard screenshot or documentation page | `[grounded]` your wording and her published talk; `[inferred]` that the probe is likely |
| G3 | Recommendations to product (R6b, important) | discovery | Underwriting is covered. A product or proposition audience is not | The JD names both audiences | A test result that changed a product feature, a bundle or a cover level; a readout to a product owner | A readout deck or memo | `[grounded]` the JD and silence in your background |
| G4 | Pet-insurance knowledge (R9, preferred) | transferability | A motor GLM is a real bridge. No pet exposure | Preferred only, but it is the most visible difference from the usual candidate | Rating-factor work with a similar structure, such as age or tenure effects | Not needed. The bridge is framed honestly in the plan | `[inferred]` bridge from your motor GLM; `[generic]` that pet and motor factors differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern conflict (R10) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The two texts may come from different versions of the role, or the terms may have changed | `[inferred]` from two grounded quotes that disagree | Is this role fully remote, or office-based in Leeds four days a week? | unresolved |
| RR2 | No salary stated | unknown | — | The posting gives no figure | The pay may sit anywhere against the market band, which is `[generic]` and not this employer's offer | `[grounded]` JD silent; `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Named senior reporting line | positive_signal | — | "reports to the Director of Pricing" | A named accountable owner suggests the post has a clear home | `[inferred]` from the careers page | What would you want this role to have delivered by the end of its first year? | noted |
| RR4 | Employer footprint beyond its own page | unknown | — | "Brindlemoor (insurtech)" | A search for the company returned nothing. Small or young firms often have thin independent footprints | `[generic]` pattern, not a claim about this employer | How large is the pricing team, and what stage is the company at? | unresolved |
| RR5 | Decision rights unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role recommends and others may decide. Authority and resources are not described | `[inferred]` from the JD's wording against its silence on decision rights | Which pricing changes does this role decide, and which go to underwriting or product? | unresolved |

## Application plan

Every row and the positioning notes below are proposed. They are `resume_edits_pending_approval` and pending your approval, and nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter or hiring manager before investing in the loop | see R10, RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead the CV and application with your four strongest rows: the GLM build (R3, R4a), the 14 price tests (R5), and the quarterly review to underwriting (R6a, R7) | They are the `direct` must-haves | `[grounded]` map rows | pending your approval |
| P2 | Prepare concrete specifics on how the young-driver model was tracked after launch. Say only what is true, and say "maintained" until you confirm more | see R4b. Her published talk is on monitoring, so a probe is likely | `[inferred]` from the talk title against R4b | pending your approval |
| P3 | Frame pet as a bridge: motor GLM experience, no pet-book experience | see R9 | `[grounded]` R9 | pending your approval |
| Q1 | Ask RR1 to RR5's questions in the loop, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| E1 | CV line: "Built and maintained the GLM rating model for the young-driver book" | Traces to your sentence | `[grounded]` your intake message | pending your approval |
| E2 | CV line: "Ran 14 price tests last year with the underwriting team" | Traces to your sentence | `[grounded]` your intake message | pending your approval |
| E3 | CV line: "Present the quarterly pricing review to the head of underwriting" | Traces to your sentence | `[grounded]` your intake message | pending your approval |
| E4 | Title line: "Senior pricing analyst (last 2 of 5 years in pricing analytics), UK motor insurer" | Traces to your sentence | `[grounded]` your intake message | pending your approval |

I added no monitoring, product, pet or management claims to E1–E4.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the role is live, and it moved role reality's contradictions row, R10, RR1 and RR4 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet only. It moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read as a snippet only. It moved the hiring-manager row, G2 and P2 |

I'll gather everything above into `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Your stance on remote versus Leeds, and your pay floor → R10 and RR2 can be checked against your constraints, and the status moves to `go` or `no_go`.
- A sanitized monitoring report or dashboard screenshot → R4b resolves, and R3 can reach `high`.
- A sanitized SQL or Python sample → R2 to `high`.
- A product-facing readout or memo → R6b resolves.
- The recruiter's answers on pay, team size and decision rights → RR2, RR4 and RR5 close.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

Q1 (R10) — Is working from a Leeds office four days a week acceptable to you, or is fully remote a requirement?

Q2 (R4b) — After the young-driver GLM went live, how did you track how it was performing, and what did you do when it drifted?

Q3 (R6b) — Have results from your price tests ever gone to a product or proposition team, and not only to underwriting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.