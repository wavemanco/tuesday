I'm checking the live Brindlemoor careers page. The search snippet says "Leeds office four days a week", but the JD you pasted says fully remote. I'll fetch the page to confirm.
# Job Underwriting Assessment — Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Yes, worth applying to. You meet R2, R3, R4, R5, R7 and R8 directly, and R1 (the working pattern) has to be resolved first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote UK working pattern)
- `must_have` — direct: R2, R3, R4, R5, R7, R8 · unclear: R6 (Monitoring rating models)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain)

R6 — monitoring not yet evidenced; R10 — a credible domain bridge, its limit named; R1 — the pasted JD and the live careers page disagree.

On your two worries: pet experience is R10, a `preferred` row at `adjacent`. The JD states no line-management requirement, so the map has no row for it. RR5 asks the question.

**Opportunity ledger.** The posting is live and names its reporting line (RR4). The working pattern conflicts between the two sources (RR1) and the salary is withheld (RR2). Decision rights, team shape and employer size are unstated (RR3, RR5, RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Remote UK working pattern); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed as one you can accept — R1, RR1; (2) the salary range is acceptable — RR2; (3) the pet-insurance bridge is framed as adjacent, never as pet expertise — R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech, with a pet-insurance product; the role reports to the Director of Pricing | `[grounded]` JD and the careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. A public profile lists a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books, and six earlier years as head of pricing analytics at Calloway Re | `[grounded]` search-result profile page, snippet read |
| Working pattern | The JD says "Fully remote (UK)". The live careers page says "Leeds office four days a week" | `[grounded]` JD against careers page; see RR1 |
| First-year outcomes | Not stated in the JD or on the careers page | `[grounded]` both silent |
| Scope read | One product's pricing analytics under a Director, a normal-sized remit for a senior analyst. Whether anyone reports to the role is unstated | `[inferred]` from the one-product mandate and the stated reporting line |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900, n=612. This is a band for the role family, never Brindlemoor's offer, since the posting withholds pay (RR2) | `[generic]` 2026 pay survey, one search, snippet read; `[grounded]` JD silent on pay |
| Unknowns | Salary; office versus remote; team size and any reports; decision rights over price changes; company size, funding and regulatory status | — |
| Contradictions | JD says fully remote and the careers page says office four days a week; the other terms agree | `[grounded]` JD against page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) working pattern | hard_gate | unclear | none | hard_gate | You have not stated a working-pattern constraint, so there is no claim to grade. The role's terms are unsettled because the JD and the careers page disagree | `[grounded]` JD against careers page; candidate constraints not given | Ask R1 below; ask Odile or the recruiter which is current |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years in pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific and plausible; CV-equivalent prose, nothing inspected yet | `[grounded]` your stated background | Share the CV to cross-check dates |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You say "daily" use. That establishes frequency, not depth | `[grounded]` your stated background | A sanitised notebook or query sample would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your stated background | A sanitised model-documentation extract would raise to `high` |
| R5 | Build rating models | must_have | direct | medium | none | Same evidence as R4: the young-driver GLM was built by you | `[grounded]` your stated background | As R4 |
| R6 | Monitor rating models | must_have | unclear | low | discovery | "Maintained" suggests ongoing model upkeep, but you have not described monitoring work such as actual-versus-expected checks or drift. A thread exists, so `low` rather than `none` | `[inferred]` from "maintained" in your background | G1 |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team; the period is as you stated it | `[grounded]` your stated background | A sanitised test readout would raise to `high` |
| R8 | Present recommendations to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD also names product as an audience, and you have not mentioned product | `[grounded]` your stated background; `[grounded]` JD names product | A sanitised review deck would raise to `high`; mention any product-team work |
| R9 | Insurance experience, a plus | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your stated background | none |
| R10 | Pet-insurance domain knowledge, implied by the product | preferred | adjacent | medium | transferability | Adjacent evidence: rating-model and price-test work on an insurance book. Limit: you have not worked on pet. Pet differs from motor in its rating factors and claims drivers, so expect the question. The JD never lists pet experience, so this row is inferred from the product named | `[inferred]` requirement from the product named; `[generic]` that pet and motor differ in rating factors | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R6, must_have) | discovery | Model upkeep is implied, and no monitoring work is described | The JD says "build and monitor", and the hiring manager's published talk is on monitoring rating models | Actual-versus-expected reviews; drift or segment checks; a trigger that led to a refit; a dashboard others used | A sanitised monitoring pack or dashboard screenshot | `[inferred]` from "maintained"; `[grounded]` JD wording and the talk title |
| G2 | Pet-insurance domain (R10, preferred) | transferability | Motor pricing carries over as method; no pet-specific exposure | A `preferred` row at `adjacent`; a stated limit reads stronger in interview than a stretched claim | Any work on thin or low-volume segments; time spent with a vet-fee or claims dataset; reading pet-market rating factors | A short written comparison of your young-driver factors against pet rating factors, labelled as study | `[inferred]` bridge from your motor work; `[generic]` that factors differ by line |
| G3 | Remote UK working pattern (R1, hard_gate) | hard_gate | The sources disagree and your requirement is unknown | A term you meet or do not; wording cannot change it | Not applicable | Written confirmation from the employer of the current working pattern | `[grounded]` JD against careers page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between sources (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The pasted copy may predate a policy change, or the page may be out of date. Medium rather than high because this is a contradiction between sources, not a demand | `[inferred]` from two sources disagreeing; `[generic]` that postings are sometimes updated on one channel only | Is this role fully remote, or based at the Leeds office four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | JD gives no figure | The figure may sit anywhere in the role-family band or outside it. Your floor is not given, so no comparison is possible yet | `[generic]` band from the pay survey; `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RR3 | Decision rights over price changes unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend while others decide; that suits many analyst roles but changes what "own" means | `[inferred]` from "recommendations" against the silence on decision rights | Who decides on a price change, and what does this role sign off alone? | unresolved |
| RR4 | Named hiring manager and clear reporting line | positive_signal | — | "reports to the Director of Pricing" | The role has a defined place and a senior pricing owner as manager | `[grounded]` careers page | What does success look like in the first year? | noted |
| RR5 | Team size and any direct reports unstated | unknown | — | "Own pricing analytics" | The JD names no reports and no line-management duty, so the post may be an individual-contributor role | `[inferred]` from the JD's silence | Does this role have direct reports now, or is that planned? | unresolved |
| RR6 | Employer size, funding and regulatory status not established | unknown | — | "Brindlemoor (insurtech)" | One search for the company and its pet-insurance product returned nothing, though the careers page exists. The company may be new, small or lightly published | `[generic]` pattern for companies of this kind, not a claim about this one | What is the company's stage and size, and is it the risk carrier or a distributor? | unresolved |

## Application plan

Nothing here is final until you approve it, and that covers the advice as well as the CV wording. The wording below uses only claims you stated.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter or Odile before investing in the loop | R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV with: "Built and maintained the GLM rating model for the young-driver book at a UK motor insurer" | R4, R5 | `[grounded]` your stated background | pending your approval |
| E2 | Add: "Ran 14 price tests with the underwriting team" — confirm the period before it goes in | R7 | `[grounded]` your stated background | pending your approval |
| E3 | Add: "Present the quarterly pricing review to the head of underwriting" | R8 | `[grounded]` your stated background | pending your approval |
| P1 | Be ready to discuss how you have monitored a model's performance, using only true examples; if you have none, say so and describe how you would start. Her published talk topic is model monitoring in small books | R6, G1 | `[grounded]` talk title; `[inferred]` relevance | pending your approval |
| B1 | Frame pet as a domain you are learning, and say what carries over (rating and testing method) and what does not (pet-specific factors) | R10, G2 | `[inferred]` bridge from your motor work | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance" (no results) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Confirmed the posting is live, the product and reporting line; surfaced the working-pattern contradiction (R1, RR1). Company size and stage not established (RR6) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved the market calibration and RR2; the snippet only was read |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned the profile "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Moved role reality's hiring-manager row and P1; snippet only |

I can save all of this as `tuesday-dossier.md` if you want a record to carry forward.

## Upgrade menu

- **Your CV:** only your prose summary was available, so the dates and any experience the CV leaves out are unchecked (R2, R6, R8).
- **Inspectable artifacts:** a sanitised notebook or query sample (R3), model documentation (R4, R5), a test readout (R7) and a pricing-review deck (R8) each raise their row from `medium` to `high`. A sanitised monitoring pack would move R6 off `unclear`.
- **Your working-pattern requirement and salary floor:** R1 would resolve and RR2 could be set against the band.
- **The employer's answers on RR1, RR2, RR3, RR5 and RR6:** the decision would simplify to `go` or `no_go`.
- **A deeper research pass on Brindlemoor** (funding, leadership changes, public reports; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

- **R1** — Is fully remote a requirement for you, or could you work from the Leeds office four days a week?
- **G1** — Have you monitored a live rating model's performance, and if so, what did you personally do when it drifted?
- **RR2** — What is the minimum salary you would accept?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.