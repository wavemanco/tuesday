I've read the skill's rules. Now I'm running two research searches, one on the company and one on pay for this role family, before I write the assessment.
## Decision snapshot

**No, this isn't worth pursuing as posted. R1 and R2, both hard gates, fail on the posting's own terms. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in Austin five days a week), R2 (Base pay of at least $150k)
- `must_have` — direct: R4, R5 · adjacent: R3 (8+ years growth leadership)
- `important` — unclear: R6 (SEO and content), R7 (Brand, PR, partnerships), R8 (Sales ops), R9 (Operating as a team of one)

R1 and R2 — the posting's terms conflict with your two constraints; R4 and R5 — your background matches; R3 — 9 years in growth, leadership share not stated.

**Opportunity ledger.** Your instinct has rows behind it. The mandate is bundled and unresourced (RR3), the hours are always-on (RR4), and success is undefined (RR5). Pay and location both conflict with your constraints (RR1, RR2). One entry runs the other way: the terms are stated plainly (RR6). The employer is not yet verified (RR7).

- **Hard gates:** failed: R1 (On-site in Austin five days a week), R2 (Base pay of at least $150k)
- **Severe red flags:** none found.
- **What would change this:** the status moves only if the posting's terms differ. That means a remote-eligible role and a base of at least $150k, or you revise a stated constraint. Better wording on your side can't fix a gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one", Austin office | `[grounded]` JD, the employer's own description, not checked here |
| Mandate | Own revenue growth end to end across paid, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` JD |
| Team and reporting | Team of one to start; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site five days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus equity of unstated size and terms | `[grounded]` JD |
| Pay against your floor | The top of the range is $65k below your $150k floor | `[grounded]` JD figure and your stated floor |
| Scope read | Seven channels with no team looks like several roles under one title | `[inferred]` from the channel list against "team of one" |
| Market calibration | Not calibrated: the role-family sweep did not run, so no market band is offered | — |
| Unknowns | Budget, equity terms, success targets, whether any exception to on-site exists | — |
| Contradictions | None found within the posting; not compared against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Your remote-only limit and Portland base are specific and your own, so confidence grades your statement. The fit fails because the JD allows no exceptions. | `[grounded]` JD quote and your stated constraint | Surface only; the employer or you would have to change terms |
| R2 | Base pay of at least $150k (your floor) | hard_gate | hard_gate_fail | high | hard_gate | The JD's $70–85k range sits below your floor at its top end. Confidence grades your stated floor. | `[grounded]` JD figure and your stated floor | Surface only; the employer or you would have to change terms |
| R3 | 8+ years growth leadership | must_have | adjacent | medium | discovery | You gave 9 years in growth, including growth lead and then Head of Growth roles. The split between leadership and individual-contributor years isn't stated. Prose-only, so `medium`. | `[grounded]` your account, no artifact seen | See G1 |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid with a budget you controlled, inside the $8M to $40M ARR scale-up. Confirmed in your words, nothing inspected yet. | `[grounded]` your account | An artifact such as a channel P&L would raise it to `high` |
| R5 | Lifecycle and CRM | must_have | direct | medium | none | You owned lifecycle and are deep in Braze. Confirmed in your words, nothing inspected yet. | `[grounded]` your account | A program overview or results deck would raise it to `high` |
| R6 | SEO and content | important | unclear | none | discovery | Nothing you gave covers SEO or content. | `[grounded]` silence in your account | See G2 |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | Nothing you gave covers these. | `[grounded]` silence in your account | See G2 |
| R8 | Sales ops | important | unclear | none | discovery | Nothing you gave covers sales ops. | `[grounded]` silence in your account | See G2 |
| R9 | Operating as a team of one | important | unclear | none | discovery | You managed teams of 3–7; solo operation isn't stated either way. | `[grounded]` your account | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leadership years (R3, must_have) | discovery | 9 years in growth, but not how many were spent leading | The screen is "8+ years growth leadership", so the split is what a reader would check | Years as growth lead or Head, including time as a player-coach | Role titles with dates | `[grounded]` your account; `[inferred]` that the split is what gets checked |
| G2 | SEO/content, brand/PR/partnerships, sales ops (R6, R7, R8, important) | discovery | No evidence either way | Moot unless R1 and R2 move; if they did, these would be the thin spots against a seven-channel mandate | Owning organic or content programs, co-marketing deals, or CRM-to-sales handoffs | Program briefs, a partnership agreement, a funnel report | `[grounded]` silence in your account |
| G3 | Solo operation (R9, important) | discovery | Team-building is evidenced, solo work is not | A team-of-one mandate rests on this | Stretches where you ran channels without a team | Role descriptions or a channel ownership map | `[grounded]` your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site requirement conflicts with your remote-only limit (R1) | red_flag | medium | "On-site in our Austin office 5 days a week — no exceptions." | Held at `medium`, not `high`: the posting states the term openly, so this is an incompatibility, not a misleading claim | `[grounded]` JD and your stated constraint | Is any remote or hybrid arrangement possible for this role, or is the on-site term fixed? | confirmed |
| RR2 | Base range below your floor (R2) | red_flag | medium | "Compensation: $70–85k base plus meaningful equity upside." | Held at `medium` for the same reason; the $65k gap to your floor is a mismatch for you, not evidence of bad faith | `[grounded]` JD figure and your stated floor | Is the base range flexible, and what are the equity terms (size, vesting, strike)? | confirmed |
| RR3 | Bundled seven-channel mandate with no team or stated resources | risk_signal | medium | "Own all revenue growth end to end ... You will be a team of one to start" | You may be accountable for outcomes without budget, headcount or decision rights | `[inferred]` from the JD's scope against its silence on resources | What budget and spend authority does this role hold, and when is the first hire planned? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be a routine norm | `[inferred]` from the wording | In a typical month, how many evenings or weekends does the team currently work? | unresolved |
| RR5 | Success undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for revenue without a stated target | `[inferred]` from the wording | What revenue target would this role be measured against by the end of year one? | unresolved |
| RR6 | Terms stated up front; direct CEO reporting | positive_signal | — | "Report to the CEO with a dotted line to the board." | Pay, location and reporting line can be read from the page, so this posting can be ruled out without a call | `[grounded]` JD | What does the board expect to see from this role, and how often? | noted |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pass on this posting as written | See R1, R2 | `[grounded]` map rows | recommended, your call |
| A2 | Carry your two constraints into your search filters: remote-eligible, base of at least $150k | See R1, R2 | `[grounded]` your stated constraints | pending your approval |
| A3 | If you choose to test the terms anyway, put RR1 and RR2's questions to the employer before spending application effort | The register doubles as interview preparation | `[grounded]` register | pending your approval |

No CV language or outreach text is proposed here. Every row above is a proposal that waits on your approval.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have confirmed whether the company and posting exist as described (role reality, RR7). |
| 2. Role-family sweep | unavailable | The search was refused. It would have given a market band for market calibration and tested RR1 and RR2 against it. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

Stage is assumed to be "evaluating", since you didn't say otherwise.

If you'd like a saved record of this assessment, I can write it to `tuesday-dossier.md`.

## Upgrade menu

- A link to the live posting or Novaline's careers page → RR7 and role reality's organization row.
- Search access, if you grant it → the market calibration row and RR1 and RR2 checked against a band. After that I can offer one deeper pass of up to 5 more searches and 2 more fetches.
- A hiring contact's name → target 3, and the scope read.
- The employer's answer on remote work and base pay → R1 and R2 could move from failed to met, and the status with them.
- A growth P&L, channel report or Braze program summary → R4 and R5 to `high`.

No questions this turn. R1 and R2 are your own stated constraints, and no recall answer could change them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.