**Should you go for it? Yes, I think it's worth applying, with open eyes about R6 (forecast ownership) and R9 (billing data). Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two days a week in the office), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3, R4, R7 · adjacent: R5 (Strong SQL and spreadsheet modelling), R6 (Experience owning a forecast) · unclear: R8 (Working with finance on revenue data) · absent: R9 (Working with billing data)
- `important`: unclear: R10 (At a B2B software company)

R6 (`medium`) is a bridge with its limit named; R9 is billing data, absent and carried as a material risk; R8 is finance work not yet established.

**Opportunity ledger.** The employer is established and states a pay band (RR5, RR6). The posting isn't confirmed on Quillfield's own site (RR1). Team shape, first-year outcomes and option terms are unstated (RR2, RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two days a week in the office), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm that R1 and R2 work for you.
  2. R6 and R9 are carried honestly, with nothing in the application implying forecast ownership or billing experience.
  3. RR1 is resolved, so the posting is confirmed live through Quillfield or the recruiter.
- **What would change this:** a failed R1 or R2 would make it `no_go`, with that gate as the reason.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` About Quillfield page, quillfield.co.uk/about |
| Mandate | "own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two days a week in the office; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe is Head of Revenue Operations at Quillfield, and previously spent four years as a sales operations manager at Corvane Payments | `[grounded]` recruiter's statement to you, and her profile page |
| Reporting line | The posting is silent on it; the role probably sits in her function | `[inferred]` from her title against the recruiter naming her |
| First-year outcomes | None stated | `[grounded]` posting silence |
| Market calibration | A 2026 UK pay guide puts a RevOps lead in B2B software (n=438) at median £64,200, interquartile range £57,800–£70,400. The posted band sits inside that range and straddles the median. It's a market pattern, not Quillfield's offer, and not Bristol-specific. | `[generic]` Ledgerline guide; `[grounded]` posting band |
| Unknowns | Direct reports; who builds the forecast today; the billing system; option terms; success measures | `[grounded]` posting silence |
| Contradictions | No contradiction found, but the posting could not be matched to a listing on Quillfield's own site (RR1) | `[grounded]` careers page fetch returned no page |

## Evidence map

Your background is typed prose, so I treat it as a self-reported lead rather than proof, and `medium` is the ceiling until something is inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | The posting states the terms. You haven't given your location or office-day limits, so I can't say whether they work. | `[grounded]` posting; your constraints not given | Q1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | The band is stated. Your pay floor isn't known. | `[grounded]` posting; floor not given | Q1 |
| R3 | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running RevOps for the UK team. That clears the years and the function. No CV or artifact has been inspected. | `[grounded]` your description | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You are Salesforce admin certified. The credential hasn't been inspected. | `[grounded]` your description | Credential page would raise to `high` (see upgrade menu) |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | You use SQL weekly and Excel daily. How deep that goes, and whether it includes building models, isn't stated. The forecast piece of the role draws on modelling. | `[grounded]` your description | G5 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director and rebuilt the pipeline dashboards. You've never owned the company forecast, because finance did. The bridge is real and so is the limit: running the review isn't owning the forecast. The posting asks for owned-forecast experience in so many words, and a literal screen may read that strictly. | `[grounded]` your description and posting wording; `[generic]` that screens read this strictly | Q3 |
| R7 | Build pipeline and renewal reporting that sales and finance teams run on | must_have | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them isn't stated, so I've kept the row to what you said. | `[grounded]` your description | none |
| R8 | Working with finance on revenue data | must_have | unclear | low | discovery | Finance owned the forecast at your company, which hints at contact, but nothing says what you did with them. | `[grounded]` your description; `[inferred]` contact from "finance did that" | Q2 |
| R9 | Working with billing data ("own our CRM and billing data") | must_have | absent | none | capability | You've never worked on billing data. That is a stated gap with no adjacent evidence yet. | `[grounded]` your statement | G4 closure path; carried as a material risk |
| R10 | The experience is at a B2B software company | important | unclear | low | discovery | Your employer is a B2B payments company. Whether it sells software, which is what the posting names, isn't stated. | `[grounded]` your description | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Office days, location and pay (R1, R2, hard_gate) | hard_gate | The posting states both terms and your limits are unknown | A failed gate ends the application whatever the fit | Not applicable; this is a yes or no on the terms | None needed | `[grounded]` posting terms; your constraints not given |
| G2 | Finance contact on revenue data (R8, must_have) | discovery | You describe pipeline and renewal work and say finance owned the forecast, but not what you exchanged with them | The role has you building reporting that finance runs on and forecasting with the CFO | Reconciling renewal values with finance; commission or quota figures finance signed off; revenue reports you supplied or checked | A renewal report finance used, or an email thread or sign-off note | `[grounded]` description silent on finance work; `[inferred]` the role leans on this |
| G3 | Forecast bridge (R6, must_have) | transferability | You run the monthly pipeline review but didn't own the forecast | R6 is the gap most likely to be probed, given the posting's wording | Deal categories such as commit and best case; coverage or weighted-pipeline numbers you produced; tracking forecast against actuals | A sanitized pipeline-review deck or a forecast-accuracy tracker | `[grounded]` your description; `[generic]` that forecast ownership draws scrutiny in roles like this |
| G4 | Billing data (R9, must_have) | capability | No billing-data work stated | The posting makes billing data part of what you would own | Nothing yet. The closure path is to learn how invoices, credit notes and subscriptions connect to renewals, then ask Quillfield which billing system sits behind the data. | A short write-up of how billing records link to your renewal dashboards, once you have read up | `[grounded]` your statement; `[inferred]` closure path |
| G5 | SQL and modelling depth (R5, must_have) | discovery | Frequency of use is stated; depth and modelling aren't | "Strong" is the posting's word, and the forecast leans on modelling | Queries joining CRM and renewal tables; a pipeline or renewal model you built in Excel | A query sample or a sanitized workbook | `[grounded]` description; `[inferred]` modelling matters for the forecast |
| G6 | Software company setting (R10, important) | discovery | A B2B payments company isn't clearly a software company | It is an `important` row and may decide how the posting's wording is read | Whether your employer sells a platform or product | None | `[grounded]` description silent on product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not matched on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The listing may live on a page I couldn't reach, the careers page may have moved, or the posting may be an aggregator copy. | `[inferred]` from the careers page fetch returning no page | Where is this role listed on your own careers page, and is it still open? | unresolved |
| RR2 | Success measures unstated on a CFO-facing mandate | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may carry forecast accountability with no defined first-year outcome. | `[inferred]` from the mandate against the posting's silence | What does success look like in the first year, and who builds the forecast today? | unresolved |
| RR3 | Team and reporting line unstated | unknown | — | "Revenue Operations Lead" | The role may be a single-person function or may lead a team; the posting doesn't say. | `[inferred]` from the posting's silence on reports | Who is on the revenue operations team, and who does this role report to? | unresolved |
| RR4 | Share option terms unstated | unknown | — | "plus share options" | The value of the options depends on terms the posting doesn't give. | `[generic]` option terms vary by grant | How many options, on what vesting schedule and at what strike price? | unresolved |
| RR5 | Pay band stated, within market range | positive_signal | — | "£61,500–£67,000" | The band is disclosed and sits inside the guide's interquartile range. | `[grounded]` posting; `[generic]` guide range | Is the band the full range for this role, or is there flexibility within it? | noted |
| RR6 | Employer established as described | positive_signal | — | "the invoicing software company" (your description) | Quillfield's own About page confirms size, location and funding. | `[grounded]` quillfield.co.uk/about | What does the revenue operations function look like today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm Bristol with two office days and the £61,500–£67,000 band against your own limits before investing more | R1, R2 | `[grounded]` posting terms | pending your approval |
| A2 | Lead with the pipeline and renewal dashboard rebuild and the monthly pipeline review you run with your sales director | R3, R7, R6; these are your own verified-by-you claims | `[grounded]` your description | pending your approval |
| A3 | Say plainly that finance owned the forecast and that you haven't worked on billing data; don't describe the pipeline review as forecast ownership | R6, R9 | `[grounded]` your statements | pending your approval |
| A4 | Ask the register questions (RR1 to RR4) verbatim in the loop, adding who builds the forecast today | RR1 to RR4 | `[grounded]` register | pending your approval |
| A5 | Read up on how billing records (invoices, credit notes, subscriptions) connect to renewals, so you can describe your closure path in the interview | R9 | `[inferred]` from R9 | pending your approval |
| A6 | For Tamsin Achebe, lead with your sales-operations-to-RevOps path, which her own public profile mirrors in outline. Don't try to guess what she wants | Her background is public; what she prefers is not | `[grounded]` her profile page; `[inferred]` that this is the story your evidence supports | pending your approval |

Every row above, including the positioning advice in A2, A3 and A6, is proposed and goes no further without your approval.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned "About Quillfield" (quillfield.co.uk/about), and "Quillfield careers Revenue Operations Lead", which returned nothing; fetched quillfield.co.uk/careers, which returned no page. Moved role reality's organization row and RR1. The posting itself is the user link read. |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B SaaS Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR5. It covered pay only, not scope norms. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe); fetched that page. Moved the hiring manager row and plan row A6. |

If you'd like, I can save all of this as a `tuesday-dossier.md` to carry forward.

**Upgrade menu**

- Your CV, or a pasted version of it, would let me check R3 to R7 against what it actually says and surface anything it undersells.
- Your Salesforce certification page would raise R4 to `high`.
- A sanitized pipeline or renewal dashboard, a pipeline-review deck, or a forecast-accuracy tracker would raise R6 and R7.
- Your location, office-day limit and pay floor would settle R1 and R2.
- The recruiter's answers on the billing system, how the forecast is built today, team size and option terms would close RR2, RR3 and RR4 and sharpen R9.
- A link to the role on Quillfield's own careers page would close RR1.
- A deeper research pass on Quillfield (funding, leadership changes, recent news) would cost up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

G1 — Is two days a week in the Bristol office workable for you, and is a base in the £61,500–£67,000 range at or above your floor?

G2 — When you have worked with finance, which numbers did you bring to them or take from them (renewal values, commission or quota figures, revenue reports, for example), and which part was yours?

G3 — In the monthly pipeline review, what part of the forecast number did you own or feed (inputs, deal categories, accuracy tracking), and who made the final call?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.