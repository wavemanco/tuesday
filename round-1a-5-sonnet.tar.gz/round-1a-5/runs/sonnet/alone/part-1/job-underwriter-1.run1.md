I'll read the reference files the skill requires before building the assessment.
Running the company and role-family searches now, then I'll write the full assessment.
# Job Underwriting Assessment: Senior Product Analyst at Harborlight Health

## Decision snapshot

**Yes, apply. You're a fit on the core of the role: R1, R2, R3, R4 and R8 (all `must_have`) are `direct`, and healthcare (R9) is the real stretch. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R8 · unclear: R5 (Define and maintain the metrics layer)
- `important` — direct: R6a · unclear: R6b (Partner with clinicians), R7 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R5 — metrics-layer work not yet evidenced; R6b, R7 — your background is silent on clinicians and on mentoring; R9 (`medium`) — a credible bridge via the consent model, its limit named.

**Opportunity ledger.** Unverified, and nothing in it is alarming. The employer is not established because research did not run (RR1), pay and location are not stated (RR2), and year-one outcomes are not stated (RR4). One entry runs the other way: the JD names a team to mentor (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting verifies as live on Harborlight's own careers page (RR1); (2) pay and location clear your own limits (RR2); (3) your metrics-layer and mentoring experience is confirmed before you lean on it (R5, R7); (4) healthcare is framed as adjacent, never as healthcare experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C | `[grounded]` JD header, as pasted; not independently checked |
| Mandate | Own product analytics for the care-navigation app | `[grounded]` JD |
| Responsibilities | Metrics layer; A/B test design and analysis; self-serve Looker dashboards; partnering with PMs and clinicians; mentoring two junior analysts | `[grounded]` JD |
| Team | Two junior analysts to mentor, so an analytics team already exists | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Pay, location, working pattern | Not stated in the posting as pasted | `[grounded]` JD silent |
| Scope read | One senior seat covering measurement, experimentation and BI for a single app, which is coherent. The breadth is heavy if no data-engineering support sits behind the metrics layer. | `[inferred]` from the JD's responsibility list against its silence on engineering support |
| Market calibration | Not established. The role-family search was refused, so no pay band is stated. | `[grounded]` JD states no pay; no `[generic]` band asserted |
| Unknowns | Pay; location; first-year outcomes; who the clinicians are and what data access the role has; whether the metrics layer is LookML or a separate warehouse layer | — |
| Contradictions | None found between the JD and your background. The JD could not be checked against Harborlight's own pages. | `[grounded]` provided inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years at a consumer-subscription company (meal-kit, about 2M subscribers). Typed background has the standing of a CV: a lead, not proof. | `[grounded]` your stated background | none |
| R2 | Expert SQL | must_have | direct | medium | none | You state daily SQL on a Snowflake warehouse over 6 years. "Expert" is a self-grade, and nothing is inspectable yet, so expect a technical screen. | `[grounded]` your stated background | A sanitized query or model would raise this to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You state you designed and ran the program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift. This is specific. The JD does not define "at scale", so the comparison with Harborlight's traffic is open. | `[grounded]` your stated background | A sanitized experiment readout would raise this to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. | `[grounded]` your stated background | Dashboard screenshots or a LookML excerpt would raise this to `high` |
| R5 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" suggests definitional work, but your background does not say you owned a metric dictionary, certified Explores or a modeled layer. I won't assume it. Teams of this kind often split the layer between analytics and data engineering. | `[grounded]` background silent on the layer; `[generic]` on how teams split it | See G1 |
| R6a | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | You present to the VP Product monthly and write the monthly metrics memo the exec team reads. The roadmap-decision outcome is not stated. | `[grounded]` your stated background | Name one decision your analysis changed, if one exists |
| R6b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background touches clinical or other domain-expert stakeholders. | `[grounded]` background silent | See G3 |
| R7 | Mentor two junior analysts | important | unclear | none | discovery | Your background is silent on mentoring or managing anyone. | `[grounded]` background silent | See G2 |
| R8 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads. | `[grounded]` your stated background | A sanitized memo would raise this to `high` |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | Adjacent: you handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse. Limit: you have not worked in healthcare, and nothing you stated touches protected health information. HIPAA-specific practice such as business-associate agreements, minimum-necessary access and de-identification is not exercised by the stated work. | `[grounded]` your stated background; `[generic]` on what HIPAA practice involves | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | A Looker build and governed dashboards, with no statement of who defined the metrics or where | It is the first responsibility the JD lists, and it is the `must_have` row still unclear | A metric dictionary or certified Explores; settling a dispute over how churn or retention is defined; a warehouse model your dashboards read | LookML excerpt, metric definitions doc, a screenshot of the governed Explore | `[grounded]` background silent; `[generic]` that this is the likeliest probe |
| G2 | Mentoring (R7, important) | discovery | No mention of mentoring | The JD names two juniors, so this is a visible part of the job | Onboarding an analyst; reviewing others' queries or tests; running a team analytics clinic | Nothing needs attaching | `[grounded]` background silent |
| G3 | Clinician partnership (R6b, important) | discovery | No domain-expert stakeholders mentioned | A care-navigation product likely involves clinical input, though the JD does not say how | Working with a subject-matter group such as culinary, ops or medical-style reviewers; translating a domain team's questions into metrics | A memo or test brief that shows it | `[grounded]` JD names clinicians; `[inferred]` that the role needs the skill daily |
| G4 | Healthcare data (R9, preferred) | transferability | Consent-state model plus GDPR/CCPA PII handling | A preferred row; the bridge is credible, and the limit is the thing an interviewer will test | Bridge: consent modeling and PII governance. Limit: no PHI or HIPAA work. Strengthener: a short note on how you scoped access and consent. | Sanitized consent-model design doc | `[inferred]` bridge from your stated work; `[generic]` that HIPAA is access- and de-identification-heavy |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. None is ranked as likely. | `[generic]` pattern for unverified postings, not a claim about this one | Can you point me at the role on your own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Pay and location not stated | unknown | — | The pasted posting gives no salary, location or remote policy | The details may be withheld, or may have been dropped from the paste | `[inferred]` from the JD as supplied | What is the salary range, and is the role remote, hybrid or on site? | unresolved |
| RR3 | Named team and defined responsibilities | positive_signal | — | "mentor two junior analysts" | The seat sits inside an existing analytics team with defined duties | `[grounded]` JD | Who are the two analysts, and who does this role report to? | noted |
| RR4 | No stated year-one outcomes on a broad mandate | unknown | — | "Own product analytics for our care-navigation app" | Success measures may be undefined, or may exist outside the posting | `[inferred]` from the JD's silence | What would this person have delivered by the end of year one? | unresolved |

## Application plan

Everything in this section is proposed, pending your approval: the resume edits, the positioning advice and the actions alike. Nothing is final until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Designed and ran the experimentation program (30+ A/B tests a year), including the pricing test behind an 11% retention lift." | R3; restates your own sentence, nothing added | `[grounded]` your stated background | `resume_edits_pending_approval` |
| E2 | Resume line: "Built the company's Looker instance from scratch; 40+ governed dashboards." | R4 | `[grounded]` your stated background | `resume_edits_pending_approval` |
| E3 | Resume line: "Built the consent-state model for the warehouse; handled GDPR/CCPA consumer PII." | R9 bridge, with no healthcare claim | `[grounded]` your stated background | `resume_edits_pending_approval` |
| E4 | Resume line: "Write the monthly metrics memo the exec team reads; present to the VP Product monthly." | R6a, R8 | `[grounded]` your stated background | `resume_edits_pending_approval` |
| P1 | Positioning: lead with E1 and E2, and say plainly that healthcare is new to you, with E3 as the bridge | Keeps R9 honest at `adjacent` | `[grounded]` R9 row | pending your approval |
| A1 | Confirm the posting is live on Harborlight's own careers site before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask for the pay range and location early | RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Ask RR3 and RR4's questions in the loop, and ask what PHI access the role has | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for the company's care-navigation app and funding stage, and for its careers page, were refused. It would have moved the organization and contradictions rows and RR1. |
| 2. Role-family sweep | unavailable | A search for a pay band and scope for this title was refused. It would have moved market calibration and RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Upgrade menu

- Permission to run web search would run targets 1 and 2, which settle RR1 and give a market band; a deeper pass (up to 5 more searches and 2 more fetches) is available after that.
- A sanitized SQL or model sample would raise R2 to `high`.
- A sanitized experiment readout would raise R3 to `high`.
- A Looker screenshot or LookML excerpt would raise R4 to `high` and may settle R5.
- A sanitized monthly memo would raise R8 to `high`.
- Your pay floor, location and work-authorization limits would add gate rows, so the hard-gates line becomes a real check.
- The hiring manager's name would add the public-footprint read to the application plan.
- A saved `tuesday-dossier.md` of this assessment is available whenever you want it.

Questions:

1. **G1** — Did you personally define or govern metrics, such as a metric dictionary, certified Explores or a shared definition others had to use? If so, what did you own, and how did you handle disagreements?
2. **G2** — Have you onboarded, reviewed the work of, or mentored other analysts, formally or informally? What did you own?
3. **Constraints** — What is your pay floor, your location or remote requirement, and your work-authorization situation, if any limit applies?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.