I'll read the reference files the skill names before building the assessment.
# Job Underwriting Assessment: Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Should you go for it? Yes on fit, but settle R1 before you apply, because the JD and the careers page disagree about where the job is done. Status: `hold_pending_answers`.** Not having worked on pet insurance is R10, a `preferred` row at `adjacent`. Not having managed anyone has no row, because the JD states no line-management requirement.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK) working pattern)
- `must_have` — direct: R2, R3a, R4, R5a, R6, R7, R8 · adjacent: R3b (Monitor rating models)
- `important` — unclear: R5b (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance familiarity)

R1 — the one row that could end this; R3b (`medium`) — "maintained" is not yet "monitored"; R10 — a transferable bridge, its limit named.

**Opportunity ledger.** The posting contradicts itself on working pattern (RR1) and withholds pay (RR2). On the positive side, the reporting line is named (RR3). Team and resourcing are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK) working pattern); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the employer confirming the working pattern (R1, RR1) and your answer on whether four office days in Leeds would work. A "fully remote" confirmation moves this to `go`. A confirmed four days in Leeds moves it to `go` or `no_go`, depending on your answer. The pay range (RR2) matters for the final call too.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; the careers page shows the role as "Accepting applications" | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing | `[grounded]` careers page |
| Working pattern | The JD as you pasted it says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` both sources, in conflict |
| Line management | The JD lists no direct reports and no management requirement | `[grounded]` JD |
| First 90 days and first year | Not stated in the JD | `[grounded]` JD silence |
| Salary | The JD as pasted gives no figure. The careers page text I could read gave none either | `[grounded]` JD; careers page fetched |
| Hiring manager | Odile Varga, Director of Pricing. Public footprint: a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books; previously head of pricing analytics at Calloway Re for six years. This comes from one search-result snippet, not a page I read in full | `[grounded]` search result snippet |
| Scope read | A single-product ownership role with a named senior manager. Whether it carries a team, data engineering support or tooling is not stated | `[inferred]` from the JD's "own" and the absence of any team or resourcing language |
| Market calibration | A 2026 pay survey of UK insurers and insurtechs puts the senior pricing analyst median base at £58,400, with an interquartile range of £52,100 to £64,900 (n=612). This is a band to expect, never Brindlemoor's offer, and it does not separate remote from office-based posts | `[generic]` role-family sweep; band from the Pricewell 2026 survey snippet |
| Unknowns | Working pattern, salary, team and resourcing, whether the role carries reports, who the product counterparts are | `[grounded]` JD and careers page silences |
| Contradictions | JD "fully remote" against careers page "Leeds office four days a week" (R1, RR1) | `[grounded]` the two sources |

## Evidence map

Your background is typed prose, so it counts as self-report, and `medium` is the ceiling until you share something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) working pattern | hard_gate | unclear | none | hard_gate | The JD says fully remote and the careers page says four days a week in Leeds, so the employer's own sources disagree. You have not stated your location or whether remote is a must, so there is no constraint of yours to grade | `[grounded]` JD and careers page; no candidate constraint given | Answer G1; put RR1's question to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer, the last two as senior analyst. Confirmed and specific, with no document inspected | `[grounded]` your background statement | A dated role history would lift it to `high` |
| R3a | Build rating models | must_have | direct | medium | none | You built the GLM rating model for the young-driver book. Confirmed and specific, with no artifact inspected | `[grounded]` your background statement | A sanitised model spec or relativities summary would lift it to `high` |
| R3b | Monitor rating models | must_have | adjacent | medium | discovery | You said you "maintained" the model. Maintenance can include performance monitoring but your statement does not say so, and ambiguity resolves downward. The hiring manager's published talk is on monitoring rating models, so this row is likely to be probed | `[grounded]` your wording; `[inferred]` probe likelihood from the talk title in the search snippet | Answer G2 |
| R4 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Whether you designed them (hypothesis, split, success measure) or ran and read them is not stated, so expect a probe | `[grounded]` your background statement | Confirm which parts you designed; held for a later turn |
| R5a | Turn results into recommendations for underwriting | must_have | direct | medium | none | You ran the tests with the underwriting team and present the quarterly pricing review to the head of underwriting | `[grounded]` your background statement | None |
| R5b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing you have said mentions a product or proposition audience. Your underwriting presentations are indirect context only | `[grounded]` silence in your statement | Answer G3 |
| R6 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. No artifact inspected | `[grounded]` your background statement | A sanitised code sample or query would lift it to `high` |
| R7 | GLM experience | must_have | direct | medium | none | Same evidence as R3a: you built and maintained a GLM rating model | `[grounded]` your background statement | None |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, and the JD says "underwriting or actuarial" | `[grounded]` your background statement; JD wording | A sanitised review deck would lift it to `high` |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background statement | None |
| R10 | Pet-insurance familiarity (inferred from the product named in the JD; the JD does not list it as a requirement) | preferred | adjacent | medium | transferability | Motor GLM rating and test discipline carry over. The limit is that you have no pet-specific rating or claims work. Pet cover rates on different factors from young-driver motor | `[grounded]` your statement that you have never worked on pet insurance; `[generic]` that pet rating factors differ from motor | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The JD says fully remote and the careers page says four days a week in Leeds. Your own location and remote requirement are not given | It decides whether this role is open to you at all, and wording cannot fix a mismatch | A term, not experience, so nothing counts here | The employer's answer, through contact details on its own careers site; a corrected posting | `[grounded]` the two sources in conflict; `[inferred]` that it could change the status |
| G2 | Monitoring rating models (R3b, must_have) | discovery | The evidence says "maintained"; nothing says whether you tracked performance after release | A must-have, and the hiring manager has published on this topic, so it is the likeliest probe | Tracking actual against expected loss ratio after a rate change; a recurring performance report on the young-driver model; spotting a drifting rating factor and recalibrating; a model-review sign-off | A sanitised monitoring dashboard or model-review note | `[grounded]` your wording; `[inferred]` the probe from the talk title |
| G3 | Product recommendations (R5b, important) | discovery | Your recommendations go to underwriting; no product-side audience is mentioned | The JD names product as a recommendation audience, and this row is the weakest of the map's rows below `direct` on evidence | A test result that went to a product, proposition or digital team; a recommendation that changed what was offered or how it was presented | A sanitised test readout or recommendation note | `[grounded]` JD wording and your silence |
| G4 | Pet-insurance familiarity (R10, preferred) | transferability | Motor GLM rating and price testing are credible adjacent work; no pet-specific work | A preferred row, so a minor risk, but it is the gap you raised yourself | The bridge is the rating method. The limit is pet-specific factors and claims behaviour you have not exercised. A short note on how you would adapt your rating structure would narrow it | A short, sanitised work sample; proposed, pending your approval | `[grounded]` your statement; `[generic]` that pet rating factors differ from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between two employer sources (see R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The posting may have been updated in one place and not the other, or the role's terms may have changed | `[inferred]` from two sources disagreeing; `[generic]` that postings drift between copies | Is this role fully remote within the UK, or based at the Leeds office four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | JD as pasted gives no figure | The figure may sit anywhere in or outside the £52,100 to £64,900 band, or the employer may simply not publish it | `[inferred]` from the withheld figure against the `[generic]` survey band | What salary range is budgeted for this post? | unresolved |
| RR3 | Reporting line named | positive_signal | — | Careers page: "reports to the Director of Pricing" | The role sits directly under the pricing lead, so ownership is likely to be real | `[grounded]` careers page | What does the Director of Pricing expect this role to deliver in its first six months? | noted |
| RR4 | Team and resourcing unstated against "own" | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be the only analyst on the product, or part of a team; data access and tooling are not stated | `[inferred]` from the JD's "own" against its silence on team and tooling | Who else works on pricing analytics for this product, and does the role carry direct reports? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Put RR1's question to the employer through contact details on its own careers site, before investing in an application | R1 decides eligibility; see RR1 | `[grounded]` R1, RR1 | pending your approval |
| E1 | In the summary and the model bullet, name the young-driver GLM rating model you built and kept maintained, using your own verbs. Keep "maintained", and do not write "monitored" unless G2 confirms it | R3a, R3b; keeps the line traceable to your sentence | `[grounded]` your statement | resume_edits_pending_approval |
| E2 | State "14 price tests last year, run with the underwriting team". Do not write "designed" until you confirm what you designed | R4; the claim stays as you said it | `[grounded]` your statement | resume_edits_pending_approval |
| E3 | If monitoring evidence turns up, lead with it, since the hiring manager's published talk is about monitoring rating models. Say plainly that your insurance work is motor and not pet | R3b, R10; Odile Varga's talk title | `[grounded]` search snippet; `[inferred]` that it is the relevant story to lead with | pending your approval |
| Q1 | Ask the verification questions from RR1 to RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A2 | If asked about management, say you have not managed anyone and note that the JD lists no reports. Confirm with RR4's question | Keeps the answer honest and checkable | `[grounded]` your statement; JD silence | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst" and fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The employer exists as described and the posting is live. It moved role reality's working-pattern and contradictions rows, R1, RR1 and the decision |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary remote pet insurance", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet only. It moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read as a snippet only. It moved the role reality hiring-manager row, R3b's reasoning and plan row E3 |

I'll offer the dossier file (`tuesday-dossier.md`) if you want this saved for later.

## Upgrade menu

- Your location and whether remote is a must, plus your pay floor → R1 becomes `direct` or `hard_gate_fail`, and RR2 can be set against your floor.
- Inspectable artifacts raise the `medium` rows to `high`. For pricing work these are a sanitised model specification or relativities summary (R3a, R7), a monitoring dashboard or model-review note (R3b), a price-test readout (R4, R5a, R5b), a sanitised quarterly review deck (R8), and a dated role history (R2, R9).
- The employer's reply on working pattern and salary → RR1 and RR2 close, and the decision simplifies.
- A deeper research pass on Brindlemoor (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1 — Would four days a week in a Leeds office work for you, or is fully remote a must?

G2 — On the young-driver model, did you track how it performed after release (for example actual against expected loss ratio, or a drifting factor you recalibrated)? What was yours to do, and what did it lead to?

G3 — Did any price-test result go to a product, proposition or digital team rather than underwriting? What did you recommend, and what changed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.