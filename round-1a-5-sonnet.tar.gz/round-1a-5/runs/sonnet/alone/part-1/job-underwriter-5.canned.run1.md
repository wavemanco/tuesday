I'll read the skill's reference files before building the assessment.
I've read the skill's rules. Next I'm checking that the posting and company page you pasted are live and match, then I'll write the assessment.
**Yes, this is worth applying to. R3, R4, R5, R6, R7 and R8 (the `must_have` rows) are all `direct`. Status: `conditional_go`.** The conditions are below. They cover your location and pay floor, which you haven't given me, and BigQuery, which is the one adjacent skill.

I fetched the careers page and ran one search before writing this. Both match what you pasted, and I found no contradictions.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery specifically); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R9 — a credible bridge from Snowflake, its limit named; R10, R11 — your background is silent on both, one question covers them.

**Opportunity ledger.** The role looks sound on what is published. The pay is stated and sits at or above the supplied market median (RR1), and the funding is recent (RR5). The open points are scope breadth and team makeup (RR2, RR3), unquantified equity (RR4) and no stated first-year outcomes (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm that the location and pay terms work for you, which closes R1 and R2; (2) the BigQuery gap is stated plainly as adjacent, never as BigQuery experience (R9); (3) scope and team makeup verify in conversation (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page, fetched via search result |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD, careers page live and identical to your paste |
| First-year outcomes | None stated in the posting | `[grounded]` JD silent |
| Terms | Remote (US) or Denver office; $148,000–$166,000 plus equity, equity unquantified | `[grounded]` JD |
| Scope read | Ingestion, modelling and contracts together are wider than the single-domain scope the report calls typical, so this may be an end-to-end role | `[inferred]` from the JD's three named areas against the report's stated norm |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, interquartile range $139,000–$163,500, "senior" typically 5–8 years, one domain's pipelines, no direct reports. The posted range runs from $3,000 below the median to $2,500 above the upper quartile, and the 5+ year floor sits inside the 5–8 norm. This is a band to expect, never this employer's offer | `[generic]` Datawright 2026 report (n=2,310) you supplied; `[grounded]` JD for the posted figures |
| Unknowns | Hiring manager, team size and makeup, equity terms, whether the role is new or a backfill, first-year outcomes | `[grounded]` JD and your note that no manager is named |
| Contradictions | None between your paste, the careers page and the about page | `[grounded]` page fetched, search result read |

## Evidence map

Your background was given in prose with no CV, so I treat it as CV-equivalent self-report. That caps every row at `medium` on a first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You stated no location or work-authorization constraint, so I can't say whether this term is met. Nothing here suggests a conflict | `[grounded]` JD term; no candidate constraint given | Q1 |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor given, so the term is not established. The range itself is at or above the supplied median (RR1) | `[grounded]` JD; no candidate floor given | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. Years of experience is graded as a requirement, not a gate | `[grounded]` your stated background; `[generic]` report's 5–8 year norm for "senior" | Offer a CV or LinkedIn role dates to raise to `high` |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state SQL and Python daily. "Strong" has no artifact behind it yet | `[grounded]` your stated background | Offer a sanitized query, repo or code sample |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Scale is stated, with no inspectable artifact yet | `[grounded]` your stated background | Offer a sanitized lineage graph, model list or project docs |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the JD asks for "a cloud warehouse" generally, so the requirement as written is met. BigQuery is carried separately as R9 | `[grounded]` your stated background and JD wording | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration, which is the named tool | `[grounded]` your stated background | Offer a sanitized DAG sample |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite, so you built it rather than only using it | `[grounded]` your stated background | Offer a sanitized suite config or sample run |
| R9 | BigQuery (named in the role description, not in the requirements list) | important | adjacent | medium | transferability | You have run dbt and SQL on Snowflake and have never used BigQuery. The limit: no BigQuery use at all, so its cost model, partitioning and permissions are unexercised. Warehouse switches usually cost the most in those areas | `[inferred]` adjacency from your Snowflake work; `[generic]` where warehouse differences tend to sit | G1 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background doesn't say which sources you ingested or whether you owned that layer. A payroll company's pipelines may include comparable sources, but I won't assume it | `[grounded]` your background silent | G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your background doesn't mention contracts, schema agreements or freshness expectations with analysts. The Great Expectations suite may be related, and that is a lead to ask about, not a claim | `[inferred]` possible link via the test suite | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Strong dbt and Snowflake evidence; BigQuery never used | It is the named platform, so it is the first thing a technical screen can probe, but R9 is `important` rather than a must-have | A side project, a migration or proof of concept, a trial account, or queries run on someone else's project | A short note or repo showing even a small BigQuery dbt project | `[inferred]` bridge from your Snowflake work; `[generic]` that a named platform you haven't used is a likely probe |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Nothing says what you ingested or whether you owned that layer | The role is "build and run" pipelines, and ingestion is the first thing it names | Event or product-usage data, CRM exports or API syncs, loading payroll-system data into the warehouse, owning connector failures | An ingestion DAG, a source list, or a runbook, sanitized | `[grounded]` background silent on sources; `[inferred]` that this closes much of the R10 doubt |
| G3 | Data contracts (R11, important) | discovery | Great Expectations is a related lead, but nothing says it was a contract with analysts | Contracts are named in the mandate, and this may be a differentiator beyond the tests | Agreeing schemas or freshness expectations with analysts, versioned model contracts, alerts that analysts relied on | A sanitized test config, a schema or freshness spec, a model YAML | `[grounded]` background silent; `[inferred]` the suite as a lead |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is transparent and sits at or above the supplied median, so there is no seniority-pay mismatch | `[grounded]` JD against the report's median and interquartile range | Where within $148,000–$166,000 does a hire with six years typically land? | noted |
| RR2 | Scope may span several domains | unknown | — | "Build and run the pipelines … ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | One engineer, or a small team, may own end-to-end what the report calls a one-domain scope | `[inferred]` from the JD's three areas against the report's scope norm | Who else owns ingestion, warehouse modelling and contracts today, and what does this role own alone? | unresolved |
| RR3 | Hiring manager and reporting line unnamed | unknown | — | "The posting names no hiring manager" (your note) | The posting may simply omit it, which is common for postings of this kind | `[generic]` posting practice; `[grounded]` your note | Who would this role report to, and who is on that team? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Its value can't be judged without grant size, vesting and valuation basis | `[inferred]` from the JD's silence | What is the grant range, vesting schedule and the valuation it is based on? | unresolved |
| RR5 | Recent funding and a live posting | positive_signal | — | "Series C ($52M, February 2026)" | The company is funded and hiring, so the role is plausibly budgeted | `[grounded]` about page for the funding; `[inferred]` that the role is budgeted | Is this a new role or a backfill? | noted |
| RR6 | No first-year outcomes stated | unknown | — | The posting states no outcomes for the first year | A broad mandate with no success definition can mean unclear expectations | `[inferred]` from the JD's silence against its wide scope | What would a successful first year look like for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm that your location and pay floor work with the posted terms before investing in the loop | See R1, R2 | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Lead with the matched must-haves from your own history: the dbt project (about 180 models), Airflow orchestration and the Great Expectations suite | See R5, R7, R8 | `[grounded]` R5, R7, R8 rows | pending your approval |
| A3 | When BigQuery comes up, say plainly that you have run dbt on Snowflake and have not used BigQuery. Don't describe the two as equivalent | See R9, G1 | `[grounded]` your statement, R9 row | pending your approval |
| A4 | Ask RR2, RR3, RR4 and RR6 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

`resume_edits_pending_approval`

| # | Current framing | Proposed line | Traces to |
|---|---|---|---|
| E1 | Not provided | "Built the dbt project on Snowflake (about 180 models); used Airflow for orchestration; set up the Great Expectations test suite." | Your sentences: "Built our dbt project on Snowflake — about 180 models. Airflow for orchestration, and I set up our Great Expectations test suite" |

The line is proposed only. It adds no scale or ownership beyond your own sentences, and I won't finalize it without your approval and your current CV wording.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). The employer is attributable and the posting is live and identical to your paste, so no failed-attribution entry was needed. This fed the contradictions row and RR5 |
| 2. Role-family sweep | skipped | The Datawright report you supplied fixes the market calibration and the pay and scope mismatch checks (role reality, RR1, RR2) |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I can save this as `tuesday-dossier.md` if you want a record to build on.

## Upgrade menu

- Your location, work authorization and pay floor → R1 and R2 close, and the hard-gates line becomes definite.
- A CV or role dates, plus a sanitized dbt lineage graph, Airflow DAG or Great Expectations suite → R3 through R8 can rise from `medium` toward `high`.
- Answers to G2 and G3 → R10 and R11 resolve, or stay carried as `important`-tier gaps.
- Any BigQuery exposure → R9's bridge strengthens or is confirmed as a plain gap.
- A hiring manager's name → the scope read and which of your stories to lead with.
- A deeper research pass on Pellucid Learning (leadership changes, hiring patterns, public employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

Questions (three):

Q1 (R1, R2) — Do the role's terms, remote from within the US or the Denver office at $148,000–$166,000, work for you, and if either doesn't, which one?

Q2 (G2, G3) — Which source systems did you personally ingest into the warehouse at the payroll company, and what, if anything, did you agree with the analysts using that data about schemas or freshness?

Q3 (G1) — Have you touched BigQuery in any form, such as a side project, a migration or queries on someone else's project, and what did you do?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.