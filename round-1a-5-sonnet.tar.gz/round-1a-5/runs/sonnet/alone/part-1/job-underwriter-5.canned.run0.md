Checking that the posting and company page are live and match what you pasted, then I'll write the assessment.
**Yes, it's worth applying, on two conditions only you can confirm (R1 and R2, both hard gates). Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery warehouse); unclear: R10 (App and CRM ingestion), R11 (Data contracts for analysts)

R9 is a credible bridge, its limit named; R10 and R11 are not yet shown by the payroll background.

**Opportunity ledger.** The role looks sound and its terms are visible. Pay is stated and sits inside the market band (RR2), and the posting is live and matches the company's own page (RR5). The team and ownership (RR1), equity terms (RR3) and reporting line and first-year outcomes (RR4) are unstated.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You are US-based and authorized, and remote (US) or Denver works for you (R1).
  2. The $148,000–$166,000 range clears your floor (R2).
  3. BigQuery is framed honestly as new to you, never as experience (R9).

  RR1 should also verify in the loop.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026). The funding figure is the company's own statement; I did not verify it elsewhere | `[grounded]` About page fetched via search result |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` careers page |
| Stated requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` careers page |
| Working pattern | Remote (US) or Denver office | `[grounded]` careers page |
| First-year outcomes | Not stated | `[grounded]` careers page silent |
| Scope read | One person's mandate spans two source systems, the warehouse and the contracts. That may be wider than a single domain if this is the sole data engineer. The posting doesn't say | `[inferred]` from the posting's mandate against the report's typical scope |
| Market calibration | Senior Data Engineer, Series B–D: base median $151,000, interquartile range $139,000–$163,500. "Senior" typically means 5–8 years, and typical scope is one domain's pipelines with no direct reports. The posting's range starts $3,000 below that median and tops out $2,500 above the upper quartile. Your 6 years sit inside the 5–8 span. This is the report's band, not this employer's offer | `[grounded]` Datawright 2026 report (n=2,310) as supplied, and posting range; `[grounded]` your stated 6 years |
| Unknowns | Team size and who owns what today; equity terms; hiring manager (none named); reporting line; whether BigQuery is already live | `[grounded]` posting silent |
| Contradictions | None between the posting you pasted and the live careers page, which is marked "Accepting applications"; the About page agrees on stage and size | `[grounded]` both pages fetched |

## Evidence map

The CV was not provided. Your background typed into the chat counts as self-report, so rows stop at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization were not stated, so nothing grades the row. The gate is neither met nor failed on what I have | `[grounded]` posting; your constraints not given | Question R1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You gave no pay floor. The range is stated, so only your floor is missing | `[grounded]` posting; floor not given | Question R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Self-report with no inspectable artifact yet, so `medium`. The CV is unseen, so its presentation is unchecked | `[grounded]` your prose background | An inspectable artifact would raise it (see upgrade menu) |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Same self-report limit | `[grounded]` your prose background | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. Same limit. Expect a probe on ownership: what was you versus the team | `[grounded]` your prose background | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | The posting asks for "a cloud warehouse" and Snowflake is one. The BigQuery specifics are in R9 | `[grounded]` your prose background and posting wording | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in the posting and you use it. Same limit | `[grounded]` your prose background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. "Set up" is your ownership claim, so expect a probe on scope and coverage | `[grounded]` your prose background | none |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The posting names BigQuery in its description, not its requirements list. Your dbt and warehouse work on Snowflake carries over. The limit: you have never used BigQuery, so nothing you've exercised covers its cost model or its specifics | `[grounded]` your statement that you have not used BigQuery; `[inferred]` that the Snowflake work carries over | Frame as adjacent; see G2 |
| R10 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background says nothing about source-system ingestion, and a payroll company probably ingests from somewhere. That is an inference, not a claim | `[grounded]` background silent; `[inferred]` the likely source systems | Question R10 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | You didn't mention contracts. The Great Expectations suite is a thread to pull, not a claim | `[grounded]` background silent; `[inferred]` the thread | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay (R1, R2, hard_gate) | hard_gate | Posting terms known; your location, authorization and floor are not | A mismatch on either would end the application however strong the fit elsewhere | n/a: a term you meet or don't | Your own statement | `[grounded]` posting terms; floor unstated |
| G2 | BigQuery (R9, important) | transferability | Snowflake and dbt carried the warehouse work; no BigQuery | The posting names BigQuery in its mandate, so it is the likeliest point to be probed | Evaluating or migrating a warehouse; a side project on BigQuery's free tier; cost-tuning work on Snowflake that mirrors partitioning or bytes-scanned thinking | A sanitized dbt docs site, or a small public project on BigQuery | `[inferred]` bridge from your Snowflake work; `[generic]` that a named platform is the usual probe |
| G3 | Data contracts (R11, important) | discovery | The GE suite is the only adjacent thread | The posting names analysts as its customers for the contracts | Agreed schemas or SLAs with analysts; breaking-change processes; GE expectations that analysts depended on | A sanitized contract, schema doc or expectation suite | `[grounded]` background silent; `[inferred]` the GE thread |
| G4 | App and CRM ingestion (R10, important) | discovery | Nothing stated about source systems | The mandate lists ingestion first | Ingesting from product databases, event streams, Salesforce-type CRMs or vendor APIs; connector work; CDC | A DAG excerpt or architecture diagram, sanitized | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the sole data engineer covering ingestion, the warehouse and the contracts, which is wider than the one domain the report calls typical | `[inferred]` from the mandate's breadth against the report's typical scope | Who else is on the data team today, and who owns the warehouse and the analysts' contracts? | unresolved |
| RR2 | Pay stated, inside the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range starts $3,000 below the $151,000 median and tops out $2,500 above the $163,500 upper quartile. It is not a seniority-compensation mismatch | `[grounded]` posting and pasted report | Where in the range would someone with 6 years and my stack land? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The grant may be small or hard to value; the posting gives no basis either way | `[inferred]` from the posting's silence on terms | What type and size of equity is offered, and on what vesting and valuation basis? | unresolved |
| RR4 | Reporting line and success measures absent | unknown | — | Posting names no hiring manager and no first-year outcomes | Success may be undefined for a role described as "build and run" | `[inferred]` from the posting's silence | Who would I report to, and what would a successful first year look like? | unresolved |
| RR5 | Posting live and consistent with the company's own pages | positive_signal | — | "Accepting applications." | The employer exists as described: stage, size and product agree across both pages. Funding is the company's own claim | `[grounded]` both pages fetched | Is the BigQuery warehouse already in production, or does this role build it? | noted |

## Application plan

Every row is a proposal. Nothing here, including the positioning advice, is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with your dbt project (about 180 models), the Great Expectations suite and Airflow, in outcome terms, with Snowflake named as your cloud warehouse | see R5, R7, R8, R6 | `[grounded]` your stated background | pending your approval |
| E2 | Say plainly that BigQuery is new to you and name the Snowflake work it builds on. Don't claim BigQuery experience | see R9 | `[grounded]` your statement | pending your approval |
| E3 | Add a data-contract or ingestion line only once your answers to R10 and G3 are confirmed | see R10, R11 | `[grounded]` rows R10, R11 | pending your approval |
| Q1 | Ask RR1, RR3, RR4 and RR5's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Settle R1 and R2 for yourself before spending application effort | see R1, R2 | `[grounded]` rows R1, R2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning Denver K-12 tutoring Series C 2026", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) to check your pasted text is live and genuine. Moved role reality's organization and contradictions rows; RR5. The employer-not-established entry was not triggered. Both pages are the company's own |
| 2. Role-family sweep | skipped | The pay report you pasted already fixes the market calibration, seniority span and typical scope this target feeds |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I can also save this as `tuesday-dossier.md` to carry forward.

**Upgrade menu**

- Your location, authorization and pay floor close R1 and R2. The decision likely simplifies to `go`, or to a stop at a failed gate.
- Your CV, or a sanitized dbt docs site, DAG code or Great Expectations config, would move R3 and R5–R8 toward `high` and let me check how the CV presents them.
- Your answers on source-system ingestion (R10) and analyst-facing contracts (R11) would resolve those rows or carry them as named gaps.
- The recruiter's answers on team structure, equity and reporting line would close RR1, RR3 and RR4.
- A hiring manager's name would let me look at their public professional footprint and shape which story to lead with.
- A deeper diligence pass on Pellucid Learning: funding and leadership changes, hiring patterns, employee reports and recent news. It would cost up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

R1 — Are you based in the US, authorized to work there without sponsorship, and happy with remote (US) or Denver?

R2 — What's your minimum base salary, and does $148,000–$166,000 clear it?

R10 — Did the payroll data you worked with arrive from app-style or CRM-style source systems, and did you own getting it into the warehouse? What did you build?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.