Reading the skill's reference files is done. Next I'll run the default research tier (company check and role-family salary sweep), then write the assessment.
## Decision snapshot

**Yes, apply. You meet R1, R3, R4, R5a, R6, R7 and R8 directly, and R2 and R5b still need confirming. `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R3, R4, R5a, R6, R7, R8 · unclear: R2 (metrics layer), R5b (clinicians)
- `important` — unclear: R9 (mentor two junior analysts)
- `preferred` — adjacent: R10 (healthcare data experience (HIPAA))

R2 — your Looker build suggests it, but metric ownership is unstated; R5b — no evidence yet; R10 (`medium`) — a real bridge with a named limit.

**Opportunity ledger.** The role is sound on its face but unverified. Research could not run, so the employer is not established (RR1), pay and location are unstated (RR2), and three specializations sit under one title (RR3). Experiment context is unknown (RR4). One entry runs the other way: a junior team exists to mentor (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) your ownership of metric definitions is confirmed and framed truthfully (R2); (3) the healthcare bridge is framed as adjacent, never as healthcare or HIPAA experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app. Not independently verified this run | `[grounded]` JD header as you pasted it |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| First-90-days and first-year outcomes | None stated in the posting | `[grounded]` JD silence |
| Scope read | A senior individual-contributor post with informal mentoring. The JD says "mentor", not line-manage | `[inferred]` from the JD's verb choice |
| Market calibration | Not calibrated. The role-family sweep did not run and the posting states no pay, so I offer no band from memory | `[grounded]` evidence status row 2; JD silent on pay |
| Unknowns | Pay, location and remote policy; who owns data modelling; experiment volume and platform; whether clinicians sit in the roadmap process | `[grounded]` JD silence |
| Contradictions | None among the inputs you gave me | `[grounded]` JD against your background |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Own product analytics for the care-navigation app | must_have | direct | medium | none | Six years of product analytics, stated by you. The function matches; the domain differs, which R10 carries. No inspectable artifact yet, so expect a probe | `[grounded]` your stated background | A sanitized analysis or readout would raise to high |
| R2 | Define and maintain the metrics layer | must_have | unclear | low | discovery | You built Looker from scratch with 40+ governed dashboards, which suggests but does not state ownership of shared metric definitions | `[grounded]` your Looker claim; `[inferred]` that governance implies definition work | See G1 |
| R3 | Design and analyze A/B tests at scale | must_have | direct | medium | none | 30+ tests a year, including the pricing test behind an 11% retention lift, at a company with about 2M subscribers. A strong, specific claim, not yet inspectable | `[grounded]` your stated background | A sanitized test plan or readout would raise to high |
| R4 | Build self-serve dashboards in Looker | must_have | direct | medium | none | You built the Looker instance from scratch, with 40+ governed dashboards. Same JD tool, so no tool translation is needed | `[grounded]` your stated background | A dashboard inventory or screenshot would raise to high |
| R5a | Partner with product managers to turn analysis into roadmap decisions | must_have | direct | medium | none | You present monthly to the VP Product and write the monthly exec metrics memo | `[grounded]` your stated background | None |
| R5b | Partner with clinicians | must_have | unclear | none | discovery | Nothing in your background touches clinical stakeholders. Other domain experts you worked with may count | `[grounded]` silence in what you gave me | See G2 |
| R6 | 5+ years of product analytics | must_have | direct | medium | none | Six years. This is a length-of-experience requirement, so it is graded as fit, not as a gate | `[grounded]` your stated background | None |
| R7 | Expert SQL | must_have | direct | medium | none | Daily SQL on a Snowflake warehouse. "Expert" is a self-assessed word that interviews will probe | `[grounded]` your stated background | A sanitized query or model would raise to high |
| R8 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | A monthly metrics memo read by the exec team | `[grounded]` your stated background | A sanitized memo would raise to high |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | Nothing stated about mentoring or onboarding | `[grounded]` silence in what you gave me | See G3 |
| R10 | Healthcare data experience (HIPAA) is a plus | preferred | adjacent | medium | transferability | You handled GDPR and CCPA consumer PII and built the warehouse consent-state model. Limit: no patient or protected health data, no HIPAA safeguards, no clinical data standards | `[grounded]` your stated background; limit named | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R2, must_have) | discovery | A governed Looker build, but nothing says who defined the metrics or where | A `must_have` at `unclear`. Resolving it is the likeliest way to firm up the decision | Owning LookML or a dbt-style metric layer; writing the company's definition of retention or churn and getting teams to adopt it; settling metric disputes between product and finance | A metric dictionary, a LookML excerpt, a definitions doc | `[grounded]` no ownership detail in your input; `[inferred]` that it is the most probed gap |
| G2 | Clinician partnership (R5b, must_have) | discovery | No clinical stakeholders in your history | A `must_have` that may be probed hard in this domain | Working with dietitians, nutritionists, food-safety or other domain specialists; turning a specialist's concern into a test or a metric | A project brief or readout where a specialist shaped the analysis | `[grounded]` silence; `[generic]` that domain-expert partnership is the usual stand-in |
| G3 | Mentoring (R9, important) | discovery | Silent | An `important` row that is not yet a question, because it ranks below G1, G2 and the constraints question | Onboarding analysts, reviewing their SQL, pairing, running an analyst guild | A mentoring plan or review checklist | `[grounded]` silence |
| G4 | Healthcare data (R10, preferred) | transferability | A consent-state model and GDPR/CCPA PII handling | A preferred row. The bridge is honest only if its limit is stated every time it is used | The consent model's design, handling of access controls or data minimisation, any audit you supported | A sanitized consent-model doc | `[grounded]` your claim; `[inferred]` the bridge to HIPAA-style duties |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not yet established; research did not run | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. This reflects my unrun check, not a finding | `[generic]` pattern, not a claim about this employer | Can you point me at the role on your careers site, and who I would be interviewing with? | unresolved |
| RR2 | Pay, location and work pattern unstated | unknown | — | "Senior Product Analyst" (the posting you pasted gives no figure or location) | The figure may fall outside what you need, or the employer may simply not publish it. Withholding it is itself worth a question | `[inferred]` from the JD's silence | What is the salary range, and the location and remote policy? | unresolved |
| RR3 | Several specializations under one title | unknown | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | The role may fold analytics engineering, experimentation and BI into one analyst post | `[inferred]` from the JD listing three specializations | Who else works on the metrics layer and data modelling today? | unresolved |
| RR4 | Experiment context unknown | unknown | — | "experiment design at scale" | A care-navigation app may have less traffic, and more clinical review of tests, than a consumer subscription product | `[generic]` pattern, not a claim about this employer | How many experiments run per quarter, on what platform, and what review do clinical-pathway tests go through? | unresolved |
| RR5 | A junior team exists to mentor | positive_signal | — | "mentor two junior analysts" | The post sits inside a team with some analytics capacity | `[grounded]` JD states it | How is the junior analysts' work split today, and who manages them? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV and summary with the experimentation program: 30+ tests a year and the pricing test behind the 11% retention lift, using your own figures only | see R3 | `[grounded]` your stated background | pending your approval |
| E2 | Give the Looker build its own outcome bullet: built from scratch, 40+ governed dashboards | see R4, R2 | `[grounded]` your stated background | pending your approval |
| E3 | Present the consent-state model and GDPR/CCPA handling as adjacent privacy-engineering experience, with its limit stated. Do not write "healthcare data" or "HIPAA" as experience | see R10, G4 | `[grounded]` R10 row | pending your approval |
| W1 | Prepare a sanitized monthly metrics memo as a writing sample | see R8 | `[grounded]` R8 row | pending your approval |
| A1 | Confirm the live posting on the company's own careers page, and the recruiter's email domain, before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the register's verification questions in the loop, especially RR2, RR3 and RR4 | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Everything above, the table and any prose advice alike, is proposed. None of it is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst" and "Harborlight Health digital health Series C care navigation"; both were refused (search permission not granted). It would have moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range scope experimentation Looker"; refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'll send no further searches unless you allow them.

I can write `tuesday-dossier.md` with all of this whenever you want it.

## Upgrade menu

- Search permission → RR1 and RR2 can close, and role reality gets a real market calibration. A deeper pass after that (up to 5 more searches and 2 more fetches) is available on request.
- A link to the live posting, and the hiring manager's name → RR1, and the scope read and positioning in the plan.
- The salary range, location and remote policy, or your own floor and constraints → the hard-gates line stops reading "unknown".
- A sanitized test plan or readout → R3 to `high`. A dashboard inventory → R4 to `high`. A sanitized metrics memo → R8 to `high`. A query or model sample → R7 to `high`.
- An answer to G1 → R2 resolves or stays unclear. An answer to G2 → R5b resolves.

## Questions

1. **G1** — Did you own the definitions of shared metrics, such as retention or churn, in a governed layer (LookML, dbt or similar)? What did you define, and who adopted it?
2. **G2** — Which non-PM domain experts, such as dietitians, food-safety or operations specialists, did you work with, and did one ever change a test or a metric?
3. **Constraints** — Are there non-negotiables I should check against this role, such as a pay floor, location or remote, or work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.