I'll read the skill's reference files before building the assessment.
## Decision snapshot

**Yes, worth applying to, on conditions. Your UK base (R1) is unconfirmed and the employer is unverified (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7a · unclear: R7b (Designing price tests)
- `important` — unclear: R8 (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain)

R7b — test-design ownership unconfirmed; R8 — product-side work not mentioned; R10 — a credible bridge, its limit named.

**Opportunity ledger.** Employer and live posting are unverified because research did not run (RR1), pay is withheld (RR2), and direct reports are not stated, which is where your no-management history would matter (RR3). The duties are named concretely (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you are UK-based, R1; (2) the role and employer verify on Brindlemoor's own careers site, RR1; (3) pay is disclosed and clears your floor, RR2; (4) pet insurance is framed as an adjacent bridge, never as pet expertise, R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product; not independently checked | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, give recommendations to underwriting and product | `[grounded]` JD |
| Stated requirements | 4+ years pricing or actuarial analytics; strong SQL and Python; GLM; presenting to underwriting or actuarial leads; insurance a plus | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Scope read | Reads as an individual-contributor post: the JD lists no line-management duty and the title is "Analyst" | `[inferred]` from the JD's duty list and title |
| First-year outcomes | Not stated. Likely to include taking over the live rating model and the price-test pipeline | `[inferred]` from "build and monitor" and "design and read price tests" |
| Market calibration | Not given: the role-family sweep did not run, so no pay band is stated. A 4+ year requirement under a "Senior … Analyst" title sits in the mid-to-senior individual-contributor bracket, which your 5 years fit | `[generic]` role-family pattern, not a claim about this employer |
| Unknowns | Pay; contract type; start date; team size; direct reports; data and tooling stack; interview process | `[grounded]` JD silence |
| Contradictions | None between the JD and your account; the JD was not checked against Brindlemoor's own pages | `[grounded]` inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | low | hard_gate | The posting says "Fully remote (UK)". You have not stated where you live or your right to work. A UK employer is indirect context only | `[grounded]` JD; `[inferred]` UK base from your UK employer | Answer Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics at a UK motor insurer, the last 2 as senior, exceeds the 4 years. Self-reported, nothing inspected. Read as graded evidence, not a gate | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", confirmed and specific, with no inspectable artifact yet | `[grounded]` your background | A sanitised code sample or notebook would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. The scope is one book, not the whole motor portfolio | `[grounded]` your background | Sanitised model documentation (variables, validation, lift charts) would raise to `high` |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which meets the "underwriting or actuarial" wording | `[grounded]` your background | A sanitised review deck would raise to `high` |
| R6 | Build and monitor rating models | must_have | direct | medium | none | You built and maintained the young-driver GLM. What monitoring involved (tracking, refits, drift checks) is not stated, so none is claimed | `[grounded]` your background | none |
| R7a | Run price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team": the 14 counts tests | `[grounded]` your background | none |
| R7b | Design price tests (setup, split, readout method) | must_have | unclear | low | discovery | "Ran" does not say who designed the tests. Resolved downward until you say | `[grounded]` your wording; `[generic]` that running and designing a test are probed as separate skills | Answer Q2 |
| R8 | Recommendations for product, as well as underwriting | important | unclear | low | discovery | Underwriting-side work is covered by R5 and R7a. Nothing mentions product stakeholders | `[grounded]` your background silent on product | Folded into Q2 |
| R9 | Insurance experience a plus | preferred | direct | medium | none | 5 years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain (the product being priced) | preferred | adjacent | medium | transferability | Motor GLM pricing method carries over. Limit: no pet exposure. Pet rating typically turns on different factors than motor | `[inferred]` bridge from your motor GLM work; `[generic]` that rating factors differ by line | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Test design and product-side recommendations (R7b must_have, R8 important) | discovery | 14 tests run with underwriting; nothing on who set the test and control split, chose what to test, wrote the readout, or who besides underwriting received it | The JD says "design and read price tests"; which of those you did decides how the line is worded | Choosing segments or rate changes to test; setting the split or sample size; writing the readout; recommending roll-out or rollback; briefing a commercial or product team | A sanitised test plan, readout or results summary | `[grounded]` your wording; `[inferred]` that the answer could move R7b to `direct` |
| G2 | Pet-insurance domain (R10, preferred) | transferability | Bridge: motor GLM pricing method and test work. Limit: no pet exposure, so no pet claim patterns or rating factors. Strengthener: a short sanitised note on how your approach would carry to a pet book | Preferred only, so a minor risk; honest framing reads stronger than a stretched claim | Frequency and severity modelling, or any health- or medical-cost data you handled | A one-page note mapping your motor method to a pet-pricing problem | `[inferred]` bridge from your motor work; limit `[grounded]` your own statement |
| G3 | UK base (R1, hard_gate) | hard_gate | Posting says fully remote (UK); your location and right to work are not stated | A gate only you can settle; wording cannot solve it | Not applicable | None to attach | `[grounded]` JD and your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not established | risk_signal | medium | "Brindlemoor (insurtech)" | Research did not run, so this is unverified, not a finding. The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay withheld, your floor not given | unknown | — | The JD states no salary | The figure may fall above or below what you need. No band is given because the sweep did not run | `[grounded]` JD silence | What salary range is budgeted for this post? | unresolved |
| RR3 | People-leadership scope unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean sole owner or lead of a small team; the JD lists no line-management duty | `[inferred]` from the JD's duty list | Does this role have direct reports now or planned, and how big is the pricing team? | unresolved |
| RR4 | Duties named concretely | positive_signal | — | "build and monitor rating models, design and read price tests" | The mandate is defined, which makes it easier to judge fit | `[grounded]` JD | What would a good first six months look like in this role? | noted |

## Application plan

Nothing here is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV edit: open with the GLM rating model you built and maintained for the young-driver book, with SQL and Python daily beside it | See R4, R6, R3 | `[grounded]` your background | `resume_edits_pending_approval` |
| E2 | CV edit: "14 price tests run with the underwriting team last year", with "run" kept until Q2 shows more | See R7a, R7b | `[grounded]` your wording | `resume_edits_pending_approval` |
| E3 | CV edit: add presenting the quarterly pricing review to the head of underwriting | See R5 | `[grounded]` your background | `resume_edits_pending_approval` |
| E4 | Say in one cover-note sentence that your GLM pricing is motor-based and you have no pet exposure yet; claim no pet expertise | See R10, G2 | `[inferred]` bridge, limit named | pending your approval |
| A1 | Check the role on Brindlemoor's own careers page, and who is interviewing, before investing effort | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the RR2 and RR3 verification questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst"; the host refused both. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary remote"; the host refused it. It would have moved role reality's market calibration and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing"; the host refused it. It would have moved role reality's scope read and the plan's positioning |

## Dossier offer

If useful, I can write this up as `tuesday-dossier.md` to reuse later.

## Upgrade menu

- Search permission granted, so the three research targets can run: Brindlemoor and the live posting (RR1), a market band for RR2, and Odile Varga's public professional footprint for the scope read and positioning.
- Your actual CV: the presentation gaps (E1–E3) are checked against its wording, not against prose.
- An answer to G1, or a sanitised test plan or readout: R7b and R8 can move to `direct`.
- A sanitised code sample, model documentation or review deck: R3, R4 and R5 can move from `medium` to `high`.
- Your pay floor and other hard terms: RR2 gets compared against them, and the hard-gates line stops flagging that your constraints were not given.
- The salary range from the recruiter or the live posting: RR2 closes.

## Questions

- **Q1 (G3, R1):** Are you UK-based, with the right to work in the UK without sponsorship?
- **Q2 (G1, R7b, R8):** On the 14 price tests, which parts were yours (choosing what to test, how the test and control groups were split, reading the result), and did your recommendations go beyond underwriting?
- **Q3 (RR2):** Do you have a pay floor or other hard terms for this move, such as contract type or notice period?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.