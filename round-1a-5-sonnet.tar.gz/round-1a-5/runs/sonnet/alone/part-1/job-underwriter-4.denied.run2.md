I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**Yes, go for it · Status: `conditional_go`.** R2, R3, R4, R5 and R6 (the `must_have` rows) are all `direct`. Pet insurance and line management, the two things you flagged, are not listed requirements in the JD (see Role reality and RR3).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6
- `important` — adjacent: R8 (Recommendations to underwriting and product) · unclear: R7 (Monitoring rating models)
- `preferred` — direct: R9

R6 (`medium`) — you ran 14 tests, but whether you designed them is unconfirmed; R7 — "maintained" is not yet shown to mean monitoring; R8 — underwriting side evidenced, product side not; R1 — your UK base is not stated.

**Opportunity ledger.** The duties are specific and the hiring manager is named (RR5). The employer is unverified (RR1) and pay is unstated (RR2). Pet-specific expectations (RR3) and sign-off authority and team (RR4) are open.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you are UK-based and fine with fully remote work (R1, G1); (2) Brindlemoor's own careers page shows this role live (RR1); (3) you learn the salary range before investing interview time (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, pricing a pet-insurance product; existence not independently checked | `[grounded]` JD header |
| Mandate | Own pricing analytics; build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing; public footprint not researched | `[grounded]` your message |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Compensation | No figure in the JD as pasted | `[grounded]` JD |
| People management | The JD states no line-management or team-leadership requirement, so never having managed anyone is not a row | `[grounded]` JD silence |
| Scope read | Reads as an individual-contributor ownership role, since "Own" appears with no team or reports clause | `[inferred]` from "Own" against the JD's silence on team |
| First-90-days outcomes | Not stated | `[grounded]` JD silence |
| Market calibration | Not run, because the role-family sweep could not run; no band is given | `[grounded]` evidence status below |
| Unknowns | Salary; day-one pet-specific expectations; who signs off rate changes; team size | `[grounded]` JD silence |
| Contradictions | None found in the pasted JD against your background | `[grounded]` JD and your message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based ("Fully remote (UK)") | hard_gate | unclear | low | hard_gate | You haven't stated where you live or any working constraint. Your UK motor-insurer employment is indirect context only | `[grounded]` JD; your message silent on location | G1: confirm UK base and remote working |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years of pricing analytics at a UK motor insurer, the last two as senior analyst. This is self-report with no artifact yet | `[grounded]` your message | CV with dates would let this be checked |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. "Strong" is a depth claim with nothing inspectable. Roles like this often test depth by exercise | `[grounded]` your message; `[generic]` on exercises | Be ready to show a worked example on non-confidential data |
| R4 | GLM experience (including building rating models) | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book. Ownership is stated and the scope is one book | `[grounded]` your message | Sanitized model documentation would raise this to `high` |
| R5 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The underwriting side is evidenced and the actuarial side is not stated, which the "or" allows | `[grounded]` your message | A sanitized review deck would raise this to `high` |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. "Ran" is carried as stated, and designing them (hypothesis, test/control, sizing) is not confirmed, so the lower reading holds | `[grounded]` your message | G2 |
| R7 | Monitor rating models | important | unclear | low | discovery | You say "maintained", which may include monitoring but is not shown to. The lower reading holds | `[grounded]` your message | Not asked this turn; raise it later if it matters |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | discovery | Underwriting side evidenced through the tests and the quarterly review. Nothing stated about product stakeholders | `[grounded]` your message; JD wording | G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance is insurance. The JD's plus names insurance in general, not pet | `[grounded]` JD and your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Fully remote, UK (R1, hard_gate) | hard_gate | No statement of where you are based | An unsettled gate stays visible in the snapshot until answered | A one-line confirmation of your base and remote working | None needed | `[grounded]` your message silent |
| G2 | Design and read price tests (R6, must_have) | discovery | 14 tests run with underwriting; your design role not stated | A must-have row at `medium`; owning design and readout is the likely probe on a "design and read" duty | Choosing test and control groups; sizing; setting the success metric; writing the readout; the decision made from it | A sanitized test readout or design note | `[grounded]` your message; `[generic]` that interviews probe design ownership |
| G3 | Recommendations to product (R8, important) | discovery | Underwriting recommendations evidenced; product side silent | The JD names product as a recipient of your recommendations | Briefing a product owner on price or proposition effects; a pricing input to a product change | A sanitized recommendation paper or email | `[grounded]` JD wording; your message silent on product |
| G4 | Monitoring rating models (R7, important) | discovery | "Maintained" stated; monitoring practice not | A named duty, but an important row rather than a must-have | Tracking model performance over time; scheduled refits; drift or segment checks | A sanitized monitoring pack | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No search ran, so nothing is established either way | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Brindlemoor's own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | No pay figure in the JD as pasted | The range may or may not suit you. You haven't given a floor, and no market band was obtained | `[inferred]` from the JD's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Pet-specific expectations unstated | unknown | — | "pet-insurance product … insurance experience a plus" | The JD asks for insurance experience in general, so pet-specific knowledge may or may not be expected on day one. Pet pricing typically involves different rating factors from motor | `[grounded]` JD wording; `[generic]` on pet versus motor rating factors | How much pet-specific rating knowledge do you expect on day one, and how is it learned on the job? | unresolved |
| RR4 | Sign-off authority and team unstated | unknown | — | "Own pricing analytics" | It is unclear who signs off rate changes and whether the role is a team of one or part of a pricing team | `[inferred]` from "Own" against the JD's silence on decision rights and team | Who signs off rate changes, and who else is on the pricing team? | unresolved |
| RR5 | Specific, testable duties and a named Director-level manager | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The duties are concrete and the hiring manager is named | `[grounded]` JD and your message | What would a strong first six months look like in this role? | noted |

## Application plan

Everything here is proposed. The CV lines, the cover-note framing and the action rows are all pending your approval, and none of it is final until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV's top section with three items: the GLM rating model you built and maintained for the young-driver book; the 14 price tests you ran with the underwriting team last year; the quarterly pricing review you present to the head of underwriting. Keep "ran" until G2 is answered | see R4, R5, R6 | `[grounded]` your own description | resume_edits_pending_approval |
| E2 | Cover-note framing for the pet gap: "I haven't worked on pet insurance. I've built and maintained a GLM rating model for a motor insurer's young-driver book and ran 14 price tests with underwriting last year." Don't claim pet-specific knowledge | see RR3, R4, R6 | `[grounded]` your own sentences | resume_edits_pending_approval |
| A1 | Confirm your UK base and remote working | see R1, G1 | `[grounded]` R1 | pending your approval |
| A2 | Check that the role is live on Brindlemoor's own careers site before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| A3 | Don't volunteer line management as a gap. If asked, say plainly that you haven't managed anyone, then describe what you did own | The JD states no management requirement | `[grounded]` JD silence | pending your approval |
| Q1 | Ask RR2, RR3 and RR4's questions verbatim with the recruiter or Odile Varga | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Brindlemoor pet insurance" and "Brindlemoor careers Senior Pricing Analyst" were refused, so nothing was returned. They would have moved Role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | The search "senior pricing analyst pet insurance UK salary remote" was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | unavailable | The search "Odile Varga Director of Pricing" was refused. It would have moved Role reality's scope read and which story the plan leads with |

## Dossier offer

I can write this assessment to `tuesday-dossier.md` if you'd like a saved copy.

## Upgrade menu

- Your CV, or sanitized artifacts (GLM model documentation, a price-test readout, the quarterly review deck): R3, R4, R5 and R6 can rise from `medium` toward `high`.
- Your answer to G1 closes the R1 gate; G2 and G3 resolve R6's gap and R8.
- Search permission for this session: the three targets above would run, covering employer existence and live posting (RR1), a salary band (RR2), and Odile Varga's public professional footprint.
- A deeper pass on Brindlemoor (funding and leadership churn, public candidate reports, recent news): up to 5 more searches and 2 more fetches. Say the word and it runs once search is permitted.

**Questions**

G1 — Are you UK-based, and is fully remote working fine for you?

G2 — On the 14 price tests, which parts did you personally own (test and control design, sizing, the success metric, the readout), and what did underwriting decide as a result?

G3 — Have you given pricing recommendations to a product team or product owner, as opposed to underwriting? What was it, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.