Checking whether the posting and company are still live and match what you pasted, then I'll write up the assessment.
**Snapshot**

**Yes, it's worth applying, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery warehouse) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts)

R9: a credible bridge, its limit named; R10, R11: discovery gaps your answers could close.

**Opportunity ledger.** The role is sound on what you pasted. The pay is stated and sits in the market band (RR5). Nothing independent confirms the posting or the employer (RR1). The scope may be wider than the typical one-domain role (RR2). The reporting line and equity terms are unstated (RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and pay floor fit R1 and R2; (2) the posting and employer are confirmed live (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` your pasted About text, not independently checked |
| Mandate | Build and run the pipelines behind the reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years, SQL and Python, dbt and *a* cloud warehouse, Airflow or similar, data quality testing. BigQuery appears in the mandate, not the requirements | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Hiring manager | Not named | `[grounded]` posting |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | The mandate names three areas (ingestion, warehouse modelling, contracts), which may make this the main data engineering post | `[inferred]` from the JD's three areas against the report's one-domain norm |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500, 5–8 years typical, one domain, no reports. The posted $148,000–$166,000 starts $3,000 under the median and ends $2,500 over the upper quartile. Your 6 years sits inside the typical range | `[generic]` Datawright 2026 report (n=2,310, supplied by your recruiter); `[grounded]` JD range and your 6 years |
| Unknowns | Reporting line, team size, equity terms, who owns scope across the three areas | n/a |
| Contradictions | None between the JD and the About text as pasted | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and constraints weren't given, so the gate can't be settled | `[grounded]` JD terms; your constraints absent | R1/R2 question |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given. The range sits in the market band (RR5) | `[grounded]` JD; `[generic]` report band | R1/R2 question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company. Intake prose is the ceiling for `medium` | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Nothing inspected | `[grounded]` your background | offer: a sanitized model or script would raise to high |
| R5 | dbt | must_have | direct | medium | none | You built the project (about 180 models). Nothing inspected | `[grounded]` your background | offer: sanitized dbt docs or a lineage graph would raise to high |
| R6 | A cloud warehouse | must_have | direct | medium | none | The JD asks for *a* cloud warehouse and you used Snowflake. BigQuery is R9 | `[grounded]` JD wording and your background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. Whether you wrote the DAGs is unstated, so wording must not claim it | `[grounded]` your background | confirm ownership later |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your background | offer: suite listing or data docs would raise to high |
| R9 | BigQuery warehouse (in the mandate, not the requirements) | important | adjacent | medium | transferability | Carries over: a dbt-modelled Snowflake warehouse at scale. Limit: no BigQuery use. Engines differ in cost model, table layout and dialect details, which a BigQuery-based interview may probe | `[grounded]` your background; `[generic]` engine differences | G1 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | You've named Airflow and dbt, not the source systems or how data came in. Indirect context only | `[grounded]` background silence | G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations suite is adjacent. Contracts between producers and consumers aren't evidenced | `[inferred]` adjacency from the suite | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Strong dbt and Snowflake, no BigQuery. The bridge is the dbt modelling, and the limit is warehouse-specific tuning | BigQuery is named in the mandate, so a probe is likely and the answer should be candid | A dbt project you've pointed at another engine, or a cross-warehouse migration | A small sample dbt project run on BigQuery (a work sample, pending your approval) | `[grounded]` JD mandate and your background; `[generic]` that such roles probe the stack |
| G2 | App and CRM ingestion (R10, important) | discovery | Pipelines and Airflow stated; sources and ingestion method not | It's the first item in the mandate | Pulling from a product database or event stream; a CRM sync or export; handling source schema changes | A pipeline diagram or DAG listing, sanitized | `[grounded]` background silence |
| G3 | Data contracts (R11, important) | discovery | Great Expectations suite stated; nothing on agreed schemas or SLAs with producers or analysts | The JD says analysts depend on them | Agreeing field definitions or freshness expectations with analysts; alerts when a source broke a field; documented, tested dbt models analysts relied on | The suite, data docs, or a sanitized contract or expectations file | `[grounded]` background silence; `[inferred]` that your suite is the nearest evidence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting and employer not independently confirmed | unknown | — | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The pasted texts are consistent with each other, but no independent check ran | `[grounded]` pasted texts; research unavailable | Can you confirm the role is open on your careers site, and who I'd interview with? | unresolved |
| RR2 | Scope may span the whole stack | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | Three areas against the report's one-domain norm may mean one engineer covers all of them. Low, because the phrase "behind our tutoring platform's reporting" can also describe one domain | `[inferred]` JD against the `[generic]` report norm | How many data engineers are on the team, and which of ingestion, modelling and contracts would I own alone? | unresolved |
| RR3 | No hiring manager or reporting line | unknown | — | "The posting names no hiring manager" | The reporting line may sit in data, engineering or finance, which shapes scope and growth | `[grounded]` posting silence | Who would I report to, and where does data sit in the org? | unresolved |
| RR4 | Equity unspecified | unknown | — | "plus equity" | Grant size, vesting and strike aren't stated, so total pay can't be compared with the report's base-only figures | `[grounded]` JD wording; `[generic]` that the report covers base only | What is the equity grant range, vesting schedule and strike for this level? | unresolved |
| RR5 | Pay stated and in the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range straddles the median and reaches slightly above the upper quartile, so there's no seniority-pay mismatch | `[grounded]` JD figure; `[generic]` report band | Where in the range would my experience place me? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask your recruiter to confirm the role is open and who you'd interview with | RR1, RR3 | `[grounded]` register | pending your approval |
| E1 | Summary line: "Built the dbt project (about 180 models) on Snowflake; pipelines orchestrated with Airflow; set up the Great Expectations test suite." No Airflow ownership claim is made | R5, R7, R8; each clause traces to your sentence | `[grounded]` your background | resume_edits_pending_approval |
| W1 | A small sample dbt project run on BigQuery, labeled as a sample, never as work experience | G1 | `[grounded]` G1 row | pending your approval |
| Q1 | Ask the RR2, RR3 and RR4 questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A2 | Frame BigQuery as "new to me, with the dbt modelling carrying over", never as experience | R9 limit named | `[grounded]` R9 row | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Pellucid Learning senior data engineer careers Denver" and fetches of pellucidlearning.com/careers/senior-data-engineer and pellucidlearning.com/about were all refused. It would have moved the organization and contradictions rows and RR1 |
| 2. Role-family sweep | skipped | Your recruiter's pay report is in hand and fixes the market calibration and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there's no query to form |

## Closing

I can save all of this as `tuesday-dossier.md` if you'd like to keep it or reuse it later.

**Upgrade menu**

- Your location and pay floor: R1 and R2 become met or failed, and the status can move to `go` or `no_go`.
- Your CV, plus a sanitized dbt docs page, a Great Expectations suite listing or a DAG listing: R4, R5, R7 and R8 can rise to `high`.
- Answers to G2 and G3: R10 and R11 firm up or become real gaps.
- A sample BigQuery dbt project: narrows R9's limit.
- The recruiter's confirmation and a manager's name: RR1 and RR3 close, and the manager's public footprint could then be researched.
- Permission for web search and fetch: I could rerun the careers-page and About-page check, which feeds RR1.

**Questions**

R1, R2: Where are you based, so I know whether Remote US or the Denver office applies? What's the lowest base salary you'd accept, and are there any other non-negotiables?

G3: At the payroll company, did analysts or other teams depend on agreed definitions, schemas or freshness expectations that you set up or enforced, perhaps through your Great Expectations suite? What did you own, and what happened when something broke?

G2: What source systems fed your pipelines (application database, events, a CRM or other SaaS), how did data get in, and which parts did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.