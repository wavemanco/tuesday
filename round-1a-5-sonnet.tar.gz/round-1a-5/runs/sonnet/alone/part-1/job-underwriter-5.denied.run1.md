Still reading the skill's reference files for the snapshot and research-accounting formats. Then I'll write the assessment.
**Yes, worth applying, with conditions. Status: `conditional_go`.** The six `must_have` rows R3, R4, R5, R6a, R7 and R8 are `direct` on your account. The one real gap is BigQuery (R6b), which is a bridge and not a block.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Pay $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6a, R7, R8
- `important`: adjacent: R6b (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts for analysts)

R6b — a credible bridge, its limit named; R9, R10 — evidence may exist in your payroll work, not yet stated.

**Opportunity ledger.** The role is plausibly sound but under-specified. Team size and reporting line are unknown (RR2, RR5). Equity terms are unstated (RR3). The stated salary is a positive signal (RR4). The employer and live posting could not be checked here (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Pay $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify on the company's own careers site (RR1); (2) your location and pay floor fit the posting's terms (R1, R2); (3) BigQuery is framed as adjacent and never claimed as experience (R6b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, Denver, founded 2016, 264 employees, Series C ($52M, February 2026) | `[grounded]` company page you pasted; not independently checked (see Evidence status) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD |
| Location and pay | Remote (US) or Denver office; $148,000–$166,000 plus equity | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated in the posting | `[grounded]` JD silence |
| Scope read | The mandate runs from ingestion through the warehouse to the contracts, which may be broader than a single-domain remit | `[inferred]` from the JD's three-part mandate against the report's norm below |
| Market calibration | The report puts a Senior Data Engineer at Series B–D companies at a base median of $151,000, interquartile range $139,000–$163,500, usually 5–8 years, one domain's pipelines, no direct reports. The posting's range runs $148,000–$166,000: above the median at its midpoint, and its top sits just over the interquartile range's upper end. No seniority-pay mismatch. The band is not this employer's offer. | `[generic]` Datawright 2026 report you supplied (n=2,310); `[grounded]` JD for the posted range |
| Unknowns | Team size and reporting line; equity type and amount; when the role opened; whether the base is the whole cash component | — |
| Contradictions | None between the pasted JD and the pasted company page | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and US work eligibility were not stated, so the gate is not established. Confidence is `none` because no constraint was given to grade. | `[grounded]` JD terms; your constraints not provided | Gate question below (Q1) |
| R2 | Pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor was not given, so the posted range cannot be checked against it. | `[grounded]` JD range; floor not provided | Gate question below (Q2) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Typed prose is a lead until probed, hence `medium`. | `[grounded]` your stated background | Offer a résumé or LinkedIn date range to raise to `high` |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated, with no artifact yet | `[grounded]` your stated background | A sanitized query or repo sample would raise to `high` |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Ownership and scale are both stated. | `[grounded]` your stated background | A sanitized model DAG or project structure would raise to `high` |
| R6a | A cloud warehouse | must_have | direct | medium | none | The JD requirement is "dbt and a cloud warehouse". Snowflake is a cloud warehouse. | `[grounded]` JD requirement text and your stated background | None |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated, matching the JD's named tool | `[grounded]` your stated background | A sanitized DAG sample would raise to `high` |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. | `[grounded]` your stated background | A suite outline or coverage numbers would raise to `high` |
| R6b | BigQuery as the warehouse | important | adjacent | medium | transferability | You have never used BigQuery. Snowflake plus dbt carries over: the modelling, testing and orchestration are the same work. The limit is that you have not run BigQuery's cost, partitioning or slot behaviour. | `[inferred]` bridge from Snowflake and dbt experience; `[generic]` that dbt skills transfer across warehouses | Gap queue G1 |
| R9 | Ingestion from the app and the CRM | important | unclear | low | discovery | Your sources at the payroll company were not described, so the match to app events and a CRM is unknown. | `[grounded]` your background is silent on source systems | Gap queue G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing stated on analyst-facing contracts or schema agreements. Your dbt and Great Expectations work may count. | `[grounded]` your background is silent on this | Gap queue G3 and Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6b, important) | transferability | Snowflake plus dbt at scale, no BigQuery | The JD names BigQuery, so the bridge and its limit decide how you present this | Anything run on BigQuery, even a side project or a course; Snowflake cost and performance tuning you did; a warehouse migration you worked on | A small BigQuery project you build and can show, or sanitized tuning notes | `[inferred]` bridge from your stack; `[generic]` that a named warehouse is probed in interviews |
| G2 | Ingestion from app and CRM (R9, important) | discovery | The sources you ingested are unstated | Matching source types shows the role is familiar ground | Product or event data into a warehouse; Salesforce or HubSpot extracts; third-party API connectors | An architecture diagram or a sanitized pipeline list | `[grounded]` your background is silent on sources; `[generic]` that these two source types are common in this kind of stack |
| G3 | Data contracts (R10, important) | discovery | Great Expectations and dbt tests are stated, but not whether analysts consumed agreed schemas | "The data contracts our analysts depend on" is the JD's own phrase, so the framing matters | Agreed schemas or SLAs with analysts; breaking-change processes; dbt contracts or exposures | A sanitized contract or schema doc | `[grounded]` JD phrase and your silence on it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Series C ($52M, February 2026)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. In this run the check did not run, so this is unverified, not failed. | `[generic]` pattern, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope may span ingestion to contracts with no team stated | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | You may be the sole or first data engineer, a broader remit than the report's one-domain norm | `[inferred]` JD scope against the `[generic]` report norm | How many data engineers are on the team, and what does this role own versus share? | unresolved |
| RR3 | Equity unspecified | unknown | — | "plus equity" | The grant may be small or may vest on unfavourable terms; the base may be the more reliable number | `[inferred]` from the JD naming equity without any terms | What is the equity type, amount and vesting schedule? | unresolved |
| RR4 | Salary stated within the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The posting is transparent, and the range sits around the report's median | `[grounded]` JD range; `[generic]` report band | Where in this range would someone with six years of experience land? | noted |
| RR5 | No hiring manager and no posting date | unknown | — | "The posting names no hiring manager" | The reporting line may not be settled, or the posting may be stale | `[inferred]` from the missing manager and date | Who is the hiring manager, and when did this role open? | unresolved |

## Application plan

Every row is proposed. Nothing becomes résumé or outreach text until you approve it, and that covers the advice as well as the table.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the dbt project (about 180 models), the Great Expectations suite you set up, and the Airflow orchestration, ahead of the payroll domain | see R3, R5, R7, R8 | `[grounded]` your background | pending your approval |
| E2 | State BigQuery honestly as new: "dbt and Snowflake at scale, with the same modelling, testing and orchestration". Do not claim BigQuery use. | see R6b | `[grounded]` R6b row | pending your approval |
| A1 | Confirm the posting is live on the company's own careers site, then apply | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the RR2, RR3 and RR5 questions in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Pellucid Learning online tutoring K-12 Denver Series C senior data engineer" and tried to fetch pellucidlearning.com/careers/senior-data-engineer. Both calls were refused because permission was not granted. That left the employer and live-posting check undone, which is why RR1 is open. |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market calibration line and the mismatch check. |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form. |

## Upgrade menu

- Your US location, work eligibility and base-pay floor: R1 and R2 move from `unclear` to met or failed.
- A sanitized dbt DAG, Airflow DAG, or Great Expectations suite outline: R5, R7 and R8 move to `high`.
- A description of your source systems, and of any analyst-facing schemas you maintained: G2 and G3 close.
- The hiring manager's name and the posting's open date: RR5 closes, and the positioning can be set for that reader.
- Permission for research calls: the careers-page check can run, which could clear RR1.
- A deeper research pass on Pellucid Learning (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches): say the word and it runs, once research permission is granted.
- A `tuesday-dossier.md` of this analysis, if you want one to keep or send on: I'll write it on request.

**Questions**

Q1 (R1, R2) — Which US state or city are you in, can you work in the US without sponsorship, and what is the minimum base you'd accept?
Q2 (G3, R10) — Have you agreed schemas, SLAs or breaking-change rules with analysts or other data consumers, and what did you own?
Q3 (G2, R9) — What source systems did your pipelines ingest, and were any product-event or CRM-style feeds?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.