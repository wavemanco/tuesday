I'll read the reference files the skill points to before building the assessment.
**Not yet, though the fit looks strong. The pasted JD says "Fully remote (UK)", but Brindlemoor's own careers page says "Leeds office four days a week" (R1, RR1). Status: `hold_pending_answers`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R7, R8 · adjacent: R9 (Recommendations for underwriting and product) · unclear: R6 (Monitor rating models)
- `preferred` — direct: R10 · adjacent: R11 (Pet-insurance product knowledge)

R6 (`low`) — monitoring not yet evidenced beyond "maintained"; R9 (`low`) — the underwriting side is evidenced and the product side isn't; R11 (`medium`) — a motor-to-pet bridge with its limit named.

**Opportunity ledger.** The role is live and attributable to the company's own site (RR4), but its working pattern contradicts the pasted JD (RR1). Pay is unstated (RR2), and team or management scope is unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** if Leeds four days a week is workable for you, or Brindlemoor confirms remote, the status moves to `conditional_go`, conditional on R6 and R9 being evidenced. If remote is non-negotiable for you and the Leeds pattern stands, R1 becomes `hard_gate_fail` and the status is `no_go`.

You said you've never worked on pet insurance (R11) and never managed anyone. The first is a preferred-tier bridge. For the second, neither the JD nor the careers page lists line management, so it has no requirement row (see the people-management row in role reality and RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; careers page fetched |
| Title and mandate | Senior Pricing Analyst; own pricing analytics for the pet-insurance product (rating models, price tests, recommendations to underwriting and product) | `[grounded]` JD and careers page agree on title and mandate |
| Reports to | Director of Pricing (Odile Varga) | `[grounded]` careers page; JD names her as hiring manager |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both quoted; I have not resolved which applies |
| People management | Not stated in the JD or on the careers page | `[grounded]` absence in both texts |
| Compensation | Not stated in the JD | `[grounded]` JD |
| Scope read | A single-product ownership role under the Director of Pricing | `[inferred]` from "own pricing analytics" plus the reporting line |
| First 90 days / first year | Not stated | `[grounded]` JD silence |
| Market calibration | UK senior pricing analyst, insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900 (survey n=612). This is a market band, not Brindlemoor's offer | `[generic]` role-family search result, 2026 pay survey snippet; the full page was not fetched |
| Unknowns | Which working pattern applies; salary; whether the role has any reports; who decides price changes | `[grounded]` JD and careers page silence |
| Contradictions | JD "Fully remote (UK)" against careers page "Leeds office four days a week" | `[grounded]` both texts |

## Evidence map

Your background was typed into the chat, so it counts as CV-equivalent self-report. Confidence tops out at `medium` until something inspectable backs it.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | No constraint of yours has been stated, so confidence grades an absent statement. Fit is `unclear` because the JD and the careers page disagree | `[grounded]` JD quote against careers page | Ask G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You stated 5 years of pricing analytics at a UK motor insurer, 2 of them as senior analyst. Specific but unconfirmed by any document | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily"; no artifact seen | `[grounded]` your background | Be ready to name one analysis done in each |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, with no inspectable proof yet | `[grounded]` your background | A sanitised model summary would raise this to `high` |
| R5 | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM | `[grounded]` your background | none |
| R6 | Monitor rating models | must_have | unclear | low | discovery | "Maintained" is the only word you gave. What monitoring you ran is not stated, and the CV can't be read as supplying it. I'm taking the lower band | `[grounded]` your wording; `[inferred]` that monitoring may sit inside maintenance | Ask G2 |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. "Ran" doesn't say which parts you designed and which you analysed, so the claim stays at what you wrote | `[grounded]` your background | Be ready to say what you designed against what you read |
| R8 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R9 | Turn results into recommendations for underwriting and product | must_have | adjacent | low | discovery | Underwriting-facing work is evidenced through R7 and R8. A product-facing audience isn't mentioned. I'm taking the lower band | `[grounded]` your background; JD wording | Ask G3 |
| R10 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R11 | Pet-insurance product knowledge (implied by the product named) | preferred | adjacent | medium | transferability | Motor rating, testing and presenting carry over. The limit is that you haven't worked on pet rating. Pet-specific rating factors are usually different from motor's | `[grounded]` your background; `[generic]` on pet-versus-motor factors | Name the bridge and its limit in the application |

R11's `requirement_source` is inferred. The JD only requires "insurance experience a plus".

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The JD and the careers page disagree; your own constraint is unknown | A gate that the inputs don't settle decides whether this application is worth making | A stated need to work from home; a commute you can or can't do to Leeds | Your own statement; the employer's answer | `[grounded]` the two texts |
| G2 | Monitoring rating models (R6, must_have) | discovery | "Maintained" the young-driver GLM; no monitoring detail | A must-have at `unclear` could move the status; the hiring manager has spoken publicly on monitoring | Actual-versus-expected tracking, drift checks, a refit trigger, a dashboard others used | A monitoring pack, dashboard screenshot, refit note (sanitised) | `[grounded]` your wording; `[inferred]` from her talk topic |
| G3 | Recommendations to product (R9, must_have) | discovery | Underwriting audience evidenced; product audience absent | The JD names both audiences | A pricing change taken to a product or commercial owner; a paper that changed a rate or a feature | A review deck or recommendation memo (sanitised) | `[grounded]` JD against your background |
| G4 | Pet-insurance knowledge (R11, preferred) | transferability | Motor-only | Preferred tier; the bridge is credible with its limit named | Any pet, small-animal or health-style rating exposure | A short written note on what you'd need to learn | `[grounded]` your background; `[generic]` that the domains differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts the posting (see R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The posting may be an older or different version, the pattern may have changed, or one source may be wrong. I can't tell which from here | `[inferred]` from two conflicting texts | The posting I saw says fully remote, and your careers page says Leeds four days a week. Which applies, and is it flexible? | unresolved |
| RR2 | Pay unstated | unknown | — | JD gives no salary | The figure may sit near the market band in role reality, or may not; the withholding is itself worth a question | `[inferred]` from the JD's silence against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Management and team scope unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The post may be an individual-contributor role, or may grow reports later | `[inferred]` from silence on both | Does this role have direct reports now, and is any expected within the first year? | unresolved |
| RR4 | Live posting on the company's own site, with title, mandate and reporting line stated | positive_signal | — | "Accepting applications… reports to the Director of Pricing" | The employer exists as described and the posting is live | `[grounded]` careers page fetched | Who would I work with day to day on pricing tests? | noted |

## Application plan

Every row is proposed and nothing is final until you approve it. That covers the resume wording (`resume_edits_pending_approval`) and the positioning advice alike.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Get the working-pattern answer before spending effort on the application | R1, RR1 | `[grounded]` the two texts | pending your approval |
| E1 | Put three lines first, in your own words: built and maintained the GLM rating model for the young-driver book; ran 14 price tests last year with the underwriting team; present the quarterly pricing review to the head of underwriting | R4, R5, R7, R8 | `[grounded]` your three statements | pending your approval |
| E2 | Say "motor insurance" plainly and write no pet-insurance claim anywhere; if you add a bridge line, state what carries over and name pet rating as new | R11 | `[grounded]` your background | pending your approval |
| P1 | Hiring-manager read: her public profile lists a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books, and six years as head of pricing analytics at Calloway Re. Getting R6 evidenced is the strongest use of your next answer | R6, G2 | `[grounded]` search result on her professional profile (snippet only); `[inferred]` on why R6 matters to this reader | pending your approval |
| Q1 | Ask the questions in RR1, RR2 and RR3 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Confirmed the posting is live and gave the contradicting working pattern: role reality's contradictions row, R1, RR1, RR4 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read from its snippet only. Moved the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read from its snippet only. Moved P1 and G2 |

I'd like to offer a one-time dossier file of this assessment, `tuesday-dossier.md`, if you want one to keep or hand on.

## Upgrade menu

- Your own constraints on location and pay would settle R1 and set RR2 against your floor.
- A sanitised model summary, monitoring pack, or test-results deck would raise R4, R5 or R7 to `high`, and would close G2 and G3.
- Brindlemoor's answers on the working pattern, salary, and reports would close RR1, RR2 and RR3.
- A deeper research pass on Brindlemoor (funding, leadership changes, public reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1 — Is fully remote a requirement for you, or could you work in Leeds four days a week? Where are you based?

G2 — On the young-driver GLM, what monitoring did you personally run (for example actual versus expected, drift checks, or refit triggers), how often, and who saw it?

G3 — Have you taken price-test results to a product or commercial owner as well as underwriting? What did you own, and what changed as a result?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.