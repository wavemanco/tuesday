Status: I've read the skill's rules. Next I'll run one search to check that Pellucid Learning and the posting are real and current, and then write the assessment.
**Worth applying to — yes, on conditions. Status: `conditional_go`.** The five `must_have` rows (R1, R2, R3, R5, R6) are all `direct` on what you've told me. I assumed you're evaluating, not yet applying.

# Job Underwriting — Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R9 (Remote US or Denver), R10 (Base pay $148,000–$166,000)
- `must_have` — direct: R1, R2, R3, R5, R6
- `important` — adjacent: R4 (BigQuery warehouse); unclear: R7 (Ingestion from app and CRM), R8 (Data contracts for analysts)

R4 — a credible bridge from Snowflake, its limit named; R7 and R8 — duties the posting names that your account hasn't touched yet.

**Opportunity ledger.** The pay is stated and concrete (RR4), but I could not verify the employer or the live posting (RR1). The manager and team are unnamed (RR2), the scope may be wider than the usual senior remit (RR3), and the equity terms are unspecified (RR5).

- **Hard gates:** none failed; unconfirmed: R9 (Remote US or Denver), R10 (Base pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location, work authorization and pay floor fit R9 and R10; (2) the employer and the live posting verify (RR1); (3) BigQuery is framed as adjacent to your Snowflake work, never as experience you have (R4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not independently confirmed (RR1) |
| Mandate | Build and run the pipelines behind reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| First 90 days / first year | Not stated | `[grounded]` JD silence |
| Scope read | Four duties under one title (ingestion, modelling, contracts, running it), against a typical scope of one domain's pipelines and no reports. The JD may be broader than usual, or it may describe one domain with several layers | `[inferred]` from the JD's duty list against the pay report's typical scope |
| Market calibration | For Senior Data Engineer at Series B–D, the report gives a base median of $151,000 and an interquartile range of $139,000–$163,500. The posting's $148,000 low end sits $3,000 under the median and inside the range. Its $166,000 high end sits $2,500 over the range's upper bound. Your 6 years fall in the report's typical 5–8 for "Senior". The figures describe the market, not this employer's offer | `[grounded]` the recruiter-supplied report (n=2,310) and the JD; the report is not independently checked |
| Unknowns | Hiring manager and team size; equity type and amount; on-call duties; where in the range offers land | — |
| Contradictions | None between the pasted JD and the pasted about-page text | `[grounded]` both pasted; neither could be checked against the live site |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company; no CV or artifact was inspected. This is a length-of-experience requirement, so it is graded as fit, not as a gate | `[grounded]` your account | CV would raise to high |
| R2 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both; nothing inspectable yet | `[grounded]` your account | a sanitized code sample would raise to high |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Snowflake is a cloud warehouse, so the requirement as written is met. The BigQuery-specific part is R4 | `[grounded]` your account | project docs or a model lineage screenshot would raise to high |
| R4 | Warehouse is BigQuery | important | adjacent | medium | transferability | Adjacent: the same dbt modelling work in a different warehouse. Limit: you have not used BigQuery, so its cost model and table-design choices are untested by you. Interviews for roles like this often probe warehouse-specific choices | `[grounded]` your account; `[generic]` interview pattern | see G1 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow orchestration of your pipelines; no artifact yet | `[grounded]` your account | a DAG excerpt would raise to high |
| R6 | Data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite. I don't claim dbt tests or other tooling, because you didn't state them | `[grounded]` your account | a sanitized suite config would raise to high |
| R7 | Ingestion from app and CRM sources | important | unclear | low | discovery | You didn't mention ingestion sources, and a payroll company likely has some, but I won't assume what | `[grounded]` silence in your account | see G2 |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing stated about agreed schemas or SLAs with downstream users | `[grounded]` silence in your account | see G3 |
| R9 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated your location or work authorization | `[grounded]` JD term; your constraints not given | see G4 |
| R10 | Base pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor wasn't stated. Compared with the report, the range sits at or above the median | `[grounded]` JD and report; your floor not given | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R4, important) | transferability | Strong dbt and warehouse work on Snowflake; no BigQuery use | The posting names BigQuery, so the swap is the first objection a reader is likely to raise | A small dbt project on BigQuery's free sandbox; any BigQuery exposure you've had that you haven't mentioned | A public repo or a short write-up of a dbt-bigquery project | `[grounded]` your account; `[generic]` that the warehouse swap is a likely objection |
| G2 | Ingestion from app and CRM (R7, important) | discovery | No ingestion experience stated | One of the three named duties; resolving it could lift R7 to `direct` | Loading data from a product database or a CRM such as Salesforce or HubSpot; managed connectors or custom extractors; handling schema changes and failed loads | A pipeline diagram or a DAG excerpt | `[grounded]` silence in your account |
| G3 | Data contracts (R8, important) | discovery | No contract-style work stated | One of the three named duties, and the least standard of them | Agreed schemas or freshness SLAs with analysts; tests that block bad data from reaching a dashboard; a versioned schema doc | A sanitized contract doc or a test config | `[grounded]` silence in your account |
| G4 | Location, authorization, pay floor (R9, R10, hard_gate) | hard_gate | Nothing stated | Either term could end this regardless of fit; the pay range alone says nothing about your floor | — | — | `[grounded]` constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The search I tried was refused, so I haven't confirmed the company or the live posting. If it doesn't confirm, the reasons stay side by side: a stale posting, a thin footprint, or not a live hiring employer. None is more likely than another | `[generic]` pattern, not a claim about this company | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Hiring manager and team unnamed | unknown | — | "The posting names no hiring manager" (your note) | The role may report into engineering, analytics or a data lead; the scope depends on which | `[inferred]` from the posting's silence | Who does this role report to, and how many people are on the data team today? | unresolved |
| RR3 | Four duties under one title | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may fold several specialties into one senior post. I take the lower severity because the stated pay sits at or above the report's median | `[inferred]` from the duty list against the report's typical scope | Which of these four duties is the main one, and what does the team already own? | unresolved |
| RR4 | Pay stated and at or above the market median | positive_signal | — | "$148,000–$166,000 plus equity" | The range is concrete, and the posting is transparent on the term most often withheld | `[grounded]` JD against the report | Where in this range would my experience place me? | noted |
| RR5 | Equity unspecified | unknown | — | "plus equity" | The grant could be material or nominal; the posting gives no type, amount or vesting | `[grounded]` the posting's silence | What equity is offered, in what form, and on what vesting schedule? | unresolved |

## Application plan

Everything here is proposed, and nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Make your top bullets state the dbt project's scale (about 180 models) and the Great Expectations suite, and name the warehouse as Snowflake. Add no BigQuery claim | R3, R6; the R4 limit | `[grounded]` your account | pending your approval |
| W1 | A small dbt project on BigQuery's free sandbox, with a short write-up that states only what you did | R4, G1 | `[inferred]` from the R4 gap | pending your approval |
| A1 | Ask the recruiter where in the range offers land and what the equity is, before you invest in the loop | R10, RR4, RR5 | `[grounded]` register rows | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR5's questions verbatim with the recruiter or interviewer | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for the company's careers page and funding was refused, so nothing was read. It would have moved RR1 and the contradictions row |
| 2. Role-family sweep | skipped | The pay report you pasted already fixes the market calibration line and the pay comparison in RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

I can write this up as `tuesday-dossier.md` for later use whenever you like.

**Upgrade menu**

- A CV, or sanitized samples (a dbt model and its docs, a DAG excerpt, your Great Expectations config) → R1, R2, R3, R5 and R6 move to `high`.
- Permission to run a search → RR1 can close or be confirmed, and the contradictions row gets a real check.
- Answers to G2 and G3 → R7 and R8 resolve; a BigQuery sandbox project → R4's limit narrows.
- The hiring manager's name → the scope read and RR2 sharpen.
- A deeper research pass on the company (funding history, leadership changes, public reports; up to 5 more searches and 2 more fetches) is available on request.

**Questions**

G4 — What are your location, work authorization and minimum base salary, and do they fit R9 and R10?

G2 — Have you built or owned ingestion from an application database or a CRM into your warehouse, and what did you use and how did you handle failed loads?

G3 — Have you set up agreed schemas, freshness SLAs or blocking tests between your pipelines and the analysts who depend on them, and who owned them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.