Checking the company, the market band and the hiring manager's public profile, then I'll write up the assessment.
**Yes, apply. Status: `conditional_go`.** You have no hard-gate failure, and the two must-haves where you're thin (R6, R7) are adjacent rather than absent. The conditions are at the end of the snapshot.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (£61,500–£67,000 salary)
- `must_have` — direct: R3, R4 · adjacent: R5 (SQL and spreadsheet modelling), R6 (Owning a forecast), R7 (Working with finance on billing or revenue data)
- `important` — direct: R9 · absent: R8 (Owning billing data)

R6 — a credible bridge, its limit named; R7 — revenue-side overlap, billing side untested; R8 — the gap you named yourself, no evidence either way.

**Opportunity ledger.** A concrete, open posting with a stated pay band (RR3). It leaves forecast ownership (RR1), the team behind the "Lead" title (RR2), the share options (RR4) and success measures (RR5) unstated.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the pay band work for you (R1, R2); (2) RR1 verifies that the forecast is shared with the CFO and that your role is a real step up, not a stretch you carry alone; (3) you frame R6, R7 and R8 as adjacent or not yet done, never as forecast or billing ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025. | `[grounded]` "About Quillfield" page, quillfield.co.uk/about |
| Mandate | Own CRM and billing data, build pipeline and renewal reporting for sales and finance, run the quarterly revenue forecast with the CFO | `[grounded]` posting, read from your link |
| Working pattern and pay | Bristol, hybrid, two days a week in the office; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe is listed publicly as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` profile "Tamsin Achebe — Head of Revenue Operations, Quillfield" |
| Scope read | A hands-on lead role. No team size or direct reports are stated, and a Head of RevOps already exists, so the role may sit under her | `[inferred]` from the posting's silence on team against the hiring manager's public title |
| First-year outcomes | None stated in the posting | `[grounded]` posting |
| Market calibration | £61.5–67k straddles the median (£64.2k) of a UK-wide revenue operations lead survey and sits inside its £57.8–70.4k interquartile range. The survey is not Bristol-specific, and the band is not Quillfield's offer. | `[generic]` Ledgerline 2026 pay guide (n=438); `[grounded]` posting for its own figure |
| Unknowns | Posting not confirmed on Quillfield's own careers page; team size; reporting line; forecast ownership; share option terms; success measures | — |
| Contradictions | None between the posting and the company's About page | `[grounded]` the two pages read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | "Bristol, hybrid: two days a week in the office" | hard_gate | unclear | none | hard_gate | You haven't said where you live or whether two office days work. Unconfirmed, so it stays a gate. | `[grounded]` posting; your constraints not given | Question in the closing block |
| R2 | "Salary £61,500–£67,000 plus share options" | hard_gate | unclear | none | hard_gate | No pay floor was given, so I can't check the band against it. | `[grounded]` posting; your constraints not given | Question in the closing block |
| R3 | "4+ years in revenue operations, sales operations or a similar analytics role at a B2B software company" | must_have | direct | medium | none | 5 years in sales operations, the last 2 running RevOps for the UK team. Confirmed and specific, but the CV isn't inspected. Worth checking that a B2B payments company reads as a software employer. | `[grounded]` your background; `[inferred]` on the payments-versus-software wording | none |
| R4 | "HubSpot or Salesforce administration" | must_have | direct | medium | none | Salesforce admin certified. The certificate isn't seen. | `[grounded]` your background | Offer: the certificate would raise it to high |
| R5 | "strong SQL and spreadsheet modelling" | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show use. "Strong" and "modelling" aren't evidenced yet. | `[grounded]` your background | Not asked this turn; a sanitized model or query would settle it (G3) |
| R6 | "experience owning a forecast"; "run the quarterly revenue forecast with the CFO" | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which is input to a forecast. You have never owned the company forecast, because finance did. | `[grounded]` your background and stated limit | See G1 |
| R7 | "experience working with finance on billing or revenue data" | must_have | adjacent | medium | discovery | The renewal dashboards touch revenue data. Whether you worked with finance on it, and on what data, isn't stated. Billing data is outside your experience, by your account. | `[grounded]` your background; `[inferred]` that the renewal work overlaps | See G2 |
| R8 | "own our CRM and billing data" (the billing half) | important | absent | none | capability | You have not worked on billing data. The CRM half is covered by R4. | `[grounded]` your stated limit | Closure path in G4 |
| R9 | "build the pipeline and renewal reporting our sales and finance teams run on" | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. The dashboards aren't inspected. | `[grounded]` your background | Offer: a sanitized screenshot would raise it to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | You run the pipeline review and finance owned the forecast. Carries over: pipeline inputs and review cadence. Limit: you have not owned the company forecast. | The posting names the forecast as a core duty, so this is the likeliest objection. | Producing the pipeline-based number finance used; a forecast-accuracy check; a commit or best-case roll-up you maintained | A sanitized pipeline review pack | `[inferred]` bridge from your pipeline review; `[generic]` that this is the likeliest objection for this title |
| G2 | Working with finance on revenue data (R7, must_have) | discovery | Renewal dashboards exist. The finance counterpart and the data behind them aren't described. | It decides whether R7 is a modest or a real gap. | Reconciling renewals with invoiced amounts; agreeing ARR definitions with finance; a month-end revenue check | A dashboard screenshot or a definitions note | `[grounded]` background silent on finance involvement |
| G3 | SQL and spreadsheet modelling (R5, must_have) | discovery | Frequency is clear. A built model isn't described. | It would raise R5 from adjacent. | A renewal or pipeline model with assumptions; a recurring SQL report others relied on | A sanitized query or workbook | `[grounded]` background silent on model building |
| G4 | Billing data (R8, important) | capability | No billing evidence, per your own account. | The posting has you owning that data. | Not applicable until evidence exists | — | `[grounded]` your stated limit |

G4's closure path is billing exposure. Ask your finance team for a read-only billing-adjacent task in your current job. Or carry it into the interview as a stated learning area, never as experience.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership split unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may share the forecast or may carry its accuracy alone | `[inferred]` from "with the CFO" against silence on who owns the model | Who owns the forecast model today, and what would I own versus the CFO? | unresolved |
| RR2 | Bundled scope under one title | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting…, and run the quarterly revenue forecast" | CRM, billing data, reporting and forecasting in one lead role priced near the market median; severity kept low because the pay sits inside the survey range | `[inferred]` from the posting's list; `[generic]` pay survey | Is there a team, and who does the role report to? | unresolved |
| RR3 | Concrete, transparent posting | positive_signal | — | "Salary £61,500–£67,000"; "4+ years…" | Stated pay, location and requirements suggest a defined role | `[grounded]` posting | What are the first-year priorities? | noted |
| RR4 | Share option terms absent | unknown | — | "plus share options" | Value depends on grant size, vesting and strike, none given | `[grounded]` posting silent | What is the grant size, vesting schedule and strike price? | unresolved |
| RR5 | No stated success measures | unknown | — | none; the posting has no outcomes | A demanding mandate with no stated definition of success | `[inferred]` from silence | What does success look like at six and twelve months? | unresolved |

## Application plan

Every row is proposed. I won't treat any of it as final, including the framing advice, until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put "ran revenue operations for the UK team (2 years)" and the rebuilt pipeline and renewal dashboards at the top of the CV, in your own facts | R3, R9 | `[grounded]` your background | pending your approval |
| E2 | Keep the Salesforce admin certification visible | R4 | `[grounded]` your background | pending your approval |
| E3 | Say plainly in your application that finance owned the forecast and that you haven't worked on billing data, then show the bridge: you run the monthly pipeline review with your sales director | R6, R7, R8 | `[grounded]` your stated limits | pending your approval |
| A1 | Confirm Bristol with two office days and the pay band suit you before investing in the loop | R1, R2 | `[grounded]` posting | pending your approval |
| A2 | Ask RR1, RR2, RR4 and RR5 verbatim in the interviews | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Prepare a sanitized one-page view of the renewal dashboard as a work sample | R9 | `[grounded]` your background | pending your approval |
| A4 | Lead with your path from sales operations to running RevOps. Her public profile shows sales operations in payments before RevOps. | Reader fit | `[grounded]` her public profile; `[inferred]` that the parallel will resonate | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers". It returned the "About Quillfield" page (quillfield.co.uk/about), which established the company. It returned no careers listing, so the posting isn't confirmed on Quillfield's own site. Moved role reality's organization and contradictions rows. |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software UK", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row. It gave a pay band only, not scope norms. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring manager row and A4. |

I can write `tuesday-dossier.md` from this assessment whenever you want it.

**Upgrade menu**
- Where you live and the lowest base you'd accept → R1 and R2 resolve, and the hard-gates line firms up.
- A sanitized pipeline review pack → G1's bridge strengthens.
- A sanitized renewal dashboard screenshot or definitions note → R9 reaches `high`, and G2 gets evidence.
- A sanitized SQL query or workbook → R5 can move up from adjacent.
- The Salesforce certificate → R4 reaches `high`.
- A link to the role on Quillfield's own careers page, or the recruiter's email domain → confirms the posting is live.
- The recruiter's answers on team, equity and success measures → RR2, RR4 and RR5 close.
- A deeper research pass on Quillfield (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**
1. R1, R2 — Is Bristol with two office days a week workable for you, and what is the lowest base salary you'd accept, share options aside?
2. G2 — In your renewal and pipeline work, who in finance did you work with, and on what data (renewal bookings, invoiced amounts, ARR)?
3. G1 — When finance built the forecast, did you supply the pipeline number it used, and did anyone check it against what closed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.