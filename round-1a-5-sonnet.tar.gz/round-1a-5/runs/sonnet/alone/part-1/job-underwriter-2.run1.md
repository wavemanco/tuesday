I'll read the skill's reference files first.
Search permission was denied, so this runs on what you pasted only. Every claim about the world below is labeled.

## Decision snapshot

**No, you're not wasting your time, but this posting is a reach. R1a, a must-have, is absent (no titled PM years) and no wording closes it. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1b (PM work without the title), R2 (Shipped API or platform products), R4 (Own the roadmap), R6 (Specs and delivery with two squads) · absent: R1a (3+ years PM experience, titled)
- `important` — direct: R5, R9 · unclear: R7 (Adoption metrics), R8 (Launches with sales and support), R10 (Agile delivery)

R1a — wording cannot recover the titled years; R1b, R2, R4, R6 — credible bridges, each limit named in the map; R7, R8, R10 — CV silent, answerable.

**Opportunity ledger.** The employer is unverified (RR1), the authority behind "own the roadmap" is unstated (RR2), and pay and location are withheld (RR3). One entry runs the other way: the two squads and the adoption metrics give the role concrete scope (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer verifies and the posting is live, RR1; (2) the recruiter confirms the 3+ years is not screened by title alone, R1a; (3) R7, R8 and R10 get truthful answers or are carried as stated risks; (4) the bridges R1b, R2, R4 and R6 are always framed as adjacent, never as product ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not independently checked. | `[grounded]` JD header; existence and stage unverified |
| Mandate | Own the roadmap for a partner-facing API platform; partner discovery; specs and delivery with two squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Seniority | A mid-level individual-contributor PM post: no "senior" or "lead" in the title, and the years bar is 3+ | `[inferred]` from the title and the 3+ years |
| Grading in the JD | Only the 3+ years is marked "must-have". The other requirements carry no grade, so the JD does not say which are firm. | `[grounded]` JD wording; the reading that they may flex is `[inferred]` |
| First-90-day and first-year outcomes | Not stated | `[grounded]` JD silent |
| Pay, location, work arrangement | Not stated | `[grounded]` JD silent |
| Unknowns | Decision rights over the roadmap; reporting line; pay; location; who the "integration partners" are (resellers, carriers, shippers' systems) | `[grounded]` JD silent on each |
| Contradictions | None inside the JD. Not checked against the company's own pages. | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, as titled years | must_have | absent | none | capability | You've never held a PM title, and the JD marks this requirement must-have. Titled-years bars are often applied literally by screens, a risk to name and not a gate. | `[grounded]` your statement; `[generic]` how such bars are screened | No wording closes it. Closure path: the bridge rows, a referral, or an internal move. See G4 |
| R1b | 3+ years product management experience, as the work itself | must_have | adjacent | medium | transferability | Overlap is real: requirements documents, roadmap-input sessions, coordinating engineers and PMs on custom builds. Limit: you fed product decisions and did not make them. | `[grounded]` your stated background, unprobed | Strengthen via G2 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You shipped 30+ client integrations of your employer's REST APIs, the consumer-and-implementer side. Nothing says you decided what the API itself does. | `[grounded]` your stated background; `[inferred]` that this is the implementer side | G1 (triage tool) and G2 |
| R3 | Technical fluency: API docs and schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs, integration architecture across 30+ integrations. Medium because nothing has been inspected. | `[grounded]` your stated background | A sanitized playbook extract would raise it to `high` |
| R4 | Own the roadmap | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions collecting client feedback for product. Limit: input, not prioritization or trade-off authority. | `[grounded]` your stated background | G2 |
| R5 | Run discovery with integration partners | important | direct | medium | none | Scoping workshops and quarterly feedback sessions are discovery with API consumers. Clients may differ from "partners", so expect a probe. | `[grounded]` your stated background; `[inferred]` client-to-partner equivalence | none |
| R6 | Write specs and drive delivery with two engineering squads | must_have | adjacent | medium | transferability | You wrote requirements and integration architecture and coordinated engineers. "Coordinated" is not owning a squad's backlog. | `[grounded]` your stated background | G2 |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | The CV is silent. A possible lead (a triage tool support agents adopted) is unconfirmed. | `[grounded]` CV silence; the lead is memory only, so it prompts a question and is not evidence | G1 |
| R8 | Coordinate launches with sales and support | important | unclear | low | discovery | Go-lives with clients are shown. Joint launch work with sales and support is not mentioned. | `[grounded]` CV silence on sales and support | G3 |
| R9 | Stakeholder management across engineering and customers (the sales leg is carried by R8) | important | direct | medium | none | Your own engineers, client engineers, product managers and clients over 30+ integrations | `[grounded]` your stated background | none |
| R10 | Agile delivery | important | unclear | low | discovery | The integration process you describe (UAT, go-live) says nothing about how you ran iterations. | `[grounded]` CV silence on agile practice | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Adoption metrics, and proof you shipped something with users (R7, R2) | discovery | A prior-context mention of an internal request-triage tool that support agents adopted, unconfirmed. Nothing else on metrics. | It could be your only shipped-product story, and it addresses two rows at once. | Choosing what the tool did; tracking who used it; a before-and-after on handling time or volume; a feature you changed after feedback | A screenshot, usage numbers, a short write-up, a demo | `[grounded]` lead recorded as unconfirmed; `[inferred]` that it spans R2 and R7 |
| G2 | Ownership of product decisions and delivery (R4, R6, R1b) | transferability | You contributed to roadmap input and coordinated builds. Adjacent evidence: feedback sessions, requirements, custom builds with PMs. Limit: no sign you set priorities or ran a backlog. Strengthener: one concrete case where your input or spec shaped something that shipped. | These must-haves are where a PM screen probes hardest. | A client request from your sessions that reached the product; a custom build whose spec you wrote; a trade-off you argued with product or engineering | A requirements document, an issue ticket or release note, the playbook | `[grounded]` your stated background; `[generic]` that these rows draw the sharpest probing |
| G3 | Sales and support launch work; agile practice (R8, R10) | discovery | Silent on both | Important rows, and cheap to answer if the evidence exists | Go-lives you coordinated with your own sales or support teams; sprint, standup or backlog work on custom builds | A launch checklist, a go-live runbook | `[grounded]` CV silence; not asked this turn, carried |
| G4 | Titled PM years (R1a) | capability | No PM title | A must-have the JD grades, and wording cannot fix it | None to recall. It is a title fact. | Not applicable | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Roadmap ownership without stated decision rights | unknown | — | "Own the roadmap for our partner-facing API platform" | Partner and sales requests may outweigh PM prioritization at a company this size. | `[generic]` pattern for Series B API platforms; the JD is silent on rights | Which roadmap decisions does this role make alone, and who can override them? | unresolved |
| RR3 | Pay, location and work arrangement withheld | unknown | — | No compensation, location or arrangement appears in the posting as pasted | Pay may or may not clear your floor, which isn't known. The market band was not obtained. | `[grounded]` posting silent; no `[generic]` band, since no search ran | What is the budgeted range for this role, and where is it based? | unresolved |
| RR4 | Concrete scope and success measures | positive_signal | — | "drive delivery with two engineering squads"; "define and track adoption metrics" | The role has defined resources and a measurable outcome. | `[grounded]` JD states both | What adoption metrics are tracked today, and which would this role own? | noted |

## Application plan

**Proposed resume edits — `resume_edits_pending_approval`.** Each line was checked clause by clause against your own sentences, and none is applied until you approve it.

| # | Current line | Proposed line | Why | Provenance | Status |
|---|---|---|---|---|---|
| E1 | "Ran quarterly roadmap-input sessions collecting client feedback for product" | "Ran quarterly sessions collecting client feedback as input to the product roadmap" | Keeps "input", so it can't drift into owning the roadmap (R4) | `[grounded]` your sentence | pending your approval |
| E2 | "Led 30+ client integrations of our REST APIs end to end" | "Led 30+ client integrations of our REST APIs end to end, from scoping workshops and requirements documents through UAT and go-live" | Surfaces spec-writing and delivery in the JD's terms (R6) without adding any fact | `[grounded]` your sentence | pending your approval |

**Positioning advice — pending your approval.** Lead the summary with what you can show: "Solutions engineer and implementation lead, 7 years, leading client integrations of REST APIs and bringing client feedback to product." Don't call yourself a product manager, and don't say you owned an API product or its roadmap, because R1a, R2 and R4 won't support it.

**Recruiter question — pending your approval.** Before investing in the loop: "Is the 3+ years of product management experience a strict requirement, or would 7 years leading API integrations and working with product managers be considered?"

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on Quartzline's own careers page before applying (RR1) | The standing check on an unverified employer | `[grounded]` RR1 | pending your approval |
| A2 | Ask the recruiter or hiring manager the R1a question above before sending a cold application | It may show early whether the years bar is firm | `[generic]` hiring pattern | pending your approval |
| A3 | Seek a warm introduction to the hiring manager | Stretch applications often travel better by referral | `[generic]` hiring pattern, not a fact about this employer | pending your approval |
| A4 | Run this application alongside two or three openings that count integration work as product-adjacent, such as technical product manager, partner or integrations product, or product operations roles | Your strongest wedge is API fluency plus client discovery. A posting that grades titled years as strictly as this one is the hardest entry. | `[generic]` role-family pattern | pending your approval |
| A5 | Ask RR1 to RR4's verification questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: a prior-context mention of a request-triage tool that support agents adopted, kept as a lead and used only to prompt G1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Quartzline logistics technology API platform careers" was refused. It would have fed role reality's organization and contradictions rows and RR1. |
| 2. Role-family sweep | unavailable | The search on platform API PM scope and pay for people moving from solutions engineering was refused. It would have fed the market calibration line and RR3's pay band. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

## Dossier offer

I can write all of this to `tuesday-dossier.md` if you want a file to keep or reuse.

## Upgrade menu

- Search permission granted → the posting and company check (RR1), the pay band against your floor (RR3), and a market calibration line. A deeper pass on Quartzline (funding, leadership churn, hiring patterns, news; up to 5 more searches and 2 more fetches) runs only on your say-so.
- A sanitized integration-playbook extract, or OpenAPI and integration-architecture notes → R3 to `high`.
- Anything inspectable on the triage tool → R7 and R2 move, and G1 may become your lead story.
- A spec, ticket, or release note where your input shaped what shipped → R4, R6 and R1b firm up.
- The hiring manager's name → positioning for that reader.
- Your location, pay floor and work-authorization constraints → hard-gate checks stop being unknown.

## Questions

1. **G1** — A prior conversation suggested you built an internal request-triage tool that support agents adopted. I haven't confirmed that, so is it right? If so, what did you decide about what it did, who used it, how did you know they adopted it, and is there anything to look at?
2. **G2** — Is there a case where something a client raised in your feedback sessions, or a custom build you specified, ended up in the product? What did you personally decide, write or prioritize, and what did the product managers own?
3. **Constraints** — What are your non-negotiables on location, work arrangement and pay floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.