I'll read the reference files the skill requires before building the assessment.
Both pages fetched. Here's the assessment.

## Decision snapshot

**Yes, it looks worth applying to: `conditional_go`.** R3, R4, R5, R6, R7 and R8, the six `must_have` rows, are `direct`. R1 and R2, the two gates, are unconfirmed because I don't have your location or pay floor.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery specifically); unclear: R10 (Data contracts), R11 (Ingestion from app and CRM)

R9 (`medium`) — a credible bridge, its limit named; R10, R11 — CV silent, one recall question each.

**Opportunity ledger.** The posting is clean on what it publishes: pay is stated and sits against the market band (RR1), and the stack is concrete (RR5). Equity (RR2), scope breadth (RR3) and the missing success outcomes and hiring manager (RR4) are unknowns, not warnings.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed, meaning you are US-based and authorized to work, or willing to work from Denver; (2) R2, with the range clearing your own pay floor; (3) R9 framed as adjacent, never as BigQuery experience; (4) RR3 and RR4 asked in conversation before you commit to a loop.
- **What would flip it to `no_go`:** a failed R1 or R2, meaning you are outside the US or the range is below your floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, Denver, founded 2016, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched; self-reported by the company |
| Mandate | Build and run reporting pipelines: ingestion from app and CRM, dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD, fetched careers page |
| Location | Remote (US) or Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity (equity terms unstated) | `[grounded]` JD |
| First-90-days and first-year outcomes | None stated | `[grounded]` JD silence |
| Scope read | Three areas (ingestion, warehouse modelling, contracts) in one post, which may be wider than a single domain | `[inferred]` from the JD's three areas against the report's typical scope of one domain's pipelines |
| Market calibration | Posted floor is $3,000 under the report's median base of $151,000; posted ceiling is $2,500 over the top of the $139,000–$163,500 interquartile range. Your 6 years sits inside the report's typical 5–8 for "Senior". Typical scope is one domain, no direct reports | `[generic]` Datawright 2026 report (n=2,310, Series B–D, US) as supplied by your recruiter; `[grounded]` JD for the posted figures |
| Unknowns | Team size and who else is on it; hiring manager; whether BigQuery is live or being built; equity terms | `[grounded]` JD silence |
| Stage | Assumed evaluating; you didn't state one | `[inferred]` from the question |
| Contradictions | None. The pasted JD and About text match the live pages word for word, and the posting shows "Accepting applications" | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The posting offers two arrangements. Your location and work authorization weren't given, so it can't be marked met. | `[grounded]` JD; your constraints not stated | Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The range is stated. Your pay floor wasn't given, so it can't be marked met. | `[grounded]` JD; your floor not stated | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, self-reported with no document yet. It is a length-of-experience requirement, not a gate. | `[grounded]` your background statement | none; dated resume would add inspectable proof |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated. "Strong" is untested, so expect a probe. | `[grounded]` your background statement | none |
| R5 | dbt | must_have | direct | medium | none | You built the company's dbt project, about 180 models, on Snowflake. | `[grounded]` your background statement | a sanitized lineage graph or project excerpt would raise to high |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. | `[grounded]` your background statement | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named as your orchestrator. The scope of what you owned in it isn't stated, so any resume line should say only what you did. | `[grounded]` your background statement | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the company's Great Expectations suite. | `[grounded]` your background statement | a sanitized suite config would raise to high |
| R9 | BigQuery specifically (the warehouse named in the mandate) | important | adjacent | medium | transferability | Adjacent: warehouse SQL plus dbt models on Snowflake. Limit: you have never used BigQuery, so its cost model, partitioning and access setup are unexercised. Tiered `important` because the requirements list says only "a cloud warehouse". | `[grounded]` your statement that you have never used BigQuery; `[generic]` SQL and dbt models generally carry across warehouses, with dialect, cost and tooling differences | G1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | In the mandate, not the requirements list. A Great Expectations suite is a thread, but nothing says agreed schemas with consumers existed. | `[grounded]` JD mandate; your background silent | G2 |
| R11 | Ingestion from the app and CRM | important | unclear | low | discovery | Your ingestion sources at the payroll company weren't described. | `[grounded]` JD mandate; your background silent | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt for 6 years; BigQuery never used | The posting names BigQuery as the warehouse, so it is the likeliest objection to a strong profile | Any BigQuery or GCP use, even a side project; a dbt-on-BigQuery sandbox project; an evaluation or migration discussion at your employer | A small repo with a README | `[inferred]` bridge from your Snowflake and dbt work; `[generic]` that a named warehouse you haven't used draws a question |
| G2 | Data contracts (R10, important) | discovery | A Great Expectations suite, with no stated agreements with consumers or upstream teams | The mandate names contracts as something analysts depend on | Agreed schemas or expectations with analysts or app teams; versioned schemas; tests or alerts on breaking changes that consumers relied on | A sanitized contract doc, dbt YAML excerpt or runbook | `[grounded]` background silence on consumer agreements |
| G3 | App and CRM ingestion (R11, important) | discovery | Sources at the payroll company not described | Ingestion is the first thing the mandate lists | Loading from a product database or a SaaS API; change-data-capture; custom loaders or managed connectors | A pipeline diagram or sanitized loader code | `[grounded]` background silence on sources |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated up front, in line with the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Transparent pay; the range straddles the report median, and its top is above the report's interquartile range | `[grounded]` JD and supplied report | Where in the range would someone with my experience land? | noted |
| RR2 | Equity unquantified | unknown | — | "plus equity" | The equity could be material or negligible | `[inferred]` from the posting's silence on grant size, vesting and valuation | What is the grant size, vesting schedule and latest valuation basis? | unresolved |
| RR3 | Scope breadth unclear | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The post may cover more than one domain, or sit in a small team | `[inferred]` from the JD's three areas against the report's typical one-domain scope | Who else is on the data team, and which of these three areas does this role own end to end? | unresolved |
| RR4 | No outcomes or hiring manager named | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Success may be undefined for a mandate that includes building | `[inferred]` from the posting naming no outcomes or manager | What would success look like at 90 days and at one year, and who would I report to? | unresolved |
| RR5 | Stack concrete; build state unknown | positive_signal | — | "a dbt-modelled warehouse in BigQuery" | The stack is real and named, but "build and run" leaves open whether the warehouse already exists | `[grounded]` JD | Is the BigQuery warehouse already in production, or being migrated or built? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle your location, authorization and pay floor before investing effort | see R1, R2 | `[grounded]` R1, R2 rows | pending your approval |
| E1 | Resume line: built the company's dbt project, about 180 models, on Snowflake | see R5 | `[grounded]` your background statement | pending your approval |
| E2 | Resume line: set up the Great Expectations data quality suite | see R8 | `[grounded]` your background statement | pending your approval |
| E3 | Say plainly that BigQuery is new to you and lead with Snowflake and dbt as the transferable base; never claim BigQuery experience | see R9, G1 | `[grounded]` R9 row | pending your approval |
| W1 | Optional: a small dbt-on-BigQuery sandbox project, stated as exactly what it is | see R9, G1 | `[inferred]` strengthener from the bridge's limit | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3, RR4 and RR5 verbatim with the recruiter or in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Nothing in the plan is final until you approve it, resume lines and strategy rows alike.

## Evidence status

Verified: none yet. Your background is intake self-report, so `medium` is the ceiling for now.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and "About Pellucid Learning" (pellucidlearning.com/about) to check the pasted text. Both match, and the posting shows "Accepting applications". Moved role reality's contradictions row. The funding and headcount are the company's own statements, not independently confirmed. |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes market calibration in role reality and RR1, so a search could not change either. |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form. |

I'm offering the `tuesday-dossier.md` file if you want a saved record of this analysis.

## Upgrade menu

- Your CV or LinkedIn → dated roles to firm up R3, and ownership details for R7.
- A sanitized dbt lineage graph or Great Expectations config → R5 and R8 to `high`.
- Your location, authorization and pay floor → R1 and R2 close, and the decision simplifies.
- A BigQuery sandbox repo → G1 narrows R9's limit.
- The hiring manager's name → role reality's scope read, and which of your stories to lead with.
- A deeper research pass on Pellucid Learning (funding and leadership churn, hiring patterns, public employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

R1, R2 — Where are you based and authorized to work, and what base salary floor would make this worth taking?
G1 — Have you used BigQuery or any other Google Cloud service in any capacity, even a side project?
G2, G3 — Which of your payroll-company pipelines ingested from an app database or an outside system's API, and did analysts or other teams rely on an agreed schema for any of them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.