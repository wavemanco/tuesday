I'll read the skill's reference files before building the assessment.
# Job Underwriting: Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Yes, worth applying to, on conditions: R3 to R8 are met on your stated experience, and the one gap that matters, BigQuery (R9), is a bridge from Snowflake. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148,000 to $166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery warehouse); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R9: a credible bridge, its limit named; R10 and R11: unrecovered, not absent; R1 and R2: waiting on your terms.

**Opportunity ledger.** The pay sits inside the pasted market band (RR3). The employer could not be checked against its live pages from here (RR1). Scope, reporting line and equity terms are open (RR2, RR4, RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000 to $166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Pellucid's own careers page (RR1); (2) the location and pay terms work for you (R1, R2); (3) BigQuery is presented as adjacent to your Snowflake work, never as experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not checked against the live site |
| Mandate | Build and run reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Seniority basis | "5+ years data engineering"; your 6 years sit inside the report's usual 5 to 8 for "Senior" | `[grounded]` JD and the Datawright report you supplied |
| First 90 days and first year | Not stated | `[grounded]` JD silence |
| Scope read | Three streams (ingestion, warehouse modelling, contracts) in one post. The report's typical scope is one domain's pipelines and no direct reports, so this may be wider than typical. It may equally be one domain described fully | `[inferred]` from the JD's three streams against the report's typical scope |
| Market calibration | Report band for Senior Data Engineer at Series B to D: median $151,000, interquartile range $139,000 to $163,500, n=2,310. The posted $148,000 to $166,000 straddles the median and tops the interquartile range by $2,500. Equity is unquantified | `[grounded]` report and JD figures; `[inferred]` the comparison |
| Unknowns | Team size and who else owns ingestion; reporting line (no hiring manager named); on-call expectations; equity terms; whether the roles of "build" and "run" include support rotations | `[grounded]` JD silence |
| Contradictions | None between the pasted JD and about text. Neither was checked against live pages (fetch refused) | `[grounded]` pasted texts compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not said where you are based or your work authorization, so the gate is neither met nor failed | `[grounded]` no constraint given | Gate question, closing block |
| R2 | Salary $148,000 to $166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor from you, and the equity is unquantified. The figure is inside the pasted band, but fit to your floor is unknown | `[grounded]` JD figure; no constraint given | Gate question, closing block |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, self-reported in your message and not yet probed. A years requirement is graded as experience, not as a gate | `[grounded]` your stated background | Offer a CV or LinkedIn history to raise to `high` |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily", stated and not yet inspectable | `[grounded]` your stated background | A repo or sanitized sample would raise to `high` |
| R5 | dbt | must_have | direct | medium | none | Built the dbt project at your employer, about 180 models. Specific and plausible; no inspectable artifact yet | `[grounded]` your stated background | Sanitized project structure or model DAG would raise to `high` |
| R6 | Cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the requirement as written is met | `[grounded]` your stated background | None |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in the JD and in your background | `[grounded]` your stated background | None |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite | `[grounded]` your stated background | A sanitized suite config would raise to `high` |
| R9 | BigQuery as the warehouse (inferred from the mandate) | important | adjacent | medium | transferability | Carries over: warehouse modelling in dbt at scale. Limit: you have not used BigQuery, so its cost model, partitioning and clustering choices are untouched ground. Strengthener: a small dbt-on-BigQuery project | `[inferred]` requirement from the JD's "dbt-modelled warehouse in BigQuery"; `[generic]` that BigQuery's cost model differs enough from Snowflake's to draw interview questions | See G1 |
| R10 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background says nothing on ingestion sources, which are the app's event data and a CRM here | `[grounded]` background silence | See G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is indirect context, since tests on data can sit near contracts without being one. Whether you agreed expectations with analyst consumers is unknown | `[grounded]` background; `[inferred]` the adjacency | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake plus dbt at about 180 models; no BigQuery use | The warehouse is named in the mandate; this is the most likely screening question | A personal dbt project on BigQuery's free tier or a public dataset; any BigQuery exposure through a cloud project or analyst-side querying | A repo or README of a small dbt-bigquery project | `[inferred]` bridge from Snowflake work; `[generic]` that a named warehouse tends to be probed |
| G2 | Ingestion from the app and CRM (R10, important) | discovery | Nothing on source systems | The mandate lists it first, so it may decide what you own day to day | Loading product events, API pulls from a CRM, managed ingestion tooling, change data capture from an application database | An architecture sketch, a DAG screenshot, a README | `[grounded]` background silence; `[generic]` that ingestion is often the first thing a new hire inherits |
| G3 | Data contracts (R11, important) | discovery | The Great Expectations suite may overlap; no stated agreement with consumers | The JD names analysts as dependants, so how you handled them is the likeliest probe | Agreed schemas or freshness expectations with analysts; breaking-change notice processes; tests that blocked a bad load | A sanitized contract doc or tests config | `[grounded]` background silence; `[inferred]` overlap with the test suite |
| G4 | Location, authorization and pay floor (R1, R2, hard_gate) | hard_gate | No terms stated | A failed gate caps the status however strong the rest is | Not applicable: a gate is met or not | None; your own statement is the evidence | `[grounded]` no constraints given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | The page I tried to read was not retrievable, so I have only your pasted text. Possible reasons, none ranked as likelier: a refused fetch on my side, a stale posting, a thin public footprint, or a posting not tied to a live hiring process | `[generic]` pattern, not a claim about this employer | Can you point me at this role on your own careers site, and who the interview loop would be? | unresolved |
| RR2 | Three streams in one post, ownership unclear | unknown | — | "Build and run the pipelines … ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | The post may cover more than one domain, or may be a domain described in full | `[inferred]` from the JD's three streams against the report's typical scope | Who else is on the data team, and which of ingestion, modelling and contracts does this role own alone? | unresolved |
| RR3 | Pay stated and inside the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The posted range is transparent and straddles the report median | `[grounded]` JD and report | Is the top of the range open to an applicant with six years' experience? | noted |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Value may be material at Series C, or may be a nominal grant | `[inferred]` from the JD naming equity without terms | What is the grant size, vesting schedule and strike price? | unresolved |
| RR5 | No hiring manager or reporting line named | unknown | — | "The posting names no hiring manager." (your note) | The data function may sit under engineering, product or finance | `[grounded]` posting silence | Who does this role report to, and what does the data team's roadmap look like? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Built the dbt project on Snowflake, about 180 models". Every word is yours; I added none | R5 | `[grounded]` your message | `resume_edits_pending_approval` |
| E2 | CV line: "Set up the Great Expectations test suite". It claims no more than you said | R8 | `[grounded]` your message | `resume_edits_pending_approval` |
| E3 | State BigQuery plainly as what you have not used, beside the Snowflake work it would build on. No wording makes it experience | R9 | `[grounded]` R9 row | pending your approval |
| W1 | A small dbt project on BigQuery (public dataset, README on the cost choices) | Narrows G1's limit | `[inferred]` strengthener derived from R9 | pending your approval |
| A1 | Confirm the posting on Pellucid's own careers page before investing effort | RR1 | `[grounded]` register | pending your approval |
| A2 | Ask RR2, RR4 and RR5 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. The map's claims are your self-report and sit at `medium` at best.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One fetch of the Pellucid careers URL was refused (permission not granted), so nothing was read. It would have moved the contradictions row and RR1 |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market calibration line and the pay comparison in RR3 |
| 3. Hiring manager's public footprint | n/a | No name given, so no query could be formed |

## Dossier offer

I can write this up as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Your location, work authorization and pay floor: R1 and R2 resolve, and the status likely moves to `go` or `no_go`.
- Permission to fetch Pellucid's careers page, or a pasted copy of the live page: RR1 closes.
- A sanitized dbt DAG, Great Expectations config or code sample: R3, R4, R5 and R8 can rise to `high`.
- An answer to G2 or G3: R10 and R11 firm up.
- The hiring manager's name once known: role reality's scope read and the plan's lead story sharpen.
- A deeper pass on Pellucid (funding, leadership churn, public employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

1. **R1, R2:** Do the location and pay terms work for you (remote US or Denver, $148,000 to $166,000 plus equity), and is there a location, authorization or pay-floor constraint the role would trip?
2. **G2:** Have you built ingestion from product-event or CRM sources, and what did you personally own?
3. **G3:** Have you agreed schemas, freshness or quality expectations with the analysts who consume your models, and what happened when one broke?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.