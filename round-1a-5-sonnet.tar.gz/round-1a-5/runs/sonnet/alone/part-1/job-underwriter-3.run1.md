I'll read the reference files the skill requires before building the assessment.
**No. This posting isn't worth pursuing as written. R1 and R2 are hard gates and both fail, so the status is `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R3 (Evenings and weekends when it matters) · hard_gate_fail: R1 (Base pay $70–85k), R2 (On-site in Austin five days a week)
- `must_have` — direct: R4, R5, R6, R7
- `important` — unclear: R8 (SEO and content), R9 (Brand and PR), R10 (Partnerships and sales ops), R11 (Team of one to start)

R1 — base sits under your floor; R2 — the office term conflicts with remote-only; R4, R5, R6, R7 — the paper match is real; R8, R9, R10, R11 — breadth your stated background doesn't speak to.

**Opportunity ledger.** Apart from your constraints, the posting folds seven functions into one person (RR3) beside always-on language (RR5) and success metrics left undefined (RR6). Its up-front pay and office terms (RR8) at least make the mismatch quick to see. The seniority-to-pay relationship (RR4) and the employer itself (RR9) are unverified.

- **Hard gates:** failed: R1 (Base pay $70–85k), R2 (On-site in Austin five days a week); unconfirmed: R3 (Evenings and weekends when it matters).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** R1 would need a base at or above your $150k floor, and R2 would need remote work from Portland. The posting says "no exceptions" on the office term. Rewording your application can't solve either gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one". None of this was checked outside the posting | `[grounded]` JD header; research did not run |
| Mandate | "Own all revenue growth end to end" across seven functions: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting and team | Reports to the CEO with a dotted line to the board. "A team of one to start" | `[grounded]` JD |
| Working pattern | On-site in Austin five days a week, "no exceptions". "Evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no amount, percentage or vesting given | `[grounded]` JD |
| Outcomes | No 90-day or first-year outcomes stated. "Success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | A "Head" title with no reports at the start and seven functions to run, which reads closer to a hands-on generalist seat than to leading a function | `[inferred]` from "team of one" against the seven-function list |
| Market calibration | Not established. The salary search was refused, so no market band is offered. Pay is compared with your floor (R1), not with a market range | `[grounded]` evidence status below |
| Unknowns | Budget and tooling, whether a team will be hired, equity size and terms, what "profitable" means in numbers | `[inferred]` from the JD's silence |
| Contradictions | None inside the posting. It was not compared with a careers page | `[grounded]` JD; target 1 unavailable |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay $70–85k, against your floor of $150k base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. Fit fails because the top of the range is $65k under it, and unquantified equity can't be read as base | `[grounded]` JD quote and your stated floor | Surface only; the employer changing the base is the only resolution |
| R2 | "On-site in our Austin office 5 days a week — no exceptions", against remote-only from Portland, no relocation | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. The JD rules out the exception your constraint needs | `[grounded]` JD quote and your stated constraint | Surface only; no workaround exists |
| R3 | "Evenings and weekends when it matters" | hard_gate | unclear | none | hard_gate | You stated no limit on hours, and the posting gives no frequency, so it can be neither met nor failed. Confidence is `none` because there is no statement of yours to grade | `[grounded]` JD quote, no constraint stated | Matters only if R1 and R2 ever resolve; RR5's question settles it |
| R4 | 8+ years of growth leadership | must_have | direct | medium | none | You state 9 years, as growth lead then Head of Growth. No artifact has been inspected, so `medium`: expect a probe on titles and dates. A length-of-experience requirement is not a gate | `[grounded]` your stated background | none |
| R5 | Paid acquisition | must_have | direct | medium | none | You state you owned paid, with a budget you controlled. Limit: you ran it with a team of 3–7, not solo | `[grounded]` your stated background | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. Confirmed and specific, with no inspectable artifact yet | `[grounded]` your stated background | none |
| R7 | Own revenue growth end to end | must_have | direct | medium | none | You state you scaled one company from $8M to $40M ARR over three years with a budget you controlled. Say "led", since a team of 3–7 was involved | `[grounded]` your stated background | none |
| R8 | SEO/content | important | unclear | none | discovery | Your background as stated names paid, lifecycle and experimentation, and is silent on SEO and content | `[grounded]` silence in your stated background | G2 |
| R9 | Brand and PR | important | unclear | none | discovery | Same silence | `[grounded]` silence in your stated background | G2 |
| R10 | Partnerships and sales ops | important | unclear | none | discovery | Same silence | `[grounded]` silence in your stated background | G2 |
| R11 | Run the function hands-on as a team of one | important | unclear | low | discovery | You have led teams of 3–7. Solo execution across seven functions is not shown either way, and the requirement is read from the posting's phrasing, not stated as a requirement | `[inferred]` from "a team of one to start" against your team history | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Hours expectation (R3, hard_gate) | hard_gate | The posting gives no frequency for evenings and weekends and you've stated no limit | Only the employer's own answer sets how often it applies, and it can't move the status while R1 and R2 stand | Not applicable; this is a term to confirm | The employer's written answer on frequency | `[grounded]` JD wording; `[inferred]` that it can't move the status |
| G2 | Breadth beyond paid and lifecycle (R8, R9, R10, important) | discovery | Nothing in your background as stated covers SEO/content, brand/PR, partnerships or sales ops | These are three of the seven functions in the mandate, so they would be probed if terms ever changed | Owning an organic or content channel, even briefly; running a launch with press; a reseller or integration partnership; owning a CRM-to-sales handoff | A channel report, a launch plan, a partner agreement summary | `[grounded]` silence in your background; `[generic]` that a seven-function mandate gets probed on its thin spots |
| G3 | Solo execution (R11, important) | discovery | You have led teams but not shown hands-on solo delivery | The posting prizes people who "don't need a bench" | A period before you had a team, or a stretch when you executed several functions yourself | A pre-team campaign or channel build | `[inferred]` from the posting's wording against your team history |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base below your stated floor (R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The stated range cannot meet a $150k base floor | `[grounded]` JD figure against your stated floor | What is the equity grant, as a percentage with its vesting terms? | confirmed |
| RR2 | Office terms against remote-only (R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting rules out remote work from Portland | `[grounded]` JD against your stated constraint | Is any version of this role open to remote work from outside Austin? | confirmed |
| RR3 | Seven functions bundled into a team of one | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | Several full roles sit under one title, which usually means the stated pay is set for fewer duties | `[generic]` bundled-specialization pattern; `[grounded]` the quoted list | Which of these seven functions are expected in the first year, and what budget and tools come with them? | unresolved |
| RR4 | Seniority and mandate against stated pay | risk_signal | medium | "8+ years growth leadership required" beside "$70–85k base" | The base may sit below what this mandate pays at market, with equity meant to carry the difference | `[inferred]` from the JD's seniority and scope against its base; no market band was looked up | How was the base range set, and how does it compare with what you've paid for this seniority? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work may be routine, with no stated limit on how often | `[inferred]` from "just who we are" and the missing frequency | How many evenings or weekends did the last person in this role work in a typical quarter? | unresolved |
| RR6 | No success metrics on a broad mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be held to targets set after the fact | `[inferred]` from the JD's wording | What revenue target applies in year one, and who sets it? | unresolved |
| RR7 | Authority and resources unstated | unknown | — | "You will be a team of one to start" | Budget, tooling and any hiring plan are not stated | `[inferred]` from the JD's silence | What budget and decision rights does this role hold, and is a team planned? | unresolved |
| RR8 | Pay and office terms stated up front | positive_signal | — | "$70–85k base"; "no exceptions" | The posting shows its hard terms in the first read, so a mismatch is cheap to find | `[grounded]` JD | Who sets the base range, and is it fixed for this search? | noted |
| RR9 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No lookup ran, so none of these is ranked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply on the posted terms | R1 and R2 are hard gates that fail, and wording can't change that | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Only if you want to test whether terms flex: ask the employer one plain question about whether the on-site rule and base range are fixed, before spending application effort. I have drafted no text | The posting says "no exceptions", so a yes is unlikely | `[inferred]` from the JD's wording | pending your approval |
| A3 | Keep your story for roles whose gates clear: $8M to $40M ARR, paid, lifecycle and Braze, stated as led by you with a team of 3–7. No CV edits are proposed | R4, R5, R6, R7 are the reusable strength | `[grounded]` R4–R7 rows | pending your approval |

## Evidence status

Verified: none yet. R4–R7 and the constraints in R1 and R2 are your own statements, with no artifact inspected.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The host refused the search. It would have confirmed that Novaline exists as described and that the posting is live, which feeds RR9 and the contradictions row |
| 2. Role-family sweep | unavailable | The host refused the search. It would have given a market band for the market calibration row and RR4 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

I can write this up as `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**

- Allow web search, and the careers-page and market-band checks run. That would close or reduce RR9 and RR4, but it can't change the status.
- The employer's answer on whether the base and the on-site rule are fixed is the only input that could move R1 and R2.
- A hiring manager's name would sharpen the scope read in role reality.
- A growth chart or board slide with the $8M to $40M path, a channel-mix budget sheet, or a Braze retention report would raise R4–R7 to `high`.
- Any SEO, content, brand, PR or partnership work you've done would move R8, R9 and R10.
- A deeper research pass (up to 5 more searches and 2 more fetches) is worth running only if you decide to pursue this anyway.

No questions this turn. The answers that could change the status belong to the employer, not you.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.