I'll read the skill's reference files before building the assessment.
## Decision snapshot

**No, this isn't worth pursuing as posted. R1 and R2, both hard gates, fail. Status: `no_go`.**

Your instinct is right. The fit is real, but the posting's terms fail two of your constraints, and no wording can fix that.

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Base pay $70–85k), R2 (On-site in our Austin office 5 days)
- `must_have`: direct: R3, R4, R5 · unclear: R6 (SEO/content)
- `important`: unclear: R7 (brand, PR, partnerships, and sales ops), R8 (A team of one to start)

R1 and R2 are failed terms no framing closes; R3, R4 and R5 are the on-paper match, stated and unproven; R6 is an open must-have.

**Opportunity ledger.** RR1 and RR2 are posted terms that conflict with your constraints, not unknowns. The rest of the posting pairs a seven-function mandate with a team of one, open-ended hours and undefined metrics (RR3, RR4, RR5). I couldn't check the employer (RR6). RR7 is the only positive entry, and it is unverified.

- **Hard gates:** failed: R1 (Base pay $70–85k), R2 (On-site in our Austin office 5 days a week).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the employer would have to state a base of at least $150k and accept remote work from Portland. The posting says "no exceptions" on location, and its top figure is $65k below your floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; the profitability claim is unverified |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | "A team of one to start"; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | Austin office 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity terms given | `[grounded]` JD |
| Success measures | "Success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | Several functions that are normally separate roles, held by one person, at one salary | `[inferred]` from the seven listed functions set against "team of one" and the stated base |
| Market calibration | Not established. The search I tried was refused, so I give no market band and use no figure from memory. The posting's own top figure is $65k under your floor | `[grounded]` JD and your stated floor |
| Unknowns | Equity percentage and terms, budget, tooling, when hiring begins, how success is measured | `[grounded]` JD silence |
| Contradictions | "Own revenue growth end to end" sits beside "success metrics will evolve". Nothing was available to compare the JD against | `[inferred]` from the JD alone |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor of $150k, which is specific and your own. The fit fails because the posting's top figure is below it | `[grounded]` JD quote and your stated constraint | Surface only; the employer changing terms is the one resolution |
| R2 | On-site in our Austin office 5 days a week, no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your remote-only, Portland-based constraint. The fit fails because the JD forbids exceptions | `[grounded]` JD quote and your stated constraint | Surface only; the employer changing terms is the one resolution |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years in growth, as growth lead then Head of Growth. This is prose self-report with nothing inspectable yet. Years of experience are not a gate | `[grounded]` your stated background | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid and controlled a budget while scaling $8M to $40M ARR over three years. This is confirmed but not inspectable | `[grounded]` your stated background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. Same limit: no inspectable artifact | `[grounded]` your stated background | none |
| R6 | SEO/content | must_have | unclear | none | discovery | Your background doesn't mention SEO or content | `[grounded]` silence in your stated background | G1 in the gap queue |
| R7 | Brand, PR, partnerships, sales ops | important | unclear | none | discovery | Your background doesn't mention any of these. Taking each separately would give the same answer | `[grounded]` silence in your stated background | G2 in the gap queue |
| R8 | Working as a team of one | important | unclear | low | discovery | You built and managed teams of 3–7, which is indirect context. Doing the whole function alone is a different job. I can't tell whether you have done it | `[inferred]` from the team sizes you stated | G3 in the gap queue |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | Nothing on SEO or content in your background | Would only matter if R1 and R2 were resolved | Owning organic landing pages, content calendars, or an SEO agency relationship | A traffic or organic-revenue report | `[grounded]` silence in your background |
| G2 | Brand, PR, partnerships, sales ops (R7, important) | discovery | Nothing stated | Same: moot unless the gates move | Running a partnership channel, a launch PR push, or CRM and pipeline reporting for a sales team | A partner program brief or a sales-ops dashboard | `[grounded]` silence in your background |
| G3 | Working as a team of one (R8, important) | discovery | Teams of 3–7 managed, nothing solo | A one-person function is a different job from leading a team of 3–7 | Early-stage stretches where you executed hands-on before hiring | A prior-role description or a 90-day plan | `[inferred]` from the team sizes you stated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay conflicts with your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The base may also sit below what an 8+ year, seven-function mandate usually commands. No market band was obtained to confirm this | `[inferred]` from the JD's years and scope set against its stated base | Is the base fixed at $70–85k, and what are the equity percentage, vesting and strike terms? | confirmed |
| RR2 | Location conflicts with your constraint (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The employer states the term is fixed | `[grounded]` JD | Is the five-day Austin requirement fixed for this role? | confirmed |
| RR3 | Several specializations bundled into one title with no resources named | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… team of one" | You may be accountable for seven functions with no budget, tooling or help | `[inferred]` from the JD's scope against its silence on resources | What budget, tools and agency or contractor support come with the role, and when does hiring begin? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine rather than occasional | `[inferred]` from the JD's wording, which sets no limit | How often have evenings and weekends been needed in the last quarter? | unresolved |
| RR5 | Success metrics absent on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for revenue with no agreed definition of success | `[inferred]` from the JD's wording | What outcomes would count as success at 90 days and at 12 months? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would report to day to day? | unresolved |
| RR7 | Reporting line and profitability stated | positive_signal | — | "Report to the CEO with a dotted line to the board… profitable since day one" | Senior access and a funded business are plausible, but both are the employer's own claims | `[grounded]` JD; unverified | Who is the CEO, and how often does the board see growth results? | noted |

I'm going only on what you've shared and what the posting says, and I can get this wrong. It's your call whether to proceed.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted | R1, R2 | `[grounded]` the two failed gates | pending your approval |
| A2 | Optional: send one written question to the employer through the contact on its own careers page, asking whether the base and the Austin on-site requirement are fixed. If the answer is unchanged, stop | RR1, RR2 | `[grounded]` register | pending your approval |
| A3 | Only if the gates move, put RR3, RR4 and RR5's questions to the employer verbatim before investing further | RR3, RR4, RR5 | `[grounded]` register | pending your approval |
| A4 | Take the $8M-to-$40M ARR, Braze, SQL and experimentation story to postings that state remote work and a base at or above $150k | R1, R2, R3, R4, R5 | `[grounded]` your stated constraints and background | pending your approval |

No CV edits are proposed.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Novaline e-commerce enablement startup Austin Series A careers", but the host refused the search. It would have moved RR6 and role reality's contradictions row. It couldn't have changed the decision |
| 2. Role-family sweep | unavailable | I searched "Head of Growth salary Series A startup base salary range 2026", and it was refused. It would have given role reality's market calibration a band and sharpened RR1's hypothesis. The gates already fix the decision |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you'd like, I can save all of this as `tuesday-dossier.md`.

## Upgrade menu

- Search permission would verify the employer and the live posting (RR6) and give market calibration a sourced band (RR1).
- The employer's answer on base and location would close R1, R2, RR1 and RR2, and only that could change the status.
- Equity terms, budget and success metrics would close RR3, RR5 and the unknowns in role reality.
- A name for the CEO or hiring contact would let me read their public professional footprint for role reality's scope read.
- An inspectable growth artifact would lift R3 to R5 to `high`. Examples are a revenue or ARR report, a Braze program overview, or an experimentation log.
- Any SEO, content, brand or partnership work you've done would settle G1 and G2.

## Questions

None this turn. R1 and R2 settle the decision, and none of the open rows could move it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.