I've fetched the posting and read most of the skill's rules. Next I'm checking its row-shape and reframing rules, then I'll write the assessment.
## Decision snapshot

**Yes, apply — but as a stretch on two requirements, not a clean match. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol office two days a week), R2 (Pay £61,500–£67,000 plus share options)
- `must_have` — direct: R3, R4, R5a · adjacent: R6 (Experience owning a forecast) · unclear: R5b (Spreadsheet modelling), R7 (Working with finance on billing or revenue data) · absent: R8 (Own billing data)
- `important` — direct: R9

R6 (`medium`) — a bridge, its limit named; R8 — billing data not yet evidenced; R5b and R7 — unconfirmed, open to recovery.

**Opportunity ledger.** Sound on what is stated: pay is disclosed and sits inside the market band (RR1). Open are the share options (RR2), the reporting line and who owns the forecast today (RR3), a broad one-post scope (RR4, a risk signal), and the posting's presence on Quillfield's own site (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol office two days a week), R2 (Pay £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Bristol office days and the pay range work for you — R1, R2; (2) the forecast is framed as adjacent, never as ownership you haven't had — R6, RR3; (3) billing data is confirmed as learnable in the role, or your answer on finance work reopens it — R7, R8, RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` "About Quillfield" search result |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern and pay | Bristol, two office days a week; £61,500–£67,000 plus share options | `[grounded]` JD |
| Hiring manager | Tamsin Achebe, named by your recruiter. Public listing: Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. The posting itself does not name her | `[grounded]` your recruiter's statement; `[grounded]` search snippet, profile page not read |
| First-year outcomes | None stated in the posting | `[grounded]` JD silent |
| Scope read | Four specialisms in one post (CRM, billing data, reporting, forecasting) with no team stated | `[inferred]` from the JD's responsibility list against its silence on team |
| Market calibration | The stated range is near the median for a UK B2B software revenue operations lead (median £64,200, interquartile range £57,800–£70,400, n=438). The guide is UK-wide, not Bristol-specific, and says nothing about options | `[generic]` Ledgerline 2026 pay guide; `[grounded]` JD for the range |
| Unknowns | Who owns the forecast today; reporting line; team or support; share-option terms; whether this is a new or backfill post | — |
| Contradictions | None between the posting and the About page. The careers address I tried returned no page, so the posting is unconfirmed on Quillfield's own site (RR5) | `[grounded]` About page; fetch result |

## Evidence map

Your background was given in prose, so it carries CV standing: claims are `medium` at most until an artifact is inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, two office days a week | hard_gate | unclear | none | hard_gate | You have not said where you are based or whether two days works. Nothing is contested yet; it is unestablished | `[grounded]` JD; no candidate constraint given | Q1 below |
| R2 | £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor given, so the range cannot be checked against one | `[grounded]` JD; no candidate constraint given | Q1 below |
| R3 | 4+ years in RevOps, sales ops or similar analytics at a B2B software company | must_have | direct | medium | none | 5 years in sales operations, the last 2 running RevOps for the UK team. Limit: the employer is a B2B payments company, and whether its product reads as software is not something I know | `[grounded]` your account; `[inferred]` that payments counts as software | State the company's product on the CV |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, and you rebuilt pipeline and renewal dashboards. No credential inspected yet | `[grounded]` your account | Attach the certification to raise to high |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly is stated; "strong" is unprobed | `[grounded]` your account | A sanitized query sample would raise to high |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily shows use, not modelling. Nothing says you built models | `[grounded]` your account silent on modelling | Not asked this turn; see G4 |
| R6 | Experience owning a forecast (the role runs it quarterly with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director; finance owned the company forecast. Limit: you have not owned a forecast or presented one to a CFO | `[grounded]` your account | G2, Q2 below |
| R7 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You have not worked on billing data. Revenue data is open: the renewal dashboards touch it, but whether finance used or reconciled them is not stated | `[grounded]` your account | G3, Q3 below |
| R8 | Own billing data (the JD's first responsibility) | must_have | absent | none | capability | You confirmed no billing data work. A realistic closure path is learning it on the job if the role has finance support. This could reopen if R7's answer shows adjacent work | `[grounded]` your account; `[generic]` that such data is learnable with support | Ask RR4's question; closure path in G5 |
| R9 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt both sets of dashboards. Whether finance was an audience is not stated | `[grounded]` your account | Lead the CV with it (E1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2, hard_gate) | hard_gate | Terms are stated in the JD; your constraints are not | A gate the inputs do not settle decides whether anything else matters | — | None needed; your answer settles it | `[grounded]` JD; `[inferred]` that a yes or no here is decisive |
| G2 | Owning a forecast (R6, must_have) | transferability | Monthly pipeline review with your sales director, with finance owning the forecast | The post runs the quarterly forecast with the CFO, so this is the largest stretch | Submitting commit or best-case roll-ups into finance's forecast; tracking forecast versus actual; scenario or weighted-pipeline calculations; presenting pipeline numbers to a finance lead | A roll-up workbook, a review deck or a forecast-accuracy report, sanitized | `[grounded]` your account; `[inferred]` that this is the biggest stretch from the JD's weighting |
| G3 | Finance on revenue data (R7, must_have) | discovery | Renewal dashboards built, with no finance interaction stated | The requirement says billing or revenue data, so revenue-side work may count | Reconciling renewals against what finance invoiced; agreeing ARR or renewal definitions with finance; fixing a CRM-to-finance mismatch | A definitions document, a reconciliation sheet or an email thread, sanitized | `[grounded]` your account silent on finance; `[inferred]` that revenue-side work may satisfy the wording |
| G4 | Spreadsheet modelling (R5b, must_have) | discovery | Excel daily, with no model described | "Strong spreadsheet modelling" sits beside SQL in the requirements | Pipeline or capacity models, scenario sheets, renewal-rate projections | A sanitized model or screenshot | `[grounded]` your account silent on models |
| G5 | Billing data ownership (R8, must_have) | capability | You have no billing data work | The JD makes it the first thing you will own | — | — | `[grounded]` your account. Closure path: show readiness to learn it, and ask what finance support the role has (RR4) |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary disclosed within market band | positive_signal | — | "Salary £61,500–£67,000" | The range is consistent with what UK B2B software pays for this title; no seniority-pay mismatch is visible | `[grounded]` JD; `[generic]` Ledgerline band, not a claim about this employer | What does the top of the range depend on? | noted |
| RR2 | Share options unquantified | unknown | — | "plus share options" | Value depends on grant size, vesting and strike, none of which is stated | `[grounded]` JD silent on terms | What grant size, vesting schedule and strike price apply to this post? | unresolved |
| RR3 | Forecast ownership and reporting line unstated | unknown | — | "run the quarterly revenue forecast with the CFO" | The search shows a Head of Revenue Operations at Quillfield, so who holds the forecast today, and whether this post is new or a backfill, is open | `[grounded]` search snippet; `[inferred]` that this leaves forecast ownership unclear | Who owns the forecast today, and who does this role report to? | unresolved |
| RR4 | Four specialisms in one post, no team stated | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting ... and run the quarterly revenue forecast with the CFO" | A single post may carry CRM admin, billing data, reporting and forecasting without support. Rated `low`, the lower of the two plausible values, because the team is simply unstated | `[inferred]` from the JD's responsibility list against its silence on team | What analyst, finance or tooling support does this role have? | unresolved |
| RR5 | Posting not confirmed on Quillfield's own site | unknown | — | "(careers address tried returned no page)" | The careers page may sit at another address, or the posting may be syndicated only on the job board | `[generic]` pattern for small companies, not a claim about this one | Can you point me at this role on your own careers site? | unresolved |

## Application plan

Everything here, table and wording advice alike, is proposed and pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Open the CV with the pipeline and renewal dashboard rebuild and the monthly pipeline review you run with your sales director, in the JD's own words | see R9, R3 | `[grounded]` your account | pending your approval |
| E2 | Name the Salesforce admin certification and attach proof | see R4 | `[grounded]` your account | pending your approval |
| E3 | State the forecast plainly: finance owned the company forecast and you ran the pipeline review. Never write "forecast ownership" | see R6 | `[grounded]` your account | pending your approval |
| E4 | In a cover note, say billing data is new to you and name the nearest work you have, but only after your answer to Q3. No billing experience claimed | see R7, R8 | `[grounded]` R7, R8 rows | pending your approval |
| W1 | Optional work sample: a weighted-pipeline forecast roll-up on dummy data, with ranges | see R5b, R6 | `[inferred]` from the R5b and R6 gaps | pending your approval |
| Q1 | Ask the RR1–RR5 questions verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page. Moved role reality's Organization row (the company matches the posting, so no standing not-established entry) and RR5 (the careers cross-check is not established) |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only. Moved role reality's hiring-manager row and RR3 |

## Dossier and upgrade menu

I can save all of this as a `tuesday-dossier.md` so it carries into later steps; say the word.

- Your CV, or confirmation of what your company's product is → R3 firms up and E1 can be drafted against your own wording.
- The Salesforce certification, a sanitized SQL sample or a dashboard screenshot → R4, R5a and R9 can reach `high`.
- Your location and pay floor → R1 and R2 close.
- A sanitized model or forecast roll-up → R5b and R6 firm up.
- The recruiter's answers on RR2–RR5 → the open register entries close.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) → RR3 and RR5 may close. Say the word and it runs.

**Questions**

G1 — Does a Bristol office two days a week and a £61,500–£67,000 range work for you as it stands?

G2 — Did anything you produced feed finance's company forecast, and what part of it was yours?

G3 — Have you worked with finance on renewal or revenue figures, such as reconciling renewals against what was invoiced, and what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.