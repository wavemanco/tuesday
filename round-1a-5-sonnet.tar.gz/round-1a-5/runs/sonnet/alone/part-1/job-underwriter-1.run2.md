I'll read the reference files the skill points to before building the assessment.
**Yes, apply. You're a fit on the core asks, R1, R2, R3, R4 and R5, which are all `direct`. R6, the metrics-layer ask, isn't established yet. Status: `conditional_go`.** The one condition is that Harborlight Health and the posting verify (RR1). I couldn't check either from here.

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · unclear: R6 (define and maintain the metrics layer)
- `important` — direct: R7a · unclear: R7b (partner with clinicians), R8 (mentor two junior analysts)
- `preferred` — adjacent: R9 (healthcare data experience, HIPAA)

R6 — your governed-dashboard work may cover it, but it's unconfirmed; R8 — no mentoring evidence on file yet; R9 (`medium`) — a credible bridge, its limit named.

**Opportunity ledger.** The scope is concrete and a junior team already exists (RR5). The employer is unverified from here (RR1). Pay and location are unstated (RR2, RR3), and so are decision rights and success measures (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify, see RR1; (2) the pay range, once stated, clears your floor, see RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C. It was not verified, because research was unavailable. | `[grounded]` JD header as pasted |
| Mandate | Own product analytics for the care-navigation app. This covers the metrics layer, A/B test design and analysis, self-serve Looker dashboards, partnering with product managers and clinicians, and mentoring two junior analysts. | `[grounded]` JD |
| Scope read | A senior individual-contributor role with informal leadership. Mentoring is named, but reporting lines are not. | `[inferred]` from "mentor two junior analysts" against silence on direct reports |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Compensation | Not stated, so it can't be set against your floor, which you haven't given. | `[grounded]` JD silence |
| Location and schedule | Not stated | `[grounded]` JD silence |
| Market calibration | Not obtained, because the role-family sweep did not run. No band is asserted. | `[generic]` |
| Contradictions | None within the pasted text. There is no second source to compare it against. | `[grounded]` JD as pasted |

## Evidence map

Your background is typed self-report, so it sits at the `medium` ceiling until you attach something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You stated 6 years of product analytics at a ~2M-subscriber meal-kit company. It's specific, with no artifact yet. | `[grounded]` your intake text | none |
| R2 | Expert SQL | must_have | direct | medium | none | You stated daily SQL on Snowflake. "Expert" is a level no document shows, so expect a live SQL exercise. | `[grounded]` your intake text; `[generic]` that roles titled "expert SQL" often test it live | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You stated that you designed and ran the program, with 30+ A/B tests a year and a pricing test behind an 11% retention lift. Sample sizes and statistical method aren't stated. | `[grounded]` your intake text; `[generic]` that interviews usually probe test rigor | An anonymized test brief or readout would raise it to `high`. |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You stated that you built the Looker instance from scratch, with 40+ governed dashboards. | `[grounded]` your intake text | A dashboard inventory or screenshot would raise it to `high`. |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads, and you present to the VP Product monthly. | `[grounded]` your intake text | A sanitized memo would raise it to `high`. |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" is close, but you haven't said who defined the metrics, or whether you built shared definitions in Looker's modeling layer. I won't assume it. | `[grounded]` your intake text silent on metric definitions; `[inferred]` adjacency to governed dashboards | See G1. |
| R7a | Partner with product managers | important | direct | medium | none | You present monthly to the VP Product. | `[grounded]` your intake text | none |
| R7b | Partner with clinicians | important | unclear | low | discovery | You haven't mentioned working with clinical or other domain experts. Your VP Product work is only indirect context. | `[grounded]` your intake text silent on domain-expert partners | See G3. |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring or managing. | `[grounded]` your intake text silent | See G2. |
| R9 | Healthcare data experience, HIPAA (a plus) | preferred | adjacent | medium | transferability | You stated GDPR/CCPA consumer-PII handling and a consent-state model you built for the warehouse. The limit is that none of it involved PHI, HIPAA rules or healthcare data. | `[grounded]` your intake text; `[inferred]` the adjacency | Frame it as adjacent only. |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed Looker dashboards, but nothing on who owned metric definitions | It's the one `must_have` row below `direct`, and resolving it could move it to `direct` | LookML explores or views you built, a metric dictionary, a retention or LTV definition you fixed and others reused, and the work of reconciling conflicting definitions | A metric-definition doc, a LookML excerpt (sanitized), or a dashboard inventory | `[grounded]` silence in your text; `[inferred]` that this moves the row |
| G2 | Mentoring (R8, important) | discovery | No mention | The role names two juniors explicitly, so a specific answer matters either way | Onboarding an analyst, code or query review, coaching on experiment readouts, an internship you supervised, or running an analytics guild | A short description of who, when and for how long | `[grounded]` silence in your text; `[generic]` that titled mentor roles are probed for specifics |
| G3 | Clinician partnership (R7b, important) | discovery | Nothing on working with subject-matter experts | The role pairs analysts with clinicians directly | Working with culinary, nutrition, ops or supply-chain experts to turn analysis into decisions | A specific example | `[grounded]` silence in your text |
| G4 | Healthcare data (R9, preferred) | transferability | The adjacent case is above. The limit is no PHI exposure. | It's the one named differentiator you lack. A truthful bridge keeps it from being a surprise. | The consent-state model design, access controls and de-identification practices you used on PII | A model diagram or a policy you wrote | `[inferred]` bridge from your consent-state work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | The posting as pasted has no pay range. | The posting may be withholding pay, or the range may sit elsewhere on the original page. | `[inferred]` from the pasted text's silence | What is the budgeted salary range for this role? | unresolved |
| RR3 | Location and schedule not stated | unknown | — | The posting as pasted has no work-location or remote terms. | Terms may exist on the original page. Your own constraints haven't been given. | `[inferred]` from the pasted text's silence | Is the role remote, hybrid or on-site, and what are the core hours? | unresolved |
| RR4 | Decision rights and success measures not stated | unknown | — | "Own product analytics … define and maintain the metrics layer" | The role may carry accountability without a stated definition of success, or without clarity on who owns the experimentation platform and data-engineering support. | `[inferred]` from the JD's scope language against its silence on outcomes | What would success look like at 90 days and at 12 months, and who owns metric definitions and the experimentation tooling today? | unresolved |
| RR5 | Concrete scope and an existing junior team | positive_signal | — | "mentor two junior analysts" | The role sits inside a functioning analytics team and has defined deliverables. | `[grounded]` JD | Where do the two juniors sit, and what do they work on? | noted |

## Application plan

Everything below is a proposal and nothing is final until you approve it. Each line uses only your own stated facts. None of it claims healthcare experience, HIPAA exposure, metrics-layer ownership or mentoring.

**resume_edits_pending_approval**

| # | Proposed line | Source clause (your words) | Provenance | Status |
|---|---|---|---|---|
| E1 | "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | "30+ A/B tests a year, including the pricing test behind an 11% retention lift" | `[grounded]` your intake text | pending your approval |
| E2 | "Built the company's Looker instance from scratch: 40+ governed dashboards." | "Built the company's Looker instance from scratch — 40+ governed dashboards" | `[grounded]` your intake text | pending your approval |
| E3 | "Write the monthly metrics memo read by the exec team; present monthly to the VP Product." | "monthly metrics memo the exec team reads … present to the VP Product monthly" | `[grounded]` your intake text | pending your approval |
| E4 | "Built the consent-state model for the warehouse; handled GDPR/CCPA consumer PII." | "built the consent-state model for our warehouse … handled GDPR/CCPA consumer PII" | `[grounded]` your intake text | pending your approval |

I left "metrics layer" out of E2 on purpose. It's the JD's term, and you haven't said that's what you built (G1).

**Positioning and actions** (pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on the company's own careers site before spending effort on the application. | See RR1. | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the experimentation program (R3), then Looker (R4), then the exec memo (R5). | These map to the JD's headline responsibilities. | `[grounded]` JD ordering, your intake text | pending your approval |
| A3 | State plainly that healthcare is new to you, and name the nearest work: the consent-state model and consumer-PII handling (R9). Don't claim HIPAA. | The limit is named up front rather than found in a screen. | `[grounded]` R9 row | pending your approval |
| A4 | Ask the RR2, RR3 and RR4 questions verbatim in the first conversation. | The register doubles as interview preparation. | `[grounded]` register | pending your approval |
| A5 | If you have a mentoring or metric-definition example, add it before applying (G1, G2). | These are the two rows most likely to move. | `[grounded]` G1, G2 | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches I sent were refused, so nothing came back. This would have settled RR1 and confirmed the posting is live. |
| 2. Role-family sweep | unavailable | The search was refused. It would have supplied a pay and scope band for the market-calibration row and RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

I'll offer the dossier now if you want it: I can write this up as `tuesday-dossier.md` so you can carry it forward.

**Upgrade menu**

- Permission to run web search would run targets 1 and 2 and could clear RR1.
- A link to the company's own careers posting would verify the employer and the posting at once, and could close RR1.
- The posted salary range and work-location terms would close RR2 and RR3 and set the pay against your floor.
- The hiring manager's name would feed role reality's scope read and the plan's positioning.
- A sanitized test brief, a dashboard inventory or an exec memo would raise R3, R4 and R5 from `medium` to `high`.
- A metric-definition doc or a LookML excerpt would resolve R6.

**Questions**

- G1 — Did you define or standardize shared metrics at the meal-kit company, such as retention or LTV, and did those definitions live in Looker's modeling layer, a doc or somewhere else? What did you own?
- G2 — Have you onboarded, coached or reviewed the work of other analysts, formally or informally? Who, for how long, and what did you do?
- Constraints — Which terms are non-negotiable for you on pay floor, location or remote, and work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.