I've read the underwriting rules and am now running the research step: checking that Quartzline exists, then looking up market norms for API platform PM roles.
Both searches were refused, so the research targets will show as unavailable. I'm reading the reframing audit now, because I'll be proposing CV positioning. Then I'll write the assessment.
# Job Underwriting Assessment: Product Manager, Platform APIs at Quartzline

## Decision snapshot

**No, applying isn't a waste of your time, but it's a stretch. R1a, the 3+ years of product management that the JD marks must-have, is a gap no wording closes. Status: `conditional_go`.**

I'm assuming you're evaluating and haven't applied yet.

**Fit ledger.**

- `must_have` — adjacent: R1b (PM work, not the title), R2 (shipped API or platform products), R3 (own the roadmap), R5 (specs and delivery with squads) · absent: R1a (3+ years PM experience)
- `important` — direct: R4, R7, R8a · unclear: R6 (adoption metrics), R8b (launches with sales and support), R9 (agile delivery)

R1a — titled years you don't have, which no wording closes; R2, R3 — adjacent, limits named; R6 — a triage-tool lead, still unconfirmed.

**Opportunity ledger.** The role is unverified rather than unsound: the employer is not established from here (RR1), and decision rights, pay and location are unstated (RR2, RR3). One entry runs the other way: named squads and a metrics duty (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears, meaning the employer and a live posting verify; (2) the employer reads R1a for the work rather than the title, tested by A1; (3) the bridges in R1b, R2, R3 and R5 are framed with their limits named, claiming no PM title and no PM years.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not verified: research was refused | `[grounded]` JD header |
| Mandate | Own the roadmap of a partner-facing API platform, run discovery with integration partners, write specs, and drive delivery with two engineering squads | `[grounded]` JD |
| Success measures | Adoption metrics are named as a duty. No first-year outcomes or targets are stated | `[grounded]` JD silent on outcomes |
| Scope read | One product surface, two squads, launches with sales and support. The title carries no seniority marker and asks 3+ years, which reads as a mid-level post | `[inferred]` from the JD's title and years requirement |
| Market calibration | Not run: the role-family sweep was refused, so no pay band or scope norm is offered | — |
| Unknowns | Pay and level, location or remote policy, roadmap decision rights, who owns adoption targets today, whether the squads are dedicated | `[grounded]` JD silent |
| Contradictions | None inside the JD. JD against the careers page not checked | `[grounded]` JD; careers page unread |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management experience (JD: "must-have") | must_have | absent | none | capability | You've said you have never held a PM title, so there are no titled years to claim. It is not a gate, because a length-of-experience term is graded on fit like any other row. A literal screen on the title is possible | `[grounded]` your statement and the JD; `[generic]` that years requirements are often screened literally | A1: ask whether product work done in a solutions role counts |
| R1b | Product-management work, as distinct from the title (named inference from R1a's wording) | must_have | adjacent | medium | transferability | Roadmap-input sessions, requirements documents and coordination with PMs on custom builds are PM-adjacent. Limit: your CV states input to product and client-driven builds, not product-wide prioritisation | `[grounded]` CV prose; `[inferred]` the bridge | G2, W1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ client integrations of your employer's REST APIs and the integration playbook show deep implementer-side experience. Limit: nothing stated about owning a release or launch of an API product. The triage tool is an unconfirmed lead and is not counted | `[grounded]` CV | G1 |
| R3 | Own the roadmap | must_have | adjacent | medium | transferability | Quarterly roadmap-input sessions collecting client feedback for product. Limit: input, not ownership, and no outcome is stated | `[grounded]` CV | G2 |
| R4 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops across 30+ client integrations plus the quarterly feedback sessions are discovery with the people who integrate. The CV frames them as delivery. Whether "partners" in the JD means clients like yours is unknown | `[grounded]` CV; JD wording | E1 |
| R5 | Write specs and drive delivery with two engineering squads | must_have | adjacent | medium | transferability | Requirements documents and integration architecture, and coordinating your engineers, clients' engineers and PMs on custom builds. Limit: specs were for client builds rather than a product backlog, and "coordinated" is not "drove" | `[grounded]` CV | G2, W1 |
| R6 | Define and track adoption metrics | important | unclear | low | discovery | The CV is silent on metrics, though it states SQL. A prior-context lead says you built an internal request-triage tool that support agents adopted. It is unconfirmed, so low rather than none because there is a concrete thread | `[grounded]` CV silence; `[inferred]` from the memory lead | G1 |
| R7 | Technical fluency: API docs and schemas | important | direct | medium | none | Postman, SQL and OpenAPI reading, plus integration architecture across 30+ integrations. The playbook, if shareable, would be an inspectable artifact | `[grounded]` CV | Share a sanitized playbook excerpt to raise to high |
| R8a | Stakeholder management with engineering and customers | important | direct | medium | none | Workshops, UAT and go-live with clients, and coordination of both sides' engineers | `[grounded]` CV | none |
| R8b | Coordinate launches with sales and support | important | unclear | low | discovery | The CV names go-lives for clients but nothing on sales or support. The triage-tool lead touches support only | `[grounded]` CV silence; `[inferred]` from the lead | G1 |
| R9 | Agile delivery | important | unclear | low | discovery | The CV names no delivery method, only coordinating engineers on builds | `[grounded]` CV silence | Not asked this turn; carried as a minor risk |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Adoption metrics, sales and support launches, a possible internal tool (R6, R8b `important`; R2 `must_have`) | discovery | The CV never mentions measuring adoption or working with sales or support. A prior-context lead (unconfirmed) mentions a triage tool support agents adopted | It is the likeliest direct evidence of owning a product outcome, and it could raise R6 and R2 | A tool, template or process others adopted; usage numbers you pulled with SQL; a rollout you coordinated with support or sales | A usage screenshot, a rollout note, or an internal write-up, sanitized | `[grounded]` CV silence; `[inferred]` that it could raise R2 and R6 |
| G2 | Product influence of the roadmap-input sessions and custom builds (R3, R5 `must_have`) | transferability | Sessions and specs exist. What changed because of them is not stated. Limit: input and client-driven builds, not ownership | Two must-haves sit at adjacent; a concrete outcome narrows the objection of "input, not ownership" | A client request your sessions moved into a build; a spec engineers built from; a trade-off you argued between two clients' demands | A sanitized spec, a session summary, or a feedback deck | `[grounded]` CV; `[generic]` that interviews for PM roles probe ownership versus input |
| G3 | 3+ years of PM experience (R1a `must_have`) | capability | No titled PM years exist, by your own statement | A must-have the posting states outright; no reframing creates years | Not applicable: this is not a recall problem | Not applicable | `[grounded]` your statement. Closure path: A1 tests whether the employer accepts equivalent work; otherwise a PM-titled step first is the usual route `[generic]` |
| G4 | Discovery framing (R4 `important`) | presentation | The evidence is strong and the CV frames it as delivery | A fix in communication, not capability | Not applicable | Not applicable | `[grounded]` CV; fix is E1 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Search was refused, so nothing about the employer is established from here. The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Roadmap decision rights unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may be accountable for the roadmap while priorities are set elsewhere, such as by sales requests | `[inferred]` from the JD's mandate against its silence on authority | Which roadmap decisions does this role make alone, and which need sign-off? | unresolved |
| RR3 | Pay, level and location unstated | unknown | — | "Product Manager, Platform APIs" | The posting withholds pay and location, itself worth a question. No band is offered because research was refused, and your floor and location needs were not given, so a check against them can't run | `[grounded]` JD silent; `[generic]` that an unleveled title with 3+ years often signals a mid-level post | What are the salary range and level, and is the role remote, hybrid or on site? | unresolved |
| RR4 | Resources and a metrics duty are named | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | Scope is concrete, with named delivery capacity and a measurable duty | `[grounded]` JD | Who owns adoption metrics today, and what would success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move your roadmap-input sessions, the 30+ client integrations and the playbook to the top of the CV under your real title. Proposed summary line: "Solutions engineer and implementation lead with 7 years taking REST API integrations from scoping to go-live, and running quarterly client feedback sessions for product." No PM title or PM years added | See R4, R3, R7. Each clause is yours: 7 years, REST API integrations, scoping to go-live, quarterly sessions collecting client feedback for product | `[grounded]` your resume lines | `resume_edits_pending_approval` |
| A1 | Before investing in a full application, ask the recruiter or hiring manager whether the 3+ years is read as titled PM roles or as product work, and say plainly you have not held a PM title | See R1a, G3 | `[grounded]` R1a | pending your approval |
| W1 | A one-page sanitized sample: one client-feedback session summary or one spec, showing what you owned and what happened | See R1b, R3, R5, G2. It raises evidence without adding claims | `[grounded]` R1b, R3, R5 rows | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR4's verification questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A2 | Run this application alongside roles where an integration-heavy background is the stated fit, such as technical or partner-integration PM roles | Hedges R1a across more than one posting | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet.

Stage assumed: evaluating.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology Series B partner API platform careers"; the search was refused and returned nothing. It would have moved role reality's Organization and Contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "platform API product manager job scope salary transition from solutions engineer to product manager"; the search was refused and returned nothing. It would have moved role reality's market calibration, RR3, and R1a's literal-screening note |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

If you want, I can save this as a `tuesday-dossier.md` to carry forward.

## Upgrade menu

- Permission for web search → targets 1 and 2 run: RR1 can clear or stand, and the pay band and scope norms fill role reality's calibration row.
- A link to the live posting or Quartzline's careers page → RR1.
- Your actual CV as a document → rows R2 to R8b are re-checked against your exact wording, and E1 is audited line by line.
- A sanitized excerpt of the integration playbook → R7 to `high`.
- Any artifact for the triage tool, such as a usage chart or an internal write-up → R6, R8b and R2 move.
- A sanitized session summary or spec → R3, R5 and R1b.
- The hiring manager's name → role reality's scope read, and which story the plan leads with.
- Your pay floor and location or remote needs → the hard-gates line stops being unknown, and RR3 gets a real comparison.

## Questions

1. **G1** — A prior conversation suggested you built an internal tool that support agents adopted. I'm treating that as unconfirmed. Is it true, and if so what did you build yourself, who used it, and how did you know it worked? Have you measured adoption, or worked with sales or support on a rollout, anywhere else?
2. **G2** — Is there a case where your roadmap-input sessions, or a spec you wrote, changed what engineers built? What was yours, and what happened?
3. **Constraints** — What are your non-negotiables on pay floor, location or remote, and are you pivoting only into PM-titled roles?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.