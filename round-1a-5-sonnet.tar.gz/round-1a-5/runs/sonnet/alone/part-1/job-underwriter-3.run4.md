I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**No — this posting isn't worth pursuing as written. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in Austin five days a week), R2 (Base pay of $70–85k against your $150k floor)
- `must_have` — direct: R3, R4a · unclear: R4b (SEO, brand, PR, partnerships, sales ops)
- `important` — unclear: R5 (Hands-on solo execution)

R1, R2 — failed gates that stand independently; R3, R4a (`medium`) — the substantive match; R4b, R5 — open, and moot while the gates stand.

**Opportunity ledger.** The posting conflicts with both of your non-negotiables (RR1, RR2). It also bundles seven functions into a team-of-one seat (RR4), with pay that may sit below the seniority asked (RR3), open-ended after-hours work (RR5), undefined success measures (RR6) and unquantified equity (RR7). I couldn't verify the employer (RR8). RR9 runs the other way: a direct CEO line.

- **Hard gates:** failed: R1 (On-site in Austin five days a week, no exceptions), R2 (Base pay $70–85k against a $150k floor).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** Novaline would have to put in writing both remote work from Portland (R1) and a base of at least $150k (R2). Nothing in the posting suggests either, and wording on your side can't close them.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one". Not verified against any outside source | `[grounded]` JD header |
| Mandate | Own all revenue growth end to end across paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` JD |
| Team and reporting | "A team of one to start"; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside"; equity size and terms not stated | `[grounded]` JD |
| Success measures | "Success metrics will evolve as we learn"; no 90-day or first-year outcomes stated | `[grounded]` JD |
| Scope read | Seven functions on one seat with no team reads as several roles bundled under one title | `[inferred]` from the function count against "team of one" |
| Market calibration | Not established. The role-family sweep did not run (see Evidence status), so no pay band is offered and the pay-versus-market question stays open (RR3) | `[grounded]` Evidence status, target 2 |
| Unknowns | Budget and agency or contractor support; equity terms; whether Novaline sells to merchants or consumers; who sets the revenue targets | `[inferred]` from the JD's silence on each |
| Contradictions | None inside the posting. It could not be checked against a careers page | `[grounded]` JD read; target 1 did not run |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint, which is specific and confirmed. The fit fails because the posting rules out any remote arrangement | `[grounded]` JD quote and your statement | Only Novaline changing the term resolves it (RR1) |
| R2 | Base pay $70–85k (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The fit fails because the top of the posted range is $85k, and unquantified equity is not base pay | `[grounded]` JD quote and your statement | Only Novaline changing the term resolves it (RR2) |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years in growth, as growth lead and then Head of Growth. It is self-reported with nothing inspectable yet, so `medium`. The year you first held a lead title isn't broken out | `[grounded]` your stated background (CV-equivalent) | Confirm when the lead title began, if you ever apply |
| R4a | Own revenue growth through paid acquisition and lifecycle/CRM | must_have | direct | medium | none | You state you owned paid, lifecycle and experimentation, and scaled one company from $8M to $40M ARR over three years with a budget you controlled, plus SQL, GA4 and Braze. Confirmed and specific, but no inspectable artifact yet. Both companies were B2C subscription, and the posting doesn't say who Novaline sells to. Expect a probe | `[grounded]` your stated background; `[inferred]` that the customer model is the likeliest probe | A sanitized growth dashboard or board-deck page would raise it to `high` |
| R4b | Own SEO/content, brand, PR, partnerships and sales ops | must_have | unclear | low | discovery | Your background doesn't mention these five. Absence of a mention isn't absence of experience, but nothing can be claimed for them. They stay out of any positioning | `[grounded]` silence in your stated background | Ask G1 below only if you decide to proceed |
| R5 | Hands-on execution as a team of one | important | unclear | low | discovery | You built and managed teams of 3–7. Whether you personally executed day to day isn't stated | `[inferred]` from the JD's "team of one" against your team-lead history | Ask G2 below only if you decide to proceed |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand, PR, partnerships, sales ops (R4b, must_have) | discovery | Nothing in your background about these five functions | A must-have row at `unclear`. Resolving it can't change the status while the gates stand | Running a content or SEO program with a freelancer or agency; a partnership or affiliate deal you closed; launch PR or brand work; building a lead-routing or CRM process for a sales team | A traffic or content report, a partnership agreement summary, a launch brief | `[grounded]` background silence; `[inferred]` that it can't move the status |
| G2 | Hands-on solo execution (R5, important) | discovery | Team-lead history, with no statement on personal day-to-day work | Matters only if the seat becomes workable | Building campaigns or lifecycle flows yourself in Braze; writing SQL for your own analysis | A Braze flow screenshot, a SQL notebook | `[grounded]` background silence |
| G3 | Location and pay (R1, R2, hard_gate) | hard_gate | Both terms conflict with your confirmed constraints | These decide the status. Wording can't close them and none is proposed | Not applicable; only Novaline changing its terms resolves them | A written offer from Novaline with changed terms | `[grounded]` JD and your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site five days against your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The term as written conflicts with your non-negotiable | `[grounded]` JD quote against your stated constraint | Is there any remote arrangement for this role, or is Austin on-site fixed? | confirmed |
| RR2 | Base pay below your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted ceiling of $85k is far below your $150k floor, and equity can't substitute for base | `[grounded]` JD quote against your stated floor | What is the ceiling on base for this role, and how large is the equity grant, with what vesting and strike? | confirmed |
| RR3 | Seniority and pay mismatch | risk_signal | medium | "8+ years growth leadership required … $70–85k base" | The figure may sit below what the title and years command. The comparison against the market was not run, so this is a risk signal and not a finding | `[inferred]` from the years and title against the posted figure; `[generic]` that such mismatches are a known posting pattern | How was the base band set for a role requiring 8+ years of growth leadership? | unresolved |
| RR4 | Bundled specializations with no team | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops … a team of one to start" | One seat may carry several full roles with no stated budget or support | `[inferred]` from the function count against the JD's silence on budget and support | Which of these functions have budget, agency or contractor support committed for year one? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine, with "when it matters" left undefined | `[inferred]` from the phrase's open-endedness | In the last quarter, how many evenings or weekends did the team work, and what triggered them? | unresolved |
| RR6 | Success measures undefined on a broad mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for all revenue may arrive without a stated target | `[inferred]` from the mandate's breadth against the metrics' vagueness | What would you want to see from this role at 90 days and at 12 months? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | Without a share count, strike, vesting and the latest valuation, the equity can't be priced | `[inferred]` from the JD's silence on the terms | What is the grant in shares and percentage, with strike, vesting and the latest preferred price? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RR9 | Direct CEO line with a stated board link | positive_signal | — | "Report to the CEO with a dotted line to the board." | Access to decision-makers is explicit | `[grounded]` JD | Who owns the growth budget day to day? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this posting as written | R1 and R2 fail and no wording closes them | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Only if you want to test flexibility: send Novaline one short written question on remote work and the base ceiling (RR1, RR2) before spending any application effort | A written answer settles both gates cheaply. I haven't drafted outreach text | `[grounded]` RR1, RR2 | pending your approval |
| A3 | If you ever proceed, lead with R4a: lifecycle and paid ownership, and the $8M to $40M ARR scale-up with the budget you controlled. Carry the B2C-subscription caveat and make no claim on SEO, brand, PR, partnerships or sales ops (R4b) | Those five are unconfirmed, so they can't be asserted | `[grounded]` R4a, R4b rows | pending your approval |
| A4 | Spend the effort on roles that state remote (or Portland-area) work and a base at or above your floor | Fit is real, so the constraint filter is the efficient screen | `[inferred]` from R3 and R4a against the failed gates | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for Novaline's site and careers page was refused by this session's permissions, and no result came back. It would have fed role reality's organization and contradictions rows and confirmed or cleared RR8. The employer stays unverified |
| 2. Role-family sweep | unavailable | The salary and scope search was refused for the same reason. It would have given a market band for the calibration line and RR3. No band is offered |
| 3. Hiring manager's public footprint | n/a | No name was given, only "the CEO", so there is no query to form |

## Closing

I can write this up as `tuesday-dossier.md` if you'd like a saved record. Say so and I will.

**Upgrade menu**

- The live posting URL, Novaline's careers page, or the recruiter's email domain would settle RR8.
- Permission for the two searches (a pay band and the careers page) would close role reality's calibration line and sharpen RR3.
- A written answer from Novaline on remote work and base pay is the only thing that could reopen R1 and R2.
- A dated CV or LinkedIn showing when your lead title began would firm up R3 to `high`.
- A sanitized growth dashboard or board-deck page showing the $8M to $40M ARR scale-up would raise R4a to `high`.
- Evidence of SEO/content, brand, PR, partnerships or sales ops work would move R4b.
- A hiring manager's name would unlock target 3.
- A deeper research pass on Novaline (funding, leadership churn, public employee and candidate reports, recent news; up to 5 more searches and 2 more fetches) is available if you say the word.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.