I'll read the reference files the skill points to before building the assessment.
Next I'll load the web tools for the L1 research pass.
The careers page snippet says Leeds office four days a week, but the JD you pasted says fully remote. I'll fetch the page to confirm.
## Decision snapshot

**Yes on fit, with one thing to settle before you spend effort: the posting contradicts itself on where the job is done. R1 is unconfirmed and RR1 records the conflict. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R5, R6, R8, R9, R10 · adjacent: R4 (Monitor rating models)
- `important` — unclear: R7 (Recommendations for product)
- `preferred` — direct: R11 · adjacent: R12 (Pet-insurance product knowledge)

R4 — monitoring is only implied by "maintained"; R7 (`none`) — no product-facing evidence yet; R12 (`low`) — a credible bridge, its limit named.

**Opportunity ledger.** The role's scope is clear and matches your work, but the working pattern differs between the JD and the company's own careers page (RR1). Pay is unstated (RR2), and team and decision rights are unstated (RR3). The company's size and stage couldn't be established (RR4). The posting names a reporting line and the scope it owns (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** it waits on two answers, yours on whether Leeds four days a week works for you (R1) and the employer's on which pattern is current (RR1). If you need remote and Brindlemoor confirms Leeds four days, R1 becomes `hard_gate_fail` and the status `no_go`. If remote is confirmed, or Leeds works for you, the status moves to `conditional_go` or `go`, depending on how G1 and G2 resolve.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, a UK insurtech selling pet insurance. Its own careers page lists this role and the pet-insurance product. Size, funding and stage are not established: a product search returned nothing | `[grounded]` JD header; careers page fetched |
| Mandate | "Own pricing analytics for our pet-insurance product": build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD and careers page |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` JD; careers page fetched |
| Reporting line | The Director of Pricing (Odile Varga), as the JD says and the careers page repeats | `[grounded]` JD and careers page |
| First-year outcomes | None stated | `[grounded]` JD silent |
| People management | None of the JD's requirements mentions managing people or direct reports | `[grounded]` JD |
| Scope read | One product's pricing analytics, owned by an analyst-grade post under a Director. No team or decision rights are stated | `[inferred]` from "Own pricing analytics" against the JD's silence on team and authority |
| Hiring manager | Director of Pricing at Brindlemoor. Spoke at the 2025 Insurance Pricing Forum, "Small Books, Loud Errors", on monitoring rating models in small books. Previously head of pricing analytics at Calloway Re for six years | `[grounded]` public profile, search result only |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900 (n=612). The posting withholds pay, so this is the band to expect, never Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 survey, search result only; `[grounded]` JD silent on pay |
| Unknowns | Which working pattern is current; salary; direct reports and decision rights; first-year outcomes; company size and stage | — |
| Contradictions | The JD and the careers page disagree on working pattern (RR1) | `[grounded]` both quoted above |

## Evidence map

Your background was given in prose, which counts as CV-equivalent, so `medium` is the ceiling on a first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD says remote and the careers page says Leeds four days a week. You haven't said what working pattern you need, so nothing settles it | `[grounded]` JD and careers page; no candidate statement | Answer the R1 question; ask the employer (RR1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You have 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Confirmed and specific, with no artifact yet | `[grounded]` your background | none |
| R3 | Build rating models | must_have | direct | medium | none | You built the GLM rating model for the young-driver book. Specific, but no inspectable artifact yet | `[grounded]` your background | Redacted model documentation or factor table would raise to high |
| R4 | Monitor rating models | must_have | adjacent | low | discovery | You said "maintained" the model. Monitoring (drift, actual-versus-expected, refits) is what the JD asks for and isn't stated. Taking the lower reading | `[grounded]` your wording; `[inferred]` that maintenance involved monitoring | See G1 |
| R5 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Specific, no artifact | `[grounded]` your background | A redacted test readout would raise to high |
| R6 | Turn results into recommendations for underwriting | must_have | direct | medium | none | The tests were run with the underwriting team, and you present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R7 | Recommendations for product | important | unclear | none | discovery | Your account names underwriting only. Nothing covers a product team | `[grounded]` silence in your account | See G2 |
| R8 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is the JD's word; the evidence is daily use | `[grounded]` your background | A sanitized notebook or query would raise to high |
| R9 | GLM experience | must_have | direct | medium | none | You built and maintained a GLM rating model | `[grounded]` your background | Covered by the R3 artifact |
| R10 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | A redacted review deck would raise to high |
| R11 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R12 | Pet-insurance product knowledge (inferred from the role's scope) | preferred | adjacent | low | transferability | You confirmed you have never worked on pet insurance. The carry-over is GLM-based rating and price testing on an insurance book. Limit: you haven't worked with pet-specific rating factors or claims cost trends. Pet pricing typically turns on species, breed and age, and its claims-cost dynamics differ from motor | `[grounded]` your statement; `[inferred]` that the role needs this, from "pet-insurance product"; `[generic]` pet pricing pattern | Name the limit up front (E4) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitor rating models (R4, must_have) | discovery | You maintained the young-driver model. Nothing says what you tracked, how often, or what you did when it moved | The JD names monitoring, and the hiring manager has spoken publicly on monitoring rating models, so this is where she is likelier to probe | Actual-versus-expected tracking, drift checks, a refit you triggered, an alert you set up, a dashboard others used | A monitoring pack, a dashboard screenshot, or a refit note, redacted | `[grounded]` your wording; `[grounded]` the talk; `[inferred]` that it makes monitoring a likely probe |
| G2 | Recommendations for product (R7, important) | discovery | Your account covers underwriting. The JD also names product | A row at `unclear` is cheap to close if you have the experience | A test readout that went to a product, proposition or commercial team; a pricing change that shaped a feature or tier | A readout or email thread, redacted | `[grounded]` your account's silence |
| G3 | Working pattern (R1, hard_gate) | hard_gate | The JD and careers page disagree. Your own requirement is unknown | A gate the inputs don't settle is a gate, and it caps the decision at `hold_pending_answers` | — | The employer's written confirmation | `[grounded]` both sources |
| G4 | Pet-insurance knowledge (R12, preferred) | transferability | Carry-over: GLM rating, test design, claims-based modelling. Limit: no pet-specific factors. Strengthener: reading about pet rating factors | A preferred row, so it can't block, but it's the one domain gap | Any work on a non-motor line; any exposure to claims-cost inflation | Not applicable: no question, since you've said you haven't | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between JD and careers page | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The JD copy may be out of date, the role's terms may have changed, or the two may describe different arrangements. None of these is ranked as likely | `[grounded]` both quotes; `[inferred]` hypotheses | Is this role fully remote, or based in Leeds four days a week, and which is current? | unresolved |
| RR2 | Pay unstated | unknown | — | JD gives no figure | Pay may sit anywhere against the band in role reality. Your floor isn't given, so no comparison is possible | `[grounded]` JD silent; `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Team and decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The post may own analysis and only recommend changes, or may carry rate-change authority or future direct reports | `[inferred]` from "Own" against the JD's silence | Does the role have direct reports now or planned, and which pricing decisions does it make itself versus recommend? | unresolved |
| RR4 | Company footprint thin beyond its careers page | unknown | — | Product search returned nothing | The company may be new or small. This is a pattern, not a finding about Brindlemoor | `[generic]` pattern for companies of this size, not a claim about this one | How large is the pricing team, and at what stage is the company? | unresolved |
| RR5 | Mandate and reporting line stated and consistent | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The ownership and manager are clear | `[grounded]` JD and careers page agree | What would success look like in the first year? | noted |

## Application plan

All rows are proposed and none is applied or sent. The E rows are `resume_edits_pending_approval`, and the wording of each traces to your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with Brindlemoor before investing in the application | R1, RR1 | `[grounded]` the register | pending your approval |
| E1 | CV line: "Built and maintained the GLM rating model for the young-driver book at a UK motor insurer." | R3, R9 | `[grounded]` your background | pending your approval |
| E2 | CV line: "Ran 14 price tests with the underwriting team" (add the calendar year; you said "last year") | R5, R6 | `[grounded]` your background | pending your approval |
| E3 | CV line: "Present the quarterly pricing review to the head of underwriting." | R10 | `[grounded]` your background | pending your approval |
| E4 | Cover note line: "My pricing experience is in UK motor insurance; I have not worked on pet insurance." | R12: states the limit before they find it | `[grounded]` your statement | pending your approval |
| A2 | Lead with the rating-model build and the price tests (R3, R5, R9). Be ready on monitoring once G1 is answered, since the Director has spoken publicly on it | R4, G1 | `[grounded]` map rows; `[grounded]` the talk | pending your approval |
| Q1 | Ask the register's verification questions (RR1 to RR5) in the interviews | They double as interview preparation | `[grounded]` the register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech", which returned nothing (company details not established), and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It moved role reality's working pattern and contradictions rows, R1, RR1 and RR4 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), snippet only. It moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (www.linkedin.example/in/odile-varga), snippet only. It moved the hiring manager row, G1 and A2 |

Extra, offered and not built: a one-page note mapping motor rating factors to pet-insurance ones, since R12 is your one domain gap and a note on it is something you can bring to an interview. Say yes if you want it.

If you want this assessment saved, say so and I'll emit it as `tuesday-dossier.md`.

## Upgrade menu

- Your CV, or the passages describing the rating-model and price-test work → the E rows get checked against your own wording.
- A redacted model factor table, test readout, monitoring pack or quarterly review deck → R3, R5, R9 and R10 move from `medium` toward `high`, and G1 may close.
- A sanitized notebook or query sample → R8 moves toward `high`.
- Your answer on working pattern, plus your pay floor and any other fixed terms → R1 resolves and the hard-gates line stops flagging that constraints are not given.
- The employer's answers on pay, team and decision rights, and working pattern → RR1, RR2 and RR3 close.
- A deeper research pass on Brindlemoor (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G3 (R1) — Is Leeds four days a week workable for you, or do you need fully remote?

G1 (R4) — After your young-driver model went live, what did you personally track, how often, and what did you do when it moved?

G2 (R7) — Have you taken price-test results to anyone beyond underwriting, such as a product or commercial team, and what came of it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.