I'm reading the skill's remaining reference files, covering the decision rules and snapshot format. After that I'll run the company research and write the assessment.
## Decision snapshot

**Yes, apply. You fit the core of this role, and the open items are R6, the unverified employer (RR1) and constraints I don't have yet. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · unclear: R6 (Define and maintain the metrics layer)
- `important` — adjacent: R8 (Partner with clinicians) · unclear: R7 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R6 — evidence of owning metric definitions isn't established yet; R9 — a credible bridge, its limit named.

**Opportunity ledger.** The role's scope is concrete and its tooling is named (RR4). The employer could not be checked from here (RR1), and pay (RR2) and location or working terms (RR3) are missing from the posting.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the employer and the live posting verify — RR1; (2) pay and location/working terms are compatible with your non-negotiables — RR2, RR3; (3) you can show you owned metric definitions, not only dashboards — R6, G1

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header; not independently verified (RR1) |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A senior individual-contributor seat with informal mentoring of two juniors. The JD names no direct-report management | `[inferred]` from "mentor two junior analysts" and the absence of any management language |
| Market calibration | Not run: the role-family search was refused, so no band is given and none is implied from memory | `[grounded]` research refused; see Evidence status |
| Unknowns | Salary; location or remote policy; who the role reports to; authority over metric definitions versus PM and clinical sign-off; size and maturity of the experimentation setup | `[grounded]` JD silent |
| Contradictions | None found within the JD. It was not compared against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics, stated by you. Years of experience is a requirement, not a gate. No document has been inspected | `[grounded]` your stated background | A CV or LinkedIn link would raise this to `high` |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on a Snowflake warehouse over six years. "Expert" is a self-level, so an interviewer will probe it | `[grounded]` your stated background | A sanitized query or model sample would raise this to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year, and you designed the program, including a pricing test behind an 11% retention lift. This employer's traffic and test cadence are unknown, so "at scale" is judged against the JD's phrase only. Expect a probe on the 11% figure's method and base | `[grounded]` your stated background | A sanitized test write-up would raise this to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. This is the same tool the JD names | `[grounded]` your stated background | A dashboard screenshot, redacted, would raise this to `high` |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your stated background | A redacted memo excerpt would raise this to `high` |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | Governed dashboards suggest definitions were controlled, but nothing says you owned the metric definitions, for example in LookML or a semantic layer. The JD names this responsibility first | `[inferred]` from "governed dashboards" against silence on definition ownership | See G1 |
| R7 | Mentor two junior analysts | important | unclear | none | discovery | No mentoring or leadership of analysts appears in what you gave me | `[grounded]` background silent | See G2 |
| R8 | Partner with product managers and clinicians to turn analysis into roadmap decisions | important | adjacent | medium | transferability | Your monthly VP Product presentations are the same kind of analysis-to-decision work. Limit: nothing shows work with clinicians or with PMs directly, and clinical input can change how a metric or test is judged. Name this limit wherever the bridge is used | `[inferred]` from the VP Product work, against the JD's clinician requirement | See G3 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for the warehouse. Limit: no protected health information, HIPAA safeguards or de-identification. Being preferred, this is a smaller risk | `[inferred]` privacy-regulated data work as the bridge; `[generic]` that healthcare employers weigh HIPAA fluency | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, must_have) | discovery | Governed dashboards, with no statement of who defined and maintained the metrics behind them | A must-have that the JD lists first. Settling it is the likeliest way to firm up the fit | Writing LookML or semantic-layer definitions; a metric dictionary; resolving a conflict over what "retention" or "active" meant; certifying the dashboard metrics | A metric dictionary, a LookML snippet (sanitized) or a definitions doc | `[grounded]` the background doesn't say who owned definitions; `[inferred]` that this is where an interviewer probes |
| G2 | Mentoring analysts (R7, important) | discovery | Nothing on mentoring or onboarding | The JD gives mentoring a named responsibility; a confirmed example turns this into a `direct` row | Onboarding a new analyst; reviewing others' SQL or experiment designs; running office hours or training on Looker; a peer who grew under you | A name-free description of the mentoring, or a review checklist you wrote | `[grounded]` background silent |
| G3 | Clinician and PM partnership (R8, important) | transferability | Monthly VP Product presentations; no clinician or PM partnership stated | The adjacent evidence carries over, but clinical judgment in decisions is the part not exercised | Working with a domain expert (nutrition, ops, culinary) who had to approve a test or metric; a roadmap change that came out of your analysis | A roadmap decision traced to your memo or a test result | `[inferred]` bridge from the VP Product work; `[generic]` that clinician sign-off is a normal part of health-product analytics |
| G4 | HIPAA and healthcare data (R9, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model | The bridge is real but doesn't cover health data. Naming that limit yourself reads stronger than leaving the interviewer to find it | Access controls, data minimization, PII masking, retention rules or audit work you did; the consent-state model's design | A one-page description of the consent-state model | `[inferred]` bridge; `[generic]` HIPAA is a preferred, not required, item here |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. None of these is more likely than the others | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be working with day to day? | unresolved |
| RR2 | Compensation not stated | unknown | — | (posting gives no figure) | The salary may fall short of what the seniority and mandate usually carry, or the company may not publish pay | `[inferred]` from the posting's silence; no band was available to compare against | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and working terms not stated | unknown | — | (posting gives none) | The role may require on-site days, a specific region or hours that clash with your constraints | `[inferred]` from the posting's silence | Is the role remote, hybrid or on-site, and in which locations or time zones? | unresolved |
| RR4 | Responsibilities and tooling are concrete | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | The scope looks genuinely defined, so success is measurable | `[grounded]` JD | What would a good first 90 days look like for this role? | noted |
| RR5 | Authority over metric definitions and roadmap influence unstated | unknown | — | "turn analysis into roadmap decisions" | You may be accountable for outcomes without a final say on metric definitions or on what ships | `[inferred]` from the JD's wording against its silence on decision rights | Who signs off on a metric's definition, and who decides whether an experiment result changes the roadmap? | unresolved |

RR1 caps the decision at `conditional_go` until the posting verifies. A link to the live posting on the company's own careers page, or the recruiter's email domain, would settle it.

## Application plan

Every row below is a proposal. None is final until you approve it, and that approval covers the advice in the Why column as well as the wording in the table.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the top of your resume with the experimentation program: "Designed and ran the experimentation program (30+ A/B tests a year), including the pricing test behind an 11% retention lift" | Covers R3, the experiment requirement, using only your own words | `[grounded]` your stated background | pending your approval |
| E2 | Pair "Built the company's Looker instance from scratch, 40+ governed dashboards" with a line on who defined the metrics, once G1 is answered | Covers R4 now and R6 after G1; I won't write the second half until you confirm it | `[grounded]` R4; R6 pending G1 | pending your approval |
| E3 | Describe the consent-state model as "built the consent-state model for the warehouse under GDPR and CCPA". Don't call it healthcare or HIPAA experience | Keeps the R9 bridge honest and states its limit | `[grounded]` your stated background | pending your approval |
| A1 | Check the posting on the company's own careers site before spending effort | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask RR2, RR3 and RR5's questions verbatim in the first conversation | They're unanswered by the posting | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched for the company's careers page and this role; the call was refused, so nothing came back. This would have moved RR1 and the contradictions row in role reality |
| 2. Role-family sweep | unavailable | Searched for a salary range for this title in digital health; the call was refused, so nothing came back. This would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A link to the live posting or the company's careers page, or the recruiter's email domain → RR1 resolves, and the cap on the decision lifts.
- Search permission, so L1 can be run → RR1 and RR2 get a basis, and role reality gets a market calibration row. After that, a deeper pass (up to 5 more searches and 2 more fetches) is on offer.
- Your location, pay and schedule non-negotiables → hard gates get checked against the role and RR2 and RR3 can close.
- A metric dictionary, a LookML snippet or a sanitized definitions doc → R6 moves toward `direct`.
- A redacted memo excerpt or a sanitized experiment write-up → R3 and R5 move to `high`.
- The hiring manager's name → role reality's scope read, and which story to lead with.

If you'd like, I can save all of this as `tuesday-dossier.md`.

**Questions**

- C1 (RR2, RR3) — What are your non-negotiables on pay floor, location or remote, and work authorization? None are stated yet, so the hard gates are unchecked against you.
- G1 (R6) — Did you personally define and maintain the metrics behind those Looker dashboards, for example in LookML or a metric dictionary? What did you own, and who signed off on definitions?
- G2 (R7) — Have you onboarded, reviewed the work of, or trained other analysts? What was your role, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.