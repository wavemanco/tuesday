Still reading the skill's reference files (risk register, output rules, worked report) before I build the assessment.
**Yes, it's worth applying, with two things to confirm first. R1 and R2 are both hard gates, and neither can be checked until I know where you're based and what your pay floor is. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R8, R9
- `important` — adjacent: R7 (BigQuery warehouse) · unclear: R10 (ingestion from app and CRM), R11 (data contracts)

R7 (`medium`) — a credible bridge, its limit named; R10, R11 — the CV is silent, so these are discoveries, not shortfalls.

**Opportunity ledger.** The posting is live and matches the company page (RR1), and the stated pay sits at the market median or above (RR2). Scope, reporting line and equity terms are not stated (RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed: you are in the US, or willing to work from Denver; (2) R2 clears your pay floor; (3) RR3's scope questions get concrete answers in the loop.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` company about page, fetched via search result |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD, live careers page |
| Seniority and scope read | The mandate reads as ownership of one reporting domain's pipelines. No direct reports are mentioned | `[inferred]` from the mandate wording against the report's "typical scope" and the posting's silence on reports |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Market calibration | Report band for Senior Data Engineer at Series B–D: base median $151,000, interquartile range $139,000–$163,500; "Senior" typically 5–8 years. The posting's 5+ years and a Series C employer both sit inside that frame. The band is a market pattern, never this employer's offer | `[grounded]` recruiter's Datawright 2026 report, n=2,310, as you supplied it and not independently checked; `[generic]` for the placement |
| Unknowns | Hiring manager; team size and reporting line; equity terms; success measures; whether a BigQuery ramp-up is expected | `[grounded]` JD names none |
| Contradictions | None between the pasted posting, the live careers page and the about page | `[grounded]` pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | "Remote (US) or our Denver office" | hard_gate | unclear | none | hard_gate | You have not stated your location or work authorization, so there is no claim to grade. Fit stays `unclear` until you answer | `[grounded]` JD; `[grounded]` no constraint given | Question Q1 |
| R2 | "Salary $148,000–$166,000 plus equity" | hard_gate | unclear | none | hard_gate | You have not stated a pay floor. The posted range is set against the market band in RR2 | `[grounded]` JD; `[grounded]` no constraint given | Question Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | "6 years of data engineering at a B2B payroll company". Specific, but self-reported with no inspectable artifact yet | `[grounded]` your background message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily". Confirmed and plausible, but "daily use" alone shows no depth. Expect a technical probe | `[grounded]` your message | Offer: a sanitized code sample would raise it to high |
| R5 | dbt | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models". You built it, and the size is stated. No artifact inspected | `[grounded]` your message | Offer: a dbt docs or lineage screenshot, sanitized |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the requirement does not name one. The BigQuery point is carried separately in R7 | `[grounded]` your message and the JD wording | none |
| R7 | Warehouse in BigQuery (named in the mandate, not in the requirements list) | important | adjacent | medium | transferability | Adjacent: you built a dbt project on a cloud warehouse. Limit: you have never used BigQuery, so its cost model, partitioning and clustering are unexercised | `[grounded]` your "never used BigQuery"; `[generic]` that warehouse skills usually transfer, with a ramp-up | Gap G1 |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration". The scope of your ownership (authoring DAGs or running the platform) is not stated | `[grounded]` your message | none |
| R9 | Experience with data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite". That is ownership of the setup, with no outcome or coverage stated | `[grounded]` your message | Offer: a sanitized suite outline would raise it |
| R10 | Ingestion from the app and from CRM | important | unclear | low | discovery | Pipelines in a payroll company are likely to involve some source ingestion, but your message says nothing about which sources or tooling. Not carried as your claim | `[inferred]` from your role family against silence; `[grounded]` silence | Gap G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your message does not mention contracts. Great Expectations tests may be adjacent, but you have not said so, so nothing is claimed | `[grounded]` silence; `[inferred]` adjacency to R9 only as a question | Question Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | Snowflake plus dbt, no BigQuery use | The posting names BigQuery as the warehouse, so this is the likeliest objection | Any dbt project you ran against a second warehouse; a personal BigQuery sandbox project; BigQuery migration or cost-tuning exposure | A small public or sanitized project on BigQuery's free tier | `[grounded]` your "never used BigQuery"; `[generic]` that this is the likeliest objection |
| G2 | Ingestion from app and CRM (R10, important) | discovery | The message names Airflow and dbt but not the source systems | Ingestion is the first named responsibility in the mandate | Pulling from a product database, an event stream or a CRM API; loading payroll-system extracts; a CDC or batch load you maintained | A DAG sketch or architecture diagram, sanitized | `[grounded]` silence on sources |
| G3 | Data contracts (R11, important) | discovery | Great Expectations is confirmed; contracts with consumers are not mentioned | The role is described as serving analysts through contracts | Agreed schemas or SLAs with downstream analysts; test-failure ownership; schema-change reviews | A schema-change policy or contract document, sanitized | `[grounded]` silence; `[inferred]` adjacency from R9 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting confirmed | positive_signal | — | "Series C ($52M, February 2026)" | The employer exists as described and the role is live. Funding and headcount are the employer's own statements, not independently confirmed | `[grounded]` careers and about pages fetched | Who would I report to, and how large is the data team? | noted |
| RR2 | Posted pay against market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The $148,000 low end is $3,000 under the $151,000 median. The $166,000 high end is $2,500 over the $163,500 upper quartile. No seniority-pay mismatch | `[grounded]` JD; `[grounded]` recruiter's report; `[generic]` report is a market band, not this employer's offer | Where in the range would someone with my background land? | noted |
| RR3 | Scope, authority and success measures not stated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | "Build and run" with no hiring manager, team or outcomes named may mean a lone owner or a small team | `[inferred]` from JD wording against its silence | What would success look like at 90 days and at one year, and who sets the priorities? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Grant size, vesting and strike terms are not given, so total pay is unknown | `[inferred]` from the posting's silence | What is the equity grant, vesting schedule and strike price for this level? | unresolved |

## Application plan

All rows are proposals. Nothing below goes into your CV or into outreach until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume edit: lead the experience section with the dbt project built on Snowflake (about 180 models), the Airflow orchestration and the Great Expectations suite you set up. These use your wording, with no BigQuery or data-contract claim added | R5, R8, R9 | `[grounded]` your message | resume_edits_pending_approval |
| E2 | Positioning: name the Snowflake-to-BigQuery step openly and as a stated ramp-up. Do not describe it as BigQuery experience | R7, G1 | `[grounded]` R7 row | pending your approval |
| A1 | Ask the recruiter for the hiring manager's name, team size and equity terms, using the questions in RR1, RR3 and RR4 | The posting names no hiring manager | `[grounded]` JD and register | pending your approval |
| A2 | Optional: a small dbt-on-BigQuery project on the free tier, if you want to narrow G1 before interviews | R7 | `[generic]` common way to narrow a tool gap | pending your approval |

## Evidence status

Verified: none yet. Unverified: every claim in R3–R11 is your own statement from this message, so none has been inspected or confirmed against an artifact. Rejected inferences: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). This checked your pasted material. The posting is live ("Accepting applications") and matches your paste. The about page matches your paste. Moved: role reality's organization and contradictions rows and RR1, and no failed-attribution entry is needed |
| 2. Role-family sweep | skipped | The recruiter's report content is in hand, which fixes the market calibration line and RR2 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

## Dossier offer

I can write all of this up as `tuesday-dossier.md`, if you want a file to keep.

## Upgrade menu

- Your location and work authorization → R1 settles.
- Your pay floor and your view of equity → R2 settles.
- Your actual CV → R3–R11 are graded on your message today. The CV may add evidence on ingestion and data contracts (R10, R11).
- A sanitized dbt lineage or docs screenshot, or a Great Expectations suite outline → R5 and R9 can rise to `high`.
- The hiring manager's name → role reality's scope read, and the people-research target.
- A deeper research pass on Pellucid (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

Q1 (R1) — Are you based in the US, and would you take Remote (US) or move to Denver?
Q2 (R2) — Does a base of $148,000–$166,000 plus equity clear your pay floor, and what is that floor?
Q3 (R11/G3) — Have you agreed schemas or expectations with downstream consumers of your pipelines, such as analysts depending on certain tables? What did you own, and what happened when a test failed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.