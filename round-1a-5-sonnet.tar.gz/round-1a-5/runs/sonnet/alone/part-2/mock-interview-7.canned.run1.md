I'll start by reading the skill's reference files.
Fixing the pronouns for Tobias (not stated, so I'll use neutral wording) and the stale section reference.
Femi, your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for the format Saltmarsh's careers page describes: one 60-minute session with the hiring manager, a live-incident tabletop first and then a values conversation. I assumed Tobias is that hiring manager.

The pack has 19 questions across six interviewer styles, weighted toward the tabletop and the values half. It also covers:
- your fit against each JD line, quoting only your own sentences
- Saltmarsh's three published values, each with a story or an honest fallback
- seven questions to ask Tobias
- a prep order for the next two days

Say the word and I'll play the skeptical interviewer on C1. That's the pack's highest-ROI question: you've never worked on a game with in-app purchases, and Saltmarsh has announced a move to a season pass.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Live Operations Producer — Saltmarsh Games: interview prep pack

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: one 60-minute session on Friday. Built as the "Outage Hour" that Saltmarsh's careers page documents: a live-incident tabletop first, then a values conversation, with the hiring manager. I assumed Tobias is that hiring manager; if that is not so, the persona table is the part to revisit.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for your own words, not a script: every line in quotation marks that is about your past is a sentence you wrote to me, and nothing here adds to it.

| Type tag | What it scores |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values, not generic virtue |
| EXP | Whether what you say you did survives follow-ups, including how much was you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's current strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to your message, the JD or a source listed in Sources. `[inferred]` is this pack's derivation, named where used. `[generic]` is a pattern with no claim about Saltmarsh or you.

## Prep triage

You have until Friday. In order:

1. Say A1 and A2 aloud twice. The tabletop is the first half of the hour.
2. Rehearse C1 until it is boring. It is the highest-ROI prep in this pack: the objection most likely to be put to you, and the one aimed where your material is thinnest.
3. For B1, B2, B3: decide now whether a real story comes to mind or you will use the honest branch.
4. Write down what you do and do not know about how the retention numbers in D1 were counted.
5. Say the F1 arc aloud once, timed at 90 seconds.
6. Pick two reverse questions from R1 to R7.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not live events and not a second title, and nothing inspected sits behind it. Words at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events line makes a probe on how far your calendar reached likely. Say which parts of it were yours to set and which were set for you, in your own words; if you cannot split them, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message, "Never led a team, and never worked on a game with in-app purchases" — your message | low | [inferred] | discovery | Your material does not show which teams the calendar touched, and your own sentence says you never led a team. Words you can say: "I haven't led a team." Answer slot: the JD names four disciplines, so expect a probe on which of them you worked with on a drop. Say which and how, in your own words; if none, or it was not part of your role, say so plainly and stay with the calendar and the checklist |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you ran a review or set the measures, and nothing inspected sits behind it. Words at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's review line makes a probe on what happened around those numbers likely. Say what you presented and to whom; if you also did anything with them afterwards, say what, in your own words; if you did not, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: "I wrote the release checklist our QA team still uses." Keep the verb: the material says wrote, and your answer stays there |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your sentence gives the years and the title; your material does not say whether the main title ran as a live service. This is a length-of-experience line, graded like any other, not a gate. Answer slot: the JD's live-service line makes a probe on that likely. Say what the title was like to run week to week, in your own words; if it did not run as a live service, say so plainly and stay with the four years and the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but nothing inspected behind it, so expect a probe on the calendar's day-to-day. Lead with it in the quote's own terms: weekly, your main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but your material shows presenting the numbers, not how they were counted, so expect a probe on that (D1). Lead with the quote in its own terms: "I presented the monthly retention numbers to the studio head" |
| F8 | "clear written communication" — JD | none given | none | [grounded] | discovery | Your material does not show any writing sample. Answer slot: the JD's written-communication line makes a probe likely, and Tobias's published talk is about patch notes. If anything you wrote reached players or other teams, such as update notes, event announcements or the checklist's instructions, say which, in your own words; if none did, say so plainly |
| F9 | Comfort with in-app-purchase economics — not in the JD; Project Larkspur's move to a season-pass model makes the topic likely | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work, and nothing added to make the gap feel smaller |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope: "For the last two years I ran the weekly content-drop calendar for our main title." The limit is the pack's observation: the material says one main title and content drops. C2's slot stays inside the calendar |
| Owned the post-event review or chose the KPIs it reports | Inflated form of F3 | F3's quote at its own scope: "I presented the monthly retention numbers to the studio head." The limit is the pack's observation: the material says presenting, not a review. D2's slot asks only what happened around those numbers |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope: "I wrote the release checklist our QA team still uses." The limit is the pack's observation: the material says wrote, not managed |
| Led or managed the teams on an update | Negative you stated, F2 | The plain acknowledgment: "I haven't led a team." No slot |
| Worked with in-app purchases or monetization | Negative you stated, F9 | The plain acknowledgment: "I've never worked on a game with in-app purchases." No slot; then a plan, never a past |

## Reading the interviewer

Public professional footprint only. Everything below comes from one search-result snippet; I did not open the talk page, so treat it as thin.

| Fact or reading | Source | Provenance | What to do with it |
|---|---|---|---|
| Tobias Wrenfield is Head of Live Operations at Saltmarsh Games and was previously a QA lead at a console studio | Search result for Tobias's name: GDC 2026 talk page, talks.gdconf.example | [grounded] | QA vocabulary is native to Tobias. F4's checklist is your strongest common ground; use it in A4 and B3 |
| Tobias's GDC 2026 talk, "Patch Notes Are a Promise", argues that a live team is judged by how often its patch notes describe what actually shipped | Same snippet | [grounded] | Expect precision tests on what you did versus what you hoped. Keep every claim at the scope of your own sentences. A2 and B2 are where this theme most likely appears. Do not quote the talk back unless Tobias raises it |
| Mirror opportunity, shared vocabulary: Tobias's QA path beside your sentence "Wrote the release checklist our QA team still uses" (F4) | Tobias's path from the snippet; your sentence from F4's evidence cell | [inferred] | Offer it as a fact about the checklist, not as shared identity. R1 asks about his path |
| Tobias runs the Outage Hour for this role | Careers page names the hiring manager; the assumption that this is Tobias is mine | [inferred] | If the recruiter names someone else, reweight the persona table |

## Persona table

The loop is established by Saltmarsh's careers page (fetched): a recruiter call, then one 60-minute session with the hiring manager made of a live-incident tabletop and a values conversation. No archetype fallback is used.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist | The tabletop: a simulated outage during a live event | Highest. The careers page documents it as the first half of the hour | Clarify, objective, approach, communication, record for the review. Think aloud and challenge one premise | 5 questions (A) |
| Values / Behavioral | The second half: a values conversation against three published values | High. The careers page documents it, and the values page names three | One story or honest branch per value; "we" for context, "I" for what you did | 4 questions (B) |
| Skeptic | Probing your two stated gaps and the calendar's scope | Medium-high. A hiring manager derisks gaps, and Project Larkspur makes the in-app-purchase gap live. `[inferred]` | Rehearse C1 until boring; concede plainly, hold what your sentences carry | 3 questions (C) |
| Data-Driven Prober | Your retention numbers and what happened after a drop | Medium. The JD names retention and KPIs, and the published talk is about accuracy of what shipped. `[inferred]` | Say how much you know about how the numbers were counted, and say plainly where you do not | 3 questions (D) |
| Pressure | A time-boxed tabletop, "why you" in sixty seconds | Low-medium. Not documented; a tabletop plausibly runs on a clock. `[inferred]` | Pause, restate, hold through two follow-ups, concede specifically | 2 questions (E) |
| Conversational | The opener | Low-medium. A 60-minute session usually opens with your background. `[inferred]` | A 90-second arc from your own sentences | 2 questions (F) |
| Peer Evaluator | — | Left out: the careers page names only the hiring-manager session | — | — |

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's the first hour of a weekend event and the event screen crashes for a slice of players. You're the producer on call. Walk me through your first fifteen minutes." | CASE | [inferred] | Think aloud in order. Clarify: who is affected, since when, what changed, what is known versus guessed. Objective: protect players first, then the event. Who you pull in and what you ask each: engineering for cause and options, QA for whether the last build went through the release checklist, community for what players are saying, design for what the event can tolerate. Make a call with what you know and say what would change it. Say what players are told and when, and what you would record for the review afterwards. State a hypothesis early and name what you do not know. This question needs no claim about your past, so the guidance makes none | The careers page documents a live-incident tabletop on a simulated outage during a live event; the scenario details are this pack's own, which is why it is `[inferred]`. CASE because it is a live problem; it also touches F2's coordination and F4's checklist |
| A2 | "Write me the player notice for that outage, two sentences. What does it say, and what does it leave out?" | JD | [grounded] | The notice says what is known and what is built, and leaves out anything hoped for: no fix time you cannot back, no reward promised before it is confirmed. Say aloud which sentence you would cut if engineering has not confirmed the cause, and what you would send next and when. Saltmarsh's published value is "we announce what is built, not what is hoped"; do not name the value unless asked. This question needs no claim about your past, so the guidance makes none | F8 is the thinnest row and the JD asks for clear written communication, so it is tested live. JD content, CASE delivery. The `[grounded]` label rests on the values page, fetched. It is also where Tobias's published theme, patch notes as a promise, is most likely to appear |
| A3 | "Engineering says the fix needs four hours. The event's biggest reward window closes in two. Do you extend the event?" | CASE | [grounded] | Make a call and say it first, then the reasoning. Ask what you would need to know: how many players are affected, what extending moves elsewhere on the calendar, what players have been told so far. Anchor the decision in players first; the published value reads "when the calendar and the players disagree, the players win". Concede what you cannot know from here, and say what would change your decision. This question needs no claim about your past, so the guidance makes none | A decision under a clock, tied to the first published value. CASE; `[grounded]` on the values page, though the scenario is this pack's own |
| A4 | "A designer wants to push a small event tweak live tonight without a QA pass, because players are dropping off. Where do you land?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Say where you land and why before you qualify it, then what you would want QA to confirm at minimum. About your own past, say only this: "I wrote the release checklist our QA team still uses." Answer slot: the JD's line on managing the release checklist with QA makes a probe on how the checklist treated urgent changes likely. If the one you wrote had a route for them, say what it was, in your own words; if it did not, or that was not yours to set, say so plainly and stay with the checklist you wrote | F4 is your strongest sentence and Tobias is a former QA lead, so this is the seam Tobias is likeliest to test. CASE with JD content |
| A5 | "Project Larkspur puts both titles on one shared events calendar from February 2027. What would you want to know before you planned it, and what would you watch in the first season?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Use only what was announced: a season-pass model for Tidepool Tactics and Lantern Row, one shared events calendar from February 2027, per-title event teams replaced by a single live-ops group. Do not recite it; bring one thesis and the questions behind it: which events must stay title-specific, what the retired per-title teams knew that a single group could lose, what the first season is meant to prove. Do not claim to know how the JD's two titles map onto Larkspur; ask in R2. If season-pass economics come up, say plainly: "I've never worked on a game with in-app purchases", then ask what the team trusts as a measure | The differentiator question: a CO/CASE grounded in current strategy, which most candidates will not touch. Read from a search-result snippet only, so nothing beyond the announced facts is safe to assert. F9 is why the acknowledgment sits in the guidance |

### B. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Players Before Plans. Selection scaffold: pick a time when what was scheduled and what players needed pulled apart. It needs a named decision, what you did, which part was yours, and what players saw afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "For the last two years I ran the weekly content-drop calendar for our main title", or how you would handle it | The first published value, asked in the form its own definition invites. F1 is the only sentence that touches the calendar, so the scaffold ends in the honest branch rather than a story |
| B2 | "Tell me about a time you announced something, or held back an announcement, because of what was actually built." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Ship the Patch Not the Promise. Selection scaffold: pick a time when what went out matched what was ready, or you chose not to say something yet. It needs a named stake, what you did, which part was yours, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I wrote the release checklist our QA team still uses", or how you would handle it | The second published value, and the one closest to Tobias's talk. F4 is the nearest sentence but does not describe an announcement, so the honest branch is the default |
| B3 | "When have you left a process better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Leave the Build Greener. Story map: "I wrote the release checklist our QA team still uses" gives you two beats, that you wrote it and that QA still uses it; tell them in your own words. Answer slot: the value speaks of leaving the checklist better with every release, so expect a probe on whether it changed after you wrote it. If you revised it after a release, say what changed and why; if it stayed as first written, or others revised it, say so plainly and stay with the checklist you wrote and the fact that QA still uses it | The third published value, and the only one where F4 carries a story. VAL because it scores behavior against the value |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Story map: the setting your sentence gives is "I presented the monthly retention numbers to the studio head." Answer slot: if any month's numbers were unwelcome, say what you said and how it landed, in your own words; if none were, or you only passed them on, say so plainly and give the nearest thing or how you would handle it | A standard values-round stem rather than a published value, included because F7's sentence is the one place you stood in front of leadership. Pick a story where the hard truth landed; if your material shows none, say so rather than supplying an ending |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases, and Project Larkspur puts both titles on a season pass. What do you do about that in your first month?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. Concede first and plainly: "I've never worked on a game with in-app purchases." Then say how you would learn it, as a plan: what you would read, who you would ask, what you would shadow. Name only what you would actually do. Hold what your sentences carry, at their scope: you ran the weekly content-drop calendar for your main title for two years, you wrote the release checklist QA still uses, you presented the monthly retention numbers to the studio head. Follow-up 1, likely "which part of this JD would you be weakest at on day one": answer with what your material does not show, and do not widen. Follow-up 2, likely "why take the risk": return to the three sentences, and never present retention work as revenue work | F9 is the biggest stated gap and the company's own announcement makes it central, so this objection arrives in some form. JD because it scores the role's context rather than a listed line. The hold is only what the quotes carry; the limit is named before it is asked for |
| C2 | "This role runs the events calendar for two titles at once. How would you run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | A plan, not a past. Structure it: what is shared and what stays title-specific, how you keep one cadence readable, where collisions show up first, what you would ask each title's teams before committing dates. About your own past, say only: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if any part of that calendar was shared with another title or team, say how; if it was one title end to end, say so plainly and say how you would run two | F1 is a transferability row: the JD's scope is wider than your sentence. JD because it scores the stated requirement |
| C3 | "You'd coordinate design, art, engineering and community on every update, and you've never led a team. How do you get four disciplines moving together?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases", "Wrote the release checklist our QA team still uses" | Say the acknowledgment first: "I haven't led a team." Answer slot: say which of the four disciplines you have worked with on a drop and how, in your own words; if none, or it was not part of your role, say so plainly. Then the plan: what each discipline needs from a producer, what you would ask each first, how you would settle a disagreement. Hold on "I wrote the release checklist our QA team still uses" and add nothing to it | F2 is a discovery row with a stated negative beside it, so the question is about coordination without authority rather than leadership. JD because it scores the stated requirement |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which retention numbers did you present each month, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Defend-the-number. Start with what your sentence states: "I presented the monthly retention numbers to the studio head." Answer slots, each in your own words: how those numbers were counted; what they were most sensitive to; which assumption behind them you would defend least; which part of the work was yours. If you do not know how a number was counted, say so plainly. Name the weakest assumption before the interviewer does. Do not name a method you cannot repeat under a second question | F7 is the row a prober reads line by line. EXP because it tests whether the claim survives scrutiny. Nothing about how the numbers were counted is in your material, so every slot is yours |
| D2 | "When a drop went out, how did you tell whether it had worked?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: the JD's review line makes this probe likely. If you looked at numbers after a drop went out, say which and what you did with them, in your own words; if you did not, or the numbers were someone else's, say so plainly and stay with presenting the monthly retention numbers. Never describe a measure you did not track | F3 is a transferability row. The question lets the premise be false: your material shows presenting, not a review |
| D3 | "What would a post-event review report on a season-pass event, and which number would you trust least?" | CASE | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Structure: the event's goal first, then what you would measure against it, then which measure is weakest and why. Retention is named in the JD, so start there; ask what else the team already trusts rather than listing measures you have not tracked. If revenue measures come up, say plainly: "I've never worked on a game with in-app purchases", and ask which ones the team relies on. Name the number you would trust least and the assumption behind it | F3's KPIs line met with F9's gap, as a live problem. CASE because it asks about no past |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events on two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Never led a team, and never worked on a game with in-app purchases" | Pause and restate the question. Hold, then concede. Hold on two sentences at their scope: "I ran the weekly content-drop calendar for our main title for the last two years" and "I wrote the release checklist our QA team still uses." Concede plainly: "I haven't led a team and I've never worked on a game with in-app purchases." Do not compare yourself to the other person. Hold through two follow-ups by returning to the sentences, not adding to them | F5 and F1 are where a comparison with a more experienced candidate bites. JD because it scores fit against the stated requirements |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours to set and which were set for you, in your own words; if others set the content or the dates, say so plainly. Hold through two follow-ups by returning to the sentence, not adding to it | An attribution probe on F6, the claim a time-boxed interviewer tests first. EXP because it scores what was actually yours |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | A 90-second arc, in order, built from those four sentences and nothing else: the four years and the title, the calendar, the checklist, the monthly retention numbers. Answer slot: why live operations, why Saltmarsh and why now are your own reasons and none are supplied here; if a reason is still forming, say so plainly | The biography question is scored even when it feels casual. F5 is the row it supports |
| F2 | "What are you actually playing in live ops these days?" | CO | [grounded] | Name a live game you actually play or follow, what its events do well or badly, in your own words. Saltmarsh's two titles per its announcement are Tidepool Tactics and Lantern Row: if you have played either, say what you noticed; if you have not, say so plainly rather than describing them. This question needs no claim about your past, so the guidance makes none | A casual question on the JD's topic, scored for genuine interest. `[grounded]` on the two titles named in the Larkspur announcement |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | C2, A5, E1 |
| "coordinate design, art, engineering and community teams on each update" | C3, A1 |
| "own the post-event review and the KPIs it reports" | D2, D3 |
| "manage the release checklist with QA" | A4, B3 |
| "3+ years producing live-service games or apps" | E1, F1 |
| "experience running a content calendar" | E2, B1, C2 |
| "comfortable with player-retention metrics" | D1, B4 |
| "clear written communication" | A2 |

## Values cheat sheet

Values are Saltmarsh's published names, from its values page (fetched). The careers page documents a values conversation in the loop.

| Value | Working meaning, paraphrased | Mapped story |
|---|---|---|
| Players Before Plans | When the schedule and what players need conflict, players come first | F1 evidence: "I ran the weekly content-drop calendar for our main title for the last two years". It carries the setting only. Selection scaffold in B1, ending in its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F4 evidence: "Wrote the release checklist our QA team still uses". It carries no announcement story, so B2's scaffold ends in its honest branch |
| Leave the Build Greener | Each release leaves the codebase and the checklist better than it found them | F4 evidence: "Wrote the release checklist our QA team still uses". Two beats, written and still used; B3's answer slot asks whether it changed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live operations from QA lead, and your GDC talk argues a live team is judged by whether its patch notes describe what actually shipped. What does a producer do day to day to protect that?" | Ties to the interviewer's own path and published argument, which signals you researched the person rather than only the company. Say it only if the snippet's description matches what you find in the talk itself |
| R2 | "Project Larkspur moves to a single live-ops group from February. Where does this role sit in it, and are the two titles in the JD those two?" | Surfaces scope you cannot learn from the posting and shows you read the announcement. The answer reweights C2 and A5 |
| R3 | "How does a post-event review work today: who owns which numbers, and what changes after one?" | Ties to the JD's review line and shows you are thinking about the work rather than the title |
| R4 | "How do design, art, engineering and community agree an update is ready, and where does the release checklist sit in that?" | Ties to the JD's coordination and checklist lines; answers whether the checklist is a gate or a record |
| R5 | "What would you want this person to have changed by the end of the first season?" | Asks for the interviewer's own definition of success rather than offering yours |
| R6 | "Where would a producer without in-app-purchase experience get up to speed fastest on how the season pass works here?" | Use only after C1 has come up. It turns the gap into a plan and asks for the interviewer's own view of how to close it |
| R7 | "After the Outage Hour, what separates a strong tabletop from an adequate one on your team?" | Shows you treat the tabletop as a skill rather than a hurdle, and tells you what the interviewer scores |

## Sources

Provided documents: the JD text and your background, both in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches sent:

| Query | Returned |
|---|---|
| Saltmarsh Games values | https://saltmarshgames.com/values |
| Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Saltmarsh Games strategy news mobile | https://saltmarshgames.com/news/project-larkspur |
| Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise |

Fetches sent: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both returned. The Larkspur announcement and the talk page were read as search-result snippets only.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | The three published value names and definitions; the VAL bank and the values cheat sheet |
| 2. Interview process | yes | The loop: one 60-minute hiring-manager session, a tabletop then a values conversation, no take-home. Persona weights and A and B banks follow it; no archetype fallback used |
| 3. Company strategy and recent news | yes | Project Larkspur, September 2026: A5, C1, F2, R2. Snippet only, so only the announced facts are used |
| 4. Interviewer name and company | yes | The interviewer read and R1. Snippet only, so the read is thin |
| 5. Representative role JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on Larkspur and the competitive frame, and more of Tobias's published talks, which would firm up A5 and R1
- The Larkspur announcement and the GDC talk, pasted or linked → A5 and R1 move from snippet-level to what the sources actually say
- Your answers to the answer slots in F1, F2, F3, F5, F8 and C3, said once outside a drill → those rows become quoted evidence and the slots upgrade to story maps
- The release checklist itself, or a calendar export or retention deck you presented → F4, F6 and F7 can move from `medium` toward `high`
- Your CV text → the rows currently built from your message alone gain a second source, and F5 may show whether the main title was a live service
- The recruiter's notes on what the tabletop covers → A1 to A4 can be retuned to the format rather than the documented outline
- A `tuesday-dossier.md` from an earlier evaluation, if you have one → verified evidence and prohibited claims arrive ready-made; this pack does not need one
