I'll read the reference files the skill points to before building anything.
Pack's written. I'm removing one leftover section that shouldn't be in the file, then I'll hand it over.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-3-denied-2bb9c12b/stripe_product-operations-manager_interview_pack.md`.

I built it from your message alone, for a final round where I don't know who you're meeting. I tried four web searches (Stripe's values, its interview process, its strategy, and a sample job description) and none was permitted. So the pack has no Stripe-specific facts. Every cell is generic, and the Sources section records the refused searches. It has 21 questions across seven interviewer styles, a six-row fit worksheet, reverse questions, and an upgrade menu. B1, "Which part of this role would you be weakest at on day one?", is flagged as your highest-value prep. It's picked from the round type alone, so it will change once I see your CV.

Say the word and I'll play the Skeptic on B1, then run follow-ups and give you feedback.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is your final round with: a future manager, a peer, a skip-level or a cross-functional interviewer, and did the recruiter name any focus areas or a deliverable? The answer reweights every question bank.

Can you paste the job description and your CV, or tell me to go on without them? With them, the generic scaffolds become answers built from your own sentences.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

- **Role / company:** Product Operations Manager, Stripe
- **Round:** final round; the number of sessions, who runs them and their relationship to you are not known
- **Interviewer:** none named
- **Built on:** your message alone. No JD, CV or recruiter notes were supplied, and web research was not permitted this turn, so this pack contains no Stripe-specific facts. Everything is labeled `[generic]`, and the upgrade menu says what adding each input unlocks.

## How to use this pack

- **Personas are how a question is asked; types are what it is scoring.** Rehearse both: a skeptical quiet voice and a time-boxed challenge can carry the same content.
- **Guidance is scaffolding, not a script.** It never supplies a fact about your past. Where a story is needed, you choose it from your own experience, and every selection scaffold ends with an honest branch for when no such story exists.
- **Type key**

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the principles the company publishes |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny; what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth; thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Fit snapshot

No background material was supplied, so this is the worksheet variant: every evidence cell reads `none given`. The requirements are role-family patterns for a product operations role, written as plain prose with no source quoted, because no JD was supplied. Replace them with the real JD lines and fill the evidence column from your CV, and these rows become a real map.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or releases across product, engineering, legal, support and go-to-market teams (role-family pattern, no source quoted) | none given | none | [generic] | discovery | Strong evidence is a launch or release you coordinated, with the teams involved, your part in it and how it ended, in your own words. Selection scaffold: pick a time several teams had to move together; it needs a named stake, your part, and an ending you can describe. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Build and run product operating mechanisms such as planning cadences, review forums and status reporting (role-family pattern, no source quoted) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or ran, what it was for and what changed because of it. Selection scaffold: pick a process that still ran after the first month; say who used it and what you owned of it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would build one |
| F3 | Use data to track product health and inform decisions (role-family pattern, no source quoted) | none given | none | [generic] | discovery | Strong evidence is a metric you reported on, how it was counted and what decision it fed. Selection scaffold: pick one figure you can explain in four parts: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set one up |
| F4 | Influence senior stakeholders and teams without direct authority (role-family pattern, no source quoted) | none given | none | [generic] | discovery | Strong evidence is a time you moved people who did not report to you and the relationship that survived. Selection scaffold: pick a disagreement with a stake, a moment you did not fold, and an intact relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Structure ambiguous problems and drive them to a decision (role-family pattern, no source quoted) | none given | none | [generic] | discovery | Strong evidence is a problem that arrived undefined and the structure you gave it, in your own words. Selection scaffold: pick a problem with no owner at the start; say what you clarified first. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one |
| F6 | Communicate clearly in writing: briefs, updates, decision documents (role-family pattern, no source quoted) | none given | none | [generic] | discovery | Strong evidence is a document others acted on, which you can bring or describe. Selection scaffold: pick one written piece whose reader changed what they did. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would write one |

## Persona table

No loop source establishes the structure of this final round, so the weights below rest on round-type priors, not on a documented Stripe process. They blend the priors for a hiring manager, a skip-level, a peer and a cross-functional interviewer, since the pack does not know which of them you meet.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A, 5 questions) | A live problem from the role: a launch at risk, a process nobody follows, a metric to choose | High. Hiring-manager and skip-level priors both lead with it, and the role is operational by nature | Clarify, state the objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (bank B, 4 questions) | Quiet probing of day-one weakness, motivation and why now | High. The hiring-manager prior pairs it with Case, and a final round is where residual doubt gets tested | Rehearse the likeliest objection until it is boring; bridge only from adjacent things you actually did; add a concrete ramp plan |
| Peer Evaluator (bank C, 3 questions) | Seam-splitting with adjacent teams, credit, what you would need from them | Medium. A peer may be in the loop for a cross-functional role, but the pack does not know that | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober (bank D, 3 questions) | Denominators, definitions, which assumption you would defend least | Medium. Peer and technical-specialist priors lift it, and any metric you cite becomes a target | Know how each figure was counted; say plainly when you do not know; name the weakest assumption before they do |
| Values / Behavioral (bank E, 2 questions) | Scenario probes tied to published values | Lower. No values-style round is detected: no loop source names one and the fallback archetype for an unknown loop has none. It is a guess, so keep the two questions | Map a story to each published value once you have the values; until then, use the scaffolds |
| Pressure / Stress (bank F, 2 questions) | Time-boxed challenges, "how much was actually you" | Lower. The skip-level prior brings it, but nothing says one is on your schedule | Pause, restate, anchor in what you actually said, hold through two follow-ups, then concede specifically |
| Conversational / Rapport (bank G, 2 questions) | Friendly openers that are still scored | Medium. It arrives in every loop as the first five minutes | A 90-second arc you have rehearsed; treat casual questions on hot topics as scored |

## Question banks

Highest-ROI prep in this pack: **B1**. It is named from the round type alone, so replace it with the real objection once your CV and the JD are in.

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two weeks before a major launch, engineering says the date holds, support says it is not ready, and legal has an open question. You own the launch process. What do you do first?" | CASE | [generic] | Clarify before structuring: what does ready mean here, who makes the go or no-go call, what can be undone after launch. Then separate blockers from non-blockers, give each blocker one owner and one date, name a single forum where the decision is made, and say what you would record and tell people. Challenge one premise aloud, such as whether the date is the real constraint | A live problem from F1 and F5. CASE because it asks for structure on a problem set in the role, and it presupposes nothing about your past |
| A2 | "A product review process exists on paper, but teams route around it. Diagnose it." | CASE | [generic] | Offer three or four hypotheses: the cost exceeds the value, ownership is unclear, the timing is wrong, nothing follows from skipping it. Say how you would test each cheaply, for example by talking to a few of the teams, then name the smallest change you would try and how you would know it worked | Tests F2 and F5. CASE because the answer is a method, not an experience |
| A3 | "How would you decide which product-health metrics a leadership review should see each month?" | CASE | [generic] | Start from the audience and the decisions the review actually makes. Pick few metrics, each tied to a decision, each with one named owner and a written definition. Say what you would remove and how you would catch a metric that stops meaning what it did | Tests F3. CASE with JD content; it asks for design, not for a past result |
| A4 | "Why Stripe, and why this role in particular?" | CO | [generic] | The pack could not research Stripe, so it supplies no reasons. Give two things you have checked yourself in Stripe's own published material, then one reason from your own work that connects to this role. If you have not yet checked anything, do that before the interview, and say so plainly if asked | Almost certain in a final round. CO because it scores homework, and it stays generic until research runs |
| A5 | "What does a product operations manager do that a product manager or a program manager does not?" | JD | [generic] | Say in your own words where the roles overlap and where they split, in two or three sentences. If your view differs from the interviewer's, say so and ask how they see it | Tests whether you can define the job you are applying for (F1 to F5). JD because it scores understanding of the role |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Choose the area from F1 to F6 where you have the least evidence and name it plainly. Then give a first-30-days plan as a plan, not as a past claim. Do not pick a fake weakness. Hold the one you named through two follow-ups; if you cannot name one, say so and name where your evidence is thinnest | Every F row is open, so this question will arrive in some form. JD because it scores honest self-assessment against the role |
| B2 | "Why are you looking to leave your current role, and why now?" | EXP | [generic] | One sentence with your own actual reason, framed forward, consistent with your answer to A4. Add no filler and no complaint you would not repeat to your current manager | Motivation consistency. EXP because it is about your own history |
| B3 | "How would you get a team that does not report to you to adopt a process it did not ask for?" | CASE | [generic] | Start with what the team gets, ask what would make adoption costly for them, pilot with one team, keep the ask small, and say how you would handle a team that still declines. Use your own experience only where it genuinely fits | Tests F4. CASE delivery on JD content |
| B4 | "Which of your past experiences is closest to this job, and where does it fall short?" | EXP | [generic] | Choose from your own material the experience that maps most closely, say where it stops, and say what you would learn first. If nothing comes close, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Pre-empts the gap probe across F1 to F6. EXP because it asks you to choose and bound your own evidence |

### Bank C: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Offer principles rather than pretending to know the seam: who owns the decision, who is consulted, how a disagreement escalates and how it is recorded. Say what you would do before escalating | Tests F4 in collegial packaging. CASE because it asks for a working model |
| C2 | "How do you handle credit when work spans teams?" | EXP | [generic] | State your principle in one sentence, then use an instance from your own experience if one comes to mind: "we" for context, "I" for what you contributed. If no instance comes to mind, say so plainly and describe how you would handle it | Credit-sharing probe from a peer. EXP because the instance has to be yours |
| C3 | "What would you need from me in your first month?" | JD | [generic] | Ask for specifics: the decisions your work feeds, the people to meet, the data you need access to. Then add what you offer their team, so the answer is reciprocal | Reciprocity signal for a peer. JD because it tests how you would start the role |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a number you reported on or owned. How was it counted?" | EXP | [generic] | Choose a figure you can explain in four parts: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Name the weakest assumption before they do. "I don't know how that part was counted" is an honest answer. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry | Prober stem; tests F3. EXP because it checks attribution |
| D2 | "A dashboard shows an adoption metric up 15 percent this week. What do you check before telling leadership it is good news?" | CASE | [generic] | Check the definition and whether it changed, the denominator, the time window, seasonality, a one-off cause, and whether a second metric moves with it. Say what you would report and with what caveat | Tests F3 as a live problem. CASE because it presupposes nothing about your past |
| D3 | "Walk me through an analysis you did yourself, end to end." | EXP | [generic] | Choose an analysis you can describe from question to decision: what you were asked, what data you used, what you found, and what happened next. Offer to go as deep as they like. If no analysis of yours comes to mind, say so plainly, then give the nearest thing your material does carry | Prober counter-strategy: offer the end-to-end walk. EXP because it separates your analysis from others' |

### Bank E: Values / Behavioral

Published Stripe values were not retrieved, so these two questions use generic stems. Swap them for the named values once they are in hand.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose a time with a named stake, a moment you did not fold, and an ending where the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Values-persona stem; tests F4. VAL because it scores behavior under pressure, not skill |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Choose a time the two pulled apart: name the metric, name what the customer needed, and say what you did and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh it | Values-persona stem. VAL because it scores judgment between two goods |

### Bank F: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate the question. Anchor in your own reasons from A4 and B4, say nothing about the other candidate, hold through two follow-ups, then concede one specific thing you do not know about the team | Pressure stem. JD because it scores fit against the role under time pressure |
| F2 | "Take the project you are proudest of. How much of that outcome was actually you?" | EXP | [generic] | Split it aloud into what was yours, what was shared and what was others'. Use "I" for your contribution and "we" for context. Hold through two follow-ups, then concede the specific part you cannot attribute. If no project comes to mind, say so plainly and use the nearest thing your material carries | Attribution probe. EXP because it tests what was actually yours |

### Bank G: Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc: where you started, two turning points of your own choosing, and why this role is next. Once your CV is added, the pack can build it from your own sentences | Casual opener that is still scored. EXP because it is your own history |
| G2 | "What are you playing with at work these days, in tools, processes or ideas?" | JD | [generic] | Name one real thing you are trying or learning and why it interests you. If nothing comes to mind, say so plainly and say what you would explore first in this role | Rapport probe on role-relevant curiosity. JD because it scores interest in the craft |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Launch and release coordination | A1, B4 |
| F2 Operating mechanisms | A2, A5 |
| F3 Data and product health | A3, D1, D2, D3 |
| F4 Influence without authority | B3, C1, C2, E1 |
| F5 Structuring ambiguity | A1, A2, A5 |
| F6 Written communication | none: no question here, because written work is usually assessed through an exercise, not a question; ask the recruiter whether one is planned |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make the first ninety days a clear success for this role?" | It shows you are thinking about outcomes, and the answer tells you what the team weighs most |
| R2 | "Which part of product operations is least settled here today?" | It signals comfort with ambiguity and invites the real problem list |
| R3 | "How do product, engineering and the teams around them decide who owns a launch decision?" | It connects to the seam questions you will face and shows operating-model thinking |
| R4 | "What does good look like for how this team measures its own impact?" | It shows you think about measuring the function, not only the products |
| R5 | "What would you want a new person on your team to do in their first month that would genuinely help you?" | A reciprocity question, useful whichever relationship you turn out to have with the interviewer |
| R6 | "How is this final round structured, and who will I meet?" | A process question with a preparation reason; it lets you reweight this pack before the day |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any statement about your past work, scope or results | No CV or other material about you was supplied, so nothing is quoted and nothing can be coached as a claim | Your own words, once material is added. Until then every guidance cell is a selection scaffold that ends with an honest branch |
| Any fact about Stripe's values, hiring process or strategy | No research ran, and model memory is not a source for these | Left out. The Stripe-specific cells say so and stay `[generic]` until research or a pasted source is available |

## Sources

- **Provided documents:** your message (company, role, round). No dossier, JD, CV or recruiter notes.
- **Searches sent:** all refused, so nothing came back and nothing from them is used.
  - "Stripe operating principles values" — refused
  - "Stripe interview process Product Operations Manager" — refused
  - "Stripe strategy news 2026" — refused
  - "Stripe Product Operations Manager job description responsibilities qualifications" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Every call was refused. It would have fed the values cheat sheet and the VAL bank |
| 2. `Stripe interview process product operations` | unavailable | Every call was refused. It would have fed the loop structure and the persona weights |
| 3. `Stripe strategy` / recent news | unavailable | Every call was refused. It would have fed the CO question A4 and a strategy-grounded CASE |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Every call was refused. It would have turned the six role-family rows in the fit snapshot into sourced requirements |

## Upgrade menu

- The JD text → the six role-family rows in the fit snapshot become real requirements in the JD's own words, and every JD-tagged question can be checked against them
- Your CV or a few lines on your background → the fit snapshot's evidence column fills with your own sentences, scaffolds become story-mapped answers, and B1 is replaced by your real likeliest objection
- Who you are meeting and how (manager, peer, skip-level, cross-functional) → persona weights stop being a blend, and banks are added or dropped
- The interviewer's name → an interviewer read and a reverse question tied to their own path
- The recruiter's prep email, with any focus areas or pre-declared deliverables → coverage of whatever is graded, and a build section for any deliverable
- Permission to search the web → Stripe's published values, documented loop structure and current strategy replace the generic cells, and a values cheat sheet appears if a values round is documented; a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is available on top of that
- Your prep time → a prioritized schedule sized to it
- If your final is several sessions, send the schedule → per-session mini-packs with their own persona weights
- A tuesday-dossier.md from an earlier job-underwriter run, if you have one → verified evidence and any prohibited claims come in as constraints on every guidance cell
