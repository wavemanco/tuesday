I'll read the reference files the skill requires before writing.
Dara, your prep pack is saved at `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-8-denied-42c867ec/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it for all three rounds on 4 December, using the recruiter's description of each. It has a shared fit snapshot and a short question bank for each round, 29 questions in all. The values cheat sheet sits with the panel round. No interviewer names are assigned, so there are no interviewer profiles. I ran no web searches, because your pasted JD, values, recruiter email and strategy points already covered what research would have.

The question to rehearse first is **B4**: "Which part of this job would you be weakest at on day one?" The JD names the contact centre outright and you've never worked in one, so expect it in some form in all three rounds. The pack gives you the concession in your own words and a plan to follow it.

Three things to know before you rehearse:
- **Gaps are quoted back at the scope you gave.** The contact centre and presenting above regional level appear as plain acknowledgments, followed by a plan.
- **Several JD lines are answer slots.** Your material doesn't show what the monthly spreadsheet counted, whether it was Excel, whether any complaints were regulated, or any work with digital teams. Each of those has two honest branches to rehearse: say how you did it, or say plainly you didn't.
- **The four values are rehearsed as story scaffolds, not scripts.** None of your sentences carries a full values story yet, so each value ends in an honest "if nothing comes to mind" branch.

Say the word and I'll play the Skeptic on B4 live, with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop:** three rounds on 4 December 2026 (written 25 November 2026), built in loop mode from the recruiter's own description of the rounds.

| Round | Who | Length | What it is |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Recruiter conversation |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four published values |

No interviewer names are assigned yet, so there is no interviewer read. Everything below is built from your JD, your message, the recruiter's email, the values text and the strategy brief points you gave me.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only what you actually did.

An answer slot is an instruction for the interview, not a question for me. It tells you where an interviewer is likely to probe and gives two honest branches: say how, if you did it, or say plainly that you did not or it was not yours, and return to what you did.

Wording the pack proposes for you to say is pending your approval: change anything that is not how it happened.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the company's strategy and can think at its level |
| CASE | A live problem from the role: structure and reasoning |

Persona letters: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Peer Evaluator, F Pressure. Numbers run across the loop, so B4 is the fourth Skeptic question overall, not the fourth in a round.

**Highest-ROI prep: B4.** The JD names the contact centre outright and you have told me you have never worked in one, so some version of "which part would you be weakest at" will arrive in round 1 (B1), round 2 (B4) and round 3 (F1). Rehearse B4 until the concession and the plan come out boring.

## Fit snapshot (shared by all three rounds)

JD requirements are quoted from the JD you supplied. Evidence is your own words from your message, nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on what you decided likely. If you made any decision about a complaint on the log, say which and how you made it, in your own words; if the log was a record and the decisions sat with others, or there was no such step, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote shows a monthly complaints spreadsheet that your regional manager uses; it does not show what the spreadsheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if the spreadsheet counted anything, say what and how each figure was counted, in your own words; if it was a record without figures, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel; the pack's derivation is that it may have been Excel, and nothing here confirms it. Answer slot: if you built it in Excel, say so and what you did in it, in your own words; if it was another tool, say which, and say plainly that Excel was not the tool |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The quote already carries the length. Say it in its own terms: "I have six years in retail banking, the last three as a branch supervisor." Do not rename it in the JD's vocabulary; let the interviewer make the link |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | The quote says formal, not regulated; the pack's derivation is that the two may overlap, and nothing here shows it. Answer slot: if any complaint on the log had a deadline or set steps you worked to, say which, in your own words; if none did, or you do not know, say so plainly and stay with the log you handled |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says tellers, not supervisors, and the words stay at that scope: "I trained new tellers on our escalation script." Answer slot: if you ever worked through a real escalation with a teller, say what happened and what part was yours; if the training was only the script, say so plainly and stay with it |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Nothing added about presenting you have not described |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital teams. Answer slot: if you have worked with a digital or app team on how members do things for themselves, say what it was and what part was yours, in your own words; if you have not, say so plainly and say what you would ask them first |

Proposed wording above is pending your approval.

## Grounding brief: Ashgrove's 2026 strategy (as you gave it)

The four points are from the July 2026 strategy brief the recruiter sent you, as you relayed them; the member-owned and 900-staff description is from the JD. Use the vocabulary: member service, digital channels, hubs, member-owned. The brief is about four months old on the day you are preparing.

| Item | From the brief or JD | Provenance | What it could mean for your answers (the pack's reading) |
|---|---|---|---|
| Digital | "move 40% of member service to digital channels by 2028" | [grounded] | Self-service journeys are the JD's fourth duty; expect complaints to be raised through channels that are not a counter. Feeds D1, A8 |
| Hubs | "consolidate eight branches into five hubs over 2027" | [grounded] | The two branch managers may be personally affected; I cannot tell, and no names are assigned. Treat it as context, not bad news. Feeds D3, C5 |
| Lending | "launch a small-business lending product in Q1 2027" | [grounded] | A new product brings new members and likely new complaints; a short mention shows you read the brief. No question is built on it |
| Competition | "the main competitive pressure is app-only banks" | [grounded] | The reason digital matters, and the foil for "why Ashgrove". Feeds A7 |
| Identity | "member-owned, about 900 staff" — JD | [grounded] | Neighbours and members, not customers; say "member" |

The brief is available to every candidate the recruiter sent it to. Bring one item from it to show you read it, then add your own view; reciting it scores as homework.

## Persona table (weights per round, with reasoning)

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 | A Conversational | Friendly chat; logistics, journey, why Ashgrove | High. Recruiter conversations prior to Conversational plus light Skeptic; the recruiter named this round as 30 minutes with them | A 90-second arc; treat every casual question as scored; give your own logistics answers |
| 1 | B Skeptic (light) | Knockout checks on the JD's named gaps | Medium. The JD names the contact centre outright and you have told me you have never worked in one | Concede exactly, then give the plan; see B4 for the full rehearsal |
| 2 | C Values/Behavioral | Stories about escalations, disagreement, hard truths | Highest. The recruiter called this round "mostly behavioural" | Choose a story you can name beats for; if none comes to mind, say so plainly and give the nearest thing you did |
| 2 | B Skeptic | Probes the gaps: contact centre, senior presenting, how much was yours | High. The Head of Member Services would be your manager, so is buying capability and weighing gaps; F2 and F8 are stated | Hold-then-concede; return to the quotes, never add to them |
| 2 | D Case/Strategist | One question on how digital changes complaints | Low-medium. Manager prior includes case work, but the recruiter said mostly behavioural | Clarify, structure, use Ashgrove's vocabulary |
| 2 | A Conversational | Why Ashgrove, digital teams | Low-medium. A manager round still opens warm | Short, your own reasons |
| 3 | C Values/Behavioral | One question per published value | Highest. The recruiter said the panel scores against the four values | One real story per value, or the honest branch |
| 3 | D Case/Strategist | The 20-minute complaint escalation case, plus hubs | High. The recruiter said 20 of the 60 minutes are a case | Clarify, owner, member's words, record, root cause, measure |
| 3 | E Peer Evaluator | Where the lead's job ends and the branches' begins | Medium. Branch managers run the branches whose supervisors you would coach; this reading is the pack's | Seam principles, reciprocity, a disagreement style with spine and tact |
| 3 | B Skeptic and F Pressure | Spreadsheet attribution; why you over a contact-centre candidate | Low-medium. Panels blend each member's top styles; the values frame may soften it | Same hold-then-concede as round 2 |
| 3 | A Conversational | Explain it in plain words | Low. Fits the Plain Words value | Short sentences, no jargon |

## Round 1: the recruiter (30 minutes)

Pay, notice, location and why you are leaving are the logistics a recruiter conversation checks. Each has a row below. You have not given me a figure or reason for any of them, so each slot is an instruction to give your own.

### Conversational (primary)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role asks for four or more years in financial-services customer operations. Talk me through how your background fits." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in three beats, each a clause you stated: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you built the monthly complaints spreadsheet your regional manager uses. Tell them in your own words and stop; let the interviewer draw the fit to customer operations | F5 is the years requirement and the opener; JD because it scores the stated requirement. F1 and F3 are the two beats an interviewer will likely follow |
| A2 | "What salary are you looking for?" | JD | [generic] | A logistics slot. Give your own figure or range, or ask for the role's band first and respond to it. If asked what you earn now: "I'd rather focus on the range for this role". The pack supplies no figure | You have not told me a pay expectation. Pay is the listed job's term, so it is tagged JD |
| A3 | "What is your notice period?" | JD | [generic] | A logistics slot. Give your actual notice period in your own words | You have not told me a notice period; recruiters ask in every screen |
| A4 | "Where are you based, and does the location of this role work for you?" | JD | [generic] | A logistics slot. Say where you are based and what travel or commute you can do, in your own words. The JD states no location, so also ask where the role sits | Location is a term of the job; with eight branches becoming five hubs, where the role sits is a fair thing to ask |
| A5 | "Why are you looking to move?" | EXP | [generic] | A logistics slot. Give your own reason in a sentence or two, aimed at what you want from this role if that is true. No criticism of your current employer | The recruiter checks consistency between your reason and the role; EXP because it is about your own history |
| A6 | "What do you know about Ashgrove, and why here?" | CO | [grounded] | Bring one point from the brief to show you read it, then add your own view in your own words on what it means for how members raise problems. The view must be yours | The brief gives the current strategy; CO because it scores homework depth. A recruiter often checks this before the Head of Member Services does |

### Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches. You haven't worked in one, have you?" | JD | [grounded] "Never worked in a contact centre" | The short version of B4. Concede first: "I have never worked in a contact centre." Then one sentence of plan in your own words, as a plan. Do not describe branch work as contact-centre work | F2 is a gap you stated; the recruiter will likely pre-screen it. JD because it scores a stated requirement |
| B2 | "Tell me about the formal complaints you've handled." | JD | [inferred] "I handled the branch's formal complaints log" | Say it as you stated it: "I handled the branch's formal complaints log." Answer slot: if any complaint on the log had a deadline or set steps you worked to, say which, in your own words; if none did, or you do not know, say so plainly and stay with the log you handled | The JD asks for regulated complaints; F6 is thin evidence, so this is where a screen would probe it |
| B3 | "How comfortable are you with Excel reporting?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Say you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it was in Excel, say so and what you did in it; if it was another tool, say which, and that Excel was not the tool | F4 is the weakest-supported JD line; a recruiter asks it as a knockout in a friendly register |

### Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Is it known yet who the two branch managers on the panel are?" | You are preparing for names that were not assigned; the answer sharpens round 3 |
| 2 | "What should I expect from the 20-minute case, and is there anything to read beforehand?" | The recruiter's own email describes it only by topic; a prepared candidate asks |
| 3 | "How is the contact centre structured, and who in it would I work with?" | Shows you are closing your gap before being asked |
| 4 | "Where is this role based?" | The JD states none; the answer settles A4 |
| 5 | "What happens after the panel, and when do you expect to decide?" | Logistics a recruiter can answer, and it closes the call |

## Round 2: the Head of Member Services (45 minutes, mostly behavioural)

### Values/Behavioral (primary)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a complaint was escalating and you stepped in." | VAL | [grounded] "I handled the branch's formal complaints log" | A selection scaffold. Pick one complaint you took part in: it needs what the member's problem was, what was yours to decide, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log". Do not supply an incident you cannot repeat under a follow-up | The JD's escalation language raises it; F1 is the nearest evidence and carries no incident. VAL because it asks for behaviour |
| C2 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [grounded] "I've never presented to anyone above regional level" | A selection scaffold. Pick a moment you said something unwelcome to a more senior person: it needs who, what you said, and the relationship afterwards. If no such time comes to mind, say so plainly. Your own limit is "I've never presented to anyone above regional level", so do not stretch a smaller moment into a bigger one | Persona stem; the JD asks for confidence with senior leaders, and F8 is a stated limit. VAL because it scores behaviour |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "I've never presented to anyone above regional level" | **The highest-ROI rehearsal.** Concede first, exactly: "I have never worked in a contact centre." Hold on what you stated: "I handled the branch's formal complaints log." Follow-up 1, how would you own it then: say your plan for your first weeks, as a plan, in your own words, including the first thing you would ask the contact-centre team; claim no knowledge of how they work. Follow-up 2, why not hire someone who has: do not run the other candidate down; return to the log and say what you would need. If asked for a second weakness: "I've never presented to anyone above regional level", then your preparation plan. Never fill either gap with experience that is not yours | F2 and F8 are stated gaps and the JD names both; this is the question most certain to arrive. JD because it scores the stated requirements |
| B5 | "How much of your branch's complaints handling was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log" | Hold: "I handled the branch's formal complaints log." Answer slot: if you made any decision about a complaint on the log, say which and how you made it; if the log was a record and the decisions sat with others, say so plainly and stay with the log. Hold through two follow-ups by returning to the log, never by adding to it | F1's quote says handled, not owned; an attribution probe is how a manager tests that. EXP because it tests what was yours |
| B6 | "The role reports monthly on complaint volumes and resolution times. What have you reported on?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if the spreadsheet counted anything, say what and how each figure was counted, what it was sensitive to, and the assumption you would defend least; if it was a record without figures, or you do not know how a figure was counted, say so plainly. Name the weakest assumption before they do | F3 is thin on what the spreadsheet counted; the weakest-assumption move turns a probe into credibility. JD because it scores a stated duty |
| B7 | "You'd coach branch supervisors on escalations. What have you done that's closest to that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what you did: you trained new tellers on your escalation script. Answer slot: if you ever worked through a real escalation with a teller, say what happened and what part was yours; if the training was only the script, say so plainly. The limit is the pack's observation: your material says tellers, not supervisors | F7 is adjacent only; JD because it scores a stated duty. The question asks for the closest thing, not a claim |
| B8 | "You'd present monthly to senior leaders. How confident are you?" | JD | [grounded] "I've never presented to anyone above regional level" | Concede exactly: "I've never presented to anyone above regional level." Then say how you would prepare, as a plan. Answer slot: if you have presented the spreadsheet's findings to your regional manager, say how that went in your own words; if it was sent rather than presented, say so plainly | F8 is a stated gap; the JD asks for confidence presenting. JD because it scores the stated requirement |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The brief moves 40% of member service to digital channels by 2028. If you owned complaints, what would you want to know first?" | CASE | [grounded] | Clarify before structuring: what counts as a complaint raised digitally, who sees it first, what the member is told. Then objective, what stays with a person, measure (volumes and resolution times), risks. Think aloud and challenge one premise respectfully. No claim about your past is needed | The brief's digital target against the JD's self-service duty; CASE because it is a live problem. The manager round tilts to the role's roadmap |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A7 | "Why Ashgrove rather than a bigger bank, or an app-only bank?" | CO | [grounded] | Bring one point from the brief, the competitive pressure from app-only banks, then your own reason for a member-owned credit union, in your own words. The reason must be yours | The brief names app-only banks as the pressure; CO because it scores strategy fluency. A manager asks to test motivation |
| A8 | "What experience do you have working with digital teams?" | JD | [grounded] | Answer slot: if you have worked with a digital or app team on how members do things for themselves, say what it was and what part was yours; if you have not, say so plainly, then say what you would ask them first and what you would want kept for a human conversation | F9 has no evidence; JD because it scores a stated duty. The honest branch has to be rehearsed before it is needed |

### Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good first 90 days look like in this role?" | Shows you are planning to start, and surfaces what they would judge you on |
| 2 | "Where do branches and the contact centre hand complaints to each other today, and where do they get stuck?" | Targets the F2 gap by asking to learn rather than pretending |
| 3 | "How are complaint volumes and resolution times reported to senior leaders now, and what would you change?" | Ties to the JD's reporting duty and shows you think about the reader |
| 4 | "How do you expect the move of 40% of member service to digital by 2028 to change what complaints look like?" | Uses the brief and invites a thinking conversation |
| 5 | "What support would I get preparing for my first presentations to senior leaders?" | Turns the F8 gap into a plan you have already started |

## Round 3: the panel of two branch managers (60 minutes, with a 20-minute case; values round)

### Values/Behavioral (primary: one question per published value)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C3 | "Tell me about a time you decided something from the member's side of the counter when it was not the easy option." | VAL | [grounded] "I handled the branch's formal complaints log" | Value: Members First, Always. A selection scaffold. Pick one decision where a member's interest and something else pulled apart: it needs what the member needed, what you chose, and what it cost or settled. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log". Do not supply the stakes | The recruiter said the panel scores against the four values; F1 carries no story with stakes, so this stays a scaffold. VAL because it scores a published value |
| C4 | "Tell me about a time you rewrote or re-explained something because people did not follow it the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Plain Words. A selection scaffold. Pick a moment where wording, not the person, was the problem: it needs what was unclear, what you changed, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you trained new tellers on your escalation script. Answer slot: if you ever changed how the script was worded, say what and why; if the wording was not yours to change, or you never changed it, say so plainly and stay with training the tellers | F7's sentence is the nearest and says nothing about wording changes. VAL because it scores a published value |
| C5 | "Tell me about a time you did something for a branch's community, or a local member, that no target asked for." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Value: Neighbours, Not Numbers. A selection scaffold. Pick one thing you did for a member or place beyond what was required: it needs who, what you did, and what it meant locally. If no such time comes to mind, say so plainly; your material carries your role, "the last 3 as a branch supervisor", and not an example. Do not borrow a team story as your own | F5's quote is your role, not an act; the panel is two branch managers, for whom this value is close to home. VAL because it scores a published value |
| C6 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Value: Own the Fix. A selection scaffold. Pick one problem you found and carried to a solution: it needs how you found it, what you did, and the point it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log". The words are "handled", not "kept hold of until solved" | F1 is the nearest evidence and says handled; the value is "whoever finds the problem keeps hold of it", which the JD's "own" echoes. VAL because it scores a published value |

### Case/Strategist (the 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D2 | A practice case: "A member complained at the branch, then phoned the contact centre, and has been told two different things about the same problem. A supervisor has escalated it to you. How do you handle it, and what do you change so it does not happen again?" The real case will differ | CASE | [generic] | Clarify first: what the member was told by each side, what they want, what has been recorded. Then owner (Own the Fix: you keep hold of it), what you tell the member in plain words, one timeline both channels can see, root cause across branch and contact centre, how you would measure it (volumes, resolution times), and what you would coach the supervisor on. Say what you would ask the contact centre rather than pretend to know their process. No claim about your past is needed | The recruiter said 20 minutes of the panel is a case on a complaint escalation; this is a practice shape, not the real case. CASE because it is live reasoning, and it is built so Plain Words and Own the Fix are visible in it |
| D3 | "Eight branches become five hubs over 2027. What happens to complaints?" | CASE | [grounded] | Clarify: what changes first for the member, who holds a complaint when a branch merges. Then principles in your own words: the member should never need to explain twice (Plain Words), someone always owns it (Own the Fix), no branch's local knowledge is lost (Neighbours, Not Numbers). Do not present the consolidation as bad news; your panel may be affected | The brief states the consolidation; CO and CASE both fit, CASE because it asks for a structured answer. Both panel members run branches, so their interest is direct |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You would coach our supervisors on escalations. Where does your job end and ours begin, and what happens when we disagree?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Propose seam principles instead of claiming to know the seam: who owns the member relationship, who owns the complaint, when it comes to you. Reciprocity: what you give the branch, not only what you need. Disagreement: show spine and tact together. The limit is the pack's observation: your material says tellers, not supervisors | F7 is adjacent only and these two will be the supervisors' own managers. JD because it scores the coaching duty; Peer persona because it is a seam question |

### Skeptic and Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B9 | "How much of that complaints spreadsheet is yours, and how much is your regional manager's?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the quote says: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if the manager set anything about it, say what and what remained yours; if nothing was set by them, or you do not know, say so plainly. If the spreadsheet counted anything, name the assumption you would defend least | F3 says built and uses, which is the attribution gap. EXP because it tests who did what |
| F1 | "Sixty seconds: why you over someone who has run a contact centre complaints team?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Pause, restate the question. Hold-then-concede: concede first, "I have never worked in a contact centre", then hold on what you stated, "I handled the branch's formal complaints log", and say what you would learn first. Do not run the other candidate down; do not claim contact-centre knowledge. Hold through two follow-ups | The same objection as B4 in a Pressure register; F2 is the stated gap. JD because it scores a stated requirement |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A9 | "Explain to us, as you would to a member who has never complained before, what happens after they raise a problem." | VAL | [generic] | Short sentences, no jargon, one step at a time, and check they follow. Say what you would do rather than describe Ashgrove's process: ask the panel to correct the steps you do not know. No claim about your past is needed | Plain Words in live form: "if a member needs it explained twice, we wrote it wrong". VAL because it scores the published value, not a story |

### Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do your supervisors find hardest about escalations?" | Shows you want to coach what they actually face |
| 2 | "What could a new complaints lead do in the first month that would genuinely help your branch?" | Reciprocity: what you bring them, not only what you need |
| 3 | "How do you expect the hubs to change how complaints are handled in your area?" | Invites their view on the 2027 consolidation without assuming it is bad news |
| 4 | "Which of the four values is hardest to live up to on a busy day?" | Shows you take the values as practice, not slogans |
| 5 | "What is the best fix you have seen someone own all the way through?" | Turns Own the Fix into a conversation, and shows what they reward |

## Values cheat sheet (round 3)

Values are quoted by name from the text you copied from ashgrovecu.org/about/values on 25 November 2026.

| Value (official name) | Working meaning (paraphrased) | Your mapped story, or scaffold | Questions |
|---|---|---|---|
| Members First, Always | Decide from the member's side, not the institution's | F1: scaffold ending in the honest branch; nearest is "I handled the branch's formal complaints log" | C3, D2 |
| Plain Words | Clarity is the writer's job; a second explanation means the first failed | F7: scaffold; nearest is that you trained new tellers on your escalation script, with a slot on any wording change | C4, A9 |
| Neighbours, Not Numbers | Each branch belongs to its town; do not treat places as figures | F5: scaffold; your material carries your role only, "the last 3 as a branch supervisor" | C5, D3 |
| Own the Fix | Whoever finds a problem keeps hold of it until solved | F1: scaffold; nearest is "I handled the branch's formal complaints log" | C6, D2 |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Own the member complaints process end to end | B4, B5, D2 |
| Across branches and the contact centre | B1, B4, F1 |
| Experience handling regulated complaints | B2, C1 |
| Report monthly on complaint volumes and resolution times | B6, B9 |
| Coach branch supervisors on escalations | B7, E1 |
| Work with digital teams on self-service journeys | A8, D1 |
| Confident presenting to senior leaders | B8, C2 |
| Comfortable with Excel reporting | B3, B6 |

## Prohibited claims

What this pack will not coach, and why. It is built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not the process end to end. B5's slot stays inside the log |
| Has worked in or run a contact centre | Negative you stated, F2 | "I have never worked in a contact centre", then a plan. No slot |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says a monthly complaints spreadsheet, not what it counted. B6's slot asks only what it counted |
| Handled regulated complaints | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says formal, not regulated. B2's slot asks only about deadlines or set steps |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's sentence at its own scope. The limit is the pack's observation: your material says tellers, not supervisors. B7's slot stays inside the teller training |
| Has presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level", then a plan. No slot |

## Sources

Provided documents: the JD; your message (background); the recruiter's email on the three rounds; the values text you copied from ashgrovecu.org/about/values on 25 November 2026; the four points you gave from the July 2026 strategy brief. No `tuesday-dossier.md` was present.

No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text is in hand and fixes the cheat sheet and the VAL questions |
| 2. Ashgrove interview process, member service roles | skipped | The recruiter's email fixes three sessions, who runs each and what each holds; persona weights follow it |
| 3. Ashgrove strategy and recent news | skipped | The four brief points you gave fix the CO and CASE questions; the brief is under six months old |
| 4. Interviewer name and Ashgrove | n/a | No names are assigned, so there is no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): Ashgrove's recent news, plus the interviewers' public professional footprints once names exist; say if you want it
- The three interviewers' names, especially the Head of Member Services and the two branch managers: an interviewer read, reweighted personas and a reverse question tied to each person's path
- Your actual pay expectation, notice period, location and reason for moving: A2 to A5 fill with your own words
- What the complaints log held, whether any complaint had a deadline or set steps, and who resolved them: F1, F6 and F7 can move from answer slots to quoted evidence
- What the monthly spreadsheet counted and whether it was Excel: F3 and F4 can move toward `[grounded]`; a sample with the names removed would be the inspectable artifact that raises F3 from medium to high
- Any work with a digital team: F9 moves from none to quoted evidence
- The full strategy brief and the recruiter's email: the grounding brief and the loop description rest on your summary of them, and the documents would let the pack quote them
- How long you have before 4 December: a prioritised prep order across the three rounds
- A `tuesday-dossier.md` from a job-underwriter evidence review: verified evidence, the objection worth the deepest rehearsal, and absolute prohibited claims, in place of the pack's own inference
