I'll read the reference files before building the pack.
Your prep pack is saved as /var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-8-canned-e721639a/ashgrove-credit-union_member-experience-lead_interview_pack.md. I built it as one shared fit snapshot plus a mini-pack for each of the three rounds on 4 December. It assumes the 20-minute complaint case is given live on the day.

Say the word and I'll play the Skeptic on 2B1, the contact-centre objection. That is the pack's highest-ROI prep, because it will come up in some form in all three rounds.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter say whether the 20-minute case material is sent ahead or handed over on the day? If it's sent ahead, I'll add a build section for it and rework the round 3 bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview prep pack for Dara

Three rounds on 4 December 2026, so this is a loop pack: one shared fit snapshot, then a mini-pack per round with its own persona weights, bank and reverse questions. Interviewers: the recruiter (30 minutes); the Head of Member Services, who would be your manager (45 minutes); a panel of two branch managers (60 minutes, including a 20-minute case on a complaint escalation). Names not yet assigned.

## How to use this pack

- Personas describe how a question is asked; types describe what is being scored. Every question carries one of each.
- Type key: VAL = behavioural or values alignment against Ashgrove's published values; EXP = a claim in your background, probed; JD = a stated requirement of the role; CO = company and strategy knowledge; CASE = a live problem.
- Question IDs: round number, then persona letter (A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Peer Evaluator, P Pressure), then a number. Fit-snapshot rows are F1 to F9.
- Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for you now: it names what the interviewer is likely to probe, and gives two honest branches, one if it happened and was yours, one if it did not or was not.
- Highest-ROI prep in this pack: 2B1, the contact-centre objection, rehearsed with its follow-ups. 1B2, 2B2 and 2P1 are the same objection arriving in other packaging.

## Fit snapshot (shared across all three rounds)

Quotes in the evidence column are your own words from your message. Nothing in the pack describes your past except through them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on years, but a line with nothing inspected behind it, so expect a probe on what the six years covered. Lead with the quote's own terms: you have six years in retail banking, the last three as a branch supervisor, and leave the interviewer to connect it to the JD's wording |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal complaints log; it does not show whether the complaints in it fell under a regulator's rules. Answer slot: the JD's regulated-complaints line makes a probe on that likely. If the complaints in your log were regulated, say which rules or deadlines applied and what you did because of them, in your own words; if you don't know, or they were not, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD (the branches part) | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process across branches, with nothing inspected behind it. The words stay at that scope: "I handled the branch's formal complaints log." Answer slot: if you saw any complaint from the log through to its outcome, say which steps were yours; if the log was where your part began and ended, say so plainly and stay with the log |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD (the contact-centre part) | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet that your regional manager uses; it does not show what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet counted and how. If it counted those, say how each was worked out; if it counted something else, say what; if you don't know how a figure was counted, say so plainly |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says tellers and a script, not supervisors. The words stay: "I trained new tellers on our escalation script." Answer slot: if any of your escalation training involved supervisors, say whose and what you did; if it was tellers only, say so plainly. A second slot: expect a probe on how you taught the script; if you did anything beyond running through it, say what, in your own words; if you taught it as written, say so plainly |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show work with digital teams. Answer slot: the JD's digital line makes a probe likely. If you have worked with any digital or product team, say what the work was and what part was yours, in your own words; if you have not, say so plainly and say what you would want to learn about the journeys first |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Your material does not say whether or to whom you presented at regional level, so nothing here claims it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a spreadsheet, not Excel, and the pack does not assume the tool. Answer slot: the JD names Excel, so expect a probe on the tool. If you built it in Excel, say what you did in it; if it was another tool, say which and how you would describe your comfort with Excel; if you do not use Excel, say so plainly |

## Grounding brief

Facts below are the points you gave from the July 2026 strategy brief the recruiter sent, and the JD's own description of Ashgrove. I have not seen the brief itself.

| Item | What it says, as you gave it | Reading for complaints work | Provenance |
|---|---|---|---|
| Ashgrove | "member-owned, about 900 staff" — JD | Complaints cover every branch and the contact centre in one organisation, so the owner of the process crosses teams by design | [inferred] |
| Digital shift | "move 40% of member service to digital channels by 2028" | Ties to the JD's self-service line (F7) and raises where complaints will be raised and whether a member has to say it once | [inferred] |
| Hubs | "consolidate eight branches into five hubs over 2027" | The round 3 panel are branch managers, and "Neighbours, Not Numbers" sits beside a plan that reduces branches; expect that tension to come up | [inferred] |
| New product | "launch a small-business lending product in Q1 2027" | A new member group and product may bring new kinds of complaint; useful as an example of what you would want to know first | [inferred] |
| Competition | "the main competitive pressure is app-only banks" | A member who is unhappy has a fast way to leave; complaint handling is part of how Ashgrove keeps members | [inferred] |

## Round 1: Recruiter, 30 minutes

Recruiter's words: "30 minutes with me". Kept short; the risk is treating it as unscored.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Conversational | Friendly walk-through, then pay, notice, location, reason for leaving | High. A recruiter screen is mostly logistics and motivation, and nothing in the recruiter's note suggests otherwise | A 90-second arc built only from your quoted sentences; treat every casual question as scored; answer logistics in your own terms |
| B Skeptic (light) | Knockout checks on the two requirements the JD leads with | Medium. The JD asks for regulated-complaints experience and covers the contact centre, and your material is thin on both (F2, F4) | Say the limit before it is asked; return to the quote |

### Round 1 bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with only the beats those quotes carry: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Say each in your own words at the same scope, add no outcome the quotes do not state, and close on why this role, in your own reason | F1, F2, F5 and F6 are the pool the arc draws on; EXP because this is the first check of your background |
| 1A2 | "What's prompting a move now?" | EXP | [generic] | Logistics slot: give your own reason for leaving, in your own words, one you would say the same way to the Head of Member Services in round 2. The pack supplies no reason | Recruiters check that the story stays the same across three rounds; EXP because it tests consistency of your account |
| 1A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first; decide which before the call. If asked what you earn now: "I'd rather focus on the range for this role." | The JD gives no pay terms, so this is the recruiter's question to ask and yours to settle; JD because it concerns the listed job's terms |
| 1A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words; if you are unsure of the exact length, say you will confirm it rather than guess | A standard knockout on timing; JD because it concerns the listed job's terms |
| 1A5 | "Where could you work from, and how often?" | JD | [grounded] | Logistics slot: state where you can work and how often, in your own terms, and ask which site the role is based at. The strategy brief's eight-branches-to-five-hubs move over 2027 is the reason the question is live | Location is a term for the recruiter to check; [grounded] on the brief points you gave for why it matters |
| 1A6 | "What do you know about Ashgrove, and why us?" | CO | [grounded] | Choose one or two items from the Grounding brief, not all of it: a published value by name, or one strategy move, with why it matters to complaints work, as your own view. Say your own reason for choosing Ashgrove; the pack supplies none | CO because it tests homework; the recruiter sent the brief, so mentioning it is expected |
| 1B1 | "Tell me about your experience handling regulated complaints." | JD | [grounded] "I handled the branch's formal complaints log" | Lead with the quote: "I handled the branch's formal complaints log." Then F2's answer slot, inside the log: if the complaints in it were regulated, say which rules or deadlines applied and what you did; if you don't know, or they were not, say so plainly and stay with the log | F2 is the likeliest knockout in a screen; JD because it scores a stated requirement |
| 1B2 | "The role covers the contact centre as well as the branches. What's your experience there?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | First rehearsal of the highest-ROI objection (full version at 2B1). Open with the limit: "I haven't worked in a contact centre." Then the quote you do have: "I handled the branch's formal complaints log." Then a plan in your own words for how you would learn the contact-centre side; the plan is future, never past | F4 is the widest gap against the JD's scope; JD because it scores a stated responsibility |

### Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "Which site would the role be based at, given the plan to move from eight branches to five hubs over 2027?" | Shows you read the brief, and settles the location logistics on your side |
| R1-2 | "Will the 20-minute complaint case be shared beforehand or given on the day, and is there anything you would suggest I read for the panel round?" | Process question with a prep reason; the answer decides whether the case needs its own build section |
| R1-3 | "Will the Head of Member Services and the two branch managers' names be available before 4 December?" | Lets you read their public professional footprint and sharpen rounds 2 and 3 |
| R1-4 | "How do complaints reach this role today: through the branches, the contact centre, or both?" | Shows you are thinking about the end-to-end scope the JD sets |
| R1-5 | "What happens after 4 December, and by when would you hope to decide?" | Signals interest and settles timing for your own planning |

## Round 2: Head of Member Services (your would-be manager), 45 minutes

Recruiter's words: "45 minutes with the Head of Member Services, who would be your manager, mostly behavioural". The hiring-manager prior is Skeptic plus Case; "mostly behavioural" pulls Values/Behavioral to the top.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | "Tell me about a time" prompts drawn from the JD and the published values | High. The recruiter's words are "mostly behavioural" | A story from your quotes where one carries it; a selection scaffold and honest branch where none does |
| B Skeptic | Quiet probing of the contact-centre and senior-presenting gaps | High. A manager is buying capability and de-risking the gaps you have stated (F4, F8) | Name the limit first, hold the quotes, give a plan |
| D Case/Strategist | Questions on the digital shift and the hubs | Medium. The strategy brief sets both, and the JD has a digital line | Clarify, structure, one respectful challenge to a premise |
| P Pressure | One time-boxed challenge | Low. No signal in the recruiter's note; included so the style is not new | Pause, restate, hold, then concede only what is true |

### Round 2 bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-map on F6: new tellers, the escalation script, and that you trained them, which are the beats the quote states; tell them in your own words. Answer slot: if any of that training involved going through a real escalation with a teller, say what happened and what part was yours; if it was the script as written, say so plainly and stay with the training | F6 is the evidence for the JD's coaching line; JD because it scores that line |
| 2C2 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the quote at its scope: you built it, and your regional manager uses it. Then the slots a figure raises: what it counted and how each figure was worked out; the assumption you would defend least, named by you before the interviewer asks; which part was yours. If you do not know how a figure was counted, say so plainly. Say which tool it was built in (F9); the pack does not assume Excel | F5 and F9 are the reporting evidence and the likeliest place to be probed; EXP because it tests what you did, JD because it scores the reporting line |
| 2C3 | "Tell me about a time you had to give someone more senior than you an unwelcome message." | JD | [generic] "I've never presented to anyone above regional level." | A selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship still intact at the end. Your own quote says you have not presented above regional level, so the story need not be a presentation. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's senior-leaders line (F8) makes the behavioural version likely; JD because it scores that line, VAL in delivery |
| 2C4 | "Tell me about a time you worked with a team outside your own to change something members do." | JD | [grounded] | A selection scaffold: pick a time with a named partner team, your own part, and a visible change; the JD's digital line raises it (F7). If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle working with a digital team | F7 has no evidence, so the pack gives selection criteria, not a story; JD because it scores the digital line |
| 2B1 | "I don't see contact-centre experience in your background, and this role owns the complaints process there too. How would you approach that?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" | Highest-ROI prep. Say the limit in your first sentence, before it is pressed: "I haven't worked in a contact centre." Hold what the quotes carry: the branch's formal complaints log, and training new tellers on the escalation script. Then a plan, in your own words: who you would sit with first and what you would want to see. Follow-up 1, "so you'd be learning on the job?": concede plainly that the contact-centre side would be new, and return to the quotes. Follow-up 2, "why would branch complaints be like contact-centre ones?": do not claim they are; say what you would test. Answer slot: if any complaint from your branch passed to or from a contact centre, say what you saw; if none did, or you don't know, say so plainly. Follow-up 3, "wouldn't someone from a contact centre be better?": concede that they may be stronger on that part, hold what you do bring at the scope of the quotes, and do not claim to be better | F4 is the widest gap against the role's scope and the manager is the person who owns it; JD because it scores a stated responsibility. Deepest rehearsal because it will arrive in some form in all three rounds |
| 2B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level." | Pick one of the two gaps you have stated and name it first, in the quote's own words, then give a plan for closing it. Do not offer a gap you have not stated, and do not claim a strength to cover it | F4 and F8 are the two stated gaps; JD because it scores honest self-assessment against the listed requirements |
| 2B3 | "The role asks for confidence presenting to senior leaders. Where are you on that today?" | JD | [grounded] "I've never presented to anyone above regional level." | Words: "I've never presented to anyone above regional level." Then a plan in your own words: what you would rehearse, who would give you feedback, and what you would present first. Do not add presenting you did not describe | F8 is a stated gap and the JD has a named requirement; JD because it scores that requirement |
| 2D1 | "We want 40% of member service on digital channels by 2028. What happens to complaints as that moves, and what would you want to know first?" | CO | [grounded] | Clarify first: which services move, which members, which kinds of complaint are raised where today. Then objective, segmentation, approach, metrics, risks. Challenge one premise respectfully, for example whether a digital channel lets a member say it once. No claim about your past; the guidance makes none | The strategy brief sets the target and the JD has a self-service line (F7); CO because it tests thinking at the company's altitude |
| 2D2 | "Eight branches become five hubs over 2027. What would you watch in the complaints data while that happens?" | CO | [grounded] | Structure it: what to measure (the JD's volumes and resolution times, by branch and hub), what to compare against, what the change itself might cause. Ask what data is available and how resolution time is defined today. No claim about your past | The brief sets the hub move and the JD sets the measures (F5); CO because it applies strategy to the role |
| 2P1 | "Sixty seconds: why you, rather than someone who has run a complaints team in a contact centre?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses." | Pause and restate the question. Hold: the quotes at their own scope, the log and the spreadsheet. Concede in the same breath: "I haven't worked in a contact centre." Do not claim you are better; end on what you would do first in the role, as a plan. Hold through two follow-ups by returning to the quotes, not by adding to them | F4 is the objection; JD because it scores a stated requirement, delivered under time pressure |

### Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would you want to have changed in complaints handling by the end of my first three months?" | Shows you think in outcomes and gives you the manager's own measure of success |
| R2-2 | "Which complaint measures do you look at today, and which do you wish you had?" | Ties to the reporting line (F5) and lets you ask what the spreadsheet would need to count |
| R2-3 | "When a member moves between a branch and the contact centre, who owns their complaint today?" | Connects to Own the Fix and the end-to-end scope of the role |
| R2-4 | "As 40% of member service moves digital by 2028, how do you expect complaints to change?" | Uses the brief and invites the manager's own view |
| R2-5 | "What does good coaching of a branch supervisor look like from your side?" | Turns the coaching line (F6) into a conversation and shows you want the standard, not just the title |

## Round 3: Panel of two branch managers, 60 minutes, including a 20-minute case

Recruiter's words: "60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation. The panel is also the values round — they score against the four values." A values-style round is therefore documented by a loop source. The case format (live or sent ahead) is not yet known; this pack assumes live.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | Stories scored against the four published values | Very high. The recruiter's words are "they score against the four values" | A story per value where a quote carries one; a scaffold and honest branch where none does |
| D Case/Strategist | The 20-minute complaint-escalation case | High. The recruiter's words are "a 20-minute case on a complaint escalation" | Clarify first, structure aloud, challenge one premise respectfully |
| E Peer Evaluator | The seam between this role and each manager's branch | Medium-high. The JD has the role coaching branch supervisors, so these managers are the people whose supervisors it works with | Reciprocity: what you bring their branch, and seam principles, not a pretended seam |
| B Skeptic | Why supervisors elsewhere would listen to a peer | Low-medium. A branch-manager panel may test the coaching line (F6) | Hold the quotes; use the F6 slots |

### Values and principles cheat sheet

Ashgrove's four values by official name, as you pasted from ashgrovecu.org/about/values on 25 November 2026.

| Value | Working meaning, paraphrased | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quote carries a story. Selection scaffold: pick a time you chose what was right for a member over a target or a rule, with a named stake and your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording was wrong | F6: "trained new tellers on our escalation script". Answer slot: if you changed or made plainer any wording in the script, or how you taught it, say what and why; if you taught it as written, say so plainly and use a scaffold: a time something had to be explained twice, what you changed, what happened next |
| Neighbours, Not Numbers | Every branch is part of its town | No quote carries a story. Selection scaffold: pick a time you did something because of the town your branch served, not because a figure said to. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3: "I handled the branch's formal complaints log". Answer slot: if you took any complaint from the log to its outcome, say what you did and what part was yours; if the log was where your part ended, say so plainly and use a scaffold: a problem you found that others could have dropped, what you did, what changed |

### Round 3 bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3C1 | "Tell me about a time you put a member's interest ahead of an internal target or rule." | VAL | [grounded] | Members First, Always. A selection scaffold: pick a time with a named stake, the target or rule in the way, and what you did and what followed. No quote carries it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first of four values the panel scores; VAL because it tests behaviour against a published value |
| 3C2 | "Tell me about a time something had to be explained to a member, or a colleague, twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words. Lightly mapped on F6: you trained new tellers on the escalation script. Answer slot: if the script's wording, or how you taught it, was something you made plainer, say what and why; if you taught it as written, say so plainly and use the scaffold in the cheat sheet | F6 is the nearest quote; VAL because it tests the second published value |
| 3C3 | "Tell me about a time you did something because of the town your branch served, rather than because a figure said to." | VAL | [grounded] | Neighbours, Not Numbers. A selection scaffold: pick a time with the town or members named, what you did and why the figure alone would not have led there. No quote carries it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Branch managers score this value from their own seat; VAL because it tests the third published value |
| 3C4 | "Our plan moves 40% of member service to digital and eight branches to five hubs. Where does Neighbours, Not Numbers go in that?" | VAL | [grounded] | No claim about your past. Name the tension honestly rather than smoothing it; give your own view of what would keep a town's members feeling looked after; ask what the managers' members value most in their branch. Do not criticise the plan or claim knowledge of how it will be carried out | The brief and the value sit side by side, so a branch-manager panel can test it; VAL and CO because it tests a value against strategy |
| 3C5 | "Tell me about a time you found a problem that wasn't yours and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix. Lightly mapped on F3: you handled the branch's formal complaints log. Answer slot: if you took any complaint from the log to its outcome, say what you did and what was yours; if the log was where your part ended, say so plainly and use the scaffold in the cheat sheet | F3 is the nearest quote; VAL because it tests the fourth published value |
| 3D1 | Practice case, real case unknown: "A member told a branch counter last month that a fee was wrongly charged. The supervisor's reply did not resolve it. The member has now phoned the contact centre, been asked to explain it all again, and written to say they are moving to an app-only bank. You have twenty minutes: what do you do?" | CASE | [generic] | Clarify first: what outcome the member wants, what has been said to them in writing, what rules or deadlines apply to this complaint (ask the panel), who holds the file now. Then objective: one owner, the member does not have to say it twice. Then approach, how the record is kept, root cause, what goes back to the branch and the contact centre. Challenge one premise respectfully, for example whether the fee is the real problem or the retelling is. No claim about your past | The recruiter said the case is on a complaint escalation; [generic] because the real scenario is unknown. CASE because it scores structure |
| 3D2 | Practice case: "The branch supervisor thinks the member is being unreasonable and does not want to escalate. What do you say to them?" | CASE | [generic] | Listen first and ask what they know that you do not. Agree the facts, then the member's position in their own words, then what escalation is for and who decides. Keep the supervisor's ownership of the member relationship. No claim about your past | Tests the coaching line (F6) as a live conversation; CASE because it asks for reasoning on a real problem of the role |
| 3D3 | Practice case: "The monthly report shows one hub's resolution times rising while the others fall. Walk us through it." | CASE | [generic] | Clarify how resolution time is defined and whether it is defined the same way everywhere; check volumes and mix before drawing a conclusion; then who you would talk to, and what goes back to the hub. No claim about your past | Tests the reporting line (F5) as a decision; CASE because it applies a measure to a live problem |
| 3E1 | "Our teams sit side by side. Where is the seam between you and a branch manager, and what happens when we disagree?" | CASE | [generic] | Propose principles, not a pretended seam: who owns the member until the problem is solved, who decides on escalation, how a disagreement is raised, and what you would ask them to expect from you. Ask them where it hurts today. No claim about your past | A role that coaches branch supervisors meets branch managers at a seam; CASE because it tests collaboration reasoning |
| 3E2 | "How do you handle credit when a fix spans a branch and the contact centre?" | VAL | [generic] | A selection scaffold: pick a time work spanned two teams; use "we" for the context and "I" for your own contribution; say how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer stem on credit-sharing; VAL because it tests behaviour with equals |
| 3E3 | "What would you need from us in your first month, and what could we expect from you?" | VAL | [generic] | Answer both halves. What you would ask for: time with their supervisors, an introduction to the contact-centre side, the measures they care about. What they could expect: your own commitments, in your own words. Ask what they would want first | A reciprocity question; VAL because it tests partnership fit |
| 3B1 | "You supervised a branch. Why would supervisors at other branches take coaching on escalations from you?" | JD | [grounded] "the last 3 as a branch supervisor" "trained new tellers on our escalation script" | Hold the quotes: you were a branch supervisor for the last three years, and you trained new tellers on the escalation script. Then F6's slots: if any of your escalation training involved supervisors, say whose and what you did; if it was tellers only, say so plainly. Do not claim more standing than the quotes carry; say how you would earn it, as a plan | The coaching line (F6) is where branch managers may press from their side; JD because it scores that line |

### Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What would you most want a new complaints lead to change about how escalations reach your branch?" | Shows you start from their branch, and gives you a real scenario for the case |
| R3-2 | "As the branch network moves toward five hubs over 2027, what do you most want members in your town to keep?" | Connects Neighbours, Not Numbers to the strategy without criticising it |
| R3-3 | "What could a new person do in their first month that would genuinely help your branch?" | Reciprocity: shows you are thinking about what you bring to them |
| R3-4 | "How do you hear about a complaint today: from the member, your supervisor, the contact centre?" | Reveals the real flow and shows end-to-end thinking |
| R3-5 | "What would each of you want to see in the first report you get from this role?" | Ties to the reporting line (F5) and makes the report something they asked for |

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "4+ years in financial-services customer operations" | 1A1 |
| "experience handling regulated complaints" | 1B1, 3D1 |
| "Own the member complaints process end to end across branches and the contact centre" | 1B2, 2B1, 2P1, 3D1, 3D2 |
| "report monthly on complaint volumes and resolution times" | 2C2, 2D2, 3D3 |
| "coach branch supervisors on escalations" | 2C1, 3B1, 3D2 |
| "work with digital teams on self-service journeys" | 2C4, 2D1 |
| "confident presenting to senior leaders" | 2B2, 2B3, 2C3 |
| "comfortable with Excel reporting" | 2C2 |

## Prohibited claims

What this pack will not coach, built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owning the member complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says one branch's log, not the process across branches. The slot stays inside the log |
| Having handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The pack's observation: your material says a formal complaints log and does not show whether the complaints were regulated. The slot stays inside the log |
| Having reported on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope. The pack's observation: your material says a monthly complaints spreadsheet and does not show what it counted. The slot asks only what it counted |
| Having coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: "I trained new tellers on our escalation script." The pack's observation: your material says tellers, not supervisors |
| Having built the reporting in Excel | Inflated form of F9 | F9's quote at its own scope. The pack's observation: your material says a spreadsheet and does not name the tool. The slot asks only which tool |
| Having contact-centre experience | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Having presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot; the pack does not claim presenting at or below regional level either |

## Sources

Provided documents: the job description you pasted; Ashgrove's four values, pasted, which you said you copied on 25 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the process; the key points of the July 2026 strategy brief as you gave them (the brief itself was not read); your background in your message. No dossier was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email fixes the loop: three sessions, who runs each, their lengths and the case, so persona weights follow the named rounds |
| 3. `Ashgrove Credit Union strategy` and recent news | skipped | The strategy points you gave (July 2026) fix the grounding brief and the CO questions |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No names have been assigned, so there is no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → the nine fit-snapshot rows get checked against a document, and any of F2, F3, F5, F6, F7, F9 where a CV line supplies more than your message may move from discovery to a grounded story
- Written answers to the answer slots in F2, F3, F5, F6, F7 and F9 (for example, what the monthly spreadsheet counted and in which tool) → those rows become `[grounded]` stories and the matching questions get beats from your own words
- The recruiter's note on whether the 20-minute case material comes beforehand → if it does, a graded-deliverable build section for it and a reworked round 3 bank
- The names of the Head of Member Services and the two branch managers, once assigned → an interviewer read from their public professional footprint, persona weights per person, and a reverse question tied to each of their paths
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → the full strategy brief if it can be found, interviewer footprints once names exist, reports of this role family's loops, and recent organisation context
- Your prep hours before 4 December → a prioritised prep schedule sized to the time, with everything else marked as insurance
- A `tuesday-dossier.md` from job-underwriter → verified evidence, an underwriter-chosen objection to rehearse, and absolute prohibited claims, in place of the ones this pack built locally
