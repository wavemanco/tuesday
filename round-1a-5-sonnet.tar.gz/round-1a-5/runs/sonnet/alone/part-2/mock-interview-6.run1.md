I'll read the reference files the skill points to before building the pack.
The pack is written and saved. Here is the message that presents it.

Your prep pack is saved as `Larkfield-Systems_engineering-manager_interview_pack.md` in the working directory. It's a three-round loop built from your schedule, with a shared fit snapshot and a separate bank for each round. My web searches for Larkfield (values, interview process, strategy) were refused. Nothing from the web is in the pack, so the company questions are generic and there is no values cheat sheet for Monday.

Say the word and I'll play the Director on A1, the question the pack names as your highest-ROI prep. A1 is the hardware-roadmap objection, and it comes back as I1 on Monday.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Could you paste your CV and the full job description? Either would turn several of the fit rows from inferred into grounded, and I'll proceed without them if you'd rather.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (three-round loop)

Candidate: Yusuf. Mode: loop, one shared fit snapshot and a mini-pack per round.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering (name not given) | 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Panel: two staff engineers and a product manager (names not given) | 60 min | Technical peers plus a cross-functional partner |
| 3 | The following Monday | VP Engineering (name not given) | 30 min | Skip-level; described by the recruiter as "values and leadership philosophy" |

The loop comes from your own account of the schedule, so persona weights rest on it and not on an archetype guess. No interviewer names were given, so there is no interviewer read.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each round has its own persona weights, shown with the reasoning so you can overrule them.
- Type key: **VAL** (past behaviour against values or leadership principles), **EXP** (does a CV claim survive scrutiny, and what was actually yours), **JD** (a stated responsibility in the role), **CO** (company and domain knowledge), **CASE** (a live problem set in the role).
- Guidance is scaffolding, not a script. Say it in your own words, and only what you actually did.
- Answer slots (instructions that end without a question mark) mark places where the pack does not know your history. Fill them from your own experience or take the plain second branch; both are good answers.
- The same quoted sentence about the reliability quarter underlies several questions across the three rounds (A4, D2, E2, F1, H2, I2). Tell it the same way every time, in the same scope, because different interviewers may compare notes.
- **Highest-ROI prep in the pack: A1**, the hardware-roadmap objection. It is the one gap your own message names that the role's third clause presses on directly, and it comes back in round 3 as I1.
- No published Larkfield values were read, so there is no values cheat sheet. The round 3 values questions use standard stems and map to your quoted sentences, not to value names.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description you gave. Evidence is your own sentences only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | medium | [grounded] | transferability | Your material says a team lead of 6, and the words stay at that scope: "I've spent 3 years as a team lead of 6." You also stated "I've never managed managers", so the plain acknowledgment is yours to give. The role description does not say whether the two squads have leads who would report to the EM, which is a question for the Director. Answer slot: the role names two squads, so expect a probe on leading more than one team; if you have led more than the team of 6, say what, in your own words; if you have not, say so plainly and stay with the team of 6 |
| F2 | "building device-management services" — role description in your message | "currently at a payments company" — your message | low | [inferred] | discovery | Your message gives a payments company and says nothing either way about devices or connected systems. Answer slot: the role is built on device-management services, so expect a probe on what transfers; if any of your work touched anything close, say what, in your own words; if none did, say so plainly and stay with the payments company |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the delivery clause) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence carries a reliability quarter you pushed through against roadmap pressure, with the 60% following it ("after", not "because"). The material does not say who set that roadmap or how delivery was tracked. Words: "My team's on-call burden dropped 60% after I pushed a reliability quarter through." Answer slot: the 60% invites four probes; say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours; if you do not know how it was counted, say so plainly. Answer slot: if asked how delivery was tracked on your team, say how, in your own words; if you did not track or own it, say so plainly and stay with the quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the hiring clause) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a CV-style line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you run the loop for backend roles, and the figure counts interviews, not hires. The sentence says backend roles, and the role is for 11 engineers on device-management services, which is the pack's observation of the distance, not words for you |
| F5 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the growth clause) | none given | none | [grounded] | discovery | Nothing in your message speaks to growing engineers, and you have stated no absence. Answer slot: the role names growth, so expect a probe; if you have helped an engineer grow, say whom (anonymised) and what you did, in your own words; if you have not, or it was not yours, say so plainly and say how you would approach it |
| F6 | "partner with hardware and product on roadmap" — role description in your message (the hardware clause) | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past |
| F7 | "partner with hardware and product on roadmap" — role description in your message (the product clause) | "I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The sentence touches a roadmap and does not say whether product was the source of the pressure or how it was worked through. Answer slot: if the pressure came from product, say how you worked it through, in your own words; if it did not, or you were not the one working it through, say so plainly and stay with the sentence |

No requirement in the role description is a gate (a licence, authorisation, location or similar term), so no gate row appears and nothing needed asking.

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 Lead two squads | A2, A3, I3 |
| F2 Device-management services | E3, J1 |
| F3 Own delivery | A4, B3, D2, E2, I2 |
| F4 Hiring | C2, E1 |
| F5 Growth | C3, H3 |
| F6 Hardware roadmap partnership | A1, B1, I1, J2 |
| F7 Product roadmap partnership | D2, F2 |

---

# Round 1: Tuesday, Director of Engineering, 45 min

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the two gaps your own message names: managers and the hardware roadmap | High. A hiring manager derisks gaps first, and your message states two of them; 45 minutes is short, so expect them early. Depth: 4 questions | Rehearse A1 until it is boring: limit first, your quote at its scope, a plan said as a plan |
| Case / Strategist | Live problems from the real roadmap: commitments under a moved date, diagnosing a slipping squad | High. The hiring-manager prior puts it beside the Skeptic, and a boss-to-be tests how you structure before they test what you know. Depth: 3 questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| Conversational | The biography opener, "why this role, why now", and a growth question in a friendly register | Medium. Most first rounds open this way, and casual questions are still scored. Depth: 3 questions | A 90-second arc built only from your quoted sentence; do not answer "I think we've covered everything" at the end |

## Question bank

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't owned a hardware-adjacent roadmap. How would you partner with hardware and product on ours?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The deepest rehearsal here, with three follow-up levels. Say the limit first, before a second ask: "I've never owned a hardware-adjacent roadmap." Then give only what your quote carries, "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure", then a plan said as a plan: what you would ask hardware and product in the first weeks and what you would want to understand before committing either squad to anything. Follow-up one, "that is a reliability example": hold by returning to the quote, never by adding to it. Follow-up two, "so what is different about hardware": concede specifically, "That is right, I haven't owned one, and that example is about a reliability quarter and roadmap pressure; it isn't offered as a hardware example." Follow-up three, "what would you do in week one": the plan again, and ask what hardware's dates look like for these squads. Answer slot: the role's line on partnering with hardware makes a probe on how roadmap trade-offs went likely; if any of your past work had you trading off against someone else's timeline, say what, in your own words; if it did not, say so plainly and stay with the quarter | F6 is a capability gap you stated, and the role's third clause presses on it; this is the objection most likely to arrive in some form. JD because it scores a stated responsibility, and the premise is your own stated negative, so it is lawful here |
| A2 | "You've been a team lead of 6. This role is two squads and 11 engineers. What changes for you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say your scope in the quote's terms: "I've spent 3 years as a team lead of 6." Then what changes, as a plan and not a past: what you would want to learn about how the two squads work before changing anything. Answer slot: the role names two squads and 11 engineers, so expect a probe on leading more than one team; if you have led more than the team of 6, say what and how large, in your own words; if you have not, say so plainly and stay with the team of 6 | F1 is where the jump in scope shows. JD because the role description states the numbers; asked as a skeptic probe because a boss-to-be needs to see you size the gap yourself |
| A3 | "Have you managed managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Answer plainly with no padding: "I've never managed managers." Then your scope in its own terms: "3 as a team lead of 6". Then turn it into a question: ask whether the two squads have leads and how they would relate to you, because the role description does not say. Do not describe mentoring or coordination as managing managers | F1 carries a stated negative, and an interviewer who reads your CV closely will test it directly. JD because the role leads two squads; the closed form is deliberate, since a direct question deserves a direct answer |
| A4 | "Walk me through the reliability quarter. Your on-call burden dropped 60% after you pushed it through against roadmap pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Tell it in the beats the sentence states: the reliability quarter, that you pushed it through, the roadmap pressure, and the 60% drop in your team's on-call burden. Say "after", as the quote does, not "because". Answer slot: say how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly. Answer slot: the role's roadmap partnership makes a probe on who applied the pressure and how it ended likely; if you know, say it in your own words; if there was no one specific, or it was not yours to resolve, say so plainly and stay with the sentence | F3 holds the one quantified claim in your material, and a boss will read it first. EXP because it tests attribution; the defend-the-number slots are the rubric's, and none of them is filled for you |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's week six. Both squads have a full roadmap and hardware has just moved a date. How do you decide what each squad commits to?" | CASE | [generic] | Clarify first: what moved, which commitments depend on it, who else is affected. Objective: what must not break. Segment work into what depends on the date and what does not. Approach: talk to hardware and product, then re-plan with the squads. Metrics: how you would know commitments are holding. Risks: hidden dependencies, squad morale. Challenge one premise politely, such as whether both squads are equally affected. Think aloud. The question needs no claim about your past, so the guidance makes none | A live problem from the role's third clause (F6's requirement), asked as a decision. Generic because no research ran and the scenario is a pattern, not a fact about this employer |
| B2 | "What do you want to understand in your first thirty days, and from whom, before you change anything?" | CASE | [generic] | Structure by who and what: the 11 engineers (how they work and what hurts), the Director (what success looks like), hardware and product (where their dates and priorities meet the squads). Say what you will deliberately not change before you have listened. Your own priorities beyond that are yours to add | Hiring managers read this as a test of judgment about a new remit, and F1's scope jump makes it likely. CASE because it is a plan problem, not a past one |
| B3 | "One squad is slipping and the other is fine. How do you diagnose it?" | JD | [generic] | Clarify first: slipping against what, and since when. Segment the causes you would test: scope growth, dependency delay, capacity, unclear ownership, quality debt. Gather evidence from the squad itself before hypothesising aloud. Compare with what the steady squad does differently, and name the risk of assuming one fix fits both. No claim about your past | The role asks you to own delivery, which F3's evidence reaches only adjacently. JD content, CASE delivery, because the stated responsibility is being tested with a live problem |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your journey, and why this role, why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc built from the beats the sentence states: nine years in engineering, three as a team lead of 6, currently at a payments company. Why this role and why now are yours to say, in your own words; the pack supplies no reason and invents none. Answer slot: tie your reason to the role description's own terms, such as the squads, device-management services and the hardware and product partnership; if you have no settled reason yet, say what draws you and stop there | The opener is scored for economy and motive, and F1 is the spine of the arc. EXP because it tests whether the career story holds together |
| C2 | "Tell me about your involvement in hiring." | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Map it on the sentence: you run the hiring loop for backend roles, and about 40 interviews happened last year. Say "interviews", not "hires". Answer slot: expect the four number probes; say how the figure was counted, what share of those interviews you conducted yourself, and the assumption you would defend least; if you do not know how it was counted, say so plainly. Answer slot: the role's hiring clause makes a probe on what you decided or changed in the loop likely; if you set or changed anything, say what and why, in your own words; if the loop was as you found it, or the decisions were someone else's, say so plainly and stay with running it | F4 is your strongest direct match to the role. Open prompt, with the theme from the role description's hiring clause; JD because it scores a stated responsibility |
| C3 | "Tell me about an engineer you helped grow." | JD | [generic] | Selection scaffold: pick one person, anonymised, whose growth you can describe from your own account: what they wanted, what you did, what changed afterwards, and what was theirs and not yours. If no such time comes to mind, say so plainly, then give the nearest thing you actually have, or how you would approach it | The role names growth, and F5 is silent, so no story is mapped for you. JD because growth is a stated responsibility; the generic label is the honest one until you supply a story |

## Reverse questions for Tuesday

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "Do the two squads have tech leads or squad leads today, and how would they relate to me?" | Resolves the ambiguity the role description leaves about managing leads, and shows you read the scope closely rather than defending your gap |
| R1-2 | "Where does the services roadmap depend most on hardware's timelines right now?" | Lets you hear the hardware seam from the person who owns it, which is also where your ramp plan for A1 starts |
| R1-3 | "What would you want to see in my first ninety days, and at a year?" | Turns the interview into agreement about what success is, and tells you how the Director measures delivery |
| R1-4 | "What is the part of this role you are least sure a new EM can do well?" | Invites the objection on your terms; a boss-to-be answers it honestly, and it shows you can hear a concern without defending |
| R1-5 | "How do you think about hiring for these squads over the next couple of quarters?" | Ties to the hiring clause and to F4; shows you think about the pipeline as part of the job |

---

# Round 2: The Thursday after, panel (two staff engineers and a product manager), 60 min

## Persona weights

No names or profiles were given, so personas are assigned to the roles, not to individuals; with names, this section would assign one per member.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between an EM and staff engineers, credit and disagreement, "what would you need from us" | High. Two of three panelists are technical peers of the squads you would lead, and the product manager is a roadmap partner; the panel prior blends each member's top two. Depth: 4 questions | Reciprocity: say what you bring them, propose seam principles instead of pretending to know the seam |
| Data-Driven Prober | Reads the figures line by line: the 60% and the 40 interviews | Medium-high. Staff engineers tend to verify claims in depth, and your two figures are the obvious targets. Depth: 3 questions | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| Values / Behavioral | A scenario about saying no to a stakeholder, probed by the cross-functional member | Medium. A product manager sits outside the function, and this round holds the one clearly cross-functional voice. Depth: 2 questions | One story at its own scope; "we" for context, "I" for contribution |

## Question bank

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where does your call as EM stop and a staff engineer's start, and what happens when you disagree?" | CASE | [generic] | Propose seam principles, not a pretend seam: ask how the squads split these today, then say how you would want it to work and where you would want to be told no. A structure to build on: technical direction decided with the staff engineers' strongest input, delivery trade-offs and people decisions yours to make with their input, disagree openly, decide, record why, revisit. Choose your own wording and your own principles; these are options, not a script | Peers price what the hire costs their own work, and a boundary question is how they check it. CASE because it is a live problem; generic because it makes no claim about your past |
| D2 | "Product wants something added to a quarter your squads have already committed to reliability work. Walk us through that conversation." | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure first, as a live problem: clarify what is being asked and by when, state the objective, set out the trade-offs you would put on the table, say who decides and how you would keep the relationship. The one story near this is your quoted sentence, told at its own scope. Answer slot: if asked how that conversation went at the time, say what you offered and who agreed, in your own words; if there was no such conversation, or it was not yours, say so plainly and stay with the sentence | F3 and F7 sit exactly here, and the product manager will hear it as a partner. CASE because the scenario is hypothetical; the story is offered only because your sentence carries it |
| D3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams, name who did what, and say how credit was given in your own account. If no such time comes to mind, say so plainly, then give the nearest thing you actually have, or how you would handle it | A standard peer probe on collaboration style. VAL because it scores behaviour against a principle, generic because no story of yours is mapped to it |
| D4 | "What would you want from the two of us in your first ninety days?" | JD | [generic] | Reciprocity framing: ask what they are stuck on first, then offer something concrete you would do as a plan, not a past. Do not only list what you need | The panel is pricing whether you reduce or add to their load, and the reverse of this question is R2-2. JD because it concerns working with the squads you would lead |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Your hiring loop did about 40 interviews last year. How were those counted, and which were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Hold the figure in your own words: "I run our hiring loop for backend roles — about 40 interviews last year." Answer slot: say how those interviews were counted, what the count is sensitive to, the assumption behind it you would defend least, and which part was yours; if you do not know how it was counted, say so plainly. It counts interviews and not hires; do not let it become a count of hires | F4's figure is a magnet for probers. EXP because it tests attribution and the denominator |
| E2 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Name it yourself before they do. Answer slot: say, in your own words, the assumption you would defend least; if you do not know how the figure was counted, say so plainly and say how you would find out. Keep "after", as the quote has it, and do not turn it into "because" | F3's number is the other figure in your material, and the weakest-assumption move turns the probe into a credibility gain |
| E3 | "The squads build device-management services. What from your payments work would you carry over, and where would you be starting fresh?" | JD | [grounded] "currently at a payments company" | Say what you do carry in your own words and be exact about its scope. Answer slot: if any of your work touched anything close to device fleets or connected systems, say what; if none did, say so plainly and stay with the payments company. Close with a plan for getting to depth, as a plan and not a past | F2 is the domain gap, and staff engineers are the people best placed to test it. JD because it scores the stated domain |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you said no to a stakeholder and kept the relationship." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The closest thing your quote carries is the quarter you pushed through against roadmap pressure; use its beats and no more. Answer slot: if the pressure came from a person you worked with, say how it landed and where the relationship stood afterwards, in your own words; if it was not personal, or you were not the one holding the line, say so plainly and stay with the sentence. If no such time comes to mind, say so plainly, then give the nearest thing you actually have, or how you would handle it | A product manager outside the function probes behaviour, not technique. VAL because it scores handling of a stakeholder, mapped to F7's thin evidence |
| F2 | "How should product and engineering make roadmap trade-offs together?" | JD | [generic] | A view, not a past: a shared objective first, the cost of changing course made visible, a named decider, a way to disagree and revisit, and hardware dependencies surfaced early. Say it in your own words, as what you would want | The role's third clause and F7 make it likely; asked by the person who owns the roadmap, it is also a test of whether you will treat product as a partner. Generic because it claims nothing about your past |

## Reverse questions for Thursday

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "Where do the squads most want an EM involved, and where is it just friction?" | Shows you are pricing your load on their work, which is what peers are scoring |
| R2-2 | "What could a new EM do in their first month that would genuinely help your squads?" | The reciprocity question for a peer panel; it signals partnership, not entitlement |
| R2-3 | "When a roadmap commitment has to give, how is that decision made today?" | For the product manager; surfaces the seam directly and previews your future trade-offs |
| R2-4 | "How does hardware's schedule reach the roadmap: through product, or straight to the squads?" | Tests the one area of F6 you have said is new to you, in a question and not a defence |
| R2-5 | "Is there a recent decision you would want a new EM to understand the history of?" | Invites a story, which shows what the group is still carrying and how they talk about it |

---

# Round 3: The following Monday, VP Engineering, 30 min

The recruiter's description, as you relayed it, was "values and leadership philosophy". That makes this a values-style round, but no published Larkfield values were read, so the questions use standard stems.

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Leadership philosophy and behavioural scenarios | High. The recruiter's own words name it, and 30 minutes leaves room for four or five questions. Depth: 4 questions | Principles in your own words, each tied to one thing you did, at its own scope |
| Pressure | Time-boxed challenges to the two gaps and the 60% figure | Medium-high. The skip-level prior adds Pressure beside strategy fluency, and the two gaps are the natural targets. Depth: 3 questions | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |
| Case / Strategist | One altitude question about how engineering, hardware and product work together | Medium. The skip-level prior includes it, but a values-led round limits time. Depth: 2 questions | Clarify before you structure; no invented facts about Larkfield |

## Question bank

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What is your leadership philosophy, in practice?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The principles are yours; the pack supplies none. Pick two or three you actually act on, and pair each with one thing you did, using only these two sentences at their own scope as examples. If no principle comes with an example you can stand behind, say so plainly and say what you are working toward | The recruiter named leadership philosophy as the round's subject. VAL because it scores whether stated principles are backed by behaviour; F3 and F4 are the only sentences that can back them |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Selection scaffold: it needs a named stake, a moment you did not fold, and a relationship intact at the end. The nearest your material carries is the quarter pushed through against roadmap pressure. Answer slot: if that involved telling someone senior something they did not want to hear, say who and how it landed, in your own words; if it did not, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing you actually have, or how you would handle it | A standard values stem; the hard truth has to have landed. The mapping is thin because F7 is thin |
| H3 | "How do you think about growing engineers when growth and delivery pull in different directions?" | VAL | [generic] | A philosophy question with no claim about your past. Say how you weigh the two, in your own principles. Answer slot: if you have an example, say whom, anonymised, and what you did; if you do not, say so plainly and say how you would approach it | The role names growth, F5 is silent, and a VP uses this to read your leadership philosophy. Generic until you supply a story |
| H4 | "Tell me about a decision you made as a leader that you would make differently now." | VAL | [generic] | Selection scaffold: pick a real decision, say what you knew then, what you know now, and what you changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing you actually have, or how you would handle it | Leaders are scored on whether they learn out loud. Generic because no quoted sentence carries it |

### I. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Sixty seconds: why you, when you haven't owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A1 in sixty seconds. Pause and restate the question. Limit first: "I've never owned a hardware-adjacent roadmap." Then the quote at its scope and the one-sentence plan. Hold through two follow-ups; concede specifically that the example is about a reliability quarter and roadmap pressure, not hardware | The same objection as A1, in its executive form; F6 is the highest-ROI rehearsal in the pack, and a VP will test composure on it |
| I2 | "That 60%, how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause. Hold on what the sentence says: the part that was yours is that you pushed the quarter through, and the drop is the team's burden. Answer slot: if you know what else contributed, say so in your own words; if you do not know how much of the drop was the quarter, say so plainly. Never claim the whole figure | The stem is the persona's own, and F3's causal gap is where it bites. EXP because it tests attribution |
| I3 | "You haven't managed managers. How do you think about leading through other leaders?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Plain acknowledgment first: "I've never managed managers." Then your scope in its own terms, "3 as a team lead of 6". Then your thinking about leading through leads, in your own principles, with no past claimed; and ask whether the two squads have leads today. Hold through a second follow-up by returning to the same two facts | F1's stated negative, put by the person senior enough to care about it. JD because it concerns the structure of the role |

### J. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What do you think makes device management hard for industrial customers?" | CO | [generic] | Say only what you know and where it came from, and where you do not know, reason aloud from the shape of the problem and name your assumptions. Make no claim about Larkfield beyond the role description. Answer slot: if you have worked near connected systems, say what; if not, say so plainly and reason from what you can see | The role description raises the domain, and F2 is the thin row. No research ran, so this stays generic, and the upgrade menu says what research would have added |
| J2 | "If you could change one thing about how engineering, hardware and product work together, what would you want to find out first?" | CASE | [generic] | Clarify before proposing: who owns which dates, where decisions get stuck, what has gone wrong before. Then name the one thing you would test first and how you would know. No invented facts about Larkfield | An altitude question for a VP; it touches F6 and F7 without claiming either. Generic because it is a pattern, not a fact about this employer |

## Reverse questions for Monday

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What does good look like for this EM at twelve months?" | A VP can answer at the right altitude, and it tells you how they measure the role |
| R3-2 | "How do you want an EM to bring you bad news?" | Fits a values round and shows you expect to have bad news to bring |
| R3-3 | "How does engineering leadership here think about the balance between reliability and roadmap?" | Connects to your own quoted quarter without claiming more than it says |
| R3-4 | "What leadership trade-off are you working through yourself this year?" | Moves the conversation from interrogation to peer-level thinking |
| R3-5 | "What would you want me to have learned by the end of my first ninety days?" | Ends on shared expectations and signals you intend to listen first |

---

## Prohibited claims

Built from the fit snapshot before the banks were written. No dossier was present, so this list is local.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 | The plain acknowledgment: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot |
| Led two squads, or led more than a team of 6 | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation: your material says a team of 6, not two squads. A2's slot stays inside that scope |
| Cut on-call burden by 60%, or caused the drop | Inflated form of F3 | F3's quote at its own scope, with "after" kept. The material does not say how the figure was counted. A4 and E2 ask only how it was counted and which part was yours |
| Owned delivery, or owned the roadmap, for your team | Inflated form of F3 | F3's quote at its own scope: you pushed a reliability quarter through against roadmap pressure. The material does not say who set the roadmap |
| Hired or made hiring decisions for 40 people | Inflated form of F4 | F4's quote at its own scope: "I run our hiring loop for backend roles — about 40 interviews last year". It counts interviews, not hires. C2 and E1 ask only how it was counted and what was yours |

Requirements with no quote behind them at all (F2, F5) are silence, not entries; they are answer slots.

## Sources

- **Provided:** your message (the role description, the three-round schedule, and your background). No CV, no full JD, no dossier.
- **Loop:** established by your own words (rounds, who runs each, length). No archetype fallback was used. The round 3 values-style label rests on the recruiter's phrase "values and leadership philosophy", as you relayed it.
- **Searches sent (all refused, so nothing from the web is used anywhere in this pack):**
  - "Larkfield Systems industrial IoT company values": refused
  - "Larkfield Systems interview process engineering manager": refused
  - "Larkfield Systems industrial IoT device management news strategy": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Every call was refused. It would have fed a values cheat sheet for Monday; none is built, and round 3 uses standard stems |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Every call was refused. It would have checked the loop against a documented one; the loop here rests on your account alone |
| 3. Larkfield Systems strategy and recent news | unavailable | Every call was refused. It would have grounded CO and CASE questions in current priorities; J1 and J2 stay generic |
| 4. Interviewer name and company | n/a | No names were given, so there was no query to form; there is no interviewer read |
| 5. Representative Engineering Manager JD | skipped | The role description you gave fixes the fit snapshot rows and the JD-tagged questions; a full JD would sharpen them, as the upgrade menu says |

## Upgrade menu

- The full JD text → F1 to F7 requirement quotes become the posting's exact words, and mid-list requirements the one-line role description may omit get questions
- Your CV → F2 and F5 may gain evidence, and the fit snapshot's evidence column draws on more than four sentences
- Your answers to the slots, outside a drill → F3 (how the 60% was counted and who set the roadmap), F4 (what you set or changed in the loop), F5 (a growth story) and F7 (whether product applied the pressure) each upgrade from a slot to a mapped story
- Each interviewer's name and title → a per-member persona assignment for Thursday, an interviewer read for each round, and at least one reverse question tied to a path
- The recruiter's notes for each round → coverage assumed from round-type priors becomes stated, and any pre-declared deliverable gets its own build section
- A pasted Larkfield values page, or search access → a values cheat sheet for Monday, mapping each named value to a quoted sentence of yours or a selection scaffold
- Deep research (up to 6 more searches and 2 more fetches, several more minutes, and it needs search access, which was refused here) → a grounding brief on strategy and recent organisation context, and CO and CASE questions rooted in it
- Hours available per day → a prep triage ordered by what to rehearse first
- A tuesday-dossier.md → verified evidence and a prohibited-claims list from a prior assessment would replace the locally built one
