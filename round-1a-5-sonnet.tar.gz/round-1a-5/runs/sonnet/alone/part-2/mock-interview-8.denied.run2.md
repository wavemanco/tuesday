I'll read the reference files the skill points to before building the pack.
I'm running a last format check on the saved pack, covering stray square brackets and table column counts, before I send it to you.
Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a loop for the three rounds on 4 December, from your background paragraph alone because there was no CV text. It has a shared fit snapshot, then a persona table, question bank and reverse questions for each round. The panel round also has the values cheat sheet.

I ran no web searches. Your pasted values, the recruiter's email, the JD and the brief points already fixed everything a search could have changed.

S4 is the pack's highest-ROI prep. It is the round 2 question on owning complaints across the branches and the contact centre, when you haven't worked in a contact centre. It comes with a hold-then-concede ladder built only from your own sentences.

Say the word and I'll play the Head of Member Services on S4 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

If you paste your CV, I can quote it into the fit snapshot. The rows on regulated complaints, the monthly spreadsheet and coaching supervisors each rest on one sentence of your message. More of your own lines would let me map fuller stories and rebuild those answer slots. I'll proceed on what I have if you'd rather not.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds on 4 December 2026. **Built from:** the JD, the published values, the recruiter's email, the strategy brief points, and your background paragraph. No CV text was supplied, so every row about your past rests on a sentence of your message.

**Highest-ROI prep in this pack: S4**, the contact-centre question in round 2. It is the likeliest objection to you, it is aimed at the JD's headline duty, and your own message names the gap.

## The loop

| Round | Who | Length | What it holds | Provenance |
|---|---|---|---|---|
| 1 | The recruiter | 30 minutes | A conversation with the recruiter | [grounded] |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural | [grounded] |
| 3 | A panel of two branch managers | 60 minutes | A 20-minute case on a complaint escalation, and the values round, scored against the four values | [grounded] |

Interviewers beyond their roles have not been assigned, so there is no interviewer read in this pack.

## How to use this pack

- **Personas describe how a question arrives; types describe what is scored.** Each round has its own persona weights, shown with the reasoning so you can recalibrate.
- **Type key:** VAL is behavioural or values alignment. EXP is a deep-dive on your own experience. JD is the stated role and its requirements. CO is knowledge of the company and its strategy. CASE is a live problem.
- **Guidance is scaffolding, not a script.** Say it in your own words. Every claim about your past is a sentence you wrote, quoted beside the question.
- **Answer slot** means an instruction for the interview, not a question for you here. It names what an interviewer is likely to probe, and gives two honest branches: say what you did, or say plainly that there was no such step or it was not yours.
- **Question IDs run by persona letter:** C is Conversational, S is Skeptic, V is Values/Behavioral, K is Case/Strategist, P is Peer Evaluator. They are numbered once across the pack.

## Fit snapshot (shared by all rounds)

No row is a hard gate: the JD as supplied states no authorization, licence, location, schedule or pay term, and its 4+ years line is a length of experience.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Words stay in the quote's own terms: "I've spent six years in retail banking, the last three as a branch supervisor." The quote says retail banking, not the JD's phrase, so say it as you wrote it and let the interviewer connect it. Answer slot: if asked what the supervisor years covered, describe what the role covered in your own words |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Words stay at the quote: "I handled the branch's formal complaints log." Your material says the log, with nothing inspected behind it, and does not say which rules it was kept under. Answer slot: the JD's word "regulated" makes a probe on that likely. If any rules governed how those complaints were handled, say which and what they meant for you, in your own words; if you do not know, or none applied, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Words stay at the quote: "I handled the branch's formal complaints log." Your material says one branch's log, not a process across sites. Answer slot: if any stage of how that branch's complaints moved was yours to set, say which and how you decided, in your own words; if none was, or it was not yours, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Words stay at the quote: "I built the monthly complaints spreadsheet our regional manager uses." The quote does not say what it counted. Answer slot: if it carried complaint volumes or resolution times, say which and how they got into it; if it held other measures, say what; if you are unsure what it carried, say so plainly and stay with the fact that you built it |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says spreadsheet, not which tool. Answer slot: say which tool you built it in; if it was not Excel, say so plainly and say what you used |
| F7 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare for a first one, said as a plan and never as a past |
| F8 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Words stay at the quote's scope: "I trained new tellers on our escalation script." Answer slot: if you ever coached or advised another supervisor on an escalation, say what and what part was yours; if not, say so plainly and stay with training new tellers |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | The material is silent here. Answer slot: if you have worked with a digital or online team on how members help themselves, say what and what your part was; if you have not, say so plainly and say what you would want to learn first |

## Grounding brief

From the strategy brief you were sent. These are the four points you gave me; the pack knows nothing else of the brief.

| Point | Where it bites in this loop | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | K6 and S6; reverse questions RQ8 | [grounded] |
| Consolidate eight branches into five hubs over 2027 | K5 and V6, with the panel of two branch managers; whether either panelist's branch is affected is unknown, so stay neutral | [grounded] |
| Launch a small-business lending product in Q1 2027 | A new product is a new source of member questions and complaints for this role to be asked about; use it as a reverse question, not as a claim | [inferred] |
| The main competitive pressure is app-only banks | K6: the case where a member gets stuck in self-service | [grounded] |
| Neighbours, Not Numbers and the hub plan sit close together, and Plain Words and digital journeys do too; expect the panel to test how you hold both | Derived from the value texts and the brief points above | [inferred] |

---

# Round 1: the recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly opener, the career journey, motivation, then logistics | High. A recruiter screen's prior is Conversational plus a light Skeptic, and the email says the first round is 30 minutes with the recruiter | A pre-scripted 90-second arc for the journey question; treat the casual questions as scored |
| Skeptic (light) | A knockout check in a friendly register: the years, the complaints work, the contact centre | Medium. Your message names the contact centre as a gap, and it sits in the JD's headline duty | Say the plain acknowledgment first, then one sentence of plan; leave the full rehearsal for S4 |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc built only from those three sentences, in your own words: six years in retail banking, the last three as a branch supervisor; then the complaints strand, the log you handled, the tellers you trained on the escalation script, and the monthly spreadsheet you built for the regional manager. Close with one sentence on why this role, in your own reason; the pack supplies none. Add no scale, outcome or result the sentences do not state | F1, F2 and F5 are the evidence. EXP because the recruiter is checking that the story holds together, and the arc answers most openers |
| C2 | "What draws you to Ashgrove?" | CO | [grounded] | Pick one thing from their own published words that you can say honestly: a value by its official name (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix) or one point of the July 2026 strategy brief. Say why it matters to you, in your own words; the pack supplies no reason. Do not recite the list | A motivation check with a homework signal. CO because it scores whether you know what they have published |
| C3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first; this pack supplies no figure. If asked what you earn now: "I'd rather focus on the range for this role." | A recruiter screen's pay question; the supplied JD gives no band. Tagged JD because it is a term of the listed job |
| C4 | "What's your notice period, and when could you start?" | JD | [generic] | Logistics slot: give your actual notice period and your earliest start, in your own words. The pack supplies no figure | The standard availability check; tagged JD as a term of the listed job |
| C5 | "Where are you based, and does the role's location work for you?" | JD | [generic] | Logistics slot: say where you are based and what works for you, in your own words. If the recruiter has not said which site the role sits at, ask; RQ2 does that | A location check; the JD as supplied does not state one. Tagged JD as a term of the listed job |
| C6 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your own reason in a sentence or two, said about what you are moving towards where that is true; the pack supplies none. Keep it consistent with C1 and C2, because the recruiter will compare them | The reason-for-leaving check. EXP because it tests the consistency of your own account |
| S1 | "The role asks for four-plus years in financial-services customer operations. Where do your six years in retail banking fit?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it in the quote's own terms: "I've spent six years in retail banking, the last three as a branch supervisor." Stop there and let the recruiter connect it. Answer slot: if asked what the supervisor years covered, describe what the role covered, in your own words | F1 is the evidence for the years line, a knockout item at screen. JD because it scores a stated requirement |
| S2 | "The role involves regulated complaints. What did you handle in your branch's complaints log?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F2 at its scope: "I handled the branch's formal complaints log" and "trained new tellers on our escalation script", told as you would say them. Answer slot: the JD's word "regulated" makes a probe on which rules applied likely. If you know which rules governed how those complaints were handled, say which and what they meant for how you handled them; if you do not know, or none applied, say so plainly and stay with the log | F2 is the evidence and the likeliest knockout probe after the contact centre. JD because it scores the stated requirement |
| S3 | "The role covers the contact centre too. You haven't worked in one, have you?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | A light version of S4. Words: "I haven't worked in a contact centre." Then one sentence on how you would learn it, as a plan and not a past. Save the full ladder for S4 | F4 is the gap, and a screen is where it first surfaces. JD because it tests a stated requirement |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Who will be on the panel on the 4th, and is there anything about the 20-minute case I should know in advance?" | It gets the panel's roles and the case format from the one person who knows both, so K3 and K4 can be sharpened |
| RQ2 | "Which site would the role sit at, and does the move to five hubs over 2027 change that?" | Ties a logistics fact to the strategy brief and shows you read it |
| RQ3 | "What does the Head of Member Services most want from this hire in the first six months?" | Turns the recruiter into a coach for round 2 |
| RQ4 | "Where does the role sit between the branches and the contact centre day to day?" | Shows you have understood the JD's headline duty and gives you words for S4 |
| RQ5 | "What happens after the three rounds, and when should I expect to hear?" | Closes the process loop and shows readiness |

---

# Round 2: the Head of Member Services (45 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the three gaps: the contact centre, senior presenting, digital | High. A hiring manager's prior is Case plus Skeptic, and this person is buying capability and derisking F4, F7 and F9 | Rehearse S4 until it is boring: plain acknowledgment, the scope of what you did, a plan, a concession, never a bluff |
| Values/Behavioral | Open prompts such as "tell me about a time" | High. The recruiter described the round as mostly behavioural, which lifts it above the hiring-manager prior | Choose stories where your own part is clear: "we" for context, "I" for contribution; where no story comes to mind, say so |
| Case/Strategist | A short live problem from the real role | Low. The prior says case, but the email says mostly behavioural, so it is cut to two questions | Clarify first, structure aloud, name one premise you would test |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S4 | "This role owns complaints across the branches and the contact centre, and you haven't worked in a contact centre. How would you own that half?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked in a contact centre." Name the limit before it is asked for, then your own side: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Follow-up one, what would you do in your first month: give a plan in your own words, what you would want to see first and whom you would ask, said as a plan and not a past. Follow-up two, what if the contact-centre lead disagrees with your read of a complaint: hold on the principle that the member hears one clear answer and someone keeps hold of the outcome, and concede that they know the channel better than you. Follow-up three, why trust you with a channel you have not seen: concede that you have not seen it, hold on the scope of what you did, and do not say complaints are the same in any channel. Never claim contact-centre work or an equivalent | F4 is the gap, and the duty it sits in is the JD's headline. The objection is aimed at where the material is thinnest, so the hold is only what the two quotes carry. JD because it scores a stated requirement; the delivery is Skeptic |
| S5 | "You haven't presented above regional level, and this role reports to senior leaders every month. How would you handle your first one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Words: "I haven't presented to anyone above regional level." Then what you have: "I built the monthly complaints spreadsheet our regional manager uses." Say that at its scope; the sentence does not say you presented it. Then a plan in your own words: how you would find out what that audience wants from the report before you build it. Hold the plan through a second follow-up and concede that it is a new audience | F7 is the stated gap, and the monthly reporting line makes it likely. JD because it scores a stated requirement |
| S6 | "The role works with the digital team on self-service journeys. What have you done with digital?" | JD | [grounded] | Answer slot: if you have worked with a digital or online team on how members help themselves, say what and what your part was; if you have not, say so plainly, then say what you would want to learn first. You may show you have read the brief, 40% of member service on digital by 2028, as context, not as expertise | F9 is silent in your material, so this is a slot and not a story. JD because the JD names the duty |
| S7 | "Tell me about the monthly complaints spreadsheet. What did it count, and what was your part?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The defend-it moves, in your own words: what it counted, which tool you built it in, how entries got in, the assumption in it you would defend least, and which part was yours. Words at scope: "I built the monthly complaints spreadsheet our regional manager uses." If you do not know how a figure in it was counted, say so plainly. If anyone else contributed, say so | F5 and F6 are the evidence and are medium: a sentence with nothing inspected behind it. EXP because it tests attribution |
| V1 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, not a story: choose a problem you found yourself, say what you did next, and say how you knew it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log", at its own scope, or how you would handle it | The theme comes from the value Own the Fix. No sentence of yours carries a story with an ending, so this is a scaffold. VAL because it scores a published value |
| V2 | "Tell me about a time you helped a colleague through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F8 at its scope: "I trained new tellers on our escalation script." Answer slot: if you ever coached or advised another supervisor on an escalation, say what and what part was yours; if not, say so plainly and stay with training new tellers. Do not describe a coaching conversation you did not have | The JD asks you to coach supervisors on escalations. JD because it scores that requirement; behavioural in delivery |
| V3 | "Tell me about a time you had to tell someone more senior something they did not want to hear." | VAL | [generic] | Selection scaffold: it needs a named stake, a moment you did not fold, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing you actually did, or how you would handle it | A persona stem for the Values interviewer, and the JD's senior-leader line (F7) makes it likely. VAL because it asks for past behaviour |
| V4 | "Tell me about a time you worked with a team outside your own to get something better for members." | VAL | [grounded] | Selection scaffold: choose one occasion, name the other team and what each side needed, and say what changed for members. If no such time comes to mind, say so plainly, then give the nearest thing you actually did, or how you would approach a first conversation with a digital team | The JD's digital-team line (F9) raises it. VAL because it tests cross-team behaviour, and it doubles as cover for F9 |
| K1 | "A branch supervisor rings you: a member was told their complaint is closed, and says it isn't. What are your first ten minutes?" | CASE | [generic] | Clarify first: what the member was told, by whom, what has been recorded, whether it is a formal complaint. State the objective: the member knows where they stand today. Then approach: who keeps hold of it, a plain explanation to the member, then why it was closed too early. End with what you would watch. Think aloud and challenge one premise respectfully | A live problem from the role's escalation duty (F2 and F3). CASE because it asks for structure, and it makes no claim about your past |
| K2 | "How would you report complaint volumes and resolution times to a senior leader who has five minutes?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Structure aloud: one headline, the two measures the JD names, what moved, and the decision you want. Answer slot: if your monthly spreadsheet carried volumes or resolution times, say how you would lift them into a five-minute summary; if it carried other measures, say which and what you would add | F5 and F7 meet here. CASE because it is a live reporting problem; JD content |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ6 | "How are complaints passed between the branches and the contact centre today, and where does it break most often?" | A manager hears you looking for the hardest part of the job first |
| RQ7 | "Who would I present the monthly report to, and what do they decide from it?" | Prepares you for F7 and shows you think about the audience |
| RQ8 | "What is the digital team building for member self-service now, and where would complaints data help them?" | Ties to the 40% digital target and the JD's digital line |
| RQ9 | "What would you want to see changed by the end of my first ninety days?" | Gives you the manager's own measure of success |
| RQ10 | "With a small-business lending product due in Q1 2027, how do you expect it to change what this role handles?" | Shows you read the brief and links to your remit |

---

# Round 3: the panel of two branch managers (60 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario prompts scored against the four values | High. The recruiter said the panel is the values round and scores against the four values | One story per value where a sentence of yours carries one, a scaffold with an honest branch where none does |
| Case/Strategist | The 20-minute complaint-escalation case | High. Twenty of the 60 minutes are a case, a third of the round | Clarify, objective, approach, risks; say it in plain words |
| Peer Evaluator | The seam between a branch manager and you; credit and blame | Medium. They are branch managers, and the role coaches branch supervisors and works across branches; that reading is inferred, not documented | Propose seam principles, not facts about their branch; say what they can expect from you |
| Skeptic | A pressure question on the contact centre | Low. Rounds 1 and 2 will already have raised it, but a panel may test it again | Concede first, hold on scope |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V5 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold, not a story: choose one decision, say what the member would have seen on each side of it, and say what you chose and why. If no such time comes to mind, say so plainly, then give the nearest thing you actually did, or how you would handle it. Keep the telling in plain words | The value Members First, Always is scored by name in this round. No sentence of yours carries a decision story, so this is a scaffold. VAL because it scores a published value |
| V6 | "Tell me about a time you took a branch's place in its town into account when you made a decision." | VAL | [grounded] | Selection scaffold: choose one decision, say who in the town it touched, and say what you did differently because of it. If no such time comes to mind, say so plainly, then give the nearest thing you actually did, or how you would weigh it. If they bring up the hub plan, take no position on which branches change; ask what they would want protected | The value Neighbours, Not Numbers is scored by name, and sits next to the consolidation in the brief. VAL because it scores a published value |
| V7 | "Tell me about a time something had to be explained twice, to a member or a colleague." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F8 at its scope: "trained new tellers on our escalation script". Answer slot: if any wording in the script, or your way of explaining it, changed because a teller or a member needed it explained twice, say what changed and who noticed; if nothing did, or the script was not yours to change, say so plainly and describe how you trained from it | The value Plain Words is scored by name, and the escalation script is the one sentence of yours that touches wording. VAL because it scores a published value |
| V8 | "Tell me about a time the fix sat with another team and you stayed with it." | VAL | [grounded] | Selection scaffold, and the same story can serve V1: choose one problem, say which team held the fix, what you did to stay on it, and how you knew it was solved. If no such time comes to mind, say so plainly, then give the nearest thing you actually did, or how you would handle it | The value Own the Fix is scored by name, and the JD's end-to-end line raises the cross-team angle. VAL because it scores a published value |
| K3 | "Here is the case: a member has complained twice about the same problem at a branch. The branch says it is closed; the member says it is not, and is now talking about taking it further. Walk us through what you do, and what you need to know first." | CASE | [generic] | Clarify first, aloud: what the member has been told and by whom, what has been recorded, whether it is a formal complaint and which rules it falls under, what the member wants. State the objective in plain words. Then approach: who keeps hold of it, what the member hears and when, what the branch needs from you, and how you check it is closed. Name one risk and one thing you would measure. Challenge one premise respectfully. The case itself is the panel's, so expect it to differ; this is the structure, not the answer | The recruiter's email says 20 minutes of the round is a case on a complaint escalation; the real case is not known, so this one is generic. CASE because it asks for structure. The F2 and F3 requirements sit underneath it |
| K4 | "The supervisor on the case says the member is being unreasonable. How do you coach them?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Structure the conversation aloud: ask what happened in their words, put the member's account back in plain words, agree the next step the supervisor keeps hold of, and agree when you will check back. Where your own experience stops: "I trained new tellers on our escalation script", at that scope. Answer slot: if you have coached a supervisor, say what and what part was yours; if not, say so plainly | The follow-up to K3 and the JD's coaching line, F8. CASE because it is a live conversation to rehearse |
| K5 | "The strategy moves eight branches into five hubs over 2027. What does that do to complaints, and what would you watch?" | CO | [grounded] | Say first that you do not have Ashgrove's data. Structure: what changes for members, where a complaint could get lost between sites, what you would track, the JD's two measures, by site, before and after, and what you would ask the managers to protect. Link to Neighbours, Not Numbers. Stay neutral on which branches change | The consolidation is in the brief the recruiter sent; CO because it asks you to think at the company's altitude, as a case. Whether either panelist's branch is affected is unknown |
| K6 | "The brief targets 40% of member service on digital by 2028, and names app-only banks as the pressure. Where do complaints go wrong in self-service, and how would you design for a member who gets stuck?" | CASE | [grounded] | Structure: the member's journey, where they get stuck, how stuck becomes a complaint, how a person picks it up with the story already attached so the member does not explain twice, and how the digital team learns of it. Answer slot: if any of your complaints work touched online or app channels, say what; if not, say so plainly | F9 is silent in your material, and the brief makes the digital line the strategy. CASE because it is a live design problem; CO content |
| P1 | "Where is the seam between a branch manager and you when a complaint escalates, and what happens when we disagree?" | JD | [generic] | Propose seam principles and do not claim to know their seam: who the member hears from, who holds the file, when it goes up. For disagreement, say you would start from the member's outcome. Reciprocity: say what they can expect from you and what you would need from them, as commitments and not past achievements | The panel is two branch managers, and the JD links the role to branches and to coaching supervisors. JD because it tests the stated working relationship; the delivery is Peer |
| P2 | "How do you handle credit and blame when a complaint spans a branch and the contact centre?" | VAL | [generic] | A principle, not a past: Own the Fix, one person keeps hold of the outcome while credit is shared. If you give an example, it must be one you actually lived; if none comes to mind, say so plainly and say how you would handle it | A persona stem for the Peer Evaluator. VAL because it tests credit-sharing behaviour; no claim about your past |
| S8 | "Sixty seconds: why you, rather than someone who has run a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold-then-concede. Concede first: "I haven't worked in a contact centre." Then hold at scope: "I've spent six years in retail banking, the last three as a branch supervisor," and "I handled the branch's formal complaints log." Do not claim equivalence. Close on one reason of your own for this role; the pack supplies none | F4 returns in pressure packaging; F1 and F2 give the only ground the quotes carry. JD because it tests the stated requirement; the delivery is Pressure |

## Values and principles cheat sheet (round 3)

| Value (official name) | Working meaning | Mapped story | Provenance |
|---|---|---|---|
| Members First, Always | Decisions start from what the member experiences | No sentence of yours carries a story. Selection scaffold at V5, ending in its honest branch | [grounded] |
| Plain Words | If the member needs it explained twice, the wording was wrong | F8: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Use the script training at its scope; V7 holds the answer slot | [grounded] |
| Neighbours, Not Numbers | Each branch is part of its town, so local weight counts | No sentence of yours carries a story. Selection scaffold at V6, ending in its honest branch | [grounded] |
| Own the Fix | Whoever finds a problem keeps hold of it until solved | No sentence of yours carries a story with an ending. Selection scaffold at V1 and V8; the nearest thing your material carries is F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." at its own scope | [grounded] |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ11 | "When a complaint escalates to you, how do you want it to arrive, and what do you wish arrived earlier?" | Asks the panel what they need, which is the Peer Evaluator's real question |
| RQ12 | "What does Neighbours, Not Numbers look like in your branch on an ordinary day?" | Uses their published value in their own terms |
| RQ13 | "Through the hub changes in 2027, what would you most want kept for your members?" | Stays neutral on who changes and invites their priorities |
| RQ14 | "Where do supervisors most often get stuck on an escalation?" | Points at the coaching duty and gives you a place to start |
| RQ15 | "In six months, what would make you say this hire made your branch's life easier?" | The reciprocity question for a peer panel |

---

# Shared sections

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| 4+ years in financial-services customer operations | C1, S1, S8 |
| Experience handling regulated complaints | S2, K3 |
| Own the member complaints process end to end | K1, K3, P2 |
| Across the branches and the contact centre | S3, S4, S8, P2 |
| Report monthly on complaint volumes and resolution times | S7, K2, K5 |
| Coach branch supervisors on escalations | V2, K4, P1, V7 |
| Confident presenting to senior leaders | S5, V3, K2 |
| Work with digital teams on self-service journeys | S6, V4, K6 |
| Comfortable with Excel reporting | S7 |
| The four values | V1 and V8 (Own the Fix), V5 (Members First, Always), V6 (Neighbours, Not Numbers), V7 (Plain Words) |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in a contact centre, or has equivalent contact-centre experience | Negative you stated, F4 | The acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F7 | The acknowledgment F7 gives: "I haven't presented to anyone above regional level." No slot |
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says one branch's log, not a process across sites. S4 and K3 stay inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The pack's observation: the material says the formal complaints log, not which rules applied. S2's slot asks only what governed how those complaints were handled |
| Coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope: new tellers on the escalation script. V2 and K4 slots stay inside that |
| Reported complaint volumes and resolution times each month | Inflated form of F5 | F5's quote at its own scope: the spreadsheet you built. The pack's observation: the material does not say what it counted. S7's slot asks only what it held |
| Built the complaints report in Excel | Inflated form of F6 | F6's quote at its own scope. The pack's observation: the material says spreadsheet, not the tool. S7's slot asks which tool |

## Sources

- **Provided documents:** the Member Experience Lead JD (pasted); Ashgrove's published values, pasted and copied on 25 November 2026 from the values page; the recruiter's email on the three rounds on 4 December; the strategy points from the brief published in July 2026, which the recruiter sent; your background paragraph.
- **Searches and fetches sent:** none.
- **Dossier:** none present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Could not have moved the values cheat sheet: the pasted values text fixes the four value names and their wording |
| 2. Ashgrove interview process | skipped | Could not have moved the persona weights: the recruiter's email fixes the three rounds, who runs them and what they hold |
| 3. Ashgrove strategy and recent news | skipped | Could not have moved K5 and K6: the brief's points you pasted already supply the strategy and the competitive frame |
| 4. Interviewer name and Ashgrove | n/a | No names were given beyond roles, so there was no query to form; there is no interviewer read |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A CV, or any further lines about your complaints and reporting work → F2, F3, F5, F6 and F8 are single-sentence rows; more of your own sentences would let the stories in C1, S7 and V7 be mapped beyond their one quote.
- Your answers to the answer slots on F2, F3, F5, F6, F8 and F9, written as your own words outside a drill → each becomes quoted evidence and its row and bank cells are regenerated.
- The column headings of your monthly complaints spreadsheet, or the text of the escalation script you trained tellers on → F5, F6 and F8 move from a sentence with nothing inspected behind it toward inspectable evidence.
- The panel's names and roles, and the Head of Member Services' name → an interviewer read from public professional footprint, reweighted personas, and a reverse question tied to their own path.
- The recruiter's guidance on the 20-minute case: format, whether there is pre-reading, who sets it → K3 and K4 move from a generic case to the real format.
- Your own pay expectation, notice, location and reason for leaving, if you want them quoted → C3 to C6 would quote your words in their slots.
- Your hours available between now and 4 December → a prep triage, sized to that time.
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, aimed at strategy beyond the four brief points, role-family loop reports and recent organisation context → the grounding brief and K5 and K6 become sharper.
- A `tuesday-dossier.md` from an earlier evidence pass → graded evidence and a strategy per weak area; never required.
