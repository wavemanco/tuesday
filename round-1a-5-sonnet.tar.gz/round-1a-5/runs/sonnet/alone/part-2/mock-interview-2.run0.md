I'll read the reference files the skill points to before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-2-denied-f2b616fd/atlas-freight_operations-manager_interview_pack.md`. It has 22 questions across seven interviewer styles. Because I don't know who you're meeting, the style weights are flat and rest on a generic screen, hiring manager, panel pattern. The web searches I tried were not permitted, so nothing in it comes from research on Atlas. It has no company-strategy or values questions, and nothing in it is guessed about the company.

The question to rehearse first is B1: you're over three supervisors, and the role has twelve across four sites. Several other probes are variants of that one. Your materials are thinnest on four things:

- **Scale:** you've run one site's surge plan, and the role covers four sites.
- **Measures:** your mis-pick result isn't on-time performance or cost per shipment.
- **Leadership years:** you've given seven years in operations, but not how many of them were spent leading people.
- **Power BI:** you've never used it, so the pack coaches a plain "I haven't used Power BI" plus a plan.

Say the word and I'll play the Skeptic on B1 and react to what you actually say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you know who's interviewing you next week, and what the recruiter said the round will cover? Either answer would reweight every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview pack: Operations Manager, Atlas Freight

Interviewer: not known. Relationship and round type: not known, so persona weights below are flat and rest on a generic loop pattern, not on anything about Atlas. Built from the job description lines and background you pasted; no company research was possible (see Sources).

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Every question has a type, a provenance label with the exact sentences of yours the guidance rests on, guidance, and a rationale. Guidance is scaffolding, not a script: say it in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your CV claims survive scrutiny: what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: no research ran) |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now: it names what an interviewer is likely to probe and gives two honest branches. Say what happened if it did, or say plainly that it did not or was not yours. The pack never fills a slot for you.

The single highest-ROI rehearsal is B1 (three supervisors against twelve, one site against four). Do that one until it is boring.

## Fit snapshot

Requirements are quoted from the job description lines you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD, your message | "ran the site's peak-season surge plan two years running" — your message; "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | The words stay at one site: "I ran the site's peak-season surge plan two years running." The pack's observation: your material says warehouse and distribution and one site's plan, not terminals and not four sites. Answer slot: the JD's four-site line makes a probe on scope likely. If any of your responsibility reached beyond one site, say which and how, in your own words; if none did, say so plainly and stay with the surge plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD, your message | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The words stay at their scope: "I cut mis-pick rate 40% by redesigning the pick path." The pack's observation: mis-pick rate is neither of the two measures the JD names, and your material shows neither. Answer slot: if you tracked any other measure alongside mis-picks, say which and what it did, in your own words; if you tracked none, say so plainly and stay with mis-picks |
| F3 | "lead a team of 12 supervisors" — JD, your message | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The words stay at their scope: "I'm a senior shift manager over three supervisors." The pack's observation: three against the JD's twelve, and "currently" speaks only to the present role. Answer slot: if you were over more supervisors at any earlier point, say when and how many; if not, say so plainly and stay with the three. For the step up in scale, bring a plan, never a past |
| F4 | "build reporting in Excel/Power BI" — JD, your message (Excel half; Power BI is F5) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a skill, not a report. Answer slot: the JD says build reporting, so expect a probe on what you built. If you built any recurring report in Excel, say what it covered and who read it, in your own words; if you did not, say so plainly and say what you used Excel for |
| F5 | "build reporting in Excel/Power BI" — JD, your message (Power BI half; Excel is F4) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim of familiarity, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD, your message | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The seven years is operations; your quotes do not say how many of those years were spent over others. Years of experience is a requirement, not an eligibility gate, but expect it probed literally. Answer slot: say which years you spent over others and in what role, in your own words; if only the present role, say so plainly and say what it covers in the words you gave: senior shift manager over three supervisors |
| F7 | "Lean/Six Sigma a plus" — JD, your message | "green belt certified" — your message | medium | [grounded] | none | No gap: the certification reaches the requirement in role-relevant terms, and the certificate is the inspectable artifact that would raise it. Say it in those words and expect a probe on use (D2) |

### Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| Own daily terminal operations across 4 sites | A3, A4, B1, D3, E1 |
| Drive on-time performance and cost-per-shipment down | A1, A2, B3, C1, F1 |
| Lead a team of 12 supervisors | A3, B1, E2, F2 |
| Build reporting in Excel/Power BI | C2, C3, F3 |
| 5+ years operations leadership | B2, D1 |
| Lean/Six Sigma a plus | D2, F2 |

## Persona table

Weights are flat because the round type and interviewer are unknown. The loop is a generic pattern (screen, then hiring manager, then panel), not Atlas's documented process; no values-style round is assumed, so there is no values cheat sheet. Case and Skeptic carry the most questions because F1, F2 and F3 are where the JD presses hardest against your material.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems on on-time, cost per shipment, a first-30-days plan | 4 questions: the JD's three operating lines (F1, F2, F3) invite plans, and a plan needs no past claim | Clarify, objective, split the problem, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of scale, years of leadership, and the measures you have not tracked | 4 questions: F1 to F3 and F6 are the largest distances between the JD and your quotes | Rehearse B1 until boring; hold what your quotes carry; say the limit plainly before it is asked for |
| C. Data-Driven Prober | Line-by-line on the 40% and the reporting claims | 3 questions: you have one headline figure and two reporting lines (F2, F4, F5) | Know what you can and cannot say about how the 40% was counted; say plainly when you do not know |
| D. Conversational / Rapport | "Walk me through the journey", casual questions about Lean and your day | 3 questions: a friendly register is still scored and the biography arc is asked in every round pattern | A 90-second arc built only from what you have said (D1); treat casual questions on JD topics as scored |
| E. Peer Evaluator | Seams between sites, shared resources, credit | 3 questions: the JD has four sites, so cross-site friction is natural territory | Propose seam principles rather than pretending to know the seam; offer what you bring, not only what you need |
| F. Pressure | Time-boxed, devil's advocate, "how much was you" | 3 questions: the 40% and the Power BI gap both invite a push | Pause, restate, hold through two follow-ups, concede specifically |
| G. Values / Behavioral | Unpopular-truth and customer-first prompts | 2 questions: no published values were available, so these are generic scaffolds | Pick a real instance; if none comes to mind, say so plainly |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance has slipped at one of your four sites for three weeks running. What do you need to know first, and what do you do in the first week?" | CASE | [generic] | Say your structure aloud. Clarify first: which lanes and shifts, whether the slip is late departures or late arrivals, what changed three weeks ago, how on-time is defined. Then the objective, how you would split the problem, the first-week actions, and the one number you would watch daily. Challenge one premise respectfully, such as whether three weeks is a trend. A live problem, so the guidance makes no claim about your past | On-time performance is the JD's first named measure and F2 shows your material carries mis-picks, not on-time. CASE because it scores structure under a live problem, with JD content |
| A2 | "Cost per shipment is rising at one site while volume holds steady. How do you take it apart?" | CASE | [generic] | Ask how the number is built before decomposing it. Split it into the cost lines it contains and the volume it divides by, find which line moved, rank causes by how quickly each can be tested, and say which you would test first and what would change your mind. Say the structure aloud; claim no past analysis | Cost per shipment is the JD's second named measure and F2 does not reach it. CASE because the test is the reasoning, not a remembered answer |
| A3 | "You start Monday with four sites and twelve supervisors. What do your first thirty days look like?" | CASE | [generic] | A plan, not a past. Learn before changing: who you would meet at each site and in what order, what you would read first, what single page of numbers you would want each morning, and what you would deliberately not change yet. Say what you would ask the supervisors. Where it comes up, the honest scale line is F3's, in your own words: you are over three supervisors now | The JD's four sites and twelve supervisors (F1, F3) make this the most natural hiring-manager case. CASE because it is a plan on the real job, with JD content |
| A4 | "Two sites hit a surge in the same week and you have one flex crew. How do you decide who gets it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: what you need to know about each site's commitments, your criteria for deciding, how you tell the site that does not get the crew, and how you review the call afterwards. If asked whether you have done this, say it at the quote's scope: "I ran the site's peak-season surge plan two years running." Answer slot: the JD is four sites, so expect a probe on moving people or work between sites. If any part of your surge plan did that, say what; if none did, say so plainly and say it was one site's plan | F1 is your strongest operating evidence and the place the multi-site probe lands. CASE because the live problem comes first and the story is a fallback |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're a senior shift manager over three supervisors, and this role has twelve across four sites. Why isn't that too big a step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running"; "7 years in warehouse and distribution ops" | The highest-ROI prep in this pack. Hold with only what the quotes carry: "I'm a senior shift manager over three supervisors. I ran the site's peak-season surge plan two years running. I've spent seven years in warehouse and distribution ops." Concede specifically: twelve supervisors across four sites is a bigger scope than you have today. Then a plan, not a past: how you would learn the team before changing anything. Follow-up 1, "that's four times the team": return to the quotes, add nothing. Follow-up 2, "what would you get wrong in month one?": name the thing you would least expect to have right, in your own words, as a risk you would manage. Follow-up 3, "why take the risk?": say what the seven years and the surge plan show, and make no claim to be better than anyone | F3 and F1 are the two biggest distances between the JD and your quotes, so this objection will arrive in some form. JD because it scores the stated requirement; deepest rehearsal because every other probe on scale is a variant of it |
| B2 | "The role requires five years of operations leadership. How many of your seven years were in leadership?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: say which years you spent over others and in what role, in your own words. If only the present role, say so plainly and say what it covers in the words you gave: senior shift manager over three supervisors. Do not round up, and do not give a number of years you cannot back from your own record | F6 leaves the leadership years open, and the JD marks the requirement as required. JD because it scores a stated requirement |
| B3 | "This role is measured on on-time performance and cost per shipment. What have you tracked on those?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you tracked either measure, say which and what you saw, in your own words; if you tracked other measures alongside mis-picks, say which and what they did; if you tracked none, say so plainly and stay with the quote: "I cut mis-pick rate 40% by redesigning the pick path." Do not describe a measure you did not track | F2 is where the JD's two measures meet your one figure. JD because it scores the stated requirement; the guidance is a slot because no quote carries either measure |
| B4 | "Why leave a senior shift manager role for this one, and why Atlas?" | EXP | [generic] | Give your actual reason, in your own words; the pack has none from you. Shape it around what the scope of this role offers, not what you are leaving. For "why Atlas", build it from the posting and whatever you find yourself; this pack could not research the company, so it supplies no facts about Atlas | Motivation consistency is the Skeptic's standard question. EXP because it tests whether your account hangs together; the label is generic because nothing about your reasons or Atlas was available |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% on mis-picks was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Four slots, each in your own words: how the figure was counted, what it is most sensitive to, the assumption behind it you would defend least (name it before they do), and which part was yours. If you do not know how it was counted, say that plainly; it is a better answer than a method you cannot repeat. The pack supplies no baseline, period or method | F2's figure is your one headline number and the natural target. EXP because it tests whether the claim survives scrutiny |
| C2 | "What reporting have you built in Excel?" | JD | [inferred] "solid Excel" | Answer slot: if you built any recurring report, say what it covered and who read it, in your own words; if you did not, say so plainly and say what you used Excel for. Name no tool, formula or dashboard you did not use | F4 has a skill with no artifact behind it. JD because the requirement is to build reporting |
| C3 | "This role builds reporting in Power BI as well as Excel. Where are you with Power BI?" | JD | [grounded] "never used Power BI" | Say it plainly: "I haven't used Power BI." Then a plan, said as a plan: what you will do, and by when, to read and build reports in it; choose something you would actually do. Do not say Excel is the same thing, and do not say "familiar" | F5 is a stated gap and the probe is certain, so the answer is rehearsed to be short. JD because it scores a named tool |

### D. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc using the beats your quotes state: seven years in warehouse and distribution ops, currently a senior shift manager over three supervisors, the pick-path redesign, the surge plan two years running. Answer slot: the roles and moves in between, and their dates, are not in your quotes; say them in your own words or leave them out. Close with your own reason for this role | F1, F2, F3 and F6 supply the beats. EXP because the arc is scored for economy and consistency with the CV |
| D2 | "What are you actually doing with Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Say it as it is: "I'm green belt certified." Answer slot: if you apply the method now, say where and what for; if you hold the certification without a current use, say so plainly and say what the certification covered, in your own words | F7 is a clean match, so the probe will be on use. JD because the JD lists it; the casual register is the persona's |
| D3 | "What does a normal day look like for you now?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Describe the day in your own words; your quotes carry only the role and the number of supervisors. Say what you decide yourself and what is decided by others; if the split varies, say so | F3 is the only quote about the present role. EXP because it tests whether the day matches the title |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "With four sites in this role, where's the seam between sites, and what happens when two of them want the same resource?" | CASE | [generic] | Offer principles, not facts about the seam: one named owner for each decision, a rule for competing requests agreed in advance, one shared view of the numbers, and a quick route for escalation. Say you would learn the actual seam before proposing changes. Claim nothing about your past | F1's four sites make cross-site friction natural. CASE because it is a live problem with no history presupposed |
| E2 | "A peer at another site tells you your supervisors are ignoring a shared process. What do you do?" | CASE | [generic] | Ask for specifics first; check your own side before defending it; separate the process from the people; agree how you will both look at the same data. Show spine and tact together | F3's supervisors are the people in question. CASE because it tests disagreement style with an equal |
| E3 | "What could you do in your first month that would actually help the other sites?" | JD | [generic] | Reciprocity: say what you would offer, as intentions, not history: listening before proposing, sharing what you find, helping standardize how the sites are measured. Make no claim about what you have done for other sites | Peer interviewers price what the hire adds to their load. JD because it is the role's cross-site scope (F1) asked collegially |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That 40% on mis-picks: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Hold with the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which parts were yours and which were others', and who; if it was all yours, say so plainly. Hold through two follow-ups. Concede only what is true and specific, such as not knowing how the figure was counted | F2's figure is the one attribution target. EXP because it tests precision about what was yours |
| F2 | "Sixty seconds: why you over a candidate who has run twelve supervisors across four sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "green belt certified"; "currently a senior shift manager over 3 supervisors" | Keep to sixty seconds. Pause, then hold on your quotes: seven years in warehouse and distribution ops, the surge plan two years running, green belt certified. Concede the scale difference plainly: you are over three supervisors now. Do not claim to be better than the other candidate; say what you bring | F1 and F3 are where this comparison bites. JD because it scores fit against the stated scope; Pressure because of the clock |
| F3 | "You haven't used Power BI, and this role builds reporting in it. Why not hire someone who has?" | JD | [grounded] "never used Power BI"; "solid Excel" | Concede at once: "I haven't used Power BI." Hold what your quotes carry: "solid Excel", at that scope, and the plan from C3. Do not fold into claiming familiarity, and do not argue that the tool does not matter | F5 is the stated gap, and this is its pressure form. JD because it scores a named tool; the push is the persona's |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | None of your quotes carries this story, so pick one: it needs a named stake, a moment where the truth was said, and a result you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values prompt; no published Atlas values were available, so it is not mapped to one. VAL because it scores behavior |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a real instance with a named customer need, the metric it cost, and what you decided. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Customer-versus-metric tradeoffs are natural in freight operations. VAL because it scores behavior; generic because no company values were available |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How are on-time performance and cost per shipment measured today, and how consistent is that data across the four sites?" | Shows a measure-first approach to the JD's two named measures and tells you how much of F2 you would inherit |
| R2 | "What does reporting look like today: what lives in Excel, what in Power BI, and who maintains it?" | Surfaces the F5 gap as a ramp question instead of waiting for it to be probed |
| R3 | "Among the twelve supervisors, where is the biggest gap you would want closed first?" | Turns F3's scale question into a joint priority and shows you think about the team before the process |
| R4 | "What would a strong first ninety days look like?" | Echoes A3 and tells you how your plan compares with theirs |
| R5 | "How different are the four sites from each other, in the work and in the teams?" | Tests the multi-site assumption behind F1 and shows you do not assume the sites are alike |
| R6 | "What would you want to have seen from me by the end of the first month for the hire to look right?" | Asks for the interviewer's own bar, which lets you check B1's concession against it |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns terminal operations across four sites | Inflated form of F1 | F1's quote at its own scope: "I ran the site's peak-season surge plan two years running." The limit is the pack's observation: your material says one site's plan, not terminals and not four sites. A4's slot stays inside the surge plan |
| Drove on-time performance and cost per shipment down | Inflated form of F2 | F2's quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." B3's slot asks only what else was tracked alongside mis-picks |
| Leads a team of twelve supervisors | Inflated form of F3 | F3's quote at its own scope: "I'm a senior shift manager over three supervisors." The step up in scale is answered with a plan (A3, B1), never a past |
| Has seven years of operations leadership | Inflated form of F6 | F6's quotes at their own scope: seven years in warehouse and distribution ops, and a current role over three supervisors. B2's slot asks which years were spent over others |
| Built operational reporting in Excel | Inflated form of F4 | F4's quote at its own scope: "solid Excel." C2's slot asks what, if anything, was built |
| Has used Power BI, or is familiar with it | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't used Power BI." No slot; a plan only |
| Led Lean or Six Sigma improvement projects | Inflated form of F7 | F7's quote at its own scope: "I'm green belt certified." D2's slot asks only about current use |

## Sources

Provided documents: the job description lines and background in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Query | Result |
|---|---|
| Atlas Freight regional logistics company values | refused |
| Atlas Freight interview process operations manager | refused |
| Atlas Freight regional logistics news strategy | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | The search was refused. It would have fed a values cheat sheet if a values-style round had been detected; with none detected, it would still have named the values you could be quizzed on |
| 2. Atlas Freight interview process, operations manager | unavailable | The search was refused. It would have fixed the loop and the persona weights; the weights fall back to a generic pattern, flat, and the pack says so |
| 3. Atlas Freight strategy and recent news | unavailable | The search was refused. It would have supported CO questions and a grounding brief; none are in this pack |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative operations manager JD | skipped | The JD lines you supplied fix the fit snapshot and the JD questions |

## Upgrade menu

- The interviewer's name and title, and the round type (recruiter, hiring manager, peer, panel) → persona weights recomputed from flat, an interviewer read, and a reverse question tied to their path
- Recruiter guidance on what the round covers → coverage matched to their stated focus instead of the generic pattern; any pre-declared deliverable gets its own build section
- Permission to run web searches → Atlas's published values, loop and recent strategy: CO questions, and a values cheat sheet if a values round turns up. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can follow
- The full job description text beyond the lines you pasted → more requirement rows quoted from the source, and any requirement not yet covered gets a question
- Your answers to the answer slots in F1, F2, F3, F4 and F6 → those rows move from slots to quoted evidence and their bridges are rewritten
- Your green belt certificate and a before-and-after mis-pick report for the pick-path redesign → F7 and F2 can move from medium to high, since each is an inspectable artifact
- A tuesday-dossier.md from an earlier evidence review → verified evidence, a ready list of prohibited claims and the objection to rehearse most
