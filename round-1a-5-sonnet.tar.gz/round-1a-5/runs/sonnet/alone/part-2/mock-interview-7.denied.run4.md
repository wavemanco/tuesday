I'll read the skill's reference files before writing the pack.
Your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md` in the working directory. Search permission was declined, so nothing is researched about Saltmarsh Games or Tobias. The pack uses only your JD and your background, and the company-specific questions are labeled `[generic]`. I built it for a hiring-manager round, since your note didn't say who Tobias is to you.

The pack has 21 questions across six interviewer styles, each with answer guidance and a rationale, plus a fit snapshot, reverse questions and a list of claims it won't coach. The most important rehearsal is B1, which asks why you're ready to own calendars for two titles after running one title's calendar as an associate producer. Your own quotes only support the one calendar, so the pack says to hold at that scope and plan the first weeks aloud.

Say the word and I'll play the Skeptic on B1 for a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, or a skip-level or cross-functional interviewer, and has the recruiter given you any focus areas or a task to prepare? The answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: 60 minutes, Friday. Relationship assumed to be hiring manager; not confirmed. No company research ran (see Sources), so everything about Saltmarsh Games beyond your JD is absent rather than guessed.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your CV claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, reasoned aloud |

Provenance labels: `[grounded]` traces to your message or the JD, `[inferred]` is derived from an adjacent source, `[generic]` is a role-family pattern with no claim about you or Saltmarsh. An answer slot is an instruction for the interview, not a question for you now.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not events and not a second title. Words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events line makes a probe on the drops likely. If any drops were tied to a date or a limited run, say how you planned them; if they were all regular drops, say so plainly and stay with the weekly calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | low | [grounded] | discovery | This quote limits team leadership and is silent on coordination, which is what the JD asks. Plain acknowledgment: "I've never led a team." Answer slot: expect a probe on which of the four disciplines you worked with on a drop. If you worked with any, say which and what you did; if none, or it was someone else's job, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says presenting monthly retention numbers, not a post-event review and not owning KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you also produced or chose those numbers, or looked back at how particular drops performed, say what; if you presented figures others produced, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran releases against it with QA, say how; if QA ran it or releases did not go through you, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives the years and an associate-producer title, not whether the title was run as a live service. Words: "I've spent four years as an associate producer at a puzzle-game studio." Answer slot: if the title was run as a live service, say how in your own words; if it was not, or you are unsure, say so plainly and stay with the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you ran it, weekly, for the main title, over two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap on the quote, with nothing inspected behind it. Lead with what you presented and to whom. Your material does not say how those numbers were counted, so "I don't know how it was counted" is an honest branch if that is true |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | discovery | The quote shows a written checklist QA uses, not whether you wrote update plans or reviews. Answer slot: if you wrote any plan, update note or review, say which; if the checklist is your main written work, say so plainly and stay with it |
| F9 | familiarity with how in-app purchases relate to live events (a role-family expectation, not in the JD) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan in your own words and never as a past. Never a claim to monetization work |

Requirement coverage:

| Requirement | Covered by |
|---|---|
| Live-events calendar for two titles (F1) | A1, A3, B1, B4 |
| Coordinate design, art, engineering, community (F2) | A1, A4, B2, E2, F2 |
| Post-event review and KPIs (F3) | A2, B5, C1, C2, C3 |
| Release checklist with QA (F4) | A5, E1 |
| 3+ years live-service (F5) | B3, D1 |
| Content calendar (F6) | A3, B4 |
| Retention metrics (F7) | A2, C1, C2, C3 |
| Written communication (F8) | E3 |

## Persona table

Relationship is unconfirmed, so weights start from the hiring-manager prior (Case/Strategist plus Skeptic). No loop source was read, so the loop is not documented: the weights rest on a generic pattern, not on how Saltmarsh interviews. No values-style round is detected, so there is no values bank or cheat sheet.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (5 questions) | Live problems on calendar collisions and event reviews | High: the hiring-manager prior, and the JD is plan-and-run work | Clarify, objective, options, risks, thinking aloud; A1 and A2 need no claim about your past |
| Skeptic (5) | Quiet probing of scope, attribution and what you have not done | High: your message states two negatives, and the JD's two-title, four-team scope sits beside a one-title calendar | Rehearse B1 until it is boring; hold on your quotes and return to them, never add |
| Data-Driven Prober (3) | Asks how the retention numbers were counted | Medium: F7 is a message line and the JD names retention metrics | Say what you can and cannot say about how the numbers were counted; C1 |
| Conversational (3) | Opens with "walk me through the journey" | Medium: openers are near-universal, and casual answers are scored | A 90-second arc built only from your four quoted sentences; D1 |
| Peer Evaluator (3) | Seam questions between production, QA and the four disciplines | Medium: the JD names QA and four teams, though Tobias is not a peer on the prior | Offer seam principles, not a claimed seam; E1 to E3 |
| Pressure (2) | Time-boxed challenges to your fit | Low: no signal in the material | Hold through two follow-ups, then concede specifically; F1 and F2 |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles share one engineering team. A big event on title one collides with a release on title two. Walk me through what you do." | CASE | [generic] | Clarify first: what is fixed, what can move, what each slip costs. Then objective, options, who you consult (design, art, engineering, community, QA), the call, how you communicate it, and the risk you would watch. The question needs no claim about your past, so the guidance makes none | The JD's calendar and coordination lines (F1, F2) become a decision here; CASE because it scores structure, `[generic]` because the scenario is a pattern, not Saltmarsh's |
| A2 | "A post-event review shows retention for the event cohort came in under target. Diagnose it." | CASE | [generic] | Clarify: under which target, which cohort, compared with what. Segment, list hypotheses, name the data each needs, say what you would report. Name the assumption in your diagnosis you would defend least. No claim about your past | F3 and F7 are the JD's review and retention lines; CASE because it is a live diagnosis, and it gives you the weakest-assumption move on a problem rather than a figure |
| A3 | "You'd run calendars for two titles, not one. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start from what the quote carries: the weekly calendar, the main title, two years. Then reason aloud about what you would need to know first about the two titles and what they share. Answer slot: if any of your calendar work reached past the main title, say how, in your own words; if it did not, say so plainly and return to the main title's calendar | F1 and F6 are the evidence; JD because it scores the two-title line directly |
| A4 | "For each update, who do you need in the room and what do you need from each?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Answer as a method: for design, art, engineering and community, say what you need from each and when. If the leadership gap comes up, plain acknowledgment: "I've never led a team." Answer slot: if you worked with any of those disciplines on a drop, say which and what you did; if none, or it was someone else's job, say so plainly | F2 is the thin row; JD because it scores coordination, and the slot keeps the answer from claiming work your message does not show |
| A5 | "Tell me about the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Tell it at the quote's scope: you wrote it, and QA still uses it. Answer slot: the JD's manage-with-QA line makes a probe on how releases ran against it likely. If you ran releases against it with QA, say how; if QA ran it, or releases did not go through you, say so plainly and stay with the checklist you wrote | F4 is your clearest QA evidence and the likeliest place to be asked what was yours |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've been an associate producer, and the calendar you ran was for your studio's main title. This role owns the calendars for two titles. Why are you ready for that step?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: four years as an associate producer, and two years running the weekly calendar for the main title. Concede specifically: your material shows one calendar, not two. Answer slot: if any of your calendar work reached past the main title, say how, in your own words; if it did not, say so plainly and return to the main title's calendar. Then say how you would approach the first weeks, as a plan in your own words. Hold through two follow-ups by returning to the calendar, never by adding to it | F1 and F5 meet the JD's scope line here, and it is the most predictable objection to this candidate; JD because it scores the stated requirement |
| B2 | "Is there anything about running live events here that you haven't done before?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgments, only if they come up: "I've never led a team." "I've never worked on a game with in-app purchases." Pair each with a plan in your own words for how you would learn it, and no past work you did not do. Do not volunteer more gaps than you are asked about | F2 and F9 carry your stated negatives; JD because it scores honest self-assessment against the role |
| B3 | "The role asks for 3+ years producing live-service games. How do your four years map?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say the years and the title as the quotes give them. Answer slot: if the title was run as a live service, say how in your own words; if it was not, or you are unsure, say so plainly and stay with the weekly calendar | F5 is a discovery row: the years are stated, the live-service nature is not |
| B4 | "How much of that calendar was yours, and how much was decided for you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote: "I ran the weekly content-drop calendar for our main title." Answer slot: if you set what shipped and when for any drops, say which; if those calls were made by others, or there was no such step, say so plainly and return to the calendar you ran | F1 and F6; EXP because attribution probes target "ran" |
| B5 | "The post-event review and its KPIs are yours here. What have you owned in a review like that?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Hold at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you also produced or chose those numbers, or looked back at how particular drops performed, say what; if you presented figures others produced, say so plainly and stay with the presenting | F3 is where the JD's ownership wording presses hardest against the material |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented: which ones, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say which numbers and what you presented, in your own words. Answer slots, for each number you name: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch. Name no method or figure you cannot repeat under a second question | F7; EXP because the line is the likeliest to be probed to its assumptions |
| C2 | "Which retention measures would you want on a post-event review, and why?" | JD | [generic] | Pick the measures you would use and say why, then name the assumption you would defend least. The question needs no claim about your past, so the guidance makes none | F3 and F7 requirement, asked as a choice |
| C3 | "An event's retention lifted. How would you tell whether the event caused it?" | CASE | [generic] | Clarify the comparison first, list what else changed, say what evidence would separate them and what you would still not be sure of. No claim about your past | F7; CASE because it scores reasoning about a metric, not recall |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc using only those four sentences: four years as an associate producer; the weekly calendar for the main title over two years; the checklist QA still uses; the monthly retention numbers presented to the studio head. Close with your own reason for this role | F4 to F7 are the beats; EXP because it is the biography question and it is scored |
| D2 | "Why live operations, and why mobile?" | JD | [generic] | Give your own reason in your own words. The guidance supplies none, because the reason must be yours | Motivation consistency is scored in casual registers |
| D3 | "What are you playing in mobile live service these days?" | CO | [generic] | Name a title you actually play and one event you noticed in it, and what you would note about how it was run. If you do not play any, say so plainly and name what you would study first | A casual question on the JD's own subject; CO at the level a candidate can reach without research |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "When QA and the production calendar pull in different directions, how do you handle it?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Offer principles for the seam, not a claimed seam: what you would raise early, who decides, how you record it. Answer slot: if you disagreed with QA on a release, say what happened and your part; if there was no such time, say so plainly and stay with the checklist you wrote | F4; the JD's QA line, asked as a seam question |
| E2 | "How do you handle credit when an update spans design, art, engineering and community?" | JD | [generic] | Pick a time credit was shared across teams and say how it was handled; it needs a named stake and a clear part of yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2's four-team line; no sentence of yours carries a story here, so it is a scaffold |
| E3 | "A major event's plan has to go to design, art, engineering and community in writing. What does that note contain?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Structure it as a method: what is happening, when, who needs to do what, what is still open. Answer slot: if you wrote any plan, update note or review, say which; if the checklist is your main written work, say so plainly and stay with it | F8, the JD's written-communication line |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has run live events on a monetized mobile game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Hold on the three quoted sentences, in your own words. Concede specifically: "I've never worked on a game with in-app purchases." Do not fold on the core claim to restore harmony, and do not add experience to it | F6, F4, F7 and F9; JD because it scores fit against a stronger rival |
| F2 | "You've never led a team. Why should four disciplines follow your calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Concede first: "I've never led a team." Then hold: the JD says coordinate, which is a different ask. Answer slot: if you worked with any of those disciplines on a drop, say which and what you did; if none, say so plainly | F2; pressure form of A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good first 90 days look like for this producer across the two titles?" | Turns the scope objection into a joint plan |
| 2 | "How does monetization figure in the live-events calendar, and what would you want a new producer to learn first?" | Raises the in-app purchase gap yourself, as a learning question |
| 3 | "Which KPIs does the post-event review report today, and who reads it?" | Shows you think about the review as a deliverable |
| 4 | "Where do design, art, engineering and community most often disagree about an update, and how is that resolved today?" | Shows you expect the coordination to be the hard part |
| 5 | "How do the two titles share engineering and QA capacity when events overlap?" | Mirrors the A1 collision, with the real answer |
| 6 | "What separates a producer who is thriving here at six months from one who is struggling?" | Asks for the bar |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says one title's weekly calendar. Slots stay inside that calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: presenting the monthly retention numbers |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope: wrote the checklist QA still uses |
| Four years as a producer on a live-service game | Inflated form of F5 | F5's quotes at their own scope: associate producer; whether it was live service is a slot |
| Led a team | Negative you stated, F2 | "I've never led a team." No slot |
| Worked on in-app purchases or monetization | Negative you stated, F9 | "I've never worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the JD text and your background, both in your message. No dossier.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The search was refused. Would have moved: a values cheat sheet if a values round was documented; nothing used |
| 2. `Saltmarsh Games interview process Live Operations Producer` | unavailable | The search was refused. Would have moved: loop structure and persona weights; weights rest on the hiring-manager prior |
| 3. `Saltmarsh Games mobile studio news strategy` | unavailable | The search was refused. Would have moved: CO and CASE grounding in current strategy; those questions are `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The search was refused. Would have moved: the interviewer read and a tailored reverse question; absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent: `Saltmarsh Games company values` (refused); `Saltmarsh Games interview process Live Operations Producer` (refused); `Saltmarsh Games mobile studio news strategy` (refused); `Tobias Wrenfield Saltmarsh Games` (refused).

## Upgrade menu

- Search access, or pasted material from the company's careers page, values page or recent news → company-specific CO and CASE questions, and a values cheat sheet if a values round is documented; today they are `[generic]`
- Tobias's public profile, talks or writing → an interviewer read, persona weights adjusted to him, and a reverse question tied to his own path
- The recruiter's prep email → focus areas and any pre-declared deliverable, with a build section for each
- A content-calendar export, your release checklist and a retention deck from your studio (the artifacts this field keeps) → F1, F4 and F7 could move from `medium` toward `high`
- Your own words on the answer slots in F1, F2, F3, F4, F5 and F8 → those rows and the questions that draw on them regenerate from what you say
- How many hours you have before Friday → a prep triage ordered to your time
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes, offered once → a strategy brief for the CO bank, if search access is granted
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and any claims already ruled out, used in place of this pack's local list
