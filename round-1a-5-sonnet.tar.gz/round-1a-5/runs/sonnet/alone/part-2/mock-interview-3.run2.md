I'll start by reading the skill's reference files.
Reading is done. I'm running the default research pass on Stripe now: values, interview process, strategy and a representative job description.
Web search was refused, so the pack is built without Stripe research. I'm writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-3-denied-d92890a6/stripe_product-operations-manager_interview_pack.md`. It holds 22 questions across seven interviewer styles, 6 questions for you to ask them, a coverage table, and an upgrade menu.

I built it from your message alone, for a final round whose format I don't know. Web search was refused, so the pack has no Stripe-specific facts: no values, loop structure or strategy. It also has no values cheat sheet, and the company questions are generic. You gave me no job description or CV, so the "fit snapshot" is a worksheet. Every answer that needs a story is a prompt for you to fill from your own history. The pack supplies no projects, numbers or outcomes for you.

The question to rehearse most is B1, "Which part of this role would you be weakest at on day one." I picked it because it's the most likely probe in a final round. It will sharpen once I see your CV.

Say the word and I'll play the interviewer on B1 or any Case question. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word.

Who are you meeting in this round, and did the recruiter name a focus area or a deliverable such as a case or presentation? The answer reweights the whole pack.

Can you paste the job description and your CV? I'll rebuild the pack around them, or I can keep going without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — final-round interview pack

Candidate-side prep. Built from your message alone: company, role, and "final round". No JD, CV, interviewer name or recruiter guidance was supplied, and web research was unavailable (see Sources). Everything company-specific is therefore absent, and everything about you is a scaffold to fill from your own material, never a script.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Every question carries both: the persona by bank, the type by tag.
- Guidance is scaffolding, not a script. Where the guidance says "pick a time", the story must come from your own history, in your own words. Nothing here supplies a project, number or outcome for you.
- Practice out loud. Each guidance cell is meant to be speakable in 90 to 120 seconds.

Type key:

| Tag | Name | What it is testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny; what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role, live |

## Fit snapshot (worksheet variant)

No JD and no background were supplied, so this is a worksheet. The requirements are role-family patterns written in plain prose, not quotes from a Stripe posting. Fill the evidence column yourself from your CV, then send it back and these rows regenerate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launches or programs across product, engineering and go-to-market teams — typical of the role family | none given | none | [generic] | discovery | Strong evidence is one named launch or program, the teams involved, and what was yours to decide, stated in your own words. Selection scaffold: pick one coordinated effort with a named stake and an outcome you can state; if no such effort comes to mind, say so plainly, then give the nearest work your material does carry, or how you would approach it |
| F2 | Designing and running operating rhythms and processes for product teams — typical of the role family | none given | none | [generic] | discovery | Strong evidence is a process or cadence you set up or changed, who used it, and how you knew it helped. Selection scaffold: pick one process you built or changed, not only ran; if there was none, say so plainly and say what you would build first |
| F3 | Using data and metrics to track product health and inform decisions — typical of the role family | none given | none | [generic] | discovery | Strong evidence is a metric you tracked, how it was counted, and a decision it changed. Selection scaffold: pick a metric you can explain end to end, including the assumption you would defend least; if none, say so plainly and say how you would set one up |
| F4 | Influencing without authority and resolving disagreement between stakeholders — typical of the role family | none given | none | [generic] | discovery | Strong evidence is a disagreement between teams, your actual part in it, and how the relationship ended up. Selection scaffold: pick one where you did not hold the decision; if none comes to mind, say so plainly and describe how you would handle it |
| F5 | Prioritizing and structuring work under ambiguity — typical of the role family | none given | none | [generic] | discovery | Strong evidence is a vague brief you turned into a plan, with the choices you made and dropped. Selection scaffold: pick one where you had to decide what not to do; if none, say so plainly and describe your approach |
| F6 | Clear written and verbal communication to leadership — typical of the role family | none given | none | [generic] | discovery | Strong evidence is a document or readout aimed at senior people and what happened after it. Selection scaffold: pick one you can describe concretely; if none, say so plainly and say how you would structure one |
| F7 | Whether the role manages people or is an individual-contributor role at manager level — unknown without the JD | none given | none | [generic] | discovery | The material does not establish whether there are direct reports. If you have led people, strong evidence is team size and what you were accountable for, in your own words; if you have not, say so plainly and stay with the coordination work F1 and F4 ask for |

## Persona table

These weights rest on a generic pattern (screen, hiring manager, panel), not on Stripe's documented final round. Your note says "final round" only: it does not say how many sessions it holds or who runs them, so the weights are blended across every plausible interviewer. Recalibrate if you know more.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problem from the role: plan a launch, diagnose a metric | Highest. A hiring-manager or skip-level session in a final round tends to test structure on the role's real problems; this is the relationship prior | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| Skeptic | Quiet probing of why product operations, why this company, where you are weakest | High. Every final round de-risks gaps, and with no CV the sharpest gap is not yet known | Rehearse the single most predictable objection until it is boring (B1) |
| Values / Behavioral | Scenario probes, STAR-shaped stories | Medium. Likely somewhere in the loop; not confirmed for this session, and Stripe's published values were not researched | Pick stories from your own history that show a specific decision, not generic virtue |
| Peer Evaluator | Seam between product operations and product management; collaboration | Medium. A product-operations hire is judged by the product and engineering peers who work beside it | Offer seam principles, reciprocity, a disagreement story with spine and tact |
| Conversational | Biography, motivation, "what are you following" | Medium. Casual questions in a final round are still scored | A 90-second arc; treat every casual question as scored |
| Data-Driven Prober | Metric-by-metric deep dives | Lower. Depends on the interviewer; unknown | Know how any number you cite was counted; name the weakest assumption first |
| Pressure | Time-boxed, devil's-advocate | Lower. More likely in a skip-level or executive session, and the sessions are unknown | Pause, restate, hold through two follow-ups, then concede only what is true |

## Question banks

Provenance is `[generic]` throughout: with no CV, no question rests on a sentence of yours. Every answer that needs a story is a selection scaffold ending in the honest branch.

### Bank A — Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two product teams are about to launch related features in the same month with no shared plan. What do you need to know first, and how would you structure the launch process?" | CASE | [generic] | Clarify before structuring: goals of each launch, dependencies, dates that cannot move, who decides trade-offs. Then objective, the few decisions that need a single owner, a lightweight check-in rhythm, and how you would tell it is working. Challenge one premise, such as whether the two launches need joint planning at all | A live coordination problem is the core of the role family (F1, F5). CASE because it scores structure, not recall |
| A2 | "An adoption metric for a recently launched product dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Rule out measurement first (definition, instrumentation, data delay), then segment (cohort, region, channel, platform), then compare against launches or changes in the same window, then name which cheap check you would run first. Say what you do not know yet | Persona stem for the Case persona; tests F3 reasoning without any claim about your past |
| A3 | "Design an operating cadence for about ten product teams. What do you build first, and what do you refuse to build" | CASE | [generic] | Start with the problem the cadence solves, then the smallest rhythm that solves it, then the anti-pick: the thing you would not add because it is process for its own sake. Say how you would retire it if it stopped helping | F2 plus the role's real job of saying no; the anti-pick separates judgment from process enthusiasm |
| A4 | "Product managers tell you your process slows them down. What do you do" | CASE | [generic] | Treat it as data: ask which step, for whom, with what cost. Separate real friction from habit, offer to remove or automate before defending, and hold the part that protects something. Name how you would check the change helped | F4 and F2 together; the likely collegial pushback on this role |
| A5 | "How would you tell whether a product operations function is working" | CASE | [generic] | Name two or three outcomes tied to what product teams need (speed, predictability, quality of decisions), a leading and a lagging signal for each, and the weakest assumption in your own measure. Say what you would stop doing if the signal did not move | F3 at function level; also the question a hiring manager asks to see whether you can define your own scorecard |

### Bank B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one" | JD | [generic] | The highest-ROI prep in this pack. This is inferred from a persona stem because no CV or JD exists to show your real gap; once you send them, B1 is rewritten around the thinnest row. For now: name one real gap from F1 to F7 that you know is yours, say it in one plain sentence, then give a concrete ramp plan (what you would learn, from whom, in the first 30 days). If no gap comes to mind, say so plainly, then name the area where you have least inspected evidence | A final round de-risks gaps, so this is asked in some form; a calm, specific answer changes the interview. JD because it scores the role's requirements, Skeptic because of how it is asked |
| B2 | "Why product operations rather than product management, and why now" | EXP | [generic] | Give your own reason in your own words, consistent with the path you describe in F1. Cover what draws you to the operating side and what you would miss about the product side. Do not claim a motive you do not hold | Motivation consistency is what the Skeptic scores; a mismatch with your CV is the common failure |
| B3 | "Why this company, and why are you looking now" | EXP | [generic] | One sentence on why Stripe, drawn only from what you have actually read; if you have read nothing recent, say so and say what you would look at first. One sentence on why now, kept truthful and forward-looking rather than critical of an employer | Stem for the Skeptic; also a CO check. Company-specific content is missing from this pack because research was unavailable |
| B4 | "Product operations can look like overhead. What would convince me you create leverage rather than process" | JD | [generic] | Pick one example of removing work or a decision delay, in your own words, with how you knew. If no such example comes to mind, say so plainly, then describe the first leverage you would look for and how you would check it | Names the role family's central objection (F2); the honest branch matters because a stretched example fails the second follow-up |

### Bank C — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership" | VAL | [generic] | Pick a time where the truth landed, with a named stake, what you said and what changed. Use "we" for context and "I" only for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for this bank; F6 and F4. Stripe's published values were not researched, so no value is mapped |
| C2 | "When did you put a customer ahead of an internal metric" | VAL | [generic] | Pick a decision with a visible trade-off: what the metric wanted, what the customer needed, what you chose and the cost. If none comes to mind, say so plainly, then say how you would weigh such a choice | Persona stem; likely to arrive in some form at a company that talks about users |
| C3 | "Tell me about a time you held a position under pressure from someone senior" | VAL | [generic] | Pick one where you did not fold on the core point, with the stake, the moment, and an intact relationship afterwards. Concede only what was true. If none comes to mind, say so plainly, then give the nearest example or describe how you would handle it | F4; also rehearses the hold-then-concede shape ahead of Bank G |

### Bank D — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree" | JD | [generic] | Offer seam principles instead of claiming to know the seam: who owns the decision, who owns the process that supports it, how disagreements escalate. Say what you would ask them about their current seam. Then name how you disagree: with data, early, and in private first | Persona stem; F4. Proposes principles because you cannot know the seam yet |
| D2 | "How do you handle credit when work spans teams" | VAL | [generic] | Pick one cross-team piece of work; say plainly what part was yours and what was others', and how the credit was shared. If none comes to mind, say so plainly and describe your practice | Persona stem; attribution honesty is the scoring target (F1, F4) |
| D3 | "What would you need from me in your first month" | JD | [generic] | Reciprocity: say what you would ask, then what you would bring back to their team (clarity on dependencies, fewer surprises, a single view of launches). Keep the offers to things the role can actually deliver | A peer prices what the hire costs and gives their team; this is the reciprocity probe |

### Bank E — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a metric you have been responsible for, and walk me through how it was counted" | EXP | [generic] | Pick a metric you can explain end to end. Say how it was counted, what it is sensitive to, the assumption you would defend least, and exactly which part was yours. If you do not know how a figure was counted, say so plainly rather than guessing | Defend-the-number rehearsal (F3); no figure from you exists yet, so this is the open form. When you send your CV, one such question per headline number is added |
| E2 | "How would you set up the data behind a launch-readiness or adoption metric so that it survives challenge" | CASE | [generic] | State the decision the metric supports, the definition and its edge cases, the source of truth, who owns it, and how you would show its limits. Name the weakest assumption in your own design | Tests whether you can design a number as well as defend one (F3) |

### Bank F — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey" | EXP | [generic] | A 90-second arc in three beats: where you are now, the thread through what you did before, why this role. Each beat uses facts from your own CV and nothing else. Practise it until it fits in 90 seconds | The opener in a casual register is still scored for economy and interest (F6) |
| F2 | "What drew you to product operations as a craft" | EXP | [generic] | One true reason, one example of the work you enjoy in your own words. If the honest answer is "it found me", say so, then say what you stayed for | Motivation check in a friendly register; links to B2 |
| F3 | "What have you been following about Stripe lately" | CO | [generic] | Name only what you have actually read or used. If you have followed nothing recent, say so plainly and say what you would look at first and why. Do not recite a headline you cannot discuss | No Stripe facts are in this pack because research was unavailable; see the upgrade menu |

### Bank G — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate" | JD | [generic] | Pause, restate, then one claim about fit drawn from your own evidence for F1 to F5, one reason you want this role, and stop. Do not disparage the alternative | Persona stem; scores composure and economy |
| G2 | "Think of the accomplishment you are proudest of. How much of it was actually you" | EXP | [generic] | Hold, then concede. Say plainly what was yours, what was a team's and what was luck; do not fold on the core claim when pushed twice, and do not inflate when pushed a third time. If you cannot separate your part, say so | Attribution honesty is the most reliable probe in a final round |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Cross-functional launches | A1, D1, D2 |
| F2 Operating rhythms and process | A3, A4, B4 |
| F3 Data and metrics | A2, A5, E1, E2 |
| F4 Influencing and disagreement | A4, C1, C3, D1, D2 |
| F5 Prioritizing under ambiguity | A1, A3, B1, G1 |
| F6 Communication to leadership | C1, F1 |
| F7 People leadership | — none, and why: whether the role has direct reports is unknown without the JD; B1 covers it if you tell me |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does success look like in this role at six months and at twelve" | Shows you scope the role by outcomes, and the answer tells you what you will actually be measured on |
| R2 | "Where does product operations stop and product management start here, and where has that line been hardest to hold" | Takes the seam from D1 to the person who lives with it; shows you plan to work inside it, not around it |
| R3 | "Which launches or processes are most in need of attention right now" | Signals you think in problems, not titles, and gives you a first-30-days plan |
| R4 | "What separates people who do well in the first six months from those who struggle" | Candid about your own risk; the answer is the hiring bar in the interviewer's words |
| R5 | "What is the trade-off the team is working through that you would most like another view on" | Invites a peer conversation instead of a closing formality; rapport-style interviewers weight this slot heavily |
| R6 | "How does the team decide when to build a process and when to leave something informal" | Tests whether the function guards against overhead (B4) and shows you share the worry |

## Prohibited claims

Built locally. With no CV, nothing is quoted, so this list names the claims candidates reach for under pressure that this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Any specific past project, figure, tool, team size or outcome | No background was supplied, so no sentence of yours is quoted and every story is a scaffold | Pick the story from your own material and tell it in your own words; the answer slots allow that the practice never existed |
| Familiarity with Stripe's published values, loop or strategy | Research was refused, so this pack holds no source for any of it | Say only what you have actually read; if nothing, say so and say what you would look at first |

## Sources

Provided documents: your message (company, role, "final round").

Searches sent, all refused:

- "Stripe operating principles values" — refused
- "Stripe interview process product operations manager" — refused
- "Stripe strategy news 2026" — refused
- "Stripe Product Operations Manager job description responsibilities qualifications" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have fed a values cheat sheet and VAL mapping; the VAL bank uses persona stems instead |
| 2. `Stripe interview process product operations` | unavailable | Would have named the real rounds and set persona weights; weights rest on the generic pattern, said plainly above |
| 3. `Stripe strategy` / recent news | unavailable | Would have fed company-grounded CO and CASE questions; those are generic here |
| 4. `{interviewer name} Stripe` | n/a | No name was given |
| 5. representative `Product Operations Manager` JD | unavailable | Would have turned the fit-snapshot requirements into quoted `[inferred]` rows and anchored the JD-tagged questions |

## Upgrade menu

- Search permission → Stripe's published values, loop structure and recent strategy: a values cheat sheet, company-grounded CO and CASE questions and persona weights from the documented loop. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once, on your say-so
- The JD text → the seven `[generic]` requirement rows become quoted `[grounded]` rows, and the JD-tagged questions are written against the real list
- Your CV → the worksheet becomes a fit snapshot with your own sentences quoted, B1 is rewritten around your actual thinnest area, and story scaffolds become story maps
- Who you are meeting and the order of the sessions → persona weights reweighted, and, if the final is several sessions, a mini-pack per session
- The recruiter's prep note, including any announced case, presentation or take-home → a build section for each declared deliverable; usually one email
- A tuesday-dossier.md from job-underwriter, if you have one → an evidence-based top objection and claim guardrails in place of the inferred ones
