I'll read the reference files the skill requires before writing anything.
Your prep pack for Priya's conversation with Dan is saved. It has 20 questions across six personas, a fit snapshot, an interviewer read, six reverse questions and a list of claims the pack won't coach.

I built it for a peer conversation, weighted toward the Peer Evaluator and Data-Driven Prober because Dan calls himself "relentlessly data-driven". I used the JD highlights and your candidate summary, not full texts.

The web searches I tried (Northwind values, interview process, Dan's footprint) were refused, so none of that is researched. The Northwind facts in the pack come only from your research note. The values and loop searches would have added value names and loop documentation, and the Dan search his public talks and writing. The pack's research accounting says which rows each would have moved.

- **Highest-ROI prep:** C1, "You're from consumer product strategy and ops. What do you bring to B2B GTM that a sales-strategy hire wouldn't?" It aims at the missing sales-ops and quota-setting experience.
- **Second priority:** B1, defending the ~$400M ARR figure. The guidance keeps it at "proposed" and "credited with" and doesn't coach "drove" or "owned".

Say the word and I'll play Dan on C1, with follow-ups that react to what Priya says.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Did the recruiter say anything about what the conversation will focus on, or ask Priya to prepare something? That would reweight the banks or add a build section.
2. Can you paste the full JD and Priya's CV text? Without them the pack stands on your summary, and the rows marked medium confidence can't move up.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

Files are in /var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-1-denied-9859bd55:
- northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind Data. He would be Priya's peer, both reporting to the same VP.
**Round:** one 60-minute conversation with Dan.
**Built on this assumption:** the JD highlights and the candidate summary you sent, not full texts. Web research was attempted and refused (see Sources), so company values, loop documentation and Dan's public footprint are not researched. Everything about Northwind comes from your research note.

## How to use this pack

- **Personas describe how a question arrives; types describe what is being scored.** Rehearse both.
- **Guidance is scaffolding, not a script.** Say it in your own words. Where a cell says "answer slot", it points at something the material does not show: answer from your real experience or say plainly that it was not yours.
- Everything about Priya's past rests on a sentence quoted from your notes. Where no sentence carries a story, the cell gives selection criteria instead.

| Type | What it scores |
|---|---|
| VAL | Past behavior against the company's published values. None in this pack: no values page was read and no values-style round is documented |
| EXP | Whether the CV's claims survive scrutiny; what was actually hers |
| JD | Whether she can do the listed job, gaps included |
| CO | Company and strategy knowledge, thinking at Northwind's altitude |
| CASE | A live problem from the actual role: structure and reasoning |

## Fit snapshot

JD lines are quoted from the "JD highlights" in your message. Candidate evidence is quoted from your notes on Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material says product strategy and ops at a consumer-tech company; it does not show a go-to-market or a new-product launch. The words stay at that scope. Answer slot: the JD's new-product-lines line makes a probe on launches likely. If any of that work took a new product or feature to market, say which and what part was yours, in your own words; if none did, or the go-to-market was someone else's, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | The sentence touches growth but does not show which stage of the customer lifecycle it sat in. Words at scope: the change was proposed, and the uplift was credited to it. Answer slot: expect a probe on which of land, adopt, expand or renew the change affected. If you can place it, say where, in your own words; if it does not map to those stages, say so plainly and stay with the sentence. The figure raises four slots: how it was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The quote already names both tools, so lead in its terms: skilled in SQL/Tableau. Nothing is inspected behind it, so expect a probe on "independent". Answer slot: if there is an analysis you ran yourself with these tools, offer to walk through it end to end; if the work was done with others' pipelines or by others, say so plainly |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The sentence carries a revenue model used in negotiations, not the design of a partner motion. The words stay with the model. Answer slot: the JD requires partner-motion design, so expect a probe on whether you designed one. If any part of that work was yours to decide, say which and how you decided; if none was, or it was someone else's, say so plainly and stay with the revenue model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Lead with it as written: annual volume targets, set with cross-org consensus. Expect a probe on which part was yours, answered in your own words and at the sentence's scope |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | Use, stated at its own scope. Nothing in the material says she built or shipped an AI product, and the words never go there |
| F7 | Sales-ops and quota-setting fluency (plain prose, not in the JD highlights; it matters because the interviewer leads sales strategy) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the notes say so. Words, from that stated negative: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |

## Reading the interviewer

Built only from the profile summary you gave me. His public footprint was not researched.

| Signal | What it implies for the conversation | Provenance |
|---|---|---|
| Profile self-describes as "relentlessly data-driven" | Expect every number to be taken two levels deep: how it was counted and what it assumes. Bank B carries this | [grounded] |
| Career spine in pricing and monetization roles | Case questions tilt to pricing, packaging and discount guardrails (A5, D2). His native language is how revenue gets captured | [grounded] |
| One early-stage-startup chapter | A single chapter, so a light prior only: he may probe pace and how much you build versus coordinate. Do not coach startup-flavored stories you do not have | [inferred] |
| Mirror opportunity, shared vocabulary | His path is pricing and monetization; the F4 sentence is "built a partner-level revenue model used in carrier negotiations". Use revenue-model language in her own sentence's terms, and let him connect the rest | [grounded] |

## Persona table

Relationship prior for a peer is Peer Evaluator plus Data-Driven Prober. His "data-driven" self-description pushes the Prober up, and his pricing spine tilts the Case bank. The loop is established by your own words (one 60-minute session with Dan), and no values-style round is documented.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Peer Evaluator | Seam-splitting, "what would you need from me", credit and disagreement probes | High: a peer reporting to the same VP is pricing what the hire costs and contributes to his own work | Reciprocity framing; propose seam principles, not a map of a seam you have not seen | A, 5 questions |
| Data-Driven Prober | Reads claims line by line; asks how numbers were counted and what they assume | High: self-described "relentlessly data-driven", and F2 carries a headline figure | Say what you know and do not know about how each number was counted; name the weakest assumption before he does | B, 5 questions |
| Skeptic | Quiet, persistent probing of the sales-ops, B2B and partner-motion gaps | Medium: F7 is a stated gap, F1 and F4 are transferability rows, and a sales-strategy director owns that ground | Rehearse the C1 objection until it is boring; hold what the quotes carry, concede the rest specifically | C, 3 questions |
| Case / Strategist | Live problems on the role: plan the first 90 days, whitespace sizing, the bundling threat | Medium: he is a peer rather than the hiring manager, but the role is strategy and his spine tilts it to pricing and packaging | Clarify, objective, segmentation, approach, metrics, risks; say the framework aloud and state a hypothesis early | D, 3 questions |
| Conversational | Opening "walk me through the journey"; casual AI question | Low-medium: a 60-minute peer conversation almost always opens this way, but it is brief | A 90-second arc; treat the casual AI question as scored | E, 2 questions |
| Pressure | Time-boxed, interrupting challenge | Low: a peer is less likely than a skip-level, but a time-boxed thesis question is cheap to rehearse | Pause, restate, hold through two follow-ups, concede specifically | F, 2 questions |

**Highest-ROI prep: C1.** It is aimed at the thinnest part of the material (consumer product strategy and no sales-ops or quota-setting experience, against a B2B GTM role), and it will arrive in some form. Second priority is B1, the defend-the-number rehearsal on the ~$400M figure.

## Question banks

### Requirement coverage

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | D1, D2, C1 |
| identify whitespace across land/adopt/expand/renew | D3, B4 |
| run independent analysis in SQL and Tableau | B5, B3, A3 |
| partner-motion design experience required | C3, B3 |
| strong cross-functional influence | A1, A2, A4, A5 |
| AI experience a plus | E2, D3 |
| Sales-ops and quota-setting fluency (not in the JD highlights) | C1, C2, F1 |
| Published values (VAL) | none, because no values page was read and no values-style round is documented |

### A. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between your remit and mine, and what happens when we disagree?" | JD | [generic] | No claim about your past is needed. Ask first what his team owns today. Then offer principles rather than a map: one named owner per decision, shared definitions for any number you both use, and evidence first when you disagree, with your shared VP as the escalation only if evidence does not settle it. Concede you do not yet know where the seam sits | The role's cross-functional line (F5) is tested hardest by a peer who shares your VP. JD because it scores the stated requirement; the peer persona sets the delivery |
| A2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5 at the sentence's own scope: annual volume targets, set with cross-org consensus. Use "we" for the context and "I" only for what was yours. Answer slot: expect a follow-up on which part was yours. Say which, in your own words; if the consensus was reached by others or the targets were set for you, say so plainly and stay with the sentence | A peer's credit probe is the collegial form of "how much of that was you". EXP because it tests attribution honesty |
| A3 | "What would you need from me in your first month, and what could you bring my team?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity first: what you can offer, then what you need. On the offer, stay at the sentence's scope: skilled in SQL/Tableau. Answer slot: if there is an analysis you ran yourself that his team could use, name it; if not, say what you would look at first. On needs, ask for definitions and data access rather than for his time | The reciprocity question the peer round exists to ask; F3 is the only row that gives a concrete thing to offer. JD because it scores the analysis requirement |
| A4 | "Tell me about a time you disagreed with a peer team over a number or a plan." | EXP | [generic] nearest sentence: "set annual volume targets with cross-org consensus" | Selection criteria: pick a time with a named stake, a position you held with tact, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (your sentence on cross-org consensus, at its own scope) or how you would handle a disagreement like this | The peer persona's disagreement probe. F5 is the nearest row but does not show a disagreement, so the cell is a scaffold rather than a story map |
| A5 | "Suppose I own the discount guardrails and you own the launch plan for a new product line. A sales leader wants to discount to win the first logos, and your plan assumes list price. How do we resolve it?" | CASE | [generic] | Clarify first: what the guardrails currently allow, and what the plan needs the first logos for. Then structure: the goal of the first deals, what discount buys against what it costs later in expand and renew, and a shared rule such as capped discounts in return for reference or design-partner terms. Name your weakest assumption. Make no claim about your past | A live seam problem in his native pricing territory. CASE because it is a decision, not a record; the peer persona sets the register |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The ~$400M ARR figure on your CV. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The required rehearsal. Say it at the sentence's own verb and scope: you proposed the change, and the uplift was credited to it. Answer slots, each in your own words: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly and say what you do know. Never say you drove, delivered or owned the uplift | F2 is the headline metric and a self-described data-driven interviewer will go to it. EXP because it tests whether the number survives scrutiny |
| B2 | "Which part of that was actually yours, and which was the team's?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold on what the sentence carries: you proposed it. Answer slot: what happened between the proposal and the credited result, and which of it was yours, in your own words. If you proposed it and others built, launched or measured it, say so plainly; that is the honest branch and it costs nothing | The attribution follow-up that comes right after B1. EXP, same row as B1 (F2); kept separate so the two levels are rehearsed apart |
| B3 | "Tell me about the revenue model you built for carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: the model, built at the partner level, used in carrier negotiations; those are the beats the sentence states. Answer slot: the JD asks for independent analysis and partner-motion design, so expect probes on how it was built and which tools. If you built it yourself, say how, in your own words, and offer to walk through it end to end; if others built parts or supplied inputs, say so plainly | F4 is the only row near the partner-motion requirement and F3's independent-analysis line; both get probed through it. EXP because it tests what was built and by whom, with a JD tie |
| B4 | "For a new product line, which numbers would you watch across land, adopt, expand and renew in the first two quarters, and which would you trust least?" | CASE | [generic] | One metric per stage, chosen after asking how Northwind defines each stage today. Then the weakest-assumption move: name the metric most open to being gamed or distorted and say why. Say what you would pull from the data yourself and what you would ask for. No claim about your past | The JD's lifecycle line (F2) made into a live question for a data-driven peer. CASE because it asks for structure on a role problem, with the metric probe as the scoring angle |
| B5 | "Tell me about an analysis you ran independently in SQL or Tableau, from the raw data to a decision." | JD | [grounded] "skilled in SQL/Tableau" | Selection criteria: pick an analysis you ran start to finish yourself, with the question it answered, the data it came from, what you did and what decision followed. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries (skilled in SQL/Tableau, at that scope) or how you would approach one. Name the analysis's weakest assumption before he does | The JD's independent-analysis line (F3), asked the way a data-driven interviewer asks. JD because it scores the stated requirement |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your background is consumer product strategy and ops. This is go-to-market for new B2B product lines. What do you bring that a sales-strategy hire wouldn't?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience." | Hold, then concede, through two follow-ups. Hold: two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops, with a partner-level revenue model used in carrier negotiations and annual volume targets set with cross-org consensus, each at its own scope. Concede specifically: "I haven't had classic sales-ops or quota-setting experience." Then a plan, said as a plan: what you would learn first and from whom. Likely follow-ups: "Where in this job would that gap cost my team the most?" (name one real area and the plan) and "What would the first 30 days look like?" (a plan, never a past). Never fold on the core claim to restore harmony | The highest-ROI question in the pack: it aims at F7 and the transferability rows F1 and F4, and a sales-strategy peer will ask it in some form. JD because it scores fit against the role; Skeptic delivery |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "No classic sales-ops or quota-setting experience." | Pick one and be specific; calibrated candor beats bluffing a competency he personally owns. The sales-ops and quota-setting gap has the plain acknowledgment above. If you pick partner-motion design instead, answer slot: say what part of the revenue model's work touched partners and what part of a motion design was or was not yours, in your own words. Close each with the ramp plan | The standard Skeptic stem, and F7 and F4 are where the honest answer lives. JD because it scores self-assessment against the listed requirements |
| C3 | "The role calls for partner-motion design experience. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Answer slot: if any part of the partner work was yours to decide, say which and how you decided, in your own words; if you designed none of it, or it was someone else's, say so plainly and stay with the revenue model, at the sentence's scope. Do not describe a motion you did not design | F4 is a hard requirement and the evidence is adjacent, so the question will come. JD because it is the stated requirement. The slot's second branch lets the premise be false |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You're handed two new product lines in your first month. What do you need to know first, and what does the first 90 days look like?" | CASE | [grounded] research note: three priorities are enterprise expansion, the AI copilot launch "Compass" and reaching profitability | Clarify before structuring: which two product lines (do not assume Compass is one of them), who the first customers are, and how success is measured. Then objective, segmentation, approach, metrics and risks, anchored to the three priorities in your note. State a hypothesis early and say the framework aloud. No claim about your past | The role's headline responsibility (F1) as a live problem; the company priorities are from your research note, not verified. CASE because it asks for structure on the actual role |
| D2 | "A much larger platform vendor starts bundling a competing capability into its suite at no extra charge. How does that change the GTM plan for a new product line?" | CO | [grounded] research note: main competitive threat is bundling by a much larger platform vendor | Structure it by stage: where bundling bites hardest (land, expand or renew), what has to be true for the product to win standalone, and the packaging, pricing and partner levers. Concede what you cannot know about Northwind's actual numbers and say what you would test first. Pricing and packaging is his native ground, so state your hypothesis early and invite his correction | The competitive threat is the one strategic fact your note supplies, and a pricing-spine peer will go there. CO because it tests thinking at Northwind's altitude; CASE in delivery |
| D3 | "Suppose an AI copilot sells as an add-on to existing customers. Where's the whitespace across land, adopt, expand and renew, and how would you size it?" | CASE | [grounded] research note: AI copilot launch ("Compass"); "skilled in SQL/Tableau" | Clarify definitions first. Then segment the installed base, size each stage's opportunity, and name the weakest assumption in your sizing before he does. You can say which cuts you would pull yourself in SQL and Tableau, at the quote's scope: skilled in SQL/Tableau. No claim about your past | The JD's whitespace line (F2) applied to the product the note names, and a place to show the AI plus (F6). CASE because it is a live sizing problem; the sizing angle suits a data-driven peer |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc built only from the sentence: two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Answer slot: why this move and why now, in your own words and your real reason; do not supply a reason you would not stand behind. Keep it under 90 seconds | The opener of a 60-minute peer conversation, and where the motivation probe starts. EXP because it checks the story against the CV; F1 is the row |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Name the tools you use and one concrete way you use them, in your own words, at the quote's scope: you use them daily. Answer slot: if you have built or shipped anything with AI, say what and what part was yours; if not, say so plainly and stay with use. Treat it as scored, however casual it sounds | The JD's AI plus (F6) asked casually, which is the register where it gets scored. JD because it scores a stated plus |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who's run a quota-carrying sales strategy team?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience." | Pause, restate the question, then hold two follow-ups before conceding. Hold on the revenue model and the volume targets at their own scope. Concede specifically: "I haven't had classic sales-ops or quota-setting experience." Never claim that the volume targets were quotas. Keep it to the minute | The time-boxed form of C1 (F7, F5, F4). JD because it scores fit; Pressure delivery tests composure rather than content |
| F2 | "Interrupting you: sixty seconds, no preamble. Where do Northwind's new products win against a bundled offering?" | CO | [grounded] research note: main competitive threat is bundling by a much larger platform vendor | State a thesis with a built-in concession: where you think the product wins, and what you do not know about Northwind that would change it. If he pushes with "you don't know our customers", concede that plainly and say what you would test first and ask what he has seen. Hold the thesis through two follow-ups | The D2 problem delivered under time pressure. CO because it scores strategy fluency; the Pressure persona tests whether a view survives interruption |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your path runs through pricing and monetization roles and an early-stage company. What carried over from that chapter to how you work here?" | Tied to his own path, and it converts an interrogation into a peer conversation. It shows you read his profile |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are pricing what you add to his load, not only what you need |
| R3 | "Where do you see the seam between your remit and this role, and where has it been fuzzy so far?" | Opens the A1 conversation on your terms and surfaces real turf questions before they turn into friction |
| R4 | "How is whitespace measured today across land, adoption, expansion and renewal, and which stage is the data weakest?" | A data-driven peer will answer at length, and the answer tells you which numbers you would inherit |
| R5 | "How does the bundling threat change how your team thinks about pricing and discounting for new products?" | Uses the competitive threat from your research note and goes into his native ground |
| R6 | "What has been hardest to get agreed across functions on the new product lines so far?" | Shows you are thinking about the influence part of the job (F5) and gets you the real obstacles |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed, credited. The limit is the pack's observation: the material says proposed and credited, not who built, launched or measured it. B2's slot stays inside the sentence |
| Set sales quotas, or has sales-ops experience | Negative the coach stated, F7; and the volume-targets sentence (F5) is not quota-setting | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." F5's quote stays at its own scope. No slot |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope: a revenue model used in negotiations. The limit is the pack's observation: the material says the model, not the motion. C3's slot stays inside the model |
| Owned the go-to-market for a launch | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. D1 and the F1 slot ask only what was hers, with an honest second branch |
| Built or shipped an AI product | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily. E2's slot stays inside use |

## Sources

**Provided:** your message (role summary, JD highlights, candidate summary, interviewer profile summary and research note). No dossier was present. The research note's date is not stated, and it was not checked against any outside source, so treat its Northwind facts as yours to confirm.

**Searches sent, all refused (web-search permission was not granted):**

- "Northwind Data company values": refused
- "Northwind Data interview process strategy operations": refused
- "Dan Kovac Northwind Data Director of Sales Strategy": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Would have given the official value names. No values-style round is documented, so section 10 is absent either way, but value names could have themed VAL questions |
| 2. `Northwind Data interview process strategy operations` | unavailable | Would have documented loop format and Dan's round. The loop is established by your own words (one 60-minute session with Dan), so persona weights stand |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note supplies the priorities and the competitive threat that feed D1 to D3 and F2; its date is unstated |
| 4. `Dan Kovac Northwind Data` | unavailable | Would have added his talks and writing to the interviewer read. It rests on the profile summary only |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the six JD-highlight rows become verbatim JD quotes, and any mid-list requirement missing from the highlights gets its own question
- Priya's CV text → the seven evidence cells move from your notes to her own CV wording; the field's inspectable artifacts here would be the revenue model itself and whatever document credits the ~$400M figure, which would lift F2 and F4 from medium toward high
- Priya's answers to the slots in F1, F2, F3, F4 and F5 → each row regenerates with her stated facts, and the matching bank cells become story maps
- Recruiter guidance on the conversation's focus, or any pre-work → persona weights re-tuned; a pre-declared deliverable gets its own build section
- Web-search permission → targets 1, 2 and 4 rerun: official values, documented loop format, Dan's public talks and writing
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, needs search permission) → a Northwind strategy brief for sharper CO and CASE questions, and a deeper read of Dan's public footprint
- The two product lines' names, and whether Compass is one → D1 and D3 become specific instead of hypothetical
- A `tuesday-dossier.md`, if you have one → verified evidence and prohibited claims would replace this pack's locally built list; never required
