I'll read the reference files the skill points to before I write anything.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-8-denied-24bac878/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop from the recruiter's email. I ran no searches, because your pasted material already covered everything a search could have changed. The interviewers aren't named yet, so there are no interviewer reads.

The pack has 29 questions across the three rounds, plus a values cheat sheet for the panel and five reverse questions per round. The highest-ROI prep is R2B2. It's the jump from handling one branch's complaints log to owning the whole process across the branches and the contact centre.

Say the word and I'll play your future manager on R2B2, with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Mode:** Loop. Three rounds on 4 December 2026, nine days after this pack was built (25 November 2026).

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Nothing more than the length |
| 2 | Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation. "The panel is also the values round" and scores against the four values |

Interviewers beyond their roles have not been assigned, so there is no interviewer read in this pack.

## How to use this pack

- **Personas are how a question arrives. Types are what it scores.** Persona letters: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Peer Evaluator, F Data-Driven Prober. A question ID reads round, persona, number: R2B2 is round 2, Skeptic, second question.
- **Type key:**
  - VAL: whether past behaviour shows Ashgrove's published values.
  - EXP: whether what you say about your experience survives follow-ups.
  - JD: a requirement from the job description, asked directly.
  - CO: whether you know where Ashgrove is heading.
  - CASE: a live problem, scored on structure and reasoning.
- **Guidance is scaffolding, not a script.** Say it in your own words.
- **Answer slot** lines are instructions for the interview itself. Fill them from what actually happened. If the honest answer is "that was not mine" or "that did not exist", the slot is met by saying so.
- **Provenance:** `[grounded]` means traceable to something you or Ashgrove provided. `[inferred]` means derived from an adjacent source. `[generic]` means a role-family pattern with no claim about you or Ashgrove.

## Prep triage

You have nine days. The order matters more than which day each item lands on. Everything else in the pack is insurance.

| Order | Do this | Tied to | Why first |
|---|---|---|---|
| 1 | Say your highest-ROI answer aloud until it is boring: the step from one branch's log to the whole process | R2B2 | This is the objection most likely to come in some form, in every round |
| 2 | Say the two gaps you stated plainly, once each, until they sound like facts | R1B2, R1B3, R2B1, R2D1 | Both the contact centre and presenting to senior leaders are named in the JD and arrive in friendly and pointed versions |
| 3 | Write your own answers to the answer slots on F1, F3, F6, F7 and F8, and send them back | F1, F3, F6, F7, F8 | Your answers become quoted evidence and regenerate the rows that depend on them |
| 4 | Find one real instance for each of the four values, using the selection scaffolds | R3C1 to R3C4 | The panel scores against the four values, and a scaffold with no instance behind it is a miss |
| 5 | Run the 20-minute case aloud twice, timed, then the other two cases once each | R3D1, R3D2, R3D3 | The case is a third of round 3 |
| 6 | Decide your logistics answers before round 1 | R1A3 to R1A5, R1B1 | They are short, they are scored, and only you can supply them |

## Fit snapshot

Shared by all three rounds. Evidence is your own words and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says a branch's log and a script you trained tellers on, with nothing inspected behind either, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on what came before and after the log likely. If any of that was yours, say what, in your own words; if the log was where your part began and ended, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a monthly spreadsheet your regional manager uses, not what it holds. Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet held. If it counted either, say which and how each was counted; if it did not, or it held something else, say so plainly and stay with the spreadsheet you built for the regional manager |
| F4 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." Then a plan for the first presentation, said as a plan. Never a claim to senior-level presenting |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The number is met on your own terms. Words: "I have six years in retail banking, the last three as a branch supervisor." The pack's observation: your sentence says retail banking, not customer operations, so the words stay at retail banking |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says a formal complaints log, not which rules governed it. Answer slot: the JD's "regulated" makes a probe on the rules or timescales likely. If the log worked to any, say which and how they showed up in your work; if you did not work to any, or do not know of any, say so plainly and stay with the log |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Words at their own scope: "I trained new tellers on our escalation script." Answer slot: the JD says supervisors and your sentence says tellers, so expect a probe on the step between them. If you have coached anyone at supervisor level, say who and on what; if not, say so plainly and stay with the tellers and the script |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have worked with any digital or online team, say what it was and what part was yours, in your own words; if you have not, say so plainly and say what a member would need from a self-service journey, as a view and not as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Words: "I built the monthly complaints spreadsheet our regional manager uses." The pack's observation: your sentence says spreadsheet, not which tool, so the words stay at spreadsheet until you say otherwise |

No figure appears in your material beyond tenure, so the pack has no defend-the-number questions. If you add a figure, such as complaint counts or resolution times you reported, it gets one.

## Grounding brief

From the 2026 strategy brief Ashgrove published in July 2026, as you relayed it. I have not seen the brief itself, and the pack has no later source.

| Item | What the brief says | Provenance | A question it raises for complaints |
|---|---|---|---|
| Digital | Move 40% of member service to digital channels by 2028 | [grounded] | Where do complaints arrive when service moves, and who owns one that starts in an app and ends at a counter? |
| Hubs | Consolidate eight branches into five hubs over 2027 | [grounded] | When a branch closes, whose town is a member from, and who keeps hold of their open complaint? |
| Lending | Launch a small-business lending product in Q1 2027 | [grounded] | A new product means a new kind of complaint: who writes the first escalation steps? |
| Competition | The main competitive pressure is app-only banks | [grounded] | Where a member can leave with a tap, what does a well-handled complaint cost to get wrong? |

Use these in the room as vocabulary. Do not recite them: a prepared candidate can assemble this list, and it is only worth bringing as the opening of a thought of your own.

---

# Round 1: Recruiter, 30 minutes

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Conversational | Friendly, unstructured; logistics, motivation, "walk me through the journey" | High. A recruiter screen is where the relationship prior puts Conversational first, and the email gives no format beyond the length | Pre-script the 90-second arc; treat every casual question as scored; never answer "no, you've covered it" to the closing slot |
| B Skeptic, light | Knockout-style checks on the two requirements your material states you lack, in a friendly register | Medium. The prior adds a light Skeptic, and F2 and F4 are stated absences against JD lines | Say each gap once in plain words, add the plan, stop talking |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in three beats, each a sentence you wrote: the six years and the last three as supervisor; the log and the script; the spreadsheet. Then your own reason for wanting this role, said in your own words. Stop there; the recruiter will pull the thread they want | F5 and F1 are the spine of the arc; EXP because the recruiter is checking that the story matches the CV they hold |
| R1A2 | "What drew you to this role at Ashgrove?" | JD | [grounded] Ashgrove's values page, quoted: "we decide from the member's side of the counter" | Give your own reason first. If you tie it to Ashgrove, use Ashgrove's published words, such as "we decide from the member's side of the counter", and say in one sentence what that means to you. Make no claim about your past in this answer | Motivation is asked in every recruiter screen; JD because it tests fit to the stated role, and the values page supplies the published words |
| R1A3 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | A recruiter screen always asks; only you can supply the fact |
| R1A4 | "What are you looking for salary-wise?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | Pay is a knockout check in a friendly register; the guidance supplies no figure |
| R1A5 | "Where would you be able to work from, and how often could you be on site?" | JD | [generic] | Logistics slot: give your actual constraints, plainly. Ask which site the role is based at, given the hub plan | Location is a recruiter check, and the 2027 hub plan makes the site a live question |
| R1A6 | "What do you know about where Ashgrove is heading?" | CO | [grounded] the strategy brief as you relayed it: move 40% of member service to digital channels by 2028; consolidate eight branches into five hubs over 2027 | Pick two of the four published moves and say each in the brief's own words. For each, ask one question about what it changes for complaints, using the grounding brief's questions as raw material. Add nothing about the credit union that the brief does not say | The one strategy question a recruiter can score cleanly; CO because it tests homework at the company's altitude |
| R1B1 | "Why are you looking to move on from your current role?" | EXP | [generic] | Logistics slot: state your actual reason in a sentence or two, in your own words, and stop | Reason for leaving is asked in every screen; EXP because the answer has to match the rest of your story |
| R1B2 | "The role covers the contact centre as well as the branches. What's your experience of the contact centre?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment first, in your words: "I haven't worked in a contact centre." Then the plan, said as a plan: how you would get to know the contact centre in the first weeks. Do not describe what the contact centre does as if you had seen it | F2 is a stated absence against half of the role's scope, so it is asked in round 1 in its mildest form |
| R1B3 | "Part of the job is presenting to senior leaders. How do you feel about that?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan, said as a plan: how you would prepare the first one and who you would ask what senior leaders need. Do not claim confidence you have not tested | F4 is a stated absence against a JD line; the recruiter asks it as a feelings question |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would the Head of Member Services most want to see from a candidate in round 2?" | A recruiter can answer this and you cannot research it |
| 2 | "Which site would this role be based at, given the move from eight branches to five hubs?" | Shows you read the brief, and settles the location logistics |
| 3 | "Which complaint rules and reporting timescales does the role report against?" | The JD says regulated complaints; the answer tells you what F6 will be measured against |
| 4 | "How is the contact centre organised today, and who would I work with there?" | Turns your stated gap into a plan question |
| 5 | "What happens after round 3, and when would you expect to decide?" | Practical, and closes the screen on a forward step |

---

# Round 2: Head of Member Services, 45 minutes

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | "Tell me about a time" questions drawn from the JD's responsibilities | High. The recruiter calls the round "mostly behavioural" | A story for each prompt, where "we" gives context and "I" gives your part; where you have no instance, say so plainly and give how you would handle it |
| B Skeptic | Quiet probing of the scope jump and the two stated gaps | High. This person would be your manager, so the prior adds the Skeptic who is buying capability and checking for gaps, and F1, F2 and F4 are where the material is thin | Rehearse the single most predictable objection until it is boring; concede only what is true |
| F Data-Driven Prober | "What is in the spreadsheet, who reads it" | Medium. A manager who receives a monthly report will read the one you built; F3 and F9 draw on the same sentence | Know what you can and cannot say about what it held, and say plainly where you do not know |
| D Case/Strategist | "Where would you start?" | Low. The email puts the case in round 3, so this is a light version | Clarify, then structure, then answer, aloud |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2B2 | "You've handled a branch's formal complaints log. This role owns the process across all the branches and the contact centre. What makes you ready for that step?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre" | **The highest-ROI prep in this pack.** The hold is only what the sentence carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Then the limit, named before it is asked for: "I haven't worked in a contact centre." Follow-up 1, "what did you see of the other branches?": answer slot: if you saw other branches' complaints or worked with the regional level on them, say what, in your own words; if not, say so plainly and return to the log. Follow-up 2, "so how would you learn it?": the plan, said as a plan: start by finding out how complaints flow today. Hold through both by returning to the log and the script, never by adding to them | F1 and F2 are where the JD's scope presses hardest, so this objection arrives in some form in every round; JD because it scores the stated requirement |
| R2B1 | "This role presents to senior leaders, and the highest level you've presented to is regional. How would you approach your first one?" | JD | [grounded] "I've never presented to anyone above regional level." | Words: "I've never presented to anyone above regional level." Then the plan as a plan: ask who the audience is and what decision the report supports, lead with one finding in plain words, rehearse it with your manager first. Do not claim any presentation experience beyond the sentence | F4 stated; asked by the person who would have to take you to those leaders |
| R2B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level." | Choose from the rows your own material shows, which are F2 and F4 as stated absences and F8 as unknown. Name one, say it plainly, then give how you would close it. Calibrated candor beats bluffing a competency the interviewer owns | A standard Skeptic stem, and the answer is already in your material |
| R2C1 | "Tell me about a time you coached someone through a difficult escalation." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Beats the sentence carries: new tellers, the escalation script, you trained them. Answer slot: a particular escalation is not in your sentence, and the JD says supervisors. If there was a specific case, say what it was and what part was yours; if there was no such case, say so plainly and describe the training itself, the tellers and the script | F7 is the JD's coaching requirement; EXP because it tests what was actually yours |
| R2C2 | "Tell me about a time you saw a pattern in complaints and did something about it." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold: pick a pattern you actually saw, with a named point at which you noticed it and what you did next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the spreadsheet, or how you would handle it | The JD asks you to own the process and report monthly, and F3 is the nearest row |
| R2C3 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A Values/Behavioral stem; a manager scoring candor wants to see it before offering the job |
| R2C4 | "Tell me about a time you worked with a team outside your branch to change something members used." | JD | [grounded] the JD line "work with digital teams on self-service journeys" | Selection scaffold. Answer slot: the JD names digital teams, so expect a probe on any such work. If you did any, say what it was and what part was yours; if you did not, say so plainly, then give how you would work with a digital team, from the member's side | F8 has no evidence either way, so the honest branch is rehearsed here |
| R2F1 | "Walk me through the monthly complaints spreadsheet you built: what's in it, and who reads it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the sentence carries: monthly, a complaints spreadsheet, your regional manager uses it. Answer slot: the JD names volumes and resolution times and Excel. If it held either, say which and how each was counted; if it was in another tool, or did not hold them, say so plainly and stay with the spreadsheet. If asked what you would defend least in it, say so in your own words, or say you do not know how part of it was counted | F3 and F9 draw on this sentence, and a manager who receives the monthly report will read yours |
| R2F2 | "What rules or timescales did the branch's complaints log have to meet?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: the JD says regulated complaints. If the log worked to any rules or timescales, say which and how they showed up in your work; if you do not know of any, or the log had none, say so plainly and stay with the log | F6 is a discovery gap; the answer tells the pack, and the interviewer, what "formal" meant |
| R2D1 | "It's your first month. How would you find out how complaints really flow across the branches and the contact centre?" | CASE | [generic] | Clarify first: what exists, who holds it, what counts as a complaint at each point. Then structure it: listen to the contact centre and the branches, trace a complaint end to end, find where the records disagree. State what you would want to know before committing to a plan | A light case for a round that is mostly behavioural, and a plan question for F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good first 90 days look like to you?" | Asks your future manager for the bar, and they can only answer in their own terms |
| 2 | "What do senior leaders ask about complaints today?" | Tells you what the monthly report must answer |
| 3 | "How much of this role is the contact centre, and how much is the branches?" | Sizes F2 against the real job |
| 4 | "Where do you see this role and the digital team meeting on self-service?" | Tests F8 against how the work is actually set up |
| 5 | "What is the hardest part of the current complaints process?" | Invites a candid answer and shows you expect to own the problem |

---

# Round 3: Panel of two branch managers, 60 minutes

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | Stories scored against the four published values | High. The email says the panel is the values round and scores against them | One story per value where you have one, and a plain "I don't have one" where you do not |
| D Case/Strategist | The 20-minute complaint-escalation case | High. 20 of the 60 minutes are fixed, and a case is scored on structure | Clarify, objective, approach, measures, risks; think aloud; challenge one premise respectfully |
| E Peer Evaluator | "What would you need from us, and what do we get" | Medium. The panel is branch managers whose supervisors you would coach, so the seam between your role and theirs is what they are pricing | Reciprocity: what you bring their branch, and principles for the seam rather than claims to know it |

Pressure is possible in a timed case, so the case guidance includes saying your structure aloud early.

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3D1 | "A member has complained three times about the same problem. Their branch supervisor has escalated it to you, and the contact centre's record of the member's contacts doesn't match the branch's. You have twenty minutes: what do you do?" | CASE | [generic] | Say your structure in the first two minutes. Clarify: what the member wants, what stage the complaint is at, which timescales apply and who sets them. Objective: the member's problem solved, and the process followed. Approach: name one owner who keeps hold of it, reconcile the two records before anyone replies, write to the member in plain words. Measures: how long it has been open, whether the member has to explain it again. Risks: a third reply that repeats the first two. Challenge one premise respectfully, such as whether the mismatch is the cause or a symptom. The panel's real case will differ; the structure carries over | The panel's actual case is unknown, so this one rehearses the pattern; F1 and F2 are the requirements it sits on, and the values give the language |
| R3D2 | "You'll report monthly to senior leaders on complaint volumes and resolution times. What goes on the first page, and what would you want to know before you build it?" | CASE | [grounded] the JD line "report monthly on complaint volumes and resolution times" | Ask first: who reads it and what decision it informs. Then a few measures with one line each in plain words, and a member story alongside the numbers. Name the assumption you would defend least, such as how a complaint is counted or when it counts as resolved. If you refer to your own spreadsheet, say only what it held: answer slot as F3 | F3 is the discovery row for the JD's reporting line; the defend-the-number move is rehearsed here as design and not as history |
| R3D3 | "Eight branches become five hubs over 2027, and 40% of member service moves to digital by 2028. What happens to complaints, and what would you want to know first?" | CASE | [grounded] the strategy brief as you relayed it: consolidate eight branches into five hubs over 2027; move 40% of member service to digital channels by 2028 | Clarify before you answer: which complaints arrive where today, what the 40% includes, how a complaint is recorded when it starts digitally. Then reason aloud: who keeps hold of an open complaint when its branch closes, and how a member in a town that loses a branch is heard. Ask whether the plan assumes complaints fall or move. Use the brief's own words and add no figures | The one CO and CASE question grounded in current strategy, and the panel's branch managers are the people the hub plan lands on |
| R3C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] Members First, Always: "we decide from the member's side of the counter" | Selection scaffold: pick a real decision with a named member situation, a rule or target that pointed the other way, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the complaints log, or how you would handle it | Members First, Always is the first published value and the panel scores against it |
| R3C2 | "Tell me about a time something needed explaining twice, and what you changed." | VAL | [grounded] Plain Words: "if a member needs it explained twice, we wrote it wrong"; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Beats the sentence carries: you trained tellers on an escalation script. Answer slot: whether you changed any wording of the script or of anything a member read is not in your sentence. If you did, say what and what happened; if you did not, or the script was not yours to change, say so plainly and stay with the training | Plain Words is the value F7 is nearest to; the slot lets the honest branch be that you only trained on the script |
| R3C3 | "Neighbours, Not Numbers: how do you keep a branch's town in view when you report in numbers?" | VAL | [grounded] Neighbours, Not Numbers: "every branch is part of its town"; "I built the monthly complaints spreadsheet our regional manager uses." | The spreadsheet is the numbers side of this value, and the panel may notice. Say that first, plainly, from your own sentence. Answer slot: whether a number ever led you to look at a branch's circumstances is not in your sentence; if one did, say what happened; if not, say so and say how you would put a branch's story beside its numbers | The tension between a reporting lead and this value is the likeliest probe, and F3 is the evidence the panel will hold up against it |
| R3C4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] Own the Fix: "whoever finds the problem keeps hold of it until it is solved" | Selection scaffold: pick a problem you found, name the point at which handing it on would have been easier, and what you did instead. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The published value is the JD's "end to end" in the employer's own words |
| R3E1 | "Our supervisors are busy at the counter. What would you need from us, and what could we expect from you?" | JD | [generic] | Reciprocity. Offer principles for the seam in your own words: what you need from a branch manager (a named contact, how escalations reach you), and what a branch can expect (one owner for each complaint, plain updates, a view of its own branch each month). These are proposals for the role, not claims about your past | The panel is pricing what you add to their branches; no claim about your past is needed |
| R3E2 | "A supervisor at my branch has handled a complaint in a way you'd have done differently. How do you raise it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Structure: ask what happened and what they were weighing, agree the outcome for the member, then the one move you would change and why, then tell the branch manager. Answer slot: coaching at supervisor level is not in your sentence, which says tellers. If you have done it, say who and on what; if not, say so plainly and stay with the tellers and the script | F7 is the JD's coaching requirement, asked by the people whose supervisors it concerns |
| R3E3 | "As a branch supervisor, what do you want from the people above you when a complaint is escalated?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Give your own view, in your own words. You can say you were on the supervisor's side of this for the last three years, because your sentence says it. Use a case only if you can describe all of it | The strongest relationship you share with this panel is the supervisor's chair; F5 holds the sentence |

## Values / principles cheat sheet

Ashgrove's published values, copied on 25 November 2026 from ashgrovecu.org/about/values.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from what the member experiences, whatever the rule or target says | Selection scaffold (R3C1): the nearest row is F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script." Pick a decision, not a log entry. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Plain Words | Wording is the organisation's fault if a member needs it twice | F7, "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beats the sentence carries: you trained tellers on a script. Whether you changed any wording is the answer slot in R3C2 |
| Neighbours, Not Numbers | Each branch is part of its town; a figure is not the whole picture | Selection scaffold (R3C3): the numbers side is F3, "I built the monthly complaints spreadsheet our regional manager uses." Say that plainly. If no story comes to mind, say so, then say how you would put a branch's story beside its numbers |
| Own the Fix | Whoever finds a problem stays with it until solved | Selection scaffold (R3C4): the nearest row is F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script." If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new complaints lead do in their first month that would genuinely help your branch?" | Reciprocity: puts you on their side of the seam |
| 2 | "When an escalation reaches head office from your branch, what would you want to be different?" | Asks for the supervisor's and manager's view, in their terms |
| 3 | "How do you expect the move to hubs to change how your branch handles escalations?" | Tests whether they see the hub plan as theirs to answer |
| 4 | "Which of the four values is tested hardest in your branch day to day?" | Shows you took the values as working terms, not slogans |
| 5 | "How do your supervisors get coached on escalations today?" | Surfaces what the JD's coaching line replaces or adds to |

---

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | R2B2, R2D1, R3D1, R1B2 |
| Report monthly on complaint volumes and resolution times | R2F1, R3D2 |
| Coach branch supervisors on escalations | R2C1, R3E2, R3C2 |
| Work with digital teams on self-service journeys | R2C4, R3D3 |
| 4+ years in financial-services customer operations | R1A1, R3E3 |
| Experience handling regulated complaints | R2F2, R3D1 |
| Confident presenting to senior leaders | R1B3, R2B1, R3D2 |
| Comfortable with Excel reporting | R2F1, R3D2 |

## Prohibited claims

What this pack will not coach, and why. Each is a wording that a requirement invites and your sentences do not carry.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's sentence at its own scope. The limit is the pack's observation: your material says a branch's formal log and a script you trained tellers on. R2B2's slot stays inside the log |
| Has handled complaints in a contact centre | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F4 | "I've never presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's sentence at its own scope: "I trained new tellers on our escalation script." R2C1's and R3E2's slots ask only whether you have coached at supervisor level, and allow no |
| Reported complaint volumes and resolution times each month | Inflated form of F3 | F3's sentence at its own scope. R2F1's slot asks what the spreadsheet held and allows that it held neither |
| Handled regulated complaints | Inflated form of F6 | F6's sentence at its own scope: a formal complaints log. R2F2's slot asks which rules governed it and allows that none did |

## Sources

Provided documents:
- The job description, quoted in the fit snapshot.
- Ashgrove's values, copied by you on 25 November 2026 from ashgrovecu.org/about/values.
- The recruiter's email on the process, which fixes the three rounds, their lengths, who runs each and the panel's scoring.
- The July 2026 strategy brief, as you summarised it. I have not seen the brief itself.
- Your own background, as you wrote it in your message.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values page fixes the values cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the rounds, their lengths, who runs each, the case and the values scoring |
| 3. `Ashgrove Credit Union strategy` and recent news | skipped | The July 2026 brief you relayed supplies the four priorities that feed the CO and CASE questions |
| 4. interviewer name and company | n/a | No names were given, only roles, so there was no query to form; the interviewer read is absent |
| 5. representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

No dossier was supplied.

## Upgrade menu

- The names of the Head of Member Services and the two branch managers, once assigned → an interviewer read for each, persona weights set per person, and a reverse question tied to each one's own public path
- The strategy brief itself, not a summary → the grounding brief grows beyond four points, and the CO and CASE questions can use its specifics
- Your answers to the slots on F1, F3, F6, F7 and F8 → those rows quote you directly, and the questions that draw on them regenerate with your own words
- Anything you are free to share that someone could inspect, such as the layout of the monthly spreadsheet with all member and employer data removed, or the complaints procedure the log followed → F3, F6 and F9 can move from `medium` toward `high`
- Your CV → the fit snapshot can quote it as well as your message, and any role it carries that your message does not may add rows
- One email to the recruiter: which complaint rules the role reports against, which site and pattern the role is based at, and whether the round 3 case comes with any material in advance or has any pre-read → the case can be rehearsed to its real format, and a graded-deliverable section can be added if one exists
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes, covering the strategy, recent leadership and organisation changes, and reports of this loop → a sharper grounding brief and more specific CO questions. Say so if you want it
- A `tuesday-dossier.md` from a job-underwriter run → verified evidence, a ranked objection, and prohibited claims set by an evidence review, in place of the ones this pack built locally
