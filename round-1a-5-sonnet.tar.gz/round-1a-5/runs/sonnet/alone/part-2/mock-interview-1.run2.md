I'll read the skill's reference files before writing anything.
I'm cleaning up one small formatting issue in the saved pack. After that I'll send the summary.
Priya's prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-1-denied-80291767/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. I built it for a peer conversation with Dan, weighted toward the Data-Driven Prober and Peer Evaluator. It has 21 questions across six personas, and each question has a type tag, answer guidance and a rationale. The web searches I tried (company values, interview process, Dan's profile) were all refused, so everything rests on your notes. The Sources section says what that cost.

Say the word and I'll play Dan on D1, the pack's highest-ROI question: "I don't see classic sales-ops or quota-setting in your background…". I can also run A1, the ~$400M figure.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full JD text and Priya's CV lines word for word? The pack currently quotes your summary, and her own sentences would upgrade rows F1, F2 and F4.
2. Did the recruiter give any focus areas, or ask for a deliverable such as a presentation or take-home, for the Dan conversation? A named deliverable would add its own build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer (same VP). **Format:** one 60-minute conversation. **Built on:** the coach's summary of the JD highlights, of Priya's background and of Dan's profile, plus the coach's research note. No full JD text or CV text was supplied, and web research was not permitted (see Sources).

## How to use this pack

- **Personas describe how a question is asked; types describe what is scored.** Rehearse both: the same question lands differently from a prober, a peer and a skeptic.
- **Guidance is scaffolding, not a script.** Where a cell says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours. Either branch is a good answer.
- **Highest-ROI prep: D1.** The sales-ops and quota-setting gap sits in Dan's own function, so some form of D1 is the likeliest question of the hour. Rehearse it until it is boring, together with A1, the figure he is likeliest to take apart.

| Tag | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. No VAL question is in this pack: no published values were available to build on |
| EXP | Whether the background survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company's strategy and competition |
| CASE | A live problem from the role: structure and reasoning |

## Fit snapshot

Requirements are the JD highlights as the coach supplied them, not full JD text. Evidence is quoted from the coach's notes, which are not Priya's own wording.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy & ops at a consumer-tech company, not go-to-market for product lines, and the words stay at "product strategy & ops". Answer slot: the JD's GTM line makes a probe on the closest thing you have owned likely. If any of your work was bringing a product to market, say what it was and which part was yours; if none was, or it was not yours, say so plainly and stay with product strategy & ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The sentence touches revenue-growth work; the material does not show whether it reached what happens after a first purchase or sign-up. Answer slot: if any of your work looked at customers or revenue after that first step, say what it was and which part was yours; if none did, say so plainly and say how you would start looking for whitespace in Northwind's base |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | Lead with the quote in its own terms: you are skilled in SQL and Tableau. The quote says skilled in the tools, not that you ran analyses alone, and "independent" is where a probe will land; A3 carries that slot |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a partner-level revenue model used in carrier negotiations, not the design of a partner motion, and the words stay with the model: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any of that work shaped how a partner went to market or what a partner earned, say what and which part was yours; if it did not, or that was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | Lead with the sentence in its own terms: annual volume targets, set with consensus across orgs. Keep "volume targets" as said; F7's stated negative draws its line at "classic" quota-setting, and this pack does not treat the two as the same |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | Say it as it stands: "I use AI tools daily." That is use, and the words stay at use. E2 carries the slot on what for |
| F7 | Sales-ops and quota-setting familiarity (not a JD line; the coach flagged it against the interviewer's function) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it has been stated. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn Dan's team's process, said as a plan and never as a past. Nothing added to make the gap feel smaller |

The JD highlights name no eligibility, location, pay or credential term, so the snapshot has no gate row. "Partner-motion design experience required" is an experience requirement, graded like any other row.

## Reading the interviewer

Public professional footprint only, as supplied by the coach from Dan's profile.

| Signal | Source | What it implies |
|---|---|---|
| Describes himself as "relentlessly data-driven" | Dan's profile, via the coach | Every figure you give gets probed to its assumptions. Name the assumption you would defend least before he asks |
| Career spine in pricing and monetization roles | Dan's profile, via the coach | Pricing, packaging and unit-economics angles are his native language; cases C1 and C3 are tilted that way. Expect him to price what hiring you costs and contributes, since you are peers |
| One early-stage-startup chapter | Dan's profile, via the coach | Practical, build-it-lean stories may land. He may also test how you work without large-company scaffolding |
| Directs Sales Strategy, and you would share a VP | The coach's notes | Quota and sales-ops territory is his function, which is why F7 becomes D1 |

**Mirror opportunity (shared vocabulary, not a shared jump):** Dan's monetization path meets F4's sentence, "built a partner-level revenue model used in carrier negotiations", and F2's, "proposed a store-surface change credited with a ~$400M ARR uplift". Use the sentences exactly as they stand, and let him draw the parallel. No shared career jump is offered, because no row carries your side of one.

## Persona table

Weights start from the relationship prior (peer: Peer Evaluator plus Data-Driven Prober), then move on Dan's signals. The loop rests on your own description, one 60-minute conversation with a peer, so no values-style round is detected and no Values bank is built.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A) | Line-by-line probing of the ~$400M figure, the revenue model and the targets | High: the peer prior plus "relentlessly data-driven" pushes it to the top | Know what you can and cannot say about how each number was counted; say plainly when you do not know; name the weakest assumption first |
| Peer Evaluator (B) | Seam-splitting between Sales Strategy and Emerging Products GTM; what you would need from him; credit | High: the peer prior, and the JD asks for cross-functional influence | Reciprocity first (what you bring his team), propose seam principles rather than pretending to know the seam |
| Skeptic (D) | Quiet probing of the sales-ops gap, consumer-to-B2B and partner-motion experience | High-medium: F7 is stated, F4 and F1 are adjacent-only, and Dan owns the gap's territory | Rehearse D1 until boring; acknowledge plainly, hold what your sentences carry, give a concrete ramp |
| Case/Strategist (C) | Live problems on Compass, whitespace and margin versus growth | Medium: a peer rarely runs a formal case, but his pricing spine and the new-product-line scope make a live problem likely | Clarify, structure, think aloud, challenge one premise respectfully |
| Conversational (E) | The "walk me through the journey" opener and a casual AI question | Medium: openers are near-certain in any conversation, and both questions are scored | A 90-second arc built from your sentences; treat the casual AI question as scored |
| Pressure (F) | "Why you over a candidate who has run sales ops?" or "how much was actually you?" | Low: peers seldom run stress tactics, but D1 can arrive in this register | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral | Scored stories against published values | Low: no loop source documents a values round and no values page was available. B2 and B5 cover behavioral ground informally | Not banked |

## Question banks

### A. Data-Driven Prober (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the sentence says: you proposed the change, and it was credited with a ~$400M ARR uplift. Answer slot: how the figure was counted. If you know, say how in your own words; if you do not, say plainly that you do not know how it was counted. Answer slot: what the figure is most sensitive to, in your own words, or say plainly you do not know. Answer slot: the assumption behind it you would defend least; name it before Dan does, or say plainly you cannot name one. Answer slot: which part of the result was yours. The sentence gives you the proposal; if more than that was yours, say what, and if not, say so plainly and stay with the proposal | F2 holds the headline number, and a self-described data-driven peer goes straight to it. EXP because it scores counting and attribution, not the role |
| A2 | "You built a partner-level revenue model for the carrier negotiations. What did it rest on?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the sentence carries: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD's SQL and Tableau analysis line makes a probe on what the model rested on likely. If you built it yourself, say what went into it and how you checked it, in your own words; if others built or fed parts of it, or you do not know how an input was derived, say so plainly and stay with the model | F4 is the main evidence near the partner requirement, and revenue models are Dan's native ground. EXP because it tests what was actually built and by whom |
| A3 | "How much of your SQL and Tableau analysis do you run yourself?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with: "I'm skilled in SQL and Tableau." Answer slot: the JD's independent-analysis line makes a "show me one" probe likely. If you ran an analysis yourself, pick one you can walk end to end in your own words, including the assumption you would defend least; if most of your analysis ran through others, say so plainly and say what you did run yourself | F3 is the JD's tooling line, and a probe on "independent" is likely. JD because it scores a stated requirement |
| A4 | "Suppose net revenue retention in our enterprise accounts fell and nobody knows why. Walk me through what you would pull and in what order." | CASE | [grounded] | Clarify before cutting: how retention is defined here, which product line, what time window, whether the drop is concentrated or spread. Then structure by the JD's land/adopt/expand/renew stages, state two or three hypotheses before any query, say what each cut would rule out, and challenge one premise (is the drop real, or did a definition change?). Name the assumption you would defend least. The question needs no claim about your past, so the guidance makes none | Enterprise expansion is a stated Northwind priority in the coach's note, and the JD's lifecycle line raises it (F2's requirement). CASE with a Prober delivery: Dan will ask for the order and the reasons |
| A5 | "Walk me through how the annual volume targets were set." | EXP | [grounded] "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience." | Say it as it stands: "I set annual volume targets with cross-org consensus." Answer slot: the JD's cross-functional line and Dan's own function make a probe on the method and on how consensus formed likely. If you chose the method, say what it was and why; if it was not yours to choose, say so plainly. If bringing orgs to consensus took something specific from you, say what; if it did not, say so plainly and stay with the sentence. Keep "volume targets" as said; if he calls them quotas, your notes draw the line at classic quota-setting, and D1 covers it | F5 is the likeliest overlap with Dan's territory, so the line between targets and quotas is where this question presses. EXP because it tests method and attribution |

### B. Peer Evaluator (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between Sales Strategy and GTM for Emerging Products, and what happens when we disagree?" | JD | [generic] | Do not pretend to know where Northwind draws the seam: ask Dan where he draws it, then offer principles. Candidates: decision rights follow who carries the number, shared metric definitions agreed before launch, and a named route to your shared VP when you cannot settle it between you. Close with what you bring his team, in your own words | Peers price how a hire changes their own load; this is the cross-functional line (F5's requirement) in its collegial form. Labeled generic because the principles are a pattern, not a fact about Northwind's structure |
| B2 | "How do you handle credit when work spans teams?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift"; "set annual volume targets with cross-org consensus" | Selection scaffold: pick one instance where work spanned teams, use "we" for context and "I" for your contribution, and say who did which part. Your material gives two places to attach it, and you may use only what each sentence states. Answer slot: if credit was shared, say how you described each part; if it was not shared, or you do not recall who did what, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2's "credited with" invites exactly this probe. JD because cross-functional influence is a stated requirement, with attribution scored alongside |
| B3 | "What would you need from my team in your first 90 days?" | JD | [generic] | Reciprocity framing: two concrete asks (for example the metric definitions and data access your analysis would start from), and one thing you would offer his team in return, in your own words. Say what you do not yet know about how his team works and that you would ask, rather than assuming | A peer scores whether the hire reduces or adds to their load. Labeled generic because it carries no claim about Northwind or your past |
| B4 | "The role calls for partner-motion design experience. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold the sentence: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD's requirement makes a probe on how partners were structured likely. If any of that work shaped how a partner went to market or what a partner earned, say what and which part was yours; if it did not, or that was not yours, say so plainly and stay with the model. Then say how you would learn Northwind's partner motion, as a plan | F4 is the required item with only adjacent evidence. JD because it scores a stated hard requirement, with the second branch letting the premise be false |
| B5 | "Tell me about a time you built agreement across orgs on something contentious." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the sentence states: annual volume targets, set, with consensus across orgs. Tell those in your own words. Answer slot: the JD's cross-functional influence line makes a probe on how the agreement formed likely. If you did something specific to bring orgs together, say what; if the consensus came without that, or it was not yours to broker, say so plainly and stay with the sentence | F5 is the evidence for the influence line. EXP as an open prompt on the one sentence that carries it |

### C. Case/Strategist (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Bundling by a much larger platform vendor is our main competitive threat, and Compass is launching into it. How would you decide where Compass lands first?" | CASE | [grounded] | Clarify first: who buys Compass, whether it sells standalone, as an add-on or inside existing tiers, and what the bundle actually covers. Then objective, segmentation by lifecycle stage, packaging options with the trade-off of each, metrics and risks. Challenge one premise respectfully (is the bundle comparable on what customers value?). Use Northwind's own vocabulary from the note: enterprise expansion, Compass, profitability. The guidance makes no claim about your past | The coach's note names bundling as the main threat and Compass as a priority, and Dan's pricing spine tilts the case toward packaging. CASE with a CO layer: it also tests whether you can sound current |
| C2 | "You have two new product lines and an existing enterprise base. How would you find whitespace across land, adopt, expand and renew?" | CASE | [grounded] | Clarify what data exists per stage and what counts as whitespace. Then define a stage-level metric for each of the four stages, cut the base to find where it thins, rank hypotheses by size and ease, and say what would change your mind. Say you would run the first cut yourself, as a plan and not a past. The guidance makes no claim about your past | Raised directly by the JD's lifecycle line (F2's requirement). CASE because the JD describes a task, not a credential |
| C3 | "We want enterprise expansion and we want profitability. A new product line's partners want richer incentives that cut margin. How do you decide?" | CASE | [grounded] | Clarify the incentive's size against the line's margin and whether the partners bring volume Northwind cannot reach alone. Then name the trade-off between growth and profitability explicitly, set a guardrail you could defend, say what you would test before committing, and state the concession: the answer depends on numbers you do not have yet. The guidance makes no claim about your past | Two of the note's three priorities collide here, and partner-motion design is a required line (F4's requirement). CASE with Dan's monetization lens |

### D. Skeptic (weight: mid-high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus" | **The highest-ROI rehearsal in this pack.** Level 1, acknowledge: "I don't have classic sales-ops or quota-setting experience." Then hold only what your sentence carries: "I set annual volume targets with cross-org consensus." Let Dan draw any parallel; do not state one. Then the ramp, as a plan: ask him to walk you through how his team sets targets for a new motion, and what you would read first. Level 2, if he says targets are not quotas: concede the difference, and if you do not know how his quotas are built, say so plainly. Level 3, "what would you get wrong first?": answer slot, name the place you expect to be slowest, in your own words. Level 4, "why should I trust you on a motion tied to quotas?": return to the sentence, and invite correction rather than argue | F7 is a stated gap sitting in the interviewer's own function, so this question will arrive in some form. JD because it scores a requirement-adjacent gap; the structure is hold-then-concede, with the limit named before it is pressed |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] | Selection scaffold: pick the line your material carries least. Per the pack's own reading of the snapshot, F1 and F4 are the rows with adjacent evidence only. Say it plainly, say what you would do in the first weeks to close it, and name who you would ask. If you would rather choose a different line, choose the one you can say a true sentence about. The guidance makes no claim about your past | The stem is standard for skeptics, and the fit snapshot shows where the honest answer sits. JD because it scores self-assessment against the stated lines |
| D3 | "Your biggest result came from a store surface. How does that carry into enterprise B2B GTM?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say the sentence at its own scope first. The pack's own observation: it states a consumer store surface, not an enterprise setting. Answer slot: name the part of how you worked that you would carry across, in your own words; if you think little carries, say so plainly and say what you would rebuild. Do not claim the result transfers | F2's transfer question is the consumer-to-B2B mismatch in one sentence. EXP because it tests the claim's reach and your honesty about it |
| D4 | "You would own GTM strategy for two new product lines. What is the closest thing you have owned?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Answer slot: if any of your work was bringing a product to market, say what it was and which part was yours; if none was, or it was not yours, say so plainly and stay with product strategy & ops. Then say how you would approach the first product line, as a plan, not a past | F1 is the headline requirement with adjacent-only evidence. JD because it scores the first stated responsibility directly |

### E. Conversational / Rapport Builder (weight: low-mid, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with three beats the sentence states: strategy consulting at a top firm, then a large consumer-tech company in product strategy & ops, then this role. Answer slot: why this role, why now, in your own words; it should still hold under "why leave" | A conversational opener is near-certain, and it is still scored for economy. EXP because it tests whether the story hangs together and the motivation is yours |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it as it stands: "I use AI tools daily." Answer slot: name the tools and what you use them for, in your own words; if the use is general rather than analytical, say so plainly. Stay at use: the sentence does not say you built or launched anything. Then turn it into a question about Compass | The JD lists AI as a plus (F6's requirement) and Compass is a stated priority, so a casual AI question is a scored one. JD because it targets a named JD plus |

### F. Pressure / Stress (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has run sales ops?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "built a partner-level revenue model used in carrier negotiations" | Pause, restate the question, then three beats: concede what is true ("I don't have classic sales-ops or quota-setting experience"), say what your sentences carry ("I built a partner-level revenue model used in carrier negotiations"), and say what you would do to close the gap. Hold through two follow-ups; do not argue that your background is equivalent | D1 in a stress register. JD because it scores fit against the role's own territory; the hold-then-concede structure is the point |
| F2 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold the sentence: you proposed the change, and it was credited with the uplift. Answer slot: which part of the result was yours. The sentence gives you the proposal; if more was yours, say what, and if not, say so plainly. Hold that through two follow-ups, and concede specifically what you cannot speak to, such as how the credit was counted, if that is true | A1 under pressure delivery; F2's figure is the thing a stress interviewer reaches for. EXP because attribution is what is scored |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "own GTM strategy for two new product lines" | D4, D2, C1, C3 |
| "identify whitespace across land/adopt/expand/renew" | C2, A4 |
| "run independent analysis in SQL and Tableau" | A3, A2, A4 |
| "partner-motion design experience required" | B4, C3 |
| "strong cross-functional influence" | B1, B2, B3, B5, A5 |
| "AI experience a plus" | E2 |
| Sales-ops and quota-setting (not a JD line) | D1, F1, A5 |
| The ~$400M figure, the headline number | A1, F2, D3 |

## Reverse questions

| # | Question to ask Dan | Why it lands |
|---|---|---|
| R1 | "Your path runs through pricing and monetization, with one early-stage-startup chapter. What from that chapter do you still use in sales strategy here?" | Tied to his own career path; it turns an interrogation into a peer conversation and shows you read about him, not just the company |
| R2 | "What could a new peer do in the first month that would genuinely help your team?" | The reciprocity question for a peer: it signals you are thinking about his load, not only your needs |
| R3 | "Where do you draw the seam between Sales Strategy and GTM for Emerging Products, and which decisions would you want a say in?" | Follows B1: you offered principles, and now you ask where he actually draws the line |
| R4 | "How does your team set targets for a motion that is new? I would like to learn the vocabulary before I propose anything." | Acknowledges the F7 gap openly and asks him to teach, which is the ramp D1 promised |
| R5 | "Compass is a stated priority. What do you hope it changes in what customers expand or renew on, and what data do you wish you had?" | A data-driven peer will want to talk about measurement; it ties to a stated Northwind priority |
| R6 | "When bundling by a larger vendor comes up, what do you most want to understand about how it shows in the data?" | Brings the main competitive threat into his analytical register without asserting what he sees |
| R7 | "What would make the first 90 days a clear success from where you sit?" | Closes on his definition of success, which tells you what he will measure you against |

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has done sales-ops or set quotas | Negative stated, F7 | The acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Set sales quotas, or that volume targets are the same as quotas | Inflated form of F5 | F5's sentence at its own scope: "set annual volume targets with cross-org consensus". The limit is the pack's observation, not words for you: the material says volume targets, and draws its line at classic quota-setting |
| Drove or generated the ~$400M ARR uplift | Inflated form of F2 | F2's sentence at its own scope: you proposed the change, and it was credited with the uplift. A1's slots stay on how it was counted and which part was yours |
| Designed or ran a partner motion | Inflated form of F4 | F4's sentence at its own scope: a partner-level revenue model used in carrier negotiations. B4's slot stays inside the model |
| Owned go-to-market for a B2B product line | Inflated form of F1 | F1's sentence at its own scope: product strategy & ops. D4's slot asks only what was brought to market and which part was yours |
| Built or launched AI products | Inflated form of F6 | F6's sentence at its own scope: use of AI tools, daily. E2's slot asks only what for |

## Sources

**Provided:** the coach's message (JD highlights, Priya's background summary, Dan's profile description, a research note on Northwind's three stated priorities and bundling as the main competitive threat). No full JD, CV or Northwind values page was supplied. No dossier was present.

**Searches sent (all refused, nothing returned):**
- "Northwind Data company values principles" (refused)
- "Northwind Data interview process strategy GTM role" (refused)
- "Dan Kovac Northwind Data Director of Sales Strategy" (refused)

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Search sent and refused. Would have moved a values cheat sheet, but only if a values-style round were documented; none is, so no VAL bank exists |
| 2. `Northwind Data interview process` | unavailable | Search sent and refused. Would have moved loop structure and persona weights; weights rest on your description of one peer conversation |
| 3. `Northwind Data strategy` | skipped | The coach's research note supplies the three priorities and the main threat, which fix the CO and CASE rows |
| 4. `Dan Kovac Northwind Data` | unavailable | Search sent and refused. Would have moved the interviewer read; it rests on the profile description the coach supplied |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text → the six JD highlights become verbatim lines, mid-list requirements get covered, and any eligibility term becomes a gate row
- Priya's CV text → fit-snapshot evidence becomes her own sentences, and F1, F2 and F4 can move off adjacent-only
- The document that credits the ~$400M uplift, and the model or negotiation memo behind the revenue model → the artifacts that could lift F2 and F4 confidence toward `high`
- Priya's answers to the answer slots, especially A1, B4, D1 and D4 → each answer enters the snapshot as new quoted material and the rows that draw on it regenerate
- The recruiter's guidance on focus areas or a pre-declared deliverable → coverage beyond round-type priors, and a build section for any named deliverable
- Research permission → rows 1, 2 and 4 of the target table, and a documented loop. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and Dan's published talks and writing
- A `tuesday-dossier.md` → verified evidence and prohibited claims in place of the locally built list
