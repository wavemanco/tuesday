I'll read the reference files the skill requires before building the pack.
Searches were refused, so I'm building the pack from your JD and background alone. Writing the file now.
Python wasn't approved, so I'll make these edits with the Edit tool.
Femi, your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-7-denied-22eae92a/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 20 questions across six interviewer styles. I assumed Tobias is your hiring manager, since you didn't say.

I ran four web searches (Saltmarsh's values, interview process, strategy, and Tobias's background) and all were refused. The pack is built only from your JD and background. That means it has no values bank, no company-strategy questions and no read on Tobias himself. The Sources and upgrade-menu sections say what each gap cost and what would fill it.

- **Biggest risk:** B1 is the question I'd rehearse most: "You haven't worked on a game with in-app purchases. How would you run events for a title that lives on them?" It starts from your own plain acknowledgment, then adds a plan for what you'd learn first. It doesn't claim monetization experience.
- **Second risk:** B3 ("you've never led a team, so how do you coordinate four teams?") is the next one to rehearse. The JD says "coordinate", not "lead".
- **Where your material stops:** your sentences cover a weekly calendar for one title and presenting retention numbers, but not events, a second title, or owning the post-event review. The pack doesn't claim those. Several answers include a slot to fill in only if it's true.
- **Triage:** the pack has a prep order for the two days before Friday.

Say the word and I'll play the Skeptic on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Is Tobias the person you'd report to, or is he a skip-level or part of a panel? And did the recruiter mention any focus areas or a task to prepare? Either answer would reweight the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations (60-minute interview, Friday). Relationship assumed to be hiring manager, since you did not say; the persona weights below say what changes if that is wrong.
**Candidate:** Femi

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: **VAL** = values alignment (no bank here: no published Saltmarsh values were in hand). **EXP** = work-experience deep-dive, whether your claims survive scrutiny. **JD** = the stated responsibilities and requirements. **CO** = company and strategy knowledge (no bank here: no research ran). **CASE** = a live problem from the role.
- Provenance labels: `[grounded]` traces to your message or the JD, `[inferred]` is this pack's derivation, `[generic]` is a role-family pattern with no claim about you or Saltmarsh.
- The guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- An answer slot is an instruction for the interview, not a question for you now. Answer it from your own experience, or say plainly that the practice was not yours or did not exist.

## Prep triage

You have until Friday. Do these in order.

1. Say B1 aloud until it is boring, then B2 and B3 (the gaps you named, rehearsed with a plan).
2. Walk through A1 and A4 aloud, structure first: the first is the live-ops problem, the second is the post-event review the JD says you will own.
3. Record D1, your 90-second arc, and cut it to fit.
4. Work out what you actually know about how the retention numbers were counted, for C1.
5. Pick your reverse questions from section 11.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not events and not a second title. The words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on whether any drops were time-limited events, and on what a second title would change, likely. If any drops were events, say how they differed from your regular drops, in your own words; if all were regular drops, or there was only the one title, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The quote touches the calendar and does not show who you worked with on each drop. Answer slot: the JD's "on each update" line makes a probe on which teams you worked with and what your part was likely. If drops involved design, art, engineering or community, say which and what you did, in your own words; if you did not work with some of them, or the coordination was someone else's, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you set the measures or ran a review. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's "own" makes a probe on whether the numbers and any review were yours likely. If you reviewed a drop's results, say what the review covered, in your own words; if you presented numbers someone else produced, or no review was yours, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | Lead with the quote in its own terms: you wrote it, and QA still uses it, because a named document beats an adjective. Expect a probe on it, since a CV line with nothing inspected behind it invites one. Answer slot: if you also worked through the checklist with QA on each release, say how; if you wrote it and did not run it release by release, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | low | [inferred] | discovery | The quote gives the years and the studio, and does not say whether the game was live-service. Answer slot: the JD's live-service line makes a probe on that likely. If your main title was updated on an ongoing basis after launch, say how it ran, in your own words; if it was not, say so plainly and stay with the four years and the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on how much was you (F2's slot and bank F2 cover it). Lead with the quote's own terms: weekly, the main title, two years. A calendar export is the inspectable artifact that would raise this to high |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in terms, since the quote names retention numbers. Expect a probe on how they were counted. Say what you know of how they were counted; if you do not know, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The material carries one piece of writing, and it is this one. Reword only the quote: the checklist is a document you wrote that another team still uses. Nothing more is claimed about its reach or its readers |
| F9 | Monetization context for the KPIs a mobile live-ops role reports (role-family expectation, no JD line, unquoted) — generic | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work, and nothing added to make the gap feel smaller |
| F10 | Leading people (role-family expectation; the JD says coordinate teams, not lead them) — generic | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You stated it. Words: "I haven't led a team." The JD as supplied asks you to coordinate design, art, engineering and community teams, and does not list leading a team; that reading is the pack's observation, not words for you. Never a claim to have led or managed anyone |

## Persona table

Loop: one 60-minute session with Tobias, from your own words. No round was named as assessing values, so no values-style round is detected and there is no VAL bank. Weights start from the hiring-manager prior, then the JD's duties adjust them; no interviewer profile was available to adjust further.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live problems from the job: two events colliding, a bad drop, a post-event review | Highest. Hiring-manager prior, and the JD's duties are planning, coordinating and reviewing, all of which can be posed as live problems | Clarify, objective, options, recommendation, risks; think aloud; challenge one premise respectfully. Needs no claim about your past |
| Skeptic (bank B) | Quiet, persistent probing of the in-app purchase and team-leading gaps (F9, F10) and of how far F1, F2, F3 reach | Highest. Hiring-manager prior, and F9 and F10 are stated gaps | Rehearse B1 until boring. Bridges only from what you stated, a plain acknowledgment of the limit, and a ramp plan said as a plan |
| Data-Driven Prober (bank C) | Retention numbers and KPIs taken down to how they were counted | Medium. The JD names retention metrics and KPIs, and F7 and F3 give the probe something to take hold of | Know what you can and cannot say about how the numbers were counted; name the assumption you would defend least; say plainly what you do not know |
| Conversational (bank D) | Biography and warm questions about the checklist and what you play | Medium. An opening biography question is likely, and casual questions are still scored | A 90-second arc built from your own sentences; treat casual questions on JD topics as scored |
| Peer Evaluator (bank E) | Seams between design, art, engineering and community; credit across teams | Lower. The JD names four teams you would coordinate, but Tobias is assumed to be your manager rather than a peer. If he is a peer, this bank moves up | Seam principles rather than pretending to know the seam; "we" for context, "I" for contribution |
| Pressure (bank F) | Time-boxed challenges to why you, and to how much of the calendar was you | Lower. No sign in your material of a stress-style loop; F1 to F3 make the attribution probe likely in a friendly register too | Pause, restate, hold the position the quotes carry through two follow-ups, concede specifically |
| Values / Behavioral | Not detected | No loop source names one, and no published values were in hand | No bank; the upgrade menu says what would change that |

## Question banks

The deepest rehearsal in this pack, and the highest-ROI prep, is **B1**.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two events are due in the same week on our two titles, and engineering says only one can ship. How do you decide?" | CASE | [generic] | Structure it aloud: what each event is meant to move on its title, whether the block is scope or date, who has the authority to make the trade, what slips if each waits. Then recommend one, give the reason, and say who you would tell and what you would record. Challenge one premise politely, for example whether engineering's constraint is firm. The question needs no claim about your past, so the guidance makes none | The JD's two-titles calendar line (F1's requirement) posed as a decision; CASE because it scores structure; `[generic]` because it is a pattern for the problem, not a fact about Saltmarsh |
| A2 | "Sketch how you would build the live-events calendar for a title you have not worked on. What do you need to know first?" | CASE | [generic] | Clarify before structuring: the title's audience, what events it already runs, what the teams can ship and how often, what the post-event review reports today. Then objective, a first-quarter shape, risks. Asking for the existing post-event reviews first is a sound opening move. No claim about your past | F1's requirement and F6's content-calendar line, asked as a live problem; the "what do you need to know first" stem scores clarification, the case persona's core test |
| A3 | "An event goes live and a reward is not granting for some players. What happens in the next hour?" | CASE | [generic] | Structure: confirm who and how many are affected, decide with engineering whether to pull or patch, brief community on what to tell players, log what happened for the post-event review. Reference the release checklist only as a thing you would look at, not as a thing you owned; no claim about your past | Ties F4's requirement (release checklist with QA) and F2's coordination line into one live problem; CASE because it scores reasoning under time pressure |
| A4 | "How would you run the post-event review, and what decisions should come out of it?" | CASE | [generic] | Structure: the question the event was meant to answer, the measures decided before launch, what happened against them, what changes in the next event, who hears it. Answer slot: the JD's "own the post-event review" line makes a probe on whether you have run one likely. If you have reviewed a drop's results, say what it covered, in your own words; if you have not, say so plainly and answer as a plan | F3's requirement; CASE because it asks for a method; the slot is there because the quote carries presenting, not reviewing |
| A5 | "You run calendars for two titles with different audiences. How do you stop one title's calendar eating the other's engineering time?" | CASE | [generic] | Structure: make the competing demands visible in one view, agree a rule for trades with the teams before a conflict, name who breaks ties, and review after each event whether the rule held. Challenge a premise: are the titles drawing on the same engineers? No claim about your past | F1's two-titles requirement, the part of it your quote does not carry, asked as a decision so no past is presupposed |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. How would you run events for a title that lives on them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what your material does carry: "I presented the monthly retention numbers to the studio head." Then a plan, said as a plan and never as a past: what you would ask for first (the existing post-event reviews for both titles, which KPIs they report, which of those are revenue measures) and whom you would ask. Follow-up one, that retention is not revenue: concede it in those words and return to the plan. Follow-up two, whether you would own a revenue KPI you have not managed: say what you would need to learn first, give your own ramp timing only if you can honestly commit to it, and do not fold on the core of your answer. Concede specifically, hold what the quotes carry | F9 is the biggest stated gap, and this is the question most likely to be put to you in some form, so a rehearsed non-defensive answer changes the interview; JD because it scores a gap against the role |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Name the in-app purchase gap first, since you stated it: "I haven't worked on a game with in-app purchases." Say what you would do in the first weeks about it, as a plan. Do not volunteer a list of weaknesses; one named gap with a plan scores better than several. Pick one only if it is yours; if another part of the job is the one you would find hardest, say that instead | The Skeptic's stem; F9 and F10 are the candidates; JD because it scores honest self-assessment against the listed duties |
| B3 | "The role coordinates design, art, engineering and community on every update, and you've never led a team. How do you get four teams moving to your dates?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment: "I haven't led a team." Then what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's coordination line makes a probe on which of those four teams you worked with, and what your part was, likely. If you worked with some of them on drops, say which and what you did, in your own words; if you did not, or the coordination was someone else's, say so plainly and stay with the calendar you ran. Then how you would agree dates with teams who do not report to you, said as a plan | F10 and F2 together; the JD asks for coordination, so the question tests how the candidate would do it without line authority; JD tag because the requirement is stated |
| B4 | "Your last studio makes puzzle games. What changes when you run live events on our titles?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the facts as you stated them: four years as an associate producer at a puzzle-game studio, and the weekly calendar for your main title. Answer slot: the question probes whether the main title was live-service and whether any drops were time-limited events. If it ran on ongoing updates, say how, in your own words; if it did not, or none were events, say so plainly and answer as a plan: what you would ask the teams about the differences | F5 and F1; EXP because it tests how far the experience transfers |
| B5 | "Why live operations, and why now?" | EXP | [generic] | Give your own actual reason, in your own words; the material you gave carries none, so the pack supplies none. Keep it to two or three sentences and make it about the work. If the move is a step up from associate producer, say that plainly if it is your reason; if it is not, do not say it | The Skeptic's motivation-consistency probe; EXP because it tests whether the story hangs together |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the retention numbers every month. Walk me through how they were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start with the quote: "I presented the monthly retention numbers to the studio head." Then the four defend-the-number slots, each in your own words. How the numbers were counted: say what you know, and if you do not know, say so plainly. What the numbers were sensitive to. The assumption behind them you would defend least, named before he does. Whether you produced them or received them and presented them, plainly. Do your homework before Friday: find out what you can about how the retention was defined | F7 and F3; EXP because the question tests whether a headline metric survives its assumptions |
| C2 | "Retention dipped after a content drop. How do you tell whether the drop caused it?" | CASE | [generic] | Structure: confirm what the metric is and over what window, check whether the dip is in one cohort or all of them, check what else changed that week, compare against previous drops, say what evidence would change your mind. State plainly what you could and could not establish from the data alone. No claim about your past | F7's requirement as a diagnosis problem; CASE because it scores structure before answers |
| C3 | "Which KPIs should a post-event review report?" | JD | [generic] | Say what you would start from and why, then say you would confirm with Tobias what the two titles report today before changing anything. Name retention among them only as something you would look at; do not name measures you cannot explain. If you are asked about a measure you do not know, say so plainly | JD because the post-event review and its KPIs (F3's requirement) are stated duties; `[generic]` because it is a pattern, not a fact about Saltmarsh |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats, each a clause your sentences state: four years as an associate producer at a puzzle-game studio; for the last two years, the weekly content-drop calendar for your main title; the release checklist you wrote that QA still uses; the monthly retention numbers you presented to the studio head. Close with your own reason for wanting live operations; the pack supplies none. Do not add scope, titles or results the sentences do not state | A biography question is the usual opener; EXP because it tests whether the story is consistent with what you can defend; the beats are those the F-rows carry |
| D2 | "What are you actually playing in mobile live-ops these days?" | JD | [generic] | Name the games you actually play and one event mechanic you noticed in each, in your own words. If you play none, say so plainly and name how you are studying them now. Do not name a game you do not play | The Conversational stem; casual questions on the job's own subject are scored; JD because the role is a mobile live-events role |
| D3 | "Tell me about the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Beats the quote states: you wrote it, and QA still uses it. Tell them in your own words. Answer slot: the JD's "manage the release checklist with QA" line makes a probe on what it covers and how you worked with QA through a release likely. If you ran it with QA release to release, say how; if you wrote it and did not run it, say so plainly and stay with having written it | F4 and F8; EXP because the question tests what was actually yours; the quote is the one inspectable-sounding artifact in your material |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How do you handle credit when an update spans design, art, engineering and community?" | VAL | [generic] | Principles first: say whose work was whose, name the other teams in the same breath as yours, "we" for the context and "I" for your contribution. Answer slot: if you have an example from your calendar, say what happened and what part was yours, in your own words; if you do not, say so plainly and give the principle only | F2's four-team line from the JD; VAL tag, since credit is a behavioral probe, though no published Saltmarsh values were in hand to tie it to |
| E2 | "Engineering says your drop date is not realistic and design says it cannot move. Where is the seam?" | CASE | [generic] | Propose principles, not a claim to know their seam: ask each side what is fixed and what is flexible, bring the trade to whoever owns the decision, write down what was agreed. Do not pretend to know how Saltmarsh's teams split the work; ask. No claim about your past | F2 and F10 as a live disagreement; CASE because it asks for reasoning, with the peer register |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has run a live-ops team on a monetized title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Pause, restate the question, then hold what the quotes carry: the weekly calendar for two years, the checklist QA still uses, the monthly retention numbers you presented. Hold through two follow-ups. Concede specifically when pushed: "I haven't led a team, and I haven't worked on a game with in-app purchases." Do not fold on the core and do not claim the other candidate's experience | F9 and F10 under time pressure; JD because it tests the case for the role against its gaps |
| F2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the sentence: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours, such as who chose the content and who set the dates, in your own words; if others set the content or the dates, say so plainly and stay with what you ran. A precise smaller claim survives the second follow-up and a larger one does not | F6 and F2; EXP because the attribution probe exists to catch inflation |

### Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A2, A5, B4, D1 |
| "coordinate design, art, engineering and community teams on each update" | A3, B3, E1, E2 |
| "own the post-event review and the KPIs it reports" | A4, C1, C2, C3 |
| "manage the release checklist with QA" | A3, D3 |
| "3+ years producing live-service games or apps" | B4, B5, D1 |
| "experience running a content calendar" | A2, D1, F2 |
| "comfortable with player-retention metrics" | C1, C2, C3 |
| "clear written communication" | — none: the JD does not make it a spoken question. D3 and the checklist are your written-work example if it comes up, and the pack does not coach a written sample here |

Type coverage across the 20 questions: CASE 7, JD 6, EXP 6, VAL 1 (E1); no CO question, because no research ran.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first quarter look like for this role across the two titles?" | Turns the interview toward the work and tells you what is expected on day one, which scopes your ramp plan in B1 |
| R2 | "Which KPIs does the post-event review report today, and which of them would I own?" | Matches the JD's "own the post-event review and the KPIs it reports" line and gets the revenue question onto the table in his words, not yours |
| R3 | "How do design, art, engineering and community plan together today, and where does the calendar run into trouble?" | Shows you are thinking about the coordination the JD asks for and gets the real friction named |
| R4 | "How does the release checklist work with QA today, and what would I inherit?" | Follows F4's JD line and signals that you would work with what exists before changing it |
| R5 | "How do the two titles differ in how their events are structured, and how would my time split between them?" | Probes the two-titles line directly and shows you are planning for it |
| R6 | "What went wrong with an event recently, and what did the team change afterwards?" | A question about how the team learns, which is the post-event review's whole purpose; it also invites an honest answer rather than a prepared one |

No question here is tied to Tobias's own career path, because no profile was available; see the upgrade menu.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led or managed a team | A negative you stated, F10 | Your sentence: "Never led a team, and never worked on a game with in-app purchases." The plain acknowledgment it supports: "I haven't led a team." |
| Has worked on a game with in-app purchases, or owned a revenue or monetization KPI | A negative you stated, F9 | The same sentence, and "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you presented the retention numbers. A4's slot asks only whether you reviewed a drop's results |
| Managed the release checklist with QA on every release | Inflated form of F4 | F4's quote at its own scope: you wrote it, and QA still uses it. D3's slot asks only how you worked with QA through a release |
| Produced a live-service game for 3+ years | Inflated form of F5 | F5's quote at its own scope: four years as an associate producer at a puzzle-game studio. The limit is the pack's observation: your material does not say whether the title was live-service. B4's slot asks only how it ran |

## Sources

Provided documents: the job description and your background as pasted in your message. No dossier was present.

Searches (all refused; nothing came back, so nothing from any of them is used):

- "Saltmarsh Games values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games mobile studio news strategy" — refused
- "Tobias Wrenfield Saltmarsh Games" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have fed a values cheat sheet and VAL questions; neither is in this pack |
| 2. Saltmarsh Games interview process, live operations | unavailable | Would have named the loop's rounds; the loop here rests on your own words, one 60-minute session with Tobias |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have fed CO questions and a grounding brief; the CO bank and the brief are absent |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have fed the interviewer read and a reverse question tied to his career path; both are absent |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is your manager, a skip-level or one of a panel, and anything the recruiter said about focus areas or a task → reweights every bank, and adds a build section if a task was announced
- The recruiter's description of the loop → confirms whether other sessions follow this one, and whether a values round is among them
- Saltmarsh's published values or careers page, pasted → a values cheat sheet and VAL questions with mapped stories or selection scaffolds
- Tobias's public talks, posts or profile, pasted → an interviewer read, persona weights adjusted to his public style, and a reverse question tied to his career path
- A recent strategy note or news on the two titles, pasted → CO questions and a grounding brief; naming the two titles alone would let a search target them if search is available
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, and it needs search access that was refused here
- Your answers to the slots in F1, F2, F3, F4 and F5 → each becomes quoted evidence and upgrades those rows and the banks that draw on them
- An inspectable artifact: a calendar export, the checklist itself, or the retention deck → raises F6, F4 and F7 from medium to high
- How the retention numbers were counted → upgrades C1 and F7
- A tuesday-dossier.md from an earlier evidence pass would add verified evidence and prohibited claims; the pack stands without one
