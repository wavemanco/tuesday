I'll read the references the skill requires before writing anything.
The prep pack is built and saved. I'm sending the summary now.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-4-denied-60f3d0ec/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a 45-minute hiring-manager round from your dossier and your message. The two Quartzline searches were refused in this session, so nothing about the company beyond the dossier is in it. The company-knowledge and values questions (B4, D3, G1, G2) are generic as a result. A1 is the highest-ROI prep: the underwriter's own "never held the title or owned a roadmap" objection.

Say the word and I'll play the hiring manager on A1, with at least two follow-ups that react to what you actually say.
I can also save an updated `tuesday-dossier.md` with a `pack_feedback` section recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack — Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. **Interviewer:** the hiring manager, name not given. **Built from:** your `tuesday-dossier.md` (conditional_go) and your message. No company research was available; see Sources.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. The banks run in weight order, heaviest first. **The highest-ROI prep in this pack is A1.** The underwriter named that objection from evidence you confirmed, so it will arrive in some form, and A1 gets the most follow-up levels.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values; here the questions are generic, since no values were available |
| EXP | Whether the claims about your past survive scrutiny, including what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script: say it in your own words, and rehearse only what you actually did. An answer slot is an instruction for the interview, not a question for you now: answer it truthfully on either branch. Provenance labels: `[grounded]` traces to your dossier or your message, `[inferred]` is this pack's derivation, `[generic]` is a role-family pattern with no claim about you or Quartzline.

## Fit snapshot

Requirements are the dossier's `role_profile` lines, standing as the JD. The three evidence sentences below are the only sentences about your past that this pack draws on; the dossier's decision summary describes you more broadly than any verified entry does, so the pack does not use it for facts about you.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's strategy is `bridge`: adjacent evidence, positioned as adjacent and never as PM experience. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through scoping, requirements, architecture, UAT and go-live, and I wrote the integration playbook my team uses." The pack's observation is that your material shows integration leadership and an authored playbook, not a PM title or a product's ownership, so the limit is said aloud before it is asked for: "That is adjacent to product management, and I haven't held the title." That acknowledgment is sourced by `prohibited_claims: "Having held a product manager title or role"` |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this gap: the `uncertain_or_weak_areas` entry "Owning a roadmap and prioritization authority (R1 sub-claim)" has `allowed_interview_strategy: acknowledge_gap`, and `prohibited_claims` lists "Having owned a product roadmap". Words: "I haven't owned a roadmap." Then how you would learn it, said as a plan and never as a past: ask which decisions are the PM's and which are the squad leads', and ask where adoption stands today. No bridge is offered on this row |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | The dossier lists R2 as a high-priority requirement but carries no weak-area entry for it, so this grading is the pack's. Your sentence says client integrations of the vendor's REST APIs taken through go-live; the pack's observation is that it does not say a product was shipped. Words: the sentence at its own scope. Answer slot: the JD's must-have makes a probe on what you shipped likely. If any part of one of those go-lives was a change to the API itself, say what and whose it was, in your own words; if none was, or you do not know, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | Both sentences touch REST APIs and a written playbook, and neither says whether you worked with API documentation or schemas. Answer slot: the JD names API docs and schemas, so expect a probe on them. If you worked with either, say which and what you did with it; if you did not, say so plainly and stay with the REST API integrations you led |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The sentences carry client-facing work and feeding client evidence to product; they do not say who from engineering or sales was involved. The second is confirmed with limited inspectable proof, so expect a probe on it. Words: the two sentences at their own scope. Answer slot: if engineers or sales colleagues were part of those integrations or sessions, say who and what you did with them; if they were not, say so plainly and stay with the client work |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier's `uncertain_or_weak_areas` entry for R5 carries `allowed_interview_strategy: clarify`, and no verified entry speaks to it. Words are an answer slot: the JD's "Agile delivery experience" makes a probe likely. If you have worked that way, say how in your own words; if you have not, say so plainly and say what you would want to confirm about how Quartzline defines it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | Confirmed, with limited inspectable proof: expect a probe, and volunteer the limit before it is extracted. The sentence says sessions that fed client evidence to product, not discovery with integration partners. Words: the sentence at its own scope. Answer slot: if any of those sessions was discovery with partners, say how it ran, in your own words; if they were something else, say so plainly and describe them as you ran them |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The first sentence names requirements and architecture among the stages you led; neither says what form they took or who built from them. Answer slot: the JD names specs and two squads. If requirements you wrote went to an engineering team to build from, say what form they took; if they did not, say so plainly and stay with the integrations you led. Prioritization for a squad is not on offer here (see section 13) |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | No sentence speaks to it, and you have stated no absence. Answer slot: the JD names adoption metrics. If you tracked usage or adoption of anything, say what was counted and how; if you did not, say so plainly and say what you would define first |

## Persona table

The loop rests on your own words: one 45-minute conversation with the hiring manager. Weights start from the hiring-manager prior (Case/Strategist and Skeptic) and move on what the dossier shows.

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title gap, roadmap ownership and squad authority | 5. The hiring-manager prior puts it first, and the underwriter named a Skeptic-shaped objection (A1) and recorded two further weak areas (F2, F6) | Rehearse A1 until it is boring; bridge only from the F1 quotes at their scope; use the plain acknowledgments where the dossier sources them (F2); where a probe lands on an answer slot, take either honest branch |
| Case/Strategist | A live problem from the role: diagnose adoption, split two squads' priorities, outline a spec | 4. The hiring-manager prior; the role's responsibilities (F7, F8, F9) are the natural problem sources | Clarify first, then objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully; reason as how you would, never as how you did |
| Data-Driven Prober | Line-by-line on your evidence: how 30+ was counted, what the sessions produced | 3. Two of your three evidence sentences carry a count or an unverified limit (F1, F7) | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know; name the assumption you would defend least before they do |
| Conversational | A friendly "walk me through the journey" that is still scored | 3. Hiring managers open this way, and the title gap makes the arc a scored answer (F1) | A 90-second arc built only from your three quoted sentences, adjacent limit named first |
| Pressure | Interrupts and time-boxes: "how much of that was you", "why would the squad leads back you" | 2. Lower for a 45-minute manager conversation, but the dossier's authority risk is exactly what this style presses | Pause; restate; hold through two follow-ups; concede the specific limit the dossier sources, never the core of what you led |
| Values/Behavioral | Open prompts about hard truths and customers over metrics | 2. No values round is documented in your material and no published values were available, so these are generic rehearsal | Pick a real instance with a named stake; if none comes to mind, say so plainly |
| Peer Evaluator | Not weighted: the two squad leads are future peers, but your material names no peer session in this loop | Not applicable to this session; if the loop adds a squad-lead conversation, the pack regenerates with it | — |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; dossier `prohibited_claims: "Having held a product manager title or role"` and `prohibited_claims: "Having owned a product roadmap"` | The highest-ROI rehearsal, and the underwriter's own objection. Level 1, concede first: "I haven't held a PM title and I haven't owned a roadmap." Then the adjacent case at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through scoping, requirements, architecture, UAT and go-live, and I wrote the integration playbook my team uses. That is adjacent to product management, not the same job." Level 2, "isn't that just delivery work?": answer from the quote's own stage names and stop. Answer slot: which requirements or architecture decisions in those integrations were yours to make; if none were, or it was not yours to decide, say so plainly and stay with the integrations as you led them. Level 3, "so why not the person with the seat time?": do not argue seat time; name the limit and the plan, which is to ask which decisions belong to the PM and which to the squad leads. Hold the concession through all three levels and never add "effectively I have been doing PM work", which claims what the dossier prohibits | The underwriter named this as the likeliest objection from evidence you confirmed, and F1 and F2 are where it presses hardest. JD because it scores the title requirement; the delivery is Skeptic |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier `uncertain_or_weak_areas` entry "Owning a roadmap and prioritization authority (R1 sub-claim)" with `allowed_interview_strategy: acknowledge_gap` | Name the weakest part plainly rather than a safe one: roadmap ownership. "I haven't owned a roadmap." Then the ramp, said as a plan: what you would ask in the first weeks, namely which decisions are the PM's and where adoption stands today. Do not bridge this one; the underwriter looked and found nothing | F2 is the row this answers, and the dossier's `acknowledge_gap` strategy is binding. JD because it scores honest self-assessment against the listed job |
| A3 | "Tell me about the nearest thing in your background to shipping an API or platform product." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Tell it at the quote's own scope: the integrations you led, through go-live. Name the limit yourself: these were client integrations of the vendor's REST APIs. Answer slot: if any part of one of those go-lives was a change to the API itself, say what and whose it was; if none was, or you do not know, say so plainly and stay with the integrations | R2 is a must-have, and F3 shows your material stops at integrations. JD because it scores R2 directly; open prompt, so the theme comes from the JD |
| A4 | "Tell me about working inside an agile delivery cycle." | JD | [generic] | The `clarify` strategy: nothing in your verified evidence speaks to this, so keep the answer question-shaped. Answer slot: the JD's "Agile delivery experience" makes this probe likely. If you have worked that way, say how in your own words; if you have not, say so plainly, then say what you would want to confirm about how Quartzline defines it | F6 is open, not absent, so the guidance leaves room for either answer. JD because R5 is a stated preference |
| A5 | "You'd be owning the roadmap and driving delivery with two engineering squads. What makes you confident you can?" | JD | [grounded] dossier `prohibited_claims: "Having set prioritization for an engineering squad"` | Do not answer with confidence you cannot back. "I haven't set prioritization for an engineering squad." Then the plan: ask which decisions are the PM's and which belong to the squad leads, and how the two squads' priorities are settled when they collide. Hold that the question you are asking is the real one, since the dossier records the authority as asserted but not evidenced | F2 and F8, and the dossier's condition that squad authority verifies in interviews. JD because the squad relationship is a stated responsibility |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Suppose adoption among newly onboarded partners has flattened. What do you need to know first, and how would you diagnose it?" | CASE | [generic] | Clarify before structuring: how adoption is defined today and what the baseline is (the dossier records it as unknown, so say you would ask). Then objective, segments (partner type, integration stage), hypotheses, metrics, risks. You may use the stage names in your own sentence (scoping through go-live) as a lens for where to look, as a structure and not as something you observed. Think aloud; challenge one premise | F7 and F9: discovery and adoption metrics are named responsibilities. CASE because the answer is structure, not history |
| B2 | "A large partner wants a new endpoint, sales wants a webhook, and one squad wants to pay down versioning debt. How do you decide?" | CASE | [generic] | Ask first who holds the decision (the open authority question), then name criteria, the evidence you would want from each side, how you would disagree and commit. Reason as how you would; do not borrow your past for authority your material does not show | F2 and F5. CASE because it tests prioritization reasoning without needing prioritization history |
| B3 | "Walk me through what goes into a spec for deprecating an API version that partners still use." | CASE | [generic] "Wrote the internal integration playbook her team uses" | Structure it generically: who is affected, migration path, timeline, communication, success measure, rollback. If asked for your own writing, name the integration playbook as a playbook, not a spec | F8 and F4. CASE; the playbook is the one inspectable writing artifact in your material |
| B4 | "What do you think makes a partner-facing API platform succeed or fail, and what would you want to learn about Quartzline's partners first?" | CO | [generic] | Say what you would want to learn rather than reciting anything about Quartzline, since no company research was available. A short theory of partner platforms, then two things you would ask | `[generic]` because research could not run; it becomes `[grounded]` with the upgrade-menu research line |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ client integrations — how was that counted, and which parts were yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | State it as the sentence has it: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot, four parts, each in your own words: how the 30+ was counted; what the count is most sensitive to; the assumption behind it you would defend least; and which part of each integration was yours rather than your team's. If you do not know how it was counted, say so plainly | The headline figure in F1, F3 and F5 is the magnet target; the weakest-assumption move turns a gotcha into credibility. EXP because it tests attribution |
| C2 | "Walk me through one of your quarterly roadmap-input sessions." | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Describe a session as you ran it, at the sentence's scope. This is the medium-confidence claim, confirmed with limited inspectable proof, so volunteer the limit early. Answer slot: if a roadmap decision traces to a session, say which; if you cannot trace one, or do not know, say so plainly and stay with the sessions as you ran them | F7 and F5. JD because it scores discovery and stakeholder work; EXP in delivery |
| C3 | "What would you track to know a partner API is succeeding, and which assumption behind it would you trust least?" | JD | [generic] | Define terms before measures (who counts as a partner, what counts as active), then two or three measures, then your weakest assumption. Say plainly that you do not know how Quartzline measures it today. No claim about what you have tracked | F9; adoption metrics are named in the JD |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the journey from client integrations to this role." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each at its sentence's scope: the integrations you led; the playbook you wrote; the roadmap-input sessions. Say the limit before the turn: adjacent, not PM experience. The reason for the move is yours, in your own words; say nothing you cannot stand behind | F1 and F7. EXP because it is your story; casual register, still scored |
| D2 | "What are you actually playing with in API tooling these days?" | JD | [generic] | Answer slot: the JD names API docs and schemas. If you work with either today, say what and how; if you do not, say so plainly and say what you would read first | F4 |
| D3 | "Why Quartzline, and why this role?" | CO | [generic] | Your own reasons, in your own words. Use only what the JD says about the role (the partner-facing API platform, two engineering squads) and what you have actually looked up; admit what you have not been able to verify | Motivation consistency; `[generic]` because no company research was available |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, restate, anchor in the sentence: "I led them." Hold through two follow-ups. Answer slot: say which part was yours and which was your team's, in your own words; if you do not know how to split it, say so plainly. Concede specifics, never the core of what you led | F1 and F3. EXP because it tests attribution under time pressure |
| E2 | "Why would the two squad leads back your roadmap when you've never held a PM title?" | JD | [grounded] dossier `prohibited_claims: "Having held a product manager title or role"` | Hold-then-concede: "I haven't held a PM title." Then the plan: you would not assume backing; you would ask what is decided where. Do not claim authority you have not seen evidenced | F1, F2 and the authority risk. JD; Pressure in delivery |

### G. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A generic stem; none of your three sentences carries a story for it |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, what it cost, who agreed. If no such time comes to mind, say so plainly, then say how you would weigh it | A generic stem; no sentence carries a story for it |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 (3+ years PM experience) and the roadmap/prioritization sub-claim | A1, A2, A5, B2, D1, E2 |
| R2 (shipped API or platform products) | A3, C1 |
| R3 (technical fluency) | D2, B3 |
| R4 (stakeholder management) | C2, B2, E1 |
| R5 (agile delivery) | A4 |
| Run discovery with integration partners | C2, B1 |
| Write specs, drive delivery with two squads | B3, A5, E2 |
| Define and track adoption metrics | B1, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier records the authority as asserted in the JD but not evidenced. The answer tells you whether the seat's prioritization authority is real |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier records adoption metrics as a named responsibility with no baseline stated. It reads as diligence and tells you what you would be judged on |
| 3 | "When the two squads' priorities collide, who decides today?" | Tests the same authority risk from the working side, and shows you have thought about the seam |
| 4 | "What does discovery with partners look like today, and who runs those conversations?" | The JD lists discovery; nothing in your material says how it runs now. Tells you whether the seat inherits a working process or builds one |
| 5 | "What would make you hesitate about a candidate coming from integration work rather than a PM seat?" | Gives you the chance to meet the A1 objection with the hiring manager's own words, in the room. Ask it only if you are ready to hear it |
| 6 | "What would you want this hire to have changed by the end of the first six months?" | A generic success-definition question; it surfaces what the hiring manager will actually score |

## Prohibited claims

Absolute: no guidance cell, slot, bridge or drill feedback asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | F1's two sentences at their own scope, plus the plain acknowledgment sourced by `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a PM title." |
| Having owned a product roadmap | Dossier `prohibited_claims`, and the `acknowledge_gap` area for the R1 sub-claim | "I haven't owned a roadmap," then the plan in F2. No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad," then the plan in A5. No slot |
| Having shipped an API or platform product | Inflated form of F3 | F3's sentence at its own scope. The limit is the pack's observation: your material says client integrations taken through go-live, not a product shipped. A3's slot stays inside the integrations |

## Sources

- Provided documents: your message (round type, length, the hiring manager as interviewer) and `tuesday-dossier.md`, version 1.1. The dossier's `handoff_to_mock_interview` supplied the verified evidence, the weak areas and their strategies, the objection, the risks, the employer questions and the prohibited claims; its `role_profile` supplied the requirements and responsibilities; its `decision` was read as context only. Its `unknowns` are the underwriter's analysis and were used only to seed reverse questions. No `evidence_map` was present.
- Searches sent: "Quartzline company values" — refused; "Quartzline partner API platform strategy news" — refused. Nothing came back, so nothing about Quartzline beyond the dossier is in this pack.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have moved the VAL bank (G1, G2) from `[generic]` to published-value themes and decided whether a values cheat sheet applies |
| 2. `Quartzline interview process` | skipped | Your own words fix the loop: one 45-minute hiring-manager conversation, so persona weights and loop structure are decided |
| 3. `Quartzline strategy` / recent news | unavailable | Would have moved the CO bank (B4, D3) from `[generic]` to grounded strategy questions |
| 4. interviewer name | n/a | No name was given, so there was no query to form |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` supplies the requirements and responsibilities |

## Upgrade menu

- Search access → Quartzline's published values, strategy and loop: B4 and D3 become `[grounded]`, G1 and G2 can be themed on published values, and a values cheat sheet is added only if a round for it is documented. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and recent org context
- The hiring manager's name or profile → an interviewer read, reweighted personas and a reverse question tied to their path
- The recruiter's prep note → any pre-declared deliverable or stated focus areas; the pack assumes none
- Your own answers to the slots in F3, F4, F5, F6, F7, F8 and F9, said outside a drill → each is quoted into the snapshot and those rows regenerate
- A confirmed sentence in your own words on how long you led integrations → the dossier's decision line summarizes your tenure, but no verified entry carries it, so the pack cannot use it
- A roadmap-input session agenda or the notes you sent to product → the inspectable artifact that would lift F7 and C2 from medium to high
