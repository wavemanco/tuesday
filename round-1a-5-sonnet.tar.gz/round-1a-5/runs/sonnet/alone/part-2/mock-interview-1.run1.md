I'll read the reference files the skill requires before writing anything.
The pack is written and saved. The only thing left is the message presenting it.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-1-denied-4d7a0078/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. It has 21 questions across six personas, weighted for a peer conversation with a "relentlessly data-driven" pricing and monetization person. The weights are Prober 5, Peer Evaluator 4, Case/Strategist 4, Skeptic 4, Conversational 2, Pressure 2.

- **Web search was refused.** All three searches (company values, Dan's public footprint, current strategy) were denied. Everything about Northwind comes from your research note. The Sources section lists the refusals, and the interviewer read rests only on your description of Dan.
- **No values cheat sheet.** A single 60-minute peer conversation isn't a values round, and no published values were retrieved.
- **Highest-ROI prep is D1.** It's the sales-ops and quota-setting gap, asked by a Director of Sales Strategy. F2 is the same question under time pressure. The pack never recasts "annual volume targets" as quotas, and it never turns "uses AI tools daily" into building AI.

Say the word and I'll play Dan on D1, with live follow-ups and feedback against that question's own guidance cell.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer who reports to the same VP. **Round:** one 60-minute conversation, per your note. This is a first version, not a regeneration.

Built on two assumptions you can overturn: the loop is the single session you described, and web research was unavailable (all three searches were refused), so company facts come only from your research note.

## How to use this pack

- **Personas describe how a question arrives; types describe what it scores.** Rehearse the delivery as well as the content.
- **Guidance is scaffolding, not a script.** Everything the guidance says about your past rests on a sentence quoted in its own row. Where the material does not show something, the cell is an answer slot: say what is true in your own words, and where the practice was not yours or never existed, say so plainly.
- **Highest-ROI prep: D1**, with F2 as its time-boxed version. A Director of Sales Strategy will see the sales-ops gap quickly. A rehearsed, non-defensive answer changes the conversation.
- **The five type tags:**

| Tag | Meaning |
|---|---|
| VAL | Past behavior against the company's published values (none retrieved for this pack) |
| EXP | Whether a line of your background survives scrutiny, and what was actually yours |
| JD | A stated responsibility or qualification in the role |
| CO | Knowledge of the company's strategy and competition |
| CASE | A live problem from the role, reasoned aloud |

Dual-tagged questions carry one tag in the Type column. The rationale names the second.

## Fit snapshot

Requirements are quoted from the JD highlights as you gave them. Evidence is quoted from your summary of the candidate. Where a row's wording has a limit, the limit is stated as the pack's own observation and not as words for you to say.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market, with nothing inspected behind it. The words stay at that scope: "For nine years I worked in product strategy and ops at a large consumer-tech company, after two years in strategy consulting." Answer slot: the JD's own-GTM line makes a probe on how close that work came to taking a product to market likely. If any of it did, say which part and what was yours to decide, in your own words; if none did, or none of it was yours, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | Your material says the change was proposed and credited with the uplift. It does not say who credited it, who built or measured it, or how the opportunity was found. The words stay at that scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's whitespace line makes a probe on how the opportunity was identified likely. If it came out of an analysis you ran, say what you looked at; if it did not, say so plainly and stay with the proposal. The figure also raises four slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer each in your own words, and where you do not know, say so plainly |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | low | [inferred] | discovery | A stated skill, with no analysis named. The words stay at that scope: "I'm skilled in SQL and Tableau." Answer slot: the JD's independent-analysis line makes a probe for one specific analysis likely. If you ran one yourself, say the question it answered and what you did with the result; if your use was lighter than that, or someone else ran the analysis, say so plainly and say how you use the tools |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says you built a partner-level revenue model that was used in carrier negotiations, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." It does not say you designed the partner relationship itself, and section 13 lists that wording as not coached. Answer slot: the requirement is marked required, so expect a probe on the partner relationship beyond the model. If any part of it was yours to shape, say which and how you decided; if the model was the extent of it, or the rest was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap in the wording, but a line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: you set annual volume targets, with cross-org consensus. The quote does not say how consensus was reached or whether anyone disagreed, so anything past it is an answer slot (B4) |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | discovery | The quote shows daily use of AI tools. It does not show which tools or for what, and it does not show building AI products. The words stay at that scope: "I use AI tools every day." Answer slot: the JD's plus line, and the Compass launch in your research note, make a probe on what that use looks like likely. Say which tools and for what work, in your own words; if the use is general rather than part of your analysis work, say so plainly |
| F7 | Familiarity with sales-ops mechanics such as quota design (role-family expectation, unquoted, not in the JD highlights) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the absence is stated in your material. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. The F5 quote is about annual volume targets, which the pack does not treat as quota-setting. No answer slot, and nothing added to make the gap feel smaller |

Proposed wording in the Gap and bridge column — pending your approval.

## Reading the interviewer

Public-footprint rule applied: only what you supplied from Dan's profile. No talks, posts or articles were retrieved, because search was refused.

| Signal | Source | What it likely means for this conversation | Provenance |
|---|---|---|---|
| "relentlessly data-driven" | Dan's profile, as you described it | Expect every number to be probed to its inputs and assumptions, the ~$400M ARR figure first (A1, A2, F1). Derived from the persona-weighting rule for self-described data-driven interviewers | [inferred] |
| "pricing and monetization roles" | Dan's profile, as you described it | Expect cases tilted to pricing, packaging and unit economics (C3). Pricing is Dan's native language, so candor beats bluffing there. Derived from the persona-weighting rule for a pricing or monetization career spine | [inferred] |
| "one early-stage-startup chapter" | Dan's profile, as you described it | Possible probes on pace and scrappiness against nine years at a large company (D4). The material carries no builder-story sentence, so the pack coaches no such story. Derived from the persona-weighting rule for startup chapters, scaled down because it is one chapter | [inferred] |
| Peer, same VP | Your note | Collegial packaging of hard questions, and a test of whether you reduce or add to Dan's load (B1, B3). Dan has a stake in how you split the work | [grounded] |

Mirror opportunities. Shared vocabulary: revenue and ARR. F2 ("proposed a store-surface change credited with a ~$400M ARR uplift") and F4 ("built a partner-level revenue model used in carrier negotiations") both sit in revenue language that Dan's pricing and monetization path also uses. The pack offers no shared career jump, because no row's evidence carries a candidate-side version of Dan's startup chapter. It also coaches no shared-identity angle.

## Persona table

The loop is one 60-minute session with a peer, per your note, so weights rest on relationship priors adjusted by the interviewer signals above, not on a documented company process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (rehearsal method) | Provenance |
|---|---|---|---|---|
| Data-Driven Prober (bank A, 5 questions) | Line-by-line probes of the ARR figure, the revenue model and the SQL claim | Highest. A peer prior plus Dan's self-description as "relentlessly data-driven" | Know what you can and cannot say about how each number was counted, and say plainly when you do not know. Name the weakest assumption before Dan does | [inferred] |
| Peer Evaluator (bank B, 4 questions) | Seam-splitting between this role and Sales Strategy, "what do you need from me", credit across teams | High. Dan is a peer reporting to the same VP, so every hard question can arrive in collegial form | Reciprocity framing. Propose seam principles instead of pretending to know the seam. Show spine and tact together | [generic] |
| Case / Strategist (bank C, 4 questions) | Live problems from the research note: bundling threat, three priorities, Compass, partner motion | High. A GTM-strategy role invites cases, and Dan's pricing spine tilts them toward packaging and unit economics | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully per case | [inferred] |
| Skeptic (bank D, 4 questions) | The sales-ops gap, B2B knowledge, why this move, operating without a playbook | High, and the home of the pack's highest-ROI question (D1). Your own summary states the sales-ops absence, which Dan's function makes hard to miss | Rehearse D1 until it is boring. Bridge only with adjacent evidence you actually have. Give a concrete ramp plan | [grounded] |
| Conversational (bank E, 2 questions) | "Walk me through the journey", and a casual AI question | Medium. Peers often open informally, and casual questions on a JD plus-skill are still scored | A 90-second arc built from one sentence. Treat the AI question as scored | [generic] |
| Pressure (bank F, 2 questions) | A time-boxed "how much was actually you" and "why you" | Low to medium. A peer data-driven interviewer is more likely to probe than to stress, but the ARR attribution question can arrive abruptly | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically | [generic] |
| Values / Behavioral (no bank) | Not expected | Low. A single peer conversation is not a values round, and no loop source names one. No published values were retrieved, so no values cheat sheet is built | If values come up, use the selection scaffolds in B4 and D4 | [generic] |

## Question banks

### Bank A — Data-Driven Prober (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The quote gives you three things: you proposed the change, it was credited with the uplift, and the figure is ~$400M ARR. Say those in your own words. Answer slot: say how the figure was counted, what it is sensitive to, and which part was yours. Where you do not know how it was counted, say so plainly instead of reconstructing a method | F2 is the pack's headline number, so a prober will start here. EXP because it tests whether the claim survives scrutiny, with a JD whitespace angle |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name, in your own words, the assumption you would defend least before Dan does. Answer slot: if you know the assumptions behind the credit, name the weakest one; if you do not know how the credit was assigned, say that plainly and say who would. Never name an assumption you cannot repeat under a second question | The follow-up to A1 on F2. Converts a gotcha into a credibility gain. EXP because it scores self-knowledge about a number |
| A3 | "The role means running independent analysis in SQL and Tableau. Tell me about an analysis you ran yourself." | JD | [grounded] "skilled in SQL/Tableau" | No sentence of yours carries a specific analysis, so this is a selection scaffold. Pick one analysis where the question was yours and you ran the work yourself; say the question, the data you used, what you found and what changed because of it. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach one | F3 is the thinnest row against a hard requirement, and a data-driven peer will test it directly. JD because it scores the stated qualification |
| A4 | "You built a partner-level revenue model. What went into it, and which input was softest?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold the scope of the quote: you built it, and it was used in carrier negotiations. Answer slot: name the inputs in your own words and the one you trust least; if you do not know how the model was used beyond the negotiations, say so rather than extending it | F4 is the pack's closest evidence on the partner requirement and a prober will test it. EXP because it checks attribution, with JD relevance |
| A5 | "How do you know when an AI-generated number is wrong?" | JD | [grounded] "uses AI tools daily" | Your quote supports daily use of AI tools, so tell it at that scope. Answer slot: if you have a check you actually run on AI output, describe it in your own words; if you do not have a settled one, say so plainly and say what you would put in place first. Do not describe building or training AI systems unless your material shows that | The JD's plus line meets a data-driven interviewer, who will want validation habits, not enthusiasm. JD because it scores the AI plus. F6 is the row it presses |

Proposed wording in this table — pending your approval.

### Bank B — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. For a new product line, what's yours, what's mine, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose seam principles instead of claiming to know the seam: one owner for each decision, shared data definitions, an agreed way to escalate to the VP you both report to. Frame your side from the JD's own line, GTM strategy for the new product lines, and ask Dan where the current boundary sits. Answer slot: if disagreements came up while setting those annual volume targets, say how they were handled; if none did, say so plainly and stay with the consensus | This is the peer test, and it also covers the "own GTM strategy" requirement. F5 is the row it draws on. JD because it scores the stated ownership, with a Peer Evaluator delivery |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Describe your part in the quote's verb: you proposed the change. Name other people's parts only where you know them, and say plainly where you do not. Answer slot: if others built, shipped or measured the change, say what you know of their part; if you do not know, say so | A peer stem. F2's credit language makes it a natural entry point. EXP because it scores attribution honesty in collegial form |
| B3 | "You'd sit beside me. What do you need from Sales Strategy in your first sixty days, and what can you give my team?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Reciprocity framing. What you need is yours to state, in your own words: for example how targets and forecasts are set here, since F7 says that is new to you. What you offer should stay at the quote's scope: you built a partner-level revenue model used in carrier negotiations. Offer a conversation about it rather than a promise of results | Dan is pricing what the hire costs and contributes. F4 and F7 are the two rows that make the answer concrete. JD because it scores cross-functional fit |
| B4 | "Tell me about a time you disagreed with another team's number and how it got resolved." | EXP | [grounded] "set annual volume targets with cross-org consensus" | The quote gives you the consensus across organisations on annual volume targets, and nothing about a disagreement or how it ended. Answer slot: if a disagreement was part of that work, tell how it ran and what was yours; if there was none, or you do not remember one, say so plainly and describe the nearest case you do have, or how you would handle one | An open prompt from the cross-functional-influence line of the JD. F5 is the row. EXP because it tests what actually happened, with a Peer Evaluator delivery |

Proposed wording in this table — pending your approval.

### Bank C — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor is bundling its way into our space. You're launching a new product line into our customer base. How do you shape land and expand so it isn't absorbed into their bundle?" | CASE | [grounded] research note: "bundling by a much larger platform vendor" | Clarify first: which product line, who the buyer is, where the bundle overlaps with it. Then objective, segmentation of the base by exposure to the bundle, approach for land and for expand, metrics, risks. Challenge one premise politely, for example whether the threat is equal across segments. Bring one consensus point (the threat is real) and one divergence of your own with reasons, including a segment where you would choose not to compete. No claim about your past is needed | The research note names bundling as the main competitive threat, so this case is likely. CASE with a CO angle. The pack's guidance is a method, so it is labeled by its source |
| C2 | "Pick one stage of land, adopt, expand or renew. Where would you look for whitespace first, and what would you pull?" | JD | [generic] pattern for a whitespace case, built on the JD highlights line "identify whitespace across land/adopt/expand/renew" | Say your hypothesis first, then segment the customer base by how deeply they have adopted what they already own. Ask Dan what usage and contract data exists before naming what you would pull. Close with the one number that would change your mind. No claim about your past is needed | Covers the whitespace requirement as a live problem. F2 and F3 are the rows it presses. JD because it scores the stated responsibility, with CASE delivery |
| C3 | "Enterprise expansion, the Compass launch and profitability are the stated priorities, and they pull against each other. How would you price and package Compass, and what would you trade off?" | CO | [grounded] research note: "enterprise expansion", "an AI copilot launch ('Compass')", "reaching profitability" | Clarify what exists today, then offer options (standalone, bundled with an existing product, usage-based) and the metric each would move. Say where profitability and enterprise expansion pull in opposite directions and which you would favour, with a reason. Pricing is Dan's native territory, so propose principles and ask Dan to correct the premise rather than bluffing depth. The three priorities are the consensus frame: use them, then add your own thesis | CO because it tests the company's stated priorities. The pricing tilt follows Dan's career spine. The research note is undated, so the framing may be stale, which is a reason to ask first |
| C4 | "Design the partner motion for one of the new lines. Who are the partners, what do they do, and how do you know it's working?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Clarify first: which line, which partner types, what the partner is meant to do for the customer. Then structure the motion and the metrics. Anchor your side in the quote at its scope: you built a partner-level revenue model that was used in carrier negotiations. Answer slot: if you shaped any part of a partner relationship beyond the model, say what; if you did not, say so plainly and say what you would need to learn | The required partner-motion line is where F4's limit shows. JD because it scores a required qualification, with CASE delivery |

Proposed wording in this table — pending your approval.

### Bank D — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales-ops or quota-setting work. This role sits beside Sales Strategy. What does that mean for your first ninety days?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal.** State the limit before it is pressed: "I don't have classic sales-ops or quota-setting experience." Hold what the quotes carry: you set annual volume targets with cross-org consensus, and you built a partner-level revenue model. Do not call the targets quotas. Follow-up one, "isn't that the core of GTM": return to the JD highlights, which list GTM strategy for two new product lines and whitespace, not quota design. Follow-up two, "who teaches you": the plan is a future one, so ask Dan's team to walk you through how targets are set before you propose anything | The single most predictable objection, aimed at the row where the material is thinnest and where Dan's function makes the gap visible. F7 is the row. JD with a Skeptic delivery. It will likely arrive in collegial packaging |
| D2 | "What don't you know yet about selling B2B data infrastructure?" | JD | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Calibrated candor beats bluffing. Name two or three things you do not yet know, in your own words. Answer slot: if you have worked with business customers or partners in any form, say how, at that scope; if not, say so plainly, then say how you would close the gap in the first weeks | F1 shows a consumer-tech background against a B2B role. The question is the Skeptic's version of day-one weakness. JD because it scores fit with the role as posted |
| D3 | "You've spent nine years in consumer tech product strategy and ops. Why this move, and why now?" | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The reason is yours: give your actual reason, in your own words, with no framing borrowed from the JD. Keep it consistent with what you say in E1. The quote supports only the career facts: two years in strategy consulting, then nine years in product strategy and ops at a large consumer-tech company | Motivation consistency is what a Skeptic scores, and F1 sets up the contrast. EXP because it tests the story behind the career, not a skill |
| D4 | "A new product line has little data and no playbook. When have you had to decide without the numbers you wanted?" | EXP | [generic] | Selection scaffold, since no quoted sentence carries it: pick a time you had to decide with partial data, naming the decision, what you used in place of the missing number, and how you checked it afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The JD's new-product-line wording and Dan's startup chapter make a pace and ambiguity probe plausible. EXP because it tests what you actually did when data was thin |

Proposed wording in this table — pending your approval.

### Bank E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the beats the quote states: two years in strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Then your own reason for this role, which is yours to give and is not in the material | An opener that is scored whatever its register. F1 is the only row that carries the career line. EXP because it tests economy and consistency |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it at the quote's scope: you use AI tools daily. Answer slot: name the tools and what you use them for in your own words; if the use is personal or general rather than part of your work, say so plainly. Do not move from using AI tools to building AI products | The JD's plus line, asked casually, with the Compass launch from your research note in the background. F6 is the row. JD because it scores the stated plus |

Proposed wording in this table — pending your approval.

### Bank F — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ARR result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, then restate. Hold: you proposed the change, and it was credited with the uplift. Hold through two follow-ups by returning to that verb, not by adding to it. Concede specifically: what you do not know about how the credit was assigned. Answer slot: if others built or measured the change, say what you know of their part; if you do not know, say so | The stem for the attribution probe, and the question most likely to arrive abruptly. F2 is the row. EXP with hold-then-concede structure |
| F2 | "Sixty seconds: why you over someone who has run a sales-ops function?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "built a partner-level revenue model used in carrier negotiations" | The time-boxed version of D1. Pause, restate the question, then answer in order: the limit ("I don't have classic sales-ops or quota-setting experience"), what the quotes carry (a partner-level revenue model used in carrier negotiations; annual volume targets set with cross-org consensus), and what you would do first. Do not claim you are the stronger candidate. Say what you bring and let Dan weigh it | Pressure delivery of the D1 objection, so the answer is ready at speed. F7 is the row. JD because it scores fit against the role |

Proposed wording in this table — pending your approval.

### Requirement coverage

| JD requirement (JD highlights) | Questions |
|---|---|
| "own GTM strategy for two new product lines" | B1, C1, C3, D1 |
| "identify whitespace across land/adopt/expand/renew" | C2, A1, A2 |
| "run independent analysis in SQL and Tableau" | A3 |
| "partner-motion design experience required" | C4, A4, B3 |
| "strong cross-functional influence" | B1, B3, B4 |
| "AI experience a plus" | A5, E2 |

Headline metric ("~$400M ARR uplift") is covered by A1, A2, B2 and F1. The stated gap (sales-ops and quota-setting) is covered by D1 and F2.

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "What could someone new in this seat do in the first month that would actually take work off your team?" | The reciprocity question for a peer. It shows you are thinking about Dan's load, not only your own | [generic] |
| R2 | "Your career has run through pricing and monetization roles, and you're now in Sales Strategy. What from the pricing side do you rely on most when you look at a sales motion?" | Tied to Dan's own path as you described it. It turns the interrogation into a peer conversation and invites the pricing perspective that C3 will have tested | [grounded] |
| R3 | "What from your early-stage-startup chapter shows up in how you'd want a new product line taken to market here?" | Also tied to Dan's path. Asked as curiosity about their view, not as a claim about yours | [grounded] |
| R4 | "Which number do you trust least when you judge whether a new motion is working?" | Speaks to Dan's self-description as "relentlessly data-driven" and shows you think about measurement honesty, the thing A1 and A2 test | [grounded] |
| R5 | "Where is the biggest open question in how Compass is positioned against the larger platform vendor?" | Rests on the research note's priority and threat. It signals you read the strategy and want Dan's view, not just to give yours | [grounded] |
| R6 | "How will the VP decide where this role's GTM ownership ends and Sales Strategy's begins?" | Surfaces the seam from B1 openly, and the answer tells you whether the role is as scoped as the JD highlights suggest | [generic] |

Proposed wording in this table — pending your approval.

## Prohibited claims

What this pack will not coach, with the basis and the honest form of each. The banks above were written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led go-to-market for a product | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says product strategy and ops, not go-to-market. D2's slot stays inside the quote |
| Designed partner motions | Inflated form of F4 | F4's quote at its own scope: you built a partner-level revenue model used in carrier negotiations. The material does not say you designed the partner relationship itself. C4's slot asks only what part you shaped |
| Has quota-setting or sales-ops experience, including restating annual volume targets as quotas | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." F5's quote stays at its own scope. No slot |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: you proposed the change, and it was credited with the uplift. The material does not say who credited it or who built or measured it |
| Ran independent SQL and Tableau analyses end to end | Inflated form of F3 | F3's quote at its own scope: skilled in SQL and Tableau. A3's slot asks only for an analysis you ran yourself, and its second branch allows that none comes to mind |
| Has built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily. The material shows use, not building |

## Sources

**Provided documents:** your message (company and role, JD highlights, the candidate summary, the interviewer description, and the research note on priorities and competitive threat). No dossier was supplied.

**Searches sent (all refused, none returned results):**

- "Northwind Data company values" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused
- "Northwind Data Compass AI copilot enterprise expansion profitability" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Search refused. It would have fed value-themed VAL questions and a values cheat sheet, but no values-style round is detected here, so section 10 is absent either way |
| 2. Interview process, role family | skipped | Your words fix the loop: one 60-minute conversation with a peer. The persona weights and bank structure follow from that |
| 3. Company strategy and recent news | unavailable | Search refused. The pasted research note supplies the priorities and the threat, so C1 and C3 rest on it. A fresh sweep would have checked whether the note is current, since it is undated |
| 4. Interviewer, Dan Kovac | unavailable | Search refused. The interviewer read rests only on the profile description you gave; any talks or writing, and any reverse question drawn from them, are absent |
| 5. Representative JD for the title | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Full JD text** → every F row currently quotes a highlight, so rows would quote the JD itself, and any mid-list requirement missing from the highlights would get a question
- **The candidate's CV** → the coach's-notes evidence in F1 to F7 becomes CV lines, and a CV with a named artifact raises bands: the readout behind the ARR credit for F2, the revenue model's input sheet for F4, or a SQL or Tableau workbook for F3
- **Your answers to the answer slots** (A1, A3, B4, C4, D2, E2) → rows F2, F3, F4 and F6 become grounded in what the candidate actually did, and the slots in those rows narrow
- **Permission for web search** → the values page, Dan's public talks or writing, and a current strategy sweep, which would sharpen the interviewer read, add reverse questions drawn from Dan's own words, and check whether the research note is stale. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is offered once, and would add a strategy brief, role-family loop reports and recent org context
- **Recruiter's guidance on this conversation** → whether a case, presentation or other deliverable is expected, which would add a build section
- **Prep time available** → a prioritized schedule built around D1 and the few other things worth doing well
- **A `tuesday-dossier.md`** → verified evidence and any claims to rule out, so the highest-ROI objection would be evidence-derived and not inferred
