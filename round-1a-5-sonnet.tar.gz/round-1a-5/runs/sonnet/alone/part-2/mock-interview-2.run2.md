I'll read the reference files the skill points to before I build the pack.
Web search was refused, so the pack runs on your message alone. I'm writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-2-denied-11cd2bc9/atlas-freight_operations-manager_interview_pack.md`. It has 20 questions across seven interviewer styles, a fit snapshot mapping each JD line to your own words, a requirement-coverage table, reverse questions, and a list of claims the pack won't coach.

I built it without knowing the round, so every interviewer style has roughly equal weight. Web search was refused, so nothing in it comes from outside research. The company questions and persona weights are generic, and the research table in the pack says so.

The one to rehearse first is B1: "You're leading three supervisors today, and this role is twelve across four sites. What changes?" The pack names it as the highest-ROI prep. The Power BI question (B2, D2) comes second. For that one, the pack coaches a plain "I haven't used Power BI" followed by a plan.

Say the word and I'll play the Skeptic on B1, with follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions, or convert the pack to Word.

1. Who are you meeting, and in what round (recruiter, hiring manager, peer or panel)? Did the recruiter mention any focus areas or something to prepare? The answer reweights every bank.
2. Can I retry the web search for the company's values, interview process and recent news? That's up to 6 searches and 2 page fetches, a few minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Relationship and round type: not known. Built with flat persona weights (see section 5) and no web research (see section 10).

## 1. How to use this pack, and the type key

Personas describe how a question is asked. Types describe what it is scoring. Every question carries one type tag, one provenance label, and the exact sentences of yours its guidance rests on. The guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values. No values were available to me, so no question carries this tag yet |
| EXP | Whether your background claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the job as the posting lists it, gaps included |
| CO | What you know about the company and why this one |
| CASE | A live problem set in the role, scored on structure and reasoning |

Answer slots, written as "Answer slot:", are instructions for the interview. Each has two honest branches: say what you did, or say plainly that there was no such step or it was not yours. Both branches score better than a stretched answer.

## 2. Prep triage

You said the interview is next week and gave no hours, so this is an order, not a schedule.

1. B1, the scale question (three supervisors today, twelve in the role). This is the highest-ROI prep in the pack: it will be asked in some form, and a calm, specific answer changes the interview.
2. B2 and D2, the Power BI question. Say the plain acknowledgment aloud until it is boring.
3. C1 and C2, the numbers. Write your own answers to the four slots under C1 before you say anything aloud.
4. A1 and A3, the live cases. Do them aloud with a timer, thinking out loud.
5. E1, your 90-second arc.

Everything else is insurance.

## 3. Requirement coverage

| JD requirement (quoted from the JD you pasted) | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B1, F1 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, C2 |
| "lead a team of 12 supervisors" | B1, D1, G2 |
| "build reporting in Excel/Power BI" | B2, D2, E2 |
| "5+ years operations leadership required" | B3 |
| "Lean/Six Sigma a plus" | C3 |

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution work, one site's surge plan, and three supervisors. It says nothing about terminals or about more than one site. Words stay at that scope: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's "4 sites" makes a probe on multi-site work likely. If any of your work spanned sites, or ran in a terminal setting, say what it was and what part was yours; if none did, say so plainly and stay with the two sentences above |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material gives a mis-pick figure, not on-time performance or cost per shipment, and the words stay with the mis-pick figure. Answer slot: if you have tracked either measure the JD names, say which one and what you saw, in your own words; if you have not, say so plainly and stay with the mis-pick quote |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says three supervisors and the JD says twelve, so the limit is the scale. The words stay at three: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have ever led more supervisors than that, say when and what part was yours; if not, say so plainly, then say what you would do at twelve as a plan and never as a past |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a self-rating, and nothing in your material shows reports built. Answer slot: the JD says build reporting, so expect a probe on what you have built. If you built reports, say what each showed and who used it; if your Excel use was something else, or no one used it, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to dashboard or report work in it, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives seven years in ops and a current people-leading role, and does not say how many of the seven years involved leading people. Answer slot: the JD says required, so expect a probe on the count. Say how many of those years were people-leading, in your own words; if fewer than five, say so plainly and stay with the two sentences quoted |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in your own terms: you are green belt certified. A certificate would raise this row |

## 5. Persona weights and table

Weights are flat. You do not know who is interviewing, and no source I could read documents this company's loop, so I have used the generic pattern (screen, hiring manager, panel) with equal weight. That is noticeably weaker than a pack built on a known round. Telling me the round reweights everything below.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems on on-time performance, cost per shipment, four-site planning | High. The JD is built around those measures, and a manager over four sites is usually tested on a live problem | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the gaps: three versus twelve supervisors, Power BI, the years of leadership | High. F3, F5 and F6 are visible on a first read of your background against the JD | Rehearse B1 until it is boring; hold only what the quotes carry; give the limit plainly, then a plan |
| Data-Driven Prober | Reads your numbers line by line, asks how the 40% was counted | High. F2 holds your one headline figure, and figures draw probes | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| Pressure | Time-boxed, interrupts, plays devil's advocate on the gaps | Medium. A senior ops role often includes one challenging voice, but nothing provided indicates it | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational | Friendly "walk me through your journey," tool and logistics questions | Medium. It appears in some form in almost any screen, and casual questions are still scored | A 90-second arc built only from your sentences; treat casual questions about reporting and Lean as scored |
| Peer Evaluator | Cross-site seams, credit, disagreement between site leads | Lower. Nothing provided says a site peer is in the loop; two questions only | Offer seam principles, not a pretended map of the seams; reciprocity framing |
| Values / Behavioral | Open prompts such as an unpopular truth, leading through pressure | Lower. No published values and no documented values round were available; two questions only | Pick stories your material carries, or use the selection scaffold and its honest branch |

## 6. Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one of the four sites has slipped over three weeks. Walk me through how you would diagnose it." | CASE | [generic] | Structure it aloud: what you would ask first (what changed, when, where), the objective, how you would cut the data (by site, shift, lane or customer, whichever you can get), what you would check first, what you would do inside the week, and how you would know it worked. Challenge one premise politely, such as how on-time is defined here. The question needs no claim about your past, so the guidance makes none | Built from the JD's on-time performance line (F2's requirement), asked as a live decision; CASE because it scores structure, and `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "Cost per shipment has climbed at two of the four sites. How would you decide where to look first?" | CASE | [generic] | Same spine as A1: clarify the definition and the period, split the number into its parts, pick the largest or fastest-moving, say what you would need from finance or the sites, name the risk of fixing the wrong thing. No claim about your past | F2's second measure, so it gets its own live problem; a candidate who can structure on-time but not cost reads as half-covered |
| A3 | "You ran the surge plan for your site. What would change if the same peak hit all four sites at once?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Open with the quote at its own scope: "I ran the site's peak-season surge plan two years running." Then treat the four-site case as a plan, not a past: what you would need to know first, what you would keep from a single-site plan, what you would not assume carries over, who you would need aligned. Say it as "I would," never as "I did" | F1 is where the JD presses on multi-site work; CASE because the second half is a live problem, with an EXP opening so the quote is rehearsed at its real scope |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You are leading three supervisors today, and this role is twelve across four sites. What changes?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have ever led more supervisors, or supervisors at more than one site, say when and what part was yours; if not, say so plainly and do not stretch. Follow-up one, how you would lead supervisors who are not in the building with you, and follow-up two, what you would do in your first thirty days: answer both as plans in your own words, about what you would find out first and what you would hold off changing. Concede the scale gap by name and do not fold on what you have actually done | F3 is the most visible gap between your material and the JD, so some form of this question arrives in the loop; JD because it scores the stated requirement |
| B2 | "The role builds reporting in Excel and Power BI. Where are you on Power BI?" | JD | [grounded] "never used Power BI"; "solid Excel" | Plain acknowledgment first, in your own terms: "I haven't used Power BI." Then a plan, said as a plan: how you would get to working use, and what you would ask the team to point you at first. Excel, at its own scope: "solid Excel." Answer slot: if you have built reports in Excel, say what they showed and who used them; if you have not, say so plainly. Never imply Power BI work | F5 is a stated gap and F4 is thin; the Skeptic asks it early and politely, so the answer must be short and unflinching; JD because it scores a stated tool requirement |
| B3 | "The role asks for five or more years of operations leadership. Which of your seven years in warehouse and distribution ops count?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Quote what you have: "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors." Answer slot: say which of those years were people-leading, in your own words and with dates you can stand behind; if fewer than five were, say so plainly and let the rest of the seven stand as what they were | F6 is a required line and your material does not show the count, so the probe is near-certain; JD because it tests a stated qualification |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut the mis-pick rate 40% by redesigning the pick path. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | State the claim as you wrote it: "cut mis-pick rate 40% by redesigning the pick path." Four answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part of the redesign was yours. If you do not know how it was counted, say so plainly rather than guessing. Naming your weakest assumption before they do turns a probe into credibility | F2's only figure, and a magnet for probers; EXP because it tests attribution and counting |
| C2 | "The role is about driving on-time performance and cost per shipment down. What have you tracked yourself?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you have tracked either measure, say which one, what you saw, and what part of any change was yours; if you have not, say so plainly and stay with what the quote carries, a mis-pick figure. Do not borrow the JD's two measures for it | F2's requirement is not reached by the quote, so the question will be asked and the honest second branch is a real answer; JD because it scores the stated measures |
| C3 | "You are green belt certified. What have you applied it to?" | JD | [grounded] "green belt certified" | Lead with it in your own terms: you are green belt certified. Answer slot: say which work, if any, you applied it to and what part was yours; if the certification has not been applied to any work, say so plainly. Do not link it to anything you have not said it was used on | F7 is a plus that a prober tests for use, not for the certificate; JD because Lean and Six Sigma are in the posting |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we choose you over someone who already runs twelve supervisors?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause and restate the question. Use your own sentences at their own scope: "currently a senior shift manager over 3 supervisors," "cut mis-pick rate 40% by redesigning the pick path," "ran the site's peak-season surge plan two years running," "green belt certified." Do not claim to be better than anyone; say what you bring. Hold through two follow-ups. Concede the scale gap specifically, and do not retreat from what the sentences say | F3 under time pressure, which is where the hold-then-concede structure is tested; JD because the content is the stated requirement |
| D2 | "You have never used Power BI, and the role builds reporting in it. Why should I not stop here?" | JD | [grounded] "never used Power BI"; "solid Excel" | Pause. Restate it calmly. Hold: "I haven't used Power BI," then "solid Excel," then your plan for getting to working use, said as a plan. Hold through two follow-ups by returning to those. Concede the gap by name, specifically, without apologizing and without implying experience you do not have | F5 is a stated negative, so the premise has a source; the Pressure persona tests whether you stay level |
| D3 | "Why this move, and why now?" | EXP | [generic] | Selection scaffold: give your actual reason, in the order it is true, stated plainly and briefly, and tie it to something the JD asks for that you want to do. Do not offer a reason you do not hold. If you are unsure of your reason, say so plainly and give the nearest true thing. Your current role, in your own words: "currently a senior shift manager over 3 supervisors" | The motivation probe a Pressure interviewer uses to test consistency; EXP because it tests your own account of your path; `[generic]` because no reason was provided to me |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc built only from those five sentences. How the seven years moved from role to role is yours to tell in your own words, from memory; I have not supplied it. Stop at what the sentences carry and let them ask for more | The biography opener is scored for economy; EXP because it tests whether the arc matches your material |
| E2 | "Tell me about how you track performance in your current role." | JD | [grounded] "solid Excel" | Answer slot: say what you track, in what, and who sees it, in your own words; "solid Excel" stays at its scope. If your tracking is mostly in systems others built, or you rarely build your own, say so plainly | Casual question on F4's requirement; the answer shows what "solid Excel" means in practice |
| E3 | "Anything on pay, notice period or travel between sites we should know about?" | JD | [generic] | Three logistics slots, each your own answer. Notice: give your actual notice period. Pay: give your own number, or ask for the role's band first. Travel: say your own constraints plainly. If asked what you earn now: "I'd rather focus on the range for this role." No figure from me | A recruiter or a friendly opener often asks; if your round is a recruiter screen, this becomes four separate rows once you tell me; `[generic]` because I have no figures from you |
| E4 | "What do you know about Atlas Freight, and why this company?" | CO | [generic] | The only company facts in your material are the JD's own: regional logistics, 800 employees, four sites, a team of twelve supervisors. Quote them as the JD gives them, and add only what you learn from the company's own site before the interview. Then your actual reason for wanting this one, in your own words | The homework check; CO because it tests company knowledge; `[generic]` because my research could not run (section 10) |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our four sites share carriers and customers. Where is the seam between sites, and what happens when two site leads disagree on a call?" | CASE | [generic] | Offer seam principles, not a pretended map: who decides what, how a disagreement gets raised, what each side owes the other. Add what you would need to learn before you could say where this company's seam is. For the disagreement half, use a selection scaffold: pick a time two people at your level disagreed and you held your view with tact; if no such time comes to mind, say so plainly and give how you would handle it | A peer prices what the hire does to their load; CASE because it is a live seam problem; `[generic]` because the company's structure is not in my material |
| F2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Use "we" for context and "I" for what was yours. Quote the claim at its scope: "cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which part of that work was yours and who else was involved; if others did part of it, say so plainly | The collegial form of the attribution probe C1 and D1 raise; EXP because it tests what was actually yours |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship still intact at the end; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. No story supplied from me | A standard behavioral stem; EXP rather than VAL because no published values were available to me |
| G2 | "Tell me about a time you led supervisors through a high-pressure period." | EXP | [grounded] "ran the site's peak-season surge plan two years running"; "currently a senior shift manager over 3 supervisors" | The two sentences are your base, at their own scope. Answer slot: the JD asks you to lead twelve supervisors, so expect a probe on how you worked with yours. If your supervisors had a part in it, say what and how you led it; if the plan was set elsewhere, or they were not involved, say so plainly and stay with the two sentences | F1 and F3 meet here; EXP because it asks for an instance, not a view |

## 7. Highest-ROI prep

B1. The scale gap (three supervisors, one site, versus twelve supervisors, four sites) is the objection most likely to be raised, and D1 and G2 draw on the same material. Rehearse B1 first, then D1.

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured today, and which of the four sites is furthest from where you want it?" | It shows you think about measures before fixes, and it ties to the JD's first measure |
| R2 | "How are the twelve supervisors spread across the four sites, and what would you want me to do with them in the first ninety days?" | It brings the scale gap into the open on your terms and asks what they expect |
| R3 | "What does reporting run on today, and what would you want built first?" | It finds out whether Power BI is a day-one need or a later one, and shows your priorities |
| R4 | "What would make you say in six months that this hire was the right one?" | It asks for the scoring sheet directly, and a specific answer is useful to you |
| R5 | "What is hardest about running four sites as one operation?" | It signals you think across sites, and invites a candid answer |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question for a peer or a manager; it shows you are thinking about their load |

## 9. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team of twelve supervisors, or ran more than one site | Inflated form of F3 and F1 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors." The limit is the pack's observation: your material says three supervisors and no site count beyond your own |
| Owned terminal operations | Inflated form of F1 | The quotes at their own scope. The limit is the pack's observation: your material says warehouse and distribution, not terminal operations |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path." C2's slot asks only what you tracked |
| Built reporting in Power BI, or has Power BI experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't used Power BI." No slot |
| Has five or more years of operations leadership | Inflated form of F6 | F6's quotes at their own scope. The limit is the pack's observation: your material gives seven years in ops and does not say how many involved leading people |
| Applied Lean or Six Sigma to the pick-path redesign | Inflated form of F7 and F2 combined | Each sentence at its own scope: "green belt certified," and "cut mis-pick rate 40% by redesigning the pick path." Your material does not link them |

## 10. Sources

Provided documents: your message, which held the JD text and your background. No dossier was provided.

Searches sent, each refused by the host:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight operations manager interview process" — refused
- "Atlas Freight regional logistics strategy news 2026" — refused

No pages were fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Would have fed a values cheat sheet if a values round were documented; none could be established, so section 10 of the skeleton is dropped and VAL has no questions |
| 2. Interview process for this role family | unavailable | Would have set persona weights from a documented loop; weights are flat instead and the pack says so |
| 3. Company strategy and recent news | unavailable | Would have grounded a CO or CASE question in current strategy; E4 is `[generic]` instead |
| 4. Interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- The round type and who you are meeting (recruiter, hiring manager, peer, panel) → persona weights recomputed; a recruiter screen would add separate pay, notice, location and reason-for-leaving rows
- The interviewer's name and title → an interviewer read, persona adjustments from public footprint, and a reverse question tied to their path
- Anything the recruiter said about focus areas or a task to prepare → a build section for any graded deliverable
- Web search allowed, or the company's values page, careers page and recent news pasted → values cheat sheet if a values round is documented, E4 and a CO or CASE question grounded in current strategy, and a documented loop in place of the generic pattern
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes) → a grounding brief on strategy, competitors and recent leadership context
- When you became a shift manager and when you first led people → F6 and F3 move from `discovery` toward grounded, and B3 gets real dates
- How the 40% mis-pick figure was counted, and what part was yours → C1's four slots can be filled from your own words
- Whether you have tracked on-time performance or cost per shipment, and what you saw → F2's slot in C2
- Any report you built in Excel, described in a sentence → F4 moves from `low`
- The green belt certificate (issuing body, level) → F7 moves from `medium` to `high`
- A `tuesday-dossier.md` from an earlier evaluation of this role, if you have one → verified evidence and absolute prohibited claims in place of the locally built list
