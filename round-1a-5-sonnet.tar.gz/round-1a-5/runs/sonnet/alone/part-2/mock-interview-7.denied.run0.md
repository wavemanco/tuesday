I'll read the reference files this skill points to before building the pack.
Femi, your prep pack for Friday is saved at `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-7-denied-7716048c/saltmarsh-games_live-operations-producer_interview_pack.md`.

It's built for a hiring-manager round, because your note didn't say where Tobias sits relative to the role. It has 19 questions across six interviewer styles, a fit snapshot against each JD line, a list of claims it won't coach, and six reverse questions.

Web search wasn't permitted, so I sent four searches and all were refused. The pack uses only your JD and your message. It has nothing on Saltmarsh's values, their interview loop or strategy, or Tobias's background. The question about their games (D2) is generic, and the persona weights rest on a generic hiring-manager pattern, not the studio's actual process.

- **Your strongest ground:** the content-drop calendar, the release checklist and the retention presentation (F6, F4, F7).
- **Highest-ROI prep:** B1, "Which part of this job would you be weakest at on day one?" Your two stated gaps (never led a team, never worked on a game with in-app purchases) are what it presses on. The pack coaches you to say both plainly, give a plan, and hold on what you did do.
- **Thinnest evidence:** the JD wants two titles with events, and you've described weekly content drops for one title. It also wants you to own the post-event review and its KPIs, and you've said you presented the retention numbers. Where a probe is likely, the pack gives answer slots, not scripted claims.

Say the word and I'll play the Skeptic on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions, or convert the pack to a Word document.

Where does Tobias sit relative to the role (your future manager, a skip-level, a peer), and is Friday the first round or a later one?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack — Live Operations Producer, Saltmarsh Games

- **Role:** Live Operations Producer, Saltmarsh Games (mobile game studio)
- **Interviewer:** Tobias Wrenfield, Head of Live Operations
- **Format:** 60 minutes, Friday
- **Relationship (assumed, yours to correct):** hiring manager. Your note gave his title and not his place in the loop, so every persona weight below rests on that assumption.
- **Candidate:** Femi

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say the beats in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. No VAL questions are in this pack because no values source is in hand (see Sources) |
| EXP | Whether your claims survive scrutiny: what you actually did |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the company, its strategy and its products |
| CASE | A live problem from the role, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for this conversation. It tells you where an interviewer is likely to probe and gives you two honest branches. Either branch is a good answer.

## Prep triage

Sized to the two days before Friday, assuming Friday is this week's.

1. **Wednesday, first:** say B1 aloud until it is boring. It is the pack's highest-ROI prep (reasoning at B1).
2. **Wednesday:** build the D1 arc from its four quoted beats, and answer the F1 and F5 slots in your own words.
3. **Wednesday:** work through C1 and C3. They carry the two slots an interviewer reading your background closely would reach first.
4. **Thursday:** run A1 to A5 aloud once each. They are scored on structure, and you cannot memorize them.
5. **Thursday:** rehearse E2 once against a 60-second clock, then pick three reverse questions.

Everything else is insurance.

## Fit snapshot

Your background came as a short summary in your message, with no CV, so every evidence cell quotes it. Nothing has been inspected behind it, which caps most rows at `medium`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title over two years, not a live-events calendar and not a second title, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events line makes a probe on what the drops contained likely. If any drop was a timed event, say which and what was yours to decide; if none was, or the decisions were not yours, say so plainly and stay with the weekly calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | discovery | The JD says coordinate, not lead, and your sentence is about leading, so the pack treats coordination as unshown, not as absent. Words: "I haven't led a team." Answer slot: the JD names four teams, so expect a probe on which of them you worked with when an update shipped. If you worked with any, say which and what you did with them, in your own words; if some were not teams you worked with, or it was not yours to coordinate, say so plainly and stay with the weekly calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers, not that you ran a review or chose the KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's review-and-KPIs line makes a probe on what sat behind the numbers likely. If you had a hand in choosing which retention numbers were reported, say which and how, in your own words; if you presented numbers others produced or chose, or there was no such choice, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in the sentence itself, but it is a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you wrote it, and your QA team still uses it. The sentence does not say who runs the checklist on a release day. Answer slot: if you also ran it on release days, say how, in your own words; if you wrote it and others ran it, say so plainly and stay with what you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years in the role and two years on the calendar. It does not say whether the main title ran as a live service, or what the first two years held. Answer slot: the JD's live-service line makes a probe likely. Say in your own words whether and how your title ran live; if it did not, say so plainly and stay with the weekly calendar. Expect a second probe on the gap between "associate producer" and the JD's "producing", and answer it from your own role |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it. Lead with it in its own terms: you ran it, weekly, for the main title, for the last two years. A named cadence and duration beat an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | Lead with it in its own terms: a named audience and a monthly cadence. The sentence says presented, not produced or analysed, so expect a probe on how the numbers were counted. Answer slot: say in your own words how the retention numbers were defined and counted, what they were sensitive to, which assumption behind them you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch, and so is "I presented numbers others produced" |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The checklist is a written document others use, which is as far as the sentence goes. It does not show how clear your writing is, and clarity is for the reader to judge, not for you to assert. Answer slot: the JD's line makes a request for an example likely. Say which written thing you would point to and who relied on it; if you have nothing beyond the checklist, say so plainly and point to that |
| F9 | Familiarity with in-app-purchase monetization on a mobile live-service title (not in the JD as supplied; raised by your own message) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work, and nothing added to make the gap feel smaller |

The strongest rows are F6, F4 and F7: each has a quote that already reaches the requirement. The two to rehearse hardest are F2 and F9, because they rest on your own stated negatives.

## Persona table

No source in hand documents Saltmarsh's loop, so the weights rest on a generic hiring-manager prior plus the supplied JD, not on this studio's documented process. If Tobias is a skip-level or a peer, say so and the weights change.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy | Bank (questions) |
|---|---|---|---|---|
| Case/Strategist | Live problems drawn from the role: schedule collisions, a late bug, a metric dip | High. The hiring-manager prior leads with it, and the JD's verbs are plan, coordinate and own | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely | A (5) |
| Skeptic | Quiet probing of what your material does not show | High. Your own message states two gaps (F2, F9), and the JD's calendar line is wider than F1 | Rehearse B1 until boring; hold what the quotes carry; concede the gaps plainly | B (4) |
| Data-Driven Prober | Line-by-line questions on the retention numbers and the checklist | Medium. The JD names retention metrics and KPIs (F3, F7), which moves this persona up from the hiring-manager prior | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know | C (3) |
| Conversational / Rapport Builder | The open "walk me through the journey", the casual question about the studio's games | Medium. This is the pack's judgment, not a finding: casual questions are still scored | A 90-second arc built only from your quoted sentences; treat casual questions as scored | D (3) |
| Pressure | "How much of that was actually you?", a time-boxed "why you" | Low. The hiring-manager prior puts it behind the Skeptic | Pause, restate, hold a challenged position through two follow-ups, concede specifics | E (2) |
| Peer Evaluator | The seam between producer and design when scope changes | Low. Applies only if Tobias is a peer or a cross-functional colleague joins | Propose seam principles instead of pretending to know the seam; reciprocity framing | P (2) |
| Values/Behavioral | Stories mapped to published values | No bank. No values source or loop source is in hand, so a values-style round is not detected | If one turns up, the values cheat sheet comes back with it (see the upgrade menu) | none |

## Question banks

Question IDs are letter-by-persona. Fit rows are F1 to F9, so the Peer bank uses P.

### Bank A — Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Imagine two titles each want a major event on the same weekend, and the teams can support only one. How do you decide?" | CASE | [generic] | Clarify first: what makes it one or the other (team capacity, what has already been announced to players, what each title needs from the event). Then your objective, the criteria you would rank on, who has the final say, the option of moving one and what moving costs each title, the risks, and what you would write down and send to whom. Think aloud, and challenge one premise politely, such as whether the teams really can support only one. The question asks about no past, so this guidance makes no claim about yours | The JD's two-titles calendar line (F1) turned into a decision; CASE because it scores structure, and [generic] because it is a pattern for the problem, not a fact about this employer |
| A2 | "A weekly update is due to ship on Thursday. On Wednesday afternoon QA finds a bug in the event's reward flow. Walk me through the next 24 hours." | CASE | [generic] | Clarify: how severe, who is affected, what a fix needs, whether the event can run with the broken piece switched off. Then the options (ship with the piece off, hotfix, delay) with the cost of each, who has to be in the conversation (engineering, QA, community for player messaging), who decides, and what goes into the post-event review. No claim about your past | The release-checklist responsibility (F4) as a live decision; CASE because it scores reasoning under time pressure |
| A3 | "Art tells you an event's key visual will be two days late, and engineering says the build freezes Thursday regardless. What do you do?" | CASE | [generic] | Clarify what slips and what is already promised to players. Lay out the options with trade-offs, who you speak to and in what order, what you can decide yourself and what you would escalate, and what you would record. Say the escalation line aloud: it answers the coordination question without a claim to authority you have not had | The coordination line (F2) as a decision, asked as a case because your stated gap (F2) is the thing it presses on; the guidance says nothing about your past |
| A4 | "Day-7 retention on one title dips in the week after an event. How do you work out why?" | CASE | [generic] | Clarify the measure, the cohort and the window first. Rule out measurement and release issues. Segment (new against returning players, platform, app version). Compare against earlier events. Rank hypotheses, say what you would check first, and say what you would report and what you could not conclude. No claim about your past | The retention requirement (F7) as a diagnosis; CASE because the structure matters more than the answer |
| A5 | "Design the post-event review for an event that just ended: what goes in it, and which KPIs does it report?" | JD | [generic] | Start from the event's stated goal. Pick a few KPIs tied to that goal, name the comparison you would measure against, and say what the data cannot tell you. Name owners and follow-ups, and keep the written summary short. Say your framework aloud before using it. No claim about your past | The post-event review and KPI line (F3) and the retention line (F7); JD because it scores the stated responsibility, with CASE delivery |

### Bank B — Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | **The highest-ROI prep in this pack.** Say it plainly in the sentence's own terms: "I haven't led a team, and I haven't worked on a game with in-app purchases." Choose which to name first, then give the plan, in your own words and never as a past: your own first steps, not ones the pack supplies. Rehearse three follow-ups. (1) "How would you learn it in the first month?" Give the plan. (2) "What if that takes longer?" Say what you would ask for, and from whom. (3) "Why take that risk?" Hold: return to "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses", at those words and never wider, and concede the two gaps specifically | F9 and F2 hold your stated gaps, and the JD's coordination and KPI lines press on both, so this is the objection most likely to arrive in some form. JD because it scores the stated responsibilities, in the Skeptic's delivery |
| B2 | "The role coordinates design, art, engineering and community on each update, and you've said you've never led a team. How do you get four teams to move on one date?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Open with the plain acknowledgment: "I haven't led a team." Answer slot: if you coordinated any of these teams on a drop, say which, what you did and what the hand-off looked like, in your own words; if you did not work with a team, or it was not yours to coordinate, say so plainly and stay with the weekly calendar you ran. Then say how you would go about it without authority over them, as a method and never as a past | F2 is the requirement your stated gap presses on, and the JD raises the four teams; JD because it scores the stated responsibility |
| B3 | "You ran the content calendar for one title. This job has two, with events. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if any of the weekly drops were timed events, say which and what was yours to decide; if none were, say so plainly. Then think aloud about what changes with two titles: what the two would share, what would collide, and what you would ask first. That is a method, not a claim about your past | F1 is the likeliest place for the "wider than your experience" probe, and F6 is the evidence under it; JD because it scores the stated requirement |
| B4 | "You've spent four years as an associate producer at a puzzle-game studio. Why this role, and why now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Give your own reason, in one or two sentences, tied to something in the JD's lines that you actually want to do. The pack has no reason from you and supplies none. If the move is about scope or the kind of game, say that in your own words. Keep it consistent with the arc you give in D1 | The motivation-consistency probe the Skeptic persona carries; F5 is the row it rests on, and EXP because it tests your own account |

### Bank C — Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented and to whom, in those words. Then the four defend-the-number slots, each in your own words: how the retention numbers were defined and counted, what they were sensitive to, the assumption you would defend least (name it before the interviewer does), and which part was yours. "I don't know how it was counted" is an honest branch, and so is "I presented numbers others produced." The pack names no method or baseline and will not | F7 is where a prober starts, and the sentence says presented, not produced; EXP because it tests whether you can account for the number |
| C2 | "Tell me about a time the numbers after a content drop told you something you didn't expect." | JD | [inferred] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a drop where what you saw afterwards differed from what you expected. It needs what you expected, what you saw, and what, if anything, changed after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — "Presented the monthly retention numbers to the studio head." — at its own words, or say how you would run a review | The JD's review-and-KPI line (F3) is the raising source; [inferred] because the question is the pack's derivation from it, and JD because it scores that stated responsibility |
| C3 | "Walk me through the release checklist your QA team still uses." | JD | [grounded] "Wrote the release checklist our QA team still uses." | The beats are the sentence's own: you wrote it, and the QA team still uses it. Tell what is on it in your own words. Answer slot: the JD's line about managing it with QA makes a probe on what happens on a release day, and on how it gets changed, likely. If you ran it at release or changed it, say how; if you wrote it and others ran it, or it has not changed, say so plainly and stay with what you wrote | F4 is your strongest row and the most checkable, so expect the detail; JD because it scores the stated release-checklist responsibility |

### Bank D — Conversational / Rapport Builder (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats the quotes state: four years as an associate producer at a puzzle-game studio; the last two years running the weekly content-drop calendar for the main title; the release checklist the QA team still uses; the monthly retention numbers presented to the studio head. Close on your own reason for this role. Answer slot: the JD's live-service line makes a probe likely, so say in your own words whether and how your title ran live; if it did not, say so plainly and stay with the weekly calendar | F5 is the JD's years requirement and F6 its calendar one; JD because the casual register is still scored against the stated requirements, with EXP delivery |
| D2 | "Have you spent time in either of our two titles? What did you notice about how its events run?" | CO | [generic] | The pack found nothing on the studio's titles, because search was unavailable, so it supplies no fact about them. If you can before Friday, spend time in both and note what you observed about the cadence of events, in your own words, saying only what you saw. If you have not played either, say so plainly and say what you would look at first | CO because it tests homework; [generic] because no research ran, and it becomes [grounded] only if the research is rerun |
| D3 | "Tell me about a time something you wrote changed what another team did." | JD | [inferred] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick a piece of writing that someone else acted on. It needs a named reader, what you wrote, and what they did differently as a result. The nearest thing your material carries is "Wrote the release checklist our QA team still uses." Say it at its own words, and add what the QA team did differently because of it only if you can say it in your own words. If no such time comes to mind, say so plainly, then give that nearest thing or say how you would write a release note | F8 is the row it rests on; JD because it scores the stated written-communication line; [inferred] because the question is the pack's derivation from that line |

### Bank E — Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That calendar you ran — how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause and restate the question. Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Hold it through two follow-ups. Concede specifically and never on the core claim. Answer slot: say in your own words which parts were yours and which were set by others; if you set none of it, say so plainly and stay with the sentence. Never widen it under pressure | F1 and F6 hold the claim a pressure interviewer tests; EXP because it scores attribution honesty and composure together |
| E2 | "Sixty seconds: why you over a candidate who has led a team and worked on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Concede first, in the sentence's own terms: "I haven't led a team, and I haven't worked on a game with in-app purchases." Then hold on what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses." Do not claim you are the better candidate, and end on your plan from B1 | F2 and F9 are the stated gaps this question prices; JD because it scores fit against the stated requirements, under a time box |

### Bank P — Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Where's the seam between a producer and the designers when an event's scope changes late, and what happens when you disagree?" | CASE | [generic] | Do not pretend to know the seam. Propose principles: who decides what, what gets written down, where an unresolved disagreement goes. Describe how you would handle a disagreement as a method, and say what you would ask the design lead in your first week. No claim about your past | The coordination line (F2) in a collegial register; CASE because it scores reasoning, and [generic] because it is a pattern for the problem |
| P2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say "we" for context and "I" for contribution. The attribution you can stand behind is the sentence's own: "Wrote the release checklist our QA team still uses." Say it at those words, and no wider | F4 is the cleanest example of a thing that was yours and is used by another team; EXP because it tests attribution |

### Requirement coverage

| JD requirement | Fit row | Questions |
|---|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | F1 | A1, B3, E1 |
| "coordinate design, art, engineering and community teams on each update" | F2 | A3, B2, P1 |
| "own the post-event review and the KPIs it reports" | F3 | A5, C2 |
| "manage the release checklist with QA" | F4 | A2, C3 |
| "3+ years producing live-service games or apps" | F5 | D1, B4 |
| "experience running a content calendar" | F6 | B3, D1, E1 |
| "comfortable with player-retention metrics" | F7 | A4, A5, C1 |
| "clear written communication" | F8 | D3 |
| In-app-purchase gap (from your message, not the JD) | F9 | B1, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first 90 days look like for this producer across the two titles?" | It asks for the interviewer's own scoring sheet for the role, and it gives you the vocabulary to answer B1 and B3 afterwards |
| R2 | "How does the live-events calendar get decided across the two titles today, and where does the producer sit in that decision?" | It tests the JD's plan-and-run line (F1) against how the studio really works, and it shows you think about the decision, not only the date |
| R3 | "Which KPIs does the post-event review report today, and who chooses them?" | It targets the review-and-KPI line (F3), the row where your material is thinnest, and shows you care who owns the measure |
| R4 | "How does the release checklist work with QA today, and who owns changes to it?" | It picks up the JD's checklist line (F4), where your strongest evidence sits, and moves the talk onto ground you can discuss well |
| R5 | "Where would a new producer need the most support in the first month, and what does onboarding look like there?" | Ask it after B1 has come up. It shows you can name a gap and plan for it, which is the same candor B1 rehearses, and it turns a probe into a plan |
| R6 | "What would tell you in six months that this hire worked?" | It asks for the success measure in the interviewer's own words, so your closing answer can tie back to it |

No reverse question is tied to Tobias's own path, because no public information about him is in hand (see Sources).

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Owned a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for one main title. B3's slot stays inside the weekly calendar |
| Owned the post-event review and chose its KPIs | Inflated form of F3 | F3's quote at its own scope: presented the monthly retention numbers. The slot asks only what sat behind the numbers |
| Managed the release checklist release by release | Inflated form of F4 | F4's quote at its own scope: wrote it, and QA still uses it. C3's slot asks only whether you also ran it |
| Produced a live-service game for four years | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer, and two years on the calendar. The slot asks only whether the title ran live |
| Defined or analysed the retention metrics | Inflated form of F7 | F7's quote at its own scope: presented. C1's slots ask what you know about how the numbers were counted |

## Sources

**Provided documents:** the JD text pasted in your message; your background summary in your message (no CV was provided). No dossier was provided.

**Searches sent, all four refused (the host did not grant search permission):**

- `Saltmarsh Games company values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games mobile studio news strategy` — refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. It would have fed a values cheat sheet and the VAL questions; with no values source in hand, neither is in the pack |
| 2. `{company} interview process {role family}` | unavailable | Every call was refused. It would have named the loop's rounds and fixed the persona weights, which now rest on the generic hiring-manager prior |
| 3. `{company} strategy` / recent news | unavailable | Every call was refused. It would have grounded D2 and added a strategy-based CASE question; D2 is generic instead |
| 4. `{interviewer name} {company}` | unavailable | Every call was refused. It would have given an interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Where Tobias sits relative to the role (your future manager, a skip-level, a peer) and whether Friday is the first round → persona weights recomputed, and banks added or dropped to match
- Web search permission for this session → rerun targets 1 to 4: the studio's published values (and a values cheat sheet if a values-style round turns up), the documented loop, a strategy-grounded version of D2, and an interviewer read with a reverse question tied to Tobias's own path
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, offered once and needing the same permission) → a grounding brief on the studio's current strategy and recent moves
- The names of the two titles → D2 and A1 to A3 can be tailored to what you actually see in them
- Your plain answers, in your own words, to the slots in F1, F2, F3, F5, F7 and F8 → each becomes a quoted evidence cell, and the questions that draw on it become story maps instead of slots
- A CV, or the artifact behind a claim (the release checklist itself, a sanitised view of the content calendar, a monthly retention deck) → F4, F6 and F7 can move from `medium` toward `high`, because something has then been inspected
- The recruiter's prep email, if there is one → whether Friday includes a pre-declared deliverable or stated focus areas, which would add a build section
- A `tuesday-dossier.md` from an earlier run, if you have one → verified evidence and any prohibited claims carried in, with no change to anything above if you do not
