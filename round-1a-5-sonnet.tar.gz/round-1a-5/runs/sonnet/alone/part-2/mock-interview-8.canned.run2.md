I'll read the reference files before building the pack.
Your prep pack is saved as /var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-8-canned-a38cc33d/ashgrove-credit-union_member-experience-lead_interview_pack.md. It has one mini-pack per round for 4 December, 28 questions in all.

I built it from the recruiter's email, because it names each round, its length and who runs it. The two interviewers haven't been assigned yet, so persona weights rest on the round type and the recruiter's description. Everything came from what you pasted, so I ran no searches.

Question 2B1 is the one to rehearse most. It asks about the contact centre, which you've never worked in, for a role that covers both branches and the contact centre. The pack gives you a short acknowledgment, the branch fact at its true scope, and a plan. Presenting above regional level is the second gap and gets its own rehearsal.

Say the word and I'll play the Head of Member Services on 2B1, with follow-ups that react to what you actually say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Built 25 November 2026 for the loop on 4 December 2026, in loop mode: three rounds, one mini-pack each.

| Round | Length | Who | Shape, in the recruiter's words |
|---|---|---|---|
| 1 | 30 minutes | The recruiter | Recruiter screen |
| 2 | 45 minutes | Head of Member Services, "who would be your manager" | "mostly behavioural" |
| 3 | 60 minutes | "a panel of two branch managers" | "including a 20-minute case on a complaint escalation"; "also the values round" |

Interviewers beyond their roles have not been assigned, so no interviewer read is included and persona weights rest on round type and the recruiter's own description of each round.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Wherever a cell says "Answer slot", the words have to come from your own experience: say what happened if it did, and say plainly that it did not if it did not. Both branches are good answers.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows one of Ashgrove's four published values |
| EXP | Whether what you say you did survives follow-up |
| JD | A stated requirement of the job, gaps included |
| CO | Homework on Ashgrove's strategy and position |
| CASE | A live problem from the role, reasoned out loud |

Provenance labels: `[grounded]` traces to what you gave me, `[inferred]` is derived from it, `[generic]` is a pattern with no claim about you or Ashgrove. Where guidance rests on something you said, your sentence is quoted beside the label.

## Prep triage

Nine days, 25 November to 4 December. Hours per day were not stated, so this is an order, not a schedule.

| Order | Do | Tied to |
|---|---|---|
| 1 | Say the contact-centre answer aloud until it is boring: the plain acknowledgment, the branch fact at its own scope, then your plan | 2B1, 1B1, 3B1 |
| 2 | Write your own answers to the answer slots in F1, F3, F4, F5, F7 and F9. Those rows are where your stories come from | Fit snapshot |
| 3 | Run the 20-minute escalation case twice, timed, saying the structure aloud | 3D1 |
| 4 | Choose one story per value, or use the honest branch for any that has none | 3C1 to 3C4 |
| 5 | Say your own pay, notice, location and reason-for-leaving answers aloud once each | 1A4 to 1A7 |
| 6 | Rehearse the presenting answer | 1B2, 2B4 |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process around it, with nothing inspected behind it. The words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's "across branches" wording makes a probe on what sat around the log likely. If any steps before or after the log were yours, say which, in your own words; if there were none, or they were not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet and who uses it, not what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it counted complaint volumes or how long complaints took to resolve, say how, in your own words; if it counted something else, or you do not recall, say so plainly and stay with the spreadsheet |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you have coached anyone above teller level on escalations, say who and how; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show whether this exists. Answer slot: if you have worked with any digital or online-banking team, say what and which part was yours; if not, say so plainly, then say how you would start, as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says "formal", not what rules applied to those complaints. Answer slot: if rules from a regulator or an internal policy shaped how the log was kept, say which and what they asked of you; if you are not sure, or none applied, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated limit. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan. The JD does not say whether regional level counts as senior leaders here, so that is the pack's own open point |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says "spreadsheet", not which tool. Answer slot: name the tool you built it in, in your own words; if you are not sure it was Excel, say so plainly and describe what the spreadsheet did |

## Grounding brief: Ashgrove's strategy

The four points below are as you relayed them from the July 2026 strategy brief the recruiter sent. I did not have the brief itself.

| Point (as you relayed it) | Provenance | Where this pack uses it |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | [grounded] | 1A3, 2D1 |
| "consolidate eight branches into five hubs over 2027" | [grounded] | 3D2, 3E1, reverse questions in round 3 |
| "launch a small-business lending product in Q1 2027" | [grounded] | 3D3 |
| "the main competitive pressure is app-only banks" | [grounded] | 1A3, 2D1 |

The brief is equally available to every other candidate, so the pack asks you to bring one item from it to show homework and then a view of your own, with a concession, never a recitation.

---

# Round 1: Recruiter screen, 30 minutes

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background, motivation and logistics | High: the recruiter's note describes a 30-minute conversation "with me", and a recruiter screen is mostly this register | A 90-second arc built from your own sentences; treat casual questions as scored |
| Skeptic, light | Knockout checks on the two gaps your material shows | Medium: F2 and F8 are the JD requirements your message says you lack | Plain acknowledgment, the branch fact at its own scope, a short plan |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Four beats, each only what your sentences state: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Tell them in your own words, then close on why this role, which only you can supply | F6 and F1 are the evidence the recruiter is screening against, and the biography question is where they are first said aloud. EXP because it checks that the story holds together |
| 1A2 | "Why Ashgrove, and why a member-owned credit union?" | CO | [grounded] | Use Ashgrove's own published words for the one value you can speak to truthfully, for example "Members First, Always — we decide from the member's side of the counter", then say in your own words why it matters to you. Do not recite all four | The values page you supplied is the raising source. CO because it scores homework and genuine interest rather than past work |
| 1A3 | "What do you know about where we're heading?" | CO | [grounded] | Bring one item from the brief to show you read it, for example "move 40% of member service to digital channels by 2028". Then one view of your own, as a view: a complaints lead would want to know which channel a complaint starts in, so reporting needs to cover digital as well as branches and calls. Concede plainly that you do not yet know Ashgrove's channel mix | The brief is shared with every candidate, so the item proves grounding and the view is what differentiates. The 40% and app-only-bank points are the ones closest to this job |
| 1A4 | "What's prompting a move now?" | EXP | [generic] | Logistics slot: give your own reason in one or two sentences, in true terms. This pack supplies no reason | Recruiters score consistency between this answer and the rest of the story. EXP because it tests candour about your own history |
| 1A5 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure or range, or ask for the role's band first. If asked what you earn now, you can say: "I'd rather focus on the range for this role" | The recruiter needs a figure to continue the process. JD because it concerns the listed job's terms |
| 1A6 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | A start-date check, scored as plain accuracy. JD because it concerns the job's terms |
| 1A7 | "Where are you based, and would travelling between sites work for you?" | JD | [generic] | Logistics slot: give where you are based and any limits you have on travel between sites. If the recruiter has not said where the role sits, ask | The JD says the role works "across branches", so a location probe is likely. JD because it concerns the job's terms |
| 1B1 | "The role covers the contact centre, and you haven't worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Short version of 2B1: "I haven't worked in a contact centre." Then the branch fact at its own scope: "I handled the branch's formal complaints log." Then one sentence on what you would learn first and from whom, as a plan. Stop there | F2 is the gap the screen is most likely to flag. The full rehearsal sits in 2B1; here the goal is a calm, short answer |
| 1B2 | "The role presents to senior leaders. What's your experience of that?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Plain acknowledgment: "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and about what; if not, say so plainly. Then how you would prepare, as a plan. The spreadsheet can be named at its own scope: you built it and your regional manager uses it | F8 is the second knockout check. JD because it scores the stated requirement |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Who will I meet on the panel, and what does the 20-minute case look like: paper, role-play or discussion?" | The interviewers are unassigned and the case format cannot be researched. A recruiter can usually answer in one email, and the answer lets this pack be sharpened |
| R1.2 | "What does the hiring team most need this role to change in its first year?" | Shows you are thinking about the job rather than the title, and gives you language for rounds 2 and 3 |
| R1.3 | "How is complaints work organised today between branches and the contact centre?" | Directly addresses F2: it signals you are already working out the ground you would own |
| R1.4 | "Which teams would I work with most, including the digital teams?" | Addresses F5 and shows you read the JD's last line |
| R1.5 | "What's the timeline after 4 December?" | A practical close that shows readiness and keeps the process moving |

---

# Round 2: Head of Member Services, 45 minutes

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Tell-me-about-a-time questions drawn from the JD's themes | High: the recruiter's note calls this round "mostly behavioural" | A story per theme where one of your sentences carries one; the honest branch where none does |
| Skeptic | Quiet probing of F2, F7, F8 and F3 | High: this person "would be your manager" and is the one deciding what risk is hiring you | Rehearse the single most predictable objection (2B1) until it is boring |
| Case / Strategist | One or two live problems from the role and the strategy | Lower: the round is described as mostly behavioural, but the 40% digital target sits squarely in a Head of Member Services' remit | Clarify, then structure, then answer; use Ashgrove's own words |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2B1 | "The job owns complaints across the branches and the contact centre, and you haven't worked in a contact centre. What does your first quarter look like?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "6 years in retail banking, the last 3 as a branch supervisor" | **Highest-ROI prep in this pack.** Level one: "I haven't worked in a contact centre." Then hold on what you said: "I handled the branch's formal complaints log" and six years in retail banking. Level two, if pressed on credibility with people who know the contact centre better: do not claim equivalence; concede specifically that you do not yet know how complaints reach that team or how it differs from a branch, then give a plan in your own words: who you would learn from first and what you would ask to see. Level three, if asked why you: return to the two quotes and stop. The limit, named before it is asked: your material says the branch log, not the contact centre and not the process around it | F2 is the largest gap against a requirement that sits in the JD's first line, and this interviewer would be your manager. JD because it scores the stated scope; the deepest follow-up levels are here because this is where the material is thinnest |
| 2B2 | "Tell me about the formal complaints log you handled. How did it work, and what made those complaints formal?" | EXP | [grounded] "I handled the branch's formal complaints log" | Describe the log at the scope you stated and no wider. Answer slot: the JD's "regulated complaints" makes a probe on the rules likely. If rules from a regulator or an internal policy shaped how the log was kept, say which and what they asked of you; if you are not sure, or none applied, say so plainly and stay with the log you handled | F7 is the requirement the JD names most specifically. EXP because it checks what the log was and what part of it was yours |
| 2B3 | "Tell me about the monthly complaints spreadsheet you built. What did it track, and what did you build it in?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it was: a monthly complaints spreadsheet your regional manager uses. Answer slot: if it counted complaint volumes or resolution times, say how, in your own words; if it counted something else, or you do not recall, say so plainly. Name the tool you built it in; if you are not sure it was Excel, say that | F3 and F9 both rest on one sentence, so a probe on it is likely. EXP and JD, dual; EXP because it tests what you actually built |
| 2B4 | "How would you approach presenting complaint results to our senior leadership?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | "I haven't presented to anyone above regional level." Then your plan, in your own words: what you would want a senior reader to take away and how you would test your pack with someone first. The spreadsheet can be named at its own scope: you built it and your regional manager uses it | F8 is a stated limit; the rehearsal is a calm acknowledgment and a concrete plan, not a claim of experience |
| 2C1 | "Tell me about a time you coached someone through an escalation." | VAL | [grounded] "trained new tellers on our escalation script" | Story map: you trained new tellers on the escalation script; tell it in your own words at that scope. Answer slot: the JD says supervisors, so expect a probe on someone above teller level. If you have coached anyone above teller level, say who and how; if not, say so plainly and stay with the tellers | F4's gap is scope: tellers versus supervisors. The JD's coaching line is the raising source |
| 2C2 | "Tell me about a time you gave leadership news about complaints they would not like." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: pick a time with a named audience, a message that was uncomfortable, a moment you did not soften it, and a working relationship intact afterwards. The spreadsheet is the nearest thing your material carries and shows only that your regional manager uses it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's senior-leader reporting line is the raising source. VAL because it scores candour upward, which Ashgrove's "Plain Words" and "Own the Fix" echo |
| 2C3 | "Tell me about a time you worked with a team outside your branch to change something members use themselves." | JD | [generic] | Selection scaffold: pick a time with a named team, a member-facing thing that changed, and a part that was clearly yours. If no such time comes to mind, say so plainly, then say how you would start working with a digital team, as a plan | F5 has no evidence either way. The JD's digital line is the raising source. The honest branch is a plan, never a past |
| 2C4 | "Tell me about a time you stayed with a member's problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick one complaint with a named member situation, a point where it could have been passed on and was not, and an outcome you can state. The log is the nearest thing your material carries and shows only that you handled it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry. Reuse this story for 3C4 | "Own the Fix — whoever finds the problem keeps hold of it until it is solved" is the raising source. Using one story twice saves rehearsal time |
| 2D1 | "40% of member service moves digital by 2028 and app-only banks are the main competitive pressure. What happens to complaints?" | CO | [grounded] | Clarify first: which channels now, what a digital complaint looks like, what is tracked. Then a view, labelled as a view: where complaints start changes, so reporting needs a channel field and a hand-off rule. Concede that you do not know Ashgrove's current channel mix | The brief's two headline points are the raising source. CO because it scores thinking at Ashgrove's altitude |
| 2D2 | "Suppose branches and the contact centre record complaints differently. How would you build one monthly report?" | CASE | [generic] | Structure: ask what each records and what leaders decide from the report; agree a small set of shared fields, volumes and resolution times first; build the report; test it with one branch and one contact-centre colleague; name what could go wrong. No claim about your past | The JD's monthly-reporting line is the raising source; asks about no past, and so presupposes nothing |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would you most want the monthly complaints report to tell senior leaders?" | Turns the reporting requirement into a shared goal and tells you what to build first |
| R2.2 | "Who in the contact centre would I learn the ground from in my first weeks?" | Converts F2 from a gap to a plan, in the interviewer's own team |
| R2.3 | "Where do you expect the digital shift to touch complaints first?" | Ties to the strategy brief and F5 without claiming experience |
| R2.4 | "What does success look like at six months?" | Gives you the manager's scoring sheet |
| R2.5 | "What's the hardest thing about complaints at Ashgrove right now?" | Invites the manager to name the real problem; their answer is material for round 3 |

---

# Round 3: Panel of two branch managers, 60 minutes, values round

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Questions scored against the four published values | Very high: the recruiter's note says the panel "score against the four values" | One story per value, or the honest branch |
| Case / Strategist | The 20-minute complaint-escalation case, plus strategy cases | High: a 20-minute case is stated in the recruiter's note | Clarify, objective, approach, metrics, risks; say the structure aloud |
| Peer Evaluator | Branch managers pricing what you cost and add to their branches | Medium: the role coaches branch supervisors and the brief says eight branches become five hubs over 2027, so branch managers may have a stake | Reciprocity framing; seam principles rather than pretending to know the seam |
| Skeptic | One probe on day-one weakness | Low: carried over from round 2 | Pick a limit that is true, then a plan |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold for "Members First, Always": pick a time with a named member situation, a decision you made, and what it cost the branch or you. Your six years and three as a branch supervisor are where to look; the sentence shows the role, not a decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value is published word for word, and "the counter" is branch language, so branch managers will hear it closely |
| 3C2 | "When has something needed explaining twice, and what did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold for "Plain Words": pick a time with a named explanation that did not land, a change in wording, and a result. The script training is the nearest thing your material carries and shows only that you trained tellers on it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | "If a member needs it explained twice, we wrote it wrong" is the published definition |
| 3C3 | "Tell me about a time you changed how you worked to fit a particular community or branch." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold for "Neighbours, Not Numbers": pick a time with a named branch or town, a specific change, and a reason it mattered locally. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | "Every branch is part of its town" will land differently with branch managers than with anyone else, given the hub consolidation in the brief |
| 3C4 | "Whoever finds the problem keeps hold of it until it is solved. Tell me about a time that was you, or a time it wasn't." | VAL | [grounded] "I handled the branch's formal complaints log" | Reuse the 2C4 story. The "or a time it wasn't" wording lets a candid answer score well: say what happened, what you did next, and what you would do now. The log shows only that you handled it | "Own the Fix" is the value closest to the job itself |
| 3D1 | The 20-minute case: "A member complained at a branch twice and phoned the contact centre once, and nobody has connected the three. The branch supervisor has escalated to you. What do you do?" | CASE | [generic] | Say the structure aloud. Clarify first: what the member is complaining about, what they were told, any deadlines or reporting duties that apply, ask the panel which. Objective: the member's problem solved and one named owner. Approach in plain words to the member, then who holds it internally. Metrics: resolution time and repeat contacts. Risks: handing it on, losing the thread across channels. Challenge one premise respectfully. No claim about your past | The recruiter's note names a complaint-escalation case, so this is the highest-likelihood shape; the scenario itself is a pattern, not Ashgrove's |
| 3D2 | "From 2027 eight branches become five hubs. How should complaints work for a member whose branch changes?" | CASE | [grounded] | Clarify first: which branches, when, how complaints flow now. Principles, not a design: a member never repeats their story; the person who receives a complaint keeps hold of it; wording stays plain. Name the tension with "Neighbours, Not Numbers" yourself and do not take a side on the consolidation. Concede that you do not know the plan | The brief's consolidation point is the raising source, and branch managers are the audience |
| 3D3 | "A small-business lending product launches in Q1 2027. What would you want in place in the complaints process first?" | CASE | [grounded] | Clarify first: who the members are, who they would call, what the product promises. Then principles: a named owner, plain-word explanations, a way to see complaints by product. Concede what you would need to learn | The brief's Q1 2027 launch is the raising source |
| 3E1 | "You'd be coaching our supervisors. What do you do when one says the escalation process doesn't work for their branch?" | CASE | [grounded] "trained new tellers on our escalation script" | Seam principles: listen first, find what specifically fails, separate a genuine gap from a habit, take real gaps back to the process owner. Only your own sentence can anchor it: you trained new tellers on the escalation script. Nothing here claims you coached supervisors | The panel are the people you would coach; F4's scope gap makes this a likely probe |
| 3E2 | "What do you need from us, and what can we expect from you in the first month?" | JD | [generic] | Reciprocity first: what you would give their branches, then what you need. Propose principles, not promises | A peer-style question scoring partnership fit |
| 3B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick the limit that is true for you. Either "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level", then your plan for it. Do not offer a weakness you do not have | F2 and F8 are the stated limits; the honest pick is one of them |

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No row carries a story. Selection scaffold in 3C1, ending in the honest branch. Nearest: F6, "6 years in retail banking, the last 3 as a branch supervisor" |
| Plain Words | If a member needed it explained twice, the wording is the problem | No row carries a story. Selection scaffold in 3C2, ending in the honest branch. Nearest: F4, "trained new tellers on our escalation script" |
| Neighbours, Not Numbers | Every branch belongs to its town | No row carries a story. Selection scaffold in 3C3, ending in the honest branch. Nearest: F6, "6 years in retail banking, the last 3 as a branch supervisor" |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | No row carries a story. Selection scaffold in 3C4 and 2C4, ending in the honest branch. Nearest: F1, "I handled the branch's formal complaints log" |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does a good escalation look like from where you sit, and what does a bad one cost your branch?" | Puts the panel in the role of the people you would coach, and tells you how they score the case |
| R3.2 | "How do you see complaint handling changing as branches become hubs?" | Ties to the brief and invites their view rather than yours |
| R3.3 | "What do your supervisors most need from a complaints lead?" | Addresses F4 directly and shows the coaching is for them |
| R3.4 | "What could I do in the first month that would genuinely help your branches?" | Reciprocity: you are pricing your contribution to their work |
| R3.5 | "Which of the four values is tested most in your branch day to day?" | Shows you read the values as working principles, not slogans |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | 1B1, 2B1, 2D2, 3D1, 3D2 |
| "report monthly on complaint volumes and resolution times" | 2B3, 2D2 |
| "coach branch supervisors on escalations" | 2C1, 3E1 |
| "work with digital teams on self-service journeys" | 2C3, 2D1 |
| "4+ years in financial-services customer operations" | 1A1 |
| "experience handling regulated complaints" | 2B2, 3D1 |
| "confident presenting to senior leaders" | 1B2, 2B4, 2C2, 3B1 |
| "comfortable with Excel reporting" | 2B3 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not the process around it |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log". The material does not say which rules applied |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: you built the monthly complaints spreadsheet your regional manager uses. The material does not say what it counted |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: you trained new tellers on the escalation script |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description; Ashgrove's published values, pasted from ashgrovecu.org/about/values on 25 November 2026; the recruiter's email about the process; the 2026 strategy brief points as you relayed them; your background as you described it. No `tuesday-dossier.md` was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values page fixes the values cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email names each round's length, who runs it and what it holds, so it fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The four brief points you relayed fix the CO and CASE questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name was given, only titles, so there was no query to form; no interviewer read |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names, once assigned → an interviewer read for rounds 2 and 3, persona weights adjusted from their public footprint, and a reverse question tied to each one's own path
- Your own answers to the answer slots in F1, F3, F4, F5, F7 and F9 → those rows change from `discovery` or `transferability` to grounded stories, and the guidance in 1A1, 2B2, 2B3, 2C1 and 2C3 becomes story-mapped
- A sanitised copy of the monthly complaints spreadsheet, or an extract of the complaints log → F3, F7 and F9 move from `medium` confidence to `high`, since those are the artifacts this field keeps
- The recruiter's answer on what the 20-minute case looks like (paper, role-play or discussion) and whether materials are provided → 3D1 reshaped to that format
- Hours per day available before 4 December → the prep triage resized to them
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, on the strategy brief itself, role-family loop reports, interviewer public footprint once names exist, and recent organisation context → fuller CO and CASE questions in place of the pattern-level ones
- A `tuesday-dossier.md` from an earlier pass over this role → verified evidence and a sourced prohibited-claims list replacing the one built locally here
