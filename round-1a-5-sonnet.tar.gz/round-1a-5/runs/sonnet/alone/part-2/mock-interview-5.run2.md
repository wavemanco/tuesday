Web search was refused, so I'm building from what you've told me and the recruiter's email. I'm writing the pack now.
Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md`.

I couldn't run any research. All six web searches were refused, so nothing in the pack describes Kelverton beyond what you told me. I also can't see the market report the recruiter attached. The pack builds the POV on role-generic theses and tells you where to test each one against the report.

- **Assumption it's built on:** a panel with Deepa as your future manager and Ross as the commercial voice, using only the recruiter's email and your background.
- **Highest-ROI prep:** C1, "You've never carried a direct quota. Why should we trust you with commercial outcomes here?" It's laid out with the exact concession wording and three follow-ups. The POV is a separate build section, with three theses to choose from, each with a concession, plus an anti-pick and the operator close.
- **Your four hours:** the prep triage splits them into five blocks and says what to skip.

Say the word and I'll play the Skeptic on C1, with Ross pushing on commercials.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the job description to paste? It would turn the requirement rows from the recruiter's wording into the posting's own list, and could add or reorder questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail — Senior Partnerships Manager: second-round panel prep pack

- **Round:** second round, one 60-minute panel on Tuesday. Panel per the recruiter's email, as you quoted it: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your spoken POV, no slides; the rest is Q&A, and "Ross will push on commercials".
- **Built on:** your message and the recruiter's email as you quoted it. No web research ran: all six searches were refused (see Sources). The JD and the market report were not in hand, so nothing here describes Kelverton beyond what you wrote.
- **Prep time:** about four hours across the weekend.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview, not a question to me: fill it from your own experience, or take the plain branch it offers.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none in this pack: no values round is documented and no values page was read) |
| EXP | Whether claims about your experience survive scrutiny, and what was actually you |
| JD | The role's stated requirements, including the gaps |
| CO | Company and market knowledge, and thinking at the company's altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

## Prep triage

| Block | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 60 min | Build the POV outline aloud: choose a lead thesis, its concession, one anti-pick, and the operator close. Reread the market report for one consensus item and one point of divergence | Graded deliverables, A2, A3, A4 |
| 2 | 45 min | Rehearse C1 aloud until it is boring, then C2 and D1 | C1, C2, D1 |
| 3 | 45 min | Defend the figure: write down what you know and do not know about how it was counted, then answer B1, B2, B4 and D2 out loud | F3, B1, B2, B4, D2 |
| 4 | 45 min | Run the full POV against a timer and cut it to fit 15 minutes, then field A1 and A5 | Graded deliverables, A1, A5 |
| 5 | 45 min | Reverse questions, the 90-second arc, and the motivation answer | Reverse questions, F1, C3 |

Everything else (B3, E1, E2, F2, D3) is insurance: read it once, rehearse only if time is left.

## Fit snapshot

Requirements are the recruiter's words as you quoted them, plus your own description of what Kelverton sells. No JD was supplied, so there are no JD-quoted rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company and a partner count that grew; it does not show what Kelverton's operator partnerships are, which is the pack's observation. Words: "For the last four years I ran the ISV channel at a payments company, and I took it from 6 partners to 40." Answer slot: the recruiter's 18-month ask makes a probe on what carries over to operator partnerships likely. If you know what Kelverton means by operator partnerships, say what carries over, in your own words; if little does, say so plainly and stay with the channel as you ran it |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email, quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Words: "I spent five years in transport consulting, on bus and light rail network planning." The pack's observation: the quote says bus and light rail, not train operating companies, and does not say whose side "the other side" was. Answer slot: if asked what "the other side" meant, say who you worked for and what you did for them, in your own words; if the work did not put you in contact with operators, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter's email, quoted in your message | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The noun stays "influenced": "I took it from 6 partners to 40, with roughly £4M of influenced revenue." The pack's observation: your message does not say what period the figure covers. Answer slots a figure raises: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly |
| F4 | "Ross will push on commercials" — recruiter's email, quoted in your message | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't carried a direct quota; what I had was influenced revenue." Then how you would learn Kelverton's commercial model, said as a plan and never as a past: what you would ask first about how partnership targets are set and counted. Nothing added to make the gap feel smaller |
| F5 | "they sell scheduling software to train operating companies" — your description of Kelverton | "Never sold into rail specifically" — your message | none | [grounded] | capability | Words: "I haven't sold into rail." Then a plan, never a past: what you would want to learn first about how train operating companies buy. Never a claim to rail sales work |
| F6 | "First 15 minutes we'd like you to present a short POV ... no slides needed, just talk us through it" — recruiter's email, quoted in your message | none given | none | [grounded] | discovery | Answer slot: the no-slides format makes a probe on how you structure an unscripted argument likely. If you have presented a POV to a panel before, say when and to whom, in your own words; if not, say so plainly, and rehearse this one aloud against a timer |

## Graded deliverable: the 15-minute POV

The recruiter's brief, in their words as you quoted them: "present a short POV on where you'd take our operator partnerships over the next 18 months", "no slides needed, just talk us through it", and "Please land on what it means for the operators themselves". Ross "will push on commercials", so every thesis needs a commercial check you can say aloud.

**Facts to build on**

| Fact | Source | Provenance |
|---|---|---|
| "UK rail-tech, ~600 staff, they sell scheduling software to train operating companies" | Your message | [grounded] |
| "the market report their strategy team circulated internally last quarter, which I've read" — the pack has not seen its contents | Your message | [grounded] |
| F1: "took it from 6 partners to 40" | Your message, row F1 | [grounded] |
| F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Your message, row F2 | [grounded] |

**Three theses to choose between.** Each is a position to test against the market report, not a finding about Kelverton. Pick one lead thesis and keep a second in reserve.

| # | Thesis | What it means for operators | Mandatory concession | Provenance | Evidence you may cite |
|---|---|---|---|---|---|
| T1 | Anchor operator partnerships on outcomes an operator already measures, and plan the 18 months around them | Partnerships are judged in the operator's own terms rather than the vendor's | You cannot name those outcomes or set targets without Kelverton's delivery data, and the report may point elsewhere | [generic] | F2: "5 years in transport consulting (bus and light rail network planning" at that scope only |
| T2 | Fewer, deeper operator relationships beat a wider partner count, if the operators Kelverton sells to are a short named list (check this in the report) | A named, accountable relationship instead of another vendor touchpoint | You are arguing against the metric you grew: F1 says "took it from 6 partners to 40". Depth costs reach, and reach may matter more than you think | [generic] | F1: "took it from 6 partners to 40" at its own scope |
| T3 | Use partners to widen what an operator can adopt without Kelverton building it | Less integration burden on the operator | Partners can collide with direct sales, which is Ross's ground, and operators may prefer one accountable supplier. Prove one partner commercially before adding a second | [generic] | F1: "running the ISV channel" at its own scope |

**Differentiation.** The report is equally available to both panelists and to any other prepared candidate, so do not recite it. Bring one consensus item from its shortlist to show you have read it, then one thesis-driven divergence with your reasons. Check whether anything in it has moved since last quarter, without correcting the panel. T2 is the natural divergence because it argues against partner count, but only keep it if the report supports its "short named list" condition.

**Anti-pick.** Name one thing you would decline to do in the first 18 months, and why. It shows judgment, and A2 rehearses it.

**Suggested shape, 15 minutes:** say how you read "operator partnerships" and invite correction (1); the consensus item (2); your lead thesis and its commercial check (6); the concession (2); the anti-pick (1); the operator close (3). The close is the requested one: finish from the operator's seat, in one or two sentences of your own, on what an operator would see differently in 18 months. Draft it from your thesis, not from a memory you do not have.

## Persona table

The loop is the one the recruiter's email describes: one 60-minute panel, a 15-minute POV and then Q&A. Weights rest on that, the recruiter's note about Ross, and relationship priors. No interviewer profile exists, so there are no profile-based adjustments.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A, 5 questions) | Probing the POV: assumptions, what you would drop, what it means for operators | High. The recruiter made a strategy case the first 15 minutes; a hiring manager's prior is Case/Strategist plus Skeptic | Clarify before structuring, state the hypothesis early, challenge one premise respectfully |
| Data-Driven Prober (B, 4) | Ross pressing the commercial figure and the economics of a partner deal | High. The recruiter said "Ross will push on commercials", and F3 is the quantified claim | Know what you can and cannot say about how the figure was counted; name the assumption you would defend least before he does |
| Skeptic (C, 3) | The gaps: no direct quota, no rail sales, bus and light rail rather than train operating companies, why now | High in likelihood, mid in depth because C1 gets the deepest rehearsal regardless. F4 and F5 are stated negatives and the hiring-manager prior includes Skeptic | Rehearse C1 until boring; bridge only from what you stated; a concrete plan for what you would learn |
| Pressure (D, 3) | Time-boxed, devil's-advocate versions of the same gaps | Medium. A commercial director on a manager's panel tilts executive, and Ross is the one expected to push | Pause, restate, hold through two follow-ups, then concede specifically |
| Peer Evaluator (E, 2) | The partnerships and direct-sales seam | Low to medium. Commercial and partnerships are adjacent functions; nothing in the recruiter's note points here | Offer seam principles rather than pretending to know the seam; say what you would bring to their team |
| Conversational (F, 2) | An opening "walk me through the journey", or casual curiosity probes | Low. A POV-plus-Q&A hour leaves little room for rapport, but the biography question usually still comes | A 90-second arc built from your own sentences; treat casual questions as scored |
| Values/Behavioral | Not weighted | No values round is documented in the recruiter's description of the loop and no values page was read | None needed |

## Question banks

**C1 is the highest-ROI prep in this pack.** It will be asked in some form, F4 is where your material is thinnest against Ross's brief, and a rehearsed, non-defensive answer changes the hour.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What did you have to assume about our operator partnerships to build that view?" | CASE | [generic] | Name how you read "operator partnerships" when you opened, the one assumption you would least like to be wrong about, and what would change your view. Where you do not know something, say so plainly. The question needs no claim about your past, so the guidance makes none | The no-slides, talk-us-through-it format makes assumptions the natural probe, and F1 shows the pack could not see what the term covers. CASE because it scores reasoning, not history |
| A2 | "Where would you say no in the first 18 months?" | CASE | [generic] | Name one thing you would decline and give the reason in operator terms, then the cost of declining it. A thesis that argues for depth over count gives you an honest anti-pick. No claim about your past | The anti-pick separates a consensus answer from a judgment, and Ross's commercial lens makes the cost of a no part of the answer. CASE because it is a live trade-off |
| A3 | "What does that mean for the operators themselves?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Close from the operator's seat in one sentence taken from your lead thesis. You may mention five years in transport consulting on bus and light rail network planning, at that scope; do not describe train operations as something you have done. Answer slot: if you can name an outcome from that consulting work that mattered to an operator, say what it was; if none comes to mind, say so plainly and give the close as your view, not a memory | The recruiter asked for this close in so many words, so it is the one requirement certain to be scored. F2 is the only evidence that reaches it. JD because it scores a stated ask |
| A4 | "Which finding in the market report do you disagree with, and why?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Bring one consensus item to show you read it, then one disagreement with your reason. Answer slot: if a finding does not hold up for you, say which; if you agree with all of it, say so and say where you would test it first. The pack has not seen the report, so check the guidance against it | A document the recruiter sent is equally available to every prepared candidate, so reciting it scores as homework and departing from it with reasons scores as judgment. CO because it tests company-level thinking |
| A5 | "If I asked you to put one number on success at month 18, what would it be?" | CASE | [generic] | Pick a measure an operator would recognise, say you would first ask what Kelverton tracks today, and say how you would get a baseline. Concede that you cannot set a number without Kelverton's data. No claim about your past | A bridge from Deepa's strategic case to Ross's commercial push, which the recruiter's note makes likely. CASE because it asks you to structure a decision |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You mention roughly £4M of influenced revenue. How was that counted?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Keep "influenced" in every sentence. Answer slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly and say what you do know | F3 is the figure Ross is expected to press, and naming the weakest assumption before he does turns a probe into a credibility gain. EXP because it tests whether the claim survives scrutiny |
| B2 | "Which part of taking it from 6 partners to 40 was yours?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say it in the quotes' terms: you ran the ISV channel for the last four years at a payments company, and you took it from 6 partners to 40. Answer slot: say which parts were yours alone and which were shared with or done by others; if any part was not yours, say so plainly | Attribution probes are asked of any headline number, and F1 and F3 carry two. EXP because it tests what was actually yours |
| B3 | "What would you want in a partner deal before you called it commercially worth doing?" | CASE | [generic] | Clarify first by asking how Kelverton prices and sells today, and say you have not seen it. Then structure: what the operator gets, what Kelverton gives, who carries the risk, and how you would measure it. The question needs no claim about your past, so the guidance makes none | "Ross will push on commercials" is the raising source, and F4 means the pack will not coach any claim about structuring deals. CASE because it is a live problem |
| B4 | "Influenced revenue: what would have happened to it without the partners?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | This is the weakest-assumption slot in its sharpest form. Say in your own words what you know about that, and if you do not know what would have happened without the partners, say so plainly. Do not say the partners caused the revenue | The sharpest follow-up to B1, and F3's "influenced" invites it. EXP because it tests how well you know your own figure |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never carried a direct quota. Why should we trust you with commercial outcomes here?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | The limit first, as the pack's observation: your material gives influenced revenue and a partner count, and does not show whose number was on the line. Hold-then-concede, with the concession worded exactly: "I haven't carried a direct quota. I ran the ISV channel and took it from 6 partners to 40, with roughly £4M of influenced revenue." Follow-up 1, what was the difference in practice: answer slot, say in your own words how that revenue was measured and reported; if you do not know, say so plainly. Follow-up 2, how would we know you could carry one: return to the sentence above, concede it is a fair limit, then give a plan, never a past: you would ask how targets are set and counted before accepting one. Follow-up 3, would you take a quota here: your own answer, nothing committed beyond what you mean. Never upgrade "influenced" to "owned" | F4 is the stated gap and F3 the nearest evidence, and the recruiter said Ross will push on commercials, so this arrives in some form. JD because it scores the stated commercial requirement against a gap |
| C2 | "You've never sold into rail. What would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Plain acknowledgment first: "I haven't sold into rail." Then what your material carries, at its own scope: five years of transport consulting on bus and light rail network planning. Then a plan, never a past: the first things you would learn about how train operating companies buy. Answer slot: if you can name the one thing about selling into rail you would know least, say it; if you cannot, say so plainly | F5 is the second stated gap and F2 is adjacent, not direct. JD because the question scores a stated requirement; the Skeptic delivers it quietly |
| C3 | "Why leave payments for rail-tech now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Your reason is yours, and the pack does not know it. Answer slot: give your actual reason in one sentence, in your own words. The arc can run in the quotes' order: five years of transport consulting, then partnerships, the last four years on the ISV channel at a payments company. If the move was circumstance rather than choice, say so plainly | The "why leave, why here, why now" probe tests motivation consistency, and F1 and F2 give the arc it will be checked against. EXP because it tests your own history |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you rather than someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause and restate the question. Hold only what the quotes carry: you ran the ISV channel for the last four years at a payments company, and spent five years in transport consulting on bus and light rail network planning. Concede plainly: "I haven't sold into rail." Hold through two follow-ups by returning to those sentences. Make no claim about other candidates | F5 is the gap a time-boxed challenger will lean on. JD because the content is the stated requirement; the Pressure persona is the delivery |
| D2 | "How much of that £4M was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | Pause first. Answer slot: say which part was yours and which was shared with or done by others, in your own words; if you do not know how the figure was split, say so plainly. Keep "influenced" in the sentence. Hold through two follow-ups by returning to what you can say, then concede the specific thing you cannot | The pressure form of B2, aimed at F3. EXP because it tests attribution under composure |
| D3 | "You ran an ISV channel at a payments company. How does that carry over to operator partnerships?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Answer slot: the recruiter's "operator partnerships" makes a probe on what transfers likely. If you can say what carries over from the channel as you ran it, say it in one example from your own experience; if little does, say so plainly, then say what you would need to learn. No claim about operator partnerships you have not seen | F1 is a transferability gap, and the question is its direct form. JD because it scores a stated ask |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where do partnerships stop and direct sales start here, and what happens when we disagree?" | CASE | [generic] | Ask how the line works today first. Then offer seam principles rather than a claimed seam, and say what you would bring to the commercial team rather than only what you would need from it. No claim about your past | A Commercial Director sits next to partnerships, and the seam question is the usual collegial form of the commercial push. CASE because it is a live problem with no past presupposed |
| E2 | "Tell me about a time credit for a result was shared across teams." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Selection scaffold: pick a time credit for a result was split between you and another team. It needs the result, who else was involved, and how credit was decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The credit-sharing probe is a standard peer stem, and F3's "influenced" is the nearest thing the material carries. EXP because it asks for a past instance |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through the journey, from transport consulting to here." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40" | A 90-second arc in the quotes' order: five years of transport consulting on bus and light rail network planning, then partnerships, the last four years running the ISV channel at a payments company, where you took it from 6 partners to 40. Answer slot: the reason for each move is yours; give it in your own words, and if a move was circumstance rather than choice, say so plainly | The biography question is the usual opener of a casual register, and F1 and F2 are the sentences it is checked against. EXP because it tests your own history |
| F2 | "What are you most curious about in how our operators buy and adopt scheduling software?" | CO | [generic] | Ask something you genuinely want answered, ideally tied to a point in the market report. Do not pretend to know the answer. The question needs no claim about your past, so the guidance makes none | A casual curiosity probe is scored for genuine interest and homework. CO because it tests how you think about the company's customers |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" | A1, A2, A5, B3, D3, and the POV build section |
| "what it means for the operators themselves" | A3, F2 |
| "Ross will push on commercials" | A5, B1, B2, B3, B4, C1, D2, E1, E2 |
| Never carried a direct quota (stated) | C1, D2 |
| Never sold into rail (stated) | C2, D1 |
| The no-slides 15-minute POV | The POV build section, A1, A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | To Deepa: "What would a good first 90 days in this role look like to you, and what would you want to see changed by then?" | It shows you plan against outcomes, and her answer tells you what she will score |
| 2 | To Deepa: "When you say operator partnerships, which relationships does that cover today, and which are you hoping to open?" | The term was never defined to you, so her answer tells you whether your POV's reading matched hers |
| 3 | To Ross: "How do partnerships and direct sales share credit and avoid overlap today?" | It meets his commercial lens directly and shows you are thinking about the seam before you are asked |
| 4 | To Ross: "A year from now, what would make you say partnerships has earned its commercial case?" | It turns his push into criteria you can plan against |
| 5 | To both, a reciprocity question: "What could a new person do in their first month that would genuinely help your team?" | It signals you think about what you bring them, which the Peer persona scores |
| 6 | To Deepa: "Did the strategy team's report change anything in how you are planning operator partnerships?" | It ties to the document the recruiter chose to send and shows you read it as a working paper |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail or into train operating companies | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't sold into rail." No slot |
| Carried a revenue quota, or closed the £4M directly | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't carried a direct quota; what I had was influenced revenue." No slot |
| Generated £4M of revenue | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue." The limit is the pack's observation: your message says influenced, and does not say what period it covers |
| Knows train operating companies' operations from the inside | Inflated form of F2 | F2's quote at its own scope: five years of transport consulting on bus and light rail network planning. The limit is the pack's observation: the quote says bus and light rail, not train operating companies |

## Sources

**Provided documents:** your message, including the recruiter's email as you quoted it, your own background, and your description of Kelverton. The market report attached to the recruiter's email was not available to this pack and nothing in it was used.

**Searches sent, all refused:**
- `Kelverton Rail company values` — refused
- `Kelverton Rail interview process partnerships manager` — refused
- `Kelverton Rail scheduling software train operating companies strategy news` — refused
- `Deepa VP Partnerships Kelverton Rail` — refused
- `Ross Commercial Director Kelverton Rail` — refused
- `Senior Partnerships Manager job description rail technology train operating companies` — refused

**Fetches sent:** none. No dossier was present.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values cheat sheet, which no documented round calls for here, and any VAL theming |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | The recruiter's email already establishes the loop; this would only have shown whether other formats exist |
| 3. `Kelverton Rail` strategy and recent news | unavailable | Would have fed the CO bank, a grounding brief and the POV's consensus item |
| 4. Interviewer names with Kelverton Rail | unavailable | Would have fed an interviewer read, persona adjustments and a reverse question tied to their career paths |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have turned the fit snapshot's requirement rows into JD-quoted rows and grounded the JD-tagged questions |

## Upgrade menu

- The job description → the fit snapshot's requirement rows become JD-quoted and the JD-tagged questions in banks A, C and D get checked against the posting's own list
- The market report's key findings, pasted or its summary page → the POV build names a real consensus item and a real divergence, A4 becomes specific, and a grounding brief section is added
- Permission to run web search → the five research targets run (up to 6 searches and 2 fetches), and a deeper pass on strategy and interviewer footprints would add up to 6 further searches and 2 further fetches, several more minutes
- The interviewers' full names or public profiles → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each one's career path
- The recruiter's answer on what "operator partnerships" covers, one email → A1, A2 and the POV's opening reading become grounded
- A partner-attributed revenue report or CRM export for the ISV channel → F3's confidence can move from medium, and the B bank can quote how the figure was counted
- A `tuesday-dossier.md` from an earlier evidence review → verified evidence and an evidence-derived objection in place of the inferred one in C1
