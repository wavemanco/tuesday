I'll read the skill's reference files before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-2-denied-0e2e69d9/atlas-freight_operations-manager_interview_pack.md`. It has 22 questions across seven interviewer styles, a fit table of the JD against your own words, reverse questions, and a list of claims the pack won't coach.

Your note didn't say what round this is or who's interviewing, so the style weights are flat. They're ordered by where your background is thinnest: leading 3 supervisors versus 12 across four sites, warehouse versus terminal work, and how many of your seven years were spent leading others. The highest-value rehearsal is A2, the 3-to-12 supervisor jump. My three web searches on Atlas Freight were refused, so the pack has no company research. That affects the values and company-knowledge questions, which are generic scaffolds.

Say the word and I'll play the Skeptic on A2 and push back with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What kind of round is it, and is the person you're meeting your future manager, a peer, or someone more senior? Also tell me if the recruiter said anything about focus areas or a presentation. How many hours do you have to prep this week?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack — Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight
- **Interviewer:** not known
- **Relationship and round type:** not known. Persona weights are flat priors, ordered by where your gaps sit (F1, F4, F7), not by anything known about this loop
- **Built from:** the JD lines and background you pasted, nothing else. Research on Atlas Freight was attempted and refused (see Sources), so company facts are absent rather than guessed

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script: where it says "answer slot", it is an instruction for the interview, and you answer from what is true for you, including the branch where the practice was not yours or never existed. Question IDs skip the letter F so they never collide with fit-snapshot rows (F1 to F8).

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether the claims in your background survive a probe, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role: structure and reasoning |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution and a senior shift manager role; it does not say terminals or more than one site. Words at that scope: "I've spent seven years in warehouse and distribution ops." Answer slot: the JD's four sites make a probe on multi-site and terminal work likely. If any of your work touched freight terminals or more than one site, say which and what your part was; if not, say so plainly and say what you would want to learn first |
| F2 | "drive on-time performance and cost-per-shipment down" — JD (the on-time half) | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The quote touches peak operations without showing what it was measured on. Answer slot: if on-time performance was tracked for the surge plan, say what it was and what moved, in your own words; if it was not tracked, or not by you, say so plainly and stay with the plan you ran |
| F3 | "drive on-time performance and cost-per-shipment down" — JD (the cost half) | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is mis-pick rate, adjacent to cost-per-shipment and not the same measure, and the bridge stays there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked anything that links the redesign to cost per shipment, say what it was; if you did not, say so plainly and say how you would connect what you measured to it |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote is three supervisors; the JD says twelve. Words at that scope: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led more than three supervisors in any role, say how many and where; if not, say so plainly and stay with the three |
| F5 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel, never used Power BI" — your message | low | [inferred] | discovery | "Solid Excel" does not say whether you built reports. Answer slot: if you built reports in Excel, say what they showed and who read them; if you used it another way, say so plainly |
| F6 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you plan to learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Seven years of operations work is stated; how many of them were spent leading others is not. Answer slot: say how many of the seven years were in a role leading others; if only part, say so plainly and state your current role as it is |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a claim with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: you are green belt certified |

## Persona table

Round type and interviewer are unknown, so no relationship prior applies and the weights are flat, as the generic-loop fallback has it; this is weaker than a pack built for a known round. The order and depth below follow where the fit snapshot is thinnest.

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| A Skeptic | Quiet, persistent probing of the span, the terminal gap and leadership years | Top (5 questions): F1, F4 and F7 are the gaps most likely to be pressed in any round | Rehearse A2 until it is boring: hold the quote, concede only what it shows. A2 is the highest-ROI prep in this pack |
| B Case/Strategist | Live problems on on-time performance, cost-per-shipment and peak season | High (4): the JD's own operating measures lend themselves to cases | Clarify, structure, metrics, risks, thinking aloud (B1 to B4) |
| C Data-Driven Prober | Goes line by line through your 40% and your surge plan | Mid (3): your background holds one figure and one named plan, and both are probe targets | Say plainly how much you know about how the figure was counted (C1, C2) |
| D Values/Behavioral | Story prompts on unpopular truths, customers versus metrics, getting supervisors to change | Mid (3): no values-style round is established, and no values were in hand, so this bank is scaffolds | Pick stories before the interview; use the honest branch where none comes to mind (D1 to D3) |
| E Conversational | The biography, why Atlas, what you do with Lean | Mid (3): a friendly opener is likely somewhere in any loop | A 90-second arc built only from your sentences (E1) |
| G Pressure | Time-boxed challenges and attribution probes | Low (2): nothing known suggests a stress style | Pause, restate, hold through two follow-ups, concede specifically (G1, G2) |
| H Peer Evaluator | Seam and credit probes, if a peer is in the loop | Low (2): a team of supervisors is named in the JD, but no peer round is known | Seam principles, not a claimed seam (H1, H2) |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Name your weakest part yourself, before they do. One gap sits in your own words: say "I've never used Power BI", then how you plan to close it, said as a plan for the future in your own words. No course, date or result is supplied here. Answer slot: if another part of the JD is your weakest in your own view, name that one instead and say why, plainly | F6 is the only gap you have stated yourself, so it is the safest honest answer; JD because it scores the stated requirements, with a Skeptic delivery |
| A2 | "You're over 3 supervisors today, and this role has 12 across four sites. What makes you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: "I'm currently a senior shift manager over 3 supervisors", and the seven years in warehouse and distribution ops. Answer slot: if you have led more than three supervisors, or worked across more than one site, say which and what your part was, in your own words; if not, or if it was not yours, say so plainly and stay with the three. Hold through two follow-ups by returning to what you said, never by adding to it. Concede only what the numbers show: twelve is more than three. Then say what you would want to learn first about the four sites, as a plan | F4 and F1 are where the role's scope presses hardest, so this objection arrives in some form. JD because it scores the stated team and site requirements; the hold-then-concede structure is the Pressure-style move it needs |
| A3 | "Your background is warehouse and distribution. This role is terminal operations. What carries over?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Say your background in its own words: "7 years in warehouse and distribution ops". Then name the pick-path redesign and the surge plan as things you did, at the scope the quotes give, and let the interviewer judge the carry-over; do not call either one proof of anything. Answer slot: if any of your seven years touched freight terminals, say where and what your part was; if none did, say so plainly and say what you would want to learn first | F1's transferability gap is the question's target; JD because it scores the "terminal operations" requirement |
| A4 | "Why are you leaving a senior shift manager role for this one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: the reason must be yours, tied to a line of the JD you actually want, and not about your current employer. Answer slot: give your actual reason in your own words; if no single reason comes to mind, say so plainly and name the part of the JD that pulls you most | F4 is a scope jump, which makes "why this, why now" likely; JD because motivation is scored against the stated role, with Skeptic delivery |
| A5 | "The role asks for five-plus years of operations leadership. Tell me about your leadership years." | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Give both sentences as they stand. Answer slot: say how many of the seven years were in a role leading others, in your own words; if only part were, say so plainly and describe your current role as it is. Where a figure is unclear, state the lower reading | F7 is the one requirement the JD marks required and the material leaves open; JD because it scores the stated requirement |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four terminals has slipped over the last month. How would you diagnose it?" | CASE | [generic] | Clarify first: how on-time is defined and measured, against what promise, from which point. Then segment the problem, choose where to look first and say why, name the metrics you would check and the risk of acting on a wrong cut. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's on-time line (F2's requirement) asked as a live decision; generic because it is a pattern for the problem, not a fact about Atlas |
| B2 | "Cost-per-shipment differs across the four sites. Where do you start?" | CASE | [generic] | Clarify what is in the cost and what counts as a shipment, compare like with like, pick the biggest lever you can influence, pilot before rolling out, and say how you would know it worked. No claim about your past | F3's requirement as a live problem; CASE because it scores structure, not a right answer |
| B3 | "Peak season is eight weeks out. What is your plan across the four sites?" | CASE | [generic] | Clarify the forecast and constraints, set the objective, list what has to be in place at each site, name the checkpoints and risks. If asked whether you have done this, answer from C2 and nothing beyond it | Peak planning is a likely probe given F2's surge-plan evidence; kept generic so the case stays a structure and not a claim |
| B4 | "What would you put on a weekly dashboard for the four sites?" | JD | [grounded] "solid Excel, never used Power BI" | Structure: who reads it, the few measures the JD itself names (on-time performance and cost-per-shipment), how each is defined, how often it updates and where the data comes from. Say what you would start with in Excel as a plan. Power BI: "I've never used Power BI", then your plan to learn it | F5 and F6 under a live format; JD because it scores the reporting requirement, CASE in delivery |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-pick rate 40%. Walk me through how that was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | State it in your words. Answer slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Never supply a method you cannot repeat under a second question | F3's headline number is the likeliest defend-the-number target; EXP because it tests attribution and counting |
| C2 | "Walk me through your peak-season surge plan. What did it cover and how do you know it worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Start with the quote: you ran the site's peak-season surge plan, two years running. Answer slot: what the plan covered and whether any part of it was yours to set, in your own words; if it was handed to you, or you ran it as written, say so plainly. If you can state a result you can stand behind, say it; if you cannot, say so plainly | F2's only evidence is this sentence, so the second-level probe is predictable; EXP because it tests what the plan was and what was yours |
| C3 | "This role is about on-time performance and cost-per-shipment. Mis-pick rate is a different measure. What have you moved that is closer?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the quote at its scope. Answer slot: if you tracked something tied to on-time performance or cost per shipment, say what it was and what moved; if you did not, say so plainly and say how you would link what you did measure to them | F2 and F3 together: the gap between the evidence and the JD's two named measures; JD because it scores the stated requirement |

### D. Values/Behavioral

No published Atlas Freight values were available, so these are selection scaffolds on the standard stems. Each ends with the honest branch.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you did not soften it, and a relationship intact at the end. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values stem; generic because no Atlas value was in hand to map |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time where the customer cost and the metric cost were both real and you decided. Say what you chose and what it cost. If none comes to mind, say so plainly, then give the nearest thing or how you would handle it | Standard values stem; fits a freight setting where service and cost-per-shipment can pull apart |
| D3 | "Tell me about a time you got a team of supervisors to change how they worked." | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Selection scaffold: choose a time people had to change their routine, with the resistance and how you handled it. Answer slot: if the pick-path redesign changed how others worked, say how you brought them with you, in your own words; if it did not, pick another time or say so plainly. If none comes to mind, say so plainly and say how you would approach it | The JD's supervisor-led team (F4's requirement) raises it; VAL because it scores behavior |

### E. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc with three beats you have stated: seven years in warehouse and distribution ops, the pick-path redesign and the surge plan, and where you are now. Answer slot: the roles and order between the endpoints are yours to say; the pack holds only the endpoints, so name your real steps and leave out anything you cannot back up | F1 and F7 are what the arc has to set up; EXP because the casual question is still scored against the background |
| E2 | "What got you interested in Atlas Freight?" | CO | [grounded] | Use only what you have read yourself. The JD frames this as regional logistics with 800 employees; anything beyond that must come from pages you have read. Answer slot: give your actual reason in your own words; if you have not found one yet, say what you are curious about, plainly, and ask | CO because it tests homework; the pack found nothing on Atlas, so it can supply no company facts |
| E3 | "What are you actually doing with Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Lead with "I'm green belt certified". Answer slot: if the pick-path redesign was run as a green belt project, say so; if it was not, say so plainly. If you are not using it right now, say that plainly and say where you would apply it here | F8's JD plus-point, asked casually, which is still scored |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, restate the question, then give the four things you have said, in order, in your own words. You cannot speak to the other candidate, so do not compare. Hold through two follow-ups and concede specifically if pushed on the span, without folding on the core | Stem for the Pressure persona; F1 to F4 give the material and F4 is where it will push |
| G2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: say which part of the redesign was yours and which parts were others', in your own words; if it was mostly others', say so plainly and describe your part. Do not defend a larger share than you can describe in detail | Attribution probe on F3's headline number; EXP because it is the CV-claim stress test |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our sites run side by side. Where is the seam between your role and mine, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam instead of claiming to know where it is: who owns what decision, how handoffs get raised, how you resolve a disagreement. Say what you would offer the other side, from work you have actually done | F1's multi-site scope makes seams likely; generic because it needs no claim about your past |
| H2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if others worked on the redesign, say who and what each did and what you did; if you did it on your own, say so plainly. Credit first, your part second | Peer-style stem; F3's number invites a "who else was involved" probe |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, A3, B1, H1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, B3, C2, C3 |
| "lead a team of 12 supervisors" | A2, D3 |
| "build reporting in Excel/Power BI" | A1, B4 |
| "5+ years operations leadership required" | A5, E1 |
| "Lean/Six Sigma a plus" | E3 |
| Your headline number (mis-pick 40%) | C1, G2, H2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How is on-time performance defined here, and what has it done over the last year?" | Shows you would define the measure before trying to move it, tied to the JD's own line |
| 2 | "Of the four sites, which is closest to where you want all of them, and what is different there?" | Shows comparison across sites, the thinking A2 needs to show |
| 3 | "What does the supervisor team look like today, and what would you most want me to change in the first quarter?" | Invites them to name their concern about the span and gives you the answer to rehearse |
| 4 | "What does reporting look like today, and who reads it?" | Opens the Power BI gap in the open, where you can ask what the learning curve really is |
| 5 | "What would make you say, six months in, that this hire worked?" | Gives you the scorecard they will use |
| 6 | "What is the biggest operational problem this role has to solve that is not in the JD?" | Shows you are reading past the posting |
| 7 | "What are the next steps, and who else will I meet?" | Tells you the shape of the loop, which this pack could not know |

## Prohibited claims

Built from the fit snapshot before the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Led 12 supervisors, or a multi-site team | Inflated form of F4 and F1 | F4's quote at its own scope: "currently a senior shift manager over 3 supervisors". The limit is the pack's observation: your material says three supervisors, not twelve or several sites |
| Ran terminal or freight operations | Inflated form of F1 | "7 years in warehouse and distribution ops" at its own scope; the material says warehouse and distribution, not terminals |
| Drove on-time performance or cost-per-shipment | Inflated form of F2 and F3 | "cut mis-pick rate 40% by redesigning the pick path" and "ran the site's peak-season surge plan two years running", each at its own scope; the material says mis-pick rate and a surge plan, not those two measures |
| Built reporting or dashboards in Power BI | Negative you stated, F6 | "never used Power BI", and the plain acknowledgment: "I've never used Power BI". No slot |
| Ran Six Sigma or Lean projects | Inflated form of F8 | "green belt certified" at its own scope; the material says the certification, not projects |

## Sources

Provided: the JD lines and background pasted in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused by the host:

- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight regional logistics terminals news strategy` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have fed a values cheat sheet and the VAL bank; D1 to D3 are generic scaffolds instead |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have fixed the loop and the persona weights; the weights are flat as a result |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have grounded a CO or CASE question in current strategy; E2 and B1 to B3 are generic as a result |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. representative Operations Manager JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you meet (hiring manager, peer, skip-level, recruiter) → persona weights recomputed; a recruiter screen would add pay, notice, location and reason-for-leaving rows
- Any recruiter guidance (focus areas, a pre-declared presentation or take-home) → coverage of what is announced
- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a tailored reverse question
- Your answers to the slots on F1, F2, F4, F5 and F7 → those rows move from `discovery` or `transferability` toward story maps, and A2, A5 and C2 become answers you can rehearse
- How the 40% was counted, in your own words → C1 and G2 become story-mapped
- Your green belt certificate, or the pick-path project's before-and-after report → F8 and F3 can rise to `high` confidence
- Atlas Freight's own values or careers page pasted in, or search permission granted → the values cheat sheet and CO questions become grounded; a deeper research pass is also available for strategy and role-family loop reports (up to 6 more searches and 2 more fetches, several more minutes)
- Hours available this week → a prep triage in priority order
- A `tuesday-dossier.md` → verified evidence, strategy per weak area and prohibited claims arrive ready-made
