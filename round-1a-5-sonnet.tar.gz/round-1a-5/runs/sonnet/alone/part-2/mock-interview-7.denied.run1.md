I'll read the reference files the skill points to before building the pack.
The pack is written. This is the message that presents it.

Your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a 60-minute hiring-manager round with Tobias, since your note didn't say whether he'd be your manager.

Web search was refused in this session, so nothing in the pack comes from outside what you pasted. The pack has no company values, loop structure, strategy or interviewer read. A5 is the only company-knowledge question, and it rests on you playing both Saltmarsh titles before Friday.

The pack has 18 questions, a requirement-coverage table, a list of claims it won't coach, and a two-day prep order. Question B1 is the one to rehearse first. It covers your stated gap on in-app purchases, with the structure of a plain concession, then only what your own sentences carry, then a ramp plan.

Say the word and I'll play the Skeptic on B1 live, with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Would you report to Tobias, and did the recruiter say anything about the format, focus areas or a task to prepare? Either answer reweights the persona banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi. **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Round:** 60 minutes, Friday. **Relationship:** assumed hiring manager, because the material does not say whether Tobias would be your manager. If he is not, the persona weights below change.

## How to use this pack

- Personas are how a question is asked. Types are what it scores. Every question carries both, plus a Provenance cell showing which of your own sentences its guidance rests on.
- Type key:
  - **VAL**: whether past behavior shows a company's published values. No VAL questions appear here, because no values-style round was detected and no values page could be read.
  - **EXP**: whether your own account of your work survives follow-ups.
  - **JD**: whether you can do the listed job, gaps included.
  - **CO**: how well you know the company and its games.
  - **CASE**: a live problem from the role.
- Guidance is scaffolding, not a script. Where it says "Answer slot", the interviewer is likely to probe a practice your material does not show. Answer from your own experience, or say plainly that the step was not yours or did not exist.
- The pack's only facts about you are the sentences you wrote to me, quoted in the fit snapshot. Nothing here is known about Saltmarsh beyond the JD you pasted.

## Prep triage (two days, hours not stated)

1. Say B1 aloud until it is boring. It is the highest-ROI prep in the pack.
2. Build the 90-second arc for D1 from your four sentences, and nothing more.
3. Write your own answers to the slots in B2, B3, B4 and C1, in your own words. Each slot has an honest branch if the practice was not yours.
4. Say the structure for A1 and A3 aloud once each. Install and play both Saltmarsh titles for A5.
5. Pick three reverse questions and learn why you are asking each.
6. Everything else is insurance.

## Fit snapshot

No row is a hard gate: the JD supplied states no authorization, location, schedule or pay term. F9 is the pack's own role-family reading, not a JD line.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one calendar, for the main title, with nothing inspected behind it; the JD says two titles and live events. Words stay at the quote: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely, and its live-events line a probe on whether any drops were timed events. If you ran or helped run another title's calendar, say what part was yours; if any drops were events, say which; if neither, say so plainly and stay with the main title |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [grounded] | discovery | Your material does not show which disciplines the drops involved, and "Never led a team" is not a statement about coordinating, so the pack treats this as unknown rather than a gap. On the team point your own words are: "I haven't led a team." Answer slot: the JD names four disciplines, so a probe on which you worked with is likely. Say which your calendar work involved and what you asked of them, in your own words; if it involved none, or the coordination was not yours, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | The JD says own the review and the KPIs; your material says presented, which is narrower, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: a probe on who produced the numbers and who chose what they covered is likely. If any of that was yours, say which and how you decided; if not, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | The JD says manage it with QA; your material says wrote it. Words stay at the quote: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran it with QA at releases, say how, in your own words; if it passed to QA once written, or you did not run it, say so plainly and stay with the checklist |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | Four years is your material's number against the JD's three. It does not show whether the title was live-service, so the words stay at the quote. Answer slot: the JD's live-service line makes a probe on how many of the four years were on a live title likely. Say which years the game was live and what you did in them; if you cannot say, say so plainly and stay with what F1's quote carries |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the calendar in the quote's own terms: weekly, main title, two years. A named cadence beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Say it as it stands: "Each month I presented the retention numbers to the studio head." Add no figure and no method. Answer slot: a probe on how the numbers were counted is likely; say what you know, and where you do not know how a figure was counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | discovery | The quote shows a written document in use by QA; it does not show other writing of yours. Answer slot: the JD names clear written communication, so a probe on other writing is likely. If other writing of yours was acted on by others, say what it was; if the checklist is the main example, say so plainly |
| F9 | Familiarity with in-app-purchase KPIs on a mobile live-ops title — the pack's role-family reading, not a line of the JD supplied | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past (B1). Nothing added to make the gap feel smaller |

## Persona table

The weights rest on an assumed hiring-manager relationship and on the generic loop archetype, because no loop source could be read. Recalibrate if you know the format.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the role: plan a calendar, handle a slipped dependency, diagnose a retention drop | high: the hiring-manager prior favors it, and the JD's plan, coordinate and review lines each convert into a live problem | Clarify, objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of the two gaps you stated and of one-title scope | high: the hiring-manager prior favors it, and F9 and F2 are gaps you named yourself | Rehearse B1 until boring; plain acknowledgment, then hold only what your quotes carry, then a plan stated as a plan |
| C. Data-Driven Prober | Which retention numbers, how counted, what was yours | medium: the JD names retention metrics and KPIs (F3, F7), and the prior does not favor it | Know what you can and cannot say about how each number was counted; name the weakest assumption before they do; say plainly when you do not know |
| D. Conversational | Opening walkthrough, then casual questions on the checklist and on writing | medium: a 60-minute hiring-manager round usually opens with the biography, but no loop source confirms the format | A 90-second arc from your four sentences; treat casual questions as scored |
| E. Pressure | Time-boxed why-you challenge, attribution challenge | low: no prior or signal favors it, kept in so the style is not new live | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| F1: the live-events calendar for two titles | A1, B3 |
| F2: coordinating the four teams | A2, B2 |
| F3: the post-event review and KPIs | A3, C1, C2, C3, E2 |
| F4: the release checklist with QA | A2, D2 |
| F5: 3+ years of live-service production | B4, B5 |
| F6: running a content calendar | A1, B3, D1 |
| F7: player-retention metrics | A4, C1, C2, C3 |
| F8: clear written communication | D3 |
| F9: in-app-purchase KPIs (not a JD line) | B1, E1 |

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Suppose you take over the live-events calendar for two mobile titles. What do you need to know first, and how do you structure the plan?" | CASE | [generic] | Clarify before structuring, aloud: how each calendar runs today, what the post-event review reports, who signs off an update, what each team needs to hear and when. Then objective, what is shared between the two calendars and what is separate, metrics, risks. Challenge one premise respectfully, for example how the two titles differ. The question needs no claim about your past, so the guidance makes none | F1 and F6 are the requirements it converts into a live problem. CASE because it scores structure and clarifying questions, not a remembered answer |
| A2 | "An event is due Thursday. On Tuesday engineering says a dependency will slip two days, and art and community have already committed to the date. What do you do?" | CASE | [generic] | Structure it: what you would establish first, the options (hold, trim, move), who decides, who is told by when, what is recorded afterwards and how it feeds the release checklist. Say what you would ask rather than what you would assume about the teams. No claim about your past | F2 and F4 are where the JD's coordination and checklist lines meet. CASE because it tests judgment under a slip, a likely live problem for this role |
| A3 | "How would you build the post-event review for an event: what goes in, who sees it, what decision it feeds?" | CASE | [generic] | Walk the shape: what the event was meant to change, the measures chosen and how each is counted, the comparison, what you would do differently next time. Say it as how you would build it. Answer slot: the JD's own-the-review line makes a probe on whether you have produced one likely. If any review of this kind was part of your work, say what it covered; if none was, say so plainly and answer as how you would build one | F3 is the requirement; the JD names the review as the role's output. CASE with JD content because it scores structure on the role's own artifact |
| A4 | "Retention on an event cohort is down against the previous event. Diagnose it." | CASE | [generic] | Clarify first: how retention is defined here, whether the cohorts are comparable, what else shipped. Then segment, check timing, content and technical causes, say what you would want before concluding, and name the assumption you would defend least. No claim about your past | F7 is the requirement. CASE because the interviewer scores the diagnosis path, using the JD's own retention vocabulary |
| A5 | "You've had a chance to look at our two titles. What would you change about how one of them runs events?" | CO | [generic] | Install and play both before Friday. Bring one observation of the player-facing event rhythm and one question about what you cannot see from outside, rather than a verdict. Concede that you see only the player side. Without research, nothing about Saltmarsh beyond your own play is supplied here | The pack could read nothing about the company, so this is the one CO question and it rests on your own play. CO because it scores homework depth |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked on a game with in-app purchases, and this role owns the KPIs a post-event review reports. How do you get up to speed, and what do you do until then?" | JD | [grounded] "never worked on a game with in-app purchases", "Presented the monthly retention numbers to the studio head.", "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack. Concede once, in your own words: "I've never worked on a game with in-app purchases." Hold only what the quotes carry: "I presented the monthly retention numbers to the studio head" and "I ran the weekly content-drop calendar for our main title." Then the ramp, said as a plan: before proposing changes, ask which KPIs the review reports today and how each is counted, and read recent reviews. Follow-up 1, "retention is not revenue": agree they differ, and say what you do not yet know. Follow-up 2, "why take the risk": return to the two held sentences. Never describe monetization work | F9 is the stated gap and F3 is the requirement it presses, so this question will arrive in some form. JD because it scores a stated requirement against a stated gap |
| B2 | "You haven't led a team, and this role coordinates four disciplines on every update. Where does your influence come from?" | JD | [grounded] "Never led a team" | Concede in your own words: "I haven't led a team." Answer slot: the JD names design, art, engineering and community. Say which your calendar work involved and what you asked of them; if it involved none, or the coordination was not yours, say so plainly. Then principles, as how you would work: say what you need, by when, and keep one record the teams can check | F2 is the requirement; the stated negative is the likeliest place a skeptic starts. JD because it scores the requirement against the gap |
| B3 | "You ran the calendar for your main title. We have two titles in this role. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you ran, at the quote's scope: the weekly calendar, the main title, two years. Answer slot: if you ever ran or helped run another title's calendar, say what part was yours; if not, say so plainly. Then how you would approach two calendars: what the two share, such as team time and clash windows, and what differs, and what you would ask Tobias about how the titles differ | F1 and F6 meet here. JD because it presses the two-titles line at the exact edge of the quote |
| B4 | "The JD asks for three-plus years producing live-service games. How much of your four years was on a live title?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio.", "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: say which years the game was live and what you did in them. If you cannot say, say so plainly and stay with the calendar quote. Do not stretch four years into four live years | F5 is the requirement; the quotes do not show whether the title was live-service. EXP because it tests whether the stated years survive a follow-up |
| B5 | "You're an associate producer on a puzzle title. Why a live-ops producer role on mobile, why us, and why now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Selection scaffold: pick the reason that is true and specific. What in your current work pulled you toward live events, what about two titles or four disciplines attracts you, what you noticed in both Saltmarsh titles (A5). If no clear reason comes to mind, say so plainly, then say what you want the next two years of your work to hold. Do not supply a motive you do not hold | F5 and the move itself invite a motivation probe. EXP because it tests consistency between your path and the stated move |

### C. Data-Driven Prober (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention numbers did you show the studio head each month, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say which numbers you presented, in your own words. Answer slot: how they were counted, what they were sensitive to, the assumption you would defend least, and which part of the work was yours, producing or presenting. If you do not know how a figure was counted, say so plainly. Name no method you did not use | F7 and F3 are the metric rows. EXP because a prober scores the denominator and the attribution |
| C2 | "Tell me about a time retention numbers changed what the team did." | EXP | [generic] | Selection scaffold: pick a time a number shifted a plan. It needs the number, the call that followed, and what was yours versus others. If no such time comes to mind, say so plainly, then say how you would want a number to change a plan. Supply no event here | The JD's retention and KPI lines raise the theme. EXP because it tests whether a metric ever drove a decision |
| C3 | "After an event, which three numbers do you look at first, and what would make you distrust them?" | JD | [generic] | Answer as how you would approach it: pick three with a reason each, then name the caveats you would check, such as how a figure is defined, whether the cohorts are comparable and whether the data is complete. Name your weakest assumption before they do | F3 and F7 are the requirements. JD because it scores the role's own measurement judgment |

### D. Conversational (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio.", "I ran the weekly content-drop calendar for our main title for the last two years.", "Wrote the release checklist our QA team still uses.", "Presented the monthly retention numbers to the studio head." | A 90-second arc from those four sentences in that order: the four years, the weekly calendar for the main title, the checklist, the monthly numbers. End on why this role (your B5 answer, in your own words). Add no team sizes, outcomes or titles | F5, F6, F4 and F3 are the four beats. EXP because the arc must survive a casual-register follow-up |
| D2 | "Tell me about the release checklist." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Beats the quote states: you wrote it, and your QA team still uses it. Answer slot: the JD's manage-with-QA line makes a probe on who ran it at each release likely. If you ran it with QA, say how; if it passed to QA once written, say so plainly. Say nothing about its contents you cannot repeat under a second question | F4 is the requirement. EXP because it tests what was actually yours, asked casually |
| D3 | "Tell me about something you wrote that other people had to act on." | JD | [grounded] "Wrote the release checklist our QA team still uses." | The checklist is the example your quote carries; tell it at the quote's scope. Answer slot: if other writing of yours was acted on by others, say what it was; if the checklist is your main example, say so plainly | F8 is the requirement. The JD's written-communication line raises the theme. JD because it scores the stated requirement |

### E. Pressure (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has already owned a live-event calendar's KPIs on a monetized game?" | JD | [grounded] "never worked on a game with in-app purchases", "Never led a team", "I ran the weekly content-drop calendar for our main title for the last two years.", "Wrote the release checklist our QA team still uses." | Pause and restate. Concede specifically: "I've never worked on a game with in-app purchases" and "I haven't led a team." Hold only what the quotes carry: the weekly calendar for the main title over two years, and the checklist QA still uses. Do not claim to be better; say what you bring and how you would close the gaps. Hold through two follow-ups | F9 and F2 are the stated gaps. JD under pressure because the stem scores composure, not content |
| E2 | "That monthly retention presentation: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what was yours at the quote's scope: you presented the numbers. Answer slot: whether you also produced, chose or analysed them. If any of that was yours, say which; if not, say so plainly. Hold through two follow-ups by returning to the quote, never by adding to it | F3 is where attribution presses hardest. EXP because it scores attribution honesty |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the post-event review report today, and which KPI would you most want a new producer to own first?" | Tied to the JD's KPI line (F3), it shows ownership thinking, and the answer tells you how monetization-heavy the KPIs are, which bears on F9 |
| R2 | "How do the two titles differ in how their calendars run, and where do they compete for the same teams' time?" | Tied to F1, it moves the conversation from your one-title scope to the real problem of two |
| R3 | "Where do updates most often slip today, and what does the producer do about it?" | Tied to F2 and F4, it shows you think about the work, not the title |
| R4 | "How is the release checklist shared between this role and QA today?" | Tied to F4, it clarifies whether the role runs it or only maintains it |
| R5 | "What would tell you in month one that this is going well?" | Asks for the bar you will be scored against, and shows you plan to be measured |
| R6 | "If I come in without in-app-purchase experience, how would you want me to close that in my first quarter?" | Only after B1 has surfaced it: it turns a stated gap into a plan Tobias helps shape, instead of a doubt he holds alone |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated, F2 | "I haven't led a team." No slot for a leadership claim |
| Has worked on in-app-purchase or monetization KPIs | Negative you stated, F9 | "I've never worked on a game with in-app purchases." No slot |
| Owned the post-event review or its KPIs | Inflated form of F3 | F3's quote at its own scope: the material says presented, not owned. C1 and E2 slots stay inside presenting |
| Ran live events for two titles | Inflated form of F1 | F1's quote at its own scope: one calendar, the main title. B3's slot stays inside that |
| Managed QA's use of the checklist at each release | Inflated form of F4 | F4's quote at its own scope: the material says wrote, not managed. D2's slot stays inside the checklist |
| Has 3+ years on live-service titles | Inflated form of F5 | F5's quote at its own scope: the material says four years as an associate producer, not live-service years. B4's slot asks which years were live |

## Sources

- **Provided documents:** the JD you pasted, and your background as written in your message. No CV file, no dossier consumed.
- **Interviewer:** Tobias Wrenfield, Head of Live Operations, given by name and title only. Nothing else about him is established.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Search refused. Would have moved: the values cheat sheet, if a values-style round were documented. Nothing moved |
| 2. `Saltmarsh Games interview process` | unavailable | Search refused. Would have moved: loop structure and persona weights. The pack falls back to the generic archetype (screen, hiring manager, panel) and says so |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Search refused. Would have moved: the CO bank and a grounding brief. A5 is the one CO question and rests on your own play |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Search refused. Would have moved: the interviewer read and a reverse question tied to his career path |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

Searches sent, every one refused:

- "Saltmarsh Games mobile studio values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games strategy news mobile titles" — refused
- "Tobias Wrenfield Saltmarsh Games" — refused

## Upgrade menu

- Web search permission → the four unavailable targets above: published values, loop structure, recent strategy and Tobias's public footprint. That unlocks a grounding brief, persona weights read from the real loop, an interviewer read, and a reverse question tied to his path. After that, a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available on request
- Whether Tobias is your future manager, and anything the recruiter said about format, focus areas or a task to prepare → persona weights reweighted, and a build section for any declared task
- Your answers to the slots in F1, F2, F3, F4, F5 and F8, said outside a practice session → each row regenerates from your own words and the matching guidance cells upgrade
- Whether the puzzle title was on mobile and live-service → F5 moves from discovery toward a grounded row
- An inspectable artifact for F1, F3, F4, F6 and F8: an event calendar you ran, a post-event or retention write-up you wrote, or the release checklist itself with confidential details removed → medium confidence can move toward high
- A full CV → evidence cells quote it directly, and rows beyond your message's five sentences can be graded
- A `tuesday-dossier.md` from an earlier evidence review → verified evidence, the single objection worth the deepest rehearsal derived from evidence rather than inferred, and any claim to keep out of your answers
