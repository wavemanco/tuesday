# Interview pack — Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 4 December 2026, built from the recruiter's email, the JD, the values page you copied on 25 November 2026, the strategy brief's four points as you relayed them, and your background as you described it.

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1 | The recruiter | 30 min | Recruiter screen |
| 2 | Head of Member Services | 45 min | Your future manager; mostly behavioural |
| 3 | Panel of two branch managers | 60 min | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewer names are not assigned yet, so there is no interviewer read. Persona weights rest on the round types in the recruiter's email.

## 1. How to use this pack

- **Personas are how a question is asked; types are what it scores.** The persona tells you the register to rehearse in. The type tells you what the interviewer is listening for.
- **The five type tags:** VAL — past behaviour against Ashgrove's published values. EXP — whether your background survives scrutiny. JD — a line of the job description. CO — knowledge of the company and its strategy. CASE — a live problem from the role.
- **Guidance is scaffolding, not a script.** Say it in your own words. Every claim about your past rests on a sentence you wrote, quoted in the Provenance column. An answer slot is an instruction for the interview: answer it truthfully either way, and the honest second branch is never a confession.
- **Highest-ROI prep: B3** (Round 2), the "you've never worked in a contact centre" challenge from your future manager. It will arrive in some form, and it is the deepest-rehearsed item here.
- **Dropped as not applicable:** the prep triage (no prep time stated), graded deliverables (none declared), the interviewer read (no names), delivery coaching (no assessment), and any defend-the-number rows (you gave no headline figures).

## 2. Fit snapshot

The JD has no gate row: each requirement is a skill or experience, not a term you meet or don't. The quotes are your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your sentence already carries the years. Say it as it stands: "I've spent six years in retail banking, the last three as a branch supervisor." Let the interviewer do the mapping to their wording; don't restate your work in the JD's terms |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal log, and does not say what rules or deadlines it was kept under. Words: "I handled the branch's formal complaints log." Answer slot: the JD's complaints-experience line makes a probe on what governed the log likely. If it was kept to rules or deadlines you worked to, say which and what that meant for how you kept it, in your own words; if you don't know the rules behind it, or none governed it, say so plainly and stay with the log |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process end to end, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how far you saw a complaint through likely. If you saw any through beyond logging it, say which and how it ended, and which part was yours; if the log was the extent of it, or the rest was not yours, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn that side, said as a plan and never as something already done. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence says you built a monthly complaints spreadsheet your regional manager uses, and does not say what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's monthly-reporting line makes a probe on what it counted likely. Say what it counted and how, in your own words; if you don't know how a figure in it was counted, or it counted something other than what the JD names, say so plainly and stay with the spreadsheet |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your sentence says spreadsheet and does not name the tool; the pack reads it as possibly Excel and no more. Answer slot: the JD's tool line makes a probe on what you built it in likely. Say the tool, in your own words; if it was not the tool the JD names, say so plainly and stay with the spreadsheet |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated limit, kept at its own scope. Words: "I've never presented to anyone above regional level." That sentence does not say whether you have presented at regional level, and the pack claims neither. Whether the JD's "senior leaders" includes your regional level is not established by your material. Then how you would prepare for it, said as a plan |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and a script, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how that training went likely. Say who you trained and what you did, in your own words; if any step was set by someone else, or there was no such step, say so plainly and stay with the training |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the JD's digital line makes a probe on work with digital or product teams likely. If you have worked with such a team on how members help themselves, say what it was and which part was yours; if not, say so plainly, then say how you would start, as a plan |

## 3. Grounding brief

Four points from Ashgrove's 2026 strategy brief (July 2026), as you relayed them, plus the vocabulary in the JD and values page. Use their words; don't recite them.

| # | Fact | Source | Provenance | What it changes in this pack |
|---|---|---|---|---|
| G1 | Move 40% of member service to digital channels by 2028 | Strategy brief, July 2026, as you relayed it | [grounded] | Feeds A3, D2 and D5; the self-service half of the JD (F9) is where this lands for you |
| G2 | Consolidate eight branches into five hubs over 2027 | Strategy brief, July 2026, as you relayed it | [grounded] | Feeds D2 and the reverse questions. The Round 3 panel are branch managers (recruiter's email), and whether their own branches are among the eight is not established, so keep answers about members and towns, not about any branch's future |
| G3 | Launch a small-business lending product in Q1 2027 | Strategy brief, July 2026, as you relayed it | [grounded] | Feeds D2: a new product is a new source of complaints to prepare for |
| G4 | The main competitive pressure is app-only banks | Strategy brief, July 2026, as you relayed it | [grounded] | Feeds A3 and D5 |
| G5 | Their words: "member" not "customer"; "hubs"; "Plain Words"; "Own the Fix" | JD and values page you copied on 25 November 2026 | [grounded] | Use the same vocabulary aloud, especially in the case (D3 to D5) |
| G6 | The brief is four months old and you hold only four points from it | Dates in your message | [inferred] | Treat dates and scope as of July; if you can read the brief itself, the CO and CASE rows get sharper (see the upgrade menu) |

## 4. Persona table

| Round | Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 | Conversational / Rapport Builder | Friendly screen: your journey, why Ashgrove, pay, notice, location, why you are leaving | Heaviest (6 questions). A recruiter screen's prior is conversational plus logistics, and the casual register is still scored | A 90-second arc built only from your quoted sentences; each logistics answer is your own, never a figure the pack supplies |
| 1 | Skeptic (light) | Knockout checks on the contact centre and on regulated complaints | Light (2 questions). The recruiter prior is a light Skeptic, and your material states one limit that the JD names (F4) | Say the limit in one plain sentence, then return to "I handled the branch's formal complaints log" and don't add to it |
| 2 | Values / Behavioral | Past-behaviour prompts built from the JD's duties | Highest in the round (4 questions). The recruiter described this round as "mostly behavioural" | Story-map from your quotes where one carries a story; a selection scaffold with its honest branch where none does |
| 2 | Skeptic | Your future manager probes the contact centre gap and what you could not do on day one | Second (3 questions). A manager prior is Case plus Skeptic, and your material states two limits the JD names (F4, F7) | Hold through two follow-ups by returning to the quoted sentences; concede the limit specifically, never the core |
| 2 | Case / Strategist | A live problem on reporting and a strategy question on 2027 | Lowest (2 questions). The manager prior favours Case, but the recruiter said the round is mostly behavioural | Clarify, then objective, then approach, then what you'd watch; challenge one premise respectfully |
| 3 | Values / Behavioral | One prompt per published value | Highest (4 questions). The recruiter said the panel "scores against the four values" | A scaffold per value ending in its honest branch; "we" for context, "I" for your contribution |
| 3 | Case / Strategist | The 20-minute complaint-escalation case | Second (3 questions). 20 of the 60 minutes are a case, and the case's content is not known yet | Clarify before structuring; say who owns the problem from now, aloud; use their words (members, Plain Words, Own the Fix) |
| 3 | Peer Evaluator | Seam and credit questions from two branch managers | Lowest (2 questions). The role coaches branch supervisors, and whether those supervisors report to these two managers is not established | Offer seam principles, not a claim to know their seam; say what you'd bring them as well as what you'd need |

## 5. Question banks

### Round 1 — The recruiter (30 min): Conversational (A1 to A7), Skeptic (B1, B2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey in banking." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Three beats in your own words, about 90 seconds, each one a clause your quotes state: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you built the monthly complaints spreadsheet your regional manager uses. Finish with your own one-sentence reason for this move. Add no team size, volume or outcome the quotes do not carry | The biography opener is scored for economy. F1, F2 and F5 supply the beats; EXP because it tests whether the CV story holds together |
| A2 | "The role asks for four or more years in financial-services customer operations. Where does your experience sit against that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say it as it stands: "I've spent six years in retail banking, the last three as a branch supervisor." Stop there and let them map it. If asked what that covered, answer with what you handled, using the sentences in A1, and nothing wider | F1 is the evidence for the years requirement, and a recruiter checks it literally; JD because it scores a stated requirement |
| A3 | "What do you know about where Ashgrove is heading, and what draws you to a member-owned credit union?" | CO | [grounded] | Use the brief's points as you hold them and no more: 40% of member service to digital by 2028, eight branches into five hubs over 2027, small-business lending in Q1 2027, app-only banks as the main competitive pressure. Pick the one that touches the role and say why in your own words, then name one value by its exact name. Your reason for choosing a credit union is your own, in one or two sentences | G1 to G4 give you current material, and the recruiter is the first person to hear whether you did the homework; CO because it tests knowledge of the company's direction |
| A4 | "What's making you look at a move now?" | EXP | [generic] | Answer slot: give your actual reason in your own words, in a sentence or two. If part of it concerns where you are now, say that part plainly and without blame. Don't offer more than you would repeat to your future manager | The reason for leaving is a logistics slot the recruiter always asks, and a reason that shifts between rounds is the thing a screen is built to catch; EXP because it tests consistency of your own story |
| A5 | "What salary are you looking for?" | JD | [generic] | Answer slot: either give your own figure or range in your own words, or ask first what band the role sits in. The JD you pasted states no salary, so asking is a fair first move. If asked what you earn now: "I'd rather focus on the range for this role." The pack supplies no number | Pay is a logistics slot at every recruiter screen; JD because it concerns the listed job's terms |
| A6 | "What's your notice period, and when could you start?" | JD | [generic] | Answer slot: give your actual notice period and your earliest start date as they stand; if you don't know one yet, say that | Notice is a logistics slot; JD because it concerns the listed job's terms |
| A7 | "The role covers our branches and the contact centre. Where are you based, and what would working across both look like for you?" | JD | [generic] | Answer slot: give your actual location and any limit on where or how often you can work on site; if you have none, say so. The JD you pasted does not say where the role sits | Location is a logistics slot, and the JD's branches-and-contact-centre line makes it a real question; JD because it concerns the listed job's terms |
| B1 | "Have you worked in a contact centre before?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | One plain sentence: "I've never worked in a contact centre." Then what you do carry, at its scope: "I handled the branch's formal complaints log." Then your plan for learning the contact centre side, in your own words, as something you would do. Don't pad the concession and don't apologise | F4 is a limit you stated, and a recruiter checks it first; JD because it scores a named part of the role. Short and clean beats elaborate here |
| B2 | "The role asks for experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold on the sentence: "I handled the branch's formal complaints log." Answer slot: if the log was kept to rules or deadlines you worked to, say which and what that meant for how you kept it; if you don't know the rules behind it, or none governed it, say so plainly and stay with the log | F2 is the only evidence for this requirement, so this is where a screen presses; JD because it scores a stated requirement |

### Round 2 — Head of Member Services (45 min): Values / Behavioral (C1 to C4), Skeptic (B3 to B5), Case / Strategist (D1, D2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F8, at the scope the quote states: you trained new tellers on your branch's escalation script. Tell it as that training, in your own words. Answer slot: the JD's coaching line makes a probe on how it went likely. Say who you trained and what you did; if any step was set by someone else, or there was no such step, say so plainly and stay with the training. If no difficult escalation comes to mind, say so plainly, then give the training | F8 is the evidence for the coaching duty and the closest thing the material has; JD because it scores a named duty |
| C2 | "Tell me about a time you presented to people more senior than you." | JD | [grounded] "I've never presented to anyone above regional level" | Selection scaffold, and your own sentence sets its limit: "I've never presented to anyone above regional level." Pick the most senior audience you have actually presented to: who they were, what you showed, what they did with it, what you would change. If no such time comes to mind, say so plainly, then say how you would prepare for a senior audience here, as a plan | F7 is a stated limit against a JD line, and a future manager will test it; JD because it scores a stated requirement |
| C3 | "Tell me about a time you worked with another team to improve something for members." | JD | [generic] | Selection scaffold, since no quote carries this: pick an occasion with a named other team, what you wanted changed, which part was yours, and what changed. If no such time comes to mind, say so plainly, then say how you would start working with a digital team on self-service, as a plan | F9 has no evidence at all, so the honest answer has to be ready before the probe; JD because it scores the digital-teams duty |
| C4 | "Tell me about a complaint you saw through to the end. What was your part?" | EXP | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: choose one complaint with a named stake, what was yours, how it ended and what you would change; "we" for context, "I" for contribution. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log," at that scope | F3 is thin and this question probes it from the behavioural side; EXP because it tests what was actually yours. It also previews Own the Fix |
| B3 | "You've never worked in a contact centre, and this role owns the process across branches and the contact centre. Why should I believe you can own that end to end?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | **The highest-ROI rehearsal in this pack.** Level 1, concede then hold: "I've never worked in a contact centre." Then only what you have: "I handled the branch's formal complaints log" and "I built the monthly complaints spreadsheet our regional manager uses." Then your plan for the contact centre side, as something you would do. Level 2, "That's one branch": stay at scope and answer slot: if the spreadsheet drew on more than your branch, say so; if it was your branch only, say that plainly. Level 3, "So what can't you do today?": name the limit specifically, in your own words, and say what you would learn first. Do not fold on the core: what you have handled is real, and what you haven't is said plainly. Say the limit before they do | F3 and F4 are where this loop's biggest gap sits, and your future manager is the person who will own the consequences, so this arrives in some form. JD because it scores the headline duty; the persona is Skeptic, and hold-then-concede is the rehearsal |
| B4 | "Which part of this role would you find hardest on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Your material states two limits the JD names. Pick the one you can speak about best, say it specifically in your own words, then say your plan. Conceding one specifically is stronger than spreading across several | The classic Skeptic stem, and F4 and F7 are the two limits you stated; JD because it scores honest self-assessment against the listed duties |
| B5 | "Walk me through the spreadsheet you built — what's in it, and who uses it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Premised on your sentence: you built it, it is monthly, it is about complaints, and your regional manager uses it. Answer slot: the JD's reporting and tool lines make probes on what it counted and what it was built in likely. Say the tool and what it counted in your own words, and which assumption in it you trust least, before they ask; if you don't know how a figure was counted, say so plainly. If any of it was built by someone else, say so and return to what you built | F5 and F6 are discovery rows, and a manager who reads CVs closely asks about the one artifact you can show. JD because it scores the reporting and Excel lines together |
| D1 | "If you owned the monthly complaints report for the whole of Ashgrove, what would it show and who would it be for?" | CASE | [generic] | Structure it aloud. Reader and decision first: who reads it and what they decide with it. Then what it shows, starting with the JD's own two, complaint volumes and resolution times. Then what you would distrust in it and how you would check. Then what you would change after the first month. It asks about no past, so the guidance makes no claim about yours | A live problem from the JD's reporting duty (F5's requirement), set as a design question; CASE because it scores structure, with JD content |
| D2 | "Over 2027 we move from eight branches to five hubs, launch small-business lending and shift more service to digital. Where do you expect complaints to change first?" | CO | [grounded] | Clarify first: what the baseline looks like now. Then take each change in turn: who it affects, what you would watch, what you would set up first. Offer your guesses as hypotheses. Challenge one premise respectfully. The three changes are the brief's (G1 to G3); the structure is a pattern, and nothing in it is a claim about your past | Differentiates you from candidates who only know the brief exists; CO because it scores thinking at the company's altitude |

### Round 3 — Panel of two branch managers (60 min): Values / Behavioral (C5 to C8), Case / Strategist (D3 to D5), Peer Evaluator (E1, E2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [generic] | Selection scaffold for Members First, Always: pick a decision that was yours, where the member's side cost someone else something, and say how it ended. "We" for context, "I" for what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The first of four published values; VAL because it scores whether a specific decision demonstrates it, and no quote of yours carries a story for it |
| C6 | "Tell me about a time something you said or wrote had to be explained a second time. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold for Plain Words. Choose an occasion where a message missed first time, and say what you changed. Answer slot, from your quote: say what you did with the escalation script, in your own words; if any wording in it was yours to change, say which and why; if not, say so plainly and stay with the training. If no such time comes to mind, say so plainly | Plain Words is the one value your material touches, through F8's script. VAL because it scores whether you think in members' terms; the slot keeps the answer inside what you did |
| C7 | "Tell me about a time you weighed what the numbers said against what a particular branch or town needed." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold for Neighbours, Not Numbers. Choose an occasion from your branch years, where a measure and a local need pulled apart: what each said, what you did, what it cost. Keep it about the members and the town, and keep it away from any branch's future. If no such time comes to mind, say so plainly, then say how you would weigh it | The value that the branch-to-hub plan (G2) makes live for this panel; VAL because it scores a decision, not a slogan. The quote is context only |
| C8 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold for Own the Fix. Pick one problem you found and kept: a named stake, the moments you could have handed it on, how it ended. If none comes to mind, say so plainly, then give the nearest thing: "I handled the branch's formal complaints log," at that scope | The fourth value, and the one closest to the JD's "own the process" line; VAL because it scores what you kept hold of, not what you were responsible for |
| D3 | "A member has now complained three times — at the branch, then to the contact centre, now in writing — and nobody has fixed the original problem. It lands on you. Talk us through your first hour." | CASE | [generic] | Clarify first: what the original problem is, what the member has been told, who holds it now, what time limits apply. Then say aloud who owns it from now. Tell the member in plain words what happens next and when. Then fix, then find the cause, then close the loop with the branch and the contact centre. Use their words: members, Plain Words, Own the Fix. It asks about no past | The 20-minute case is on a complaint escalation (recruiter's email), and its content is not known, so this is a plausible shape; CASE because it scores structure under their own vocabulary |
| D4 | "The branch supervisor tells you the member was given the right answer and wants it closed. What do you do?" | CASE | [generic] | Don't pick a side yet: ask what the member was told, in what words, and whether the member could act on it. Respect the supervisor; keep the decision with the facts. Hold your position through two pushbacks, then concede what is genuinely open. It asks about no past | The likely follow-up to any escalation case, and a test of how you coach a supervisor you disagree with; CASE because it scores reasoning and tact together |
| D5 | "How would you design the escalation path so that a member never has to tell their story twice, and can start in the app?" | CASE | [grounded] | Clarify the journeys that exist now. Then the member's path, step by step: where it starts, where it hands off, what each hand-off carries. Then what you would measure, using the JD's own two, volumes and resolution times. Then the risk that a hub or an app makes it worse. Ground it in G1 and G4 and keep it a design, not a claim about your past | Connects the digital strategy to the complaints duty; CASE with CO content, and it previews the Plain Words value |
| E1 | "Where's the seam between your role and ours, and what happens when we disagree about an escalation?" | JD | [generic] | Offer seam principles, not a claim to know their seam: who owns the member's outcome, who owns the branch's decisions, and how you would settle a disagreement with facts first. Hold your view through two follow-ups, then concede what is open. Say what you would bring them as well as what you would need | The Peer Evaluator's main stem, and the role works with branch supervisors every day; JD because it scores the duty's boundary |
| E2 | "Our supervisors are stretched. Why should they take coaching from this role?" | JD | [grounded] "trained new tellers on our escalation script" | Reciprocity first: ask what they need, and say what you would take off them. If you mention your own experience, keep it at the quote: "I trained new tellers on our escalation script." Don't claim more than that. Concede that coaching costs them time | F8 is thin against a duty the panel will feel directly; JD because it scores the coaching line. A stretched-team question tests whether you reduce their load |

### Requirement coverage

| Requirement or theme | Covered by |
|---|---|
| "4+ years in financial-services customer operations" (F1) | A1, A2 |
| "experience handling regulated complaints" (F2) | B2, C4 |
| "Own the member complaints process end to end across branches" (F3) | B3, C4, D3 |
| "across branches and the contact centre" (F4) | B1, B3, B4 |
| "report monthly on complaint volumes and resolution times" (F5) | B5, D1, D5 |
| "comfortable with Excel reporting" (F6) | B5 |
| "confident presenting to senior leaders" (F7) | C2, B4 |
| "coach branch supervisors on escalations" (F8) | C1, E1, E2 |
| "work with digital teams on self-service journeys" (F9) | C3, D2, D5 |
| The four published values | C5, C6, C7, C8 |
| Strategy (G1 to G4) | A3, D2, D5 |
| Logistics: reason for leaving, pay, notice, location | A4, A5, A6, A7 |

## 6. Values cheat sheet

Round 3 is the values round, and the four names below are from the page you copied on 25 November 2026. Say them by their exact names.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quote of yours carries a story for it. Scaffold: pick a decision that was yours and that cost someone else something; if none comes to mind, say so plainly, then give the nearest thing or how you would handle it. See C5 |
| Plain Words | If a member needs it explained twice, the writer got it wrong | F8: "trained new tellers on our escalation script," context only. Scaffold: pick an occasion where a message missed first time and say what you changed; the slot in C6 keeps it inside what you did. See C6 |
| Neighbours, Not Numbers | Every branch is part of its town | F1: "6 years in retail banking, the last 3 as a branch supervisor," context only. Scaffold: a measure and a local need pulled apart, and what you did; if none comes to mind, say so plainly. See C7 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2 and F3: "I handled the branch's formal complaints log," setting only, not a story. Scaffold: one problem you found and kept; if none, say so plainly and give the log at that scope. See C8 |

## 7. Reverse questions

Round 1 — the recruiter

| # | Question | Why it lands |
|---|---|---|
| R1 | "Is there anything in my background you'd want me to address before I meet the Head of Member Services?" | Gives you the recruiter's read before the manager round, and shows you take the gaps seriously |
| R2 | "What does the case in the panel round look like — is there any preparation I should do, and what kind of complaint does it centre on?" | The case's content isn't known; asking is normal and shapes your prep |
| R3 | "Who are the senior leaders this role presents to, and how often?" | Turns the F7 gap into a practical question about the real audience |
| R4 | "How would the contact centre side of the role work — is there someone I would work with there?" | Shows you are planning to learn it, not hiding from it |
| R5 | "What happens after 4 December, and when would you expect to decide?" | Practical, and keeps the recruiter's process visible |

Round 2 — Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| R6 | "What would success look like in this role at six months and at twelve?" | Lets your future manager define it; the answer shapes what you should emphasise later |
| R7 | "Where does the complaints process work least smoothly between branches and the contact centre today?" | Speaks to the end-to-end duty and invites candour from the person who owns it |
| R8 | "How do you expect the 40% digital shift to change what complaints look like, and who is shaping the self-service journeys now?" | Uses G1 and opens F9, which your material doesn't cover |
| R9 | "How do you expect the move to five hubs to change the escalation load on branch supervisors?" | Ties G2 to the coaching duty |
| R10 | "Which of the four values do you see tested hardest in complaints?" | Shows you read the values page, and shifts the conversation to their view |
| R11 | "What do people from a branch background usually find steepest in this role, and how does your team support that?" | Names your gap as a plan, on your terms |

Round 3 — the panel of two branch managers

| # | Question | Why it lands |
|---|---|---|
| R12 | "What could a new person in this role do in the first month that would genuinely help your branch?" | The reciprocity question for a peer-adjacent panel |
| R13 | "Where do escalations from your branch work well today, and where don't they?" | Shows you start from their experience, not your own plan |
| R14 | "How do you hear what happened to a complaint after it leaves the branch?" | Speaks to Own the Fix and to the loop-closing duty |
| R15 | "Which of the four values shows up most in how your branch runs day to day?" | Invites a story from them and ties to Neighbours, Not Numbers |
| R16 | "How do members who try the app first show up at your counter?" | Connects G1 to the branch view without raising any branch's future |

## 8. Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log, not the process end to end |
| Has contact centre experience | Negative you stated, F4 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Has handled regulated complaints | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says a formal log, not what governed it |
| Reported monthly on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." B5's slot asks only what it counted |
| Presented complaints figures to the regional manager | Inflated form of F5 | The same quote: it says your regional manager uses the spreadsheet, not that you presented it |
| Has presented to senior leaders | Negative you stated, F7 | The plain acknowledgment: "I've never presented to anyone above regional level." That sentence does not say whether you have presented at regional level, and nothing here claims it |
| Coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: your material says new tellers, not supervisors |
| Is an Excel reporting user | Inflated form of F6 | F6's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." B5's slot asks what tool you built it in |

## 9. Sources

Provided documents: the JD you pasted; the four values copied on 25 November 2026 from ashgrovecu.org/about/values (named as where the text came from; the page was not fetched); the recruiter's email about the process; the 2026 strategy brief's four points as you relayed them (the brief itself was not read); your background as you described it. Dossier: none present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the four names for section 6 and the VAL questions C5 to C8 |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email fixes the three sessions, who runs each, the case and the values scoring, so it fixes the persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The July 2026 brief's four points, as you relayed them, fix the grounding brief and the CO and CASE rows; fresher news was not checked |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No names are assigned, so there is no query to form; the interviewer read is absent and the upgrade menu says what a name would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 10. Upgrade menu

- The interviewers' names, once assigned → an interviewer read, persona weights tuned to each person's public footprint, and a reverse question tied to their own path
- The strategy brief itself, pasted → G1 to G6 become fully `[grounded]` and the CO and CASE rows get sharper than four relayed points allow
- The recruiter's answer on the case (any pre-reading, and what kind of complaint) → D3 to D5 rebuilt on the real case instead of a plausible shape
- Your own answers to the answer slots: what governed the complaints log (F2), how far you saw complaints through (F3), what the spreadsheet counted and what tool it was built in (F5, F6), whether you have coached anyone beyond new tellers (F8), and whether you have worked with a digital team (F9) → those rows move from discovery to grounded, and the guidance gets story-mapped
- Your actual pay figure, notice period, location and reason for leaving → A4 to A7 get your own words quoted whole in Provenance instead of slots
- How many hours you have before 4 December → a prioritised prep schedule built around B3
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) for loop reports and recent organisation context → sharper persona weights and CO rows; offered once
- A `tuesday-dossier.md` → verified evidence and prohibited claims arrive pre-graded instead of built from your message
