# Interview pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees), per the JD you pasted.
Interviewer: not known. Round type and relationship: not given, so persona weights are flat (see the persona table).

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment: past behavior shown through a chosen story |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny and what was actually yours |
| JD | Role and JD-driven: the stated responsibilities and qualifications, gaps included |
| CO | Company and strategy knowledge. None in this pack: research was unavailable (see Sources) |
| CASE | A live problem set in the role, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for you now. Where a row says "Answer slot", say it aloud in your own words, taking whichever branch is true.

## Prep triage

You have until next week. In this order, then stop:

1. Rehearse A1 aloud with both follow-ups until the concession no longer feels defensive. It is the highest-ROI prep in the pack.
2. Defend the number: C1, then E2.
3. Say the Power BI line (F6) out loud once, with your plan: C3 and E3.
4. Decide your truthful branch on each answer slot in the fit snapshot (F1, F2, F3, F4, F5, F7, F8).
5. Run B1 and B2 once each as a structured, think-aloud answer.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted; evidence is your own sentences from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops and a shift manager role; it does not show work across more than one site, or terminal-style freight work. The words stay at the quotes: "For seven years I've worked in warehouse and distribution ops." Answer slot: the JD's "across 4 sites" line makes a probe on whether your work has spanned sites likely. If it has, say which sites and what part was yours, in your own words; if it has not, say so plainly and stay with the shift and the supervisors you work with |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | Your material says the surge plan, not on-time performance, and nothing in it shows whether on-time was tracked. Answer slot: the JD's on-time line makes a probe on your on-time record likely. If on-time was measured around that plan, say what the measure was and what it showed, in your own words; if it was not measured, or not yours to track, say so plainly and say what you would measure first |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says mis-picks, not cost, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's cost-per-shipment line makes a probe on cost likely. If you tracked any cost effect from that redesign, say what you tracked; if you did not, say so plainly and say what you would look at first for cost-per-shipment |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors; the JD says 12. The words stay at the quote: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have been responsible for more than three supervisors at any time, say when and how many, in your own words; if you have not, say so plainly, then give how you would ramp to twelve, as a plan and never as a past |
| F5 | "build reporting in Excel/Power BI" — JD, the Excel half | "solid Excel" — your message | low | [inferred] | discovery | Your material gives a self-description and names no report, so it is a clarify note and not a claim about what you built. Answer slot: the JD's "build reporting" line makes a probe on what you have built likely. If you have built reports in Excel, say what they showed and who used them, in your own words; if you have not built reports there, say so plainly and say how you use Excel |
| F6 | "build reporting in Excel/Power BI" — JD, the Power BI half | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives seven years in ops and a current shift-manager role; it does not say how many of those years were spent leading people. The JD marks the line required, so expect the probe. Words at the quote's scope: "I have 7 years in warehouse and distribution ops." Answer slot: say in your own words when you began leading people and for how long; if you do not know the exact count, say so plainly |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | presentation | Your quote reaches the requirement in other terms: the JD says Lean/Six Sigma, your sentence says green belt. Words: "I'm green belt certified." Your message does not say which green belt, so say it as the certificate names it. Answer slot: if the pick-path redesign was part of your green belt work, say so; if it was separate, or you do not connect them, say so plainly |

## Persona table

Round type and relationship were not given and no loop source was read, so weights fall back to the Generic archetype (screen, hiring manager, panel) and are flat. The order of the banks follows where this pack finds the most to rehearse, not a prediction of the round.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the scale and tool gaps | Even weight. The JD's 12 supervisors and 4 sites sit against F4's 3 supervisors, the widest gap in the snapshot, so A1 gets the deepest rehearsal | Rehearse the single most predictable objection (A1) until it is boring; bridges only from F-row quotes at their own scope |
| B. Case / Strategist | Live problems drawn from the JD's on-time and cost lines | Even weight. Two JD lines (F2, F3) are directly diagnosable problems | Clarify, then segment, then approach, then metrics, then risks; think aloud; use the bank's structures and no past claims |
| C. Data-Driven Prober | Asks how a figure was counted and what was yours | Even weight. F3 holds the one headline figure in your material | Know what you can and cannot say about how the 40% was counted; say plainly where you do not know |
| D. Conversational | Friendly openers that are still scored | Even weight. An open round often starts with the biography | A 90-second arc built only from your own sentences (D1) |
| E. Pressure | Interrupts, time-boxes, questions motives | Even weight. The scale and Power BI gaps are the natural pressure points (F4, F6) | Pause, restate, hold the position the quotes carry through two follow-ups, concede specifically |
| F. Peer | Seam-splitting between sites and collegial probes | Even weight. The JD's 4 sites imply neighbouring site leaders, a reading and not a source | Offer seam principles, not claims about a seam you have not seen; reciprocity framing |
| G. Values / Behavioral | Story prompts on judgment and people leadership | Even weight. No values-style round is detected (the Generic archetype reads no, and no loop source was read), so these use generic stems and selection scaffolds | Pick the story by the criteria given, and take the honest branch if none comes to mind |

## Question banks

Provenance quotes are exact sentences from the fit snapshot. `[generic]` rows make no claim about your past.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a senior shift manager over 3 supervisors today, and this role has 12 supervisors across 4 sites. What changes for you?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Beat 1: say that sentence plainly. Beat 2: concede the size in your own words, that twelve is more than three. Answer slot: if you have been responsible for more than three supervisors, or for work across more than one site, say when and how many, in your own words; if you have not, say so plainly and stay with the three. Beat 3: a ramp plan, said as a plan and never as a past: what you would learn first, and from whom, at each site. Follow-up 1, a probe on whether it scales: do not argue scale; return to the three and to your plan. Follow-up 2, a probe on what you would get wrong first: name the one thing you would be slowest at, in your own words, and what you would do about it. Add no figure, site or event the quote does not hold | F4 is the widest gap between the JD and your material, so some form of this objection is likely; JD because it scores a stated requirement, delivered as a Skeptic probe |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "7 years in warehouse and distribution ops" | Name one weakness honestly, with a plan, not a list. If you choose Power BI, the words are your stated negative: "I haven't used Power BI." Then how you would learn it, as a plan and never as a past. If you choose the terminal side, the quote is "7 years in warehouse and distribution ops" against the JD's terminal operations. Answer slot: if any of your seven years touched terminal-style work, say which part in your own words; if none did, say so plainly and stay with warehouse and distribution | F6 is the one gap you stated outright and F1 is the widest in wording, so the likeliest candidates for the answer; JD because it scores the stated requirements, asked as a Skeptic probe |
| A3 | "Why this role, and why now?" | EXP | [generic] | The question needs no claim about your past, so the guidance makes none. Give your actual reason in your own words; it needs one reason that points at this role's content (the JD's scope: four sites, twelve supervisors, on-time and cost-per-shipment) rather than only away from your current job. Reasons specific to Atlas Freight need research this pack does not have, so read their site before the interview and use only what you find there. If no clear reason comes to mind beyond wanting a larger role, say that plainly | Motivation consistency is scored in nearly any loop; EXP because it tests whether your story about yourself holds together, and the pack has no company research to make it CO |
| A4 | "The JD asks for 5+ years of operations leadership. Walk me through your leadership years." | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Start at the quote's scope: "I have 7 years in warehouse and distribution ops." Answer slot: say when you began leading people and for how long, in your own words; if you do not know the exact count, say so plainly. If it is under five years, say so plainly, then give what you do lead now: "I'm currently a senior shift manager over 3 supervisors." Do not present the seven years as seven years of leadership | F7 is a required line whose evidence says ops years and not leadership years; JD because it scores that requirement literally |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance has dropped at two of the four sites over the last month. Diagnose it." | JD | [generic] | A structure and no claim about your past. Clarify first: how on-time is defined, which lanes and shifts, since when, and what changed. Segment: by site, lane, time of day, customer, inbound versus outbound. State two or three hypotheses (volume, labor, equipment, carrier) and the data that would confirm each. Separate containment today from root cause. Say who you would involve and what you would track afterwards | F2's requirement as a live problem; JD because it scores the on-time line, with CASE delivery |
| B2 | "Cost-per-shipment is above plan. Where do you look first?" | JD | [generic] | A structure and no claim about your past. Clarify the definition and denominator, then break the cost into its parts (labor, linehaul, dock handling, rework, claims) and look at volume mix. Name the trade-off with on-time before proposing levers, and say how you would test a change at one site before rolling it out | F3's requirement as a live problem; JD because it scores the cost line, with CASE delivery |
| B3 | "Peak volume is forecast to jump, and the four sites have different capacity. How do you plan it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Answer it first as a structure: forecast, capacity per site, labor and equipment, carrier options, triggers for contingency, post-peak review. If the interviewer asks about your own experience, return to your words: "I ran the site's peak-season surge plan two years running." Answer slot: name the part of that plan you would least expect to carry over to four sites, or say plainly that you do not yet know. Add no figure or event the quote does not hold | F2's evidence is the surge plan, the nearest thing your material has to this problem; CASE because it is a live planning problem set in the role |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut the mis-pick rate by 40%. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what the quote says, in your own words: you cut the mis-pick rate 40% by redesigning the pick path. Four answer slots, each in your own words. How it was counted: the denominator and the time window, or say plainly that you do not know. What it is sensitive to. The assumption you would defend least, named before they ask. Which part was yours; if part was not, say which part and whose. If you do not know how it was counted, say so plainly. Do not explain a method you cannot repeat under a second question | F3 holds your one headline figure, the usual first target of a probe; EXP because it tests attribution and counting |
| C2 | "Walk me through the pick path redesign." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Tell it in your own words with the beats the quote states: a pick path, a redesign of it, a 40% cut in the mis-pick rate. Answer slot: which part was yours; if others did part, say which, and if the redesign was yours alone, say so plainly. Add no step, tool or stakeholder reaction beyond what you actually did | F3 again, from the story side; EXP because the probe is on what you did, not on the number |
| C3 | "The role builds reporting in Excel and Power BI. Tell me about your experience with each." | JD | [grounded] "solid Excel"; "never used Power BI" | Excel: answer slot. If you have built reports in Excel, say what they showed and who used them, in your own words; if you have not, say so plainly and say how you use Excel. Power BI: the words are your stated negative, "I haven't used Power BI." Then a plan, said as a plan: what you would do first to learn it. Do not describe Power BI work, and do not claim Excel reporting beyond what you say in your own words | F5 and F6 are the tool half of the JD's reporting line; JD because it scores that line directly |

### D. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc whose beats are only your own sentences, in order: the seven years in warehouse and distribution ops, where you are now, the pick-path redesign and the surge plan, the green belt. End on why this role, in your own words (see A3). Every beat stays at its quote's scope | An open biography prompt is the likeliest opener of an unstructured round; EXP because it tests whether your story is coherent and unembellished |
| D2 | "The posting mentions Lean and Six Sigma as a plus. Tell me about your background with them." | JD | [grounded] "green belt certified" | Start with your own words: "I'm green belt certified." Say the certification as your certificate names it, since your message does not say which belt. Answer slot: if the pick-path redesign was part of your green belt work, say so; if it was separate, or you do not connect them, say so plainly. Do not call anything a Six Sigma project unless it was | F8 is the one requirement your material meets in other terms; JD because it scores the plus-skill, asked casually |
| D3 | "What does a normal shift look like for you at the moment?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops" | Describe a real shift in your own words, starting from the quote: "I'm currently a senior shift manager over 3 supervisors." Pick one ordinary shift and describe it in the order it happened; if you cannot pick a typical one, say so and describe the last one. Add nothing you would not repeat under a second question | A casual question that is still scored; EXP because it checks that F4 and F1 describe real daily work |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who already runs four sites?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Pause, restate the question, then hold on what the quotes carry: "I cut mis-pick rate 40% by redesigning the pick path" and "I ran the site's peak-season surge plan two years running." Hold through two follow-ups; do not add to those sentences. Concede specifically: three supervisors is fewer than twelve. Answer slot: if you have not worked across sites, say so plainly and return to the two sentences | F1 and F4 are where a pressure probe lands; JD because it tests fit against the stated scope |
| E2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the quote first: you cut the mis-pick rate 40% by redesigning the pick path. Answer slot: name what part was yours and what part others did, in your own words; if others did none of it, say so plainly and say what you relied on others for. Hold through two follow-ups; concede only the specific part that was not yours, and do not fold the whole claim to restore harmony | F3's figure under pressure; EXP because it scores attribution honesty |
| E3 | "You've never used Power BI, and we need reporting built in it. Why should we wait for you to learn it?" | JD | [grounded] "never used Power BI"; "solid Excel" | Your stated negative is the starting point: "I haven't used Power BI." Concede that you cannot promise a timeline you do not know. Hold on what your own words carry: your Excel, at its own scope, with the slot from C3 (what you built, or say plainly that you have not built reports). Then give a plan in your own words, as a plan. Do not claim you learn quickly unless you can name where you did | F6 under pressure; JD because it scores the Power BI half of the reporting line |

### F. Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Suppose two of our sites need the same dock door or trailer pool at the same hour, and we disagree. How do we handle it?" | CASE | [generic] | Offer principles, not a claim about a seam you have not seen: agree the priority rule before the conflict (the shipment commitment that cannot slip), escalate by exception, and review afterwards without blame. Say you would ask how it works today before proposing a change | The JD's four sites make peer seams a likely topic; CASE because it is a live problem with no claim about your past |
| F2 | "How do you handle credit when a result spans teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Use "we" for context and "I" for what you did. Your own sentence is "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which part was shared with others and what they did; if none was shared, say so plainly. Never claim sole credit for a part you cannot defend | F3 is your one result that could be shared; VAL because it scores collegial credit behaviour |
| F3 | "What would you need from me and my team in your first month?" | JD | [generic] | Reciprocity framing and no claim about your past: ask for a walk of the site, the definitions behind on-time and cost-per-shipment, and access to the current reports; then say what you would give back, as a plan, such as sharing what you learn at each site. Keep the asks small and specific | A peer prices what the hire costs them; JD because it scores readiness for the role in its first month |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold, no claim about your past: pick a time with a named stake, a moment you did not soften the message, and a relationship that was intact afterwards. Choose one in which the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values prompt; VAL, and generic because no published values were read |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold, no claim about your past: pick a time where the on-time commitment and a cost or productivity number pulled apart, and say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Links to the on-time versus cost-per-shipment trade-off in the JD (F2, F3); VAL, generic because no values page was read |
| G3 | "Tell me about a time you had to change how a supervisor worked." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Your context is the quote: "I'm currently a senior shift manager over 3 supervisors." Selection scaffold: pick a time with a specific behaviour, a conversation you had, and a result you can describe without exaggeration. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD asks you to lead 12 supervisors (F4); VAL because it scores behaviour with a direct report |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, B3, E1, F1 |
| "drive on-time performance" | B1, B3 |
| "cost-per-shipment down" | B2 |
| "lead a team of 12 supervisors" | A1, G3 |
| "build reporting in Excel/Power BI" | C3, E3 |
| "5+ years operations leadership required" | A4 |
| "Lean/Six Sigma a plus" | D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How are on-time performance and cost-per-shipment defined today, and do the four sites measure them the same way?" | Asks for the definitions before the levers; the answer tells you whether the measures F2 and F3 depend on exist in the form the JD assumes |
| R2 | "What does the reporting look like now: what is built in Excel, what is in Power BI, and who maintains it?" | Puts the Power BI gap (F6) on the table as a question about the job, and tells you whether you would be building or reading reports |
| R3 | "How are the twelve supervisors spread across the four sites and shifts, and where does the team need the most support?" | Moves the scale question (F4) from your history to their situation |
| R4 | "What would success look like at 90 days, and which site would you want me to start with?" | Gives a concrete first target and shows you are planning the ramp A1 asks for |
| R5 | "What is the biggest operating constraint across the sites right now: capacity, labor, equipment or carriers?" | The answer shows what the on-time and cost lines are really up against and which case structure (B1, B2) the interviewer cares about |
| R6 | "How is peak season planned across the sites today, and who owns the plan?" | A natural opening for F2's evidence in your own words |

## Prohibited claims

What this pack will not coach, with the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed twelve supervisors, or led across four sites | Inflated form of F4 and F1 | F4's quote at its own scope: "I'm currently a senior shift manager over 3 supervisors." The limit is the pack's observation: your material says 3 supervisors and does not show work across sites. A1's slot stays with the three |
| Owned or ran terminal operations | Inflated form of F1 | F1's quote at its own scope: "7 years in warehouse and distribution ops". The material says warehouse and distribution, not terminals |
| Kept on-time performance up through peak | Inflated form of F2 | F2's quote at its own scope: "ran the site's peak-season surge plan two years running". The material says the plan, not an on-time result; B3's slot stays inside the plan |
| Cut cost-per-shipment | Inflated form of F3 | F3's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path". The material says mis-picks, not cost |
| Built reporting or dashboards in Excel | Inflated form of F5 | F5's quote at its own scope: "solid Excel". The material names no report |
| Power BI experience | Negative you stated, F6 | The plain acknowledgment F6 gives: "I haven't used Power BI." No slot |
| Seven years of operations leadership | Inflated form of F7 | F7's quote at its own scope: "7 years in warehouse and distribution ops". The material says ops years, not leadership years |
| The pick-path redesign was a Six Sigma project | Inflated form of F3 and F8 | The two quotes at their own scopes, separately: the redesign (F3) and "green belt certified" (F8). D2's slot asks whether they connect |

## Sources

Provided documents: your message, containing the JD text and your background. No dossier was consumed.

Searches sent (each refused: the host did not grant search permission):

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics terminals news strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have fed a values cheat sheet and raising sources for the VAL bank; the G bank is generic instead |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have named the real rounds; persona weights use the Generic archetype and are flat |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have supported a CO question and grounded the case bank; no CO question is in this pack |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who the interviewer is (recruiter, hiring manager, panel, peer) → persona weights stop being flat and the banks reorder; a recruiter screen would also add logistics rows for pay, notice, location and the reason for leaving
- The interviewer's name and title → an interviewer read from their public footprint and a reverse question tied to their own path
- Research access, or Atlas Freight's values page, careers page or any interview guidance pasted in → a CO question, a values cheat sheet if a values round is documented, and a loop structure in place of the archetype; a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is available once, on your say-so
- The recruiter's guidance on focus areas, or any pre-declared deliverable such as a site walkthrough or presentation → coverage matched to what is scored, and a build section for any deliverable
- Your answers to the slots in F1, F2, F3, F4, F5, F7 and F8, typed outside any rehearsal → those rows become story-mapped answers in place of branches
- The certificate behind "green belt certified" and the mis-pick report or before-and-after figures behind the 40% → F8 and F3 can move from medium to high confidence
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence per requirement and an allowed strategy for each weak area
