# Stripe — Product Operations Manager: final-round interview pack

- **Role:** Product Operations Manager
- **Company:** Stripe
- **Round:** final round; the sessions, interviewers and their relationship to you are not known
- **Interviewer:** not given
- **Built on:** no job description, no CV, no web research (every search was refused in this session). Persona weights rest on the generic loop pattern, not on a documented Stripe loop. Everything below is labeled so you can see what rests on what.

## 1. How to use this pack

Personas describe how a question is asked; types describe what is being scored. Rehearse both: say each answer aloud, in your own words, in under two minutes. Guidance is scaffolding, not a script. This pack has none of your history to draw on, so every answer is a selection scaffold or a method for you to fill from your real experience, and each one ends with the honest branch for when nothing fits.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values a company publishes, not generic virtue |
| EXP | Whether your claimed experience survives scrutiny, and how honestly you attribute it |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge, and thinking at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

Labels: `[grounded]` rests on a document you supplied or a page fetched; `[inferred]` is this pack's derivation from fetched material; `[generic]` is a pattern for the role family, not a fact about Stripe or about you. Everything here is `[generic]`, because no document was supplied and no page could be fetched.

## 2. Fit snapshot (worksheet)

You gave no CV, so this is a worksheet: the requirements are what the product operations role family typically asks, written as plain prose, not quoted from any posting. Fill the evidence column yourself before the interview, using only sentences you could defend under a follow-up. A `[generic]` row raises no specific probe.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate product launches or releases across product, engineering and go-to-market teams (role-family prose, no JD supplied) | none given | none | [generic] | discovery | Strong evidence looks like a named launch or release process, who was in it, and what changed because of it. Selection scaffold: pick one instance with named partners and a visible result; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Design and run operating cadences such as planning, reviews and decision forums (role-family prose, no JD supplied) | none given | none | [generic] | discovery | Strong evidence looks like a recurring mechanism you set up or changed, with who attended and what decisions it produced. Selection scaffold: pick one mechanism and say what it replaced; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Use data to measure product and process health and to inform decisions (role-family prose, no JD supplied) | none given | none | [generic] | discovery | Strong evidence looks like a metric you owned, how it was counted, and a decision it changed. Selection scaffold: pick one metric and be ready to say how it was counted and which assumption you would defend least; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Improve tools, workflows and processes for product teams (role-family prose, no JD supplied) | none given | none | [generic] | discovery | Strong evidence looks like one process or tool change, who adopted it, and how you knew it worked. Selection scaffold: pick the change you can explain end to end; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence partner teams without formal authority (role-family prose, no JD supplied) | none given | none | [generic] | discovery | Strong evidence looks like a disagreement with a partner team, what you did, and the state of the relationship afterwards. Selection scaffold: pick a case with a named stake; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Bring customer and field feedback into product decisions (role-family prose, no JD supplied) | none given | none | [generic] | discovery | Strong evidence looks like a piece of feedback you routed, to whom, and what happened to it. Selection scaffold: pick one where the feedback and an internal metric pulled in different directions; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Structure ambiguous problems and communicate clearly in writing and speech (role-family prose, no JD supplied) | none given | none | [generic] | discovery | Strong evidence looks like a problem you framed from a vague start and the artifact you wrote to settle it. Selection scaffold: pick one document or decision you can walk through; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## 3. Persona table

No loop source was read, so weights fall back to the Generic archetype (screen, hiring manager, panel) and are flat. This pack does not assert how Stripe's final is structured. If yours is several sessions, send the schedule and the pack splits into per-session mini-packs.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the role: diagnose, plan, decide | Flat. Live problems are a standard way to test a function whose job is judgment; the relationship to the interviewer is unknown | Clarify, state the objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of motivation and gaps: why this role, why here, why now | Flat, with one extra question. Motivation questions arrive in some form in any final round | Rehearse the most predictable objection until it is boring; calibrated candor over bluffing |
| C. Values / Behavioral | Scenario probes about hard truths, customers and integrity | Flat. No published values were in hand, so these use the persona's own stems | Pick a story where the hard truth landed; "we" for context, "I" for contribution; if none, say so |
| D. Peer Evaluator | Seam-splitting with adjacent teams, credit, disagreement | Flat. A product operations hire sits between teams, so seam questions are plausible from any adjacent interviewer | Offer seam principles instead of pretending to know the seam; frame what you bring, not only what you need |
| E. Data-Driven Prober | How a number was counted, which assumption is weakest | Flat. Measurement is a standard probe for an operations role | Say how a figure was counted or plainly that you do not know; name the weakest assumption first |
| F. Pressure | Time-boxed, interrupting, devil's advocate | Flat. Final rounds with senior interviewers often test composure | Pause, restate, hold through two follow-ups, concede specifically |
| G. Conversational | Friendly, unstructured; still scored | Flat. An opening biography question is near-universal | A pre-scripted 90-second arc; treat casual questions as scored |

Highest-ROI prep: **B1**. With no CV, this pack cannot see your biggest gap, so the most predictable objection is the one every final round carries: why this function, why this company, why now. Treat B1 as the placeholder until you send your background, which would replace it with the objection your own material makes likeliest.

## 4. Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two launches land in the same week, and engineering, support and sales each say their own readiness criteria matter most. How do you decide what ready means?" | CASE | [generic] | Ask first: who owns the launch decision, what each team's criteria protect, what happens if a criterion is missed. Then objective, a single shared checklist with an owner per item, how disputes get resolved, and what you would measure afterwards. Name one premise you would challenge, such as whether both launches need the same bar | Live problem set in the role, requiring no claim about your past; covers F1 and F5. CASE because structure is scored over the answer |
| A2 | "A product team's weekly planning meeting produces more discussion than decisions. Diagnose it and tell me what you would change first." | CASE | [generic] | Clarify what a decision would look like and who makes it; segment causes (attendance, inputs, ownership, format); pick the smallest change that tests your hypothesis, and say how you would know it worked | Tests operating-cadence design, F2 and F4, as a live diagnosis |
| A3 | "A metric leadership watches dropped 20% week over week. Diagnose it." | CASE | [generic] | Before explaining anything: is the drop real (definition, instrumentation, data pipeline), then segment (who, where, when), then candidate causes, then what you would check first and why. Say what you would not conclude yet | The stem for this persona; covers F3. CASE because the delivery is a live diagnosis |
| A4 | "Where does a product operations team create the most leverage in a company of this size, and where does it risk becoming overhead?" | CO | [generic] | Give a position, a concession and a test: where leverage is greatest in your view, the strongest argument against, and what evidence would change your mind. Add what you verified yourself about Stripe, in your own words; this pack could not research it | Strategy-altitude question; CO because it tests thinking at the company's level. Generic because research was refused, so it carries no Stripe-specific fact |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why product operations, why here, and why now?" | EXP | [generic] | Three short parts, each in your own words: why the function, why this company (a specific you checked yourself), why now. Hold through two follow-ups by returning to your own stated reasons; concede specifically anything you are unsure of. If one part is not clear to you yet, say so plainly and say what you are still working out | Highest-ROI prep (section 3). EXP because it tests whether your story survives cross-examination |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name a real gap from your honest self-assessment, then a concrete ramp plan for the first weeks. Calibrated candor beats claiming a strength you cannot defend. If you cannot name one, say so plainly and say what you would ask the team first | The stem for this persona; JD because it scores the listed job including its gaps, F1 to F7 |
| B3 | "What would make this role a mistake for you?" | VAL | [generic] | Say your own real answer, tied to what you want from the work. Do not offer a flattering non-answer; if you do not know yet, say so and say what you would need to learn | Probes motivation consistency; VAL because the answer shows your priorities |
| B4 | "If you joined and it was not working in six months, what would the most likely reason be?" | JD | [generic] | Name one honest risk from your side (for example a skill still ramping) and one from the context, and what you would do to catch it early. Keep it to what you can speak to truthfully | A quiet self-assessment probe; JD because it asks about success in the job |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a moment you did not fold, and an intact relationship at the end. Use "we" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The stem for this persona; covers F5 |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: the customer need, the metric it cut against, what you decided and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The stem for this persona; covers F6 |
| C3 | "A senior stakeholder asks you to report a launch as green when you believe it is not. What do you do?" | VAL | [generic] | Structure: what you would verify first, how you would raise it, what evidence you would bring, what you would not do, and how you would keep the relationship. Hold your position through two follow-ups | A live problem about integrity under pressure; makes no claim about your past. VAL scored, CASE delivered; covers F5 and F7 |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Offer seam principles instead of claiming to know the seam: who owns decisions, who owns the mechanism, how disagreements escalate. Say what you would ask first about how they work today | The stem for this persona; covers F2 and F5 |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: one piece of shared work, what was yours, what was theirs, how the credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The stem for this persona; covers F5 |
| D3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Lead with reciprocity: one thing you would offer their team, then one or two specific asks. Keep the offer to what you could truthfully deliver | Tests partnership fit; covers F4 and F5 |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a metric you were accountable for. How was it counted?" | EXP | [generic] | Pick one you can explain end to end. Say plainly how it was counted, or that you do not know. Add what it is sensitive to and which part of the result was yours. If no such metric comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Prober stem as an open prompt; covers F3. EXP because it tests attribution |
| E2 | "How would you decide whether a process change actually worked? What would you count, and what could mislead you?" | CASE | [generic] | Method: the baseline, a comparison, leading and lagging indicators, confounds, and what result would make you reverse the change. Supply no numbers you cannot defend | Hypothetical, so no claim about your past; covers F3 and F4 |
| E3 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Follow-up to E1. Name the assumption in your own words before it is pulled out of you. If you do not know how the figure was counted, say so plainly; that is a credible answer, and a guessed one is not | The stem for this persona; the weakest-assumption move |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, give two reasons that are true of you in your own words. Hold through two follow-ups; concede what you cannot know about the internal candidate. If you cannot say what sets you apart yet, say so plainly and say what you would ask | The stem for this persona; tests composure |
| F2 | "Pick one result you have told me about today. How much of it was actually you?" | EXP | [generic] | Attribution in your own words: your part, your partners' part. Do not widen your share to restore harmony. If the honest answer is a share, say it | The stem for this persona; EXP because it scores attribution honesty |
| F3 | "You have been talking for two minutes. What is the one thing I should remember?" | EXP | [generic] | One sentence you can defend, chosen from what you actually said. Practice it until it takes ten seconds | Tests economy under interruption; the one-line takeaway recurs across personas |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in your own words: where you started, the turns, why product operations, why now. Each beat is a fact you can stand behind; leave out anything you would not repeat under a follow-up | The stem for this persona; near-universal opener; covers F7 |
| G2 | "Why Stripe?" | CO | [generic] | Name two specifics you checked yourself from Stripe's own published material and say why they matter to this role. This pack could not fetch any, so it supplies none. If you have not yet found two, do that research before the interview | Homework signal in a casual register; generic because research was refused |
| G3 | "Where do you want to be in two years?" | VAL | [generic] | Your own answer, connected to the work this role does. Do not offer a destination you would not defend | Motivation check in a casual register |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 Launch coordination | A1, B2 |
| F2 Operating cadences | A2, D1 |
| F3 Data and measurement | A3, E1, E2, E3 |
| F4 Tools and process improvement | A2, E2, D3 |
| F5 Influence without authority | A1, C1, C3, D1, D2, D3 |
| F6 Customer and field feedback | C2 |
| F7 Structuring and communication | A1, C3, G1 |
| Motivation consistency (not a requirement) | B1, B3, B4, G3 |

## 5. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first ninety days look like for this role, and who will judge it?" | Turns a vague role into a definable target and shows you are already thinking about delivery |
| R2 | "Where does this team's remit stop and the product teams' begin?" | Surfaces the seam directly; echoes D1 so the answer helps you prepare for it |
| R3 | "What is the hardest cross-team tension this role would sit in?" | Invites a real story, and shows you expect friction rather than hoping to avoid it |
| R4 | "How does the team know product operations is working?" | Shows measurement discipline; the answer tells you how you would be judged |
| R5 | "What would make you hesitate about me, and can I address it now?" | Gives the interviewer room to voice an objection while you can still answer it |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer interviewer; use it only if the person is a peer |

## 6. Prohibited claims

No entries. The pack lists the stretched wording of sentences you wrote, or negatives you stated; you supplied none, so there is nothing to list, and that is an absence of material, not a clean bill. Until you send a CV, every answer above is yours to fill, and none of it may claim a launch, metric, process or result you cannot explain end to end.

## 7. Sources

Provided documents: your message naming the company, the role and the round. No job description, CV, dossier or interviewer information was supplied.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Query "Stripe operating principles values": refused. Would have moved the values cheat sheet and VAL questions by name |
| 2. Stripe interview process, product operations | unavailable | Query "Stripe interview process Product Operations Manager": refused. Would have moved persona weights and whether a values round is detected |
| 3. Stripe strategy and recent news | unavailable | Query "Stripe strategy news 2026": refused. Would have moved A4 and G2 from generic to strategy-grounded |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Query "Stripe Product Operations Manager job description": refused. Would have turned the F rows into quoted, `[inferred]` requirements |

## 8. Upgrade menu

- A job description pasted in → F1 to F7 become quoted requirements, the JD-tagged questions become `[grounded]`, and the coverage table is keyed to its list
- Your CV, or the four to six lines you would lead with → the evidence column fills, selection scaffolds become story maps, and the Skeptic bank retargets from B1 to the objection your own gaps make likeliest
- Who you meet and how they relate to the role, plus the schedule if the final is several sessions → persona weights recomputed and per-session mini-packs
- The recruiter's prep email → focus areas, and a build section for any assignment they announced
- Interviewer names → a reading of each interviewer's public professional path and a reverse question tied to it
- Permission to run web search → Stripe's published values by name, the documented loop, current strategy, a values cheat sheet if a values round is documented, and strategy-grounded CO and CASE questions
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief, interviewer talks and writing, role-family loop reports and recent org context
- How much prep time you have → a prioritized prep schedule sized to it
- A tuesday-dossier.md from an earlier evaluation of the role, if you have one → verified evidence, an objection derived from it, and an absolute list of claims not to make
