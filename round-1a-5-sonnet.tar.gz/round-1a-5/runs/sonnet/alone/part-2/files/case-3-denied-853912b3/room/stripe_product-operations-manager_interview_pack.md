# Stripe — Product Operations Manager — final-round prep pack

Interviewer(s): not given. Relationship to you: not given. Round: final round, format not given. Built on that assumption, with flat persona weights.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims about your work survive scrutiny, and what was actually yours |
| JD | The role's stated or typical responsibilities, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

Two limits shape everything below. No CV was supplied, so no row or question here says anything about your past: where a question reaches for your experience, the guidance is a selection scaffold that ends with an honest branch. And the research calls were refused (see Sources), so nothing here claims anything about Stripe's values, loop or strategy. Every question is labeled `[generic]` for that reason.

The highest-ROI prep in this pack is B1, "Which part of this role would you be weakest at on day one". It is built from the role family, since there is no CV to aim it at, and it will be replaced by your real weakest area once you share your CV.

## Fit snapshot

No background was supplied, so this is the worksheet variant: every evidence cell reads `none given`. The requirements are role-family patterns written as plain prose, not quotes from a Stripe posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate cross-team product launches or programs through to completion (role family, no posting seen) | none given | none | [generic] | discovery | Strong evidence here is a named launch or program, who was involved, and what you personally coordinated. Selection scaffold: pick one launch or program where you can say which parts were yours; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Set up and run operating rhythms such as planning, reviews and launch readiness (role family, no posting seen) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or ran, with what changed because of it. Selection scaffold: pick a rhythm you ran and what was yours to decide; if none was yours or none existed, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Define, track and report product or operational metrics (role family, no posting seen) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: definition, source, what it is sensitive to. Selection scaffold: pick one you can defend; if you do not know how a figure was counted, say so plainly and say what you would check |
| F4 | Influence engineering, product and go-to-market partners without owning them (role family, no posting seen) | none given | none | [generic] | discovery | Strong evidence is a disagreement or a change you drove across teams, with what you did and what the other side did. Selection scaffold: pick one where your part is separable from the team's; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Use data and tooling to diagnose problems and scale a process (role family, no posting seen) | none given | none | [generic] | discovery | Strong evidence names the tool or analysis and what you did with it. Selection scaffold: pick one analysis or tool you used yourself; if it was done by someone else, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Communicate status and decisions in writing to senior stakeholders (role family, no posting seen) | none given | none | [generic] | discovery | Strong evidence is a document or update you wrote and who read it. Selection scaffold: pick one you can describe from memory; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Be based where the role is based and work its office pattern (gate; no posting seen) | none given | none | [generic] | hard_gate | Your material does not establish this. It is a term you meet or do not, and no wording changes that |
| F8 | Hold the right to work in the role's country without sponsorship, if the role requires it (gate; no posting seen) | none given | none | [generic] | hard_gate | Your material does not establish this. It is a term you meet or do not, and no wording changes that |

## Persona table

The loop was not established: no source named Stripe's rounds or this session's interviewers, so the weights are flat and the order below is a convention, not a ranking. Tell me who is in the room and this section is recomputed.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the role: diagnose, plan, structure | Medium. A hiring-manager seat would favor it; relationship unknown | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of gaps and motivation | Medium. A final round usually has someone assessing risk; relationship unknown | Rehearse the likeliest objection until it is boring; say limits plainly |
| C. Data-Driven Prober | Reads claims closely, asks how numbers were counted | Medium. Metrics are central to the role family | Know what you can and cannot say about each figure; name the weakest assumption first |
| D. Values/Behavioral | Scenario probes mapped to published values | Unknown. No loop source says a values round exists, so none is assumed | Choose stories where the hard truth actually landed |
| E. Peer Evaluator | Seam-splitting, collaboration, credit | Medium. The role sits between teams, so a peer or partner may sit across | Offer seam principles and what you bring their team |
| F. Conversational | Friendly, unstructured; still scored | Medium. Often opens any round | A 90-second arc, true in every clause |
| G. Pressure | Interrupts, time-boxes, tests composure | Low. Likelier from a senior seat | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

Every Provenance cell is the label alone: no CV sentence exists to quote, and no guidance cell below makes a claim about your past.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch six weeks out has three teams each reporting a different status. What do you need to know first, and what do you do in your first week?" | CASE | [generic] | Clarify aloud before structuring: who owns the date, what counts as launched, what a slip costs. State a hypothesis early. Then objective, a single source of truth for status, owners per workstream, risks, and the cadence you would set. Challenge one premise respectfully. No claim about your past is needed | Covers F1 and F4 as a live problem. CASE because it scores structure, not history |
| A2 | "Adoption of a recently shipped feature is 20 percent below plan. Diagnose it." | CASE | [generic] | Clarify the metric definition and where the plan came from. Segment by user type and funnel stage. Separate measurement problems from behavior problems. Name what data you would pull first and what would change your mind | Covers F3 and F5. CASE with a metrics tilt |
| A3 | "You inherit a product organization with no regular cross-team planning or review rhythm. What do you set up first, and what do you refuse to set up?" | CASE | [generic] | Start from the problem the rhythm solves, not the ritual. Name one thing you would set up and one you would deliberately not, with the reason. Say how you would know it worked | Covers F2. The refuse half tests judgment about saying no |
| A4 | "What do you see as the hardest operating problem for a product organization at Stripe, and where would product operations help?" | CO | [generic] | Research was unavailable, so this pack knows nothing current about Stripe. Do your own reading of their published material first. Then offer a hypothesis labeled as one and invite correction. Never recite a source the interviewer has also read | The one strategy-flavored question; generic because no strategy research succeeded |
| A5 | "Give me, out loud, the three-sentence update you would send a vice president when a launch is slipping." | CASE | [generic] | Lead with the decision or ask, then the cause in one clause, then the date you can commit to. No hedging adjectives. Say it twice, tighter the second time | Covers F6 as a spoken task |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal. Name your real answer, not a strength in disguise. Structure: name it plainly, say why it is true in your own words, give a concrete first-thirty-days plan and who you would ask. Follow-up one, "So that is a real gap": hold, say yes, and stop. Follow-up two, "What if the team cannot wait": concede specifically, say what you would do in the interim, and do not fold into claiming strength. If no weakness comes to mind, say which area you have the least proof for | Aimed at the pack's thinnest evidence, which is everything until a CV arrives; see F1 to F6. JD because it scores the role's requirements, including gaps |
| B2 | "Why this role, and why now?" | EXP | [generic] | Give your real reasons: one about the work, one about timing. Do not criticize a current employer. If only part of the reason is about the role, say that plainly | Motivation consistency is the standard Skeptic probe; EXP because it tests what is actually yours to say |
| B3 | "Product operations sits between product, engineering and go-to-market without owning any of them. Where does your authority come from?" | JD | [generic] | Authority from a clear mandate agreed with a senior sponsor, from being useful to each team, and from visible decisions made transparently. Say what you would ask for in week one | Covers F4 as a role question with no past premise |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Choose a number you have reported to leadership and walk me through how it was counted." | EXP | [generic] | Choose one you can fully explain: definition, source, owner. If you do not know how a figure was counted, say so plainly and say what you would check. Never reconstruct a method you cannot repeat under a second question | Covers F3. Open prompt, so you choose the instance |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it in your own words before they do. If you know of none, say you do not know of one and what you would test first | The weakest-assumption move converts a gotcha into credibility; see F3 |
| C3 | "Which three metrics would you put on a launch dashboard, and what would each fail to tell you?" | CASE | [generic] | One leading, one lagging, one health metric, each with its blind spot. Say who would act on each | Covers F3 and F5 without a claim about your past |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time where the truth actually landed, with a named stake and an intact relationship afterward. Use we for context and I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; see F4. No Stripe values were retrieved, so this is not mapped to any |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a decision, not a sentiment: what the metric was, what the customer needed, what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; generic until Stripe's published values are in hand |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer principles, not a map of a seam you cannot see: who decides what, how disagreements escalate, what you bring their team. Do not pretend to know their boundaries | Covers F2 and F4 |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a case where credit was shared and say how, in one clause. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; see F4 |
| E3 | "An engineering lead tells you your launch process is slowing her team. What do you do?" | CASE | [generic] | Listen first and ask for the specific step. Separate real cost from habit. Be willing to cut a step. Say how you would check the change helped | Covers F1 and F4 |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you are now, how you got here, why this role. Every clause true and defensible. It becomes story-mapped once a CV is supplied | The most common opener and still scored |
| F2 | "What is the one thing you would want us to know that your résumé does not show?" | EXP | [generic] | Choose something real and checkable that bears on the role, said in one or two sentences. If nothing comes to mind, say what you would like to talk about instead | Casual register, scored for economy and judgment |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give two reasons you can back from your own record. Hold through two follow-ups and concede what you do not know specifically | Persona stem testing composure |
| G2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | State the split plainly: what you did, what the team did. Hold that split through two follow-ups, concede any piece you cannot back, never fold the core claim. If the honest answer is mostly the team, say so | Attribution probe; hold-then-concede |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1 launches | A1, E3 | |
| F2 rhythms | A3, E1 | |
| F3 metrics | A2, C1, C2, C3 | |
| F4 influence | A1, B3, D1, E1, E2, E3 | |
| F5 data and tooling | A2, C3 | No tool is named by any source, so none is asked about |
| F6 written communication | A5 | |
| F7, F8 gates | none, and why | Gate rows ask nothing; the closing message asks whether you meet them |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make the first six months in this role clearly successful from where you sit?" | Shows you are working from outcomes, and gives you the scoring sheet for the role |
| R2 | "Where does product operations stop and where do product, engineering and program teams start here?" | Tests the seam you were just asked about, and signals you know the role lives there |
| R3 | "What is a process this team set up that you would do differently now?" | Invites candor and shows you expect processes to be revised |
| R4 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity framing: what you bring, not only what you need |
| R5 | "How does the team find out whether a process change actually worked?" | Signals metric discipline without claiming a method |
| R6 | "What separates people who are strong in this role from people who are merely good?" | Gets the real bar in the interviewer's own words |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No CV sentence, stated negative or dossier was supplied, so there is no stretched wording to list and no sourced entry | The pack asserts nothing about your past: every past-tense question is a selection scaffold that ends in an honest branch |

## Sources

Provided: your message (company, role, "final round"). No CV, JD, interviewer information or recruiter guidance was supplied.

Searches sent, all refused:

- "Stripe operating principles values" — refused
- "Stripe interview process product operations manager" — refused
- "Stripe strategy news 2026" — refused
- "Stripe Product Operations Manager job description responsibilities qualifications" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have fed a values cheat sheet and VAL mapping; none built, and D1, D2 and E2 are generic |
| 2. Stripe interview process, role family | unavailable | Would have fixed the loop and persona weights; weights are flat and no round structure is asserted |
| 3. Stripe strategy and recent news | unavailable | Would have grounded A4 and a grounding brief; A4 is generic and no brief is included |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Would have given quotable requirements; F1 to F8 are plain-prose role-family patterns |

## Upgrade menu

- Your CV, or the lines you would lean on: every `none given` row becomes a quoted row, and the selection scaffolds become story-mapped answers
- The job description: F1 to F8 become quoted requirements, and the coverage table is checked against its own list
- Interviewer names or roles, and the schedule if the final is several sessions: persona weights recomputed, a tailored reverse question, and per-session mini-packs
- Recruiter guidance on focus areas or a presentation or case to prepare: a build section for each declared deliverable
- Search access, or Stripe's values page and recent strategy material pasted in: A4 grounded, a values cheat sheet if a values round is documented, and a grounding brief
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes
- A `tuesday-dossier.md` from job-underwriter: verified evidence, a named highest-risk objection and strategy limits per gap
