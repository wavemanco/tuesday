# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round. **Interviewer(s):** not given. **Relationship:** not given, so persona weights are blended (see the persona table). **Built from:** your message only. No JD, no CV, and no research (the web searches were not permitted), so this is a lower-detail pack than it could be. The upgrade menu says what each missing input would change.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether claims about your work survive scrutiny |
| JD | Whether you can do the role as described, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem |

Provenance labels: `[grounded]` traces to something you gave me or to cited research; `[inferred]` is derived from a named source; `[generic]` is a role-family pattern with no claim about Stripe or about you. **Every row below is `[generic]`**, because the pack had no JD, no CV and no research to ground anything.

## Fit snapshot (worksheet variant)

You gave no background, so no row has your evidence, and none of these requirements is quoted from a posting. The requirements are plain-prose role-family patterns, not Stripe's stated requirements. Use the "bridge" column as a worksheet: find your own evidence for each row, then send it to me and I will turn the rows into quoted, story-mapped ones.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or programs across product, engineering and go-to-market teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence names the teams, your part, and what changed because of it. Selection scaffold: pick one cross-team effort where you can say plainly which part was yours; if no such effort comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define and run operating rhythms such as planning, reviews and launch readiness (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a recurring forum you set up or ran, with who attended and what it decided. Selection scaffold: pick a recurring meeting or review you owned or helped run, and be clear about whether you designed it or inherited it; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Define, track and act on metrics (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: how it was counted, what it is sensitive to, and which part of the movement was yours. Selection scaffold: pick one number you could defend under two follow-ups; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Design or improve processes and prioritize between competing requests (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a process change with a before, an after and a reason you picked it over alternatives. Selection scaffold: pick a time you chose one improvement over others, and what you declined; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence without authority, including in writing (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a decision that moved because of your argument, plus a written artifact others used. Selection scaffold: pick a time you moved a group that did not report to you; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Operate with ambiguity and limited context (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a situation with unclear ownership or goals and what you did first. Selection scaffold: pick a time you started work before the problem was well defined; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Familiarity with the product area and customers of the team you would join (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is first-hand use or first-hand reading you can describe in your own words. The pack states nothing about Stripe's products because no source for them is in hand. Selection scaffold: pick what you have used or read directly about this company; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

No loop source establishes how Stripe's final round runs: "final round" alone names no sessions, and no research ran. The weights below rest on round-type priors for an unknown relationship, blended, and will move when you tell me who you are meeting.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A, 5 questions) | Live problems on launches, metrics and process | Highest: a hiring-manager prior and a skip-level prior both lead with it, and a role that runs operating work lends itself to live problems | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (bank B, 4 questions) | Quiet probing of gaps, motivation, why here and why now | High: the same hiring-manager prior, and a final round is where residual doubts get tested | Rehearse the most predictable objection until it is boring; name limits plainly; give a ramp plan as a plan |
| Values / Behavioral (bank C, 3 questions) | Scenario probes for stories | Medium: a cross-functional interviewer in a final round would lead with it. No values-style round is established, so Stripe's published values are not in this pack | Pick stories you can tell with "we" for context and "I" for your part; use ones where the hard truth landed |
| Peer Evaluator (bank D, 3 questions) | Seam-splitting, "what would you need from me" | Medium: depends on whether a peer is in the loop, which is unknown | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober (bank E, 3 questions) | Defend-the-number follow-ups | Medium: any metrics-heavy role draws it | Know and say how each number was counted; name your weakest assumption first |
| Pressure (bank F, 2 questions) | Time-boxed challenges | Lower: a skip-level or executive prior would raise it | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational (bank G, 2 questions) | Friendly, unstructured, still scored | Lower in weight, but present in most rounds | Prepare a 90-second arc from your own material |

## Question banks

Highest-ROI prep: **B1** (weakest part on day one). It is inferred from the persona, not from your CV, because no CV was given. Once I can see your background it will move to the real gap.

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks out. Engineering, sales and support each name a different blocker. What do you need to know first, and what do you do in the first two days?" | CASE | [generic] | Clarify before structuring: what launching means here, who decides go or no-go, what is truly blocking versus uncomfortable. Then sequence: get the three views side by side, find the shared dependency, name one decision and its owner, state what you would escalate. Think aloud and name your riskiest assumption. The question needs no claim about your past, so the guidance makes none | Live problem for F1 and F6. CASE because it scores structure, not history |
| A2 | "Adoption of a feature we shipped last quarter is 20% below plan. Diagnose it." | CASE | [generic] | Define the metric and the plan's basis first. Then segment: who, where, since when. Form two or three hypotheses (not reaching the right users, reaching but not activating, a measurement error), say what data separates them, and say what you would do before the data arrives. Challenge one premise, for example whether the plan itself was sound | Live problem for F3. The stem is the Case persona's metric-drop diagnosis |
| A3 | "Design the weekly operating rhythm for a product org of several teams shipping to business customers. What goes in it, and what stays out?" | CASE | [generic] | Purpose first (what decision does each forum exist to make), then audience, inputs, outputs, cadence, and what you cut. Name how you would know a meeting has stopped earning its slot. Describe what you would propose, not anything you have done | Live problem for F2. "What stays out" tests the willingness to remove work |
| A4 | "You can fix one process this quarter. Five teams each ask for theirs. How do you choose?" | CASE | [generic] | State your criteria before applying them (reach, cost of the status quo, effort, reversibility), apply them aloud, and name the one you would decline and how you would tell that team. Say what you would need to know that you do not | Live problem for F4 and F6. Saying no is part of the answer |
| A5 | "Six months in, how would you know product operations is working? What would you measure?" | CASE | [generic] | Separate outputs (what ops produced) from outcomes (what changed for the teams), pick a few measures per kind, and name how each could mislead. Name the weakest assumption behind your top measure before being asked | Live problem for F3. Rewards the weakest-assumption move |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Highest-ROI rehearsal. Check each of F1 to F7 against your own record and pick the one you are least able to evidence. Name it plainly, in one sentence, without cushioning. Then give a ramp plan said as a plan, not as a past: who you would talk to first, what you would read, and what you would deliver in thirty days. Hold through two follow-ups by returning to the gap and the plan; never claim the gap is smaller than it is. If no gap comes to mind, say so plainly, then name the area where you have the least direct time and how you would find out quickly | Every Skeptic probes this, and which gap it hits is yours to find. JD because it scores the role's requirements, gaps included |
| B2 | "Why this company, and why now?" | CO | [generic] | Give your own reasons in order of weight, each one something you can support from your own work or your own direct reading. This pack holds no research on Stripe, so do not borrow a company fact from it. If your reasons are partly about timing, say so plainly. If no company-specific reason comes to mind yet, say that, then say what you will look at before the interview | The "why here, why now" stem. CO because it scores homework; it is `[generic]` for lack of research |
| B3 | "Say you start and the product area is one you do not know. What do you do in your first thirty days?" | CASE | [generic] | A plan, not a history: who you meet and in what order, what you read, what you ask each person, what you hold back from changing, and the first small thing you would deliver. State what you would not do yet | Tests ramp realism for F6 and F7 without a claim about your past |
| B4 | "Operations work is often invisible when it goes well. How would you make your impact visible without taking credit for other teams' work?" | JD | [generic] | Describe your method: what you would record, how you would attribute, how you would report to teams rather than about them. Keep it as a method and say what you would do | Tests F5 and the credit-sharing posture |

### Bank C: Values / Behavioral

Stripe's published values are not in this pack (no research ran), so these are the persona's standard stems, not value-by-value questions.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, what you said, and how the person received it. Choose one where the hard truth actually landed, and say plainly how it ended, including if it went unresolved. Use "I" for what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard Values stem. Covers F5 and F6 |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: the story needs the metric, the customer's need, the call you made and what it cost. Say what was yours and what was the team's. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard Values stem. Covers F3 |
| C3 | "Tell me about a time you said no to a request from someone senior." | VAL | [generic] | Selection scaffold: a variant of the unpopular-truth stem, aimed at prioritization. Pick one with the request, your reason, what you offered instead and how the relationship ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Variant of the C1 stem, aimed at F4 |

### Bank D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Product operations and product management sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles instead of claiming to know the seam: PMs own what and why, ops owns how work moves and how it is measured (a starting position to test, not a fact about this team). Ask how they split it today. On disagreement, say how you surface it early and who breaks ties | Peer stem. Covers F1 and F5 |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams and say what you did about attribution. Use "we" for the work and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer stem. Covers F5 |
| D3 | "What would you need from me in your first month?" | JD | [generic] | Short and specific: two or three things (context, access, introductions, a first problem), then what you would offer in return so it is reciprocal. Do not list needs you cannot justify | Reciprocity check. Covers F6 and F7 |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick one metric you have reported on and walk me through how it was counted." | EXP | [generic] | Choose a metric you can defend. Cover how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how a figure was counted, say so plainly rather than reconstruct it | Defend-the-number rehearsal for F3 |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Follow-up to E1. Name the weakest assumption before the interviewer does and say what would change if it were wrong. If you do not know, say so plainly | Weakest-assumption stem |
| E3 | "That result: how much of it was actually you?" | EXP | [generic] | Follow-up to E1. Separate your part from the team's in plain words, without trimming either. If part of it was not yours, say so and return to what was | Attribution stem. Covers F3 and F5 |

### Bank F: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give one reason and one proof point from your own material, in that order. Hold the position through two follow-ups. Concede what is true (they know the org, you do not) before restating why your reason still stands | Pressure stem. Hold-then-concede |
| F2 | "I am not convinced operations work moves the business. Convince me." | JD | [generic] | Do not argue the function in the abstract. State what you would measure, what decision it would change, and what you would stop doing if it did not. Hold through two follow-ups; concede that some operations work is overhead, and say which kind you would cut | Tests F3 and F4 under challenge |

### Bank G: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in three beats: where you started, the one thing that mattered most, and why this role is next. Fill each beat from your own material, in your own words. If a beat is thin, shorten it instead of padding | Conversational stem. Casual openers are still scored |
| G2 | "What have you been learning lately that bears on this work?" | JD | [generic] | Name one thing you have genuinely been reading, trying or building, and what you took from it. If nothing comes to mind, say so plainly, and name what you would pick up first and why | Rapport-style probe for engagement. Covers F7 |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Cross-team launches | A1, D1, B3 |
| F2 Operating rhythms | A3 |
| F3 Metrics | A2, A5, C2, E1, E2, E3, F2 |
| F4 Process and prioritization | A4, C3, F2 |
| F5 Influence, including in writing | C1, C3, D1, D2, E3, B4 |
| F6 Ambiguity | A1, A4, B3, C1, D3 |
| F7 Product-area familiarity | B2, B3, G2 |
| Written communication specifically | none, and why: no source says a writing exercise exists. If your recruiter mentions one, it needs its own build section |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| H1 | "What would you want product operations to have changed, specifically, six months from now?" | It turns an open role into success criteria you can then hold yourself to |
| H2 | "Where does product operations end and product management begin on this team, and where is that still being worked out?" | It shows you think about seams and turf, and surfaces the honest answer |
| H3 | "What is one operating change here that worked and one that did not? What made the difference?" | It invites a real story instead of a pitch |
| H4 | "How does the team tell valuable operations work from busywork?" | It tells you how you will be judged, and signals you care about outcomes |
| H5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for use if the interviewer is a peer |
| H6 | "What is the hardest part of this role that is not in the job description?" | It invites candor and gives you a chance to address it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None | You gave no sentence about your past, so there is nothing for the pack to widen and no stated negative to carry. Silence is handled through selection scaffolds and answer slots, not a prohibition | When you send your background it becomes quoted evidence, and any wider wording of it will be listed here |

## Sources

Provided documents: your message (company, role, round).

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Every search was refused, so nothing from research is used in this pack. No fact about Stripe's values, loop, strategy or products comes from memory.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Query "Stripe operating principles values" refused. Would have moved the values cheat sheet and the VAL bank by named value |
| 2. `Stripe interview process product operations` | unavailable | Query "Stripe interview process product operations manager final round" refused. Would have moved persona weights and any session-by-session structure |
| 3. `Stripe strategy` or recent news | unavailable | Query "Stripe strategy 2026 news annual letter" refused. Would have moved the CO and strategy-grounded CASE questions |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Query "Stripe Product Operations Manager job description" refused. Would have turned F1 to F7 from `[generic]` to `[inferred]` |

## Upgrade menu

- The JD text → F1 to F7 become quoted `[grounded]` requirements and each JD question is tied to a stated line
- Your CV or a short background → the fit snapshot gets your quoted evidence, selection scaffolds become story-mapped guidance, and B1 moves to your real gap
- Who you are meeting and the format (manager, peer, skip-level, panel; any recruiter guidance or pre-set assignment) → persona weights are recomputed and any announced deliverable gets its own build section
- The interviewers' names → an interviewer read and a reverse question tied to their path
- If your final is several sessions, the schedule → a mini-pack per session
- Permission for web search → Stripe's published values, loop structure and strategy, which would add a values cheat sheet and CO questions. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once, if you want it
- A `tuesday-dossier.md` from a prior session → verified evidence and prohibited claims to build on
