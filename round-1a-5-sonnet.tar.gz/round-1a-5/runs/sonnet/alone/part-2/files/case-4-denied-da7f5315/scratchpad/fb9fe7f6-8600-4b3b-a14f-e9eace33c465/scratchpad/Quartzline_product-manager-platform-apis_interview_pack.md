# Interview pack: Product Manager, Platform APIs at Quartzline

Hiring-manager conversation, 45 minutes, Thursday. Interviewer name unknown. Built from your underwriting dossier (conditional_go). No company research was available, so the company-specific parts are thin and labeled.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your experience claims survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role |

The guidance is scaffolding, not a script. Say only what you actually did, in your own words. A line in quotation marks inside a guidance cell is your own sentence from the fit snapshot. An answer slot is an instruction for the interview: it asks nothing of you now.

**Highest-ROI rehearsal: B1.** The underwriter named this objection: you have not held the PM title or owned a roadmap, so why hire you over a PM with three years of the actual job? It gets the deepest rehearsal below.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | transferability | The dossier's strategy is bridge, and its limit is that this is adjacent work, never PM experience. Your quotes carry integration leadership and a playbook, not a product management role. Words at the quote's own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Position it as adjacent, and let the interviewer decide how far it transfers |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile (responsibility) | none given | none | [grounded] | capability | The dossier records this as a capability gap with strategy acknowledge_gap, and lists prohibited_claims: "Having owned a product roadmap". Plain words: "I haven't owned a product roadmap." Then a ramp plan said as a plan, never as a past, for example how you would learn the two squads' priorities in your first weeks. No bridge, and no slot |
| F3 | "Shipped API or platform products" — dossier role_profile (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The dossier does not list R2 among its weak areas, so this pack grades it from the quote alone, and the quote says integrations of the vendor's APIs, not shipping an API product. Answer slot: the JD's must-have makes a probe on what you shipped likely. If you took any API or platform product to release, say which and what part was yours, in your own words; if the work was integrating the vendor's APIs and no API product shipped under you, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [inferred] | presentation | Your quotes reach technical fluency in other terms: REST APIs and architecture. They do not name API docs or schemas, so say REST APIs and architecture, and let the interviewer name the next level. The playbook quote is inspectable, which is why the technical case is your strongest |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | presentation | The quotes reach customers (client integrations) and product (the roadmap-input sessions). They do not name sales or engineering squads. The roadmap-input sessions are confirmed but with limited inspectable proof, so expect a probe, and volunteer the limit before it is extracted |
| F6 | "Agile delivery experience" — dossier role_profile (preferred) | none given | low | [grounded] | discovery | The dossier's strategy is clarify. Answer slot: the JD names agile delivery, so expect a probe on how you have worked with delivery cycles. If you worked that way, say how in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline's two squads define it |
| F7 | "Run discovery with integration partners" — dossier role_profile (responsibility) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quote is sessions that fed client evidence to product, at the quote's own scope. Whether those sessions were discovery with partners in the JD's sense is not shown. Answer slot: if you ran any of them as open conversations with clients about what they need, say how; if they were for collecting input only, say so plainly and stay with the sessions |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile (responsibility) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | The quote carries requirements and go-live on client integrations, not specs for an engineering squad and not squad prioritization, which prohibited_claims lists. Answer slot: if any requirements you wrote were handed to a team that built from them, say what and for whom; if they were for client integrations only, say so plainly and stay with the integrations |
| F9 | "Define and track adoption metrics" — dossier role_profile (responsibility) | none given | none | [grounded] | discovery | Your material says nothing about metrics, and the dossier records no baseline on Quartzline's side either. Answer slot: if you tracked anything like adoption or completion across the integrations, say what was counted and how, in your own words; if you did not track one, say so plainly, and say what you would measure first |

Coverage line from the dossier: R1, R2 and R4 are the high-priority requirements. Decision authority versus the two squad leads and the current adoption baseline are Quartzline-side unknowns, handled in the reverse questions.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims: "Having held a product manager title or role" | Your quotes at their own scope: integration leadership and the playbook. The plain acknowledgment is the F1 and F2 wording |
| Having owned a product roadmap | Dossier prohibited_claims: "Having owned a product roadmap"; dossier acknowledge_gap area | "I haven't owned a product roadmap," then a ramp plan. No slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims: "Having set prioritization for an engineering squad" | The roadmap-input sessions quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product". They fed input; the quote does not show you decided |
| Shipped the vendor's API product itself | Inflated form of F3 | The integrations quote at its own scope. The pack's observation is that the quote says integrations of the vendor's APIs |

## Persona weights

Relationship prior: hiring manager means Case/Strategist and Skeptic dominate. Loop: no loop source was available, so the Generic archetype applies and the weights stay at the hiring-manager prior. No interviewer profile exists, so there are no signal adjustments.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (B) | Quiet probing of the title and roadmap gap | Highest. The dossier names this as the likely objection, and a hiring manager is buying capability and derisking gaps | Rehearse B1 until it is boring: hold the quote's scope, concede the gap plainly |
| Case/Strategist (C) | A live problem on the partner API platform | High. Hiring managers run live problems from their own roadmap | Clarify, structure, metrics, risks. Ask your two employer questions inside the case |
| Peer Evaluator (D) | Seam-splitting with the two squad leads | Medium. The unresolved squad-authority question makes the seam a real topic | Propose seam principles rather than pretend to know the seam |
| Conversational (A) | Opening biography and why-this-role | Medium, and always scored | A 90-second arc made only of your quotes |

## Question banks

### A. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background and why a product role now?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Three beats, each a clause your quotes state: the integrations, the playbook, the roadmap-input sessions. Tell them in your own words, in that order, and stop. Answer slot: the reason you want product work is not in your material. Give your own reason, in your own words; if you do not have a settled one, say so plainly and say what draws you to this role | F1, F7 and F4 carry the arc. EXP because it is a CV walk-through, and the probe will land on the medium-confidence sessions |
| A2 | "What are you actually playing with in API platforms these days?" | JD | [generic] | Your material says nothing about current activity, so the guidance makes no claim about you. Answer slot: if you are working with or reading about any API tooling or specs right now, name it in your own words; if not, say so plainly and talk about the REST API integrations quote at its own scope | The role is partner-facing APIs, so a casual question about it is scored (F4) |
| A3 | "What do you know about us and the platform?" | CO | [generic] | No Quartzline research was available to this pack, so there is nothing here to recite. Use only what you read yourself on their site or in the posting. Pick one concrete thing, say what you took from it, and ask a question about it | The pack has no company research, so this is the honest form of a CO question |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The underwriter's objection, worded as the dossier wrote it, and the deepest rehearsal in this pack. Level 1, concede first: "I haven't held the PM title and I haven't owned a product roadmap." Level 2, the bridge with its limit: "What I have is this: I led 30+ end-to-end client integrations of the vendor's REST APIs, I wrote the integration playbook my team uses, and I ran quarterly roadmap-input sessions feeding client evidence to product. That is adjacent to the job, not the job." Level 3, if pressed on the sessions: they are confirmed with limited inspectable proof, so say what they were and stop, and do not say they set priorities. Level 4, the ramp: say how you would learn the two squads' priorities before proposing anything. Hold through two follow-ups by returning to the quotes, never by adding to them. Answer slot: if the interviewer asks which part of the sessions fed a decision, say what you know, in your own words; if you do not know whether any did, say so plainly | F1 and F2 are the largest gap. JD because it scores a stated requirement, and the dossier named this objection as most likely |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Name the roadmap and prioritization first, since the dossier records it as a gap: "Owning a roadmap, which I haven't done." Then the ramp plan as a plan. Do not volunteer a weakness beyond the dossier's three | F2 is the acknowledge_gap area; saying it first is the credibility move. JD because it scores self-assessment against the role |
| B3 | "What did you actually ship, as opposed to integrate?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The quote is integrations of the vendor's APIs. Answer slot: the JD's shipped-products must-have makes this probe likely. If you took any API or platform product to release, say which and what part was yours; if not, say so plainly and stay with the 30+ integrations | F3 is the only must-have the dossier does not grade as a weak area, so this pack rehearses it |
| B4 | "How much of the roadmap-input work actually changed what product built?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The quote is sessions that fed client evidence to product, and it carries no outcome. Answer slot: if you know of anything product did differently after a session, say what and how you know; if you do not know, say so plainly and stay with the sessions. Do not claim you set priorities | F7 is medium, with limited inspectable proof. EXP because it tests attribution, and a prober will find this seam |
| B5 | "Have you worked in agile delivery inside a product org?" | JD | [generic] | See the F6 slot. Answer slot: if you worked with delivery cycles, say how in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how the two squads define it | F6 is the dossier's clarify area |
| B6 | "You say 30+ integrations. How was that counted, and which of them were yours end to end?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure is "30+", attached to integrations, and the quote says you led them. Answer slot: say how the 30+ was counted, in your own words, or say plainly you do not know how it was counted. Answer slot: say what the figure is most sensitive to, and which assumption behind it you would defend least. Answer slot: say which part was yours alone and which was shared; if the work was shared, say so plainly. Never round the number up or describe a count method you did not use | F1 and F3 rest on this one number, and it is the headline metric a prober will test. EXP because it tests attribution |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Partner API adoption has stalled. How would you diagnose it?" | CASE | [generic] | Clarify first: how adoption is defined, which partners, what changed. Then segment (new versus existing partners, by integration stage), then hypotheses, metrics and risks. This asks about no past, so the guidance makes none. Ask the baseline question from the reverse bank as part of clarifying | The JD's adoption-metrics line (F9) with the baseline unknown. CASE because it is a live problem |
| C2 | "Two squads want conflicting API changes. How do you decide?" | CASE | [generic] | Structure it: what each squad needs, what partners are asking for, what is reversible, who decides. Ask who owns the call, since the dossier shows decision authority is unresolved. Propose a principle rather than a verdict | F2 and the unresolved squad-authority question. CASE because it tests prioritization reasoning without claiming past prioritization |
| C3 | "A top partner wants a breaking change to the API. Walk me through it." | CASE | [generic] | Clarify scope and who else depends on it, then options (versioning, deprecation window, a partner-specific path), then the partner and internal communication. Technical fluency shows through the options, and you claim no past incident | F4 and F5. The case lets technical fluency show without any claim about your past |
| C5 | "A partner says the API documentation is confusing and they are stalling. What do you do?" | CASE | [generic] | Clarify which docs, which partner stage and how many partners are affected. Then separate a docs fix from a schema or design problem, decide who fixes what, and say how you would know it worked. This asks about no past, so the guidance makes none | F4: technical fluency shown through a live problem, without claiming you wrote API docs or schemas |
| C4 | "How would you decide what goes on the partner API roadmap next quarter?" | CASE | [generic] | State inputs first: partner evidence, adoption data, squad capacity, strategy. Then say what you would need to learn before proposing anything. This is where you can say that client evidence is what you have worked with, using the roadmap-input quote at its own scope | F2 asked as a live problem, so you can show reasoning while conceding you have not owned a roadmap |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where's the seam between you and the squad leads, and what happens when you disagree?" | JD | [generic] | Propose principles, not a verdict: the PM owns the what and why for partners, the leads own how, and a disagreement goes to evidence. Then say you would ask how it works here, since decision authority is the open question | The dossier flags squad authority as asserted but not evidenced, so the answer should not pretend to know the seam |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Use "we" for context and "I" for contribution. For the 30+ integrations, the quote says you led them, so state it at that scope: "I led them." Answer slot: if a team shared the work, say who did what; if nobody did, say so | F5. VAL because it probes collaboration behavior; no values were researched, so this is generic |
| D4 | "How would you earn trust with a squad lead who has run this platform for years?" | VAL | [generic] | Principles, not a past: listen first to what they own and why, bring partner evidence rather than opinions, and agree how disagreements get settled. You claim no history of doing this, and you do not say you have led an engineering squad | F5 and the squad-authority risk. VAL because it scores collaboration behavior; no published values were available, so it is generic |
| D3 | "What would you need from the squads in your first month?" | JD | [generic] | Reciprocity first: what you would bring (partner evidence from the sessions, quoted at scope), then what you need (their current priorities, how adoption is measured today) | F5 and the two Quartzline-side unknowns |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 3+ years product management | B1, B2, A1 |
| R2 Shipped API or platform products | B3, B6 |
| R3 Technical fluency | A2, C3, C5 |
| R4 Stakeholder management | D2, D3, D4, C2 |
| R5 Agile delivery | B5 |
| Run discovery with partners | B4 |
| Own the roadmap | B1, B2, C4 |
| Specs and delivery with two squads | C2, D1 |
| Adoption metrics | C1 |

A values round was not detected, because no loop source was available, so there is no values cheat sheet. The banks hold 18 questions: A1 to A3, B1 to B6, C1 to C5 and D1 to D4, with D4 and C5 listed before C4 and D3 in their tables. That is the bottom of the 18 to 26 range, because the missing company research left no CO or values questions to add.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's open risk: decision authority is asserted in the JD but not evidenced. The answer tells you whether you would own the roadmap or only coordinate it |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second risk: adoption is a named responsibility with no stated baseline. It also shows you think about the number you would be judged on |
| 3 | "What would a strong first 90 days look like for someone coming from the integration side?" | It names the transfer you are making and invites the hiring manager to say how big a gap they see |
| 4 | "How do the two squads split the platform, and where do they overlap?" | It prepares D1 and C2 and exposes the seam |
| 5 | "What does the hiring manager's side of discovery with partners look like today — who talks to them?" | It tests whether discovery is open to you or already owned elsewhere (F7) |
| 6 | "What does agile delivery look like for those squads in practice?" | The clarify move for F6, asked as interest instead of confession |

## Sources

- Provided: `tuesday-dossier.md` was consumed. It supplied `role_profile` (the JD equivalent), `handoff_to_mock_interview` (verified evidence, weak areas with strategies, the objection, risks, employer questions, prohibited claims) and `decision` (context only).
- Searches sent: "Quartzline company values" (refused), "Quartzline interview process product manager" (refused), "Quartzline API platform strategy news" (refused).

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have supplied named values and a values cheat sheet |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. It would have supplied the loop and persona weights |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have fed CO questions and made A3 and C-bank cases specific |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` supplies the requirements |

## Upgrade menu

- The interviewer's name and role → an interviewer read, reweighted personas and a reverse question tied to their path
- Quartzline's values page or a pasted strategy brief → CO questions and a values cheat sheet, with A3 becoming `[grounded]`
- The recruiter's notes on the interview focus → coverage of any declared deliverable
- Your CV or any inspectable proof for the roadmap-input sessions → F5 and F7 can rise from medium
- Your answers to the slots in F3, F6, F7, F8 and F9 → those rows become `[grounded]` and the B-bank guidance sharpens
- Deep research (up to 6 more searches and 2 more fetches, several minutes) → a strategy brief and a role-family loop report; offered once
