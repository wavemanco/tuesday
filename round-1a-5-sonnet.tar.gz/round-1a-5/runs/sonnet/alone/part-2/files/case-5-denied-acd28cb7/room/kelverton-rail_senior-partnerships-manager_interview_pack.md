# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60 minutes, two-person panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your POV on operator partnerships over the next 18 months, no slides, landing on what it means for the operators. Remaining 45 minutes: Q&A, with Ross pushing on commercials.

**What this pack is built on:** your message only. No job description, no CV text, and no copy of the market report reached the pack, and the web searches it tried were refused (see Sources). So company facts are limited to what you told me, and anything about Kelverton's strategy, values or people is labeled generic or left out. I assumed Ross is a senior commercial stakeholder rather than your line manager, because the recruiter's email does not say how he relates to the role.

## How to use this pack

- Personas describe how a question is asked: who is asking and in what style. Types describe what is being scored.
- Type key: **VAL** behavioral / values alignment. **EXP** work-experience deep-dive. **JD** role- or requirement-driven. **CO** company and strategy knowledge. **CASE** hypothetical or live problem.
- Guidance is scaffolding, not a script. Every sentence about your own past rests on a sentence you wrote, quoted in the Provenance column. Where the material is silent, the guidance is an answer slot: an instruction to answer from your own experience, or to say plainly that it was not yours.
- Labels: `[grounded]` traces to what you gave me, `[inferred]` is a derivation (named), `[generic]` is a role-family pattern with no claim about Kelverton or you.

## Prep triage (about four hours)

| Order | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 75 min | Choose your lead thesis and anti-pick, then say the POV out loud three times against a 15-minute timer, ending on the operator close | Section: Graded deliverable |
| 2 | 45 min | Rehearse the objection you will certainly get, to the point it is boring: concession wording first, then the adjacent evidence, then the ramp plan | B1, B2, D2 |
| 3 | 45 min | Write down what you actually know about how the 6, the 40 and the £4M were counted, and what you do not know. Practise saying "I don't know how that part was counted" without flinching | C1, C2, D1 |
| 4 | 30 min | Talk through the three commercial cases aloud, clarifying first each time | A5, C4, D3 |
| 5 | 15 min | Pick three reverse questions and say them aloud | Reverse questions |

Everything else is insurance. The remaining half hour is for one uninterrupted run of the POV plus B1.

## Fit snapshot

No job description was supplied, so requirements come from the recruiter's own words (quoted) and from role-family patterns (plain prose, no source). No row here is an eligibility or term requirement, so there are no hard-gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material shows an ISV channel in payments and bus and light rail planning, not operator partnerships, so the POV is a view and never a record: say "my view", not "what I have done". Words at their scope: "For the last four years I ran the ISV channel at a payments company." Answer slot: expect a probe on what carries from the ISV channel to operators. If some practice from it would carry, say which and why, in your own words; if none would, say so plainly and say what you would learn first |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email, quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | discovery | Your material does not show which operators, in what capacity, or whether any ran trains. Words at their scope: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: if your planning work put you in front of operators, say which kind and what you saw them care about, in your own words; if it did not, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter's email, quoted in your message | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The sentence gives a figure for influenced revenue and nothing about the commercial side of any deal. Words at their scope: "The number I had was roughly £4M of influenced revenue." Answer slot: if any part of the commercial side of partner deals was yours, say which part and what you decided, in your own words; if it was set elsewhere, or you only influenced it, say so plainly and stay with the influenced revenue |
| F4 | Carrying a revenue number for partner-sourced business (role-family requirement, no source) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota. What I had was influenced revenue." Then, as a plan and never as a past, how you would get to carrying a number. Nothing added to make the gap feel smaller |
| F5 | Selling or partnering into rail operators (role-family requirement, no source) | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then how you would learn it, said as a plan. The adjacent consulting sentence sits on F2 and stays at F2's scope |
| F6 | Build and scale a partner programme (role-family requirement, no source) | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | No gap in wording, but a CV-style line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: "I took the ISV channel from 6 partners to 40." The figures raise the four defend-the-number probes in C1 and C2, and the part of it that was yours is yours to state precisely |

## Graded deliverable: the 15-minute POV

**What was declared:** "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it." — recruiter's email, quoted in your message. The requested close: "Please land on what it means for the operators themselves."

**Grounded facts you can build on:**

| Fact | Row | Quoted exactly from that row | Use |
|---|---|---|---|
| Your channel background | F6 | "9 years in partnerships, last 4 at a payments company running the ISV channel" | One sentence of credibility, then move on. Do not use it as proof the plan will work |
| Your partner-scale figure | F6 | "took it from 6 partners to 40, roughly £4M of influenced revenue" | Mention at most once, at its scope. It will be probed (C1, C2, D1) |
| Your operator-side exposure | F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Use it in the first minute and in the operator close, at its scope, with the F2 answer slot ready |
| What Kelverton sells | none: from your message | "they sell scheduling software to train operating companies" — described to me in your message, not a CV sentence | The only company fact the pack holds. Everything else about Kelverton comes from the report you read |

**Three defensible theses** (choose one to lead, at most one to support; each carries a mandatory concession). All three are built to be checked against the report you read, which the pack has not seen.

| Thesis | What you would say | What it means for operators | Mandatory concession | Provenance |
|---|---|---|---|---|
| 1. Depth before breadth | For 18 months, deepen a small number of operator relationships into joint working relationships before widening | A named counterpart, a route to raise needs, and a regular joint review. They give time and access in return | Depth concentrates risk in a few accounts and slows the number of references. Partnerships also does not control what gets built, so the plan depends on commitments from product | [generic] |
| 2. Operator outcomes as the unit of partnership | Define each partnership by an outcome the operator already cares about (take the outcomes from the report, not from this pack) and review it jointly | The partnership is judged by something they already track, and they can hold Kelverton to it | Outcomes are hard to attribute to software, operators may not share the data, and a measure can mislead. Also: your own sentence is a count of partners, so be ready to say plainly that count is not the measure here | [inferred] derived from F6's quote "took it from 6 partners to 40, roughly £4M of influenced revenue" |
| 3. An ecosystem around operators | Extend partnerships beyond operators to the other firms operators work with, so Kelverton is easier to adopt and connect to | Fewer separate integrations for them to commission and manage (a hypothesis to test with operators) | This is where your experience is adjacent, not direct: you have said you have never sold into rail. Frame it as a hypothesis, and say up front that the ISV channel may not transfer | [inferred] derived from F1's quote "9 years in partnerships, last 4 at a payments company running the ISV channel" |

**Differentiation against the consensus answer.** The report was written by Kelverton's own strategy team and circulated to staff, so any prepared candidate will recite its shortlist back to people who already know it. Bring exactly one point from it, attributed to it, to show you read it. Then take one thesis where your view departs from it, with reasons. Then state one anti-pick: something you would decline to do in the 18 months. Options for the anti-pick, which the pack proposes and you must believe: not measuring success by number of partnerships (expect Deepa to notice your own sentence is a count); not building a tiered partner programme in the first 18 months; not trading exclusivity for speed. Whichever you pick, say what evidence would change your mind.

**Shape of the 15 minutes.** Minutes 0 to 2: say how you read "operator partnerships" and ask whether that matches the team's use. Give your lead thesis in one sentence. Minutes 2 to 10: the thesis, the one report-sourced point, the departure, the anti-pick. Minutes 10 to 13: the operator close, in three parts: what an operator gets, what you would ask of them, and how they can hold Kelverton to it. State each as what you would test unless you saw it first-hand. Minutes 13 to 15: your concession, what you would need to learn first, and an invitation to push.

## Persona table

The loop is one session described by the recruiter's own words: a 15-minute talk, then Q&A. That establishes the loop, so no archetype fallback is used. No source names a values round, so no values-style round is detected.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (Deepa) | Follow-ups on your POV: what first, what you would stop, how you would decide | High. A hiring manager buys capability, and the 15-minute POV hands her a live problem to probe. Highest weight, so bank A has 5 questions | Clarify before structuring, say the frame aloud, challenge one premise respectfully. No claim about your past needed (A1 to A5) |
| Skeptic (Deepa) | The gaps: no rail sales, no quota, payments to rail | High. Your own message states both gaps, and a future manager is derisking. Bank B has 4 | Rehearse the objection until boring (B1). Concede in your own stated words, then adjacent evidence at its scope, then a ramp plan |
| Data-Driven Prober (Ross) | The 6 to 40 and the £4M, taken apart | High. The recruiter says Ross will push on commercials, and your two figures are what a commercial director reads first. Bank C has 4 | Know what you can and cannot say about how each figure was counted, and say plainly where you do not know (C1, C2) |
| Pressure (Ross) | Interruptions, "how much was you", sixty-second challenges | Medium. A commercial director pushing on commercials often does it by challenge; the pack assumes this and cannot confirm it. Bank D has 3 | Pause, restate, hold the position the quotes carry through two follow-ups, concede specifically (D1 to D3) |
| Peer Evaluator (Ross) | The seam between partnerships and commercial on a live deal | Medium. Partnerships and commercial sit adjacent, and what you need from him is exactly what he will weigh. Bank E has 3 | Reciprocity framing and seam principles, not a pretended knowledge of where their seam is (E1 to E3) |
| Conversational (Deepa) | "Walk me through the journey", "what do you know about us" | Low to medium. A future manager often opens or closes warmly, and these are still scored. Bank F has 2 | A 90-second arc built only from your two background sentences (F1, F2) |
| Values/Behavioral | Scenario probes against published values | Low. No source in hand names a values round and no values page could be read, so there is no values bank. E3 covers one behavioral prompt | Ask the recruiter whether a values conversation is planned |

## Question banks

### Bank A: Case/Strategist (Deepa), weight highest

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Before you start, is there anything you want to clarify about what we mean by operator partnerships?" | CASE | [generic] | Take the offer and keep it to one or two points. Say how you are reading "operator partnerships" (who counts as the partner and what each side commits to) and ask whether that matches the team's use. Then state your lead thesis in one sentence before the detail. Think aloud and challenge at most one premise, respectfully. No claim about your past | The POV is the graded deliverable in F1, and Case/Strategist interviewers score clarifying and structuring first. CASE because the POV is a live problem set in the role |
| A2 | "If you could do only one thing in the first six months, what is it, and what would you decline to do?" | CASE | [generic] | Name one thesis from the build section and why it goes first. Name one thing you would decline across the 18 months and why. Say what evidence would change your mind. A ranked choice with an anti-pick is the departure from a consensus list, so do not rank by what sounds safest | A POV can dodge prioritising. F1 is the requirement; CASE because it is asked as a decision |
| A3 | "Staying with the operators: what changes for them under your plan, and what does it cost them?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer in three parts tied to your lead thesis: what operators gain, what you would ask of them, and how they can hold Kelverton to it. Treat each as something to test unless you saw it first-hand. If you draw on your consulting years, use them at their scope: "I know the operator world from the other side." Answer slot: expect a probe on what operators actually care about. If your planning work put you in front of operators, say which kind and what you saw, in your own words; if it did not, say so plainly and stay with the network planning | The recruiter asked you to land on the operators (F2), so this arrives in some form. JD because it scores that stated close, with CASE delivery |
| A4 | "How do you see us competing, and where do partnerships help or hurt that?" | CO | [generic] | The pack could not read the report or run research, so it supplies no competitor facts. Bring exactly one point from the strategy report, attributed to it, to show you read it. Then one point where your view departs, with reasons. Say plainly what you do not know about how Kelverton competes rather than filling it from memory | The differentiator question most candidates cannot touch. Labeled generic because research was refused and the report was not available to the pack |
| A5 | "An operator offers to co-develop a feature with us, but wants a discount and a year of exclusivity. Where do you start?" | CASE | [generic] | Clarify before structuring: what the operator would commit in return, what Kelverton would give up, who inside has to agree (including the commercial side), and what walking away costs. Then structure: objective, options, the price of each, what you would propose, what would make you walk. Say who you would bring in early and why. The scenario is hypothetical and makes no claim about Kelverton or your past | Previews the commercials push (F3) in case form, which Deepa can ask as easily as Ross. CASE because it is a live problem set in the role |

### Bank B: Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail, and you haven't carried a quota. Why should we trust you with our operator relationships and commercials?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **Highest-ROI prep in the pack.** Level 1: concede first, in your own words: "I haven't sold into rail specifically, and I've never carried a direct quota; what I had was influenced revenue." Then give only the adjacent evidence your sentences carry: the ISV channel from 6 partners to 40, and five years in transport consulting, in bus and light rail network planning. Level 2, if they press on bus and light rail not being train operators, or on influenced not being owned: hold by going back to your sentences, never by adding to them, and concede the exact limit. Answer slot: if any of the operators you worked with in consulting ran trains, say so; if none did, say so plainly and say what you would need to learn first. Level 3, if they ask about your ramp: say, as a plan and not a past, what you would learn first, from whom, and what you would not commit to until you had. Do not claim rail or quota experience you did not state | Named by the pack as the most predictable objection for you, since F4 and F5 are gaps you stated yourself. JD because it scores the role's stated close on operators and commercials (F2, F3); the Skeptic persona is the delivery |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Choose the one you would choose yourself and say it plainly, in your own stated words: "I haven't sold into rail specifically" or "I've never carried a direct quota; what I had was influenced revenue." Then how you would close it, as a plan, and who you would learn from. Do not volunteer a weakness your material does not show, and do not use humility to avoid choosing | Skeptic stem. F4 and F5 are the two gaps you stated; JD because it scores honest self-assessment against the role |
| B3 | "Why move from payments to rail, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer slot: give your actual reason for the move in your own words; the pack supplies none. If your consulting years are part of the reason, say how, using the sentence at its scope; if they are not, do not reach for them. Keep it to what draws you to this role and its operators, and say nothing against the payments company | The Skeptic's "why leave, why here, why now" tests motivation consistency (F1). EXP because it tests whether your story holds across the two parts of your background |
| B4 | "Your channel experience is in payments ISVs. What would you carry over to train operators, and what would you leave behind?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Concede the difference first: an ISV channel and operators are different settings, and you have said you haven't sold into rail. Answer slot: if some practice from the ISV channel would carry to operators, name it and say why you think so; if none would, say so plainly and say what you would learn first. Frame whatever carries over as a hypothesis to test, never as a playbook you will replicate | F1's transferability gap, asked head-on. JD because it scores whether you can do the listed job from adjacent work |

### Bank C: Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You took the ISV channel from 6 partners to 40. How was that counted?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | Four answer slots, each in your own words. What made a partner count among the 6 and among the 40. What that number is most sensitive to. The assumption behind it you would defend least. Which part of it was yours and which was other people's. Where you do not know how something was counted, say so plainly: that serves you better than a method you cannot repeat under a second question. The pack supplies no counting method, baseline or attribution | A headline figure is where a prober starts (F6). EXP because it tests whether the claim survives scrutiny |
| C2 | "You cite roughly £4M of influenced revenue. What counts as influenced, and which part would you defend least?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold at the word your sentence uses, "influenced"; do not let it become "closed" or "won" under pressure. The same four slots: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. Answer slot: if they ask how much you closed, say your actual involvement in your own words; if you closed none of it, say so plainly and return to "influenced revenue" | F3 and F6 both rest on this figure, and a commercial director reads influenced versus owned first |
| C3 | "You've never carried a quota. What would you want to be measured on here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Open with the plain acknowledgment: "I've never carried a direct quota." Then state the measures you would propose for the role, covering the operators' side and the commercial side, as your position and not your past. Decide before Tuesday whether you would accept a revenue number here and say your actual answer; offering only soft measures reads as avoiding it | F4 is a stated gap, and the recruiter flagged commercials (F3). JD because it scores how you would be held accountable in the role |
| C4 | "How would you decide whether a partnership with an operator is worth doing commercially?" | CASE | [generic] | Structure: what the operator brings, what it costs Kelverton, what it does to everything else Kelverton sells, how you would measure it, when you would walk away. Name what you would need from the commercial side to decide. State your confidence and what you do not know. No claim about your past | F3 in case form. CASE because it is a live problem; JD content from the recruiter's note on commercials |

### Bank D: Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How much of that £4M was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold, then concede. Hold at what the sentence says, "roughly £4M of influenced revenue", through two follow-ups, without restating it as yours. Concede specifically what you cannot attribute. Answer slot: say which part was yours, in your own words; if you cannot say how much, say so plainly. The pack supplies no share | Pressure stem on the headline figure (F3, F6). EXP because it tests attribution honesty |
| D2 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause and restate the question. Concede in your stated words: "I haven't sold into rail specifically." Hold on what your sentences carry: the ISV channel from 6 partners to 40, and five years in transport consulting, in bus and light rail network planning. Do not claim you would outperform a rail seller. Say what you would offer and what you would need to learn first. Finish inside sixty seconds | F5 is a stated gap, and this is B1 under time pressure. JD because it scores the stated fit |
| D3 | "I don't buy it. Operators don't care about partnerships, they care about price. Convince me." | CASE | [generic] | Pause and restate the objection in neutral words without adopting it as fact. Do not fold. Concede the part that is true, that price matters, then say what a partnership would have to deliver to matter anyway. Treat your operator view as hypotheses and say what you would want to find out; ask Ross what he sees. No claim about your past | A devil's-advocate challenge on the F2 close. CASE because it is a live challenge to a premise |

### Bank E: Peer Evaluator (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and commercial sit side by side. Where's the seam on a live deal, and what happens when we disagree?" | CASE | [generic] | Propose seam principles instead of pretending to know where the seam is today, and say you would ask. Lead with what you would bring his team, as a plan: opportunities checked with the operator before they reach him. Say how you would disagree: say your position, say what would change it, and agree who decides before the deal, not during it. No claim about your past | Peer stem; F3 is where the seam bites. CASE because it is a live collaboration problem |
| E2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Your sentence says "influenced", not owned; use the word as written. Answer slot: if there was a case in the ISV channel where credit was shared with sales or others, say what it was and how you handled it, in your own words; if there was none, say so plainly and describe how you would handle it here | Peer stem on credit. EXP because "influenced revenue" invites it (F3) |
| E3 | "Tell me about a time you disagreed with someone on the commercial side over a partner decision." | VAL | [generic] | Pick one time where your position differed from a commercial counterpart's: it needs your actual position, what you conceded, and how it actually ended, including if it ended badly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. No claim is made for you here | An open prompt on the commercials theme the recruiter raised. VAL because it scores behavior with a peer; generic because no company values were readable |

### Bank F: Conversational (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through your career so far." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc made only of those two sentences: the transport consulting years, the partnership years, the last four running the ISV channel. Answer slot: say the order and dates as they actually were, since your message does not show whether the consulting years come before or overlap the nine; and say how and why you moved from one to the other, in your own words. If the move was not planned, say so | A casual opener that is scored (F1). EXP because it tests whether the CV story is coherent |
| F2 | "What do you know about what we do, and what are you curious about?" | CO | [grounded] | Say what you know in your own terms. The pack holds only your description of Kelverton: it sells scheduling software to train operating companies. Add one point you took from the report, attributed to it, and one question the report did not answer for you. Do not pad with general statements about rail | A warm CO probe that is still scored. Grounded on your message; anything more would be from the report, which the pack has not seen |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1: POV on operator partnerships over 18 months | A1, A2, A4, B3, B4, and the build section |
| F2: land on what it means for operators | A3, D3, and the build section's operator close |
| F3: commercials | A5, C2, C3, C4, E1 |
| F4: revenue number | B1, B2, C3, D1 |
| F5: rail experience | B1, B2, D2, F2 |
| F6: build and scale a partner programme | B4, C1, C2, E2 |

## Reverse questions

No interviewer profile was available, so these are role-generic. At least one reciprocity question is included because Ross sits beside the role.

| # | Question | Why it lands |
|---|---|---|
| R1 | To both: "In 18 months, what would make you say partnerships had worked, in the operators' words and in commercial terms?" | Gets the success measure out in the open, which tells you whether a number is coming (F4) and shows you think in both of the panel's terms |
| R2 | To Ross: "Where do partnerships and commercial overlap on a live deal today, and where has that rubbed?" | Shows you are looking for the seam rather than assuming it, which is what the Peer Evaluator scores (E1) |
| R3 | To Ross: "What could someone in this role do in their first month that would genuinely help your team?" | The reciprocity question: it asks what you can give his side, not only what you need |
| R4 | To Deepa: "Your strategy team's report from last quarter: which of its conclusions has already changed what partnerships does, and where is it still being argued?" | Shows you read it as an argument and not as a list, and tells you where your POV can add something. Ask it only if you have read the report as you said |
| R5 | To Deepa: "What would you want me to have learned about rail operators by day 90, and from whom?" | Turns your stated rail gap (F5) into a ramp plan the manager owns a piece of |
| R6 | To both: "What did I not ask that you expected me to?" | Surfaces an unspoken concern while you can still answer it, and keeps the closing slot from being generic |

## Prohibited claims

What this pack will not coach, and the basis. Each entry's honest form is below.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F5 | "I haven't sold into rail specifically." Then a plan to learn it, never a past. No slot |
| Has carried a quota or revenue number | Negative you stated, F4 | "I've never carried a direct quota. What I had was influenced revenue." No slot |
| Closed, owned or was accountable for £4M | Inflated form of F3 and F6 | The quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: your material says influenced, not closed. C2 and D1 slots stay inside that sentence |
| Has worked with train operating companies, or knows their buying | Inflated form of F2 | The quote at its own scope: bus and light rail network planning, "the operator world from the other side". The limit is the pack's observation: your material says bus and light rail, not train operating companies. A3 and B1's slots ask only what you actually saw |

## Sources

**Provided:** your message, which holds your background and the recruiter's email quoted word for word. The market report you mentioned was not available to the pack and was not read.

**Searches sent, all refused (permission was not granted), and no fetches sent:**

1. "Kelverton Rail company values" — refused
2. "Kelverton Rail interview process partnerships" — refused
3. "Kelverton Rail strategy scheduling software train operating companies news" — refused
4. "Deepa VP Partnerships Kelverton Rail" — refused
5. "Ross Commercial Director Kelverton Rail" — refused
6. "Senior Partnerships Manager job description rail technology software train operators UK" — refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Every call refused. It would have fed a values cheat sheet and VAL questions on named values; neither is in this pack |
| 2. Kelverton Rail interview process, partnerships | unavailable | Every call refused. It would have confirmed the loop beyond the recruiter's email; the persona weights rest on that email only |
| 3. Kelverton Rail strategy and recent news | unavailable | Every call refused. It would have grounded the CO bank (A4, F2); those rows are generic or limited to your description |
| 4. Deepa and Ross at Kelverton Rail | unavailable | Both calls refused. It would have supplied an interviewer read and a reverse question tied to each person's path; neither is in this pack |
| 5. Representative Senior Partnerships Manager JD | unavailable | The call was refused. It would have turned the role-family rows F4 to F6 into quoted requirements; they are plain prose here |

## Upgrade menu

- The job description text → F4 to F6 become quoted requirements with their sources, and any JD-only requirement gets a row and a question
- The market report, pasted or its key pages → the thesis differentiation becomes concrete (you would see the exact shortlist to depart from), A4 and F2 move from generic to grounded, and a grounding brief could be added
- Permission to run web searches → target 1 to 5 re-run: Kelverton's published values, any documented loop, current strategy and news, and what Deepa and Ross have said publicly
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, which also needs the search permission above → a strategy brief, the interviewers' talks and writing, and recent organisation context
- The channel scorecard or partner-sourced pipeline report behind the 6 to 40 and the £4M → F3 and F6 confidence moves from medium toward high, and C1 and C2 get your exact definition of "influenced"
- Your CV text → evidence cells quote CV lines as well as your message, and F1 to F3 may tighten
- Deepa's and Ross's full names → an interviewer read and a reverse question tied to each person's path
- One email to the recruiter asking what "operator partnerships" covers and which commercial topics Ross intends to push on → the POV build and bank C can be aimed rather than assumed
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and absolute prohibited claims would replace the ones this pack built locally
