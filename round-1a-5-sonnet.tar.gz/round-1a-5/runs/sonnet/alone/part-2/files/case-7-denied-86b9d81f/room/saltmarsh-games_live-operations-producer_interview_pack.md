# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager (the role is in his area; you did not say whether you would report to him).
**Session:** one 60-minute interview, Friday.
**Built from:** the JD and background you pasted. No outside research ran (see Sources), so nothing here claims to know Saltmarsh's values, loop or strategy.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Every question carries one persona (its bank letter) and one type.

| Type | What it scores |
|---|---|
| VAL | Past behavior against the company's published values |
| EXP | Whether your own experience survives scrutiny, and what was actually you |
| JD | Whether you can do the job as listed, including its gaps |
| CO | What you know about the company and its games |
| CASE | A live problem from the role, reasoned out loud |

Guidance is scaffolding, not a script: say it in your own words. Answer slots are instructions for the interview. Answer them from your real experience, and either branch is a good answer. Bank letters skip F so question IDs cannot be confused with fit-snapshot rows (F1 to F9).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title, with nothing inspected behind it, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD says live events and two titles, so expect a probe on both. If any of what you scheduled was a time-limited event rather than a drop, say what it was and what part of it was yours; if there was none, say so plainly and stay with the weekly calendar. If you worked on a second title, say what you did on it; if not, say so plainly |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show work with any of the four named teams. Note the JD says coordinate, not lead. Answer slot: if any of those teams took part in the drops you scheduled, say which and what you did with them, in your own words; if none did, or if QA was the only team you worked with, say so plainly and stay with the calendar and the checklist |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you ran a review or chose the KPIs, and the words stay there: "Every month I presented the retention numbers to the studio head." Answer slot: the JD ties the review to events. If you ever reviewed a content drop afterward, say how it was done and what part was yours; if no such review existed, or it was not yours, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it, nothing inspected behind it. Words: "I wrote the release checklist our QA team still uses." Answer slot: the JD says manage. If you also ran the checklist through releases with QA, say how that worked, in your own words; if you only wrote it, or someone else ran it, say so plainly and stay with writing it. This is your most concrete row, so expect the most follow-ups here |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years are stated; your material does not say whether the main title was a live service, or for how many of the four years. This is a length requirement, not a gate. Words: "I was an associate producer at a puzzle-game studio for four years." Answer slot: if the title ran on ongoing updates, say for how long, in your own words; if you are unsure, or it did not, say so plainly and give the four years and the two years of the weekly calendar as you stated them |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | Your strongest match: the quote already names the calendar. Lead with it in its own terms, weekly and the main title and two years, because a named record beats an adjective. Expect a probe on how the calendar worked day to day |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote names retention numbers and a monthly cadence. It does not say how retention was defined or who produced the numbers, so expect a probe on method, not comfort. Lead with the quote at its own scope; the slots are in C1 |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The checklist is the only written work your material names, and a checklist touches the requirement without showing it. Answer slot: if you wrote anything else others relied on, such as an update or a review, name the kind of document; if the checklist is the main example, say so plainly and stay with it |
| F9 | "Never led a team, and never worked on a game with in-app purchases." — your message (limits you flagged; the JD names neither) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never led a team, and I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to leading or to in-app-purchase work, and nothing added to make the gap feel smaller |

## Persona table

Weights: relationship prior for a hiring manager (Case/Strategist plus Skeptic), no interviewer signals (no profile was available), and one session whose structure rests on your own account. Recalibrate if you know more.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A, 5 questions) | A live problem on the calendar, a release, or a retention dip | High. The prior puts it first, and the JD's duties (calendar, update coordination, post-event review, release checklist) can each be run as a live problem | Clarify, then objective, segmentation, approach, metrics, risks, aloud; challenge one premise respectfully per case |
| Skeptic (bank B, 5 questions) | Quiet, persistent probing of what the material does not show | High. The prior puts it second, F2 has no evidence behind it, and F9 holds two limits you flagged yourself | Rehearse B1 until it is boring: limit first, then your quotes at their own scope, then a plan |
| Data-Driven Prober (bank C, 3) | Asks how the retention numbers were counted | Medium. The JD names retention metrics and F7 is the line a prober would open | Say plainly what you can and cannot say about how the numbers were counted; the slots are in C1 |
| Conversational (bank D, 3) | Friendly opener, then casual questions that are still scored | Medium. The prior ranks it below the top two, and the opening biography is cheap to prepare | A 90-second arc built from your own sentences (D1) |
| Pressure (bank E, 2) | Time-boxed challenge to "how much was you" or "why you" | Low. The prior does not weight it; E1 and E2 exist because F4 and F9 invite exactly those challenges | Pause, restate, hold the quote through two follow-ups, concede only what is true |
| Peer Evaluator (bank G, 2) | Seam-splitting between teams | Low. Tobias is the Head, not a peer, on your account; two questions because F2's coordination duty can arrive in collegial form | Offer seam principles, not claimed knowledge of the seam |
| Values/Behavioral (no bank) | Stories mapped to published values | Low. No source names a values round, and no published values were obtained, so a values bank would be invented | If a values round appears, answer from the open-prompt scaffolds in B3 and C2 |

## Question banks

### Bank A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A big event on one of your two titles lands in the same week as a major update on the other, and the same art and engineering people are needed for both. Walk me through how you'd sort it out." | CASE | [generic] | Structure it aloud. First ask: what is fixed and what can move, what each team's capacity is, what is at stake for each title. Then name the decision rule you would use, who you would bring in to decide, and what you would write down afterward so the same clash is caught earlier next time. The question needs no claim about your past, so the guidance makes none | A live version of the JD's two-title calendar line (F1), asked as a decision rather than a record. [generic] because it is a pattern for the problem, not a fact about this employer |
| A2 | "An event just ended. Walk me through the post-event review you'd run and which KPIs you'd report." | CASE | [generic] | Say the structure first: what the event was meant to do, what you would compare it against, what you would report and to whom. Choose the KPIs yourself, in your own words, and for each say what the number cannot tell you. Say plainly what you would confirm about how the studio defines and counts them before trusting any figure. No claim about past reviews | F3 is the row this question presses on; it is asked as a live problem so the answer does not depend on past reviews you may not have run |
| A3 | "A retention figure drops 20% the week after an update. Diagnose it." | CASE | [generic] | Clarify before diagnosing: how the figure is defined, which players and platforms, when the drop began relative to the update and to anything else that changed, and whether it is real or a data problem. Then group the possible causes, say how you would test each, and name which team you would pull in for each. Say which assumption you would defend least | Combines the JD's retention line (F7) with its coordination line (F2) in one problem. Strategists score clarifying and structure before the answer |
| A4 | "It's Wednesday. The update ships Thursday, QA has flagged a blocking bug, engineering says a fix is possible by Thursday, and design wants to ship anyway. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Clarify first: how severe the bug is and for whom, what the fix risks, who holds the ship decision. Then lay out the options and what each costs, what you would say to each team and when, and what you would record. The only claim about your past is the quote: you wrote the checklist and QA still uses it. Answer slot: if the checklist covers a call like this, say what it says; if it does not, or you do not recall, say so plainly and answer from how you would decide | F4 is where the JD's QA line is strongest; a release-day conflict is the natural live test of it |
| A5 | "What would you want to learn in your first two weeks, before you touched either calendar?" | JD | [generic] | A plan, not a claim: what you would ask each of the four teams, which past events and reviews you would read, how the release checklist runs between production and QA today, which KPIs are reported now, and, if the titles use in-app purchases, what role they play in event planning. Order it by what would change your first decision | Turns F2 and F9 into a forward plan the Skeptic bank will otherwise force; the in-app-purchase item is conditional because the JD does not mention it |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see design, art, engineering or community in your background. How would you coordinate them on an update?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | The highest-ROI rehearsal in this pack. Say the limit first, before it is asked for: "I've never led a team." Then what your quotes carry and no more: you ran the weekly content-drop calendar for your main title, and you wrote the checklist QA still uses. Answer slot: if any of the four teams took part in the drops you scheduled, say which and what you did with them; if none did, say so plainly and stay with the calendar and the checklist. Then a plan, said as a plan: what you would put in front of each team, and when. Rehearse three follow-ups: how much of the calendar was actually you; when you got a team to move that did not report to you (if no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it); what you would do in your first month | F2 is the JD's core duty with no evidence behind it, and F9 is the limit you flagged. This is the objection most likely to arrive in some form, so a rehearsed, non-defensive answer changes the interview. JD because it scores a stated duty |
| B2 | "You've said you've never worked on a game with in-app purchases. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Acknowledge it plainly and briefly: "I've never worked on a game with in-app purchases." Do not defend or minimise it. Then give a plan in your own words: what you would read, whom you would ask and what you would shadow in your first weeks. Do not argue that your retention or calendar work covers it; your material does not say so. Ask them how it fits into event planning here, which is also reverse question 5 | F9 holds the limit and it came from you. The JD does not mention in-app purchases, so do not assume they are central; the reverse question finds out |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Pick one JD line yourself and name it plainly with its limit. Your material points to two: the post-event review and KPIs (F3), where your quote says presented, and the four-team coordination (F2). Say the limit, then what you would do in your first weeks. Selection scaffold: pick a line where you can state the limit in one sentence and the plan in two; if no single line stands out, say so plainly and name the one where your material is thinnest | F3 and F2 are the two JD rows where the material is thinnest. A stated weakness with a plan scores better than a polished non-answer |
| B4 | "You ran the weekly content-drop calendar for your main title. This role covers two titles and a live-events calendar. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if any of what you scheduled was a time-limited event rather than a drop, say what; if none was, say so plainly. Answer slot: if you worked on a second title, say what you did on it; if not, say so plainly. Then your plan for two titles: what you would want to see first, as in A1 | F1 is the likeliest place for the JD's wording (events, two titles) to be pressed against your one calendar |
| B5 | "You've been an associate producer. This is a producer role. Why now, and why us?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Give your actual reasons in your own words; the pack does not know them and will not supply them. Shape: what you have done (four years as an associate producer at a puzzle-game studio), what you want the next role to hold, and one reason this team in particular, which you can only name after you know what they work on. Do not run down your current studio | F5 carries the years; the question is the standard why-leave, why-here, why-now probe, tagged EXP because it tests your own story |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented to the studio head were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Open with the quote: every month you presented them. Then four slots, each in your own words. How they were counted: say what you know; if you do not know, say so plainly. What the figures are sensitive to. The assumption behind them you would defend least. Which part was yours: if you also produced the numbers, say so; if you took them from an analyst and presented them, say that plainly | F7 is where a prober starts. No figure was given, so the probe is on method and attribution, and nothing here supplies a method |
| C2 | "When have retention numbers changed what you did with the calendar?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | Open prompt: pick one real time, name the number, what you saw, what you did, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you ran the weekly calendar and presented the monthly numbers, and say how the two were connected, if they were | F7 and F1 meet here; the question tests whether retention knowledge ever reached the calendar. The honest branch is built in |
| C3 | "What would you expect in a post-event review, and which retention measure would you trust least?" | JD | [generic] | Name the measures you would look at, in your own words. For each, say what it cannot tell you, then say which you would trust least and why. Say plainly what you would check about how the studio defines it. No claim about past work | The weakest-assumption move applied to a hypothetical. F3 and F7 together; asked as a judgement call because you gave no figures to defend |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get here, and where do you want to go?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with three beats, each from your own sentences. Beat one: four years as an associate producer at a puzzle-game studio. Beat two: the weekly content-drop calendar for the main title, the release checklist QA still uses, the monthly retention numbers you presented. Beat three, in your own words: why this role. Stop there; do not add outcomes you have not told me | The opener is cheap to prepare and sets what the interviewer probes next. F1, F4, F5 and F7 are the sentences it draws on |
| D2 | "What live events have you enjoyed in games lately, and have you played either of our titles?" | CO | [generic] | Choose a game you actually play and say what an event in it did well or badly, in your own words. If you have played either Saltmarsh title, say what you noticed; if you have not, say so plainly. Before Friday, try to download both | The casual question is still scored. [generic] because no research on the studio's titles was possible, so the pack cannot name them |
| D3 | "What does a good written update to the whole studio look like?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Describe the update you would write, in your own words: who it is for, what must be in the first line, what can wait. Then the one piece of written work you named: you wrote the release checklist QA still uses. Answer slot: if you wrote other updates or reviews others relied on, name the kind; if the checklist is the main example, say so plainly | F8 is the only row with no direct evidence; this question closes that coverage gap and lets the checklist carry it honestly |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Pause, restate the question, then hold the quote: "I wrote the release checklist our QA team still uses." Hold it through two follow-ups. Answer slot: if QA or anyone else changed or approved it, say what, in your own words; if not, say so plainly. Concede only what is true and specific, such as what you cannot speak to, and never fold on the core claim just to restore harmony | F4 is your most concrete row and so the one an interviewer tests for attribution |
| E2 | "Sixty seconds: why you over a candidate who has run live events on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Pause, restate, then in order: the limit first ("I've never worked on a game with in-app purchases"), then what you have done, using the three quotes at their own scope, then how you would ramp. Do not claim to be the stronger candidate. Hold through two follow-ups; concede the limit again if pressed rather than defending around it | F9 invites this challenge and the Pressure persona scores composure, not the content |

### Bank G: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Engineering and design both want the next slot on the calendar. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Offer seam principles instead of claiming to know the seam: what you would ask each side, what you would put in writing, who would decide and by what rule. Show spine and tact together. No claim about your past | F2's coordination duty in a collegial form |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Say how you would handle it, in your own words, and only give a real example if you have one. If no such time comes to mind, say so plainly and say how you would handle it | A cheap collegial probe on the same coordination duty (F2); no past is presupposed |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, B4, G1 |
| "coordinate design, art, engineering and community teams on each update" | A5, B1, G1, G2 |
| "own the post-event review and the KPIs it reports" | A2, A3, B3, C3 |
| "manage the release checklist with QA" | A4, E1 |
| "3+ years producing live-service games or apps" | B5, D1 |
| "experience running a content calendar" | B4, C2, D1 |
| "comfortable with player-retention metrics" | A3, C1, C2, C3 |
| "clear written communication" | D3 |
| Limits you flagged (F9) | B1, B2, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a strong first ninety days look like for whoever takes these calendars?" | Shows you are planning a ramp, and the answer tells you what the role is really measured on |
| 2 | "How do the two titles differ in how their event calendars run today, and which would I start on?" | Shows you are thinking about two titles, the part of the JD furthest from your experience, and tells you what to learn first |
| 3 | "Which KPIs does the post-event review report today, and who decides what good looks like?" | Ties to the JD's review-and-KPI line and shows you want to know the definitions before you own the numbers |
| 4 | "How does the release checklist run today between production and QA, and where does it hurt?" | Plays to the checklist you wrote and invites the interviewer to describe a real problem you could help with |
| 5 | "How do in-app purchases, if any, fit into event planning on these titles?" | Raises your stated limit on your terms, as a learning question rather than a confession, and finds out whether it matters here |
| 6 | "Which of the four teams does the producer spend the most time with during an update?" | Shows you are mapping the coordination duty and tells you where the day-to-day weight sits |
| 7 | "How does the team share what it learns after an event so the next one is better?" | Signals care for the review as a loop, not a report, and tells you how seriously the review is taken |

No reverse question is tied to Tobias's own path: no interviewer profile was available (see upgrade menu).

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or led design, art, engineering or community on an update | Negative you stated, F9 | The plain acknowledgment F9 gives: "I've never led a team." No slot; B1 asks only what your work with those teams was |
| Worked on live events or any game with in-app purchases | Negative you stated, F9 | "I've never worked on a game with in-app purchases." Then a plan said as a plan, never a past |
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope: a weekly content-drop calendar for the main title. The limit is the pack's observation, not words for you: the material says drops and one title |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers. B3 and A2 stay inside that scope |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist QA still uses. E1's slot asks only what was changed or approved |
| Produced or analysed the retention numbers | Inflated form of F7 | F7's quote at its own scope: you presented them. C1's slot lets you say either way |
| Has 3+ years producing a live-service game | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer, two years of the weekly calendar. B5 and D1 stay there |

## Sources

Provided documents: the JD text you pasted; your background message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, all refused (this session did not grant search permission):

- "Saltmarsh Games company values" — refused
- "Saltmarsh Games interview process Live Operations Producer" — refused
- "Saltmarsh Games mobile studio strategy news 2026" — refused
- "Tobias Wrenfield Saltmarsh Games" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The search was refused. It would have fed a values cheat sheet, which is dropped; no values round is established either |
| 2. `Saltmarsh Games interview process Live Operations Producer` | unavailable | The search was refused. It would have named the real rounds. Your own account fixes one 60-minute session run by Tobias, so weights rest on the hiring-manager prior and no archetype fallback applies |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | The search was refused. It would have fed the company-knowledge questions and a grounding brief, both dropped; D2 is [generic] |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The search was refused. The interviewer read is absent and reverse questions are role-generic |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search, or a pasted values page, strategy brief or interviewing page → a values cheat sheet if a values round exists, a grounding brief, and company-knowledge questions that name the real titles
- Deep research (up to 6 more searches and 2 more fetches, several more minutes), offered once, needs search permission first → strategy cases and a sharper "why us"
- Tobias Wrenfield's LinkedIn page, talks or writing, pasted or linked → an interviewer read, persona weights adjusted from his public footprint, and a reverse question tied to his own path
- The recruiter's prep email → stated focus areas, any pre-declared deliverable, and the loop structure; usually one email
- The names of the two titles → company-knowledge questions that name them
- Your answers to the answer slots in F1, F2, F3, F4, F5, F7 and F8 → those rows move from slots to quoted evidence and the banks that draw on them regenerate
- The inspectable artifacts for your field: a redacted copy of the weekly content-drop calendar, the release checklist, a monthly retention deck → F1, F4 and F7 from medium toward high
- A CV → more rows can quote it, and any story your CV carries but your message did not
- Hours available before Friday → a prioritized prep schedule
- A `tuesday-dossier.md` from a prior session → verified evidence and constraints the pack could use in place of my inferences
