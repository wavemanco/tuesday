# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy. He is Priya's peer: both would report to the same VP.
- **Round:** one 60-minute conversation, in your words. Persona weights are built for a peer round on that basis.
- **Built from:** your message only (JD highlights, Priya's summary, your description of Dan's profile, your research note). Web research was refused, so nothing here comes from outside your material. See Sources.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

An **answer slot** is an instruction for the interview, not a question for you. Where the pack cannot know something, the slot gives two honest branches. If you did the thing, say how. If you did not, or it was not yours, say so plainly and stay with what your material does carry.

**Highest-ROI prep: B2.** It is the question most likely to be asked, and it aims at the one gap Priya stated herself. Rehearse it until it is boring, then rehearse C1 and F1, which come at the same objection in other packaging.

| Type | What is being scored |
|---|---|
| VAL | Whether past behavior demonstrates the company's published values. No published values are in hand, so no row carries this tag. |
| EXP | Whether the CV's claims survive scrutiny, and what was actually the candidate's. |
| JD | Whether the candidate can do the listed job, gaps included. |
| CO | Company and strategy knowledge, and the altitude of the thinking. |
| CASE | Structure and reasoning on a live problem from the actual role. |

## 2. Fit snapshot

Requirements are quoted from the JD highlights in your message. Evidence is quoted from your notes on Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights in your message | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy & ops, not go-to-market for product lines, with nothing inspected behind it. The words stay at that scope: "I spent nine years in product strategy and operations at a large consumer-tech company." Answer slot: the JD's ownership line makes a probe on what reached customers or revenue directly likely. If any of the work in that role did, say what and which part was yours; if none did, say so plainly and stay with product strategy & ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights in your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | The quote shows a proposal and a credited uplift. It does not show a customer-lifecycle stage. Words at the quote's scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: if the change touched how existing customers adopted or expanded, say how and which part was yours; if it did not, say so plainly and stay with the proposal. The figure itself raises only the defend-the-number slots in A1 and A2 |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights in your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The quote already names both tools. It is a stated skill with no analysis behind it, so expect a probe. Lead in the quote's terms: skilled in SQL and Tableau. A3 holds the walk-through scaffold |
| F4 | "partner-motion design experience required" — JD highlights in your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The quote shows a revenue model used in negotiations with carriers. It does not show a motion. Words at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if you shaped anything about the carrier partnership beyond the model, say what and how you decided; if the model was your contribution, say so plainly and stay with it |
| F5 | "strong cross-functional influence" — JD highlights in your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Lead with the consensus: the annual volume targets were set with cross-org consensus. Add no event or number to it |
| F6 | "AI experience a plus" — JD highlights in your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | The quote names daily use of AI tools. It does not say building them. Lead in the quote's terms and let the interviewer ask for more |
| F7 | Sales-ops and quota-setting fluency. This is not a JD line. It is likely to be probed because the interviewer is a Director of Sales Strategy per your description | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [inferred] | capability | A gap wording cannot close, and Priya has said so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to that work, and nothing added to make the gap feel smaller. The pack does not treat F5's volume targets as quota-setting, and neither should the answer |

## 3. Reading the interviewer

Public search was refused, so this read uses only your description of Dan's profile.

| Signal (your description) | What it implies | Used in |
|---|---|---|
| "relentlessly data-driven" (his self-description) | Every number Priya states gets taken down to its inputs. | A1, A2, A3, A4 |
| career spine is "pricing and monetization roles" | His native vocabulary is pricing, packaging and unit economics. Cases tilt that way. | D1, D2 |
| "one early-stage-startup chapter" | Builder stories may land. Expect a probe on how Priya works where there is no playbook, since her material is from a large company. | C3, R1 |
| Director of Sales Strategy, same VP as the hire | He is judging what the hire adds to or takes from his team's load. | B1 to B5 |

**Mirror opportunity (shared vocabulary, not a shared jump).** Dan's monetization spine and F4's "built a partner-level revenue model used in carrier negotiations" share the language of revenue economics. The quote does not say pricing, and nothing in the pack coaches Priya to claim it. No shared career jump can be established from the material.

## 4. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Takes the headline number apart to its inputs. Asks for a start-to-finish analysis. | **High.** Peer prior (Prober and Peer lead), raised by "relentlessly data-driven". Priya's one headline figure is F2's. | Say what you can and cannot say about how F2's figure was counted, and say plainly where you do not know. Name the weakest assumption before he does (A2). Offer to walk one analysis end to end only if one comes to mind (A3) |
| B. Peer Evaluator | Seam-splitting, "what would you need from me", credit, disagreement. | **High.** Peer prior. He is pricing what a hire costs and contributes to his work. B2 is the highest-ROI row in the pack. | Reciprocity: what Priya brings his team as well as what she needs. Offer seam principles, not a claim to know the seam. Hold B2 with the stated limit first |
| C. Skeptic | Quiet probing of the gaps: F7, F4, F1 and why leave. | **Medium.** He is a peer, not the hiring manager, but F7 sits in his own domain. | Rehearse the F7 objection until it is dull (B2 and C1). Bridge only from the quotes. Add a ramp plan, said as a plan |
| D. Case / Strategist | A live GTM problem, tilted to pricing, packaging and bundling. | **Medium.** The JD asks for GTM ownership, and his spine tilts cases toward pricing. Against that, peers test less with cases than managers do. | Clarify, objective, segmentation, options, metrics, risks. Challenge one premise politely. Name your weakest assumption |
| E. Conversational / Rapport | "Walk me through the journey." Casual AI questions. | **Low.** A 60-minute conversation will likely open with biography. The JD flags AI as a plus, so the casual question is still scored. | A prepared 90-second arc from the quotes (E1). A real answer on AI (E2) |
| F. Pressure | "Why you over someone from sales ops?" "How much of that was you?" | **Low.** Nothing in the profile suggests a stress style, but attribution probes can arrive as collegial pressure. | Hold the quoted position through two follow-ups. Concede specifically. Never fold on the core claim |

## 5. Question banks

### A. Data-Driven Prober (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Tell it at the quote's scope: you proposed the change, and the uplift was credited to it. Answer slot: say how the figure was counted, what it is most sensitive to, and which part was yours, each in your own words. If you do not know how it was counted, say so plainly rather than reconstructing a method. Do not say drove or delivered | F2 holds the only headline number in the material, and the Prober persona takes numbers to their inputs. EXP because it scores what the candidate can stand behind |
| A2 | "Which assumption behind that ~$400M would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name the assumption you would defend least before he does, because it turns a gotcha into a credibility gain. Answer slot: if you know the assumptions behind the figure, pick the weakest and say what changes if it is wrong; if you do not know them, say so plainly and say what you would want to check first | The Prober's signature follow-up to A1. EXP because it tests whether the candidate knows the limits of F2's own figure |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | The quote carries a skill, not an analysis, so this is a selection scaffold. Pick one analysis where you wrote the query or built the view yourself, can name the question it answered and the decision it fed, and can say what was yours versus handed to you. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries: that you are skilled in SQL and Tableau | The JD's independent-analysis line (F3) is a stated requirement, and a data-driven interviewer is likely to test it with a walk-through. JD because it scores the listed requirement |
| A4 | "Walk me through the partner-level revenue model you built for the carrier negotiations, and where it was weakest." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: you built it, it was partner-level, it was used in the negotiations. Answer slot: say what the model took in and which assumption you would defend least, in your own words. If you saw or took part in how it was used in the negotiations, say how; if you did not, say so plainly and stay with the model | F4's evidence is the closest to the JD's partner requirement and the easiest to probe for depth. EXP because the weakness question tests attribution and honesty |
| A5 | "If I gave you a table of accounts by stage, land, adopt, expand and renew, what is the first cut you would run to find whitespace?" | CASE | [grounded] | A live problem, so the guidance makes no claim about your past. Clarify first: what is an account, what counts as adopted, which product. Then state the objective, the cut you would run, what you would distrust in the data, and what decision it would feed. Say it as method aloud, in SQL-shaped terms | The JD's whitespace line (F2) is a stated requirement, and a Prober tests it as a data problem. CASE because it is a live problem; JD would also fit |

### B. Peer Evaluator (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [grounded] | The question needs no claim about your past, so the guidance makes none. Offer seam principles rather than pretending to know the seam: who owns the number, who owns the call, and how a disagreement gets escalated. Say you would ask him how it works today before proposing anything | F5's requirement is cross-functional influence, and a peer tests it with a seam question. JD because it scores the listed requirement |
| B2 | "I don't see sales-ops or quota-setting in your background. How would you work with my team without it?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" | **Highest-ROI prep.** Hold and concede in order. Say the limit first, in the stated words: "I don't have classic sales-ops or quota-setting experience." Then what your material does carry, kept separate from it: "I set annual volume targets with cross-org consensus." Then a plan, said as a plan: how you would learn how targets work in his team, starting with asking him. Follow-up 1, if asked how targets differ from quotas: answer from your own work if you know, or say plainly that you do not. Follow-up 2, if pressed on why he should not be worried: return to the quotes and add nothing. Concession, said exactly: "I won't know your mechanics on day one, and I'd come to you first." Never describe the targets as quotas | F7 is the stated negative, and this is the seat that owns that domain. JD because it scores fit for the role; the Skeptic version is C1. Deepest follow-up chain in the pack, because the likeliest objection is aimed at the one gap Priya stated |
| B3 | "How do you handle credit when work spans teams?" | EXP | [generic] | A selection scaffold. Pick a time work spanned two teams where you can name what each side owned and how credit was said aloud. Say what you did, and use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then say how you would handle it | A persona stem from the Peer Evaluator. A peer is pricing whether the hire shares or grabs credit. EXP because it asks for a real instance and scores attribution honesty |
| B4 | "What would you need from my team in your first ninety days, and what could you take off our plate?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity framing. Needs: how the numbers are defined today and who to ask. Offer: you are skilled in SQL and Tableau. Answer slot: if there is a specific piece of analysis you would offer his team, name it in your own words; if there is none yet, say you would learn first what is useful. Keep the offer to the quote | Peers weigh what a hire adds, not only what they need. F3 and F5 both feed this answer. JD because it scores cross-functional fit |
| B5 | "Tell me about a time you disagreed with another team's number and how it got resolved." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote states: the targets were annual, volume-based, and set with consensus across orgs. Answer slot: the question raises disagreement. If orgs disagreed before the consensus, say what and what you did; if consensus came without a disagreement, say so plainly and stay with the targets. If neither fits, say so and give the nearest instance you actually have, or how you would handle it | F5's consensus line is the nearest evidence for influence. EXP because the disagreement beat is where a probe lands |

### C. Skeptic (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "built a partner-level revenue model used in carrier negotiations" | Choose the weakness that is true, in your own judgment, and name it first. Your material supports two candidates: the stated absence, "I don't have classic sales-ops or quota-setting experience", and the distance between the carrier model and a partner motion, "I built a partner-level revenue model used in carrier negotiations." Follow with a ramp plan said as a plan: who you would ask, what you would read, what you would not decide alone | The Skeptic version of B2, in a form candidates often answer with a non-answer. JD because it scores the listed role; the rehearsal is calibrated candor |
| C2 | "Partner-motion design is listed as required. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you shaped anything about the carrier partnership beyond the model, say what and how you decided; if the model was your contribution, say so plainly and stay with it. Hold through two follow-ups by returning to the quote, never by adding to it | F4 is the JD's required line and the quote is adjacent to it. The hold is the part a second follow-up breaks, so the limit is named before it is asked for |
| C3 | "You have spent nine years inside a large consumer-tech company, mostly strategy and ops. Why leave, why here, and why now?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | The reason for leaving and the reason for this role are yours, and the pack does not supply them. Answer slot: give your actual reasons, in your own words, tied to what the JD asks for, which is ownership of GTM for two new product lines. If asked how you would work without a playbook, say what your material carries and where it stops; do not claim a startup-style pace you have not described | A long-tenure adaptability probe, sharpened by Dan's "one early-stage-startup chapter" per your description. F1 supplies the background; EXP because it scores motivation consistency |

### D. Case / Strategist (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A much larger platform vendor starts bundling a capability that overlaps one of our new lines. How do you decide between competing on price, differentiating, or partnering?" | CASE | [grounded] | A live problem, so the guidance makes no claim about your past. Clarify first: which line, which segment, how deep the bundled capability is, who buys, how hard it is to switch. State the objective, given your note that profitability is one of Northwind's three priorities. Weigh the three options, name the metrics you would watch, and name the assumption you would defend least. Challenge one premise politely: whether bundling is a pricing problem or a distribution problem | Your research note names bundling by a much larger platform vendor as the main threat. Dan's pricing spine tilts cases toward packaging. CASE because it is a live decision |
| D2 | "Enterprise expansion, Compass, profitability. Where do those pull against each other for a GTM lead on emerging products?" | CO | [grounded] | Bring the three named priorities to show grounding, then one thesis of your own with a mandatory concession. Say only what your note establishes. Ask whether Compass is one of the two new lines instead of assuming it. Do not recite the note; any prepared candidate can | The three priorities come from your note, which any prepared candidate can assemble. The differentiator is a reasoned tension. CO because it scores strategy at the company's altitude |
| D3 | "We have a new line and no partner motion yet. What do you need to know first, and how do you decide between partner-led and direct?" | CASE | [grounded] | A live problem. Clarify first: the buyer, the product's role in a deal, what a partner would have to do, what it costs to support. Then the decision criteria, the profitability trade-off, the data you would pull, and a first test. Say it as method; claim no past partner design | The JD's partner-motion requirement (F4) is the gap where a live problem tests reasoning without needing experience. CASE because it asks for structure, not history |

### E. Conversational / Rapport (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with two beats the quotes state: two years in strategy consulting at a top firm, then nine years in product strategy and operations at a large consumer-tech company. Answer slot: why this role, in your own words; the pack does not supply a motive. End on that reason and stop | A casual opener that is still scored. EXP because it checks the biography against the CV and sets up every later probe |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Lead in the quote's terms: you use AI tools daily. Answer slot: say which tools and what you use them for, in your own words. If your use is as a user rather than a builder, say so plainly. If Compass comes up, say plainly what you have and have not looked at | The JD flags AI as a plus (F6), asked casually so it is easy to under-prepare. JD because it scores the listed plus |

### F. Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has run sales ops?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "skilled in SQL/Tableau" "No classic sales-ops or quota-setting experience." | Pause, restate the question, then answer in order. First the limit: "I don't have classic sales-ops or quota-setting experience." Then what your material carries: the revenue model used in carrier negotiations, the annual volume targets set with cross-org consensus, and skilled in SQL and Tableau. Hold through two follow-ups by returning to those quotes. Concede specifically and keep the core | The same objection as B2 under a time box. JD because it scores the requirement; the pressure is delivery |
| F2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold the quote's own attribution: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: between the proposal and the credited result, say what you did and who did the rest; if you do not know who did what, say so plainly. Concede only what is true and specific, and never fold on the proposal | The attribution probe, asked bluntly. EXP because it scores precise honesty about F2 |

### Requirement coverage

| Requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | C1, C3, D1, D2, D3 |
| identify whitespace across land/adopt/expand/renew | A5, D2 |
| run independent analysis in SQL and Tableau | A3, A5, B4 |
| partner-motion design experience required | A4, C2, D3 |
| strong cross-functional influence | B1, B4, B5 |
| AI experience a plus | E2, D2 |
| Sales-ops and quota-setting (stated gap, not a JD line) | B2, C1, F1 |

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has been in pricing and monetization, with one early-stage chapter. What from that chapter changes how you think about GTM for a new product line?" | Ties to his own path, per your description. It invites a builder story from him and turns an interrogation into a peer conversation |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer. It shows Priya is thinking about his load, which is what the Peer persona is scoring |
| R3 | "How do our two teams share numbers today, and where does it chafe?" | Finds the real seam without assuming it, and respects that he knows it better |
| R4 | "From the sales strategy seat, where do enterprise expansion, Compass and profitability pull against each other most?" | Uses the three priorities in your note and invites his view instead of reciting yours |
| R5 | "How do you decide what counts as whitespace, and which data do you trust least?" | Speaks to his self-described data-driven approach, and the answer shows what Priya would be working with |
| R6 | "How has bundling by the larger platform vendor changed the way deals are priced or packaged?" | Invites his pricing perspective on the main threat named in your note, and shows the research |

## 7. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience | Negative Priya stated, F7 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." No slot |
| The annual volume targets were quotas | A claim F7's stated negative contradicts | F5's quote at its own scope, kept separate from F7, and nothing more |
| Drove or delivered the ~$400M ARR uplift | Inflated form of F2 | The quote at its own scope. The pack's observation is that the material says proposed and credited, not delivered. A1, A2 and F2 stay inside that |
| Designed or owned a partner motion | Inflated form of F4 | The quote at its own scope. The pack's observation is that the material says a revenue model used in negotiations. C2's slot stays inside the carrier work |
| Owned GTM for product lines | Inflated form of F1 | The quote at its own scope. The pack's observation is that the material says product strategy & ops. F1's slot asks only what reached customers or revenue |
| Has pricing or packaging experience | Inflated form of F4 | The quote at its own scope. The pack's observation is that the material says a revenue model, not pricing |
| Built or shipped AI products | Inflated form of F6 | The quote at its own scope: uses AI tools daily |
| Identified whitespace across the customer lifecycle as past work | Inflated form of F2 | The quote at its own scope. F2's slot asks only whether the change touched adoption or expansion |

## 8. Sources

**Provided documents:** your message (role and company description, JD highlights, Priya's summary, your description of Dan's profile, your research note). No dossier was present.

**Searches sent (both refused, so nothing came back):**
- Northwind Data company values and principles: refused
- Dan Kovac, Director of Sales Strategy, Northwind Data: refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. Official value names would have themed VAL questions. No values-style round is detected, so the values cheat sheet is absent either way |
| 2. `Northwind Data interview process, GTM strategy` | skipped | Your words fix the loop as one 60-minute conversation with a peer, so persona weights follow that |
| 3. `Northwind Data strategy` and recent news | skipped | Your research note already supplies the three priorities and the main competitive threat that feed D1, D2 and R4 |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. The interviewer read uses only your description of his profile |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## 9. Upgrade menu

- Full JD text → the six requirement quotes become the JD's own full wording, and any requirement missing from the highlights, such as a location or pay term, could add a row
- Priya's CV text → each evidence quote comes from the CV itself rather than your notes, and the answer slots in F1, F2 and F4 can be filled from her own words
- A readout document for the ~$400M ARR credit, and the carrier revenue model or its summary → F2 and F4 can move from `medium` to `high`, and A1, A2 and A4 can be rehearsed against real inputs
- Priya's answers to the slots in F1, F2, F4 and A3 → each becomes quoted evidence, and the rows that draw on it regenerate
- Whether Compass is one of the two new product lines → D1, D2 and R4 can be made specific
- Recruiter guidance on focus areas or any pre-work → coverage reweights, and a build section is added for any declared deliverable
- Dan's public profile or talks, pasted, or a retry of the search when permitted → the interviewer read gains his own themes, and R1 gets sharper
- Northwind Data's published values → VAL framing for the behavioral questions
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief with current strategy and financial context, and stronger D2 and R4
- A `tuesday-dossier.md` from job-underwriter → verified evidence, strategies per weak area, and prohibited claims recorded rather than built locally
