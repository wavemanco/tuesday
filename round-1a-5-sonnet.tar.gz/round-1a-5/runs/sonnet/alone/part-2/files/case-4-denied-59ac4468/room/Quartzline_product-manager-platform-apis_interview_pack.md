# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Round:** a 45-minute conversation with the hiring manager, on Thursday. The interviewer's name was not given.
- **Built from:** your dossier (`tuesday-dossier.md`, version 1.1, dated 2026-08-14) and your message. Web research did not run (see Sources).

## How to use this pack

Personas describe how a question arrives (the interviewer's style). Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: tell it in your own words, and say only what the quoted sentences say.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. You answer it truthfully in either direction, and "that was not mine" or "that never existed" are valid answers.

## Prep triage

Sized to the time before Thursday. These are the few things to do well, in order:

1. **B1**, the question the underwriter named as the one you will be asked. Say it aloud three times, including its three follow-ups.
2. **B2** and **E1**, the compressed pressure version of B1.
3. **A1** and **A2**, aloud, thinking out loud, without notes.
4. **C1** and **C3**, where the roadmap-input sessions and the adoption-metric gap get probed.
5. Choose two reverse questions, RQ1 and RQ2 first.

Everything else is insurance.

## Fit snapshot

Requirements are the dossier's `role_profile` lines. The evidence cells are your confirmed claims from the dossier, quoted exactly. A dossier confidence note is not part of a quote. It is carried in the Confidence column and the bridge.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [inferred] | transferability | The underwriter's condition: position this as adjacent, never as product management experience. Say the two sentences at their own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" and "I ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation: your material shows integrations led and inputs fed to product, not product management. The plain acknowledgment, sourced by the dossier field prohibited_claims "Having held a product manager title or role": "I haven't held a product manager title or role." The second quote is confirmed with limited inspectable proof, so expect a probe on it |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area ("Owning a roadmap and prioritization authority (R1 sub-claim)"). No bridge is coached. Words, sourced by prohibited_claims "Having owned a product roadmap": "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: learn how the two squad leads decide today, find out which decisions the PM makes alone, and get the adoption baseline |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | low | [inferred] | transferability | Your material says integrations led and a playbook written, not products shipped, and the words stay there: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the must-have line makes a probe on shipping likely. If you shipped or released any API or platform product, say which and what part was yours; if the work was on the integration side, or there was no such product, say so plainly and stay with the 30+ integrations and the playbook. The dossier grades R2 as high priority but lists it in no weak area, so this grading is the pack's own |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | medium | [inferred] | discovery | The quotes touch REST APIs and architecture and do not show docs or schemas. Answer slot: the requirement names API docs and schemas, so expect a probe on them. If you worked from the vendor's API docs or schemas in these integrations, say which and what you did with them, in your own words; if you did not, say so plainly and stay with the architecture stage your quote names |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [inferred] | transferability | The quotes carry clients and product. They do not name engineering or sales, and the words stay at "client integrations" and "feeding client evidence to product". Answer slot: if you worked with engineering or sales colleagues in these integrations, say who and about what; if not, say so plainly and stay with the clients and the sessions. Volunteer what you can and cannot show for the sessions before a prober extracts it |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy for this area is clarify: no verified entry speaks to it, so no past is coached. Answer slot: the requirement says agile delivery, so expect a probe on how you have worked that way. If you worked in sprints or a similar cadence, say how and what your part was; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline's squads define it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [inferred] | transferability | The quote is sessions feeding client evidence to product, and the words stay there. Answer slot: the responsibility names discovery with partners, so expect a probe on how you learned what partners needed. If you ran any other conversations with them, say what they were; if not, say so plainly and stay with the sessions as described |
| F8 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | The material is silent here, and the dossier also lists the current adoption baseline as unknown. Answer slot: if you defined or tracked any adoption or usage measure, say what was counted; if none, say so plainly and say what you would ask first about how Quartzline measures adoption today |
| F9 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | discovery | The quote has requirements and UAT as stages of the integrations and does not show specs. Answer slot: if you wrote anything engineers built from, say what and how it was used; if not, say so plainly and stay with requirements and UAT as your quote states them. Prioritization for an engineering squad is on the prohibited list below |

## Persona table

The hiring-manager prior is Case/Strategist plus Skeptic. Your own words establish one session, a 45-minute conversation, so no documented loop shifts the weights. The adjustments come from your dossier. The objection it names raises the Skeptic. The unresolved decision authority raises the Peer seam. The unknown adoption baseline and the technical-fluency requirement raise the Prober.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Quiet, persistent probing of the title and roadmap gap | Highest. The underwriter named this objection from evidence you confirmed, and the must-have R1 is where it lands (F1, F2) | Rehearse B1 until it is boring: concede specifically, state only the quoted sentences, hold through follow-ups |
| Case/Strategist (weight 5) | Live problems from the actual role: adoption, prioritization, a spec | Very high. Hiring managers buy capability on their own roadmap, and the JD lines on adoption and squads invite cases (A1 to A5) | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Data-Driven Prober (weight 4) | Walks the confirmed claims and asks how they were counted | High. A confirmed claim with limited inspectable proof, a headline 30+, and R3 and the adoption line all invite it (C1 to C4) | Know what you can and cannot say about each figure. Name the assumption you would defend least before they do |
| Conversational (weight 3) | Friendly opener, "walk me through the journey", "what do you know about us" | Medium. It opens most hiring-manager conversations and is still scored (D1 to D3) | A 90-second arc built from your three quoted sentences, and honesty about what you know of Quartzline |
| Peer Evaluator (weight 3) | Seam-splitting with the two squad leads, credit, cross-team work | Medium. The JD's two-squad structure and the dossier's open authority question make the seam a live topic (bank F) | Propose seam principles instead of pretending to know the seam. Ask about decision rights |
| Pressure (weight 2) | A 60-second time-box or "how much was you" | Lower. The objection can arrive in this register, so E1 and E2 rehearse it | Pause, restate, hold two follow-ups, concede specifically |
| Values/Behavioral (not banked) | A dedicated values round | No values-style round is detected: your words describe one conversation and no source documents a values round. No values cheat sheet is built | None needed |

## Question banks

The pack rates B1 as its highest-ROI prep, and the underwriter named that objection.

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" (the dossier's own wording) | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | The deepest rehearsal in the pack. Concede first, in the dossier's words: "I haven't held a product manager title or role" and "I haven't owned a product roadmap." Name the limit before they press: your material shows integrations led and inputs fed to product, which is adjacent to the job and not the job. Then say only what the quotes say: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I ran quarterly roadmap-input sessions feeding client evidence to product." Stop there and let them draw the inference. Follow-up 1, that is not product management: agree it is adjacent, return to the two sentences, add nothing. Follow-up 2, a PM with three years has done the job: concede specifically that they have more of the roadmap and prioritization work than you do, and hold that you bring the integration side. Follow-up 3, what would you be worst at in month one: roadmap and prioritization, said as a plan, which is to learn how the squad leads decide today and what the PM decides alone (RQ1). The second quote is confirmed with limited inspectable proof: volunteer what you can and cannot show from the sessions before they extract it. Never call the integration work product management | F1 and F2 are the biggest gap, and the underwriter derived this objection from evidence you confirmed. JD because it scores R1, the must-have |
| B2 | "The role owns the platform roadmap with two squad leads. What part of that would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap" | The dossier says no credible evidence exists here, so no bridge. Use the plain acknowledgment: "I haven't owned a product roadmap." Then the ramp plan as a plan: learn how the squad leads decide today, find out what the PM decides alone, and get the adoption baseline. Do not reach for the roadmap-input sessions here: they fed client evidence to product, which is a different thing from owning a roadmap | F2 is an acknowledge_gap area, and this is the Skeptic's stem for it. JD because the line is the JD's |
| B3 | "What's drawing you from integration work into product, and why now?" | EXP | [generic] | Your material carries no reason for the move, so the words are yours. Give your actual reason in two sentences, in your own words. If the reason connects to something you did, say that thing at its quoted scope only; if it does not, leave it out | Motivation consistency is the Skeptic's core test for a career switcher. EXP because it scores whether your story holds together, and the dossier gives nothing to map |
| B4 | "The role asks for shipped API or platform products. Where does your experience sit against that?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Say the quotes at their scope, in first person: the 30+ integrations, and the playbook. Answer slot: if you shipped or released any API or platform product, say which and what part was yours; if the work was on the integration side, or there was no such product, say so plainly and stay with the integrations and the playbook. The limit is the pack's observation: your material says integrations led, not products shipped | F3 is a must-have with adjacent evidence only. JD because it scores R2 |
| B5 | "How have you worked in agile delivery?" | JD | [grounded] | No verified entry speaks to this, so the answer is a slot and not a story. Answer slot: the requirement says agile delivery, so expect a probe on what it looked like for you. If you worked in sprints or a similar cadence, say how and what your part was; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline's squads define it | F6 is a clarify area. The requirement is only preferred, so a short honest answer costs little |

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Suppose a partner-facing API has plenty of sign-ups but few partners reach a live integration, and you've just been handed it. What do you need to know first, and what do you do in your first month?" | CASE | [generic] | Clarify before structuring: what counts as live, which partners stall and where, and how adoption is measured today. Then the objective, a segmentation of partners, an approach (talk to stalled partners, read what the support and test data say), the metrics, and the risks. Say aloud that you do not yet know Quartzline's baseline, because the dossier lists it as unknown. Challenge one premise respectfully, such as whether sign-up to live is the right funnel. No claim about your past is needed | Adoption is a named responsibility (F8). CASE because it scores structure; the scenario is a pattern, not a fact about Quartzline |
| A2 | "Two squad leads disagree: one wants a new endpoint partners asked for, the other wants reliability work. You're the PM. Walk me through it." | CASE | [generic] | Start with decision rights: ask who decides and by what criteria, since you do not yet know Quartzline's. Then criteria, partner evidence for each option, the cost of waiting, and an escalation path you would agree in advance. Do not offer a story of setting an engineering squad's priorities: your material does not carry one, and it is on the prohibited list | The dossier names squad authority as unverified, and the JD gives the role two squads. CASE because it scores reasoning under a live disagreement |
| A3 | "How would you decide what counts as adoption for a partner API, and what would you instrument first?" | CASE | [generic] | Offer two or three candidate definitions, from started to live to sustained use, and pick one to defend. Name its weakest assumption yourself, before they do. Say you would first ask how Quartzline measures it now. No claim about your past | F8 is silent in the material and the baseline is an open unknown. CASE because it asks for a definition and a first instrument |
| A4 | "What makes a platform API succeed with partners, and where do APIs like this usually go wrong?" | CO | [generic] | Pick two factors you can speak to with conviction rather than reciting a list. The pack could not research Quartzline, so make no claim about its platform: say what you would want to learn about it. Read Quartzline's own site before Thursday | Company-strategy fluency would normally be grounded in research, which did not run. CO and generic for that reason |
| A5 | "A partner needs a change to one endpoint, and both of your squads touch it. How do you write the spec and get it delivered?" | CASE | [generic] | Clarify the need behind the ask, then who owns each side. A spec skeleton: the problem, the partner evidence, scope and non-goals, the success measure, rollout and open questions. For delivery across two squads, one shared milestone and a checkpoint cadence you agree with the leads. No claim about your past | F9 is the JD line on specs and delivery, with only requirements and UAT as nearby evidence. CASE because it tests the work live |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you ran the quarterly roadmap-input sessions." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Beats the quote states: quarterly, roadmap-input sessions, client evidence fed to product. Confirmed with limited inspectable proof, so say plainly what you can and cannot show. Answer slot: the JD's discovery line makes a probe on what happened to what you fed in likely. If you know any of it was used, say what and how you know; if you do not know, or none was, say so plainly and stay with what you fed in. Do not say you influenced the roadmap | F7 and F5 draw on this quote, and it is the one with the thinnest proof. EXP because it tests what was actually yours |
| C2 | "You led 30+ integrations. How was that figure counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot, in your own words: say how the 30+ was counted, or say plainly you do not know how it was counted; say which assumption behind it you would defend least; say which parts of the work were yours and which were others. Keep the number attached to what it counts, integrations, as your quote does | A headline figure is a magnet for a Prober. EXP because it scores attribution and defensibility |
| C3 | "The role defines and tracks adoption metrics. What have you measured?" | JD | [grounded] | Answer slot: if you defined or tracked any adoption or usage measure, say what was counted and what it was sensitive to; if none, say so plainly, and say what you would ask first about how Quartzline measures adoption today. Asking is expected, since the dossier lists the baseline as unknown | F8 is silent in the material. JD because it scores the stated responsibility |
| C4 | "The role asks for fluency with API docs and schemas. Where does yours sit?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Say the quotes first: REST API integrations with an architecture stage, and the playbook you wrote. Answer slot: if you worked from API docs or schemas, say which and what you did with them; if you did not, say so plainly and stay with the architecture stage your quote names | F4 touches the requirement without showing it. JD because it scores R3 |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, each at its quote's own words, in first person: the 30+ integrations, the playbook, the quarterly sessions. Then the reason for this role, in your own words, since the material carries none. Use "we" for context and "I" for what you did | The biography question opens most hiring-manager conversations. F1, F3 and F7 are the rows it draws on. EXP because it tests whether the story holds |
| D2 | "What do you know about what we're building at Quartzline?" | CO | [generic] | Say what you can honestly say from the posting: a partner-facing API platform, with two engineering squads. Make no claim beyond it. Then say what you would most like to learn. The pack could not research Quartzline, so read its own pages before Thursday | A casual question about the company is still scored. CO and generic because research did not run |
| D3 | "Tell me about the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Your strongest inspectable evidence, with a document behind it. Beats the quote states: you wrote it, it is internal, your team uses it. Offer to walk through it end to end if it is shareable. Answer slot: if asked what it covers or who else contributed, answer from the document itself, in your own words; if others contributed, say so plainly | The playbook is the high-confidence evidence. EXP because it tests what was actually yours |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who's done this for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role" | Pause and restate the question. Concede in one sentence: "I haven't held a product manager title or role." Hold on the two quotes at their own wording. Hold through two follow-ups, then concede specifically that they have more roadmap experience. Do not fold on the quoted work to restore harmony | This is B1 compressed into the Pressure register (F1). JD because it scores R1 |
| E2 | "That roadmap-input work. How much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold the quote's own verb: you ran the sessions. Answer slot: if others co-ran or attended, say who and what their part was; if you ran them alone, or you do not know who else shaped them, say so plainly. Concede only what is true | F7 and C1 draw on this medium-confidence quote. EXP because it is an attribution probe |

### F. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where does the seam sit between a PM and a squad lead, and what happens when you disagree?" | CASE | [generic] | Propose seam principles instead of pretending to know Quartzline's: the PM owns the problem and the partner evidence, the lead owns how it is built, and you agree beforehand how disagreements escalate. Say you would ask which decisions the PM makes alone (RQ1). Offer what you would bring a squad, as well as what you need | The dossier says squad authority is asserted but not evidenced. CASE because it is a live seam question |
| F2 | "Tell me about a time work spanned teams and you shared credit." | EXP | [generic] | No quoted sentence carries a story here. A selection scaffold: pick a time with a named second team, a moment where credit could have been claimed, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem on credit and turf. EXP because it tests honesty about who did what |
| F3 | "Tell me about a time you had to align engineering, sales and a customer who wanted different things." | EXP | [generic] | A selection scaffold: pick a time with all three parties, a conflict between what they wanted, and what you did that was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Your quotes name clients and product and not engineering or sales, so do not stretch them to cover it | F5 is the row, and the requirement names three groups the quotes do not. EXP because it scores cross-functional stakeholder work |

### Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1 3+ years product management (F1) | B1, E1, D1 |
| Own the roadmap (F2) | B2, A2 |
| R2 Shipped API or platform products (F3) | B4, D3 |
| R3 Technical fluency (F4) | C4, D3 |
| R4 Stakeholder management (F5) | F3, F2, F1 |
| R5 Agile delivery (F6) | B5 |
| Run discovery with integration partners (F7) | C1, E2 |
| Define and track adoption metrics (F8) | C3, A3, A1 |
| Write specs and drive delivery with two squads (F9) | A5, A2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's open risk: authority is asserted in the JD and not evidenced. It reads as diligence and answers something you need before accepting |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second open risk: the metric is a named responsibility with no stated baseline. It tells you what you would be judged on |
| RQ3 | "What would a strong first quarter look like for this role?" | It converts the interviewer's picture of the job into something you can check your gaps against |
| RQ4 | "Where do the two squads and the partners most often disagree about what to build next?" | It surfaces the seam from F1 in the Peer bank and shows you are thinking about the actual job |
| RQ5 | "What did the last person in this role, or the team before it, find hardest?" | It tests whether the ramp plan you offered in B2 matches reality |

## Prohibited claims

What this pack will not coach. The first three are your dossier's `prohibited_claims`. The last two are wording this pack built because a quoted sentence is close to them.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | prohibited_claims: "Having held a product manager title or role" | The F1 quotes at their own scope, and the plain acknowledgment: "I haven't held a product manager title or role." |
| Having owned a product roadmap | prohibited_claims: "Having owned a product roadmap" | The plain acknowledgment: "I haven't owned a product roadmap." Then the ramp plan in F2. No bridge |
| Having set prioritization for an engineering squad | prohibited_claims: "Having set prioritization for an engineering squad" | The plain acknowledgment this field supports: "I haven't set prioritization for an engineering squad." A2 and F1 rehearse decision rights as questions |
| Shipped an API or platform product | Inflated form of F3 | The F3 quotes at their own scope. The limit is the pack's observation: the material says integrations led, not products shipped. B4's slot stays inside the integrations |
| Ran product discovery with partners, or influenced the roadmap | Inflated form of F7 | The F7 quote at its own scope: sessions feeding client evidence to product. C1's slot asks only what you know happened to it |

## Sources

- **Provided documents:** your message and the dossier `tuesday-dossier.md` (version 1.1, generated by job-underwriter, dated 2026-08-14). The dossier was consumed. `role_profile` supplied the requirements. `handoff_to_mock_interview` supplied the verified evidence, the three weak areas with their allowed strategies, the objection used in B1, the risks and employer questions behind RQ1 and RQ2, and the prohibited claims. `decision` was context only. `evidence_map`, `evidence_state` and `risk_register` were not in it.
- **Searches sent:** "Quartzline company values" (refused), "Quartzline interview process product manager" (refused), "Quartzline API platform strategy news" (refused). The host refused them, so nothing came back and nothing from any outside source is in this pack.
- **Loop:** established by your own words: one 45-minute conversation with the hiring manager. No values-style round is documented, so there is no values cheat sheet.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have fed a values cheat sheet and VAL questions. None are in this pack |
| 2. Quartzline interview process, product manager | unavailable | Would have documented the loop. The loop rests on your own words |
| 3. Quartzline strategy and recent news | unavailable | Would have grounded the CO questions. A4 and D2 are labeled generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative product manager JD | skipped | The dossier's role_profile fixes the requirements, the fit snapshot and the JD questions |

## Upgrade menu

- Allow web search, or paste Quartzline's values page and a recent strategy or news item → A4 and D2 become grounded, and a values cheat sheet is built if a values round is documented. A deeper pass is optional afterwards: up to 6 further searches and 2 further fetches, several more minutes, for a strategy brief
- The interviewer's name → an interviewer read, a reverse question tied to their path, and persona weights tuned to their public footprint
- The recruiter's prep email → coverage of any announced focus areas or pre-declared deliverable
- The raw CV behind your confirmed claims → rows F3 to F9 can move from inferred to grounded
- Agendas, notes or a message from product about the roadmap-input sessions → F1, F5, F7 and C1 move from medium confidence toward high
- Your own answers to the slots in F3, F4, F5, F6, F7, F8 and F9, sent as a message outside a drill → those rows become story-mapped, grounded guidance
