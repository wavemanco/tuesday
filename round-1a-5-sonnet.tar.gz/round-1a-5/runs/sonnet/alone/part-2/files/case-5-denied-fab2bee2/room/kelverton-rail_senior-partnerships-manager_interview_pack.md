# Interview pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your POV on operator partnerships, no slides. Rest: Q&A, where Ross will push on commercials. Built for a Tuesday interview with about four hours of prep.

## How to use this pack

- Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored.
- Type key: **EXP** work-experience deep-dive (do your claims survive scrutiny). **JD** role and requirement-driven. **CO** company and market knowledge. **CASE** live problem or hypothetical. **VAL** values and behavioral (none in this pack, see the persona table).
- Provenance labels: `[grounded]` traces to your message or the recruiter's words you quoted; `[inferred]` is derived from an adjacent source; `[generic]` is a role-family pattern with no claim about you or Kelverton.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that it was not yours, and return to what you did say.

## Prep triage (about four hours)

1. 75 minutes: build the POV from section "Graded deliverable: the 15-minute POV". Say it aloud twice against a timer. It is the first thing they score and the only part you control completely.
2. 45 minutes: rehearse B1 and B2 until they are boring. B1 is the highest-ROI prep in this pack.
3. 45 minutes: C1 to C3, the £4M figure, spoken aloud. Ross will push here.
4. 30 minutes: A2 and A4, clarify-first and the operator close.
5. 20 minutes: pick three reverse questions.

That is about 3 hours 35 minutes, leaving buffer for the two inputs the upgrade menu asks for. Everything else is insurance.

## Fit snapshot

No JD was supplied, so requirements come from the recruiter's own words (quoted) and, where marked, role-family expectations with no source. No gate requirement (location, office days, pay, start date) appears in your material.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material says a payments ISV channel grown from 6 partners to 40, not rail operator partnerships, with nothing inspected behind it. Words at that scope: "I spent the last four years at a payments company running the ISV channel, and took it from 6 partners to 40." Answer slot: the POV looks forward, so expect a probe on what carries across. If any part of how that channel grew carries to operators, say which part and why, in your own words; if none does, say so plainly and stay with the numbers you gave |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies, with nothing inspected behind it. Words at that scope: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: the phrase "the operator world from the other side" invites a probe on which operators and what you saw of their work. Say which, in your own words; if the contact was limited, say so plainly and stay with the network planning you did |
| F3 | Experience selling into rail operators (role-family expectation, no source supplied) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F4 | "Ross will push on commercials." — recruiter's email | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message, "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Influenced revenue is adjacent to direct revenue and is not the same thing, and the limit is yours to state first. Words: "I haven't carried a direct quota; what I carried was influenced revenue." Then the figure at its own scope. Any wider step is F5's slot |
| F5 | "Ross will push on commercials." — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | discovery | The figure is yours and nothing in the material shows how it was counted. Answer slot: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; where you do not know how it was counted, say so plainly, and "roughly" stays in the sentence |
| F6 | The reason for the move into rail (role-family expectation, no source supplied) | none given | none | [generic] | discovery | The material says nothing about why rail or why now. Answer slot: give your actual reason, in your own words, in about thirty seconds; if there is not one single reason, say what the main one is |
| F7 | Working the seam between partnerships and direct sales (role-family expectation, no source supplied) | none given | none | [generic] | discovery | The material shows no case of partner-sourced and directly sourced work meeting. A strong answer here is a named case and how it was settled; if one comes to mind, it goes into the E bank. If none does, E1 and E2 are answered as principles, labeled as how you would handle it |

## Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. She asked you to "land on what it means for the operators themselves", so the last beat of the 15 minutes is the operator close, not the recommendation.

**Facts to build on**

- Recruiter's words: POV on "where you'd take our operator partnerships over the next 18 months"; no slides; land on the operators.
- F1: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."
- F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."
- Kelverton sells scheduling software to train operating companies, per your message.

**Differentiation.** The strategy team's report is equally available to both interviewers and to any prepared candidate, so reciting its shortlist scores as homework. Bring one item from it to prove you read it, then one thesis of your own that departs from it, with reasons, and one anti-pick (something you would say no to). I do not have the report's text, so I cannot name its consensus items; paste it and this paragraph becomes specific.

**Terms.** "Operator partnerships" could mean partnerships with the operators as customers or co-development partners, or partners who reach operators. State the reading you are using in your first sentence. The report probably settles it.

**Three theses (pick one as your spine, name the others as what you considered)**

| Thesis | Mandatory concession | What it means for the operators | Provenance |
|---|---|---|---|
| Deepen a small number of operator partnerships into joint work rather than widen the list | Slower to show breadth, and it concentrates dependence on a few operators | The operators that partner get a say in what gets built and a named counterpart, instead of a vendor relationship | [generic] |
| Build a partner ecosystem around the scheduling product so operators get outcomes delivered faster | It will not show results inside two quarters, and it needs delivery capacity I cannot see from outside | Operators reach outcomes through partners they already work with rather than waiting on one vendor | [generic] |
| Agree with operators how partnership success is measured on their side, then add partners against it | Harder to tie to revenue, which is exactly what Ross will push on | The measure comes from the operator's own aims, so partnership effort is judged on what changes for them | [generic] |

Anti-pick to prepare, in your own judgment: one kind of partnership you would not pursue in these 18 months, and why. Say it as a hypothesis, since you are outside.

**Shape of the 15 minutes (a rehearsal method, not a script)**

| Minutes | Beat |
|---|---|
| 1 | Name the reading of "operator partnerships" you are using, and one sentence on where you are coming from, at F1 and F2's scope |
| 3 | What you would want to be true or find out first, stated as hypotheses |
| 6 | Your spine thesis, then the others you set aside and why, plus the anti-pick |
| 3 | What it means for the operators themselves, concrete, in operator terms |
| 2 | What you would measure, the one concession, and what would change your mind |

## Persona table

Weighting: a panel blends the top two personas of each member's relationship. Deepa, as your future manager, brings Case/Strategist and Skeptic. Ross, a Commercial Director who will push on commercials, brings Data-Driven Prober and Pressure, with a Peer Evaluator tilt on the seam with his direct sales. The recruiter's email documents one 60-minute session, a 15-minute POV and Q&A, which is why there is no values round: none is documented, so there is no values cheat sheet. If you know something that changes these weights, change them.

| Persona | Bank | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | A | Live problems on operator partnerships, probing your POV | Highest. The POV is 15 of the 60 minutes, and Deepa is the person buying capability | Clarify, then structure, then answer; use "operator" vocabulary; challenge one premise respectfully |
| Skeptic | B | Quiet probing of "never sold into rail" and the move from payments | High. Your own message names the gaps, so they will find them | Rehearse B1 until boring; hold what your quotes carry; concede the rest plainly |
| Data-Driven Prober | C | The £4M and the 6 to 40, pulled apart | High. Ross "will push on commercials", and the headline numbers are all influenced revenue | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| Pressure | D | Time-boxed challenges, "why you over someone who has sold into rail" | Medium. A Commercial Director testing a partnerships hire often tests composure | Pause, restate, hold through two follow-ups, then concede one specific thing |
| Peer Evaluator | E | The seam with direct sales, credit-sharing | Low to medium. Depends on how Ross sees his own team | Reciprocity first; propose principles for the seam, do not pretend to know it |
| Conversational | F | "Walk me through the journey" | Low, but it opens the Q&A and is still scored | A 90-second arc, practiced |

## Question banks

Provenance sits before the guidance. A cell with a label alone makes no claim about your past.

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months, and land on what it means for the operators themselves." | CASE | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | This is the section above. One sentence of credentials at the quote's scope, then straight to your reading of the term, your spine thesis and the operator close. Keep the concession in the middle, not the end. Answer slot: if a probe asks what carries over from the ISV channel, say which part and why in your own words; if none does, say so plainly and stay with the figures you gave | Announced deliverable, so it is the first scored item. F1 and F2 are the evidence it draws on; CASE because it is a live recommendation, not a recall question |
| A2 | "Before you commit to a plan: what do you need to know about our operator partnerships first?" | CASE | [generic] | Clarify before you structure: what "partnership" means here, what the next 18 months will be judged on, what is working today, and what has been tried. Then state your assumption and proceed. The question needs no claim about your past, so the guidance makes none | Case/Strategist interviewers score whether the candidate clarifies first. Generic because it is a pattern for the problem, not a fact about this employer |
| A3 | "Which kind of partnership would you say no to in the next 18 months?" | CASE | [generic] | Name one, with the reason, as your judgment from outside. Then say what would change your mind. The anti-pick is where a shared report's consensus is departed from, with reasons | The role's real job includes saying no, and an anti-pick scores as judgment rather than homework |
| A4 | "What changes for an operator on the ground if your plan works?" | CASE | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Describe the change in operator terms, concretely. Answer slot: if your planning work gave you a view of how operators' own staff work, say what you saw and where; if it did not, say so plainly and reason from first principles, said as such | The recruiter asked you to land on this, so it is the likeliest probe of the close. F2 is the evidence and its limit |
| A5 | "What would you do in your first 90 days?" | CASE | [generic] | Structure: listen to operators first, map what exists, agree one measure, pick one early piece of work. Present it as a plan with a stated assumption. No claim about your past | Standard Deepa question from a future manager. Generic, and a short one |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. Why should an operator take your call?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | **Highest-ROI prep in this pack.** Level 1: concede in one sentence, "I've never sold into rail specifically", then hold what your quotes carry, which is five years in transport consulting in bus and light rail network planning, and a payments channel taken from 6 partners to 40. Level 2, if they say bus and light rail is not train operating companies: concede that too, plainly, and return to what you did say. Level 3, if they ask how you would close the gap: a plan, said as a plan, never as a past. The limit: your material says bus and light rail network planning, not train operating companies. Never add a rail contact or a rail project you did not mention | The gap is stated in your own message, so this will be asked in some form. JD because it scores a stated requirement; the guidance holds only what F2 and F3 carry |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick the one that is true, say it in one sentence ("I haven't carried a direct quota" or "I've never sold into rail specifically"), then say what you would do first about it, as a plan. Do not choose a weakness you do not have to sound modest | A prober of the gaps wants honest self-assessment. F3 and F4 are the candidates |
| B3 | "Why leave payments for rail-tech, and why now?" | EXP | [generic] | Answer slot: give your actual reason, in your own words, about thirty seconds. If there is no single reason, say the main one. The pack does not supply a motive | Motivation consistency is scored in every skeptic round. F6 is `discovery`, so the pack holds the slot open |
| B4 | "You say you know the operator world 'from the other side'. What does that give you, and what doesn't it?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | What it gives: a view built in bus and light rail network planning. Answer slot: if you saw how operators' staff work, say which and what; if the contact was limited, say so plainly. What it does not: heavy rail operators, which your material does not show. Say that limit in your own words | The question quotes your own phrase back, so it is premised only on F2's sentence |

### C. Data-Driven Prober (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Say the figure as you gave it: "roughly £4M of influenced revenue." Answer slot: if you know how it was counted, say it in your company's terms; if you do not know, say so plainly. The pack supplies no method, baseline or attribution model, and an explanation you cannot repeat under a second question is worse than none | Every headline figure gets a defend-the-number question, and this is the one on your message. F5 |
| C2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Name it before they do, in your own words. Answer slot: if you know the assumption you would defend least, say it and what it is sensitive to; if you do not know, say so plainly | Naming the weakest assumption turns a gotcha into a credibility gain. The pack does not name it for you |
| C3 | "How much of the move from 6 partners to 40 was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say which parts were yours and which were others', in your own words. If you cannot split it, say so plainly; if it was mostly yours, say what you mean by mostly. Your sentence says you took it from 6 to 40, so keep it at that scope and add nothing | Attribution probes are asked of every channel-growth claim. F1 |
| C4 | "How would you structure the commercial relationship with an operator partner?" | CASE | [generic] | Options, with a concession: what each side contributes, how value is measured, how credit is attributed, and what happens on underperformance. Say it as how you would think about it, not as something you have done in rail. The pack makes no claim about your past | Ross will push on commercials. This is the live version of the same push |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Pause and restate. Concede the first point in one sentence, then hold: a payments partner channel taken from 6 partners to 40, and five years in bus and light rail network planning. Hold through two follow-ups; concede one specific thing, and never fold the whole claim to restore harmony. Claim no superiority your quotes do not carry | A time-boxed version of B1. F1 to F3 |
| D2 | "Our partnerships team may be held to direct revenue. Would you take that?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Answer slot: give your own position in your own words. If you would take it, say so and say what you would want to understand first; if you would not, say so plainly and say what you would want measured instead. The first sentence is "I haven't carried a direct quota", which is already yours | Tests whether you will accept Ross's accountability, and whether you will bluff it. F4 |
| D3 | "I'm not convinced your recommendation works. Convince me." | CASE | [generic] | Hold the thesis through two follow-ups. Concede the one weakness you named in your POV, specifically, then say what would change your mind. No claim about your past | The pressure persona tests composure on your own recommendation |

### E. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the seam between partnerships and direct sales, and what happens when we disagree?" | CASE | [generic] | Propose principles, do not pretend to know the seam: who owns the relationship with an operator, how a deal that both teams touched is recorded, how disagreements get settled. Reciprocity first: what you bring his team. If you have a named case from your own work, say so; if none comes to mind, say so plainly and answer as how you would handle it | F7 has no evidence, so this is a selection scaffold, not a story map |
| E2 | "How do you handle credit when a deal spans partnerships and sales?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: if credit-splitting came up at your payments company, say what and how it was settled; if it did not, say so plainly, then give your principles as how you would handle it. Influenced revenue is the only number you gave, so keep it at that scope | The figure is influenced revenue by your own words, so the credit question is a natural next probe. F4 |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey from transport consulting to partnerships." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc with two chapters and a through-line to rail, using only those two sentences. Answer slot: the move between the chapters is not in your material; say your actual reason, in your own words | The opener of a Q&A that feels safe and is scored |
| F2 | "What's caught your eye lately about how operators are being asked to run their services?" | CO | [generic] | Pick one point from the report you have read, and one thing from outside it. Make no claim about Kelverton beyond what the report states, and none about your past | CO is generic here because research was not available and the report's text is not in hand. Pasting it makes this specific |

## Requirement coverage

| Requirement | Questions |
|---|---|
| POV on operator partnerships over 18 months | A1, A2, A3, A5, D3 |
| Land on what it means for the operators | A1, A4, B4 |
| Ross will push on commercials | C1, C2, C3, C4, D2, E2 |
| Selling into rail (role-family) | B1, B2, D1 |
| Reason for the move (role-family) | B3, F1 |
| Seam with direct sales (role-family) | E1, E2 |
| Company and market knowledge | F2, A2 — none grounded in research, and why: research was refused |

## Reverse questions

| Reverse question | Why it lands |
|---|---|
| "Which operator partnership today would you point to as the one that works, and what makes it work?" | It shows you are looking for the working pattern, and it hands you the vocabulary for the rest of the conversation |
| "How will the partnerships team be measured over the next 18 months, and by whom?" | Ross cares about commercials; asking it first shows you are not avoiding the number |
| "Where does partnerships sit relative to direct sales when both touch the same operator?" | It is the seam from E1, asked as a real question, and it answers what you could not research |
| "What would you want me to have learned by day 90?" | It makes the expectation concrete and shows you plan to learn rather than assume |
| "What does the strategy team's report underweight, in your view?" | It signals you read it and are not reciting it, and it asks Deepa for her own view |
| "What would make you say, a year in, that this hire was the right call?" | A manager-facing close: it gets the success measure in her words |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F3 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." Plain acknowledgment: "I've never sold into rail specifically." No slot |
| Has carried a direct quota | Negative you stated, F3 and F4 | The same sentence, with the plain acknowledgment "I haven't carried a direct quota." No slot |
| Knows how train operating companies work from the inside | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says bus and light rail network planning, not train operating companies |
| Owned £4M of revenue, or closed it | Inflated form of F1 and F5 | F1's quote at its own scope: "roughly £4M of influenced revenue" |
| Built the ISV channel from scratch | Inflated form of F1 | F1's quote: you ran it and took it from 6 partners to 40. The pack does not say more than the sentence does |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. The strategy team's market report was attached to the recruiter's email, but its text was not provided to me, so nothing in this pack draws on it. No JD, CV text or interviewer profile was supplied. No dossier was supplied.

Searches sent. Every one was refused (permission not granted), so none returned anything:

- "Kelverton Rail company values" — refused
- "Kelverton Rail interview process partnerships" — refused
- "Kelverton Rail scheduling software train operating companies news strategy" — refused
- "Deepa VP Partnerships Kelverton Rail" — refused
- "Senior Partnerships Manager job description rail technology train operating companies" — refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed the values cheat sheet; none is built because no values-style round is documented in the recruiter's email |
| 2. `Kelverton Rail interview process` | unavailable | Would have checked the loop; the recruiter's email already establishes this one session, its two interviewers and its format, so persona weights rest on that |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have grounded the CO questions; they are labeled `[generic]` instead, and the report's text is not in hand |
| 4. `Deepa` / `Ross` and Kelverton Rail | unavailable | Would have produced the interviewer read and a reverse question tied to a path; with titles only there is nothing to read, so the section is dropped |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have fixed JD-tagged requirements; they come from the recruiter's words and are marked as such |

## Upgrade menu

- The JD text → the `[generic]` requirement rows become quoted `[grounded]` rows, any gate (location, office days, start date) gets surfaced, and the JD-tagged questions are re-aimed
- The market report pasted in (or its headline findings) → the POV's differentiation paragraph names the consensus items to depart from, and F2 and A2 become grounded CO questions
- Search permission, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the strategy context and a recent-moves read for Kelverton Rail
- Full names or public profiles for Deepa and Ross → an interviewer read, persona weights adjusted from their public path, and a reverse question tied to it
- Your CV text → more of your own sentences to quote, so the E and F banks can be story-mapped instead of scaffolds
- Whatever sits behind the £4M, for example the partner-sourced pipeline report from your payments company → F5 moves from `medium` toward `high`
- A `tuesday-dossier.md` → verified evidence, prohibited claims and a strategy per weak area from an earlier evidence check, which this pack otherwise infers from your message alone
