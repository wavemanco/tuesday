# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager, in a single 60-minute session on Friday. Saltmarsh's careers page describes every loop as a recruiter call, then the Outage Hour: one 60-minute interview with the hiring manager, a live-incident tabletop and then a values conversation (Sources 2). Your note does not say that Friday is that session or that Tobias is the manager you would report to. The pack is built on both assumptions.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scored on. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Whether the claims in your background survive follow-up, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | How much you know about the company and its current direction |
| CASE | Structure and reasoning on a live problem from the role |

IDs run by persona (A, B, C…) so you can ask for a drill by ID. An answer slot is an instruction for the interview, not a question for you now: it tells you what to say if a practice was yours and what to say if it was not.

## Prep triage

You have until Friday. In order:

1. Say C1 out loud until it is boring. It is the objection you stated yourself, and the pack names it the highest-ROI prep.
2. Run A1 and A2 aloud, timed. The tabletop is the documented first half of the session (Sources 2).
3. Rehearse B3 and E1, the release-checklist answers. F4 is the row where an interviewer with a QA background can probe deepest (section 7).
4. Read the full Project Larkspur announcement and the values page before Friday (A5, B1 to B3). The pack saw only a search snippet of the announcement.
5. Pick three reverse questions and say them aloud.

Everything else in the pack is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title, with nothing inspected behind it. It does not say live events or a second title, so the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's calendar line makes a probe on how the calendar was fed likely. If design, art, engineering or community teams supplied items for a drop, say which and how, in your own words; if none did, or it was not yours, say so plainly and describe how you ran the calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The calendar touches this requirement without showing which teams you worked with. Answer slot: if you worked with any of those four teams on a drop, say which and what the work was between you, in your own words; if you did not, or the contact ran through someone else, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers; it does not show a review or the setting of KPIs, and the words stay at the presenting: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on which measures were in those numbers. Say which, in your own words, and whether you produced them or received them; if you only presented what others produced, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it, with nothing inspected behind it, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: if you and QA went through the checklist together at release time, say how that worked, in your own words; if the checklist was handed over once written, or you do not know how it is used now, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer at a puzzle-game studio and does not say whether the title was live for all of them. Answer slot: the JD says live-service, so expect a probe on that. Say how many of the four years the title was live and how it ran, in your own words; if it was live for only part of the time, say which part and stay with the quote |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. Lead with the named record in the quote's own terms: weekly, the main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | The quote shows the numbers reached the studio head through you; it does not show how they were produced or counted. Answer slot: say which retention measures were in them and how each was counted, if you know; if you do not know how one was counted, say so plainly and stay with presenting them |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | A written document that is still in use is a named record, and the quote already reaches the requirement in other terms. Lead with it in the quote's terms and let the interviewer judge the clarity: "I wrote the release checklist our QA team still uses." |
| F9 | Team leadership (not stated in the JD; an interviewer can still raise it) — [generic] | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I've never led a team." Then how you would work without reports, said as a plan and never as a past. Never a claim to leading people |
| F10 | Monetization experience in a live-service title (not stated in the JD; relevant if the season-pass move in Sources 3 comes up) — [generic] | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to purchase, pricing or pass work |

No requirement in the JD is a gate: it names no licence, location, schedule or pay term.

## Prohibited claims

Built from the fit snapshot before the banks were written. None of these is coached, in any cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F9 | Your words: "Never led a team, and never worked on a game with in-app purchases." The plain acknowledgment: "I've never led a team." No slot |
| Has worked on a game with in-app purchases or a season pass | Negative you stated, F10 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." The plan after it is a plan, not a past |
| Ran live events for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for the main title |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The material says you presented monthly retention numbers; D1's slot asks only what was in those numbers |
| Managed each release's checklist with QA | Inflated form of F4 | F4's quote at its own scope. The material says you wrote the checklist and QA still uses it |
| Produced live-service games for four years | Inflated form of F5 | F5's quote at its own scope. The material gives four years as an associate producer and does not say how many of them the title was live |

## Persona weights

Weights are a judgment, shown so you can recalibrate if you know something the pack does not. Reasoning runs in three passes: the hiring-manager prior (Case/Strategist and Skeptic up), the loop (Sources 2 documents a tabletop and then a values conversation, so Case and Values rise), and the interviewer's published theme (section 7). A peer persona is left out: the session is with the hiring manager, not a peer.

| Persona | Questions | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | 5 (A) | The Outage Hour tabletop: a simulated outage during a live event, with injects | High. Sources 2 documents the tabletop as the first half of the session, and a hiring-manager round tilts to case work anyway | Clarify before you decide, say what is known against assumed, then options, owners, player message, what to record. Challenge one premise respectfully |
| Values/Behavioral | 5 (B) | A values conversation built on Saltmarsh's three named values | High. Sources 2 documents the second half as a values conversation; Sources 1 gives the three values by name | Pick stories where one of your quoted sentences carries the story; where none does, use the selection scaffold and its honest branch |
| Skeptic | 3 (C) | Quiet probing of the two gaps you stated and of one title against two | Medium. F9 and F10 are gaps you stated, and the hiring manager is the person deciding whether to carry them | Rehearse C1 until it is boring: plain acknowledgment, then a plan, never an adjacent claim stretched to cover the gap |
| Data-Driven Prober | 3 (D) | How the retention numbers and the content-drop calendar worked, step by step | Medium. The JD names retention metrics, and F3 and F7 are the rows with the least behind them | Know what you can and cannot say about how each number was counted; say plainly where you do not know |
| Pressure | 2 (E) | The tabletop's injects and interruptions; attribution probes on the checklist | Low to medium. This is inference: an incident tabletop plausibly includes time pressure, but no source says so | Pause, restate, hold the position the quote carries through two follow-ups, then concede specifically |
| Conversational/Rapport | 2 (F) | The opener and any lighter moments | Low. A single 60-minute session spends little on rapport, but the opener is still scored | A 90-second arc built only from your quoted sentences |

## Reading the interviewer

Public professional footprint only. Both facts come from one search result that the pack did not open (Sources 4); the conference's own listing confirms them.

| What the result says | Practical implication |
|---|---|
| Tobias Wrenfield is Head of Live Operations at Saltmarsh Games and was previously a QA lead at a console studio | Expect release hygiene to be his native language. F4 is the row most likely to draw follow-ups, which is why B3 and E1 are in the pack |
| His GDC 2026 talk is "Patch Notes Are a Promise", arguing that a live team is judged by how often its patch notes describe what actually shipped | The value Ship the Patch Not the Promise (Sources 1) matches his published theme. Answers that separate what was built from what was hoped will land. Do not recite his talk; read it first if you plan to mention it |

Mirror opportunity, shared vocabulary rather than a shared path: his QA background and F4's quote, "Wrote the release checklist our QA team still uses." — your message. Offer it at its own scope and let him take it further.

## Question banks

Ordered by weight. Every provenance cell leads with one label; where guidance rests on something you said, your own sentence follows it.

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A3, A4, A5, D2 |
| Coordinate design, art, engineering and community on each update | B5, C2, A2 |
| Own the post-event review and the KPIs it reports | D3, D1 |
| Manage the release checklist with QA | A4, B3, E1 |
| 3+ years producing live-service games or apps | F1, E2 |
| Experience running a content calendar | A3, D2 |
| Comfortable with player-retention metrics | D1, B4, D3 |
| Clear written communication | A2, B2 |

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event. Players can't claim a reward and support tickets are climbing. You have ten minutes with engineering. What do you ask first, and what do you decide?" | CASE | [generic] | Structure it aloud. First, what is confirmed against reported: who is affected, since when, whether it is still getting worse. Then the objective: protect players, in the spirit of the published value that players win when the calendar and the players disagree. Then the options, such as pause, roll back, hotfix or run with a workaround, and which you would pick on what is known now and what would change your mind. Close with owners, what players hear and when, and what you would record for the review. Challenge one premise, for example whether the reward claim is the only thing broken. The question needs no claim about your past, so the guidance makes none | The tabletop is the documented first half of the session (Sources 2), so this is the likeliest shape of the opening. CASE because it scores structure and prioritization on a live problem; the scenario itself is generic, not Saltmarsh's |
| A2 | "In the same incident, design wants to extend the event to make up the lost time and community wants a statement within the hour. What do you tell each of them, and what are the first two sentences of the player statement?" | CASE | [generic] | Tell design that the extension waits until the fix is verified and players can actually claim. Tell community what is confirmed now and when the next update comes, not a fix time you cannot yet back. The two sentences: one says what is happening and who is affected; the other says what is being done and when players will hear next. Announce what is built and say nothing hoped, which is the published value's own wording. The question needs no claim about your past | JD coverage for clear written communication, delivered as CASE. Ship the Patch Not the Promise (Sources 1) is the raising source for the shape of the answer |
| A3 | "You're handed the live-events calendar for two mobile titles that share a player base, starting next month. What do you need to know before you plan the first eight weeks?" | CASE | [generic] | Clarify first: what is already committed, such as releases and platform or store dates; the objective for each title; the current cadence; each discipline's capacity; QA lock dates; and how overlaps between titles are handled. Then structure: constraints, cadence with buffers, a dependency check per team, a KPI per event, a slot for the review. Challenge one premise respectfully, such as whether both titles should run on one calendar. Makes no claim about your past | JD coverage for the calendar requirement, as a decision rather than a record. Generic because it is a planning pattern; the premise about a shared calendar is deliberately open |
| A4 | "A seasonal event is booked for the same week as an engineering release that QA hasn't signed off. What moves, and who do you tell first?" | CASE | [generic] | Ask what QA's open issues are and how severe, and what each option costs players. Options: ship the release without the event, run the event without the release's content, or move both. QA sign-off against the checklist is the gate, so the checklist decides, not the calendar. Tell first the people whose work moves. Makes no claim about your past | Covers the checklist-with-QA requirement from the decision side, and the QA-lead background in section 7 makes it a natural question |
| A5 | "Project Larkspur puts the two titles on one shared events calendar from February. What does that change about this job, and what would worry you about it?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what the announcement says, as you read it in full before Friday: a season-pass model for Tidepool Tactics and Lantern Row, one shared events calendar from February 2027, and a single live-ops group in place of per-title event teams (Sources 3). Then reason openly: a shared calendar means more collisions, one set of dependencies, a larger cost to a miss. Use your own calendar as the comparison point, at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Say what you would want to learn about running more than one. You have no inside view, so do not offer one | The one strategy question the research supports. CO because it scores whether you can think at the company's altitude. The pack saw only a search snippet of the announcement, so reading the full page is part of the prep |

### B. Values/Behavioral (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the plan and the players pulled in different directions." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time a scheduled drop and what players were experiencing disagreed. It needs what the plan said, what told you about the players, what you did, and whether the calendar moved. The published value says the players win, so a story where the calendar won needs the honest reason said plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the weekly content-drop calendar, or say how you would decide | Players Before Plans (Sources 1) is the raising source. No quoted sentence carries a conflict, so this is a scaffold, not a story map |
| B2 | "Tell me about a time you had to be exact about what had shipped and what hadn't." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick a time you had to separate what was built from what was hoped. It needs what was claimed or planned, what was actually in the build, and who you told and how. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the checklist you wrote and QA still uses, or say how you would handle it | Ship the Patch Not the Promise (Sources 1), and the interviewer's published theme (section 7). Scaffold, because no quote carries the story |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: the checklist, written by you, which QA still uses. Those are the beats the quote states; tell them in your own words. Answer slot: the value's wording ties each release to leaving the checklist better, so expect a probe on whether it changed. If you revised it after a release, say what and why; if it has not changed since you wrote it, or you do not know, say so plainly and stay with having written it | Leave the Build Greener (Sources 1) names the checklist directly, and F4 is the only row that carries a story for it |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time the news was unwelcome and you did not soften it. It needs a named stake, the moment you held your position, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is presenting the monthly retention numbers to the studio head, or say how you would deliver a bad number | Persona stem for the Values interviewer; Players Before Plans makes it likely, because telling leadership the players disagree is that value in practice. Your material shows the presenting, not an unwelcome result |
| B5 | "Tell me about a time design, art, engineering and community wanted different things from the same update." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a drop where two disciplines wanted different things. It needs what each wanted, who decided, and what shipped. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the weekly calendar, or say how you would handle it: ask each side what it would lose, put the trade in front of whoever owns the decision, and record it | The JD's coordination line is the raising source. JD because it scores a listed duty, delivered as a behavioral prompt |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our titles are moving to a season-pass model, and you haven't worked on a game with in-app purchases. What's your plan for the first ninety days?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. First the plain acknowledgment, in your own words: "I haven't worked on a game with in-app purchases." Then stop. Nothing in your material shows purchase work, so adding an adjacent claim here is what breaks on the second follow-up. Then the plan, said as a plan: the first thing you would ask for, one person or team you would sit with, and one assumption you would stop yourself from making. The one adjacent thing your material carries is presenting the monthly retention numbers; say that and no more. Follow-up one asks what makes you think you can get up to speed: return to the plan. Follow-up two asks what if it takes longer: concede specifically that purchase-related decisions would be slower at first, and say what you would do to cover | F10 is a gap you stated, and the move to a season pass (Sources 3) puts monetization close to the calendar you would own. The likeliest single objection to this candidate, so it gets the most follow-up levels and the exact concession wording. JD because the premise comes from the announcement and your own statement |
| C2 | "This role coordinates design, art, engineering and community on every update, and you haven't led a team. Why does that work?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first: "I've never led a team." Hold that coordinating an update is not the same as managing people, which is the JD's own wording. Answer slot: if you worked with any of those teams on a drop, say which and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar. Concede specifically if pushed: you have had no reports | F9 is stated, and the JD's coordination line is why it surfaces. Hold-then-concede is the type's bar: hold the distinction, concede the missing reports |
| C3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose from the two things you told me, using the plain acknowledgments from C1 and C2, or a truer one if there is one. Do not invent a safe-sounding weakness. Then what you would do in the first month, said as a plan | Persona stem for the Skeptic; F9 and F10 are the honest answers, and a candidate who names them first converts a probe into candor |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers to the studio head. Which measures were in them, and who produced them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: the JD asks for comfort with retention metrics, so expect a probe on the numbers. Say which measures were in them and how each was counted, if you know; say which part was yours, the producing or the presenting; and name the assumption behind one measure you would defend least. If you did not produce them, or you do not know how one was counted, say so plainly and stay with the presenting | F7 is the row with the least behind it. EXP because it tests what was actually yours; the weakest-assumption move is the type's bar |
| D2 | "Walk me through how the weekly content-drop calendar ran, from planning to release." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F6: the weekly calendar, the main title, two years. Those are the beats the quote states. Answer slot: if design, art, engineering or community teams supplied items for a drop, say which and how; if none did, or it was not yours, say so plainly and describe how you ran the calendar | F6 is the evidence for the calendar requirement and the likeliest place to be probed. EXP because it checks the claim survives a walk-through |
| D3 | "After an event, what goes into the review, and which KPIs does it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | A method, not a past. What was planned against what shipped; what players did and said; the retention measures you would choose and why, naming them yourself; support volume; what you would change next time. Say one KPI you would distrust and why. Your own experience of putting numbers in front of leadership is the one quoted line: "I presented the monthly retention numbers to the studio head." | JD coverage for the review-and-KPIs line, asked as a decision so the answer does not rest on a past the material does not show |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That release checklist — how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold the position the quote carries: "I wrote the release checklist our QA team still uses." Answer slot: if QA or anyone else added items, say who and what, in your own words; if it was all yours, or you do not know what has been added since, say so plainly. Hold through two follow-ups by returning to the quote; concede specifically on anything you did not do, never on having written it | Persona stem for the Pressure interviewer. F4 is the row a QA-background interviewer can probe hardest, and attribution is exactly what this question scores |
| E2 | "Sixty seconds: why you over someone who has already run live events for two titles?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Never led a team, and never worked on a game with in-app purchases." | Three beats, each at its quote's scope: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the main title for two years, the checklist QA still uses. Then concede specifically what a more experienced candidate would have over you: the plain acknowledgments from C1 and C2. Close with the first thing you would do. Make no claim that you are better than anyone | Persona stem for the Pressure interviewer, asked in the hold-then-concede shape. JD because it scores the whole fit at once |

### F. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through your journey so far." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats, each one of your quoted sentences in your own words: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar, the checklist QA still uses, the monthly retention numbers to the studio head. Answer slot: end with why this role at Saltmarsh, in your own words; the pack has no material on your reasons | The opener is scored even when it is casual. F5, F6, F4 and F7 are the rows it draws on |
| F2 | "What are you playing right now, and what do you notice about how it runs its events?" | CO | [generic] | Name a live game you actually play and one specific thing you notice about its event rhythm or how it communicates with players. Before Friday, spend an hour in a title named in the announcement if you can. If you are not playing a live game right now, say so plainly and name one you would study first | Persona stem for the Rapport builder, aimed at the role's own subject. Generic: the pack knows nothing about what you play |

## Values cheat sheet

Included because Sources 2 documents a values conversation as the second half of the session. The names are Saltmarsh's own (Sources 1).

| Value | Working meaning, paraphrased | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries a conflict. Selection scaffold (B1): pick a time a scheduled drop and what players were experiencing disagreed, with a named signal, what you did and whether the calendar moved. If none comes to mind, say so plainly, then give the nearest thing, F6's calendar: "I ran the weekly content-drop calendar for our main title for the last two years." — your message, or say how you would decide |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence carries it. Selection scaffold (B2): pick a time you had to separate what was built from what was hoped. If none comes to mind, say so plainly, then give the nearest thing, F4: "Wrote the release checklist our QA team still uses." — your message, or say how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." — your message. The beats are the quote's: you wrote it, and QA still uses it. See B3 for the slot |

## Reverse questions

Pick three. Each leaves you less like a candidate and more like a colleague.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live operations from QA. How did that shape what you want a producer's release process to protect?" | Ties to Tobias's own path (section 7) and turns an interview into a conversation about the craft. It also gives F4's checklist a natural place to come up |
| R2 | "Your GDC talk argued that a live team is judged by how often its patch notes describe what actually shipped. How does the team measure that today, and where would this role sit in it?" | Asks about his published theme and the role's place in it. Ask it only if you have read or watched the talk; the pack saw only a search snippet of it |
| R3 | "With Project Larkspur moving to one live-ops group and one calendar, where would this role sit, and which two titles would I be working on first?" | The JD says two of our mobile titles; the announcement names two titles and one calendar. Asking which two shows you have connected them and removes a gap in what the pack knows |
| R4 | "What does the post-event review look like today, and which KPI would you most want this role to change?" | Ties to the JD's own review-and-KPIs line and shows you are thinking about what you would own |
| R5 | "Who would I learn the season-pass and purchase side from in my first month?" | Turns F10 into a plan in front of the interviewer instead of a gap he finds, and gives the C1 plan a named first step |
| R6 | "What would you want to have heard from me by the end of my first ninety days?" | Asks how he will judge you, and the answer tells you what to weight in the first month |

## Sources

Provided documents: the JD text and the background as given in your message. No dossier was consumed.

Searches sent and what came back:

1. "Saltmarsh Games values" returned https://saltmarshgames.com/values
2. "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
3. "Saltmarsh Games strategy news mobile" returned https://saltmarshgames.com/news/project-larkspur (search snippet only, not fetched)
4. "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only, not fetched)

Pages fetched: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet; B1 to B3 use the three names exactly |
| 2. Saltmarsh Games interview process, live operations producer | yes | Established the loop: one 60-minute session with the hiring manager, a tabletop and then a values conversation, so the persona weights and the cheat sheet follow it |
| 3. Saltmarsh Games strategy and recent news | yes | A5, C1's premise and reverse questions R3 and R5; the announcement was seen as a snippet only |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Section 7, B2 and reverse questions R1 and R2; seen as a snippet only |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Confirmation that Friday is the Outage Hour and that Tobias is the manager you would report to → the persona weights stop resting on an assumption, and a different round would restructure the banks
- Your recruiter's prep notes, if any → coverage of any focus area they named that the pack has not assumed
- Which two titles the role covers (one email to the recruiter) → A5, A3 and R3 become specific, and the F1 gap can be stated against the actual titles
- Your answers to the slots in F1, F3, F4, F5 and F7 → those rows gain real sentences from you, and the story maps in D1, D2 and B3 replace slots
- The release checklist itself, or a redacted page of the content calendar → F4 and F6 can move from medium to high, because those are the inspectable artifacts in this field
- Your full CV → rows that now quote your message can quote it, and F2 and F8 may gain evidence
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the full Larkspur announcement, Tobias's talk and any role-family loop reports, replacing the two snippet-only entries in Sources
- A tuesday-dossier.md → verified evidence and constraints on the weak areas carried in from earlier work, if you have one
