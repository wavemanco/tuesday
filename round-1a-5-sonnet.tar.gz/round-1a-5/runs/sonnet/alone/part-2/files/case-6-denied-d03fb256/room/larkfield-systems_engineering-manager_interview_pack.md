# Interview pack: Engineering Manager, Larkfield Systems (three-round loop)

**Candidate:** Yusuf. **Mode:** loop (three scheduled rounds, one shared fit snapshot, one mini-pack per round).

| Round | When | Who and how long | Relationship |
|---|---|---|---|
| 1 | Tuesday | Director of Engineering, 45 min | Hiring manager and your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager, 60 min panel | Technical specialists plus a cross-functional partner |
| 3 | The following Monday | VP Engineering, 30 min | Skip-level; the recruiter's description, as you relayed it, is "values and leadership philosophy" |

Interviewer names were not given, so there is no interviewer read. Persona weights come from relationship priors and from the round descriptions you supplied. Web research was refused in this session, so nothing here comes from Larkfield's own public material (see Sources).

## How to use this pack, and the type key

Personas describe how a question will be asked. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it is scoring |
|---|---|
| VAL | Whether your past behaviour shows values and leadership principles, not generic virtue |
| EXP | Whether what you have said about your work survives scrutiny, and how exactly you attribute it |
| JD | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge, and whether you can think at the company's altitude |
| CASE | A live problem from the actual role: structure and reasoning |

An answer slot is an instruction for the interview, not a question for you now. It names where an interviewer is likely to probe, and it has two honest branches: say what you did, in your own words, or say plainly that it was not yours or did not happen.

## Prep triage

| When | Do this, in this order | Where |
|---|---|---|
| Before Tuesday | 1. Rehearse your answer to the weakest-on-day-one question until it is boring. 2. Say your 90-second journey aloud. 3. Run each of the three cases once aloud, thinking out loud. 4. Settle your honest answers to the four answer slots | A1, C1, B1 to B3, A2 to A4 |
| Between Tuesday and Thursday | 1. Write your own answers to the four defend-the-number slots on the 60% and the 40 interviews. 2. Rehearse the reliability quarter as a story with only its stated beats. 3. Choose your two or three reverse questions per panelist | D1 to D3, F1, F2, Round 2 reverse questions |
| Between Thursday and Monday | 1. Draft your leadership principles, each tied to one thing you did. 2. Time your sixty-second answer. 3. Read whatever Larkfield publishes about itself before the CO question | G1, I1, G2, H1 |

Everything else in the pack is insurance. Anything the Director or the panel tells you about the squads should change your Round 2 and Round 3 answers; send it back and the affected sections can be regenerated.

## Shared fit snapshot

The requirements are quoted from the role description you gave. The evidence column holds your words from your message and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description you gave | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of 6, not two squads, with nothing inspected behind it. Your words stay at that scale: "I was a team lead of 6." Answer slot: the role's two squads makes a probe on what changes at that scale likely. If you have a view from your own work on what changes, say it in your own words; if you do not, say so plainly and stay with the team of 6 |
| F2 | "own delivery" — role description you gave | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Your sentence is about one reliability quarter, not delivery across a roadmap, and the words stay there: "I pushed a reliability quarter through against roadmap pressure." Answer slot: expect a probe on how the quarter got through. If you made the call or the argument, say which, in your own words; if the call was not yours, say so plainly and stay with the quarter. The 60% raises its own defend-the-number slots (D1) |
| F3 | "hiring and growth for 11 engineers" (the hiring half) — role description you gave | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap in kind, but a line with nothing inspected behind it, so expect a probe. Lead with the loop and the count in the quote's own terms. The pack's observation: the count is of interviews, and the loop is for backend roles. Defend-the-number slots on the 40: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours (D3) |
| F4 | "hiring and growth for 11 engineers" (the growth half) — role description you gave | none given | none | [grounded] | discovery | Your material says nothing about growing engineers. Answer slot: the role's "growth" makes a probe likely. If you helped an engineer grow, say who, what you did and what happened, in your own words; if it was not part of your role, or did not happen, say so plainly and say how you would approach it |
| F5 | "partner with hardware and product on roadmap" (the product half) — role description you gave | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Your sentence puts you in a roadmap contest over one quarter; it does not say with whom, or what the partnership looked like. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: expect a probe on how you worked with product around it. If you worked with a product counterpart, say how, in your own words; if the pressure came from elsewhere or there was no product partner, say so plainly and stay with the quarter |
| F6 | "partner with hardware and product on roadmap" (the hardware half) — role description you gave | "I've never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A limit you stated, at its own scope: "I've never owned a hardware-adjacent roadmap." The pack's observation: the role says partner and your sentence says owned, and your material does not say whether you have worked beside a hardware team in any other way. Words: that sentence, then how you would learn it, said as a plan and never as a past. Never a claim to hardware work |
| F7 | "building device-management services" — role description you gave | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | The quote places you in engineering at a payments company; it does not show whether any of that work touched fleets of devices, firmware or remote operations. Answer slot: the role's device-management services makes a probe on your closest technical experience likely. If some of your work was close, say what it was and which part was yours, in your own words; if none was, say so plainly and say how you would get up to speed |

One more sentence of yours sits outside the table because the role description names no requirement for it: "I've never managed managers." It appears in A1 and G2 as a plain acknowledgment, since you stated it.

---

# Round 1: Director of Engineering (hiring manager), 45 min

## Persona table, Round 1

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps: scale, hardware, domain, why move | High. The relationship prior for a hiring manager is Case/Strategist plus Skeptic, and the Skeptic leads here because the Director would own your ramp and your own message names two limits (F1, F6, F7) a would-be boss is paid to derisk. This is a prior for the relationship, not a read of this Director | Rehearse the single most predictable objection until it is boring; build bridges only from what you stated; say the limit plainly, then a concrete plan |
| Case/Strategist | A live problem from the role: ship dates, an inherited team, a hardware-versus-product clash | High. Same prior; in 45 minutes expect one or two, most likely hardware and product both leaning on you | Clarify, objective, options, risks, who you bring in; think aloud; challenge one premise respectfully |
| Conversational | The opener ("walk me through the journey") and the wrap | Medium. Every hiring-manager conversation opens with it, and casual questions are still scored | A 90-second arc told from your own sentences; treat the casual questions as scored |

**Highest-ROI prep in the whole loop: A1.** Some version of "which part of this would you be weakest at" will arrive in all three rounds, and Round 1 is where it is cheapest to get wrong.

## Question bank, Round 1

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Pick one limit, not three, and say it first in your own words: "I've never owned a hardware-adjacent roadmap." Hold it through two follow-ups without hedging, then concede specifically what you do not yet know (how the hardware roadmap is built, who sets its dates) and close with a plan, not a past: what you would learn first, and from whom. Do not slide into "but I can partner" unless you can back it. Answer slot: if any of your own work has put you beside a hardware team, say how, in your own words; if none has, say so plainly and stay with the limit. Never describe hardware work your material does not carry | F6 is where the role's hardware mandate presses on a stated limit, so this objection arrives in some form; JD because it scores the stated requirement, Skeptic because the whole point is the gap |
| A2 | "You've led a team of six. This role is two squads and eleven engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say the scale difference before they do: "I was a team lead of 6." Then the answer slot: if you have a view from your own experience of what changes at two squads, say what and why in your own words; if you do not yet, say so plainly and say what you would ask the Director in the first weeks, such as how the two squads divide the work. If asked about managers, your own words are: "I've never managed managers." Stay with the team of 6 throughout | F1 is the evidence for the squads requirement and the likeliest scale probe from a would-be boss; JD because the headcount is the role's own |
| A3 | "You'd own delivery for both squads. Tell me about a time you owned delivery of something that was at risk." | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | An open prompt, so you choose the instance. Selection criteria: a named stake, the call you made, what you told the people it affected, what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, in the sentence's own words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if delivery of the quarter was yours to decide, say how, in your own words; if it was not, say so plainly and stay with the quarter | F2 carries only one quarter, so this question is where "own delivery" gets tested against thin evidence; JD because the theme is the role's own line |
| A4 | "Tell me about how you've helped an engineer grow." | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | An open prompt from the role's "growth". Selection criteria: one named person, what they were working towards, what you did, what changed for them. Your material does not show whether this was part of your 3 as a team lead of 6, and the pack will not write it for you. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would approach it | F4 has nothing quoted behind it, so the guidance is a scaffold, not a story; JD because "growth" is a stated duty |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "After a release, a share of the devices in the field stop checking in. What do you do in the first hour, and in the following week?" | CASE | [generic] | Structure it aloud: what you need to know first (which devices, which versions, which change), stop the damage (pause the rollout, roll back if the service supports it), who you pull in (the hardware lead, support, product), what you tell people and when, then the following week: cause, what to change so it does not recur. Challenge one premise politely, such as how "stop checking in" is measured. This needs no claim about your past, so the guidance makes none | A live problem from the role's device-management scope (F7), asked as a decision; `[generic]` because it is a pattern for the problem, not a fact about Larkfield's systems |
| B2 | "You inherit two squads. Product wants three features this quarter and one squad is carrying most of the on-call load. Where does your first month go?" | CASE | [generic] | Clarify first: what each squad owns, what is on fire, what the Director expects. Then an objective, how you would sort the three features against the load (evidence from the squads themselves, not your assumptions), what you would say no or not-yet to and to whom, and how you would measure that the first month worked. Think aloud; say the framework before using it. No claim about your past | Tests "own delivery" and the squads requirement as a decision (F1, F2), with no past asserted |
| B3 | "Hardware and product want conflicting things for the same quarter. How do you arbitrate, and who do you take it to?" | CASE | [generic] | Clarify what each side is actually trying to protect (a date, a customer, a safety margin); set out the options with a named cost each; say who decides and what you would bring them. Propose principles for the seam rather than pretending to know Larkfield's: if you have never owned a hardware-adjacent roadmap, your own words are "I've never owned a hardware-adjacent roadmap", which makes asking how it is arbitrated today part of your answer | Hits both halves of "partner with hardware and product" (F5, F6) in one live problem; the stated limit is acknowledged by the guidance, not hidden |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with the beats your sentence states: nine years in engineering, 3 of them as a team lead of 6, currently at a payments company. Then answer slot: your material gives no reason for the move and the pack will not write one. Give your own reason in a sentence or two, tied to something in the role description, such as the device-management services or the hardware and product partnership. Stay with what you did, in the order you did it | The biography question opens most hiring-manager conversations and is scored; F1 is the only evidence it can draw on, so the arc is only as long as that sentence |
| C2 | "Tell me about your hiring loop. You've run a lot of interviews." | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say it in the quote's terms: "I run our hiring loop for backend roles — about 40 interviews last year." Defend-the-number slots, in your own words: how the 40 was counted, what it is sensitive to, the assumption behind it you would defend least, which part was yours. If you do not know how a figure was counted, say so plainly. Do not turn interviews into hires | F3 is the one place your message is strongest against the role's hiring duty, and the figure is a magnet for probes; JD because hiring is a stated duty |

## Reverse questions, Round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What does a good first 90 days look like in this role, and what would tell you at six months that it is going well?" | It turns the conversation to success criteria and shows you plan to be measured |
| R1.2 | "How are the two squads split today, and where is the hardest seam between them?" | It gets you facts about the squads without asserting any, and signals you think about structure |
| R1.3 | "Where does the hardware roadmap meet the software roadmap today, and who arbitrates when they collide?" | It goes straight at your largest stated limit as curiosity, and invites the Director to describe the support you would have |
| R1.4 | "What is the reliability and on-call situation for the device-management services right now?" | It is practical, and it lets you listen before offering anything |
| R1.5 | "What have you seen make new engineering managers struggle here?" | It invites candour and tells you what the Director fears |
| R1.6 | "What will the VP be looking at on Monday that you are not?" | It is a fair question for a would-be boss and gets you ahead of Round 3 |

---

# Round 2: the panel (two staff engineers and a product manager), 60 min

## Persona table, Round 2

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | A staff engineer reading your sentences closely and asking what was counted, changed and decided | High. The technical-specialist prior is Prober plus Pressure, and a panel blends the top personas of each member; with two staff engineers on three seats, the Prober leads. Your message holds two figures (the 60% and the 40) for a Prober to walk to their assumptions | Know what you can and cannot say about how each figure was counted; say plainly when you do not know; name the weakest assumption before they do |
| Peer Evaluator | Where is the seam, what do you need from us, who gets credit | Medium to high. The staff engineers will work beside whoever leads the squads, so this is the collegial form of the same objections | Reciprocity first (what you bring them); propose seam principles, not a pretended seam |
| Values/Behavioral (cross-functional) | The product manager asking for stories about disagreement, saying no, and roadmap partnership | Medium. The cross-functional prior is Values/Behavioral plus Conversational, and the PM is the member most likely to probe the product half of "partner with hardware and product" (F5) | Map a story only where one of your sentences carries it; otherwise a scaffold with its honest branch |

## Question bank, Round 2

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The sentence says the burden dropped after you pushed the quarter through; that is the scope. Slots, in your own words: how the 60% was counted; what it is sensitive to; the assumption behind it you would defend least; which part of the drop was the quarter's work and which part was not yours. If you do not know how it was counted, say so plainly and say what you would check. The pack supplies no method, baseline or attribution, and neither should you | The headline figure of your message, the one a Prober will walk to its assumptions; EXP because it tests attribution |
| D2 | "What did the reliability quarter actually change, and which of it was your call?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Tell the beats the sentence states: a reliability quarter, roadmap pressure against it, you pushed it through, the on-call burden dropped. Answer slot: the probe is to the middle. If you chose the work, say what and why, in your own words; if someone else chose it, or you chose some and not all, say so plainly and stay with what you did. Do not claim more of the quarter than the sentence does | F2 is a single sentence, and staff engineers check whether the person describing the work did it; EXP because attribution is the score |
| D3 | "About 40 interviews last year. How do you know your loop is working?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | The count is the quote's: "about 40 interviews last year." Defend-the-number slots as in C2. Then answer slot: if you have a way of telling whether the loop works, say what it is, in your own words; if you do not, say so plainly and say what you would look at. Do not offer a measure you do not track | F3 turned into the probe a Prober prefers, from a count to a result; EXP because it tests what you can stand behind |
| D4 | "Suppose a device-management service has to cope with devices that are often offline. What would you want your squads to have thought about?" | JD | [generic] | Your material does not show device-fleet work (F7), so do not bluff domain depth. Ask what the failure modes are today, what the last painful incident was, and how rollouts are staged; offer the questions you would ask in the first month and the kind of judgement a manager brings (what to protect, what to stage, who to pull in). Where you reach for your own reliability work, use only its own words, as in D2 | JD for the device-management domain with CASE delivery; `[generic]` because it is a pattern for the problem, and F7 says why the honest answer is questions, not expertise |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where is the seam between an engineering manager and a staff engineer, and what happens when we disagree?" | JD | [generic] | Propose principles, not a map you cannot know: who decides what, how a disagreement is surfaced early, how it is closed, how the relationship survives. For an example from your own work, choose a real disagreement with a technical peer: a named point of disagreement, how it was decided, how you worked together afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The collegial form of the squads requirement (F1); JD because leading squads that contain staff engineers is the role |
| E2 | "What would you need from us in your first month?" | JD | [generic] | Reciprocity framing first: what you would bring them (a protected plan, a clear line to product and hardware), then what you need (the unwritten history, the sharp edges of the services, where they would not want you in the way). Ask them which of the two they would rather you did first. No claim about your past | A peer's way of pricing what the hire costs them; JD because it is a ramp question; `[generic]` because no sentence of yours is needed |
| E3 | "How do you handle credit when work spans a manager and the engineers who built it?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Use the sentence's own "I pushed" for what you did and no more. Answer slot: if you know what others did on the quarter, say so, naming them, in your own words; if you do not, say so plainly. Practise the sentence "I pushed it through; the engineers did the work" only if it is true | Peers test attribution under a collegial front; EXP because it checks the same line as D2 from a different angle |

### Values/Behavioral (product manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When product wants something engineering does not think should ship this quarter, what do you do?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on the one sentence: the roadmap pressure, the reliability quarter, you pushing it through. Answer slot: the PM will ask how you worked with product. If you worked with a product counterpart, say how, in your own words; if the pressure came from elsewhere or there was no product counterpart, say so plainly and stay with the sentence. Never present a product partnership the sentence does not carry | F5 is the one place your material touches the product half of the roadmap requirement; JD because it scores the stated duty |
| F2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | An open prompt. The sentence may carry it: pushing a quarter through against roadmap pressure. It does not say who you told or how it landed. Answer slot: if you told someone senior something unwelcome, say who and how it landed, in your own words; if not, say so plainly, then give the nearest thing your material carries or how you would handle it. Choose a story in which the hard truth actually landed, and do not supply an ending | A standard values and behavioural probe from a cross-functional interviewer; VAL because it tests behaviour, and the pack does not know Larkfield's published values |
| F3 | "How would you want product, hardware and your squads to run roadmap conversations?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap" | Propose principles: who is in the room, how asks arrive, how a date is challenged, how a no is delivered. Your own words for the limit: "I've never owned a hardware-adjacent roadmap", then ask the PM how it works today, as curiosity and not as a dodge. Never describe a hardware roadmap process you have run | Probes the role's roadmap-partnership duty from the PM's seat (F5, F6) and gives you a way to state the limit once, cleanly |

## Reverse questions, Round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What is the thing about the current release or on-call process you would change first?" | The staff engineers hold the real answer, and asking signals you listen before acting |
| R2.2 | "Where does the squads' technical direction get decided today, and where would you want a manager in it or out of it?" | It names the seam, for a peer audience, as a question, not a claim |
| R2.3 | "What could a new engineering manager do in their first month that would genuinely help your work?" | The reciprocity question for a peer audience |
| R2.4 | "How are priorities set between product asks and hardware dates today, and where does it hurt?" | For the PM: it goes at your stated limit as curiosity and shows the product half matters to you |
| R2.5 | "What does a good partnership between product and engineering look like to you, and what is the most common way it breaks?" | For the PM: it invites a story you can then answer with your own |
| R2.6 | "What is one thing you would want a new manager to leave alone?" | It asks the panel for a boundary and shows you will respect one |

---

# Round 3: VP Engineering, 30 min

## Persona table, Round 3

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Leadership philosophy and values questions asked for evidence in past behaviour | High. The skip-level prior is Case/Strategist plus Pressure, but the recruiter's description, as you relayed it, is "values and leadership philosophy", which a loop source (your own words) makes the heavier signal; this raises Values/Behavioral above the prior. The pack has no published Larkfield values, so the questions are themed on that description, not on named values | Map a story to each principle only where one of your sentences carries it; otherwise a scaffold with its honest branch; "we" for context, "I" for what you did |
| Case/Strategist | One question at the VP's altitude: where engineering is going, how software and hardware plan together | Medium. The prior still applies, but 30 minutes leaves room for one | Think aloud at the right altitude; do not recite what any prepared candidate would say; say what you do not know about Larkfield |
| Pressure | A time-boxed challenge: why you, how much of that was you | Medium. The prior for an executive; 30 minutes makes a sixty-second challenge likely | Pause, restate, hold a challenged position through two follow-ups, concede specifically |

In 30 minutes expect roughly five or six questions. Rehearse G1, G2 and I1 first.

## Question bank, Round 3

### Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What is your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" and "I run our hiring loop for backend roles — about 40 interviews last year" | State two or three principles in your own words, each with the one thing you did that shows it. Two sentences of yours can carry one each: the reliability quarter, and the hiring loop. Use their own words. The pack will not write your philosophy; name only a principle your behaviour shows. Answer slot: if a principle has nothing you did behind it, say it as something you are working towards, plainly, not as a record | Executives score whether a philosophy is backed by behaviour; VAL because that is the scored thing |
| G2 | "How do you think about leading through other leaders rather than directly?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Your own words, at their scope: "I've never managed managers." Then a plan, said as a plan and never as a past: what you would learn first, whom you would ask, and what you would hold yourself to. Answer slot: if you have led through others in any form, say how, in your own words; if not, say so plainly and stay with the plan. Do not describe managing managers | The VP is the one person likely to test the next rung of your ladder; VAL because it is a leadership question and the limit is one you stated |
| G3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | An open prompt from the standard values stems. Selection criteria: a named customer or user need, the internal metric it cut across, the call you made, what it cost, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. The pack carries no story for this one | Executives asking about values commonly use this stem; `[generic]` because no sentence of yours carries a customer story |
| G4 | "Tell me about a time a hire, or a decision not to hire, taught you something." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | An open prompt from the role's hiring duty. Selection criteria: a named decision, what you saw, what you would do differently now. If the decision was not yours, say so plainly and tell it as what you saw. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, in the sentence's own words: "I run our hiring loop for backend roles." Do not turn interviews into hires | Hiring is a stated duty (F3) and a values topic for any VP; VAL because it asks what you took from it |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Where should engineering be at a company of this size in two years, and what is your part in it?" | CO | [generic] | Research was refused here, so the pack knows nothing about Larkfield's strategy. Do not recite anything you have not read; if you have read Larkfield's public material by Monday, bring one point and one divergence with a reason. If not, say what you would want to understand first (customers, hardware cadence, where reliability hurts) and what you would do in your own scope. State plainly what you do not know about their strategy | CO at the VP's altitude; `[generic]` because the pack could not read any Larkfield material, and the upgrade menu says what would change that |
| H2 | "How should a software team and a hardware team with different release rhythms plan together?" | CASE | [generic] | Structure: what each rhythm protects, what has to be fixed and what can flex, how dates and dependencies are shared, how a slip is surfaced early, who decides. Say the principle first and the mechanisms second. If you reach for your own experience, you have none in your material on hardware planning (F6): use your words, "I've never owned a hardware-adjacent roadmap", and keep the answer as principles | The role's hardware seam at the VP's altitude; CASE because it is a live design problem |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" and "I've never managed managers and never owned a hardware-adjacent roadmap" | Pause and restate. Hold two things in their own words: the hiring loop, and the reliability quarter. Concede the limits specifically before they do: "I've never managed managers" and "I've never owned a hardware-adjacent roadmap". Hold through two follow-ups; never argue the limits are irrelevant. Answer slot: if you have a third thing that is not in your material, say it plainly in your own words and stay inside what you did | A standard time-boxed executive challenge; JD because it scores fit against the role |
| I2 | "Your on-call burden dropped 60%. How much of that was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the sentence: it dropped after you pushed the quarter through. Concede specifically: say which parts of the drop you know were the quarter's work and which you cannot attribute. If you do not know how it was counted, say so plainly. Do not claim the whole figure and do not disown it | The attribution probe in its pressure form (the Prober's form is D1); EXP because it tests candour about credit |

## Reverse questions, Round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "Is there a decision you made as VP that you would point to as showing how you lead?" | It invites a story on the round's own topic and gets you the philosophy you are being scored against |
| R3.2 | "Where does engineering management at Larkfield most need to grow over the next two years?" | It shows altitude and tells you what the role is really for |
| R3.3 | "How do you think about the balance between hardware-driven dates and software reliability?" | It goes at the seam you have no experience of, at the right altitude, as a question |
| R3.4 | "What have you seen separate the managers who thrive here from those who do not?" | It invites candour and hands you a target |
| R3.5 | "What would you want me to have learned or changed by the end of six months?" | It converts the interview into a shared goal |

---

# Shared sections

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and gives the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads, or managed 11 engineers | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation: your material says a team lead of 6, not two squads |
| Managed managers, or led through other leaders | A negative you stated, the half of F6's source sentence about managers | The plain acknowledgment from your own sentence: "I've never managed managers." A2 and G2 give the plan, never a past |
| Owned or co-owned a hardware-adjacent roadmap | A negative you stated, F6 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot widens it into hardware work |
| Hired about 40 engineers, or owned the hiring decisions | Inflated form of F3 | F3's quote at its own scope: "about 40 interviews last year". The limit is the pack's observation: the count is of interviews, not hires, and the sentence says you run the loop, not that you make the calls |
| Cut the on-call burden by 60%, or reduced pages or incidents by 60% | Inflated form of F2 | F2's quote at its own scope: the burden "dropped 60% after I pushed a reliability quarter through". The limit is the pack's observation: the sentence says burden, not pages or incidents, and says dropped after, not that you cut it |
| Owned delivery across a roadmap | Inflated form of F2 | The quote at its own scope: you pushed one reliability quarter through. A3's slot stays inside the quarter |

## Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| Lead two squads building device-management services | A2, B2, D4, E1, H2 | A2 and D4 are the JD-tagged questions; the rest are cases |
| Own delivery | A3, B2, B3, F1 | A3 and F1 are the JD-tagged questions |
| Hiring | C2, D3, G4 | C2 is the JD-tagged question |
| Growth | A4, G2 | A4 is the JD-tagged question; G2 is the leadership-philosophy form |
| Partner with product on roadmap | B3, F1, F2, F3 | |
| Partner with hardware on roadmap | A1, B3, F3, H2, I1 | |
| The 60% figure | D1, I2 | Defend-the-number questions |
| The 40 interviews figure | C2, D3 | Defend-the-number questions |
| Company strategy | H1 | Generic: research was refused; no other CO question is written |

## Sources

Provided documents: the role description and your background statements in your message. Nothing else was read. No dossier was present.

Searches sent (all refused, none returned anything):

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Every call was refused. It would have fed a values cheat sheet; none was written, since no published values are in hand |
| 2. Larkfield interview process for this role family | unavailable | Every call was refused. The loop in this pack comes from your own words (three sessions, who runs each), which establish it; the search would only have added documented formats |
| 3. Larkfield strategy and recent news | unavailable | Every call was refused. It would have grounded H1 and the case questions; they are labelled generic |
| 4. Interviewer name and company | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. Representative Engineering Manager JD | unavailable | Search permission was refused on the three calls above and no fourth was sent. It would have added requirement rows from a typical posting, labelled inferred |

## Upgrade menu

- The full JD text → the fit snapshot's four quoted requirements grow to the JD's own list, mid-list items get JD-tagged questions, and the coverage table gains rows
- A CV or a list of your roles → the fit snapshot draws on more than the four sentences of your message; story-mapped guidance replaces the scaffolds in A4, E1, F2, G3 and G4
- Your answers to the answer slots in A1 to A4, D2, E3 and F1 → each answer you give enters the fit snapshot as quoted evidence and upgrades rows F1, F2, F4, F5, F6 and F7, and the guidance that draws on them
- The source of the 60% (for example the paging or incident counts before and after) and your hiring-loop document or scorecard → the F2 and F3 confidence can rise from medium to high, and the defend-the-number slots can be answered from fact
- Interviewer names for all three rounds → an interviewer read, persona weights from their public footprint, and a reverse question tied to each interviewer's own path
- The recruiter's notes on the panel format or any exercise → a build section for any declared deliverable, and persona weights that rest on a stated format
- Permission to run web search → Larkfield's published values (and a values cheat sheet if it publishes any), documented loop structure, and a strategy brief that would turn H1 and the case questions from generic to grounded; one deeper research pass (up to 6 further searches and 2 further fetches, several more minutes) can be offered once research is allowed
- A dossier of verified evidence (tuesday-dossier.md) → confirmed evidence in place of the inferred rows, and a list of claims the pack must never coach
