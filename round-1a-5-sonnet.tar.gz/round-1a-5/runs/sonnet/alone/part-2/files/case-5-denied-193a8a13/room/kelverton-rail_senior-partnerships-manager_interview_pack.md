# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your POV on operator partnerships over the next 18 months, no slides. Remaining time: Q&A, with Ross pushing on commercials.

**Built on:** your message and the recruiter's email only. No web research ran (see Sources), so company-specific questions are labeled `[generic]` and the market report is not used, because I have not seen it.

## 2. How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Past behavior against the company's published values (none are used here: no values round is documented) |
| EXP | Whether your own claims survive scrutiny, and what was actually you |
| JD | The role's stated requirements, including your gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, scored on structure |

Guidance is scaffolding for a spoken answer, not a script. Where it says "answer slot", the content has to come from your own experience, and "I did not do that" is a fully acceptable branch.

## 3. Prep triage (four hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 90 min | Build the POV and say it aloud against a clock three times | Section 5, A4 |
| 2 | 50 min | The objection cluster, aloud, with each follow-up. This is the highest-ROI prep in the pack | C1, D2, B2 |
| 3 | 40 min | Write your own answer to the four number slots (how counted, what it is sensitive to, the assumption you would defend least, which part was yours) for each figure | B1, B3, D1 |
| 4 | 30 min | Talk through the case structures out loud | A1, A2, A5, B4 |
| 5 | 20 min | The 90-second arc and your reverse questions | F1, R1, R2, R6 |

Everything else is insurance.

## 4. Fit snapshot

No JD was supplied. Requirements come from the recruiter's own words, quoted; two role-family rows are plain prose with no source. No row is a gate: nothing in your material or the recruiter's words states a term such as location, authorization or pay.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material carries a partner channel, not operator partnerships, with nothing inspected behind it. Words: "For the last four years I ran the ISV channel at a payments company." Answer slot: the recruiter's ask makes a probe on how that carries to operators likely. If any of the channel's partners resembled operators, say how, in your own words; if there is no such parallel, say so plainly and stay with the channel |
| F2 | "what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Words stay at the quote's scope: "I spent five years in transport consulting, in bus and light rail network planning." "The other side" can be heard two ways, so say which side you meant. Answer slot: expect a probe on which operators and in what capacity. Say who the work was for and what contact you had with operators, in your own words; if the work did not put you in contact with train operators, say so plainly and stay with bus and light rail |
| F3 | "Ross will push on commercials." — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure stays at its own scope, with the word "influenced" kept. Answer slot: expect how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words, with "I don't know how that part was counted" an honest branch. Answer slot: if any commercial terms with partners were yours to set or negotiate, say which and how you decided; if none were, or they sat with someone else, say so plainly and stay with influenced revenue |
| F4 | carry a revenue number (role-family requirement, no source supplied) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota; what I had was influenced revenue." Then how you would learn the number, said as a plan and never as a past |
| F5 | sell into the rail sector (role-family requirement, no source supplied) | "Never sold into rail specifically" — your message | none | [grounded] | capability | You have stated this gap. Words: "I've never sold into rail specifically." Then the ramp plan, said as a plan. Nothing added to make the gap feel smaller |
| F6 | grow a partner portfolio (role-family requirement, no source supplied) | "took it from 6 partners to 40" — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, and "took it" can be read as yours alone or shared. Lead with the record in your own terms: "I ran the ISV channel and took it from 6 partners to 40." Expect a probe on which part was yours |
| F7 | deliver a 15-minute POV with "no slides needed, just talk us through it" — recruiter's email | none given | none | [grounded] | discovery | Your material says nothing about presenting a point of view to a panel. Answer slot: if you have done something like it, say where, in your own words; if not, say so plainly. The preparation is saying it aloud to a clock, which is practice and not a claim about your past |

## 5. Graded deliverable: the 15-minute POV

**What was asked, in the recruiter's words:** "where you'd take our operator partnerships over the next 18 months"; "no slides needed, just talk us through it"; "Please land on what it means for the operators themselves."

**What you can stand on about yourself** (use as short credibility lines, never as claims about operators):
- F1: "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message
- F6: "took it from 6 partners to 40" — your message
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message

**What I cannot supply:** the market report's contents. The theses below are structures. Test each against your own reading of the report before you commit to it.

**Three theses, each with the concession you must make out loud.** Pick two, or all three if timing allows.

| Thesis | What you would argue | Mandatory concession |
|---|---|---|
| T1 Depth before breadth | Choose a few operators and go deep before adding more, with criteria you would state aloud for choosing them | It narrows the pipeline, and you cannot see from outside which few to pick, so the criteria are yours and the names need their account data |
| T2 Operator result as the unit | Agree with each operator the one or two results that would show the partnership is working, and report on those | Those results are the operators' to define, so the plan starts with listening, and you are proposing a method, not an answer |
| T3 Sequence the 18 months | Diagnose the current book first, prove the approach with a few operators, then scale what worked | Gating scale on proof makes the plan slower than a growth-first one, and you accept that cost |

**Differentiation.** The report is equally available to both interviewers, so reciting its shortlist scores as homework. Bring one item from the report to show you did the reading, name the one finding you would weight differently and why, then give the anti-pick: one kind of partnership you would say no to, stated as a criterion (for example, any partnership where you cannot name the operator result it moves) and not as a cut you cannot see from outside.

**The close the recruiter asked for.** Finish on operators. Write one sentence an operator would say unprompted if the plan worked, then two concrete things that are different for them at month six and month eighteen. Check that each could be heard from an operator's mouth and not from ours.

**Suggested shape for 15 minutes:** 2 min framing (the question you are answering, and that you are working from outside, so these are hypotheses); 9 min for two or three theses with concessions; 3 min on what it means for operators; 1 min on what you would test first once inside. Signpost aloud, since there are no slides ("three things, then what it means for operators").

## 8. Persona table

The loop is established by the recruiter's words: one 60-minute panel, 15 minutes of POV, then Q&A. No source documents a values round, so none is assumed. No interviewer profile exists, so weights come from relationship priors and the recruiter's note.

| Persona | How it shows up here | Questions | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Deepa follows up the POV with live problems on the role | 5 | High: future manager (hiring-manager prior), plus a POV that invites case follow-ups | Clarify, structure, one challenged premise per case (A1 to A5) |
| Data-Driven Prober | Ross on commercials and your two figures | 5 | High: the recruiter said "Ross will push on commercials", and you carry two headline figures | Know what you can and cannot say about each figure and say plainly where you do not know (B1 to B5) |
| Skeptic | Deepa on the two gaps you have stated | 4 | High: hiring-manager prior, and F4 and F5 are the obvious targets | Rehearse the single most likely objection until it is boring (C1) |
| Pressure | Time-boxed or devil's-advocate versions of the same two objections | 3 | Medium: commercial directors often press, but nothing in the recruiter's note says so | Pause, restate, hold through two follow-ups, concede specifically (D1 to D3) |
| Peer Evaluator | Ross on the Partnerships and Commercial seam | 2 | Medium-low: both teams meet the same operators, but Ross is not a peer by title | Offer seam principles, not a pretended seam (E1, E2) |
| Conversational | The opening "walk us through" and "what drew you" | 2 | Medium-low: the POV takes the first 15 minutes, so the opener may be short | A pre-scripted 90-second arc, treated as scored (F1, F2) |

## 9. Question banks

### A. Case/Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "An operator you've been courting says it likes the idea but won't commit before its next budget cycle. What do you do with the next six months?" | CASE | [generic] | Structure it aloud: what you would ask first (who decides, what would make a yes easier), what you would do in the gap that keeps the operator's interest, and how you would know by month six whether to keep going. The question needs no claim about your past, so the guidance makes none | A live problem in the shape of the role; scores clarifying before structuring. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "How would you choose the first few operators to go deepest with? What do you need to know first?" | CASE | [generic] | Clarify what "deepest" buys (revenue, feedback, references), then give criteria, not names, since you cannot see the book from outside. Name the assumption in your criteria you would defend least, and concede that the choices need their data | T1's natural follow-up, so it is likely if you argue depth. CASE because it scores structure |
| A3 | "What do you see as the biggest risk to our operator partnerships over the next 18 months?" | CO | [generic] | Use your own reading of the report: the risk it ranks first that you agree with, then one you would add or weight differently, labeled as your hypothesis. Assert nothing about Kelverton's current numbers; you have read the report, not the internal figures | No research ran and I have not seen the report, so this is a method, not a grounded answer |
| A4 | "In plain terms, if your plan works, what is different for an operator?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer in one sentence an operator would recognise, then two concrete differences. Answer slot: if asked how you know what operators want, say what contact you had with operators and in what capacity, in your own words; if the knowledge is more general than that, say so plainly and stay with bus and light rail | The recruiter named this as the required close of the POV, so it is the graded part of the 15 minutes. JD because it scores the stated deliverable; F2 is the evidence it will test |
| A5 | "What would you stop, or say no to, in how we work with operators today?" | CASE | [generic] | The anti-pick: state the criterion you would apply rather than an item you cannot see. Concede openly that specific cuts need internal data, and hold the criterion through one follow-up. No claim about your past | A role that includes saying no is scored on judgment, and departing from the consensus is what differentiates. CASE because it scores reasoning under limited information |

### B. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Answer the four slots from what you know, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least (say it before he does), and which part was yours. Keep the word "influenced". Say the period if you know it; if you do not, say so. "I don't know how that part was counted" is an honest answer | F3 is the headline figure, and quantified claims are where probers start. EXP because it tests attribution |
| B2 | "You say influenced. Where does influenced end and sold begin?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" | Open with the sentence you can say truthfully: "I've never carried a direct quota; what I had was influenced revenue." Answer slot: say what counted as influenced at your company, in your own words; if you do not know the rule, say so plainly. Hold through two follow-ups by returning to the sentence above, never by adding to it | F4 states the negative, and this is the first place a commercial push lands. EXP with JD content |
| B3 | "You went from 6 partners to 40. What counts as a partner, and which part of that was yours?" | EXP | [grounded] "took it from 6 partners to 40"; "running the ISV channel" | Say how a partner was counted, in your own words, and say plainly if you do not know or if it was contested. Answer slot: which part was yours. If the growth was shared, say so plainly and return to "I ran the ISV channel" | F6 is the second headline figure and "took it" admits two readings. EXP because it tests what was actually yours |
| B4 | "What commercial terms would you offer an operator partner, and what would you hold back?" | CASE | [grounded] "roughly £4M of influenced revenue" | Clarify what you are buying from the partner (adoption, a reference, product input), then principles, not terms, since you do not have their price book. Concede that terms need Commercial's input and frame it as building it with Ross. Answer slot: if any commercial terms with partners were yours to set or negotiate, say which and how you decided; if none were, or they sat with someone else, say so plainly and stay with influenced revenue | The recruiter said commercials will be pushed (F3). CASE delivery of a JD-style requirement |
| B5 | "What would you show me after 90 days to prove the operator partnerships are paying back?" | CASE | [generic] | Propose two or three measures, at least one from the operator's side and one commercial, and name the assumption you would defend least. Concede that the measures would be agreed with Ross's team. No claim about your past | Tests whether you can talk about return at the commercial director's altitude. CASE because it asks for a structure |

### C. Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail and haven't carried a quota. Why would this role work for you?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **The highest-ROI prep in this pack.** Three beats. (1) Acknowledge in your own words: "I've never sold into rail specifically, and I've never carried a direct quota; what I had was influenced revenue." (2) Hold only what the quotes carry: you ran the ISV channel, it went from 6 partners to 40, and you spent five years in bus and light rail network planning. (3) Concede the limit specifically and give a ramp plan said as a plan: what you would learn first and from whom. Follow-up 1, "influenced isn't sold": return to beat 1, do not stretch it. Follow-up 2, "bus and light rail isn't train operators": answer slot, if any of the consulting work was for or with train operators, say what; if none was, say so plainly and stay with bus and light rail. Follow-up 3, "why you over someone who has done both": concede that such a candidate may exist and say what you would do in the first 90 days | F4 and F5 are the two gaps you stated, and the future manager will probe them in some form. JD because it scores the stated requirement, with the deepest ladder because the material is thinnest exactly here |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Choose from the two limits you have already named, say which would matter more to this panel, state it plainly, then the first step you would take. Do not answer "none", and do not introduce a third weakness you have not thought through | A standard Skeptic stem that rewards calibrated candor. The answer is bounded by F4 and F5 |
| C3 | "Walk us through why now, and why rail." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Give your actual reason in your own words, one you would still give after two follow-ups. If the reason is the operator world, point to your own sentence and say which side "the other side" was. If part of the honest reason is wanting a change, say that | Motivation consistency is scored here, and the material states no reason, so the guidance is an instruction and not a supplied answer. EXP because it tests whether your story survives cross-examination |
| C4 | "How long before you're useful to an operator, and what do you do in the meantime?" | CASE | [generic] | Give a number of weeks you would stand behind, your own, and say what the first conversations would aim to learn. Concede it is a hypothesis. No claim about your past | The ramp plan C1's third beat promises, asked as a live problem |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: how much of that £4M was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue"; "running the ISV channel" | Pause and restate. Hold on two facts: "I ran the ISV channel. The figure I gave you is influenced revenue, roughly £4M." Concede specifically: say which part you cannot claim, if any, and if you do not know exactly how much was yours, say so plainly. Return to the same two facts through two follow-ups | The attribution stem in its pressure form. F3 is the figure it will test |
| D2 | "We need someone who can carry a number. Why not hire someone who already has?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Concede first and specifically: "I've never carried a direct quota; what I had was influenced revenue." Hold on what your quotes carry and do not argue that you have effectively carried one. You can ask back what the number would be and how it is built here. If pushed that influenced revenue is soft, return to the B2 sentences | Tests composure on F4. JD because it scores the stated requirement, delivered under pressure |
| D3 | "Your plan is eighteen months. What happens to it if an operator you're counting on pulls back in month six?" | CASE | [generic] | Say what you would re-plan and what stays, concede the uncertainty plainly, and hold your position on the rest. No claim about your past | Tests whether you hold a position without becoming defensive |

### E. Peer Evaluator (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and Commercial will both be in front of the same operators. Where's the seam, and what happens when we disagree?" | JD | [generic] | Offer principles, not the seam itself: one owner per operator conversation, shared notes, disagreements settled before the meeting. Concede that you would learn the real seam in the first weeks, and say what you would ask Ross for. No claim about your past | A seam question between adjacent teams, from the commercial seat. JD because it tests the role's working relationships |
| E2 | "Tell me about a time work spanned teams and credit was shared. How did you handle it?" | EXP | [generic] | Pick an instance that has a named tension, your own part, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing is the Peer Evaluator's stem, and partner-influenced revenue invites it |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk us through your journey. What's the thread?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc with only the beats the quotes carry: nine years in partnerships, the last four running the ISV channel at a payments company, and five years in bus and light rail network planning. Tell the order as it actually ran. Answer slot: the thread between them is yours to state; say the real one in your own words, and if there is none, say so and stay with the facts | The opening biography question is scored even when casual. EXP because it tests the CV's story |
| F2 | "What do you know about us, and what drew you to Kelverton?" | CO | [grounded] "they sell scheduling software to train operating companies" — your message | Start from what you said you know: Kelverton sells scheduling software to train operating companies. Add one point from the report and your own take on it. Do not recite the report | CO with no research behind it, so the guidance is a method. The report is the only strategy source and I have not seen it |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, A5, D3, Section 5 |
| "what it means for the operators themselves" | A4, C4 |
| "Ross will push on commercials." | B1, B2, B4, B5, D1, D2 |
| carry a revenue number (role-family) | B2, C1, C2, D2 |
| sell into the rail sector (role-family) | C1, C2, C3 |
| grow a partner portfolio (role-family) | B3, F1 |
| a spoken 15-minute POV | Section 5 |
| working across teams (role-family, not stated by the recruiter) | E1, E2 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To both: "What would make you say in twelve months that this was the right hire, for operators and for the commercial case?" | You get the scorecard, and you show you think at both their altitudes |
| R2 | To Ross: "Does this role carry a revenue number, and if so how is it built?" | He said he will push on commercials, so this puts your stated gap on the table on your terms and tells you the real bar |
| R3 | To Deepa: "Which operator partnerships are working best today, and what do they have in common?" | It shows what good looks like inside, and it tests T1's criteria against their view |
| R4 | To Ross: "Where do Partnerships and Commercial split a deal with an operator today, and where does it get awkward?" | It turns E1's seam question into your question, and shows you expect to work with his team |
| R5 | To Ross: "What is one thing a new partnerships hire could do in their first month that would make your team's job easier?" | A reciprocity question that shifts from what you need to what you bring |
| R6 | To both: "Since the strategy team's report last quarter, what has moved that most changes the operator picture?" | It shows you read the report, and the answer tells you which parts of your POV to lean on. Pick your own finding to anchor it before Tuesday |

## 13. Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or knows train operating companies from the inside | Negative you stated, F5, and inflated form of F2 | "I've never sold into rail specifically." F2's quote at its own scope: bus and light rail network planning. The limit is the pack's observation: your material says bus and light rail, not train operating companies |
| Has carried a quota or a revenue target | Negative you stated, F4 | "I've never carried a direct quota; what I had was influenced revenue." |
| Closed, booked or sourced £4M | Inflated form of F3 | "roughly £4M of influenced revenue", with "influenced" kept. Your material gives the figure and not what part was yours |
| Personally recruited the 34 additional partners | Inflated form of F6 | "I ran the ISV channel and took it from 6 partners to 40." Your material says you ran the channel, not who signed each partner. B3's slot stays inside that scope |
| Operator-side or operations-side experience at a train operating company | Inflated form of F2 | F2's quote at its own scope, with "the other side" explained in your own words |

## 14. Sources

**Provided:** your message (background and the recruiter's email, quoted in it). The market report you mention was not in my context, so it was not read and nothing in the pack is drawn from it. No dossier was present.

**Searches sent (all refused, search permission not granted, nothing returned):**
- "Kelverton Rail values": refused
- "Kelverton Rail interview process partnerships manager": refused
- "Kelverton Rail scheduling software train operating companies strategy news": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Search refused. It would have decided whether a values cheat sheet applies; none is built, and no source documents a values round |
| 2. Interview process | unavailable | Search refused. The recruiter's words establish this loop, so persona weights stand on them; reports of this company's panel style would have sharpened the weights |
| 3. Strategy and recent news | unavailable | Search refused. It would have grounded A3 and F2, which are labeled `[generic]` |
| 4. Interviewer names | unavailable | Both searches refused. The interviewer read is absent and no reverse question is tied to either person's path |
| 5. Representative JD | unavailable | No search sent: permission was refused on the other five calls and I did not retry. It would have moved the JD-derived rows in the fit snapshot, now plain prose |

## 15. Upgrade menu

- Search permission, then re-run at L1 → values, interview-process reports, recent strategy and each interviewer's public footprint, which would turn A3 and F2 from `[generic]` to `[grounded]` and add an interviewer read and a reverse question tied to each person's path
- A deeper research pass (offered once) → up to 6 more searches and 2 more fetches, several more minutes, giving a strategy brief of the company's competitive set and recent org context for the CO bank
- The JD text → the two role-family rows F4 and F6 become sourced rows, and any mid-list requirement I have not covered gets a question
- The market report's headline recommendations, pasted → a grounding brief, sharper differentiation in Section 5, and A3 and F2 rebuilt on it
- A document showing how the £4M of influenced revenue was counted → F3 could move from `medium` toward `high`, and B1's slots would have your own method to rest on
- One email to the recruiter: does the role carry a revenue number, and have the panel read the market report → settles R2 and the premise of the POV's differentiation
- Deepa's and Ross's public profile text, if you can find it → persona weights and an interviewer read
- A `tuesday-dossier.md`, if you have one → verified evidence and prohibited claims that would tighten the guidance cells
