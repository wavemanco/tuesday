# Interview pack: Product Manager, Platform APIs at Quartzline

Hiring-manager conversation, 45 minutes, Thursday. The interviewer's name was not given. Built on your underwriting dossier (`handoff_to_mock_interview` and `role_profile`); no company research ran (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims on your record survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question to you here. Decide your honest branch before Thursday.

## Prep triage

1. Rehearse A1 aloud, with both follow-ups, until the concession and the hold feel boring. The underwriter named this objection, so it is the highest-ROI prep in the pack. F6 is its time-boxed twin.
2. Re-read your integration playbook and settle what you can truthfully say about how the 30+ was counted (C3, D1), and what survives of the roadmap-input sessions (D3, F2).
3. Choose your honest branch on the answer slots in A3, A4, B5 and D2.
4. Practise reverse questions 1 and 2. They are the two risks the underwriter left open.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD via dossier R1 | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier R1; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R1 | low | [grounded] | transferability | The underwriter's condition: position this as adjacent, never as PM experience. Words stay at the quotes' own scope. The pack's observation: your material shows input into a roadmap and delivery of integrations, not the title or years in the job. The roadmap-input claim is confirmed with limited inspectable proof, so volunteer that limit before a prober extracts it. Answer slot: expect a probe on the distance between the JD's years line and your background; say plainly that your background is adjacent, then name which part of the two quoted sentences is closest to the job; if none is, say so and stay with the two sentences |
| F2 | "Own the roadmap for the partner-facing API platform" — JD via dossier role_profile; the dossier's `acknowledge_gap` area is "Owning a roadmap and prioritization authority (R1 sub-claim)" | none given | none | [grounded] | capability | Words come only from the dossier fields `uncertain_or_weak_areas` (acknowledge_gap) and `prohibited_claims`: "I haven't owned a roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan said as a plan, never as a past. No bridge and no slot here |
| F3 | "Shipped API or platform products" — JD via dossier R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R2 | low | [inferred] | transferability | The dossier carries no grade for R2, so this one is the pack's own: the quote reaches API work, not the product itself. The pack's observation: your material says integrations of the vendor's REST APIs, not shipping the API or platform. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the JD's line makes a probe on what you shipped likely; if any of that work changed what the vendor's API did, say what and which part was yours; if none did, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — JD via dossier R3, important | "Wrote the internal integration playbook her team uses" — dossier R3; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R3 | medium | [inferred] | discovery | The pack's own grade. The quotes touch the requirement (a written playbook, an architecture stage) without showing whether they reach docs or schemas. Answer slot: if the playbook or the integrations had you reading or writing the API's documentation, or working from its schemas, say what and how, in your own words; if they did not, say so plainly and stay with the playbook and the architecture stage |
| F5 | "Stakeholder management across engineering, sales, customers" — JD via dossier R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R4; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier R4 | medium | [inferred] | transferability | The pack's own grade. The quotes reach the client side and the hand-off of client evidence to product; they do not show engineering or sales. Answer slot: expect a probe on engineering and sales; if any of those integrations put you across either, say who and which part was yours; if not, say so plainly and stay with the client-facing work and the sessions |
| F6 | "Agile delivery experience" — JD via dossier R5, preferred | none given | low | [grounded] | discovery | The underwriter's strategy is `clarify`. Nothing in the verified evidence speaks to this requirement, so no story is mapped. Answer slot: the JD's "Agile delivery experience" line is the interviewer's likely probe; if you worked in an agile cadence, say what it was and your part in it; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline's squads define it |

## Persona table

No interviewer profile and no documented Quartzline loop were available, so the weights come from the round-type prior: for a hiring manager, Case/Strategist and Skeptic dominate. The loop falls back to the Generic archetype (flat tilt), which adds nothing.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Skeptic | Quiet, persistent probing of the title and roadmap gap | Highest. The prior puts it first for a hiring manager, and the underwriter named a specific objection from this gap | Rehearse A1 until it is boring; concede the sourced negatives plainly; hold only what the quotes carry; bring a ramp plan |
| B Case/Strategist | Live problems on the partner API platform | Highest. The prior puts it first; the JD's responsibilities (roadmap, discovery, specs, adoption) are all case-able | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; ask who decides |
| C Conversational | Opening "walk me through the journey" and casual probes | Medium. A 45-minute conversation usually opens this way, and casual questions are still scored | A 90-second arc built from your three quoted sentences |
| D Data-Driven Prober | Pushes on the headline figure and on proof | Medium. The 30+ figure is a magnet, and the roadmap-input claim is medium confidence with limited proof | Say how it was counted, or say plainly you do not know; volunteer the proof limit |
| E Peer Evaluator | The seam with the two squad leads | Low for a manager round, but the JD puts you across two squads and the underwriter left decision authority unresolved | Propose seam principles; do not pretend to know the seam |
| F Pressure | Time-boxed "why you over a PM with three years" | Low. Possible as a test of the A1 answer | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `likely_interviewer_objections` (the underwriter's wording); `prohibited_claims: "Having held a product manager title or role"`; `prohibited_claims: "Having owned a product roadmap"` | The deepest rehearsal in the pack. Concede first and plainly: "I haven't held a product manager title or role, and I haven't owned a roadmap." Then the adjacent case at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live," and "I ran quarterly roadmap-input sessions feeding client evidence to product." Say the limit before they do: this is adjacent work, not product management. Then a ramp plan in your own words: what you would learn first, from whom, by when. Follow-up 1, "A roadmap-input session isn't owning a roadmap — what did you decide?": hold on what you ran and fed in, concede that the roadmap was not yours, and do not add outcomes. Answer slot: the JD's roadmap line makes a probe on what those sessions led to likely; if you know what came of any session, say what and which part was yours; if you do not know, or nothing did, say so plainly and stay with what you ran. Follow-up 2, "So you'd be learning the job on our time?": concede specifically, since the title, roadmap ownership and prioritization authority are new to you, hold the two quoted sentences, and ask the decision-authority question (reverse question 1) | The underwriter named this objection, from evidence you confirmed, so it is used as written. F1 and F2 are where the material is thinnest, which is why the hold is limited to the quotes |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `uncertain_or_weak_areas` acknowledge_gap "Owning a roadmap and prioritization authority (R1 sub-claim)"; `prohibited_claims: "Having owned a product roadmap"` | Name the roadmap line without being asked twice: "I haven't owned a roadmap." Then the ramp plan, said as a plan: what you would learn and from whom before making a call alone. Do not offer a bridge for this line and do not shrink it. Candor on the weakest line makes the other answers more believable | F2 is the underwriter's acknowledge-gap area, so the honest form is the plain acknowledgment plus a ramp; Skeptic stem, JD because it scores the stated roadmap responsibility |
| A3 | "Tell me about the API or platform work you've done that's closest to what we're hiring for." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3, with the beats the quote states: the 30+ integrations, end to end, and the stages scoping, requirements, architecture, UAT, go-live; tell them in your own words. Name the limit yourself: this is integration work on the vendor's REST APIs. Answer slot: if any of that work changed what the vendor's API did, say what and which part was yours; if none did, say so plainly and stay with the integrations | F3 is the must-have requirement with the thinnest bridge; open prompt so you choose the instance, JD because it scores R2 |
| A4 | "How have you worked with agile delivery teams?" | JD | [grounded] `uncertain_or_weak_areas` clarify "Agile delivery inside a product org (R5)" | No story is mapped, because nothing verified speaks to it. Answer slot: if you worked in an agile cadence, say what it was and what your part was; if you never worked that way, say so plainly, then say what you would want to confirm about how Quartzline's squads define it. Do not describe ceremonies you did not run | F6 is a clarify area; the question-shaped answer is the one the underwriter allows |
| A5 | "Why move from integration work into product, and why here, why now?" | EXP | [generic] | Say your actual reason in your own words, in one or two sentences. Keep it consistent with the A1 concession: you are not claiming to be a PM already. For "why here", name only something you can point to; if no Quartzline-specific reason comes to mind, say so plainly and say what the role's own responsibilities offer. The pack has no company research, so it supplies none | Motivation consistency is what a Skeptic scores, and the move is the story most likely to be probed; EXP because it tests whether your account holds together |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says their integration is running far behind plan and they are thinking of pulling out. What do you do in your first two weeks?" | CASE | [generic] | Clarify first: what behind plan means, which stage it is stuck at, what the partner needs and by when. Then objective, the options, who you need from engineering, how you would know it worked, and the risk of each path. You may borrow the stage names from your own quote (scoping, requirements, architecture, UAT, go-live) as a way to locate the problem. Makes no claim about your past | A live problem from the role's partner-facing work; `[generic]` because it is a pattern, not a fact about Quartzline |
| B2 | "Two squads, one roadmap. One lead wants to pay down technical debt in the API and the other wants three partner-requested endpoints. How do you decide?" | CASE | [generic] | Ask first which of these calls belong to the PM and which to the squad leads; that is the open authority question, and asking it is the right move, not a dodge. Then criteria, partner evidence, cost of delay, what you would record, and how you would bring both leads to the decision. Makes no claim about your past | Tests the unresolved decision-authority risk live; CASE because it scores reasoning, and it gives you a natural place to ask about authority |
| B3 | "Partner adoption of the API has gone flat. How would you diagnose it?" | CASE | [generic] | Ask how adoption is defined and measured today and what the baseline is; the dossier flags both as unknown. Then segment partners, locate where they stall, propose two or three metrics, and say which you would trust least. Makes no claim about your past | JD line "Define and track adoption metrics"; CASE delivery, and the metrics gap is one of the underwriter's open risks |
| B4 | "Sketch how you would run discovery with integration partners in your first quarter. What do you need to know first?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Clarify who the partners are, what decisions the discovery must inform, and what already exists. Then approach, synthesis, and what you would bring back to the squads. The nearest thing your material carries is the sessions, at their scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Say that and no more about how they ran | JD line "Run discovery with integration partners"; F1 and F5 hold the evidence, so the case ties to the one quote that touches it |
| B5 | "How would you write a spec for a new endpoint so two squads can build against it?" | CASE | [grounded] "Wrote the internal integration playbook her team uses"; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure it: the partner problem, the contract (what goes in and out, error cases), acceptance and UAT, rollout and deprecation, the metric. Answer slot: the JD's "Write specs" line makes a probe on specs you have written likely; if you wrote any, say what and for whom; if none, say so plainly and stay with the playbook you wrote and the requirements and UAT stages you led | JD lines "Write specs and drive delivery with two engineering squads" and R3; F4 holds the evidence |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each one of the quoted sentences in your own words: the integrations, the playbook, the roadmap-input sessions. Stop the arc at "feeding client evidence to product"; do not close it with a claim to product management. End with your own sentence on why this role is next | F1 holds the arc; the biography question is scored even when it sounds casual |
| C2 | "What are you actually playing with in API tooling these days?" | JD | [generic] | Answer only with what you actually use or read. If nothing comes to mind, say so plainly and say what you would look at first for a platform like this. Do not name a tool you have not used | R3 asked casually; casual questions on a hot JD topic are still scored |
| C3 | "Tell me about the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats are the quote's: you wrote it, it is internal, your team uses it. Re-read it before Thursday so every further detail comes from the document itself. If asked who else contributed or how it is kept current, say what you know and say plainly what you do not | The playbook is the inspectable artifact behind the high-confidence evidence, so a prober can ask to see it; F4 |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You led 30+ client integrations. How was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure counts integrations, not clients or API calls. Answer slot, in your own words: what counted as one integration; what the figure is most sensitive to; the assumption behind it you would defend least; and which part was yours. "I don't know exactly how it was counted" is an honest branch. Never describe a method you did not use | The headline figure on your record is the likeliest target for a prober; F1, F3 |
| D2 | "What did you measure to know an integration had gone well?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the JD's adoption-metrics line makes a probe on what you tracked likely; if you tracked anything about how integrations went, say what and how it was counted; if you tracked nothing, say so plainly, and say what you would measure first at Quartzline, after asking how adoption is measured there today | The JD asks for adoption metrics and your quote stops at go-live, so the second branch matters; JD content, EXP delivery |
| D3 | "What could you show me from those roadmap-input sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The underwriter confirmed this claim but with limited inspectable proof, so volunteer the limit: "I ran quarterly roadmap-input sessions feeding client evidence to product," then say plainly what exists, if anything, beyond your account. If nothing does, say so and do not reconstruct it | The medium-confidence claim is the seam a prober finds; the limit named before it is asked for; F1, F5 |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You would work with two squad leads who have been shipping this API for a while. Where is the seam between your calls and theirs, and what happens when you disagree?" | CASE | [generic] | Do not pretend to know the seam. Propose principles: who owns the what and the why, who owns the how, and how a disagreement is escalated and recorded. Ask how it works today. Makes no claim about your past | The JD asserts authority over two squads and the underwriter could not verify it; the question lets you probe it from inside the answer |
| E2 | "Tell me about a time you disagreed with engineering or sales." | VAL | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Selection scaffold: pick a time with a named stake, a moment you held your position, and an intact working relationship afterwards. Your quotes carry client-facing work and do not show engineering or sales, so do not stretch them. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the client-facing stages of the integrations, or how you would handle it | R4 names engineering, sales and customers, and F5 does not show the first two |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM who has done this for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims: "Having held a product manager title or role"` | The time-boxed A1. Pause and restate. Concede first: "I haven't held a product manager title or role." Hold the two quoted sentences through two follow-ups and add nothing to them. Do not claim equivalence with a PM who has three years in the job | F1; the same objection under pressure tests whether the A1 answer survives interruption |
| F2 | "That roadmap-input work — how much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims: "Having owned a product roadmap"` | Hold on what the quote carries: you ran the sessions and fed client evidence to product. Concede in the same breath: "I haven't owned a roadmap." Answer slot: if anyone shared the running of the sessions, or product decided what to take from them, say so plainly | F1; attribution probes aim at the medium-confidence claim |

## Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1 3+ years product management experience | A1, A2, A5, F1, F2, C1 |
| R2 Shipped API or platform products | A3, D1 |
| R3 Technical fluency: API docs, schemas | B5, C2, C3 |
| R4 Stakeholder management across engineering, sales, customers | E1, E2, B2 |
| R5 Agile delivery experience | A4 |
| Own the roadmap for the partner-facing API platform | A1, A2, B2 |
| Run discovery with integration partners | B4 |
| Write specs and drive delivery with two engineering squads | B5, B2, E1 |
| Define and track adoption metrics | B3, D2 |

No question is grounded in Quartzline's strategy, because research did not run.

## Reverse questions

| # | Question | Why it lands | Source |
|---|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | It reads as diligence about how the role works, and it answers the open risk that decision authority is asserted in the JD but not evidenced | [grounded] `questions_for_employer` |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | It shows you think in adoption terms and settles the second open risk: the metric is named as a responsibility with no baseline stated | [grounded] `questions_for_employer` |
| 3 | "What would you want a new PM on this platform to have learned by day 60?" | It invites the ramp conversation on your terms and tells you what they weigh most | [generic] |
| 4 | "How do the two squads split the platform today, and how does partner feedback reach them?" | It maps the seam you would sit in, and the answer tells you how much of E1 is real | [generic] |
| 5 | "What was the hardest prioritization trade-off this team faced recently, and who made the call?" | A concrete story shows how decisions are made in practice, which the JD's wording does not | [generic] |
| 6 | "What would tell you in a year that this hire is working?" | Success criteria are the thing most worth knowing before you accept | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The plain acknowledgment, sourced to `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title or role." The adjacent case stays F1's two quotes at their own scope |
| Having owned a product roadmap | Dossier `prohibited_claims` and the `acknowledge_gap` area | "I haven't owned a roadmap," sourced to `prohibited_claims: "Having owned a product roadmap"`. The sessions stay at their quote's scope, as input to product and not ownership of a roadmap |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad," sourced to `prohibited_claims: "Having set prioritization for an engineering squad"`. No slot, no bridge |
| Shipped API or platform products | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says integrations of the vendor's REST APIs, not the API or platform itself. A3's slot stays inside the integrations |

## Sources

- Provided: `tuesday-dossier.md` (dossier version 1.1, from job-underwriter, dated 2026-08-14). Consumed: `role_profile` (the JD equivalent), `decision` (context only), and `handoff_to_mock_interview` (verified evidence, weak areas and their allowed strategies, the objection, risks, employer questions, prohibited claims). It carried no `evidence_map`, so the confidence and gap type for F3 to F5 are this pack's own and are labeled `[inferred]`; F1, F2 and F6 follow the underwriter's grades. The dossier is dated before today; if anything in the confirmed evidence has changed, say so and the rows regenerate.
- No round-type documents, recruiter guidance, interviewer profile or assessment were provided. Round type was stated: hiring manager, 45 minutes.
- Searches sent, all refused: "Quartzline company values principles", "Quartzline interview process product manager", "Quartzline API platform strategy news". No pages were fetched, and nothing about Quartzline's values, process or strategy comes from memory.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions; none is in the pack |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. It would have named the loop and the rounds; persona weights rest on the hiring-manager prior and a Generic archetype, and the pack does not assert how Quartzline's loop is structured |
| 3. `Quartzline strategy` / recent news | unavailable | Every call was refused. It would have grounded a CO question and the case bank; the cases are `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` supplies the requirement and responsibility lines |

## Upgrade menu

- The interviewer's name and role → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their path
- The recruiter's prep note, if one exists → coverage of any pre-declared deliverable and stated focus areas
- Quartzline's published values or interview guide, pasted → a values cheat sheet if a values round is documented, a loop read in place of the Generic fallback, and a CO question
- Permission for web search → reruns the three refused targets, and a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once
- The written input that went to product after one of the roadmap-input sessions → the one artifact that would raise that medium-confidence claim toward high (F1, F5, D3)
- Your answers to the slots in A3, A4, B5, D2 and F2 → those rows regenerate on what you actually did
