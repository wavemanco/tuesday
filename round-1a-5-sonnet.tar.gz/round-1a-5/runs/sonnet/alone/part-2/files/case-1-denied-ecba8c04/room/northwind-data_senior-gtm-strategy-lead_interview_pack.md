# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

- **Interviewer:** Dan Kovac, Director of Sales Strategy. A peer: he and Priya would report to the same VP.
- **Round:** one 60-minute conversation (per your notes). Session mode, peer weights.
- **Candidate:** Priya.
- **Built from:** your message only: JD highlights, candidate summary, Dan's profile, your research note. No full JD, no recruiter guidance, no search results (both lookups were refused; see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words. An "answer slot" is an instruction for the interview. Answer it from what actually happened, or say plainly that it did not happen or was not yours.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values. No rows here: no values-style round is detected (your notes describe one conversation with a peer) and no published values are in hand |
| EXP | Whether the CV's claims survive scrutiny; what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge, and thinking at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

Requirements are quoted from your JD highlights, which are a summary and not the full JD. Evidence is quoted from your notes on Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says consulting and product strategy & ops, not go-to-market ownership, and the words stay at that scope: "I spent 2 years in strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops." Answer slot: the JD's own-GTM line makes a probe on whether any go-to-market was yours likely. If any part of taking a product to market was yours to decide, say which part and how you decided, in your own words; if none was, say so plainly and stay with the strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | Your material says you proposed the change and that it was credited with the uplift. It does not show how the opportunity was found or whether it sat in a land/adopt/expand/renew frame. Answer slot: the JD's whitespace line makes a probe on how you spotted the opportunity likely. If analysis found it, say what you looked at; if it came from elsewhere, or you do not recall, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | low | [inferred] | discovery | A skills line with no instance behind it, so the bridge is a derivation and asserts nothing beyond your words: "I'm skilled in SQL/Tableau." Answer slot: if asked for an analysis you ran yourself, name the question, the data and what it informed; if you cannot name one that was yours end to end, say so plainly and say how you would build one for this role |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a model, built and used in negotiations, not the design of how partners are engaged. The words stay at that scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD makes a probe on partner-motion design likely. If any part of how partners were engaged was yours to design, say which and how you decided; if your work was the model and not the motion, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the sentence's own terms: annual volume targets, set with consensus across orgs |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | Vague on tools and purpose, so it is coached as a discovery lead and not asserted as a story. Your words: "I use AI tools daily." Answer slot: say which tools and what for, in your own words, whatever that is, and say where your use stops |
| F7 | Familiarity with sales-ops and quota-setting practice, the working language of a sales-strategy peer (unquoted: not in the JD highlights) | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap you stated yourself, so the words are yours to give back: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller, and no answer slot, because the requirement is the pack's own reading of the role |

## Grounding brief

Your research note is the only strategy source in hand. It carries no date, so check it against Northwind's latest public news before the conversation.

| Item | What your material says | Provenance | How to use it |
|---|---|---|---|
| Stated priorities | "Northwind's three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" — your research note | [grounded] | Frame plans against all three. Ask Dan how each is showing up in his work instead of asserting how Northwind runs it |
| Main competitive threat | "main competitive threat is bundling by a much larger platform vendor" — your research note | [grounded] | Raise bundling yourself in a case answer (D3) to show you think at company altitude |
| Stage vocabulary | "land/adopt/expand/renew" — JD highlights | [grounded] | Use the four stages aloud when structuring; they are the JD's own words |
| Compass | Named in the note as the AI copilot launch; nothing else is in hand | [grounded] | Ask about it; never claim familiarity with it |

Do not coach Dan on the framing of any of these. Use them to sound current.

## Reading the interviewer

Everything here comes from the profile you supplied. The public-footprint search was refused, so no talks or writing were read.

| Signal (from your notes) | What it likely means for the conversation | Provenance |
|---|---|---|
| Describes himself as "relentlessly data-driven" | Every figure you give will be followed two levels down: how it was counted, what it is sensitive to. Banks B and F carry this | [inferred] |
| Career spine is pricing and monetization roles | Cases tilt toward packaging, pricing and unit economics (D3, B5). The revenue model line (F4) is likely to draw him | [inferred] |
| One early-stage-startup chapter | Builder stories land well, and expect a probe on scrappiness. The only quoted sentence with "built" is F4's, so tell it at that scope | [inferred] |
| Your peer, same VP | He is pricing what your hire costs and contributes to his own work; probes arrive collegially (bank A) | [inferred] |
| Your own 2 years in consulting (F1) | Say the structure aloud before using it, and state your hypothesis early | [inferred] |
| Mirror opportunities | None offered: no row's evidence carries a side of a shared career jump with his | [inferred] |

## Persona table

| Persona | Weight and bank | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | 1st, A1 to A5 | Seam between your role and his, what you need from his team, credit across teams | High. The peer relationship prior puts it first, and you share a VP | Reciprocity first: what you bring his team. Propose seam principles, never a pretended seam |
| Data-Driven Prober | Joint 1st, B1 to B5 | The ~$400M figure, the revenue model, a SQL walkthrough | High. Peer prior, plus his self-described "relentlessly data-driven", plus the JD's SQL and Tableau line | Say what you know and do not know about how each figure was counted; name the weakest assumption before he does |
| Skeptic | 3rd, C1 to C3 | Sales-ops and quota-setting, partner-motion design, why this move | Medium. He runs sales strategy, so F7 and F4 are in his own territory | Rehearse C1 until it is boring; calibrated candor over bluffing a competency he personally owns |
| Case/Strategist | 3rd, D1 to D3 | Live problems on the two new lines, adoption, bundling | Medium. The JD asks for GTM ownership and his spine tilts to pricing, but he is a peer, not the hiring manager | Clarify, then structure; challenge one premise respectfully |
| Conversational | 5th, E1 to E2 | The opening walk-through, and a casual question on AI | Medium. Most conversations open this way, and "AI experience a plus" arrives casually | Pre-script the 90-second arc; treat casual questions as scored |
| Pressure | 5th, F1 to F2 | "How much of it was you" and "why you over someone who has done this" | Low to medium. Not a skip-level, but a data-driven peer probes attribution hard | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral | Not weighted | Not detected | Low. Your notes describe one conversation with a peer and no published values are in hand | n/a |

## Question banks

The highest-ROI prep in this pack is **C1**. It is the one question this interviewer is most likely to ask, it sits in his own territory, and it rests on a negative you stated.

### Bank A: Peer Evaluator (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between your role and mine, and what happens when we disagree?" | JD | [generic] | A design answer, with no claim about your past. Ask for his view of the seam before proposing one. Offer principles: who decides which kind of call, one shared set of definitions for land/adopt/expand/renew, no surprises before the shared VP sees anything, disagreements raised with each other first and escalated together if still open. Close by asking where the seam has already caused friction | F5 is the requirement this scores. A peer prices the seam first. JD because it tests the stated role, not a story |
| A2 | "What would you want from me in your first 90 days, and what could you do that would take load off my team?" | JD | [generic] | Lead with what you bring his team before what you need. Ask for his team's definitions and data access, and for what his team already knows about how new products have sold. Offer something his team can reuse, said as an intention | The reciprocity probe: a peer asks what the hire costs him. JD because it scores the cross-functional line (F5) |
| A3 | "Tell me about a time you had to get several teams to agree on something when they started in different places." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5, with only the beats the sentence states: annual volume targets, consensus across orgs. "We" for context, "I" for what you did. Answer slot: if the orgs started in different places, say where and what you did to move them; if there was little disagreement, or someone else drove the consensus, say so plainly and stay with what the sentence says | F5 is the evidence for cross-functional influence. EXP because it tests what was actually yours; it is the credit-and-disagreement probe in collegial packaging |
| A4 | "Say your analysis of an expansion pattern disagrees with what my team's dashboards show. What do you do before it reaches our VP?" | CASE | [generic] | Ask first, then reconcile definitions (what counts as expand, which cohort, which dates). Sit with his team to find the difference. Bring one reconciled number, or a named open difference, to the VP together. No claim about a past instance | A live seam problem for a data-driven peer; the F3 and F5 requirements meet here. CASE because it asks for reasoning, not history |
| A5 | "Enterprise expansion is one of the company's priorities. How would two new product lines support it without competing with it for the same sellers?" | CO | [grounded] "enterprise expansion" — your research note | A trade-off answer, with no claim about your past. Ask how seller capacity is allocated today instead of assuming it. Then separate where a line attaches to accounts already expanding from where it takes seller time, and say what you would measure to tell the two apart | Tests strategy at company altitude and the GTM requirement (F1). CO because it turns on a stated priority; peer-flavored because it lands on his sellers |

### Bank B: Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open at the sentence's scope: you proposed the change, and it was credited with the uplift. Then four answer slots, each in your own words: how the figure was counted; what it is most sensitive to; the assumption behind it you would defend least; which part was yours. Where you do not know how it was counted, say "I don't know how it was counted" and say what you do know. Do not supply a method you cannot repeat under a second question | F2 carries the headline number, and a defend-the-number question is owed to every headline figure. EXP because it tests attribution and counting |
| B2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name it before he does, in your own words. If you do not know the assumptions, say so plainly. Then say what you would check to test it, as a plan. Naming your own weak spot converts a gotcha into credibility | The weakest-assumption move, asked directly, since a data-driven peer will reach it by the second follow-up (F2) |
| B3 | "Walk me through the partner-level revenue model. What would change its answer most?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the sentence says: you built the model, and it was used in carrier negotiations. Answer slots: if you know what would change its answer most, say so; if you never tested that, say so plainly. If asked which part was yours, say it in your own words and where it stopped being yours | F4 is the other headline claim and sits in a pricing-and-monetization interviewer's native territory. EXP because it tests what you built and what you can defend |
| B4 | "Tell me about an analysis you ran yourself in SQL, from the question to the answer." | JD | [inferred] "skilled in SQL/Tableau" | A selection scaffold: pick an analysis that was yours end to end, where you can name the question, the data you pulled and what it changed. Expect him to ask for the denominator, and offer to walk through it live. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would build one here | F3 is `low` confidence, so the pack coaches a selection scaffold, not a story. JD because the SQL and Tableau line is a stated requirement |
| B5 | "For a new line with no history, which retention and expansion metrics would you compute first, and what in each would you distrust?" | JD | [generic] | Define each metric aloud before computing it (what is counted, over what base). Show where small samples, mixed cohorts and contract timing distort it, and treat early reads as directional. Ask how Northwind defines them today. No claim about your past | Tests analytic judgment on the whitespace requirement (F2) in a B2B frame that differs from the consumer background. JD with CASE delivery |

### Bank C: Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal.** Level 1: concede plainly, in your words: "I don't have classic sales-ops or quota-setting experience." Add nothing to soften it. Then the sentence at its own scope: you set annual volume targets with consensus across orgs. Do not call that equivalent. Then a ramp plan, said as a plan: ask his team to walk you through how it is done today before you propose anything. Level 2 (he says targets are not quotas): agree, and name what you would want to learn. Level 3 (so why you): return to the quoted sentences and say what you would defer to his team on. Hold the position through all three; concede specifically, never fold into claiming equivalence | F7 is the biggest gap and sits in his own domain. F5 is the only adjacent evidence, and it does not reach it. JD because it scores fit against the role; Skeptic because the negative is the question |
| C2 | "This role requires partner-motion design experience. Where does yours come from?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the sentence carries: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of how partners were engaged was yours to design, say which and how you decided; if your work was the model and not the motion, say so plainly and stay with the model. Concede the limit specifically, then say what you would want to learn about Northwind's partners first | F4 is the JD's required line and the second-biggest gap. The slot's second branch allows the premise to be false |
| C3 | "Why leave a large consumer-tech company for B2B data infrastructure, and why this role, and why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Three parts, each in your own words: what pulled you to this role (you can name Northwind's stated priorities from the research note), what the 9 years gave you at the sentence's scope, and why now. Your material gives no reason for the move or its timing, so the reason is an answer slot: give your actual one. Do not borrow an enthusiasm you do not have | The motivation probe every background change draws. EXP because it tests whether the story survives cross-questioning. F1 is the career line |

### Bank D: Case/Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sketch the go-to-market plan for one of the new lines. What do you need to know first?" | CASE | [grounded] | Clarify first (what the line is, who buys it, how it is sold, what the revenue ambition is, what is known about each stage of land/adopt/expand/renew). Then objective (tie it to enterprise expansion and profitability), segmentation, approach by stage, metrics, risks, with bundling as one. Think aloud and challenge one premise, such as whether both lines need the same motion. No claim about your past | The JD's GTM-ownership line (F1) made live. CASE because it scores structure |
| D2 | "A new line lands customers, but adoption stalls after the initial land. Diagnose it." | CASE | [generic] | Define adoption first. Cut by segment, cohort and plan. Separate product, onboarding, packaging and seller-incentive causes. Name the first three cuts you would run and what result would change your mind. Say it as a plan, not a past | The whitespace requirement (F2) as a diagnosis, using SQL and Tableau reasoning aloud (F3). CASE with JD content |
| D3 | "A much larger platform vendor starts bundling a competing capability into its suite at no extra charge. What does that do to your plan for a new line, and for Compass?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" — your research note | Structure: who is exposed, where a bundled version is good enough, where whitespace cannot be bundled, the pricing and packaging response (standalone versus attach), and the signals you would watch. Name what you would not do, such as chasing feature parity. Ask Dan what he is seeing. Assert nothing about Northwind's own positioning | The company's stated main threat, delivered in a pricing-and-monetization interviewer's native frame. CO with CASE delivery; it also touches the AI plus (F6) through Compass |

### Bank E: Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc. The consulting years, then the 9 years in product strategy & ops, then one sentence each on the three quoted pieces at their own scope (the model, the targets, the proposal). Answer slot: why you moved between them and why this role now is your own reason; your material gives none. End on why this role, in your words | The opener is scored for economy and interest. F1 is the career spine; F2, F4 and F5 are the three sentences to carry |
| E2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Say that you use AI tools daily, then answer the slot: which tools and what for, in your own words, whatever that is, and where your use stops. Ask about Compass out of curiosity; never claim to know it | The casual question about a JD plus. F6 is `low` confidence, so this is coached as a clarify-strategy note |

### Bank F: Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate. Hold: "I proposed the change." Concede specifically: the uplift was credited to the change, and you can speak to the proposal and what you know about how the figure was counted, not to more than that. Answer slot: if you took further part after proposing it, say what; if not, say so plainly. Hold through two follow-ups; never reach for "drove" or "delivered" | The attribution probe that data-driven interviewers use on every headline figure (F2). EXP; Pressure because of the delivery |
| F2 | "Sixty seconds: why you over someone who has run sales strategy for years?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Concede first, in your words: "I don't have classic sales-ops or quota-setting experience." Then the two quoted sentences at their own scope, and what you would bring his team, said as an intention. Do not claim you are better. Hold the position without becoming defensive | F7 under time pressure. JD because it scores fit against the role |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "own GTM strategy for two new product lines" | A5, D1, D3, E1 |
| "identify whitespace across land/adopt/expand/renew" | B5, D1, D2 |
| "run independent analysis in SQL and Tableau" | B4, B5, A4 |
| "partner-motion design experience required" | C2, B3 |
| "strong cross-functional influence" | A1, A2, A3, A4 |
| "AI experience a plus" | E2, D3 |
| Sales-ops and quota-setting (F7) | C1, F2 |
| Headline figures (the ~$400M, the revenue model) | B1, B2, B3, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Most of your career has been in pricing and monetization, with one early-stage chapter. What from that startup stretch do you still use when you plan sales strategy here?" | Tied to his own path: it shows you read him, not just the company, and turns a quiz into a conversation |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are thinking about his load |
| R3 | "Where do sales strategy and emerging-products GTM most often pull in different directions, and how has your shared VP wanted that settled?" | Goes straight to the seam he will be probing, from his side |
| R4 | "How is land/adopt/expand/renew health measured today, and where is the data weakest?" | A data-driven interviewer enjoys naming the weak spot, and it uses the JD's own vocabulary |
| R5 | "With bundling by a larger platform vendor as the main competitive threat, how is that showing up in how you think about targets and packaging?" | Shows homework from your research note and asks where his judgment sits |
| R6 | "How do you see Compass fitting alongside the two new lines: as an attach to them, or a line of its own?" | Connects the AI priority to the role without claiming product knowledge |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience | Negative you stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Set quotas, or "volume targets" described as equivalent to quotas | Inflated form of F5 | F5's quote at its own scope. The pack's observation is that your material says volume targets with cross-org consensus, not quotas |
| Designed or ran a partner motion, or led the carrier negotiations | Inflated form of F4 | F4's quote at its own scope. The pack's observation is that your material says a model built and used in negotiations. C2's slot stays inside the model |
| Drove, owned or delivered the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed, and credited. B1 and F1's slots ask only how it was counted and which part was yours |
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The pack's observation is that your material says product strategy & ops |
| Expert in SQL and Tableau analysis of B2B funnels | Inflated form of F3 | F3's quote at its own scope: "skilled in SQL/Tableau". B4's slot asks only for an analysis you ran yourself |
| Built or shipped AI products, or knows Compass | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily". E2's slot asks which tools and what for |

## Sources

- **Provided documents:** your message: JD highlights, candidate summary (the coach's notes), Dan Kovac's profile, your research note. No dossier was present.
- **Searches sent:**
  1. "Northwind Data company values": refused.
  2. "Dan Kovac Director of Sales Strategy Northwind Data": refused.
- **Fetches sent:** none.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The call was refused. It would have moved the published value names for VAL questions and a values cheat sheet; neither is in the pack, because no values-style round is detected |
| 2. `Northwind Data interview process, strategy lead` | skipped | Your words fix the loop: one 60-minute conversation with a peer. Persona weights follow from that |
| 3. `Northwind Data strategy` and recent news | skipped | Your research note already supplies the priorities and the competitive threat; its age is flagged in the grounding brief |
| 4. `Dan Kovac Northwind Data` | unavailable | The call was refused. It would have moved the interviewer read beyond your profile, and a tailored reverse question |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights fix the six requirement rows; the full JD text is in the upgrade menu |

## Upgrade menu

- The full JD text → the six requirement rows are quoted from the JD itself, and any mid-list requirement the highlights dropped gets a row and a question
- The recruiter's focus areas for the conversation with Dan, or a deliverable he expects → coverage matched to what is graded, and a build section if a deliverable was announced
- Search access, so the two refused lookups can run → Northwind's published value names and Dan's public talks or writing: a sharper interviewer read and a tailored reverse question
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → a strategy brief and org context for D1 to D3
- How long you have to prepare → a prioritized schedule sized to it
- The readout or memo behind the ~$400M uplift → F2 from `medium` to `high` confidence, and B1 and B2 become story-mapped instead of slot-based
- The revenue-model file or a deck from the carrier negotiations → F4 from `medium` to `high`
- A SQL query or Tableau workbook you wrote yourself → F3 from `low` to `medium` or `high`, and B4 becomes story-mapped
- Your answers to the answer slots in F1, F2, F3, F4 and F6 → those rows regenerate on your own words
- A `tuesday-dossier.md` from an earlier pass → verified evidence and absolute prohibited claims in place of the ones this pack built locally
