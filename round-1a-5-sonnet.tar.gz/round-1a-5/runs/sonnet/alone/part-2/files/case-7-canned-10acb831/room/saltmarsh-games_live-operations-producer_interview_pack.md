# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Built as the hiring-manager round: Saltmarsh's interviewing page says every loop after the recruiter call is a single 60-minute "Outage Hour" with the hiring manager, and this pack assumes Tobias is that person.
**When:** Friday

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on. Guidance is scaffolding for your own words, not a script, and every answer slot is an instruction for the interview: answer it from your real experience, or say plainly that the practice was not yours.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values, not generic virtue |
| EXP | Whether your background claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its current direction |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage (two days)

1. Say C1 aloud, with its two follow-ups, until the plain acknowledgment sounds ordinary. It is the highest-ROI prep in this pack.
2. Say A1, A2 and A4 aloud, thinking out loud. The tabletop is the first half of the hour.
3. Fill in your own answers to the slots in B3, D1, D2 and D3 so that you say them in your own words.
4. Play Tidepool Tactics and Lantern Row if you can, for F2 and A3.
5. Read B1 to B4 against the three values and pick your hardest value for B4.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title and weekly content drops, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: expect a probe on what in your drops resembled an event. If anything did, say what it was and what you did on it, in your own words; if nothing did, say so plainly and stay with the weekly content-drop calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show whom you worked with on each drop. Answer slot: if you worked with design, art, engineering or community on a drop, say which and what your part was, in your own words; if some of them were not people you worked with, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says presenting the numbers, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on who chose what went into those numbers. If you chose, say what and why, in your own words; if someone else set them, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | Lead with the checklist in the quote's own terms: you wrote it, and QA still uses it. A CV-style line with no artifact inspected behind it, so expect a probe on it, and bring the checklist itself if you can |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | Your material gives the years, the title and the studio type, and does not say whether the title was a live-service game. The years line is an experience requirement, not a gate. Answer slot: if the title was a live-service game, say what made it one, in your own words; if it was not, or you are unsure what the studio would call it, say so plainly and stay with the four years and the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | Lead with the calendar in its own terms: weekly, one title, two years. No inspected artifact behind it, so a calendar export is the thing to bring |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Reword only the quote: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on how those numbers were counted. If you know, say how, and name the assumption you would defend least, in your own words; if you do not know how they were counted, say so plainly and say what you would check |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Reword only the quote: a document you wrote that a team still uses. Say it as "I wrote the release checklist our QA team still uses" and let the interviewer judge the writing |
| F9 | Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model from February 2027 — Saltmarsh news page, search result | "never worked on a game with in-app purchases" — your message | none | [inferred] | capability | A gap you stated. The JD does not name the two titles, so the link to this role is the pack's derivation. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |

## Reading the interviewer

Public professional footprint only, from a search-result listing of his GDC 2026 talk (the talk itself was not opened).

| Item | What the source says | What it means for you |
|---|---|---|
| Role | Head of Live Operations at Saltmarsh Games | He sets the standard for this seat |
| Background | Previously a QA lead at a console studio | A release checklist is his native territory, so expect F4 to be probed with insider knowledge |
| Talk | "Patch Notes Are a Promise" (GDC 2026): a live team is judged by how often its patch notes describe what actually shipped | Expect questions about announcing against shipping, close to Saltmarsh's second value. A2 and B2 rehearse this |
| Mirror opportunity | His QA background beside your F4 quote, "Wrote the release checklist our QA team still uses." | Shared vocabulary only. Speak about the checklist in its own terms and do not quote his talk back unless you have watched it |

## Persona table

The loop is established by Saltmarsh's interviewing page: one 60-minute session with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home.

| Persona | Bank | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | A | The tabletop: an outage during a live event, run live | High. The interviewing page names the tabletop as the first half of the hour, and a hiring-manager round leans Case | Clarify, then objective, approach, comms, risks; think aloud; say who you would pull in and why. These are plans, so say "I would" |
| Values / Behavioral | B | The second half of the hour, mapped to the three published values | High. The interviewing page names a values conversation, and Saltmarsh publishes three values | Where a quoted sentence carries a story, use it at its own scope; elsewhere use the selection scaffold and its honest branch |
| Skeptic | C | Probing your two stated gaps and the move to a season pass | High. A hiring-manager round leans Skeptic, you stated both gaps, and the Larkspur news makes the season pass current | Rehearse C1 until it is boring: plain acknowledgment, then what your material carries, then a plan |
| Data-Driven Prober | D | Walking your retention numbers and your checklist to their assumptions | Medium. His talk is about whether announcements match what shipped, and he came from QA, so claims are likely verified | Say what you know and plainly what you do not; name the assumption you would defend least |
| Pressure | E | Time-boxed challenges and tabletop injects | Medium-low. The interviewing page does not describe a stress style; tabletop injects can still arrive as pressure | Pause, restate, hold the position the quotes carry, concede specifically |
| Conversational | F | An opener on your journey and what you play | Low. The page lists no opener, but an opener is still scored | Short arc from your quoted sentences only |
| Peer Evaluator | G | Seam questions between design, engineering and live ops | Low. The interviewer is the hiring manager, but the role coordinates four teams | Seam principles, not a pretended seam |

## Question banks

### Bank A: Case / Strategist (highest weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The Outage Hour. It is day two of a live event and the reward is not arriving for a share of players. It is your incident. What do you do in the first fifteen minutes?" | CASE | [generic] | Think aloud and clarify before structuring: who is affected, since when, whether it is still getting worse, whether a cause is known. Then contain, communicate, recover: pause or protect the event if that is an option, tell players what you know and when the next update comes, and say who you would pull in and for what, such as engineering to diagnose, community for the player message, QA to check the fix, and design if the reward must be made good. Challenge one premise politely, such as whether the event should keep running while broken. This is a plan, so say "I would" | The interviewing page documents the tabletop as the opening half of the hour, so this is the likeliest question shape. CASE because it scores structure; the scenario is a pattern, hence generic; the four teams come from the JD's coordination line (F2) |
| A2 | "Community says players are asking for an ETA. Engineering says they do not have one yet. Say the first two lines of the player update out loud." | CASE | [grounded] | Say what is known, what is not, and when the next update comes. Promise only what is built, in short plain sentences, because you are being heard as a writer. Do not give a fix time you cannot back | Saltmarsh's second value says to announce what is built, not what is hoped, and his talk is about patch notes matching what shipped. CASE delivery, JD content: it scores the clear-written-communication requirement (F8) without a take-home |
| A3 | "From February 2027 two of our titles share one events calendar, and the per-title event teams become one live-ops group. You are asked to plan the first quarter. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify before planning: what is fixed, who decides when two titles want the same week, who sits in the new group, and what players of each title will see. Then structure and metrics. State your own scope plainly: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles wording makes a probe on planning around a second title likely. If you have ever scheduled around a second title or another team's dates, say how, in your own words; if you have not, say so plainly and describe how you would find the collisions | Current strategy (Project Larkspur, September 2026) turned into a role-relevant case. F1 and F6 are the evidence; CASE because it scores clarifying before structuring, with CO content |
| A4 | "Thursday's drop is locked. On Tuesday afternoon QA flags a blocker. Walk me through the call." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Structure: how bad it is, the options (hold, trim scope, ship with a named known issue), who decides, and what players are told. Start where Saltmarsh's first value starts: when the calendar and the players disagree, the players win. Your material line is "Wrote the release checklist our QA team still uses." Say where the checklist would enter the decision. Answer slot: the JD's checklist-with-QA wording makes a probe on a real release likely. If you went through a release with QA using it, say how a blocker was handled, in your own words; if QA used it without you in the room, or no such case came up, say so plainly and stay with having written it | F4 is the evidence and the JD's release-checklist line is the target. CASE because the problem is live; the first value sets the position to hold |
| A5 | "You are building the post-event review for an event that just closed. What is on the first page?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Ask what the event was for first. Then design the page: what was planned against what shipped, what players did, the retention view, and what changes before the next event (Saltmarsh's third value says to leave the checklist better). Say the retention part in your own words from your quote. Answer slot: if a review followed a drop, say how it ran and what you did in it, in your own words; if none did, say so plainly and stay with presenting the monthly retention numbers | F3 and F7 are the evidence for the review-and-KPI requirement. JD because it scores the stated responsibility, with CASE delivery |

### Bank B: Values / Behavioral (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick one time a scheduled drop met a reason to hold or change it. It needs a named stake, what you decided or recommended, and what players ended up seeing. "We" for context, "I" for what was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the weekly content-drop calendar you ran, or how you would handle it | Value one, Players Before Plans. Scaffold because no quoted sentence carries a disagreement; F1 is the nearest evidence |
| B2 | "Tell me about a time you held back an announcement because the thing was not built yet." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick a time with a stake, what was wanted, what was actually built, and what you told people. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the release checklist you wrote, or how you would handle it | Value two, Ship the Patch Not the Promise, and the theme of his public talk. Scaffold because no quote carries an announcement; F4 is the nearest evidence |
| B3 | "Tell me about a time you left a process or a checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the release checklist, and QA still uses it; tell those beats in your own words. Answer slot: value three makes a probe on what came before and what changed likely. If there was an earlier version or a release that prompted it, say what, in your own words; if you wrote it first, or cannot name what prompted it, say so plainly and stay with the checklist QA still uses | Value three, Leave the Build Greener. F4 is the only quoted sentence that carries a story for it |
| B4 | "Which of our three values would you find hardest to live by?" | VAL | [grounded] | Choose honestly, not humbly. Pick the value your material gives you least on, say why in one sentence, and say what you would do about it. If you cannot decide, name the one you would most want a colleague to call out | Tests honest self-assessment against the published names. Nothing in it needs a claim about your past |

### Bank C: Skeptic (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never worked on a game with in-app purchases, and our titles are moving to a season pass. How does that work for us?" | JD | [grounded] "never worked on a game with in-app purchases" "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Pause and restate. Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what your material carries, at its own scope: the weekly calendar and the monthly retention numbers you presented. Then a plan, said as a plan: two or three things you would do first, chosen by you. Follow-up one: what would you do first. Follow-up two: who would you ask. Hold through both by returning to the plain acknowledgment and the plan, concede the absence specifically each time, and never claim a comparison | F9 is the gap, and a season pass is current at Saltmarsh. The likeliest objection to this candidate, so it gets the most follow-up levels and the most exact concession wording. JD because it scores a gap against the role |
| C2 | "You have never led a team. This job coordinates design, art, engineering and community on every update. Where does that go wrong for you?" | JD | [grounded] "Never led a team" "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment: "I haven't led a team." The JD's word is coordinate, so stay on that word. Answer slot: if you worked with design, art, engineering or community on a drop, say which and what your part was, in your own words; if some were not people you worked with, say so plainly and stay with the calendar you ran. Then name the one place you expect to need support and what you would do about it | F2 is a discovery row, and the stated negative is the objection's source. JD because it scores the coordination requirement |
| C3 | "You have been four years at a puzzle-game studio. Why leave, and why here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Give your actual reason in your own words. Choose one line from this job description that you are moving toward, and say it plainly. Your material gives no reason, so the pack supplies none | F5 and motivation consistency. EXP because it tests whether the story hangs together |

### Bank D: Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Open with your sentence: "I presented the monthly retention numbers to the studio head." Answer slot: if you know how they were counted, say so in your own words, and name the assumption you would defend least; if you do not know how they were counted, say so plainly and say what you would check. If someone else produced them, say so and stay with presenting them | F7 and F3. EXP because it tests attribution and the weakest-assumption move |
| D2 | "Tell me about the release checklist you wrote. What is it for, and how does QA use it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say it in the quote's terms: you wrote it, and QA still uses it. Answer slot: if you went through a release with QA using it, say how, in your own words; if QA took it from there without you, say so plainly and stay with having written it | F4, and the interviewer's QA background makes this probe likely. EXP because it tests the claim's depth |
| D3 | "Describe the main title you ran the calendar for. What does a player get each week?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Describe the weekly drops in your own words, because you ran the calendar. Answer slot: the JD's live-service wording makes a probe on whether the title was a live-service game likely. If it was, say what made it one; if it was not, or you are unsure what the studio would call it, say so plainly and stay with the weekly content-drop calendar | F5 and F6. EXP because it tests whether the title fits the JD's live-service line |

### Bank E: Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds. Why you, over a candidate who has already run a season pass?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "never worked on a game with in-app purchases" | Hold, then concede. Hold on what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses." Concede the one thing plainly: "I haven't worked on a game with in-app purchases." Do not add a comparison or a claim about how fast you learn | F9 returns as a time-boxed challenge. JD because it tests the stated fit against a stronger rival |
| E2 | "How much of that calendar was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, restate, and hold: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if others set dates or content, say who and which, in your own words; if the calendar was yours end to end, say that and no more. Hold through two follow-ups | The attribution probe the Pressure persona uses, aimed at F1 and F6 |

### Bank F: Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc using only those four sentences, in that order: the studio and the years, the calendar, the checklist, the retention numbers. Close with your own reason for this role, in your own words | A casual question that is still scored. F5, F6, F4 and F7 are the material |
| F2 | "Which of our titles have you played?" | CO | [grounded] | Answer slot: say which you have actually played and for how long; if neither, say so plainly and say what you will do before Friday. Tidepool Tactics and Lantern Row are the two named in Saltmarsh's Larkspur announcement | The homework check, from current strategy. Nothing in it needs a claim about your past |

### Bank G: Peer Evaluator (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Engineering says the update cannot make Thursday. Design says the event cannot move. You are in the middle. What happens?" | JD | [generic] | Ask each side what is fixed and why. Lay out the options, say who decides, and say what players see. Offer seam principles rather than pretending to know the seam, and start from Saltmarsh's first value: the players win | Scores the coordination requirement (F2) as a decision, with no claim about your past |
| G2 | "An update ships late and four teams touched it. How do you handle credit and blame in the review?" | VAL | [generic] | Describe what you would do: what happened against what was promised, who decided what, and what changes next time, so the review reads as a record and not a verdict. This is a plan, so say "I would" | Collegial packaging of the third value and the post-event review. Nothing in it needs a claim about your past |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, E2 |
| Coordinate design, art, engineering and community teams on each update | C2, G1, A1 |
| Own the post-event review and the KPIs it reports | A5, D1 |
| Manage the release checklist with QA | A4, D2, B3 |
| 3+ years producing live-service games or apps | D3, C3, F1 |
| Experience running a content calendar | D3, B1, F1 |
| Comfortable with player-retention metrics | D1, A5 |
| Clear written communication | A2 |

## Values cheat sheet

Saltmarsh's published values, by official name, from its values page. A values conversation is documented in the interviewing page, so this sheet applies.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries a disagreement. Selection scaffold in B1: a named stake, what you decided, what players saw. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence carries an announcement. Selection scaffold in B2: what was wanted, what was built, what you told people. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Story beats are the sentence's own, with the answer slot in B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You were a QA lead before leading live operations, and your GDC talk argues patch notes are a promise. How does your team check an update before it is announced?" | Ties to his own path and his published argument, and invites him to talk about the checklist territory you know (F4) |
| R2 | "Project Larkspur brings the per-title event teams into one live-ops group. Where would this role sit in that group, and which titles would it cover?" | Shows you read current strategy and asks the question that decides the scope of the job |
| R3 | "How does the season pass change what a post-event review reports?" | Turns F9 into a forward question and shows you are thinking about the review (F3) |
| R4 | "What does a good first 90 days look like here, and where would you expect someone from outside monetization to need the most support?" | Raises the stated gap yourself and asks how the team supports it, which reads as candor |
| R5 | "What has changed in the last year because of a post-event review?" | Tests whether the review is used, and echoes the third value |
| R6 | "What separates a strong Outage Hour from an average one?" | Shows you treat the format as a skill and gives you the scoring in his words |

## Prohibited claims

What this pack will not coach, because your material does not carry it.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | A negative you stated: "Never led a team" — your message | "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or a season pass | A negative you stated, F9: "never worked on a game with in-app purchases" — your message | "I haven't worked on a game with in-app purchases." Then a plan, said as a plan |
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the weekly content-drop calendar for one title |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: "Presented the monthly retention numbers to the studio head." The material says presenting, not owning |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope: "Wrote the release checklist our QA team still uses." The material says wrote it and QA uses it |
| Producer experience on a live-service title | Inflated form of F5 | F5's quote at its own scope: "4 years as an associate producer at a puzzle-game studio." The material does not say the title was live-service |

## Sources

Provided: the job description and your background note (your message). No dossier was provided.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Query | What came back |
|---|---|
| Saltmarsh Games company values | https://saltmarshgames.com/values |
| Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Saltmarsh Games mobile studio news strategy | https://saltmarshgames.com/news/project-larkspur |
| Tobias Wrenfield Head of Live Operations Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise |

Fetches: https://saltmarshgames.com/careers/interviewing and https://saltmarshgames.com/values.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and Bank B: three values by official name |
| 2. Saltmarsh Games interview process, live operations | yes | Loop structure: one session, hiring manager, tabletop then values conversation; persona weights follow it |
| 3. Saltmarsh Games strategy and recent news | yes | A3, F2, R2, R3: Project Larkspur, September 2026. The listing was read; the news page itself was not opened |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Reading the interviewer, A2, B2, R1. The talk listing was read; the talk itself was not opened |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your recruiter's note on the Outage Hour: any detail on what the tabletop covers would sharpen Bank A and the persona weights
- Confirmation that Tobias is the hiring manager running your Outage Hour: a different seat would reweight every bank
- Your answers to the answer slots, stated in your own words: they would upgrade F1, F2, F3, F5 and F7 and turn the slots in A3, A4, A5, C2, D1, D2 and D3 into story maps
- The release checklist, a calendar export and a sample monthly retention report: inspectable artifacts that would lift F4, F6, F3 and F7 from medium toward high
- Your full CV: more quotable sentences would turn selection scaffolds in B1 and B2 into story maps
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): a Larkspur strategy brief, the content of the GDC talk, and recent org context. Offered once
- A tuesday-dossier.md: it would add verified-evidence grading and prohibited-claim constraints to the next pack
