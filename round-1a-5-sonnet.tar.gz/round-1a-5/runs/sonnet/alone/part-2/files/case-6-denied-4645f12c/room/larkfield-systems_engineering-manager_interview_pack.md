# Interview pack — Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Three scheduled rounds, one shared fit snapshot, one mini-pack per round.

| Round | When | Who (names not given) | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | 45 min | Hiring manager, would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel of peers and a cross-functional partner |
| 3 | The following Monday | VP Engineering | 30 min | Skip-level; recruiter's description: "values and leadership philosophy" |

## How to use this pack

Personas are how a question arrives; types are what it scores. Guidance is scaffolding for a spoken answer, not a script: tell every story in your own words, and tell it the same way in all three rounds.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values and your leadership philosophy |
| EXP | Whether the claims in your background survive scrutiny; what was actually yours |
| JD | The stated responsibilities of the role, gaps included |
| CO | Homework on the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Two label notes. Provenance: `[grounded]` rests on your message or the JD you gave, `[inferred]` is this pack's derivation, `[generic]` is a role-family pattern with no claim about you or Larkfield. An answer slot is an instruction for the live answer, with two honest branches; it asks nothing of you here.

## Prep triage

1. Before Tuesday: 1A1 until it is boring (the highest-ROI rehearsal in the whole pack), then 1A2, 1D1, 1C1.
2. Between Tuesday and Thursday: 2A4, 2B1, 2B3, 2C1. Note what Tuesday's Director actually pressed on and tell me; the weights below get recomputed.
3. Between Thursday and Monday: 3A1, 3B2, 3C1, 3A3.
4. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description you pasted; evidence is quoted from your message. You gave no CV, so every row rests on four sentences of your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — JD | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material says a team lead of six, with nothing inspected behind it; it does not carry two squads or eleven engineers. The words stay at that scope: "Three of my nine years in engineering have been as a team lead of six." Your own stated limit on managers: "I've never managed managers." Answer slot: the JD's two-squads line makes a probe on leading beyond one team likely. If any of your lead time covered work across more than one team, say how and at what scope, in your own words; if it was one team, say so plainly and stay with the team of six |
| F2 | "own delivery" — JD | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The sentence carries a reliability quarter and a 60% drop after it, not ownership of a delivery plan, and the sequence is "after", not "because". Words: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: the JD's own-delivery line makes a probe on delivery commitments likely. If commitments such as dates or scope were yours to make or defend, say which, in your own words; if others set them, say so plainly and stay with the quarter |
| F3 | "hiring" — JD | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap in terms, but a line with nothing inspected behind it, so expect a probe on "run" and on "about 40". Lead with the quote's own terms: you run the hiring loop for backend roles, about 40 interviews last year. The probes are rehearsed in 1D2 and 2B2 |
| F4 | "growth for 11 engineers" — JD | none given | none | [grounded] | discovery | Your material is silent on developing engineers. Answer slot: the JD ties growth to eleven engineers, so expect a probe on how you grow people. If you have helped someone grow, say who and what you did at that scope, in your own words; if it was not part of your role, say so plainly and say how you would start |
| F5 | "partner with hardware" — JD | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn the hardware side, said as a plan and never as a past. Never a claim to hardware roadmap work. The pack's observation: your sentence says owning, and your material does not show whether you have worked alongside hardware teams in any other way; the upgrade menu asks for that |
| F6 | "partner with hardware and product on roadmap" — JD (product side) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your sentence says the roadmap pressure and the quarter, not who applied the pressure or what was negotiated. Words: your quote at its own scope. Answer slot: the JD's product-partnership line makes a probe on the other side of that pressure likely. If product partners were part of it, say how it was worked out and what was yours, in your own words; if the pressure came from elsewhere or nothing was negotiated, say so plainly and stay with the quarter |
| F7 | "building device-management services" — JD | none given | none | [grounded] | discovery | Your material says a payments company and is silent on device or fleet work. Answer slot: if any of your work touched managing devices or connected equipment, say what and at what scope, in your own words; if none did, say so plainly and say how you would get up to speed |

## Round 1 — Tuesday, Director of Engineering (45 min)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Skeptic (4 questions) | Quiet probing of the gaps: hardware, scale, domain, why the move | Highest. A hiring manager is deciding who his own squads will depend on, and your message names two limits (F5, and the scale in F1) that sit squarely in his remit | Rehearse the single most predictable objection until it is boring; state the limit before he does; plans said as plans |
| B Case/Strategist (3) | Live problems from the actual role: inherit, arbitrate, diagnose | High. The hiring-manager prior is live problems on his own roadmap, and the JD's roadmap-partnership line gives him ready scenarios | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C Conversational (3) | Friendly opener, why us, how you grow people | Medium. The opener is near-certain in 45 minutes, and the casual register is still scored | A 90-second arc; treat casual questions about JD topics as scored |
| D Prober (2) | Line-by-line on the 60% and the 40 interviews | Low-medium. The two figures in your message are magnet targets, but this seat tilts to the other three | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |

Relationship prior plus the stated gaps; no interviewer profile was available, so no interviewer-signal adjustment.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "I don't see a hardware-adjacent roadmap in your background. How would you handle the hardware side of this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI prep in the pack: this will be asked in some form, here and again in rounds 2 and 3. Lead with the limit before he does: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan: who on the hardware side you would sit with first and the first two things you would ask them, in your own words. Follow-up 1 (how would you know what good looks like): hold, by returning to the plan, never by adding experience. Follow-up 2 (that is the hardest part of this job): concede it specifically, that it is a real gap and the learning curve is yours to carry, and do not fold on the plan. Answer slot: expect a probe on any contact with hardware teams; if you have worked with them in any form, say what and at what scope, in your own words; if not, say so plainly and return to the plan. If asked what is weakest on day one, this is the one to name, with one ramp step, never five gaps | F5 is the biggest stated gap and the one a hiring manager can test fastest. JD because it scores the stated hardware-partnership line; also the Skeptic's central probe |
| 1A2 | "You've been a team lead of six. This role is two squads and eleven engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | Say the scope as it is: "Three of my nine years in engineering have been as a team lead of six." Then say what you expect to change at eleven engineers across two squads as your thinking, not a past: two or three things you would do differently, in your own words. If asked about managing managers: "I've never managed managers." Answer slot: if any of your lead time covered work across more than one team, say how and at what scope; if it was one team, say so plainly and stay with the team of six. The question of whether the squads have their own leads belongs in your reverse questions | F1 is where the scale step presses. JD because it scores the lead-two-squads line |
| 1A3 | "What's behind the move to industrial IoT, and to this scope?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Give your actual reasons, one for the domain, one for the scope, one for this company, each a sentence in your own words. This pack supplies none, and a reason you do not hold is the one a second follow-up breaks. If part of it is that you want to manage, say so plainly | Motivation consistency is the Skeptic's second test after the gaps. EXP because it tests whether your story holds under cross-examination |
| 1A4 | "Have you worked on services that manage devices out in the field?" | JD | [grounded] | Answer slot: if any of your work touched managing devices or connected equipment, say what and at what scope, in your own words; if none did, say so plainly, then say how you would get up to speed, as a plan. Keep it to three sentences either way | F7 is silent in your material, so this is a discovery probe; the question is the JD's domain line asked directly |
| 1B1 | "You inherit two squads, eleven engineers and a roadmap you didn't write. What do you do in your first ninety days?" | CASE | [generic] | Structure aloud: what you need to know first (who owns what, what is committed, where the team hurts), your objective for the first month, how you would listen before changing anything, what you would measure by day ninety, and the main risk. Ask one clarifying question before you structure. This answer makes no claim about your past | A hiring manager's most natural live problem for this JD; `[generic]` because it is a pattern for the role, not a fact about Larkfield |
| 1B2 | "Product wants a capability next quarter. Hardware says a constraint means it can't land. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Clarify first: what the constraint is, what the capability is worth, what can move. Then options, a decision rule, and who you would bring in. Hold the structure through two follow-ups. If you reach for your own experience, the only beat you can claim is the quote's: a reliability quarter pushed through against roadmap pressure. Answer slot: if product partners were part of that pressure, say how it was worked out and what was yours; if not, say so plainly and stay with the quarter | F5 and F6 together: the scenario sits on the seam the JD names. CASE because it scores structure, with a quoted anchor for the one claim you might make |
| 1B3 | "Delivery is slipping on one squad and fine on the other. What do you look at?" | CASE | [generic] | Segment before diagnosing: scope, capacity, dependencies, decisions waiting on someone, team health. State your hypothesis early, say what would disprove it, and name the first conversation you would have. No claim about your past | F2's own-delivery requirement as a live problem rather than a record; avoids asking you to claim delivery ownership |
| 1C1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc with the beats the sentence carries: nine years in engineering, three of them as a team lead of six, currently at a payments company. Answer slot: one sentence each, in your own words, on what you worked on and why you stepped into leading. End on why this role, matching 1A3 | The near-certain opener; EXP because it is where the background first gets tested |
| 1C2 | "What do you know about Larkfield, and what's pulling you to industrial IoT?" | CO | [generic] | Search was not available in this run, so nothing here is researched about Larkfield. Prepare three facts from Larkfield's own site and open roles: what it sells, to whom, and one recent move. Say the facts, then what interests you, in your own words | CO is the homework check; `[generic]` is the honest label until the company brief arrives, and the upgrade menu says what moves it |
| 1C3 | "Tell me about an engineer you've helped grow." | EXP | [grounded] | The JD ties growth to eleven engineers. Pick a person where you can name the starting point, what you did, and what changed for them. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would approach it. Do not borrow the on-call story for this | F4 is silent, so this is a selection scaffold rather than a story map |
| 1D1 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Describe the sequence as the sentence has it: the burden dropped after the quarter. Answer slots, in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly. Never say the quarter caused it unless you can back that under a second question | The headline figure; EXP because probers go two levels deeper than the first answer |
| 1D2 | "You run the hiring loop — what did you actually decide?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say it at its own scope: you run the hiring loop for backend roles, about 40 interviews last year. Answer slot: the JD's own-hiring line makes a probe on decision rights likely. If hire or no-hire calls were yours, say how you made them; if a panel or others decided, say so plainly and describe your part. Also in your own words: how the "about 40" was counted, or that you do not know | F3 is the only direct row, so it gets pressed on how direct it is |

### Reverse questions for the Director

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Do the two squads have their own leads today, and how do you see my role relative to them?" | Opens the people-structure question for you to hear the answer rather than guess it |
| R1.2 | "What does good look like for me at 90 days and at 12 months?" | Makes the success bar explicit and shows you are thinking past onboarding |
| R1.3 | "Who on the hardware side would I work with most, and where do the squads' plans meet theirs?" | Turns your biggest stated gap into a learning plan in front of the person who will help close it |
| R1.4 | "What is the biggest risk to delivery on these squads right now?" | Shows you are scoping the real problem; the answer sizes your first ninety days |
| R1.5 | "How do you and your managers work together day to day, and what do you want from me?" | Reads the working relationship with your would-be boss directly |
| R1.6 | "What would make you say this hire was a mistake in the first six months?" | Surfaces the hidden objection while you can still answer it |

## Round 2 — Thursday, panel: two staff engineers and a product manager (60 min)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Peer Evaluator (4) | Seam-splitting, collaboration, credit, "what would you need from me" | Highest. All three panelists work beside the squads rather than above them, so partnership fit is what they price; the product manager adds the roadmap seam named in the JD (F6) | Reciprocity framing; seam principles instead of pretending to know the seam; disagreement stories showing spine and tact |
| B Prober (3) | Depth checks on the 60%, the hiring loop, how hands-on you are | Medium. Staff engineers verify technical claims; Round 1's figures return in collegial packaging | Know what you can say about each number; name the weakest assumption first |
| C Case/Strategist (2) | Live problems on device fleets and team health | Medium-low. The domain is theirs, so expect one scenario in their language | Clarify first; say plainly where the domain is new to you |
| D Conversational (2) | Introductions and what staff engineers need | Low-medium. A 60-minute panel opens warm | Short arc; treat it as scored |

Panelists' names and roles beyond the two titles were not given, so no per-member assignment; the weights blend the relationship priors.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Where's the seam between product and engineering, and what happens when we disagree about priorities?" | VAL | [generic] | Offer seam principles rather than claiming to know the seam: who decides what and who decides how; shared goals before trade-offs; what gets escalated and when. Then reciprocity: what the product manager can expect from you, and what you would ask of them. No claim about your past | The panel's product seat tests exactly the F6 seam; `[generic]` because it presupposes nothing about you |
| 2A2 | "A staff engineer thinks your call on a delivery trade-off is technically wrong. What happens?" | VAL | [generic] | Structure: ask for the reasoning first, separate the decision from the disagreement, say what would change your mind, and say who makes the final call and how it is recorded. Concede that a staff engineer may see the technical risk better than you | Two seats are staff engineers; credit and disagreement with equals is the Peer stem |
| 2A3 | "What do you need from the staff engineers on these squads, and what will they get from you?" | VAL | [generic] | Reciprocity first: what you bring them (clear priorities, air cover, a manager who learns the domain), then what you need (honest technical risk early). Say the first as commitments to behavior, not credentials | Peers price what a hire adds to their load |
| 2A4 | "Tell me about a time you disagreed with a product partner about priorities." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the sentence: a reliability quarter, roadmap pressure, and the on-call burden dropping 60% after it. Tell those beats in your own words. Answer slot: the JD's product-partnership line makes a probe on the other side likely; if product partners were part of the pressure, say what they wanted, what you said, and what was yours; if the pressure came from elsewhere or nothing was negotiated, say so plainly and stay with the quarter | F6 is the evidence for the product seam; EXP because it tests what was actually yours |
| 2B1 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The second pass on 1D1, so say the weakest assumption first, in your own words, before they do. Answer slot: what else changed in that period, if anything; if you do not know how the figure was counted, say so plainly. Keep "after", not "because" | The Prober's standard stem; a credibility gain if you name it first |
| 2B2 | "You run hiring for backend roles. How would you adapt that loop for the engineers these squads need?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say the quote's scope first: the loop is for backend roles. Then the adaptation as a plan, in your own words: what you would ask the panel and the hardware side before designing a loop for any role you have not hired before. Answer slot: if you designed or changed your loop, say what; if it was set by others, say so plainly. Ask what roles the squads hire for rather than assuming | F3's scope is backend; the squads' roles are not in your material |
| 2B3 | "How hands-on are you with code today?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer from what you actually do now, in your own words, and say plainly if you do not write production code. Do not stretch nine years in engineering into current hands-on work. A staff engineer scoring you wants the honest level and a view on how you stay close to the code | A staff-engineer staple; nothing in your material says how hands-on you are now |
| 2C1 | "A device-management service has to push a risky change to a fleet in the field. How do you decide whether to ship, stage or hold?" | CASE | [generic] | Clarify first: blast radius, rollback and recall, what the devices do if the change fails. Then staging, success measures and a stop rule. Say plainly where the hardware context is new to you and what you would ask the hardware side. No claim about your past | The domain scenario in the panel's own vocabulary; F7 and F5 stay honest because the answer claims nothing |
| 2C2 | "How would you tell, in your first quarter, whether these two squads are healthy?" | CASE | [generic] | Choose a small set across delivery, reliability and people, and say what each would not tell you (your weakest-assumption move on your own measures). Say who you would ask before trusting any number | F2 as a measurement problem; CASE because it scores structure |
| 2D1 | "Tell us who you are and what you'd bring to these squads." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Two minutes: nine years in engineering, three as a team lead of six, currently at a payments company. Answer slot: one sentence in your own words on what you would bring, limited to what the sentence and your other quoted lines carry. End by asking what they would most want from a manager | The panel's opener |
| 2D2 | "What do staff-level engineers need from their manager?" | VAL | [generic] | A short list from your own view: clarity on priorities, protection from churn, honest feedback, room to lead technically. Say which you would find hardest to deliver and why. No claim about your past | Staff engineers will use their own answer to judge yours |

### Reverse questions for the panel

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "How do product and engineering decide when reliability work wins over a feature?" | Puts the seam in the room and lets the product manager answer in their own terms |
| R2.2 | "What does a manager do that most helps staff engineers here?" | Shows you are asking what the role is for, not what it pays |
| R2.3 | "What could a new manager do in their first month that would genuinely help you?" | The reciprocity question for a panel of peers |
| R2.4 | "Where do the squads disagree most with hardware or product, and how does it get resolved?" | Surfaces the real seam, which you have said you have not owned |
| R2.5 | "What does on-call look like for these squads today?" | Gives you a place to connect your reliability quarter to their daily reality, in your own words |
| R2.6 | "How are technical decisions made and recorded?" | Shows respect for staff-level ownership and lets you see how much sits with them |

## Round 3 — Monday, VP Engineering (30 min, values and leadership philosophy)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Values/Behavioral (4) | Scenario probes on leadership, hard truths, people decisions | Highest. The recruiter's own description is "values and leadership philosophy", which documents a values-style round | Map a story where one of your quoted sentences carries one; a selection scaffold ending in the honest branch where none does; "we" for context, "I" for contribution |
| B Pressure (3) | Time-boxed challenges, "how much was actually you" | Medium-high. A skip-level in 30 minutes tests altitude and composure | Pause, restate, hold a challenged position through two follow-ups, concede specifically |
| C Skeptic (2) | The two stated limits, support needed | Medium. The VP will see the same gaps the Director saw | Say the limit plainly; plans as plans |
| D Case/Strategist (2) | Org-level thinking and what you want in a year | Low-medium. Altitude questions are short at this length | Clarify, then principles |

Larkfield's published values were not available in this run, so nothing below is mapped to a value by name; the stories are mapped to your quoted sentences, and the cheat sheet is in the upgrade menu.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the sentence: roadmap pressure, a reliability quarter you pushed through, the burden dropping 60% after it. Answer slot: if you took the case to leadership, say what you said and how it landed; if the decision was made elsewhere or it was not a conversation with leadership, say so plainly and choose a different example, or say what you would do. Do not supply an ending the sentence does not carry | Your strongest quoted story against the most common values stem; VAL because it scores behavior |
| 3A2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment where you held, and a relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. Nothing in your quoted material is a customer story, so none is assumed | A standard stem; your material gives it no quote |
| 3A3 | "What's your philosophy of leadership?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Two or three principles, each anchored to something you actually did, in your own words. Where a principle has no behavior behind it, say it is a belief you are still testing. Your quoted experience is a team lead of six; do not let the principles sound like they were tested across more | The recruiter named this directly |
| 3A4 | "Tell me about a hard decision about hiring or people." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | The sentence carries that you run the hiring loop for backend roles. Answer slot: if a hard call was yours, say what it was, how you decided and what happened; if you only contributed or no such call arose, say so plainly and describe how you run the loop. No decision is supplied here | JD's hiring and growth lines, asked at values altitude |
| 3B1 | "Sixty seconds: why you for a role leading two squads when you've been a team lead of six?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold what your sentences carry: the nine years, the team of six, the hiring loop, the quarter and the drop after it, in your own words, not as proof of readiness. Concede the scale step plainly: "I've never managed managers" and the hardware limit. Hold through two follow-ups by returning to those sentences | F1 as a pressure question; the hold is only what the quotes carry |
| 3B2 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the sentence: you pushed the quarter through; the burden dropped after. Concede specifically: say what others contributed, in your own words, and if you do not know how it was counted, say so plainly. Never fold on the core of what you did; never widen it | The Pressure stem aimed at your headline figure |
| 3B3 | "In sixty seconds, what's the strongest reason not to hire you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Say it first and plainly: "I've never managed managers and I've never owned a hardware-adjacent roadmap." Then the plan for each, one sentence each, said as plans. Do not add a third item to seem humble | You have named both limits yourself, so the honest answer is already written |
| 3C1 | "What worries you most about taking this role?" | EXP | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Choose one of the limits you have stated and say why it is the one, in your own words; say what you would do about it in the first months. Honest candor here is the point | The Skeptic's softer form of 1A1 |
| 3C2 | "Where would you need the most support in your first six months?" | EXP | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Name the support you would ask for, as a request: who and for what. Tie it to a limit you have stated, not to a vague "learning". No claim about your past | Tests self-awareness at skip-level altitude |
| 3D1 | "What should an engineering organisation of about 600 people be great at, and where does a manager like you fit?" | CO | [generic] | Principles first, then your place in them. The 600 comes from the role description you pasted; this run could not research Larkfield, so keep it to principles and ask what the VP thinks the company should be great at | CO question; `[generic]` until the company brief arrives |
| 3D2 | "What would you want to be true of your two squads a year from now?" | CASE | [generic] | Outcomes in three buckets: delivery, people, partnership with hardware and product. Say what you would measure and what the measure would miss. No claim about your past | Closes the loop on the JD's three halves at VP altitude |

### Reverse questions for the VP

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What leadership behaviors have mattered most to the people who have succeeded here?" | Asks for the values in practice, not as a slogan |
| R3.2 | "What is the hardest trade-off engineering leadership is facing right now?" | Lets you answer at their altitude and shows you are thinking about the company, not only the role |
| R3.3 | "How do you want engineering managers to disagree with you?" | Directly tests the fit with your own stated reliability story |
| R3.4 | "What would make you regret this hire a year from now?" | Surfaces the last objection while you can still address it |
| R3.5 | "How does the company grow engineering managers?" | Fits the limits you have stated and shows you intend to be developed |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Lead two squads" | 1A2, 3B1, 3D2 |
| "building device-management services" | 1A4, 2C1 |
| "own delivery" | 1B3, 1D1, 2C2 |
| "hiring" | 1D2, 2B2, 3A4 |
| "growth for 11 engineers" | 1C3, 2D2, 3A4 |
| "partner with hardware" | 1A1, 1B2, 2C1, 3B3 |
| "partner with hardware and product on roadmap" (product side) | 1B2, 2A1, 2A4 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers | Negative you stated: "I've never managed managers and never owned a hardware-adjacent roadmap." | Your own words: "I've never managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, same sentence | Your own words: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan |
| Led two squads or eleven engineers | Inflated form of F1 | Your sentence at its own scope: a team lead of six. The pack's observation: your material says one team of six |
| Owned delivery for a roadmap | Inflated form of F2 | Your sentence at its own scope: a reliability quarter you pushed through, and the burden dropping after it. The pack's observation: the sentence is not a delivery plan |
| The reliability quarter caused the 60% drop | Inflated form of F2 | Your sentence says "after", not "because"; keep it |
| Owned hiring decisions | Inflated form of F3 | Your sentence at its own scope: you run the hiring loop for backend roles, about 40 interviews last year. The slot in 1D2 stays inside it |

## Sources

Provided documents: your message (the role description, the three rounds, your background in four sentences). No CV and no full JD were provided.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

Calls sent:

- "Larkfield Systems industrial IoT values" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have fed the values cheat sheet and named-value story mapping for round 3 (3A1 to 3A4); both calls refused |
| 2. `Larkfield Systems interview process` | skipped | Your own words fix the loop: three rounds, with who runs each and how long |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have grounded 1C2 and 3D1 as CO questions rather than `[generic]`; the call was refused |
| 4. interviewer name and company | n/a | No names were given, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | skipped | The role description you gave fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV and the full JD text → your four sentences become exact quotes for F1 to F7, F4 and F7 may gain evidence, and the six `[grounded]` rows with no inspected proof can rise above medium
- Larkfield's published values page, pasted → a values cheat sheet for round 3 and named-value stories for 3A1 to 3A4
- Search access, or a pasted strategy brief → 1C2 and 3D1 become grounded CO questions; a deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, is available once and only if you want it
- The interviewers' names → an interviewer read, per-member persona weights for the panel, and a reverse question tied to each person's path
- The recruiter's prep email → coverage of any pre-declared focus areas, and the panel's format
- Anything about contact with hardware, firmware or embedded teams in any form → upgrades F5 and 1A1
- Anything about developing an engineer, or about device or connected-equipment work → upgrades F4, 1C3, 2D2, F7 and 1A4
- A `tuesday-dossier.md` from an earlier evidence check → verified evidence and any prohibited claims it records, in place of the ones built here
