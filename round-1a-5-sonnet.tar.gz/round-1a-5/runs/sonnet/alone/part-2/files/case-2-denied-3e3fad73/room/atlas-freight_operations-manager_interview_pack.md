# Interview prep pack: Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees), per the JD you pasted
- **Interviewer and relationship:** not known. This pack assumes an unknown round type and uses flat persona weights, ordered by where your fit snapshot shows the most pressure
- **Research:** the three company searches I tried were refused, so nothing here comes from outside your JD and your message (Sources has the detail)

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did.

An **answer slot** is an instruction for the interview, not a question for you now. It names a probe the JD makes likely, then gives two honest branches: if you did it, say how; if there was no such step, or it was not yours, say so plainly and return to what you did say. Either branch is a good answer.

Question IDs skip the letter F so they do not clash with fit-snapshot rows F1 to F7.

| Type | What it scores |
|---|---|
| VAL | Behavioral and values alignment: whether past behavior shows the stated values |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny and attribution is honest |
| JD | Role and JD requirements: whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth |
| CASE | Live problem from the role: structure and reasoning |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift and one site's surge plan in warehouse and distribution; it does not establish four sites or terminal operations. Words stay at the quotes: "Currently I'm a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four sites make a probe on reach likely. If any responsibility of yours extended beyond your own shift or site, say what it covered; if none did, say so plainly and stay with the shift and the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material states mis-pick rate, not on-time performance or cost per shipment. Words stay at: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names two measures, so a probe on them is likely. If you tracked either, say which and how it was counted; if you did not, say so plainly and stay with the mis-pick rate |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The JD says twelve; your material says 3. Words stay at: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led more than 3 supervisors in any role, say how many and in which role; if not, say so plainly and stay with the 3. How you would lead twelve is a plan, said as a plan and never as a past |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" does not say whether it was used for reporting or what for, and the bridge should not be stretched. Answer slot: if you built reports in Excel that other people used, say which and who used them; if Excel was for your own working, say so plainly and say what you used it for |
| F5 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller. The JD joins the two tools with a slash; whether one suffices is a question for R1 |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | discovery | Your material gives seven years in operations, not how many of them were spent leading others. Words stay at: "I have 7 years in warehouse and distribution ops." Answer slot: say which of your seven years were in roles leading others, and which roles; if none or few were, say so plainly and say what the other years were, in your own words |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a one-line claim with no certificate or project inspected, so expect a probe. Lead with the quote's own terms: "I'm green belt certified." Answer slot: expect "what did you do with it?" If a project of yours applied it, say which and what part was yours; if none did, say so plainly |

## Persona table

No loop source establishes this loop, so the fallback archetype is Generic: flat weights, said plainly. The ordering below is my judgment from the fit snapshot, not a documented read of Atlas Freight's process. If you learn the round type, the weights change (see the question at the end of my message).

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet, persistent probing of scale, background fit, weakest area, why leave and why here | High. F1, F3, F5 and F6 are the rows where the JD asks for more than your material shows, and a skeptic aims at exactly those | Rehearse the scale-jump objection (A1) until it is boring; bridge only from what you stated; calibrated candor over bluffing |
| Case / Strategist (bank B) | Live problems from the role: diagnose on-time performance, cost per shipment, plan a surge | High. The JD's role is daily operational calls against two named measures (F2), so live problems on them are likely | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (bank C) | Reads your one headline number line by line | Medium. F2 holds the only figure in your material | Know what you can and cannot say about how the 40% was counted; say plainly when you do not know |
| Pressure (bank D) | Time-boxed, interrupting, devil's advocate on your stated gaps | Medium. Unknown whether any interviewer uses this style; F5 and F3 give it material | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |
| Conversational (bank E) | Friendly opener and casual questions that are still scored | Medium. Any round can open with the biography question | A 90-second arc built only from your own sentences; treat casual questions as scored |
| Peer Evaluator (bank G) | Seam-splitting with adjacent site and terminal leads | Low unless a peer is in the loop; nothing says one is | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Values / Behavioral (bank H) | Scenario probes on leading people | Low. No loop source documents a values round and no published values were read | Choose stories where the hard truth actually landed; where none comes to mind, say so |

## Question banks

**Highest-ROI prep in this pack: A1**, the scale-jump objection. It targets the widest distance between the JD and your material (F3, F1), so it will arrive in some form.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role leads twelve supervisors across four sites, and you currently have three. Why should we believe you can step up?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Deepest rehearsal. Hold on the quote at its own scope: "Currently I'm a senior shift manager over 3 supervisors." Say it plainly as the starting point; add no "effectively" or "in practice". Answer slot: if you have led more than 3 supervisors in any role, say how many and in which role; if not, say so plainly and stay with the 3. Follow-up 1, "what changes at twelve": say what you would do differently, as a plan and not a past claim. Follow-up 2, "what worries you most": name the one thing you would want to learn first about the four sites. Do not retreat from the opening line to restore harmony | F3 and F1 are where the JD most outruns the material, so this objection is the likeliest single question. JD because it scores the stated team-size requirement |
| A2 | "Your background is in warehouse and distribution. How does that compare with running terminals?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say what the quote says: "7 years in warehouse and distribution ops." Answer slot: the JD's "daily terminal operations" makes a probe on terminal work likely. If you have worked in a terminal, say where and in what role; if not, say so plainly and say what you would ask first to learn how the terminals here run | F1 carries the only match for this requirement and it is adjacent, not direct. JD because it scores the stated responsibility |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick a gap from your own material and say it plainly. The one you have already stated is Power BI: "I've never used Power BI." Then say how you would close it, as your own plan. If a different part is honestly your weakest, F1, F3 and F6 are the other rows the snapshot shows; say that one instead and say it just as plainly | F5 is a stated negative, so it is the safest honest answer to a question that rewards calibrated candor. JD because it asks about fit to the listed job |
| A4 | "What's prompting a move now, and why Atlas Freight?" | EXP | [generic] | Give your actual reason in one sentence. Then connect it to something in the posting you can name, such as the four sites, the twelve supervisors, or the two measures, only if it is true for you. If your honest reason is less polished than the posting's language, say the true part plainly | The skeptic's "why leave, why here, why now" is a motivation-consistency check. EXP because it tests whether your story holds together; `[generic]` because it needs no claim about your past |
| A5 | "The posting asks for five-plus years of operations leadership. How many of your seven years were leading others?" | JD | [grounded] "7 years in warehouse and distribution ops" | Open with the quote: "7 years in warehouse and distribution ops." Answer slot: say which of your seven years were in roles leading others, and which roles; if none or few were, say so plainly and say what the other years were, in your own words. The count is yours: do not round | F6 is the requirement the posting marks required, so a direct question on it is likely. JD because it scores that requirement |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance has slipped at one of the four sites over the last month. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify first: how on-time is defined and measured, what changed and when. Objective. Segment by site, lane, customer, time of day. Hypotheses and the data you would pull to test each. What you would do in the first 48 hours versus the first month. Risks. This is a structure to speak aloud and it makes no claim about your past | F2 names on-time performance as a target, so a live problem on it is likely. CASE because it scores structure on a role problem |
| B2 | "Cost per shipment is rising. Where do you look first?" | JD | [generic] | Ask how cost per shipment is defined at Atlas Freight, then break it into its parts and rank where you would look first and why. Name the one premise you would challenge, for example whether the rise is real or a change in the mix. Say what data you would need. A structure, not a claim about your past | F2's second measure. JD primary because it scores a stated responsibility; CASE delivery |
| B3 | "Peak is six weeks out and forecast volume is well above normal at all four sites. Walk me through your plan." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure it: clarify the forecast and what constrains each site, objective, segmentation by site, plan, metrics, risks, one premise you would challenge. Your own experience enters only at the quote's scope: "I ran the site's peak-season surge plan two years running." Say in your own words what you would carry over, and describe as past practice only what you did | F1 holds the surge plan, the closest match to this scenario. CASE because it tests reasoning on a live problem |
| B4 | "You take over four sites next week. What do you want to know in your first 30 days?" | CASE | [generic] | Clarify what you are accountable for, then say how you would learn it: which sites you would see first and why, who you would meet, which baseline numbers you would ask for. A plan said as a plan. This doubles as your answer to "how would you ramp" in A1 | F1 and F3 are the scale gaps, and a ramp plan is the Skeptic counter-strategy. CASE because it is a live problem |
| B5 | "How would you build a weekly performance report for the four sites? What's on it, and who is it for?" | JD | [grounded] "solid Excel"; "never used Power BI" | Audience first, then the decisions the report supports, then the measures (the JD's two, on-time performance and cost per shipment), their definitions, cadence and data sources. On tooling say what is true: your stated strength is "solid Excel", and "I've never used Power BI." Answer slot: if you built reports in Excel that others used, say which; if not, say so plainly | F4 and F5 are the reporting rows. JD because the JD lists reporting; CASE delivery |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Start from the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say how the rate was counted, over what periods, and what it is sensitive to, in your own words; if you do not know how it was counted, say so plainly. Name the assumption you would defend least before they do | F2's only figure, and a headline number draws a defend-the-number probe. EXP because it tests whether the claim survives scrutiny |
| C2 | "What else could have moved that number besides the pick path?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold on the quote's attribution: you cut it "by redesigning the pick path". Answer slot: if anything else changed in that period, say what; if nothing did, or you do not know, say so plainly. Do not defend the figure by adding detail you cannot repeat under a second question | The follow-up two levels below C1. EXP because it probes attribution |
| C3 | "You redesigned the pick path. Who else was involved, and which decisions were yours?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say "we" for context and "I" for your contribution. Answer slot: say which decisions were yours; if the redesign was shared or someone else owned parts of it, say so plainly and describe your part. Only what you did | Attribution honesty on F2. EXP because it asks what was actually yours |

### D. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, rather than someone who already runs several sites?" | EXP | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "currently a senior shift manager over 3 supervisors" | Pause and restate the question. Then three beats in the quotes' own words: the surge plan two years running, the 40% mis-pick cut by redesigning the pick path, and your current role over 3 supervisors. Concede the scale in the same breath: your current scope is the 3. Say what you would bring in your own words, and hold through two follow-ups without adding to the quotes | The time-boxed "why you" is the Pressure persona's signature. F1, F2 and F3 supply every beat. EXP because it tests what was actually yours |
| D2 | "You've never used Power BI. Why hire you into a reporting role?" | JD | [grounded] "never used Power BI"; "solid Excel" | Pause. Do not argue with the fact: "I've never used Power BI." Then your stated strength, "solid Excel", and how you would learn the new tool, as a plan. Hold through two follow-ups and concede the tool gap specifically. Answer slot: if you built reports in Excel that others used, say which; if not, say so plainly | F5 is a stated negative and F4 is its counterpart. JD because it scores the reporting requirement; Pressure supplies the register |
| D3 | "Does a green belt matter on a busy terminal floor? Persuade me." | JD | [grounded] "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path" | Hold on the quote: "I'm green belt certified." Answer slot: if the pick-path redesign was a project you ran for the belt, say so; if it was not, say what project was, or that no project was tied to it. Do not claim the redesign was a Lean or Six Sigma project unless it was. Concede what a certificate shows and does not, in your own words | F7 is the posting's "plus", and the likeliest place a certification is pressed. JD because it scores that requirement |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey into operations." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc with only the beats your quotes carry: the seven years in warehouse and distribution ops, and where you are now, a senior shift manager over 3 supervisors. The order of your roles in between is yours to tell; add no title or date you have not given. End on why this role, in one sentence | The biography question opens many rounds, and F6 and F3 are the rows an interviewer will listen for in it. EXP because it tests whether the story hangs together |
| E2 | "What do you know about Atlas Freight, and what interests you?" | CO | [grounded] | The posting says regional logistics, 800 employees, four sites. Say that much as the posting states it, and do not add facts you have not read. Before the interview, read the company's own site and any recent news, and say only what you found there; if you know little, say so plainly and ask them about it | No company research ran, so this question rests on the JD's own words alone. CO because it tests homework depth |
| E3 | "What would your supervisors say about working for you?" | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Pick one concrete thing a supervisor of yours would recognize, something you actually do, and describe it in your own words. The quote gives only your role over 3 supervisors, so the behavior is yours to name. If no example comes to mind, say so plainly and describe how you would want to be described | F3's leadership evidence is a role, not a behavior, so this casual question has to be answered from your own experience. VAL because it surfaces how you lead |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You'd sit alongside the other site and terminal leads. Where does your job end and theirs start, and what happens when we disagree?" | CASE | [generic] | Do not pretend to know the seam. Propose principles: who owns which decision, how a disagreement gets escalated and how fast, what each side needs from the other. Say what you would ask to find out how it works today. A structure, not a claim about your past | F1's four-site scope puts the role next to other leads. CASE because it is a live collaboration problem |
| G2 | "How do you handle credit when a result belongs to more than one team?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say "we" for context and "I" for your contribution. Answer slot: if the pick-path work involved other people or teams, say whose part was whose; if it was yours alone, say so plainly. Only what you did | F2's attribution again, in collegial packaging. EXP because it probes credit-sharing |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a thing you actually said, and an intact relationship afterward. Use "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values-round stem. No values round is documented, so it is `[generic]`. VAL because it tests behavior under pressure |
| H2 | "Tell me about a time a supervisor on your team wasn't performing." | VAL | [generic] | Pick a time with a named situation, what you said or did, and what happened next. Describe only what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD asks you to lead twelve supervisors (F3). VAL because it tests how you manage people |

### Requirement coverage

| JD requirement | Covered by | JD-tagged question |
|---|---|---|
| "Own daily terminal operations across 4 sites" | A2, B3, B4, G1 | A2 |
| "drive on-time performance and cost-per-shipment down" | B1, B2 | B2 |
| "lead a team of 12 supervisors" | A1, B4, E3, H2 | A1 |
| "build reporting in Excel/Power BI" | A3, B5, D2 | B5, D2 |
| "5+ years operations leadership required" | A5, E1 | A5 |
| "Lean/Six Sigma a plus" | D3 | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Is Excel enough for the reporting today, or is Power BI expected from the start? What does the current reporting look like?" | The JD joins the two tools with a slash, and the answer tells you how much of F5 matters on day one |
| R2 | "What do on-time performance and cost-per-shipment look like at the four sites today, and how is each measured?" | The JD names both as targets, so this gets you the baseline and the definition you would need before any plan |
| R3 | "How are the twelve supervisors spread across the four sites, and who do they report to today?" | It signals you are already thinking about the span of the role, which is the F3 gap |
| R4 | "What would a good first 90 days look like, and what would make you say it went well a year in?" | It converts the interview into a conversation about expectations and shows you plan for the ramp (B4) |
| R5 | "What is the hardest operational problem across the sites right now?" | It shows you think in problems and tells you what the first months would actually be |
| R6 | "Which site should I get to know first, and who would I be working with there?" | It makes the ramp concrete and shows you expect to be on the ground |
| R7 | If you are meeting a peer: "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer round; it shifts from what you need to what you bring |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran operations across the four sites, or ran terminals | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says a shift and the site's surge plan in warehouse and distribution. A2's slot stays inside what you have worked |
| Improved on-time performance or cost per shipment | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material states mis-pick rate. C1's slot asks only how that figure was counted |
| Led a team of twelve, or a large team | Inflated form of F3 | F3's quote at its own scope: a senior shift manager over 3 supervisors. A1's slot asks only about any role where you led more than that |
| Experience building reports in Power BI | Negative you stated, F5 | The plain acknowledgment: "I've never used Power BI." No slot |
| Seven years of operations leadership | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the material says seven years in operations, not how many were spent leading others. A5's slot asks which years were |

## Sources

Provided documents: the JD text you pasted and your background as written in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have fed a values cheat sheet; none is included because no values were read and no values round is documented |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. Persona weights fall back to the Generic archetype and are flat; this is a pattern, not Atlas Freight's documented loop |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. No CO or CASE question is grounded in company strategy, and E2 rests on the JD's own words only |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent, all refused:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics news strategy" — refused

## Upgrade menu

- The interviewer's name and role, and the round type → persona weights read from their public footprint, a tailored reverse question tied to their path, and a restructured bank order
- Anything the recruiter said about focus areas, or a task or presentation to prepare → a build section for any pre-declared deliverable, and coverage tuned to the stated focus
- Your answers to the answer slots on F1, F2, F3, F4, F6 and F7 → each is quoted into the snapshot and the rows that draw on it are regenerated, and several `transferability` and `discovery` rows can move
- The before-and-after mis-pick report behind the 40%, and your green-belt certificate → inspectable artifacts that could raise F2 and F7 above `medium`
- Your CV text, with the roles and dates for the seven years → F6 and F3 can quote the CV, and A5 and E1 can be built on dated roles
- A pasted copy of Atlas Freight's values page, a recent news item or the recruiter's description of the interview loop → a values cheat sheet if the loop has a values round, a CO question grounded in current strategy, and loop-specific persona weights
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence, per-gap strategy constraints, and an evidence-based highest-ROI objection in place of the one inferred here
