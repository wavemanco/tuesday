I've read the skill's rules and templates. I'm now checking the interaction grammar for the research-tier accounting, and then I'll build the pack.
Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. It's a loop pack with a shared fit snapshot and a mini-pack per round: 8 questions for the recruiter, 10 for the Head of Member Services and 10 for the panel, each round with its own reverse questions. I used only what you pasted and ran no web research. The pack's Sources section says what each pasted item fixed.

- **Highest-ROI prep:** question 2B1, "you haven't worked in a contact centre, so why should I think you can do this?" Your own words give a plain concession and a hold on the complaints log, with two follow-ups rehearsed.
- **Your gaps:** your message states two. You've never worked in a contact centre and have never presented above regional level. The pack coaches plain acknowledgments for both, plus a plan, and doesn't stretch your quotes.
- **Values round:** none of your four sentences carries a story for any of the four values, so each value gets an honest "pick a real story, or say so" scaffold. It does not supply a story.
- **Hub consolidation:** the strategy brief you relayed doesn't say which branches become hubs, so the panel's branch managers may be personally affected. Question 3C3 keeps you neutral on that.
- **Interviewers:** none are assigned yet, so there is no interviewer read. The upgrade menu says what names would add.
- **Your own words:** your pay, notice, location and reason for leaving are blank for you to fill in. I only wrote the instructions.

Say the word and I'll play the Skeptic on 2B1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop (loop mode, all on 4 December 2026):** Round 1, 30 minutes with the recruiter. Round 2, 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural. Round 3, 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation; the panel also scores against the four published values. No interviewer names are assigned yet, so there is no interviewer read in this pack.

## How to use this pack

- **Personas describe how a question arrives; types describe what it scores.** Round 1 is a friendly screen with logistics; Round 2 is a manager deciding whether your gaps are safe; Round 3 is a panel scoring values and watching you work a case.
- **Type key:** VAL scores whether your past behaviour shows Ashgrove's published values. EXP tests whether what you've said about your work survives follow-up. JD scores the listed requirements. CO tests how well you know Ashgrove's strategy. CASE is a live problem from the role.
- **Guidance is scaffolding, not a script.** Say it in your own words. Anything marked "answer slot" is an instruction for the interview: answer from what actually happened, and if the practice was not yours or never existed, say so plainly and return to what you did do.
- **Question IDs** read round, persona letter, number: 1A1 is Round 1, Conversational, first question. Letters: A Conversational, B Skeptic, C Case/Strategist, D Values/Behavioral, E Peer Evaluator, G Data-Driven Prober.

## Prep triage

The window is 25 November to 4 December, nine days; your hours per day aren't stated, so this is an order, not a timetable.

1. **2B1, then 1B1:** the contact-centre concession and hold. Highest-ROI prep in the pack (reasoning in the persona table).
2. **1A3 to 1A6:** your own pay, notice, location and reason-for-leaving words, written down once and reused. Your reason in 1A6 must be word-for-word the same in 1A1, 2B3 and with the panel.
3. **3C1 aloud, twice:** the 20-minute escalation case is a third of the panel hour.
4. **3D1 to 3D4:** pick or honestly fail to find one story per value; the cheat sheet in Round 3 shows where a story is and isn't carried by your material.
5. **2G1 and 2B2:** what your spreadsheet counted, and your plan for the first senior-leader presentation.

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

No gate rows: the JD text you pasted states no term you either meet or don't (pay, location, licence, schedule), and "4+ years" is a length of experience, graded below like any requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process across branches, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat around the log likely, where complaints came from and where they went. If any of that was yours, say which part, in your own words; if the log was the whole of your part, or any part was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past: you would start by listening to calls and asking the team how complaints reach them. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote says a spreadsheet you built that your regional manager uses; it does not show what the spreadsheet counted. Answer slot: expect a probe on what it counted and how. Say what it counted, in your own words; if you do not know how a figure in it was counted, say so plainly, and say what you would count first |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote says spreadsheet and does not name the tool. Answer slot: if you built it in Excel, say so; if in another tool, say which, and say plainly how comfortable you are in Excel today |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers, not supervisors, and the words stay there: "I trained new tellers on our escalation script." The step to supervisors is a plan, not a past: what you would ask them first. Answer slot: expect a probe on what the training covered. Say what it covered, in your own words; if any part was not yours, say so plainly and stay with what you did |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way, so wording cannot close this. Answer slot: if you have worked with a digital team, or on any self-service journey, say what your part was, in your own words; if not, say so plainly and say what you would want to learn from a digital team first |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The quote reaches the years in other terms than the JD's. Words, from the quote only: "I've had six years in retail banking, the last three as a branch supervisor." Whether branch work counts as customer operations is the interviewer's call; stay in the quote's terms |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | "Formal" is the quote's word; the material does not show what rules the log ran under. Answer slot: expect a probe on the frame the log ran under. If you worked to specific rules or deadlines, name them in your own words; if you do not know which applied, or there were none you worked to, say so plainly and stay with the log |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I haven't presented to anyone above regional level." Then a plan, never a past: ask who the audience is and what decision each person takes from the numbers, and ask your manager to hear a first run |

## Grounding brief (shared)

Source: the 2026 strategy brief the recruiter sent you, as you summarised it; the brief's own text was not in front of me. It was published in July 2026, four months before today (25 November 2026), so nothing in it is stale yet.

| Item | What the brief says, as relayed | Provenance |
|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] |
| Branch network | "consolidate eight branches into five hubs over 2027" | [grounded] |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] |
| Competition | "the main competitive pressure is app-only banks" | [grounded] |
| Organisation | "member-owned, about 900 staff" — JD | [grounded] |
| Reading: digital and complaints | More of what members say is wrong may arrive through channels with no person on the other end; self-service that makes a member explain twice would break "Plain Words". Rehearse as questions to ask, not facts about Ashgrove | [inferred] |
| Reading: hubs and ownership | A complaint can fall between sites while branches become hubs, which is "Own the Fix" under strain. The brief as relayed does not say which branches are affected, so whether either panel member's branch is affected is not established; treat the room as possibly affected and don't cheer-lead | [inferred] |
| Reading: small-business lending | A new product brings a new kind of member and possibly new kinds of complaint; whether the complaints process is in the launch plan is a fair question to ask | [inferred] |

## Persona table (weights per round, reasoning shown)

| Round and persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| R1 Conversational | Friendly 30 minutes: "walk me through the journey", then pay, notice, location, why leaving | High. Recruiter prior; the email states no focus areas, so logistics and motivation are assumed | A 90-second arc; each logistics answer in your own words, same every round |
| R1 Skeptic (light) | Knockout checks on the JD's plain lines | Medium. The JD's first line names the contact centre and another names senior leaders, and both are stated gaps in your message | Plain acknowledgment, then a plan; no cushioning |
| R2 Skeptic | The manager testing the contact-centre gap, the senior-presenting gap and the motive for moving | High. Hiring-manager prior is "buying capability, derisking gaps", and this person would be your manager | Hold-then-concede; the single most likely objection is 2B1, so it is the highest-ROI prep in the pack |
| R2 Values/Behavioral | "Tell me about a time…" prompts | High. The recruiter calls this round "mostly behavioural" | Story selection from your real material; where none exists, say so and give the nearest thing |
| R2 Prober | Questions on the spreadsheet | Medium. The JD names monthly reporting and Excel, and the spreadsheet is your one concrete artifact | Know what it counted or say you don't know how a figure was counted |
| R2 Case/Strategist | Digital-shift question | Low to medium. A mostly behavioural round leaves little room, but the strategy brief invites one | Clarify, then structure aloud |
| R3 Values/Behavioral | One prompt per value | Highest. The recruiter says the panel "is also the values round — they score against the four values" | A story or an honest scaffold per value; plain words |
| R3 Case/Strategist | The 20-minute complaint-escalation case, plus the hubs question | High. A 20-minute case is named for this round | Clarify, structure, member first, one owner, close the loop |
| R3 Peer Evaluator | Branch managers asking what your function means for their branch | Medium. Two branch managers whose supervisors you would coach and whose branches you would report on; their exact relationship to the role is not stated | Reciprocity: what they get from you, not only what you need |
| R3 Pressure | Pushback on hubs or on branch numbers | Low. Nothing says the panel is adversarial; consolidation could make a question sharp | Hold, concede specifically, don't argue the strategy |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | 1B1, 2B1, 3C1, 3C3, 3E3 |
| Report monthly on complaint volumes and resolution times | 2G1, 2G2, 3E2 |
| Coach branch supervisors on escalations | 3C2 |
| Work with digital teams on self-service journeys | 2C1, 2D3 |
| 4+ years in financial-services customer operations | 1A1, 2B3 |
| Experience handling regulated complaints | 2B4, 3C1 |
| Confident presenting to senior leaders | 1B2, 2B2, 2D2 |
| Comfortable with Excel reporting | 2G1 |
| Pay, notice, location, reason for leaving (recruiter logistics) | 1A3, 1A4, 1A5, 1A6 |
| The four published values | 3D1, 3D2, 3D3, 3D4 |

---

## Round 1 — Recruiter, 30 minutes

**Weights:** Conversational 6 questions, Skeptic (light) 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" | A 90-second arc with the beats the quotes state: six years in retail banking, the last three as a branch supervisor, and that you handled the branch's formal complaints log. Tell them in your own words. End on one sentence of your own about why this role; no quote here supplies it, so it has to be true for you | F7 and F1 are the spine of your CV story; EXP because a recruiter screen checks the biography matches what a manager will probe later |
| 1A2 | "What drew you to Ashgrove?" | CO | [grounded] | Your reason is yours. The published words you can point to are Ashgrove's own: "Members First, Always", "Plain Words", "Neighbours, Not Numbers", "Own the Fix". Pick the one that is true for you and say why in your own words; if none is, say what is. You may name one strategy item, such as the 40% digital shift by 2028, only if you can say why it matters to you. Make no claim about past experience here | CO because it tests homework and motivation together; the answer must match 1A6 and 2B3, which is why it sits early |
| 1A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot, and the only safe answer is your own: give your own figure, or ask what band the role carries before naming one. If asked what you earn now: "I'd rather focus on the range for this role." This pack supplies no figure; you haven't given one and the JD text states none | A recruiter screen carries pay as a standing question; JD because it is a term of the listed job |
| 1A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period as your contract states it | Standing recruiter question, and the one answer nobody can prepare for you; JD because it is a term of the listed job |
| 1A5 | "Where would you be working from, and does the working pattern suit you?" | JD | [generic] | Logistics slot: state where you can work and how often, in your own terms. The JD does not state the role's location pattern, so ask the recruiter for it (see Round 1 reverse questions) before you commit to anything | The role spans branches and the contact centre, so location is likely to matter; JD because it is a term of the listed job |
| 1A6 | "What's prompting a move now?" | EXP | [generic] | Logistics slot: give your own reason in one sentence, in words you would be content to repeat to the Head of Member Services and to the panel. Same words every round; a reason that changes between rounds is the thing recruiters note | Reason for leaving is the standing motivation check; EXP because it is about your own history and decisions |
| 1B1 | "Which part of this role would be new to you?" | JD | [grounded] "Never worked in a contact centre" | Say it first and plain: "I haven't worked in a contact centre." Then stop. Then the plan, said as a plan: you would start by listening to calls and asking the team how complaints reach them. Don't try to bridge it here; the full hold is rehearsed in 2B1 | F2 is the gap the screen cannot skip, since the JD's first line names the contact centre; JD because it scores a stated requirement |
| 1B2 | "The role presents to senior leaders. What's the most senior group you've presented to?" | JD | [grounded] "I've never presented to anyone above regional level." | Answer plainly: "I haven't presented to anyone above regional level." Don't stretch "regional" into something bigger. Then the plan: ask who the audience is and what decision each person takes from the numbers, and ask your manager to hear a first run | F9 is a stated gap against a JD line; JD because it scores that line |

**Reverse questions, Round 1**

| # | Question | Why it lands |
|---|---|---|
| 1R1 | "Is there anything about the 20-minute escalation case I can prepare with, and will it be written or spoken?" | Only the recruiter knows the format; it shows you prepare |
| 1R2 | "Who is on the panel, and could you tell me before 4 December?" | Interviewers aren't assigned yet; names would unlock an interviewer read |
| 1R3 | "Where would this role be based as the eight branches become five hubs?" | Ties your question to the published strategy and settles the location question you can't yet answer |
| 1R4 | "Is this a new role or a replacement, and what changed in how complaints were handled to create it?" | Tells you whether you are building or inheriting |
| 1R5 | "What will you tell the Head of Member Services about this call?" | Shows you know the recruiter's notes travel, which is why 1A6 must stay consistent |

---

## Round 2 — Head of Member Services (your manager), 45 minutes, mostly behavioural

**Weights:** Skeptic 4, Values/Behavioral 3, Prober 2, Case 1.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2B1 | "This role owns complaints across the branches and the contact centre, and you haven't worked in a contact centre. Why should I think you can do it?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | **Hold-then-concede.** First, concede plainly: "I haven't worked in a contact centre." Then hold at the quote's scope: "I handled the branch's formal complaints log." Then the plan, as a plan: listen to calls, sit with the team, ask where complaints cross between a channel and a branch. Follow-up one, "Everything you know is branch-side; what would you get wrong first?": concede specifically, and name the assumption you would defend least, that what works in a branch log carries over to the phone, and say how you would test it. Follow-up two, "Why not hire someone from our contact centre?": don't disparage the alternative; say that person knows the phone side and you would have to learn it, then return to the log, the part you can speak to from your own experience. Never add contact-centre knowledge you don't have, and never fold the first concession to fix the mood | F2 is the gap in the JD's first line, and your manager's job in this round is to price it. This is the single most predictable objection, so it is the highest-ROI prep in the pack: deepest follow-ups, exact concession wording. JD because it scores a stated requirement; the delivery is Skeptic |
| 2B2 | "Monthly reporting goes to senior leaders, and you haven't presented above regional level. How do you get ready for that room?" | JD | [grounded] "I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Concede first: "I haven't presented to anyone above regional level." Hold at the quote's scope: "I built the monthly complaints spreadsheet our regional manager uses." Then the plan: ask what decision each leader takes from the numbers, keep the page to what that decision needs, and ask your manager to hear a first run. If pushed with "is that enough?", concede that the first one will be new and don't claim confidence you haven't earned | F9 and F3 together: the stated gap and the one artifact you can point to. JD because it scores a stated requirement |
| 2B3 | "Why leave a supervisor role for this one?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Your own reason, in the same words as 1A6. The quote carries two beats, six years in retail banking and the last three as a supervisor; the reason for moving is not in any quote, so it must be true for you. Answer slot: what you would gain and what you would give up are yours to name; if part of your reason is uncomfortable, say it plainly and briefly | F7 covers the years; EXP because the manager is checking motivation holds up against the recruiter's notes |
| 2B4 | "Which rules or deadlines did your branch's formal complaints log have to meet?" | JD | [grounded] "I handled the branch's formal complaints log" | Start from the quote: "I handled the branch's formal complaints log." Answer slot: the JD asks for experience handling regulated complaints, so expect a probe on the frame the log ran under. If you worked to specific rules or deadlines, name them in your own words; if you do not know which applied, or there were none you worked to, say so plainly and stay with the log, then say what you would learn first about Ashgrove's | F8 is the JD line where your quote is thinnest; the question's premise is the JD's and the guidance does not adopt it. JD because it scores a stated requirement |
| 2D1 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, since the quote carries no story: a named problem (no member identity), the point where it could have been passed on, what you did to keep hold, how it ended and what the member was told. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the log, at its own words, or how you would keep hold | The theme comes from the published value "Own the Fix". VAL because it asks for behaviour that shows that value |
| 2D2 | "Tell me about a time you delivered an unwelcome truth to someone more senior." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it into nothing, and a relationship still intact afterwards; choose one where the hard truth actually landed. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would do it | A standard behavioural stem; it also probes the senior-leader gap in F9 from a behavioural angle. VAL because it scores past behaviour |
| 2D3 | "Tell me about a time you worked with a digital or product team on something members use." | EXP | [generic] | Selection scaffold: a named piece of work, what the team owned and what you owned, what changed for members. If no such time comes to mind, say so plainly and say what you would want to learn from a digital team first. Your material carries nothing on this, so no beats are supplied | F6 has no evidence either way; the JD names digital teams and self-service journeys. EXP because it tests what was actually yours |
| 2G1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the quote states: you built it, it is monthly, your regional manager uses it. Answer slot: expect "what did it count, and how?" Say what it counted, in your own words, and name the assumption behind a figure you would defend least; if you do not know how a figure was counted, say so plainly, and say what you would count first. Say which tool it was in: Excel, or another | F3 and F4 are the discovery rows. EXP because a prober scores whether the numbers survive; the defend-the-number slots apply |
| 2G2 | "How would you tell whether complaint handling is getting better or worse month to month?" | CASE | [generic] | Think aloud: clarify what counts as a complaint and who decides; then the two measures the JD names, volumes and resolution times; then what could mislead, a rise in volume can mean more members are speaking up or more things went wrong, so ask for categories and resolution times beside it before you say which; then what you would report in plain words, and to whom. No claim about your past is needed | The JD requires monthly reporting on those two measures; CASE because it is a live problem |
| 2C1 | "We aim to move 40% of member service to digital by 2028. What does that do to complaints?" | CO | [grounded] | Clarify first: which services move first, and what counts as a complaint raised in an app. Then two or three questions you would ask rather than facts you would assert: where do members tell us something is wrong in an app, who sees it, which complaints should stay human, and how does self-service avoid making a member explain twice. Mention app-only banks as the stated competitive pressure. You are not claiming to know Ashgrove's journeys | The brief is the raising source; CO because it tests strategy fluency, with CASE delivery |

**Reverse questions, Round 2**

| # | Question | Why it lands |
|---|---|---|
| 2R1 | "What would a good first 90 days look like, and what would you want me to understand about the contact centre by then?" | Turns your stated gap into an agreed expectation, which is what a manager wants from a hire with a gap |
| 2R2 | "How are complaint volumes and resolution times reported now, and what decision does that report have to support?" | Ties to the JD's reporting line and signals you start from the decision, not the spreadsheet |
| 2R3 | "As 40% of member service moves digital, which complaints do you expect to stay human?" | Shows strategy fluency and invites their view rather than yours |
| 2R4 | "What does success in this role look like at the end of 2027, when the hubs are in place?" | Anchors the role in the published timeline |
| 2R5 | "Where does a complaint most often get stuck between a branch and the contact centre today?" | Shows you think about the seam, and the answer tells you what you would inherit |

---

## Round 3 — Panel of two branch managers, 60 minutes, including a 20-minute case; also the values round

**Weights:** Values/Behavioral 4, Case 3, Peer Evaluator 3. The two panel members are unassigned, so each persona is a blend, not a person.

### Values / principles cheat sheet

Published names are from the page text you pasted. The mapped-story column draws only on your quoted sentences, and most values have no sentence that carries a story, so the honest result is a scaffold with an honest branch.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. Scaffold in 3D1, and the nearest thing your material carries is F1, "I handled the branch's formal complaints log" |
| Plain Words | If a member needs it explained twice, the writing was wrong | No quoted sentence carries a story. Scaffold in 3D2, nearest F5, "trained new tellers on our escalation script" |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Scaffold in 3D3, nearest F3, "I built the monthly complaints spreadsheet our regional manager uses." |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No quoted sentence carries a story. Scaffold in 3D4, nearest F1, "I handled the branch's formal complaints log" |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3D1 | "Tell me about a time you put a member's interest ahead of what was easier for the branch." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: a named decision, what the easier option was, what you chose, how it ended and whether the hard truth landed. Describe what you decided and who you told; don't claim to speak for members. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the log, in its own words, or how you would decide | Theme from "Members First, Always". The panel scores against the four values; VAL because it asks for behaviour |
| 3D2 | "Tell me about a time you changed how something was worded so a member could follow it." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: what the wording was, why it did not work, what you changed it to, how you knew it worked. Nearest thing your material carries is the escalation script you trained tellers on, and the quote says you trained them, not that you wrote or reworded it. If no such time comes to mind, say so plainly. Answer this one in plain words yourself; the panel will hear how you talk as well as what you say | Theme from "Plain Words". VAL, and the delivery is itself scored |
| 3D3 | "Tell me about a time a number didn't tell you what was happening with the people in front of you." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold: the number, what it said, what you saw that it didn't show, what you did. The quote says what you built and nothing about what it hid or showed, so no beats are supplied. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would keep a number from standing in for a person | Theme from "Neighbours, Not Numbers"; the role reports numbers monthly, so this is where the value presses on the job. VAL because it scores behaviour |
| 3D4 | "Tell me about a time you found a problem that wasn't yours." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: the problem, why it wasn't yours, what you did to keep hold of it, how it ended. "Keeps hold of it until it is solved" doesn't say who does the work, so if your story involves handing something on, say how you stayed in touch with it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would keep hold | Theme from "Own the Fix". The tension with escalation is worth settling in your own mind before the panel does |
| 3C1 | "Practice case, written for this pack and not Ashgrove's real one: a member complained at a branch two weeks ago and was told it was resolved. They've phoned the contact centre, angry, saying nobody called back. The branch says it escalated; the contact centre has no record. What do you do?" | CASE | [generic] | Think aloud, in this order. **Clarify:** what was promised, what the member is owed now, whether it is a formal complaint with a clock running, who holds the complaint today. **Member first:** one named owner, and a call back with a time you will keep, in plain words, before any investigation. **Find the gap:** where it left the branch and where it should have arrived, without blaming either side. **Fix:** what changes so it can't happen the same way, and who is told. **Measure:** what you would count to know it is working. Challenge one premise respectfully, such as "resolved, by whose definition?". Ashgrove's real case will differ; practise the structure, not the details | The panel names a 20-minute escalation case, so this rehearses the shape. CASE; the problem touches F1 and F8 but asks about no past |
| 3C2 | "A branch supervisor escalates almost everything to you. How do you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | Say what the quote carries and no more: "I trained new tellers on our escalation script." Then the structure, as a plan: ask first what they are worried about, agree together what "ready to escalate" means, treat escalating as handing information on and not handing the problem on, follow up on the first few together. Keep it in plain words | F5 is the transferability row; the panel are the supervisors' managers, so this one is likely. CASE because it is a live problem |
| 3C3 | "Eight branches are becoming five hubs over 2027. What should the complaints process protect through that?" | CO | [grounded] | Clarify what changes for members and staff before you say anything. Then think aloud: a complaint should not be dropped in a move (Own the Fix), and a hub should still feel like part of its town (Neighbours, Not Numbers). Don't argue for or against the consolidation. If you don't know, say what you'd want to ask the panel | The brief is the raising source. Whether either panel member's branch is affected is not established, so this is delicate; CO with CASE delivery |
| 3E1 | "What do you need from branch managers, and what do we get from you?" | CASE | [generic] | Lead with what they get: early notice of what the numbers are showing, a clear rule for when to escalate, one named owner per complaint. Then what you need: honest signals when something isn't working. Offer principles for where the seam sits rather than pretending to know it | Peer reciprocity framing; the panel are your stakeholders. CASE because it is a live collaboration problem |
| 3E2 | "Your report will make my branch look worse than the one down the road. How do we handle that?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold at the quote's scope: you built a spreadsheet your regional manager uses, and answer what it counted the same way you answered 2G1. Then the method, as a plan: look behind the number before comparing branches, check categories, tell the manager before the report goes up. Hold your position through two follow-ups and concede specifically that a number can mislead | F3 plus the role's reporting duty; the panel's own branches are what the reports are about, so a collegial version of this objection is likely |
| 3E3 | "What would you want to know about our branches before you changed anything?" | CASE | [generic] | Listen first: ask what makes each branch different, what the town expects of it, what they would not want to lose. Offer to visit before proposing anything. Make no claim about what you have already seen | Touches "Neighbours, Not Numbers" and shows you won't arrive with a template; CASE because it is a live problem |

**Reverse questions, Round 3**

| # | Question | Why it lands |
|---|---|---|
| 3R1 | "What could a new complaints lead do in their first month that would genuinely help your branch?" | Reciprocity question; it turns a panel into a conversation between people who'll work together |
| 3R2 | "What does keeping hold of a complaint look like at your branch when it needs the contact centre?" | Uses their value, "Own the Fix", and surfaces the seam |
| 3R3 | "What would you want a complaints report to tell you, in plain words?" | Uses "Plain Words" and tells you what the report is for |
| 3R4 | "What does a branch do on complaints that you'd not want lost as the hubs form?" | Uses "Neighbours, Not Numbers"; invites them to tell you what matters rather than selling the plan |
| 3R5 | "How are you hearing about the hub plan, and what would you want the complaints process to protect?" | Shows you listen; ask it only if the tone of the room allows, since the panel may be personally affected |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says one branch's log, not the process across branches. 2B1 stays on the log |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't presented to anyone above regional level." No slot |
| Reported on complaint volumes and resolution times each month | Inflated form of F3 | F3's quote at its own scope: you built a monthly spreadsheet your regional manager uses. The limit is the pack's observation: the material does not show what it counted. 2G1's slot asks only what it counted |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: you trained new tellers. The limit is the pack's observation: the material says tellers, not supervisors |
| Handled regulated complaints | Inflated form of F8 | F8's quote at its own scope: you handled the branch's formal complaints log. The limit is the pack's observation: the material does not show what rules it ran under |

## Sources

Provided by you: the JD text; the values text copied from ashgrovecu.org/about/values on 25 November 2026; the recruiter's email on the three rounds; your summary of the July 2026 strategy brief (the brief's own text was not in front of me); your background. No dossier was present. The copied values page is where the text came from, not a link I was asked to read, so I did not fetch it.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the cheat sheet's names and meanings |
| 2. Ashgrove interview process, member service roles | skipped | The recruiter's email fixes the three rounds, their lengths, who runs each and the case format, so persona weights follow it |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief, four months old as you summarised it, fixes the CO and CASE content |
| 4. Interviewer names | n/a | No names were assigned, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names, once assigned (the Head of Member Services and the two panellists) → an interviewer read, persona weights tuned from public professional footprint, and reverse questions tied to their paths
- Your own pay, notice, location and reason-for-leaving words → 1A3 to 1A6 become your quoted sentences instead of instructions
- Your answers to the answer slots on F1, F3, F4, F5, F6 and F8, said outside a drill → those rows move from discovery or transferability, and the questions that draw on them regenerate with your quoted words
- An anonymised copy of the monthly complaints spreadsheet's layout, with member details removed → F3 and F4 can move from medium toward high, since the artifact that settles them is the report itself
- A line from the recruiter on which rules Ashgrove's complaints process runs under, and whether the 20-minute case is written or spoken → F8 and Round 3's case rehearse the real frame, not a practice one
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports, recent organisation context and a fuller strategy read for the CO questions
- A `tuesday-dossier.md` from job-underwriter → verified evidence and strategy limits per gap that this pack would otherwise infer; never required
