I'll read the reference files the skill points to before building the pack.
Pack is written. I'm now cleaning up two references in it that point to section numbers the headings don't carry, then checking it for stray square brackets before I present it.
Femi, your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-7-canned-ede81229/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 21 questions across six interviewer styles, a fit table against the JD, and six reverse questions for Tobias.

Saltmarsh's careers page describes your Friday session as the "Outage Hour". It's one 60-minute interview with the hiring manager: a live-incident tabletop on a simulated outage, then a conversation about their three published values. There's no take-home. I built the pack on the assumption that Tobias is that hiring manager. I weighted the tabletop and the values half most heavily. The page doesn't say how the hour is split, so prepare both in full.

- **Your most likely hard question:** Saltmarsh's news says its live titles are moving to a season-pass model, and you've never worked on a game with in-app purchases. Question C1 rehearses this. Say the plain version first: "I haven't worked on a game with in-app purchases." Then give a plan for learning it, and don't suggest your retention numbers covered spending.
- **Tobias's public theme:** His GDC 2026 talk is "Patch Notes Are a Promise". He argues a live team is judged by whether its patch notes match what shipped. That lines up with their value "Ship the Patch Not the Promise" and with the release checklist you wrote. Questions B3 and B4 use it.
- **Fit gaps:** The weakest fits to the JD are running two titles' calendars (you ran one), coordinating the four named teams, and owning the post-event review and KPIs (you presented the numbers). Each has an answer slot, where you say what you actually did or say plainly that you didn't.
- **Claims the pack won't coach:** Leading a team, in-app-purchase experience, owning a two-title calendar, owning the KPI review, owning the release process, and four years of live-service production. Each has an honest wording instead.
- **Research limits:** I read Saltmarsh's values and interviewing pages in full. The Project Larkspur news and Tobias's talk come from search snippets only, so I used nothing beyond what the snippets said.

I asked you nothing, because the careers page answered the round-type question.

Say the word and I'll run C1 as a live drill, with Tobias pressing on the in-app-purchase answer. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** the Outage Hour, a single 60-minute interview with the hiring manager: a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home. (Source: saltmarshgames.com/careers/interviewing, fetched.)
**Built on this assumption:** Tobias is the hiring manager the page names. If he is not, the persona weights in the persona table change.

## How to use this pack

- **Personas** are how a question is asked. **Types** are what it is scored on. Each question carries one of each.
- Type key:
  - **VAL**: whether past behaviour shows the company's published values.
  - **EXP**: whether your own claims survive scrutiny, and what was actually you.
  - **JD**: whether you can do the listed job, gaps included.
  - **CO**: whether you know the company's current strategy.
  - **CASE**: structure and reasoning on a live problem from the role.
- Guidance is scaffolding, not a script. Say it in your own words.
- An answer slot is an instruction for the interview, not a question for this chat. Answer it from what actually happened. Either branch is a good answer.
- Question IDs run by persona (A1, A2, B1 and so on). The drill and any later regeneration refer to them.

## Prep triage

You have two days. Do these in order. Everything else is insurance.

1. **C1**, the in-app-purchase question. It is the most predictable hard question for you. Say the first sentence aloud until it is boring.
2. **A1 and A2**, the tabletop. Practise thinking aloud and recommending before you are certain.
3. **B3 and B4**, the two values questions closest to what you have actually done (the checklist) and to Tobias's public theme.
4. **E2 and D1**, attribution and how the retention numbers were counted. These are the two places a CV line gets probed.
5. **F1**, your 90-second opening.

## Fit snapshot

No requirement in the JD is a term you either meet or do not (authorization, licence, location, schedule, pay), so there are no gate rows. F9 and F10 are not JD requirements. They are here because you named them as gaps and because the published news below makes F9 likely to come up.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material carries one title's weekly content-drop calendar, not two titles' events calendar. The words stay at that scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-title line makes a probe on handling more than one title likely. If you ever carried a second title's calendar, say which and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the main title's calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | The calendar line touches coordination but does not show which disciplines you worked with. Answer slot: the JD names four teams, so expect a probe on each. For each one you worked with on the drops, say how, in your own words; for any you did not work with, or where it was not yours, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, and says nothing about a review or about choosing KPIs. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose or built any of what you presented, say which part; if the numbers came from elsewhere and you presented them, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | The quote already speaks in the JD's terms: you wrote it and QA still uses it. It is a CV-style line with nothing inspected behind it, so expect a probe. Lead with the quote's own verbs, wrote and still uses, because a named artifact beats an adjective |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | The material gives the years and the title, associate producer, and does not show whether the main title ran as a live service. The words stay: "four years as an associate producer at a puzzle-game studio." Answer slot: the JD says live-service. If the title ran as a live service, say what that meant in your own words; if it did not, say so plainly |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | The quote reaches the requirement in its own terms: you ran a weekly calendar for two years. Lead with it and let the interviewer ask for more |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote names retention numbers and a senior audience. Expect a probe on how they were counted, rehearsed at D1. The quote shows you presented them; it does not show you built them |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A written artifact is in your material. Whether it shows clear writing is for the reader to judge, and the pack does not claim it. Answer slot: if you have other written work an interviewer could look at, say what it is in your own words; if not, say so plainly and stay with the checklist |
| F9 | Working with in-app-purchase games. Not in the JD; raised by Saltmarsh's own news that its live titles are moving to a season-pass model (Project Larkspur, search result) | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |
| F10 | Leading a team. Not a JD requirement: the JD says coordinate, not manage | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | Words: "I haven't led a team." Then F2's slot, which is where the JD's coordination line is actually tested |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A4, C3, E2, F2 |
| Coordinate design, art, engineering and community | A1, C2 |
| Own the post-event review and its KPIs | A5, D1, D3 |
| Manage the release checklist with QA | A3, B3, B4 |
| 3+ years producing live-service | C3, E1, F1 |
| Running a content calendar | A4, B1, E2 |
| Comfortable with retention metrics | A5, D1, D2, D3 |
| Clear written communication | A2, B4. An oral round cannot score writing directly, so these two have you say announcement wording aloud, and the upgrade menu asks for a written sample |

## Reading the interviewer

Public professional footprint only. The facts below come from one search result about a GDC 2026 talk. The talk itself was not fetched.

| Fact | Provenance | What it means for you |
|---|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | [grounded] | He knows release checklists from the inside. Your F4 line is the natural shared vocabulary, so use it in your own words, and do not claim to have worked in QA |
| GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | [grounded] | Expect accuracy of announcements against what is built to run through the tabletop and the values half. B2 and B4 rehearse this |

Practical points:

- When you rehearse A2 and B4, use his vocabulary: what shipped, what was announced, the difference between them.
- His public theme and Saltmarsh's published value "Ship the Patch Not the Promise" say the same thing. Treat them as one question that can arrive from either side.

## Persona table

The Interviewing page documents one session of two parts, the tabletop and then the values conversation. It does not say how the hour is split, so both halves are prepared in full.

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop: a simulated outage during a live event | Highest. The careers page documents the tabletop, and the hiring-manager prior points the same way | Clarify, then structure, then recommend. Think aloud. Name one premise you would challenge. Make no claim about your past that your quotes do not carry |
| Values / Behavioral | The second half of the Outage Hour, on the three published values | Highest. The page documents a values conversation, and the three values are published | Map a quoted sentence to each value where one carries a story. Where none does, use the selection scaffold and its honest branch |
| Skeptic | Probes on in-app purchases, team leadership, and associate producer against a producer role | Middle. The hiring-manager prior, and you have named two gaps yourself (F9, F10) | Rehearse C1 until it is boring. Say the plain acknowledgment first, then the ramp plan as a plan |
| Data-Driven Prober | Probes on how the retention numbers were counted | Middle-low. The JD names retention metrics and a post-event KPI report, and F7 is a number-adjacent claim | Know what you can and cannot say about how the numbers were counted. Say plainly when you do not know |
| Pressure | Time-boxed or challenged answers during the tabletop | Low. The page describes a simulated outage and does not say whether it is time-boxed or adversarial | Pause, restate the question, hold your position through two follow-ups, concede specifically |
| Conversational | The opening biography question and a CO question on strategy | Low. Every loop opens somewhere, and the recruiter call is a separate step on the page | A 90-second arc built only from your four quoted sentences (question F1 in the Conversational bank) |
| Peer Evaluator | Not included | Not applicable. The documented loop has no peer round | None |

## Question banks

### A. Case / Strategist: the tabletop (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's the second hour of a live event and players say they can't log in while the event timer keeps counting down. What do you do in the first ten minutes?" | CASE | [generic] | Clarify first: what is confirmed versus reported, which players and platforms, and who owns the incident call. Then sequence it: get the right people into one place, decide what happens to the event clock, and agree one message for players that says only what is known. Keep a running timeline. Think aloud and name one premise you would challenge, such as whether to touch the timer before the cause is known. The question needs no claim about your past, so the guidance makes none | The Interviewing page describes a simulated outage during a live event, so this is the closest rehearsal available. CASE because it scores structure. [generic] because the pack does not know Saltmarsh's actual incident process |
| A2 | "The fix lands ninety minutes later and the event has two days left. Do you extend it, and what do you tell players?" | CASE | [grounded] | Recommend first, then say what you would check: who missed rewards, what fairness depends on, who decides compensation. Then say the player message aloud in two or three plain sentences that announce only what is confirmed. Saltmarsh's values page puts it as "we announce what is built, not what is hoped". This is the written-communication row (F8) rehearsed by voice. The question makes no claim about your past, so the guidance makes none | Players Before Plans and Ship the Patch Not the Promise both press on this decision, and the values page is the source. CASE because the decision is live; the wording also scores F8 |
| A3 | "Before the fix goes live, walk me through the checklist you'd run." | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Say what you would want the checklist to confirm for an urgent fix, as how you would work. You can say you wrote the release checklist your QA team still uses, and stop there. Answer slot: the JD's release-checklist line makes a probe on urgent releases likely. If your checklist covered urgent fixes or a rollback, say how, in your own words; if it did not, or that was not yours, say so plainly and say what you would add | F4 is the evidence for the checklist requirement and the likeliest place this half of the hour touches your own history. CASE because it is a live problem; JD because it scores the checklist line |
| A4 | "Two titles, one shared calendar. Both want engineering for the same weekend. How do you decide?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify what each event is worth to players, what slipping costs, who has the final say and what could move. Recommend, then name the assumption you would defend least. On your past, stay at the quote's scope: "I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-title line raises competing demands on one calendar. If you have handled that, say what and how, in your own words; if not, say so plainly and stay with how you would decide | F1 is the gap between one title and two, and this is where the gap is tested as a decision. CASE because it asks for reasoning on a live problem |
| A5 | "The cohort that joined during the outage retains worse than usual. How do you read that, and what goes in the post-event review?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head" | Clarify what the comparison is, then separate what the numbers show from what they cannot. Name the assumption you would defend least, such as whether the cohort is comparable. Say what you would put in a review: what happened, what was announced against what shipped, what changes. On your past, stay at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event line raises ownership of the review. If you built any part of the numbers you presented, say which; if not, say so plainly and stay with presenting them | F3 and F7 are tested together here. CASE because it asks for a diagnosis; JD content because it covers the post-event review line |

### B. Values / Behavioral: the second half (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Your sentence carries the calendar and the two years. It does not carry a clash between the calendar and players, so this is a selection scaffold. Pick a time a scheduled drop and a player-facing concern pulled apart. It needs a named stake, what you recommended and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Players Before Plans is the first published value, and the theme comes from the values page. VAL because it scores whether past behaviour shows that value |
| B2 | "Tell me about a time you held an announcement back because the work wasn't finished." | VAL | [grounded] | Selection scaffold: pick a time something was planned to be announced and was not ready. It needs what was not ready, who you told, and what holding back cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not describe an announcement you did not make | Ship the Patch Not the Promise is the second published value, and it matches the theme of Tobias's GDC talk. VAL because it scores that value |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: you wrote the release checklist, and your QA team still uses it. Tell those two beats in your own words. Answer slot: the values page ties Leave the Build Greener to the checklist, so expect a probe on what the checklist replaced and what changed after. If something prompted it, say what and how you decided; if nothing did, or it was not yours to decide, say so plainly and stay with that you wrote it and QA still uses it | Leave the Build Greener is the third published value, and F4 is the only quote that carries a story for it. VAL because it scores that value |
| B4 | "How would you make sure what an announcement says is in the update is what's actually in the update?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Say how you would work: one source of truth for what is in scope, QA sign-off against the announcement text before it publishes, and a comparison after the event. Say it as a plan. Answer slot: if your checklist covered checking announcements against the build, say how, in your own words; if it did not, say so plainly and say what you would add | Tobias's public talk is about exactly this, and the values page makes the same point. VAL because it scores the value; JD content because the JD gives you the checklist with QA |
| B5 | "Tell me about a time you had to deliver a hard retention number to someone senior." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Your quote carries the audience and the monthly rhythm. It does not carry a hard result or how the room reacted, so this is a selection scaffold. Pick a month a number was bad and say what it was, what you said and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would present a drop | Players Before Plans and the retention line both press on honest reporting. VAL because it scores whether the hard truth landed, not generic virtue |

### C. Skeptic (middle weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our live titles are moving to a season-pass model. Have you worked on a game with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases" and "Presented the monthly retention numbers to the studio head" | **The highest-ROI rehearsal in this pack.** Level one: say it first and plainly, "I haven't worked on a game with in-app purchases", with nothing before it. Level two, "How would you own KPIs you've never reported?": concede specifically that you would be learning those measures from the team, and say as a plan what you would ask first: what the team already reports and who owns each measure. Do not suggest the retention numbers you presented covered spending; your material does not say so. Level three, "What would you get wrong first?": name one real limit in your own words. Hold throughout by returning to what you do carry, "I presented the monthly retention numbers to the studio head", and never add to it | F9 is a gap you named yourself, and Saltmarsh's own news makes it relevant. EXP because it tests a claim of experience; the answer is a plain acknowledgment plus a plan |
| C2 | "Have you led a team? This role coordinates design, art, engineering and community without managing them." | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" and "I ran the weekly content-drop calendar for our main title for the last two years" | Say "I haven't led a team" first. Then go to the coordination the role actually asks for, at your quote's scope: you ran the weekly content-drop calendar for two years. Answer slot: the JD names four teams. For each one you worked with on the drops, say how you got what you needed from them, in your own words; for any you did not work with, or where it was not yours, say so plainly and stay with the calendar | F10 is a stated negative and F2 is where the JD's coordination line is tested. JD because it scores the stated responsibility |
| C3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Choose honestly from what your material shows. Candidates from your own sentences: in-app purchases (F9), and running two titles' calendars rather than the one you ran (F1). Say which you would pick, then a plan for it, said as a plan. A real weakness named calmly is a stronger answer than an invented one | The standard Skeptic stem, aimed at F1 and F9. JD because it scores honest self-assessment against the listed job |
| C4 | "Why live operations, why Saltmarsh, and why now?" | EXP | [grounded] | Give your actual reason in one sentence, then tie it to something you can point to in Saltmarsh's published material, such as the three values on its values page. Do not use a reason that is not yours. If you are not sure what your reason is, work that out before Friday | A motivation probe, which the Skeptic runs. EXP because it tests whether your story is consistent |

### D. Data-Driven Prober (middle-low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: say how the numbers were counted, including which retention measure it was, in your own words; if you do not know how they were counted, say so plainly. Name the assumption behind them you would defend least. Say which part was yours, producing them or presenting them; if you only presented them, say that | F7 is the claim the Prober tests. EXP because it checks whether the claim survives, and the four things asked are the ones every figure raises |
| D2 | "Tell me about a time a retention number moved and what you did with it." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Your quote carries presenting monthly. It does not carry a movement or a response, so this is a selection scaffold. Pick a month a number moved and say what moved, what you thought caused it and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would investigate a drop | F7 again, from the side of what you did with the number. EXP because it asks for a chosen instance |
| D3 | "What KPIs would your post-event review report, and why those?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you would measure and name the assumption you would defend least. Say it as a plan. Answer slot: the JD's post-event line raises ownership of the KPIs. If you chose any of the measures you presented, say which and why; if they were set by others, say so plainly and stay with presenting them. If asked about spending measures, say you would learn what the team uses, consistent with C1 | F3 is the gap between presenting numbers and owning a review. JD because it scores the stated requirement |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses" and "Presented the monthly retention numbers to the studio head" and "Never led a team, and never worked on a game with in-app purchases" | Hold on the three sentences, and only them: you ran the weekly calendar for two years, you wrote the checklist QA still uses, you presented the monthly retention numbers. Concede in one clause: "I haven't worked on a game with in-app purchases." Do not claim to be the stronger candidate; say what you would bring and let him judge. Through two follow-ups, return to the same three sentences and add nothing | The standard Pressure stem against F9. JD because it scores fit against the listed job |
| E2 | "How much of that calendar was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: say which parts of the weekly calendar were yours, in your own words. If others set what went into the drops, or decided when, say so plainly and stay with that you ran the calendar. Hold your position through two follow-ups. Concede specifically where the calendar depended on others. Do not fold on "I ran the weekly content-drop calendar for our main title" | F1 and F6 both rest on this sentence, so this is where it gets tested. EXP because it scores attribution |

### F. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses" and "Presented the monthly retention numbers to the studio head" | A 90-second arc of four beats, each a sentence you wrote: four years as an associate producer at a puzzle-game studio; the last two running the weekly content-drop calendar for the main title; the release checklist you wrote that QA still uses; the monthly retention numbers you presented to the studio head. Add your own reason for wanting live operations at Saltmarsh, in your own words. Add nothing else about the past | A casual opener is still scored. EXP because it checks that your account matches your claims |
| F2 | "What do you make of one shared events calendar across more than one title?" | CO | [grounded] | Grounding fact: Saltmarsh's news page, read from a search snippet only (the page itself was not fetched), says Project Larkspur (September 2026) moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027 and replaces per-title event teams with a single live-ops group. Use it to sound current. Give a view from first principles: a shared calendar avoids collisions between titles, and the risk is one title's needs being crowded out. Say you would want to hear how the group is organised. Do not recite the announcement back, claim knowledge of internal plans, or correct him on anything | The only company-strategy question the research supports. CO because it scores whether you can think at the company's altitude |

## Values cheat sheet

A values-style round is documented: the Interviewing page names a values conversation.

| Value (official name) | Working meaning, paraphrased | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players disagree, the players win | No quoted sentence carries a story. Use the selection scaffold at B1 and its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence carries a story. Use the selection scaffold at B2 and its honest branch; B4 is the plan version |
| Leave the Build Greener | Each release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses" — your message. Story at B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spoken about patch notes as a promise. How does the team check today that what's announced is what shipped, and what would I own in that?" | Ties to his public GDC talk and to your checklist. It shows you looked at his work and want to own the part you have evidence for |
| R2 | "With one shared events calendar and a single live-ops group from February, which two titles would I be producing, and who would I report to?" | The JD says two titles and the news page says per-title event teams are being retired. This is a fair question about scope and reporting that you cannot find by research |
| R3 | "What does a good post-event review look like here, and which KPIs are non-negotiable in it?" | The JD says you would own the review and its KPIs, and the answer shows whether spending measures are in scope without you raising your gap |
| R4 | "What is one thing about the release checklist today that you'd change?" | Ties to Leave the Build Greener and to your strongest quote. It invites him to talk about something he knows well |
| R5 | "What separates a strong tabletop from an adequate one in the Outage Hour?" | Asked at the end, it signals that you take the format seriously and gives you something to act on if there is a later step |
| R6 | "What would you want me to have done by day ninety?" | A clear success measure, and it shows how he judges the role |

## Prohibited claims

What this pack will not coach, and why. It was built before the question banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | A negative you stated, F10 | "I haven't led a team." No slot |
| Worked on a game with in-app purchases or a season pass | A negative you stated, F9 | "I haven't worked on a game with in-app purchases." The ramp plan is said as a plan |
| Owned a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one title's content-drop calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: "I presented the monthly retention numbers to the studio head". The limit is the pack's observation |
| Managed releases, or owned the release process | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist QA still uses |
| Produced live-service games for four years | Inflated form of F5 | F5's quote at its own scope: "4 years as an associate producer at a puzzle-game studio" |

## Sources

**Provided:** your message (the JD, your background, the interviewer's name and title, and the company).

**Research tier: L1 — searches 4 of 6, fetches 2 of 2**

Searches sent:

- "Saltmarsh Games values" returned saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned saltmarshgames.com/careers/interviewing
- "Saltmarsh Games strategy news mobile" returned saltmarshgames.com/news/project-larkspur (snippet only; the page was not fetched)
- "Tobias Wrenfield Saltmarsh Games" returned talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only; the talk was not fetched)

Pages fetched: saltmarshgames.com/values and saltmarshgames.com/careers/interviewing.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | Values cheat sheet and the B bank: three values by name |
| 2. Interview process | yes | The one-session loop, the hiring-manager relationship, and the A and B banks; a values-style round is documented |
| 3. Strategy and recent news | yes | F2 and R2. Only the snippet was read, so the pack uses nothing beyond it |
| 4. Interviewer | yes | Reading the interviewer, B4 and R1. Only the snippet was read |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias is the hiring manager for this role: if he is not, the persona weights and bank depths are recomputed
- The recruiter's prep email, or any note on the tabletop: whether it uses a specific kind of event or incident, which would tailor A1 to A5
- Which two titles the role covers: F2 and R2 become specific rather than general
- Your answers to the slots in F1, F2, F3, F5 and F8 (whether you carried a second calendar, which teams you worked with, what you built in the numbers you presented, whether the main title ran as a live service, and other written work): those rows move from `low` or `medium` toward `high` and the matching bank cells become story-mapped
- A redacted copy of the release checklist, a retention deck you presented, or a written post-event or announcement text you wrote: each is the inspectable artifact that raises F4, F7 or F8
- Your full CV: more quotes for the fit snapshot, and any that cover F2 or F8
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes. It would read the Larkspur page and the GDC talk themselves and build a grounding brief
- A tuesday-dossier.md from an earlier evaluation of this role, if you have one: it would add verified evidence and a prohibited-claims list to build against
