Searches were refused, so I'm building the pack from your message and the recruiter's words only. Writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-5-denied-7f229617/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for the two-person panel: Deepa as your future manager, and Ross pushing on commercials. It uses only your message and the recruiter's words. Web searches were refused here and the market report's text wasn't in our conversation, so nothing in the pack comes from either. The report-based parts are marked as patterns to test against what you read.

The pack names A3 as the prep that matters most. Ross will push on commercials, and your own message says you've never carried a direct quota. A3 rehearses that objection through three follow-up levels, and D1 to D3 are the same objection under pressure. The pack also has a timed structure for your 15-minute POV, three thesis options with concessions, and a four-hour prep schedule.

Say the word and I'll play Ross on A3, with live follow-ups and feedback against the pack's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the JD text? If so, paste it and I'll replace the recruiter-quote requirements with its lines. If not, nothing changes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail — Senior Partnerships Manager — round 2 prep pack

**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director), on the recruiter's word. **Format:** 60 minutes; the first 15 are your POV on operator partnerships over the next 18 months, then Q&A in which Ross will push on commercials.

What the recruiter wrote, as you quoted it:

| Recruiter's words | Used in |
|---|---|
| "The panel is Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes." | Persona table |
| "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it." | POV build, F1 |
| "Please land on what it means for the operators themselves." | POV build, F3 |
| "Rest is Q&A, and Ross will push on commercials." | F2, bank A |

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you can stand behind on a second follow-up.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none in this pack: no values-style round is documented for this loop) |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | The role's stated requirements, gaps included |
| CO | Company and market knowledge |
| CASE | A live problem from the role, reasoned out loud |

- **Answer slots** are instructions for the interview, not questions for you now. Each gives two honest branches; the second always allows that the practice was not yours or never existed.
- **Wording proposed in this pack is pending your approval.** Change anything that is not how you would say it.
- **Highest-ROI prep: A3.** Ross is the one pushing on commercials, and your own material says you have never carried a direct quota. A3 is that objection, with follow-up levels. D1, D2 and D3 are the same objection under pressure.

## Prep triage

You have about four hours across the weekend. In this order:

| Order | Time | What | Where |
|---|---|---|---|
| 1 | 90 min | Build and speak the POV. Choose two theses, write the operator close, say it aloud twice against a timer; aim for 12 to 13 minutes so Q&A starts on time | Graded deliverable below; C1, C2, C4 |
| 2 | 50 min | The commercials objection, out loud, three follow-up levels deep. Then the two figures: how each was counted, what it is sensitive to, the weakest assumption, which part was yours | A1, A2, A3, D2 |
| 3 | 40 min | The rail gap: concede it plainly once, hold what your quotes carry, plan the first weeks | B1, B2, B3, D1, D3 |
| 4 | 30 min | Re-run the POV from memory, then take its follow-ups cold | C1 to C4 |
| 5 | 20 min | The 90-second journey arc, and pick three reverse questions | E1, B4, Reverse questions |
| 6 | 10 min | Read the prohibited claims and the bridge wording in the fit snapshot aloud once | Prohibited claims; Fit snapshot |

Everything else is insurance.

## Fit snapshot

There is no JD in hand, so requirements come from the recruiter's words and your message, quoted. F5 is a role-family requirement with no source, written as plain prose and labelled generic. Bridge wording is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material says a channel grown from 6 partners to 40 at a payments company, not operator partnerships, and nothing inspected sits behind it. The words stay at that scope: "For the last four years I've been running the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: if anything that worked in that channel carries over to what operators need, say what and why, in your own words; if nothing does, say so plainly and use the 6 to 40 only as a story about growing a partner base |
| F2 | "Ross will push on commercials" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | Your material carries influenced revenue and says in your own words that there was no direct quota, so the words are: "I haven't carried a direct quota; what I carried was influenced revenue." The figure raises four slots and no others: how the £4M was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; "I don't know how it was counted" is an honest branch. Nothing in the pack names a counting method for you |
| F3 | "Please land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies, and the words stay there: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: your sentence says you know the operator world from the other side, so expect which operators and what part was yours. If your consulting work was for or with operators, say which kind and what you did; if it was for others, or from outside the operators, say so plainly and stay with the network planning |
| F4 | "they sell scheduling software to train operating companies" — your message (the company's context, not a posting line, so it raises no slot) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | Grow a partner base from a small starting point (role-family requirement, no source; plain prose) | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [generic] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe on the 6 and the 40. Lead in the quote's own terms: you took the channel from 6 partners to 40. The slots from F2 apply to the 6 and the 40 as well |

## Graded deliverable: the 15-minute POV

The recruiter announced it, asked for no slides and asked you to land on what it means for the operators. It is graded, so it gets its own build. Proposed structure and wording here are pending your approval.

**One thing I could not do:** your message says you have read the strategy team's market report, but its text was not in our conversation, so nothing below is built from it. Every thesis is a pattern to test against what the report actually says, not a claim about Kelverton.

**Grounded facts to build on**

| Fact | Row | Quote |
|---|---|---|
| The ask: a view on where operator partnerships go in 18 months, landing on what it means for operators | F1, F3 | "Please land on what it means for the operators themselves." — recruiter's email |
| Your partner-growth experience, at its own scope | F5 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message |
| Your transport background, at its own scope | F3 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message |
| Your stated limits | F4 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message |

**Suggested shape (timings are a target, speak it, no slides)**

| Time | Beat | Notes |
|---|---|---|
| 0:00 to 1:00 | Frame | Say what you took "operator partnerships" to mean and invite correction. The material does not say whether operators are customers, channel partners or both, so state your assumption instead of guessing silently |
| 1:00 to 3:30 | The report, then the departure | One point from the report you can defend, to show you read it; then say where you would take a different line and why. Do not recite its shortlist: the panel's own strategy team wrote it, so it scores as homework, and a reasoned departure scores as judgment |
| 3:30 to 10:00 | Two theses | Two from the table below, each with its concession said aloud |
| 10:00 to 13:00 | What it means for the operators | Month 6 and month 18 from the operator's seat, in operator terms, one concrete difference each. The content must come from the report or from what you learn before Tuesday; this pack supplies no operator facts |
| 13:00 to 15:00 | The anti-pick and the close | One thing you would not do in 18 months, one sentence on what you do not yet know about rail (F4), then end on the operator line |

**Thesis options**

| Thesis | Concession to say aloud | How it differs from the consensus answer | Provenance |
|---|---|---|---|
| Operator outcomes first: agree with each operator a result they would count as theirs, then work back to what Kelverton needs | It will be slower to show a headline partner count, and it asks the commercial side to accept results that are not bookings | A shortlist-style answer leads with what Kelverton wants from partners; this one starts from the operator and lands on the close the recruiter asked for | [generic] |
| Sequence before scale: earn a small number of operator partnerships to the point an operator would speak for them, before widening | It concentrates dependence on a few relationships, and your own 6 to 40 story is about scale, so it is less use here if the operator set turns out to be small (check the report) | Most partnership plans widen first; this one makes a case for not widening yet | [generic] |
| Make the commercial model legible to operators: agree up front how each partnership's value will be counted | It will expose that some value is influence rather than revenue, and it slows launches. It also puts your own influenced-versus-direct limit (F2) on the table, so only choose it if you can handle that in Q&A | It answers Ross's commercial push inside the POV instead of waiting for it | [generic] |

**Anti-pick (the role includes saying no):** name one thing you would decline in 18 months, for example making partner count the headline measure, but only if you actually hold that view. Provenance: [generic].

**Mandatory concession:** whichever two you pick, say one concession for each aloud, in your own voice, before anyone asks.

## Persona table

The loop rests on the recruiter's words: one 60-minute session, a two-person panel, a 15-minute POV, then Q&A. That establishes the loop, so no company-archetype fallback is used and no values-style round is detected.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (Ross) | Takes your two headline figures apart | High. The recruiter says "Ross will push on commercials", and your material has two figures (6 to 40, £4M influenced) | Know what you can and cannot say about how each was counted, name the weakest assumption before he does, and say plainly when you do not know (A1 to A3) |
| Skeptic (Deepa and Ross) | Quiet, persistent probing of rail and quota | High. Your own message says you have never sold into rail and never carried a direct quota, and a future manager derisks exactly that | Rehearse A3 and B1 until boring; bridge only from the quotes at their own scope; concede the limit once, plainly |
| Case/Strategist (Deepa) | Follow-ups on your POV, then live problems | High. The POV is the graded deliverable and a hiring manager's prior is case plus skeptic | Clarify, objective, segmentation, approach, metrics, risks; name your weakest assumption first (C1 to C4) |
| Pressure (Ross) | Time-boxed, devil's advocate on commercials | Medium. "Push" suggests challenge, but nothing says he interrupts | Pause, restate, hold two follow-ups, then concede specifically (D1 to D3) |
| Conversational (Deepa) | The journey question as an opener | Low to medium. It is scored, but short | A 90-second arc (E1) |
| Peer Evaluator | The seam with Ross's team | Low. No peers on the panel, but partnerships and commercial share operators | Offer principles for the seam, not a claim to know it (F1, F2) |

## Question banks

Each row's Provenance leads with one label; the quotes after it are the only sentences the guidance rests on. Wording is pending your approval.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You took the ISV channel from 6 partners to 40. How was that counted?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Open in the quote's terms: you took the channel from 6 partners to 40. Then the four slots, in your own words: how the 6 and the 40 were counted, what the figure is most sensitive to, the assumption behind it you would defend least (name it before Ross does), and which part was yours. If you do not know how something was counted, say so plainly and say what you do know. Name no method you did not use | F5 is the evidence and the likeliest figure to be probed; EXP because it tests counting and attribution, not the listed job |
| A2 | "You said roughly £4M of influenced revenue. What counts as influenced?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Keep the word influenced; do not turn it into revenue you brought in or closed. Answer slot: if you know who closed the deals, say who; if you do not know, say so plainly. Then the same four slots as A1 for this figure, in your own words | F2 is where "push on commercials" lands first, so this arrives in some form; EXP because it scores attribution |
| A3 | "You haven't carried a direct quota. If we gave you a number to carry here, what would you want settled before you took it?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | The highest-ROI rehearsal in this pack. Level 0, the plain words: "I haven't carried a direct quota; what I carried was influenced revenue." Level 1 ("so you're asking us to take a risk"): return to that sentence, concede that direct accountability would be new, and add nothing to it. Level 2 ("what would you do in the first quarter"): a plan, said as a plan: your own list of what you would want agreed about the number before taking it, such as what it is counted on, who sets it and what is outside your control. Level 3 ("and if you miss it"): say what you would want to be told early and how you would report it; claim no past miss and no past save. Name the limit yourself before Ross asks | F2 holds the objection most likely to be asked in some form; JD because it scores the commercial requirement the recruiter flagged, and the guidance goes no further than the quote |
| A4 | "When you shape a partnership with an operator, what has to be settled commercially before anyone builds anything?" | CASE | [generic] | Say it as questions you would ask, not as how Kelverton works, since you do not know its model: what the operator is buying and how it would count success; who pays for what and who carries the risk if it does not work; how Kelverton earns and over what period. End with one thing you would refuse to leave open | A live problem from the commercial push; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A5 | "How do you tell a partnership that's working from one that's just busy?" | JD | [generic] | Name the measure you would want agreed up front, who reads it and how often, and the point at which you would stop. If a time from your own work comes to mind, use only what you can say about it; if none comes to mind, say so plainly, then say how you would tell | Commercial probes often come as judgment questions with no CV hook; JD because it scores whether you can run a partnership portfolio |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. What would you most likely get wrong in your first three months?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Acknowledge in the quote's words: "I've never sold into rail specifically." Then the adjacent work at its own scope: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: name the assumption you would most likely carry in from your partnerships work and how you would test it; if you cannot name one, say so and say you would ask operators early. Then how you would learn, as a plan | F4 is the stated gap and F3 is the adjacent work; JD because it scores fit to the context the role sits in |
| B2 | "You say you know the operator world from the other side. Which operators, and what was your part?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Answer slot: if your consulting work was for or with operators, say which kind and what you did; if it was for others, or you worked from outside them, say so plainly and stay with the quote: five years of transport consulting in bus and light rail network planning. Do not stretch bus and light rail into train operating companies | F3 carries a sentence an interviewer will test; EXP because it scores what was actually yours |
| B3 | "Operators will ask why they should trust a partnerships lead who hasn't sold into rail. What do you tell them?" | CASE | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Hold then concede: concede it plainly ("I've never sold into rail specifically"), then say what you would do for operators, not what you have done in rail: how you would start by listening, and what you would agree before asking anything of them. Link it to the operator close of your POV | F4 and F3, asked from the operator's seat, which is the recruiter's requested close; CASE because it is delivered as a live problem |
| B4 | "What's pulling you from payments to rail now?" | EXP | [generic] | Give your actual reason in your own words, one or two sentences, and say what draws you to this role before what you are leaving. Say only what is true, because B2 and the POV will test it | Motivation consistency is the skeptic's standing probe; EXP because it scores whether your story holds together |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Take one operator and tell me what you'd want to be true about the partnership in 18 months." | CASE | [generic] | Clarify first (what constraint does this operator work under?), then the objective, how you would segment, the approach, how you would measure it, and the risk. Challenge one premise of the question respectfully. Where you lack the information, say what you would need to know | A direct follow-up from the POV the recruiter announced |
| C2 | "Where is your POV weakest?" | CASE | [generic] | Name the assumption you would defend least before they do, concede it explicitly, and say what would change your mind. Do not defend the whole POV equally | The strategist scores whether you can see your own seam |
| C3 | "Two operators want opposite things from us. How do you decide?" | CASE | [generic] | Ask first whether it is truly a conflict, what each constraint is, and what Kelverton can give; say who you would bring in and who owns the call, in principle rather than claiming to know the seam | A live problem set in an operator-facing role, with the seam to product and commercial |
| C4 | "Which part of the market report would you push on, if any?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | The pack cannot see the report, so it cannot tell you what to push on. The move: one point you can defend from it, one you would qualify and why, said without reciting. It is the strategy team's own document, so qualify it, do not correct it. If nothing struck you, say what you would want to know more about | CO because it scores whether you can think at the company's altitude; `[grounded]` only that you have read it |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you rather than someone who has already sold into rail?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause and restate. Beat one, concede: "I've never sold into rail specifically." Beat two, hold what the quote carries: you took the ISV channel from 6 partners to 40. Beat three, how you would close the gap, as a plan. Claim nothing about rail | The stem is the standard pressure test of F4; JD because it scores fit |
| D2 | "That £4M — how much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Hold through two follow-ups by returning to the word influenced. Answer slot: say which part was yours in your own words; if you do not know the split, say so plainly and stay with the quote. Never convert influenced into closed, owned or generated | A3's objection delivered with pressure; EXP because it is an attribution probe |
| D3 | "You'd be new to rail, managing partners who aren't. How long before you're useful?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Concede that you are new to rail selling, in the quote's words. Give a timeline only if you can stand behind it; if you cannot, say what you would need to learn to give one. Do not promise a date | F4 under time pressure; JD because it scores readiness for the role |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."; "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc with the beats the quotes carry: five years in transport consulting, in bus and light rail network planning; then nine years in partnerships, the last four running an ISV channel at a payments company, taken from 6 partners to 40; then why this role, in your own words (B4) | Casual in register and still scored; EXP because it tests whether your story matches your CV |
| E2 | "What are you actually following in rail these days?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Say only what you actually follow. The report is one thing you have read; name another only if it is real. If there is not one, say so plainly and say where you would start | Scored casually; CO because it checks homework |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where's the seam between partnerships and Ross's team, and what happens when you disagree?" | JD | [generic] | Offer principles, not a claim to know the seam: who owns the operator relationship, who owns the terms, how you would agree the split with Ross early. Add what you would bring his team, not only what you need. For the disagreement, pick a time you disagreed with an equal in another function; it needs a named stake, how you disagreed, and the relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Partnerships and commercial share operators; JD because it scores how you would work in the role |
| F2 | "Tell me about a time credit for a deal was shared across two teams." | EXP | [generic] | Pick a time where the credit question actually arose and say how it was settled and what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2's influenced-revenue figure is the natural place this probe comes from |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1: the POV | Graded deliverable; C1, C2, C4 |
| F2: commercials | A1 to A5, D2 |
| F3: land on what it means for operators | B2, B3, C1, C3; Graded deliverable |
| F4: selling into rail | B1, B3, D1, D3, E2 |
| F5: growing a partner base | A1, A2, E1, F2 |
| Reason for moving (your message) | B4, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would the operators you work with most closely say Kelverton gets right in partnership today, and what would they change?" | It puts the operator's view, which the recruiter asked you to land on, into the room, and it shows you what an operator relationship actually looks like here |
| 2 | "How is this role measured in the first year: a number I'd carry directly, or influence on others' work?" | It surfaces the commercial accountability early, which your own message flags, so you are not guessing at the answer to A3 |
| 3 | "How do partnerships and commercial split who holds the operator relationship day to day?" | It tests the seam from F1 and shows you think about working with Ross's team, not around it |
| 4 | "Where would you most like to be argued with in my POV?" | It invites the challenge you would be getting anyway, and shows you can hold a view and update it |
| 5 | "What does a good first 90 days look like for someone new to selling into rail?" | It names your gap on your terms and turns the skeptic's probe into a joint plan |
| 6 | "What would make you say in a year that this hire was a mistake?" | It tells you what the panel is actually afraid of, and signals you can hear it |

## Prohibited claims

What this pack will not coach, with the basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | A negative you stated, F4 | The plain acknowledgment: "I've never sold into rail specifically." |
| Has carried a direct quota or been accountable for a revenue number | A negative you stated, F2 | "I haven't carried a direct quota; what I carried was influenced revenue." |
| Knows train operating companies from the inside | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says bus and light rail network planning, not train operating companies. B2's slot stays inside that scope |
| Closed, owned or generated the £4M | Inflated form of F2 | F2's quote at its own scope: influenced revenue. The limit is the pack's observation: the material does not show who closed it. A2 and D2 slots ask only which part was yours |

## Sources

**Provided:** your message, including the recruiter's email as you quoted it. The market report's text was not in the conversation, so nothing here comes from it. No dossier was present.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Query sent, refused. Would have fed a values cheat sheet; none is built, and no values-style round is documented in the recruiter's words |
| 2. Kelverton Rail interview process | unavailable | Query sent, refused. The recruiter's own words establish this loop, so the persona weights rest on them |
| 3. Kelverton Rail strategy and recent news | unavailable | Query sent, refused. Would have made C4 and the POV theses specific rather than `[generic]` |
| 4. Interviewer footprint | unavailable | One query sent for Deepa, refused; none sent for Ross after that. No interviewer read is built |
| 5. Representative role JD | unavailable | Query sent, refused. Requirements come from the recruiter's words and your message |

Queries sent, all refused: "Kelverton Rail values"; "Kelverton Rail interview process partnerships manager"; "Kelverton Rail strategy scheduling software train operating companies news"; "Senior Partnerships Manager rail technology job description operators"; "Deepa VP Partnerships Kelverton Rail".

## Upgrade menu

- The market report's text, or its headline sections → the POV theses stop being `[generic]` patterns, C4 and E2 become grounded, and the consensus point to open with is named
- The JD text → the recruiter-quote requirements in F1 to F3 become JD lines, F5 becomes grounded, and the coverage table is checked against the posting's own list
- What the recruiter means by operator partnerships (customers, channel partners or both), by one email → the POV frame and thesis weights can be set rather than assumed
- Search permission, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → values, strategy and recent news, and Deepa's and Ross's public professional footprint, giving an interviewer read and a reverse question tied to their paths
- Your own answers to the answer slots in F1, F2 and F3 (which part of the £4M was yours, which operators your consulting served) → those rows upgrade from slots to quoted evidence
- A `tuesday-dossier.md`, if you have one → verified evidence and sourced prohibited claims; the pack stands without it
