I've built your prep pack and saved it. It covers all three rounds on 4 December, each with its own personas, questions and reverse questions. I didn't run any web searches because your pasted JD, values, recruiter email and strategy points already cover what research would have.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-8-canned-7fef0075/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

- **Shape:** I built it as a loop with a shared fit snapshot and a mini-pack for each round: recruiter, Head of Member Services, then the branch-manager panel with the values round and the complaint-escalation case.
- **Rehearse first:** B5 is the contact-centre question. Your own message makes it the likeliest objection, and it comes back in all three rounds as A7, B5 and C10.
- **Gaps:** you said you've never worked in a contact centre and have never presented above regional level. The pack coaches you to say each plainly, once, with a plan.
- **Slots:** several answers depend on facts only you have, such as what made your complaints "formal" and what the monthly spreadsheet counted. Where the pack doesn't know, it leaves an answer slot instead of inventing details.
- **Values:** none of your sentences describes a specific decision or outcome. The four values therefore get selection scaffolds with an honest fallback, not ready-made stories.

Say the word and I'll play the Skeptic on B5 so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Mode: loop, three rounds on 4 December 2026 (nine days from 25 November 2026). Interviewers: Round 1 the recruiter, Round 2 the Head of Member Services (your future manager), Round 3 a panel of two branch managers. No names are assigned yet, so there is no interviewer read.

## How to use this pack

- Personas are how a question is asked. Types are what is being scored. Tags: **VAL** behavioural or values alignment; **EXP** work-experience deep-dive; **JD** role and job-description requirement; **CO** company and strategy knowledge; **CASE** live problem.
- Guidance is scaffolding, not a script. Where a cell says "Answer slot", it is an instruction for the interview: answer it from your own experience, or say plainly that the step was not yours or did not exist. Neither branch is a failure.
- The highest-ROI prep in this pack is **B5**, the contact-centre question. It is the objection your own message makes most likely, and it will arrive in some form in all three rounds (A7, B5, C10).
- Question IDs run by round: A for Round 1, B for Round 2, C for Round 3.

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on which parts of a complaint's journey were yours likely. If any step beyond the log was yours, say which, in your own words; if the log was the extent of it, or the other steps were not yours, say so plainly and stay with the log you handled |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | A formal log touches this requirement, and the material does not show what made the complaints in it formal. Answer slot: expect a probe on what made a complaint formal at your branch. Say what you know, in your own words; if that was set elsewhere, or you do not know, say so plainly and stay with the log you handled |
| F4 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your material says the monthly spreadsheet, not what it counted. Answer slot: expect a probe on what it held. If it counted volumes or resolution times, say how each was counted, what it was sensitive to and which part was yours; if it counted something else, or someone else set what it counted, say so plainly and describe what it did hold |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The quote says tellers, not supervisors, and a script, and the words stay there: "I trained new tellers on our escalation script." Answer slot: expect a probe on whether you have worked with other supervisors on escalations. If you have, say what happened and what part was yours; if not, say so plainly and stay with the tellers |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | The material does not show this either way. Answer slot: if any of your branch work touched app or online self-service, say what, in your own words; if none did, say so plainly, and say what you would ask a digital team first |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your quote says spreadsheet, not Excel, and the material does not show which tool it was. Answer slot: if it was built in Excel, say so and say what it did, in your own words; if it was another tool, say so plainly and name it |
| F9 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The years clear the bar, and the JD's term is customer operations where your quote says retail banking. Say it in your own terms, "six years in retail banking, the last three as a branch supervisor", and let them map it. Add no practice or outcome to it |

No row is a hard gate: the JD states no authorisation, licence, location, schedule or pay term.

## Grounding brief (shared)

The four points of Ashgrove's July 2026 strategy brief, as you relayed them. I have not seen the brief itself.

| Point | What it gives you in a room | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | Vocabulary for the digital and self-service questions (B7, C5, C7). Use the figure and the year as the brief gives them | [grounded] |
| Consolidate eight branches into five hubs over 2027 | The panel are branch managers. How the hubs affect them is not in the material, so ask rather than assume (Round 3 reverse questions) | [grounded] |
| Launch a small-business lending product in Q1 2027 | A new product line means new kinds of complaint; a CASE angle if asked what you would prepare before launch | [grounded] |
| Main competitive pressure is app-only banks | The frame behind why a mishandled complaint matters (C5) | [grounded] |

Reading, not a source claim: the role reports monthly numbers while one of the four values is "Neighbours, Not Numbers", so expect the panel to probe how a numbers person keeps the member in view (C3).

---

# Round 1 — Recruiter, 30 minutes

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, logistics, motivation | Top. Recruiter-screen prior is Conversational plus light Skeptic, and the recruiter's email describes a 30-minute conversation. Pay, notice, location and reason for leaving are all scored in a friendly register | Prepared 90-second arc; own answers to the four logistics |
| Skeptic (light) | Knockout checks on the JD's hardest lines | Low. The same prior; your two stated gaps are the likely checks | Say each gap once, plainly, with a plan |

## Round 1 question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F9, F1, F5 and F4: a 90-second arc in four beats, each the quote's own. Six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close on why this role, in your own words. Add no outcome, number or reaction the quotes do not carry | The opener of every screen, and the arc the later rounds build on. EXP because it checks the CV story hangs together |
| A2 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, in your own words, or ask for the role's band first. Either is a legitimate answer; use the one you actually hold. If asked what you earn now: "I'd rather focus on the range for this role." Give no current figure | The JD states no pay term, so this is the first logistics item a recruiter asks. JD because it is a term of the listed job |
| A3 | "What's your notice period, and when could you start?" | JD | [generic] | Logistics slot: give your actual notice period and the earliest date you could really start, in your own words | A standard screen item; the recruiter email gives a single date for all three rounds, so timing is live. JD because it is a term of the listed job |
| A4 | "The role covers branches and the contact centre. Where could you be based, and how much could you move between sites?" | JD | [generic] | Logistics slot: say where you can work and how often you can travel between sites, in your own words. If you are unsure, say what you would need to know first | The JD's "across branches and the contact centre" makes the working pattern a natural check. JD because it is a term of the listed job |
| A5 | "Why are you looking to move on from your current role?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words. Keep to what you are moving toward and do not criticise a colleague or employer | Motivation consistency is scored here, and a reason that changes between rounds is a visible miss. EXP because it tests the story of the career |
| A6 | "What draws you to a member-owned credit union?" | CO | [grounded] | Selection scaffold on the values page, which you pasted: say what drew you, in your own words. If one of the four published values matches how you want to work, name it by its official name and say why, without claiming you already worked that way. If nothing comes to mind, say so plainly and ask what makes the work distinctive | The JD opens with "member-owned", and values are scored in Round 3, so a consistent line from Round 1 helps. CO because it tests homework |
| A7 | "Which part of this job would be hardest for you on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name the one you honestly pick, using that row's words: "I've never worked in a contact centre" (F2) or "I haven't presented to anyone above regional level" (F7). Then one sentence of plan, in your own words, and stop. Add no claim that the gap is smaller than it is | Your two stated gaps are the likeliest knockout checks. JD because it tests the listed requirements, and the Skeptic delivery is light here |
| A8 | "The role needs someone confident presenting to senior leaders. Where are you with that?" | JD | [grounded] "I've never presented to anyone above regional level" | The plain acknowledgment from F7: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan: for example, asking who the audience is and offering a practice run of your first report before it goes up. Do not claim comfort you have not shown | The JD line "confident presenting to senior leaders" is a requirement your material says you have not met at that level. JD because it scores a stated requirement |

## Round 1 reverse questions

| # | Reverse question | Why it lands |
|---|---|---|
| RA1 | "Is the 20-minute case on a real escalation or a typical one, and should I expect to talk it through or bring something prepared?" | Recruiter guidance is the highest-leverage input you can get, and it tells you whether a deliverable exists |
| RA2 | "When will you know who is on the panel, and could you tell me their branches?" | Lets you reweight Round 3 once names exist |
| RA3 | "What does the Head of Member Services most want from this hire in the first 90 days?" | The recruiter can tell you what the hiring manager has said; it shapes Round 2 |
| RA4 | "How is complaints work split today between branches and the contact centre?" | Turns your stated contact-centre gap into a learning question and shows the structure you would inherit |
| RA5 | "Which of the strategy brief's priorities does this role touch first?" | Shows you read the brief the recruiter sent |

---

# Round 2 — Head of Member Services (your future manager), 45 minutes, mostly behavioural

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time" stories | Top. The recruiter says the round is mostly behavioural | Selection scaffolds where no quote carries a story; "we" for context, "I" for contribution |
| Skeptic | Probes the gaps in F1, F2, F3, F6, F7 | High. A hiring manager derisks gaps, and the material has two stated ones. B5 is the deepest rehearsal in the pack | Say each limit once, plainly, then the plan; hold the position through follow-ups |
| Data-Driven Prober | Reads the spreadsheet claim line by line | Low. One built-reporting claim exists | Say what it counted, or say you do not know |

## Round 2 question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you had to deliver an unpopular message to someone more senior." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and an intact relationship afterwards. No sentence in your material states such a time, so none is supplied here. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | A persona stem for the behavioural round and a fit for a role that reports on complaints. VAL because it tests behaviour, not content |
| B2 | "Tell me about a time a complaint was escalated beyond the branch." | EXP | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Your quotes state the log and the escalation-script training, not a particular escalated case. Selection scaffold: pick one case, name the stake, what you did and what was yours. If no such case comes to mind, say so plainly, then give the nearest thing your material carries: you handled the branch's formal complaints log, and you trained new tellers on your escalation script | The JD's "coach branch supervisors on escalations" makes escalation the likeliest behavioural theme (F5, F1). EXP because the story must survive follow-ups |
| B3 | "How would you coach a branch supervisor who handles escalations differently from how you would want?" | JD | [grounded] "trained new tellers on our escalation script" | A live problem, so it asks about no past. Structure it: find out why they handle it that way, agree what a good escalation looks like, show it and review it together. Answer slot: if you have worked with other supervisors on escalations, say what happened and what part was yours; if not, say so plainly and stay with training new tellers on your escalation script | Coaching supervisors is a stated duty and F5's evidence is tellers, so expect the seam to be tested. JD because it scores that duty |
| B4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, mapped to the Own the Fix value: pick a problem you found, name who else could have passed it on, and say what you did to the end. Your quote states handling the log, not a particular problem followed through. If no such time comes to mind, say so plainly, then give the log you handled, in those words, or how you would handle it | Own the Fix is a published value and the recruiter says values are scored, so rehearsing it here helps in Round 3. VAL because it tests the value, not the job |
| B5 | "The role owns complaints across branches and the contact centre, and you haven't worked in a contact centre. How do you get there?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | **Highest-ROI rehearsal.** Opening: "I've never worked in a contact centre." What you can say about your own work stays at its scope: you handled the branch's formal complaints log, and you trained new tellers on your escalation script. Then the plan, in your own words: what you would learn first, from whom, before changing anything. Hold through three follow-ups. If told that branches handle complaints too, say the difference is the part you would learn, and do not claim the two are equivalent. If asked whether you can own something you have not seen, say you can speak for the branch side you handled and that you would learn the contact centre's side from the people who work it. If pressed a third time, concede the specific limit once more and return to the log and the plan. Never fold on what the quotes carry and never add to them | The JD's central line is end to end across branches and the contact centre, and F2 is a stated absence. JD because it scores that line, Skeptic because it probes your gap |
| B6 | "The role asks for experience handling regulated complaints. What does that look like in what you've handled?" | JD | [inferred] "I handled the branch's formal complaints log" | Open with what the quote carries: "I handled the branch's formal complaints log." Answer slot: expect a probe on what made a complaint formal at your branch. Say what you know, in your own words; if that was set elsewhere, or you do not know, say so plainly and stay with the log you handled. Name no rule, deadline or regulator you did not work with | The requirement is in the JD and F3's evidence touches it without showing it. JD because it scores a stated requirement |
| B7 | "You'd work with digital teams on self-service journeys. What's your experience there, and where would you start?" | JD | [grounded] | Answer slot (F6): if any of your branch work touched app or online self-service, say what, in your own words; if none did, say so plainly. Then the start: ask the digital team which complaint types they see members raising before a journey is built. Use the brief's figure as the brief gives it: 40% of member service to digital by 2028 | The strategy brief makes digital the largest stated shift, and F6 has no evidence. JD because it scores the listed duty; the CO call is why the brief's figure is in the guidance |
| B8 | "The role needs someone confident presenting to senior leaders. Where are you with that?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Plain acknowledgment from F7: "I haven't presented to anyone above regional level." What the quote carries: you built the monthly complaints spreadsheet your regional manager uses. That is a report others use; it does not say you presented it, so do not say you did. Then the plan, in your own words: ask what the audience wants decided and offer a practice run with this manager first | The future manager will own the exposure of a first presentation. JD because it scores a stated requirement |
| B9 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Describe what it was and who used it, in the quote's own terms. Answer slot: the JD's monthly line makes a probe on what it counted likely. If it counted volumes or resolution times, say how each was counted, what it was sensitive to and which part was yours; if it counted something else, or someone else set what it counted, say so plainly and describe what it did hold. Say plainly if you do not know how a figure was counted | The only reporting claim in your material (F4), and probers go line by line. EXP because it tests attribution |
| B10 | "How comfortable are you with Excel reporting? What would you build for this role's monthly report?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot (F8): if the spreadsheet was built in Excel, say so and say what it did, in your own words; if it was another tool, say so plainly and name it. For what you would build, structure it aloud: what the reader decides, what to count, how to show it. Claim no feature you have not used | F8's tool is unstated, so an Excel probe is likely. JD because it scores the stated requirement; the second sentence is CASE delivery |

## Round 2 reverse questions

| # | Reverse question | Why it lands |
|---|---|---|
| RB1 | "What would a good first 90 days look like, and how would you want to hear about problems early?" | Shows you ask for the manager's expectations before changing anything |
| RB2 | "How does complaints information reach senior leaders today, and where does it get stuck?" | Ties to the reporting and presenting lines and shows you are thinking about the audience |
| RB3 | "Which complaint types does the contact centre see most that branches rarely see?" | Converts your stated contact-centre gap into a learning question |
| RB4 | "How are self-service journeys chosen today, and how do complaints feed in?" | Ties to the brief's 40% by 2028 and to the JD's digital line |
| RB5 | "What will the move from eight branches to five hubs change about how complaints are handled?" | Shows you read the brief and asks the future manager for a view you cannot research |

---

# Round 3 — Panel of two branch managers, 60 minutes: 20-minute complaint-escalation case, plus the values round

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes scored against the four published values | Top. The recruiter says the panel scores against the four values | One story or scaffold per value; "we" for context, "I" for contribution |
| Case/Strategist | The 20-minute escalation case | High. The recruiter names a 20-minute case on a complaint escalation | Clarify, set the objective, structure, then decide; challenge one premise politely |
| Peer Evaluator | Seam questions with people who run branches | Medium. The panel are branch managers, and the role coaches branch supervisors; the relationship is my reading, not a stated fact | Propose seam principles and ask how it works today |
| Pressure | Time-boxed challenge on your gaps | Low. No signal beyond the standard panel prior | Hold the quoted core, concede each limit once |

## Round 3 question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Members First, Always. Selection scaffold: pick a decision where the member's side and an easier internal option pointed different ways; name the decision and what it cost you. Your quote states handling the log, not a decision. If no such time comes to mind, say so plainly, then give the log you handled, in those words, or how you would decide | The value's own words raise it; the recruiter says each value is scored. VAL because it tests the value |
| C2 | "Tell me about a time you explained something so that it needed saying only once." | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words. Selection scaffold: pick a time you explained something and it landed first time; say what made it plain. Your quote states the training, not an outcome. If no such time comes to mind, say so plainly, then give the training, in those words, or how you would make a letter plain | The value's own words: if a member needs it explained twice, the wording was wrong. VAL because it tests the value |
| C3 | "Tell me about a time a number and a person pulled in different directions." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Neighbours, Not Numbers. Selection scaffold: pick a case where the figure said one thing and a member or a town said another; say what you did. Your quote states the spreadsheet, not such a case. Do not describe the spreadsheet as a problem. If no such time comes to mind, say so plainly, then give the spreadsheet, in those words, or how you would keep the member in view of a monthly figure | The role reports numbers while the value is "Neighbours, Not Numbers", so the tension is likely to be probed. VAL because it tests the value |
| C4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix. Reuse B4's scaffold: a named problem, who else could have passed it on, what you did to the end. If no such time comes to mind, say so plainly, then give the log you handled, in those words, or how you would keep hold of one | The value's own words: whoever finds the problem keeps hold of it. Repeats B4 because a panel scores it on their own sheet. VAL because it tests the value |
| C5 | "A member has complained twice about the same fee error at a branch and was told it was settled. Now they ring the contact centre and say they are moving to an app-only bank. Walk us through what you do." | CASE | [generic] | Practice scenario, not the panel's actual case. Think aloud: clarify first (what the member was told, what is on record, whether it is formally a complaint and what clock applies); objective (fix the error, keep the member informed, record it); who needs to hear, and who keeps hold until it is closed (Own the Fix); a plain-words reply to the member (Plain Words); then the cause and what the branch learns. Challenge one premise politely, for example whether the member was told twice the same thing. The brief names app-only banks as the pressure, so say why one unresolved complaint matters | The recruiter names a 20-minute escalation case. CASE because it tests structure, and the panel scores the four values on it too |
| C6 | "The branch supervisor says it's settled and doesn't want to escalate. What do you say to them?" | CASE | [grounded] "trained new tellers on our escalation script" | A live problem, so it asks about no past. Structure it: ask what they know, agree what the record shows, offer the escalation route, keep the member informed in the meantime. Answer slot: if you have had this conversation with another supervisor, say what happened and what part was yours; if not, say so plainly and stay with training new tellers on your escalation script | The natural second leg of the case, and F5's evidence is tellers. CASE because it is a live problem |
| C7 | "As eight branches become five hubs over 2027, what would you want to be true of the complaints process for members whose branch is merged?" | CO | [grounded] | Use the brief's frame: eight branches into five hubs over 2027. Structure it: the member should not have to start again, the record follows the member, and the branch manager knows who holds the problem. Tie to Neighbours, Not Numbers: each branch is part of its town. Do not guess how the change affects the panel; ask them in RC2 | The brief's most concrete operational change falls on this panel's world. CO because it tests strategy fluency |
| C8 | "Where does your job stop and mine start when a complaint lands in my branch?" | JD | [generic] | A live problem, so it asks about no past. Offer principles and not a made-up seam: the member never has to explain it twice, and whoever finds the problem keeps hold of it until it is closed. Ask how it works today, then offer what you would bring: a shared view of open complaints | The role works across branches, and branch managers are the people who live the seam. JD because it scores the stated duty; Peer delivery |
| C9 | "How do you handle credit when a fix involves people from several teams?" | VAL | [generic] | Selection scaffold: pick a fix that crossed teams, name your part and name theirs. Your material states no such fix, so none is supplied. If no such time comes to mind, say so plainly, then give how you would share credit | A Peer Evaluator stem; credit-sharing is a collaboration check. VAL because it tests behaviour with equals |
| C10 | "Sixty seconds: why you, when you haven't worked in a contact centre and haven't presented to senior leaders?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level"; "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Pressure delivery. Pause, restate the question, then concede each limit once, in the F2 and F7 acknowledgments: "I've never worked in a contact centre" and "I haven't presented to anyone above regional level." Hold on what your quotes carry: six years in retail banking, the last three as a branch supervisor, and you handled the branch's formal complaints log. Then one sentence of plan for each limit. If pushed, repeat the limit and the quote; never add to either | Both negatives are stated in your message, so a panel can use them. JD because it tests the stated requirements, with Pressure delivery |

## Values cheat sheet (Round 3)

Values are the four on the page you copied on 25 November 2026. No quoted sentence of yours states a decision or an outcome, so each value gets a scaffold with its honest branch, not a mapped story.

| Value (official name) | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold at C1. Nearest thing your material carries: F1, "I handled the branch's formal complaints log". If no such time comes to mind, say so plainly |
| Plain Words | If a member needs it explained twice, the wording was wrong | Scaffold at C2. Nearest thing: F5, "trained new tellers on our escalation script". If no such time comes to mind, say so plainly |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold at C3. Nearest thing: F4, "I built the monthly complaints spreadsheet our regional manager uses". If no such time comes to mind, say so plainly |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold at C4 and B4. Nearest thing: F1, "I handled the branch's formal complaints log". If no such time comes to mind, say so plainly |

## Round 3 reverse questions

| # | Reverse question | Why it lands |
|---|---|---|
| RC1 | "What does a complaint that goes well look like in your branch, and where does the process let you down?" | Puts the panel's own experience first and tells you what the case will reward |
| RC2 | "How do you expect this role to work with branch managers as branches move into hubs in 2027?" | Asks the branch managers about the brief's change without assuming their view |
| RC3 | "What could this role do in its first month that would genuinely help your branch?" | Reciprocity: shows what you offer, not just what you need |
| RC4 | "Which of the four values is hardest to keep hold of in a busy week?" | Brings the values round into conversation and shows you take them as working guides |
| RC5 | "What do your supervisors most often get stuck on in an escalation?" | Ties to the coaching duty and tells you what the role would be coaching on |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | A7, B2, B5, C5, C10 |
| Report monthly on complaint volumes and resolution times | B9 |
| Coach branch supervisors on escalations | B2, B3, C6 |
| Work with digital teams on self-service journeys | B7 |
| 4+ years in financial-services customer operations | A1, C10 |
| Experience handling regulated complaints | B6 |
| Confident presenting to senior leaders | A7, A8, B8, C10 |
| Comfortable with Excel reporting | B10 |

## Prohibited claims

Built from the fit snapshot before the banks were written. These are not coached.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log, not the process |
| Handled regulated complaints | Inflated form of F3 | F3's quote at its own scope. B6's slot asks only what made a complaint formal at your branch |
| Coached or trained branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: new tellers, and a script. The limit is the pack's observation: the material says tellers, not supervisors |
| Reported on complaint volumes and resolution times | Inflated form of F4 | F4's quote at its own scope: you built the monthly spreadsheet. B9's slot asks what it held |
| Expert Excel skill | Inflated form of F8 | F8's quote at its own scope. The limit is the pack's observation: the material says spreadsheet, not Excel |
| Contact-centre experience, or complaints experience across channels | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." Then a plan, never a past |
| Presenting to senior leaders | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't presented to anyone above regional level." Then a plan, never a past |

## Sources

Provided documents: the job description you pasted; the values page text you pasted, copied on 25 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the process, a loop source; the four points of the July 2026 strategy brief as you relayed them; your background in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values page fixes the values cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes three sessions on 4 December, who runs each and what each holds; persona weights follow it |
| 3. `Ashgrove Credit Union strategy` | skipped | The July 2026 brief you relayed supplies priorities and the competitive frame for the CO questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewers' names, once assigned → an interviewer read, persona weights adjusted to their public footprint, and reverse questions tied to their paths
- The recruiter's answer on the 20-minute case (RA1) → a build section if any deliverable is announced, and a sharper Round 3 case bank
- Your answers to the slots on rows F1, F3, F4, F5, F6 and F8 (what the log and the spreadsheet held, the tool, any digital touchpoint) → those rows become stated evidence and the answer slots become story maps
- A copy of the monthly spreadsheet with member data removed, or the log's headings → raises F4 and F8 from medium, because that is the inspectable artifact for complaints reporting
- The full text of the strategy brief → the grounding brief currently rests on four relayed points
- Deeper research (up to 6 more searches and 2 more fetches, several more minutes) → role-family loop reports and recent organisation context; say so if you want it
- Hours available before 4 December → a prep triage section ordered to your time
- A tuesday-dossier.md from an earlier evaluation → verified evidence and stated limits; the pack stands without it
