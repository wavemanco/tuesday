I'll read the skill's reference files before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-6-denied-be8624ba/larkfield-systems_engineering-manager_interview_pack.md`. I built it in loop mode, with a shared fit snapshot and one mini-pack per round. Each mini-pack has its own persona weights, a bank of 8 to 10 questions, and reverse questions. It rests only on your message, because web search was refused here. That means no Larkfield values, strategy or loop details are in it, and the company-knowledge question (C8) is generic.

- **Most likely objection:** you've never owned a hardware-adjacent roadmap, while the role includes partnering with hardware on roadmap. That's A1, the pack's highest-ROI prep. I'd spend most of your time before Tuesday on it, because it will come back in all three rounds.
- **The 60% figure:** it comes up in Round 1 as a "walk me through how it was counted" probe (A8) and in Round 3 as "how much of it was you?" (C6). One rehearsal covers both.
- **The VP round:** it hinges on "never managed managers" (C4, C5). The pack has you say that plainly, hold what your material supports, and ask whether the role has managers reporting to it (RC1).
- **Answer slots:** where your material is silent (device fleets, growing engineers, working with hardware or product), the pack leaves an answer slot for you to fill from experience, or to say it wasn't yours. I didn't invent anything.

I can play the Skeptic on A1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full job description and your CV? Either one would replace the one-line role description and turn several rows from silence into your own quoted words. Or say skip and I'll leave it as is.
2. Did the recruiter say anything about Rounds 1 and 2, such as focus areas or a case, presentation or exercise to prepare? A pre-declared exercise would need its own build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (loop of three rounds)

Candidate: Yusuf. Mode: loop, built from your message alone (no JD text, no CV, no interviewer names, and web research was not available, so nothing here is sourced from Larkfield's own pages).

| Round | When | Who | Length |
|---|---|---|---|
| 1 | Tuesday | Director of Engineering, the hiring manager and your would-be boss | 45 min |
| 2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min |
| 3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min |

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and leadership philosophy, not generic virtue |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The stated responsibilities of the role, gaps included |
| CO | Company and industry knowledge |
| CASE | A live problem from the actual role, scored on structure |

Provenance labels: `[grounded]` traces to what you gave me, `[inferred]` is derived from it, `[generic]` is a role-family pattern with no claim about you or Larkfield. A cell that leads with a label and then quotes you rests on the quoted sentence and nothing more. "Answer slot" means an instruction for the interview: answer it from your own experience, or say plainly it was not yours or did not exist.

## Prep triage (two weeks, three rounds)

1. Before Tuesday, most of your time: A1, the hardware-roadmap objection. It is the question this pack names as the highest-ROI prep, because it will be asked in some form in all three rounds. Say it aloud until it is boring, through all three follow-up levels.
2. Before Tuesday: A8, the 60% figure. The same figure returns as C6, so one rehearsal serves both.
3. Before Tuesday: A2 and A4 (day-one weakness; one team of 6 versus two squads), then A5 to A7 once each, saying your framework aloud.
4. Tuesday to Thursday: B5, B6 (the hiring loop and the "about 40 interviews"), B8 and B9 (product partnership; the reliability quarter), B1 and B4 (the peer seam and what you bring them).
5. Thursday to Monday: C4 and C5 (the "never managed managers" answer, held and conceded), then C1 and C3, written in your own words.

Everything else is insurance.

## The fit snapshot (shared across all three rounds)

Role requirements are quoted from the role description you gave me. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (the two-squads part), role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says one team of 6, and the words stay there: "I have 9 years in engineering, 3 of them as a team lead of 6." The pack's observation is that the role is two squads and 11 engineers and your material does not show that scale. Answer slot: expect a probe on moving from one team to two squads. If any of your work spanned more than your own team, say what and what part was yours, in your own words; if none did, say so plainly and stay with leading a team of 6 |
| F2 | "Lead two squads building device-management services" (the device-management part), role description | none given | none | [grounded] | discovery | Your material says nothing about devices or device fleets; that is the pack's observation, not words for you. Answer slot: the role is device-management services, so expect a probe on what you know of that domain. If any of your work touched devices or fleets, say what and what part was yours; if none did, say so plainly and say what you would read or ask first |
| F3 | "own delivery, hiring and growth for 11 engineers" (the delivery part), role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Words at the quote's own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The pack's observation is that this is one reliability quarter, not a delivery record across a roadmap. Answer slot: expect a probe on how you keep delivery on track. If you used a way of tracking it, say what, in your own words; if there was none, or it was not yours, say so plainly and return to the reliability quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" (the hiring part), role description | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on the figure. Lead with the loop in the quote's own terms and keep the number attached to what it counts, interviews. The pack's observation is that the material says the loop, not who made the final decisions; B6's slot covers that |
| F5 | "own delivery, hiring and growth for 11 engineers" (the growth part), role description | none given | none | [grounded] | discovery | Your material says nothing about growing engineers; that is the pack's observation, not words for you. Answer slot: expect a probe on how you grow engineers. If any engineer's growth was something you worked on, say what and what part was yours, in your own words; if not, say so plainly and say how you would begin with a group of 11 |
| F6 | "partner with hardware and product on roadmap", role description | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | discovery | The negative you stated is yours to give back: "I've never owned a hardware-adjacent roadmap." Your material is silent on whether you have worked alongside hardware or product on what shipped. Answer slot: if you have, say what and what part was yours; if you have not, say so plainly and move to how you would start, said as a plan and never as a past |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| Lead two squads (scale) | A4, A5, C7 |
| Device-management services (domain) | A3, A6, B3, C8 |
| Own delivery | A5, A7, A8, B10, C6, C7 |
| Own hiring | B5, B6 |
| Own growth | C3 |
| Partner with hardware on roadmap | A1, A2, A7 |
| Partner with product on roadmap | B8, B9, B10 |

The recruiter's stated focus for round 3, values and leadership philosophy, is covered by C1 to C5. No question here is grounded in Larkfield's published values or strategy because neither could be fetched; C8 is generic for that reason.

---

# Round 1 — Director of Engineering, hiring manager (Tuesday, 45 min)

## Persona table

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the hardware-roadmap gap and the jump from one team to two squads | High (4 questions). A hiring manager is buying capability and derisking gaps, and F6 and F1 are where your own message says the material is thinnest | Rehearse A1 until it is boring; acknowledge only the negative you stated, then a forward plan said as a plan |
| Case / Strategist | Live problems from the role: planning a quarter, diagnosing a service, a slipping dependency | High (3 questions). The hiring-manager prior is Case plus Skeptic, and the role description names delivery and roadmap partnership | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Data-Driven Prober | Wants the 60% counted | Low (1 question). One headline figure, and the next two rounds also test it | Know what you can and cannot say about how it was counted; say plainly where you do not know |
| Conversational | The opening "walk me through your path" | Low (1 question). Casual, but scored | A 90-second arc built from your own sentences |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've said you've never owned a hardware-adjacent roadmap, and partnering with hardware on roadmap is part of this job. How do you plan to do it?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI rehearsal in this pack. Level 1, the concession, short and plain: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan: the first thing you would learn is how hardware constraints shape this roadmap and who decides what, by asking hardware and product directly. Level 2, "so why trust you": hold only what your quote carries, "I pushed a reliability quarter through against roadmap pressure", and do not widen it. Level 3, "what would you get wrong": name the thing you would be slowest on and how you would find out sooner. Answer slot: if you have worked alongside a hardware or product group on what shipped and when, say what and what part was yours; if you have not, say so plainly and stay with the plan | F6 is the most predictable objection and the material is thinnest exactly there. JD because it scores a stated requirement; the Skeptic delivery is how it will arrive |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick one limit honestly and say it in under a minute, then how you would close it. The material you gave supports naming the hardware-adjacent roadmap in your own stated words; if the device-management domain is also new to you, say that plainly. Do not name a fake weakness | F6 and F2 are the likeliest answers; the question tests calibration. JD with a Skeptic delivery |
| A3 | "Tell me about any work you've done around devices or device fleets." | JD | [grounded] | Answer slot: the role builds device-management services, so this is a direct probe. If any of your work touched devices or fleets, say what and what part was yours, in your own words; if none did, say so plainly and say what you would read or ask first | F2 is silence in the material, so the pack asks rather than assumes; the question presupposes nothing about your past |
| A4 | "You've led a team of 6. This role is two squads and 11 engineers. What changes?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start from the quote at its scope: "I've been a team lead of 6 for 3 of my 9 years." Then answer as principles for a larger group, said as what you would do, not what you did. Answer slot: if any of your lead work spanned more than your own team, say what and what part was yours; if none did, say so plainly and stay with leading 6 | F1 is a scale gap; the interviewer's numbers come from the role description and the premise from your own sentence |
| A5 | "Imagine two squads, one fleet of devices in the field, and a quarter where product, hardware and reliability each want the same engineers. How do you plan it?" | CASE | [generic] | Clarify first: what is fixed, who decides, what a miss costs. Then objective, segmentation of the work, approach, metrics, risks. Say your framework aloud. Challenge one premise respectfully. The guidance makes no claim about your past | The role is two squads and delivery; a live planning problem is the natural hiring-manager test. Generic because it is a pattern, not a fact about Larkfield |
| A6 | "Pages for a device-management service have doubled since last week's release. Diagnose it." | CASE | [generic] | Clarify (what pages, since when, which devices, what changed), form hypotheses ranked by cost to check, name the first two checks, say when you would roll back and who you would tell. Think aloud | F2 domain with a diagnosis format; tests structure over the right answer |
| A7 | "A hardware revision slips six weeks and product has already promised a customer a date. What do you do?" | CASE | [generic] | Clarify who promised what and what is movable. Then options and their costs, who decides, how you talk to product and hardware, and what you would change so a slip is seen sooner. Concede where you would need facts you do not have yet | Combines delivery with the hardware and product partnership of F3 and F6; generic because the scenario is a pattern |
| A8 | "Your on-call burden dropped 60%. Walk me through how that was counted, and which assumption behind it you would defend least." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Four slots, in your own words: how the 60% was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly. Keep the sentence's own order: it says the burden dropped after you pushed the quarter, which is not the same as the quarter causing it, so do not claim more | The headline figure, and a prober's target. EXP because it scores attribution; F3 is where it lives |
| A9 | "So, walk me through the journey. What brings you to this role?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc whose factual beats are the ones the quote states: 9 years engineering, 3 as a team lead of 6, currently at a payments company. Add the reliability quarter and the hiring loop only at the scope your own sentences give them. Answer slot: why this role, in your own words and only your own reason | Opening question in a hiring-manager round; the motivation beat is yours to supply |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| RA1 | "How are the two squads split today, and where do they depend on each other and on hardware?" | Shows you are thinking about the seams you will own, and gives you facts to answer A1 and A7 properly later |
| RA2 | "How does the roadmap get decided between hardware, product and engineering today, and where does that break?" | Goes straight at the part of the job where you said you are newest |
| RA3 | "What would make you say, ninety days in, that this hire was working?" | Converts an interview into a shared scoring sheet |
| RA4 | "Is there a part of my background you'd want me to close first?" | Invites the objection while you can still answer it; only ask it if you are ready to hear it |
| RA5 | "What do the 11 engineers need most right now: delivery, hiring or growth?" | The three things the role names; the answer tells you where the director's attention is |

---

# Round 2 — Panel: two staff engineers and a product manager (the Thursday after, 60 min)

## Persona table

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Staff engineers pricing what you cost and add to their work: the seam, disagreement, credit | High (4 questions). Staff engineers are peers to an EM on technical direction; the peer prior is Peer plus Prober | Reciprocity: what you bring, not only what you need; propose seam principles rather than claim to know the seam |
| Data-Driven Prober | Staff engineers checking the numbers and the hiring loop | Mid (3 questions). The same prior; your hiring figure is an easy target | Know what the "about 40 interviews" counts; say plainly where you do not know |
| Values / Behavioral | The product manager asking for a time you worked through roadmap tension | Mid (3 questions). The cross-functional prior is Values plus Conversational, and the role names partnering with product | Story-map the reliability quarter at its own scope; where no sentence carries the story, a scaffold ending in the honest branch |

Three people with three lenses: tune delivery per person, not per answer. Look at whoever asked, and answer the person, not the panel.

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between an engineering manager and a staff engineer on technical direction, and what happens when we disagree?" | CASE | [generic] | Propose principles, not a claim to know their seam: who owns the decision, who owns the outcome, how a disagreement is surfaced early and decided by a named person. Then ask how they work today. No claim about your past | Staff engineers will price how you share technical authority; the seam is the central peer question. Generic because it is a pattern |
| B2 | "How do you handle credit when work spans teams?" | VAL | [generic] | State your approach as a principle in your own words. Answer slot: if you have an example from your own work, say what and what part was yours; if you do not, say so plainly and stay with the principle | A peer-persona stem; scores partnership, not a specific story |
| B3 | "Two staff engineers disagree on how to roll out an update to devices already in the field. You're the engineering manager. What do you do?" | CASE | [generic] | Clarify what is at stake and how reversible it is. Surface both positions in their strongest form, name who decides and by when, decide how risk is contained, and say what you would leave to the engineers. Concede where you would need their technical judgment | Combines the device domain (F2) with the peer seam; scores whether you share the technical call |
| B4 | "What would you need from us in your first month, and what could you do for us?" | JD | [generic] | Reciprocity: lead with what you bring them (taking process and interruption load off them is a principle, not a claim about your past), then what you need to learn from them. Keep both short | The peer reciprocity question; panels weight what a hire adds to their load |
| B5 | "You said about 40 interviews last year. Walk me through how that number was counted." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Four slots, in your own words: what the number counts (the sentence says interviews, not hires or candidates); what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly | F4's figure, asked by people who will sit in your loop. EXP because it scores attribution |
| B6 | "Walk me through how your hiring loop for backend roles works." | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | The beats the quote states: you run the hiring loop, for backend roles, about 40 interviews last year. Answer slot: expect a probe on how the loop reached a decision on a candidate. Say how, in your own words; if the decision was not yours, say so plainly and describe your part | The role names hiring, and the staff engineers will interview with whoever you hire; F4 is the evidence |
| B7 | "How do you stay credible with staff engineers on technical decisions?" | JD | [generic] | A principle answer in your own words: how you ask, when you defer, when you decide. Do not claim domain depth the material does not show; say how you would learn the domain's failure modes from them | The device-management domain is new ground in the material (F2); credibility is the staff engineers' real question |
| B8 | "Tell me about a time you worked with a product manager on what would ship." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Selection scaffold: pick a time with a named decision, a trade-off and a relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the reliability quarter at its own scope: you pushed it through against roadmap pressure. Whether product was the other side of that pressure is not in your sentence; say who it was only if you know | The role names partnering with product on roadmap (F6); the PM will test it. VAL because it is a behavior probe |
| B9 | "Tell me about a time you pushed back on roadmap pressure." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story map on the quote's beats: the on-call burden, the reliability quarter, the push against roadmap pressure, the 60% drop after. Answer slot: expect probes on who the pressure came from and what you gave up. If there was a trade, say what and with whom; if there was none, say so plainly and stay with the beats above. Use "we" for context and "I" for what you did | F3 is your best story and the PM's best question; VAL because the scoring is how you held a position with someone |
| B10 | "How would you decide between a reliability quarter and a feature quarter?" | CASE | [generic] | Clarify what each protects and costs, who is affected, what the data says, then a decision rule you would say aloud and when you would revisit it. You may link it to your own reliability quarter at its scope: "I pushed a reliability quarter through against roadmap pressure." | A natural PM question that sits on F3; generic because it is a pattern for the decision |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| RB1 | "How do you want an engineering manager to engage with technical decisions, and where do you want us to stay out?" | Shows you share the technical call rather than compete for it |
| RB2 | "Where does device-management work hurt most today?" | Gives you the domain's real problems and tells staff engineers you ask rather than assume |
| RB3 | "What could a new engineering manager do in the first month that would genuinely help your team?" | The peer reciprocity question: it turns an evaluation into a collaboration |
| RB4 | "Where does the product side draw the line between product and engineering on the roadmap, and where does it blur?" | Directed at the PM, and the honest version of the partnership requirement in F6 |
| RB5 | "What's the last disagreement across your teams, and how was it settled?" | Surfaces how decisions really get made; a tidy answer is as informative as a messy one |

---

# Round 3 — VP Engineering, values and leadership philosophy (the following Monday, 30 min)

Thirty minutes will hold perhaps four or five questions plus yours. Prepare all eight, and rehearse C1, C4 and C5 first.

## Persona table

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" probes on how you lead; the recruiter's own description of the round | High (4 questions). The recruiter's words, "values and leadership philosophy", detect a values-style round, though Larkfield's published values were not available to this pack | Map a story where a sentence of yours carries one; a scaffold ending in the honest branch where none does |
| Pressure | Time-boxed challenge on why you, and how much was you | Mid (2 questions). The executive prior pairs strategy with Pressure, and your two stated negatives are the obvious lever | Pause, restate, hold the position the quotes carry through two follow-ups, concede the two negatives plainly and specifically |
| Case / Strategist | A strategy-altitude problem and a company-knowledge check | Mid (2 questions). The executive prior; kept short because the recruiter pointed the round at values | Structure first; use the company's own vocabulary once you have read their pages |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What's your philosophy of leadership?" | VAL | [generic] | Say in one or two sentences, in your own words, what you believe leaders owe the people they lead. Then point to one thing in your material that you did which fits it, at the scope your sentence gives. The pack does not write the philosophy for you: only a belief you actually hold survives the follow-up | The round is described as leadership philosophy; the opener must be yours |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Selection scaffold first: a named stake, a moment you did not fold, a relationship intact after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the reliability quarter at its own scope. Answer slot: whether the pressure came from leadership is not in your sentence; if it did, say who and what you said, in your own words; if it did not, say so plainly and stay with the beats the sentence states | A persona stem for values rounds; F3 is the nearest story, so the pack states its limit |
| C3 | "Tell me about a time you helped an engineer grow." | VAL | [grounded] | Selection scaffold: pick one person, one specific thing that changed for them, and your own part. If no such time comes to mind, say so plainly, then say how you would approach growing engineers across a group of 11, said as a plan. The material you gave carries no sentence for this | The role names growth (F5) and a VP of engineering will ask about developing people |
| C4 | "You've never managed managers. What would you want to learn before you did?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Level 1: "I've never managed managers." Say it first, plainly, then say what you would want to learn, as a plan: how the VP develops managers and what they expect of one. Do not describe management of managers as if you had done it. Whether this role has managers reporting to it is not in your material; the answer to that is a reverse question below | The VP owns the leadership model, and your own message raises this gap. VAL because it scores self-assessment |
| C5 | "Sixty seconds: why you, rather than someone who has already managed managers or owned a hardware roadmap?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year.", "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold-then-concede. Hold what the sentences carry: you run the hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Hold it through two follow-ups by returning to those sentences, never by adding to them. Concede the two stated negatives plainly: "I've never managed managers" and "I've never owned a hardware-adjacent roadmap". Do not claim one makes up for the other | A stress prompt aimed at the two stated negatives (F6); the structure matters more than the content |
| C6 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot, in your own words: which part was yours and which part others', and how the number was counted. The sentence says the burden dropped after you pushed the quarter; do not stretch "after" into "because". If it was a shared effort, say so plainly. Pause before answering | The same figure as A8, in its pressure form; one rehearsal covers both |
| C7 | "How would you balance reliability against the roadmap across two squads when hardware dates keep moving?" | CASE | [generic] | Clarify what is fixed and who decides, state a decision rule aloud, say how you would tell each squad and when you would revisit the rule. You may link to your reliability quarter at its own scope; do not describe it as a rule you set | The strategy-altitude version of F3, set in this role |
| C8 | "What attracts you to industrial IoT, and what do you know about Larkfield?" | CO | [generic] | Answer slot for the first half: your own reason, in your own words; the pack supplies none. For the second half, read the company's own pages, careers material and any recent news yourself before Monday and say only what you found; this pack could not fetch them | A VP will check homework. Generic because no research ran |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| RC1 | "Does this role have managers or leads reporting to it, or is it all individual contributors?" | Settles how much of C4 applies to this job instead of leaving it as an assumption |
| RC2 | "What does your leadership philosophy look like in practice? Is there a decision that tested it?" | Turns the values round into a two-way conversation; asked after you have answered C1 |
| RC3 | "How do you develop engineering managers here?" | Shows you plan to grow; the answer tells you what support the role gets |
| RC4 | "What would you want this role to have changed in a year?" | Gives you the VP's definition of success |
| RC5 | "Where does the engineering organization feel the most strain as the company grows?" | Altitude question; invites the VP to name the real problem |

---

## Prohibited claims (shared)

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed two squads, or 11 engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one team of 6. A4's slot stays inside leading a team of 6 |
| Owned delivery for a roadmap | Inflated form of F3 | F3's quote at its own scope: the on-call burden and the reliability quarter. The limit is the pack's observation, not words for you |
| Made the hiring decisions, or hired a number of people | Inflated form of F4 | F4's quote: you run the loop, about 40 interviews. The pack's observation is that the material says interviews, not hires or decision rights; B6's slot asks only how a decision got made |
| The reliability quarter caused the 60% drop, or the 60% was entirely yours | Inflated form of F3 | The sentence as stated: the burden dropped after you pushed the quarter. A8's and C6's slots ask how it was counted and which part was yours |
| Has managed managers | Negative you stated, F6 | The plain acknowledgment: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot |

## Sources

Provided documents: your message (the role description, the three rounds and your background). No dossier was provided. No job description text, CV or interviewer names were supplied.

Searches sent, all refused by the host:

- "Larkfield Systems industrial IoT values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems strategy news device management" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Would have fed a values and principles cheat sheet and mapped VAL questions by value name; the section is dropped and C1 to C3 use scaffolds |
| 2. Interview process, role family | unavailable | Would have checked the loop; your own words already establish three sessions and who runs each, so the round structure stands on them |
| 3. Strategy and recent news | unavailable | Would have fed CO and company-grounded CASE questions; C8 is generic as a result |
| 4. Interviewer public footprint | n/a | No interviewer names were given, so there was no query to form; there is no interviewer read |
| 5. Representative JD | skipped | The role description you gave fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the six fit-snapshot rows quote the JD's own lines instead of the one-line role description, and any requirement it lists beyond those six gets a question
- Your CV → evidence cells quote it directly, and F2 and F5 may move from silence to quoted evidence
- Your answers to the answer slots (F1, F2, F3, F5, F6) → the rows they touch regenerate with your own words
- The recruiter's notes on rounds 1 and 2, including any case, presentation or exercise → coverage for a pre-declared deliverable, plus a focus-weighted persona table
- Interviewer names (the Director, the two staff engineers, the product manager, the VP) → a tailored interviewer read and reverse questions tied to their public paths
- Company web access (values, interview process, strategy) → a values cheat sheet, a grounded CO bank and a checked loop; a deeper pass would add up to 6 further searches and 2 further fetches, several more minutes
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and a sharper objection list
