I'll read the reference files the skill points to before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-8-denied-227c9c96/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop from the recruiter's email. It has a shared fit snapshot, then a mini-pack per round with its own persona weights, questions and reverse questions.

- **Highest-ROI prep:** B5, the contact-centre question. You said you've never worked in a contact centre, and the job's headline duty covers branches and the contact centre. It will come up in some form in all three rounds (A7, B5, C9). B5 has four follow-up levels.
- **Second gap:** you've never presented above regional level, which the JD's "senior leaders" line tests. That is B6, and the pack treats it the same way: say it plainly, then hold only what your own words carry.
- **Panel round:** the four values are mapped in the cheat sheet. Each maps to one of your quoted sentences or a selection scaffold. "Neighbours, Not Numbers" is the one to watch, because the monthly spreadsheet you built invites the "where do the neighbours come in?" probe.
- **Answer slots:** several answers are slots, not claims. The material doesn't show whether your complaints log was regulated, what your spreadsheet counted or whether it was Excel, or whether you've coached supervisors or worked with a digital team. Answer each from what you actually did, or say plainly that you didn't.
- **Research:** I ran no searches, because your pasted material fixed every research target. The strategy points rest on your summary of the brief, not the brief itself.
- **Gaps in the pack:** the interviewer names aren't assigned, so there's no interviewer read. The 20-minute case format is unknown, so C5 is a generic escalation case.

Say the word and I'll play the panel on B5 or C9, with follow-ups that react to your answers.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Interviews on 4 December 2026, three rounds in one loop:

- Round 1 (A): 30 minutes with the recruiter.
- Round 2 (B): 45 minutes with the Head of Member Services, your future manager, mostly behavioural.
- Round 3 (C): 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation. The panel is also the values round and scores against the four published values.

Built in loop mode: one shared fit snapshot, then a mini-pack per round. Interviewer names are not assigned yet, so there is no interviewer read. The case format is unknown, so C5 is a generic escalation case, not a rehearsal of theirs.

## How to use this pack

Personas are how a question arrives. Types are what it scores. Guidance is scaffolding for your own words, not a script. An answer slot is an instruction for the interview: answer it truthfully from your own experience, and if the practice it names was not yours or never existed, say that plainly.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the published values |
| EXP | Whether your background claims survive scrutiny |
| JD | The stated responsibilities and requirements, gaps included |
| CO | Knowledge of Ashgrove's strategy and competitive position |
| CASE | Structure and reasoning on a live problem |

The single highest-ROI rehearsal in this pack is **B5**, the contact-centre question. It is the one gap you stated in your own words that sits in the job's headline duty. It will come up in some form in all three rounds (A7, B5, C9), so it gets the most follow-up levels.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your words reach the years in retail banking terms, and the JD's phrase is customer operations, so say what your sentence says: "I've worked six years in retail banking, the last three as a branch supervisor." A years-of-experience line is a risk to name, not a gate. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal complaints log and does not show which rules governed it. Answer slot: the JD's word regulated makes a probe on what governed the log likely. If the log was kept to external rules, say which and what that meant for how you handled it, in your own words; if it was an internal log, or you do not know, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Words at the quote's own scope: "I handled the branch's formal complaints log." Your material says one branch's log, not a process across branches. Answer slot: the JD's across-branches line makes a probe on how far your handling reached likely. Say what the log covered and who used it, in your own words; if it covered only your own branch, say so plainly and stay with it |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past: what you would find out first about how complaints enter and leave the centre. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Quote at its own scope. Your material says a monthly complaints spreadsheet and does not show what it counted. Answer slot: if it counted volumes or resolution times, say which and how they were counted, in your own words; if it tracked something else, say so plainly and describe what it did |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Words at the quote's own scope: "I trained new tellers on our escalation script." Your material says tellers, not supervisors. Answer slot: if you have guided other supervisors through an escalation, say what, in your own words; if you have not, say so plainly and stay with the tellers |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show it. Answer slot: if you have worked with an online or app team on something members use themselves, say what and what your part was; if you have not, say so plainly, then say what you would ask them first |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented above regional level." Then how you would prepare, said as a plan and never as a past. Your material does not say what presenting at regional level involved, so nothing is built on it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says a spreadsheet, not which tool. Answer slot: if it was Excel, say so and say what it did; if it was another tool, say so plainly and stay with what you built |

## Grounding brief

Built from your summary of the July 2026 strategy brief the recruiter sent. I have not read the brief itself.

| Item | Why it matters for this role | Provenance |
|---|---|---|
| 40% of member service moved to digital channels by 2028 | Ties to the JD line on self-service journeys (F7) and to how complaints will start and travel | [grounded] your account of the brief |
| Eight branches consolidated into five hubs over 2027 | Touches the JD's across-branches scope (F3) and the value Neighbours, Not Numbers | [grounded] your account of the brief |
| Small-business lending product launching in Q1 2027 | A new product is a new source of member contact; worth asking how complaints on it will be logged and reported | [inferred] from the launch date, not from the brief |
| Main competitive pressure is app-only banks | A benchmark for what self-service feels like to a member; ties to Plain Words | [grounded] your account of the brief |

## Round 1 (A): recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background, motivation, logistics | High: the recruiter-screen prior is conversational plus a light skeptic, and this is a 30-minute screen | Pre-script a 90-second arc; treat casual questions as scored |
| Skeptic (light) | Knockout checks on the two obvious gaps: contact centre and regulated complaints | Medium: the same prior, and F2 and F4 are the rows a screener checks first | Say the gap in your own words, then what your material does carry |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc using only those beats, in your own words: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log you handled; the monthly complaints spreadsheet you built that your regional manager uses. Close on why this role. Answer slot: say which of Ashgrove's published values or strategy lines is true for you and why; if none is, say so plainly and name what drew you instead | The opener of nearly every screen; F1, F2 and F5 supply the beats. EXP because it tests whether the story matches the paper |
| A2 | "What interests you about Ashgrove?" | CO | [grounded] | Pick one strategy line and one published value, using the value's exact name, and say why it matters to the work of this role. The pack's grounding brief gives the lines. Say it in your own words and connect it to complaints, not to banking in general. The guidance makes no claim about your past | Tests homework and motivation consistency. CO because it checks company knowledge; recruiters hear the generic version constantly |
| A3 | "What's your notice period?" | JD | [generic] | Give your actual notice period and any constraint on a start date, in your own words. The pack supplies no figure | Logistics slot; a recruiter checks it first. JD because it is a term of the listed job |
| A4 | "What salary are you looking for?" | JD | [generic] | Either give your own number, in your own words, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." The pack supplies no figure | Logistics slot. JD because pay is a term of the listed job |
| A5 | "Are you comfortable with where the role is based?" | JD | [generic] | Give your own answer on location and any limit on days or travel. The JD you pasted names no location, so you may ask where the role sits and whether branch visits are expected. The strategy summary says eight branches become five hubs over 2027, so you may also ask how that affects where the role sits | Logistics slot. JD because location is a term of the listed job |
| A6 | "What's prompting you to look at a move now?" | EXP | [generic] | Give your own reason in your own words, and point it toward this role where that is true. The pack supplies no reason | Logistics slot for the reason for leaving; EXP because it tests consistency with the story told in A1 |
| A7 | "This role spans branches and the contact centre. Where does your experience sit on the contact-centre side?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Concede first, in your own words: "I haven't worked in a contact centre." Then the branch side at its own scope: "I handled the branch's formal complaints log." Then a plan, not a past: what you would learn first about how complaints enter and leave the centre. B5 is the deeper version of this | F4 is the screener's likeliest knockout; JD because it scores the stated scope of the role |
| A8 | "What's your experience of handling regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold the quote at its scope: "I handled the branch's formal complaints log." Answer slot: if the log was kept to external rules, say which and what that meant for how you handled it; if it was an internal log, or you do not know, say so plainly and stay with the log | F2 is the JD's named experience requirement and the recruiter will ask it in some form. JD because it scores a stated requirement |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| A-R1 | "Which complaints does this role hold today: only escalated ones, or every formal complaint across branches and the contact centre?" | Clarifies the scope the JD calls end to end, and shows you are sizing the job, not just applying |
| A-R2 | "How is the contact centre organised today, and who does it report to?" | Turns your stated gap into curiosity; it is the half of the role you have not worked in |
| A-R3 | "Which of the 2026 strategy's moves reaches this role first: the digital shift, the hub consolidation or the lending launch?" | Shows you read the brief the recruiter sent and can think at its altitude |
| A-R4 | "What does the Head of Member Services most want covered in round two?" | Recruiter guidance is the highest-leverage input you can get before 4 December |
| A-R5 | "When will the panel's names be confirmed?" | Lets you prepare for the people in round three; names are the missing input behind the upgrade menu |

## Round 2 (B): Head of Member Services, 45 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Past-behaviour questions, probably in STAR shape | High: the recruiter calls the round mostly behavioural | Choose stories where the hard truth landed; "we" for context, "I" for your part |
| Skeptic | Probes on the contact-centre and senior-leader gaps from a manager pricing risk | High: the hiring-manager prior is Case plus Skeptic, and this person would manage you | Say the gap in your own words, then hold only what your quotes carry |
| Case/Strategist | One or two live problems on the digital shift and the first 90 days | Medium: part of the hiring-manager prior, lowered because the round is mostly behavioural | Clarify, structure, state your limits |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem; the role reports to senior leaders (F8). VAL because it scores behaviour, not knowledge |
| B2 | "Tell me about a time you helped someone handle an escalation better." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on F6: "I trained new tellers on our escalation script." Tell those beats in your own words. Answer slot: if a teller's handling of an escalation changed afterwards, say what you saw, in your own words; if you did not see a change, or there was none, say so plainly and describe the training. Do not describe it as coaching supervisors | The JD's coaching line (F6) is where your evidence is nearest but not exact. EXP because it tests what you actually did |
| B3 | "Tell me about a time you worked with another team to get a member's problem fixed." | VAL | [grounded] | Selection scaffold: pick a time the fix sat outside your branch, with a named owner on the other side, a moment you kept hold of it, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's across-branches and digital-team lines raise it. VAL because Own the Fix is a published value the panel will also score |
| B4 | "Walk me through the monthly complaints spreadsheet your regional manager uses." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Beats the sentence states: you built it, it is monthly, it is about complaints, your regional manager uses it. Answer slots: what it counted, in your own words, and whether it held volumes or resolution times, as the JD asks; which tool it was, since the JD says Excel; and the part of it you would defend least, said before they ask. If you do not know how a column was counted, say so plainly | F5 and F9 are the reporting requirements; an interviewer will test whether you can explain your own tool. EXP, with JD content |
| B5 | "This role owns complaints end to end across branches and the contact centre. How would you handle the contact-centre half?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" | **Highest-ROI rehearsal.** Level 1, concede first: "I haven't worked in a contact centre." Hold the branch side at its own scope: "I handled the branch's formal complaints log" and "I trained new tellers on our escalation script." Then the plan, stated as future: how you would learn how complaints enter and leave the centre. Level 2, "Branches and the centre will each try to hand you the problem — where do you start?": a structure of what you would ask each side, with no claim to know how Ashgrove's centre works. Level 3, "Why take the risk when we could hire someone from a contact centre?": hold by returning to those two quotes, concede specifically that you would be learning the centre's side. Level 4, "What would you get wrong first?": say which part you expect to take longest, in your own words. Say all of it without defensiveness | F4 is the gap the manager is paid to find, and it sits in the JD's headline duty. JD because it scores the stated scope; the depth is the point |
| B6 | "The role reports monthly to senior leaders. What makes you confident presenting at that level?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses" | Concede in your own words: "I haven't presented above regional level." Hold only what the second quote carries: "I built the monthly complaints spreadsheet our regional manager uses." It does not say you presented it. Answer slot: if you have presented at regional level, say what and to whom; if you have not, say so plainly. Then the plan: ask the Head what format and audience they expect, and rehearse once before the first report | F8 is the second stated gap. JD because the confidence line is a stated requirement |
| B7 | "Tell me about working with a digital team on something members use themselves." | JD | [grounded] | Answer slot: if you have, say what it was and your part in it, in your own words; if you have not, say so plainly, then say what you would ask a digital team first and what you would want counted. Never present branch feedback as digital work | F7 has no evidence in your material. JD because it scores the self-service line |
| B8 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that do to complaints?" | CO | [grounded] | Structure: clarify what counts as service moved and which complaint types can start online; objective; which members will self-serve and which will not; the hand-offs between app, branch hub and contact centre; metrics, using the JD's volumes and resolution times; risks, including a member who needs it explained twice and app-only banks as the benchmark. Say what you would need to know. The guidance makes no claim about your past | The differentiator question: strategy plus the role. CO with CASE delivery |
| B9 | "What would your first 90 days look like?" | CASE | [generic] | A plan, not a past: listen before changing anything. The first weeks go to the contact-centre side (F4) and to agreeing with the Head what the monthly report should show and for whom (F8). Name what you would not change yet | Managers use it to price the risk of the gaps. CASE because it asks for a structured plan |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| B-R1 | "How do complaint numbers reach senior leaders today, and who would I present them to?" | Goes straight at F8 and shows you are planning for the gap |
| B-R2 | "Where does contact-centre complaint handling meet branch handling today, and where does it hurt?" | Honest curiosity about the half you have not worked in |
| B-R3 | "Which of the four values does the team find hardest to live up to in complaints?" | Links to the round-three scoring and invites a real answer |
| B-R4 | "How will moving 40% of member service to digital by 2028 change what a complaint is?" | Shows strategy fluency at the manager's altitude |
| B-R5 | "What would you want to have changed by month six, and what would make you say it was working?" | Converts the 90-day plan into your future manager's own measure |

## Round 3 (C): panel of two branch managers, 60 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Stories scored against the four published values | High: the recruiter says the panel is the values round and scores against the four values | One story per value; "we" for context, "I" for your part |
| Case/Strategist | The 20-minute complaint escalation case, probably with strategy follow-ups | High: it is announced, 20 of the 60 minutes | Clarify, structure, state limits, keep the member central |
| Peer Evaluator | Seam questions: who owns what when a complaint escalates through a branch | Medium: branch managers work beside the role you would hold, and the JD has you coaching their supervisors | Offer seam principles, not a pretence of knowing the seam |
| Pressure | A time-boxed challenge on the two gaps | Low to medium: not announced; a panel often adds one | Hold, then concede specifically |

### Values / principles cheat sheet

Values are Ashgrove's, copied by you this morning from ashgrovecu.org/about/values. Working meanings are paraphrased. Each candidate story rests on a quoted sentence or is a selection scaffold.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold (C1): pick a time what the member needed and what the process said pulled apart; if none comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log" (F2), or how you would decide |
| Plain Words | If a member needs it explained twice, the writing was wrong | F6: "trained new tellers on our escalation script". Beats the sentence states: new tellers, our escalation script. Whether any wording was ever changed because something needed explaining twice is an answer slot (C2) |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold (C3): pick a time the local picture changed what you did; expect the probe that a monthly spreadsheet (F5, "I built the monthly complaints spreadsheet our regional manager uses") is a numbers tool, and be ready to say what it left out |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2: "I handled the branch's formal complaints log". The beat the sentence states is the log; one complaint you kept hold of is an answer slot (C4) |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold for Members First: pick a time what the member needed and what the process said pulled apart; name the stake, what you chose and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log," or how you would decide | Value one of four; the panel scores each by name. VAL |
| C2 | "Tell me about a time something you wrote or said needed explaining twice." | VAL | [grounded] "trained new tellers on our escalation script" | Beats the sentence states: you trained new tellers on an escalation script. Answer slot: if any wording of the script or the training had to change because it needed explaining twice, say what changed and how you knew; if none did, say so plainly and describe the training | Plain Words; F6 is the nearest evidence. VAL |
| C3 | "Tell me about a time the local picture, not the numbers, changed what you did." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold for Neighbours, Not Numbers: pick a time something specific to your branch's town changed your handling. Answer slot: expect "you built a spreadsheet, so where do the neighbours come in?"; say what the spreadsheet counted and what it left out, in your own words. If no such time comes to mind, say so plainly, then give how you would hold both | Value three; the spreadsheet is the likeliest hook for the opposing reading. VAL |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Beat the sentence states: you handled the log. Answer slot: pick one complaint from it you kept hold of, and say what you did and how it ended, in your own words; if none stayed with you to the end, say so plainly and say how you would keep hold of one that crosses the contact centre | Own the Fix; the JD's end-to-end ownership line makes it the value closest to the job. VAL |
| C5 | "A member complained at a branch counter, was passed to the contact centre and has rung three times. The supervisor's note says resolved, and the member says it is not. What do you do in the next 24 hours, and what do you change?" | CASE | [generic] | Clarify first: is a regulatory deadline running, who holds the case now, what the member was told, what resolved meant. Objective: the member's problem solved and the case owned by one named person. Approach: contact the member plainly, reconcile the branch and centre records, decide the next step. Then what you change: the hand-off so no one re-explains. Say your limits aloud, including that you would learn how Ashgrove's centre records cases. Challenge one premise respectfully, such as the word resolved | The announced 20-minute escalation case, as a generic stand-in. CASE; the real case may differ |
| C6 | "A branch supervisor says they followed the script and the member was still failed. How do you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | Structure: listen to the case as they saw it, separate the script from the outcome, agree one change, and own the follow-up. Your own words stay at their scope: "I trained new tellers on our escalation script." Answer slot: if you have guided another supervisor through an escalation, say what; if not, say so plainly and stay with the tellers | The JD's coaching line (F6) and the panel are the supervisors' own managers. CASE with JD content |
| C7 | "Eight branches are becoming five hubs over 2027. What happens to complaint handling in a town that loses its branch?" | CO | [grounded] | Clarify first: what the consolidation changes for members and what is already decided. Then structure: how a member in an affected town raises a complaint, how it reaches the hub, how reporting shows the town and not only the total. Tie it to Neighbours, Not Numbers and Plain Words. Do not argue the strategy; say what you would need to know. The guidance makes no claim about your past | Strategy question for the people the consolidation touches most; an inference from their titles, not from anything they said. CO with CASE delivery |
| C8 | "Where does your role end and a branch manager's begin when a complaint escalates?" | CASE | [generic] | Offer seam principles, not a claimed map: the member never explains twice, one named owner at each moment, the branch keeps the relationship while the role keeps the process and the report. Say you would agree the seam with the managers, not impose it. Reciprocity: what you would bring their branches | Peer-evaluator seam question; the panel are the role's closest colleagues. CASE with JD content |
| C9 | "Sixty seconds: why you over someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" | Concede in your own words: "I haven't worked in a contact centre." Hold the branch side at its own scope: "I handled the branch's formal complaints log" and "I trained new tellers on our escalation script." On the second follow-up, return to those two quotes and add nothing; concede specifically what you would be learning | The B5 objection again, time-boxed. JD under pressure |
| C10 | "That spreadsheet — how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if anyone else set what it showed or supplied its data, say which part was theirs; if none of that applied, say so plainly. Hold through two follow-ups by returning to the sentence | The attribution probe that a numbers-minded panelist uses on F5. EXP under pressure |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| C-R1 | "What could a new person in this role do in their first month that would genuinely help your branches?" | Reciprocity with the people the role works beside |
| C-R2 | "How do you want complaints from affected towns handled during the changeover from eight branches to five hubs?" | Shows you took Neighbours, Not Numbers seriously and read the strategy |
| C-R3 | "What does a good escalation hand-off from your branch look like?" | Moves C5 and C8 from rehearsal to their real practice |
| C-R4 | "Where do you see Plain Words in complaint letters today, and where not?" | Uses a published value to ask a practical question |
| C-R5 | "A year in, what would make you say the complaints process had improved for your members?" | Members First turned into a measure the panel owns |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | A7, B5, B9, C4, C5, C9 |
| Report monthly on complaint volumes and resolution times | B4, C3, C10 |
| Coach branch supervisors on escalations | B2, C6 |
| Work with digital teams on self-service journeys | B7, B8 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | A8, C5 |
| Confident presenting to senior leaders | B1, B6, B9 |
| Comfortable with Excel reporting | B4, C10 |

## Prohibited claims

What this pack will not coach, and why. The honest form is what you say instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log, not a process across branches |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its scope. The limit is the pack's observation: your material says a formal log, not which rules governed it |
| Reported complaint volumes and resolution times | Inflated form of F5 | F5's quote at its scope. Your material says a monthly spreadsheet, not what it counted |
| Coached supervisors on escalations | Inflated form of F6 | F6's quote at its scope: tellers, not supervisors |
| Built Excel reporting | Inflated form of F9 | F9's quote at its scope: a spreadsheet, tool not stated |
| Has contact-centre experience | Negative you stated, F4 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I haven't presented above regional level." No slot |

## Sources

Provided documents: the job description you pasted; the four published values you copied from ashgrovecu.org/about/values on 25 November 2026; the recruiter's email on the three rounds; your account of the July 2026 strategy brief, not the brief itself; your background message. No dossier was present. Interviewer names were not given.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the values cheat sheet and the VAL questions; no call sent |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email names all three rounds, who runs them and how long they are, which fixes the loop and the persona weights; no call sent |
| 3. `Ashgrove Credit Union strategy` | skipped | Your account of the July 2026 brief fixes the grounding brief and the CO questions; no call sent |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No names yet, so there is no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you pasted fixes the fit snapshot and JD questions |

## Upgrade menu

- The panel's and the Head of Member Services' names, when assigned → an interviewer read, persona weights adjusted to their public footprint, and a reverse question tied to each path
- The recruiter's note on the 20-minute case (format, materials in advance, whether you present or discuss) → C5 becomes a build for their case instead of a generic stand-in
- The full strategy brief text → the grounding brief and B8, C7 use its own wording; two rows now rest on your summary
- An answer to the slots in F2, F3, F5, F6, F7 and F9 → each row regenerates from your own words; a complaints-log extract and the spreadsheet itself, with member details removed, would lift F2, F5 and F9 from medium to high
- Your CV → every row drawing on your message gains its source line, and the snapshot can add rows
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes → competitor and role-family loop reports behind the CO bank, run only on your say-so
- A tuesday-dossier.md from an earlier evidence check → verified evidence and absolute prohibited claims replace this pack's locally built list
