I'll read the reference files the skill points to before building the pack.
The pack is built and saved. Here is the summary.

Your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md` in the working directory. I built it for the Outage Hour, which is Saltmarsh's single 60-minute interview with the hiring manager. Their careers page describes it as a live-incident tabletop on a simulated outage, followed by a values conversation. I assumed Tobias is that hiring manager.

It has 19 questions across five personas. It also has a fit snapshot against the JD, a read on Tobias, a values cheat sheet for the three published values, six reverse questions and a prep triage for the time before Friday.

- **Biggest exposure:** you've never worked on a game with in-app purchases, and Saltmarsh announced in September that both titles move to a season-pass model in February 2027. C1 to C3 rehearse that objection, and C1 is the highest-ROI prep in the pack. The announcement doesn't say how the pass is sold, so R4 asks him.
- **Strongest ground:** your weekly content-drop calendar and the QA checklist. Tobias is a former QA lead, so expect checklist questions to go deep.
- **The JD and the announcement disagree:** the JD says "two of our mobile titles", but the announcement retires per-title event teams in favour of one live-ops group. R3 asks where this role sits.
- **Research:** 4 searches and 2 page fetches. I read only the search snippets for the announcement and for Tobias's GDC talk, not the pages themselves.

Say the word and I'll play Tobias on C1, with follow-ups that react to what you actually say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the hiring manager you'd report to? If he isn't, the persona weights change.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be the hiring manager, because the company's careers page describes the loop's one interview as run by "the hiring manager". Confirm it and the persona weights get retuned.
**Round:** 60 minutes, Friday.

## How to use this pack

- **Personas are how a question is asked; types are what it is scoring.** Each bank is one persona, ordered by weight. Each question carries one type tag.
- **Type key**
  - VAL: whether past behaviour shows the company's published values.
  - EXP: whether your own claims survive scrutiny, and exactly what was yours.
  - JD: whether you can do the listed job, gaps included.
  - CO: homework on the company and its strategy.
  - CASE: a live problem from the role, scored on structure and reasoning.
- **Guidance is scaffolding, not a script.** Every claim about your past rests on a sentence you wrote, quoted in the Provenance column. Where the material says nothing, the guidance is an answer slot: answer it from your own experience, or say plainly it was not yours.
- **Provenance labels:** `[grounded]` traces to your documents or to cited research; `[inferred]` is derived, with the derivation named; `[generic]` is a role-family pattern with no claim about Saltmarsh or about you.

## Prep triage (the time between now and Friday)

1. **C1, then C2 and C3, aloud, until the answers are boring.** C1 is the highest-ROI prep in the pack, because the gap you named is where the questions will concentrate.
2. **A1 and A2, aloud and timed.** The tabletop is half of the hour and the only part you cannot prepare from your CV. Practise the structure, not the answer.
3. **B3 and B4**, the two values questions your own sentences carry, then choose stories for B1 and B2.
4. **D1 and D4**, your two strongest sentences, at QA-level depth.
5. **E1**, a 90-second arc, and two reverse questions from section 11 (R1 and R3 first).

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, with nothing inspected behind it; the JD says live events across two titles. The words stay at the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: expect a probe on how one title's calendar extends to two. If any part of your calendar covered more than one title, or events as well as content drops, say so in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | low | [grounded] | discovery | The sentence says you never led a team; it does not say whether you worked with design, art, engineering or community, and the pack does not assume it. Words you can say: "I haven't led a team." Answer slot: the JD's "each update" makes a probe on who you worked with likely. If you worked with any of those four on a drop, say which and what you did, in your own words; if you did not, or it was not yours to do, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | The quote's verb is presented. Your material does not show who chose the measures or whether a review followed an event, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you also chose or counted those numbers, or reviewed what a release did, say what and how, in your own words; if not, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | The JD's verb is manage and the quote's is wrote, so the words stay at wrote: "I wrote the release checklist our QA team still uses." Answer slot: expect a probe on what is on it and who changes it. If you also ran releases against it, say how; if QA or someone else did, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | Both quotes reach the requirement in other terms. Say the title as you held it, associate producer, never producer. Words: "I spent four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for our main title." Nothing is added to it |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | Your strongest row. Lead with the quote's own terms: you ran it, weekly, for your main title, for two years. Expect a probe on what the calendar held, since a CV line has nothing inspected behind it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | The quote shows presenting them, not how they were defined or counted. Answer slot: expect a probe on how the numbers were counted. Say which retention measure it was, how it was counted and which part was yours (pulling, defining or presenting), in your own words; if you do not know how it was counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | discovery | One written artifact in use. Your material does not show other writing (player notes, review write-ups). Answer slot: if you wrote anything else others relied on, say what and for whom; if not, stay with the checklist |
| F9 | "moves Tidepool Tactics and Lantern Row to a season-pass model" — Saltmarsh news page, Project Larkspur | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [inferred] | capability | Your own sentence states the absence, so the words are: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The link is the pack's inference: the announcement says season-pass model and does not say how the pass is sold, so R4 asks. Never a claim to monetisation work, and nothing added to make the gap feel smaller |

**Requirement coverage**

| Requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, D1 |
| Coordinate design, art, engineering and community teams on each update | A1, C4 |
| Own the post-event review and the KPIs it reports | A3, D2, D3 |
| Manage the release checklist with QA | A5, B3, D4 |
| 3+ years producing live-service games or apps | C3, E1 |
| Experience running a content calendar | D1, A4 |
| Comfortable with player-retention metrics | D2, B4 |
| Clear written communication | A1, B2 |
| Season-pass model (from the announcement, not the JD) | C1, C2, A4 |

## Reading the interviewer

Public professional footprint only: Tobias Wrenfield is Head of Live Operations at Saltmarsh Games and was previously a QA lead at a console studio. His GDC 2026 talk is "Patch Notes Are a Promise", and its argument is that "a live team is judged by how often its patch notes describe what actually shipped." Only the search snippet was read, not the talk itself.

| Signal | Practical implication |
|---|---|
| Talk title and argument: patch notes as a promise | His lens is the gap between what was announced and what shipped. It matches the company value "Ship the Patch Not the Promise", so expect it in both halves of the hour (A2, A5, B2) |
| Previous role: QA lead | Questions on your checklist are likely to go to QA-level depth (D4). Where you do not know how QA used an item, say so plainly |
| He runs live operations | The tabletop will be scored on what you ask first and what you refuse to promise, not on a polished plan (A1, A2) |

**Mirror opportunity:** shared vocabulary, not a shared career jump. His path runs through QA; your side is F4, "Wrote the release checklist our QA team still uses." Speak about the checklist in plain QA terms, and do not claim a QA background.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | The Outage Hour tabletop: a simulated outage during a live event | High. The careers page says the interview is "a live-incident tabletop on a simulated outage during a live event, then a values conversation" | Clarify first, then objective, who you call, decision, player message, review. Think aloud and commit to a recommendation |
| B. Values/Behavioral | The second half of the same hour, against three published values | High. Same careers-page sentence, and the values page names three: Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener | One story from your own sentences where one carries it (B3, B4); a selection scaffold with an honest branch where none does (B1, B2) |
| C. Skeptic | Probing the in-app-purchase and team-lead gaps, in a quiet register | High. You named both gaps yourself (F2, F9), and the announcement moves both titles to a season-pass model | Rehearse C1 until it is boring: plain acknowledgment, then a ramp plan said as a plan |
| D. Data-Driven Prober | Line-by-line probing of the calendar, the checklist and the retention numbers | Medium. Your four sentences are your whole evidence base, and he is a former QA lead | Know what each sentence does and does not carry; say plainly what you do not know |
| E. Conversational | The opening: walk me through the journey, why Saltmarsh | Medium for E1, since most interviews open this way; the careers page does not describe the opening | A 90-second arc built only from your four sentences |
| Pressure | Time-boxed challenge on why you | Low as a style. It shows up inside C3 | Hold, then concede the specific gap; never fold the core |
| Peer | Seam-splitting between adjacent teams | Not expected: the careers page describes the interview as with the hiring manager | No bank |

## Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event went out at 10:00. By 10:20 players are posting that the reward isn't arriving, and your community lead wants to know what to say. What do you need to know first, and who do you call?" | CASE | [generic] | Think aloud in order. Clarify: how many players, which platforms, since when, what changed at release. Objective: stop the harm and tell players the truth. Who: engineering on call, QA, community, and whoever can pause the event. Then the decision, then the first player message, which says only what is confirmed, what you are doing and when the next update comes. Expect to be asked to draft that message aloud. The question asks about no past, so the guidance makes none | The tabletop is half the hour (see the persona table). CASE because it scores structure under time pressure; the player message also exercises F8's written-communication requirement |
| A2 | "Same outage. Engineering says the fix lands tomorrow morning, and the event ends tonight. Extend it, pause it, or let it run? Argue it." | CASE | [generic] | Commit to one recommendation and say what would change your mind. The criteria to say aloud: what players were told, what they lost, what the next slot on the calendar can absorb. Name the value in play in the company's own words: when the calendar and the players disagree, the players win. Say what you will not announce until it is built | A follow-up is the likeliest second beat of a tabletop. It scores whether you hold a decision under a changed fact; CASE with a values edge, tied to the company's first two published values |
| A3 | "The fix is out. What goes in the post-event review, and which KPIs does it report?" | CASE | [generic] | Structure: timeline, cause, player impact, what was told to players against what shipped, actions with owners. For KPIs, choose the few that match the event's objective and say why you chose them. The question asks about no past, so the guidance makes none | The JD's "own the post-event review and the KPIs it reports" has to be answered somewhere in a tabletop. F3 is where your own evidence is thinnest, so the live-problem form is safer and is the likely form |
| A4 | "From February 2027 both titles share one events calendar. How would you plan a month on it?" | CASE | [inferred] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first: what is shared, who owns which slot. Objective, then the players of each title as segments (do not assume they overlap), collisions and cadence, metrics per title and shared, and the risk that one title's incident disrupts a shared calendar. Challenge one premise politely: does shared mean the same events or the same cadence? If you use your own calendar as a reference, keep it at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." That is one title | Derived from the Project Larkspur announcement and the JD's two-titles line; the CO question this pack builds from research. CASE because it asks you to plan, not to recite. F1 is the evidence row and it covers one title |
| A5 | "QA tells you the build isn't ready the day before an event goes live. Design says it is already announced. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Say the position first: do not ship a promise the build cannot keep. Then who decides, what you can tell players, and what the checklist says about the missing item. Your side of it is the checklist, at its scope: "I wrote the release checklist our QA team still uses." Answer slot: the JD's checklist line makes a probe on a release held against it likely. If one was, say what happened and which part was yours; if none was, or it was not your call, say so plainly and describe how you would use it | Scores the JD's "manage the release checklist with QA" (F4) inside a live decision, and the value Ship the Patch Not the Promise; CASE because the problem is live |

### B. Values/Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. Pick a time a scheduled drop met a signal from players. It needs a named stake, what you decided, and whether the calendar moved. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I ran the weekly content-drop calendar for our main title for the last two years.", or say how you would handle it | The value Players Before Plans, from the values page. No sentence of yours carries a story for it, so this is a scaffold; F6 is the nearest row |
| B2 | "Tell me about a time you chose not to announce something because it wasn't built yet." | VAL | [grounded] | Selection scaffold. Pick a time an announcement or a date was ready before the work was. It needs the pressure to announce, what you said instead, and what happened. If no such time comes to mind, say so plainly, then say how you would handle it. Use the value's own words only as the company's, not as yours | The value Ship the Patch Not the Promise, and the theme of the interviewer's talk. A scaffold because none of your sentences carries a story here |
| B3 | "Tell me about a release that left the checklist better than it found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4, with only the beats the sentence states: you wrote it, and QA still uses it. Answer slot: the value says every release leaves the checklist better, so expect a probe on whether it changed after a release. If it did, say what changed, what prompted it and which part was yours; if it did not, or someone else made the changes, say so plainly and stay with the checklist you wrote | The value Leave the Build Greener, and the one value your own sentence reaches |
| B4 | "Tell me about a time you delivered numbers leadership did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F3 at the sentence's scope: you presented the monthly retention numbers to the studio head. Answer slot: if a month's numbers were unwelcome, say what they showed, what you said and how it landed; if none were, say so plainly and stay with presenting them. Choose a story where the hard truth actually landed | A standard values stem pointed at the strongest numbers-facing sentence you have; EXP content with VAL scoring |

### C. Skeptic (weight 4) — the highest-ROI prep is C1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Both titles move to a season-pass model in February 2027, and you've told us you haven't worked on a game with in-app purchases. How would you get up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment first: "I haven't worked on a game with in-app purchases." Say it once, flatly, with no apology and no hedge. Then the ramp as a plan, never as a past: who you would learn the purchase side from, what you would ask to see first, which numbers you would ask to be shown. Do not claim retention work as monetisation work; say your reporting experience is retention, as F3 states it. Hold this through two follow-ups by returning to the plan | F9 is the biggest gap and the most predictable objection, because the announcement moves both titles to a season pass. JD because it scores whether you can do the role as it will be |
| C2 | "What would you most likely get wrong in your first month coming from a game without purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The weakest-assumption move: name, in your own words, the area you expect to be weakest at first, before he does. Answer slot: if you already know which part of the purchase side is least familiar, say which; if you do not, say so plainly and say how you would find out. Do not name a mistake as if you had made it | The follow-up that converts a gotcha into a credibility gain; deepest rehearsal means a second and third level on the same objection |
| C3 | "Sixty seconds: why you over someone who has already run purchase-driven events?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Hold, then concede. Hold with the four sentences at their own scope: four years as an associate producer; the weekly content-drop calendar for your main title for two years; the release checklist QA still uses; the monthly retention numbers presented to the studio head. Concede the gap specifically: "I haven't worked on a game with in-app purchases." Stay on the sentences through two follow-ups, and do not add to them to win the exchange | Pressure style inside a Skeptic bank; time-boxed to test composure. Rows F5 to F7 are the evidence held, F9 the gap conceded |
| C4 | "You've never led a team. This role coordinates design, art, engineering and community on every update. How would you get four disciplines to move on your calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment: "I haven't led a team." Then the JD's word is coordinate, and your material does not say you coordinated those four, so the plan is a plan: agree dates and the checklist with each discipline, and settle who decides when they conflict. Answer slot: if you worked with any of the four on a drop, say which and what you did; if not, or it was not yours, say so plainly and stay with the calendar you ran: "I ran the weekly content-drop calendar for our main title for the last two years." | F2's gap, in the Skeptic's register. JD because coordination is the role's second duty |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F6 with only its beats: weekly, content drops, your main title, the last two years, told in your own words. Answer slot: the JD's "plan and run" makes a probe on who set the dates and what happened when one moved likely. If the dates were yours to set, say how you decided; if a drop ever moved, say what happened and which part was yours; if neither, or it was not your call, say so plainly and stay with how you ran the weekly calendar | Your strongest row and the likeliest opener of the hour's second half; EXP because it tests what was actually yours |
| D2 | "Which retention numbers did you present, and where did they come from?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The defend-the-number slots, in your own words. Which retention measure it was, how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours: pulling, defining or presenting. If you do not know how it was counted, say so plainly. Never describe a method you did not use | F7 and F3: retention is the one metric the JD names, and your sentence says presented. EXP, with the weakest-assumption move |
| D3 | "What did review after a drop look like on your title?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: the JD's "post-event review" raises it. If there was a review after drops, say who ran it, what it looked at and which part was yours; if there was none, or it was someone else's, say so plainly and stay with the sentence: you presented the monthly retention numbers to the studio head | F3's thin spot, rehearsed so the honest answer is ready; the premise is the JD's and the guidance does not adopt it |
| D4 | "What's on the release checklist you wrote, and how does QA use it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Beats from F4: you wrote it, QA still uses it. Answer slot: say in your own words what is on it and why; if items came from QA or engineering, say so; if you do not know how QA uses an item, say so plainly. The interviewer's public background is QA, so expect depth | F4 under a QA-trained interviewer's eye (see the interviewer read). EXP because the claim is a written artifact |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in this order: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for your main title, two years; the release checklist QA still uses; the retention numbers presented to the studio head. Each at its own scope, in your own words. End on why live operations, in your own reason, not one the pack supplies | The opener is scored even when it feels casual. F5 is the row; EXP because it is your own story told once |
| E2 | "Why Saltmarsh, and why now?" | CO | [grounded] | Your reason is yours to give; the pack does not supply one. What you can say accurately about the company: its three published values by name, and that Project Larkspur moves both titles to a shared events calendar from February 2027. Mention the interviewer's talk only if you have read it | Motivation consistency; CO because it tests homework. The facts are from the values page and the announcement in Sources |

## Values cheat sheet

| Value (official name) | Working meaning, paraphrased | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players pull apart, the players decide | Selection scaffold, B1: pick a time a scheduled drop met a signal from players, with a named stake and what you decided; if none comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold, B2: pick a time an announcement was ready before the work was; if none comes to mind, say so plainly, then say how you would handle it |
| Leave the Build Greener | Each release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Beats: you wrote it, QA still uses it. B3 holds the answer slot on whether it changed after a release |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved into live operations from QA. What did QA teach you about running live events that you wish every producer started with?" | Tied to his public path as a former QA lead; it turns an interrogation into a conversation, and your side of that shared vocabulary is the checklist |
| R2 | "Your GDC talk argues a live team is judged by how often its patch notes describe what actually shipped. How does the team measure that today?" | Shows you have researched him, and ties to Ship the Patch Not the Promise. Ask it only if you have read the talk or its summary |
| R3 | "The JD says 'two of our mobile titles', and Project Larkspur retires per-title event teams in favour of a single live-ops group. Where does this role sit in that structure?" | The JD and the announcement describe different shapes; asking shows you read both, and the answer tells you what you would actually be running |
| R4 | "How is the season pass sold and measured, and who would walk me through that side in my first weeks?" | The announcement does not say how the pass is sold. It also turns F9 into a ramp question without claiming anything |
| R5 | "What separates a post-event review you are glad you did from one that just got filed?" | Tests the JD's "own the post-event review and the KPIs it reports" from the owner's side |
| R6 | "How do QA and live operations share the release checklist today, and what would you want to change first?" | Shows you think about the checklist as a shared artifact, F4's territory |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Planned and ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for one main title. A1 to A4 and D1 stay inside it |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: "Presented the monthly retention numbers to the studio head." D3's slot stays inside what you presented |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope: "Wrote the release checklist our QA team still uses." The JD's verb is manage; the quote's is wrote |
| Led a team | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I haven't led a team." No slot |
| Worked on a game with in-app purchases | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |

## Sources

**Provided documents:** the job description text and your background message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Query or fetch | Returned |
|---|---|
| Search: `Saltmarsh Games values` | https://saltmarshgames.com/values |
| Search: `Saltmarsh Games interview process live operations producer` | https://saltmarshgames.com/careers/interviewing |
| Search: `Saltmarsh Games strategy news mobile` | https://saltmarshgames.com/news/project-larkspur (search snippet only, page not fetched) |
| Search: `Tobias Wrenfield Saltmarsh Games` | https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only, page not fetched) |
| Fetch: values page | Read in full |
| Fetch: careers interviewing page | Read in full |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, the three values by name; B1 to B4 |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: one 60-minute session, tabletop then values conversation; persona weights, the A and B banks |
| 3. `Saltmarsh Games strategy` / recent news | yes | A4, C1, E2, R3, and F9; the announcement is dated September 2026 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, R1, R2 and D4's depth note; the talk page was not read, so only its snippet is used |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Recruiter's prep email** → whether the Outage Hour scenario or its format is shared in advance, and confirmation that Tobias is the hiring manager; this would reweight the A and B banks
- **A deeper research pass (L2)** → a strategy brief, more of the interviewer's talks and writing, and loop reports for this role family; up to 6 more searches and 2 more fetches, several more minutes, run only if you say so. It would replace the single announcement the A4 and E2 questions now rest on
- **Your answers to the answer slots** (F1, F2, F3, F4, F7, F8) → each row you answer upgrades from `discovery` or `transferability` to a quoted story, and the matching bank questions become story-mapped
- **A sample of the release checklist or a calendar page, with names removed** → raises F4, F6 and F8 from `medium` or `low`, the artifact a producer's work is judged on
- **A tuesday-dossier.md from job-underwriter** → verified evidence and an evidence-derived top objection in place of the one inferred here
