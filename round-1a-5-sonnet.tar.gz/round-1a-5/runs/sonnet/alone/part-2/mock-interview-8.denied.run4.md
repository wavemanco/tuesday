I'll read the reference files the skill points to before building the pack.
Dara, your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-8-denied-e92d3b6b/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it in loop mode, one section per round, on the three rounds the recruiter listed for 4 December. It has 29 questions in all: 8 for the recruiter, 11 for the Head of Member Services and 10 for the panel. The panel section includes a four-values cheat sheet and rehearsal for the 20-minute case.

I ran no web research. Your pasted values, the recruiter's email and your four strategy points already covered every research target, so there are no outside facts in the pack. No interviewer has been named, so there is no interviewer read.

The question I'd rehearse hardest is B4, where a manager points out that you've never worked in a contact centre. You said so yourself, and the JD puts the contact centre in your remit. The pack gives you the concession wording and three follow-up levels to hold through.

Where your message doesn't show something, the pack gives you an answer slot instead of an answer. The slots cover whether your complaints log was kept under outside rules, what your spreadsheet counted and what tool it was in, whether you've coached anyone beyond new tellers, and any digital work. Fill them from your own experience, or say plainly it wasn't yours.

Say the word and I'll run a live drill as the Skeptic on B4.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Date of interviews:** 4 December 2026, three rounds in one day. **Mode:** loop (three scheduled rounds), built on the recruiter's email.

| Round | Who | Length | Shape, per the recruiter's email |
|---|---|---|---|
| 1 | The recruiter | 30 min | Screen |
| 2 | Head of Member Services, who would be your manager | 45 min | Mostly behavioural |
| 3 | Panel of two branch managers | 60 min | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewers beyond their roles have not been assigned, so there is no interviewer read in this pack.

## How to use this pack

- **Personas describe how a question arrives; types describe what it scores.** Rehearse both.
- **Type key:** VAL = behavioural and values alignment. EXP = work-experience deep-dive. JD = a requirement the job description states. CO = company and strategy knowledge. CASE = a live problem set in the role.
- **Guidance is scaffolding, not a script.** Every claim about your past comes from a sentence you wrote, quoted next to the answer. Where the pack cannot know something, the guidance is an **answer slot**: say what is true in your own words, and where the practice was not yours, say so plainly. The honest branch is a limit, not a confession.
- IDs run by persona: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Data-Driven Prober, F Peer Evaluator, G Pressure.

## Prep triage (nine days from 25 November to 4 December)

1. **Now to 28 November: B4, then B1, B3, B5 and G1.** They rest on the same two facts. Say B4 aloud until the concession and the hold take under 90 seconds. It is the highest-ROI prep in this pack.
2. **29 November to 2 December: the 20-minute case.** Run D4 and D5 against a timer, thinking aloud. Then D1, D2 and D6 once each.
3. **29 November to 2 December: the four values.** Settle C3 to C6: one real instance each, or the honest branch.
4. **3 December: logistics and the spreadsheet.** Settle your own answers to A3 to A6, since you give them to three people on the same day. Be ready to talk through E1 and E2.

Everything else in this pack is insurance.

## The fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on length: the quote states six years against the JD's four. It is a line from your message with nothing inspected behind it, so expect a probe. Lead in the quote's own terms, "I've spent six years in retail banking, the last three as a branch supervisor", and leave the JD's category name to the interviewer |
| F2 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log and training on an escalation script, not the process across branches, and the words stay there: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: the JD's end-to-end line makes a probe on parts of the process beyond the log likely. If any part was yours to set, say which and how you decided, in your own words; if none was, or it was not yours, say so plainly and stay with the log and the script |
| F3 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller. Rehearsal: B1, B4 |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | The quote says a formal log; it does not show whether rules from outside the branch governed it, so the pack does not call it regulated. Answer slot: the JD's line on regulated complaints makes a probe on this likely. If rules from outside the branch governed the log, say which, in your own words, and what part of keeping to them was yours; if the log was an internal record only, or none of that was yours, say so plainly and stay with the log |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote says you built a monthly complaints spreadsheet your regional manager uses; it does not show what the spreadsheet counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours held. If it counted anything, say what and how, in your own words; if it counted nothing, or the figures were not yours, say plainly what it did hold |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers, not supervisors, and the words stay at that scope: "I trained new tellers on our escalation script." Answer slot: if you took anyone besides new tellers through the script, say who and what you did; if you did not, or it was not yours to do, say so plainly and stay with the tellers |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here, so this is discovery and not a gap you have stated. Answer slot: if any of your work touched a digital channel or a self-service step, say what and what part was yours, in your own words; if none did, say so plainly and say how you would start working with that team |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A limit you have stated. Words: "I haven't presented to anyone above regional level." Then a plan for how you would prepare, said as a plan and never as a past. Your material does not show whether you have presented at regional level; B5 holds a slot for it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The quote says spreadsheet and names no tool, so the pack does not say Excel for you. Answer slot: the JD names Excel, so expect a direct probe. Say what the spreadsheet was made in, in your own words; if the tool differs from the one the interviewer names, say so plainly and say how you would get to the same footing, as a plan |

## Grounding brief (from the strategy points you gave, July 2026 brief)

| Strategy point, as you gave it | Provenance | Where it can surface |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] | D2, D3; the JD's digital-teams line (F7) |
| Consolidate eight branches into five hubs over 2027 | [grounded] | D1 and reverse questions. The published value "Neighbours, Not Numbers" sits beside this point, and the pairing is worth being ready for in round 3. Your material does not say whether either panelist's branch is affected |
| Launch a small-business lending product in Q1 2027 | [grounded] | Only as awareness in A2. Nothing in the JD links it to complaints, though a new product plausibly brings new kinds of complaint |
| Main competitive pressure is app-only banks | [grounded] | D6, A2 |

I hold your four points, not the brief itself.

---

# Round 1: the recruiter (30 minutes)

### Persona table, round 1

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Conversational | Friendly, unstructured; logistics asked casually | High: a recruiter screen's prior is conversational plus light skeptic, and pay, notice, location and reason for change are the standard logistics | Pre-script the 90-second arc (A1); treat every casual question as scored; decide A3 to A6 in advance |
| B Skeptic (light) | Knockout checks in a friendly register | Medium: the JD names the contact centre and your message states you have not worked in one (F3), so a yes/no check is likely | Say the sourced concession in one breath and move on (B1) |

### Question bank, round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in your own words, built only from these three sentences: six years in retail banking, the last three as a branch supervisor; the formal complaints log and the escalation-script training; the monthly complaints spreadsheet. Close on why this role, which is yours to say; the pack supplies no reason. Stop there and let the recruiter pick the thread | F1, F2 and F5 are the beats. A recruiter's opening question is scored for economy, so the arc is rehearsed. EXP because it tests the story your own sentences tell |
| A2 | "What interests you about Ashgrove?" | CO | [grounded] | Pick one thing and say why it matters to you, in your own words: the published value "Members First, Always", or one move from the July brief (40% digital by 2028, eight branches into five hubs over 2027, the small-business lending launch, pressure from app-only banks). Link it to your own work only where your sentences carry it (F2, F5); if none connects, say what in the role draws you and stop | The values and the strategy points are in the material you gave, and a recruiter listens for an answer about this employer. CO because it tests homework depth; the reason itself is left to you |
| A3 | "What's led you to look at a change?" | EXP | [generic] | A logistics slot: give your own reason in your own words, in a sentence or two, about what draws you to this role. The pack supplies no reason. Keep it identical across all three conversations on the day, because a reason that shifts is the risk when you meet three people | The reason for a change is on every screen's logistics list. EXP because it checks motivation against the story told in A1 |
| A4 | "What are you looking for salary-wise?" | JD | [generic] | A logistics slot: either give your own number, in your own words, or ask for the role's band first and respond to it. If asked what you earn now, a prepared line: "I'd rather focus on the range for this role." Give no figure for current pay | Pay is a standard recruiter-screen item. JD because it concerns the listed job's terms, and the JD you pasted states none |
| A5 | "What's your notice period?" | JD | [generic] | A logistics slot: give your actual notice period as it stands, in your own words. The pack supplies no figure | Standard logistics; JD because it concerns the job's terms |
| A6 | "Is the location of the role workable for you?" | JD | [generic] | A logistics slot: give your own answer, plainly. The JD says "across branches", so expect a follow-up on moving between sites; say what is true for you rather than what you think suits | The JD you pasted names no site or schedule, so the recruiter's version is the one to rehearse. JD because it concerns the job's terms |
| B1 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The sourced acknowledgment, in one breath: "I haven't worked in a contact centre." Then, unprompted, the second sentence at its own scope. Then one sentence of plan: what you would learn first, in your own words. Stop; the full rehearsal is B4 | A knockout check in a friendly register; F3 is the requirement it screens. JD because it scores a stated requirement, and the yes/no form is why the answer is short |
| B2 | "Tell me about the formal complaints log you handled." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F2: the log, and the escalation-script training, which are the beats the sentence states; tell them in your own words. Answer slot: the JD's line on regulated complaints makes a probe on the rules the log was kept under likely. If rules from outside the branch governed it, say which and what part was yours; if it was an internal record only, or those rules were not yours, say so plainly and describe how you handled the log | F4 is the row a recruiter listens for in a first screen, and F2 is the quote it stands on. EXP because it tests what was actually yours |

### Reverse questions, round 1

| Question | Why it lands |
|---|---|
| "Who are the two branch managers on the panel, and which branches are they from?" | Your note says interviewers beyond their roles are not assigned; names would let the round 3 bank be reweighted |
| "What should I expect from the 20-minute case: will there be materials beforehand?" | The recruiter's email names the case; the answer decides how much structure to rehearse cold (D4, D5) |
| "How does the contact centre sit alongside branches in this role's week?" | F3 is where your material is thinnest; the answer shows how much weight the gap carries and costs the recruiter nothing to share |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

### Persona table, round 2

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | Open "tell me about a time" prompts on escalation and coaching | High: the recruiter calls the round mostly behavioural | Tell what you did in your own words; where no quote carries a story, use the honest branch (C1, C2) |
| B Skeptic | Quiet probing of the two stated absences | High: a hiring-manager round buys capability and derisks gaps, and F3 and F8 are stated absences | Rehearse B4 until it is boring; concede the fact, hold what the quotes carry, plan in the future tense |
| D Case/Strategist | Strategy-flavoured live problems | Medium: a hiring manager's prior, but the recruiter places the dedicated case in round 3 | Clarify, objective, segmentation, approach, metrics, risks; think aloud (D1, D2, E3) |
| E Data-Driven Prober | Line-by-line questions on the spreadsheet | Medium: the JD asks for monthly reporting and you built one; no interviewer signals exist to push it higher | Know what the spreadsheet held and say plainly what you do not know (E1, E2) |

### Question bank, round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name your own two limits first, before they do, in the quote's terms: "I haven't worked in a contact centre" and "I haven't presented to anyone above regional level." Say which matters more to you, then stop and let B4 and B5 carry the depth. Add no third weakness you have not stated | F3 and F8 are the two rows you stated as absent, so an open question lands on them. JD because it scores the stated requirements; Skeptic delivery |
| B4 | "I don't see contact-centre work in your background — how would you own complaints that run through it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **Highest-ROI rehearsal in this pack.** Level 1: concede the fact in one breath, "I haven't worked in a contact centre", then hold on what the second sentence carries, at its own scope. Level 2, pushed on the plan: say in your own words what you would do first and whom you would ask; it is a plan, not a past. Level 3, pushed on the risk: return to those two sentences and widen neither. Answer slot: if you have picked up an unfamiliar process in a new setting before, say which and what part was yours; if no such time comes to mind, say so plainly and stay with the plan. Hold through all three levels; the concession is the fact, never the plan | F3 is the largest gap against the JD's contact-centre wording and the likeliest probe in every round, so it gets the most follow-up levels and the exact concession wording. JD because it scores a stated requirement, delivered as a Skeptic's quiet probe |
| B5 | "How do you feel about presenting to senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The sourced acknowledgment: "I haven't presented to anyone above regional level." Then a plan in your own words: how you would prepare your first report for leaders. Answer slot: if you have presented at regional level, say to whom and what, in your own words; if you have not, say so plainly. Never describe an audience you did not present to | F8 is a stated limit, and the JD's presenting line makes this likely in a manager round. JD because it scores a stated requirement |
| C1 | "Tell me about a time a complaint went beyond what the first person could resolve." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt, so choose the instance. Pick one you can tell start to finish: what you saw, what you did, how it ended, in your own words; the pack supplies no instance. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the log and the script), or how you would handle it | The JD and the recruiter's email both put escalation at the centre. F2 is the only quote near it. EXP because it tests what was actually yours |
| C2 | "Tell me about a time you helped a colleague get better at something." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F6: training new tellers on the escalation script is the beat the sentence states. Answer slot: if you took anyone besides new tellers through the script, say who and what you did; if you did not, say so plainly and stay with the tellers. Tell what you did in your own words; the pack supplies no outcome | The JD's coaching line is the probe, and F6 is the only quote near it. EXP because the open prompt asks you to choose and own an instance |
| E1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F5: you built it, it is monthly, it is about complaints, and your regional manager uses it. Answer slot: if it counted anything, say what was counted and how, and which part was yours; if it counted nothing, or part of it was not yours, say so plainly and say what it did hold. Describe no column or figure you cannot reproduce on the spot | F5 is the evidence for the JD's reporting line and the thing a manager can ask about for 10 minutes. EXP because it tests whether the claim survives scrutiny |
| E2 | "How comfortable are you in Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot on F9: say what the spreadsheet was made in, in your own words, and what you did in it at the scope of the sentence. If the tool differs from the one the interviewer names, say so plainly and say how you would get to the same footing, as a plan | F9 is a requirement the quote touches without naming the tool, so the direct question is likely. JD because it scores a stated requirement |
| E3 | "How would you define resolution time on a monthly report?" | CASE | [generic] | Think aloud. Ask what clock the organisation already uses. Then state your own choices: when it starts (the first contact or the formal log), when it stops (the fix, or the member's acceptance), working or calendar days, and what happens to a reopened case. Say you would agree the definition with the person who owns the report before the first one goes out. No claim about your past is needed | The JD's reporting line (F5's requirement) as a live problem; it lets you show reporting judgement without a past claim. CASE delivery, JD content |
| D1 | "Ashgrove is consolidating eight branches into five hubs over 2027. How should complaints handling change?" | CASE | [grounded] | Clarify first: what the hubs will and will not handle. Objective: a member's complaint still has one named owner ("Own the Fix"). Segment by where the member raises it and by complexity. Approach, metrics (volumes and resolution times, as the JD names them), then risks, including a town that loses its counter ("Neighbours, Not Numbers"). Challenge one premise respectfully; think aloud | A CO question grounded in the July strategy brief. CASE because it is a live problem on the manager's likely roadmap |
| D2 | "The strategy moves 40% of member service to digital by 2028. Which complaints should move to self-service, and which should not?" | CASE | [grounded] | Clarify what counts as service moving. Segment complaints by type and by the member's circumstances. State your criteria for what stays with a person (a member needing it explained twice is the published test for "Plain Words"). Say who you would agree it with: the digital teams. Name how you would tell it is working. No claim about your past is needed | The 40% target is in the brief and the JD names digital teams (F7's requirement). CASE with CO content |
| D3 | "Tell me about a time you worked with a digital or product team." | JD | [grounded] | Open prompt on F7, where your material is silent. Selection scaffold: pick an occasion your work met a digital channel or a self-service step; it needs what you asked of the team and what changed for members. Answer slot: if any of your work touched one, say what and what part was yours; if none did, say so plainly, then give the nearest thing your material does carry, or how you would start working with that team | The JD's digital line is the only source, and silence is discovery, so the honest form is a slot. JD because it scores a stated requirement |

### Reverse questions, round 2

| Question | Why it lands |
|---|---|
| "As eight branches consolidate into five hubs over 2027, where do you want complaints owned: in the hubs, or in this role?" | It is drawn from the brief and asks about the shape of the job you would hold |
| "What would a good first monthly report look like to you, and who reads it?" | It ties to the JD's reporting line and lets the answer tell you what the report is for |
| "Which part of the contact centre's complaint handling would you want me to learn first?" | It meets F3 head-on with a plan-ready question instead of waiting to be asked |
| "How will you judge, at six months, whether the move to digital is working for complaints?" | It ties to the 40% target and shows you are thinking about how success is measured |

---

# Round 3: panel of two branch managers (60 minutes, including a 20-minute case; also the values round)

### Persona table, round 3

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | Scenario prompts mapped to the four published values | High: the recruiter says the panel scores against the four values | One story or honest branch per value (C3 to C6); see the cheat sheet below |
| D Case/Strategist | The 20-minute escalation case, plus strategy prompts | High: the recruiter's email names the case | Clarify, objective, owner, next hour, next week; think aloud; ask rather than assume where the contact centre's process is unknown to you (D4, D5, D6) |
| F Peer Evaluator | Seam questions: where this job ends and a branch manager's begins | Medium, [inferred]: the panelists are branch managers whose supervisors the role would coach; the email does not say how they will question | Offer seam principles, not a boundary; ask where they feel the seam is (F1, F2) |
| G Pressure | A time-boxed challenge | Low: no signal in the email; one rehearsal for composure | Pause, restate, hold two follow-ups (G1) |

### Question bank, round 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C3 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt, so choose the instance. Selection scaffold: pick a time what was easiest for the branch and what was right for the member pulled apart; it needs a named situation, the choice you made, and what it cost. The sentence above does not tell a member-side story by itself; if the log or the training holds one, tell it in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first of the four published values, "Members First, Always". F2 is the nearest quote. VAL because it scores behaviour against the published value |
| C4 | "Tell me about a time something had to be explained twice, and what you changed." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. Selection scaffold: pick a time an explanation, letter or script did not land first time; it needs what was unclear, who noticed, and what you changed. Answer slot: if the escalation-script training involved rewording anything, say what and what part was yours; if it did not, or the script was not yours to change, say so plainly and stay with the tellers' training as the sentence states it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries | The published value "Plain Words". F6 is the nearest quote. VAL because it scores behaviour against the value |
| C5 | "Tell me about a time you put a particular branch or town ahead of a standard approach." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. Selection scaffold: pick a decision where one place's needs differed from the standard approach; it needs the place, what was different, and what you did. The sentence names one branch's log and does not show a local decision. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The published value "Neighbours, Not Numbers", sitting beside the hub plan in the grounding brief. F2 is the nearest quote. VAL |
| C6 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot on F2: if you carried any complaint from first report to fix, say which and which steps were yours; if the log was a record you kept while others fixed things, or you passed it on once logged, say so plainly and describe what you did with it. Scaffold if none: a named problem, what you did, how you knew it was solved; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The published value "Own the Fix". The sentence says handled the log, which does not show whether it covered the fix. VAL |
| D4 | "A member's complaint has gone between a branch and the contact centre three times without a fix. Walk us through your next hour and your next week." | CASE | [generic] | The 20-minute case. Think aloud. Clarify first: what the member asked for, what they were told, what is in writing, whether a formal complaint is open and what deadlines apply. Objective: the member's outcome. Owner: you hold it until it is solved ("Own the Fix"). Next hour: contact the member in plain words, gather both sides' notes, name one owner. Next week: the fix, the check, the cause, what you tell supervisors, how it enters the monthly report. Where the contact centre's process is unknown to you, say what you would ask, not what you assume | The recruiter's email names a case on a complaint escalation, and the JD puts branches and the contact centre in your remit. No claim about your past is needed. CASE |
| D5 | "Now the branch supervisor says the contact centre never passed on the notes, and the contact centre says the branch never asked. Whose fix is it?" | CASE | [generic] | The published value says whoever finds the problem keeps hold of it until it is solved, so say it is yours until it is handed over with agreement. Then principles, not blame: one named owner on every case, the notes travel with the case, and what you would ask both sides. Hold your position through a challenge, and concede only what you do not know | A twist is how a case panel tests whether the structure survives pressure. CASE |
| D6 | "Members could move to an app-only bank. What does complaints handling have to do to keep them?" | CO | [grounded] | Think aloud, structure first: what members compare, what a person adds that an app does not, where digital should do the work (the 40% target). Tie it to "Members First, Always" and "Neighbours, Not Numbers" by name. State no facts about any app-only bank; none are in your material | App-only banks are the brief's named competitive pressure. CO with CASE delivery |
| F1 | "A supervisor from my branch handles an escalation badly. How would you coach them without going around me?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Method first: agree with the branch manager what good looks like; go through the case with the supervisor; agree what you report back and to whom. If asked for a past instance, the quote above is the only coaching-adjacent sentence, so use the F6 slot and stay at its scope. Do not claim to have coached supervisors | The JD's coaching line seen from the branch manager's chair, where a branch manager would feel it. CASE delivery, JD content |
| F2 | "Our teams sit side by side. Where's the seam between your job and a branch manager's, and what happens when we disagree?" | CASE | [generic] | Ask the panel where they feel the seam is today before proposing one. Then offer principles, not a boundary: one owner named per complaint at the time, decisions made by whoever is closest to the member, escalation by agreement. Say what you would want to hear first when you disagree | A peer evaluator's seam stem. Reciprocity framing, and no claim about your past is needed |
| G1 | "Sixty seconds: why you over someone who has run a contact-centre complaints team?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause, restate the question in a clause, concede the fact, "I haven't worked in a contact centre", then hold on the second sentence at its own scope. Widen neither. Hold through two follow-ups | One rehearsal of composure on the same facts as B4. JD because it scores the stated requirement |

### Values cheat sheet (round 3)

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | Nearest: F2, "I handled the branch's formal complaints log and trained new tellers on our escalation script." It does not carry a member-side decision by itself. Selection scaffold in C3, ending in its honest branch |
| Plain Words | Judge your own wording by whether a member understood it first time | Nearest: F6, the same sentence, at the tellers' scope. Answer slot in C4, ending in its honest branch |
| Neighbours, Not Numbers | Treat each branch as part of its own town | Nearest: F2, the same sentence, which names one branch's log only. Selection scaffold in C5, ending in its honest branch |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Nearest: F2, the same sentence. Answer slot in C6, ending in its honest branch |

### Reverse questions, round 3

| Question | Why it lands |
|---|---|
| "What would make you feel a complaint was well handled from your branch's side?" | It asks the panel for their definition and fits "Members First, Always" |
| "When an escalation from your branch goes wrong, what usually happens next?" | It draws out the seam F1 and F2 rehearse, in their words |
| "How do you expect the move from eight branches to five hubs to change what your supervisors need from this role?" | It ties to "Neighbours, Not Numbers" and the brief. Ask it with care: your material does not say whether either panelist's branch is affected |
| "What could a new person in this role do in their first month that would genuinely help your supervisors?" | A reciprocity question for peers; it turns the panel from judges into collaborators |

---

## Requirement coverage

| JD requirement | Fit row | Questions |
|---|---|---|
| 4+ years in financial-services customer operations | F1 | A1 |
| Own the member complaints process end to end across branches | F2 | B2, C1, C6, D4, D5, F1 |
| ...and the contact centre | F3 | B1, B3, B4, D4, D5, G1 |
| Experience handling regulated complaints | F4 | B2, C1 |
| Report monthly on complaint volumes and resolution times | F5 | E1, E3 |
| Coach branch supervisors on escalations | F6 | C2, F1 |
| Work with digital teams on self-service journeys | F7 | D2, D3, D6 |
| Confident presenting to senior leaders | F8 | B3, B5 |
| Comfortable with Excel reporting | F9 | E1, E2 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log and the script, not the process across branches |
| Has contact-centre experience | Negative you stated, F3 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope. The material says a formal log, not what governed it |
| Reported complaint volumes and resolution times each month | Inflated form of F5 | F5's quote at its own scope: you built the monthly complaints spreadsheet your regional manager uses |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: the tellers |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." |
| Built Excel reporting | Inflated form of F9 | F9's quote at its own scope: a spreadsheet, tool not named |

## Sources

**Provided documents:** the job description you pasted; the four values you copied on 25 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the process; four points from the July 2026 strategy brief (the brief itself was not supplied); your background in your message. No dossier was present.

**Searches and fetches sent:** none. The page named as the values source was not fetched, since its content is already in hand.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values fix the four official names and their meanings: the cheat sheet and C3 to C6 |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email establishes three sessions and who runs each: persona weights and the round split |
| 3. `Ashgrove Credit Union strategy` | skipped | The four July 2026 points fix the CO and CASE rows: A2, D1, D2, D6 and the grounding brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer has been named, so there is no query; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Your CV** → the fit rows would quote it as well as your message, and F1, F2, F5 and F6 could move toward `high` if it carries more
- **Your answers to the answer slots** (F2, F4, F5, F6, F7, F9) → those rows become stories in your own words, and B2, C1, C2, D3, E1 and E2 turn from slots into story maps
- **A redacted copy of the monthly complaints spreadsheet, or a log extract with all member details removed** (only if your employer allows you to keep one) → F5 and F9 could move to `high`, since it is the inspectable proof for this field
- **The names and titles of the Head of Member Services and the two branch managers** → an interviewer read, reweighted personas and tailored reverse questions
- **The full July 2026 strategy brief** → a fuller grounding brief and sharper D1, D2, D6 and reverse questions
- **The recruiter's answer on how the 20-minute case runs** (usually one email; see round 1 reverse questions) → D4 and D5 reshaped to the real format
- **Deeper research** (up to 6 more searches and 2 more fetches, several more minutes) → role-family loop reports, recent organisation context, and a public footprint for each interviewer once names exist; say if you want it
- **A tuesday-dossier.md from job-underwriter**, if you have one → verified evidence and prohibited claims in place of the ones built here
