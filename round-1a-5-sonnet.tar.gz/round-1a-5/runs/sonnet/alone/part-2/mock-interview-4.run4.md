I'll read the skill's reference files first.
I've saved the pack and I'm making one wording fix before I hand it over.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-4-denied-e9f0de78/quartzline_product-manager-platform-apis_interview_pack.md`. It has 21 questions, built for a hiring-manager round and weighted toward the Skeptic and Case/Strategist styles.

- **Highest-ROI prep:** A1 is the objection your dossier named: you have never held the PM title or owned a roadmap, so why you over a PM with three years of the actual job. The coaching is to concede both plainly first, then hold only what your three quoted evidence lines say, and offer a ramp plan. F1 is the same objection time-boxed to sixty seconds.
- **What the pack won't coach:** your three prohibited claims are never asserted. They are held title, owned roadmap, and set squad prioritization. The roadmap-ownership gap is an acknowledgment plus a plan, with no bridge.
- **Research:** my three web searches on Quartzline's values, interview process and strategy were refused, so the pack states no Quartzline facts. The "why Quartzline" question (B5) is generic, and there is no values section. Pasting Quartzline's values page or a strategy brief would fix that.
- **My own grading:** your dossier doesn't grade R2 to R4, so I graded those three rows myself and marked them as inferred.
- **Reverse questions:** the pack's first two are your dossier's employer questions on decision authority versus the squad leads, and on how adoption is measured.

I can run a live drill as the hiring manager on A1, with follow-ups that react to what you actually say. I can also save a `tuesday-dossier.md` update that records the gaps this prep exposed. Say so if you'd like the pack as a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack — Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. Interviewer name not given. Built from your dossier plus what you told me; the web searches I tried were refused, so nothing here asserts a fact about Quartzline (see Sources).

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for your own words, not a script. Every clause about your past rests on a sentence quoted in the row's Provenance cell. An "answer slot" is an instruction for the interview, not a question for me: answer whichever branch is true, and the honest branch is never a confession.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny and attribution |
| JD | The stated responsibilities and requirements, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role |

Labels: `[grounded]` traces to a document you provided, `[inferred]` is this pack's derivation (named), `[generic]` is a role-family pattern with no claim about you or Quartzline.

**Highest-ROI prep: A1.** Your dossier named this objection as the likeliest one, and it lands exactly where F1 and F2 are thinnest. A1 gets the deepest rehearsal; F1 is the same objection, time-boxed.

## Fit snapshot

Requirement lines are quoted from your dossier's `role_profile`. Evidence is quoted from `verified_candidate_evidence`. Your dossier grades R1 (transferability, low) and the roadmap-ownership sub-claim (capability, none); it lists R5 as a discovery area. It does not grade R2, R3 or R4, so those three rows are this pack's own grading and are marked `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | Your dossier's strategy is bridge, positioned as adjacent and never as PM experience. The pack's observation: your material carries integration work and roadmap input, not time in a PM seat, and the roadmap-input line has limited inspectable proof, so expect a probe on it. Words stay at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." and "I ran quarterly roadmap-input sessions feeding client evidence to product." The limit, said plainly, sourced by `prohibited_claims: "Having held a product manager title or role"`: "I haven't held the product manager title." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | Your dossier's strategy for this area is acknowledge_gap, so no bridge is coached; the roadmap-input line in F1 is input, and is not offered as ownership. Words, sourced by `prohibited_claims: "Having owned a product roadmap"` and by the acknowledge_gap area in `uncertain_or_weak_areas`: "I haven't owned a product roadmap." Then a ramp plan said as a plan and never as a past: "In my first weeks I'd learn how roadmap decisions are split between this role and the two squad leads before I proposed anything." |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [inferred] | transferability | Derived by this pack, since your dossier does not grade R2. The quote carries integrations of the vendor's REST APIs; your material does not say you shipped an API or platform product. Words at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: R2 is a must-have, so a probe on shipping is likely. If any part of the API side itself was yours, say which part and what you did, in your own words; if your work was on the integration side only, or none of it was yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes touch REST APIs, an architecture stage and a playbook; they do not show whether you worked from or wrote API documentation or schemas, so the words are an answer slot. If you worked with the APIs' documentation or schemas, say which and how, in your own words; if you did not, or that sat with others, say so plainly and stay with the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes show client-facing work and a line to product; they do not show whether engineering or sales were part of it. Answer slot: if you worked with people in engineering or sales on those integrations, say who and what the work was, in your own words; if you did not, say so plainly and stay with the clients and product. The roadmap-input line is confirmed with limited inspectable proof |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | Your dossier's strategy is clarify and no verified entry speaks to this requirement, so nothing about your past goes into the answer. Answer slot: the JD lists agile delivery as preferred, so expect a probe on how squads run it. If you have worked in a sprint or iteration rhythm, say how and what your part was; if you have not worked that way, say so plainly. Then ask how Quartzline's squads run delivery so you describe the same thing |

## Persona table

Weights are shown with their reasoning so you can recalibrate if you know something I don't.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A, 5 questions) | Quiet, persistent probing of the title and roadmap gap and the must-haves | Highest. The hiring-manager prior is Case plus Skeptic, and your dossier names a Skeptic-shaped objection as the likeliest one | Rehearse A1 until it is boring: concede first, hold only what the quotes carry, offer a ramp plan |
| Case / Strategist (B, 5) | Live problems from the JD: adoption, roadmap conflicts, discovery, specs | Highest. Same prior; the JD's responsibilities (partner discovery, specs with two squads, adoption metrics) are all case-shaped | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Conversational (C, 3) | The opener and "tell me about" questions in a friendly register | Likely. A 45-minute conversation opens with your path, and casual questions are still scored | Pre-script the 90-second arc (C1) from the quoted beats only |
| Peer Evaluator (D, 3) | Seam-splitting with the two squad leads; disagreement and credit | Medium. Decision authority versus the squad leads is an unknown, so a hiring manager has reason to test it collegially | Propose seam principles rather than pretending to know the seam |
| Data-Driven Prober (E, 2) | Line-by-line on the 30+ figure and the integration stages | Medium-low. One headline figure and one inspectable artifact give it a target, but the prior does not favor it | Know what you can and cannot say about how the figure was counted; say plainly when you don't know |
| Pressure (F, 2) | Time-boxed or interrupting versions of the A1 objection | Lower. Not in the hiring-manager prior; included because A1 can arrive time-boxed | Pause, restate, hold the quote's scope through two follow-ups, concede specifically |
| Values / Behavioral | Dropped | No published Quartzline values were obtained and no source documents a values round, so no bank can be built on them honestly | Upgrade menu: paste Quartzline's values page if you have it |

Loop basis: your own words establish one session, with the hiring manager, 45 minutes. Persona weights follow the hiring-manager relationship prior adjusted by your dossier; no interviewer profile exists, so there is no interviewer read.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | The highest-ROI rehearsal, and your dossier's own wording of the objection. Four moves. (1) Concede before you are pressed, in the plain words your dossier sources: "I haven't held the product manager title, and I haven't owned a product roadmap." (2) Hold only what the quotes carry: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I wrote the internal integration playbook my team uses." (3) Name the limit of the third quote yourself before it is extracted: "I ran quarterly roadmap-input sessions feeding client evidence to product" is input, and is not roadmap ownership. (4) Do not argue you beat a three-year PM; the case is adjacent evidence plus a plan: "I'd start by learning how decisions are split between this role and the two squad leads." Follow-up ladder: if pressed on what you wouldn't know on day one, return to the concession and the plan; if told it still isn't the job, agree and return to the quotes without adding to them; if asked why Quartzline should take the risk, restate the plan and ask which decisions the PM makes alone (reverse question 1). Never add an outcome, a figure or a decision the quotes do not state | Your dossier named this objection from evidence you confirmed; F1 and F2 are where the material is thinnest, so it arrives in some form. JD because it scores the title requirement; Skeptic because it probes the gap persistently |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap" | Name it yourself rather than choosing a safe weakness: "I haven't owned a product roadmap," and owning the roadmap is a line in the JD. Then the plan, said as a plan: you would learn where decisions sit between this role and the two squad leads, and how partner adoption is measured today, before proposing anything. No bridge and no slot here; your dossier found nothing to bridge with, and inventing one live is how a candidate gets caught | F2 is the capability gap and this is the question that asks for it directly. JD because it scores the responsibility; Skeptic because it asks for honest self-assessment |
| A3 | "We need shipped API or platform products. What's your closest experience to that?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | Story-mapped on F3 at the quote's own scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, and the stages the quote names are the beats. Say plainly that this is integration work. Answer slot: R2 is a must-have, so expect a probe on shipping. If any part of the API side itself was yours, say which part and what you did, in your own words; if your work was on the integration side only, or none of it was yours, say so plainly and stay with the integrations you led. Let the interviewer draw the inference | F3 is a must-have with adjacent evidence only. JD because it scores the stated requirement; the grading is this pack's own, hence `[inferred]` |
| A4 | "The role leans on technical fluency with API docs and schemas. Where does that show up for you?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | Two facts at their own scope: you led integrations of the vendor's REST APIs, with architecture as one stage, and you wrote the internal integration playbook your team uses. The pack's observation is that neither quote says you worked from or wrote API documentation or schemas. Answer slot: if you worked with the APIs' documentation or schemas, say which and how, in your own words; if you did not, or that sat with others, say so plainly and stay with the integrations and the playbook | F4 is a discovery row: the evidence touches the requirement without showing it. JD because R3 is an important requirement; the slot lets the honest branch stand |
| A5 | "What's your experience with agile delivery?" | JD | [grounded] | No quoted sentence of yours speaks to this, so the guidance makes no claim about your past. Answer slot: the JD lists agile delivery as preferred, so expect a probe on how squads run it. If you have worked in a sprint or iteration rhythm, say how and what your part was, in your own words; if you have not worked that way, say so plainly. Before answering at length, ask how Quartzline's two squads run delivery today so you describe the same thing | F6 is a discovery row with a clarify strategy from your dossier. JD because R5 is stated, though preferred; low weight because it is the lowest-priority requirement |

### B. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner adoption of an API endpoint is flat six weeks after launch. What do you need to know first, and how would you diagnose it?" | CASE | [generic] | Clarify before structuring: what adoption means here and how it is measured today, what the baseline is, which partner segments you are looking at. Then objective, segmentation, a funnel from awareness through first successful call to sustained use, candidate causes (discoverability, documentation, a missing capability, partner priorities), the metric you would watch, and the risk of reading too much into a short window. Challenge one premise respectfully: whether flat is bad against the baseline. This question needs no claim about your past, so the guidance makes none | The JD has an adoption-metrics responsibility and your dossier flags that no baseline is stated. CASE because it is a live problem from the role; `[generic]` because it is a pattern, not a fact about Quartzline |
| B2 | "Two squad leads want different things on next quarter's roadmap, and each has a case. How do you decide?" | CASE | [generic] | Start by clarifying decision rights, since that is the open question about this role. Then criteria stated aloud (partner evidence, adoption impact, cost, dependencies), a way to make the trade-off visible to both leads, and who decides and how it is recorded. Propose principles rather than pretending to know how Quartzline splits the decision. Speak in the future tense; no claim about your past is needed | The JD's roadmap and two-squad lines meet an unresolved authority question. CASE with a Peer flavor; `[generic]` because it is a pattern |
| B3 | "How would you run discovery with partners who integrate the API? Start with who you'd talk to and what you'd ask." | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | Structure the case: which partner segments, what you need to learn about their jobs and blockers, how often, and how the evidence reaches the roadmap. One beat from your own material, at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Volunteer the limit: that is input, and your material does not say what came of it. Answer slot: expect a probe on what came of the sessions. Say what you know, in your own words; if you do not know, or nothing did, say so plainly and return to the sessions you ran | The JD has a discovery-with-partners responsibility. F1 and F5 carry the roadmap-input line, which is confirmed with limited inspectable proof, so a probe on it is likely. CASE delivery, EXP content |
| B4 | "A partner asks for webhooks on the API. Sketch the spec you'd hand the squad — what's in it, and what do you need to know first?" | CASE | [generic] | Clarify the partner's actual problem and what they do today, then an outline: problem, who it is for, scope and non-goals, behavior of the interface, how success is measured, rollout and deprecation. Think aloud and challenge one premise, whether webhooks are the right fix. This question needs no claim about your past, so the guidance makes none | The JD has a specs-with-two-squads responsibility. CASE because it is a live problem; `[generic]` because it is a pattern for the problem |
| B5 | "Why Quartzline, and where do you think a partner API platform should go next?" | CO | [generic] | No Quartzline research was obtained, so this pack asserts nothing about the company and you should not state facts you cannot source. Selection scaffold: pick the one JD line that drew you, such as "Run discovery with integration partners" or "Define and track adoption metrics," and say why in your own words. For the second half, give a view about partner API platforms in general and tie it to a question you would ask the interviewer. If you have not read Quartzline's published material by Thursday, say what you have read and what you would want to learn | The coverage rule asks for a strategy-grounded CO question when research succeeded; it did not, so this stays `[generic]`. The upgrade menu says what would change that |

### C. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey. How did you get here, and why this role?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | A 90-second arc from the quoted beats only: you led the integrations, you wrote the playbook your team uses, you ran the roadmap-input sessions. Say the third as input to product, not as roadmap ownership. The why-this-role beat is yours: give your own reason in your own words; this pack supplies none. End on what you want to do next, not on what you lack | The opener is always scored. F1 supplies the beats. EXP because it tests whether your path survives scrutiny |
| C2 | "Tell me about the integration playbook your team uses — what's in it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | Describe it only as your material does: you wrote it and your team uses it. Answer slot: expect a probe on its contents and on how it is used day to day. Say what it covers and how it came about, in your own words; if you do not know how it is used day to day, say so plainly. Your dossier lists it as inspectable, so check whether you are allowed to share it before offering to | The playbook is the one inspectable artifact in your material (F4). EXP because it tests what was actually yours |
| C3 | "Pick one of those integrations you led and tell me about it." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | Story-mapped on F3: choose one integration and tell it through the stages the quote names — scoping, requirements, architecture, UAT, go-live — in your own words. Answer slot: expect "which of that was you?" Say what you did hands-on and what others did; if a stage sat with someone else, say so plainly and describe the part you led. Do not add an incident or an outcome you have not stated | The strongest evidence in the material, so the likeliest story request. EXP because it tests attribution |

### D. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where's the seam between this role and the two squad leads, and what happens when you disagree?" | JD | [generic] | Propose principles rather than claiming to know the seam: decision rights agreed up front, disagreement resolved with partner evidence, a clear escalation path, and a record of what was decided. Say you would want to learn how Quartzline splits these decisions today, and use reverse question 1. Offer what you would bring the squads in the future tense; make no claim about decisions you have made | The JD asserts squad authority without evidence, which your dossier flags. JD because it scores the responsibility; this is the collegial version of A1 |
| D2 | "Tell me about a time you had to bring engineers and a client to the same page." | EXP | [generic] | Selection scaffold, since no quoted sentence carries this story: pick a time a client's need and an engineering constraint pulled apart; it needs a named stake, what you did, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | R4 names engineering and customers (F5), and the material does not show the engineering side. EXP because it asks for a past instance |
| D3 | "Sales has told a partner a date the squads can't hit. What do you do?" | CASE | [generic] | Facts first: what was promised, to whom, and whether it is in writing. Then impact, options (re-scope, re-date, an interim step), who decides, how the partner hears it, and how to stop it recurring. Needs no claim about your past, so the guidance makes none | R4 includes sales, and F5 shows no sales evidence, so a live problem is the safe way to probe it |

### E. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Thirty-plus client integrations — how was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | Keep the figure on its noun: "30+ end-to-end client integrations of the vendor's REST APIs." Answer slot, four parts, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which of them were yours to lead. "I don't know exactly how it was counted" is an honest branch. Do not supply a method you cannot repeat under a second question | The headline figure on the confirmed evidence, so it is the prober's target. EXP because it tests the number and its attribution |
| E2 | "Walk me through one of those integrations from scoping to go-live, and how the architecture step went." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | Pick one integration and move through the stages the quote names. Answer slot: expect the probe to go two levels deeper at architecture. If you made or shaped architecture choices, say which and how you decided, in your own words; if the architecture came from the vendor's or the client's engineers, or was not yours, say so plainly and describe the part you led | The architecture stage is where technical fluency (F4) is most testable. EXP because it checks what was actually yours |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM who's done this for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; prohibited_claims: "Having held a product manager title or role" | The A1 objection, time-boxed. Pause and restate the question. Concede in one clause, "I haven't held the product manager title," then hold the quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Hold through two follow-ups by returning to that sentence and the plan from A1, never by adding to it. Concede uncertainty specifically, not generally; do not fold on the quote to restore harmony | The same highest-ROI objection in pressure packaging. JD because it scores R1; hold-then-concede is the type's bar |
| F2 | "That roadmap-input work — how much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence; prohibited_claims: "Having owned a product roadmap" | Hold the quote: "I ran quarterly roadmap-input sessions feeding client evidence to product." Concede specifically that it was input, and that "I haven't owned a product roadmap." This line is confirmed with limited inspectable proof, so volunteer that rather than waiting to be asked. Answer slot: if an agenda or write-up from a session exists, offer it; if none exists, say so plainly. If asked what came of the sessions, say what you know; if you do not know, say so plainly | The roadmap-input line is the medium-confidence evidence (F1, F5), so a prober finds its seam. EXP with Pressure delivery |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 "3+ years product management experience" | A1, A2, F1 |
| Roadmap ownership, "Own the roadmap for the partner-facing API platform" | A1, A2, B2, D1, F2 |
| R2 "Shipped API or platform products" | A3, C3 |
| R3 "Technical fluency: API docs, schemas" | A4, C2, E2 |
| R4 "Stakeholder management across engineering, sales, customers" | D1, D2, D3, B3 |
| R5 "Agile delivery experience" | A5 |
| Responsibility: run discovery with integration partners | B3 |
| Responsibility: write specs and drive delivery with two engineering squads | B4, B2 |
| Responsibility: define and track adoption metrics | B1 |

## Reverse questions

Questions 1 and 2 are your dossier's employer questions, and they double as the two risks it asks you to validate.

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Your dossier flags decision authority as asserted in the JD but not evidenced. It reads as diligence and its answer decides whether this is the role described |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a named responsibility with no stated baseline. A thin answer tells you what you would inherit; it also shows you think in measures |
| 3 | "What would a strong first 90 days look like for someone coming from the integration side rather than a PM seat?" | It puts the bridge on the table in your own terms and shows what ramp support exists |
| 4 | "How do the two squads divide the platform today, and where do they most need a third voice?" | It surfaces the seam from D1 and shows you are thinking about the squads, not just the title |
| 5 | "How does partner feedback reach the roadmap today, and who talks to integrators?" | It tests where discovery sits and where evidence like your roadmap-input sessions would plug in |
| 6 | "What would make this hire a clear success a year from now, and what worries you most about the role?" | It invites the hiring manager to state their own risk, which is the A1 objection in their own words |

## Prohibited claims

What this pack will not coach. The first three come from your dossier's `prohibited_claims` field. The last two are wordings built locally from the fit snapshot, stretched forms of sentences you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | "I haven't held the product manager title." Then F1's first quote at its own scope |
| Having owned a product roadmap | Dossier `prohibited_claims`, and the acknowledge_gap area in `uncertain_or_weak_areas` | "I haven't owned a product roadmap." The roadmap-input line stays at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." No slot and no bridge |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." B2 and D1 are written in the future tense for this reason |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is this pack's observation: the material says integrations of the vendor's REST APIs, not shipping a product. A3's slot stays inside the integrations |
| Drove or shaped roadmap decisions through the roadmap-input sessions | Inflated form of F1's third quote | The quote at its own scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." B3 and F2 slots ask only what you know came of the sessions |

## Sources

- Provided: `tuesday-dossier.md`, dossier_version 1.1 (major version supported). Consumed: `handoff_to_mock_interview` (verified evidence, weak areas and their strategies, the named objection, risks, employer questions, `prohibited_claims`), `role_profile` (stands as the JD), and `decision` for context only. The dossier carries no `evidence_map`, `evidence_state` or `risk_register`, so F3 to F5 are graded by this pack.
- Provided in your message: a hiring-manager conversation, 45 minutes, on Thursday.
- Searches sent, all refused (the host did not grant search permission): "Quartzline company values" — refused; "Quartzline interview process product manager" — refused; "Quartzline API platform strategy news" — refused. Nothing in this pack comes from them.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. Would have fed VAL theming; no values-style round is detected anyway, so the values section is dropped |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. Would have documented the loop; persona weights rest on your own words and the hiring-manager prior instead |
| 3. `Quartzline strategy` or recent news | unavailable | Every call was refused. B5 stays `[generic]`, and there is no grounding brief |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative `Product Manager, Platform APIs` JD | skipped | Your dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name and role → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their path
- The recruiter's note on focus areas or any pre-declared deliverable → coverage beyond the hiring-manager prior, and a build section if a deliverable was announced
- Quartzline's values page, loop description or a strategy brief, pasted → B5 becomes `[grounded]`, and a values map is added if a source documents a values round
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), which needs search permission this session did not have → a grounding brief and strategy-based CASE and CO questions
- An agenda or write-up from one roadmap-input session → the medium-confidence line in F1, F5 and F2 can move toward high, because the inspectable proof is what is missing
- Your own answers to the slots in A3, A4, A5, C2, E1 and E2, given outside a drill → F3 to F6 regenerate from your words
- `evidence_map` rows for R2 to R4 added to `tuesday-dossier.md` → those three rows stop being this pack's own grading
