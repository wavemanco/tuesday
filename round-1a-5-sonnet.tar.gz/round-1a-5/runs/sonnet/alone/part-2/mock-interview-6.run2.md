I'll read the reference files before writing the pack.
I've read the skill's reference files. Next I'm running the budgeted company research (values, interview loop, strategy) for Larkfield Systems, then I'll build the three-round pack.
Your prep pack for all three rounds is saved at `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-2/rooms/case-6-denied-de285c7b/larkfield-systems_engineering-manager_interview_pack.md`. It has one shared fit snapshot, then a mini-pack per round with persona weights and reasoning, 10, 12 and 9 questions with answer guidance, and reverse questions. The prohibited-claims list, the sources and the upgrade menu close the file.

I built it from your message alone, which is a one-sentence role description, the three rounds and four sentences about your background. Company research didn't run because the web searches were refused (permission wasn't granted). Nothing in the pack states Larkfield's values, loop or strategy, and there is no Round 3 values cheat sheet.

The highest-ROI prep is R1.A1: "I don't see a hardware-adjacent roadmap in your background." It probes the gap you named yourself, and it will come back in some form in all three rounds. The pack coaches a plain acknowledgment, a plan said as a plan, and no claim of hardware experience.

You'll also be probed on two figures. The 60% on-call drop gets R1.D1 and R2.B1. The "about 40 interviews" gets R2.B2, because the pack can't tell whether the 40 were yours or the loop's.

Say the word and I'll play the Director on R1.A1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Has the recruiter said anything about the format of any round, such as a case, presentation or take-home for Thursday's panel?
2. Can you paste the full job description and your CV lines, or say skip and keep the pack as built?
3. If you grant search permission, should I retry the Larkfield research (up to 6 searches and 2 fetches), with a deeper pass of up to 6 more searches and 2 more fetches taking several more minutes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf. **Mode:** loop, three scheduled rounds, one shared fit snapshot, one mini-pack per round.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel: two technical seniors and one cross-functional partner |
| 3 | The following Monday | VP Engineering | 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

The loop above is the one your message gives. The persona weights rest on those relationships and on no documented Larkfield process: company research did not run (see Sources), so this pack states nothing about Larkfield's published values, loop or strategy.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each round opens with its persona weights and the reasoning behind them, so you can recalibrate if you know something this pack does not.
- **Type key.** VAL: past behavior and collaboration, scored for fit with how the company works. EXP: whether the claims in your background survive scrutiny and attribution. JD: whether you can do the listed job, gaps included. CO: homework on the company. CASE: a live problem from the role, scored on structure.
- **Guidance is scaffolding, not a script.** It is built only from your own sentences, quoted in the Provenance column. Where the pack could not trace a beat to a sentence of yours, it gives an answer slot: an instruction for the interview, in two branches, where the second branch always allows that the thing never happened or was not yours. Say what is true.
- **The highest-ROI prep in this pack is R1.A1**, the hardware-roadmap objection. It will arrive in some form in all three rounds.

## Prep triage

About two weeks, three rounds. Say each answer aloud against a timer; guidance is sized to 90 to 120 seconds.

1. **Before Tuesday:** R1.A1 first and longest, then R1.D1, R1.C1, R1.A3. Everything else in Round 1 is insurance.
2. **Between Tuesday and Thursday:** R2.B1, R2.B2, R2.A1, R2.C1. If anything Tuesday changes what you know (a format, a name, a priority), tell me and I will regenerate the affected sections.
3. **Between Thursday and Monday:** R3.A1, R3.B3, R3.B1, R3.A2.
4. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

The JD is the one-sentence role description in your message; the full posting would add rows. The JD supplies no gate (no location, authorization, schedule or pay term), so no row is a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — JD, your message | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says a team lead of 6, with nothing inspected behind it; the JD says two squads and 11 engineers, and no quoted sentence reaches past the one team. Words, at that scope: "I've been a team lead of six." Answer slot: the JD's two-squads line makes a probe on stepping up in scale likely. If any of your leading touched more than one team, say which and what part was yours, in your own words; if it did not, say so plainly and stay with the team of six |
| F2 | "building device-management services" — JD, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | The quote places your current work at a payments company and does not show whether any of your work touches device management. Answer slot: expect a probe on the domain. If you have worked on anything device-management-like, say what and what part was yours, in your own words; if not, say plainly the domain is new to you, and say what you would learn first |
| F3 | "own delivery, hiring and growth for 11 engineers" — JD, your message (delivery) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote carries one reliability quarter and one figure, with nothing inspected behind either; it does not say what else the team delivered. Words, at that scope: "I pushed a reliability quarter through against roadmap pressure." The 60% is a headline figure, so expect probes on it (R1.D1, R2.B1). Answer slot: if you were accountable for what the team delivered beyond that quarter, say how, in your own words; if delivery sat with someone else, or there was no such accountability, say so plainly and stay with the reliability quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" — JD, your message (hiring) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms: you run a hiring loop. Two limits sit inside it: it says backend roles, and "about 40 interviews" does not say whether the 40 were yours or the loop's. Words: "I run our hiring loop for backend roles." Answer slot on the figure: say how it was counted and which interviews were yours, in your own words; if you do not know how it was counted, say so plainly |
| F5 | "own delivery, hiring and growth for 11 engineers" — JD, your message (growth) | none given | none | [grounded] | discovery | Your material is silent on developing engineers. Answer slot: the JD's growth line makes a probe likely. If you have helped an engineer develop, say who or what and what part was yours, in your own words; if you have not, say so plainly and say how you would start |
| F6 | "partner with hardware and product on roadmap" — JD, your message (hardware) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | discovery | You have said you have never owned a hardware-adjacent roadmap, and those words are yours: "I've never owned a hardware-adjacent roadmap." The JD says partner, and your material is silent on whether you have worked with hardware teams. Answer slot: if you have worked with hardware or device teams in any form, say how and what part was yours, in your own words; if not, say so plainly and say what you would ask them first, as a plan and never as a past |
| F7 | "partner with hardware and product on roadmap" — JD, your message (product) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote carries roadmap pressure and a push against it; it does not say who the pressure came from. Answer slot: the JD's product line makes a probe on working with product likely. If the pressure came from product, say what you did with them, in your own words; if it came from elsewhere, or you did not work with product on it, say so plainly and stay with the quote |
| F8 | "values and leadership philosophy" — the recruiter's description of Round 3, via your message | none given | none | [grounded] | discovery | No sentence of yours states a leadership philosophy. Answer slot: expect to be asked. Describe what you do, in your own words, and let the VP draw the inference; if you cannot yet say it in a sentence, say so plainly and give the nearest thing your material carries, or how you would handle it |

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| "Lead two squads" (F1) | R1.A3, R1.B2, R2.A1, R3.C1 |
| "building device-management services" (F2) | R1.A2, R1.A4, R1.C2 |
| Delivery (F3) | R1.B1, R1.B3, R1.D1, R2.B1, R2.D1, R2.D2, R3.B2 |
| Hiring (F4) | R2.B2, R2.B3 |
| Growth (F5) | R1.B2, R3.A3 |
| Partner with hardware (F6) | R1.A1, R1.B1, R2.D1, R3.B1, R3.B2 |
| Partner with product (F7) | R1.B1, R2.C1, R2.C2, R2.D1 |
| "values and leadership philosophy" (F8) | R2.C3, R3.A1, R3.A2, R3.A4, R3.C2 |

---

## Round 1: Director of Engineering (Tuesday, 45 min)

### Persona weights, with the reasoning

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the distance between your background and the JD | Highest, 4 questions. The hiring-manager prior is Skeptic plus Case, and your own message names two stated gaps (F6). The person who would be your boss is the one pricing the risk | Rehearse the single most predictable objection until it is boring (R1.A1). Acknowledge the limit plainly, then give a plan said as a plan |
| Case/Strategist | A live problem on the role's own shape: two squads, hardware and product dates | 3 questions. Same prior; 45 minutes leaves room for one or two live problems | Clarify, objective, options, metrics, risks. Think aloud and challenge one premise respectfully |
| Conversational | The opening arc and "what do you know about us" | 2 questions. The first minutes of a manager conversation are usually casual and still scored | Pre-script a 90-second arc built only from your own sentences; treat casual questions about the JD's hot topics as scored |
| Data-Driven Prober | One probe on your headline figure | 1 question. The 60% in F3 is the figure a careful reader goes to first | Say how it was counted, or say plainly that you do not know |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1.A1 | "I don't see a hardware-adjacent roadmap in your background. How would you handle that in this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The deepest rehearsal in the pack. First, the plain acknowledgment, with no preamble: "I've never owned a hardware-adjacent roadmap." Second, the plan, said as a plan and never as a past: the first things you would ask the hardware partners and the Director, in your own words. Third, only if pressed on what you do have, the nearest thing your material carries at its own scope, "I pushed a reliability quarter through against roadmap pressure", and stop there; do not call it hardware experience. Follow-up one, "that's a plan, not experience": concede it in a sentence, "Agreed, it's a plan." Follow-up two, "what would make this a mistake": name the limit once, specifically, without apologizing. Answer slot: if you have worked with hardware or device teams in any form, say how and what part was yours; if not, say so plainly | F6 is where your material is thinnest on the JD's hardware line, so this objection arrives in some form in every round. JD because it scores a stated requirement; Skeptic because it probes the gap |
| R1.A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick the one that is true for you and say it in one sentence, then one sentence on how you would close it. If it is the hardware roadmap, your own words are "I've never owned a hardware-adjacent roadmap." Do not recite a list of weaknesses. Answer slot: if your honest answer is something this pack does not name, say that instead, in your own words | F6 and F2 are the likeliest candidates; naming one precisely beats being asked to name one. JD because it scores the listed job; Skeptic because it asks for self-assessment |
| R1.A3 | "You've been a team lead of six. This role is two squads and eleven engineers. What changes?" | JD | [grounded] "3 as a team lead of 6" | Start at your scope: "I've been a team lead of six." Then say what you expect to change, as a plan: what you would learn first about the two squads and what you would ask the Director for. Answer slot: if any of your leading touched more than one team, say which and what part was yours; if it did not, say so plainly and stay with the team of six | F1 is the scale step the JD makes explicit. JD because it tests the stated scope |
| R1.A4 | "Why this role, and why now?" | VAL | [generic] | Selection scaffold: one reason about the work, taken from what the JD actually says (device-management services, partnering with hardware and product, 11 engineers), and one about what you are looking for, specific enough that it could not be said about any other company. If no reason is yet clear, say so plainly, and say what you hope to learn from these rounds | The standard motivation-consistency probe; no sentence of yours states a motive, so this is a scaffold. VAL because it scores why, not what |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1.B1 | "Suppose hardware and product give you conflicting dates for the same quarter. How would you plan it, and what do you need to know first?" | CASE | [generic] | Clarify before structuring: what is fixed and what is movable on each side, who decides, what the squads are already carrying. Then the objective, two or three options, how you would choose between them, the metric you would watch, and the main risk. Think aloud; challenge one premise respectfully. The case needs no claim about your past, so this guidance makes none | F6 and F7 are the partnership lines; a live problem on them is likelier than a story. CASE because it scores structure |
| R1.B2 | "You inherit two squads and eleven engineers. What do you do in the first 30 days with the people?" | CASE | [generic] | Say it as what you would do: learn before changing, talk to each engineer, find out what each squad has committed to and to whom, and agree with the Director what matters most. Keep it to a plan; it carries no claim about a past inheritance | F1 and F5 combined: scale and people growth in one prompt. CASE because it asks for a plan, with JD content |
| R1.B3 | "A squad lead wants to stop feature work for a quarter to fix reliability, and hardware has a launch coming. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure first: what not fixing costs, what a smaller version looks like, who needs to agree, how you would tell the people affected. Your nearest material, at its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if anything was deferred or traded in that quarter, say what, in your own words; if nothing was, say so plainly and describe how you decided | F3 is the one place your material touches this tension, so an interviewer who has read it will ask it as a live case. CASE with EXP content |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1.C1 | "Walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" and "I run our hiring loop for backend roles — about 40 interviews last year." and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc with three beats, each told at the scope of its sentence: the years and the team of six, the hiring loop, the reliability quarter. Do not add titles, employers, reasons for moves or outcomes beyond those sentences. End on why this role, using R1.A4 | The opener is scored for economy. F3 and F4 are the strongest quoted lines, so they carry the arc. EXP because it tests the background as told |
| R1.C2 | "What do you know about what we're building?" | CO | [grounded] | Say only what you have actually read. From your own role description: industrial IoT, about 600 people, two squads building device-management services, partnering with hardware and product. Research did not run, so do not add strategy or product facts from memory. If you have read little, say so plainly and ask the Director to tell you | Homework depth, asked casually. CO because it scores company knowledge; the label is grounded because every fact in the guidance is in the role description you gave |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1.D1 | "Your team's on-call burden dropped 60%. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say what the sentence says, at its scope. Then four slots, each in your own words: how the 60% was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly, which is better than a method you cannot repeat under a second question. Offer to walk through it end to end only if you can | F3's figure is the headline number on your side of the table. EXP because it tests whether the claim survives attribution |

### Reverse questions for Round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would success look like for these two squads at 90 days and at a year, and how will you and I know?" | Turns the conversation to outcomes and shows you think in expectations, which a manager scores |
| 2 | "Where do the hardware and product roadmaps pull against each other today, and who decides when they do?" | Goes straight at F6 and gives you the real shape of the thing you have not owned |
| 3 | "How are reliability and on-call work weighed against roadmap work right now?" | Connects to your reliability quarter without claiming it applies here |
| 4 | "What are the two squads best at, and where do they struggle?" | Shows you want the people picture before the plan |
| 5 | "What do you want from me in the first month, and how do you like to be kept informed?" | Asks the boss for the working agreement you will live under |
| 6 | "What would make you regret this hire in six months?" | Invites the objection into the open, where you can answer it |

---

## Round 2: panel, two staff engineers and a product manager (Thursday after, 60 min)

### Persona weights, with the reasoning

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between you and the senior engineers, "what would you need from us", credit and disagreement | Highest, 4 questions. The panel prior blends the top two personas of each member's relationship, and two of three members are senior engineers whose work you would shape | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober | Attribution and counting on your two figures | 3 questions. Technical seniors tend to go to the numbers, and F3 and F4 each carry one | Say what you can and cannot say about each count; name the assumption you would defend least before they do |
| Values/Behavioral | The product manager's stories: pushing back, disagreeing, customers | 3 questions. The cross-functional prior; casual register is still scored | Choose stories only where one of your sentences carries them; otherwise a scaffold with its honest branch |
| Case/Strategist | One or two live problems from the partnership lines | 2 questions. The product manager is likeliest to set one | Clarify, structure, one challenged premise |

No names were given, so the personas are assigned by role, not by person.

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2.A1 | "Where is the seam between what you would decide and what the senior engineers would decide, and what happens when we disagree?" | VAL | [generic] | Offer seam principles and do not pretend to know the seam: who owns the outcome, who holds the context, who has to live with the decision. Say how you would handle a disagreement as a plan: hear the argument, say who decides and why, explain the call, and revisit it. Answer slot: if you have settled a disagreement of this kind, say what it was and what part was yours; if not, say so plainly and stay with the plan | The staff engineers are pricing what you would do to their work. VAL because it scores working style with equals; F1 is the scale context |
| R2.A2 | "What would you need from us in your first month?" | VAL | [generic] | Reciprocity first: what you would bring, then what you would ask. Ask for their view of what is fragile and where the squads hurt, in your own words, and say how you would use it. Do not promise outcomes | The peer prior's signature question; a one-sided answer reads as taking. VAL because it scores partnership |
| R2.A3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams or people, name who did what, use "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly and say how you would handle it | A persona stem; credit-sharing is a standard peer probe. No quote of yours carries a cross-team story |
| R2.A4 | "Tell me about a time you disagreed with a senior engineer about a technical call." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Your nearest material, at its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if the pressure involved a disagreement with an engineer, say who and what each side argued, in your own words; if it did not, say so plainly and choose another time, or say how you would handle one | F7 shows pressure, not who it came from, so this is a slot. VAL because it scores spine and tact together |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2.B1 | "How much of that on-call reduction was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold what the sentence says: "I pushed a reliability quarter through against roadmap pressure." Concede the rest specifically, in your own words: what the team did, and what you did beyond pushing the quarter. Answer slot: if the team did the reliability work itself, say so plainly; if you did part of it, say which part. Never claim the 60% as your own output. Hold through two follow-ups by returning to the sentence | Engineers who carry a pager know exactly what this figure takes. EXP because it scores attribution; the pressure stem makes it a hold-then-concede |
| R2.B2 | "You mentioned about 40 interviews last year. What does that number cover?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what the sentence says: "I run our hiring loop for backend roles." Slots, in your own words: whether the 40 were interviews you conducted or the loop's total; how it was counted; what it is sensitive to; the assumption you would defend least. If you do not know how it was counted, say so plainly | F4's figure is ambiguous on its face, and a careful panel will resolve it |
| R2.B3 | "What would you look for in the next engineer you hire for these squads?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | You run a loop for backend roles; say how you would adapt it, as a plan: ask the staff engineers what the squads need and what the last strong hire had that others lacked. Answer slot: if you have hired for anything device-adjacent, say what; if not, say so plainly and say what you would ask them first | The JD names hiring; the staff engineers would work with whoever you hire. JD because it scores a stated responsibility |

### Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2.C1 | "Tell me about a time you pushed back on a roadmap request." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The one quoted story that fits, at its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: say who the request or pressure came from, what you said and what was agreed, in your own words; if you did not push back on a request, or it was not framed that way, say so plainly and choose another time | F7 and the JD's roadmap line make this the product manager's likeliest behavioral prompt |
| R2.C2 | "Tell me about a time you and a product manager disagreed." | VAL | [generic] | Selection scaffold: a named disagreement, what each of you wanted, what was decided and how, and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F7 is the partnership line; no sentence of yours names a product partner, so this is a scaffold |
| R2.C3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named stake and a decision you made; say what the metric was, what you chose and what happened. If none comes to mind, say so plainly and say how you would handle one | A persona stem for the cross-functional interviewer; Larkfield's published values were not retrievable, so it is a generic prompt, not a value-mapped one |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2.D1 | "A feature depends on a hardware milestone that slips six weeks, and product has already told a customer a date. Walk me through your next two days." | CASE | [generic] | Clarify first: what exactly slipped, what is movable, what the customer was told. Then who needs to know today, two or three options (reduce scope, change the date, work around), how you would choose, and how you would say it to product and to the customer. Say the framework aloud. The case makes no claim about your past | F6 and F7 on a live case; hardware dependence is named in the JD |
| R2.D2 | "Both squads want the same senior engineer for the quarter. How do you decide?" | CASE | [generic] | Clarify what each squad needs the person for and what happens if they do not get them, then the criteria you would use, who you would involve, and how you would explain it to the squad that loses. No claim about your past | F1 and F3: running two squads is a prioritisation problem |

### Reverse questions for Round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What is the hardest part of the technical seam between the squads and the hardware?" | Goes to the staff engineers' real ground and fills in the domain you have not worked in |
| 2 | "What could a new manager do in their first month that would genuinely help you?" | The reciprocity question for a panel that includes your would-be seniors in the work |
| 3 | "What do you wish a manager here had done differently?" | Invites their experience of the thing you would be |
| 4 | "How does product learn about hardware constraints today, and where does it go wrong?" | Aimed at the product manager and at F6 and F7 together |
| 5 | "When the two squads' priorities collide, who feels it first?" | Shows you are thinking about the people in the seam |

---

## Round 3: VP Engineering (the following Monday, 30 min)

### Persona weights, with the reasoning

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Values and leadership philosophy": stories and principles | Highest, 4 questions. The recruiter's own description names this round's content | Describe behaviors and let the VP draw the inference; "we" for context, "I" for contribution |
| Pressure | Time-boxed, devil's advocate, motive-testing | 3 questions. The skip-level prior is strategy plus Pressure; at 30 minutes, composure is cheap to score | Pause, restate, anchor in what you actually said, hold through two follow-ups before conceding anything real |
| Skeptic | Risk and commitment | 2 questions. Your two stated limits (F6) are what a VP weighs against the level | Plain acknowledgment, then a plan |

Case/Strategist is weighted at zero here because the recruiter's description names values, not strategy. Ask me for one if Monday's format changes.

### Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3.A1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | No sentence of yours states a philosophy, so build it from behavior, not adjectives: say what you do, with one concrete example at its scope ("I pushed a reliability quarter through against roadmap pressure"), and let the VP draw the inference. Answer slot: if you can state the principle behind that quarter in your own words, say it; if you cannot yet say it in one sentence, say so plainly and say how you would handle a similar choice | F8 is the recruiter's stated focus. VAL because it scores principles against behavior |
| R3.A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | At its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if the pressure came from leadership, say what you told them and what happened, in your own words; if it did not, or you did not say anything unwelcome, say so plainly and choose another time, or say how you would handle it | A persona stem for a values interviewer; F7 does not say who the pressure came from |
| R3.A3 | "Tell me about a time you invested in someone's growth." | VAL | [generic] | Selection scaffold: a named person, what you noticed, what you did, what changed for them, and your part in it, with "we" for context and "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would start | The JD names growth and F5 holds no quote. The VP sees managers as developers of people |
| R3.A4 | "What is a leadership decision you would make differently today?" | VAL | [generic] | Selection scaffold: a decision where you had real options, what you chose, what you learned and what you do now. Pick one you can describe without defending it. If none comes to mind, say so plainly and say what you are still working out about how you lead | Probes self-awareness, which is what "leadership philosophy" rounds usually score |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3.B1 | "Sixty seconds: why you, rather than a manager who has already run device-management teams?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." and "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause, then restate the question. Hold only what your sentences carry: "I run our hiring loop for backend roles" and "I pushed a reliability quarter through against roadmap pressure." Concede the limit in one sentence, "I've never owned a hardware-adjacent roadmap", and stop. Do not argue that you are better; say what you would do in the first 90 days, as a plan. Hold through two follow-ups | The stem is the classic pressure comparison; F6 is the concession |
| R3.B2 | "You pushed a reliability quarter through against roadmap pressure. Would you do the same here, where hardware and product both have dates?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause. Answer with how you would decide, using the R1.B3 structure, not a bare yes or no. Concede that the context differs: "I've never owned a hardware-adjacent roadmap." Answer slot: if something was deferred or someone disagreed in that quarter, say what, in your own words; if not, say so plainly | F3 and F6 collide here; the VP is testing whether your one story is a principle or a one-off |
| R3.B3 | "You've never managed managers. Why should I trust you to grow into this?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The plain acknowledgment first: "I've never managed managers." Do not claim you can; say how you would learn, as a plan: ask the VP what the expectations are and what progression looks like. The JD as you gave it does not list managing managers, so do not volunteer a claim about it. Concede the limit once and stop | The sentence is your own stated negative. JD because the question tests the level; the acknowledgment has a source |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3.C1 | "What is the biggest risk in hiring you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pick the one you actually believe is biggest, say it in a sentence, and give one sentence of ramp. If it is the hardware roadmap, your own words are "I've never owned a hardware-adjacent roadmap." One risk, not three | F6 and F1 are the candidate risks; naming one precisely is the strongest answer |
| R3.C2 | "What would make you stay here for three years?" | VAL | [generic] | Selection scaffold: what about the work and the people you would want to still be doing, specific to what you have read in the role description. If you cannot yet say, say so plainly and say what you would need to learn from these rounds | A commitment probe from a leader who owns retention; no quote of yours states a motive |

### Reverse questions for Round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do you want engineering to look like in two years, and what would you want this role to contribute to that?" | The altitude a VP wants to hear; it ties your role to their agenda |
| 2 | "Which leadership behaviors do you most want to reward here, and which do you most want to stop?" | Values-round signal; it asks for their philosophy before you give yours |
| 3 | "What have you changed your mind about in how you lead?" | Matches the round's subject and invites a peer-like answer |
| 4 | "How do you make the trade-offs between hardware-driven and software-driven priorities at your level?" | Shows you are thinking about the seam you have not owned, without claiming it |
| 5 | "What does progression from this role look like?" | Surfaces the manager-of-managers question on your terms |

---

## Prohibited claims

What this pack will not coach, and why. Built before the question banks and held against every cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Having owned a hardware-adjacent roadmap | Negative you stated, F6 | "I've never owned a hardware-adjacent roadmap." No slot asks you to supply the thing; the plan is said as a plan |
| Having managed managers | Negative you stated, F6 | "I've never managed managers." No slot |
| Having led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope: "I've been a team lead of six." The limit is the pack's observation: the material says a team of six, not two squads |
| The 60% as your own sole output, or any method behind it | Inflated form of F3 | F3's quote at its own scope: "I pushed a reliability quarter through against roadmap pressure." The limit is the pack's observation: the material states the figure and the push, not how it was counted or who else contributed |
| Having personally conducted 40 interviews, or owning engineering hiring beyond backend roles | Inflated form of F4 | F4's quote at its own scope: "I run our hiring loop for backend roles." The slot in R2.B2 asks only what the 40 covered |

## Sources

**Provided documents:** your message: the role description, the three rounds and who runs each, and four sentences about your background. No CV, full JD, dossier or interviewer information was provided.

**Searches sent, all refused:**

- "Larkfield Systems industrial IoT company values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT device management strategy news": refused

No page was fetched. Nothing in this pack is drawn from search results.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Every call was refused. Would have moved a values cheat sheet for Round 3, which is absent because no published values are in hand |
| 2. Larkfield interview process, engineering manager | unavailable | Every call was refused. Persona weights rest on your own description of the loop and on relationship priors |
| 3. Larkfield strategy and recent news | unavailable | Every call was refused. Would have moved company-strategy cases and a grounding brief; the CO bank is one generic-label question |
| 4. Interviewer names | n/a | No name was given, so no query could be formed; there is no interviewer read |
| 5. Representative Engineering Manager JD | skipped | A role description was supplied and fixes the fit snapshot and the JD-tagged questions |

**Loop and values-style round:** the loop is established by your own words (three rounds, who runs each). A values-style round is detected from the recruiter's description of Round 3; the cheat sheet is not built because Larkfield's published values are not in hand.

## Upgrade menu

- Full JD text → the fit snapshot's eight rows come from one sentence; a posting would add requirements, convert more JD-tagged questions to quoted ones and tighten the coverage table.
- Your CV or résumé lines → F1 to F4 rest on four sentences of your message; the lines behind the team of six, the hiring loop and the reliability quarter would add quotes the banks can map stories onto.
- An inspectable artifact for the 60% (the on-call or paging report from before and after the reliability quarter) and for the hiring loop (the scorecard or loop design document) → F3 and F4 from medium toward high.
- Your answers to the answer slots, especially F1, F2, F5, F6 and F7 → each upgraded row becomes a quoted story and the matching slots become story maps.
- Larkfield's published values, pasted → the Round 3 values cheat sheet, with a mapped story or selection scaffold for each value.
- Search permission, then research on values, loop and strategy → the grounding brief, strategy cases and a quoted loop; a deeper pass (up to 6 further searches and 2 further fetches, several more minutes) would add a strategy brief and recent organization context.
- The interviewers' names → an interviewer read, persona weights adjusted per person and one reverse question tied to each person's path.
- The recruiter's notes on any round's format, in particular whether the panel has a case, presentation or take-home → a build section for any pre-declared deliverable.
- A `tuesday-dossier.md` → verified evidence and a strategy constraint on each weak area, replacing the inferred objection ranking.
