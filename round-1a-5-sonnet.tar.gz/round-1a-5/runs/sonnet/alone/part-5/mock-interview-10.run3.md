I've read the skill's reference files. Next I'm running three company searches (values, interview process, recent strategy) for the Lumenvale pack.
The invite has a warning sign, so I'm putting that before the prep.

Before the prep, one thing in the invite: it says the process is "carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern, and a chat alone doesn't show who you're dealing with. Until you know who sent it, send no money, documents or bank details through the chat. Check the invite with Lumenvale through contact details you find yourself on its own website or careers page, never through this chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `lumenvale-software_customer-support-specialist_interview_pack.md`. It has 18 questions across five interviewer styles, plus a fit table, reverse questions and a coverage check. I built it assuming the support team lead would be your future manager, since your note didn't say. My company searches were refused here, so nothing in it comes from outside your message. Company questions are labelled generic.

The biggest prep item is B1: "You haven't worked for a software company before. What will be hardest about moving into one?" Your answer rests on your own words: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Then you say plainly that you've never worked for a software company, and give a plan for learning the product.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead the person you'd report to? Can you paste the full text of the job ad? Without it I keep working from the four requirements you gave me.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (name not given). Format: a text chat on Telegram, per the invite. Relationship: assumed to be your future manager or close to it, because your note did not say. Built from what you told me only; the company searches were refused in this session, so nothing here comes from outside your message.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

Type key:

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your own experience holds up when probed |
| JD | Whether you can do the listed job, gaps included |
| CO | What you know about the company and what it does |
| CASE | A live problem from the role, answered as a decision |

Your interview is a typed chat, so your writing is on show in every answer. Answer in short, plain paragraphs. Answer slots below are instructions for what to say in the interview if the question comes up. They are not questions for you now.

## Fit snapshot

Requirements are quoted from your message, where you described the ad.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | Nothing to recover, but it is your own statement with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms: three years, customer service advisor, energy supplier. Keep the title you gave, not the ad's |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | none | The ad's own words "or a similar ticketing tool" are what connect Freshdesk to the line. Name Freshdesk and say it as the sentence does, every day. The pack says nothing about Zendesk, because your material does not mention it |
| F3 | "clear written communication" — the ad, as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are in your sentence, but a volume does not show how clear the writing was. Answer slot: the interview is itself a text chat, so expect your writing to be judged live. If you can say anything concrete about the written side of those emails, in your own words, do; if you cannot, say so plainly and stay with the sentence |
| F4 | "confidence handling escalations" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: expect a probe on escalations. If an issue ever went beyond what you could settle, say what it was and what part was yours, in your own words; if none did, or it was not yours, say so plainly and say how you would handle one |
| F5 | Familiarity with a software company's support work (not in the ad as you described it; a role-family expectation) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Passing process knowledge to colleagues (not in the ad as you described it; a role-family pattern) | "I trained four new starters on our refunds process last year" — your message | medium | [inferred] | none | The link from this sentence to a support team's needs is the pack's derivation, not something you said. Say the sentence at its own scope: four new starters, the refunds process, last year, trained by you |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live support problems set as decisions: an angry customer, a repeat contact, a queue to order | High. The hiring-manager prior favours it, and the ad as you described it names escalations. The support team lead's relationship to you is assumed, not known | Clarify first, then structure, then answer. Think aloud in typed form: short steps, not one block |
| B. Skeptic | Quiet probing of gaps | High. Your message states the software-company gap (F5), and escalations show no evidence (F4) | Rehearse B1 until it is boring: hold what your sentences say, concede what they do not |
| C. Conversational | Friendly opening, journey and motivation questions | Medium. The invite calls it a chat; no source says how structured it is | A 90-second arc built only from your own sentences (C1). Treat casual questions as scored |
| D. Data-Driven Prober | Pulls on a number or a claim until it breaks | Medium. Your message gives "around 60" and "four new starters" | Know what you can and cannot say about how each was counted or done; say plainly when you do not know |
| E. Pressure | Time-boxes, challenges motive and attribution | Low. Nothing in your inputs signals a stress style; two questions cover composure | Pause, restate, hold the sentence you stated through two follow-ups, concede only what is real |
| Values/Behavioral | Scenario questions mapped to published values | Not banked. Your inputs name no values round, and no values were researched | If one comes up, use a selection scaffold from B2 |
| Peer | Seam-splitting, collaboration | Not banked. Low unless the team lead turns out to be a peer; if so, tell me and I will reweight | n/a |

Weights run A and B at 5 questions each, C at 3, D at 3, E at 2. The loop is one session, as your own invite describes it, so no archetype fallback was used.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer has written in three times about the same problem and now says they want a manager. What do you do in your next reply?" | CASE | [generic] | Ask one clarifying question first, for instance what the earlier replies said. Then structure it: what you would check on the ticket history, what you would tell the customer in plain words, what you would do about the problem itself today, whether it goes to someone else and what you would hand over with it, and what you would record. No claim about your past is needed, so none is made; if you have a real escalation, B2 is the place for it | The ad as you described it names escalations (F4), and a live decision is the likeliest way to test it. CASE because it asks for reasoning, not a past |
| A2 | "Write me the first two lines of your reply to a customer who is angry that a refund they asked for is outside our policy." | JD | [generic] | This is the written-communication line (F3) scored in the medium of the interview itself. Shape: acknowledge the specific problem in the customer's terms, say plainly what can and cannot be done, then give the next step. Keep it short and plain, and read it once before sending. No claim about your past is made | Written communication is a stated requirement and a typed chat is its own sample. JD because it scores the stated line, with CASE delivery |
| A3 | "You open your queue and find four tickets: a customer who cannot log in, a billing question, a feature request, and a customer who says their data has disappeared. What order do you take them in and why?" | CASE | [generic] | Say what you would want to know first, such as how many people are affected and whether anything has a deadline. Sort by impact and urgency, say the reasoning aloud, and say what you would tell the customers who wait. The logic matters more than the order | A queue-ordering problem is a pattern for support roles, not a fact about this employer, which is why it is generic. CASE because it is a live problem |
| A4 | "It's your second day and a customer asks about a feature you have never seen. What do you do?" | CASE | [generic] | Say what you would check, who you would ask, and what you would tell the customer about when they will hear back. Do not guess an answer to look knowledgeable. This is the F5 limit handled as a plan, not a past | F5 makes product knowledge the likeliest worry. CASE because it asks for a decision under unfamiliarity |
| A5 | "A customer asks us for something the product cannot do. How do you reply?" | CASE | [generic] | Say plainly what the product does and does not do, offer what is possible, and say what happens to the request. Write it as you would type it. No claim about your past is made | A routine support problem in a software setting, with the written line (F3) running under it |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked for a software company before. What will be hardest about moving into one?" | JD | [grounded] "I've never worked for a software company" "I use Freshdesk every day" "3 years as a customer service advisor at an energy supplier" | The highest-ROI prep in this pack. Hold only what the sentences carry: "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day." Concede plainly: "I've never worked for a software company." Then give the limit and a plan: what you would learn first and how. Hold through two follow-ups by returning to those sentences, never by adding to them. Do not claim software support work, technical troubleshooting or product knowledge your sentences do not carry | F5 is the stated gap and the objection most likely to be asked in some form. JD because it scores the role's fit, with Skeptic delivery |
| B2 | "Tell me about a time a customer's issue had to go beyond you. What did you do?" | JD | [grounded] | Pick a time an issue went beyond what you could settle yourself. It needs the situation, what you did, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The escalations line (F4) has no evidence in your material, so this is where it is probed. It is an open prompt, so it supplies no event |
| B3 | "What is drawing you from energy customer service into software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Your own reason, in your own words. The pack has none of your reasons on file and supplies none. Say the true one briefly, then what you want from this role. The beats your sentence carries are three years, customer service advisor, energy supplier | Motivation consistency is what Skeptics score, and F1 gives them the background to ask about. EXP because it tests your own account |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" "I use Freshdesk every day" | Say a real one first, before they do. Your material offers two to choose from: "I've never worked for a software company," and the ticketing line against "I use Freshdesk every day" if their tool is a different one. State the limit in your own words, then how you would close it in the first weeks. Do not name a weakness you do not have, or one you cannot speak to | A standard Skeptic stem, aimed at F5 and F2. JD because it measures you against the listed job |
| B5 | "If we are on Zendesk, how would you handle moving from Freshdesk?" | JD | [grounded] "I use Freshdesk every day" | Start from the sentence: you use Freshdesk every day. Answer slot: if you have used Zendesk, say where and how much, in your own words; if you have not, or only barely, say so plainly and say how you would get up to speed. Do not suggest the two tools are the same | The ad as you described it lists Zendesk by name (F2). The premise, that this team is on Zendesk, is the interviewer's, so the answer does not adopt it as fact |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your three years in support and what brought you to us." | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | A short arc using only what the sentence states: three years, customer service advisor, an energy supplier. Why this move is your own reason, in your own words; the pack has none on file. End on what you want from this role | Covers the experience requirement (F1) in a friendly register. JD because it scores the stated years, with a Conversational delivery |
| C2 | "What does a good day in support look like for you?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer in your own terms. The sentence carries the shape of the day: calls and emails, around 60 of them. What makes a day good is yours to say. Keep it short; casual questions are still scored | A casual question that returns to F3's volume sentence. EXP because it tests whether your account of the work is yours |
| C3 | "What do you know about Lumenvale, and why this company?" | CO | [generic] | The pack holds no company facts this run, because the searches were refused. Before the chat, read the company's own pages and say only what you read there, naming where you read it. If you know little, say so plainly and say what you would like to learn. Do not repeat anything from memory | A company-knowledge question is near certain in a chat like this, and the pack cannot ground it, which is why it is generic |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say it as the sentence does, with the word "around" kept. Four things to be able to say in your own words: how the figure was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | The one headline number in your material (F3), and the magnet for probers. EXP because it tests whether you know your own figure |
| D2 | "Tell me about training the four new starters on your refunds process." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it with the beats the sentence states: four new starters, the refunds process, last year, trained by you. Stay at those. If asked what happened afterwards, or how you did it, answer from what you actually remember and say plainly where you do not know | F6 is your one example of working with other people, so it will be tested. EXP because it tests what was actually yours |
| D3 | "What do you do in Freshdesk on a normal day?" | JD | [grounded] "I use Freshdesk every day" | Start from the sentence. Which parts of the tool you use and which you do not is your own account, in your own words. If there are parts you have not touched, say so plainly rather than let it be found | Tests the ticketing line (F2) beyond the tool's name. JD because it scores the stated requirement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "In sixty seconds: why you over someone who has already worked at a software company?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" "I've never worked for a software company" | Pause and restate the question first. Hold what the sentences carry: "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day." Concede the real gap in your own words: "I've never worked for a software company." Hold through two follow-ups by returning to the sentences, and do not fold on them to restore harmony | B1 under time pressure, aimed at F5. JD because it tests fit, with Pressure delivery |
| E2 | "How much of that training of the four new starters was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence: you trained them. If pushed on the share, say what part was yours in your own words, and if someone else, or a set course, was part of it, say so plainly. Do not widen the sentence to cover more | An attribution probe on F6, the sentence in your material most likely to be pressed on. EXP because it tests attribution honesty |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | C1, B3 |
| "experience with Zendesk or a similar ticketing tool" | B5, D3 |
| "clear written communication" | A2, A5 |
| "confidence handling escalations" | B2, A1 |
| Software-company background (F5) | B1, B4, A4, E1 |
| Training four new starters (F6) | D2, E2 |
| Company knowledge | C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone new on this team, and how would you judge it?" | Gives you the bar to prepare against, and shows you are thinking about being useful rather than only being hired |
| R2 | "Which kinds of issues reach the team most often, and which of them end up escalated?" | Tied to the escalations line (F4); the answer shows you what to prepare for B2 and A1 |
| R3 | "How are new starters taught the product, and how long before they take customers on their own?" | Raises your software-company gap (F5) yourself, as a question about learning, which reads as planning rather than worry |
| R4 | "Which ticketing tool does the team use, and how are written replies reviewed?" | Covers F2 and F3 in one question, and the answer tells you which of B5 and A2 to rehearse harder |
| R5 | "After this chat, is there a call or video conversation, and who would I speak to next?" | Lets you prepare for the next stage and tune to the right interviewer; it asks only about the process |
| R6 | "What is the hardest part of this role that people do not expect?" | An open question that tends to produce a candid answer you can respond to, and a better closing than having none |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked for a software company or in software support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." Then a plan for learning the product, never a past |
| Owned or led the refunds process or the new starters' onboarding | Inflated form of F6 | F6's sentence at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: your material says training four new starters, not owning the process or onboarding |
| A precise daily figure, or a stated split between calls and emails | Inflated form of F3's volume sentence | "answering around 60 calls and emails a day," at its own scope. Your material gives one approximate figure for both together |

## Sources

Provided documents: your message, including the invite text, the four requirements as you described the ad, and your background. No `tuesday-dossier.md` was present.

Searches sent, all refused, none returned anything:

- "Lumenvale Software company values" — refused
- "Lumenvale Software interview process customer support specialist" — refused
- "Lumenvale Software strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have fed C3 and given VAL questions a published theme; no values-style round is detected from your inputs, so no values sheet was due either way |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | The search was refused. It would have checked the loop; your invite establishes one session, a text chat with the support team lead, so the persona weights rest on that and the hiring-manager prior |
| 3. `Lumenvale Software strategy` / recent news | unavailable | The search was refused. It would have grounded C3 and any strategy-linked case; both stay generic |
| 4. `{interviewer name} Lumenvale Software` | n/a | No name was given for the support team lead, so there was no query to form; the interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | The four requirements you gave fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the job ad → the four requirement rows quote the ad itself instead of your description of it, and any requirement you did not mention gets a row and a question
- Your own read of Lumenvale's values or about page, pasted → C3 and any values theming become `[grounded]` instead of `[generic]`
- A real escalation you handled, or a statement that you handled none → F4 moves off `none given`, and B2 becomes a story-mapped answer or a settled gap
- Whether you have used Zendesk, and what you do in Freshdesk → B5 and D3 become story-mapped instead of answer slots
- Anything you can say about the written side of your emails → F3 moves off `low`, and A2 and A5 get a story to sit beside them
- The support team lead's name → an interviewer read, persona weights adjusted from their public professional footprint, and a reverse question tied to their own path
- Anything the recruiter said about focus areas for the chat → coverage I have assumed from round-type priors becomes real
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, and it needs search permission) → a strategy brief and recent company context, so C3 stops being generic
- A `tuesday-dossier.md` from an earlier session → verified evidence and constraints that would sharpen F3 to F6, though this pack never needs one
