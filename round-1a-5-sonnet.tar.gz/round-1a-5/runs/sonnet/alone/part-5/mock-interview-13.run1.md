I'll read the skill's reference files before building the pack.
The pack is written and saved. Searches were blocked in this session, so it's built from your message alone.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-5/rooms/case-13-denied-e544f5ca/Quillmoor-Diagnostics_operations-coordinator_interview_pack.md`. I built it for a 30-minute recruiter screen with Hannah, using only what you pasted. Searches for Quillmoor's values, strategy and Hannah's public profile were all refused. So the pack has no company-specific research, and the Sources section says so.

- **Hannah's four topics are rows A2 to A5.** Salary, notice period, hybrid and why you're leaving are rehearsed in your own words:
  - Pay is your £42,000, which sits inside the £38,000–£44,000 band.
  - Hybrid is your north Bristol and "not more than three days" line.
  - The reason for leaving is your Reading sentence.
  - Nothing is added to any of them, and nothing makes you justify or defend them.
- **B3 is the highest-ROI prep.** The advert's core duty is production scheduling across planning, the warehouse and QA. Your material covers delivering schedules for three depots, so expect a probe there. The pack holds you to what you actually said and gives you a slot to answer honestly about who you coordinate with.
- **SAP is a stated limit, not a bluff.** The pack has you say "I've never used SAP", then "we run our own in-house stock system" at its own scope, then how you'd learn it. It won't coach you to call the in-house system ERP experience.
- **The stock-count figure needs ownership.** Be ready to say how the "about a third" was counted and which part was yours. C1 and E2 rehearse this, and the pack keeps the "about".

The rest of the pack covers questions for you to ask Hannah, a list of claims it won't coach, the sources and a list of what extra material would improve it. A few questions are generic insurance rather than Quillmoor-specific.

Say the word and I'll play Hannah on B3 and push back with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What is your actual notice period? Your material doesn't say, and A4 can't be filled in your own words without it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quillmoor-Diagnostics_operations-coordinator_interview_pack.md -----
# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

- **Role:** Operations Coordinator, Quillmoor Diagnostics
- **Round:** recruiter screen, Thursday 2pm, 30-minute phone call
- **Interviewer:** Hannah Lowther, Talent Partner (recruiter)
- **Built from:** your message only (the advert, your background summary and what you plan to say). No CV document, no research results (see Sources)

## How to use this pack

Personas are how a question arrives. Types are what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows published company values |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | The advert's stated requirements and terms, gaps included |
| CO | Company and strategy knowledge (none in this pack, see Sources) |
| CASE | Reasoning on a live problem from the role |

Hannah named four agenda items: salary expectations, notice period, how the hybrid pattern would work, and what is prompting the move. Those are A2 to A5, and they are certain to come up, so know them cold. The highest-ROI prep for the skills side is **B3**, the question most likely to be pressed on this candidate: production scheduling is the core of the advert and the part your material covers least. Everything from C onward is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production scheduling, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on who your depot scheduling put you in contact with. Say who, in your own words; if it was mostly you and the depots, say so plainly and describe how you schedule deliveries |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | The quote reaches the chasing in role-relevant terms. Lead with it in its own terms: you chase suppliers when orders slip. Your material does not say how slippage is spotted, so expect a probe on that, and let C3 hold it |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | Say it with its qualifiers: "about a third" and "over a year". A figure with no inspected record behind it draws a probe on how it was counted, rehearsed in C1 and E2 |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show any reporting. Answer slot: if you reported on deliveries or dispatch, say what and how often, in your own words; if you did not, or it was not yours, say so plainly and stay with the deliveries you schedule |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | The quote meets the requirement in role terms. Lead with the title, the four years and the employer type exactly as written, and nothing added to them |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel. Answer slot: if the spreadsheet was Excel, say so and name one thing you did in it, in your own words; if it was another tool, say which, and say plainly that Excel itself is newer to you if that is true |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | The stated limit is SAP: "I've never used SAP." The adjacent fact stays at its own scope: "we run our own in-house stock system." The quote does not say that system is an ERP, which is the pack's observation. Answer slot: the advert says "or similar", so expect a probe on what you did in the in-house system. If you used it for something specific, say what, in your own words; if it was not yours to use, say so plainly and stay with the first sentence. Then how you would learn SAP, said as a plan and never as a past |
| F8 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | The figure sits inside the posted band, which is the pack's observation. The words are the quote, given as you gave it |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Two days is the advert's pattern and your quote meets it. The words are the quote, with the three-day limit kept as you stated it |
| F10 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish it. Surfaced, not bridged: A4 is the rehearsal row and holds an instruction only |
| F11 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | Your sentence is the whole answer. Give it in its own words and add nothing |

## Persona table

The loop is established by your own words and Hannah's message: one 30-minute phone call with her. Weights start from the recruiter-screen prior (Conversational plus a light Skeptic), then follow her stated agenda.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly, structured around her four agenda items | high: her own message lists logistics and motivation in a friendly register, and a recruiter screen is mostly this | Know the four logistics answers in your own words; treat the casual ones as scored; use the biography arc in A1 |
| B. Skeptic | Quiet knock-out probing of the advert's requirements against your background | medium: recruiters check requirements before passing a candidate on, and the advert has a clear mismatch with a wholesaler background | Rehearse B3 until it is boring; state the stated limits plainly, then the adjacent fact at its own scope, then a learning plan |
| C. Data-Driven Prober | Pushes on how a figure was counted or what a tool was | low to medium: recruiters rarely probe numbers, but one headline figure and a named tool invite it | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| D. Case / Strategist | A short live problem from the role | low: a recruiter screen seldom runs cases, but a quick "what would you do if" is common | Clarify first, structure second, think aloud |
| E. Pressure | Time-boxed challenge to motive or attribution | low: no sign of a stress style in her message | Pause, restate, hold through two follow-ups, concede only what is true |
| F. Values / Behavioural | Scenario prompts | low: no values round is documented and no values source was read | Insurance only; these are stems, not Quillmoor's values |
| Peer Evaluator | Seam-splitting with an adjacent team | not plausible on a recruiter call; no bank | None needed this round |

## Question banks

Requirement coverage:

| Requirement | Covered by |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B3, D1 |
| "track supplier deliveries and chase late orders" | C3, D1 |
| "keep stock records accurate" | C1, D2, E2 |
| "report weekly on on-time dispatch" | B4 |
| "2+ years in operations or logistics coordination" | A1 |
| "confident with Excel" | C2 |
| "ERP experience (SAP or similar) a plus" | B2, E1 |
| "£38,000–£44,000" | A3 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A5 |
| "your notice period" | A4 |
| "what's prompting a move" | A2 |

### A. Conversational (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Three beats, each one the quote's own: the four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for the three depots and chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Keep "about". Close with the move in A2's words, then one line, in your own words, on what draws you to this role. About 90 seconds | F5, F2 and F3 are the evidence the arc rests on. EXP because it tests whether the CV-level claims hold when told aloud; the casual register is still scored |
| A2 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Your own words, whole: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Say it and stop. If she follows up on this topic, say those words again | Hannah's fourth agenda item, so the reason for leaving is a certain question (F11). EXP because it tests whether the story is consistent and plainly told |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Your own words: "I'm hoping for £42,000." The advert posts £38,000–£44,000, so the figure sits inside the band. Nothing else is coached: no range, no floor, nothing added to the figure you gave. If asked what you earn now, you can decline: "I'd rather focus on the range for this role" | Her first agenda item (F8). JD because it concerns the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Give your actual notice period, in your own words, plainly and as it stands today. Nothing is coached beyond that, because your material does not establish it | Her second agenda item (F10). JD because it is a term of the listed job; `[generic]` because no notice period was provided to build on |
| A5 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on the commute or on more days, your own words again, with nothing added | Her third agenda item (F9). JD because the two Avonmouth days are the advert's own term |

### B. Skeptic (weight: second)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've spent four years in building supplies. What attracts you to a diagnostics manufacturer?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" | The wholesaler and the four years are in the quote. What attracts you to a manufacturer is yours to say, in your own words. If what is driving the move is the office closing, A2's words already say it, so do not invent an interest you do not have. If nothing specific about diagnostics comes to mind yet, say so plainly, then say what you would want to learn first | A sector change is a natural screen for a recruiter (F5). JD because it scores fit with the listed employer; the honest branch is built in |
| B2 | "Have you worked with SAP or a similar ERP system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Plain first: "I've never used SAP." Then the adjacent fact at its own scope: "we run our own in-house stock system." Answer slot: the advert says "or similar", so expect a probe on what you did in that system. If you used it for something specific, say what, in your own words; if it was not yours to use, say so plainly and stay with the first sentence. Then how you would learn SAP, said as a plan. Hold through two follow-ups by returning to those two sentences, never by adding to them | F7 is a stated limit on a requirement the advert marks as a plus. JD because it scores a listed requirement |
| B3 | "This role coordinates production schedules between planning, the warehouse and QA. What have you done that's close to that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | **Highest-ROI prep in the pack.** Hold only what the quote carries: "I schedule deliveries for our three depots." Answer slot: expect a probe on who your depot scheduling puts you in contact with. Say who, in your own words; if it was mostly you and the depots, say so plainly and describe how you schedule deliveries. Follow-up 1, on who you coordinate with: your own words, the same slot. Follow-up 2, on what would be new for you: say what you would need to learn, as a plan and never as a past. Say where your scheduling stops before she asks, and do not describe planning or QA work you did not do | F1 is where the advert presses hardest and where your material is thinnest, so this objection will arrive in some form. JD because it scores the stated core duty |
| B4 | "The role reports weekly on on-time dispatch. Have you done that kind of reporting?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Answer slot: if you reported on deliveries or dispatch, say what and how often, in your own words. If you did not, or it was not yours, say so plainly and stay with the deliveries you schedule and the suppliers you chase. Nothing is coached beyond that, because your material does not show any reporting | F4 is a requirement your material is silent on, so a plain slot is the honest rehearsal. JD because it scores a listed duty |

### C. Data-Driven Prober (weight: middle)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how those discrepancies fell by about a third." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Keep the quote's qualifiers: "about a third" and "over a year". Four slots, each answered in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly | F3 is the one headline figure, so it is the magnet for a defend-the-number probe. EXP because it tests attribution and honest precision |
| C2 | "How confident are you in Excel, and what do you do in it?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | The quote carries a spreadsheet you rebuilt. Answer slot: if it was Excel, say so and name one thing you did in it, in your own words; if it was another tool, say which, and say plainly where Excel is newer to you. Do not rate yourself beyond what you can show | F6 is thin because the quote says spreadsheet, not Excel. JD because it scores a listed requirement |
| C3 | "Tell me about a time a supplier order slipped." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | The quote's own beat: you chase suppliers when orders slip. Answer slot: expect a probe on one particular order and what part of it was yours. If a case comes to mind, say what happened and what you did, in your own words; if no single case comes to mind, say so plainly and describe how you chase | F2 is a strong match for an advert duty, so a concrete case is likely. EXP because an open prompt tests what you actually did |

### D. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier says a key part will arrive a week late and production is scheduled for Monday. What do you do first?" | CASE | [generic] | Structure it aloud: what you need to know first (which part, which orders depend on it, whether the schedule can move, whether another source exists); who needs to hear today; what you decide and what you record. This question needs no claim about your past, so the guidance makes none | A live problem from the advert's schedule-and-chase duties (F1, F2). `[generic]` because it is a pattern for the problem, not a fact about this employer |
| D2 | "The stock record says one number and the shelf count says another. How do you work out what happened?" | CASE | [generic] | Structure it aloud: confirm the count, check recent receipts and dispatches, find where record and shelf diverged, correct and record it, then say what you would change to stop it recurring. No claim about your past is made | Live version of the advert's stock-record duty (F3). `[generic]` because it is a problem pattern |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you rather than someone who already knows SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system"; "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Pause and restate the question. Hold on the quoted facts only: four years as a logistics coordinator at a building-supplies wholesaler, and you schedule deliveries for the three depots and chase suppliers when orders slip. Concede plainly: "I've never used SAP." Hold through two follow-ups by returning to those sentences, never by adding to them. Say how you would learn SAP as a plan | F7 is the visible gap on a plus requirement, so a pressured version is plausible. JD because it scores a listed requirement; the tone is the pressure |
| E2 | "That drop in discrepancies: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold on what your sentence says: you rebuilt the stock-count spreadsheet. Answer slot: say which part of the fall you can attribute to the rebuild and which part you cannot, in your own words; if you do not know, say so plainly. Concede specifically and never fold on the rebuild | F3's quote joins the rebuild and the fall in one sentence. EXP because it is the standard attribution probe |

### F. Values / Behavioural (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose a time with a named stake, something unwelcome you said, and what happened afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem. `[generic]` because no Quillmoor values were found; this is insurance, not alignment |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Choose a time with a named customer need, the internal measure it cut across, and your decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem. `[generic]` for the same reason as F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which team would the role sit in, and who would I work with most across planning, the warehouse and QA?" | It shows you understand the role is a coordination hub, and it tells you how big the production-side contact surface is |
| R2 | "Are the two Avonmouth days set for the whole team, or agreed individually?" | It is a practical question a candidate who has thought about the commute would ask, and it clarifies how fixed the pattern is |
| R3 | "How does the team report on-time dispatch today, and what does good look like?" | It points at the advert's weekly reporting duty and gives you a target to work toward |
| R4 | "Which stock or ERP system does the team use day to day, and how are new starters trained on it?" | It shows interest in the tooling and tells you what the "SAP or similar" plus means in practice |
| R5 | "What are the next steps and timeline after this call, and who would I meet next?" | It is the standard process question, and it signals you are planning for the next round |
| R6 | "What would a good first three months look like in this role?" | It shows you are already thinking about delivery, and a recruiter can usually answer it or route you to who can |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says delivery scheduling for three depots, not production scheduling. B3's slot stays inside the depots |
| Has used SAP | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." No slot |
| Has ERP experience through the in-house stock system | Inflated form of F7 | F7's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: the quote does not say that system is an ERP. B2's slot asks only what you did in it |
| Cut discrepancies by a third through the rebuild | Inflated form of F3 | F3's quote at its own scope, with "about a third" and "over a year" kept. The limit is the pack's observation: the quote joins the rebuild and the fall but does not say how the fall was measured or attributed. C1 and E2 ask only that |
| Advanced Excel skills | Inflated form of F6 | F6's quote at its own scope: a spreadsheet you rebuilt. C2's slot asks only which tool it was and what you did in it |

## Sources

- **Provided:** your message (the advert, your background summary, what you plan to say) and Hannah Lowther's LinkedIn message. No CV, no dossier.
- **Searches sent (all refused, none returned a result):**
  - "Quillmoor Diagnostics values": refused
  - "Quillmoor Diagnostics Avonmouth news strategy": refused
  - "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused
- Nothing in this pack is drawn from the web or from model memory about Quillmoor.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | All calls were refused. It would have named the published values for the VAL bank (F1, F2 stay generic stems) |
| 2. Quillmoor Diagnostics interview process | skipped | Your own words and Hannah's message fix the loop: one 30-minute phone call with her, so persona weights follow that |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | All calls were refused. It would have supplied a CO question and a company-specific reverse question; the pack has no CO question |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | All calls were refused. It would have supported an interviewer read and a reverse question tied to her path; both are absent |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A pasted "about us" or values page for Quillmoor → a CO question, VAL questions on the real value names (F1 and F2 become grounded), and a company-specific reverse question
- Search permitted in this session, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → strategy brief and interviewer footprint; offered once
- Your notice period → A4 filled in your own words and the F10 row established
- Whether the stock-count spreadsheet was Excel, how the third was counted and which part was yours → C1, C2 and E2 become story-mapped, and F6 and F3 improve
- Any reporting you did on deliveries or dispatch, and who your depot scheduling put you in contact with → B3 and B4 become story-mapped, and F1 and F4 improve
- What you did in the in-house stock system → B2 and F7 improve
- Your CV → every fit-snapshot row's evidence is quoted from it, and medium rows can move toward high
- A tuesday-dossier.md, if you have one → verified evidence and prohibited-claims constraints replace this pack's locally built list
- The schedule of later rounds, if there are any → per-round mini-packs
