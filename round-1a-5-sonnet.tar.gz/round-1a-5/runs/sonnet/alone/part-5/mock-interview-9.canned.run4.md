I'll read the reference files before building the pack.
Research is done (5 of 6 searches, 2 of 2 fetches). Now I'm writing the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-5/rooms/case-9-canned-f7814476/Orrinsford_fourth-grade-teacher_interview_pack.md`. The invite has no job description, so I built it on a representative Illinois fourth-grade posting. Rows from that posting are marked `[inferred]`. The district's own pages supplied the panel format, its three published beliefs and the August 2026 literacy plan. I also found the principal's public background: nine years as a reading specialist, and a 2025 talk on weekly reading conferences in grades 3 to 5.

- **Biggest risk:** your résumé says you've never taught fourth grade, so expect A1 ("I see six years in third grade. What would be different for you in fourth?"). The pack has you hold what you wrote, concede that one limit plainly, and give a plan as a plan. Rehearse that first.
- **License:** it meets the invite's requirement as you've stated it, and the pack uses it that way. Check the registration against your own record before Thursday.
- **Team lead:** your résumé also says you've never been a team lead, so the pack won't coach you to claim it. If someone asks about the curriculum move, your sentence is "I led our grade level's move to a new reading curriculum in 2024", and no more.
- **Your message included a Social Security number.** It isn't needed for any of this, and I haven't used it or sent it anywhere. You may want to take it out of anything you share.

Where your résumé is silent, such as which subjects you taught, classroom routines or assessment, the pack leaves a slot with two honest answers instead of inventing details.

I can play the principal or a teammate on A1 so you can practice it live. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. Say so if you'd like a Word version of the pack.

1. Do you have the posting's full text, or anything HR told you about what the panel will focus on?
2. Do you want a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Orrinsford_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Round: one 45-minute panel on Thursday. Panel: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Built as a first pass: the invite carries no job description, so JD-derived rows rest on a representative posting and say so.

Highest-ROI prep in this pack: **A1**, the fourth-grade question. It will arrive in some form, because your material shows six years in third grade and no fourth grade. A rehearsed, non-defensive answer changes the interview. A2 and G1 feed it.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores. Answer guidance is scaffolding for a spoken answer, not a script: say it in your own words.
- Type key: **VAL** values and behavior; **EXP** work-experience deep-dive; **JD** the role's stated duties; **CO** knowledge of the district and its plans; **CASE** a live problem from the role.
- Provenance: `[grounded]` traces to your words or a source in Sources; `[inferred]` is derived from the representative posting or a reasonable extension; `[generic]` is a pattern with no claim about you or the district.
- An answer slot is an instruction for the interview, not a question for you now. Where a slot offers two branches, either is a good answer, and the second branch is a limit, not a confession.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met: kind, issuer, endorsement, status and expiry are all in the quote. The pack's own observation: the grade range you state, 1–6, includes fourth grade. It is a CV line with nothing inspected behind it, so confirm the registration against your own record before Thursday, and say it in the quote's terms |
| F2 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade and I've never been a team lead." — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn it, said as a plan and never as a past. Answer slot: name what you would find out first and from whom, in your own words |
| F3 | "experience in grades 3 to 5 preferred" — representative posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | The quote already sits inside the posting's grade range, which is typical for the role rather than this team's stated practice. Lead with it in its own terms: six years, third grade, a public elementary school in Joliet. Expect a probe, since nothing is inspected behind a CV line |
| F4 | "plan and teach reading, writing, math, science and social studies" — representative posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | The quote says the grade, not which subjects. Answer slot: the posting lists five subjects, so expect a probe on which you taught. Say which you taught, in your own words; if some were taught by others, say so plainly and stay with what you taught |
| F5 | "Panels ask about reading instruction, classroom routines and how you work with families" — Orrinsford hiring page | "I led our grade level's move to a new reading curriculum in 2024", "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | Both quotes are adjacent to reading instruction: a curriculum move and a club, at their stated scope. Words: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if you taught reading to your own class, say how it ran, in your own words; if you did not, or not in that form, say so plainly and stay with the move and the club |
| F6 | "classroom routines" — Orrinsford hiring page | none given | none | [grounded] | discovery | Your material is silent on routines. Answer slot: if you set routines in your own room, say which and why, in your own words; if you did not set them, say so plainly and say what you would put in place first, as a plan |
| F7 | "communicate regularly with families" — representative posting, K12 Jobs Board | "I write a weekly email to families." — your CV | medium | [inferred] | none | The quote already reaches the requirement in role-relevant terms: weekly, written, to families. Lead with it as stated; a named record beats an adjective |
| F8 | "each teacher speaks with every family each term" — Orrinsford Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The belief names speaking with families; your quote names a written email. Words stay at the quote: "I write a weekly email to families." Answer slot: if you also speak with families directly, say how and how often; if the email is your main channel, say so plainly |
| F9 | "work with the grade-level team" — representative posting, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | none | The quote reaches team work in role-relevant terms, at its own scope: your grade level's move. Expect a probe on what leading looked like, because your material also says you have never been a team lead. Hold both sentences exactly as you wrote them |
| F10 | "differentiate instruction using assessment data" — representative posting, K12 Jobs Board | none given | none | [inferred] | discovery | Your material is silent on assessment. The district's own belief, "assessments inform teaching and never replace it", makes a probe likely. Answer slot: if you used assessment results to adjust teaching, say which and what changed; if you did not, or not in that form, say so plainly and say what you would look at first, as a plan |
| F11 | "no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs page | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [grounded] | discovery | The district's belief is about the year you teach, and your quote names that grade without showing whether reading plans were part of it. Answer slot: if you wrote or used reading plans for your third graders, say how, in your own words; if there was no such practice, or it was not yours, say so plainly |

## Reading the interviewer

Public professional footprint only, from the source named in Sources.

| Item | What the public record shows | Practical implications |
|---|---|---|
| Principal Dolores Vantongeren: career | Principal of Halvering Elementary since 2022, after nine years as a reading specialist | Expect reading to be where the follow-ups go deepest. Do not claim reading expertise beyond your own sentences; calibrated candor reads better to someone who has specialized in it |
| Principal Dolores Vantongeren: talk | A 2025 forum talk, "Small Groups, Big Readers", on weekly reading conferences in grades 3 to 5 | Weekly small-group reading conferences are a likely theme (C2). She is the first likely reader of your curriculum-move story (A5, C3) |
| Mirror opportunity | Shared vocabulary: reading, grades 3 to 5. F5's quote carries your side: "I led our grade level's move to a new reading curriculum in 2024" | Use the shared words, not a claim of shared expertise. No shared career jump is offered: nothing in your material carries your side of one |
| Two fourth-grade team members | Names not given; nothing researched | Treated as peers; the persona table assigns the Peer Evaluator to them. Names in the upgrade menu would sharpen this |

## Persona table

The loop is established by the district's own hiring page: one 45-minute building panel of the principal and two grade-level teachers, with questions on reading instruction, classroom routines and working with families. Weights come from that page, the panel's makeup and the principal's footprint, not from an archetype.

| Persona | How it shows up | Likelihood and the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet probing of the move from third to fourth grade and of what leading meant | High. The invite is for fourth grade and your material shows third grade only (F2, F3). A principal buying capability probes the gap first | Rehearse A1 until it is boring. Bridge only from F3's quote, concede the stated limit plainly, and give a plan as a plan |
| Peer Evaluator (bank B) | The two teammates asking about planning together, routines and where your work meets theirs | High. Two of three panelists are the people who would share your grade level, and the hiring page names routines and teamwork topics | Reciprocity: what you bring and what you need. Propose principles for the seam rather than pretending to know their routines |
| Case / Strategist (bank C) | A live reading problem, a small-group or family scenario, a question on the literacy plan | Medium. The hiring page names reading instruction and families as panel topics, and the principal's talk centers on reading conferences | Clarify, set the objective, structure, then check and note risks; think aloud and ask what you need to know first |
| Conversational (bank D) | "Walk me through your journey", then casual questions on the club and families | Medium. Panels open this way, and families are a named topic. Casual questions are still scored | A 90-second arc built only from your quoted sentences; treat casual questions about reading and families as scored |
| Values / Behavioral (bank E) | Scenario questions tied to the district's three published beliefs | Medium. The mission page says the beliefs guide every hire, though no source here documents a separate values round, so no values cheat sheet is included | Choose stories where one of your quoted sentences carries the story; where none does, use the selection scaffold and its honest branch |
| Data-Driven Prober (bank F) | Asking how you know the curriculum move or the club is working | Low. Your material states no figures, so there is nothing to defend by number; the probe lands on assessment practice instead | Say plainly what you do and do not know; name no figure your material does not carry |
| Pressure (bank G) | A time-boxed "why you over someone who has taught fourth grade" | Low. The hiring page describes a panel conversation, not a stress format, but the fourth-grade gap makes one pointed question plausible | Hold the position through two follow-ups, then concede the specific limit; never fold on what your quotes carry |

## Question banks

Requirement coverage first: each stated requirement mapped to the questions that cover it.

| Requirement | Questions |
|---|---|
| Valid Illinois license with elementary endorsement (F1) | none, and why: a gate your material shows met, so no question tests it; if asked, state it in the quote's terms |
| Fourth-grade fit and grades 3 to 5 (F2, F3) | A1, A2, A4, G1 |
| Plan and teach five subjects (F4) | A3 |
| Reading instruction (F5, F11) | C1, C2, C3, D2, E1, F1 |
| Classroom routines (F6) | B4 |
| Communicate with families (F7, F8) | C1, D3, E2 |
| Work with the grade-level team (F9) | A5, B1, B2, B3, G2 |
| Differentiate using assessment data (F10) | E3, F1, F2 |

Your CV states no metric, so no defend-the-number question is included.

### Bank A: Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I see six years in third grade. What would be different for you in fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade and I've never been a team lead." | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "For six years I taught third grade at a public elementary school in Joliet." Concede the limit plainly: "I've never taught fourth grade." Then give a plan, said as a plan: answer slot, name what you would find out first and from whom, in your own words. Likely follow-up 1, "What is the biggest thing you don't know about fourth grade?": name something you honestly do not know. Follow-up 2, "Why take that on instead of someone who has taught it?": hold by returning to the sentences you wrote, add nothing, and say the difference is real | F2 and F3 are the biggest gap and the nearest evidence, so this objection arrives in some form. JD because it scores the role's stated grade level; Skeptic because it probes the gap |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." | Pick one weakness honestly from the role's duties, name it in a sentence, and say what you would do about it as a plan. The material supports "I've never taught fourth grade" as one candidate; choose the one that is true for you. If no weakness comes to mind, say so plainly, then name what you would ask the team first | A standard Skeptic stem aimed at F2. JD because it scores the listed duties |
| A3 | "This role teaches reading, writing, math, science and social studies. Which of those have you taught?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: say which subjects you taught, in your own words; if some were taught by others, or you taught a different mix, say so plainly and stay with what you taught. The five subjects are the representative posting's list, typical for the role and not this team's stated practice | F4 is a quote that names the grade and not the subjects, so the probe is likely and the honest answer needs rehearsal. JD because it scores a stated duty |
| A4 | "Why fourth grade, and why Orrinsford?" | CO | [grounded] | Your reason is yours to state, in one honest sentence; your material gives none. The district's public facts are in Sources: its three beliefs, and the 2026–2029 literacy plan the board adopted in August 2026. Refer to a fact only if you have read it and it is the real reason | Motivation consistency is the Skeptic's core score. CO because a good answer shows homework on the district, JD-adjacent because it concerns the move itself |
| A5 | "Tell me more about how you led your grade level's move to the new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never taught fourth grade and I've never been a team lead." | Story-mapped on F9, with only the beats the quote states: you led it, it was your grade level's move, the curriculum was new, the year was 2024. Tell them in your own words. Answer slot: the posting's team-work line makes a probe on how colleagues came along likely; if you brought colleagues along in a particular way, say how and which part was yours; if there was no such step, or it was not yours, say so plainly and stay with the move. If asked whether you have been a team lead, your own words: "I've never been a team lead." | F9 is the strongest evidence of team work and the likeliest place to be tested on attribution. EXP because it tests what was actually yours |

### Bank B: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you and colleagues disagreed on a teaching decision. How did it end?" | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | A selection scaffold: pick a real time, with a named decision, what you said, and how it ended with the working relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the curriculum move at its own scope, or say how you would handle it. The disagreement is not supplied: do not invent one | The posting's team line makes disagreement-with-equals a standard peer probe. JD because it scores that duty |
| B2 | "Tell me about a time work was shared across colleagues. How did you handle credit?" | VAL | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Use we for the group, I for what was yours. The quote supports "I led our grade level's move"; where you divided parts of it with colleagues, say which parts, in your own words. If no such division comes to mind, say so plainly and stay with the move | Credit-sharing is the Peer Evaluator's stem; F9 is where your material meets it. VAL because it scores collaboration conduct |
| B3 | "What would you bring to our team, and what would you need from us in your first month?" | JD | [grounded] "I've run the after-school reading club for the last two years." "I write a weekly email to families." "I've never taught fourth grade and I've never been a team lead." | Bring: the club and the weekly email, in those words and at that scope. Need: be specific about what you would ask the two fourth-grade teachers to show you, which follows from "I've never taught fourth grade"; choose the specifics that are true for you. Reciprocity first, then the ask | The reciprocity frame the Peer Evaluator rewards. F2 is the honest need, F5 and F7 the offer. JD because it scores fit with the team |
| B4 | "What routines would you put in place in the first week, and what if ours differ?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: if you set routines in your own third-grade room, say which and why, in your own words; if you did not set them, say so plainly and answer as a plan. On the "what if ours differ" half, offer principles, such as asking which routines are shared across the team, rather than pretending to know theirs | The hiring page names classroom routines as a panel topic (F6). JD because it scores a stated topic; the second half is peer-seam testing |

### Bank C: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader is reading well below grade level and the family is worried. Walk me through your first month." | CASE | [generic] | Clarify first: what you know about the child's reading, what the family has already been told and what support exists. Then the objective, your approach, how you would check progress, who else is involved, and the risks. Think aloud. Treat the family as a partner, which is the district's published belief. The question needs no claim about your past, so the guidance makes none | A live problem from the posting's reading and families duties and the district's Every Child a Reader belief. Generic pattern, not a fact about this district |
| C2 | "How would you run weekly small-group reading conferences in a fourth-grade classroom?" | CASE | [grounded] | Clarify before structuring: class size, groupings, time available. Then structure, and think aloud. Answer slot: if you have run conferences in your own room, say how, in your own words; if not, say so plainly and answer as a plan. Do not borrow the principal's vocabulary as your experience | The principal's public 2025 talk covers weekly reading conferences in grades 3 to 5. CASE because it asks for a plan, not a history |
| C3 | "The board adopted a three-year literacy plan in August 2026. Which part matters most for a fourth-grade classroom?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The plan, as published: structured phonics from kindergarten to second grade, a new grades 3 to 5 reading curriculum from fall 2027, and a family reading night at every school each term. Fourth grade falls inside grades 3 to 5, so the new curriculum lands on your room. Say which part you would watch most and why, in your own words, and what you would want to know about it. You may say you led your grade level's move to a new reading curriculum in 2024, at that scope, and no more | Recent strategy from a news source, the differentiator most candidates skip. CO because it tests homework; F5 is the one quote it touches |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey to this point." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | A 90-second arc, one beat per sentence: six years teaching third grade in Joliet; leading your grade level's move to a new reading curriculum in 2024; running the after-school reading club for two years; the weekly email to families. Close with your own reason for fourth grade, in one sentence; your material gives none | The opener is scored. The arc uses only your own sentences and leaves nothing for a follow-up to collapse |
| D2 | "Tell me about the reading club. What do the kids do there?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | The stated beats: after school, a reading club, you have run it for two years. Answer slot: the district's Every Child a Reader belief makes a probe on what happens in a session likely; if you chose the books or the format, say how, in your own words; if the format was set by someone else, say so plainly and describe what you do | F5's quote has no session detail, so the likely probe needs an honest answer ready. EXP because it tests what you did |
| D3 | "How do you keep families in the loop?" | JD | [grounded] "I write a weekly email to families." | Say it as written: "I write a weekly email to families." Answer slot: the district's Families Are Partners belief is that each teacher speaks with every family each term; if you speak with families directly as well, say how and how often; if the email is your main channel, say so plainly | F7 and F8: the quote reaches the posting's duty and sits next to, not on, the district's belief. JD because it scores a stated duty |

### Bank E: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you helped a struggling reader." | VAL | [grounded] "I've run the after-school reading club for the last two years." | Every Child a Reader. A selection scaffold: a real student (no name), what you noticed, what you changed, and what you saw afterwards, where the hard truth landed rather than a tidy ending. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the club, at its own scope, or how you would handle it | The first of the district's three published beliefs. Your quotes do not carry a struggling-reader story, so the scaffold applies. VAL because it scores a value |
| E2 | "Tell me about a time a family was worried or disagreed with you." | VAL | [grounded] "I write a weekly email to families." | Families Are Partners. A selection scaffold: a real instance, what the family raised, what you said, how it ended and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the weekly email, at its own scope, or how you would handle it | The second published belief; F8 is where your material is thinnest against it. VAL because it scores a value |
| E3 | "Tell me about a time assessment results changed what you taught." | VAL | [grounded] | Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it. A selection scaffold: the assessment, what it showed, what you changed and what followed. If no such time comes to mind, say so plainly, then say how you would use assessment as a plan. No quote of yours carries this, so none is supplied | The third published belief and the posting's assessment-data duty (F10). VAL because it scores a value |

### Bank F: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "What have you looked at to judge how the new reading curriculum is going?" | EXP | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: the posting's assessment-data line and the district's assessment belief make this probe likely; if you looked at assessment results, say which and what they told you, in your own words; if no such review happened, or it was not yours, say so plainly and stay with the move. Name no figure: your material states none | Probers go where a claim has no measure behind it (F5, F10). EXP because it tests what was actually done |
| F2 | "How would you use assessment data to group students in your first weeks?" | JD | [inferred] | Answer slot: if you used assessment results to group or adjust teaching in your own room, say how, in your own words; if not, say so plainly and answer as a plan: what you would look at first and what you would ask the team. The posting's duty is typical for the role, not this team's stated practice | F10 is silent in your material. JD because it scores a stated duty |

### Bank G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've never taught fourth grade and I've never been a team lead." | Pause, restate the question, then hold: the six years in third grade, the curriculum move, in those words. Concede the specific limit: "I've never taught fourth grade." Through two follow-ups, return to the quotes and add nothing; never fold on what they carry | The hold-then-concede structure for the Pressure persona, aimed at F2. JD because it scores fit for the stated role |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never taught fourth grade and I've never been a team lead." | Hold the quote: "I led our grade level's move." Concede specifically: answer slot, say which parts others did and which were yours, in your own words; if you cannot divide it cleanly, say so plainly. If asked about a team-lead role: "I've never been a team lead" | Attribution probes are a standard pressure stem; F9 is where yours would land. EXP because it tests what was actually yours |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved into the principal's role after nine years as a reading specialist. How does that shape what you look for in fourth-grade reading?" | Ties to the principal's own public path and shows you researched the principal, not just the district |
| R2 | "Your 2025 talk covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade room here?" | Draws on her published theme and turns an interrogation into a peer conversation |
| R3 | "The board adopted a literacy plan with a new grades 3 to 5 reading curriculum from fall 2027. What would a new fourth-grade teacher be asked to do before then?" | Signals you read the district's own news and lets you gauge the first-year load |
| R4 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the two teammates: it asks what you can give, not only what you need |
| R5 | "How does the fourth-grade team plan together, and where would a new teammate fit?" | Prepares you for B1 and B4 and shows you are already thinking about the seam |
| R6 | "What happens after the panel? Your hiring page says references are taken up afterwards." | A process question with a prep reason: it tells you the timeline and shows you read the page |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | The plain acknowledgment: "I've never taught fourth grade." No slot |
| Has been a team lead | A negative you stated, F2 | The plain acknowledgment: "I've never been a team lead." No slot |
| Chose, selected or designed the new reading curriculum | Inflated form of F5 and F9 | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The limit is the pack's observation: your material says the move, not who chose the curriculum |
| Ran or led reading across the school | Inflated form of F5 | The quote at its own scope: "I've run the after-school reading club for the last two years." |
| Speaks with every family each term | Inflated form of F7 and F8 | The quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material names an email, not conversations |
| Raised reading results through the move or the club | Inflated form of F5 | The quotes at their own scope. The pack's observation: your material states no results |

## Sources

Provided documents: the invite from Human Resources, Orrinsford Community School District; the résumé text in your message. Your message also carried a government ID number; it was not needed and was not used, and the license number on your résumé went into no search.

No JD was supplied. A fetched representative posting stands in for it, and every row built on it is labeled `[inferred]`.

Searches sent, with what came back:

1. "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
2. "Orrinsford Community School District teacher interview process panel" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
3. "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
4. "Illinois fourth grade teacher job posting elementary requirements" returned https://k12jobsboard.example/listings/fourth-grade-teacher
5. "Orrinsford Community School District strategic plan news 2026" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan

Fetches: https://orrinsfordschools.example/about/mission-and-beliefs and https://k12jobsboard.example/listings/fourth-grade-teacher. The hiring page, the principal's page and the news item were read from their search results only.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | The three published beliefs by name: rows F8, F10 and F11 and the VAL bank. No values cheat sheet: no source here documents a separate values round |
| 2. `Orrinsford Community School District interview process teacher` | yes | The loop: one 45-minute building panel of the principal and two grade-level teachers, on reading instruction, routines and families; persona weights follow it |
| 3. `Orrinsford Community School District strategy` / recent news | yes | The August 2026 literacy plan: C3 and reverse question R3 |
| 4. `Dolores Vantongeren Halvering Elementary School` | yes | The interviewer read, C2 and reverse questions R1 and R2. The two teammates are unnamed, so nothing was searched for them |
| 5. representative `Fourth Grade Teacher` JD | yes | Rows F3, F4, F7, F9 and F10 and the JD-tagged questions, all `[inferred]` |

## Upgrade menu

- The posting's full text → the `[inferred]` rows F3, F4, F7, F9 and F10 become `[grounded]`, and the JD-tagged questions re-anchor to this district's own wording
- The names of the two fourth-grade team members → per-member persona weights in the interviewer read and a reverse question tailored to each
- Anything HR said about the panel's focus → coverage tuned to it; usually one email to HR
- Your answers to the slots in F4, F5, F6, F8, F10 and F11, said outside a drill → those `discovery` and `transferability` rows regenerate from your own words
- The state's registration record for your license, if you can pull it up → F1 moves from `medium` to `high`
- A `tuesday-dossier.md` from an earlier evidence review, if you have one → verified evidence and any prohibited claims replace the ones built locally; this pack never needs it
